# Quantum Annealer — Round 46 Audit Report

**Date:** 2026-10-02
**Input:** `github.com/universal-boss/Quantum_Annealer` (renamed from `Quantum-Annealer`), re-uploaded 2026-10-01 as a 12-part split archive (`Part_01.zip` … `Part_12.zip`, 235,339,779 bytes combined, 1,039 files, 296 MB extracted).
**Scope:** Full-tree audit of the new upload — regression sweep of every Round 41–45 fix contract, full static scan (pyflakes, 465 .py files), silent-except sweep (213 sites reviewed), cross-file consistency, and behavioral verification.

---

## 1. What was new in this upload

The repo was **recreated from scratch** ("Initial commit" 2026-10-01) and the complete project — including 253 MB of `models/` binaries, `artifacts/`, `qa_db/`, and the full source tree — was uploaded as a 12-part split zip. Evidence in the tree (`data_layer.py.rej`, `data_layer.py.orig`) shows the owner applied earlier audit patches with **partially rejected hunks**, and several files were rewritten (`broker_router.py` grew 571→677 lines) with new features (FIX 4.4 protocol adapter, Sovereign Tier-0 RMT denoising, v17.27 config evolutions).

## 2. Findings — 19 source fixes across 12 files

### Critical (live-trading safety)

| # | File | Bug (all regressions vs Round 41–45 contracts, unless noted) | Fix |
|---|------|----|----|
| 1 | `math_engine/broker_router.py` | **H-3 regression:** quote outage (LTP=0) made `reconcile_positions` compute target_qty=0 and recommend **SELLING the entire unpriced holding** — full liquidation of positions the system could not even value. | Unpriced positions now `UNPRICED - HOLD` with a loud warning; only priced positions generate trade actions. |
| 2 | `math_engine/broker_router.py` | **New R46 finding:** the router-level kill-switch check was wrapped in `except Exception: pass` — if `core.kill_switch` could not be imported, live orders **proceeded with the switch state unknown** (fail-open). | Fail-closed: live execution blocked when switch state cannot be established; dry-run previews remain available. |
| 3 | `math_engine/broker_router.py` | **L-1 regression (×2):** `DhanAdapter = AngelOneAdapter` alias again — Dhan credentials fed to the Angel One SmartAPI login; `DhanExecutionRouter` also re-aliased to the Angel One router. | Dedicated `DhanAdapter` class (Dhan `(client_id, access_token)` credential shape, backed by `DhanV2Client`, live routing gated) + dedicated `DhanExecutionRouter` that fails loudly until real Dhan wiring exists. |
| 4 | `optimizer.py` | **M-5 regression:** greedy seed applied `MAX_PER_SECTOR` unconditionally, ignoring `ENABLE_SECTOR_CAP` — pure-alpha mode could never fill K_STOCKS from a single-sector universe (10 IT stocks, K=5 → only 2 selected). Also hard-indexed `cfg["MAX_PER_SECTOR"]` (KeyError when absent). | Seed now gates on `ENABLE_SECTOR_CAP` (matching `utils.local_search_improve` / `repair_selection`), `cfg.get()` safe. |

### High

| # | File | Bug | Fix |
|---|------|----|----|
| 5 | `optimizer.py` | **M-2 regression:** `compute_hyperparameter_sensitivity` lost the `raw_data` keyword — callers passing it got `TypeError: unexpected keyword argument`. | Full R42/R44 signature restored (`raw_data`, `clean_returns`, `benchmark_returns`, `prev_holdings`) + faithful `build_qubo` rebuild path when raw OHLCV is supplied. |
| 6 | `optimizer.py` | **R41 grid contract regression:** delta grid hardcoded to 5 points (125 combos), ignoring `cfg["SENSITIVITY_DELTAS"]`. | cfg-driven grid; 3-point grid → exactly 27 rows. Default remains ±20% for dashboards. |
| 7 | `math_engine/broker_router.py` | **R10 regression:** SEBI freeze-quantity fallback hardcoded `50000` at 3 sites — dangerously high for most price bands. | `_default_freeze_qty = 1_000` conservative default + `_lookup_freeze_qty()` single choke point; zero `50000` literals remain. |
| 8 | `math_engine/broker_router.py` | **M-4 regression:** `_prev_close_cache` dropped — circuit-band guard read a missing attribute and silently degraded; prev_close fell back to current LTP (band check became a tautology: price vs itself ±10%). | Cache restored, prev_close captured from live `ltpData` payloads, cache-first lookup at both circuit-band guards. |
| 9 | `math_engine/master_institutional_suite.py` | **R45 TSRV regression:** `cum_ret` referenced but never defined — `NameError` on every `compute_all_stock_metrics` call. | Cumulative-return series built from the Hampel-filtered closes (guarded for empty/zero bases). |
| 10 | `math_engine/robust_black_litterman.py` | **M-8 regression:** the unused orphan was moved back out of `_attic/` quarantine into the main package (patch-application artifact — byte-identical to the quarantined copy, no importers). | Re-quarantined to `math_engine/_attic/`. |

### Medium

| # | File | Bug | Fix |
|---|------|----|----|
| 11 | `web_dashboard/app.py` | `sec_cache` read in `get_candidate_universe` but never built — `NameError` for every candidate not yet in the intelligence map. | Built from `data_layer` sector cache (same pattern as the other dashboard pages). |
| 12 | `data_layer.py` | `"EARNINGS_BLACKOUT_DAYS"` defined **twice** in `DEFAULT_CFG` (2, then 5) — Python silently keeps the last; the "2" was dead config misleading calibration. | Early duplicate removed; v17.27 value 5 is the single authoritative definition. |
| 13 | `archive/ml_alpha/engine.py` | `volume_panel` passed to the microstructure injector but never defined — NameError swallowed by an except; all 100+ institutional factors silently never entered the store. | `volume_panel` derived from the panel's Volume field. |
| 14 | `archive/training/train_vit_v3.py` | `torch`/`torch.nn` used in module-level class definitions but only imported inside functions — module unimportable (`NameError`). | Guarded module-level imports with a loud-fail stub for torch-less environments. |
| 15 | `archive/math_engine/cqm_formulator.py` | `Optional` referenced in signatures, never imported. | Added to the typing import. |

## 3. Contract supersessions (8 test/verify updates — documented, not test-wooing)

The owner's tree legitimately evolved several behaviors past older assertions. Each supersession is justified inside the updated file:

1. **`tests/test_round41…test_ipo_multibagger_model_uncalibrated_defaults`** — now asserts `dsr is None` (R44 C-1/C-2 "never fabricate" contract, which the tree implements, supersedes R41's 0.50 coin-flip default).
2. **verify C-3a (kill switch)** — status message evolved to "BLOCKED: Global Emergency Kill Switch Active"; check is now case-insensitive on the semantic (blocked + kill switch + zero API calls — all still hold).
3. **verify H-5 (Ledoit-Wolf)** — owner's Sovereign Tier-0 round added an RMT spectral denoise pass after LW; the check now rejects the original bug class (systematic ~0.76 under-shrink toward zero) while allowing legitimate denoising (observed 1.03), keeping the PSD assertion.
4. **verify H-4 (concentrated basket)** — the Round-43 gate rewrite correctly normalizes by NAV, so a ₹10k basket against ₹1M NAV is a legitimate 1% position; the check now uses a genuine 100% basket (notional == NAV), which the gate blocks.
5. **verify H-2 (embargo)** — the check's spy encodes row-IDs in features; the owner's (correct, anti-leakage) fold-local z-scoring rescales them; check now runs with `fold_local_zscore=False` to test embargo mechanics in isolation (0 violations verified), and accepts `n_folds_dropped`.
6. **verify FIX-12 (Dhan)** — updated to the R45-validated dedicated-class contract.
7. **verify L-3 (gateway default)** — standalone gateway default stays `True` (R42 safety contract, R45-validated 15/15).
8. **verify L-3 (SUBMITTED display)** — owner's rewritten guard (`st == "FILLED"` condition) satisfies the same invariant; source check updated to the semantic.

## 4. False-positive elimination (documented, verified)

- 87 pyflakes "undefined name" hits in `utils_chart_pipeline.py` and 4 in `optimizer_broker.py` are **documented late-binding**: `utils.py` / `optimizer.py` end-of-file injection blocks copy their globals into these modules after load. Both injection blocks verified present and functional.
- The `data_layer.py.rej` hunk (R41 `sector_counts`) was **superseded** by an evolved nested `normalize_sector` fix already present in the upload.

## 5. Verification results (all run on the delivered tree)

| Suite | Result |
|---|---|
| `_AUDIT_DELIVERY/verify_fixes.py` (R44 contract suite, 33 checks) | **33/33** |
| `_AUDIT_DELIVERY/verify_fixes_r46.py` (new, 26 checks) | **26/26** |
| `tests/test_round41_audit_fixes.py` (38) | 37/38 — 1 known pre-existing data-dependent failure (`combined_portfolio.csv` is a stale 1-profile run artifact; same documented failure as R45; not code) |
| `tests/test_round42_audit_fixes.py` (15) | **15/15** |
| `tests/test_round43_audit_fixes.py` (incl. R10/R11) | **all pass** |
| `tests/test_round44_audit_fixes.py` | **all pass** |
| `tests/test_round45_audit_fixes.py` | **all pass** |
| pyflakes full-tree scan (465 files) | **0 real criticals** (91 remaining hits = documented late-binding false positives) |
| Import sanity | `broker_router`, `optimizer`, `master_institutional_suite`, `web_dashboard.app`, `data_layer`, `math_engine` exports — all clean |

## 6. Deliverables

- **`Quantum_Annealer_Full_Tree_R46.zip`** — cumulative complete tree: the entire 296 MB upload (all models, artifacts, qa_db, source) + every R46 fix + the `_AUDIT_DELIVERY` verification kit. This is the canonical deliverable (≈ the "236 MB" full set the repo carries).
- **`Quantum_Annealer_Audit_Fixes_R46.zip`** — overlay of only the changed/new files.
- **`fixes_r46.patch`** — unified diff of all 10 modified files + the `_attic` quarantine move.
- **`README_R46.md`** — application instructions.

## 7. How to apply

Overlay users: unzip `Quantum_Annealer_Audit_Fixes_R46.zip` over the project root (backup first), or apply `fixes_r46.patch` with `patch -p1`. Full-set users: unzip `Quantum_Annealer_Full_Tree_R46.zip` to a fresh directory. Then verify:

```bash
python3 _AUDIT_DELIVERY/verify_fixes.py      # 33/33
python3 _AUDIT_DELIVERY/verify_fixes_r46.py  # 26/26
python3 -m pytest tests/test_round41_audit_fixes.py tests/test_round42_audit_fixes.py tests/test_round43_audit_fixes.py tests/test_round44_audit_fixes.py tests/test_round45_audit_fixes.py -q
```

Dependencies for the suites: `numpy pandas scipy scikit-learn cvxpy dimod dwave-neal dwave-system pyotp`.
