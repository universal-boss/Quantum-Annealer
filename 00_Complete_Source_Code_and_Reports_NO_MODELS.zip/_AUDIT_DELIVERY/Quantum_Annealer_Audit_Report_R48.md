# Quantum Annealer — Round 48 Audit Report

**Date:** 3 October 2026 (IST)
**Scope:** Deep bug-hunt on the R47 corrected tree (repo HEAD `3127065`; the GitHub source is private again as of this round — API 404 — so R48 audits the cumulative corrected tree delivered as `Quantum_Annealer_Full_Tree_R47.zip`).
**Method:** Fresh pyflakes sweep over 461 modules, deep full-reads of previously unaudited trading-path modules (broker OMS, risk gateway, P&L/tax ledger, trade journal, TCA, workers/threads layer, smart order router, options hedger / GEX, realtime risk, Kalman pair engine, ML metrics), look-ahead-bias and unit-convention pattern sweeps, and cross-file consistency checks. Every fix is proven by a behavioral proof and guarded by a permanent verify suite.

---

## Findings fixed this round — 5 confirmed defects (4 primary + 1 companion), 5 source files

### R48-1 · realized_gains_ledger — legacy share derivation is sign-broken for LOSS events (grandfathering accounting silently skipped)
**File:** `core/realized_gains_ledger.py` · **Severity:** MEDIUM (tax-accounting integrity)

The Sec 112A(2) grandfathering path in `net_gains_by_category` derives a share count for legacy events that carry no `shares` field. The old derivation had two compounding defects: (a) the guard `if exit_px_f > entry_px_f > 0` only admitted GAIN events at all — a long-term LOSS (exit < entry) always fell through to `shares = None`; (b) even on its own terms, `abs(pnl) / (exit_px_f - entry_px_f)` produces a NEGATIVE share count whenever pnl < 0 (the denominator is negative), which the downstream `float(shares) > 0` gate then rejected. Net effect: pre-Feb-2018 long-term loss events were silently excluded from grandfathering accounting — the `eligible/applied` counts understated them even when an FMV feed was supplied. Fixed: shares are derived as `|pnl| / |exit − entry|` (always positive) for any non-degenerate price pair. Proven: the legacy loss event is now counted as applied with the statute-correct 0.0 adjustment (deemed cost = actual cost for losses — the step-up can never change a loss), while the classic pre-2018 gain case still gets its exact Rs 20,000 step-up reduction.

### R48-2 · _MacroRefreshWorker — fabricated 0.0 yield-curve spread (and VIX 0.0) on fetch failure
**File:** `workers/worker_threads.py` · **Severity:** MEDIUM (anti-fabrication contract violation)

When BOTH the Indian Gsec proxy (`IN10YT=RR`/`IN91DT=RR`) and the US Treasury fallback (`^TNX`/`^IRX`) fetches failed, the worker emitted `yc_spread = 0.0`, which the Macro Regime Dashboard rendered as a MEASURED "+0.00% / Flat" curve — indistinguishable from a genuinely near-flat yield curve (itself a meaningful macro signal), while VIX honestly stayed `None`. Same defect one branch up: an EMPTY VIX series fabricated `vix_val = 0.0` (VIX is never zero). Fixed: both paths now emit `None` on failure; the consumer's existing fallback chain (regime_info → "—" placeholder) renders honest unknowns, mirroring the R19/R40/R47-1 anti-fabrication contracts.

### R48-3 · RealTimeRiskMonitor — stop() can never take effect mid-interval; stop→start resurrects the old thread
**File:** `math_engine/realtime_risk.py` · **Severity:** MEDIUM (duplicate risk-monitor threads / duplicate alerts)

The monitor loop slept `interval_sec` (default 300 s) in ONE solid `time.sleep`, so `stop()`'s `join(timeout=5)` could never succeed mid-interval — "Stopped" was logged while the thread kept running. Worse, `stop()` → `start()` flipped the shared `_running` bool back to `True`, so the OLD thread never exited: two monitor threads then ran concurrently, double-emitting drawdown/VaR alerts and double-appending to the returns history (inflating the VaR window). Fixed: a per-generation `threading.Event` makes the wait interruptible (stop takes effect in <0.25 s), the old generation dies even if a new one starts immediately, and a double `start()` is refused with a warning. The R45 signed-VaR semantics are regression-proven intact.

### R48-4 · stock↔benchmark series never date-aligned — Kalman beta / RS rating / residual momentum computed on mismatched dates
**Files:** `math_engine/master_institutional_suite.py`, `math_engine/kalman_pair_trading.py` · **Severity:** HIGH (silent data-integrity corruption in paired metrics)

`compute_all_stock_metrics` extracted the stock and benchmark closes with INDEPENDENT `dropna()` calls (`b = benchmark_close.dropna().values`), so whenever date coverage differed — the index trades on days a halted / suspended / recently-listed stock does not — every `(stock_t, benchmark_t)` pair silently mixed different dates. All three paired consumers were corrupted: the Kalman filter's dynamic hedge ratio and spread z-score, `compute_relative_strength_rating`, and `compute_residual_momentum`. Fixed: the benchmark is aligned to the stock on their COMMON index before any paired computation (the stock-only metrics keep their original inputs); with fewer than 10 common dates the pair metrics degrade to an honest self-pair (beta 1, zero spread) instead of a misaligned beta. Defense-in-depth: `KalmanPairTradingEngine.filter_pair_spread` itself now aligns Series inputs on their common index (array inputs keep the element-wise contract; the R41 Kalman test passes unchanged).

### R48-4b · compute_portfolio_analytics — same misalignment class feeding Hansen SPA and active returns
**File:** `math_engine/master_institutional_suite.py` · **Severity:** MEDIUM

`b = benchmark_returns.dropna().values` dropped NaNs independently of `returns_df.dropna()`, so any row-coverage difference between the two frames silently paired portfolio day *t* with benchmark day *t′* in `hansens_superior_predictive_ability(b[:T], port_rets)` and the active-return spread `port_rets - b[:T]`. Fixed: the benchmark is reindexed to the portfolio's post-dropna rows; when it does not cover every portfolio row (≥20 common required), the code degrades honestly to the equal-weight market proxy — the same convention as passing no benchmark.

---

## Verification (all run on the corrected tree, and re-run from a FRESH extraction of the delivered zip)

| Suite | Result |
|---|---|
| `prove_r48.py` (behavioral proofs) | **30/30** |
| `_AUDIT_DELIVERY/verify_fixes_r48.py` (new permanent suite) | **33/33** |
| `_AUDIT_DELIVERY/verify_fixes.py` (R44 battery) | **33/33** |
| `_AUDIT_DELIVERY/verify_fixes_r46.py` | **26/26** |
| `_AUDIT_DELIVERY/verify_fixes_r47.py` | **31/31** |
| `tests/test_round41_audit_fixes.py` + `test_round42` | 52/53 (1 documented pre-existing stale-CSV data artifact, unchanged since R45 — regression-neutral) |
| `tests/test_round43/44/45_audit_fixes.py` | **73/73** |
| `tests/test_round6_regressions.py` (engine) | **24/24** |
| pyflakes on the 5 changed files | no new findings (pre-existing cosmetics only) |

**Total: 269 checks passing, 1 documented pre-existing failure (data artifact, not code).**

## Deliverables

| File | Contents |
|---|---|
| `Quantum_Annealer_Full_Tree_R48.zip` | **Canonical cumulative deliverable** — the complete corrected tree: all Round 41–47 fixes plus this round's 5 fixes and the new verify suite. 1,044 files. |
| `Quantum_Annealer_Audit_Fixes_R48.zip` | Overlay: only the 5 fixed source files + `verify_fixes_r48.py` |
| `fixes_r48.patch` | Unified diff, 248 lines, 10 hunks — dry-run verified against the pristine R47 baseline (applies with `patch -p1`; reproduces the fixed tree byte-exactly) |
| `Quantum_Annealer_Audit_Report_R48.md` | This report |
| `README_R48.md` | Application instructions |

## Application

```bash
# Option A — full tree (recommended)
unzip Quantum_Annealer_Full_Tree_R48.zip -d quantum_annealer_r48

# Option B — overlay onto the R47 tree
unzip -o Quantum_Annealer_Audit_Fixes_R48.zip -d /path/to/existing/tree

# Option C — patch onto the pristine R47 baseline
patch -p1 < fixes_r48.patch

# Verify (from the tree root)
python _AUDIT_DELIVERY/verify_fixes_r48.py
```
