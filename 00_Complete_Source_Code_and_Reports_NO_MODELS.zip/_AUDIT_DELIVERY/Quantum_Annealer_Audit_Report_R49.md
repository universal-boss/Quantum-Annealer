# Quantum Annealer — Round 49 Audit Report

**Date:** 3 October 2026 (IST)
**Input:** the R48 corrected tree (`Quantum_Annealer_Full_Tree_R48.zip`, md5 `2fdcbab79b3ec6376a688b581efe613c`) — the GitHub source remains private (API 404 / git auth-gated, re-confirmed this round), so R49 continues on the delivered cumulative baseline, exactly as R48 did.
**Scope:** a fresh bug-hunt over the full 469-module tree with **new scan classes not covered by any prior round** (state-write atomicity, CSV round-trip dtype corruption, merge row-multiplication, money rounding/tick alignment, float accumulation in ledger paths, retry-cap absence, logging argument integrity, pandas latent deprecations, exception-handler shadowing, numeric downcast, NaN dict keys, path-join overrides, mutable class attributes, thread-shared state), plus deep full-reads of previously unaudited modules (`math_engine/algo_execution.py`, `core/state_manager.py`, `math_engine/corporate_adjustments.py`, `data/corporate_actions_registry.py`, `math_engine/dsr_calculator.py`, `scripts/build_tax_fmv_feed.py`, the dashboard tax-optimizer region, the security-master scrip/token chain) and cross-file consistency checks (FMV-feed ↔ journal ticker key convention, AY boundary arithmetic, IST market-hours scheduling, order-quantity guard coverage).

---

## 1. Scan battery results (what was checked and found clean)

Round 49's static battery produced 1,543 raw hits across 17 scan classes; every class was triaged to real findings or documented false-positive classes:

| Scan class | Triage result |
|---|---|
| Naive/aware datetime mixing (`now()` vs tz-aware) | Clean — no mixed-convention money paths; APScheduler market-close job is explicitly `timezone="Asia/Kolkata"` |
| CSV dtype round-trip (`read_csv` without `dtype=` on id columns) | 13 hits — all defensive (`str()` coercion + `NAN` guards at every consumer, e.g. `dynamic_security_master` NSE master ingestion) |
| Merge without `validate=` | 1 hit (`optimizer.py:7018`) — downstream `set_index("ticker")` + `.loc[s]` would fail loudly on duplicates; no multiplication path |
| Money rounding / tick alignment | 105 raw hits — all display-format rounding or guarded; no NSE tick (₹0.05) quantization happens at order construction (whole-share market orders) |
| Float accumulation (`+=`/`sum()` in P&L) | `event_backtester`/`utils` open-P&L accumulations are standard backtester practice (drift ≪ 1e-6 per fill); remaining hits are `np.sum` (pairwise) or archive code |
| Unbounded network retry (`while True` + net, no break) | 1 hit — the dashboard's 12 h regime-refresh daemon (legitimate periodic worker, not a retry loop) |
| Logging placeholder/arg mismatches | 181 raw hits — all false positives of the crude counter (multi-line calls, `exc_info`, nested-call commas) |
| Pandas latent deprecations | `.fillna(method=` (removed), `.append(`, `.ix[`, chained-assignment — zero live occurrences (R45 sweep holding; chained-set hits are dict-of-dict writes, not pandas) |
| Exception-handler shadowing (broad before narrow) | None in the live tree |
| Numeric downcast on money (`astype(int32)`, `to_numeric(errors='ignore')`) | None in the live tree |
| NaN/float dict keys | None (single hit is the correct `df.replace({np.nan: None})` idiom) |
| `x in df` column-vs-value confusion | None |
| `os.path.join` absolute-override | None |
| Asserts in production code | 75 hits, all in `tests/`, `archive/`, `scratch/` or vendor docs — zero in live trading paths |
| Mutable class attributes mutated in place | 1 hit — `AgenticDesktopBridge.LIVE_LOGS` (an intentional class-level shared log buffer, single-process dashboard) |
| Threads + module-level mutable state without locks | 1 hit — `scripts/rerun_all.py` (dev harness, not shipped runtime) |
| **State-write atomicity** (new class) | **6 confirmed contract violations → R49-2** |

## 2. Verified-sound (positive controls, this round)

- **`corporate_adjustments.py` compounding math** — hand-verified the reverse-chronological CRSP adjustment for interleaved splits and dividends (split S0 2022 → dividend 2023 → split S1 2024): the `cum_split_factor` unit correction (Phase 6.2) is exactly right — the dividend factor computes identically in raw and split-adjusted terms.
- **Assessment-year arithmetic** (`realized_gains_ledger.assessment_year_for_date`) — correct Indian FY (Apr 1 – Mar 31), AY = FY + 1, label form `AY 2026-27`; the carry-forward 8-year window arithmetic (`0 < cur_yr − yr ≤ 8`) is correct.
- **FMV-feed ↔ journal ticker convention** — both sides are `.NS`-suffixed (manual paper path journals `f"{ticker}.NS"`; the shipped 565-key feed is 100% `.NS`), so the `fmv_map.get(tk)` grandfathering lookup matches. (Suspicion raised by the scan, resolved by tracing both conventions.)
- **Order-quantity guards** — all five `qty = int((w × pv) / ltp)` sites in `broker_router.py` are guarded by `ltp <= 0` fail-safe branches (R46 H-3 contract holding); the `max(ltp, 1e-4)` denominators are unreachable with ltp ≤ 0.
- **`core/state_manager.py`** — R45 deep-copy hardening and double-checked singleton locking intact and correct.
- **`math_engine/dsr_calculator.py`** — PSR/DSR/MinTRL formulas match Bailey–López de Prado (the R6 docstring alignment holding); GPR edge cases guarded.
- **`scripts/build_tax_fmv_feed.py`** — exemplary: mkstemp + fsync + os.replace write, no-fabrication missing list, offline selfcheck vectors.

---

## 3. Findings fixed this round — 3 defects (2 primary + 1 latent), 7 files changed, 2 new guard files

### R49-1 · `_AUDIT_DELIVERY/verify_fixes.py` — the shipped R44 contract suite is machine-bound (delivery-integrity defect)
**Severity:** HIGH (breaks the delivery's own verification promise)

The R44 battery — the flagship "32/32 → 33/33 behavioral proofs" suite shipped in every round's README instructions — began with `ROOT = "/home/z/my-project/audit_workspace/r46/extracted"`, an absolute path that exists only on the auditing agent's machine. On the owner's machine (or any other), `os.chdir(ROOT)` raised `FileNotFoundError` before a single check ran, so the README's own `python _AUDIT_DELIVERY/verify_fixes.py` instruction was impossible to follow. Every round since R46 re-ran it only inside a workspace that happened to match the path, so the defect survived five deliveries unnoticed. (The R46/R47/R48 suites already resolve `ROOT` from `__file__`; only the oldest suite lagged.)

**Fix:** `ROOT` is now derived from the suite file's own location (`parent.parent` of `_AUDIT_DELIVERY/`), making it self-locating on any machine. **Proven:** the suite now runs to 33/33 from an unrelated working directory on this machine (the exact crash class, previously fatal, is exercised by a permanent regression lock).

### R49-2 · Six persisted-state writes bypass the repo's own atomic-write discipline — headlined by the tax carry-forward ledger whose torn write silently zeroes carried-forward losses
**Severity:** MEDIUM-HIGH (financial-state integrity; the tax member has direct overpaid-tax consequences)

The codebase's own standard is atomic everywhere else: `utils.write_json_cache` (Phase 4.4 / R6 C-P2-4: unique-tmp + `os.replace`) and `scripts/build_tax_fmv_feed.py` (mkstemp + fsync + `os.replace`) both document the crash-torn-file hazard explicitly. Six state writes never got that treatment:

| Site | File | Torn-write consequence |
|---|---|---|
| **Tax carry-forward ledger** (writer) | `web_dashboard/app.py` | A crash/OOM-kill mid-`json.dump` left truncated JSON; the reader's except-branch returned `{}` — **every accumulated Sec 70/74 unabsorbed STCL/LTCL vintage silently treated as zero** — and the very next request *overwrote* the file, making the erasure permanent. The operator then pays capital-gains tax on losses already suffered. This was the R24-5 feature's documented "best-effort" weakness, now closed. |
| User settings | `web_dashboard/app.py` | Truncated `user_settings.json` → saved configuration silently reset to defaults on next load. |
| SEBI caps cache mirror | `data_layer.py` | Manual `open(w)+json.dump` in a module that *already imports* the atomic `write_json_cache` helper — a torn cache skipped the layer and degraded the SEBI category gates toward the static-CSV / fail-open path. |
| Dynamic Security Master cache | `data/dynamic_security_master.py` | Torn cache → empty master at boot; whenever the NSE re-sync was unavailable, the R38/R40 fail-closed listing-age gates ran against no data (every candidate unverifiable) instead of the last-good ≤24 h cache the file exists to provide. |
| Regime HMM artifact | `math_engine/regime_detector.py` | Torn `regime_hmm_latest.json` → `load_json` raises → forced full retrain or "Defensive (Stale Model)" fallback instead of keeping the last good artifact. |
| Angel One scrip token cache | `math_engine/broker_router.py` | Torn token cache → cold start re-fetch of the full scrip master before any order can be priced. |

**Fix (one pattern, six sites):** every write now goes through an atomic unique-tmp + fsync + `os.replace` install (a shared `_atomic_write_json` helper in the dashboard; delegation to `write_json_cache` in `data_layer`; inlined tmp+replace at the other three sites). The tax carry-forward additionally gains a **parse-guarded last-good `.bak` rotation** and a **reader fallback**: a torn primary now recovers the `.bak` vintage (warning-level log — never the old invisible `debug`) and only degrades to the disclosed no-brought-forward default when no good copy exists at all. The rotation is parse-guarded so a torn primary can never clobber a good backup.

**Proven:** (a) a simulated mid-write crash leaves the previous file byte-intact (the old bug class installed truncated JSON); (b) a torn carry-forward primary recovers the exact `.bak` vintage (₹120,000 STCL preserved instead of zeroed); (c) the R24/R26 oldest-vintage-first consumption math is regression-locked (₹120,000 brought − ₹75,000 consumed → ₹45,000 remainder); (d) the DSM round-trip and regime-model save write valid JSON with no tmp litter; (e) all six sites carry the pattern (source locks).

### R49-3 · `AlgoExecutionManager.record_fill` — slice state replaced while manager totals accumulate: partial fills double-count execution bookkeeping
**Severity:** MEDIUM (latent — reachable the moment partial fills are wired, which the API's own `PARTIAL` status invites)

`record_fill` **replaced** the per-slice `filled_qty` but **added** to the manager total (`self.filled_qty += filled_qty`). The two interpretations collide on any second update for the same slice: recording cumulative progress (40, then 150) left the slice field correct (150) but the manager total at 190 — **40 + 150 instead of 150**. The over-count then (a) understated `remaining_qty`, which feeds the IS adapter's early-zero path (pending slices zeroed early → the parent order under-executes vs. its target), and (b) corrupted `avg_fill_price`, whose weight used the already-drifted total. The current production caller (ui/main_window.py) records each slice's full fill exactly once, so the defect is latent today — but the method's own `PARTIAL` status documents partial updates as a supported flow, and the fix makes that flow actually correct.

**Fix:** the slice table becomes the single source of truth. Manager totals and the VWAP-style average fill price are **recomputed from the slice states** after every update, and the argument contract is pinned in the docstring (`filled_qty` = cumulative per slice, `price` = that slice's VWAP so far). For the once-per-slice production caller the arithmetic is exactly equivalent (locked by test).

---

## 4. Verification (all run on the corrected tree, and re-run from a FRESH patch-application of the delivered patch onto the pristine R48 baseline)

| Suite | Result |
|---|---|
| `_AUDIT_DELIVERY/verify_fixes_r49.py` (new permanent suite) | **27/27** |
| `_AUDIT_DELIVERY/verify_fixes.py` (R44 battery — now portable, R49-1) | **33/33** |
| `_AUDIT_DELIVERY/verify_fixes_r46.py` | **26/26** |
| `_AUDIT_DELIVERY/verify_fixes_r47.py` | **31/31** |
| `_AUDIT_DELIVERY/verify_fixes_r48.py` | **33/33** |
| `tests/test_round49_audit_fixes.py` (new) | **16/16** |
| `tests/test_round43/44/45_audit_fixes.py` + `test_round6_regressions.py` | **97/97** |
| `tests/test_round41 + round42_audit_fixes.py` | 52/53 (1 documented pre-existing stale-CSV data artifact, unchanged since R45 — regression-neutral) |
| pyflakes on all 7 changed files | **0 new findings** (counts identical to pristine R48) |
| `patch -p1 < fixes_r49.patch` onto pristine R48 | applies clean; all 9 files byte-identical to the delivered tree; verify suite 27/27 on the patched tree |
| Overlay zip onto pristine R48 | byte-identical (all 9 files) |

**Total: 266 checks passing** across the battery, plus the 16 new pytest locks.

## 5. Files in this round

| File | Change |
|---|---|
| `_AUDIT_DELIVERY/verify_fixes.py` | R49-1 portable ROOT |
| `web_dashboard/app.py` | R49-2: `_atomic_write_json` helper; tear-proof carry-forward (writer + parse-guarded `.bak` rotation + recovering reader); atomic settings write |
| `data_layer.py` | R49-2: SEBI caps cache via the atomic `write_json_cache` helper |
| `data/dynamic_security_master.py` | R49-2: atomic security-master cache save |
| `math_engine/regime_detector.py` | R49-2: atomic HMM artifact save |
| `math_engine/broker_router.py` | R49-2: atomic scrip token-cache write |
| `math_engine/algo_execution.py` | R49-3: slice-truth `record_fill` bookkeeping |
| `_AUDIT_DELIVERY/verify_fixes_r49.py` | NEW — 27-check permanent verify suite |
| `tests/test_round49_audit_fixes.py` | NEW — 16 pytest regression locks |

## 6. Round history (truth ledger)

| Round | Status |
|---|---|
| R41–R45 | Delivered (cumulative tree, four test suites) |
| R46 | Delivered — 19 fixes / 12 files |
| R47 | Delivered — 7 fixes + MockFIX companion repair |
| R48 | Delivered — 5 fixes / 5 files |
| **R49** | **Delivered (this round)** — 3 findings / 7 files + 2 guard files, verify_fixes_r49.py 27/27, patch path byte-identical |
