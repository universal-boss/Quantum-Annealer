# Quantum Annealer — Round 50 Audit Report

**Scope:** the new GitHub multi-part upload ("Round 49 Audited Baseline",
repo recreated 2026-10-03, 9 commits, 23 split zips) of the Gemini-corrected
tree. **Date:** 2026-10-03. **Auditor:** GLM (Super Z), Round 50.

---

## 1. Upload reassembly verification (the "check this new upload" ask)

### 1.1 Packaging structure
- The repo is no longer a plain tree: it ships a `README_GITHUB_UPLOAD.md`
  manifest + 23 numbered zips (`00_Complete_Source_Code…` →
  `15_DeepAlpha_Model_Part09_of_09`), all < 18 MB per GitHub's upload limit.
- **All 23 archives pass `unzip -t` integrity.** Upload commits are purely
  additive (zip blobs byte-identical across commits) — one packaging batch
  pushed progressively.
- Reassembly per the manifest's own instructions produces the full 296 MB
  tree; the 9-part DeepAlpha model reassembles exactly
  (8 × 14,680,064 + 83,521 = 117,524,033 bytes; valid pickle protocol-5
  header).
- **Manifest inaccuracies (cosmetic, unfixed):** the README table says the
  DeepAlpha model is split "Part01_of_08..Part08_of_08" while the repo ships
  9 parts labeled `_of_09`; several listed sizes are stale. The restore
  commands themselves are correct.

### 1.2 What the packaging LOST (R50-1 — the headline finding)
- **Every provenance/integrity sidecar was dropped**: all 7
  `models/*.pkl.sha256` and all 138 `models/feature_cache/*.meta.json`
  (only `artifacts/saved_ml_alpha.pkl.sha256` survived, because it lives in
  a different directory). This repeats the Round 36 upload defect (which
  deleted 28 of them) at total scale — the packaging step appears to select
  only `*.pkl` / `*.parquet` / code files.
- Consequence on the reassembled tree: `test_round33_ml_hygiene`
  (lean size/sha), `test_regime_moe_ensemble` (five-archetype integrity) and
  `test_round36::r36_6` (provenance completeness) all failed.
- **Fix (honest reconstruction):** sidecars rebuilt from the artifacts
  themselves — the sha256 sidecars ARE the hashes of the shipped bytes; each
  meta.json carries factor/version parsed from the canonical filename,
  start/end measured from the panel's own index, n_dates/n_tickers measured
  from its shape, plus an explicit `sidecar_rebuilt: true` disclosure note.
  Generator script shipped in-tree at
  `scripts/rebuild_provenance_sidecars_r50.py`.
- The R34-12b `"regenerated": true` notes belong to the retired factors_100
  cache generation (23 panels, R34 era) — that generation no longer ships
  (the current 138 panels are the clean 5-archetype rebuild, uniformly
  501×150, no ±3.5 clipping signature). No regeneration note was fabricated
  onto panels that are not substitutes; the r36_6 lock was superseded to the
  generalized disclosure contract (either era's key satisfies it).
- **Data-quality disclosure:** panels `frac_diff_03_v1_d61e3a887ff1` and
  `frac_diff_05_v1_62f3f4c0c317` are entirely NaN in this generation —
  disclosed in their sidecars (`all_nan: true`); regenerate via the live
  pipeline.

## 2. Gemini R46–R49 fix review (line-by-line, all patches + undocumented R47)

**Verdict: all sound — no regressions found.** Reviewed hunk-by-hunk:

- **R46** (19 fixes/12 files): sensitivity `raw_data`/grid contract restored;
  greedy seed sector-cap gating; Angel One freeze-qty fail-closed default
  1,000 (was 50,000); prev_close cache restored (circuit-band guard no
  longer tautological); unpriced-HOLD reconciliation (never liquidate what
  cannot be valued); kill-switch fail-closed on unverifiable state; Dhan
  de-aliased from Angel One (dedicated adapter, live routing fails loudly
  until wired); sec_cache NameError; duplicate cfg key; archive NameErrors;
  R46's own 26-check suite — all verified live.
- **R47** (7 fixes — **no patch file shipped, process gap**): SSE synthetic
  stream labeled `simulated: true` + `[DEMO]` prefix, with the frontend guard
  verified present (`dashboard.js:2650`); ExecutionStateMachine
  duplicate-report idempotent release and delta-based position contributions
  (constant-contribution math checked — reservation model preserved,
  multi-order erasure fixed); matching-engine same-ID accumulation; algo
  child orders as complete NewOrderSingles with unique child ClOrdIDs;
  **FIX 4.4 framing checked against the spec** (BodyLength = bytes from tag
  35 through the last body SOH; CheckSum = byte sum of tag 8 through the SOH
  before tag 10, mod 256, 3 digits) — genuinely conformant; Angel One
  placeOrder plain-string order-id accepted (both call sites).
- **R48** (5 fixes/5 files): legacy-loss shares derivation `|pnl|/|Δpx|`
  (Sec 112A(2) grandfathering restored for loss lots); VIX/yield-spread
  honest nulls (emitter verified — the worker has no live consumer yet, so
  no None-crash path); RiskMonitor interruptible stop with per-generation
  Event (start/stop race analyzed — sound); Kalman pair + master-suite
  benchmark DATE alignment with honest self-pair/equal-weight degradation.
- **R49** (3 findings/7 files): portable verify suite (the hardcoded
  auditor-workspace path was real); six atomic-write sites (unique tmp
  pid+tid, fsync, `os.replace`, parse-guarded `.bak` rotation — the
  tax carry-forward erasure scenario is correctly closed);
  `record_fill` slice-table-as-single-source-of-truth (production caller
  verified to call once per slice with full qty — the cumulative contract
  holds).

## 3. Full battery on the reassembled tree — triage of all 20 failures

Environment restored first (venv with torch-cpu/pyarrow/faiss/onnxruntime/
yfinance/arch/cvxpy/dimod/dwave-neal/pyotp/markdown — 13 of the 20 failures
were missing-optional-dependency artifacts, not tree defects, and cleared on
install).

| # | Failure | Root cause | Disposition |
|---|---|---|---|
| 1–4 | `test_p2_warnings::TestA3RobustBlackLitterman` ×4 | R46 quarantine moved the module; test loader stale | **R50-2 fixed** |
| 5 | `test_regime_moe_ensemble` sha256 | sidecars lost in packaging | **R50-1 fixed** |
| 6 | `test_round33` lean size/sha256 | sidecars lost | **R50-1 fixed** |
| 7 | `test_round36::r36_2` | R47 call-form refactor, stale string lock | **R50-4 fixed** |
| 8 | `test_round36::r36_6` | sidecars lost (+ generation supersession) | **R50-1 fixed** |
| 9 | `test_round17::b6` | honest-null supersession, stale literal lock | **R50-3 fixed** |
| 10 | `test_sovereign_tier0` telemetry | live-vendor flake in long batches (bisected: order/vendor-dependent, passes standalone) | **R50-6 offline-aware lock** |
| 11 | `test_ipo…holdings` (EPACKPEB) | registry gap (new 2025-listing cohort) | **R50-5 fixed** |
| 12–20 | ML/parquet suites ×9 | missing torch/pyarrow/faiss/onnxruntime in the audit env | environment; green after install |

**Post-R50 battery:** 855 passed / 3 skipped / **1 by-design data lock**
(the KMEW in-band assertion — §4). All six verify suites green
(33+26+31+33+27+28 = 178 checks).

**README_R49 truth mismatch (documented, superseded):** it claimed "full
battery: 266 checks passing; the single test_round41 failure is the known
stale-CSV artifact" — on this tree round41 passes (its stale-CSV state was
apparently resolved by the 2026-10-02 sweep artifacts) while the 20 failures
above existed. The R49 battery evidently ran only its curated command list,
not the full suite.

## 4. The unicorn market-cap gate hole (R50-5) — the substantive code finding

The 2026-10-02 sweep admitted two registry-unknown names into the 🦄 book
through the documented permissive-None mcap gate (`utils.py` feeds
`market_cap_cr` from the registry; unknown → None → gate skipped):

- **EPACKPEB.NS** (EPack Prefab Technologies, listed 01-OCT-2025 — the very
  first day it could enter the 1-2y window): true cap ~₹2,436 Cr — in-band
  by luck. Registered (derived: 100.63M shares × the tree's own ₹242.07
  sweep price; cross-checked vs public quotes ₹2,376/₹2,497 Cr).
- **KMEW.NS** (Knowledge Marine & Engineering Works, listed 14-NOV-2024):
  true cap **~₹7,484 Cr — a mid-cap ~50% above the ₹5,000 Cr ceiling**
  (screener.in 7,483 / tickertape 7,715 as of Oct 1 / blinkx 7,332 /
  univest 6,818; +151% 1-yr run). The sweep's own selection contract was
  violated, silently, because the cap was never measured.

**Fixes:** both registered at TRUE values (never in-band fabrications),
flagged ESTIMATED with full derivation comments; the 🦄 profile now pins
`REQUIRE_MCAP_BAND: True` and `ipo_gate_pass` fails CLOSED on unmeasurable
caps for opt-in profiles (disclosed reason `mcap_unmeasurable …`), while
every non-opt-in profile keeps the historical permissive contract. Locked by
`test_ipo_gate_mcap_band_required_fail_closed` (4 behavioral cases).

**The by-design lock:** the shipped `combined_portfolio.csv` still holds
KMEW (data artifact, not regenerable offline). The in-band assertion is left
unweakened and fails with `Holding KMEW.NS has market cap ₹7,484.0 Cr
outside [500, 5000] Cr!` — R40 doctrine ("the data-state locks fail on this
ship by design until the trading machine re-runs the sweep"). **Operator
action: re-run the 🦄 sweep and re-ship; the lock turns green automatically.**

## 5. Files changed (9 source + 145 generated sidecars + 3 delivery docs)

```
data_layer.py                                    M  REQUIRE_MCAP_BAND cfg (unicorn)
math_engine/institutional_research_registry.py   M  EPACKPEB + KMEW entries, ESTIMATED flags
math_engine/ipo_multibagger_math.py              M  fail-closed mcap gate + docstring
scripts/qa_bugfix_verify.py                      M  attic-aware import
scripts/rebuild_provenance_sidecars_r50.py       A  sidecar generator (in-tree)
tests/test_p2_warnings.py                        M  attic-aware loader (R50-2)
tests/test_round17_regressions.py                M  honest-null bench-Z lock (R50-3)
tests/test_round36_regressions.py                M  call-form + disclosure lock (R50-4)
tests/test_sovereign_tier0.py                    M  offline-aware telemetry lock (R50-6)
tests/test_ipo_multibagger_profile.py            M  R50 disclosure + new fail-closed lock
models/*.pkl.sha256                              A  ×7 (hashes of the shipped bytes)
models/feature_cache/*.meta.json                 A  ×138 (content-true + rebuild disclosure)
_AUDIT_DELIVERY/verify_fixes_r50.py              A  28 behavioral checks
_AUDIT_DELIVERY/fixes_r50.patch                  A  354-line unified diff (9 files)
_AUDIT_DELIVERY/README_R50.md                    A  delivery note
_AUDIT_DELIVERY/Quantum_Annealer_Audit_Report_R50.md  this report
```

## 6. Disclosed, not fixed (offline limits / cosmetic)

1. **KMEW in the shipped book** — by-design lock until the operator re-runs
   the 🦄 sweep (§4).
2. **All-NaN panels** `frac_diff_03`/`frac_diff_05` — disclosed in sidecars;
   regeneration needs the live pipeline.
3. **README_GITHUB_UPLOAD.md manifest inaccuracies** — 9 parts shipped vs
   "8 parts" documented; stale sizes. Cosmetic; the restore commands work.
4. **R47 has no patch file** — its changes are only described by
   `verify_fixes_r47.py`. Process gap in the R47 delivery; noted for the
   truth ledger. (Round 50's review of those changes found them sound.)
5. **`test_round41` README_R49 claim** — superseded by §3's triage; the
   round41 suite passes on this tree.
