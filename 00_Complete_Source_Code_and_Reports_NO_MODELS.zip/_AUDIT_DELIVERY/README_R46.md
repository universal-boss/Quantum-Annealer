# Round 46 — Quantum Annealer Audit Fixes

**What this is:** Round 46 correction set for the 2026-10-01 full re-upload
(12-part split archive, 1,039 files). 19 source fixes across 12 files +
8 documented test-contract updates + a new 26-check verification suite.

**Status:** All suites green on this exact tree —
`verify_fixes.py` 33/33 · `verify_fixes_r46.py` 26/26 ·
round-41/42/43/44/45 pytest suites 125/126 (the 1 failure is the
known pre-existing stale `combined_portfolio.csv` data artifact,
identical to the R45-era documented state, not code).

## Files changed (overlay contents)

```
optimizer.py                                   M-5 greedy-seed sector-cap gate; M-2/R41 sensitivity (raw_data, cfg grid, faithful rebuild)
math_engine/broker_router.py                   H-3 unpriced HOLD; L-1 dedicated DhanAdapter + DhanExecutionRouter; R10 freeze default 1,000; M-4 prev_close cache; fail-closed kill-switch gate
math_engine/master_institutional_suite.py      cum_ret NameError (R45 TSRV)
math_engine/_attic/robust_black_litterman.py   re-quarantined orphan (M-8)
web_dashboard/app.py                           sec_cache NameError
data_layer.py                                  duplicate EARNINGS_BLACKOUT_DAYS key
tests/test_round41_audit_fixes.py              IPO defaults contract supersession (dsr=None, documented)
archive/math_engine/cqm_formulator.py          Optional import
archive/ml_alpha/engine.py                     volume_panel NameError
archive/training/train_vit_v3.py               module-level torch/nn imports
_AUDIT_DELIVERY/verify_fixes.py                R44 suite, 33 checks (contract updates documented in-file)
_AUDIT_DELIVERY/verify_fixes_r46.py            NEW — 26 behavioral checks
_AUDIT_DELIVERY/fixes_r46.patch                unified diff (685 lines)
_AUDIT_DELIVERY/Quantum_Annealer_Audit_Report_R46.md  full report
```

## Apply

```bash
# Option A — overlay (backup your tree first)
unzip Quantum_Annealer_Audit_Fixes_R46.zip -d /path/to/QuantumAnnealer

# Option B — patch
patch -p1 < _AUDIT_DELIVERY/fixes_r46.patch

# Option C — full set
unzip Quantum_Annealer_Full_Tree_R46.zip -d FreshDir
```

## Verify

```bash
pip install numpy pandas scipy scikit-learn cvxpy dimod dwave-neal dwave-system pyotp
python3 _AUDIT_DELIVERY/verify_fixes.py       # expect 33/33
python3 _AUDIT_DELIVERY/verify_fixes_r46.py   # expect 26/26
python3 -m pytest tests/test_round4{1,2,3,4,5}_audit_fixes.py -q
```

Note: `data_layer.py.orig` and `data_layer.py.rej` in the upload are patch
application leftovers from an older round — safe to delete.
