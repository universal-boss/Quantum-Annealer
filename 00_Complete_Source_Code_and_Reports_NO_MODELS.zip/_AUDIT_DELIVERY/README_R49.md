# Quantum Annealer — Round 49 Delivery

## What's in this round

Round 49 ran a fresh bug-hunt over the R48 corrected tree with 17 scan
classes **not covered by any prior round** (state-write atomicity, CSV dtype
round-trips, merge validation, money rounding, ledger float accumulation,
retry caps, logging integrity, pandas deprecations, exception shadowing,
downcasts, NaN keys, path joins, mutable class attrs, thread-shared state)
plus deep reads of previously unaudited execution/state modules, and fixed
**3 defects**:

| ID | File(s) | Defect |
|---|---|---|
| R49-1 | `_AUDIT_DELIVERY/verify_fixes.py` | The shipped R44 suite hardcoded the auditing agent's workspace path — it crashed with `FileNotFoundError` on any other machine (including yours), breaking the README's own verify instructions. Now self-locating. |
| R49-2 | `web_dashboard/app.py`, `data_layer.py`, `data/dynamic_security_master.py`, `math_engine/regime_detector.py`, `math_engine/broker_router.py` | Six persisted-state writes bypassed the repo's own atomic-write discipline. Headline: a crash mid-write of the **tax carry-forward ledger** left truncated JSON, the reader silently returned "no brought-forward losses", and the next write made the erasure permanent — **unabsorbed STCL/LTCL vintages vanished and the tax position overstated gains**. All writes are now atomic (unique-tmp + fsync + `os.replace`); the carry-forward also gains a parse-guarded last-good `.bak` and a recovering reader. |
| R49-3 | `math_engine/algo_execution.py` | `record_fill` replaced per-slice state but accumulated manager totals — partial-fill updates double-counted `filled_qty`, understated `remaining_qty` (IS adapter under-executes) and skewed `avg_fill_price`. Slice states are now the single source of truth. |

Also verified sound this round (positive controls): corporate-actions
compounding math, AY (Apr–Mar) arithmetic, IST scheduler timezone, all five
order-qty guards, FMV-feed ↔ journal ticker convention, state-manager
hardening, DSR formulas, FMV feed builder.

## Files in this delivery

- `Quantum_Annealer_Full_Tree_R49.zip` — **canonical cumulative tree** (R41→R49), 1,046 files
- `Quantum_Annealer_Audit_Fixes_R49.zip` — overlay with just the 9 changed/new files
- `fixes_r49.patch` — unified diff (863 lines / 24 hunks), applies with `patch -p1` onto the pristine R48 baseline
- `Quantum_Annealer_Audit_Report_R49.md` — full audit report with severity, evidence and verification
- `README_R49.md` — this file

## How to apply

```bash
# Full tree (recommended)
unzip Quantum_Annealer_Full_Tree_R49.zip -d quantum_annealer_r49
cd quantum_annealer_r49

#   ...or overlay onto an existing R48 tree
unzip -o Quantum_Annealer_Audit_Fixes_R49.zip -d /path/to/r48/tree

#   ...or patch the pristine R48 baseline
patch -p1 < fixes_r49.patch
```

## How to verify

From the tree root (any machine, any working directory):

```bash
python _AUDIT_DELIVERY/verify_fixes_r49.py     # 27/27 — this round's fixes
python _AUDIT_DELIVERY/verify_fixes.py         # 33/33 — R44 battery (NOW PORTABLE — this round also fixed it)
python _AUDIT_DELIVERY/verify_fixes_r46.py     # 26/26 — R46 (regression)
python _AUDIT_DELIVERY/verify_fixes_r47.py     # 31/31 — R47 (regression)
python _AUDIT_DELIVERY/verify_fixes_r48.py     # 33/33 — R48 (regression)
python -m pytest tests/test_round49_audit_fixes.py -q        # 16/16 (new locks)
python -m pytest tests/test_round43_audit_fixes.py tests/test_round44_audit_fixes.py tests/test_round45_audit_fixes.py tests/test_round6_regressions.py -q   # 97/97
```

Full battery: **266 checks passing**; the single
`test_round41::test_combined_portfolio_csv_has_no_zero_weights` failure is
the documented pre-existing stale-CSV data artifact (unchanged since R45).
All three application paths (full tree / overlay / patch) produce
byte-identical files — proven, not assumed.

## Round history (truth ledger)

| Round | Status |
|---|---|
| R41–R45 | Delivered (cumulative tree, four test suites) |
| R46 | Delivered — 19 fixes / 12 files |
| R47 | Delivered — 7 fixes + MockFIX companion repair |
| R48 | Delivered — 5 fixes / 5 files |
| **R49** | **Delivered (this round)** — 3 findings / 7 files + 2 guard files |
