#!/usr/bin/env python3
"""
FIX VERIFICATION SUITE — Quantum Annealer audit remediations.
Run against the FIXED tree. Each test proves the buggy behavior is GONE.
Mirrors the original audit experiments (audit_repro_suite*.py).
"""
import sys, os, types
import numpy as np
import pandas as pd

# AUDIT-FIX (Round 49 — R49-1): this suite previously hardcoded the auditing
# agent's absolute workspace path (an audit_workspace/r46/extracted location),
# so on ANY other machine — including the repository owner's — it died with
# FileNotFoundError before running a single check, breaking the README's own
# "python _AUDIT_DELIVERY/verify_fixes.py" instructions. The tree root is now
# resolved relative to this file (the suite lives in _AUDIT_DELIVERY/ at the
# tree root), making the R44 contract battery portable and self-locating.
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
sys.path.insert(0, ROOT)

PASS, FAIL = "  [FIXED]", "  [STILL BROKEN]"
results = []


def report(name, ok, detail=""):
    results.append((name, ok))
    print(f"{PASS if ok else FAIL} {name}" + (f"  — {detail}" if detail else ""))


print("=" * 100)
print("FIX-1 (C-4) — OMS refuses to fabricate Rs.100 fills")
print("=" * 100)
from core.broker_oms import BrokerOrderManagementSystem
from core.risk_gateway import HardPreTradeRiskGateway
from core.tca_engine import TCAEngine
from unittest.mock import MagicMock
from core.kill_switch import MasterKillSwitch

oms = BrokerOrderManagementSystem.__new__(BrokerOrderManagementSystem)
oms.cfg = {}
oms.db = MagicMock()
oms.risk_gateway = HardPreTradeRiskGateway({})
oms.tca_engine = TCAEngine.__new__(TCAEngine)
oms.tca_engine.analyze_and_record_trade = lambda **k: {}
MasterKillSwitch.deactivate(reason="audit", operator="AUDIT")
res = oms.submit_order(broker="paper", symbol="HDFCBANK.NS", side="BUY", qty=100,
                       price=0.0, ltp=None, dry_run=True)
print(f"submit_order(price=0, ltp=None) -> success={res.get('success')}, status={res.get('status')}")
ok = (res.get("success") is False and res.get("status") == "REJECTED"
      and "NO_RELIABLE_PRICE" in str(res.get("reason")))
report("C-4a OMS rejects unpriceable orders", ok,
       f"reason={res.get('reason')!r}" if not ok else "no fabricated fill at Rs.100")
statuses = [c[1].get("status") for c in oms.db.update_order_status.call_args_list]
report("C-4a REJECTED status persisted to DB", "REJECTED" in statuses, f"statuses={statuses}")

print()
print("=" * 100)
print("FIX-2 (C-3) — kill switch gates the Angel One router path")
print("=" * 100)
from core.db_engine import get_db
db = get_db()
db.set_governance_value(key="KILL_SWITCH_ACTIVE", value="1", updated_by="AUDIT", reason="audit-test")
try:
    from core.kill_switch import MasterKillSwitch as MKS
    print(f"kill switch active: {MKS.is_active()}")
    import math_engine.broker_router as br

    calls = {"n": 0}

    class FakeSmart:
        def __init__(self, api_key=None): pass
        def placeOrder(self, params):
            calls["n"] += 1
            return {"status": True, "data": {"orderid": "FAKE-123"}}
        def ltpData(self, exch, sym, token):
            return {"status": True, "data": {"ltp": 2900.0}}
    br.SmartConnect = FakeSmart
    sys.modules.setdefault("SmartApi", types.ModuleType("SmartApi"))  # stub SDK presence
    sys.modules["SmartApi"].SmartConnect = FakeSmart
    router = br.AngelOneExecutionRouter(cfg={
        "ANGELONE_API_KEY": "k", "ANGELONE_CLIENT_ID": "c",
        "ANGELONE_PASSWORD": "p", "ANGELONE_TOTP_SECRET": "t"})
    df = router.route_basket_execution({"RELIANCE.NS": 0.05}, 1_000_000, dry_run=False)
    print(df[["Ticker", "Status", "OrderID"]].to_string(index=False))
    # R46 UPDATE: the router's block message is now "BLOCKED: Global Emergency
    # Kill Switch Active" (evolved wording). Check case-insensitively for the
    # semantic ("blocked" + "kill switch") rather than one literal string.
    _stat = df["Status"].astype(str).str.lower()
    blocked = bool(_stat.str.contains("blocked").any() and _stat.str.contains("kill switch").any())
    report("C-3a router blocks all orders under kill switch",
           blocked and calls["n"] == 0, f"SmartAPI calls={calls['n']}")
finally:
    db.set_governance_value(key="KILL_SWITCH_ACTIVE", value="0", updated_by="AUDIT", reason="cleanup")

print()
print("=" * 100)
print("FIX-3 (H-3) — quote outage no longer recommends full liquidation")
print("=" * 100)
adapter = br.AngelOneAdapter(api_key="k", client_id="c", password="p", totp_secret="t")
adapter.get_ltp = lambda sym, exchange="NSE": 0.0          # simulate quote outage
adapter.get_holdings = lambda: [{"tradingsymbol": "HDFCBANK-EQ", "quantity": 340}]
rec = adapter.reconcile_positions({"HDFCBANK.NS": 0.10, "CASH": 0.90}, 1_000_000.0)
print(rec[["Ticker", "Current Qty", "Target Qty", "Action"]].to_string(index=False))
act = str(rec.iloc[0]["Action"])
report("H-3 unpriced position is HELD, not liquidated",
       "UNPRICED" in act and "SELL" not in act, f"action={act!r}")

print()
print("=" * 100)
print("FIX-4 (H-5) — Ledoit-Wolf correlation no longer double-shrunk")
print("=" * 100)
from utils_chart_pipeline import build_correlation_matrix
from sklearn.covariance import LedoitWolf
rng = np.random.default_rng(11)
base = rng.normal(0, 0.01, (300, 1))
X = np.hstack([base, base * 0.7 + rng.normal(0, 0.006, (300, 1)),
               base * 0.5 + rng.normal(0, 0.008, (300, 1)),
               rng.normal(0, 0.01, (300, 1))])
rx = pd.DataFrame(X, columns=[f"S{i}" for i in range(4)])
lw = LedoitWolf().fit(rx.values)
std = np.sqrt(np.diag(lw.covariance_))
corr_lw = lw.covariance_ / np.outer(std, std)
out = build_correlation_matrix(rx, method="Ledoit-Wolf", shrinkage=0.25)
ratio = float(np.mean(np.abs(out.values) / np.abs(corr_lw + 1e-12)))
print(f"mean |shrunk_output| / |LW_estimator| = {ratio:.4f}  (buggy build: 0.7647)")
# R46 UPDATE: the owner's Sovereign Tier-0 round added a Marchenko-Pastur RMT
# spectral denoising pass AFTER Ledoit-Wolf estimation, so the output no longer
# equals the raw estimator bit-for-bit (observed ratio ~1.03). The H-5 bug class
# was systematic UNDER-shrinking toward zero (buggy ratio ~0.76); the assertion
# now rejects that class while allowing legitimate spectral denoising.
report("H-5 LW output not under-shrunk toward zero (ratio in 0.90..1.10)", 0.90 < ratio < 1.10, f"ratio={ratio:.4f}")
eig = np.linalg.eigvalsh(out.values)
report("H-5 output stays positive semi-definite", float(eig.min()) > -1e-8, f"min eig={eig.min():.2e}")

print()
print("=" * 100)
print("FIX-5 (M-3) — margin gate uses buying power, not raw cash")
print("=" * 100)
gw = HardPreTradeRiskGateway({"AVAILABLE_BUYING_POWER": 1_200_000.0})
w10 = {f"S{i}": 0.10 for i in range(10)}
chk = gw.validate_basket(weights=w10, total_nav=1_000_000.0, sector_map=None, available_cash=5_000.0)
print(f"10x10% basket, NAV 10L, cash 5k, buying power 12L -> {chk['status']}")
report("M-3 diversified basket PASSES with proper buying power", chk["status"] == "PASSED",
       f"violations={[v['rule'] for v in chk['violations']]}")
gw2 = HardPreTradeRiskGateway({"AVAILABLE_BUYING_POWER": 1_000_000.0})
chk2 = gw2.validate_basket(weights=w10, total_nav=1_000_000.0, sector_map=None, available_cash=5_000.0)
report("M-3 gate still fires at >=90% utilization", chk2["status"] == "BLOCKED")
gw3 = HardPreTradeRiskGateway({"RISK_MAX_MARGIN_UTILIZATION": 0.5, "AVAILABLE_BUYING_POWER": 1_200_000.0})
chk3 = gw3.validate_basket(weights=w10, total_nav=1_000_000.0, sector_map=None, available_cash=5_000.0)
report("M-3 ceiling is config-overridable (0.5 blocks 83%)", chk3["status"] == "BLOCKED")

print()
print("=" * 100)
print("FIX-6 (H-4) — submit_basket wires the portfolio-level gate")
print("=" * 100)
oms2 = BrokerOrderManagementSystem(cfg={})
MasterKillSwitch.deactivate(reason="audit", operator="AUDIT")
# R46 UPDATE: the Round-43 gate rewrite normalizes each order's notional by
# portfolio NAV (not basket notional) — a 100x100=Rs.10k basket against a
# Rs.1,000,000 NAV is a legitimate 1% position and must NOT be blocked. To test
# the 100%-concentration contract we now send a basket whose notional EQUALS NAV.
basket = oms2.submit_basket(broker="paper",
                            orders=[{"ticker": "HDFCBANK.NS", "side": "BUY", "qty": 10_000, "ltp": 100.0}],
                            total_nav=1_000_000.0, dry_run=True,
                            log_cb=lambda m: print("   |", m))
print(f"single-name 100% basket -> executed={basket['executed_count']}, blocked_by={basket.get('blocked_by')}")
report("H-4 100% concentrated basket BLOCKED at the gate",
       basket.get("blocked_by") == "PORTFOLIO_RISK_GATE" and basket["executed_count"] == 0)

print()
print("=" * 100)
print("FIX-7 (C-1/C-2) — unmeasured models refused / DSR stays None")
print("=" * 100)
import ml_alpha.regime_ensemble as re_mod
m_flow = re_mod.load_verified_model("flow")
print(f"load_verified_model('flow') on the shipped ArchWrap artifact -> {type(m_flow).__name__ if m_flow else None}")
report("C-1 wrong-class artifact refused at load", m_flow is None)

class StubModel:
    feature_names = ["z_a", "z_b"]
    def predict(self, X): return np.linspace(-1, 1, len(X))
    # NOTE: no dsr / oos_sharpe attributes

sig = pd.DataFrame({"z_a": [0.1, -0.2, 0.3, 0.0], "z_b": [0.5, 0.4, 0.2, 0.9]},
                   index=["A.NS", "B.NS", "C.NS", "D.NS"])
orig_loader = re_mod.load_verified_model
re_mod.load_verified_model = lambda key, **kw: StubModel()
try:
    router = re_mod.RegimeEnsembleRouter(primary_archetype="flow")
    _, diag = router.predict_ensemble(sig)
    print(f"stub model without dsr/oos -> ensemble_dsr={diag.get('ensemble_dsr')!r}, "
          f"ensemble_oos_sharpe={diag.get('ensemble_oos_sharpe')!r}")
    report("C-2 unmeasured stats propagate as None",
           diag.get("ensemble_dsr") is None and diag.get("ensemble_oos_sharpe") is None)

    class MeasuredModel(StubModel):
        dsr = 0.72
        oos_sharpe = 1.10
    re_mod.load_verified_model = lambda key, **kw: MeasuredModel()
    _, diag2 = router.predict_ensemble(sig)
    print(f"measured stub -> ensemble_dsr={diag2.get('ensemble_dsr')!r}")
    report("C-2 measured stats still flow through", diag2.get("ensemble_dsr") == 0.72)
finally:
    re_mod.load_verified_model = orig_loader

print()
print("=" * 100)
print("FIX-8 (H-1) — GAT diffusion is name-aligned")
print("=" * 100)
from ml_alpha.graph_attention_network import DynamicGATEngine
stocks_train = ["AAA", "BBB", "CCC", "DDD", "EEE"]
rng2 = np.random.default_rng(7)
rets = pd.DataFrame(rng2.normal(0, 0.01, (120, 5)), columns=stocks_train)
eng = DynamicGATEngine(n_heads=2, feature_dim=1, hidden_dim=4, n_epochs=3)
eng.fit_dynamic_attention(stocks=stocks_train, returns_df=rets, base_scores=np.array([0.9, 0.1, 0.5, 0.5, 0.5]))
order1 = ["AAA", "BBB", "CCC", "DDD", "EEE"]
order2 = ["CCC", "AAA", "EEE", "BBB", "DDD"]                      # permuted live order
scores1 = {n: v for n, v in zip(order1, [0.9, 0.1, 0.5, 0.5, 0.5])}
d1 = eng.propagate(np.array([scores1[n] for n in order1]), 0.30, names=order1)
d2 = eng.propagate(np.array([scores1[n] for n in order2]), 0.30, names=order2)
by_name_1 = {n: v for n, v in zip(order1, d1)}
by_name_2 = {n: v for n, v in zip(order2, d2)}
same = all(np.isclose(by_name_1[n], by_name_2[n], atol=1e-9) for n in order1)
print(f"per-name diffusion identical across caller orderings: {same}")
report("H-1 diffusion keyed by ticker name, not array position", same)
unseen = eng.propagate(np.array([0.5, 0.5, 0.5]), 0.30, names=["AAA", "ZZZ", "QQQ"])
report("H-1 unseen live universe -> input returned unchanged (honest no-op)",
       np.allclose(unseen, [0.5, 0.5, 0.5]))

print()
print("=" * 100)
print("FIX-9 (H-2/L-2) — CV embargoes on the TIME axis; fold-local normalization")
print("=" * 100)
from ml_alpha.archetype_models import compute_purged_embargo_cv_metrics
dates = pd.date_range("2023-01-01", periods=200, freq="D")
Xc = np.column_stack([np.arange(200, dtype=float)] * 3)          # row id encoded
yc = np.sin(np.arange(200) / 20.0)
received = []
def spy_fit(X_tr, y_tr, X_te):
    received.append((X_tr[:, 0].astype(int), X_te[:, 0].astype(int)))
    return X_te[:, 0]
# R46 UPDATE: fold_local_zscore=False for THIS check only — the spy encodes
# row-ids in the feature matrix and the (correct, anti-leakage) fold-local
# z-scoring transform would rescale them into garbage. Embargo mechanics are
# what this check measures.
res_cv = compute_purged_embargo_cv_metrics(Xc, yc, spy_fit, n_splits=4,
                                           embargo_fraction=0.02, as_of_dates=dates, embargo_days=28,
                                           fold_local_zscore=False)
viol = 0
for tr, te in received:
    t_lo, t_hi = dates[te.min()], dates[te.max()]
    for i in tr:
        if (t_lo - pd.Timedelta(days=28)) <= dates[i] <= (t_hi + pd.Timedelta(days=28)):
            viol += 1
print(f"train rows inside the +/-28d embargo window across folds: {viol} (buggy positional embargo: leaks)")
report("H-2 embargo excludes train rows within 28 days of the test block", viol == 0)
print(f"cv metrics keys include fold counts: {'n_folds_used' in res_cv and 'n_folds_failed' in res_cv}")
report("H-2 fold accounting reported",
       "n_folds_used" in res_cv and ("n_folds_dropped" in res_cv or "n_folds_failed" in res_cv))

print()
print("=" * 100)
print("FIX-10 (M-5) — greedy seed honors ENABLE_SECTOR_CAP=False")
print("=" * 100)
from optimizer import solve_qubo
tick = ["A1", "A2", "A3", "B1", "B2", "B3"]
sdf = pd.DataFrame({"alpha_score": [0.95, 0.90, 0.85, 0.70, 0.60, 0.50],
                    "risk_score": [0.1] * 6}, index=tick)
secs = {"A1": "SEC_A", "A2": "SEC_A", "A3": "SEC_A", "B1": "SEC_B", "B2": "SEC_B", "B3": "SEC_B"}
q = {}
for a in tick:
    for b in tick:
        q[(a, b)] = (-1.0 if a == b else 0.0)
cfg5 = {"OPTIMIZER_MODE": "Greedy", "K_STOCKS": 3, "MAX_PER_SECTOR": 1,
        "ENABLE_SECTOR_CAP": False, "MAX_WEIGHT": 0.5, "MIN_WEIGHT": 0.0}
sel5, _, _ = solve_qubo(q, sdf, secs, cfg5, log_cb=None)
print(f"ENABLE_SECTOR_CAP=False, MAX_PER_SECTOR=1 -> selected: {sorted(sel5)}")
report("M-5 pure-alpha mode may take 3 same-sector names", set(["A1", "A2", "A3"]).issubset(set(sel5)),
       f"selected={sorted(sel5)}")
cfg6 = dict(cfg5); cfg6["ENABLE_SECTOR_CAP"] = True
sel6, _, _ = solve_qubo(q, sdf, secs, cfg6, log_cb=None)
print(f"ENABLE_SECTOR_CAP=True,  MAX_PER_SECTOR=1 -> selected: {sorted(sel6)}")
report("M-5 cap still enforced when enabled",
       set(["A2", "A3"]).isdisjoint(set(sel6)) and "A1" in sel6, f"selected={sorted(sel6)}")

print()
print("=" * 100)
print("FIX-11 (M-4) — prev_close captured from the live LTP payload")
print("=" * 100)
class FakeSmart2:
    def __init__(self, api_key=None): pass
    def ltpData(self, exch, sym, token):
        return {"status": True, "data": {"ltp": 100.0, "prev_close": 80.0}}
br.SmartConnect = FakeSmart2
sys.modules["SmartApi"].SmartConnect = FakeSmart2   # _init_client imports from the module
ad2 = br.AngelOneAdapter(api_key="k", client_id="c", password="p", totp_secret="t")
ltp_val = ad2.get_ltp("RELIANCE.NS")
print(f"get_ltp -> {ltp_val}; _prev_close_cache['RELIANCE'] = {ad2._prev_close_cache.get('RELIANCE')}")
report("M-4 prev_close captured for the circuit-band guard",
       ltp_val == 100.0 and ad2._prev_close_cache.get("RELIANCE") == 80.0)

print()
print("=" * 100)
print("FIX-12 (L-1) — Dhan alias hazard removed")
print("=" * 100)
# R46 UPDATE (contract supersession): R44 removed the DhanAdapter name
# entirely; R45 restored it as a DEDICATED class (tests/test_round42's
# L-1 contract — instantiable with Dhan credentials, never equal to
# AngelOneAdapter). The dedicated-class design supersedes the removal
# design: it satisfies the same anti-aliasing hazard while keeping a
# working Dhan surface. The checks below assert the R45+ semantic.
_da = getattr(br, "DhanAdapter", None)
report("L-1 broker_router.DhanAdapter is a dedicated class (not AngelOneAdapter)",
       _da is not None and _da is not br.AngelOneAdapter)
import math_engine as me
report("L-1 math_engine.DhanAdapter is the dedicated class (not None, not AngelOneAdapter)",
       me.DhanAdapter is not None and me.DhanAdapter is not br.AngelOneAdapter)
try:
    _dadv = br.DhanAdapter("fake_client", "fake_token")
    report("L-1 DhanAdapter instantiates offline with Dhan-style credentials",
           isinstance(_dadv, br.DhanAdapter) and not isinstance(_dadv, br.AngelOneAdapter))
except Exception as _dae:
    report("L-1 DhanAdapter instantiates offline with Dhan-style credentials", False)
    print(f"   DhanAdapter init error: {_dae}")
try:
    me.DhanExecutionRouter("cid", "tok").route_basket_execution({}, 0.0)
    report("L-1 DhanExecutionRouter fails loudly", False)
except NotImplementedError as e:
    report("L-1 DhanExecutionRouter fails loudly", "audit L-1" in str(e))

print()
print("=" * 100)
print("FIX-13 (M-8) — conservative freeze default + attic quarantine")
print("=" * 100)
gw8 = HardPreTradeRiskGateway({})
report("M-8 unknown-symbol freeze limit defaults to 1,000",
       gw8._get_freeze_limit("SOMEUNKNOWNXYZ") == 1000)
from math_engine._attic import fix_engine  # noqa: F401
report("M-8 quarantined modules importable from math_engine._attic", True)
import importlib
spec = importlib.import_module("math_engine._attic.robust_black_litterman")
report("M-8 largest orphan (robust_black_litterman) quarantined", spec is not None)
report("M-8 legacy export CQMFormulator still resolves (redirected)",
       me.CQMFormulator is not None)

print()
print("=" * 100)
print("FIX-14 (M-2) — sensitivity analysis accepts raw OHLCV data")
print("=" * 100)
import inspect
from optimizer import compute_hyperparameter_sensitivity
sigp = inspect.signature(compute_hyperparameter_sensitivity)
report("M-2 signature carries raw_data param", "raw_data" in sigp.parameters)
src_m2 = inspect.getsource(compute_hyperparameter_sensitivity)
report("M-2 build_qubo called with raw_data (not signal_df)",
       "build_qubo(\n                    raw_data," in src_m2)

print()
print("=" * 100)
print("FIX-15 (M-1) — re-sync keeps the build-time risk deflation (arithmetic)")
print("=" * 100)
ALPHA, GAMMA, K, N = 1.8, 12.0, 8, 20
alpha, risk = 1.0, 1.0
deflation = max(0.80, 1.0 - 0.20 * risk)
old_term = (-ALPHA * alpha + GAMMA * (1 - 2 * K)) / N                    # buggy: raw alpha
new_term = (-ALPHA * (alpha * deflation) + GAMMA * (1 - 2 * K)) / N      # fixed: deflated
prior_term = (-ALPHA * (alpha * deflation) + GAMMA * (1 - 2 * K)) / N
delta_fixed = (-prior_term + new_term)
print(f"post-resync diagonal delta with fix: {delta_fixed:+.6f} (buggy build: "
      f"{(-prior_term + old_term):+.6f} = 20% attractiveness boost for max-risk names)")
report("M-1 resync delta is now zero for deflated names", abs(delta_fixed) < 1e-12)

print()
print("=" * 100)
print("FIX-16 (L-3) — honest defaults and display")
print("=" * 100)
gw9 = HardPreTradeRiskGateway({})
# R46 UPDATE (contract supersession): R44 briefly defaulted the standalone
# gateway to False to match the pipeline's pure-alpha profile. The R42 L-3
# contract (and R45's validated 15/15 run) keeps the SAFER standalone
# default: a gateway built without explicit config enforces sector caps
# (True); profiles that want pure-alpha pass ENABLE_SECTOR_CAP=False
# explicitly (test_l3_risk_gateway_enable_sector_cap_respects_config).
report("L-3 gateway ENABLE_SECTOR_CAP defaults to True (standalone safety; explicit False respected)",
       gw9.enable_sector_cap is True)
src_oms = open("core/broker_oms.py", encoding="utf-8").read()
# R46 UPDATE: the display guard was rewritten; the invariant is the same —
# a fill price is only ever shown for FILLED orders (SUBMITTED orders must
# not display a fabricated fill price).
report("L-3 SUBMITTED orders no longer displayed with a fill price",
       ('st == "FILLED"' in src_oms) and ('avg_fill_price' in src_oms)
       and ('_px_str = f"₹{_fp:.2f}" if _fp else' in src_oms
            or 'if res.get("avg_fill_price") and st == "FILLED"' in src_oms))

print()
print("=" * 100)
print("SUMMARY")
print("=" * 100)
n_ok = sum(1 for _, ok in results if ok)
for name, ok in results:
    if not ok:
        print(f"  !! {name}")
print(f"\n{n_ok}/{len(results)} fix verifications passed")
sys.exit(0 if n_ok == len(results) else 1)
