#!/usr/bin/env python3
"""
verify_fixes_r46.py — Round 46 audit-fix verification suite.
Run from the project root:  python3 _AUDIT_DELIVERY/verify_fixes_r46.py

Round 46 scope: the owner re-uploaded the complete project (12-part split
archive, ~235 MB, 2026-10-01). The evolved tree regressed several Round
41-45 fixes and carried new defects. This script proves each R46 fix
behaviorally.
"""
import os
import sys
import inspect

import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
sys.path.insert(0, ROOT)

results = []


def report(name, ok, detail=""):
    results.append((name, bool(ok)))
    print(f"  [{'FIXED' if ok else 'STILL BROKEN'}] {name}" + (f"  — {detail}" if detail else ""))


print("=" * 100)
print("R46-1 — Greedy seed honors ENABLE_SECTOR_CAP (M-5 regression)")
print("=" * 100)
from optimizer import solve_qubo
tick = [f"A1{i}" for i in range(5)] + [f"B2{i}" for i in range(5)]
sdf = pd.DataFrame({"alpha_score": np.linspace(1.0, 0.1, 10)}, index=tick)
secs = {s: "SEC_A" for s in tick}
q = {(s, s): -1.0 for s in tick}
cfg = {"OPTIMIZER_MODE": "Greedy", "K_STOCKS": 5, "ENABLE_SECTOR_CAP": False,
       "MAX_PER_SECTOR": 2, "MAX_WEIGHT": 0.5, "MIN_WEIGHT": 0.0}
sel, _, _ = solve_qubo(q, sdf, secs, cfg)
report("cap OFF fills K_STOCKS from a single-sector universe", len(sel) == 5,
       f"selected={len(sel)}")
cfg_on = dict(cfg); cfg_on["ENABLE_SECTOR_CAP"] = True
sel_on, _, _ = solve_qubo(q, sdf, secs, cfg_on)
report("cap ON still restricts per-sector count", len(sel_on) <= 2,
       f"selected={len(sel_on)}")

print()
print("=" * 100)
print("R46-2 — compute_hyperparameter_sensitivity: raw_data kwarg + cfg grid (M-2 / R41)")
print("=" * 100)
from optimizer import compute_hyperparameter_sensitivity
sig = inspect.signature(compute_hyperparameter_sensitivity)
report("raw_data parameter present", "raw_data" in sig.parameters)
report("clean_returns/benchmark/prev_holdings params present",
       all(p in sig.parameters for p in ("clean_returns", "benchmark_returns", "prev_holdings")))
np.random.seed(7)
tk = [f"T{i}" for i in range(6)]
sig_df = pd.DataFrame({"alpha_score": [0.9, 0.7, 0.5, 0.3, 0.2, 0.1],
                       "risk_score": [0.1] * 6}, index=tk)
sectors = {t: "Tech" if i < 3 else "Auto" for i, t in enumerate(tk)}
bq = {}
for i, s1 in enumerate(tk):
    bq[(s1, s1)] = -1.0 * sig_df.loc[s1, "alpha_score"]
    for j in range(i + 1, len(tk)):
        bq[(s1, tk[j])] = 0.5
cfg_sens = {"GAMMA": 10.0, "ALPHA": 1.5, "VOL_PENALTY": 0.5, "K_STOCKS": 3,
            "SENSITIVITY_DELTAS": [0.90, 1.00, 1.10]}
try:
    df_sens = compute_hyperparameter_sensitivity(bq, sig_df, sectors, cfg_sens, raw_data=None)
    report("raw_data=None call completes (no TypeError)", not df_sens.empty)
    report("cfg SENSITIVITY_DELTAS honored (27 rows for a 3-point grid)",
           len(df_sens) == 27, f"rows={len(df_sens)}")
except TypeError as e:
    report("raw_data=None call completes (no TypeError)", False, str(e)[:80])
    report("cfg SENSITIVITY_DELTAS honored (27 rows for a 3-point grid)", False)

print()
print("=" * 100)
print("R46-3 — DhanAdapter is a dedicated class (L-1 regression)")
print("=" * 100)
import math_engine.broker_router as br
import math_engine as me
report("broker_router.DhanAdapter is not AngelOneAdapter",
       br.DhanAdapter is not br.AngelOneAdapter)
try:
    d = br.DhanAdapter("fake_client", "fake_token")
    report("DhanAdapter instantiates offline with Dhan credentials",
           isinstance(d, br.DhanAdapter) and not isinstance(d, br.AngelOneAdapter))
except Exception as e:
    report("DhanAdapter instantiates offline with Dhan credentials", False, str(e)[:80])
try:
    me.DhanExecutionRouter("cid", "tok").route_basket_execution({}, 0.0)
    report("DhanExecutionRouter live routing fails loudly (NotImplementedError)",
           False)
except NotImplementedError as e:
    report("DhanExecutionRouter live routing fails loudly (NotImplementedError)",
           "audit L-1" in str(e))

print()
print("=" * 100)
print("R46-4 — SEBI freeze fallback conservative (R10 regression)")
print("=" * 100)
a = br.AngelOneAdapter()
report("AngelOneAdapter._default_freeze_qty == 1,000",
       getattr(a, "_default_freeze_qty", None) == 1_000)
src_br = open(os.path.join("math_engine", "broker_router.py"), encoding="utf-8").read()
report("no hardcoded 50,000 freeze fallback remains in source",
       'get("freeze_qty", 50000)' not in src_br and 'get("freeze_limit", 50000)' not in src_br)

print()
print("=" * 100)
print("R46-5 — prev_close captured from live LTP payload (M-4 regression)")
print("=" * 100)
a2 = br.AngelOneAdapter()
report("_prev_close_cache initialized", isinstance(getattr(a2, "_prev_close_cache", None), dict))


class _FakeLTP:
    def ltpData(self, exch, sym, token):
        return {"status": True, "data": {"ltp": 2900.0, "prev_close": 2850.0}}


a2._smart_api = _FakeLTP()
a2._prev_close_cache.clear()
val = a2.get_ltp("RELIANCE")
report("prev_close captured when the payload carries it",
       val == 2900.0 and a2._prev_close_cache.get("RELIANCE") == 2850.0,
       f"ltp={val}, cache={a2._prev_close_cache.get('RELIANCE')}")

print()
print("=" * 100)
print("R46-6 — Unpriced holdings are HELD, never panic-sold (H-3 regression)")
print("=" * 100)
ad = br.AngelOneAdapter()
ad.get_ltp = lambda sym, exchange="NSE": 0.0  # quote outage
ad.get_holdings = lambda: [{"tradingsymbol": "HDFCBANK-EQ", "quantity": 340}]
rec = ad.reconcile_positions({"HDFCBANK.NS": 0.10, "CASH": 0.90}, 1_000_000.0)
act = str(rec.iloc[0]["Action"])
report("unpriced position -> UNPRICED-HOLD (no SELL)",
       "UNPRICED" in act and "SELL" not in act, f"action={act!r}")

print()
print("=" * 100)
print("R46-7 — Router kill-switch gate is fail-closed")
print("=" * 100)
import re as _re
m = _re.search(r"def route_basket_execution.*?(?=\n    def |\nclass |\Z)",
               src_br, _re.S)
_route_src = m.group(0) if m else ""
report("kill-switch check no longer swallowed by bare except",
       "except Exception:\n            pass" not in _route_src
       and "failing CLOSED" in _route_src)

print()
print("=" * 100)
print("R46-8 — master_institutional_suite cum_ret defined (R45 TSRV regression)")
print("=" * 100)
src_ms = open(os.path.join("math_engine", "master_institutional_suite.py"),
              encoding="utf-8").read()
report("cum_ret is built from filtered closes before the Snell call",
       "cum_ret = _cc / _cc0 - 1.0" in src_ms)
try:
    from math_engine.master_institutional_suite import MasterInstitutionalSuite as MS
    rng = np.random.default_rng(3)
    closes = 100 + np.cumsum(rng.normal(0, 0.8, 260))
    highs = closes * 1.01
    lows = closes * 0.99
    vols = np.abs(rng.normal(1e6, 1e5, 260))
    out = None
    for _m in ("compute_all_stock_metrics", "compute_stock_metrics"):
        fn = getattr(MS, _m, None)
        if fn is None:
            continue
        try:
            out = fn("TEST.NS", pd.Series(closes), pd.Series(vols),
                     high=pd.Series(highs), low=pd.Series(lows),
                     benchmark_close=pd.Series(closes * 0.9))
            break
        except Exception as _me:
            print(f"      (note: {_m} attempt: {_me})")
            continue
    report("suite metric call completes without NameError (cum_ret)", out is not None)
except Exception as e:
    report("suite metric call completes without NameError (cum_ret)", False, str(e)[:90])

print()
print("=" * 100)
print("R46-9 — web_dashboard sec_cache built before use")
print("=" * 100)
src_wd = open(os.path.join("web_dashboard", "app.py"), encoding="utf-8").read()
report("sec_cache constructed from the sector cache in get_candidate_universe",
       "sec_cache = _read_sec_cache(_SEC_PATH, {})" in src_wd)

print()
print("=" * 100)
print("R46-10 — data_layer DEFAULT_CFG single EARNINGS_BLACKOUT_DAYS key")
print("=" * 100)
src_dl = open("data_layer.py", encoding="utf-8").read()
_head = src_dl.split("DEFAULT_CFG = {", 1)[1]
_depth = 1
for _i, _ch in enumerate(_head):
    if _ch == "{":
        _depth += 1
    elif _ch == "}":
        _depth -= 1
    if _depth == 0:
        break
_body = _head[:_i]
import re as _re46
n_key = len(_re46.findall(r'^\s*"EARNINGS_BLACKOUT_DAYS"\s*:', _body, _re.M))
report("EARNINGS_BLACKOUT_DAYS defined exactly once in DEFAULT_CFG", n_key == 1,
       f"key-definitions={n_key} (v17.27 value 5 authoritative)")

print()
print("=" * 100)
print("R46-11 — Archive modules import-safe (Optional / volume_panel / torch)")
print("=" * 100)
import py_compile
for _f in ("archive/math_engine/cqm_formulator.py",
           "archive/ml_alpha/engine.py",
           "archive/training/train_vit_v3.py"):
    try:
        py_compile.compile(_f, doraise=True)
        report(f"{_f} compiles", True)
    except Exception as e:
        report(f"{_f} compiles", False, str(e)[:80])
src_e = open("archive/ml_alpha/engine.py", encoding="utf-8").read()
report("volume_panel derived from the panel (no NameError path)",
       "volume_panel = panel.get(\"Volume\", pd.DataFrame())" in src_e)
try:
    import archive.training.train_vit_v3 as _tv
    report("train_vit_v3 importable without torch installed", True)
except Exception as e:
    report("train_vit_v3 importable without torch installed", False, str(e)[:80])

print()
print("=" * 100)
print("R46-12 — Uncalibrated IPO model refuses to fabricate DSR (C-1/C-2 kept)")
print("=" * 100)
from ml_alpha.ipo_model import IPOMultibaggerModel
_m = IPOMultibaggerModel()
report("uncalibrated dsr is None (refused, not fabricated 0.50)",
       _m.dsr is None)
report("uncalibrated oos_sharpe is 0.0", _m.oos_sharpe == 0.0)

print()
print("=" * 100)
print("SUMMARY")
print("=" * 100)
n_ok = sum(1 for _, ok in results if ok)
for name, ok in results:
    if not ok:
        print(f"  !! {name}")
print(f"\n{n_ok}/{len(results)} R46 fix verifications passed")
sys.exit(0 if n_ok == len(results) else 1)
