#!/usr/bin/env python3
"""Round 48 fix verification suite — Quantum Annealer.

Run from the project root of the CORRECTED tree:
    python _AUDIT_DELIVERY/verify_fixes_r48.py

Verifies the 5 Round-48 fixes (R48-1 .. R48-4b) on the corrected source:
  R48-1  core/realized_gains_ledger.py — legacy share derivation produced
         NEGATIVE shares for loss events (and skipped loss events entirely),
         silently disabling Sec 112A(2) grandfathering accounting for
         pre-Feb-2018 long-term losses.
  R48-2  workers/worker_threads.py — _MacroRefreshWorker fabricated
         yc_spread = 0.0 (and VIX = 0.0 for an empty series) when every
         network path failed; a failed fetch was displayed as a measured
         "+0.00% Flat" curve / impossible VIX-0 reading.
  R48-3  math_engine/realtime_risk.py — the monitor loop slept the full
         interval (default 300 s) in one solid time.sleep, so stop() could
         never join in time and a stop()->start() cycle resurrected the old
         thread via the shared _running bool → duplicate monitor threads and
         duplicate drawdown/VaR alerts.
  R48-4  math_engine/master_institutional_suite.py + kalman_pair_trading.py —
         stock-vs-benchmark series were never date-aligned; independent
         dropna() shifted every (stock_t, benchmark_t) pair fed to the Kalman
         hedge ratio, residual momentum, and RS rating (4b: same class of bug
         in compute_portfolio_analytics feeding Hansen SPA + active returns).
"""
from __future__ import annotations

import sys
import time
import types
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

PASS = 0
FAIL = 0
_failures: list = []


def check(name: str, cond: bool, detail: str = "") -> None:
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  [PASS] {name}")
    else:
        FAIL += 1
        _failures.append((name, detail))
        print(f"  [FAIL] {name} {detail}")


def section(title: str) -> None:
    print(f"\n{'─' * 76}\n{title}\n{'─' * 76}")


# ═══════════════════════════════════════════════════════════════════════════
section("R48-1 — realized-gains ledger: legacy loss-event share derivation")
# ═══════════════════════════════════════════════════════════════════════════
import tempfile

from core.realized_gains_ledger import RealizedGainsLedger

tmp = Path(tempfile.mkdtemp(prefix="vfy_r48_ledger_"))
led = RealizedGainsLedger(storage_path=tmp / "rg.json")

# Pre-Feb-2018 LONG-TERM LOSS with NO share count (legacy row).
ev = led.record_realized_close({
    "id": "LOSS2019", "ticker": "LEGACY.NS",
    "entry_date": "2017-06-01", "exit_date": "2020-01-15",
    "entry_price": 200.0, "exit_price": 150.0,
    "shares": None, "realized_pnl_%": -25.0, "weight_pct": 5.0,
})
check("legacy LTCG loss event recorded", ev is not None)
check("event classified LTCG (>365d holding)", bool(ev) and ev["tax_category"] == "LTCG")

res = led.net_gains_by_category(
    "AY 2020-21", portfolio_value_inr=1_000_000.0,
    fmv_31jan2018={"LEGACY.NS": 180.0},
)
gf = res.get("grandfathering", {})
check("grandfathering now APPLIES to the pre-2018 loss event (eligible+applied counted)",
      gf.get("applied_events", 0) == 1 and gf.get("eligible_events", 0) >= 1,
      f"got {gf}")
# Statute math: for a loss (exit<entry), deemed cost = max(entry, min(FMV, exit))
# always collapses to `entry` — the step-up never changes a loss's P&L; the
# fix is the honest share derivation + eligible/applied counting.
check("loss-event adjustment remains exactly 0.0 (deemed cost = actual cost)",
      abs(gf.get("adjustment_inr", 1.0)) < 1e-9, f"adj={gf.get('adjustment_inr')}")

# The classic grandfathering gain case must keep working (regression guard).
led2 = RealizedGainsLedger(storage_path=tmp / "rg2.json")
led2.record_realized_close({
    "id": "GAIN2019", "ticker": "OLDGAIN.NS",
    "entry_date": "2016-01-01", "exit_date": "2020-03-02",
    "entry_price": 100.0, "exit_price": 400.0,
    "shares": 100, "realized_pnl_%": 300.0, "weight_pct": 5.0,
})
res2 = led2.net_gains_by_category("AY 2020-21", fmv_31jan2018={"OLDGAIN.NS": 300.0})
gf2 = res2.get("grandfathering", {})
check("pre-2018 gain: grandfathering applied", gf2.get("applied_events", 0) == 1)
check("pre-2018 gain: step-up adjustment exactly -20000 INR (100 shares x Rs200)",
      abs(gf2.get("adjustment_inr", 0.0) + 20000.0) < 0.01,
      f"adj={gf2.get('adjustment_inr')}")

# Unit demo: the derivation formula itself.
pnl, entry_px, exit_px = -5000.0, 200.0, 150.0
check("old formula produced NEGATIVE shares on losses (bug reproduction)",
      (abs(pnl) / (exit_px - entry_px)) < 0)
check("new formula |pnl|/|exit-entry| derives the correct +100 shares",
      abs(abs(pnl) / abs(exit_px - entry_px) - 100.0) < 1e-9)

src = (ROOT / "core" / "realized_gains_ledger.py").read_text(encoding="utf-8")
check("source: corrected derivation (abs/abs) present",
      "abs(pnl) / abs(exit_px_f - entry_px_f)" in src)
check("source: gain-only guard removed",
      "if exit_px_f > entry_px_f > 0 and" not in src)


# ═══════════════════════════════════════════════════════════════════════════
section("R48-2 — macro refresh worker: no fabricated 0.0 readings on fetch failure")
# ═══════════════════════════════════════════════════════════════════════════
# Stub Qt so the worker module imports headlessly (no PySide6/PyQt5 needed).
for _qt_pkg in ("PySide6", "PyQt5"):
    _qtcore = types.ModuleType(f"{_qt_pkg}.QtCore")

    class _FakeSignal:
        def __init__(self, *a, **k): pass
        def __get__(self, obj, objtype=None): return self
        def connect(self, *a, **k): pass
        def emit(self, *a, **k): pass

    class _FakeQtEnum:
        def __getattr__(self, name): return 0

    _qtcore.QThread = type("QThread", (), {"__init__": lambda self, *a, **k: None})
    _qtcore.QObject = type("QObject", (), {"__init__": lambda self, *a, **k: None})
    _qtcore.Signal = _FakeSignal
    _qtcore.pyqtSignal = _FakeSignal
    _qtcore.Qt = _FakeQtEnum()
    _pkg = types.ModuleType(_qt_pkg)
    _pkg.QtCore = _qtcore
    sys.modules[_qt_pkg] = _pkg
    sys.modules[f"{_qt_pkg}.QtCore"] = _qtcore

import workers.worker_threads as wt  # noqa: E402


class _CaptureSignal:
    def __init__(self):
        self.captured = None
    def emit(self, *args):
        self.captured = args


class _FakeMacroWorker(wt._MacroRefreshWorker):
    def __init__(self):
        self._regime_info = {}
    def start(self):
        self.run()


_fw = _FakeMacroWorker()
_fw.done = _CaptureSignal()

import data.price_feed as pf
import utils

_orig_sd = pf.safe_download
_pf_mod = sys.modules["data.price_feed"]


class _DeadProvider:
    def get_vix(self):
        raise RuntimeError("network down")


utils._DATA_PROVIDER = _DeadProvider()


def _boom(*a, **k):
    raise RuntimeError("network down")


pf.safe_download = _boom
try:
    _fw.run()
finally:
    pf.safe_download = _orig_sd

_vix_got, _yc_got = _fw.done.captured
check("total fetch failure → VIX honestly None", _vix_got is None, f"vix={_vix_got}")
check("total fetch failure → yc_spread honestly None (was fabricated 0.0)",
      _yc_got is None, f"yc={_yc_got}")

wsrc = Path(wt.__file__).read_text(encoding="utf-8")
check("source: yc_spread 0.0 fabrication line removed",
      "yc_spread = _spread if _spread is not None else 0.0" not in wsrc)
check("source: VIX 0.0 fabrication on empty series removed",
      "if not vix_raw.empty else 0.0" not in wsrc)
legacy = (ROOT / "archive" / "ui" / "legacy_widgets.py").read_text(encoding="utf-8")
check("consumer still renders the '—' placeholder for None spread",
      "yc_spread is not None else" in legacy)


# ═══════════════════════════════════════════════════════════════════════════
section("R48-3 — RealTimeRiskMonitor: responsive stop + single-thread lifecycle")
# ═══════════════════════════════════════════════════════════════════════════
from math_engine.realtime_risk import RealTimeRiskMonitor

mon = RealTimeRiskMonitor(weights={"A": 1.0}, interval_sec=300)
_t0 = time.time()
mon.start()
time.sleep(0.4)          # thread is inside the 300 s wait
mon.stop()
check("stop() joins the thread mid-interval (was impossible: solid 300 s sleep)",
      mon._thread is not None and not mon._thread.is_alive(),
      f"elapsed={time.time() - _t0:.2f}s")
check("stop() returns well under the interval", time.time() - _t0 < 5.0)

mon2 = RealTimeRiskMonitor(weights={"A": 1.0}, interval_sec=300)
mon2.start()
_old = mon2._thread
time.sleep(0.3)
mon2.stop()
mon2.start()             # immediate restart — the resurrection hazard
_new = mon2._thread
time.sleep(0.3)
check("stop()->start(): OLD thread stays dead (was resurrected by shared _running)",
      _old is not _new and not _old.is_alive())
check("exactly one live monitor thread after restart", _new.is_alive() and not _old.is_alive())
mon2.start()             # double-start refused
check("double start() refused — no second thread spawned", mon2._thread is _new)
mon2.stop()

# R45 semantic regressions preserved.
eng = RealTimeRiskMonitor(weights={"A": 1.0}, var_threshold=0.05)
eng.check_var(np.full(50, 0.10))
check("R45 regression: all-positive returns → no VaR breach",
      not [a for a in eng.alerts if "var" in a.alert_type])
eng.check_var(np.random.default_rng(7).normal(-0.10, 0.02, 50))
check("R45 regression: genuine VaR breach still fires",
      bool([a for a in eng.alerts if "var" in a.alert_type]))

rsrc = (ROOT / "math_engine" / "realtime_risk.py").read_text(encoding="utf-8")
check("source: interruptible event wait present",
      "_stop_event.wait(timeout=self.interval_sec)" in rsrc)


# ═══════════════════════════════════════════════════════════════════════════
section("R48-4 / R48-4b — stock↔benchmark date alignment")
# ═══════════════════════════════════════════════════════════════════════════
from math_engine.kalman_pair_trading import KalmanPairTradingEngine

_idx = pd.date_range("2024-01-01", periods=40, freq="D")
_y = pd.Series(100.0 + np.linspace(0, 10, 40)
               + np.random.default_rng(1).normal(0, 0.05, 40), index=_idx)
_x = 2.0 * pd.Series(np.linspace(0, 10, 40), index=_idx) + 50.0
_x.iloc[5] = np.nan      # a missing benchmark day in the middle

_res_series = KalmanPairTradingEngine.filter_pair_spread(_y, _x)
check("engine: NaN in one leg no longer shifts the pair (finite beta)",
      np.isfinite(_res_series["hedge_ratio_beta"]))
_mask = ~_x.isna()
_res_manual = KalmanPairTradingEngine.filter_pair_spread(
    _y[_mask].to_numpy(), _x[_mask].to_numpy())
check("engine: Series-path beta == manually-aligned array-path beta",
      abs(_res_manual["hedge_ratio_beta"] - _res_series["hedge_ratio_beta"]) < 1e-9,
      f"series={_res_series['hedge_ratio_beta']} manual={_res_manual['hedge_ratio_beta']}")

from math_engine.master_institutional_suite import MasterInstitutionalSuite

_stock_idx = pd.date_range("2024-01-01", periods=120, freq="B")
_stock_close = pd.Series(
    100 + np.cumsum(np.random.default_rng(3).normal(0.05, 1.0, 120)), index=_stock_idx)
_stock_vol = pd.Series(
    np.random.default_rng(4).integers(1e5, 5e5, 120).astype(float), index=_stock_idx)
_bench_idx = _stock_idx[30:]  # benchmark misses the first 30 stock days
_bench_close = pd.Series(
    200 + np.cumsum(np.random.default_rng(5).normal(0.02, 0.8, 90)), index=_bench_idx)
_bench_close.iloc[[7, 19, 33, 51, 70]] = np.nan

_metrics = MasterInstitutionalSuite.compute_all_stock_metrics(
    "TEST.NS", _stock_close, _stock_vol, benchmark_close=_bench_close)
check("suite: compute_all_stock_metrics survives mismatched benchmark coverage",
      isinstance(_metrics, dict) and len(_metrics) > 20)
_kal_keys = [k for k in _metrics if "kalman" in str(k).lower()]
check("suite: Kalman fields present in the metrics row", bool(_kal_keys))
if _kal_keys:
    _kv = _metrics[_kal_keys[0]]
    check("suite: Kalman beta finite under misaligned coverage",
          isinstance(_kv, (int, float)) and np.isfinite(_kv), f"{_kal_keys[0]}={_kv}")

ssrc = (ROOT / "math_engine" / "master_institutional_suite.py").read_text(encoding="utf-8")
check("source: closes-pair alignment present (compute_all_stock_metrics)",
      "_cs.index.intersection(_bs.index)" in ssrc)
check("source: unaligned closes extraction statement removed",
      "        b = benchmark_close.dropna().values if benchmark_close is not None else c" not in ssrc)
check("source: returns-pair alignment present (compute_portfolio_analytics, R48-4b)",
      "_r_idx.intersection(_bser.index)" in ssrc)
check("source: unaligned returns extraction statement removed",
      "b = benchmark_returns.dropna().values if benchmark_returns is not None else np.mean(R, axis=1)" not in ssrc)

ksrc = (ROOT / "math_engine" / "kalman_pair_trading.py").read_text(encoding="utf-8")
check("source: Kalman engine aligns Series inputs on the common index",
      'join="inner"' in ksrc and "_aligned" in ksrc)


# ═══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 76)
print(f"R48 VERIFICATION: {PASS} passed, {FAIL} failed (of {PASS + FAIL})")
print("=" * 76)
if _failures:
    for _n, _d in _failures:
        print(f"  FAILED: {_n} {_d}")
sys.exit(1 if FAIL else 0)
