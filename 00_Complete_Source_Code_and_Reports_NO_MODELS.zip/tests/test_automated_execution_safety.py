"""
tests/test_automated_execution_safety.py
========================================
Regression test suite verifying:
1. Strict 5-Crore ADV Liquidity floor enforcement (no low-float or illiquid penny traps).
2. Zero-manual verification telemetry (liquidity badge, circuit safety).
3. Exact share quantity and rupee allocation calculation.
4. Correct multi-broker basket formatting (Zerodha Kite, Dhan HQ, Angel One).
"""
import pytest
import numpy as np
import pandas as pd
from unittest.mock import MagicMock, patch

from web_dashboard.app import AgenticDesktopBridge


def test_liquidity_thresholds_defaults():
    """Verify DEFAULT_CFG and prescreen defaults strictly enforce ₹5 Cr ADV."""
    from data_layer import DEFAULT_CFG
    assert DEFAULT_CFG.get("MIN_AVG_DOLLAR_VOL") == 50_000_000, "Base ADV floor must be at least ₹5 Crores"


def test_trade_execution_suite_exact_sizing_and_baskets():
    """Verify compute_trade_execution_suite calculates exact integer shares, ATR brackets, and broker baskets."""
    mock_holdings = [
        {
            "ticker": "RELIANCE.NS",
            "Current Price (₹)": 2800.0,
            "weight_pct": 25.0,
            "adv20": 150_000_000.0,  # ₹15 Cr ADV
        },
        {
            "ticker": "TCS.NS",
            "Current Price (₹)": 4000.0,
            "weight_pct": 15.0,
            "adv20": 80_000_000.0,   # ₹8 Cr ADV
        }
    ]

    with patch.object(AgenticDesktopBridge, "get_active_holdings", return_value=mock_holdings):
        portfolio_capital = 1_000_000.0  # ₹10 Lakhs
        res = AgenticDesktopBridge.compute_trade_execution_suite(portfolio_value=portfolio_capital)

        assert res["status"] == "SUCCESS"
        assert res["portfolio_value"] == 1_000_000.0
        assert len(res["trade_ladders"]) == 2

        # 1. Check RELIANCE sizing
        rel_ladder = next(l for l in res["trade_ladders"] if l["ticker"] == "RELIANCE")
        # 25% of 10L = 2,50,000 INR. At 2800/share -> ~89 shares
        assert rel_ladder["quantity"] == int(round(250_000.0 / 2800.0))
        assert rel_ladder["allocated_capital"] == 250_000.0
        assert rel_ladder["adv20_crores"] == 15.0
        assert "Solid" in rel_ladder["liquidity_badge"] or "High" in rel_ladder["liquidity_badge"]
        assert rel_ladder["circuit_safe"] is True

        # 2. Check TCS sizing
        tcs_ladder = next(l for l in res["trade_ladders"] if l["ticker"] == "TCS")
        # 15% of 10L = 1,50,000 INR. At 4000/share -> ~38 shares
        assert tcs_ladder["quantity"] == int(round(150_000.0 / 4000.0))
        assert tcs_ladder["allocated_capital"] == 150_000.0
        assert tcs_ladder["adv20_crores"] == 8.0
        assert "Solid" in tcs_ladder["liquidity_badge"]

        # 3. Check Multi-Broker Order Baskets
        baskets = res["broker_baskets"]
        assert "zerodha_kite" in baskets
        assert "dhan_hq" in baskets
        assert "angel_one" in baskets

        # Zerodha Kite check
        zk_orders = baskets["zerodha_kite"]
        assert len(zk_orders) == 2
        assert zk_orders[0]["tradingsymbol"] == "RELIANCE"
        assert zk_orders[0]["quantity"] == rel_ladder["quantity"]
        assert zk_orders[0]["product"] == "CNC"

        # Dhan HQ check
        dhan_orders = baskets["dhan_hq"]
        assert len(dhan_orders) == 2
        assert dhan_orders[0]["securityId"] == "RELIANCE"
        assert dhan_orders[0]["quantity"] == rel_ladder["quantity"]

        # Angel One check
        angel_orders = baskets["angel_one"]
        assert len(angel_orders) == 2
        assert angel_orders[0]["tradingsymbol"] == "RELIANCE-EQ"
        assert angel_orders[0]["quantity"] == rel_ladder["quantity"]


def test_conformal_brackets_calculated():
    """Verify stop-loss and targets are non-zero and mathematically sound."""
    mock_holdings = [
        {
            "ticker": "INFY.NS",
            "Current Price (₹)": 1850.0,
            "weight_pct": 20.0,
            "adv20": 200_000_000.0,
        }
    ]

    with patch.object(AgenticDesktopBridge, "get_active_holdings", return_value=mock_holdings):
        res = AgenticDesktopBridge.compute_trade_execution_suite(portfolio_value=500_000.0)
        ladder = res["trade_ladders"][0]
        assert ladder["entry_price"] == 1850.0
        assert ladder["stop_loss"] < ladder["entry_price"], "Stop loss must be below entry for long position"
        assert ladder["target_1"] > ladder["entry_price"], "Target 1 must be above entry"
        assert ladder["target_2"] > ladder["target_1"], "Target 2 must be above Target 1"
