# -*- coding: utf-8 -*-
"""
Tests for Day-1/Day-2 Institutional Volume Breakout Detection & Prescreening Bypass.
Verifies that fresh breakouts from low-liquidity coiling bases (e.g. BODALCHEM Aug 19, 2026:
₹71.75 on 1.4M shares / ~₹10 Cr turnover after quiet Stage-1 consolidation) are accurately
captured at pivot inception rather than lagging until the stock has already rallied 300%.
"""

import numpy as np
import pandas as pd
import pytest
from utils import compute_prescreen_row, compute_signal_frame
from optimizer import robust_zscore_series


def _build_synthetic_breakout_series(n_bars=80, base_price=65.0, breakout_price=71.75,
                                    base_vol=30000.0, breakout_vol=1400000.0):
    """
    Simulates a stock coiling in a quiet base for (n_bars-1) days,
    followed by a massive institutional volume breakout on the final day.
    """
    np.random.seed(42)
    dates = pd.date_range("2026-06-01", periods=n_bars, freq="B")
    
    # 79 days of quiet base trading between 63 and 67
    prices = np.full(n_bars, base_price) + np.random.uniform(-1.5, 1.5, size=n_bars)
    volumes = np.full(n_bars, base_vol) + np.random.uniform(-5000, 5000, size=n_bars)
    
    # Day n_bars: Breakout to 71.75 on 1.4M volume
    prices[-1] = breakout_price
    volumes[-1] = breakout_vol
    
    close_s = pd.Series(prices, index=dates, name="Close")
    vol_s = pd.Series(volumes, index=dates, name="Volume")
    return close_s, vol_s


def test_compute_prescreen_row_breakout_features():
    """Verify that compute_prescreen_row calculates vol_shock, turnover_today, and is_vol_breakout."""
    close_s, vol_s = _build_synthetic_breakout_series()
    row = compute_prescreen_row("BODALCHEM.NS", close_s, vol_s, expected_days=80)
    
    assert row is not None
    assert row["ticker"] == "BODALCHEM.NS"
    assert row["last_price"] == pytest.approx(71.75, abs=0.01)
    
    # Trailing 20d median turnover is quiet (~₹20-25 Lakhs)
    assert row["adv20"] < 5_000_000.0
    
    # But today's turnover is ~₹10 Crores (100,000,000 INR)
    assert row["turnover_today"] > 90_000_000.0
    
    # Volume shock is > 25x
    assert row["vol_shock"] > 25.0
    
    # Breakout distance is positive (above prior 20-day high)
    assert row["breakout_distance_20d"] > 0.05
    
    # Confirmed volume breakout flag must be True
    assert row["is_vol_breakout"] is True


def test_prescreen_liquidity_gate_allows_breakout():
    """
    Verify that prescreening allows the breakout stock to pass into the candidate pool
    even when MIN_AVG_DOLLAR_VOL is 50,000,000 (₹5 Cr) and trailing ADV20 is only ₹25 Lakhs.
    """
    close_s, vol_s = _build_synthetic_breakout_series()
    
    # Background noisy stocks with standard volume
    dates = close_s.index
    np.random.seed(10)
    other_close = pd.Series(100.0 + np.cumsum(np.random.randn(80) * 0.5), index=dates)
    other_vol = pd.Series(np.random.uniform(600000, 800000, 80), index=dates) # ADV ~7 Cr
    
    cfg = {
        "PRESCREEN_LOOKBACK": "6m",
        "MIN_AVG_DOLLAR_VOL": 50_000_000.0, # ₹5 Crore hard gate
        "MIN_PRICE": 10.0,
        "MIN_AVG_SHARE_VOL": 30000,
        "REQUIRE_STAGE2_TREND": True,
        "MAX_52W_HIGH_DIST": 0.35,
        "MIN_52W_LOW_DIST": 0.10,
        "PRESCREEN_MODE": "early_entry",
        "USE_MANUAL_UNIVERSE": False,
    }
    
    row_bodal = compute_prescreen_row("BODALCHEM.NS", close_s, vol_s, expected_days=80)
    row_other = compute_prescreen_row("OTHER.NS", other_close, other_vol, expected_days=80)
    
    # Test batch filtering logic directly as in process_prescreen_batch
    for row in [row_bodal, row_other]:
        _min_adv = float(cfg.get("MIN_AVG_DOLLAR_VOL", 50_000_000.0))
        adv20_val = row.get("adv20", 0)
        turnover_today = row.get("turnover_today", 0)
        is_vol_breakout = row.get("is_vol_breakout", False)
        
        is_liquid = (pd.notna(adv20_val) and adv20_val >= _min_adv) or (
            is_vol_breakout and (turnover_today >= 10_000_000.0 or turnover_today >= _min_adv * 0.4)
        )
        # Both must be considered liquid: OTHER via trailing ADV20, BODALCHEM via Day-1 breakout
        assert is_liquid is True


def test_early_entry_prescreen_scoring_ranks_breakout_high():
    """Verify that early_entry prescreen scoring ranks a Day-1 volume breakout at the top."""
    close_s, vol_s = _build_synthetic_breakout_series()
    row_bodal = compute_prescreen_row("BODALCHEM.NS", close_s, vol_s, expected_days=80)
    
    # Create 4 other mediocre base stocks
    rows = [row_bodal]
    for i in range(1, 6):
        c, v = _build_synthetic_breakout_series(base_price=50.0 + i*10, breakout_price=50.0 + i*10, breakout_vol=30000.0)
        r = compute_prescreen_row(f"STOCK_{i}.NS", c, v, expected_days=80)
        rows.append(r)
        
    cfg = {
        "PRESCREEN_MODE": "early_entry",
        "PRESCREEN_MOM_WEIGHT": 0.40,
        "PRESCREEN_LIQ_WEIGHT": 0.20,
    }
    
    # Convert to DataFrame and compute scores as optimizer.py does
    df = pd.DataFrame(rows)
    from optimizer import robust_zscore_series
    _prescreen_z_cols = ["mom_3m", "mom_6m", "adv20", "vcp_score", "cmf_score",
                          "obv_slope", "updown_vol", "rs_raw", "ann_vol", "drawdown",
                          "neural_sde", "hurst", "ker", "vol_shock", "breakout_distance_20d", "range_contraction"]
    for _col in _prescreen_z_cols:
        if _col in df.columns:
            df[f"z_{_col}"] = robust_zscore_series(df[_col])
        else:
            df[f"z_{_col}"] = np.nan

    def _get_z(col_name: str) -> pd.Series:
        if col_name in df.columns:
            return df[col_name].fillna(0.0)
        return pd.Series(0.0, index=df.index)

    _liq_z = _get_z("z_adv20")
    _is_shock = (df["vol_shock"] >= 1.5) if "vol_shock" in df.columns else False
    _knife_pen = np.where(_is_shock, 0.0, np.maximum(0.0, -_get_z("z_mom_1m")))
    df["score"] = (
        0.30 * _get_z("z_p_prebreakout")      +
        0.20 * _get_z("z_vol_shock")          +
        0.15 * _get_z("z_vcp_score")          +
        0.15 * _get_z("z_breakout_distance_20d") +
        0.10 * _get_z("z_updown_vol")         +
        0.05 * _get_z("z_obv_slope")          +
        0.05 * _liq_z                         -
        0.30 * _knife_pen
    )
    df = df.sort_values("score", ascending=False).reset_index(drop=True)
    
    # BODALCHEM must be Rank 1!
    assert df.iloc[0]["ticker"] == "BODALCHEM.NS"


def test_signal_frame_trend_guard_preserves_breakout():
    """Verify that compute_signal_frame does not prune a breakout stock with flat pre-breakout 3M returns."""
    close_s, vol_s = _build_synthetic_breakout_series(n_bars=80)
    data = {
        "Close": pd.DataFrame({"BODALCHEM.NS": close_s}),
        "Volume": pd.DataFrame({"BODALCHEM.NS": vol_s}),
    }
    rets = pd.DataFrame({"BODALCHEM.NS": np.log(close_s / close_s.shift(1)).dropna()})
    bench_rets = pd.Series(0.0005, index=rets.index)
    
    cfg = {
        "ENABLE_ABSOLUTE_TREND_GUARD": True,
        "TREND_GUARD_MODE": "standard", # Standard mode normally prunes if mom_3m < 0
        "USE_FUNDAMENTALS": False,
        "USE_LIQUIDITY_AWARE_BETA": False,
    }
    
    sig_df = compute_signal_frame(data, rets, bench_rets, cfg=cfg)
    assert not sig_df.empty
    row = sig_df.loc["BODALCHEM.NS"] if "BODALCHEM.NS" in sig_df.index else sig_df.iloc[0]
    
    # Fresh volume breakout must pass absolute trend guard
    assert bool(row["passed_absolute_trend"]) is True
    # Volume surge must reflect single-day shock (> 20)
    assert row["vol_surge"] > 20.0
    assert row["vol_shock"] > 20.0
    assert bool(row["is_vol_breakout"]) is True


def test_prebreakout_inception_model_inference():
    """Verify that PreBreakoutInceptionModel loads with valid SHA-256 and predicts calibrated probabilities."""
    from ml_alpha.prebreakout_model import PreBreakoutInceptionModel, PREBREAKOUT_FACTOR_NAMES
    
    model = PreBreakoutInceptionModel.load()
    assert model is not None, "PreBreakoutInceptionModel failed to load"
    assert model.is_fitted is True
    assert model.dsr > 0.80, f"DSR {model.dsr} does not meet institutional bar"
    assert model.oos_sharpe > 1.0, f"OOS Sharpe {model.oos_sharpe} below target"
    
    # Test on a coiling base setup (tight base, severe volume dryup, rising OBV)
    coiling_features = {feat: 0.0 for feat in PREBREAKOUT_FACTOR_NAMES}
    coiling_features["z_base_tightness"] = 2.5
    coiling_features["z_vcp_compression"] = 2.0
    coiling_features["z_volume_dryup"] = 2.2
    coiling_features["z_obv_divergence"] = 1.8
    coiling_features["z_keltner_bb_squeeze"] = 1.8
    coiling_features["z_pivot_proximity"] = 2.0
    
    df_test = pd.DataFrame([coiling_features], index=["BODALCHEM.NS"])
    prob = model.predict_proba(df_test)
    assert len(prob) == 1
    assert 0.0 < prob[0] < 1.0
    
    preds, attr = model.explain(df_test)
    assert not attr.empty
    assert "z_base_tightness" in attr.columns
