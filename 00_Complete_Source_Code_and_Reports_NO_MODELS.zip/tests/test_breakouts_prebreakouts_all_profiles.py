"""
Tests verifying that Breakouts and Pre-Breakouts engines function correctly across ALL 10 profiles.
Ensures no profile returns empty breakouts/prebreakouts or 0.0000 dummy scores.
"""
import pytest
from pathlib import Path
from data_layer import PROFILE_MAP
from web_dashboard.app import AgenticDesktopBridge


def test_all_5_archetypes_resolve_breakouts_and_prebreakouts():
    """Verify resolve_breakout_and_prebreakout_for_profile returns valid candidates for all 5 archetypes."""
    all_profiles = list(PROFILE_MAP.keys())
    assert len(all_profiles) >= 5, f"Expected at least 5 profiles, got {len(all_profiles)}"

    for pname in all_profiles:
        bo, pb = AgenticDesktopBridge.resolve_breakout_and_prebreakout_for_profile(pname)
        assert len(bo) > 0, f"Profile '{pname}' returned 0 breakouts"
        assert len(pb) > 0, f"Profile '{pname}' returned 0 prebreakouts"

        # Validate breakout attributes
        for item in bo:
            assert item["Ticker"], "Breakout item missing Ticker"
            assert item["Sector"], "Breakout item missing Sector"
            assert "Breakout" in item["Signal"], f"Invalid Signal: {item['Signal']}"
            assert item["BreakoutScore"] > 0, f"Zero or negative BreakoutScore for {item['Ticker']}"
            assert item["Price"] > 0, f"Zero or negative Price for {item['Ticker']}"
            assert item["Pivot"] > 0, f"Zero or negative Pivot for {item['Ticker']}"

        # Validate pre-breakout attributes
        for item in pb:
            assert item["Ticker"], "Pre-breakout item missing Ticker"
            assert item["Sector"], "Pre-breakout item missing Sector"
            assert "Pre-Breakout" in item["Signal"], f"Invalid Signal: {item['Signal']}"
            assert item["BreakoutScore"] > 0, f"Zero or negative BreakoutScore for {item['Ticker']}"
            assert item["Price"] > 0, f"Zero or negative Price for {item['Ticker']}"
            assert item["AccumulationZone"], f"Missing AccumulationZone for {item['Ticker']}"


def test_sync_and_save_breakout_csvs():
    """Verify sync_and_save_breakout_csvs creates valid combined CSV files on disk."""
    bo_csv = Path("combined_breakout.csv")
    pb_csv = Path("combined_prebreakout.csv")
    orig_bo = bo_csv.read_bytes() if bo_csv.exists() else None
    orig_pb = pb_csv.read_bytes() if pb_csv.exists() else None

    try:
        AgenticDesktopBridge.sync_and_save_breakout_csvs()

        assert bo_csv.exists(), "combined_breakout.csv not created"
        assert pb_csv.exists(), "combined_prebreakout.csv not created"

        import pandas as pd
        bo_df = pd.read_csv(bo_csv)
        pb_df = pd.read_csv(pb_csv)

        assert len(bo_df) >= 10, f"combined_breakout.csv has too few rows: {len(bo_df)}"
        assert len(pb_df) >= 10, f"combined_prebreakout.csv has too few rows: {len(pb_df)}"

        required_cols = [
            "Ticker", "Sector", "Signal", "TriggerState", "BreakoutScore",
            "SetupScore", "TriggerScore", "CompressionScore", "PressureScore",
            "Price", "Profile"
        ]
        for col in required_cols:
            assert col in bo_df.columns, f"Missing column {col} in combined_breakout.csv"
            assert col in pb_df.columns, f"Missing column {col} in combined_prebreakout.csv"
    finally:
        if orig_bo is not None:
            bo_csv.write_bytes(orig_bo)
        if orig_pb is not None:
            pb_csv.write_bytes(orig_pb)


def test_no_synthetic_stub_scores_or_cross_profile_contamination():
    """Permanent regression lock: verify no profile returns 10.0/10.8/9.8/10.2 stub scores or cross-contaminated duplicate candidate lists."""
    from data_layer import PROFILE_MAP
    all_profiles = list(PROFILE_MAP.keys())
    
    profile_pb_tickers = {}
    for pname in all_profiles:
        bo, pb = AgenticDesktopBridge.resolve_breakout_and_prebreakout_for_profile(pname)
        assert len(pb) > 0, f"Profile '{pname}' returned zero prebreakouts"
        
        scores_seen = []
        tickers_seen = []
        for item in pb:
            tickers_seen.append(item["Ticker"])
            # Permanent lock against the 10.00 / 10.80 / 9.80 / 10.20 / 86.20 stub
            assert not (
                item["BreakoutScore"] == 10.0
                and item["SetupScore"] == 10.8
                and item["TriggerScore"] == 9.8
            ), f"Detected synthetic stub scores (10.0/10.8/9.8) for {item['Ticker']} in profile '{pname}'"
            scores_seen.append(item["BreakoutScore"])
        
        # Verify scores are varied, not an identical constant repeated across all rows
        if len(scores_seen) >= 2:
            assert len(set(scores_seen)) > 1, f"All scores in profile '{pname}' are identical: {scores_seen}"
            
        profile_pb_tickers[pname] = tickers_seen

    # Verify orthogonal profiles do not have identical candidate lists (proper profile differentiation)
    ipo_pname = "🦄 High-Growth IPO · Multibagger Hunter"
    mom_pname = "🚀 Momentum & Vol Squeeze · Institutional Alpha"
    if ipo_pname in profile_pb_tickers and mom_pname in profile_pb_tickers:
        assert profile_pb_tickers[ipo_pname] != profile_pb_tickers[mom_pname], (
            f"IPO profile and Momentum profile have identical prebreakout tickers! Cross-contamination detected."
        )

