"""tests/test_broker_reconciliation.py
======================================
Round 12: Unit tests for reconcile_portfolio_holdings, generate_idempotency_key,
and execute_reconciled_basket in optimizer_broker.py.
"""
import sys, os, unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from optimizer_broker import (
    reconcile_portfolio_holdings,
    generate_idempotency_key,
    execute_reconciled_basket,
    _IDEMPOTENCY_CACHE,
    _IDEMPOTENCY_LOCK,
)

PRICES = {
    "RELIANCE.NS": 2950.0,
    "HDFCBANK.NS": 1680.0,
    "INFY.NS":     1820.0,
    "TCS.NS":      4200.0,
}
TOTAL_VALUE = 1_000_000.0

def _clear_idem_cache():
    with _IDEMPOTENCY_LOCK:
        _IDEMPOTENCY_CACHE.clear()


class TestReconcilePortfolioHoldings(unittest.TestCase):

    def test_returns_dict_with_expected_keys(self):
        result = reconcile_portfolio_holdings(
            target_weights={"RELIANCE.NS": 0.25, "HDFCBANK.NS": 0.25},
            current_holdings={}, total_value=TOTAL_VALUE, prices=PRICES,
        )
        for key in ("orders","turnover_pct","skipped_tickers","total_buy_inr","total_sell_inr","order_count"):
            self.assertIn(key, result)

    def test_fresh_portfolio_all_buys(self):
        result = reconcile_portfolio_holdings(
            target_weights={"RELIANCE.NS": 0.25, "HDFCBANK.NS": 0.25},
            current_holdings={}, total_value=TOTAL_VALUE, prices=PRICES,
        )
        sides = {o["side"] for o in result["orders"]}
        self.assertIn("BUY", sides)
        self.assertNotIn("SELL", sides)

    def test_excess_holdings_produce_sells(self):
        result = reconcile_portfolio_holdings(
            target_weights={"RELIANCE.NS": 0.05},
            current_holdings={"RELIANCE.NS": 100},
            total_value=TOTAL_VALUE, prices=PRICES,
        )
        sells = [o for o in result["orders"] if o["side"] == "SELL"]
        self.assertGreater(len(sells), 0)

    def test_cash_ticker_is_skipped(self):
        result = reconcile_portfolio_holdings(
            target_weights={"CASH": 0.10, "RELIANCE.NS": 0.40},
            current_holdings={}, total_value=TOTAL_VALUE, prices=PRICES,
        )
        tickers = {o["ticker"] for o in result["orders"]}
        self.assertNotIn("CASH", tickers)
        self.assertIn("CASH", result["skipped_tickers"])

    def test_min_trade_filter_suppresses_micro_rebalance(self):
        result = reconcile_portfolio_holdings(
            target_weights={"RELIANCE.NS": 0.0001},
            current_holdings={}, total_value=TOTAL_VALUE, prices=PRICES, min_trade_inr=500.0,
        )
        for o in result["orders"]:
            self.assertGreaterEqual(o["value_inr"], 500.0)

    def test_no_orders_when_already_at_target(self):
        price = PRICES["RELIANCE.NS"]
        target_w = 0.295
        target_qty = int(target_w * TOTAL_VALUE / price)
        result = reconcile_portfolio_holdings(
            target_weights={"RELIANCE.NS": target_w},
            current_holdings={"RELIANCE.NS": target_qty},
            total_value=TOTAL_VALUE, prices=PRICES,
        )
        self.assertEqual(result["order_count"], 0)

    def test_missing_price_skips_ticker(self):
        result = reconcile_portfolio_holdings(
            target_weights={"UNKNOWN_XYZ": 0.10, "RELIANCE.NS": 0.20},
            current_holdings={}, total_value=TOTAL_VALUE, prices=PRICES,
        )
        self.assertIn("UNKNOWN_XYZ", result["skipped_tickers"])

    def test_turnover_non_negative(self):
        result = reconcile_portfolio_holdings(
            target_weights={"RELIANCE.NS": 0.25},
            current_holdings={}, total_value=TOTAL_VALUE, prices=PRICES,
        )
        self.assertGreaterEqual(result["turnover_pct"], 0.0)

    def test_total_buy_matches_order_values(self):
        result = reconcile_portfolio_holdings(
            target_weights={"RELIANCE.NS": 0.25, "HDFCBANK.NS": 0.25},
            current_holdings={}, total_value=TOTAL_VALUE, prices=PRICES,
        )
        computed_buy = sum(o["value_inr"] for o in result["orders"] if o["side"] == "BUY")
        self.assertAlmostEqual(computed_buy, result["total_buy_inr"], places=0)

    def test_order_fields_complete(self):
        result = reconcile_portfolio_holdings(
            target_weights={"RELIANCE.NS": 0.25},
            current_holdings={}, total_value=TOTAL_VALUE, prices=PRICES,
        )
        for o in result["orders"]:
            for field in ("ticker","side","qty","price","value_inr","delta_weight",
                          "target_weight","current_qty","target_qty"):
                self.assertIn(field, o)


class TestGenerateIdempotencyKey(unittest.TestCase):

    def test_returns_64_hex_string(self):
        token = generate_idempotency_key({"RELIANCE.NS": {"qty": 50, "side": "BUY"}})
        self.assertEqual(len(token), 64)
        self.assertTrue(all(c in "0123456789abcdef" for c in token))

    def test_same_basket_same_token(self):
        basket = {"RELIANCE.NS": {"qty": 50, "side": "BUY"}, "TCS.NS": {"qty": 10, "side": "BUY"}}
        self.assertEqual(generate_idempotency_key(basket), generate_idempotency_key(basket))

    def test_different_basket_different_token(self):
        self.assertNotEqual(
            generate_idempotency_key({"RELIANCE.NS": {"qty": 50, "side": "BUY"}}),
            generate_idempotency_key({"HDFCBANK.NS": {"qty": 30, "side": "BUY"}}),
        )

    def test_buy_vs_sell_different_token(self):
        self.assertNotEqual(
            generate_idempotency_key({"RELIANCE.NS": {"qty": 50, "side": "BUY"}}),
            generate_idempotency_key({"RELIANCE.NS": {"qty": 50, "side": "SELL"}}),
        )

    def test_different_qty_different_token(self):
        self.assertNotEqual(
            generate_idempotency_key({"RELIANCE.NS": {"qty": 10, "side": "BUY"}}),
            generate_idempotency_key({"RELIANCE.NS": {"qty": 99, "side": "BUY"}}),
        )


class TestExecuteReconciledBasket(unittest.TestCase):

    def setUp(self):
        _clear_idem_cache()

    def test_returns_success_dict(self):
        result = execute_reconciled_basket(
            target_weights={"RELIANCE.NS": 0.25, "HDFCBANK.NS": 0.25},
            current_holdings={}, total_value=TOTAL_VALUE, prices=PRICES, paper=True,
        )
        self.assertIn("success", result)
        self.assertIn("orders", result)
        self.assertEqual(result["mode"], "paper")

    def test_paper_orders_are_simulated(self):
        result = execute_reconciled_basket(
            target_weights={"RELIANCE.NS": 0.25},
            current_holdings={}, total_value=TOTAL_VALUE, prices=PRICES, paper=True,
        )
        if result["orders"]:
            self.assertEqual(result["orders"][0]["status"], "SIMULATED")

    def test_idempotency_dedup_blocks_second_call(self):
        weights = {"RELIANCE.NS": 0.25, "HDFCBANK.NS": 0.25}
        first  = execute_reconciled_basket(target_weights=weights, current_holdings={},
                                           total_value=TOTAL_VALUE, prices=PRICES, paper=True)
        second = execute_reconciled_basket(target_weights=weights, current_holdings={},
                                           total_value=TOTAL_VALUE, prices=PRICES, paper=True)
        # AUDIT-FIX (Round 5, 2-g-3): the guarded `if first.get(...)` made the
        # assertion vacuous whenever the FIRST call failed — exactly the
        # regression this test exists to catch. Assert unconditionally.
        self.assertTrue(first.get("success"), f"first call failed: {first}")
        self.assertTrue(first.get("idempotency_key"), "first call produced no idempotency key")
        self.assertTrue(second.get("duplicate"), f"second call was not deduplicated: {second}")

    def test_no_orders_when_already_at_target(self):
        price = PRICES["RELIANCE.NS"]
        target_w = 0.295
        target_qty = int(target_w * TOTAL_VALUE / price)
        result = execute_reconciled_basket(
            target_weights={"RELIANCE.NS": target_w},
            current_holdings={"RELIANCE.NS": target_qty},
            total_value=TOTAL_VALUE, prices=PRICES, paper=True,
        )
        self.assertEqual(result["orders"], [])

    def test_orders_have_order_id(self):
        _clear_idem_cache()
        result = execute_reconciled_basket(
            target_weights={"RELIANCE.NS": 0.30},
            current_holdings={}, total_value=TOTAL_VALUE, prices=PRICES, paper=True,
        )
        for o in result.get("orders", []):
            self.assertIn("order_id", o)

    def test_total_buy_inr_non_negative(self):
        _clear_idem_cache()
        result = execute_reconciled_basket(
            target_weights={"RELIANCE.NS": 0.25, "HDFCBANK.NS": 0.25},
            current_holdings={}, total_value=TOTAL_VALUE, prices=PRICES, paper=True,
        )
        self.assertGreaterEqual(result.get("total_buy_inr", 0.0), 0.0)

    def test_idempotency_key_64_chars_when_orders_exist(self):
        _clear_idem_cache()
        result = execute_reconciled_basket(
            target_weights={"RELIANCE.NS": 0.30},
            current_holdings={}, total_value=TOTAL_VALUE, prices=PRICES, paper=True,
        )
        if result.get("orders"):
            self.assertEqual(len(result.get("idempotency_key", "")), 64)


if __name__ == "__main__":
    unittest.main(verbosity=2)
