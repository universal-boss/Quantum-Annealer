"""tests/test_chandelier_trade_levels.py
=========================================
Unit tests for Chandelier Ratchet, Volatility Scaling, and Time Barrier Exits
in AdaptiveVolatilityRiskEngine and optimizer_broker.py.
"""
import sys, os, unittest
import pandas as pd
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from math_engine.profile_mathematical_suite import AdaptiveVolatilityRiskEngine
from optimizer_broker import compute_dynamic_trade_levels, generate_consultative_order_sheet


class TestChandelierTradeLevels(unittest.TestCase):

    def test_fresh_position_volatility_scaling(self):
        # Low vol stock vs High vol stock
        low_vol = AdaptiveVolatilityRiskEngine.compute_dynamic_levels(
            current_price=1000.0, atr_val=15.0, risk_profile="balanced"
        )
        high_vol = AdaptiveVolatilityRiskEngine.compute_dynamic_levels(
            current_price=1000.0, atr_val=50.0, risk_profile="balanced"
        )

        self.assertLess(low_vol["stop_loss_pct"], high_vol["stop_loss_pct"])
        self.assertLess(low_vol["target_upside_pct"], high_vol["target_upside_pct"])
        self.assertFalse(low_vol["stop_loss_ratcheted"])

    def test_chandelier_ratchet_moves_stop_up(self):
        # Initial trade entered at 1000 with ATR 30 + Merton Gap buffer -> Stop at 1000 - 61.5 = 938.5
        initial = AdaptiveVolatilityRiskEngine.compute_dynamic_levels(
            current_price=1000.0, atr_val=30.0, risk_profile="balanced"
        )
        initial_sl = float(initial["stop_loss_price"])
        self.assertEqual(initial_sl, 938.5)

        # Stock rallies to 1100 (highest high = 1100, current price = 1080)
        # Chandelier anchor at 1100 - 61.5 = 1038.5 (which is > initial 938.5)
        ratcheted = AdaptiveVolatilityRiskEngine.compute_dynamic_levels(
            current_price=1080.0,
            atr_val=30.0,
            risk_profile="balanced",
            previous_stop_loss=initial_sl,
            highest_high_since_entry=1100.0,
        )
        self.assertTrue(ratcheted["stop_loss_ratcheted"])
        self.assertGreater(ratcheted["stop_loss_price"], initial_sl)
        self.assertEqual(float(ratcheted["stop_loss_price"]), 1038.5)

    def test_chandelier_ratchet_never_retreats(self):
        # If current price dips back to 1020, the stop should remain locked at 1038.5, not retreat
        locked = AdaptiveVolatilityRiskEngine.compute_dynamic_levels(
            current_price=1020.0,
            atr_val=30.0,
            risk_profile="balanced",
            previous_stop_loss=1038.5,
            highest_high_since_entry=1100.0,
        )
        self.assertGreaterEqual(float(locked["stop_loss_price"]), 1038.5)

    def test_risk_profile_tiered_time_barriers(self):
        agg = AdaptiveVolatilityRiskEngine.compute_dynamic_levels(100.0, atr_val=3.0, risk_profile="aggressive")
        bal = AdaptiveVolatilityRiskEngine.compute_dynamic_levels(100.0, atr_val=3.0, risk_profile="balanced")
        dfn = AdaptiveVolatilityRiskEngine.compute_dynamic_levels(100.0, atr_val=3.0, risk_profile="defensive")

        self.assertEqual(agg["time_barrier_days"], 15)
        self.assertEqual(bal["time_barrier_days"], 20)
        self.assertEqual(dfn["time_barrier_days"], 30)

    def test_broker_compute_dynamic_trade_levels_integration(self):
        res = compute_dynamic_trade_levels(
            ticker="RELIANCE.NS",
            current_price=2950.0,
            atr_val=60.0,
            regime="Bull",
            previous_stop_loss=2800.0,
            highest_high_since_entry=3100.0,
        )
        self.assertIn("entry_price", res)
        self.assertEqual(res["ticker"], "RELIANCE.NS")
        self.assertIn("stop_loss_price", res)
        self.assertIn("snell_target_price", res)
        self.assertIn("kelly_position_weight_pct", res)
        self.assertIn("time_barrier_days", res)
        self.assertTrue(res["stop_loss_ratcheted"])
        self.assertGreater(res["stop_loss_price"], 2800.0)

    def test_runner_architecture_and_breakeven_stop(self):
        # Position entered at 500 with ATR 15
        res = AdaptiveVolatilityRiskEngine.compute_dynamic_levels(
            current_price=500.0,
            atr_val=15.0,
            risk_profile="aggressive"
        )
        self.assertIn("target_1_price", res)
        self.assertIn("breakeven_stop_loss", res)
        self.assertIn("runner_strategy", res)
        self.assertIn("runner_trailing_stop", res)
        self.assertIn("profit_taking_plan", res)

        self.assertEqual(res["breakeven_stop_loss"], 500.0)
        self.assertEqual(res["target_1_action"], "SELL 50% (De-Risk)")
        self.assertEqual(res["runner_strategy"], "UNCAPPED (Trailing ATR)")
        self.assertGreater(res["target_1_price"], 500.0)
        self.assertLess(res["stop_loss_price"], 500.0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
