"""tests/test_chart_structural_levels.py
======================================
Comprehensive unit tests for deterministic, chart-derived structural Stop-Loss
and Target level calculation engine in AdaptiveVolatilityRiskEngine.
"""
import sys, os, unittest
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from math_engine.profile_mathematical_suite import AdaptiveVolatilityRiskEngine


class TestChartStructuralLevels(unittest.TestCase):

    def test_standard_stock_pullback_low_with_atr_buffer(self):
        # 100 days of price action
        closes = np.linspace(100.0, 120.0, 100)
        highs = closes + 2.0
        lows = closes - 2.0
        # Create a clear pullback trough 5 bars ago: low drops to 110.0
        lows[-5] = 110.0
        highs[-5] = 114.0
        closes[-5] = 112.0
        cur_p = 120.0

        res = AdaptiveVolatilityRiskEngine.compute_chart_structural_levels(cur_p, highs, lows, closes)
        # Pullback swing low should be 110.0
        self.assertEqual(res["swing_low"], 110.0)
        # ATR is approx 4.0, buffer 0.5 * ATR approx 2.0 -> raw SL approx 108.0 (10% max bound is 108.0)
        self.assertLess(res["stop_loss_price"], cur_p)
        self.assertGreaterEqual(res["stop_loss_pct"], 3.0)
        self.assertLessEqual(res["stop_loss_pct"], 10.0)

    def test_protective_boundary_guards(self):
        # Case A: Too tight swing low (only 1% away) -> Clamped to min 3% distance
        closes_tight = np.full(50, 100.0)
        highs_tight = np.full(50, 100.5)
        lows_tight = np.full(50, 99.5)
        res_tight = AdaptiveVolatilityRiskEngine.compute_chart_structural_levels(100.0, highs_tight, lows_tight, closes_tight)
        self.assertLessEqual(res_tight["stop_loss_price"], 97.0)
        self.assertGreaterEqual(res_tight["stop_loss_pct"], 3.0)

        # Case B: Too wide swing low (25% away) -> Clamped to max 10% risk cap
        closes_wide = np.linspace(80.0, 100.0, 50)
        highs_wide = closes_wide + 1.0
        lows_wide = closes_wide - 1.0
        lows_wide[-10] = 75.0  # 25% down
        res_wide = AdaptiveVolatilityRiskEngine.compute_chart_structural_levels(100.0, highs_wide, lows_wide, closes_wide)
        self.assertEqual(res_wide["stop_loss_price"], 90.0)
        self.assertEqual(res_wide["stop_loss_pct"], 10.0)

    def test_overhead_resistance_target(self):
        # 200 days: stock rallied to 150.0 40 days ago, pulled back, now at 130.0
        closes = np.full(200, 130.0)
        highs = np.full(200, 132.0)
        lows = np.full(200, 128.0)
        # Prior major resistance peak at bar index 160: High = 150.0
        highs[160] = 150.0
        closes[160] = 148.0

        res = AdaptiveVolatilityRiskEngine.compute_chart_structural_levels(130.0, highs, lows, closes)
        self.assertEqual(res["target_1_price"], 150.0)
        self.assertFalse(res["is_ath"])
        self.assertEqual(res["overhead_resistance"], 150.0)

    def test_blue_sky_all_time_high_measured_move(self):
        # Stock broke out to All-Time Highs (no resistance above 150)
        # Consolidation base between 120 and 150 (base height = 30)
        closes = np.linspace(120.0, 150.0, 60)
        highs = closes + 1.0
        lows = closes - 1.0
        highs[-1] = 152.0
        cur_p = 152.0

        res = AdaptiveVolatilityRiskEngine.compute_chart_structural_levels(cur_p, highs, lows, closes)
        self.assertTrue(res["is_ath"])
        # Base height is approx 152 - 119 = 33 -> Target is approx 152 + 33 = 185
        self.assertGreater(res["target_1_price"], cur_p + 20.0)
        self.assertGreater(res["target_upside_pct"], 10.0)

    def test_fresh_ipo_less_than_14_days(self):
        # Fresh IPO with only 6 days of trading
        closes_ipo = np.array([100.0, 102.0, 105.0, 103.0, 106.0, 108.0])
        highs_ipo = np.array([103.0, 104.0, 107.0, 105.0, 108.0, 110.0])
        lows_ipo = np.array([98.0, 101.0, 102.0, 101.0, 104.0, 105.0])

        res_ipo = AdaptiveVolatilityRiskEngine.compute_chart_structural_levels(108.0, highs_ipo, lows_ipo, closes_ipo)
        # Should execute cleanly without NaN or exceptions
        self.assertEqual(res_ipo["swing_low"], 98.0)  # Listing floor
        self.assertLessEqual(res_ipo["stop_loss_pct"], 10.0)
        self.assertGreaterEqual(res_ipo["stop_loss_pct"], 3.0)
        self.assertGreater(res_ipo["target_1_price"], 108.0)


if __name__ == "__main__":
    unittest.main()
