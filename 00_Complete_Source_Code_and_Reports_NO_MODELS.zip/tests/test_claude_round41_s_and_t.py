"""tests/test_claude_round41_s_and_t.py
=======================================
Verification suite for Claude Audit Round 41 findings §5s and §5t:
- §5s: CorporateActionsAdjuster correctly parses Indian bonus issue notation ("1:1" -> multiplier 2.0, not 1.0 no-op).
- §5t: AngelOneAdapter.execute_differential_orders splits large orders into multiple child orders covering the full requested quantity without silent truncation or dropping remainders.
"""

import unittest
from unittest.mock import MagicMock, patch
import pandas as pd
import numpy as np


class TestClaudeAudit5sBonusRatio(unittest.TestCase):
    """§5s: Indian market bonus notation (X:Y) parsed as (X+Y)/Y multiplier."""

    def test_bonus_1_to_1_parsed_as_ratio_2(self):
        from math_engine.corporate_adjustments import CorporateActionsAdjuster

        # Create 10 days of synthetic price data
        dates = pd.date_range("2024-01-01", periods=10, freq="D")
        df = pd.DataFrame({
            "Open": [1000.0] * 10,
            "High": [1010.0] * 10,
            "Low": [990.0] * 10,
            "Close": [1000.0] * 10,
            "Volume": [10000.0] * 10,
        }, index=dates)

        # 1:1 Bonus on day 5 (index 4)
        ex_date = dates[4]
        actions = pd.DataFrame([{
            "type": "BONUS",
            "ex_date": ex_date,
            "ratio": "1:1",
        }])

        adj_df = CorporateActionsAdjuster.adjust_prices_pit(df, actions, as_of_date=dates[-1])

        # Historical prices prior to ex-date (days 0..3) must be divided by 2.0 (factor 0.5)
        # Old code parsed 1:1 as 1/1 = 1.0 and skipped the adjustment completely.
        pre_ex_close = adj_df.loc[adj_df.index < ex_date, "Close"]
        post_ex_close = adj_df.loc[adj_df.index >= ex_date, "Close"]

        self.assertTrue((pre_ex_close == 500.0).all(), "Pre-ex-date prices must be adjusted to 500.0 (divided by 2.0)")
        self.assertTrue((post_ex_close == 1000.0).all(), "Post-ex-date prices must remain 1000.0")

    def test_split_vs_bonus_ratio_differentiation(self):
        from math_engine.corporate_adjustments import CorporateActionsAdjuster

        dates = pd.date_range("2024-01-01", periods=6, freq="D")
        df = pd.DataFrame({"Close": [300.0] * 6}, index=dates)

        # 2:1 Split -> ratio is 2.0 (1 share becomes 2) -> historical prices become 150.0
        split_actions = pd.DataFrame([{"type": "SPLIT", "ex_date": dates[3], "ratio": "2:1"}])
        adj_split = CorporateActionsAdjuster.adjust_prices_pit(df, split_actions, as_of_date=dates[-1])
        self.assertEqual(adj_split["Close"].iloc[0], 150.0)

        # 2:1 Bonus -> 2 new shares for 1 held -> total 3 shares -> ratio is 3.0 -> historical prices become 100.0
        bonus_actions = pd.DataFrame([{"type": "BONUS", "ex_date": dates[3], "ratio": "2:1"}])
        adj_bonus = CorporateActionsAdjuster.adjust_prices_pit(df, bonus_actions, as_of_date=dates[-1])
        self.assertEqual(adj_bonus["Close"].iloc[0], 100.0)


class TestClaudeAudit5tFreezeLimitOrderSplitting(unittest.TestCase):
    """§5t: Orders exceeding freeze limit must be fully filled via multiple child orders."""

    def test_multi_child_order_loop_covers_full_quantity(self):
        from math_engine.broker_router import AngelOneAdapter

        adapter = AngelOneAdapter()
        mock_smart_api = MagicMock()
        mock_smart_api.placeOrder.return_value = {"status": True, "data": {"orderid": "MOCK-ORD-123"}}
        adapter._smart_api = mock_smart_api

        # Set freeze qty to 1,000 shares
        adapter._default_freeze_qty = 1000
        adapter._scrip_master = {"INFY": {"freeze_qty": 1000, "prev_close": 1800.0}}

        orders = [{
            "ticker": "INFY.NS",
            "side": "BUY",
            "qty": 2500,
            "price": 1800.0,
        }]

        with patch.object(adapter, "get_ltp", return_value=1800.0):
            df_res = adapter.execute_differential_orders(orders, dry_run=False)

        # Must have submitted 3 child orders: 1000, 1000, 500
        self.assertEqual(len(df_res), 3, "Expected 3 child order rows covering 2500 total quantity")
        self.assertEqual(df_res["Qty"].sum(), 2500, "Total executed child quantity must exactly equal 2500")
        self.assertEqual(mock_smart_api.placeOrder.call_count, 3, "placeOrder must be called 3 times")

        self.assertIn("(child 1/3)", df_res.iloc[0]["Status"])
        self.assertIn("(child 2/3)", df_res.iloc[1]["Status"])
        self.assertIn("(child 3/3)", df_res.iloc[2]["Status"])


if __name__ == "__main__":
    unittest.main()
