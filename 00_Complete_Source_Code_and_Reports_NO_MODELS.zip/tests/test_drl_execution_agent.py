"""tests/test_drl_execution_agent.py
===================================
Unit tests for Deep Reinforcement Learning (DRL) Execution Slicing Engine.
"""
import sys, os, unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from math_engine.drl_execution_agent import (
    ExecutionEnv,
    PPOExecutionAgent,
    schedule_drl_execution,
)


class TestDRLExecutionAgent(unittest.TestCase):

    def test_execution_env_step_and_inventory_depletion(self):
        env = ExecutionEnv(total_shares=5000, time_steps=5)
        state = env.reset()
        self.assertEqual(len(state), 4)

        # AUDIT-FIX (Round 5, 2-g-22): bound the loop — if env.step never
        # sets done (the exact regression this guards), the old `while not
        # done` hung until the CI timeout instead of failing.
        done = False
        step_count = 0
        for _ in range(100):
            state, reward, done, info = env.step(action_fraction=0.30)
            step_count += 1
            if done:
                break
        else:
            self.fail("env.step() never set done=True within 100 steps")

        self.assertEqual(env.shares_remaining, 0)
        self.assertLessEqual(step_count, 5)

    def test_ppo_agent_action_selection(self):
        agent = PPOExecutionAgent()
        # [time_ratio, inventory_ratio, price_dev, vol]
        state = [0.2, 0.8, 0.01, 0.02]
        action = agent.select_action(state)
        self.assertGreater(action, 0.0)
        self.assertLessEqual(action, 1.0)

    def test_schedule_drl_execution_orchestrator(self):
        res = schedule_drl_execution("RELIANCE.NS", total_qty=10000, num_intervals=8)
        self.assertEqual(res["ticker"], "RELIANCE.NS")
        self.assertEqual(res["total_qty"], 10000)
        self.assertEqual(res["num_slices"], 8)
        self.assertEqual(res["method"], "drl_ppo_policy")
        
        # Verify all shares were scheduled
        total_scheduled = sum(s["slice_qty"] for s in res["schedule"])
        self.assertEqual(total_scheduled, 10000)


if __name__ == "__main__":
    unittest.main(verbosity=2)
