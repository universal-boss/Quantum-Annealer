"""
tests/test_hierarchical_moe.py
==============================
Unit & Regression Tests for Hierarchical Regime-Gated Mixture of Experts (MoE)
and Latent Factor De-Noising Engine (RMT + Factor-VAE).
"""
import os
import pickle
import numpy as np
import pandas as pd
import pytest

from ml_alpha.latent_denoiser import LatentFactorDenoiser
from ml_alpha.hierarchical_moe import (
    MacroRegimeGater,
    TrendMomentumExpert,
    MeanReversionSqueezeExpert,
    PeerSpilloverExpert,
    HierarchicalMoEPredictor,
    REGIME_BULL_TREND,
    REGIME_STRESS_CRASH,
)


def test_latent_factor_denoiser_rmt():
    """Verifies RMT Marchenko-Pastur spectral clipping."""
    np.random.seed(42)
    N, T = 15, 300
    # Simulate factor matrix with 2 strong signals and 13 noise columns
    signals = np.random.randn(T, 2)
    noise = np.random.randn(T, 13)
    X = np.hstack([signals @ np.array([[1.0, 0.5], [0.5, 1.0]]), noise])
    cols = [f"f_{i}" for i in range(N)]
    df = pd.DataFrame(X, columns=cols)

    denoiser = LatentFactorDenoiser(method="rmt")
    denoiser.fit(df)
    diag = denoiser.get_diagnostics()

    assert diag["method"] == "rmt"
    assert diag["input_dim"] == N
    assert diag["lambda_plus_spectral_bound"] > 0
    assert diag["n_clipped_eigenvalues"] > 0  # Successfully identified and clipped noise eigenvalues

    denoised_df = denoiser.denoise(df)
    assert denoised_df.shape == df.shape
    assert not denoised_df.isna().any().any()
    # Trace of standardized correlation is approximately preserved
    raw_var = np.var(df.values, axis=0)
    denoised_var = np.var(denoised_df.values, axis=0)
    assert np.all(denoised_var > 0)


def test_latent_factor_denoiser_vae():
    """Verifies Factor-VAE latent compression and ELBO reconstruction."""
    np.random.seed(42)
    N, T = 10, 150
    X = np.random.randn(T, N)
    df = pd.DataFrame(X, columns=[f"f_{i}" for i in range(N)])

    denoiser = LatentFactorDenoiser(method="vae", latent_dim=3, vae_epochs=5)
    denoiser.fit(df)
    diag = denoiser.get_diagnostics()

    assert diag["method"] == "vae"
    assert diag["last_elbo_loss"] >= 0
    assert diag["last_recon_loss"] >= 0

    denoised_df = denoiser.denoise(df)
    assert denoised_df.shape == df.shape
    assert not denoised_df.isna().any().any()


def test_macro_regime_gater_classification():
    """Verifies MacroRegimeGater identifies Bull vs Crash market states."""
    np.random.seed(42)
    gater = MacroRegimeGater()

    # 1. Quiet Bull Market: positive steady returns, low volatility
    bull_returns = np.random.normal(0.001, 0.007, 100)  # ~11% ann vol, upward drift
    state_bull, probs_bull = gater.classify_market_state(bull_returns)
    assert len(probs_bull) == 3
    assert np.isclose(np.sum(probs_bull), 1.0)
    assert probs_bull[0] > probs_bull[2]  # P(Bull) > P(Stress)
    assert state_bull == REGIME_BULL_TREND

    # 2. Crash Market: severe negative returns, high volatility
    crash_returns = np.random.normal(-0.015, 0.035, 100)  # ~55% ann vol, crash drift
    state_crash, probs_crash = gater.classify_market_state(crash_returns)
    assert np.isclose(np.sum(probs_crash), 1.0)
    assert probs_crash[2] > probs_crash[0]  # P(Stress) > P(Bull)
    assert state_crash == REGIME_STRESS_CRASH


def test_specialized_experts_execution():
    """Verifies individual experts fit and predict finite numerical arrays."""
    np.random.seed(42)
    n_samples = 80
    feature_names = [
        "mom_252d", "mom_skip21_252", "breakout_252", "trend_sma_200",
        "turnover_ratio_21", "vol_trend_10", "vol_relative_5", "frac_diff_07"
    ]
    X = pd.DataFrame(np.random.randn(n_samples, len(feature_names)), columns=feature_names)
    y = np.random.randn(n_samples) * 0.05
    tickers = [f"SYM_{i}.NS" for i in range(n_samples)]

    # Expert 1: Trend
    trend_exp = TrendMomentumExpert(n_estimators=10, max_depth=3)
    trend_exp.fit(X, y)
    p_trend = trend_exp.predict(X)
    assert len(p_trend) == n_samples
    assert not np.isnan(p_trend).any()

    # Expert 2: Reversion
    rev_exp = MeanReversionSqueezeExpert()
    rev_exp.fit(X, y)
    p_rev = rev_exp.predict(X)
    assert len(p_rev) == n_samples
    assert not np.isnan(p_rev).any()

    # Expert 3: Peer Spillover
    spill_exp = PeerSpilloverExpert()
    spill_exp.fit(X, y)
    p_spill = spill_exp.predict(X, tickers=tickers)
    assert len(p_spill) == n_samples
    assert not np.isnan(p_spill).any()


def test_hierarchical_moe_predictor_end_to_end():
    """Verifies complete HierarchicalMoEPredictor integration, dynamic weights, and output validity."""
    np.random.seed(42)
    n_samples = 100
    feature_names = [
        "mom_252d", "breakout_252", "trend_sma_200",
        "turnover_ratio_21", "vol_trend_10", "frac_diff_07"
    ]
    X = pd.DataFrame(np.random.randn(n_samples, len(feature_names)), columns=feature_names)
    y = np.random.randn(n_samples) * 0.04
    tickers = [f"TICKER_{i}.NS" for i in range(n_samples)]
    benchmark = pd.Series(np.random.normal(0.0005, 0.01, 150))

    moe = HierarchicalMoEPredictor(denoise_method="hybrid", latent_dim=3)
    moe.fit(X, y, tickers=tickers, benchmark_returns=benchmark)

    preds = moe.predict(X, tickers=tickers)
    assert isinstance(preds, pd.Series)
    assert len(preds) == n_samples
    assert not preds.isna().any()

    breakdown = moe.get_regime_breakdown()
    assert "current_regime" in breakdown
    assert "expert_weights" in breakdown
    weights = breakdown["expert_weights"]
    assert np.isclose(sum(weights.values()), 1.0, atol=1e-3)


def test_hierarchical_moe_cpu_safe_serialization(tmp_path):
    """Verifies that HierarchicalMoEPredictor can be pickled and unpickled with lean size (<1MB) and CPU safety."""
    np.random.seed(42)
    n_samples = 60
    feature_names = ["mom_252d", "breakout_252", "vol_trend_10", "turnover_ratio_21"]
    X = pd.DataFrame(np.random.randn(n_samples, len(feature_names)), columns=feature_names)
    y = np.random.randn(n_samples) * 0.03
    tickers = [f"EQ_{i}.NS" for i in range(n_samples)]

    moe = HierarchicalMoEPredictor(denoise_method="hybrid", latent_dim=2)
    moe.fit(X, y, tickers=tickers)

    save_path = tmp_path / "moe_model_test.pkl"
    with open(save_path, "wb") as f:
        pickle.dump(moe, f)

    file_size_bytes = os.path.getsize(save_path)
    # Must be under 1.5 MB (ultra-lean)
    assert file_size_bytes < 1_500_000, f"Model file size too large: {file_size_bytes} bytes"

    # Unpickle and test prediction on CPU
    with open(save_path, "rb") as f:
        unpickled_moe = pickle.load(f)

    preds = unpickled_moe.predict(X, tickers=tickers)
    assert len(preds) == n_samples
    assert not preds.isna().any()
