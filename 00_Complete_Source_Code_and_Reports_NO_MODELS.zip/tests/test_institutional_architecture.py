"""
tests/test_institutional_architecture.py
=========================================
Hermetic Integration & Unit Test Suite for Institutional Architecture:
  1. Transactional Database & SQLite WAL Mode
  2. Master Hardware/Software Emergency Kill Switch
  3. Hard Pre-Trade Risk Gateway & Statutory Safeguards
  4. Perold (1988) Implementation Shortfall & TCA Engine
  5. Event-Driven Broker OMS & Execution Engine
  6. Integration with optimizer_broker.py (Dhan & Zerodha)
"""
import os
import tempfile
import pytest
from pathlib import Path

from core.db_engine import TransactionalDBEngine, get_db
from core.kill_switch import MasterKillSwitch
from core.risk_gateway import HardPreTradeRiskGateway
from core.tca_engine import TCAEngine
from core.broker_oms import BrokerOrderManagementSystem
from optimizer_broker import dhan_place_basket, zerodha_place_basket


@pytest.fixture(autouse=True)
def isolated_db_environment(monkeypatch):
    """Provide an isolated temporary SQLite database for each test."""
    temp_dir = tempfile.TemporaryDirectory()
    temp_db_path = Path(temp_dir.name) / "test_institutional.db"
    
    # Initialize test DB
    test_db = TransactionalDBEngine(temp_db_path)
    monkeypatch.setattr(TransactionalDBEngine, "_instance", test_db)
    
    # Ensure kill switch is clean/disarmed at start
    MasterKillSwitch.deactivate(reason="Test fixture init", operator="TEST")
    
    yield test_db
    
    temp_dir.cleanup()


# ── 1. Database & WAL Mode Tests ─────────────────────────────────────────────

def test_database_acid_wal_transactions(isolated_db_environment):
    """Verify SQLite WAL mode and atomic transaction rollback."""
    db = isolated_db_environment
    with db.connection() as conn:
        cursor = conn.cursor()
        cursor.execute("PRAGMA journal_mode;")
        row = cursor.fetchone()
        assert row[0].lower() == "wal", f"Expected WAL mode, got {row[0]}"

    # Verify order insertion and status updates
    ok = db.record_order(
        order_id="TEST-ORD-001",
        broker="paper",
        symbol="RELIANCE.NS",
        side="BUY",
        qty=100,
        price=2950.0,
        status="PENDING_RISK",
    )
    assert ok is True

    retrieved = db.get_order("TEST-ORD-001")
    assert retrieved is not None
    assert retrieved["symbol"] == "RELIANCE.NS"
    assert retrieved["qty"] == 100
    assert retrieved["status"] == "PENDING_RISK"

    # Test update
    db.update_order_status(
        order_id="TEST-ORD-001",
        status="FILLED",
        filled_qty=100,
        avg_fill_price=2952.5,
    )
    updated = db.get_order("TEST-ORD-001")
    assert updated["status"] == "FILLED"
    assert updated["filled_qty"] == 100
    assert updated["avg_fill_price"] == 2952.5


# ── 2. Kill Switch Tests ─────────────────────────────────────────────────────

def test_kill_switch_lifecycle(isolated_db_environment):
    """Test emergency kill switch activation, order cancellation, and deactivation."""
    db = isolated_db_environment

    # Initially disarmed
    assert MasterKillSwitch.is_active() is False

    # Insert an active order
    db.record_order(
        order_id="WORKING-001",
        broker="paper",
        symbol="TCS.NS",
        side="BUY",
        qty=50,
        price=4200.0,
        status="SUBMITTED",
    )

    # Activate kill switch
    res = MasterKillSwitch.activate(reason="Flash crash detected", operator="CHIEF_RISK_OFFICER")
    assert res["status"] == "SUCCESS"
    assert res["active"] is True
    assert MasterKillSwitch.is_active() is True
    assert "WORKING-001" in res["cancelled_orders"]

    # Verify working order is now CANCELLED in DB
    order = db.get_order("WORKING-001")
    assert order["status"] == "CANCELLED"
    assert "Flash crash detected" in order["rejection_reason"]

    # Verify pre-trade gateway blocks new orders fail-closed
    gateway = HardPreTradeRiskGateway()
    is_ok, reason = gateway.validate_order(symbol="INFY.NS", side="BUY", qty=10, price=1800.0)
    assert is_ok is False
    assert "kill switch is active" in reason.lower()

    # Disarm kill switch
    disarm_res = MasterKillSwitch.deactivate(reason="Market stabilized", operator="CHIEF_RISK_OFFICER")
    assert disarm_res["active"] is False
    assert MasterKillSwitch.is_active() is False

    # Now orders should pass again
    is_ok, _ = gateway.validate_order(symbol="INFY.NS", side="BUY", qty=10, price=1800.0)
    assert is_ok is True


# ── 3. Hard Pre-Trade Risk Gateway Tests ─────────────────────────────────────

def test_risk_gateway_order_value_ceiling():
    """Verify orders exceeding single-order rupee limit are rejected."""
    gateway = HardPreTradeRiskGateway({"RISK_MAX_ORDER_VALUE": 2_500_000.0})

    # Order under ceiling: 500 * ₹4,000 = ₹20,00,000 (Approved)
    ok, err = gateway.validate_order("TCS.NS", "BUY", 500, 4000.0)
    assert ok is True
    assert err is None

    # Order over ceiling: 1,000 * ₹4,000 = ₹40,00,000 (Rejected)
    ok, err = gateway.validate_order("TCS.NS", "BUY", 1000, 4000.0)
    assert ok is False
    assert "exceeds statutory ceiling" in err


def test_risk_gateway_freeze_limit():
    """Verify orders exceeding exchange freeze quantities are blocked."""
    gateway = HardPreTradeRiskGateway()

    # NIFTYBEES freeze limit is 100,000
    ok, err = gateway.validate_order("NIFTYBEES.NS", "BUY", 150_000, 250.0)
    assert ok is False
    assert "exceeds exchange freeze limit" in err


def test_risk_gateway_portfolio_concentration():
    """Verify portfolio concentration limits for stocks and sectors."""
    gateway = HardPreTradeRiskGateway({
        "RISK_MAX_STOCK_CONCENTRATION": 0.10,
        "RISK_MAX_SECTOR_CONCENTRATION": 0.25,
    })

    # Single stock > 10%
    bad_weights = {"RELIANCE.NS": 0.15, "TCS.NS": 0.08, "INFY.NS": 0.05, "CASH": 0.72}
    res = gateway.validate_basket(bad_weights, total_nav=1_000_000.0)
    assert res["status"] == "BLOCKED"
    assert any("STOCK_CONCENTRATION_LIMIT" in v["rule"] for v in res["violations"])

    # Sector > 25%
    sector_map = {"TCS.NS": "IT", "INFY.NS": "IT", "WIPRO.NS": "IT", "RELIANCE.NS": "Energy"}
    sector_heavy_weights = {"TCS.NS": 0.10, "INFY.NS": 0.10, "WIPRO.NS": 0.10, "RELIANCE.NS": 0.05, "CASH": 0.65}
    res_sec = gateway.validate_basket(sector_heavy_weights, total_nav=1_000_000.0, sector_map=sector_map)
    assert res_sec["status"] == "BLOCKED"
    assert any("SECTOR_CONCENTRATION_LIMIT" in v["rule"] for v in res_sec["violations"])


# ── 4. Transaction Cost Analysis (TCA) Tests ─────────────────────────────────

def test_tca_implementation_shortfall_math():
    """Verify exact mathematical calculation of Perold (1988) Implementation Shortfall."""
    engine = TCAEngine()

    # BUY Order:
    # Decision Price: 100.0
    # Arrival Price: 101.0
    # Execution Fill Price: 101.50
    tca = engine.analyze_and_record_trade(
        order_id="TCA-TEST-001",
        symbol="SBIN.NS",
        side="BUY",
        qty=1000,
        decision_price=100.0,
        arrival_price=101.0,
        execution_price=101.50,
        adv=500_000,
    )

    # Delay slippage: (101 - 100) / 100 * 10,000 = 100.0 bps
    assert tca["delay_slippage_bps"] == pytest.approx(100.0, abs=0.1)

    # Execution slippage: (101.50 - 101) / 101 * 10,000 = 49.50 bps
    assert tca["execution_slippage_bps"] == pytest.approx(49.50, abs=0.1)

    # Total Implementation Shortfall: (101.50 - 100) / 100 * 10,000 = 150.0 bps
    assert tca["total_shortfall_bps"] == pytest.approx(150.0, abs=0.1)


# ── 5. Broker OMS & Execution Engine Tests ───────────────────────────────────

def test_broker_oms_paper_execution():
    """Verify end-to-end execution of paper order through OMS with automatic TCA."""
    oms = BrokerOrderManagementSystem()
    res = oms.submit_order(
        broker="paper",
        symbol="HDFCBANK.NS",
        side="BUY",
        qty=100,
        price=1650.0,
        ltp=1650.0,
        decision_price=1648.0,
        dry_run=True,
    )

    assert res["success"] is True
    assert res["status"] == "FILLED"
    assert res["filled_qty"] == 100
    assert res["avg_fill_price"] > 0
    assert "tca" in res
    assert res["tca"]["total_shortfall_bps"] != 0.0

    # Verify persisted in DB
    db = get_db()
    db_order = db.get_order(res["order_id"])
    assert db_order["status"] == "FILLED"
    assert db_order["symbol"] == "HDFCBANK.NS"


def test_dhan_and_kite_basket_execution():
    """Verify that dhan_place_basket and zerodha_place_basket route through OMS without raising NotImplementedError."""
    from data_layer import DynamicPriceResolver

    # AUDIT-FIX (Round 43): hermetic price seeding. This test previously relied
    # on the ₹100/share price fabrication that AUDIT-04 (C-4) removed from the
    # dhan/zerodha basket builders — with honest price resolution an unseeded
    # ticker is skipped (no fabricated fill price), so the test now seeds the
    # price cache explicitly, exactly like the Round 41 angelone test does.
    DynamicPriceResolver._CACHE["ITC.NS"] = 400.0
    DynamicPriceResolver._CACHE["ASIANPAINT.NS"] = 2800.0

    weights = {"ITC.NS": 0.05, "ASIANPAINT.NS": 0.05, "CASH": 0.90}
    portfolio_value = 500_000.0

    # Dhan execution in dry_run mode
    dhan_res = dhan_place_basket(
        weights=weights,
        portfolio_value=portfolio_value,
        api_key="mock_key",
        client_id="mock_client",
        dry_run=True,
    )
    assert dhan_res["total_orders"] == 2
    assert dhan_res["executed_count"] == 2
    assert dhan_res["rejected_count"] == 0

    # Zerodha Kite execution in dry_run mode
    kite_res = zerodha_place_basket(
        weights=weights,
        portfolio_value=portfolio_value,
        api_key="mock_key",
        dry_run=True,
    )
    assert kite_res["total_orders"] == 2
    assert kite_res["executed_count"] == 2
    assert kite_res["rejected_count"] == 0
