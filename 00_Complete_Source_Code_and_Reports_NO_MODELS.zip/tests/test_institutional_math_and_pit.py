"""tests/test_institutional_math_and_pit.py
=========================================
Hermetic Unit & Integration Test Suite for:
  1. Multi-Stage Minervini Volatility Contraction Pattern (VCP)
  2. Volume-Clock VPIN (Easley, López de Prado, & O'Hara 2012)
  3. Sloan Accruals Anomaly Ratio (Sloan 1996)
  4. Piotroski 9-Point Fundamental Composite F-Score (Piotroski 2000)
  5. Novy-Marx Gross Profitability / Total Assets (Novy-Marx 2013)
  6. Ledoit-Wolf Analytical Shrinkage Covariance (Ledoit & Wolf 2004)
  7. Hierarchical Risk Parity (HRP - López de Prado 2016)
  8. Conditional Value-at-Risk (CVaR / Expected Shortfall)
  9. SEBI Anchor Lock-in Expiry Impact & Free-Float Velocity
  10. Point-in-Time (PIT) Fundamentals Fetcher & Zero-Lookahead Lag
  11. Cross-Sectional Listwise LGBMRanker in ExpandedAlphaEnsemble
"""
from __future__ import annotations

import tempfile
from pathlib import Path
import numpy as np
import pandas as pd
import pytest

from math_engine.institutional.momentum_vcp import (
    compute_minervini_vcp,
    compute_volume_clock_vpin,
)
from math_engine.institutional.quality_accounting import (
    compute_sloan_accrual_ratio,
    compute_piotroski_f_score,
    compute_novy_marx_gross_profitability,
)
from math_engine.institutional.risk_parity import (
    ledoit_wolf_shrinkage_covariance,
    hierarchical_risk_parity_weights,
    compute_cvar_expected_shortfall,
)
from math_engine.institutional.ipo_microstructure import (
    compute_sebi_anchor_lockin_impact,
    compute_free_float_velocity,
    compute_base_tightness_geometry,
)
from data.fundamentals_pit_fetcher import PITFundamentalsFetcher, init_pit_db
from ml_alpha.expanded_ensemble import ExpandedAlphaEnsemble


# ── 1. Momentum & Volatility Squeeze Math ────────────────────────────────────

def test_minervini_vcp_contracting_waves():
    """Verify authentic Minervini VCP detects monotonic wave contraction."""
    # Synthesize 70 bars with compressing volatility:
    # Wave 1 (50 to 25 bars ago): high=120, low=90 (dd = 25%)
    # Wave 2 (25 to 10 bars ago): high=110, low=98 (dd = 10.9%)
    # Wave 3 (last 10 bars): high=105, low=100 (dd = 4.7%)
    n = 70
    closes = np.full(n, 100.0)
    highs = np.full(n, 102.0)
    lows = np.full(n, 98.0)
    vols = np.full(n, 1000.0)

    # Wave 1
    highs[-50:-25] = 120.0
    lows[-50:-25] = 90.0
    closes[-50:-25] = 105.0
    vols[-50:-25] = 5000.0  # Heavy volume at base inception

    # Wave 2
    highs[-25:-10] = 110.0
    lows[-25:-10] = 98.0
    closes[-25:-10] = 104.0
    vols[-25:-10] = 2500.0

    # Wave 3 (Pivot)
    highs[-10:] = 105.0
    lows[-10:] = 100.0
    closes[-10:] = 104.5
    vols[-10:] = 800.0  # Volume dryup

    df = pd.DataFrame({"high": highs, "low": lows, "close": closes, "volume": vols})
    res = compute_minervini_vcp(df)

    assert res["is_vcp_valid"] is True
    assert res["dd_wave1"] > res["dd_wave2"] > res["dd_wave3"]
    assert res["volume_dryup_ratio"] < 0.75
    assert res["vcp_score"] >= 75.0


def test_minervini_vcp_expanding_volatility_rejection():
    """Verify non-contracting / expanding patterns are rejected."""
    n = 70
    closes = np.full(n, 100.0)
    highs = np.full(n, 102.0)
    lows = np.full(n, 98.0)

    # Expanding: wave 1 small, wave 3 large
    highs[-50:-25] = 104.0
    lows[-50:-25] = 99.0
    highs[-10:] = 130.0
    lows[-10:] = 80.0

    df = pd.DataFrame({"high": highs, "low": lows, "close": closes, "volume": 1000.0})
    res = compute_minervini_vcp(df)
    assert res["is_vcp_valid"] is False


def test_volume_clock_vpin_bounds():
    """Verify Volume-Clock VPIN computation stays strictly bounded in [0.01..0.99]."""
    np.random.seed(42)
    n = 100
    rets = np.random.randn(n) * 0.01
    closes = 100.0 * np.exp(np.cumsum(rets))
    vols = np.random.uniform(50000, 200000, size=n)

    df = pd.DataFrame({"close": closes, "volume": vols})
    vpin = compute_volume_clock_vpin(df)
    assert 0.01 <= vpin <= 0.99
    assert isinstance(vpin, float)


# ── 2. Forensic Accounting & Quality Math ────────────────────────────────────

def test_sloan_accrual_anomaly_ratio():
    """Verify Sloan Accruals distinguishes high-cash-quality from accrual-heavy earnings."""
    # Conservative company: CFO outstrips Net Income (negative accruals)
    accrual_good = compute_sloan_accrual_ratio(net_income=100.0, operating_cash_flow=160.0, total_assets=1000.0)
    assert accrual_good == pytest.approx(-0.06, abs=1e-4)

    # Aggressive company: Net Income high but no cash backing (positive accruals)
    accrual_bad = compute_sloan_accrual_ratio(net_income=180.0, operating_cash_flow=40.0, total_assets=1000.0)
    assert accrual_bad == pytest.approx(0.14, abs=1e-4)
    assert accrual_good < accrual_bad


def test_piotroski_f_score_all_signals():
    """Verify Piotroski 9-point composite evaluates all 9 dimensions."""
    # Perfect 9/9 firm
    res_perfect = compute_piotroski_f_score(
        roa_curr=0.15, roa_prev=0.10,
        cfo_curr=200.0, total_assets_curr=1000.0,
        leverage_curr=0.30, leverage_prev=0.40,
        current_ratio_curr=2.0, current_ratio_prev=1.8,
        shares_curr=100.0, shares_prev=100.0,
        gross_margin_curr=0.35, gross_margin_prev=0.30,
        asset_turnover_curr=1.2, asset_turnover_prev=1.1,
    )
    assert res_perfect["f_score"] == 9
    assert res_perfect["is_high_quality"] is True

    # Severely deteriorating firm: 0/9
    res_poor = compute_piotroski_f_score(
        roa_curr=-0.05, roa_prev=0.05,
        cfo_curr=-100.0, total_assets_curr=1000.0,
        leverage_curr=0.80, leverage_prev=0.50,
        current_ratio_curr=0.9, current_ratio_prev=1.2,
        shares_curr=150.0, shares_prev=100.0,
        gross_margin_curr=0.15, gross_margin_prev=0.25,
        asset_turnover_curr=0.6, asset_turnover_prev=0.8,
    )
    assert res_poor["f_score"] == 0
    assert res_poor["is_high_quality"] is False


def test_novy_marx_gross_profitability():
    """Verify Novy-Marx Gross Profitability / Total Assets calculation."""
    gp = compute_novy_marx_gross_profitability(revenue=500.0, cogs=300.0, total_assets=1000.0)
    assert gp == pytest.approx(0.20, abs=1e-4)

    # Edge case: zero assets
    assert compute_novy_marx_gross_profitability(revenue=100.0, cogs=50.0, total_assets=0.0) == 0.0


# ── 3. Risk Parity & Analytical Shrinkage Math ────────────────────────────────

def test_ledoit_wolf_shrinkage_properties():
    """Verify Ledoit-Wolf produces symmetric, positive-definite covariance with valid intensity."""
    np.random.seed(123)
    T, N = 60, 5
    returns = np.random.randn(T, N) * 0.02
    cov_shrunk, delta = ledoit_wolf_shrinkage_covariance(returns)

    assert cov_shrunk.shape == (N, N)
    assert 0.0 <= delta <= 1.0
    # Symmetric
    np.testing.assert_allclose(cov_shrunk, cov_shrunk.T, atol=1e-8)
    # Positive definite
    eigenvals = np.linalg.eigvalsh(cov_shrunk)
    assert np.all(eigenvals > 0)


def test_hierarchical_risk_parity_weights():
    """Verify HRP generates non-negative weights that sum to 1.0 with inverse-volatility preference."""
    np.random.seed(42)
    T = 100
    # Asset 0: low vol (1%), Asset 1: med vol (2%), Asset 2: high vol (4%)
    r0 = np.random.randn(T) * 0.01
    r1 = np.random.randn(T) * 0.02
    r2 = np.random.randn(T) * 0.04
    returns_df = pd.DataFrame({"LOW_VOL": r0, "MED_VOL": r1, "HIGH_VOL": r2})

    weights = hierarchical_risk_parity_weights(returns_df)

    assert set(weights.keys()) == {"LOW_VOL", "MED_VOL", "HIGH_VOL"}
    assert sum(weights.values()) == pytest.approx(1.0, abs=1e-4)
    assert all(w > 0.0 for w in weights.values())
    # Low-vol asset must receive higher allocation than high-vol asset
    assert weights["LOW_VOL"] > weights["HIGH_VOL"]


def test_cvar_expected_shortfall_subadditivity():
    """Verify CVaR is strictly more conservative than VaR in the tail."""
    np.random.seed(42)
    rets = np.random.standard_t(df=3, size=500) * 0.02  # Fat-tailed distribution
    res = compute_cvar_expected_shortfall(rets, confidence=0.95)

    assert res["var"] < 0
    assert res["cvar"] <= res["var"]  # CVaR is the average of returns <= VaR


# ── 4. IPO Microstructure & SEBI Regulatory Math ─────────────────────────────

def test_sebi_anchor_lockin_impact_lifecycle():
    """Verify SEBI Anchor lock-in mechanics correctly assess 30d cliff, 90d cliff, and mature seasoning."""
    dummy_ohlcv = pd.DataFrame({
        "close": np.linspace(100, 150, 100),
        "volume": np.full(100, 50000.0),
    })

    # Young IPO at Day 29 (1 day before 30-day cliff)
    res_30 = compute_sebi_anchor_lockin_impact(listing_age_days=29, recent_ohlcv=dummy_ohlcv, free_float_shares=1e7)
    assert res_30["lockin_status"] == "HIGH_CLIFF_VOLATILITY"
    assert res_30["supply_cliff_risk"] >= 0.80

    # Seasoned IPO in 1-2 Year Sweet Spot (Day 450)
    res_sweet = compute_sebi_anchor_lockin_impact(listing_age_days=450, recent_ohlcv=dummy_ohlcv, free_float_shares=1e7)
    assert res_sweet["is_in_sweet_spot"] is True
    assert res_sweet["lockin_status"] == "FULLY_UNLOCKED_MATURE_BASE"
    assert res_sweet["supply_cliff_risk"] <= 0.10


def test_free_float_velocity_and_base_tightness():
    """Verify float velocity ratio and base tightness metrics."""
    # 2% of float delivered daily -> extreme accumulation
    vel = compute_free_float_velocity(avg_daily_delivery_volume=200_000, free_float_shares=10_000_000)
    assert vel >= 0.70

    # Base tightness
    ohlcv = pd.DataFrame({
        "high": [102.0] * 20,
        "low": [98.0] * 20,
        "close": [100.0] * 20,
    })
    tightness = compute_base_tightness_geometry(ohlcv, consolidation_bars=20)
    assert tightness["tightness_pct"] <= 5.0
    assert tightness["is_tight_base"] is True


# ── 5. Point-in-Time (PIT) Fundamentals & Zero-Lookahead Lag ─────────────────

def test_pit_fetcher_isolated_db_zero_lookahead():
    """Verify PIT fundamentals engine strictly enforces 75-day lag and step-forward caching."""
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_db = Path(tmp_dir) / "test_pit.db"
        fetcher = PITFundamentalsFetcher(db_path=tmp_db)

        # Manually populate disclosures for a test ticker
        # Period ending: 2024-03-31 -> Disclosed on: 2024-06-14 (75-day lag)
        conn = fetcher._init_db()
        import sqlite3
        conn = sqlite3.connect(str(tmp_db))
        with conn:
            conn.execute("""
                INSERT INTO quarterly_disclosures (
                    ticker, period_end, disclosed_at, net_income, operating_cfo,
                    total_assets, total_revenue, cost_of_revenue, stockholders_equity,
                    total_debt, current_assets, current_liabilities, sloan_accrual,
                    novy_marx_gp, roe, debt_equity, profit_margin, f_score
                ) VALUES (
                    'TESTCO', '2024-03-31', '2024-06-14', 100.0, 140.0,
                    1000.0, 500.0, 300.0, 600.0, 100.0, 400.0, 200.0,
                    -0.04, 0.20, 0.166, 0.166, 0.20, 8
                )
            """)
        conn.close()

        # Query on 2024-06-01 (BEFORE disclosure date 2024-06-14)
        # MUST return fallback baseline (zero-lookahead guarantee)
        fund_before = fetcher.get_ticker_fundamentals_as_of("TESTCO", "2024-06-01")
        assert fund_before["is_real_filing"] is False
        assert fund_before["sloan_accrual"] == 0.0

        # Query on 2024-06-15 (AFTER disclosure date 2024-06-14)
        # MUST return actual audited disclosure
        fund_after = fetcher.get_ticker_fundamentals_as_of("TESTCO", "2024-06-15")
        assert fund_after["is_real_filing"] is True
        assert fund_after["sloan_accrual"] == pytest.approx(-0.04, abs=1e-4)
        assert fund_after["f_score"] == 8
        assert fund_after["disclosed_at"] == "2024-06-14"

        # Verify get_pit_panels generates aligned panels with step function
        dates = ["2024-06-01", "2024-06-10", "2024-06-20"]
        panels = fetcher.get_pit_panels(["TESTCO"], dates)
        assert "z_sloan_accrual" in panels
        sloan_series = panels["z_sloan_accrual"]["TESTCO"]
        assert sloan_series.loc["2024-06-01"] == 0.0
        assert sloan_series.loc["2024-06-20"] == pytest.approx(-0.04, abs=1e-4)


# ── 6. ExpandedAlphaEnsemble LGBMRanker Integration ──────────────────────────

def test_expanded_ensemble_lgb_ranker():
    """Verify ExpandedAlphaEnsemble fits LGBMRanker with cross-sectional grouping and generates valid ranking scores."""
    np.random.seed(42)
    # Generate 4 dates with 10 tickers each
    dates = pd.date_range("2024-01-01", periods=4, freq="D")
    tickers = [f"STK_{i}" for i in range(10)]
    idx = pd.MultiIndex.from_product([dates, tickers], names=["date", "ticker"])

    X = pd.DataFrame(np.random.randn(len(idx), 6), index=idx, columns=[f"f_{i}" for i in range(6)])
    y = pd.Series(np.random.randn(len(idx)), index=idx)

    model = ExpandedAlphaEnsemble(model_type="ranker", use_catboost=False, use_xgboost=False)
    model.fit(X, y, groups=idx.get_level_values("date"))

    preds = model.predict(X)
    assert len(preds) == len(X)
    assert np.all(np.isfinite(preds))
    assert "lightgbm" in model._models
