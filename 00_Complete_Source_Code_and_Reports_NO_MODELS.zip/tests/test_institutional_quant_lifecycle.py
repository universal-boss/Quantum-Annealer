"""
tests/test_institutional_quant_lifecycle.py
===========================================
Unit tests for the InstitutionalQuantLifecycleEngine.
Verifies the 5 core institutional quantitative risk and exit pillars:
1. Alpha Signal Dynamics & Empirical Half-Life Horizon
2. Convex Quadratic Utility Rebalancing & Variance Harvesting
3. Market Microstructure Order Flow Toxicity (VPIN Early Liquidation)
4. Fundamental & Factor Disqualification Surveillance (Piotroski, Altman)
5. Marginal Conditional Value-at-Risk (MCVaR 99%) & Snell Continuation Value
"""
import sys, os, unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from math_engine.institutional_lifecycle_engine import InstitutionalQuantLifecycleEngine


class TestInstitutionalQuantLifecycle(unittest.TestCase):

    def test_active_alpha_expansion_hold(self):
        res = InstitutionalQuantLifecycleEngine.evaluate_position_lifecycle(
            ticker="TRENT.NS",
            entry_price=4500.0,
            current_price=5200.0,
            current_weight_pct=6.67,
            optimal_weight_pct=6.67,
            momentum_z=2.5,
            vpin_toxicity=0.12,
            piotroski_f=9,
            altman_z=4.5,
            holding_days=5
        )
        self.assertEqual(res["signal_lifecycle"], "ACTIVE_EXPANDING")
        self.assertEqual(res["lifecycle_action"], "HOLD_ACTIVE_ALPHA")
        self.assertEqual(res["vpin_status"], "SAFE_ACCUMULATION")
        self.assertEqual(res["factor_status"], "PRIME_QUALITY")
        self.assertEqual(res["continuation_decision"], "CONTINUE_RIDE")
        self.assertGreater(res["snell_continuation_value_pct"], res["unrealized_pnl_pct"])

    def test_weight_bloat_harvest_trim(self):
        # Position was allocated at 6.67%, but stock rallied +120% and weight bloated to 11.5%
        res = InstitutionalQuantLifecycleEngine.evaluate_position_lifecycle(
            ticker="DIXON.NS",
            entry_price=8000.0,
            current_price=17600.0,
            current_weight_pct=11.5,
            optimal_weight_pct=6.67,
            momentum_z=2.8,
            vpin_toxicity=0.20,
            holding_days=25
        )
        self.assertTrue("HARVEST_TRIM" in res["lifecycle_action"])
        self.assertIn("Harvest variance", res["lifecycle_description"])

    def test_microstructure_vpin_toxicity_exit(self):
        # Heavy institutional dumping detected with VPIN > 0.65
        res = InstitutionalQuantLifecycleEngine.evaluate_position_lifecycle(
            ticker="TOXIC_STOCK.NS",
            entry_price=100.0,
            current_price=98.0,
            current_weight_pct=6.67,
            optimal_weight_pct=6.67,
            vpin_toxicity=0.78,
            holding_days=3
        )
        self.assertEqual(res["lifecycle_action"], "TOXICITY_CUT")
        self.assertEqual(res["vpin_status"], "CRITICAL_TOXIC")
        self.assertIn("Informed Institutional Dumping", res["microstructure_alert"])

    def test_fundamental_factor_disqualification_exit(self):
        # Piotroski F-Score deteriorates to 3 and Altman Z enters distress < 1.8
        res = InstitutionalQuantLifecycleEngine.evaluate_position_lifecycle(
            ticker="FAILEDBIZ.NS",
            entry_price=200.0,
            current_price=190.0,
            current_weight_pct=6.67,
            optimal_weight_pct=6.67,
            piotroski_f=3,
            altman_z=1.2,
            holding_days=15
        )
        self.assertEqual(res["lifecycle_action"], "DISQUALIFIED_EXIT")
        self.assertEqual(res["factor_status"], "FUNDAMENTAL_VIOLATION")


if __name__ == "__main__":
    unittest.main(verbosity=2)
