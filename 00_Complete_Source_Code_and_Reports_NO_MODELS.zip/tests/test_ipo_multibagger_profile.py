"""Tests for 🦄 High-Growth IPO · Multibagger Hunter research profile."""

import pytest
import pandas as pd
import numpy as np
from pathlib import Path

from data_layer import PROFILE_MAP, DEFAULT_CFG
import utils


def test_ipo_profile_registered_in_profile_map():
    """Verify 🦄 High-Growth IPO · Multibagger Hunter is registered with institutional SOTA factors."""
    profile_name = "🦄 High-Growth IPO · Multibagger Hunter"
    assert profile_name in PROFILE_MAP, f"Profile '{profile_name}' not found in PROFILE_MAP"

    cfg = PROFILE_MAP[profile_name]
    assert cfg.get("PROFILE_NAME") == profile_name
    assert cfg.get("PRESCREEN_MODE") == "ipo_multibagger"
    assert cfg.get("STRATEGY_MODE") == "Alpha-Concentrated"
    assert cfg.get("REQUIRE_STAGE2_TREND") is False  # IPO bases do not require rigid 200 SMA
    assert cfg.get("ALPHA") >= 3.0  # High alpha target
    assert cfg.get("USE_FLOAT_SQUEEZE") is True
    assert cfg.get("USE_BULK_DEAL_SIGNAL") is True
    assert cfg.get("USE_PEAD_SIGNAL") is True

    fw = cfg.get("FACTOR_WEIGHTS", {})
    # 1. Microstructure & Float Absorption
    assert "z_float_squeeze" in fw
    assert "z_bulk_deal_footprint" in fw
    assert "z_vpin_toxicity" in fw
    assert "z_delivery" in fw
    # 2. Forensic Quality & Accounting Momentum
    assert "z_pead" in fw
    assert "z_de_inv" in fw
    assert "z_roe" in fw
    # 3. Volatility Contraction & Non-Linear Dynamics
    assert "z_vcp" in fw
    assert "z_volume_dryup" in fw
    assert "z_ma_compression" in fw
    assert sum(fw.values()) > 0.5


def test_ipo_prescreen_scoring_logic():
    """Verify ipo_multibagger prescreen scoring rewards Neural-SDE, Hurst, VCP, and Up/Down volume."""
    df = pd.DataFrame({
        "ticker": ["IPO_LEADER.NS", "IPO_LAGGARD.NS"],
        "z_neural_sde": [1.8, -0.8],
        "z_hurst": [1.6, -0.5],
        "z_vcp_score": [1.5, -0.4],
        "z_updown_vol": [1.3, -0.8],
        "z_rs_raw": [1.5, -1.0],
        "z_ker": [1.2, -0.6],
        "z_adv20": [0.5, 0.5],
        "z_mom_1m": [0.3, -2.5],  # Laggard has falling-knife penalty
    })

    def _get_z(col):
        return df[col].fillna(0.0)

    _liq_z = _get_z("z_adv20")
    score = (
        0.22 * _get_z("z_neural_sde") +
        0.18 * _get_z("z_hurst") +
        0.18 * _get_z("z_vcp_score") +
        0.14 * _get_z("z_updown_vol") +
        0.12 * _get_z("z_rs_raw") +
        0.08 * _get_z("z_ker") +
        0.08 * _liq_z -
        0.40 * np.maximum(0.0, -_get_z("z_mom_1m"))
    )
    df["score"] = score

    assert df.loc[0, "score"] > df.loc[1, "score"], "IPO leader with strong SDE drift, Hurst persistence, and VCP must score higher"
    assert df.loc[1, "score"] < 0, "Severe falling knife in IPO must trigger significant deduction"


def test_ipo_prescreen_filtering_window():
    """R38: the PRODUCTION ipo_gate_pass enforces the 1-2 YEAR listing window.

    SUPERSEDES the pre-R38 local re-implementation (bars-only logic that
    drifted from production and never checked the calendar window). This lock
    now calls math_engine.ipo_multibagger_math.ipo_gate_pass itself on REAL
    DynamicSecurityMaster listing dates with a pinned as_of_date, so the
    contract the user asked for — '1-2 year listed stocks' — is what is
    actually locked: 365 <= listing age in calendar days <= 730.
    """
    import datetime as _dt
    from math_engine.ipo_multibagger_math import ipo_gate_pass

    AS_OF = _dt.date(2026, 9, 16)
    cfg = dict(DEFAULT_CFG)
    cfg["PRESCREEN_MODE"] = "ipo_multibagger"
    cfg["REQUIRE_BASE_FORMATION"] = False  # isolate the listing-age window

    base = {
        "adv20": 50_000_000.0,
        "pct_below_52w_high": 0.12,
        "market_cap_cr": 1500.0,
        "bars_count": 350,
    }

    # 1. KRN — listed 2024-10-03, 713d old at AS_OF -> STRICTLY IN the 1-2y window -> PASS
    ok, why = ipo_gate_pass({**base, "ticker": "KRN.NS"}, cfg,
                            expected_days=504, as_of_date=AS_OF)
    assert ok is True, f"KRN (713d, in-window) must pass, got: {why}"

    # 2. BLSE — listed 2024-02-06, 953d old -> MATURE (> 730d) -> REJECT
    ok, why = ipo_gate_pass({**base, "ticker": "BLSE.NS"}, cfg,
                            expected_days=504, as_of_date=AS_OF)
    assert ok is False and "730" in (why or ""), \
        f"BLSE (953d) must be rejected by the 730d ceiling, got: {ok} {why}"

    # 3. ARSSBL — listed 2025-09-30, 351d old -> UNSEASONED (< 365d) -> REJECT
    ok, why = ipo_gate_pass({**base, "ticker": "ARSSBL.NS"}, cfg,
                            expected_days=504, as_of_date=AS_OF)
    assert ok is False and "365" in (why or ""), \
        f"ARSSBL (351d) must be rejected by the 365d floor, got: {ok} {why}"

    # 4. Phantom ticker — not in the NSE security master -> REJECT (fail-closed)
    ok, why = ipo_gate_pass({**base, "ticker": "PHANTOMXYZ.NS"}, cfg,
                            expected_days=504, as_of_date=AS_OF)
    assert ok is False, "phantom ticker must be rejected fail-closed"

    # 5. Too few bars (data sufficiency, unchanged pre-R38 behavior) -> REJECT
    ok, why = ipo_gate_pass({**base, "ticker": "KRN.NS", "bars_count": 50}, cfg,
                            expected_days=504, as_of_date=AS_OF)
    assert ok is False, "< 160 bars must still be rejected (data sufficiency)"

    # 6. The window is config-live: explicit IPO_MAX_CALENDAR_DAYS widens it
    ok, why = ipo_gate_pass({**base, "ticker": "BLSE.NS"},
                            {**cfg, "IPO_MAX_CALENDAR_DAYS": 1000},
                            expected_days=504, as_of_date=AS_OF)
    assert ok is True, "explicit cfg override must be honored by the gate"


def test_ipo_gate_mcap_band_required_fail_closed():
    """R50: the unicorn profile's market-cap band is a HARD contract.

    Locks the REQUIRE_MCAP_BAND fail-closed behavior added in Round 50:
    (a) unmeasurable cap + REQUIRE_MCAP_BAND -> REJECT with a disclosed
    reason (the 2026-10-02 sweep admitted EPACKPEB and a ~₹7,484 Cr KMEW
    through exactly this hole);
    (b) out-of-band measurable cap (the true KMEW value, now registered)
    -> REJECT;
    (c) in-band measurable cap -> PASS;
    (d) the historical permissive-None behavior is preserved for profiles
    that do NOT opt in (no REQUIRE_MCAP_BAND key).
    """
    import datetime as _dt
    from math_engine.ipo_multibagger_math import ipo_gate_pass
    from math_engine.institutional_research_registry import get_ipo_market_cap_cr

    AS_OF = _dt.date(2026, 10, 2)
    cfg = dict(DEFAULT_CFG)
    cfg["PRESCREEN_MODE"] = "ipo_multibagger"
    cfg["REQUIRE_BASE_FORMATION"] = False
    cfg["REQUIRE_MCAP_BAND"] = True

    base = {
        "adv20": 50_000_000.0,
        "pct_below_52w_high": 0.12,
        "bars_count": 350,
    }

    # (a) unmeasurable cap + required band -> fail-closed, disclosed reason
    ok, why = ipo_gate_pass({**base, "ticker": "KRN.NS"}, cfg,   # KRN in-window at AS_OF
                            expected_days=504, as_of_date=AS_OF)
    assert ok is False and "mcap_unmeasurable" in (why or ""), \
        f"unmeasurable cap must be rejected fail-closed for the unicorn profile, got: {ok} {why}"

    # (b) the true KMEW cap (~₹7,484 Cr, registered R50) is out-of-band -> REJECT
    kmew_cap = get_ipo_market_cap_cr("KMEW.NS")
    assert kmew_cap is not None, "R50: KMEW must be registered (true value)"
    ok, why = ipo_gate_pass({**base, "ticker": "KMEW.NS", "market_cap_cr": kmew_cap}, cfg,
                            expected_days=504, as_of_date=AS_OF)
    assert ok is False and "outside_" in (why or ""), \
        f"KMEW at its true ~7,484 Cr cap must be rejected by the 5,000 Cr ceiling, got: {ok} {why}"

    # (c) in-band measurable cap -> PASS
    ok, why = ipo_gate_pass({**base, "ticker": "KRN.NS", "market_cap_cr": 4200.0}, cfg,
                            expected_days=504, as_of_date=AS_OF)
    assert ok is True, f"in-band measurable cap must pass, got: {why}"

    # (d) profiles without the opt-in keep the historical permissive-None contract
    cfg_permissive = {k: v for k, v in cfg.items() if k != "REQUIRE_MCAP_BAND"}
    ok, why = ipo_gate_pass({**base, "ticker": "KRN.NS"}, cfg_permissive,
                            expected_days=504, as_of_date=AS_OF)
    assert ok is True, \
        f"permissive-None mcap behavior must be preserved for non-opt-in profiles, got: {why}"


def test_ipo_profile_in_web_dashboard_html_and_app():
    """Verify UI dropdowns and comparison matrix include 🦄 High-Growth IPO · Multibagger Hunter."""
    html_path = Path("web_dashboard/index.html")
    html_content = html_path.read_text(encoding="utf-8")
    assert 'value="🦄 High-Growth IPO · Multibagger Hunter"' in html_content
    assert "Master Comparison Matrix" in html_content

    app_path = Path("web_dashboard/app.py")
    app_content = app_path.read_text(encoding="utf-8")
    assert '"🦄 High-Growth IPO · Multibagger Hunter"' in app_content
    assert '"🦄 High-Growth IPO · Multibagger Hunter": ["ipo", "high-growth"' in app_content


def test_ipo_profile_holdings_and_pricing_integrity():
    """R38: the 🦄 book is STRICTLY 1-2 year listed equities (the USER CONTRACT).

    SUPERSEDES the pre-R38 BLSE-presence asserts: BLSE listed 2024-02-06 is
    ~953 calendar days old at the 2026-09-16 master state — 2.6 years, OUTSIDE
    the 1-2 year window the user explicitly asked for, so it must NOT appear.
    Every shipped 🦄 holding/universe name is now DSM-verified in-window, with
    authentic prices (no ₹100.00 dummies) and in-band market caps.

    R50 DISCLOSURE (by-design data lock, R40 doctrine): the 2026-10-02 sweep
    admitted KMEW.NS (Knowledge Marine & Engineering Works, listed
    14-NOV-2024, in-window) through the then-permissive unmeasurable-cap
    gate at a TRUE cap of ~₹7,484 Cr — far outside the profile's
    ₹500-5,000 Cr sweet spot. R50 registered KMEW at its true value and made
    the unicorn gate fail-closed (REQUIRE_MCAP_BAND), so the NEXT sweep
    cannot admit it; the shipped combined_portfolio.csv is a data artifact
    that cannot be regenerated offline (live NSE/Yahoo sweep). Until the
    operator re-runs the sweep, the in-band assertion below fails on KMEW
    BY DESIGN — the failure message names the exact ticker and true cap,
    which is the point: the lock must not lie. Everything else in this test
    (window, prices, sectors, caps for the other 11 holdings) is green.
    """
    from data.dynamic_security_master import DynamicSecurityMaster
    from tests.test_round40_regressions import _load_prov, _prov_vintage

    # R40 SUPERSESSION: the vintage now comes from the sweep provenance (the
    # R38 form hardcoded 2026-09-16 — a freeze that forbade fresh data).
    _prov = _load_prov()
    assert _prov is not None, "R40: requires sweep provenance (see r40_1)"
    AS_OF = _prov_vintage(_prov)
    dsm = DynamicSecurityMaster.get_instance()

    comb_port = Path("combined_portfolio.csv")
    assert comb_port.exists()
    df = pd.read_csv(comb_port)
    ipo_rows = df[df["Profile"].str.contains("IPO", na=False)]
    tickers = ipo_rows["Ticker"].tolist()

    # 1. THE CONTRACT: every 🦄 holding is DSM-active and strictly 365-730d listed
    assert tickers, "the 🦄 allocation must not be empty"
    for t in tickers:
        assert dsm.is_recent_ipo(t.replace(".NS", ""), min_days=365, max_days=730,
                                 as_of_date=AS_OF), \
            f"Holding {t} is NOT a 1-2 year listed equity (the user contract)"

    # 2. Out-of-window names are gone — the PERMANENTLY MATURE legacy names
    #    (all 737d+ at the 2026-09-16 master state: they only age further out,
    #    so they can never legitimately re-enter the window), plus the
    #    pre-IPO-era BLS.NS. (R40: ARSSBL.NS — 351d on Sep 16 — was listed
    #    here by R38, but it AGES INTO the window on 2026-09-30; the generic
    #    vintage-aware check above governs it now. Likewise the R38
    #    'DAMCAPITAL/MANBA must ship' pins are DROPPED — the sweep's own
    #    selections must be free to change with fresh data; freezing them
    #    is what incentivised the 2026-09-17 stale-artifact paste.)
    for gone in ("BLS.NS", "BLSE.NS", "GALAPREC.NS", "EMSLIMITED.NS",
                 "IDEAFORGE.NS", "AVANTEL.NS", "AWFIS.NS", "EPACK.NS"):
        assert gone not in tickers, f"{gone} is outside the 1-2y window and must NOT be held"

    # 3. Universe CSV carries the same contract
    comb_univ = Path("combined_universe.csv")
    if comb_univ.exists():
        df_u = pd.read_csv(comb_univ)
        ipo_u = df_u[df_u["Profile"].str.contains("IPO", na=False)]
        u_tickers = ipo_u["Ticker"].tolist()
        assert u_tickers, "the 🦄 universe must not be empty"
        for t in u_tickers:
            assert dsm.is_recent_ipo(t.replace(".NS", ""), min_days=365, max_days=730,
                                     as_of_date=AS_OF), \
                f"Universe name {t} is NOT a 1-2 year listed equity (the user contract)"

    # 4. Prices and fundamentals are authentic for every holding
    from web_dashboard.app import DynamicPriceResolver
    from math_engine.institutional_research_registry import InstitutionalResearchRegistry, get_ipo_market_cap_cr
    for t in tickers:
        px = DynamicPriceResolver.get(t)
        prof = InstitutionalResearchRegistry.get_stock_profile(t)
        assert px > 0 and px != 100.0, f"Dummy 100.0 price found for {t}: {px}"
        sec = (prof.get("sector") if prof else None) or "Technology"
        assert sec != "Equities", f"Generic 'Equities' sector found for {t}: {sec}"
        # Verify market cap is strictly in ₹500 Cr – ₹5,000 Cr sweet spot
        mcap = get_ipo_market_cap_cr(t)
        assert mcap is not None, f"Market cap missing for {t}"
        assert 500.0 <= mcap <= 5000.0, f"Holding {t} has market cap ₹{mcap} Cr outside [500, 5000] Cr!"


def test_ipo_profile_market_cap_and_base_formation_gates():
    """Verify IPO profile enforces ₹500 Cr - ₹5,000 Cr market cap, Base Formation, and Frontier ML."""
    profile_name = "🦄 High-Growth IPO · Multibagger Hunter"
    cfg = PROFILE_MAP[profile_name]

    # 1. Market Cap bounds
    assert cfg.get("MIN_MARKET_CAP_CR") == 500.0
    assert cfg.get("MAX_MARKET_CAP_CR") == 5000.0

    # 2. Base formation requirements
    assert cfg.get("REQUIRE_BASE_FORMATION") is True
    assert cfg.get("MAX_BASE_TIGHTNESS_PCT") <= 14.5
    assert cfg.get("MAX_PIVOT_DISTANCE_PCT") <= 15.0

    # 3. Frontier SOTA ML stack
    assert cfg.get("USE_PATCH_TST_ALPHA") is True
    assert cfg.get("USE_NEURAL_SDE") is True
    assert cfg.get("USE_CONFORMAL_BOUNDS") is True
    assert cfg.get("USE_VISION_CHART_AUDITOR") is True

    # 4. Factor weights
    fw = cfg.get("FACTOR_WEIGHTS", {})
    assert "z_base_tightness" in fw
    assert "z_neural_sde" in fw
    assert "z_patch_tst" in fw


def test_market_cap_and_base_tightness_filtering_logic():
    """Verify that prescreen filters out large caps (> 5,000 Cr), micro-pennies (< 500 Cr), and loose bases (> 14.5%)."""
    cfg = {
        "PRESCREEN_MODE": "ipo_multibagger",
        "MIN_MARKET_CAP_CR": 500.0,
        "MAX_MARKET_CAP_CR": 5000.0,
        "REQUIRE_BASE_FORMATION": True,
        "MAX_BASE_TIGHTNESS_PCT": 14.5,
        "MAX_PIVOT_DISTANCE_PCT": 15.0,
    }

    # Candidate A: Authentic Small-Cap IPO with tight base (PASS)
    # (R38: DAMCAPITAL — a genuinely in-window 1-2y listed name, 628d at the
    #  2026-09-16 master state; registry market cap ₹1,006.8 Cr.)
    cand_a = {"ticker": "DAMCAPITAL.NS", "market_cap_cr": 1006.8, "base_tightness_pct": 9.1, "pivot_dist_pct": 4.8}
    # Candidate B: Large-Cap that already became multibagger (REJECT: MCap > 5000 Cr)
    cand_b = {"ticker": "TATATECH.NS", "market_cap_cr": 31200.0, "base_tightness_pct": 7.3, "pivot_dist_pct": 5.0}
    # Candidate C: Mega-Cap that already expanded (REJECT: MCap > 5000 Cr)
    cand_c = {"ticker": "JIOFIN.NS", "market_cap_cr": 149800.0, "base_tightness_pct": 8.5, "pivot_dist_pct": 6.2}
    # Candidate D: Micro-penny illiquid asset (REJECT: MCap < 500 Cr)
    cand_d = {"ticker": "PENNY_IPO.NS", "market_cap_cr": 320.0, "base_tightness_pct": 8.0, "pivot_dist_pct": 3.0}
    # Candidate E: Small-Cap but NO base formation (REJECT: Base Tightness > 14.5%)
    cand_e = {"ticker": "WILD_SWING.NS", "market_cap_cr": 1800.0, "base_tightness_pct": 26.5, "pivot_dist_pct": 18.0}

    def _passes_quant_gates(c):
        mcap = c.get("market_cap_cr")
        if mcap is not None:
            if mcap < cfg["MIN_MARKET_CAP_CR"] or mcap > cfg["MAX_MARKET_CAP_CR"]:
                return False
        if cfg["REQUIRE_BASE_FORMATION"]:
            bt = c.get("base_tightness_pct")
            if bt is not None and bt > cfg["MAX_BASE_TIGHTNESS_PCT"]:
                return False
            pd_pct = c.get("pivot_dist_pct", 0.0)
            if pd_pct > cfg["MAX_PIVOT_DISTANCE_PCT"]:
                return False
        return True

    assert _passes_quant_gates(cand_a) is True, "Valid base-forming small cap must pass"
    assert _passes_quant_gates(cand_b) is False, "Large-cap (>5,000 Cr) must be rejected"
    assert _passes_quant_gates(cand_c) is False, "Mega-cap (>5,000 Cr) must be rejected"
    assert _passes_quant_gates(cand_d) is False, "Micro-penny (<500 Cr) must be rejected"
    assert _passes_quant_gates(cand_e) is False, "Loose base (>14.5%) must be rejected"


def test_vision_chart_auditor_base_formation_geometry():
    """Verify VisionChartAuditor extracts exact base metrics and Keltner squeeze."""
    from math_engine.vision_chart_auditor import VisionChartAuditor

    # Generate coiled synthetic OHLCV with tight 8% consolidation
    np.random.seed(42)
    base_px = 300.0
    dates = pd.date_range("2024-01-01", periods=60, freq="B")
    noise = np.random.uniform(-3.0, 3.0, size=60)
    close_series = base_px + noise
    ohlcv = pd.DataFrame({
        "Open": close_series - np.random.uniform(0, 1, size=60),
        "High": close_series + np.random.uniform(0.5, 2.0, size=60),
        "Low": close_series - np.random.uniform(0.5, 2.0, size=60),
        "Close": close_series,
        "Volume": np.random.uniform(50000, 150000, size=60),
    }, index=dates)

    res = VisionChartAuditor.audit_chart_geometry(ohlcv)
    assert "base_tightness_pct" in res
    assert res["base_tightness_pct"] < 14.5, f"Expected tight base, got {res['base_tightness_pct']}%"
    assert res["is_base_forming"] is True
    assert res["pivot_price"] >= res["accumulation_floor"]
    assert res["ibfi_score"] > 50.0

