"""
tests/test_log_fixes.py
======================
Unit tests for the 8 log fixes:
1. WFO backtest safe NUM_READS handling (no KeyError)
2. GEX NIFTY spot price loading from benchmark
3. QPU clean fallback without warning traceback
4. SAST empty dictionary cache recognition
5. Bulk deals _bootstrap_attempted flag and multi-profile cache merge
6. Fundamentals SQLite PiT DB auto-initialization and seeding
7. Safe DSR formatting in QuantPipeline
"""

import os
import json
import pytest
import sqlite3
import numpy as np
import pandas as pd
from pathlib import Path


def test_fundamentals_pit_db_seeded_and_queried(tmp_path, monkeypatch):
    """R35 correction: this test asserted the PRE-R34-6 behaviour ("table
    should be seeded" > 0 rows on ANY seat) — which only passed by machine
    state pollution (a runtime DB pre-seeded by earlier runs). Per the R34-6
    doctrine a CLEAN seat must be honestly EMPTY; only the real scrape cache
    (fundamentals_cache.json produced by the live fetch path) seeds the PiT
    DB. The clean-seat and cache-path branches are both proven here,
    hermetically, via a monkeypatched RUNTIME_DIR (same pattern as
    tests/test_round33_ml_hygiene.py::test_fundamentals_pit_db_hermetic_clean_seat).
    """
    import sqlite3
    import data_layer
    from data_layer import _ensure_pit_db, fetch_fundamentals

    empty_runtime = tmp_path / "runtime"
    empty_runtime.mkdir()
    monkeypatch.setattr(data_layer, "RUNTIME_DIR", empty_runtime)

    # ── Branch 1: clean seat → honestly EMPTY (R34-6: never invent) ──
    db_path = empty_runtime / "fundamentals_history.db"
    assert _ensure_pit_db(db_path) is True
    assert db_path.exists()
    conn = sqlite3.connect(str(db_path))
    count = conn.execute("SELECT COUNT(*) FROM fundamentals").fetchone()[0]
    conn.close()
    assert count == 0, (
        "clean seat must seed NOTHING (R34-6: fabricated fundamentals removed; "
        f"found {count} rows)"
    )

    # ── Branch 2: real cache present → the DB seeds from the cache ──
    cache = {
        "RELIANCE.NS": {"roe": 11.2, "de_ratio": 36.6, "rev_growth": 29.7, "pe_ratio": 22.8},
        "TCS.NS": {"roe": 47.7, "de_ratio": 8.1, "rev_growth": 12.4, "pe_ratio": 16.0},
    }
    (empty_runtime / "fundamentals_cache.json").write_text(json.dumps(cache))
    assert _ensure_pit_db(db_path) is True
    conn = sqlite3.connect(str(db_path))
    seeded = conn.execute("SELECT COUNT(*) FROM fundamentals").fetchone()[0]
    rows = conn.execute("SELECT ticker, roe, pe_ratio FROM fundamentals").fetchall()
    conn.close()
    assert seeded == 2, f"cache path must seed 2 tickers, found {seeded}"
    by_tkr = {r[0]: r for r in rows}
    assert "RELIANCE" in by_tkr and "TCS" in by_tkr
    assert abs(by_tkr["RELIANCE"][1] - 11.2) < 1e-9
    assert abs(by_tkr["TCS"][2] - 16.0) < 1e-9

    # ── Branch 3: fetch_fundamentals reads the seeded PiT DB ──
    res = fetch_fundamentals(["RELIANCE.NS", "TCS.NS"])
    assert "RELIANCE.NS" in res and "TCS.NS" in res
    assert "roe" in res["RELIANCE.NS"]
    assert "pe_ratio" in res["RELIANCE.NS"]
    assert "de_ratio" in res["TCS.NS"]


def test_benchmark_last_price_getter():
    import data_layer
    # When initialized with a price
    data_layer._LAST_BENCHMARK_PRICE = 24850.5
    price = data_layer.get_benchmark_last_price()
    assert price == 24850.5


def test_bulk_deal_bootstrap_gating():
    from datetime import datetime

    today_str = datetime.now().strftime("%Y-%m-%d")
    raw_hist = {"_bootstrap_attempted": today_str}
    valid_days = sum(1 for k in raw_hist.keys() if not str(k).startswith("_"))
    assert valid_days == 0
    assert raw_hist.get("_bootstrap_attempted") == today_str
    # Should not re-bootstrap when attempted today
    attempt_needed = (valid_days < 5 and raw_hist.get("_bootstrap_attempted") != today_str)
    assert attempt_needed is False


def test_qpu_clean_sampler_without_token():
    from utils import _get_quantum_sampler
    # Temporarily remove DWAVE_API_TOKEN if set
    old_token = os.environ.pop("DWAVE_API_TOKEN", None)
    try:
        sampler, label = _get_quantum_sampler(qpu_native=False)
        assert sampler is not None
        assert "SimulatedAnnealing" in type(sampler).__name__ or "Simulated" in label
    finally:
        if old_token is not None:
            os.environ["DWAVE_API_TOKEN"] = old_token


def test_wfo_backtest_cfg_reads_protection():
    # Verify cfg.get('NUM_READS', 400) does not raise KeyError
    cfg = {}
    _reads = int(cfg.get("NUM_READS", 400))
    _sweeps = int(cfg.get("NUM_SWEEPS", 500))
    assert _reads == 400
    assert _sweeps == 500


def test_dsr_formatting_logic():
    # Case 1: NaN DSR, No inst DSR
    _dsr_res = {"dsr": float("nan")}
    _inst_dsr = {}
    _dsr_val = _dsr_res.get('dsr', float('nan'))
    if np.isfinite(_dsr_val):
        disp = f"{_dsr_val:.1%}"
    elif _inst_dsr.get('deflated_sharpe') is not None and np.isfinite(_inst_dsr.get('deflated_sharpe')):
        disp = f"{_inst_dsr['deflated_sharpe']:.2f} (Inst)"
    else:
        disp = "N/A"
    assert disp == "N/A"

    # Case 2: NaN DSR, finite inst DSR
    _inst_dsr = {"deflated_sharpe": 0.6341}
    _dsr_val = _dsr_res.get('dsr', float('nan'))
    if np.isfinite(_dsr_val):
        disp = f"{_dsr_val:.1%}"
    elif _inst_dsr.get('deflated_sharpe') is not None and np.isfinite(_inst_dsr.get('deflated_sharpe')):
        disp = f"{_inst_dsr['deflated_sharpe']:.2f} (Inst)"
    else:
        disp = "N/A"
    assert disp == "0.63 (Inst)"

    # Case 3: Valid DSR
    _dsr_res = {"dsr": 0.852}
    _dsr_val = _dsr_res.get('dsr', float('nan'))
    if np.isfinite(_dsr_val):
        disp = f"{_dsr_val:.1%}"
    elif _inst_dsr.get('deflated_sharpe') is not None and np.isfinite(_inst_dsr.get('deflated_sharpe')):
        disp = f"{_inst_dsr['deflated_sharpe']:.2f} (Inst)"
    else:
        disp = "N/A"
    assert disp == "85.2%"


def test_wfo_sparse_cfg_and_oos_sharpe():
    from optimizer import run_wfo_backtest
    from utils import compute_oos_validation

    dates = pd.bdate_range('2024-01-01', periods=200)
    tickers = ['RELIANCE.NS', 'TCS.NS', 'INFY.NS', 'HDFCBANK.NS']
    np.random.seed(42)
    rets_raw = np.random.normal(0.0005, 0.015, (200, len(tickers)))
    prices = pd.DataFrame(100 * np.cumprod(1 + rets_raw, axis=0), index=dates, columns=tickers)
    volumes = pd.DataFrame(np.random.randint(100000, 1000000, (200, len(tickers))), index=dates, columns=tickers)
    returns = np.log(prices / prices.shift(1)).dropna()
    bench = returns.mean(axis=1)

    data = {'Close': prices, 'Volume': volumes}
    sectors = {t: 'Tech' if 'T' in t or 'IN' in t else 'Finance' for t in tickers}
    # Sparse cfg deliberately omitting CORR_SHRINKAGE, RISK_MODEL, etc.
    sparse_cfg = {
        'BACKTEST_REBALANCE_DAYS': 21,
        'WFO_WINDOWS': 2,
        'NUM_READS': 100,
        'NUM_SWEEPS': 100,
        'K_STOCKS': 2,
        'K_MIN_STOCKS': 1,
        'SEED': 42,
        'MULTI_STARTS': 1,
        'USE_HRP': False,
        'USE_CHART_IMAGE_SSL': False,
        'USE_FUNDAMENTALS': False,
    }

    res = run_wfo_backtest(data, returns, bench, sectors, sparse_cfg, log_cb=None, progress_cb=None)
    assert res is not None
    assert "Sharpe" in res
    assert np.isfinite(res["Sharpe"])
    assert "Rebalances" in res
    assert res["Rebalances"] >= 1


def test_oos_validation_verdict_casing_and_tag():
    # Verify both capital 'Verdict' and lowercase 'verdict' trigger the disclaimer tag
    payload = {}
    _oos_res = {"Verdict": "Underpowered", "OOS Steps": 2}
    if isinstance(_oos_res, dict) and (_oos_res.get("Verdict") == "Underpowered" or _oos_res.get("verdict") == "Underpowered"):
        payload["oos_validation_tag"] = "[⚠️ LOW SAMPLE WFO: <15 STEPS]"
    assert payload.get("oos_validation_tag") == "[⚠️ LOW SAMPLE WFO: <15 STEPS]"


def test_sector_metadata_clean_success_log():
    # Verify when _sec_fail_count is 0, no failure warning is emitted
    logs = []
    def log_cb(msg): logs.append(msg)

    tickers = ["RELIANCE.NS", "TCS.NS"]
    missing = ["TCS.NS"]
    _sec_fail_count = 0
    resolved = 2
    cache_msg = " (1 cached)"

    if missing and _sec_fail_count > 0:
        _fail_pct = (_sec_fail_count / max(len(missing), 1)) * 100.0
        log_cb(f"Sector metadata fetched: {len(tickers)} tickers, {resolved} resolved{cache_msg}. "
               f"{_sec_fail_count} tickers failed lookup ({_fail_pct:.1f}% of missing) — NOT cached, will be retried next run.")
    else:
        log_cb(f"Sector metadata fetched: {len(tickers)} tickers, {resolved} resolved{cache_msg}")

    assert len(logs) == 1
    assert "failed lookup" not in logs[0]
    assert "Sector metadata fetched: 2 tickers, 2 resolved (1 cached)" == logs[0]


def test_factor_orthogonalizer_no_empty_slice_warning():
    import warnings
    from math_engine.factor_orthogonalizer import FactorOrthogonalizer

    # Matrix with an all-NaN column or zeros
    mat = np.array([
        [1.0, np.nan, 3.0],
        [2.0, np.nan, 4.0],
        [1.5, np.nan, 3.5],
    ])
    with warnings.catch_warnings():
        warnings.simplefilter("error")
        ortho = FactorOrthogonalizer.orthogonalize_factors(mat)
    assert ortho.shape == mat.shape
    assert np.all(np.isfinite(ortho))


