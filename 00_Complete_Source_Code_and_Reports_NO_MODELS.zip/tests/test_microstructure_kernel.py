"""tests/test_microstructure_kernel.py
======================================
Unit tests for High-Performance Microstructure & OFI Stream Kernel.
"""
import sys, os, unittest, time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from math_engine.microstructure_kernel import (
    FastHawkesIntensityEngine,
    OrderFlowImbalanceStreamer,
    StreamingVPINAccumulator,
)


class TestMicrostructureKernel(unittest.TestCase):

    def test_fast_hawkes_intensity_and_burst(self):
        engine = FastHawkesIntensityEngine(mu=0.5, alpha=0.9, beta=1.0)
        base_intensity = engine.compute_intensity()
        self.assertEqual(base_intensity, 0.5)

        # Push rapid burst of 10 events
        now = time.time()
        for i in range(10):
            engine.push_event(now + i * 0.05)

        burst_intensity = engine.compute_intensity(now + 0.6)
        self.assertGreater(burst_intensity, base_intensity * 2.0)
        self.assertTrue(engine.is_micro_burst(threshold_multiplier=2.0))

    def test_order_flow_imbalance_streamer(self):
        streamer = OrderFlowImbalanceStreamer()
        # Initial level: Bid 100 @ 10, Ask 101 @ 10
        ofi0 = streamer.update_depth(100.0, 10, 101.0, 10)
        self.assertEqual(ofi0, 0.0)

        # Buyer adds 20 shares at same bid price: Bid 100 @ 30, Ask 101 @ 10
        ofi1 = streamer.update_depth(100.0, 30, 101.0, 10)
        self.assertEqual(ofi1, 20.0)
        self.assertEqual(streamer.cumulative_ofi, 20.0)

        # Seller steps down ask price: Bid 100 @ 30, Ask 100.5 @ 15
        ofi2 = streamer.update_depth(100.0, 30, 100.5, 15)
        self.assertEqual(ofi2, -15.0)
        self.assertEqual(streamer.cumulative_ofi, 5.0)

    def test_streaming_vpin_accumulator(self):
        vpin_engine = StreamingVPINAccumulator(bucket_size_volume=1000.0, num_buckets=10)
        # Add 5 buy-dominated trades
        for _ in range(5):
            vpin_engine.add_trade(price=101.0, volume=300.0, prev_price=100.0)
        
        vpin = vpin_engine.compute_vpin()
        self.assertGreaterEqual(vpin, 0.0)
        self.assertLessEqual(vpin, 1.0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
