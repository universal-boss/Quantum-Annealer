"""tests/test_nlp_alternative_data.py
=====================================
Unit tests for Alternative Data & Live Concall NLP Sentiment Ingestion.
"""
import sys, os, unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from math_engine.nlp_alternative_data import (
    CorporateFilingNLPAnalyzer,
    PromoterPledgeTracker,
    ConcallTranscriptSentimentEngine,
)


class TestNLPAlternativeData(unittest.TestCase):

    def test_filing_catalyst_classification_bullish(self):
        headline = "Company receives major order win worth INR 2,500 Crores for greenfield plant capacity expansion"
        res = CorporateFilingNLPAnalyzer.analyze_filing(headline)
        self.assertTrue(res["is_material"])
        self.assertIn("ORDER_WIN", res["catalysts"])
        self.assertIn("CAPEX_EXPANSION", res["catalysts"])
        self.assertGreater(res["sentiment_score"], 0.0)

    def test_filing_catalyst_classification_bearish(self):
        headline = "USFDA issues Form 483 with 5 inspection observations at manufacturing facility"
        res = CorporateFilingNLPAnalyzer.analyze_filing(headline)
        self.assertTrue(res["is_material"])
        self.assertIn("USFDA_WARNING", res["catalysts"])
        self.assertLess(res["sentiment_score"], 0.0)

    def test_promoter_pledge_risk_evaluation(self):
        safe_res = PromoterPledgeTracker.evaluate_pledge_risk("TCS", 72.0, 0.0)
        self.assertEqual(safe_res["risk_level"], "LOW")
        self.assertTrue(safe_res["safe_for_accumulation"])

        danger_res = PromoterPledgeTracker.evaluate_pledge_risk("STRESSED_CORP", 55.0, 65.0)
        self.assertEqual(danger_res["risk_level"], "HIGH")
        self.assertFalse(danger_res["safe_for_accumulation"])
        self.assertEqual(danger_res["risk_penalty"], -0.35)

    def test_concall_transcript_views_extraction(self):
        sample_transcripts = {
            "RELIANCE": "Management is confident of achieving double digit growth with strong demand tailwinds and margin expansion expected.",
            "INFY": "Client deferrals and demand slowdown are causing pricing pressure and margin compression in key verticals."
        }
        res = ConcallTranscriptSentimentEngine.extract_concall_views(sample_transcripts)
        self.assertIn("RELIANCE", res["per_ticker_views"])
        self.assertIn("INFY", res["per_ticker_views"])
        self.assertGreater(res["per_ticker_views"]["RELIANCE"]["sentiment_score"], 0.0)
        self.assertLess(res["per_ticker_views"]["INFY"]["sentiment_score"], 0.0)
        self.assertEqual(len(res["Q_vector"]), 2)


if __name__ == "__main__":
    unittest.main(verbosity=2)
