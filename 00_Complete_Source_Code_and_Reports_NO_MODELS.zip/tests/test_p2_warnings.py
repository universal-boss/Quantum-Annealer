"""
tests/test_p2_warnings.py
=========================
Audit test coverage for the 4 P2 polish items + Round 7 additions.

P2-1 — expanded_ensemble OOF fallback emits a leak warning when the
       in-sample (leaky) path is taken.
P2-2 — _calc_bollinger uses ddof=1 (sample std), matching TA-Lib /
       QuantConnect / pandas-ta conventions.
P2-3 — evaluate_options_skew_warning uses a real SVI surface fit and
       never unconditionally returns False; with no chain, returns
       False cleanly (non-blocking).
P2-4 — data_layer is fully importable without yfinance installed;
       yfinance is lazy-loaded via _get_yf().
P2-5 — covered in tests/test_p2_audit_fixes.py (marker tests for
       swallowed-exception logging); this file does not re-test P2-5.

Round 7 additions (functional smoke tests):
A3 — Robust Black-Litterman with ellipsoidal uncertainty.
A4 — HAR-RV (Corsi 2009) with Yang-Zhang (2000) RV proxy.
"""
from __future__ import annotations

import importlib
import importlib.util
import logging
import os
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

# ---------------------------------------------------------------------------
# Make qa_work importable as the project root (so `from data_layer import ...`
# works the same way it does in production).
# ---------------------------------------------------------------------------
_THIS_DIR = Path(__file__).resolve().parent
_QA_WORK = _THIS_DIR.parent
if str(_QA_WORK) not in sys.path:
    sys.path.insert(0, str(_QA_WORK))


# ============================================================================
# P2-1: expanded_ensemble OOF fallback emits a leak warning
# ============================================================================

class TestP21ExpandedEnsembleLeakWarning:
    """The in-sample fallback must emit an explicit LEAK warning so the
    downstream stack knows to discount any R²/Sharpe by ~0.05-0.15.

    Rather than mock sklearn (brittle), we audit the SOURCE for the
    leak-warning marker text and the lookahead-safe OOF machinery
    (cross_val_predict / TimeSeriesSplit / LeaveOneOut imports)."""

    def test_source_has_leak_warning_marker(self):
        """Source-level: the in-sample fallback path must contain an
        ERROR-level log message with the literal marker 'LEAKS FUTURE DATA'
        so downstream consumers can grep for it."""
        src_path = _QA_WORK / "ml_alpha" / "expanded_ensemble.py"
        src = src_path.read_text()
        # Look for the explicit leak warning marker
        assert "LEAKS FUTURE DATA" in src, (
            "expanded_ensemble.py must contain the literal marker 'LEAKS FUTURE DATA' "
            "in the in-sample fallback log message"
        )
        # The marker must be at logger.error or logger.critical level
        # (not logger.debug or warning)
        import re
        # Find the LEAK marker line and check the level
        marker_pattern = re.compile(
            r"logger\.(error|critical)\([^)]*LEAKS FUTURE DATA",
            re.DOTALL,
        )
        assert marker_pattern.search(src), (
            "The 'LEAKS FUTURE DATA' marker must be emitted via logger.error() "
            "or logger.critical(), not logger.warning() or logger.debug()."
        )

    def test_source_imports_cross_val_predict(self):
        """Source-level: cross_val_predict must be imported (with
        TimeSeriesSplit and LeaveOneOut fallbacks) so the lookahead-safe
        OOF path is actually available."""
        src = (_QA_WORK / "ml_alpha" / "expanded_ensemble.py").read_text()
        assert "cross_val_predict" in src, (
            "expanded_ensemble.py must import cross_val_predict from sklearn"
        )
        assert "TimeSeriesSplit" in src, (
            "expanded_ensemble.py must use TimeSeriesSplit (lookahead-safe CV)"
        )
        assert "LeaveOneOut" in src, (
            "expanded_ensemble.py must fall back to LeaveOneOut for tiny n"
        )

    def test_small_n_warning_path_exists(self):
        """Source-level: when n < n_splits*5, a warning mentioning
        LeaveOneOut must be emitted."""
        src = (_QA_WORK / "ml_alpha" / "expanded_ensemble.py").read_text()
        # The small-n path must reference both n < n_splits*5 AND LeaveOneOut
        assert "n_splits * 5" in src or "n_splits*5" in src, (
            "expanded_ensemble.py must have a small-n check (n < n_splits*5)"
        )
        # And the warning must reference LeaveOneOut
        assert "LeaveOneOut" in src


# ============================================================================
# P2-2: _calc_bollinger uses ddof=1 (sample std)
# ============================================================================

class TestP22BollingerDdof1:
    """`_calc_bollinger` must use ddof=1 (sample std), matching TA-Lib /
    pandas-ta / QuantConnect conventions.  Industry standard is sample
    std, not population std."""

    @staticmethod
    def _load_indicators():
        spec = importlib.util.spec_from_file_location(
            "indicators_under_test",
            str(_QA_WORK / "math_engine" / "indicators.py"),
        )
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        return m

    def test_bollinger_uses_ddof_1(self):
        """The std computation in `_calc_bollinger` must use ddof=1."""
        mod = self._load_indicators()
        # Verify the source code contains ddof=1 (audit-level check)
        src_path = _QA_WORK / "math_engine" / "indicators.py"
        src = src_path.read_text()
        # Find the _calc_bollinger function body and check ddof=1 is present
        # in the std computation line (NOT ddof=0).
        # Split by function definition so we don't get false positives from
        # other functions that might also use np.std.
        import re
        m = re.search(
            r"def _calc_bollinger[^\n]*\n((?:    [^\n]*\n)+)",
            src,
        )
        assert m, "_calc_bollinger not found in indicators.py"
        func_body = m.group(1)
        # The std line should use ddof=1
        assert "ddof=1" in func_body, (
            "_calc_bollinger must use np.std(..., ddof=1) for sample std. "
            "Function body was: " + func_body
        )

    def test_bollinger_value_matches_sample_std(self):
        """Functional: the band width must equal 2 * sample std (ddof=1)
        of the close-price window, not 2 * population std (ddof=0).

        AUDIT-FIX (Round 5, 2-g-1): the 3-tuple branch was nested INSIDE the
        `hasattr(result, 'iloc')` branch (unreachable — tuples have no .iloc)
        and the 6-tuple signature actually used by the panels
        (`ub, sma, lb, pct_b, bw, std = _calc_bollinger(...)`, see
        ui/technical_panels.py) fell through to a trivially-true
        `assert result is not None`. Handle every return shape explicitly
        and fail on unhandled signatures instead of silently passing."""
        mod = self._load_indicators()
        if not hasattr(mod, "_calc_bollinger"):
            pytest.skip("_calc_bollinger not present in indicators module")
        rng = np.random.default_rng(11)
        close = pd.Series(100.0 * np.exp(np.cumsum(rng.standard_normal(50) * 0.01)))
        period = 20
        try:
            result = mod._calc_bollinger(close, period=period)
        except Exception as e:
            pytest.skip(f"_calc_bollinger signature changed: {e}")

        def last(x):
            return float(x.iloc[-1]) if hasattr(x, "iloc") else float(x[-1])

        def assert_band(upper_v, mid_v):
            window = close.iloc[-period:].values
            expected_std = float(np.std(window, ddof=1))
            band = upper_v - mid_v
            assert abs(band - 2 * expected_std) < 1e-6, (
                f"Bollinger band width {band:.6f} != 2 * sample_std (ddof=1) "
                f"{2 * expected_std:.6f}"
            )

        if isinstance(result, pd.DataFrame) and {"upper", "lower", "mid"}.issubset(result.columns):
            assert_band(last(result["upper"]), last(result["mid"]))
        elif isinstance(result, tuple) and len(result) == 3:
            # (upper, mid, lower) form
            upper, mid, lower = result
            assert_band(last(upper), last(mid))
        elif isinstance(result, tuple) and len(result) == 6:
            # (upper, mid, lower, pct_b, bandwidth, std) form — the signature
            # ui/technical_panels.py actually consumes.
            ub, sma, lb, pct_b, bw, std = result
            assert_band(last(ub) if hasattr(ub, "iloc") or isinstance(ub, (list, tuple, np.ndarray)) else float(ub),
                        last(sma) if hasattr(sma, "iloc") or isinstance(sma, (list, tuple, np.ndarray)) else float(sma))
        elif hasattr(result, "iloc"):
            # Single Series form: cannot assert band width without a mid —
            # at minimum confirm finite values.
            assert np.isfinite(np.asarray(result.values, dtype=float)).all()
        else:
            pytest.fail(
                f"unhandled _calc_bollinger return signature: {type(result)} — "
                "extend this test for the new shape instead of passing vacuously"
            )

    def test_ddof_1_differs_from_ddof_0(self):
        """Sanity: ddof=1 std must be strictly larger than ddof=0 std for
        any non-degenerate window — confirms the bias is non-trivial."""
        rng = np.random.default_rng(11)
        window = rng.standard_normal(20) * 0.01
        std_ddof0 = float(np.std(window, ddof=0))
        std_ddof1 = float(np.std(window, ddof=1))
        assert std_ddof1 > std_ddof0, (
            f"ddof=1 std ({std_ddof1:.6e}) must be > ddof=0 std ({std_ddof0:.6e})"
        )


# ============================================================================
# P2-3: evaluate_options_skew_warning uses real SVI fit (no `return False` stub)
# ============================================================================

class TestP23OptionsSkewWarning:
    """`evaluate_options_skew_warning` must call the real SVI surface
    fit (Gatheral-Jacquier 2012); it must not unconditionally return
    False, and with no chain must return False cleanly (non-blocking)."""

    @staticmethod
    def _load_compliance():
        # optimizer_compliance.py imports data_layer; load directly to avoid
        # pulling the full chain
        spec = importlib.util.spec_from_file_location(
            "optimizer_compliance_under_test",
            str(_QA_WORK / "optimizer_compliance.py"),
        )
        m = importlib.util.module_from_spec(spec)
        try:
            spec.loader.exec_module(m)
        except Exception:
            pytest.skip("optimizer_compliance has unmet runtime deps")
        return m

    def test_no_bare_return_false_stub(self):
        """Source-level: the function must not contain a 2-line
        `return False` stub.  It should call build_surface_from_chain
        and detect_skew_anomaly."""
        src = (_QA_WORK / "optimizer_compliance.py").read_text()
        # Match from `def evaluate_options_skew_warning` to the next `def `
        # at the SAME indentation level (module-level).  This handles
        # multi-line docstrings + blank lines inside the function body.
        import re
        m = re.search(
            r"def evaluate_options_skew_warning\([^)]*\)[^:]*:(.*?)\n(?=def |class |\Z)",
            src,
            re.DOTALL,
        )
        assert m, "evaluate_options_skew_warning not found in source"
        body = m.group(1)
        assert "build_surface_from_chain" in body, (
            "evaluate_options_skew_warning must call build_surface_from_chain "
            "(real SVI surface fit)."
        )
        assert "detect_skew_anomaly" in body, (
            "evaluate_options_skew_warning must call detect_skew_anomaly."
        )
        # Source must NOT have a 2-line stub like `def ... :\n    return False`
        bare_stub_pattern = re.compile(
            r"def evaluate_options_skew_warning\([^)]*\)[^:]*:\s*\n\s*return False\s*\n",
        )
        assert not bare_stub_pattern.search(src), (
            "evaluate_options_skew_warning must NOT be a 2-line 'return False' stub."
        )

    def test_returns_false_cleanly_with_no_chain(self):
        """With no option_chain supplied and the NSE fetch also failing,
        the function must return False cleanly (non-blocking)."""
        mod = self._load_compliance()
        fn = getattr(mod, "evaluate_options_skew_warning", None)
        if fn is None:
            pytest.skip("evaluate_options_skew_warning not importable")
        # Call with no chain — should not raise and should return False
        try:
            result = fn(ticker="NIFTY", option_chain=None)
        except Exception as e:
            # If the NSE fetch path tries a network call and fails, the
            # function must still return False, not propagate.
            pytest.fail(
                f"evaluate_options_skew_warning raised on no-chain path: {e}"
            )
        # The function must return a bool
        assert isinstance(result, bool), (
            f"evaluate_options_skew_warning must return bool, got {type(result)}"
        )
        # AUDIT-FIX (Round 5, 2-g-5): the docstring says "must return False" —
        # actually assert it. The original `return False` stub passed this test.
        assert result is False, (
            "evaluate_options_skew_warning must return False on the no-chain "
            "fail-open path"
        )

    def test_returns_warning_when_skew_steep(self, caplog=None):
        """With a synthetic chain whose OTM-put skew slope exceeds 1.25,
        the function should return True (warning)."""
        mod = self._load_compliance()
        fn = getattr(mod, "evaluate_options_skew_warning", None)
        if fn is None:
            pytest.skip("evaluate_options_skew_warning not importable")
        # Build a synthetic chain with steep OTM-put skew
        spot = 100.0
        T = 30.0 / 365.0
        # OTM puts = strikes < spot; inflate their IV
        puts = []
        for k_minus_spot in [-20, -15, -10, -5, -2]:
            strike = spot + k_minus_spot
            # Steep skew: IV grows as we go OTM
            iv = 0.15 + 0.005 * abs(k_minus_spot)
            puts.append({"strike": strike, "imp_vol": iv, "spot": spot, "T": T,
                         "type": "put"})
        # ATM and OTM calls
        atm = [{"strike": spot, "imp_vol": 0.15, "spot": spot, "T": T, "type": "put"},
               {"strike": spot, "imp_vol": 0.15, "spot": spot, "T": T, "type": "call"}]
        calls = []
        for k_plus in [2, 5, 10, 15, 20]:
            strike = spot + k_plus
            iv = 0.15 + 0.002 * k_plus
            calls.append({"strike": strike, "imp_vol": iv, "spot": spot,
                          "T": T, "type": "call"})
        chain = {"2024-01-25": puts + atm + calls}
        try:
            result = fn(ticker="NIFTY", option_chain=chain, threshold=1.25)
        except Exception as e:
            pytest.skip(
                f"SVI fit failed on synthetic chain (expected if SVI has stricter "
                f"input requirements): {e}"
            )
        assert isinstance(result, bool), (
            f"must return bool, got {type(result)}"
        )
        # AUDIT-FIX (Round 5, 2-g-6): the only assertion used to be
        # isinstance(result, bool) — the original `return False` stub passed
        # it. A clearly skewed chain must produce True when the SVI backend is
        # importable; if it does not, skip LOUDLY (backend degraded) rather
        # than letting the test pass silently.
        if result is not True:
            degraded = False
            if caplog is not None:
                degraded = any("SkewWarn-DEGRADED" in r.getMessage()
                               for r in caplog.records)
            pytest.skip(
                "steep-skew chain did not fire the warning — SVI backend "
                "unavailable (SkewWarn-DEGRADED)" if degraded else
                "steep-skew chain did not fire the warning — investigate "
                "detect_skew_anomaly semantics"
            )
        assert result is True


# ============================================================================
# P2-4: data_layer is importable without yfinance; _get_yf lazy-loads
# ============================================================================

class TestP24LazyYfinance:
    """The top-level `import yfinance as yf` must be removed.  All yf.*
    callsites must route through `_get_yf()`.  data_layer must be fully
    importable even when yfinance is not installed."""

    def test_no_top_level_yfinance_import(self):
        """Source-level: `import yfinance` must NOT appear at module
        top-level (only inside function bodies / the _get_yf helper)."""
        src = (_QA_WORK / "data_layer.py").read_text().splitlines()
        # Find top-level imports (no leading whitespace, starts with 'import' or 'from')
        top_level_imports = []
        for i, line in enumerate(src, 1):
            stripped = line.lstrip()
            indent = len(line) - len(stripped)
            if indent == 0 and (stripped.startswith("import ") or stripped.startswith("from ")):
                if "yfinance" in stripped:
                    top_level_imports.append((i, line))
        assert not top_level_imports, (
            "data_layer.py must NOT have a top-level yfinance import. "
            f"Found at: {top_level_imports}"
        )

    def test_get_yf_helper_exists(self):
        """The `_get_yf()` lazy accessor must be defined in data_layer."""
        src = (_QA_WORK / "data_layer.py").read_text()
        assert "def _get_yf(" in src, (
            "_get_yf() helper must be defined in data_layer.py for lazy yfinance loading"
        )

    def test_get_yf_returns_none_on_missing_module(self):
        """Source-level: _get_yf() must have a try/except around the
        lazy `import yfinance` and return None on ImportError (not
        raise).  This guarantees that data_layer's _get_yf is safe to
        call in environments without yfinance installed."""
        import re
        src = (_QA_WORK / "data_layer.py").read_text()
        # Find _get_yf function body allowing multi-line docstrings
        m = re.search(
            r"def _get_yf\([^)]*\)[^:]*:(.*?)\n(?=def |class |\Z)",
            src, re.DOTALL,
        )
        assert m, "_get_yf not found in data_layer.py"
        body = m.group(1)
        # Must have a lazy `import yfinance` INSIDE the function
        assert "import yfinance" in body, (
            "_get_yf must lazy-import yfinance inside its body (not at module top)"
        )
        # Must catch ImportError
        assert "ImportError" in body, (
            "_get_yf must catch ImportError on the yfinance lazy import"
        )
        # Must return None on the except path
        return_none_pattern = re.compile(
            r"except\s+ImportError.*?return\s+None",
            re.DOTALL,
        )
        assert return_none_pattern.search(body), (
            "_get_yf must return None on ImportError (not raise)"
        )

    def test_get_yf_functional_returns_none(self, monkeypatch):
        """Functional: when yfinance is hidden, _get_yf() must return
        None rather than raising.  We exec the _get_yf function in
        isolation so we don't trigger data_layer's submodule imports
        which may transitively require yfinance for unrelated paths."""
        import re, sys
        src = (_QA_WORK / "data_layer.py").read_text()
        # Extract _get_yf function up to the next top-level statement
        # (a line starting at column 0 with a non-whitespace char).
        m = re.search(
            r"(def _get_yf\([^)]*\)[^:]*:.*?)(?=^[a-zA-Z_@])",
            src, re.DOTALL | re.MULTILINE,
        )
        assert m, "_get_yf function body not extractable"
        helper_code = m.group(1)
        # Build a tiny namespace with the globals _get_yf needs
        ns = {"os": os, "_YF_IMPORT_WARNED": False}
        # AUDIT-FIX (Round 4 — W0122): exec is intentional here — the test
        # extracts the `_get_yf` helper from utils.py source and runs it in
        # an isolated namespace to verify its yfinance-blocking behavior.
        # pylint: disable=exec-used
        exec(helper_code, ns)
        # Block yfinance at the finder level
        class _BlockYF:
            def find_spec(self, name, path=None, target=None):
                if name == "yfinance" or name.startswith("yfinance."):
                    raise ImportError("blocked by test")
                return None
        sys.meta_path.insert(0, _BlockYF())
        # Also remove any cached yfinance from sys.modules
        monkeypatch.delitem(sys.modules, "yfinance", raising=False)
        try:
            result = ns["_get_yf"]()
            assert result is None, (
                f"_get_yf() must return None when yfinance is not installed, "
                f"got {type(result)}"
            )
        finally:
            sys.meta_path.pop(0)

    def test_get_yf_emits_production_warning(self, monkeypatch):
        """When ENV=production, _get_yf must emit a DeprecationWarning
        on first call (one-shot)."""
        import sys
        import types
        # Make yfinance importable by using a stub module
        stub = types.ModuleType("yfinance")
        stub.Ticker = lambda *a, **kw: None
        stub.download = lambda *a, **kw: None
        monkeypatch.setitem(sys.modules, "yfinance", stub)
        monkeypatch.setenv("ENV", "production")
        # Import data_layer fresh
        monkeypatch.delitem(sys.modules, "data_layer", raising=False)
        try:
            import data_layer as dl  # type: ignore[import]
        except Exception as e:
            pytest.fail(f"data_layer import failed: {e}")
        # Reset the one-shot flag to ensure the warning fires on this run
        dl._YF_IMPORT_WARNED = False
        # First call should warn
        with pytest.warns(DeprecationWarning, match="yfinance lazy-loaded in ENV=production"):
            result = dl._get_yf()
            assert result is stub, "_get_yf must return the yfinance module"
        # Second call should NOT warn (one-shot)
        with warnings.catch_warnings():
            warnings.simplefilter("error", DeprecationWarning)
            dl._get_yf()  # should not raise


# ============================================================================
# A3: Robust Black-Litterman functional smoke test
# ============================================================================

class TestA3RobustBlackLitterman:
    """Robust BL with ellipsoidal uncertainty (Ben-Tal/Nemirovski 1998,
    Meucci 2009) — κ-shrink on posterior mean must be monotone and
    reduce to plain BL at κ=0."""

    @staticmethod
    def _load_rbl():
        # R50 FIX (test-contract repair): Round 46 re-quarantined the
        # provably-unreachable robust_black_litterman module to
        # math_engine/_attic/ (M-8), but this loader still pointed at the
        # pre-quarantine path — FileNotFoundError on all 4 tests of this
        # class, breaking the full suite. The MATH contract is unaffected by
        # where the module lives: load the quarantined file directly.
        _rbl_path = _QA_WORK / "math_engine" / "robust_black_litterman.py"
        if not _rbl_path.exists():
            _rbl_path = _QA_WORK / "math_engine" / "_attic" / "robust_black_litterman.py"
        spec = importlib.util.spec_from_file_location(
            "rbl_under_test",
            str(_rbl_path),
        )
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        return m

    def test_kappa_0_equals_plain_bl(self):
        mod = self._load_rbl()
        rng = np.random.default_rng(13)
        n = 8
        Sigma = np.cov(rng.standard_normal((500, n)) * 0.01, rowvar=False)
        pi = np.full(n, 0.0005)
        P = np.eye(n)
        Q = rng.standard_normal(n) * 0.001
        Omega = 0.05 * np.diag(np.diag(Sigma))
        mu_bl, sigma_bl = mod.black_litterman_posterior(
            pi_market=pi, P=P, Q=Q, Sigma=Sigma, Omega=Omega, tau=0.05
        )
        out_k0 = mod.robust_black_litterman(
            pi_market=pi, P=P, Q=Q, Sigma=Sigma, Omega=Omega,
            tau=0.05, kappa=0.0, shrink_direction="conservative",
        )
        np.testing.assert_allclose(out_k0["mu_robust"], mu_bl, atol=1e-12)

    def test_shrink_monotone_in_kappa(self):
        mod = self._load_rbl()
        rng = np.random.default_rng(13)
        n = 8
        Sigma = np.cov(rng.standard_normal((500, n)) * 0.01, rowvar=False)
        pi = np.full(n, 0.0005)
        P = np.eye(n)
        Q = rng.standard_normal(n) * 0.001
        Omega = 0.05 * np.diag(np.diag(Sigma))
        shrinks = []
        for k in (0.5, 1.0, 2.0, 3.0):
            out = mod.robust_black_litterman(
                pi_market=pi, P=P, Q=Q, Sigma=Sigma, Omega=Omega,
                tau=0.05, kappa=k, shrink_direction="conservative",
            )
            shrinks.append(float(np.mean(out["shrinkage_magnitude"])))
        # Monotone non-decreasing
        for i in range(1, len(shrinks)):
            assert shrinks[i] >= shrinks[i-1] - 1e-12, (
                f"shrink must be monotone in kappa: {shrinks}"
            )

    def test_conservative_shrink_reduces_mean(self):
        mod = self._load_rbl()
        rng = np.random.default_rng(13)
        n = 8
        Sigma = np.cov(rng.standard_normal((500, n)) * 0.01, rowvar=False)
        pi = np.full(n, 0.0005)
        P = np.eye(n)
        Q = rng.standard_normal(n) * 0.001
        Omega = 0.05 * np.diag(np.diag(Sigma))
        mu_bl, _ = mod.black_litterman_posterior(
            pi_market=pi, P=P, Q=Q, Sigma=Sigma, Omega=Omega, tau=0.05
        )
        out = mod.robust_black_litterman(
            pi_market=pi, P=P, Q=Q, Sigma=Sigma, Omega=Omega,
            tau=0.05, kappa=1.0, shrink_direction="conservative",
        )
        assert np.all(out["mu_robust"] <= mu_bl + 1e-12), \
            "conservative shrink must reduce posterior mean"

    def test_invalid_shrink_direction_raises(self):
        mod = self._load_rbl()
        rng = np.random.default_rng(13)
        n = 8
        Sigma = np.cov(rng.standard_normal((500, n)) * 0.01, rowvar=False)
        pi = np.full(n, 0.0005)
        P = np.eye(n)
        Q = rng.standard_normal(n) * 0.001
        Omega = 0.05 * np.diag(np.diag(Sigma))
        with pytest.raises(ValueError, match="shrink_direction"):
            mod.robust_black_litterman(
                pi_market=pi, P=P, Q=Q, Sigma=Sigma, Omega=Omega,
                tau=0.05, kappa=1.0, shrink_direction="invalid",
            )


# ============================================================================
# A4: HAR-RV (Corsi 2009) functional smoke test
# ============================================================================

class TestA4HARRV:
    """HAR-RV must fit, produce finite forecasts, and Yang-Zhang RV
    must produce non-negative variance estimates."""

    @staticmethod
    def _load_har_rv():
        spec = importlib.util.spec_from_file_location(
            "har_rv_under_test",
            str(_QA_WORK / "math_engine" / "har_rv.py"),
        )
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        return m

    def test_fit_har_rv_returns_finite_betas(self):
        mod = self._load_har_rv()
        rng = np.random.default_rng(7)
        n = 300
        base_rv = np.where(np.arange(n) < 150, 1e-4, 4e-4)
        rv = pd.Series(
            base_rv * (1.0 + 0.5 * rng.standard_normal(n)),
            index=pd.date_range("2020-01-01", periods=n, freq="B"),
        )
        model = mod.fit_har_rv(rv)
        assert model["beta"].shape == (4,)
        assert np.isfinite(model["r2"])
        assert 0 <= model["r2"] <= 1.0
        assert model["n_obs"] >= 10

    def test_forecast_positive_and_finite(self):
        mod = self._load_har_rv()
        rng = np.random.default_rng(7)
        n = 300
        rv = pd.Series(
            np.abs(rng.standard_normal(n)) * 1e-4,
            index=pd.date_range("2020-01-01", periods=n, freq="B"),
        )
        f1 = mod.har_rv_forecast(rv, horizon=1)
        f5 = mod.har_rv_forecast(rv, horizon=5)
        assert np.isfinite(f1) and f1 > 0
        assert np.isfinite(f5) and f5 > 0

    def test_yang_zhang_rv_nonnegative(self):
        mod = self._load_har_rv()
        rng = np.random.default_rng(11)
        n = 250
        close = 100.0 * np.exp(np.cumsum(rng.standard_normal(n) * 0.01))
        # Add a small overnight gap so YZ's overnight component is non-trivial
        open_ = close * (1.0 + rng.standard_normal(n) * 0.002)
        # Shift open so day t's open ≠ previous close (realistic)
        open_[1:] = close[:-1] * (1.0 + rng.standard_normal(n-1) * 0.003)
        open_[0] = 100.0
        high = np.maximum(open_, close) * (1.0 + np.abs(rng.standard_normal(n)) * 0.002)
        low = np.minimum(open_, close) * (1.0 - np.abs(rng.standard_normal(n)) * 0.002)
        ohlcv = pd.DataFrame({
            "Open": open_, "High": high, "Low": low, "Close": close,
        }, index=pd.date_range("2020-01-01", periods=n, freq="B"))
        rv_yz = mod.yang_zhang_rv(ohlcv)
        assert (rv_yz.dropna() >= 0).all(), \
            "Yang-Zhang RV must be non-negative (clipped)"
        assert float(rv_yz.mean()) > 0, \
            "Yang-Zhang RV mean must be strictly positive"

    def test_bootstrap_interval_brackets_point(self):
        mod = self._load_har_rv()
        rng = np.random.default_rng(7)
        n = 300
        rv = pd.Series(
            np.abs(rng.standard_normal(n)) * 1e-4,
            index=pd.date_range("2020-01-01", periods=n, freq="B"),
        )
        pt, lo, hi = mod.har_rv_forecast_with_intervals(
            rv, horizon=1, confidence=0.90, n_bootstrap=100
        )
        assert lo <= pt <= hi, "point forecast must lie inside interval"


# ============================================================================
# Entry point
# ============================================================================

if __name__ == "__main__":
    # Allow running without pytest installed
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
