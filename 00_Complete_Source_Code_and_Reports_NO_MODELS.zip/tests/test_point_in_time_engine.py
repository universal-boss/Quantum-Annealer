"""tests/test_point_in_time_engine.py
======================================
Unit tests for Point-in-Time Disclosures & Corporate Actions Engine.
"""
import sys, os, unittest
import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from data.point_in_time_engine import (
    PointInTimeStatementStore,
    CorporateActionAdjuster,
    get_pit_financials,
)


class TestPointInTimeEngine(unittest.TestCase):

    def test_zero_lookahead_financials(self):
        # As of July 1, 2024 (before Q1 disclosure on July 19), should return Q4 (period_end: 2024-03-31)
        res_early = get_pit_financials("RELIANCE", "2024-07-01 00:00:00")
        self.assertIsNotNone(res_early)
        self.assertEqual(res_early["period_end"], "2024-03-31")

        # As of August 1, 2024 (after Q1 disclosure), should return Q1 (period_end: 2024-06-30)
        res_later = get_pit_financials("RELIANCE", "2024-08-01 00:00:00")
        self.assertIsNotNone(res_later)
        self.assertEqual(res_later["period_end"], "2024-06-30")

    def test_unknown_ticker_returns_none(self):
        self.assertIsNone(get_pit_financials("NON_EXISTENT_CO", "2025-01-01"))

    def test_spinoff_demerger_resolution(self):
        # Before Tata Motors demerger (Oct 2025)
        before_spinoff = CorporateActionAdjuster.resolve_spinoff_constituents("TATAMOTORS", "2025-10-01")
        self.assertEqual(before_spinoff, ["TATAMOTORS"])

        # After Tata Motors demerger (Dec 2025)
        after_spinoff = CorporateActionAdjuster.resolve_spinoff_constituents("TATAMOTORS", "2025-12-01")
        self.assertEqual(set(after_spinoff), {"TMCV", "TMPV"})

    def test_bonus_price_adjustment(self):
        dates = pd.date_range("2024-10-20", periods=15, freq="D")
        df = pd.DataFrame({"Close": [3000.0] * 15, "Volume": [1000] * 15}, index=dates)
        adj_df = CorporateActionAdjuster.adjust_historical_prices("RELIANCE", df, as_of="2025-01-01")
        
        # Effective date was 2024-10-28. Dates before should be halved (factor 0.5)
        pre_event_price = adj_df.loc["2024-10-22", "Close"]
        self.assertEqual(pre_event_price, 1500.0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
