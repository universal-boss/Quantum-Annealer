"""tests/test_regime_kelly_levels.py
====================================
Unit tests for Tier 5 Regime-Conditional Scaling, Tier 7 Kelly-Linked Joint Sizing,
and Merton Jump-Diffusion Overnight Gap Risk Buffering.
"""
import sys, os, unittest
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from math_engine.profile_mathematical_suite import AdaptiveVolatilityRiskEngine
from optimizer_broker import compute_dynamic_trade_levels


class TestRegimeKellyLevels(unittest.TestCase):

    def test_tier5_regime_scaling_bull_vs_bear(self):
        # Under identical ATR (30.0), Bull Low-Vol vs Bear High-Vol
        bull = AdaptiveVolatilityRiskEngine.compute_dynamic_levels(
            current_price=1000.0, atr_val=30.0, regime="bull_lowvol", overnight_gap_buffer=False
        )
        bear = AdaptiveVolatilityRiskEngine.compute_dynamic_levels(
            current_price=1000.0, atr_val=30.0, regime="bear_highvol", overnight_gap_buffer=False
        )

        # Bull should have tighter stop and larger target
        self.assertLess(bull["stop_loss_pct"], bear["stop_loss_pct"])
        self.assertGreater(bull["target_upside_pct"], bull["stop_loss_pct"] * 2.5)
        self.assertIn("Bull Trending", bull["regime_applied"])
        self.assertIn("High Vol Shock", bear["regime_applied"])

    def test_merton_overnight_gap_buffering(self):
        # Position with gap buffering vs without gap buffering
        no_gap = AdaptiveVolatilityRiskEngine.compute_dynamic_levels(
            current_price=1000.0, atr_val=25.0, overnight_gap_buffer=False
        )
        with_gap = AdaptiveVolatilityRiskEngine.compute_dynamic_levels(
            current_price=1000.0, atr_val=25.0, overnight_gap_buffer=True
        )

        self.assertTrue(with_gap["merton_jump_adjusted"])
        self.assertGreater(with_gap["overnight_gap_buffer_pct"], 0.0)
        self.assertLess(with_gap["stop_loss_price"], no_gap["stop_loss_price"])

    def test_tier7_kelly_fixed_risk_parity(self):
        # Stock A with tight 2.5% stop vs Stock B with wider 5.0% stop
        res_a = AdaptiveVolatilityRiskEngine.compute_dynamic_levels(
            current_price=1000.0, atr_val=15.0, risk_per_trade_pct=1.0, max_position_weight_pct=50.0, overnight_gap_buffer=False
        )
        res_b = AdaptiveVolatilityRiskEngine.compute_dynamic_levels(
            current_price=1000.0, atr_val=30.0, risk_per_trade_pct=1.0, max_position_weight_pct=50.0, overnight_gap_buffer=False
        )

        # Implied risk should be exactly 1.0%
        risk_a = (res_a["kelly_position_weight_pct"] / 100.0) * (res_a["stop_loss_pct"] / 100.0) * 100.0
        risk_b = (res_b["kelly_position_weight_pct"] / 100.0) * (res_b["stop_loss_pct"] / 100.0) * 100.0

        # AUDIT-FIX (Round 5, 2-g-24): places=1 tolerates a 5% relative error
        # on a 1.0% fixed-risk target — tighten to places=3.
        self.assertAlmostEqual(risk_a, 1.0, places=3)
        self.assertAlmostEqual(risk_b, 1.0, places=3)

    def test_broker_dynamic_trade_levels_with_regime_and_kelly(self):
        res = compute_dynamic_trade_levels(
            ticker="TCS.NS",
            current_price=4200.0,
            atr_val=70.0,
            regime="Bull",
        )
        self.assertIn("kelly_position_weight_pct", res)
        self.assertIn("regime_applied", res)
        self.assertIn("overnight_gap_buffer_pct", res)
        self.assertTrue(res["merton_jump_adjusted"])
        self.assertGreater(res["kelly_position_weight_pct"], 0.0)
        self.assertLessEqual(res["kelly_position_weight_pct"], 25.0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
