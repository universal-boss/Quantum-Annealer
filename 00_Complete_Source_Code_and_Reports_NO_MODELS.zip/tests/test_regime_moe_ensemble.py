"""
tests/test_regime_moe_ensemble.py
=================================
Regression test suite for:
1. Dynamic Macro Regime Router & Mixture of Experts (MoE) Architecture
2. Sector-Neutral Cross-Sectional Ranking
3. Cryptographic SHA-256 Integrity of the 5 Archetype Models
"""
import hashlib
from pathlib import Path
import numpy as np
import pandas as pd
import pytest

from ml_alpha.regime_ensemble import (
    ARCHETYPE_MODEL_FILES,
    RegimeEnsembleRouter,
    apply_sector_neutral_ranking,
    detect_macro_regime_state,
    load_verified_model,
    resolve_primary_archetype,
)

ROOT = Path(__file__).resolve().parent.parent
MODELS_DIR = ROOT / "models"


def test_sha256_integrity_all_five_archetype_models():
    """All 5 archetype model pickles must exist and match their SHA-256 sidecars.

    AUDIT-FIX (Round 43): the shipped artifacts are ArchWrap(DeepResidual-
    ArchetypeNet) MLPs — NOT the five advertised architectures (GLM audit
    AUDIT-01/C-1). The C-1 load-time class assertion now correctly REFUSES
    them, so `load_verified_model` returning None for these artifacts is the
    *honest* expected behavior until they are regenerated via
    `python -m ml_alpha.train_archetype_models`. This test verifies the
    integrity sidecars, and verifies the loader does the right thing in
    whichever state the artifacts are in: genuine architecture -> loads;
    mismatched class -> refused (None).
    """
    import pickletools

    def _artifact_class_name(path):
        """Protocol-level extraction of the artifact's outermost class name.

        Executes NOTHING from the pickle (no torch/joblib imports needed):
        for a freshly-pickled object the FIRST STACK_GLOBAL/GLOBAL opcode pair
        names the outermost object's class (pickling is depth-first pre-order).
        """
        with open(path, "rb") as f:
            data = f.read()
        strings = []
        first_global = None
        for op, arg, _pos in pickletools.genops(data):
            if op.name in ("SHORT_BINUNICODE", "BINUNICODE", "UNICODE"):
                strings.append(arg)
            elif op.name == "GLOBAL" and isinstance(arg, str) and " " in arg:
                mod, cls = arg.split(" ", 1)
                if first_global is None:
                    first_global = (mod, cls)
            elif op.name == "STACK_GLOBAL" and len(strings) >= 2:
                if first_global is None:
                    first_global = (strings[-2], strings[-1])
        return first_global[1] if first_global else "<unknown>"

    expected_types = {
        "flow": "InstitutionalFlowGATModel",
        "momentum": "MomentumPatchTSTModel",
        "quality": "QualityCausalGARPModel",
        "defensive": "AllWeatherLiquidODEModel",
        "ipo": "IPOMultibaggerModel",
        "prebreakout": "PreBreakoutInceptionModel",
    }

    for arch_key, filename in ARCHETYPE_MODEL_FILES.items():
        pkl_path = MODELS_DIR / filename
        sha_path = pkl_path.with_suffix(pkl_path.suffix + ".sha256")

        assert pkl_path.exists(), f"Model file missing: {pkl_path}"
        assert sha_path.exists(), f"Sidecar missing: {sha_path}"

        expected_sha = sha_path.read_text(encoding="utf-8").strip().lower()
        actual_sha = hashlib.sha256(pkl_path.read_bytes()).hexdigest().lower()
        assert expected_sha == actual_sha, f"SHA-256 mismatch for {filename}"

        # Inspect the artifact class (torch-free) to decide which loader
        # behavior is correct for the deployed artifact.
        artifact_class = _artifact_class_name(pkl_path)

        model = load_verified_model(arch_key)
        if artifact_class == expected_types[arch_key]:
            # Genuine artifact: loader must accept it
            assert model is not None, f"Genuine {artifact_class} artifact refused for {arch_key}"
            assert hasattr(model, "predict") or hasattr(model, "predict_with_attribution")
        else:
            # Known fake-artifact state (AUDIT-01): loader must REFUSE it and
            # the MoE must run without this model rather than injecting
            # unverified alpha from a mis-advertised architecture.
            assert model is None, (
                f"{filename} contains {artifact_class} (expected {expected_types[arch_key]}) "
                f"but load_verified_model accepted it — the C-1 class assertion is not enforcing."
            )


def test_resolve_primary_archetype_all_profiles():
    """Maps canonical and alias profile names to the correct archetype key."""
    cases = [
        ("🦄 High-Growth IPO · Multibagger Hunter", "", "ipo"),
        ("ipo_multibagger", "ipo_multibagger", "ipo"),
        ("🚀 Momentum & Vol Squeeze · Institutional Alpha", "", "momentum"),
        ("Trend Momentum · Core", "institutional_alpha", "momentum"),
        ("Vol Squeeze & Expansion", "vol_squeeze", "momentum"),
        ("🏦 Institutional Flow & Smart Money", "", "flow"),
        ("Smart Money · Institutional Flow", "accumulation", "flow"),
        ("🏛️ Quality Growth & GARP Compounders", "", "quality"),
        ("GARP & Capital Compounders", "garp", "quality"),
        ("🛡️ All-Weather & Capital Preservation", "", "defensive"),
        ("Risk Parity & All-Weather", "pure_defensive", "defensive"),
    ]
    for pname, pmode, expected in cases:
        resolved = resolve_primary_archetype(pname, pmode)
        assert resolved == expected, f"Expected {expected} for ({pname}, {pmode}), got {resolved}"


def test_detect_macro_regime_state():
    """Tests macro regime state classification under varying market conditions."""
    # 1. Bull trending: low vol, positive trend, no drawdown
    regime_bull, probs_bull = detect_macro_regime_state(
        regime_info={"Regime": "Bull_Trending", "P_Bull": 0.8},
        benchmark_returns=pd.Series([0.002] * 63),
        india_vix=13.5,
    )
    assert regime_bull == "Bull_Trending"
    assert probs_bull["Bull_Trending"] > probs_bull["HighVol_CrashStress"]

    # 2. Stress / High Vol: high VIX
    regime_stress, probs_stress = detect_macro_regime_state(
        regime_info={"Regime": "Turbulent Bear"},
        benchmark_returns=pd.Series([-0.01] * 63),
        india_vix=24.5,
    )
    assert regime_stress == "HighVol_CrashStress"
    assert probs_stress["HighVol_CrashStress"] > 0.50

    # 3. Chop / Sideways: low trend, moderate vol
    regime_chop, probs_chop = detect_macro_regime_state(
        regime_info={"Regime": "Sideways", "P_Sideways": 0.6},
        benchmark_returns=pd.Series([0.0001] * 63),
        india_vix=15.0,
    )
    assert regime_chop == "Chop_MeanReversion"
    assert probs_chop["Chop_MeanReversion"] >= 0.40


def test_regime_ensemble_router_weight_simplex():
    """Routing weights must sum to 1.0 and anchor the primary archetype."""
    router = RegimeEnsembleRouter(primary_archetype="momentum", anchor_weight=0.60)

    # Bull regime tilts towards momentum and ipo
    w_bull = router.compute_routing_weights(regime_info={"Regime": "Bull_Trending", "P_Bull": 0.8})
    assert pytest.approx(sum(w_bull.values()), abs=1e-3) == 1.0
    assert w_bull["momentum"] >= 0.50
    assert w_bull["ipo"] > w_bull["defensive"]

    # Stress regime tilts towards defensive
    w_stress = router.compute_routing_weights(
        regime_info={"Regime": "Turbulent Bear"},
        india_vix=25.0,
    )
    assert pytest.approx(sum(w_stress.values()), abs=1e-3) == 1.0
    assert w_stress["defensive"] > w_bull["defensive"]


def test_predict_ensemble_execution():
    """Tests predict_ensemble on a synthetic universe with all required factors.

    AUDIT-FIX (Round 43): the five shipped archetype artifacts are ArchWrap
    MLPs (GLM audit AUDIT-01), which the C-1 class assertion correctly
    refuses — so in the as-shipped state the MoE runs with ZERO active models
    and predict_ensemble must honestly return zero-dispersion alpha with
    None metrics (the optimizer's Round-20 guard then refuses ML injection,
    by design). The dispersion/Sharpe assertions below can therefore only
    run when at least one GENUINE architecture artifact is deployed; when
    none are, this test instead pins the honest no-active-models contract.
    Regenerate genuine artifacts via `python -m ml_alpha.train_archetype_models`.
    """
    tickers = ["TCS", "INFY", "RELIANCE", "HDFCBANK", "ICICIBANK", "SBIN", "BHARTIARTL", "ITC"]
    np.random.seed(42)

    # Build signal_df containing factors for all 5 models
    all_factors = [
        "z_rs_rating", "z_mom_3m", "z_mom_6m", "z_vcp", "z_vpin_toxicity", "z_range_contraction",
        "z_vol_surge", "z_ma_compression", "z_obv_slope", "z_ann_vol", "z_trend_quality",
        "z_beta", "z_downside_vol", "z_sast_vel", "z_bulk_deal_footprint", "z_cmf", "z_delivery",
        "z_updown_vol", "z_pead", "z_float_squeeze", "z_volume_dryup", "z_roe", "z_pe_inv",
        "z_de_inv", "z_rev_growth", "z_drawdown", "z_neural_sde", "z_patch_tst", "z_base_tightness",
    ]
    data = {f: np.random.randn(len(tickers)) for f in all_factors}
    signal_df = pd.DataFrame(data, index=tickers)

    router = RegimeEnsembleRouter(primary_archetype="momentum")
    blended_alpha, diag = router.predict_ensemble(
        signal_df=signal_df,
        regime_info={"Regime": "Bull_Trending", "P_Bull": 0.8},
        india_vix=14.0,
    )

    assert len(blended_alpha) == len(tickers)

    if not diag or "active_weights" not in diag or not diag.get("active_weights"):
        # Honest no-active-models contract (shipped ArchWrap artifacts refused
        # per AUDIT-01/C-1): the ensemble must return zero alpha and an empty
        # diagnostics dict rather than fabricated signal — the optimizer's
        # Round-20 guard then refuses ML injection, by design.
        assert float(np.std(blended_alpha.values)) <= 1e-9, (
            "With zero verified models the ensemble must return zero alpha, "
            "not fabricated signal."
        )
        pytest.skip(
            "No genuine archetype artifacts deployed (shipped .pkl files are ArchWrap "
            "MLPs, refused per AUDIT-01) — dispersion/Sharpe assertions require "
            "artifacts regenerated via `python -m ml_alpha.train_archetype_models`."
        )

    assert "active_weights" in diag
    assert blended_alpha.std() > 1e-4, "Ensemble alpha must have non-zero cross-sectional dispersion"
    assert diag["ensemble_oos_sharpe"] >= 0.50, f"Ensemble OOS Sharpe {diag['ensemble_oos_sharpe']} must be >= 0.50"


def test_sector_neutral_cross_sectional_ranking():
    """Verifies that intra-sector ranking removes sector bias while preserving ranking."""
    tickers = ["A1", "A2", "A3", "B1", "B2", "B3"]
    sectors = {
        "A1": "TECH", "A2": "TECH", "A3": "TECH",
        "B1": "FIN", "B2": "FIN", "B3": "FIN",
    }
    # Notice sector B has artificially inflated alpha scores (e.g. bubble in financials)
    raw_alpha = [1.0, 2.0, 3.0, 10.0, 11.0, 12.0]
    df = pd.DataFrame({"alpha_score": raw_alpha}, index=tickers)

    # Without sector neutralization: all FIN stocks beat all TECH stocks
    # With 100% sector neutralization (lambda=1.0):
    neut_100 = apply_sector_neutral_ranking(df, sectors=sectors, lambda_sector=1.0)
    # A3 is best in TECH, B3 is best in FIN -> both should have identical intra-sector z-score
    assert pytest.approx(neut_100["A3"], abs=1e-3) == neut_100["B3"]
    assert pytest.approx(neut_100["A1"], abs=1e-3) == neut_100["B1"]

    # With balanced 50% blend:
    neut_50 = apply_sector_neutral_ranking(df, sectors=sectors, lambda_sector=0.5)
    # A3 should now be close to B1 or higher, preventing total crowding into sector B
    assert neut_50["A3"] > neut_50["B1"]
