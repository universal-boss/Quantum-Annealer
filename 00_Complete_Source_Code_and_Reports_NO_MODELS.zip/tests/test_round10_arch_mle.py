"""Round 10 — arch MLE wiring regression tests.

Verifies that:
  1. Both Cond-EVT and FHS-DCC-GARCH expose a `garch_method` field
     in their return dicts (either 'arch_mle' or 'gmm').
  2. When the `arch` package is importable, both modules prefer the
     full MLE path (garch_method == 'arch_mle').
  3. When arch is unavailable (simulated via import poisoning), both
     modules fall back to GMM cleanly (garch_method == 'gmm') and
     still produce a valid return dict of the same shape.
  4. The dispatcher's contract holds: same dict keys under both paths,
     only `garch_method` and `log_likelihood` differ.

References:
  - conditional_evt.fit_ar1_garch (Round 10 added garch_method + log_likelihood)
  - fhs_dcc_garch.fit_univariate_garch_mle (NEW in Round 10)
  - fhs_dcc_garch.fit_univariate_garch dispatcher (NEW in Round 10)
  - fhs_dcc_garch.fit_dcc_garch_gmm (now routes per-asset via dispatcher)
"""
from __future__ import annotations

import importlib
import sys
import unittest
from unittest.mock import patch
from pathlib import Path
import warnings

import numpy as np
import pandas as pd

# Resolve project root for in-tree imports (same pattern as test_round8_wiring)
_QA_ROOT = Path(__file__).resolve().parent.parent
if str(_QA_ROOT) not in sys.path:
    sys.path.insert(0, str(_QA_ROOT))

# Suppress pyparsing / matplotlib deprecation noise
# AUDIT-FIX (Round 5, 2-g-18): module-level filterwarnings mutated the GLOBAL
# filter for the whole test session (masking deprecations in other files).
# Scope them to this module's run via setUpModule/tearDownModule instead.
_WARN_CTX = None


def setUpModule():
    global _WARN_CTX
    _WARN_CTX = warnings.catch_warnings()
    _WARN_CTX.__enter__()
    warnings.filterwarnings("ignore", category=DeprecationWarning)
    warnings.filterwarnings("ignore", category=UserWarning)


def tearDownModule():
    if _WARN_CTX is not None:
        _WARN_CTX.__exit__(None, None, None)


def _make_garch_series(n: int = 750, seed: int = 42) -> np.ndarray:
    """Generate a synthetic GARCH(1,1) return series for testing.

    Uses true parameters omega=1e-6, alpha=0.10, beta=0.88 — close to
    typical equity index daily returns. Series length 750 ensures arch
    MLE converges reliably.
    """
    rng = np.random.default_rng(seed)
    eps = rng.standard_normal(n) * 0.01
    var = np.empty(n)
    var[0] = 0.01 ** 2
    for t in range(1, n):
        var[t] = 1e-6 + 0.10 * eps[t - 1] ** 2 + 0.88 * var[t - 1]
    return eps * np.sqrt(var)


def _make_3asset_frame(n: int = 750, seed: int = 42) -> pd.DataFrame:
    """3-asset return frame with cross-asset correlation 0.5 baseline."""
    rng = np.random.default_rng(seed)
    base = _make_garch_series(n, seed=seed)
    cols = {}
    L = np.linalg.cholesky(np.array([[1.0, 0.5, 0.3],
                                      [0.5, 1.0, 0.4],
                                      [0.3, 0.4, 1.0]]))
    raw = rng.standard_normal((n, 3))
    corr = raw @ L.T
    for j in range(3):
        cols[f"S{j}"] = base * 0.7 + corr[:, j] * 0.005
    return pd.DataFrame(cols)


class TestArchAvailability(unittest.TestCase):
    """Sanity: confirm arch is installed in this test environment so the
    MLE path is exercised. If arch is missing, the rest of the suite
    still passes but the MLE assertions are skipped."""

    def setUp(self):
        try:
            import arch  # noqa: F401
            self.arch_available = True
        except ImportError:
            self.arch_available = False

    def test_arch_is_installed(self):
        """arch>=6.3.0 should be installed per requirements.txt."""
        if not self.arch_available:
            self.skipTest("arch package not installed; MLE path tests are skipped")
        import arch
        self.assertGreaterEqual(
            tuple(int(x) for x in arch.__version__.split(".")[:2]),
            (6, 3),
            f"arch >= 6.3.0 required, got {arch.__version__}",
        )


class TestCondEVTGarchMethod(unittest.TestCase):
    """Round 10: conditional_evt.fit_ar1_garch must return a
    `garch_method` field ('arch_mle' or 'gmm')."""

    def setUp(self):
        try:
            import arch  # noqa: F401
            self.arch_available = True
        except ImportError:
            self.arch_available = False
        self.returns = _make_garch_series(750, seed=11)

    def test_return_has_garch_method_field(self):
        from math_engine.institutional.conditional_evt import fit_ar1_garch
        out = fit_ar1_garch(self.returns)
        self.assertIn("garch_method", out,
                      "fit_ar1_garch must return garch_method field (Round 10)")
        self.assertIn(out["garch_method"], ("arch_mle", "gmm"),
                      f"invalid garch_method: {out['garch_method']}")

    def test_return_has_log_likelihood_field(self):
        from math_engine.institutional.conditional_evt import fit_ar1_garch
        out = fit_ar1_garch(self.returns)
        self.assertIn("log_likelihood", out,
                      "fit_ar1_garch must return log_likelihood field (Round 10)")
        self.assertTrue(np.isfinite(out["log_likelihood"]) or
                        out["log_likelihood"] == float("-inf"))

    def test_arch_mle_preferred_when_available(self):
        if not self.arch_available:
            self.skipTest("arch not installed")
        from math_engine.institutional.conditional_evt import fit_ar1_garch
        out = fit_ar1_garch(self.returns)
        self.assertEqual(out["garch_method"], "arch_mle",
                         "fit_ar1_garch should prefer arch MLE when arch is installed")
        self.assertGreater(out["log_likelihood"], -1e6,
                           "arch MLE should produce a finite log-likelihood")

    def test_gmm_fallback_when_arch_unavailable(self):
        """Simulate arch being missing by poisoning sys.modules."""
        from math_engine.institutional.conditional_evt import fit_ar1_garch
        # Save original arch modules
        saved = {k: sys.modules.get(k) for k in list(sys.modules) if k == "arch" or k.startswith("arch.")}
        # Poison arch and arch.arch_model so the import raises ImportError
        for k in list(sys.modules):
            if k == "arch" or k.startswith("arch."):
                del sys.modules[k]
        sys.modules["arch"] = None  # type: ignore[assignment]

        try:
            out = fit_ar1_garch(self.returns)
            self.assertEqual(out["garch_method"], "gmm",
                             "fit_ar1_garch must fall back to gmm when arch unavailable")
            self.assertIsNone(out["fitted_obj"],
                              "GMM fallback must set fitted_obj=None")
            self.assertEqual(out["log_likelihood"], float("-inf"))
        finally:
            # Restore
            for k in list(sys.modules):
                if k == "arch" or k.startswith("arch."):
                    del sys.modules[k]
            for k, v in saved.items():
                if v is not None:
                    sys.modules[k] = v


class TestFhsDccGarchMethod(unittest.TestCase):
    """Round 10: fhs_dcc_garch must (a) expose fit_univariate_garch_mle,
    (b) route per-asset fits through the dispatcher, and (c) carry
    `garch_method` (per asset) and `garch_methods` (in DCC fit)."""

    def setUp(self):
        try:
            import arch  # noqa: F401
            self.arch_available = True
        except ImportError:
            self.arch_available = False
        self.r1d = _make_garch_series(750, seed=21)
        self.df3 = _make_3asset_frame(750, seed=21)

    def test_mle_function_exists(self):
        from math_engine.institutional.fhs_dcc_garch import (
            fit_univariate_garch_mle, fit_univariate_garch,
            fit_univariate_garch_gmm, fit_dcc_garch,
        )
        self.assertTrue(callable(fit_univariate_garch_mle))
        self.assertTrue(callable(fit_univariate_garch))
        self.assertTrue(callable(fit_univariate_garch_gmm))
        self.assertTrue(callable(fit_dcc_garch))  # Round 10 alias

    def test_per_asset_dispatcher_prefers_mle(self):
        from math_engine.institutional.fhs_dcc_garch import fit_univariate_garch
        out = fit_univariate_garch(self.r1d)
        self.assertIn("garch_method", out)
        self.assertIn("log_likelihood", out)
        if self.arch_available:
            self.assertEqual(out["garch_method"], "arch_mle")
            self.assertGreater(out["log_likelihood"], -1e6)
        else:
            self.assertEqual(out["garch_method"], "gmm")

    def test_mle_and_gmm_have_same_return_shape(self):
        """Round 10 contract: MLE and GMM must return the same dict keys
        so callers don't break when arch is / isn't available. Only
        `garch_method` and `log_likelihood` values differ."""
        from math_engine.institutional.fhs_dcc_garch import (
            fit_univariate_garch_mle, fit_univariate_garch_gmm,
        )
        if not self.arch_available:
            self.skipTest("arch not installed; cannot compare MLE vs GMM shapes")
        mle = fit_univariate_garch_mle(self.r1d)
        gmm = fit_univariate_garch_gmm(self.r1d)
        mle_keys = set(mle.keys())
        gmm_keys = set(gmm.keys())
        self.assertEqual(mle_keys, gmm_keys,
                         f"MLE vs GMM return shape mismatch: "
                         f"only-MLE={mle_keys - gmm_keys}, "
                         f"only-GMM={gmm_keys - mle_keys}")

    def test_dcc_fit_carries_garch_methods_list(self):
        from math_engine.institutional.fhs_dcc_garch import fit_dcc_garch_gmm
        out = fit_dcc_garch_gmm(self.df3)
        self.assertIn("garch_methods", out,
                      "fit_dcc_garch_gmm must return garch_methods list (Round 10)")
        methods = out["garch_methods"]
        self.assertEqual(len(methods), 3,
                         f"expected 3 per-asset methods, got {len(methods)}")
        for m in methods:
            self.assertIn(m, ("arch_mle", "gmm"),
                          f"invalid per-asset garch_method: {m}")

    def test_dcc_fit_aliases_are_identical(self):
        """fit_dcc_garch (Round 10 alias) and fit_dcc_garch_gmm must be
        the same callable — back-compat preserved."""
        from math_engine.institutional.fhs_dcc_garch import (
            fit_dcc_garch, fit_dcc_garch_gmm,
        )
        self.assertIs(fit_dcc_garch, fit_dcc_garch_gmm,
                      "fit_dcc_garch must be an alias of fit_dcc_garch_gmm")

    def test_dcc_fit_gmm_fallback_works(self):
        """When arch is unavailable, fit_dcc_garch_gmm must still produce
        a valid result via GMM per-asset fallback. Simulate arch missing."""
        from math_engine.institutional.fhs_dcc_garch import fit_dcc_garch_gmm
        saved = {k: sys.modules.get(k) for k in list(sys.modules) if k == "arch" or k.startswith("arch.")}
        for k in list(sys.modules):
            if k == "arch" or k.startswith("arch."):
                del sys.modules[k]
        sys.modules["arch"] = None  # type: ignore[assignment]

        try:
            out = fit_dcc_garch_gmm(self.df3)
            self.assertEqual(len(out["garch_methods"]), 3)
            self.assertTrue(all(m == "gmm" for m in out["garch_methods"]),
                            f"expected all 'gmm' fallback, got {out['garch_methods']}")
            self.assertEqual(out["R_next"].shape, (3, 3))
            self.assertEqual(out["sigma_next"].shape, (3,))
        finally:
            for k in list(sys.modules):
                if k == "arch" or k.startswith("arch."):
                    del sys.modules[k]
            for k, v in saved.items():
                if v is not None:
                    sys.modules[k] = v

    def test_mle_path_changes_output_vs_gmm(self):
        """Sanity: arch MLE and GMM must produce DIFFERENT sigma_next
        for the same data — otherwise the wiring is a no-op. The exact
        value doesn't matter, only that the MLE path is materially
        different from the GMM fallback."""
        if not self.arch_available:
            self.skipTest("arch not installed; cannot compare MLE vs GMM outputs")
        from math_engine.institutional.fhs_dcc_garch import (
            fit_univariate_garch_mle, fit_univariate_garch_gmm,
        )
        mle = fit_univariate_garch_mle(self.r1d)
        gmm = fit_univariate_garch_gmm(self.r1d)
        # Parameters should differ by at least a small margin — MLE is
        # statistically efficient, GMM is a closed-form moment match
        diff_alpha = abs(mle["alpha"] - gmm["alpha"])
        self.assertGreater(diff_alpha, 1e-6,
                           "MLE and GMM alpha should differ — wiring may be a no-op")
        diff_sigma = abs(mle["next_sigma"] - gmm["next_sigma"])
        self.assertGreater(diff_sigma, 1e-10,
                           "MLE and GMM sigma_next should differ — wiring may be a no-op")


class TestWiringBackwardCompatAfterArch(unittest.TestCase):
    """The Round 8 wiring (optimizer_risk_institutional.multivariate_var_es)
    must still work end-to-end now that arch is wired in. It should
    produce the same dict shape (success/var/es/source) regardless of
    whether arch is available — only the per-asset garch_method inside
    the DCC fit changes."""

    def setUp(self):
        try:
            import arch  # noqa: F401
            self.arch_available = True
        except ImportError:
            self.arch_available = False
        rng = np.random.default_rng(31)
        n = 750
        cols = {}
        for j in range(3):
            cols[f"S{j}"] = pd.Series(
                _make_garch_series(n, seed=31 + j) +
                rng.standard_normal(n) * 0.003
            )
        self.returns_df = pd.DataFrame(cols)
        self.weights = np.array([0.4, 0.3, 0.3])

    def test_multivariate_var_es_wiring_still_passes(self):
        from optimizer_risk_institutional import multivariate_var_es
        out = multivariate_var_es(
            returns_df=self.returns_df,
            weights=self.weights,
            alpha=0.99,
            horizon=1,
            n_sim=2000,
        )
        self.assertIn("source", out)
        self.assertEqual(out["source"], "fhs_dcc_garch",
                         "Round 8 wiring must still route to fhs_dcc_garch source")
        # Round 8 wiring return contract: var_pct / es_pct (as fractions)
        # plus var_inr / es_inr (in rupees given nav_inr)
        for k in ("var_pct", "es_pct", "var_inr", "es_inr"):
            self.assertIn(k, out,
                          f"multivariate_var_es must return {k} (Round 8 wiring contract)")
        # VaR/ES should be positive magnitudes (losses)
        self.assertGreater(out["var_pct"], 0.0)
        self.assertGreater(out["es_pct"], 0.0)
        # ES ≥ VaR by definition (ES averages the tail beyond VaR)
        self.assertGreaterEqual(out["es_pct"], out["var_pct"],
                                "ES must be >= VaR (coherent risk measure)")


if __name__ == "__main__":
    unittest.main()
