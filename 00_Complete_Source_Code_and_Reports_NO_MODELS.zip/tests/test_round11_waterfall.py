"""Round 11 tests — real NSE waterfall, stacked waterfall, FHS-DCC max-weight cap.

This module tests the three Round 11 deliverables:

  Task A — `data_layer.fetch_ohlcv` returns a clean daily-returns
           DataFrame on real NSE tickers. The waterfall script's
           `_load_real_nse_returns` helper returns the same shape as
           `_generate_synthetic_returns` and gracefully degrades to
           empty on failure.

  Task B — `run_stacked_waterfall` enables wirings cumulatively in
           descending single-module-lift order and reports per-step
           incremental and cumulative Sharpe deltas. The interaction
           effect (= net stacked lift - sum of positive per-module
           lifts) is finite and observable, NOT always zero — proves
           the stacked run actually exercises the blend logic.

  Task C — `_apply_max_weight_constraint` caps each weight at
           `max_weight`, redistributes the residual to un-frozen
           assets, and converges in ≤ ceil(N / max_weight * N) iters.
           `_w_fhs_dcc_garch` with the default cap (0.40) produces
           no weight > 0.40 on the synthetic 5-asset bench — proving
           the over-concentration regression is fixed.

Run:
    python -m pytest tests/test_round11_waterfall.py -v
"""
from __future__ import annotations

import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import unittest

# Project root on sys.path
_QA_ROOT = Path(__file__).resolve().parent.parent
if str(_QA_ROOT) not in sys.path:
    sys.path.insert(0, str(_QA_ROOT))

# AUDIT-FIX (Round 5, 2-g-18): scope the global warning-filter mutations to
# this module's run instead of leaking them into the whole session.
_WARN_CTX = None


def setUpModule():
    global _WARN_CTX
    _WARN_CTX = warnings.catch_warnings()
    _WARN_CTX.__enter__()
    warnings.filterwarnings("ignore", category=DeprecationWarning)
    warnings.filterwarnings("ignore", category=UserWarning)
    warnings.filterwarnings("ignore", category=RuntimeWarning)
    warnings.filterwarnings("ignore", category=FutureWarning)


def tearDownModule():
    if _WARN_CTX is not None:
        _WARN_CTX.__exit__(None, None, None)


# ─────────────────────────────────────────────────────────────────────────
# Task C: max-weight constraint
# ─────────────────────────────────────────────────────────────────────────

class TestMaxWeightConstraint(unittest.TestCase):
    """Tests for `_apply_max_weight_constraint` (Task C)."""

    def setUp(self):
        from scripts.sharpe_lift_waterfall import _apply_max_weight_constraint
        self.cap_fn = _apply_max_weight_constraint

    def test_no_clipping_needed_when_all_below_cap(self):
        """5-asset equal-weight (0.20 each) with cap=0.40 → unchanged."""
        w = np.array([0.20, 0.20, 0.20, 0.20, 0.20])
        out = self.cap_fn(w, max_weight=0.40)
        np.testing.assert_allclose(out, w, atol=1e-12)
        self.assertAlmostEqual(out.sum(), 1.0, places=10)

    def test_concentrated_solution_gets_capped(self):
        """One asset at 0.80, cap=0.40 → that asset clipped to 0.40,
        residual 0.40 distributed proportionally to the other four."""
        # 0.80 / 0.05 / 0.05 / 0.05 / 0.05 = total 1.0
        w = np.array([0.80, 0.05, 0.05, 0.05, 0.05])
        out = self.cap_fn(w, max_weight=0.40)
        self.assertLessEqual(out.max(), 0.40 + 1e-9, "cap not enforced")
        self.assertAlmostEqual(out.sum(), 1.0, places=10)
        # Capped asset should be exactly at the cap
        self.assertAlmostEqual(out[0], 0.40, places=10)
        # The other four should split the residual 0.60 equally
        # (since they were all equal before the cap)
        for i in range(1, 5):
            self.assertAlmostEqual(out[i], 0.15, places=10)

    def test_iterative_clip_with_two_offenders(self):
        """Two assets at 0.45 each, cap=0.40 — both get clipped and the
        residual 0.10 must go to the other three (each at 0.0333 before
        the clip → ~0.0667 after)."""
        w = np.array([0.45, 0.45, 0.0333, 0.0333, 0.0334])
        out = self.cap_fn(w, max_weight=0.40)
        self.assertLessEqual(out.max(), 0.40 + 1e-9)
        self.assertAlmostEqual(out.sum(), 1.0, places=10)
        # First two should be exactly at the cap
        self.assertAlmostEqual(out[0], 0.40, places=8)
        self.assertAlmostEqual(out[1], 0.40, places=8)

    def test_feasibility_relaxation_when_cap_below_one_over_n(self):
        """Cap = 0.10 with 5 assets (1/5 = 0.20) — infeasible. The cap
        should be relaxed to 1/N and the function should return equal
        weights (which trivially satisfies the relaxed cap)."""
        w = np.array([0.50, 0.20, 0.15, 0.10, 0.05])
        out = self.cap_fn(w, max_weight=0.10)
        self.assertAlmostEqual(out.sum(), 1.0, places=10)
        # Each entry should be 1/5 = 0.20 (the feasible cap)
        np.testing.assert_allclose(out, np.full(5, 0.20), atol=1e-9)

    def test_zero_weight_vector_returns_equal_weight(self):
        """All-zero input → return equal weight (degenerate but valid)."""
        w = np.zeros(5)
        out = self.cap_fn(w, max_weight=0.40)
        self.assertAlmostEqual(out.sum(), 1.0, places=10)
        np.testing.assert_allclose(out, np.full(5, 0.20), atol=1e-9)

    def test_negative_weights_clipped_to_zero_first(self):
        """Weights with negatives → clipped to zero then capped."""
        # Sum after clip = 0.90; renormalized to 1.0; then 0.85 entry
        # gets capped at 0.40, residual distributed.
        w = np.array([0.85, 0.05, -0.10, 0.10, 0.10])
        out = self.cap_fn(w, max_weight=0.40)
        self.assertLessEqual(out.max(), 0.40 + 1e-9)
        self.assertAlmostEqual(out.sum(), 1.0, places=10)
        # No negative weights after cap
        self.assertGreaterEqual(out.min(), -1e-12)

    def test_convergence_within_iter_budget(self):
        """Even pathological input must converge before max_iter=50."""
        # Worst case: alternating weights that need many clip-and-
        # renormalize rounds. 5-asset case converges in < 5 iters.
        # AUDIT-FIX (Round 4 — W0125): original line had `if False` constant
        # test that always picked the hardcoded array; the rng.dirichlet
        # branch was dead code. Remove the dead branch entirely.
        w = np.array(
            [0.95, 0.01, 0.01, 0.01, 0.02]
        )
        out = self.cap_fn(w, max_weight=0.30, max_iter=50)
        self.assertLessEqual(out.max(), 0.30 + 1e-9)
        self.assertAlmostEqual(out.sum(), 1.0, places=10)


# ─────────────────────────────────────────────────────────────────────────
# Task C continued: FHS-DCC wiring uses the cap
# ─────────────────────────────────────────────────────────────────────────

class TestFhsDccMaxWeightWiring(unittest.TestCase):
    """The FHS-DCC min-variance wiring must respect the max_weight cap
    (Round 11 fix for over-concentration)."""

    def setUp(self):
        from scripts.sharpe_lift_waterfall import _w_fhs_dcc_garch
        self.wiring = _w_fhs_dcc_garch
        # Synthetic 5-asset 250-day return frame that previously triggered
        # over-concentration (one asset with much lower variance → ~80%
        # weight under unconstrained min-var).
        rng = np.random.default_rng(7)
        cols = ["LOW_VOL", "MED1", "MED2", "HIGH1", "HIGH2"]
        # LOW_VOL asset has 1/10 the vol of the others — unconstrained
        # min-var puts ~85% weight on it.
        sig = np.array([0.005, 0.05, 0.06, 0.07, 0.08])
        eps = rng.standard_normal((300, 5)) * sig
        # Inject a tiny positive drift so Sharpe is finite
        eps[:, 0] += 0.0002
        self.r = pd.DataFrame(eps, columns=cols)

    def test_default_cap_enforced(self):
        """With default max_weight=0.40, no weight exceeds 0.40."""
        out = self.wiring(self.r)
        w = out["weights"]
        self.assertLessEqual(w.max(), 0.40 + 1e-9,
                             f"max weight {w.max()} exceeds default cap 0.40")
        self.assertAlmostEqual(w.sum(), 1.0, places=8)
        # Source tag should reflect the cap
        self.assertIn("max_w", out["source"])

    def test_cap_at_one_recovers_unconstrained_behavior(self):
        """max_weight=1.0 disables the cap (backward-compat)."""
        out_uncapped = self.wiring(self.r, max_weight=1.0)
        # Even uncapped, the long-only clip applies so weights are ≥ 0
        self.assertGreaterEqual(out_uncapped["weights"].min(), -1e-9)
        # Verify that the cap is what's making the difference — on this
        # bench, uncapped FHS-DCC should over-concentrate on LOW_VOL
        # (which is the whole point of the Round 11 fix).
        uncapped_w = out_uncapped["weights"]
        # Some weight should exceed 0.40 in uncapped mode (this is
        # the bug Round 11 fixes). If it doesn't, the test bench is
        # no longer discriminating — re-tune the synthetic generator.
        # We assert at least one weight > 0.35 (so the cap actually
        # binds, otherwise the cap is a no-op on this bench).
        self.assertGreater(
            uncapped_w.max(), 0.35,
            f"uncapped max weight {uncapped_w.max():.4f} should exceed "
            f"0.35 on this bench (otherwise the cap is non-binding)",
        )

    def test_cap_disabled_with_high_threshold(self):
        """max_weight=0.99 effectively disables the cap."""
        out = self.wiring(self.r, max_weight=0.99)
        w = out["weights"]
        self.assertLessEqual(w.max(), 0.99 + 1e-9)
        self.assertAlmostEqual(w.sum(), 1.0, places=8)

    def test_cap_changes_sharpe(self):
        """The cap changes the realized Sharpe (it's not a no-op)."""
        out_capped = self.wiring(self.r, max_weight=0.40)
        out_uncapped = self.wiring(self.r, max_weight=1.0)
        # On a mean-reverting alpha bench, capping should HURT Sharpe
        # (we're prevented from overweighting the lowest-vol asset).
        # On a trend bench, capping should HELP. Either way, they
        # should differ. We don't assert direction — just that the
        # cap materially affects the output.
        self.assertNotEqual(
            round(out_capped["sharpe"], 6),
            round(out_uncapped["sharpe"], 6),
            "Cap had no effect on Sharpe — cap is a no-op on this bench",
        )


# ─────────────────────────────────────────────────────────────────────────
# Task A: data_layer.fetch_ohlcv + _load_real_nse_returns
# ─────────────────────────────────────────────────────────────────────────

class TestFetchOhlcvPublicAPI(unittest.TestCase):
    """`data_layer.fetch_ohlcv` is a new public entry point (Round 11)."""

    def setUp(self):
        try:
            import data_layer  # noqa: F401
            self.dl = data_layer
        except Exception as e:
            self.skipTest(f"data_layer import failed: {e}")

    def test_function_exists_and_is_callable(self):
        self.assertTrue(hasattr(self.dl, "fetch_ohlcv"),
                        "data_layer.fetch_ohlcv missing")
        self.assertTrue(callable(self.dl.fetch_ohlcv))

    def test_empty_tickers_returns_empty_dataframe(self):
        out = self.dl.fetch_ohlcv([])
        self.assertIsInstance(out, pd.DataFrame)
        self.assertTrue(out.empty)

    def test_suffix_normalization_reliance_ns(self):
        """'RELIANCE' should be normalized to 'RELIANCE.NS' internally.
        We can't assert the exact fetch call without mocking yfinance,
        but we can assert the function doesn't crash on bare tickers
        AND on already-suffixed tickers, producing the same shape."""
        # This test will likely produce empty results in the sandbox
        # if yfinance isn't reachable, but it must NOT raise.
        try:
            out_bare = self.dl.fetch_ohlcv(
                ["RELIANCE"], period="5d", return_returns=False,
            )
        except Exception as e:
            self.fail(f"fetch_ohlcv(['RELIANCE']) raised {e!r}")
        try:
            out_suf = self.dl.fetch_ohlcv(
                ["RELIANCE.NS"], period="5d", return_returns=False,
            )
        except Exception as e:
            self.fail(f"fetch_ohlcv(['RELIANCE.NS']) raised {e!r}")
        # If both succeeded, shapes must match
        if out_bare is not None and out_suf is not None:
            self.assertEqual(out_bare.shape, out_suf.shape,
                             "bare vs suffixed ticker produced different shapes")

    def test_returns_mode_returns_dataframe_or_empty(self):
        """return_returns=True must return either a non-empty DataFrame
        with numeric values, or an empty DataFrame — never None, never
        raise."""
        out = self.dl.fetch_ohlcv(
            ["RELIANCE.NS"], period="5d", return_returns=True,
        )
        self.assertIsInstance(out, pd.DataFrame,
                              "must return DataFrame, not None")
        if not out.empty:
            # Numeric check
            self.assertTrue(
                out.select_dtypes(include="number").shape[1] > 0,
                "returns frame has no numeric columns",
            )


class TestWaterfallRealNseLoader(unittest.TestCase):
    """`_load_real_nse_returns` helper in the waterfall script."""

    def setUp(self):
        try:
            from scripts.sharpe_lift_waterfall import _load_real_nse_returns
            self.loader = _load_real_nse_returns
        except Exception as e:
            self.skipTest(f"waterfall script import failed: {e}")

    def test_returns_dataframe_or_empty_never_raises(self):
        out = self.loader(tickers=["RELIANCE.NS"], period="5d")
        self.assertIsInstance(out, pd.DataFrame)
        # Don't assert non-empty — sandbox may not have network.

    def test_invalid_tickers_returns_empty_silently(self):
        out = self.loader(tickers=["NOT_A_TICKER_XYZ.NS"], period="5d")
        self.assertIsInstance(out, pd.DataFrame)
        # Either empty or a frame with all-NaN rows that we then dropped.
        # If non-empty, it shouldn't crash downstream code.
        if not out.empty:
            # No NaN rows in the final output (the loader drops them)
            self.assertFalse(out.isna().any().any(),
                             "loader left NaN rows in returns frame")

    def test_column_names_strip_ns_suffix(self):
        """When real fetch works, columns should have '.NS' stripped."""
        out = self.loader(tickers=["RELIANCE.NS", "HDFCBANK.NS"],
                          period="5d")
        if not out.empty:
            self.assertNotIn(".NS", "".join(out.columns.astype(str)),
                             "column names still contain .NS suffix")
            self.assertIn("RELIANCE", out.columns.astype(str).tolist())


# ─────────────────────────────────────────────────────────────────────────
# Task B: stacked waterfall
# ─────────────────────────────────────────────────────────────────────────

class TestStackedWaterfall(unittest.TestCase):
    """Tests for `run_stacked_waterfall` and `_blend_weights`."""

    def setUp(self):
        try:
            from scripts.sharpe_lift_waterfall import (
                _blend_weights, run_stacked_waterfall, run_waterfall,
                _generate_synthetic_returns,
            )
            self.blend = _blend_weights
            self.run_stacked = run_stacked_waterfall
            self.run_single = run_waterfall
            self.synth = _generate_synthetic_returns
        except Exception as e:
            self.skipTest(f"waterfall script import failed: {e}")

    def test_blend_weights_simple_mean(self):
        """Blend of [1,0,0,0,0] and [0,1,0,0,0] = [0.5,0.5,0,0,0]."""
        a = np.array([1.0, 0, 0, 0, 0])
        b = np.array([0.0, 1.0, 0, 0, 0])
        out = self.blend([a, b])
        np.testing.assert_allclose(out, [0.5, 0.5, 0, 0, 0], atol=1e-12)
        self.assertAlmostEqual(out.sum(), 1.0, places=10)

    def test_blend_weights_normalizes_to_one(self):
        """Blend of three vectors each summing to 1.0 should also sum
        to 1.0 (mean of vectors that each sum to 1 → vector that sums
        to 1)."""
        rng = np.random.default_rng(0)
        vecs = [rng.dirichlet([1, 1, 1, 1, 1]) for _ in range(3)]
        out = self.blend(vecs)
        self.assertAlmostEqual(out.sum(), 1.0, places=10)
        self.assertEqual(out.shape, (5,))

    def test_blend_empty_list_returns_empty(self):
        out = self.blend([])
        self.assertEqual(out.size, 0)

    def test_blend_zero_sum_falls_back_to_equal_weight(self):
        """If the mean is all-zero (degenerate), return equal weight."""
        a = np.array([0.5, -0.5, 0, 0, 0])
        b = np.array([-0.5, 0.5, 0, 0, 0])
        out = self.blend([a, b])
        self.assertAlmostEqual(out.sum(), 1.0, places=10)
        np.testing.assert_allclose(out, np.full(5, 0.20), atol=1e-9)

    def test_stacked_waterfall_runs_on_synthetic(self):
        """End-to-end: run single-module waterfall on synthetic data,
        then run stacked waterfall on the result. Must produce 18 rows
        (1 baseline + 17 wirings — the 16 institutional modules plus
        har_rv from Round 7) and a non-trivial interaction delta."""
        import tempfile
        r = self.synth(n_days=300, n_assets=5, seed=11)
        with tempfile.TemporaryDirectory() as tmp:
            out_dir = Path(tmp)
            df_single, csv_single, png_single = self.run_single(r, out_dir)
            df_stacked, csv_stacked, png_stacked = self.run_stacked(
                r, df_single, out_dir,
            )
            # CSVs and PNGs must exist (check inside the context before
            # the temp dir is cleaned up on exit)
            self.assertTrue(csv_stacked.exists(),
                            f"stacked CSV not written: {csv_stacked}")
            self.assertTrue(png_stacked.exists(),
                            f"stacked PNG not written: {png_stacked}")
        # Shape checks: 1 BASELINE + 17 wirings = 18 rows
        # AUDIT-FIX (Round 5, 2-g-20): the expectation was derived from the
        # production output itself (len(df_single) - 1), so a regression to
        # 15 modules still passed. Assert the documented absolute count.
        n_wirings = len(df_single) - 1  # informational
        self.assertEqual(len(df_single), 18,
                         f"single-module sheet must have 18 rows (1 BASELINE + 17 "
                         f"wirings), got {len(df_single)}")
        self.assertEqual(len(df_stacked), 18,
                         f"stacked must have 18 rows (BASELINE + 17 wirings), "
                         f"got {len(df_stacked)}")
        self.assertIn("incremental_delta", df_stacked.columns)
        self.assertIn("cumulative_delta_vs_baseline", df_stacked.columns)
        self.assertIn("stack_size", df_stacked.columns)
        # Stack size should be 0, 1, 2, ..., n_wirings
        self.assertEqual(df_stacked["stack_size"].tolist(),
                         list(range(n_wirings + 1)))
        # Step 0 must be BASELINE
        self.assertEqual(df_stacked.loc[0, "module_added"], "BASELINE")
        # Final Sharpe must differ from baseline (otherwise the stacked
        # run is a no-op — either all deltas are zero, or the blend
        # always happens to recover the equal-weight Sharpe, both of
        # which would indicate a bug).
        base_sharpe = float(df_stacked["sharpe"].iloc[0])
        final_sharpe = float(df_stacked["sharpe"].iloc[-1])
        self.assertNotEqual(
            round(base_sharpe, 6), round(final_sharpe, 6),
            "stacked Sharpe didn't move from baseline — blend is a no-op",
        )

    def test_stacked_waterfall_interaction_effect_is_finite(self):
        """The interaction effect = (final stacked delta) - (sum of
        positive per-module deltas). It must be a finite float, not
        NaN/inf. Also test that it's NOT always zero — proving the
        blend actually exercises inter-module interaction."""
        import tempfile
        r = self.synth(n_days=300, n_assets=5, seed=11)
        with tempfile.TemporaryDirectory() as tmp:
            out_dir = Path(tmp)
            df_single, _, _ = self.run_single(r, out_dir)
            df_stacked, _, _ = self.run_stacked(r, df_single, out_dir)
        pos_total = float(
            df_single.loc[df_single["module"] != "BASELINE",
                          "delta_vs_baseline"].clip(lower=0).sum()
        )
        final_delta = float(df_stacked["sharpe"].iloc[-1] -
                            df_stacked["sharpe"].iloc[0])
        interaction = final_delta - pos_total
        self.assertTrue(np.isfinite(interaction),
                        f"interaction effect is not finite: {interaction}")
        # On the synthetic bench, the interaction should be non-zero
        # (modules overlap, cancel, or amplify). If it's exactly zero,
        # the blend logic is broken.
        self.assertNotEqual(
            round(interaction, 6), 0.0,
            f"interaction effect is exactly 0 — blend is not exercising "
            f"inter-module effects (final_delta={final_delta}, "
            f"pos_total={pos_total})",
        )

    def test_stacked_waterfall_respects_descending_lift_order(self):
        """The first module added must be the one with the highest
        single-module delta; the last one must be the lowest."""
        import tempfile
        r = self.synth(n_days=300, n_assets=5, seed=11)
        with tempfile.TemporaryDirectory() as tmp:
            out_dir = Path(tmp)
            df_single, _, _ = self.run_single(r, out_dir)
            df_stacked, _, _ = self.run_stacked(r, df_single, out_dir)
        # Single-module deltas (excluding BASELINE), sorted desc
        sm = df_single[df_single["module"] != "BASELINE"].sort_values(
            "delta_vs_baseline", ascending=False
        ).reset_index(drop=True)
        # Stacked module_added order (excluding BASELINE)
        stacked_order = df_stacked.loc[
            df_stacked["module_added"] != "BASELINE", "module_added"
        ].tolist()
        expected_order = sm["module"].tolist()
        self.assertEqual(stacked_order, expected_order,
                         "stacked enablement order is not descending-lift")


# ─────────────────────────────────────────────────────────────────────────
# CLI: source selection
# ─────────────────────────────────────────────────────────────────────────

class TestSourceSelection(unittest.TestCase):
    """main() should pick the source from CLI / env var correctly."""

    def setUp(self):
        try:
            from scripts.sharpe_lift_waterfall import _load_real_nse_returns
            self.loader = _load_real_nse_returns
        except Exception as e:
            self.skipTest(f"waterfall script import failed: {e}")

    def test_env_var_qa_wf_source_overrides_default(self):
        """Setting QA_WF_SOURCE=synthetic must change the source actually
        selected by the waterfall's source-selection logic.

        AUDIT-FIX (Round 5, 2-g-2): the previous body wrote an env var and
        read the same key back — a tautology testing os.environ, not the
        waterfall. Exercise the real selection helper if the script exposes
        one; otherwise skip LOUDLY instead of passing vacuously."""
        import os
        try:
            import scripts.sharpe_lift_waterfall as wf
        except Exception as e:
            self.skipTest(f"waterfall script import failed: {e}")
        select = getattr(wf, "_select_source", None)
        if not callable(select):
            self.skipTest(
                "scripts.sharpe_lift_waterfall does not export _select_source() — "
                "the env-var override path cannot be verified without executing "
                "main(); add a _select_source() helper to the script so this "
                "test can exercise it."
            )
        os.environ["QA_WF_SOURCE"] = "synthetic"
        try:
            self.assertEqual(select(), "synthetic")
            os.environ["QA_WF_SOURCE"] = "real"
            self.assertEqual(select(), "real")
        finally:
            del os.environ["QA_WF_SOURCE"]


if __name__ == "__main__":
    unittest.main()
