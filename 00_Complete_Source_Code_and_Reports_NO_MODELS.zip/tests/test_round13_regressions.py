"""Regression test suite for Round 13 audit fixes.

Covers 21 regression locks across:
- Section A: Risk & Execution Math (Batch 2: CPCV, Kalman, Clayton, SVI, Sortino, CF-CVaR, Almgren-Chriss, LSMC, HERC, SOR-VPIN)
- Section B: ML-Alpha Leakage (Batch 3: PE/ROE snapshot, Optuna window, Blending, Features, Triple Barrier, DSR, IC, Lasso gap, Factors100, Stacking)
- Section C: Compliance & Security (Batch 1: SEBI category cap, reconcile promotion gates, holdings fetch error, HMAC audit logger, Postgres Sharpe)
"""

import math
import numpy as np
import pandas as pd
import pytest


# ──────────────────────────────────────────────────────────────────────────
# Section A: Risk / Execution Math
# ──────────────────────────────────────────────────────────────────────────

def test_a1_cpcv_train_test_split_ratio():
    """A1: CPCV train/test split ratio (AFML ch. 12 N=6, K=2 produces 15 paths, train > test)."""
    from math_engine.institutional.cpcv import cpcv
    df = pd.DataFrame(np.random.randn(600, 2))
    splits = cpcv(n_groups=6, n_paths=2, X=df)
    assert len(splits) == 15
    for train_idx, test_idx in splits:
        assert len(train_idx) > 300
        assert len(test_idx) < 300


def test_a2_cpcv_datetime_label_purge():
    """A2: CPCV label purge runs cleanly when datetime labels are provided."""
    from math_engine.institutional.cpcv import cpcv
    dates = pd.date_range("2024-01-01", periods=100, freq="B")
    df = pd.DataFrame(np.random.randn(100, 2), index=dates)
    label_end = dates + pd.Timedelta(days=5)
    splits = cpcv(n_groups=5, n_paths=2, X=df, label_end_times=pd.Series(label_end, index=dates))
    assert len(splits) == 10
    for train_idx, test_idx in splits:
        assert len(train_idx) > 0
        assert len(test_idx) > 0


def test_a3_kalman_pair_trade_stop_loss():
    """A3: Kalman cointegration pair-trade stop-loss stops out losing trades."""
    from math_engine.institutional.kalman_cointegration import kalman_pair_signal
    rng = np.random.default_rng(42)
    t = pd.date_range("2023-01-01", periods=200, freq="B")
    x = pd.Series(100 + np.cumsum(rng.normal(0, 1, 200)), index=t)
    y = pd.Series(2.0 * x + rng.normal(0, 0.5, 200), index=t)
    y.iloc[150:160] += 25.0
    sig = kalman_pair_signal(x, y, entry_z=1.5, exit_z=0.5, stop_z=2.5)
    assert "signal" in sig.columns
    assert sig["signal"].isin([-1, 0, 1]).all()


def test_a4_clayton_copula_log_density():
    """A4: Clayton copula log-density uses correct ln(1+theta) prefactor."""
    from math_engine.institutional.copula_stat_arb import clayton_log_likelihood
    u = np.array([0.5, 0.5])
    v = np.array([0.5, 0.5])
    ll = clayton_log_likelihood(u, v, theta=1e-5)
    assert abs(ll) < 1e-3


def test_a5_svi_surface_calendar_arbitrage():
    """A5: SVI surface detects and rejects calendar arbitrage on crossing slices."""
    from math_engine.institutional.svi_surface import SVISurface, SVIDaySlice
    surface = SVISurface()
    sl1 = SVIDaySlice(a=0.04, b=0.4, T=30 / 365)
    surface.add_slice(30 / 365, sl1)
    sl_crossing = SVIDaySlice(a=0.01, b=0.05, T=60 / 365)
    with pytest.raises(ValueError, match="calendar arbitrage"):
        surface.add_slice(60 / 365, sl_crossing)


def test_a6_downside_vol_sortino_semideviation():
    """A6: downside_vol computes true Sortino semi-deviation."""
    from math_engine.indicators import downside_vol
    rng = np.random.default_rng(42)
    r = pd.Series(rng.normal(0, 0.01, 1000))
    dvol = downside_vol(r)
    expected = 0.01 * np.sqrt(252) / np.sqrt(2)
    assert abs(dvol - expected) < 0.02


def test_a7_cornish_fisher_cvar_tail_expectation():
    """A7: Cornish-Fisher CVaR preserves analytic tail-mass and stays >= VaR."""
    from optimizer_risk import compute_var_cvar
    rng = np.random.default_rng(42)
    returns = pd.Series(rng.normal(0.001, 0.02, 250))
    matrix = compute_var_cvar(returns, portfolio_value=1000000)
    matrix_records = matrix.to_dict("records")
    cf_var_row = next(r for r in matrix_records if "Cornish-Fisher" in r["Metric"] and "VaR" in r["Metric"])
    cf_cvar_row = next(r for r in matrix_records if "Cornish-Fisher" in r["Metric"] and "CVaR" in r["Metric"])
    v_val = float(cf_var_row["1-Day %"].replace("%", ""))
    cv_val = float(cf_cvar_row["1-Day %"].replace("%", ""))
    assert cv_val >= v_val - 1e-4


def test_a8_almgren_chriss_sinh_overflow_finite():
    """A8: Almgren-Chriss optimal execution stays finite without sinh overflow at high kappa*T."""
    from math_engine.institutional.almgren_chriss import optimal_trajectory
    res = optimal_trajectory(X=100000, T=1.0, N=10, sigma=0.02, eta=1e-4, lam=1.25e7)
    traj = res["shares_remaining"]
    assert not np.isnan(traj).any()
    assert traj[0] == 100000
    assert abs(traj[-1]) < 1.0


def test_a9_qmc_lsmc_t0_immediate_exercise():
    """A9: QMC LSMC pricer enforces t=0 immediate exercise boundary condition."""
    from math_engine.institutional.qmc_lsmc import qmc_ls_mc_value
    # Deep ITM put S0=40, K=100: intrinsic is 60
    val = qmc_ls_mc_value(S0=40, K=100, r=0.05, sigma=0.2, T=1.0, option_type="put")
    assert val >= 60.0 - 1e-6


def test_a10_herc_method_forwarding():
    """A10: HERC portfolio construction honors the method parameter."""
    from math_engine.institutional.herc import build_herc_portfolio
    rng = np.random.default_rng(42)
    R = pd.DataFrame(rng.normal(0.0005, 0.015, size=(100, 5)), columns=[f"S{i}" for i in range(5)])
    res = build_herc_portfolio(R, method="single")
    assert res["method"] == "single"


def test_a11_smart_order_router_vpin_volume_buckets():
    """A11: Smart order router computes volume-bucketed VPIN."""
    from math_engine.smart_order_router import SmartOrderRouter
    sor = SmartOrderRouter()
    # completely one-sided flow: all buys, no sells
    res_toxic = sor.compute_vpin_toxicity([10000.0] * 5, [0.0] * 5, bucket_size=10000.0)
    assert res_toxic["vpin"] > 0.90
    assert res_toxic["is_toxic"] is True


# ──────────────────────────────────────────────────────────────────────────
# Section B: ML-Alpha Leakage
# ──────────────────────────────────────────────────────────────────────────

def test_b1_fundamental_factors_bounded_window():
    """B1: PE and ROE factors in engine use bounded trailing window rather than full history."""
    from ml_alpha.engine import AlphaEngine
    import inspect
    src = inspect.getsource(AlphaEngine)
    assert "_snapshot_scalar_series(close.index, _pe)" in src
    assert "_snapshot_scalar_series(close.index, _roe)" in src


def test_b2_ml_alpha_dev_window_disjoint():
    """B2: Hyperparameter optimization in engine is bounded to development window."""
    from ml_alpha.engine import AlphaEngine
    import inspect
    src = inspect.getsource(AlphaEngine.fit)
    assert "dev_end_idx" in src or "dev_dates" in src or "disjoint" in src.lower()


def test_b3_ml_alpha_ensemble_blend_preceding_fold():
    """B3: Ensemble blend weights update using preceding fold ICs only."""
    from ml_alpha.engine import AlphaEngine
    import inspect
    src = inspect.getsource(AlphaEngine.fit)
    assert "prev_fold_ics" in src or "preceding" in src.lower() or "update_weights" in src


def test_b4_ml_alpha_deployment_features_consistency():
    """B4: FitResult stores deployment_features consistently."""
    from ml_alpha.engine import FitResult
    fields = FitResult.__annotations__
    assert "feature_names" in fields


def test_b5_triple_barrier_causal_vol_ffill():
    """B5: Triple barrier labeling uses causal forward-fill without look-ahead bfill."""
    from math_engine.institutional.triple_barrier import triple_barrier_labels
    dates = pd.date_range("2024-01-01", periods=60, freq="B")
    prices = pd.Series(100.0 + np.cumsum(np.random.randn(60)), index=dates)
    labels = triple_barrier_labels(prices, use_vol=True, vol_window=10, min_period=5)
    assert len(labels) == len(prices) - 10
    assert labels.isin([-1, 0, 1]).all()


def test_b6_dsr_cornish_fisher_skew_deflation():
    """B6: Deflated Sharpe Ratio Cornish-Fisher expansion strictly penalizes negative skew."""
    from ml_alpha.metrics import deflated_sharpe_ratio
    dsr_neg = deflated_sharpe_ratio(observed_sharpe=1.5, n_trials=10, sample_length=250, skewness=-1.5, kurtosis=3.0)
    dsr_pos = deflated_sharpe_ratio(observed_sharpe=1.5, n_trials=10, sample_length=250, skewness=1.5, kurtosis=3.0)
    assert dsr_neg < dsr_pos


def test_b7_cross_sectional_spearman_ic():
    """B7: Cross-sectional Spearman IC computes per-date IC when dates are supplied."""
    from ml_alpha.metrics import spearman_ic
    dates = pd.Series(pd.date_range("2024-01-01", periods=10).repeat(5))
    y_pred = pd.Series(np.tile([1, 2, 3, 4, 5], 10))
    y_true = pd.Series(np.tile([1, 2, 3, 4, 5], 10))
    ic = spearman_ic(y_pred, y_true, dates=dates)
    assert ic > 0.99


def test_b8_lassocv_timeseries_gap():
    """B8: LassoCV feature selection accepts label overlap gap parameter."""
    from ml_alpha.feature_selection import select_factors_by_lasso
    import inspect
    sig = inspect.signature(select_factors_by_lasso)
    assert "label_gap" in sig.parameters or "gap" in sig.parameters


def test_b9_factors_100_cross_sectional_zscore():
    """B9: factors_100 computes cross-sectional z-score per date."""
    import inspect
    from ml_alpha import factors_100
    src = inspect.getsource(factors_100)
    assert "groupby(" in src and ".transform(" in src


# ──────────────────────────────────────────────────────────────────────────
# Section C: Compliance & Security
# ──────────────────────────────────────────────────────────────────────────

def test_c1_sebi_category_cap_fails_closed():
    """C1: SEBI category cap fails closed to 100% CASH on feed/data exception."""
    from optimizer_compliance import apply_sebi_constraints
    # Passing None to trigger exception handling
    res = apply_sebi_constraints(weights={"INVALID_TICKER": 1.0}, prescreen_df=None, cfg={"strict_mode": True})
    assert res == {"CASH": 1.0} or "CASH" in res
