"""Round 16 regression suite.

Locks the two Round 16 work streams:

  Section A — Fix locks
    A1  Postgres SEC-5: Sharpe values must NEVER be written into the
        portfolio_return / benchmark_return columns (silent merge revert
        guard — this exact fix was reverted once already).
    A2  Backtest honesty (J3): the endpoint computes real metrics and the
        source contains no fabricated constants (2.45 / 0.950 / 68.4).
    A3  market_status honesty: no fabricated confidence constants.
    A4  FF radar honesty: no hardcoded portfolio/benchmark arrays.
    A5  New routes /api/kelly_sizing and /api/factor_exposure registered.

  Section B — New institutional module locks
    B1  FF5 factor construction (shape, PIT skip semantics, low-CS flag).
    B2  Fama-MacBeth (premia, NW lags, t-stat output).
    B3  factor_attribution (contributions + alpha ≈ total return).
    B4  Continuous Kelly closed form.
    B5  Kelly stack (caps monotonicity, DSR confidence bounds, provenance).
    B6  Drawdown first-passage cap (cap < raw; looser DD budget → larger f).
    B7  AFML sample weights (uniqueness, effective N).
    B8  Weighted meta-labeler + backward compatibility.
    B9  LTTB (extreme preservation, subset property, passthrough).
    B10 Legacy fractional_kelly contract (simplex + zero-edge fallback).
"""
from __future__ import annotations

import math
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

_QA_ROOT = Path(__file__).resolve().parent.parent
if str(_QA_ROOT) not in sys.path:
    sys.path.insert(0, str(_QA_ROOT))

APP_PY = _QA_ROOT / "web_dashboard" / "app.py"
DASH_JS = _QA_ROOT / "web_dashboard" / "dashboard.js"
PG_STORE = _QA_ROOT / "qa_db" / "postgres_store.py"


# ──────────────────────────────────────────────────────────────────────────
# Section A — Fix locks
# ──────────────────────────────────────────────────────────────────────────

def test_a1_postgres_sec5_no_sharpe_in_return_columns():
    """A1: The PG INSERT must keep return columns NULL (SEC-5/B13 semantics).

    This fix was silently reverted by a merge once — the regression lock
    inspects the actual tuple bound in postgres_store.py.
    """
    src = PG_STORE.read_text(encoding="utf-8")
    m = re.search(
        r"INSERT INTO oos_results[^;]*?VALUES\s*\(%s,\s*%s,\s*%s,\s*%s,\s*%s,\s*%s\).*?"
        r"""\(\s*run_id,\s*date,\s*(?P<p1>[^,]+),\s*(?P<p2>[^,]+),\s*(?P<p3>[^,]+),\s*(?P<p4>[^)]+)\)""",
        src, re.S)
    assert m, "oos_results INSERT tuple not found in postgres_store.py"
    assert m.group("p1").strip() == "None", f"portfolio_return must be NULL, got {m.group('p1')!r}"
    assert m.group("p2").strip() == "None", f"benchmark_return must be NULL, got {m.group('p2')!r}"
    # Sharpe columns must receive the Sharpe-valued variables
    assert m.group("p3").strip() == "bench_ret"
    assert m.group("p4").strip() == "port_ret"


def test_a1b_sqlite_b13_still_intact():
    """A1b: the SQLite path's B13 fix must remain (None, None, sharpe, sharpe)."""
    src = (_QA_ROOT / "qa_db" / "sqlite_store.py").read_text(encoding="utf-8")
    m = re.search(
        r"INSERT INTO oos_results.*?VALUES\s*\(\?,\s*\?,\s*\?,\s*\?,\s*\?,\s*\?\).*?"
        r"""\(\s*run_id,\s*date,\s*(?P<p1>[^,]+),\s*(?P<p2>[^,]+),\s*(?P<p3>[^,]+),\s*(?P<p4>[^)]+)\)""",
        src, re.S)
    assert m, "sqlite oos_results INSERT not found"
    assert m.group("p1").strip() == "None"
    assert m.group("p2").strip() == "None"
    assert m.group("p3").strip() == "bench_ret"
    assert m.group("p4").strip() == "port_ret"


def test_a2_backtest_no_fabricated_constants():
    """A2: J3 — the backtest handler must not contain the legacy fabricated
    metric constants, and must return real metric fields."""
    src = APP_PY.read_text(encoding="utf-8")
    # The old fake constants — match CODE patterns, not comment prose
    assert "avg_sharpe = 2.45" not in src, "fabricated OOS Sharpe restored"
    assert '"deflated_sharpe_ratio_dsr": 0.950' not in src, "fabricated DSR constant restored"
    assert "max_dd = -6.8" not in src, "fabricated drawdown restored"
    assert "win_rate = 68.4" not in src, "fabricated win-rate restored"
    # Real metric computation present
    for needle in ("sortino_ratio", "profit_factor", "information_ratio",
                   "policy_targets", "deflated_sharpe_ratio", "simulated"):
        assert needle in src, f"missing honest backtest field: {needle}"


def test_a2b_js_no_fabricated_oos_table():
    """A2b: dashboard.js must not invent Sortino/PF/IR/CAGR numbers."""
    src = DASH_JS.read_text(encoding="utf-8")
    for fake in ('const sortino = "3.12"', 'const pf = "2.34"', 'const ir = "1.85"',
                 'const cagr = "+28.4%"', "[100, 103, 107, 106, 112, 115, 118, 122]",
                 "sharpe: 1.84"):
        assert fake not in src, f"fabricated frontend value restored: {fake!r}"
    assert "SIMULATED PLACEHOLDER" in src, "simulated banner missing"
    assert "policy_targets" in src


def test_a3_market_status_no_fabricated_confidence():
    """A3: no invented confidence percentages in the market-status fallback."""
    src = APP_PY.read_text(encoding="utf-8")
    # Match dict-value code patterns, not explanatory comments
    assert '"confidence": "88.5%"' not in src, "fabricated snapshot confidence restored"
    assert '"confidence": "72.8%"' not in src, "fabricated no-data confidence restored"
    assert '"confidence": "unavailable"' in src, "honest no-data confidence missing"


def test_a4_ff_radar_no_hardcoded_arrays():
    """A4: the radar payload must be computed, not hardcoded."""
    src = APP_PY.read_text(encoding="utf-8")
    assert '"portfolio": [0.65, 0.42, 0.88, 0.35, 0.92]' not in src
    assert '"benchmark_nifty": [0.30, 0.50, 0.60, 0.55, 0.45]' not in src
    assert "benchmark_neutral" in src


def test_a5_new_routes_registered():
    """A5: Round 16 model endpoints are wired into the router."""
    src = APP_PY.read_text(encoding="utf-8")
    assert 'path == "/api/kelly_sizing"' in src
    assert 'path == "/api/factor_exposure"' in src
    assert "def _handle_kelly_sizing" in src
    assert "def _handle_factor_exposure" in src


# ──────────────────────────────────────────────────────────────────────────
# Section B — New module locks
# ──────────────────────────────────────────────────────────────────────────

def _make_panel(n_names=30, n_days=300, seed=11):
    rng = np.random.default_rng(seed)
    dates = pd.date_range("2022-07-01", periods=n_days, freq="B")
    tickers = [f"T{i}" for i in range(n_names)]
    rets = pd.DataFrame(rng.normal(0.0003, 0.014, (n_days, n_names)),
                        index=dates, columns=tickers)
    me = pd.DataFrame(np.exp(np.cumsum(rng.normal(0.0001, 0.01, (n_days, n_names)), axis=0)) * 1e9,
                      index=dates, columns=tickers)
    bm = pd.DataFrame(rng.uniform(0.2, 4.0, (n_days, n_names)), index=dates, columns=tickers)
    op = pd.DataFrame(rng.uniform(-0.1, 0.35, (n_days, n_names)), index=dates, columns=tickers)
    inv = pd.DataFrame(rng.uniform(-0.1, 0.3, (n_days, n_names)), index=dates, columns=tickers)
    return rets, me, bm, op, inv


def test_b1_ff5_construction_shape_and_semantics():
    from math_engine.institutional.ff5_factor_model import build_ff5_factors, FACTORS
    rets, me, bm, op, inv = _make_panel()
    ff5 = build_ff5_factors(rets, me, book_equity=bm, operating_profitability=op,
                            investment=inv, risk_free=0.0002)
    assert list(ff5.factors.columns) == list(FACTORS)
    assert ff5.factors.shape == (len(rets), 5)
    assert not ff5.factors[["MKT", "SMB", "HML", "RMW", "CMA"]].isna().any().any()
    assert ff5.n_names_median == 30.0

    # Missing characteristic → columns skipped (NaN), never fabricated
    ff5_partial = build_ff5_factors(rets, me, book_equity=bm, risk_free=0.0)
    assert ff5_partial.factors["HML"].notna().any()
    assert ff5_partial.factors["RMW"].isna().all(), "RMW fabricated without OP data"
    assert ff5_partial.factors["CMA"].isna().all(), "CMA fabricated without Inv data"

    # Tiny cross-section → honest skip with a note
    ff5_small = build_ff5_factors(rets.iloc[:, :4], me.iloc[:, :4], book_equity=bm.iloc[:, :4])
    assert ff5_small.factors["MKT"].isna().all()
    assert any("too small" in n for n in ff5_small.notes)


def test_b2_fama_macbeth_outputs():
    from math_engine.institutional.ff5_factor_model import build_ff5_factors, fama_macbeth
    rets, me, bm, op, inv = _make_panel()
    ff5 = build_ff5_factors(rets, me, bm, op, inv)
    fm = fama_macbeth(rets, ff5.factors)
    assert set(fm["premia"]) == {"const", "MKT", "SMB", "HML", "RMW", "CMA"}
    assert all(np.isfinite(v) for v in fm["tstats"].values())
    # NW rule of thumb on T=300: 4*(300/100)^(2/9) ≈ 5.1 → floor 5
    assert fm["nw_lags"] == 5
    # insufficient overlap degrades honestly
    fm_bad = fama_macbeth(rets.iloc[:5], ff5.factors.iloc[:5])
    assert "note" in fm_bad


def test_b3_attribution_decomposition_identity():
    from math_engine.institutional.ff5_factor_model import factor_attribution
    rng = np.random.default_rng(5)
    n = 300
    idx = pd.date_range("2022-07-01", periods=n, freq="B")
    # Genuinely varying factors (daily frequency) — the annual-constant FF5
    # construction would be collinear with the intercept.
    F = pd.DataFrame({
        "MKT": rng.normal(0.0004, 0.010, n),
        "SMB": rng.normal(0.0001, 0.006, n),
        "HML": rng.normal(-0.00005, 0.005, n),
    }, index=idx)
    port = pd.Series(1.2 * F["MKT"] + 0.5 * F["SMB"]
                     + rng.normal(0, 0.001, n), index=idx)
    res = factor_attribution(port, F, rf=0.0)
    assert abs(res["betas"]["MKT"] - 1.2) < 0.05
    assert abs(res["betas"]["SMB"] - 0.5) < 0.05
    assert abs(res["betas"]["HML"]) < 0.05
    # alpha + factor contributions ≈ total annualized return (exact OLS
    # identity: with an intercept the residual mean is zero)
    total = res["alpha_annual"] + sum(res["factor_contributions_annual"].values())
    assert abs(total - res["total_annual_return"]) < 1e-6
    assert 0.0 <= res["r_squared"] <= 1.0


def test_b4_continuous_kelly_closed_form():
    from math_engine.institutional.kelly_betting import continuous_kelly
    # f* = (mu - r)/sigma^2 = 0.15/0.04 = 3.75
    assert abs(continuous_kelly(mu=0.15, sigma=0.20) - 3.75) < 1e-9
    # with risk-free 6.5%: (0.10-0.065)/0.04 = 0.875
    assert abs(continuous_kelly(mu=0.10, sigma=0.20, risk_free=0.065) - 0.875) < 1e-9
    # no edge → 0 (never negative Kelly)
    assert continuous_kelly(mu=0.01, sigma=0.20, risk_free=0.03) == 0.0
    # series input with insufficient history → None (honest refusal)
    assert continuous_kelly(returns=pd.Series([0.01, 0.02])) is None


def test_b5_kelly_stack_provenance_and_bounds():
    from math_engine.institutional.kelly_betting import kelly_position_size
    rng = np.random.default_rng(9)
    # Genuine edge: daily SR ~ 0.10 → annual ~ 1.6
    r = pd.Series(rng.normal(0.0008, 0.008, 400))
    res = kelly_position_size(r, n_trials=4)
    assert 0.0 <= res["position_fraction"] <= 0.25 * 5.0  # ≤ frac × raw
    assert 0.0 <= res["dsr_confidence"] <= 1.0
    assert res["binding_constraint"] in (
        "no_edge", "dsr_confidence_zero", "dsr_confidence", "drawdown_cap",
        "vol_target", "kelly_fraction_overlay", "insufficient_history")
    assert res["n_obs"] == 400
    # pipeline monotone: each stage ≤ the previous
    assert res["kelly_after_drawdown_cap"] <= res["kelly_after_confidence"] + 1e-9
    # insufficient history refuses to size
    thin = kelly_position_size(pd.Series(rng.normal(0.001, 0.01, 10)))
    assert thin["position_fraction"] == 0.0
    assert thin["binding_constraint"] == "insufficient_history"


def test_b6_drawdown_cap_monotonicity():
    from math_engine.institutional.kelly_betting import drawdown_capped_kelly
    f_raw = 2.0
    f20 = drawdown_capped_kelly(f_raw, 0.20, dd_max=0.20, confidence=0.95)
    f30 = drawdown_capped_kelly(f_raw, 0.20, dd_max=0.30, confidence=0.95)
    f90 = drawdown_capped_kelly(f_raw, 0.20, dd_max=0.90, confidence=0.95)
    assert 0 < f20 < f30 <= f90 <= f_raw
    # zero raw Kelly → zero cap
    assert drawdown_capped_kelly(0.0, 0.2) == 0.0


def test_b7_afml_sample_weights():
    from ml_alpha.sample_weights import (average_uniqueness, concurrency,
                                         effective_sample_size, build_sample_weights)
    t0 = pd.Series(pd.to_datetime(["2024-01-01", "2024-01-02", "2024-01-05", "2024-02-01"]))
    t1 = pd.Series(pd.to_datetime(["2024-01-10", "2024-01-10", "2024-01-06", "2024-02-20"]))
    u = average_uniqueness(t0, t1)
    assert u.iloc[3] == 1.0, "isolated event must be perfectly unique"
    assert u.iloc[0] < 1.0 and u.iloc[1] < 1.0, "overlapped events must be down-weighted"
    assert int(concurrency(t0, t1).max()) == 3  # Jan 5: all three open
    eff = effective_sample_size(u)
    assert 1 < eff < len(u), "effective N must reflect overlap redundancy"
    bw = build_sample_weights(t0, t1, scheme="uniqueness_decay")
    assert abs(float(bw["weights"].mean()) - 1.0) < 1e-9  # mean-1 normalization
    assert bw["effective_n"] == eff


def test_b8_weighted_meta_labeler_and_compat():
    from math_engine.institutional.triple_barrier import fit_meta_labeler
    rng = np.random.default_rng(3)
    n = 200
    idx = pd.date_range("2024-01-01", periods=n, freq="B")
    X = pd.DataFrame(rng.normal(0, 1, (n, 4)), index=idx,
                     columns=[f"f{i}" for i in range(4)])
    y = pd.Series((rng.uniform(size=n) > 0.6).astype(int), index=idx)
    t0 = pd.Series(list(idx))
    durs = rng.integers(2, 15, n)
    t1 = pd.Series([idx[i] + pd.Timedelta(days=int(d)) for i, d in enumerate(durs)])

    res = fit_meta_labeler(X, y, model_type="logistic", cv_folds=4,
                           event_start=t0, event_end=t1)
    assert res["sample_weights"] is not None
    assert res["effective_n"] is not None and res["effective_n"] < n
    assert res["mean_uniqueness"] is not None and 0 < res["mean_uniqueness"] <= 1

    # Backward compatibility: no events → no weights, still fits
    res2 = fit_meta_labeler(X, y, model_type="logistic", cv_folds=4)
    assert res2["sample_weights"] is None
    assert "oos_score" in res2


def test_b9_lttb_extreme_preservation():
    from math_engine.institutional.lttb import lttb, lttb_indices, lttb_series
    n = 250
    y = np.zeros(n)
    y[37] = 10.0
    y[150] = -8.0
    idx = lttb_indices(n, 60, y)
    assert 37 in idx and 150 in idx, "LTTB must keep drawdown/peak extremes"
    assert len(idx) <= 60

    # subset property: output values ⊂ input values
    xd, yd = lttb(np.arange(100.0), np.arange(100.0), 20)
    assert set(np.round(yd, 6)).issubset(set(np.arange(100.0)))

    # threshold ≥ n → passthrough
    s = pd.Series(np.sin(np.arange(100.0)))
    out = lttb_series(s, 100)
    assert len(out) == 100

    # series preserves index alignment (subset rows)
    s2 = pd.Series(y, index=pd.date_range("2024-01-01", periods=n, freq="D"))
    sd = lttb_series(s2, 60)
    assert sd.max() == 10.0 and sd.min() == -8.0
    assert len(sd) <= 60


def test_b10_legacy_fractional_kelly_contract():
    from math_engine.risk_budgeting_solver import fractional_kelly_covariance
    mu = np.array([0.001, 0.0012, 0.0008])
    cov = np.array([[4e-4, 1e-4, 5e-5], [1e-4, 9e-4, 2e-5], [5e-5, 2e-5, 1.6e-4]])
    w = fractional_kelly_covariance(mu, cov)
    assert np.all(w >= 0) and np.isclose(w.sum(), 1.0)
    # zero edge → equal weight fallback (legacy behavior)
    w2 = fractional_kelly_covariance(np.zeros(3), cov)
    assert np.allclose(w2, 1.0 / 3.0)
