"""
Round 17 Regression Tests — Fabrication Elimination Lock
=========================================================
These tests lock in the honest-null policy adopted in Round 17.
They detect any future reversion that re-introduces hardcoded fabrications
into the web dashboard API endpoints.
"""
import ast
import sys
import re
import pytest

APP_PATH = "web_dashboard/app.py"
JS_PATH = "web_dashboard/dashboard.js"


def _read(path):
    with open(path, "r") as f:
        return f.read()


def _live_code_lines(path, ext=".py"):
    """Return only non-comment, non-docstring lines (best-effort)."""
    lines = _read(path).splitlines()
    live = []
    in_docstring = False
    docstring_char = None
    for line in lines:
        stripped = line.strip()
        if in_docstring:
            if docstring_char in stripped:
                in_docstring = False
            continue
        if stripped.startswith('"""') or stripped.startswith("'''"):
            char = '"""' if stripped.startswith('"""') else "'''"
            # single-line docstring
            if stripped.count(char) >= 2 and len(stripped) > 6:
                continue
            in_docstring = True
            docstring_char = char
            continue
        if ext == ".py" and stripped.startswith("#"):
            continue
        if ext == ".js" and (stripped.startswith("//") or stripped.startswith("*")):
            continue
        live.append(line)
    return "\n".join(live)


class TestR17FabricationElimination:
    """A1–A10: No fabricated constants in live executable code."""

    def _assert_not_in_live(self, pattern, label, path=APP_PATH, ext=".py"):
        live = _live_code_lines(path, ext)
        assert pattern not in live, (
            f"REGRESSION (Round 17): '{label}' re-introduced in {path}. "
            f"Pattern: {pattern!r}"
        )

    # ── app.py checks ────────────────────────────────────────────────────────

    def test_a1_no_ppo_twap_agent(self):
        self._assert_not_in_live('"agent": "PPO-TWAP-v3"', "fake RL agent name")

    def test_a2_no_fake_slippage_14_2(self):
        self._assert_not_in_live('"slippage_reduction_bps": 14.2', "fake slippage_reduction_bps=14.2")

    def test_a3_no_fake_market_impact_68_4(self):
        self._assert_not_in_live('"market_impact_mitigation_%": 68.4', "fake market_impact=68.4")

    def test_a4_no_fake_win_rate_68_4_fallback(self):
        self._assert_not_in_live('win_rate_%": 68.4', "fabricated win_rate_%=68.4 in exception fallback")

    def test_a5_no_fake_profit_factor_2_45_fallback(self):
        self._assert_not_in_live('profit_factor": 2.45', "fabricated profit_factor=2.45 in exception fallback")

    def test_a6_no_fake_nlp_score_0_88(self):
        self._assert_not_in_live('nlp_score": 0.88', "hardcoded nlp_score=0.88")

    def test_a7_no_fake_hawkish_expansion(self):
        self._assert_not_in_live('"HAWKISH / EXPANSION"', "hardcoded management_tone HAWKISH/EXPANSION")

    def test_a8_no_fake_240_accumulation(self):
        self._assert_not_in_live('"+240% (INSTITUTIONAL ACCUMULATION)"', "hardcoded +240% social velocity")

    def test_a9_no_capex_commissioning_template(self):
        self._assert_not_in_live('"Capex commissioning on schedule', "boilerplate Capex transcript")

    def test_a10_no_port_turnover_hardcoded_1_65(self):
        self._assert_not_in_live('port_turnover_z = 1.65', "hardcoded port_turnover_z=1.65")

    def test_a11_no_bench_mom_z_0_28(self):
        self._assert_not_in_live('bench_mom_z = 0.28', "hardcoded bench_mom_z=0.28 (wrong benchmark definition)")

    def test_a12_no_bench_qual_z_0_45(self):
        self._assert_not_in_live('bench_qual_z = 0.45', "hardcoded bench_qual_z=0.45")

    def test_a13_no_bench_lowvol_z_0_15(self):
        self._assert_not_in_live('bench_lowvol_z = 0.15', "hardcoded bench_lowvol_z=0.15")

    def test_a14_no_bench_turnover_z_0_85(self):
        self._assert_not_in_live('bench_turnover_z = 0.85', "hardcoded bench_turnover_z=0.85")

    def test_a15_no_cost_drag_12_4_literal(self):
        self._assert_not_in_live('cost_drag_bps": 12.4', "hardcoded cost_drag_bps=12.4")

    def test_a16_no_delivery_conviction_68_4(self):
        self._assert_not_in_live('delivery_conviction_%": 68.4', "hardcoded delivery_conviction=68.4")

    def test_a17_no_ofi_base_vol_120000_in_code(self):
        self._assert_not_in_live('base_vol = 120_000 if px', "fabricated OFI base_vol=120000 formula")

    def test_a18_no_arbitrage_idx_formula(self):
        self._assert_not_in_live('spread_pct = 0.0012 + (idx', "fabricated arbitrage spread formula idx*0.0004")

    def test_a19_no_auditor_fee_growth_formula(self):
        self._assert_not_in_live('aud_growth_val = round(1.2 +', "synthetic auditor fee growth formula")

    # ── dashboard.js checks ──────────────────────────────────────────────────

    def test_b1_no_hardcoded_attribution_chart_data(self):
        self._assert_not_in_live(
            'data: [210, 385, 47, 642]',
            "hardcoded attribution chart [210,385,47,642]",
            path=JS_PATH, ext=".js"
        )

    def test_b2_no_slice_6_truncation_in_correlation_table(self):
        self._assert_not_in_live(
            'allocList.slice(0, 6)',
            ".slice(0,6) truncation on correlation table",
            path=JS_PATH, ext=".js"
        )

    def test_b3_no_slice_8_truncation_in_mrc_table(self):
        self._assert_not_in_live(
            'allocList.slice(0, 8)',
            ".slice(0,8) truncation on MRC table",
            path=JS_PATH, ext=".js"
        )


class TestR17HonestNullPolicy:
    """B-series: Verify endpoints now return null for unavailable data."""

    def test_b4_rl_execution_returns_null_agent(self):
        """_handle_rl_execution must not set a non-null agent string."""
        content = _read(APP_PATH)
        # Find _handle_rl_execution block
        match = re.search(r'def _handle_rl_execution.*?(?=\n    def )', content, re.DOTALL)
        assert match, "_handle_rl_execution not found"
        block = match.group(0)
        assert '"agent": None' in block or '"agent": null' in block.lower(), (
            "REGRESSION: _handle_rl_execution must set agent=None (not a fake agent name)"
        )

    def test_b5_sentiment_velocity_no_hardcoded_score(self):
        """_handle_sentiment_velocity must not assign a numeric nlp_score literal."""
        content = _read(APP_PATH)
        match = re.search(r'def _handle_sentiment_velocity.*?(?=\n    def )', content, re.DOTALL)
        assert match, "_handle_sentiment_velocity not found"
        block = match.group(0)
        # No numeric assignment like nlp_score": 0.xx
        assert not re.search(r'"nlp_score":\s*[0-9]', block), (
            "REGRESSION: _handle_sentiment_velocity assigns a numeric nlp_score"
        )

    def test_b6_benchmark_z_scores_are_zero(self):
        """Factor tilts benchmark must use an HONEST neutral baseline.

        R17 contract: the benchmark Z must never be a fabricated constant
        (the Round 16 form hardcoded 0.28/0.45/0.15/0.85).

        R50 UPDATE (supersession of the literal-0.0 form): the live
        _handle_factor_tilts now reports the benchmark factors as an HONEST
        NULL (bench_*_z = None, rendered "—") rather than 0.0. Rationale:
        the portfolio Z-scores are measured against the SCREENING-UNIVERSE
        cross-section, but the benchmark the dashboard names is a
        cap-weighted NIFTY 500 — whose own factor exposures are NOT
        definitionally zero against that cross-section (an equal-weight
        universe mean is not the cap-weighted index). Asserting 0.0 implied
        a measured value that was never measured; None discloses that a
        dedicated index factor model is not active. The spread vs the
        universe baseline remains the portfolio Z itself (mu = 0).
        """
        content = _read(APP_PATH)
        match = re.search(r'def _handle_factor_tilts.*?(?=\n    def )', content, re.DOTALL)
        assert match, "_handle_factor_tilts not found"
        block = match.group(0)
        # The honest-null contract: all four benchmark Zs are None until a
        # dedicated cap-weighted index factor model is active (the code
        # comment discloses exactly this).
        assert 'bench_mom_z = None' in block, "REGRESSION: bench_mom_z must be the honest null (None), not a fabricated constant"
        assert 'bench_qual_z = None' in block, "REGRESSION: bench_qual_z must be the honest null (None)"
        assert 'bench_lowvol_z = None' in block, "REGRESSION: bench_lowvol_z must be the honest null (None)"
        assert 'bench_turnover_z = None' in block, "REGRESSION: bench_turnover_z must be the honest null (None)"
        # And the historical fabrication must stay dead: none of the old
        # hardcoded constants may return.
        for fabricated in ('bench_mom_z = 0.28', 'bench_qual_z = 0.45',
                           'bench_lowvol_z = 0.15', 'bench_turnover_z = 0.85'):
            assert fabricated not in block, f"REGRESSION: fabricated benchmark constant returned: {fabricated}"

    def test_b7_attribution_chart_reads_risk_suite(self):
        """Attribution chart must read from window.__lastRiskSuite, not hardcoded."""
        js = _read(JS_PATH)
        assert 'window.__lastRiskSuite' in js, (
            "REGRESSION: attribution chart no longer reads from window.__lastRiskSuite"
        )
        assert '__lastRiskSuite = data.risk_suite' in js, (
            "REGRESSION: risk_suite no longer stored in window.__lastRiskSuite after optimize"
        )
