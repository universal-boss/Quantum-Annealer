"""Regression tests verifying elimination of hardcoded stocks and fallback arrays."""
from pathlib import Path
import re

QA_ROOT = Path(__file__).resolve().parent.parent
APP_PY = QA_ROOT / "web_dashboard" / "app.py"
DASH_JS = QA_ROOT / "web_dashboard" / "dashboard.js"

def test_no_hardcoded_pairs_in_app():
    src = APP_PY.read_text(encoding="utf-8")
    m = re.search(r"def _handle_pairs_trading.*?(?=\n    def )", src, re.DOTALL)
    assert m, "pairs_trading handler not found"
    block = m.group(0)
    for pair in ["HDFCBANK / ICICIBANK", "TCS / INFY", "RELIANCE / ONGC", "TATASTEEL / JSWSTEEL"]:
        assert pair not in block, f"Hardcoded pair {pair} found in _handle_pairs_trading"

def test_no_hardcoded_options_spot_in_app():
    src = APP_PY.read_text(encoding="utf-8")
    m = re.search(r"def _handle_options_surface.*?(?=\n    def )", src, re.DOTALL)
    assert m, "options_surface handler not found"
    block = m.group(0)
    assert "24580.0" not in block, "Hardcoded spot price 24580.0 found"
    assert "24600.0" not in block, "Hardcoded max pain strike 24600.0 found"

def test_no_hardcoded_ticker_fallbacks_in_app():
    src = APP_PY.read_text(encoding="utf-8")
    assert '"NSE:ASTRAMICRO"' not in src, "Hardcoded NSE:ASTRAMICRO fallback found in app.py"

def test_no_hardcoded_tickers_array_in_dashboard_js():
    js = DASH_JS.read_text(encoding="utf-8")
    assert '["ITC", "ASIANPAINT", "WIPRO", "MARUTI", "OIL", "WELSPUNLIV", "TRENT", "BEL"]' not in js, \
        "Hardcoded fallback tickers array found in dashboard.js"
    assert "0.30 * Math.sin" not in js, "Fake sinusoidal correlation matrix found in dashboard.js"
