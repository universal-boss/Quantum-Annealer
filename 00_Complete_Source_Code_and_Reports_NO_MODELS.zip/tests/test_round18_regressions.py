"""Round 18 regression suite.

Locks the Round 18 work streams:

  Section A — Fabrication-elimination locks (pattern-level, stronger than
              literal-string locks: they catch formula fabrications and
              fallback constants, not just the exact old strings)
    A1  optimize paths: no Sharpe floor formula, no 14.8*beta vol, no
        210/385/47 attribution constants, no linear DTL formula.
    A2  Barra .get() fallback defaults eliminated in BOTH risk-suite paths.
    A3  Lifecycle exception fallback carries no invented verdict/metrics.
    A4  get_active_holdings / get_candidate_universe inject no fabricated
        fundamentals (4.5/7/0.20; 0.75/0.15/3.8/8; price 100; snell 118).
    A5  block_deals fabricates no fund names / dates / quantities.
    A6  brokers status: no hardcoded CONNECTED + invented latencies.
    A7  macro_events / intermarket / nlp radar / microstructure honesty.
    A8  paper orders require a real price (no stale 189.22 default).
    A9  per-stock fundamentals are not derived from volatility formulas.
    A10 governance AAA requires KNOWN-zero pledge (unknown != clean).

  Section B — New math locks
    B1  /api/dcc_garch_risk route registered; FHS-DCC-GARCH math on a
        synthetic panel is finite, positive, and self-consistent.
    B2  DCC stack refuses (None) when the price feed is offline.
    B3  kelly_sizing carries the regime overlay block.
    B4  factor tilts: true cross-sectional Z-score semantics; formula
        patterns gone (backend AND the renderDynamicTabs JS twin).
    B5  JS display honesty: no Number(null) fake zeros / || 0.18 defaults.

  Section C — R16/R17 fixes survive Round 18 (no re-regression).
"""
from __future__ import annotations

import importlib.util
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

_QA_ROOT = Path(__file__).resolve().parent.parent
if str(_QA_ROOT) not in sys.path:
    sys.path.insert(0, str(_QA_ROOT))

APP_PY = _QA_ROOT / "web_dashboard" / "app.py"
DASH_JS = _QA_ROOT / "web_dashboard" / "dashboard.js"


def _app_source() -> str:
    return APP_PY.read_text(encoding="utf-8")


def _live_app() -> str:
    """App source with docstrings and comments stripped (live code only).

    Pattern locks must never fire on AUDIT-FIX documentation that DESCRIBES
    a removed fabrication.
    """
    src = _app_source()
    out, in_doc = [], False
    for line in src.splitlines():
        s = line.strip()
        if in_doc:
            if '"""' in s:
                in_doc = False
            continue
        if s.startswith('"""'):
            if s.count('"""') >= 2:
                continue
            in_doc = True
            continue
        if s.startswith("#"):
            continue
        out.append(line)
    return "\n".join(out)


def _js_source() -> str:
    return DASH_JS.read_text(encoding="utf-8")


def _live_js() -> str:
    """JS source without // comments (AUDIT-FIX notes excluded from locks)."""
    return "\n".join(
        l for l in _js_source().splitlines()
        if not l.strip().startswith("//")
    )


# ──────────────────────────────────────────────────────────────────────────
# Section A — Fabrication-elimination locks
# ──────────────────────────────────────────────────────────────────────────

class TestA18FabricationLocks:
    def test_a1_optimize_paths_no_formula_fabrications(self):
        live = _live_app()
        for pattern in [
            "max(1.85, 2.76",                        # Sharpe floor formula
            "14.8 * avg_beta",                       # vol = 14.8*beta
            "14.8 * max(0.4",                        # profile-path vol formula
            "210.0 * (1.0 /",                        # alloc attribution constant
            "385.0 * (1.0 /",                        # select attribution constant
            "0.20 + (len(results) * 0.015",          # linear DTL
            "0.20 + (len(portfolio_positions) * 0.015",  # profile-path DTL
            "-16.42 - (len(results) * 0.25)",        # fabricated energy
        ]:
            assert pattern not in live, (
                f"REGRESSION (R18-A1): fabrication formula re-introduced: {pattern!r}")

    def test_a2_barra_fallback_defaults_gone(self):
        live = _live_app()
        for pattern in [
            '"barra_r2", 0.842',
            '"systematic_risk_%", 68.5',
            '"specific_risk_%", 31.5',
            '"shrinkage_weight_v", 0.807',
        ]:
            assert pattern not in live, (
                f"REGRESSION (R18-A2): Barra fallback default re-introduced: {pattern!r}")

    def test_a3_lifecycle_fallback_no_invented_verdict(self):
        live = _live_app()
        m = re.search(
            r"Lifecycle calculation unavailable.*?hjb_optimal_unwind_days",
            live, re.DOTALL)
        assert m, "R18-A3: honest lifecycle fallback block not found"
        block = m.group(0)
        for bad in ["SAFE_ACCUMULATION", "PRIME_QUALITY", "42.5", "3.42",
                    "0.42", "0.21", "18.4"]:
            assert bad not in block, (
                f"REGRESSION (R18-A3): fabricated lifecycle value {bad!r} re-introduced")
        assert "UNAVAILABLE" in block, "R18-A3: fallback must carry an UNAVAILABLE status"

    def test_a4_holdings_and_universe_no_fabricated_fundamentals(self):
        live = _live_app()
        for bad in [
            '"altman_z": 4.5',
            '"piotroski_f": 7,',
            '"vpin_toxicity": 0.20',
            '"Market Beta (\u03b2)": 0.75,',
            '"VPIN Toxicity": 0.15,',
            '"Altman Z-Score": 3.8,',
            '"Piotroski F-Score": 8,',
            '"Snell Target Price (\u20b9)": 118.0',
            '"Stop Loss Price (\u20b9)": 95.0',
            '"Current Price (\u20b9)": 100.0',
        ]:
            assert bad not in live, (
                f"REGRESSION (R18-A4): fabricated fallback re-introduced: {bad!r}")

    def test_a5_block_deals_no_fabricated_flow(self):
        live = _live_app()
        m = re.search(r"def _handle_block_deals.*?(?=\n    def )", live, re.DOTALL)
        assert m, "R18-A5: block deals handler not found"
        block = m.group(0)
        for bad in ["Goldman Sachs India Equity Fund", "Nippon India Small Cap Fund",
                    "Kotak Emerging Equity Fund", "idx % 5", "del_spike / 7.5"]:
            assert bad not in block, (
                f"REGRESSION (R18-A5): fabricated block-deal machinery re-introduced: {bad!r}")
        # R20 contract upgrade: the panel now serves REAL deals read from the
        # on-disk NSE bulk-deal raw history (optimizer-maintained) — empty list
        # when no local history matches. Lock the honest-empty *initialization*
        # plus the real-data-only population (no invented deals anywhere).
        assert "deals = []" in block, "R18-A5: honest empty initialization missing"
        assert 'deals[:8]' in block, "R18-A5: bounded real-deal response missing"
        assert "bulk_deals_raw_history.json" in block, (
            "R20-A5: block deals must come from the local NSE raw-deal history")

    def test_a6_brokers_status_no_hardcoded_connectivity(self):
        live = _live_app()
        m = re.search(r"def _handle_brokers_status.*?(?=\n    def )", live, re.DOTALL)
        assert m, "R18-A6: brokers status handler not found"
        block = m.group(0)
        assert '"latency_ms": None' in block, "R18-A6: latency must be null (no ping protocol)"
        assert "conn.connect()" in block, "R18-A6: must actually probe the connectors"
        assert "latency_ms\": 12" not in block, "R18-A6: invented latency re-introduced"

    def test_a7_static_panels_labeled_or_null(self):
        live = _live_app()
        m = re.search(r"def _handle_macro_events.*?(?=\n    def )", live, re.DOTALL)
        assert m and '"date": None' in m.group(0), "R18-A7: macro calendar dates must be null"
        m = re.search(r"def _handle_global_intermarket.*?(?=\n    def )", live, re.DOTALL)
        assert m and "data_source" in m.group(0), "R18-A7: intermarket matrix must carry a data_source label"
        m = re.search(r"def _handle_nlp_sentiment_radar.*?(?=\n    def )", live, re.DOTALL)
        assert m and '"filing_catalysts": []' in m.group(0), "R18-A7: NLP radar must not fabricate filings"
        m = re.search(r"def _handle_microstructure_live_ofi.*?(?=\n    def )", live, re.DOTALL)
        assert m and '"hawkes_intensity": None' in m.group(0), "R18-A7: microstructure must not report empty-engine state"

    def test_a8_paper_order_requires_price(self):
        live = _live_app()
        m = re.search(r"def _handle_execute_paper_order.*?(?=\n    def )", live, re.DOTALL)
        assert m, "R18-A8: paper order handler not found"
        block = m.group(0)
        assert 'params.get("price", 189.22)' not in block, "R18-A8: stale default price re-introduced"
        assert "px = float(params.get" not in block, "R18-A8: unconditional price default re-introduced"
        assert "price required" in block, "R18-A8: missing-price refusal missing"

    def test_a9_no_fundamentals_from_volatility(self):
        live = _live_app()
        for pattern in [
            "vol / 0.22",                    # beta from vol
            "8 if vol < 0.35 else 7",        # Piotroski from vol
            "3.5 + (1.0 - min(vol, 0.6))",   # Altman from vol
            '25_000_000.0',                  # ADV default
        ]:
            assert pattern not in live, (
                f"REGRESSION (R18-A9): fundamentals-from-volatility re-introduced: {pattern!r}")

    def test_a10_governance_aaa_requires_known_clean_pledge(self):
        live = _live_app()
        m = re.search(r"def _handle_governance_flags.*?(?=\n    def )", live, re.DOTALL)
        assert m, "R18-A10: governance handler not found"
        block = m.group(0)
        assert "_pledge_known_clean" in block, "R18-A10: AAA must require KNOWN-zero pledge"


# ──────────────────────────────────────────────────────────────────────────
# Section B — New math locks
# ──────────────────────────────────────────────────────────────────────────

def _load_app_module():
    spec = importlib.util.spec_from_file_location("qa_app_r18", str(APP_PY))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


class TestB18DccGarchRisk:
    def _synthetic_panel(self, n=400, m=4, seed=7):
        rng = np.random.default_rng(seed)
        base = rng.standard_normal((n, m)) * 0.012
        L = np.linalg.cholesky(np.full((m, m), 0.35) + np.eye(m) * 0.65)
        return pd.DataFrame(base @ L.T, columns=[f"A{i}" for i in range(m)])

    def test_b1_dcc_payload_finite_and_consistent(self):
        rets = self._synthetic_panel()
        from math_engine.institutional.fhs_dcc_garch import fit_dcc_garch_gmm, fhs_var_es
        dcc = fit_dcc_garch_gmm(rets)
        w = np.full(rets.shape[1], 1.0 / rets.shape[1])
        r99 = fhs_var_es(dcc, w, alpha=0.99, n_sim=4000, horizon=1)
        r975 = fhs_var_es(dcc, w, alpha=0.975, n_sim=4000, horizon=1)
        assert np.isfinite(r99["var"]) and r99["var"] > 0
        assert np.isfinite(r99["es"]) and r99["es"] >= r99["var"]   # ES beyond VaR
        assert np.isfinite(r975["es"])
        assert 0 < r975["es"] < r99["es"]                            # lower alpha -> smaller ES
        # ES ordering sanity across alphas and route registration
        assert "/api/dcc_garch_risk" in _app_source()

    def test_b2_dcc_offline_refusal(self, monkeypatch):
        mod = _load_app_module()
        monkeypatch.setattr(
            "data_layer.YFinanceProvider.get_prices",
            lambda self, syms, period="1y": pd.DataFrame(),
            raising=True,
        )
        mod.AgenticDesktopBridge._DCC_CACHE.clear()
        out = mod.AgenticDesktopBridge.compute_dcc_garch_risk()
        assert out is None, "R18-B2: DCC must refuse (None) when the feed is offline"

    def test_b2b_dcc_synthetic_computation(self, monkeypatch):
        """With a stubbed feed the stack computes real finite numbers end-to-end."""
        mod = _load_app_module()
        H = mod.AgenticDesktopBridge
        H._DCC_CACHE.clear()
        rets = self._synthetic_panel(n=300, m=3)
        close = np.exp(np.cumsum(rets.values, axis=0))
        monkeypatch.setattr(
            "data_layer.YFinanceProvider.get_prices",
            lambda self, syms, period="1y": pd.DataFrame(
                close, columns=list(syms)),
            raising=True,
        )
        monkeypatch.setattr(
            mod.AgenticDesktopBridge, "get_active_holdings",
            classmethod(lambda cls: [
                {"ticker": f"{s}.NS", "weight_pct": 33.3} for s in rets.columns]),
            raising=True,
        )
        out = H.compute_dcc_garch_risk(min_obs=120, n_sim=2000)
        assert out is not None, "R18-B2b: DCC computation unexpectedly failed"
        assert out["status"] == "OK"
        assert 0 < out["var_99_1d_pct"] < 25        # sane daily VaR bound
        assert out["es_99_1d_pct"] >= out["var_99_1d_pct"]
        assert 0 < out["es_97_5_1d_pct"] <= out["es_99_1d_pct"]
        assert out["portfolio_vol_annualized_pct"] > 0
        assert len(out["correlation_matrix_next"]) == 3

    def test_b3_kelly_regime_overlay_present(self):
        src = _app_source()
        assert "regime_overlay" in src, "R18-B3: kelly response must carry the regime overlay"
        assert "sizing_multiplier" in src

    def test_b4_factor_tilts_cross_z(self):
        live = _live_app()
        for bad in ["max(0.65, w_mom)", "1.10 + (w_piot - 5.0)", "1.0 + (1.0 - w_beta)"]:
            assert bad not in live, f"R18-B4: formula Z re-introduced: {bad!r}"
        # true Z semantics
        universe = list(np.linspace(0.5, 2.5, 60))
        port_val = 3.5
        mu, sd = float(np.mean(universe)), float(np.std(universe))
        assert (port_val - mu) / sd > 2.0      # extreme portfolio -> large |Z|
        assert (mu - mu) / sd == 0.0           # universe-mean portfolio -> Z=0
        # the JS twin (renderDynamicTabs) must also be formula-free
        js = _live_js()
        for bad in ["Math.max(0.65, sumZ / sumW)",
                    "1.10 + (wPiot - 5.0) * 0.22",
                    "1.0 + (1.0 - wBeta) * 0.85",
                    "portTurnoverZ = 1.65",
                    "benchMomZ = 0.28",
                    "benchQualZ = 0.45",
                    "benchLowVolZ = 0.15",
                    "benchTurnoverZ = 0.85"]:
            assert bad not in js, f"R18-B4: JS twin fabrication re-introduced: {bad!r}"

    def test_b5_js_display_honesty(self):
        js = _live_js()
        for bad in [
            "Number(d.bid_qty).toLocaleString()",
            "Number(a.bse_px).toFixed(2)",
            "(Number(a.vpin_toxicity) || 0.18)",
            "(Number(a.entry_price) || 100).toFixed(2)",
            "(Number(a.alpha_half_life_days) || 20",
            "'PRIME_QUALITY')",
            "'HOLD_ACTIVE_ALPHA')",
            "'SAFE_ACCUMULATION')",
            "? 75 : rs",
            "? 15 : ret6m",
            "Number(px) * 1.12",
            "(Number(px) * 0.94)",
            "|| 0.38)",
        ]:
            assert bad not in js, (
                f"REGRESSION (R18-B5): JS fabricated default re-introduced: {bad!r}")


# ──────────────────────────────────────────────────────────────────────────
# Section C — R16/R17 fixes survive Round 18 (no re-regression)
# ──────────────────────────────────────────────────────────────────────────

class TestC18R17Survival:
    def test_c1_r17_literal_locks_still_hold(self):
        live = _live_app()
        for bad in [
            '"agent": "PPO-TWAP-v3"',
            'nlp_score": 0.88',
            'win_rate_%": 68.4',
            'cost_drag_bps": 12.4',
            'base_vol = 120_000',
            'spread_pct = 0.0012',
        ]:
            assert bad not in live, (
                f"REGRESSION (R18-C1): R17 fabrication re-introduced: {bad!r}")

    def test_c2_r16_routes_still_registered(self):
        src = _app_source()
        for route in ["/api/kelly_sizing", "/api/factor_exposure", "/api/backtest_data"]:
            assert route in src, f"REGRESSION (R18-C2): R16 route lost: {route}"

    def test_c3_tv_frame_route_untouched(self):
        src = _app_source()
        assert '"/tv_frame"' in src, "R18-C3: TradingView frame route lost"
        assert "frame-ancestors" in src, "R18-C3: TV CSP frame-ancestors lost"
