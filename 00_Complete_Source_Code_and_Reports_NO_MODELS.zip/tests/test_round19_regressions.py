"""Round 19 regression suite.

Locks the Round 19 work streams (the residuals that survived R17 AND R18):

  Section A — Display-honesty / fabrication-elimination locks
    A1  technical_scanner: no hardcoded BULLISH/ABOVE-CLOUD/BULL-CROSS
        panel, no adx 36.4 default, no poc=px*0.985 / fib=px*0.965
        formulas, no ₹100 default price. Must compute via
        compute_technical_signals and carry data_source.
    A2  risk_attribution: no 24.5 expected-return default, no flat 12.0
        benchmark, no 185/412/45/642 bps fallback fabrications.
    A3  ohlcv: no NaN→100.0 close filler, no NaN→100000 volume filler;
        the synthetic random-walk path must be flagged simulated:true
        with an explicit data_source label.
    A4  monte_carlo_frontier: no invented correlation matrix (0.48/0.18),
        no fallback arrays [0.22,0.28,0.19,0.33]/[0.18,0.24,0.16,0.28],
        no 25.0/80.0/18.0/0.85 screening-input defaults; must carry an
        assumptions block and refuse when history is unavailable.
    A5  JS drill-down: the invented-default metric family is gone
        (3.82/0.72/2.14/3.2/0.2/6.67/+2.10/42.5/+18.4/0.42/0.210/3.42,
        entry*0.92 disaster floor, HOLD_ACTIVE_ALPHA / CONTINUE_RIDE /
        ACTIVE_EXPANDING / PRIME_QUALITY fallback badges, ₹100 price).
    A6  JS technical scanner: null-aware ADX cell (no Number(null) NaN).

  Section B — Math locks (real computation)
    B1  compute_technical_signals on synthetic geometric-random-walk bars:
        ADX bounded 0..100, supertrend direction + stop level finite and
        consistent with the last close, POC inside the price range,
        Camarilla/Fib levels finite; <30 bars → None (refusal).
    B2  brinson_fachler_closed_form: equal-weight identical returns →
        all effects exactly 0 (zero is a valid result, NOT a 185/412
        fallback); a known 2-asset case matches hand-computed bps.
    B3  Wilder smoothing reference values.

  Section C — Survival locks (R16/R17/R18/TV/security intact)
    C1  R18 fabrication locks still hold (spot patterns).
    C2  R17 literals still gone; R16 routes still registered.
    C3  TradingView frame + CSP + auth gate survive; build marker QA-R19.
"""
from __future__ import annotations

import importlib.util
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

_QA_ROOT = Path(__file__).resolve().parent.parent
if str(_QA_ROOT) not in sys.path:
    sys.path.insert(0, str(_QA_ROOT))

APP_PY = _QA_ROOT / "web_dashboard" / "app.py"
DASH_JS = _QA_ROOT / "web_dashboard" / "dashboard.js"


def _app_source() -> str:
    return APP_PY.read_text(encoding="utf-8")


def _live_app() -> str:
    """App source with docstrings and comments stripped (live code only)."""
    src = _app_source()
    out, in_doc = [], False
    for line in src.splitlines():
        s = line.strip()
        if in_doc:
            if '"""' in s:
                in_doc = False
            continue
        if s.startswith('"""'):
            if s.count('"""') >= 2:
                continue
            in_doc = True
            continue
        if s.startswith("#"):
            continue
        out.append(line)
    return "\n".join(out)


def _live_js() -> str:
    return "\n".join(
        l for l in DASH_JS.read_text(encoding="utf-8").splitlines()
        if not l.strip().startswith("//")
    )


def _handler_block(live: str, name: str) -> str:
    m = re.search(rf"def {name}.*?(?=\n    def )", live, re.DOTALL)
    assert m, f"handler {name} not found"
    return m.group(0)


# ──────────────────────────────────────────────────────────────────────────
# Section A — Display-honesty locks
# ──────────────────────────────────────────────────────────────────────────

class TestA19FabricationLocks:
    def test_a1_technical_scanner_no_hardcoded_panel(self):
        live = _live_app()
        block = _handler_block(live, "_handle_technical_scanner")
        for bad in [
            '"BULL CROSS (+4.5)"',
            '"ABOVE CLOUD"',
            "36.4",
            "px * 0.985",
            "px * 0.965",
            "100.0",          # fake default price
            '"STOCK.NS"',
        ]:
            assert bad not in block, (
                f"REGRESSION (R19-A1): technical scanner fabrication re-introduced: {bad!r}")
        assert "compute_technical_signals(" in block, "R19-A1: must compute real signals"
        assert "data_source" in block, "R19-A1: must carry data_source provenance"
        assert '"n_with_history"' in block, "R19-A1: must report coverage honestly"

    def test_a1b_indicators_computed_not_hardcoded(self):
        live = _live_app()
        fn = re.search(r"def compute_technical_signals.*?(?=\ndef )", live, re.DOTALL)
        assert fn, "R19-A1b: compute_technical_signals function missing"
        block = fn.group(0)
        assert "_calc_macd" in block, "R19-A1b: must reuse the tested MACD implementation"
        assert "_calc_volume_profile" in block, "R19-A1b: must reuse the tested volume-profile POC"
        for bad in ["36.4", "+4.5)\"", "0.985", "0.965"]:
            assert bad not in block, f"R19-A1b: indicator formula fabrication {bad!r}"

    def test_a2_risk_attribution_no_fabrications(self):
        live = _live_app()
        block = _handler_block(live, "_handle_risk_attribution")
        for bad in [
            "24.5",            # invented expected return
            "0.120",           # flat invented benchmark
            "185.0", "412.0", "45.0", "642.0",   # fallback fabrications
        ]:
            assert bad not in block, (
                f"REGRESSION (R19-A2): risk attribution fabrication re-introduced: {bad!r}")
        assert "_fetch_returns_panel" in block, "R19-A2: benchmark must be measured"
        assert "brinson_fachler_closed_form" in block, "R19-A2: fallback must use the closed form"
        assert "data_source" in block, "R19-A2: provenance required"

    def test_a3_ohlcv_honest_nan_and_simulated_flag(self):
        live = _live_app()
        block = _handler_block(live, "_handle_ohlcv")
        assert "else 100.0" not in block, "R19-A3: NaN close must not become ₹100"
        assert "else 100000" not in block, "R19-A3: NaN volume must not become 100000"
        assert "simulated = True" in block, "R19-A3: synthetic path must set simulated"
        assert '"simulated": simulated' in block, "R19-A3: payload must carry the simulated flag"
        assert "SYNTHETIC random-walk demonstration series" in block, (
            "R19-A3: synthetic data_source label missing")

    def test_a4_monte_carlo_real_inputs_only(self):
        live = _live_app()
        block = _handler_block(live, "_handle_monte_carlo_frontier")
        for bad in [
            "np.array([0.22, 0.28, 0.19, 0.33])",   # fallback return array
            "np.array([0.18, 0.24, 0.16, 0.28])",   # fallback vol array
            "corr[i, j] = 0.48",                    # invented sector corr
            "corr[i, j] = 0.18",                    # invented cross corr
            '"6M Return %", 25.0',                  # screening defaults
            '"Tier-1 Quant Score", 80.0',
            '"Downside Vol %", 18.0',
            '"Market Beta (β)", 0.85',
        ]:
            assert bad not in block, (
                f"REGRESSION (R19-A4): MC fabrication re-introduced: {bad!r}")
        assert "_fetch_returns_panel" in block, "R19-A4: correlations must be measured"
        assert '"assumptions"' in block, "R19-A4: assumptions block required"
        assert "data_source" in block, "R19-A4: provenance required"

    def test_a5_js_drilldown_family_gone(self):
        js = _live_js()
        for bad in [
            ": 8;",                    # piotroski default
            "'3.82'",
            "'0.72'",
            "'2.14'",
            "'3.2'",
            "'0.2'",
            "'6.67'",
            "'+2.10'",
            "'42.5'",
            "'+18.4'",
            "'0.42'",
            "'0.210'",
            "'3.42'",
            "entryPx * 0.92",
            "|| 100.0",
            "|| 20;",
            "HOLD_ACTIVE_ALPHA'",
            "CONTINUE_RIDE'",
            "ACTIVE_EXPANDING'",
            "HOLD_CONTINUE'",
            "|| 'PRIME_QUALITY'",
            "Consensus Quant Core'",
            "High-conviction cross-factor leader",
        ]:
            assert bad not in js, (
                f"REGRESSION (R19-A5): drill-down fabrication re-introduced: {bad!r}")

    def test_a6_js_technical_scanner_null_aware(self):
        js = _live_js()
        assert "${Number(i.adx).toFixed(1)}" not in js, (
            "R19-A6: ADX cell must be null-aware (Number(null).toFixed renders NaN)")
        assert "i.adx != null ?" in js, "R19-A6: null-check rendering missing"


# ──────────────────────────────────────────────────────────────────────────
# Section B — Math locks
# ──────────────────────────────────────────────────────────────────────────

def _load_app_module():
    spec = importlib.util.spec_from_file_location("qa_app_r19", str(APP_PY))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


class TestB19MathLocks:
    @staticmethod
    def _synthetic_bars(n=250, seed=11):
        rng = np.random.default_rng(seed)
        rets = rng.normal(0.0006, 0.018, n)
        close = 100.0 * np.cumprod(1.0 + rets)
        o = close * (1.0 + rng.normal(0.0, 0.004, n))
        spread = np.abs(rng.normal(0.0, 0.008, n)) * close
        h = np.maximum(o, close) + spread
        l = np.minimum(o, close) - spread
        v = rng.integers(80_000, 900_000, n).astype(float)
        return o, h, l, close, v

    def test_b1_technical_signals_real_computation(self):
        mod = _load_app_module()
        o, h, l, c, v = self._synthetic_bars()
        sig = mod.compute_technical_signals(o, h, l, c, v)
        assert sig is not None, "R19-B1: 250 real bars must produce signals"
        # ADX bounded
        assert sig["adx"] is None or 0.0 <= sig["adx"] <= 100.0
        # Supertrend: direction + finite stop consistent with close
        st = sig["supertrend"]
        assert st is not None and ("BULLISH" in st or "BEARISH" in st)
        stop = float(re.sub(r"[^\d.]", "", st.replace(",", "")))
        assert np.isfinite(stop) and stop > 0
        # Ichimoku one of the three honest states
        assert sig["ichimoku"] in ("ABOVE CLOUD", "BELOW CLOUD", "INSIDE CLOUD")
        # MACD labeled
        assert sig["macd"] is None or ("SIGNAL" in sig["macd"])
        # POC within the observed price range
        poc = float(re.sub(r"[^\d.]", "", sig["vol_profile_poc"]))
        assert float(l.min()) <= poc <= float(h.max())
        # Fib and Camarilla finite levels
        fib = float(re.sub(r"[^\d.]", "", sig["fib_618"]))
        camar = float(re.sub(r"[^\d.]", "", sig["camarilla_r3"]))
        assert np.isfinite(fib) and fib > 0
        assert np.isfinite(camar) and camar > 0
        assert sig["n_bars"] == len(c)

    def test_b1b_insufficient_bars_refused(self):
        mod = _load_app_module()
        o, h, l, c, v = self._synthetic_bars(n=25)
        assert mod.compute_technical_signals(o, h, l, c, v) is None, (
            "R19-B1b: <30 bars must refuse (None), never fabricate")

    def test_b2_brinson_zero_is_valid_and_known_case(self):
        mod = _load_app_module()
        # Case 1: identical weights and identical returns -> exactly zero.
        p_w = {"A": 0.5, "B": 0.5}
        b_w = {"A": 0.5, "B": 0.5}
        r = {"A": 0.10, "B": 0.10}
        out = mod.brinson_fachler_closed_form(p_w, b_w, r, r)
        assert out["allocation_effect_bps"] == 0.0
        assert out["selection_effect_bps"] == 0.0
        assert out["interaction_effect_bps"] == 0.0
        assert out["total_active_alpha_bps"] == 0.0
        # Case 2: hand-computed known case.
        p_w = {"A": 0.75, "B": 0.25}
        b_w = {"A": 0.50, "B": 0.50}
        p_r = {"A": 0.20, "B": 0.05}
        b_r = {"A": 0.10, "B": 0.10}
        out = mod.brinson_fachler_closed_form(p_w, b_w, p_r, b_r)
        # alloc = sum((pw-bw)*br) = (0.25*0.10) + (-0.25*0.10) = 0
        assert abs(out["allocation_effect_bps"]) < 1e-9
        # select = sum(bw*(pr-br)) = 0.5*0.10 + 0.5*(-0.05) = 0.025 -> 250 bps
        assert abs(out["selection_effect_bps"] - 250.0) < 1e-6
        # inter = sum((pw-bw)*(pr-br)) = 0.25*0.10 + (-0.25)*(-0.05) = 0.0375 -> 375 bps
        assert abs(out["interaction_effect_bps"] - 375.0) < 1e-6
        assert abs(out["total_active_alpha_bps"] - 625.0) < 1e-6

    def test_b3b_bool_serializer_not_coerced_to_int(self):
        """bool is a subclass of int — the sanitizer must check bool FIRST.

        Round 19 found `simulated: true` arriving as `simulated: 1` because
        the int branch consumed every boolean. Locks the check order.
        """
        src = _app_source()
        m = re.search(r"def _send_json.*?def _sanitize.*?(?=def [a-z_])", src, re.DOTALL)
        assert m, "R19-B3b: _send_json/_sanitize not found"
        block = m.group(0)
        bool_pos = block.find("isinstance(o, bool)")
        int_pos = block.find("isinstance(o, (np.integer, int)")
        assert bool_pos != -1 and int_pos != -1 and bool_pos < int_pos, (
            "R19-B3b: bool check must precede the int branch")

    def test_b3c_batch_price_bars_wiring(self, monkeypatch):
        """_get_price_bars_batch: one provider round-trip, per-ticker split."""
        mod = _load_app_module()
        h = mod.DashboardAPIHandler.__new__(mod.DashboardAPIHandler)
        h._OHLCV_CACHE = {}
        rng = np.random.default_rng(5)
        syms = ["AAA.NS", "BBB.NS"]
        cols = pd.MultiIndex.from_product(
            [["Open", "High", "Low", "Close", "Volume"], syms])
        n = 250
        base = {s: 100.0 * np.cumprod(1.0 + rng.normal(0.0005, 0.015, n)) for s in syms}
        data = {}
        for s in syms:
            c = base[s]
            o = c * (1.0 + rng.normal(0, 0.004, n))
            data[("Open", s)] = o
            data[("High", s)] = np.maximum(o, c) * 1.01
            data[("Low", s)] = np.minimum(o, c) * 0.99
            data[("Close", s)] = c
            data[("Volume", s)] = rng.integers(50_000, 500_000, n)
        frame = pd.DataFrame(data)
        frame.columns = cols
        calls = {"n": 0}

        def fake_get_prices(self_prov, tickers, period="1y", interval="1d", auto_adjust=True):
            calls["n"] += 1
            assert set(tickers) == set(syms), "batch must fetch ALL tickers in one call"
            return frame

        monkeypatch.setattr("data_layer.YFinanceProvider.get_prices", fake_get_prices, raising=True)
        out = h._get_price_bars_batch(syms)
        assert calls["n"] == 1, "R19-B3c: exactly ONE provider round-trip required"
        assert set(out.keys()) == set(syms)
        for s in syms:
            assert len(out[s]) >= 200
            assert list(out[s].columns) == ["open", "high", "low", "close", "volume"]
        # second call is fully cached (no additional provider round-trip)
        out2 = h._get_price_bars_batch(syms)
        assert calls["n"] == 1 and set(out2.keys()) == set(syms)

    def test_b3_wilder_smoothing_reference(self):
        mod = _load_app_module()
        # Wilder smoothing of a constant series = that constant.
        assert mod._wilder_smooth([3.0] * 50, 14) == pytest.approx(3.0)
        # Empty input -> NaN (refusal).
        assert np.isnan(mod._wilder_smooth([], 14))


# ──────────────────────────────────────────────────────────────────────────
# Section C — Survival locks
# ──────────────────────────────────────────────────────────────────────────

class TestC19Survival:
    def test_c1_r18_fabrications_still_gone(self):
        live = _live_app()
        for bad in [
            "max(1.85, 2.76",
            "14.8 * avg_beta",
            "210.0 * (1.0 /",
            "0.20 + (len(results) * 0.015",
            "Goldman Sachs India Equity Fund",
            "params.get(\"price\", 189.22)",
        ]:
            assert bad not in live, (
                f"REGRESSION (R19-C1): R18 fabrication re-introduced: {bad!r}")

    def test_c2_r17_r16_survive(self):
        live = _live_app()
        for bad in ['"agent": "PPO-TWAP-v3"', 'nlp_score": 0.88', 'win_rate_%": 68.4']:
            assert bad not in live, f"REGRESSION (R19-C2): R17 literal back: {bad!r}"
        src = _app_source()
        for route in ["/api/kelly_sizing", "/api/factor_exposure",
                      "/api/dcc_garch_risk", "/api/backtest_data"]:
            assert route in src, f"REGRESSION (R19-C2): route lost: {route}"

    def test_c3_tv_security_build_marker(self):
        src = _app_source()
        assert '"/tv_frame"' in src, "R19-C3: TradingView frame route lost"
        assert "frame-ancestors" in src, "R19-C3: TV CSP frame-ancestors lost"
        assert "X-QA-Token" in src, "R19-C3: session-token gate lost"
        # Build marker bumped each round: R19 → R20 (honesty restoration on
        # the Sovereign Tier-Ω workspace). Accept the current lineage marker.
        import re
        assert re.search(r"QA-R(19|20)(-|\"|$)", src), (
            "R19-C3: build marker lineage lost (expected QA-R19/QA-R20)")

    def test_c4_js_r18_honesty_survives(self):
        js = _live_js()
        for bad in ["Math.max(0.65, sumZ / sumW)", "portTurnoverZ = 1.65",
                    "Number(px) * 1.12"]:
            assert bad not in js, f"REGRESSION (R19-C4): R18 JS fabrication back: {bad!r}"
