"""Round 20 regression locks — "Sovereign Tier-Ω" honesty restoration.

Round 20 fixed the regressions and new fabrications introduced by the
Sep-7 "Sovereign Tier-Ω" edit on top of the verified Round-19 build:

  R20-1  data_layer.py dangling-`if` corruption (PEAD + Buyback) — module
         failed to import, app could not boot.
  R20-2  block deals re-fabricated (LIC/Nippon/Vanguard/Morgan Stanley...)
         under a false NSE-disclosure provenance.
  R20-3  governance metrics fabricated from abs(hash(ticker)) + AA+ fallback
         + Altman 4.25 / Piotroski 7 defaults.
  R20-4  frontier telemetry offline constants (RMT 68.4%, absorption 0.4215,
         Hawkes 0.52 "INSTITUTIONAL_ALGO_ACCUMULATION", static DMA weights,
         "Active Wasserstein" claim).
  R20-5  synthetic RandomState(42) returns fed to Tier-0+/Ω telemetry
         unlabeled.
  R20-6  trade execution suite default portfolio (RELIANCE 2980...), NIFTY
         24500 hardcode, ₹100 price fallback, strike-23500 hedge fallback.
  R20-7  OOS backtest Sharpe floor `else 1.85` regression + fabricated DSR
         defaults 0.952/0.048 + silent 12%/yr benchmark fill.
  R20-8  ML alpha None→0.95/1.85 re-inflation (log's constant
         "OOS Sharpe=+1.85 | DSR=0.9500 | weight=28%").
  R20-9  LLM swarm fed hardcoded var99=2.0%; GPU Monte Carlo on identity
         covariance np.eye(n)*0.0001.
  R20-10 CVaR(99%) == VaR(99%) clamp in factor_risk (incoherent Gaussian-ES
         at CF quantile) → coherent tail-average CF ES.
  R20-11 one-sided OOS verdict ("Stable" for gap=-5.25) → OOS-Suspicious.
  R20-12 order book depth re-fabricated (ADV×0.02 bid/ask, false
         Easley-O'Hara/CKS provenance).
  R20-13 pairs trading fabricated (HINDOILEXP/JINDRILL, false Engle-Granger
         provenance) → real Kalman cointegration scan.
  R20-14 tax optimizer hardcoded ₹45,200/₹18,400/₹32,100/₹28,500.
  R20-15 options surface hardcoded 24580/24600/1.24/34.2.
  R20-16 screening-table JS fallbacks (₹100 price, 0.85 beta, 90 RS, 1.2 VCP,
         +0.0% 3M return).
  R20-17 summary line now surfaces the Inst-DSR verdict (FAIL vs 95.4%
         contradiction reconciled).
  R20-18 session cookie Max-Age 1 year → 1 day.
  R20-19 tests/ suite restored (was missing from the live workspace).

Lock strategy mirrors the Round-17/18/19 suites:
  A-series: fabrication patterns must be ABSENT from live code
            (docstring/comment-stripped scanning).
  B-series: real behavior/math locks (imports, coherent ES, verdict).
  C-series: survival of prior-round guarantees (security, R19 locks).
"""

import ast
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "web_dashboard" / "app.py"
JS = ROOT / "web_dashboard" / "dashboard.js"
DATA_LAYER = ROOT / "data_layer.py"
OPTIMIZER = ROOT / "optimizer.py"
UTILS = ROOT / "utils.py"
FACTOR_RISK = ROOT / "math_engine" / "factor_risk.py"


def _live_code(path: Path) -> str:
    """Source with docstrings and comments stripped (live code only)."""
    src = path.read_text(encoding="utf-8")
    out = []
    for node in ast.walk(ast.parse(src)):
        if isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant) \
                and isinstance(node.value.value, str):
            continue
    # simpler robust approach: tokenize out comments + docstrings
    import io
    import tokenize
    result = []
    last_end = (1, 0)
    tokens = list(tokenize.generate_tokens(io.StringIO(src).readline))
    for tok in tokens:
        if tok.type == tokenize.COMMENT:
            continue
        if tok.type == tokenize.STRING:
            # keep only strings that are NOT statement docstrings
            result.append(tok.string)
            continue
        result.append(tok.string)
    return "\n".join(result)


def _strip_docstrings(path: Path) -> str:
    """AST-based docstring + comment removal (same technique as R17/R18 locks)."""
    src = path.read_text(encoding="utf-8")
    tree = ast.parse(src)
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            body = node.body
            if body and isinstance(body[0], ast.Expr) and isinstance(body[0].value, ast.Constant) \
                    and isinstance(body[0].value.value, str):
                node.body = body[1:]
    return ast.unparse(tree)


APP_LIVE = _strip_docstrings(APP)
OPT_LIVE = _strip_docstrings(OPTIMIZER)
DL_LIVE = _strip_docstrings(DATA_LAYER)


# ── A-series: fabrication patterns absent from live code ─────────────────────

def test_A1_block_deal_fabrications_gone():
    """R20-2: hardcoded institutional block deals + false provenance gone."""
    for pattern in [
        r"Life Insurance Corporation",
        r"Vanguard Emerging Markets",
        r"Morgan Stanley Asia",
        r"Post-Market Institutional Bulk & Block Deal Disclosures",
    ]:
        assert not re.search(pattern, APP_LIVE), f"block-deal fabrication pattern back: {pattern}"


def test_A2_governance_hash_fabrications_gone():
    """R20-3: abs(hash(ticker))-derived audit metrics + AA+ default gone."""
    assert not re.search(r"abs\(hash\(clean_sym\)\)", APP_LIVE)
    assert not re.search(r'altman_z"\].*else 4\.25', APP_LIVE)
    assert not re.search(r"\"AA\+ \(Clean Institutional Board\)\"\s*$", APP_LIVE) or \
        "rating" not in APP_LIVE  # only the graded branch may keep the label
    assert not re.search(r"MCA & SEBI LODR Reg 23 Compliant", APP_LIVE)


def test_A3_frontier_offline_constants_gone():
    """R20-4: fabricated offline telemetry constants + claims gone."""
    assert not re.search(r'"rejection_pct":\s*68\.4', APP_LIVE)
    assert not re.search(r'"absorption_ratio":\s*0\.4215', APP_LIVE)
    assert not re.search(r'"branching_ratio":\s*0\.52', APP_LIVE)
    assert not re.search(r'"dma_model_allocations"', APP_LIVE)
    assert not re.search(r"Active Wasserstein Ambiguity Ball", APP_LIVE)


def test_A4_execution_suite_defaults_gone():
    """R20-6: default portfolio, NIFTY 24500, ₹100 fallback gone."""
    assert not re.search(r'default_picks', APP_LIVE)
    assert not re.search(r'"RELIANCE",\s*2980\.0', APP_LIVE)
    assert not re.search(r'nifty_price=24500', APP_LIVE)
    assert not re.search(r'current_price",\s*100\.0\)\)\),\s*100\.0', APP_LIVE)


def test_A5_oos_sharpe_floor_and_dsr_defaults_gone():
    """R20-7: `else 1.85` floor + fabricated DSR 0.952/0.048 defaults gone."""
    assert not re.search(r"else 1\.85", APP_LIVE)
    assert not re.search(r"dsr_val\s*=\s*0\.952", APP_LIVE)
    assert not re.search(r"dsr_p\s*=\s*0\.048", APP_LIVE)


def test_A6_ml_alpha_none_reinflation_gone():
    """R20-8: None→0.95/1.85 default re-inflation in optimizer gone."""
    assert not re.search(r'get\("_ML_DSR"\)\s+if\s+.*\s+else\s+0\.95', OPT_LIVE)
    assert not re.search(r'get\("_ML_OOS_SHARPE_NUM"\)\s+if\s+.*\s+else\s+1\.85', OPT_LIVE)
    assert 'not measured (None)' in OPT_LIVE  # honest refusal path present


def test_A7_swarm_hardcoded_var_and_identity_cov_gone():
    """R20-9: hardcoded var99=2.0 swarm input + identity-cov GPU MC gone."""
    assert not re.search(r'"var99_pct":\s*2\.0', OPT_LIVE)
    assert not re.search(r"np\.eye\(len\(weights\)\)\s*\*\s*0\.0001", OPT_LIVE)


def test_A8_ofi_fabrications_gone():
    """R20-12: invented bid/ask + false Easley-O'Hara/CKS provenance gone."""
    assert not re.search(r"Easley-O'Hara VPIN & Cont-Kukanov-Stoikov", APP_LIVE)
    assert not re.search(r"depth_base\s*\*\s*\(1\.0\s*\+\s*ofi_bias\)", APP_LIVE)
    assert not re.search(r'"VPIN Toxicity",\s*h\.get\("vpin_toxicity"\)\),\s*0\.25', APP_LIVE)


def test_A9_pairs_fabrications_gone():
    """R20-13: fabricated pairs + false Engle-Granger provenance gone."""
    assert not re.search(r"HINDOILEXP / JINDRILL", APP_LIVE)
    assert not re.search(r"CUPID / INDOBORAX", APP_LIVE)
    assert not re.search(r"Engle-Granger Two-Step Cointegration Solver", APP_LIVE)
    # real Kalman cointegration wiring present
    assert "detect_kalman_cointegration" in APP_LIVE


def test_A10_tax_and_options_constants_gone():
    """R20-14/15: hardcoded tax liabilities + options surface gone."""
    for pattern in [r'"stcg_tax_liability_rs":\s*45200', r'"ltcg_tax_liability_rs":\s*18400',
                    r'"tax_harvest_opportunity_rs":\s*32100', r'"spot_price":\s*24580\.0',
                    r'"max_pain_strike":\s*24600\.0', r'"pc_ratio_oi":\s*1\.24']:
        assert not re.search(pattern, APP_LIVE), pattern


def test_A11_tier_synthetic_inputs_labeled():
    """R20-5: synthetic returns fed to Tier-0+/Ω must be labeled."""
    # both tier telemetry builders now track synthetic inputs
    assert APP_LIVE.count("_synthetic_inputs") >= 4  # 2 builders × flag+check
    # quote-agnostic (ast.unparse may normalize quotes)
    assert re.search(r"telemetry\[.simulated.\]\s*=\s*True", APP_LIVE)


def test_A12_js_screening_fallbacks_gone():
    """R20-16: screening table + ladder numeric fallbacks gone from JS."""
    js = JS.read_text(encoding="utf-8")
    assert not re.search(r'\|\| 100\)\.toFixed', js)
    assert not re.search(r'\|\| 0\.85\)\.toFixed', js)
    assert not re.search(r'\|\| 90\}', js)
    assert not re.search(r'\|\| 1\.2\)\.toFixed', js)
    assert not re.search(r'Number\(l\.entry_price \|\| 0\)', js)
    # null-aware renders present
    assert 's["Market Beta (β)"] != null' in js


# ── B-series: behavior / math locks ──────────────────────────────────────────

def test_B1_data_layer_imports():
    """R20-1: the dangling-`if` corruption made data_layer unimportable."""
    sys.path.insert(0, str(ROOT))
    import data_layer  # noqa: F401
    assert hasattr(data_layer, "fetch_pead_scores")
    # restored bodies present
    dl_src = DATA_LAYER.read_text(encoding="utf-8")
    assert "result[t] = round((float(s.loc[_t21]) / price_base) - 1.0, 4)" in dl_src
    assert 'result[f"{sym}.NS"] = 1.0' in dl_src


def test_B2_coherent_cf_expected_shortfall():
    """R20-10: CF-tail-average ES — fat tails must give ES(99) > VaR(99)."""
    sys.path.insert(0, str(ROOT))
    from math_engine.factor_risk import FactorRiskDecomposer

    rng = np.random.RandomState(7)
    n = 300
    # fat-tailed portfolio returns: negative skew, high kurtosis
    rets = pd.DataFrame({
        "A": rng.standard_t(df=3, size=n) * 0.02 - 0.003,
        "B": rng.standard_t(df=4, size=n) * 0.015,
    })
    # exposures: rows = tickers, columns = factors (decompose_risk does
    # exposures.loc[stocks] and reads factor names from columns)
    factors = ["Size", "Value", "Momentum", "Volatility", "Liquidity",
               "Quality", "Leverage", "Growth"]
    exposures = pd.DataFrame(
        [[1.0, 0.2, -0.1, 0.5, 0.3, 0.1, 0.0, 0.2],
         [0.4, 1.0, 0.3, -0.2, 0.1, 0.4, 0.1, -0.1]],
        index=["A", "B"], columns=factors)
    dec = FactorRiskDecomposer()
    res = dec.decompose_risk(rets, exposures, {"A": 0.5, "B": 0.5})
    assert res, "decompose_risk returned empty dict — check exposures orientation"
    var99 = res.get("ex_ante_var_99", 0.0)
    cvar99 = res.get("ex_ante_cvar_99", 0.0)
    var95 = res.get("ex_ante_var_95", 0.0)
    cvar95 = res.get("ex_ante_cvar_95", 0.0)
    # ES strictly exceeds VaR (the old bug pinned them equal)
    assert cvar99 > var99 + 1e-9, f"CVaR99 {cvar99} must exceed VaR99 {var99}"
    assert cvar95 >= var95 - 1e-9
    assert cvar99 >= cvar95


def test_B3_oos_suspicious_verdict():
    """R20-11: OOS ≫ IS must be flagged, not labeled 'Stable'."""
    utils_src = UTILS.read_text(encoding="utf-8")
    assert "OOS-Suspicious" in utils_src
    assert "_g < -1.0" in utils_src


def test_B4_cookie_one_day():
    """R20-18: session cookie Max-Age tightened to 1 day."""
    app_src = APP.read_text(encoding="utf-8")
    assert "Max-Age=86400" in app_src
    assert "Max-Age=31536000" not in app_src


def test_B5_summary_reconciles_inst_dsr():
    """R20-17: pipeline summary surfaces the Inst-DSR verdict."""
    opt_src = OPTIMIZER.read_text(encoding="utf-8")
    assert "Inst-DSR: {" in opt_src


# ── C-series: survival of prior guarantees ───────────────────────────────────

def test_C1_security_gates_survive():
    """W2 constant-time compare + W5 loopback bind + W4 host validation."""
    app_src = APP.read_text(encoding="utf-8")
    assert "compare_digest" in app_src
    assert re.search(r"PORT\s*=\s*8088", app_src)
    assert "_valid_local_host" in app_src
    assert "127.0.0.1" in app_src


def test_C2_r19_fixes_survive():
    """R19 display-honesty machinery still present."""
    app_src = APP.read_text(encoding="utf-8")
    assert "compute_technical_signals" in app_src
    assert "brinson_fachler_closed_form" in app_src
    assert "SYNTHETIC random-walk demonstration series" in app_src  # OHLCV label
    # serializer: bool checked before int
    assert re.search(r"isinstance\(o,\s*bool\)", app_src)


def test_C3_round19_lock_file_present():
    """R20-19: the restored tests/ directory carries the full lineage."""
    assert (ROOT / "tests" / "test_round19_regressions.py").exists()
    assert (ROOT / "tests" / "test_round18_regressions.py").exists()
    assert (ROOT / "tests" / "test_round17_regressions.py").exists()
