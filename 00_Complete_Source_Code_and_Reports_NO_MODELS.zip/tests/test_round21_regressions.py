"""Round 21 regression locks — Section 4 residual fixes & quantitative integrity.

Covers:
  R21-1: ProfileCashOverlay echoes the active profile name (not hardcoded "Default").
  R21-2: All strategy profiles in PROFILE_MAP explicitly define "PROFILE_NAME".
  R21-3: Unified canonical market regime reporting across ProfileCashOverlay,
         ChartV3, and QuantPipeline summary.
  R21-4: Out-Of-Sample (OOS) validation window diagnostics, selection bias risk
         flagging for IS<0 vs OOS>0 anomalies, and structural diagnosis.
  R21-5: Factor attribution explicitly discloses retroactive static basket selection
         to prevent net alpha magnitude inflation misunderstandings.
  R21-6: Live NSE option-chain fetching engine (Max Pain, PCR, IV, Skew) with
         in-memory TTL cache and honest offline fallbacks.
  R21-7: Indian share-lot tax-loss harvesting engine (STCG @ 20%, LTCG @ 12.5%)
         wired dynamically into /api/tax_optimizer.
  R21-8: Build ID integrity & backwards compatibility with prior regression locks.
"""

import ast
import inspect
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "web_dashboard" / "app.py"
DATA_LAYER = ROOT / "data_layer.py"
OPTIMIZER = ROOT / "optimizer.py"
UTILS = ROOT / "utils.py"
CHART_PIPELINE = ROOT / "utils_chart_pipeline.py"
TAX_ENGINE = ROOT / "math_engine" / "tax_loss_harvesting.py"


def test_r21_1_profile_cash_overlay_echoes_active_profile():
    """ProfileCashOverlay must dynamically extract and echo the active profile name,
    never hardcoding Profile=Default."""
    opt_src = OPTIMIZER.read_text(encoding="utf-8")
    assert "Profile=Default" not in opt_src, (
        "optimizer.py must not hardcode 'Profile=Default' in log strings"
    )
    assert "_prof_disp = working_cfg.get('PROFILE_NAME')" in opt_src or "working_cfg.get(\"PROFILE_NAME\")" in opt_src, (
        "optimizer.py must dynamically resolve PROFILE_NAME in ProfileCashOverlay"
    )


def test_r21_2_all_profiles_have_profile_name():
    """All 9 profiles in data_layer.PROFILE_MAP must define PROFILE_NAME equal to their key."""
    from data_layer import PROFILE_MAP
    assert len(PROFILE_MAP) >= 5, f"Expected >= 5 profiles, got {len(PROFILE_MAP)}"
    for name, p_cfg in PROFILE_MAP.items():
        assert "PROFILE_NAME" in p_cfg, f"Profile '{name}' is missing 'PROFILE_NAME' key"
        assert p_cfg["PROFILE_NAME"] == name, (
            f"Profile '{name}' has mismatched PROFILE_NAME: {p_cfg['PROFILE_NAME']}"
        )


def test_r21_3_canonical_regime_unification():
    """Market regime must be unified via _CANONICAL_MARKET_REGIME across optimizer,
    ChartV3, and cash overlay."""
    opt_src = OPTIMIZER.read_text(encoding="utf-8")
    chart_src = CHART_PIPELINE.read_text(encoding="utf-8")

    assert "_CANONICAL_MARKET_REGIME" in opt_src, (
        "optimizer.py must set and consume _CANONICAL_MARKET_REGIME"
    )
    assert "_CANONICAL_MARKET_REGIME" in chart_src, (
        "utils_chart_pipeline.py must check _CANONICAL_MARKET_REGIME in ChartV3"
    )


def test_r21_4_oos_selection_bias_and_structural_diagnosis():
    """compute_oos_validation must include window diagnostics, selection bias risk,
    and structural diagnosis while preserving OOS-Suspicious verdict."""
    utils_src = UTILS.read_text(encoding="utf-8")
    assert "IS_Window_Days" in utils_src
    assert "OOS_Window_Days" in utils_src
    assert "Selection_Bias_Risk" in utils_src
    assert "Structural_Diagnosis" in utils_src
    assert "OOS-Suspicious" in utils_src
    assert "_g < -1.0" in utils_src


def test_r21_5_factor_attribution_retroactive_disclosure():
    """compute_factor_attribution must properly label and disclose retroactive static baskets."""
    from utils import compute_factor_attribution

    dates = pd.date_range("2024-01-01", periods=100)
    port_ret = pd.Series(np.random.normal(0.001, 0.01, 100), index=dates)
    bm_ret = pd.Series(np.random.normal(0.0005, 0.01, 100), index=dates)

    # Standard call (live walk-forward equity curve)
    attr_live = compute_factor_attribution(port_ret, bm_ret, is_retroactive_basket=False)
    assert isinstance(attr_live, pd.DataFrame)
    assert "Residual Net Alpha" in attr_live["Component"].values

    # Retroactive basket call (static end-of-period holdings)
    attr_retro = compute_factor_attribution(port_ret, bm_ret, is_retroactive_basket=True)
    assert isinstance(attr_retro, pd.DataFrame)
    assert "Residual Net Alpha (Retroactive)" in attr_retro["Component"].values
    
    # Detail column must surface warning disclaimer
    retro_row = attr_retro[attr_retro["Component"] == "Residual Net Alpha (Retroactive)"].iloc[0]
    assert "RETROACTIVE BASKET" in retro_row["Detail"]


def test_r21_6_nse_option_chain_calculation_and_caching(monkeypatch):
    """Test fetch_nse_option_chain logic and caching.

    AUDIT-FIX (Round 22 — R22-5): this test previously called the REAL NSE
    endpoint, making the suite fail on any machine/network where nseindia.com
    is unreachable (CI runners, datacenter IPs rate-limited by NSE's Akamai
    WAF, offline development). The test is now hermetic: NSEClient.get is
    monkeypatched with canned contract-info + option-chain-v3 payloads and
    the max-pain / PCR / median-IV / skew math is verified against
    hand-computed values. A separate opt-in live test exists below.
    """
    from data_layer import fetch_nse_option_chain, _OPTION_CHAIN_CACHE

    # ── Canned NSE payloads ─────────────────────────────────────────────
    STRIKES = [22000, 22500, 23000, 23500, 24000, 24500, 25000]
    CALL_OI = [100, 300, 500, 700, 900, 1100, 1300]
    PUT_OI  = [900, 700, 500, 300, 100, 50, 10]
    CALL_IV = [12.0, 13.0, 14.0, 15.0, 16.0, 17.0, 18.0]
    PUT_IV  = [22.0, 21.0, 20.0, 19.0, 18.0, 17.0, 16.0]

    info_payload = {"expiryDates": ["16-Oct-2026"]}
    chain_payload = {
        "records": {
            "underlyingValue": 24000.0,
            "timestamp": "11-Sep-2026 12:00:00",
            "data": [
                {
                    "strikePrice": k,
                    "CE": {"openInterest": c, "impliedVolatility": civ},
                    "PE": {"openInterest": p, "impliedVolatility": piv},
                }
                for k, c, p, civ, piv in zip(STRIKES, CALL_OI, PUT_OI, CALL_IV, PUT_IV)
            ],
        }
    }

    class _FakeResponse:
        def __init__(self, payload):
            self.status_code = 200
            self._payload = payload
            self.text = str(payload)

        def json(self):
            return self._payload

    call_counter = {"n": 0}

    def _fake_get(cls, url, params=None, headers=None, timeout=10, stream=False):
        call_counter["n"] += 1
        if "option-chain-contract-info" in url:
            return _FakeResponse(info_payload)
        if "option-chain-v3" in url:
            return _FakeResponse(chain_payload)
        raise AssertionError(f"Unexpected URL requested by option chain fetch: {url}")

    import utils as _utils
    monkeypatch.setattr(_utils.NSEClient, "get", classmethod(_fake_get))

    # Clear cache for fresh fetch
    _OPTION_CHAIN_CACHE.clear()
    # AUDIT-FIX (Round 23 — R23-1): data_layer now also keeps a short-lived
    # negative cache (recent-failure suppression) so offline sweeps don't
    # hammer NSE. An earlier test's unmocked live-network failure (e.g. the
    # p2_warnings compliance probe) can leave a fresh failure stamp that
    # would suppress THIS test's mocked fetch — clear it so the hermetic
    # mock is always exercised regardless of test ordering.
    try:
        from data_layer import _OPTION_CHAIN_FAIL_TS
        _OPTION_CHAIN_FAIL_TS.clear()
    except ImportError:
        pass

    # Call with symbol="NIFTY"
    chain = fetch_nse_option_chain("NIFTY")
    assert isinstance(chain, dict)
    assert "spot_price" in chain
    assert "max_pain_strike" in chain
    assert "pc_ratio_oi" in chain
    assert "median_iv" in chain          # R22-3: honest label (was 'iv_percentile')
    assert "iv_skew_5pct_otm" in chain   # R22-3: honest label (was 'iv_skew_25d_delta')
    assert "data_source" in chain

    assert chain["spot_price"] == 24000.0
    # Max pain: strike minimizing writer payout sum(max(0,S-K)*CallOI + max(0,K-S)*PutOI)
    # Hand-computed over this chain -> minimum total payout at S=23000
    assert chain["max_pain_strike"] == 23000.0
    # PCR = sum(Put OI) / sum(Call OI) = 2560 / 4900
    assert chain["pc_ratio_oi"] == round(2560.0 / 4900.0, 2)
    # median IV across all 14 listed IVs = 17.0
    assert chain["median_iv"] == 17.0
    # skew = put IV at strike nearest 95% spot (23000) - call IV at nearest 105% spot (25000)
    assert chain["iv_skew_5pct_otm"] == 20.0 - 18.0
    assert chain["total_call_oi"] == 4900.0
    assert chain["total_put_oi"] == 2560.0
    assert chain["expiry"] == "16-Oct-2026"

    # Verify cache hit on second call (no additional HTTP requests)
    n_calls_after_first = call_counter["n"]
    chain_cached = fetch_nse_option_chain("NIFTY")
    assert chain_cached == chain
    assert call_counter["n"] == n_calls_after_first

    # Stale cache entry (> TTL) must trigger a refetch
    import time as _time
    key = "NIFTY:nearest"
    if key in _OPTION_CHAIN_CACHE:
        data, ts = _OPTION_CHAIN_CACHE[key]
        _OPTION_CHAIN_CACHE[key] = (data, _time.time() - 600.0)
        chain_refetched = fetch_nse_option_chain("NIFTY")
        assert chain_refetched == chain
        assert call_counter["n"] > n_calls_after_first


@pytest.mark.skipif(
    __import__("os").environ.get("QA_LIVE_NETTESTS", "0") != "1",
    reason="Live NSE network test opted in via QA_LIVE_NETTESTS=1 (NSE blocks most CI/datacenter IPs)",
)
def test_r21_6b_nse_option_chain_live_smoke():
    """Opt-in live smoke test against the real NSE endpoint.

    The suite's default run must stay hermetic (see test_r21_6). Set
    QA_LIVE_NETTESTS=1 on a workstation with residential/Indian ISP access
    to exercise the real feed; the honest None return offline is expected
    and asserted (not failed).

    R34-1: the Round 33 upload had removed this opt-in gate, making every
    default suite run attempt a live NSE call (breaking the documented
    hermetic-suite contract from Rounds 21/22). Gate restored verbatim.
    """
    from data_layer import fetch_nse_option_chain, _OPTION_CHAIN_CACHE
    _OPTION_CHAIN_CACHE.clear()
    chain = fetch_nse_option_chain("NIFTY")
    if chain is None:
        pytest.skip("NSE live feed unreachable from this network — honest None return")
    assert isinstance(chain, dict)
    assert chain.get("spot_price", 0) > 0
    assert chain.get("max_pain_strike", 0) > 0

def test_r21_7_tax_loss_harvesting_engine_rates_and_structure():
    """TaxLossHarvestingOptimizer must compute Indian STCG (20%) and LTCG (12.5%)."""
    from math_engine.tax_loss_harvesting import TaxLossHarvestingOptimizer

    current_prices = {"RELIANCE": 2500.0, "TCS": 3000.0}
    holdings_df = pd.DataFrame([
        {
            "Ticker": "RELIANCE",
            "Shares": 10,
            "BuyPrice": 3000.0,
            "HoldingDays": 90,  # Short term (< 365)
        },
        {
            "Ticker": "TCS",
            "Shares": 5,
            "BuyPrice": 3500.0,
            "HoldingDays": 400,  # Long term (>= 365)
        },
    ])

    report = TaxLossHarvestingOptimizer.identify_harvestable_lots(holdings_df, current_prices)
    assert "harvestable_lots_df" in report
    assert "est_stcg_savings_inr" in report
    assert "est_ltcg_savings_inr" in report
    assert "total_tax_saved_inr" in report

    # Loss amounts:
    # Reliance: (2500 - 3000) * 10 = -5000 (short term) -> STCG tax saved = 5000 * 0.20 = 1000
    # TCS: (3000 - 3500) * 5 = -2500 (long term) -> LTCG tax saved = 2500 * 0.125 = 312.5
    assert report["est_stcg_savings_inr"] == 1000.0
    assert report["est_ltcg_savings_inr"] == 312.5
    assert report["total_tax_saved_inr"] == 1312.5


def test_r21_8_app_build_marker_compliance():
    """app.py APP_BUILD_ID must satisfy the prior regression lock regex QA-R(19|20)
    while designating Round 21."""
    app_src = APP.read_text(encoding="utf-8")
    m = re.search(r'APP_BUILD_ID\s*=\s*"([^"]+)"', app_src)
    assert m, "APP_BUILD_ID definition not found in app.py"
    build_id = m.group(1)
    assert re.search(r"QA-R(19|20)", build_id), (
        f"APP_BUILD_ID '{build_id}' must match prior test lock pattern QA-R(19|20)"
    )
    assert "R21" in build_id, f"APP_BUILD_ID '{build_id}' must designate R21"
