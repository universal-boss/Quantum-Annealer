"""Round 22 regression locks — honesty & wiring integrity of the R21 features.

Covers:
  R22-1: /api/tax_optimizer sources lots from the trade journal (real recorded
         entry prices + last-marked current prices); the Round-21 wiring that
         passed the SAME price as BuyPrice and CurrentPrice (guaranteeing a
         zero unrealized PnL and a permanently dead engine), the invented
         1.25x "rebalance savings" markup, and the hidden hardcoded Rs 1M
         portfolio value are all gone.
  R22-2: optimizer.py no longer runs the decorative dead tax call
         identify_harvestable_lots(portfolio_df, {}) whose result was never
         consumed.
  R22-3: fetch_nse_option_chain emits honest metric labels: `median_iv`
         (cross-sectional IV level) instead of the mislabeled `iv_percentile`,
         and `iv_skew_5pct_otm` (fixed ±5% moneyness skew) instead of
         `iv_skew_25d_delta`; a non-positive spot refuses honestly.
  R22-4: TaxLossHarvestingOptimizer's empty-input return includes
         `total_tax_saved_inr` (shape consistency with the populated path).
  R22-5: /api/options_surface serves the renamed keys and only serves a chain
         whose spot_price is a positive real number (0.0 previously passed the
         `is not None` check).
  R22-6: The R21-6 option-chain test stays hermetic (mocked network) so the
         suite cannot fail on networks where nseindia.com is unreachable.
"""

import io
import re
import tokenize
from pathlib import Path

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "web_dashboard" / "app.py"
DATA_LAYER = ROOT / "data_layer.py"
OPTIMIZER = ROOT / "optimizer.py"
TAX_ENGINE = ROOT / "math_engine" / "tax_loss_harvesting.py"
R21_TESTS = ROOT / "tests" / "test_round21_regressions.py"


def _code_only(path: Path) -> str:
    """Return the source of `path` with comments and docstrings removed.

    Pattern locks must run against executable code only — AUDIT-FIX comments
    and docstrings legitimately QUOTE the eliminated bug patterns (e.g.
    `identify_harvestable_lots(portfolio_df, {})` inside an explanation),
    which would otherwise trip `not in` assertions.
    """
    import ast

    src = path.read_text(encoding="utf-8")
    tree = ast.parse(src)
    docstring_lines = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                docstring_lines.add(node.body[0].lineno)
    kept = []
    for tok in tokenize.generate_tokens(io.StringIO(src).readline):
        if tok.type == tokenize.COMMENT:
            continue
        if tok.type == tokenize.STRING and tok.start[0] in docstring_lines:
            continue
        kept.append(tok)
    return tokenize.untokenize(kept)


def test_r22_1_tax_optimizer_uses_journal_lot_ledger():
    """The tax endpoint must derive lots from TradeJournalManager (the only
    real cost-basis source), never from the current-price-only holdings."""
    app_code = _code_only(APP)
    m = re.search(r"def _handle_tax_optimizer\(.*?(?=\n    def )", app_code, re.S)
    assert m, "_handle_tax_optimizer not found in app.py"
    body = m.group(0)

    # Sources lots from the journal (recorded entry prices at fill time)
    assert "TradeJournalManager()" in body
    assert 't.get("entry_price")' in body
    assert 't.get("current_price")' in body
    # The dead-on-arrival pattern: current price reused as BuyPrice
    assert "curr_prices[tk] = ep" not in body
    # The invented 1.25x markup on measured savings
    assert "* 1.25" not in body
    # Savings reported must equal the measured harvest opportunity
    assert '"tax_optimized_rebalance_savings_rs": round(harvest_opp, 2)' in body
    # The portfolio value assumption is accepted from query params
    assert 'params.get("portfolio_value")' in body


def test_r22_1b_tax_optimizer_journal_math():
    """Behavioral lock: journal lots with real entry/current prices produce the
    correct STCG/LTCG split through the endpoint's lot schema."""
    from math_engine.tax_loss_harvesting import TaxLossHarvestingOptimizer

    # Endpoint schema: Ticker / BuyPrice (recorded entry) / Shares / HoldingDays
    lots = pd.DataFrame([
        {"Ticker": "RELIANCE", "BuyPrice": 3000.0, "Shares": 10, "HoldingDays": 90},
        {"Ticker": "TCS", "BuyPrice": 3500.0, "Shares": 5, "HoldingDays": 400},
    ])
    # Current prices from the journal's last mark — DIFFERENT from entry
    prices = {"RELIANCE": 2500.0, "TCS": 3000.0}
    res = TaxLossHarvestingOptimizer.identify_harvestable_lots(lots, prices)
    # RELIANCE: (2500-3000)*10 = -5000 short-term -> 5000*0.20 = 1000
    assert res["est_stcg_savings_inr"] == 1000.0
    # TCS: (3000-3500)*5 = -2500 long-term -> 2500*0.125 = 312.5
    assert res["est_ltcg_savings_inr"] == 312.5
    assert res["total_tax_saved_inr"] == 1312.5


def test_r22_2_no_dead_tax_call_in_optimizer():
    """optimizer.py must not re-introduce the decorative
    identify_harvestable_lots(portfolio_df, {}) call (empty price map,
    result never consumed)."""
    opt_code = _code_only(OPTIMIZER)
    assert "identify_harvestable_lots(portfolio_df, {})" not in opt_code
    # The removal is documented at the site (in prose, not executable code)
    opt_src = OPTIMIZER.read_text(encoding="utf-8")
    assert "AUDIT-FIX (Round 22 — R22-2)" in opt_src


def test_r22_3_option_chain_honest_metric_labels():
    """Option chain keys must describe the math actually computed."""
    dl_code = _code_only(DATA_LAYER)
    # Mislabels eliminated from executable code
    assert '"iv_percentile"' not in dl_code
    assert '"iv_skew_25d_delta"' not in dl_code
    # Honest labels present in the produced dict
    assert '"median_iv"' in dl_code
    assert '"iv_skew_5pct_otm"' in dl_code
    # Non-positive spot refuses honestly
    assert "if spot <= 0" in dl_code


def test_r22_4_tax_engine_empty_return_shape():
    """The empty-input early return must carry the same keys as the populated
    path (total_tax_saved_inr was previously missing)."""
    from math_engine.tax_loss_harvesting import TaxLossHarvestingOptimizer
    res = TaxLossHarvestingOptimizer.identify_harvestable_lots(pd.DataFrame(), {})
    assert set(res.keys()) >= {
        "harvestable_lots_df", "est_stcg_savings_inr",
        "est_ltcg_savings_inr", "total_tax_saved_inr",
    }
    assert res["total_tax_saved_inr"] == 0.0


def test_r22_5_options_surface_serves_only_valid_chains():
    """The endpoint must gate on a positive numeric spot and use the renamed
    honest keys in its offline fallback."""
    app_code = _code_only(APP)
    m = re.search(r"def _handle_options_surface\(.*?(?=\n    def )", app_code, re.S)
    assert m, "_handle_options_surface not found in app.py"
    body = m.group(0)

    assert 'chain.get("spot_price")' in body
    assert "> 0" in body
    assert '"median_iv": None' in body
    assert '"iv_skew_5pct_otm": None' in body
    assert '"iv_percentile"' not in body
    assert '"iv_skew_25d_delta"' not in body


def test_r22_6_r21_option_chain_test_is_hermetic():
    """The R21-6 test must mock the network — a live-network test makes the
    suite fail on every CI runner and offline workstation (NSE 403s
    datacenter IPs)."""
    r21_src = R21_TESTS.read_text(encoding="utf-8")
    m = re.search(
        r"def test_r21_6_nse_option_chain_calculation_and_caching\(.*?(?=\n@pytest|\ndef test_)",
        r21_src, re.S,
    )
    assert m, "test_r21_6_nse_option_chain_calculation_and_caching not found"
    body = m.group(0)
    assert "monkeypatch" in body
    # No unmocked direct call to the live fetch in the hermetic test body
    assert "QA_LIVE_NETTESTS" not in body
