"""Round 23 regression locks — the five residuals from BUGFIX_REPORT_ROUND22 §4.

  R23-1: Live option-chain wiring into GEX + the tail hedge. The sweep's
         hedge no longer runs on policy-flat 18% IV / 30d DTE when a live
         NSE chain is fetchable: median IV (percent -> fraction) and expiry
         DTE flow into calculate_hedge_recommendation with honest source
         labels; GEX consumes real per-strike OI rows (chain_rows) instead
         of the canned +Rs150M fallback; premiums are Black-Scholes with the
         same iv/T as the delta (was a flat 1.2%-of-index heuristic).
  R23-2: /api/tax_optimizer refreshes journal price marks at request time
         (best-effort NSE quote-equity via fetch_nse_equity_last_prices);
         offline keeps the last marks AND discloses them as stale.
  R23-3: Disclosed beta floor (cfg TAIL_HEDGE_BETA_FLOOR, default 0.30) in
         the tail hedge so illiquid microcaps' near-zero 63d betas cannot
         silently collapse hedge size; floored tickers are listed in the
         response; the Barra portfolio beta is echoed as a cross-check.
  R23-4: OOS walk-forward selection-bias DIAGNOSTICS (point-in-time basket
         overlap + per-fold alpha concentration) wired into the sweep
         payload — the bias is now measured per run, not just labeled.
  R23-5: Tax engine + endpoint + panel disclose the lot-harvesting
         assumptions (full loss offsettability, no LTCG exemption slab).
"""

import io
import re
import tokenize
from datetime import date
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "web_dashboard" / "app.py"
DATA_LAYER = ROOT / "data_layer.py"
OPTIMIZER = ROOT / "optimizer.py"
HEDGER = ROOT / "math_engine" / "options_hedger.py"
TAX_ENGINE = ROOT / "math_engine" / "tax_loss_harvesting.py"
WFO = ROOT / "math_engine" / "oos_walkforward.py"
DASHBOARD_JS = ROOT / "web_dashboard" / "dashboard.js"


def _code_only(path: Path) -> str:
    """Return the source of `path` with comments and docstrings removed.

    Pattern locks must run against executable code only — AUDIT-FIX comments
    and docstrings legitimately QUOTE the eliminated bug patterns, which
    would otherwise trip `not in` assertions.
    """
    import ast

    src = path.read_text(encoding="utf-8")
    tree = ast.parse(src)
    docstring_lines = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                docstring_lines.add(node.body[0].lineno)
    kept = []
    for tok in tokenize.generate_tokens(io.StringIO(src).readline):
        if tok.type == tokenize.COMMENT:
            continue
        if tok.type == tokenize.STRING and tok.start[0] in docstring_lines:
            continue
        kept.append(tok)
    return tokenize.untokenize(kept)


# ══════════════════════════════════════════════════════════════════════
# R23-1 — live option-chain wiring
# ══════════════════════════════════════════════════════════════════════

def test_r23_1a_resolve_live_chain_inputs_units_and_sources():
    """Chain inputs: median_iv arrives in PERCENT and must become a BS
    fraction; expiry must become calendar DTE; degraded chains keep the
    policy defaults WITH honest source labels."""
    from math_engine.options_hedger import resolve_live_chain_inputs

    chain = {
        "underlying": "NIFTY",
        "expiry": "25-Sep-2026",
        "spot_price": 24600.5,
        "median_iv": 13.5,
    }
    ri = resolve_live_chain_inputs(chain, today=date(2026, 9, 11))
    assert ri["iv"] == pytest.approx(0.135)          # 13.5% -> 0.135
    assert ri["dte_days"] == 14                      # 11-Sep -> 25-Sep
    assert ri["spot"] == 24600.5
    assert ri["iv_source"].startswith("live")
    assert ri["dte_source"].startswith("live")

    # Same-day expiry floors at 1 day of time value
    assert resolve_live_chain_inputs({"expiry": "11-Sep-2026"}, today=date(2026, 9, 11))["dte_days"] == 1
    # Past / garbage expiry keeps the policy default DTE
    assert resolve_live_chain_inputs({"expiry": "10-Jan-2020"}, today=date(2026, 9, 11))["dte_days"] == 30
    assert resolve_live_chain_inputs({"expiry": "not-a-date"})["dte_days"] == 30
    # None / degraded chain -> policy defaults with honest labels
    ri2 = resolve_live_chain_inputs(None)
    assert ri2["iv"] == 0.18 and ri2["dte_days"] == 30
    assert "unavailable" in ri2["iv_source"]
    assert "unavailable" in ri2["dte_source"]


def test_r23_1b_sweep_tail_hedge_passes_live_iv_dte_and_gex_chain():
    """Pattern lock: the sweep's tail-hedge call passes the resolved live
    iv/dte (+ source labels) and the GEX call consumes real chain rows.
    AUDIT-FIX (Round 24 — R24-2 supersession): the GEX call now also passes
    iv/dte/sources so gamma is strike-solved; the lock was updated to the
    stronger wiring."""
    opt_code = _code_only(OPTIMIZER)
    # Tail-hedge wiring
    assert 'iv=_chain_inputs["iv"]' in opt_code
    assert 'dte_days=_chain_inputs["dte_days"]' in opt_code
    assert 'iv_source=_chain_inputs["iv_source"]' in opt_code
    assert 'dte_source=_chain_inputs["dte_source"]' in opt_code
    assert "resolve_live_chain_inputs(" in opt_code
    # GEX wiring: real chain rows + live spot preference + resolved inputs
    assert "option_chain=_gex_chain_df" in opt_code
    assert 'fetch_nse_option_chain("NIFTY", log_cb=log_cb)' in opt_code
    assert 'iv=(_gex_chain_inputs or {}).get("iv", 0.18)' in opt_code
    assert 'dte_days=(_gex_chain_inputs or {}).get("dte_days", 30)' in opt_code


def test_r23_1c_option_chain_emits_per_strike_rows_and_negative_cache(monkeypatch):
    """fetch_nse_option_chain emits chain_rows (per-strike OI/IV) for the GEX
    wiring, and a recent failure suppresses refetch hammering (negative
    cache) — both hermetic via a mocked NSEClient."""
    from data_layer import fetch_nse_option_chain, _OPTION_CHAIN_CACHE, _OPTION_CHAIN_FAIL_TS
    import utils as _utils

    STRIKES = [22000, 22500, 23000, 23500, 24000]
    info_payload = {"expiryDates": ["16-Oct-2026"]}
    chain_payload = {
        "records": {
            "underlyingValue": 24000.0,
            "data": [
                {
                    "strikePrice": k,
                    "CE": {"openInterest": 100 * i, "impliedVolatility": 14.0},
                    "PE": {"openInterest": 300 - 50 * i, "impliedVolatility": 20.0},
                }
                for i, k in enumerate(STRIKES)
            ],
        }
    }

    class _FakeResponse:
        def __init__(self, payload, status=200):
            self.status_code = status
            self._payload = payload

        def json(self):
            return self._payload

    calls = {"n": 0}

    def _fake_get(cls, url, params=None, headers=None, timeout=10, stream=False):
        calls["n"] += 1
        if "option-chain-contract-info" in url:
            return _FakeResponse(info_payload)
        if "option-chain-v3" in url:
            return _FakeResponse(chain_payload)
        raise AssertionError(f"Unexpected URL: {url}")

    monkeypatch.setattr(_utils.NSEClient, "get", classmethod(_fake_get))
    _OPTION_CHAIN_CACHE.clear()
    _OPTION_CHAIN_FAIL_TS.clear()

    chain = fetch_nse_option_chain("NIFTY")
    assert isinstance(chain, dict) and chain.get("chain_rows")
    rows = pd.DataFrame(chain["chain_rows"])
    assert list(rows.columns) == ["strikePrice", "callOI", "putOI", "callIV", "putIV"]
    assert rows["callOI"].sum() == chain["total_call_oi"]
    assert rows["putOI"].sum() == chain["total_put_oi"]
    assert len(rows) == len(STRIKES)

    # Negative cache: a non-200 failure stamps the key; the next call within
    # the TTL returns None WITHOUT a new HTTP round-trip.
    _fail_calls = {"n": 0}

    def _failing_get(cls, url, params=None, headers=None, timeout=10, stream=False):
        _fail_calls["n"] += 1
        return _FakeResponse({}, status=403)

    _OPTION_CHAIN_CACHE.clear()
    _OPTION_CHAIN_FAIL_TS.clear()
    monkeypatch.setattr(_utils.NSEClient, "get", classmethod(_failing_get))
    assert fetch_nse_option_chain("NIFTY") is None
    n_after_first = _fail_calls["n"]
    assert fetch_nse_option_chain("NIFTY") is None
    assert _fail_calls["n"] == n_after_first  # suppressed — no refetch
    # cleanup for other tests
    _OPTION_CHAIN_FAIL_TS.clear()


def test_r23_1d_hedge_premium_uses_black_scholes_inputs():
    """Collar premiums must respond to the IV/DTE actually used (Black-Scholes
    with the delta's inputs), not a flat 1.2%-of-index heuristic; the premium
    model is disclosed; a policy-flat hedge flags itself in the summary."""
    from math_engine.options_hedger import OptionsTailHedger

    pdf = pd.DataFrame([
        {"Ticker": "AAA", "Weight %": 100.0, "Beta": 1.0},
    ])
    h = OptionsTailHedger(nifty_price=24000.0)
    r_lo = h.calculate_hedge_recommendation(pdf, portfolio_value=1_000_000, regime="Bear", iv=0.10, dte_days=5)
    r_hi = h.calculate_hedge_recommendation(pdf, portfolio_value=1_000_000, regime="Bear", iv=0.30, dte_days=60)
    p_lo = float(r_lo["collar_legs_df"].iloc[0]["Est. Premium/Share"].replace("Rs", "").replace(",", ""))
    p_hi = float(r_hi["collar_legs_df"].iloc[0]["Est. Premium/Share"].replace("Rs", "").replace(",", ""))
    assert "Black-Scholes" in r_lo["premium_model"]
    assert p_hi > p_lo * 3  # 60d/30% IV put costs multiples of the 5d/10% IV put
    # The old flat heuristic quoted the SAME premium for both regimes
    assert p_lo < 24000.0 * 0.012  # low IV/short DTE is cheaper than the old flat 1.2%
    # A hedge on policy-default inputs flags itself in the summary
    r_def = h.calculate_hedge_recommendation(pdf, portfolio_value=1_000_000, regime="Bear")
    assert "policy defaults" in r_def["summary"]
    # Input provenance echoed in the response
    assert "iv_source" in r_def and "dte_source" in r_def


def test_r23_1e_execution_suite_hedge_wires_chain_and_floor():
    """Pattern lock: the dashboard's trade-execution suite prices its collar
    from the live chain (iv/dte/sources) and applies the beta floor."""
    app_code = _code_only(APP)
    m = re.search(
        r"_chain_inputs = None.*?nifty_spot_used",
        app_code, re.S,
    )
    assert m, "execution-suite chain wiring not found in app.py"
    body = m.group(0)
    assert "fetch_nse_option_chain" in body
    assert "resolve_live_chain_inputs" in body
    assert 'iv=(_chain_inputs["iv"] if _chain_inputs else 0.18)' in body
    assert 'dte_days=(_chain_inputs["dte_days"] if _chain_inputs else 30)' in body
    assert "beta_floor=0.30" in body
    assert 'iv_source=(_chain_inputs["iv_source"] if _chain_inputs else None)' in body


# ══════════════════════════════════════════════════════════════════════
# R23-2 — tax endpoint live mark refresh
# ══════════════════════════════════════════════════════════════════════

def test_r23_2a_tax_endpoint_refreshes_marks_and_discloses_freshness():
    """Pattern lock: the tax endpoint attempts a live quote refresh, persists
    it through the journal, and discloses either freshness or staleness.
    AUDIT-FIX (Round 24 — R24-4 supersession): the refresh is now layered
    (NSE quote-equity first, BSE .BO fallback second) with per-mark
    provenance + measured staleness; the lock was updated to the stronger
    wiring."""
    app_code = _code_only(APP)
    m = re.search(r"def _handle_tax_optimizer\(.*?(?=\n    def )", app_code, re.S)
    assert m, "_handle_tax_optimizer not found in app.py"
    body = m.group(0)
    assert "fetch_equity_last_prices_multi_source(" in body
    assert "journal.update_live_prices(_prices_only, price_sources=_sources_only)" in body
    assert '"marks_refreshed_count"' in body
    assert '"marks"' in body  # per-symbol provenance + staleness detail
    assert "LAST MARKED prices" in body  # stale disclosure, not silent
    assert '"state"' in body and '"age_hours"' in body


def test_r23_2b_fetch_nse_equity_last_prices_parsing_and_honesty(monkeypatch):
    """Quote parser: priceInfo.lastPrice extraction keyed by the caller's raw
    ticker form; failures return an empty dict (no fabricated prices)."""
    from data_layer import fetch_nse_equity_last_prices, _EQ_QUOTE_CACHE
    import utils as _utils

    class _FakeResponse:
        status_code = 200

        def json(self):
            return {"priceInfo": {"lastPrice": 2987.65}}

    calls = {"n": 0}

    def _fake_get(cls, url, params=None, headers=None, timeout=6, stream=False):
        calls["n"] += 1
        return _FakeResponse()

    _EQ_QUOTE_CACHE.clear()
    monkeypatch.setattr(_utils.NSEClient, "get", classmethod(_fake_get))
    out = fetch_nse_equity_last_prices(["RELIANCE.NS", "TCS"])
    assert out["RELIANCE.NS"] == 2987.65  # raw key preserved for journal matching
    assert out["TCS"] == 2987.65
    # Cache hit: second call makes no additional HTTP request
    n = calls["n"]
    out2 = fetch_nse_equity_last_prices(["RELIANCE.NS"])
    assert out2["RELIANCE.NS"] == 2987.65 and calls["n"] == n

    class _FailResponse:
        status_code = 403

        def json(self):
            return {}

    monkeypatch.setattr(_utils.NSEClient, "get", classmethod(
        lambda cls, url, **kw: _FailResponse()))
    _EQ_QUOTE_CACHE.clear()
    assert fetch_nse_equity_last_prices(["WIPRO"]) == {}  # honest empty, no fabrication


# ══════════════════════════════════════════════════════════════════════
# R23-3 — disclosed beta floor + Barra cross-check
# ══════════════════════════════════════════════════════════════════════

def test_r23_3a_beta_floor_behavior_and_disclosure():
    """A near-zero microcap beta is floored (hedge size protected), the
    floored ticker is DISCLOSED, CASH stays exempt, NaN betas are counted."""
    from math_engine.options_hedger import OptionsTailHedger

    pdf = pd.DataFrame([
        {"Ticker": "MICROCAP", "Weight %": 60.0, "Beta": 0.05},
        {"Ticker": "LARGECAP", "Weight %": 30.0, "Beta": 1.2},
        {"Ticker": "CASH", "Weight %": 10.0, "Beta": 0.0},
    ])
    h = OptionsTailHedger(nifty_price=24000.0)
    r_plain = h.calculate_hedge_recommendation(pdf, portfolio_value=1_000_000, regime="Bear")
    r_floor = h.calculate_hedge_recommendation(
        pdf, portfolio_value=1_000_000, regime="Bear",
        beta_floor=0.30, barra_portfolio_beta=0.621,
    )
    # 0.6*0.05 + 0.3*1.2 = 0.39 (the collapsed GARP-style basis)
    assert r_plain["portfolio_beta_weighted_delta"] == pytest.approx(0.39)
    # 0.6*0.30 + 0.3*1.2 = 0.54 (floored — hedge size protected)
    assert r_floor["portfolio_beta_weighted_delta"] == pytest.approx(0.54)
    assert r_floor["portfolio_delta_rupee_val"] > r_plain["portfolio_delta_rupee_val"]
    # Disclosure, never silent
    assert r_floor["beta_floor_applied_to"] == ["MICROCAP"]
    assert r_floor["beta_floor"] == 0.30
    assert "MICROCAP" in r_floor["beta_basis_note"]
    assert "CASH" not in r_floor["beta_floor_applied_to"]
    # Barra cross-check echoed
    assert r_floor["barra_portfolio_beta"] == 0.621
    assert r_floor["barra_cross_check_note"] is not None
    # Without a floor the response says so
    assert r_plain["beta_floor"] is None
    # NaN beta rows counted in the note
    pdf_nan = pd.DataFrame([{"Ticker": "X", "Weight %": 100.0, "Beta": np.nan}])
    r_nan = h.calculate_hedge_recommendation(pdf_nan, portfolio_value=1_000_000, regime="Bear")
    assert "1 row(s) had NaN beta defaulted to 1.0" in r_nan["beta_basis_note"]


def test_r23_3b_sweep_passes_beta_floor_and_barra_beta():
    """Pattern lock: the sweep wires TAIL_HEDGE_BETA_FLOOR (default 0.30) and
    the Barra portfolio beta into the hedge call, and logs the floor use."""
    opt_code = _code_only(OPTIMIZER)
    assert 'working_cfg.get("TAIL_HEDGE_BETA_FLOOR", 0.30)' in opt_code
    assert "beta_floor=_tail_beta_floor" in opt_code
    assert "barra_portfolio_beta=_barra_beta_for_hedge" in opt_code
    assert 'risk_attrib.get("portfolio_beta")' in opt_code


# ══════════════════════════════════════════════════════════════════════
# R23-4 — walk-forward selection-bias diagnostics
# ══════════════════════════════════════════════════════════════════════

def test_r23_4a_walkforward_overlap_measures_retroactivity():
    """A historically stable basket scores high overlap / LOW risk; a
    retroactive basket (leaders only in the final segment) scores low
    overlap / HIGH risk; degenerate inputs are honestly UNMEASURED."""
    from math_engine.oos_walkforward import walk_forward_selection_overlap

    rng = np.random.default_rng(7)
    n_days, n_stocks = 500, 30
    dates = pd.date_range("2025-01-01", periods=n_days, freq="B")
    close = pd.DataFrame(
        100 + rng.normal(0, 0.5, (n_days, n_stocks)).cumsum(axis=0),
        index=dates, columns=[f"S{i:02d}" for i in range(n_stocks)],
    )
    for i in range(5):  # persistent leaders all window long
        close[f"S{i:02d}"] = 100 * np.exp(np.linspace(0, 0.6 + 0.1 * i, n_days))
    stable = [f"S{i:02d}" for i in range(5)]
    res_stable = walk_forward_selection_overlap(close, stable)
    assert res_stable["mean_overlap_pct"] >= 80.0
    assert "LOW" in res_stable["retroactive_basket_risk"]

    # Retroactive: tickers that only rise in the last 60 days
    late = [f"S{5 + j:02d}" for j in range(5)]
    for j, t in enumerate(late):
        arr = np.ones(n_days) * 100
        arr[n_days - 60:] = np.linspace(100, 160 + 10 * j, 60)
        close[t] = arr
    res_retro = walk_forward_selection_overlap(close, late)
    assert res_retro["mean_overlap_pct"] < res_stable["mean_overlap_pct"]
    assert res_retro["mean_overlap_pct"] < 25.0
    assert "HIGH" in res_retro["retroactive_basket_risk"]
    assert "retroactive-basket artifact" in res_retro["retroactive_basket_risk"]

    # Degenerate inputs -> honest UNMEASURED, no fabricated numbers
    assert "UNMEASURED" in walk_forward_selection_overlap(None, [])["retroactive_basket_risk"]
    assert "UNMEASURED" in walk_forward_selection_overlap(close.iloc[:50], stable)["retroactive_basket_risk"]


def test_r23_4b_fold_alpha_concentration_flags_lucky_fold():
    from math_engine.oos_walkforward import fold_alpha_concentration

    idx = pd.date_range("2025-01-01", periods=300, freq="B")
    # All alpha in the first 50 days -> CONCENTRATED verdict
    port = pd.Series(0.0, index=idx)
    port.iloc[0:50] = 0.01
    fa = fold_alpha_concentration(port, pd.Series(0.0, index=idx), n_folds=6)
    assert "CONCENTRATED" in fa["alpha_concentration_verdict"]
    assert fa["best_fold_share_pct"] > 80.0
    assert len(fa["folds"]) == 6
    # Broad alpha -> BROAD-BASED
    rng = np.random.default_rng(3)
    port2 = pd.Series(rng.normal(0.0009, 0.01, 300), index=idx)
    bench2 = pd.Series(rng.normal(0.0002, 0.008, 300), index=idx)
    fa2 = fold_alpha_concentration(port2, bench2, n_folds=6)
    assert "BROAD-BASED" in fa2["alpha_concentration_verdict"]
    # Degenerate -> honest UNMEASURED
    assert "UNMEASURED" in fold_alpha_concentration(pd.Series(dtype=float), None)["alpha_concentration_verdict"]


def test_r23_4c_optimizer_wires_wfo_diagnostics():
    """Pattern lock: the sweep emits oos_walkforward_diagnostics and logs the
    overlap/concentration verdicts."""
    opt_code = _code_only(OPTIMIZER)
    assert '"oos_walkforward_diagnostics"' in opt_code
    assert "walk_forward_selection_overlap(" in opt_code
    assert "fold_alpha_concentration(" in opt_code
    assert "[WFO-Diag]" in opt_code


# ══════════════════════════════════════════════════════════════════════
# R23-5 — tax assumption disclosure
# ══════════════════════════════════════════════════════════════════════

def test_r23_5a_tax_engine_returns_assumptions_both_paths():
    from math_engine.tax_loss_harvesting import TaxLossHarvestingOptimizer

    lots = pd.DataFrame([{"Ticker": "REL", "BuyPrice": 3000.0, "Shares": 10, "HoldingDays": 90}])
    res = TaxLossHarvestingOptimizer.identify_harvestable_lots(lots, {"REL": 2500.0})
    assert res["total_tax_saved_inr"] == 1000.0  # R22 math unchanged
    assert isinstance(res.get("assumptions"), list) and len(res["assumptions"]) >= 3
    joined = " ".join(res["assumptions"]).lower()
    assert "offsettable" in joined or "carried-forward" in joined
    assert "exemption" in joined
    # Empty path carries the same disclosure
    res_empty = TaxLossHarvestingOptimizer.identify_harvestable_lots(pd.DataFrame(), {})
    assert res_empty.get("assumptions") == res["assumptions"]


def test_r23_5b_endpoint_and_panel_disclose_assumptions():
    """The endpoint response carries the assumptions list and the panel
    renders them on hover with the mark-freshness note."""
    app_code = _code_only(APP)
    m = re.search(r"def _handle_tax_optimizer\(.*?(?=\n    def )", app_code, re.S)
    assert m
    body = m.group(0)
    assert '"assumptions"' in body
    assert "exemption slab is NOT modeled" in body or "exemption" in body

    js_src = DASHBOARD_JS.read_text(encoding="utf-8")
    assert "d.assumptions" in js_src
    assert "marks_refreshed_count" in js_src
