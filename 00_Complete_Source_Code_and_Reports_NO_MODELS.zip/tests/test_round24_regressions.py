"""Round 24 regression locks — the five residuals from BUGFIX_REPORT_ROUND23 §4.

  R24-1: FULL walk-forward RE-SELECTION — the screen (mode-weighted prescreen
         scoring) is re-run point-in-time at each of K cutoffs on trailing
         data only, the point-in-time basket is forward-tested, and a
         TRUE-OOS alpha + measured retroactive-basket bias are reported
         (payload key oos_walkforward_reselection). The honest scope (QUBO /
         pool prescreen / live-only filters not replayed) is disclosed.
  R24-2: GEX gamma is STRIKE-SOLVED Black-Scholes (N'(d1)/(S·σ·√T)) with
         per-strike chain IVs (fallback chain-level IV) — the flat
         0.0001 × spot² proxy is gone; provenance/model disclosed; degenerate
         IV strikes contribute zero, never fabricated gamma.
  R24-3: Beta floor is a MODEL now — liquidity-aware shrinkage estimator
         (beta_adj = w·beta_OLS + (1−w)·1.0, w = n_eff/(n_eff+κ)) in the
         signal frame; the flat floor at the hedge site is a disclosed
         backstop; raw beta + shrink weight are retained for disclosure.
  R24-4: Non-NSE-quoted symbols get a real second source (BSE .BO via
         yfinance) in the tax mark refresh; every journal mark carries
         last_mark_ts + price_mark_source; the endpoint reports per-symbol
         provenance + measured staleness.
  R24-5: Realized-gains LEDGER (core/realized_gains_ledger.py) recorded by
         the journal on every close; tax engine models Sec 70/74 set-off
         order, 8-year carry-forward, and the Rs 1.25L LTCG exemption slab;
         endpoint exposes net_tax_position + persists carry-forward state.
"""

import io
import re
import tempfile
import tokenize
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "web_dashboard" / "app.py"
DATA_LAYER = ROOT / "data_layer.py"
OPTIMIZER = ROOT / "optimizer.py"
UTILS = ROOT / "utils.py"
HEDGER = ROOT / "math_engine" / "options_hedger.py"
INDICATORS = ROOT / "math_engine" / "indicators.py"
TAX_ENGINE = ROOT / "math_engine" / "tax_loss_harvesting.py"
WFO = ROOT / "math_engine" / "oos_walkforward.py"
JOURNAL = ROOT / "core" / "trade_journal.py"
LEDGER = ROOT / "core" / "realized_gains_ledger.py"
DASHBOARD_JS = ROOT / "web_dashboard" / "dashboard.js"


def _code_only(path: Path) -> str:
    """Return the source of `path` with comments and docstrings removed.

    Pattern locks must run against executable code only — AUDIT-FIX comments
    and docstrings legitimately QUOTE the eliminated bug patterns, which
    would otherwise trip `not in` assertions.
    """
    import ast

    src = path.read_text(encoding="utf-8")
    tree = ast.parse(src)
    docstring_lines = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                docstring_lines.add(node.body[0].lineno)
    kept = []
    for tok in tokenize.generate_tokens(io.StringIO(src).readline):
        if tok.type == tokenize.COMMENT:
            continue
        if tok.type == tokenize.STRING and tok.start[0] in docstring_lines:
            continue
        kept.append(tok)
    return tokenize.untokenize(kept)


# ══════════════════════════════════════════════════════════════════════
# R24-1 — full walk-forward RE-SELECTION
# ══════════════════════════════════════════════════════════════════════

def test_r24_1a_reselection_deterministic_math():
    """Single-fold hand-check: the point-in-time top-K basket is selected on
    trailing momentum, weighted inverse-vol (single name -> w=1), forward
    returns match the hand-computed value, and the bias vs a passed
    retroactive alpha is headline - true-OOS."""
    from math_engine.oos_walkforward import walk_forward_reselection_backtest

    n = 160
    dates = pd.bdate_range("2025-01-01", periods=n)
    close = pd.DataFrame({
        "FLAT.NS": [100.0] * n,
        "WIN.NS": list(np.linspace(100.0, 130.0, n)),   # steady riser
        "LOSE.NS": list(np.linspace(100.0, 85.0, n)),   # steady decliner (3rd name
                                                          # keeps robust-z non-degenerate)
    }, index=dates)
    vol = pd.DataFrame(1e6, index=dates, columns=close.columns, dtype=float)
    # After the cutoff (day 126+), WIN drops 10% on the first forward day and STAYS there
    close.loc[dates[127:], "WIN.NS"] = close.loc[dates[126], "WIN.NS"] * 0.90

    res = walk_forward_reselection_backtest(
        close, vol, n_folds=1, score_lookback=126, k_stocks=1,
        mode="balanced", benchmark_returns=pd.Series(0.0, index=dates),
        fee_bps=0.0, selected_final=["WIN.NS"], retroactive_alpha_ann=0.30,
    )
    f0 = res["folds"][0]
    assert f0["basket"] == ["WIN.NS"]  # trailing momentum picks the riser
    assert f0["weights"] == {"WIN.NS": 1.0}  # single name, w=1
    # Fold total return = -10.00% exactly (no fee), forward from cutoff+1
    assert f0["fold_total_return_pct"] == pytest.approx(-10.0, abs=0.05)
    assert res["true_oos_total_return_pct"] == pytest.approx(-10.0, abs=0.05)
    # Bias = retroactive (30%) - true OOS alpha (annualized from -10% over fwd days)
    assert res["retroactive_alpha_ann_pct"] == pytest.approx(30.0)
    assert res["retroactive_basket_bias_pct"] is not None
    assert "HIGH SELECTION BIAS" in res["verdict"]
    assert "method_disclosure" in res and "inverse-vol" in res["method_disclosure"]


def test_r24_1b_reselection_is_point_in_time():
    """No look-ahead: a ticker that only starts rising at day 200 is NEVER
    selected at cutoffs that end before day 200, and IS selected once its
    rise enters the trailing window — selection at each cutoff uses only
    trailing data.

    SUPERSESSION (Round 25 — R25-1): the fold basket is now chosen by the
    QUBO-CORE replay (alpha + vol penalty + correlation + cardinality), so a
    perfectly FLAT ticker can legitimately enter an early basket through
    the vol/diversification term — trailing zero vol IS trailing information
    (the production risk_score is vol-dominated exactly the same way), so
    that is not look-ahead. The original momentum-semantics assertions now
    lock the `reference_topk_basket` (the pure mode-score top-K, R24
    semantics, reported per fold), and the no-look-ahead property is locked
    DIRECTLY by cutoff-invariance: fold 1 is decided at day 126, so its
    basket must be IDENTICAL whether or not the frame contains the post-200
    rise — any difference means future data leaked into selection.
    """
    from math_engine.oos_walkforward import walk_forward_reselection_backtest

    n = 300
    dates = pd.bdate_range("2025-01-01", periods=n)
    cols = {}
    for i in range(10):  # steady mild risers (momentum ~ +13% per window)
        cols[f"N{i:02d}.NS"] = 100.0 * np.exp(0.001 * np.arange(n))
    late = np.ones(n) * 100.0
    late[200:] = 100.0 * np.exp(0.015 * (np.arange(200, n) - 200))  # +1.5%/d from day 200
    cols["LATE.NS"] = late
    close = pd.DataFrame(cols, index=dates)
    vol = pd.DataFrame(1e6, index=dates, columns=close.columns, dtype=float)

    res = walk_forward_reselection_backtest(
        close, vol, n_folds=3, score_lookback=126, k_stocks=2,
        mode="balanced", benchmark_returns=None,
    )
    assert len(res["folds"]) == 3
    b1 = res["folds"][0]["basket"]
    # Reference basket (pure mode-score top-K, the R24 semantics): the rise
    # is invisible before day 200 -> LATE excluded early, included late.
    r1, r2, r3 = (res["folds"][k]["reference_topk_basket"] for k in range(3))
    assert "LATE.NS" not in r1
    assert "LATE.NS" not in r2
    assert "LATE.NS" in r3
    # Look-ahead detector (cutoff-invariance): fold 1 is decided at day 126.
    # Truncating the frame at day 150 (well before the day-200 rise) cannot
    # change that decision — if it does, future data leaked into selection.
    res_trunc = walk_forward_reselection_backtest(
        close.iloc[:150].copy(), vol.iloc[:150].copy(),
        n_folds=1, score_lookback=126, k_stocks=2, mode="balanced",
        benchmark_returns=None,
    )
    assert res_trunc["folds"], "truncated run must still produce fold 1"
    assert res_trunc["folds"][0]["basket"] == b1, (
        "fold-1 basket changed when post-cutoff data was removed — look-ahead leak"
    )


def test_r24_1c_reselection_honest_degenerates():
    from math_engine.oos_walkforward import walk_forward_reselection_backtest
    r1 = walk_forward_reselection_backtest(pd.DataFrame(), None)
    assert "UNMEASURED" in r1["verdict"]
    r2 = walk_forward_reselection_backtest(None, None)
    assert "UNMEASURED" in r2["verdict"]
    dates = pd.bdate_range("2025-01-01", periods=150)
    short = pd.DataFrame({"A.NS": [100.0] * 150}, index=dates)
    r3 = walk_forward_reselection_backtest(short, None, n_folds=4)
    assert "UNMEASURED" in r3["verdict"]


def test_r24_1d_optimizer_wires_reselection():
    """Pattern lock: the sweep runs the re-selection by default, passes the
    volume frame + retroactive alpha, publishes the payload key, and logs
    the verdict.

    SUPERSESSION (Round 25 — R25-1): the call site now routes the frames
    through _wfr_close/_wfr_volume (default: identical inheritance of the
    in-memory pool; opt-in WFO_POOL_FULL_UNIVERSE re-downloads a supersample
    frame so the TOP_N pool cut is replayed point-in-time) and replays the
    ALLOCATION layer (QUBO-core selection + production HRP weighting) with
    the run's working_cfg coefficients. Locks updated to the stronger
    wiring; the R24 intent (default-on, volume frame, retroactive alpha,
    payload key, verdict log) is unchanged.
    """
    opt_code = _code_only(OPTIMIZER)
    assert 'working_cfg.get("WFO_FULL_RESELECTION", True)' in opt_code
    assert "walk_forward_reselection_backtest(" in opt_code
    # R25-1: frames flow through the pool-inheritance/supersample variables
    assert "_wfr_volume = (volume if volume is not None and not volume.empty else None)" in opt_code
    assert "volume_df=_wfr_volume" in opt_code
    assert "close_df=_wfr_close" in opt_code
    # R25-1: the allocation layer is replayed with the run's coefficients
    assert "replay_allocation=True" in opt_code
    assert "allocation_cfg=working_cfg" in opt_code
    assert "top_n_pool=_wfr_pool" in opt_code
    assert 'working_cfg.get("WFO_POOL_FULL_UNIVERSE", False)' in opt_code
    assert 'int(working_cfg.get("WFO_HRP_LOOKBACK", 63) or 63)' in opt_code
    assert 'backtest["Alpha vs Benchmark"]' in opt_code
    assert '"oos_walkforward_reselection"' in opt_code
    assert "[WFO-ReSel]" in opt_code


# ══════════════════════════════════════════════════════════════════════
# R24-2 — strike-solved BS gamma
# ══════════════════════════════════════════════════════════════════════

def test_r24_2a_bs_gamma_closed_form_and_wings():
    from math_engine.options_hedger import _bs_gamma
    from scipy.stats import norm

    S, r, sig, T = 24000.0, 0.065, 0.14, 14 / 252
    d1 = (np.log(S / S) + (r + 0.5 * sig ** 2) * T) / (sig * np.sqrt(T))
    g_atm = norm.pdf(d1) / (S * sig * np.sqrt(T))
    assert _bs_gamma(S, S, r, sig, T) == pytest.approx(g_atm, rel=1e-12)
    # Wing gamma decays by ~2 orders of magnitude (the flat proxy overstated it)
    g_wing = _bs_gamma(S, S * 0.90, r, sig, T)
    assert g_wing < 0.01 * g_atm
    # Degenerate inputs -> 0.0 (no fabricated gamma)
    assert _bs_gamma(0.0, S, r, sig, T) == 0.0
    assert _bs_gamma(S, S, r, 0.0, T) == 0.0
    assert _bs_gamma(S, S, r, sig, 0.0) == 0.0


def test_r24_2b_gex_strike_solved_per_strike_iv():
    from math_engine.options_hedger import OptionsTailHedger, _bs_gamma

    S = 24000.0
    chain = pd.DataFrame({
        "strikePrice": [22000.0, 24000.0, 26000.0],
        "callOI":      [100.0,   2000.0,  50.0],
        "putOI":       [800.0,   1500.0,  30.0],
        "callIV":      [22.0,    14.0,    12.0],
        "putIV":       [26.0,    15.0,    12.5],
    })
    h = OptionsTailHedger(nifty_price=S)
    res = h.calculate_net_gamma_exposure(option_chain=chain, iv=0.14, dte_days=14,
                                         iv_source="live test", dte_source="live test")
    # Hand-verify every strike with ITS OWN IV
    T, r = 14 / 252, 0.065
    expected = 0.0
    for _, row in chain.iterrows():
        k = row["strikePrice"]
        sig = row["callIV"] / 100.0
        expected += _bs_gamma(S, k, r, sig, T) * (row["callOI"] - row["putOI"]) * 75 * S ** 2
    assert res["net_gex_rupees"] == pytest.approx(expected, rel=1e-9)
    assert "per-strike IV" in res["gamma_model"]
    assert "live test" in res["gex_source"]
    g = res["gamma_range"]
    assert g[1] > 10 * g[0]  # ATM-to-wing spread is real, not flat

    # Fallback path: no IV columns -> chain-level iv for every strike
    res2 = h.calculate_net_gamma_exposure(option_chain=chain.drop(columns=["callIV", "putIV"]),
                                          iv=0.14, dte_days=14)
    expected2 = sum(
        _bs_gamma(S, row["strikePrice"], r, 0.14, T) * (row["callOI"] - row["putOI"]) * 75 * S ** 2
        for _, row in chain.iterrows()
    )
    assert res2["net_gex_rupees"] == pytest.approx(expected2, rel=1e-9)
    assert "chain-level IV" in res2["gamma_model"]

    # Degenerate IV rows contribute zero and are DISCLOSED, never fabricated
    chain_bad = chain.copy()
    chain_bad["callIV"] = [0.0, 14.0, np.nan]
    chain_bad["putIV"] = [0.0, 15.0, np.nan]
    res3 = h.calculate_net_gamma_exposure(option_chain=chain_bad, iv=0.0, dte_days=14)
    # strike 22000 has no usable IV anywhere (per-strike 0/0, fallback iv=0) -> 0 contribution
    only_atm = _bs_gamma(S, 24000.0, r, 0.14, T) * (2000.0 - 1500.0) * 75 * S ** 2
    assert res3["net_gex_rupees"] == pytest.approx(only_atm, rel=1e-9)
    assert "contributed 0" in res3["gex_source"]

    # Canned prior is disclosed as a placeholder, not a measurement
    res4 = h.calculate_net_gamma_exposure(option_chain=None)
    assert "CANNED PRIOR" in res4["gex_source"]
    assert res4["net_gex_rupees"] == 150_000_000.0


def test_r24_2c_flat_gamma_proxy_eliminated():
    """The 0.0001 × spot² flat proxy must be gone from executable code."""
    hedger_code = _code_only(HEDGER)
    assert "0.0001" not in hedger_code
    assert "_bs_gamma(" in hedger_code
    assert "gamma_model" in hedger_code
    assert "gex_source" in hedger_code


# ══════════════════════════════════════════════════════════════════════
# R24-3 — liquidity-aware beta estimator
# ══════════════════════════════════════════════════════════════════════

def test_r24_3a_liquidity_aware_beta_behavior():
    from math_engine.indicators import liquidity_aware_beta, compute_beta

    rng = np.random.default_rng(5)
    n = 120
    idx = pd.bdate_range("2025-01-01", periods=n)
    bench = pd.Series(rng.normal(0.0005, 0.01, size=n), index=idx)
    asset = pd.Series(1.8 * bench.values + rng.normal(0, 0.02, size=n), index=idx)
    b_ols = compute_beta(asset, bench)

    # Liquid (ADV >= Rs5cr): retains >= 89% weight, beta close to OLS
    b_liq, d_liq = liquidity_aware_beta(asset, bench, adv20=2e8)
    assert d_liq["shrink_weight"] == pytest.approx(63 / 71, abs=1e-3)
    assert abs(b_liq - b_ols) / max(abs(b_ols), 1.0) < 0.15

    # Illiquid microcap (ADV Rs10L): strong shrink toward prior 1.0
    b_ill, d_ill = liquidity_aware_beta(asset, bench, adv20=1e6)
    assert d_ill["shrink_weight"] < 0.2
    w = d_ill["shrink_weight"]
    assert b_ill == pytest.approx(w * b_ols + (1 - w) * 1.0, abs=1e-3)
    assert b_ill > 0.9  # prior-dominated

    # THE collapse case: near-zero OLS beta on an illiquid name lands near
    # the prior, not at 0 (the old flat floor would have said 0.30)
    zero_asset = pd.Series(0.05 * bench.values + rng.normal(0, 0.03, size=n), index=idx)
    b_zero, _ = liquidity_aware_beta(zero_asset, bench, adv20=2e6)
    assert b_zero > 0.5

    # Degenerate: short series -> NaN with honest diagnostics
    b_short, d_short = liquidity_aware_beta(asset.iloc[:10], bench.iloc[:10])
    assert np.isnan(b_short) and np.isnan(d_short["beta_ols"])

    # adv20 unknown: neutral liquidity factor, sample-only mild shrink
    b_nol, d_nol = liquidity_aware_beta(asset, bench, adv20=None)
    assert d_nol["liquidity_factor"] == 1.0 and d_nol["shrink_weight"] > 0.8


def test_r24_3b_signal_frame_carries_beta_disclosure_columns():
    from utils import compute_signal_frame

    rng = np.random.default_rng(9)
    dates = pd.bdate_range("2025-01-01", periods=400)
    bench = pd.Series(rng.normal(0.0005, 0.01, size=400), index=dates)
    close = pd.DataFrame({
        "LIQ.NS": 100 * np.exp(np.cumsum(rng.normal(0.0008, 0.015, 400))),
        "ILLQ.NS": 100 * np.exp(np.cumsum(rng.normal(0.0002, 0.01, 400))),
    }, index=dates)
    # LIQ: ADV ~Rs10cr; ILLQ: ADV ~Rs30L (price ~100 x shares)
    vol = pd.DataFrame({"LIQ.NS": 1e7, "ILLQ.NS": 3e4}, index=dates, dtype=float)
    data = {"Close": close, "Volume": vol}
    rets = np.log(close / close.shift(1)).fillna(0.0)

    sig = compute_signal_frame(data, rets, bench, cfg={"USE_LIQUIDITY_AWARE_BETA": True})
    for col in ("beta", "beta_raw", "beta_shrink_weight"):
        assert col in sig.columns
    assert np.isfinite(sig.loc["LIQ.NS", "beta"])
    # The illiquid row shrinks harder than the liquid row
    assert sig.loc["ILLQ.NS", "beta_shrink_weight"] < sig.loc["LIQ.NS", "beta_shrink_weight"]

    # Opt-out flag reverts to exact raw OLS
    sig2 = compute_signal_frame(data, rets, bench, cfg={"USE_LIQUIDITY_AWARE_BETA": False})
    assert (sig2["beta_shrink_weight"] == 1.0).all()
    assert np.allclose(sig2["beta"], sig2["beta_raw"], equal_nan=True)


def test_r24_3c_hedge_discloses_estimator_backstop():
    from math_engine.options_hedger import OptionsTailHedger

    pdf = pd.DataFrame([{"Ticker": "MICRO", "Weight %": 50.0, "Beta": 0.7},
                        {"Ticker": "LARGE", "Weight %": 50.0, "Beta": 1.1}])
    h = OptionsTailHedger(nifty_price=24000.0)
    r = h.calculate_hedge_recommendation(pdf, portfolio_value=1_000_000, regime="Bear",
                                         beta_floor=0.30)
    assert "liquidity-aware shrinkage" in r["beta_estimation_note"]
    assert "BACKSTOP" in r["beta_estimation_note"]
    # Estimator-adjusted betas arrive above the floor -> floor not applied
    assert r["beta_floor_applied_to"] == []

    ind_code = _code_only(INDICATORS)
    assert "def liquidity_aware_beta(" in ind_code
    util_code = _code_only(UTILS)
    assert 'cfg.get("USE_LIQUIDITY_AWARE_BETA", True)' in util_code
    assert "liquidity_aware_beta(" in util_code


# ══════════════════════════════════════════════════════════════════════
# R24-4 — layered price marks + staleness
# ══════════════════════════════════════════════════════════════════════

def test_r24_4a_multi_source_fetcher_bse_fallback_and_honesty(monkeypatch):
    import data_layer as dl

    # Layer 1 mocked: NSE serves only the first symbol
    monkeypatch.setattr(dl, "fetch_nse_equity_last_prices",
                        lambda symbols, log_cb=None, max_symbols=40: {"NSEOK.NS": 1234.5})
    calls = {"n": 0}

    def _fake_bse(clean_sym, log_cb=None):
        calls["n"] += 1
        if clean_sym == "BSEONLY":
            return 55.5, "BSE (.BO) via yfinance"
        return None, "no usable BSE price"

    monkeypatch.setattr(dl, "_bse_last_price_yfinance", _fake_bse)
    dl._BSE_QUOTE_CACHE.clear()

    out = dl.fetch_equity_last_prices_multi_source(["NSEOK.NS", "BSEONLY.NS", "NOQUOTE.NS"])
    assert set(out.keys()) == {"NSEOK.NS", "BSEONLY.NS"}  # NOQUOTE omitted honestly
    assert out["NSEOK.NS"]["price"] == 1234.5
    assert out["NSEOK.NS"]["source"].startswith("NSE")
    assert isinstance(out["NSEOK.NS"]["fetched_at"], float)
    assert out["BSEONLY.NS"]["price"] == 55.5
    assert "BSE" in out["BSEONLY.NS"]["source"]

    # BSE cache: second call serves BSEONLY without re-invoking the fetcher
    n_before = calls["n"]
    dl._EQ_QUOTE_CACHE.clear()
    out2 = dl.fetch_equity_last_prices_multi_source(["BSEONLY.NS"])
    assert out2["BSEONLY.NS"]["price"] == 55.5
    assert calls["n"] == n_before


def test_r24_4b_journal_stamps_mark_provenance_and_time():
    from core.trade_journal import TradeJournalManager
    from core.realized_gains_ledger import RealizedGainsLedger

    tmp = Path(tempfile.mkdtemp())
    jm = TradeJournalManager(storage_path=tmp / "j.json")
    jm.realized_ledger = RealizedGainsLedger(storage_path=tmp / "rg.json")
    jm.trades = [{
        "id": "T1", "basket_name": "b", "ticker": "X.NS", "entry_date": "2026-06-01",
        "entry_price": 100.0, "current_price": 100.0, "stop_loss_price": 50.0,
        "snell_target_price": 999.0, "weight_pct": 5.0, "profile_source": "t",
        "status": "ACTIVE", "unlevelled": False, "unrealized_pnl_%": 0.0,
        "realized_pnl_%": 0.0, "exit_date": None, "exit_price": None, "notes": "",
    }]
    jm.update_live_prices({"X.NS": 101.0}, price_sources={"X.NS": "BSE (.BO) via yfinance"})
    t = jm.trades[0]
    assert t["price_mark_source"] == "BSE (.BO) via yfinance"
    assert isinstance(t["last_mark_ts"], float) and t["last_mark_ts"] > 0
    # Unlabeled refresh falls back to a generic source, still stamped
    jm.update_live_prices({"X.NS": 102.0})
    assert jm.trades[0]["price_mark_source"] == "unlabeled refresh"


def test_r24_4c_endpoint_layered_marks_pattern():
    app_code = _code_only(APP)
    m = re.search(r"def _handle_tax_optimizer\(.*?(?=\n    def )", app_code, re.S)
    assert m
    body = m.group(0)
    assert "fetch_equity_last_prices_multi_source(" in body
    assert "price_sources=_sources_only" in body
    assert '"age_hours"' in body and '"state"' in body
    assert "BSE (.BO) fallback" in body

    dl_code = _code_only(DATA_LAYER)
    assert "def fetch_equity_last_prices_multi_source(" in dl_code
    assert 'f"{clean_sym}.BO"' in dl_code
    assert "def _bse_last_price_yfinance(" in dl_code


# ══════════════════════════════════════════════════════════════════════
# R24-5 — realized-gains ledger + set-off + LTCG exemption
# ══════════════════════════════════════════════════════════════════════

def test_r24_5a_compute_tax_position_setoff_math():
    from math_engine.tax_loss_harvesting import TaxLossHarvestingOptimizer as T

    holdings = pd.DataFrame([
        {"Ticker": "ST", "BuyPrice": 200.0, "Shares": 100, "HoldingDays": 90},
        {"Ticker": "LT", "BuyPrice": 300.0, "Shares": 100, "HoldingDays": 500},
    ])
    cur = {"ST": 100.0, "LT": 100.0}  # STCL 10,000 + LTCL 20,000 harvestable

    # 1. Full walk: STCL absorbs STCG first, then LTCG; LTCL only LTCG;
    #    exemption applies to net LTCG after set-off.
    r = T.compute_tax_position(
        holdings, cur,
        realized_gains={"STCG": 60000.0, "LTCG": 40000.0, "unpriced_events": 0},
        carried_forward={"unabsorbed_stcl_inr": 0.0, "unabsorbed_ltcl_inr": 0.0},
        assessment_year="AY 2026-27",
    )
    assert r["tax_without_harvest_inr"] == pytest.approx(12000.0)  # 20%*60k + 12.5%*max(0,40k-125k)
    # Harvest: STCL 10k -> STCG 50k; LTCL 20k -> LTCG 20k (below exemption)
    assert r["tax_with_harvest_inr"] == pytest.approx(10000.0)     # 20%*50k
    assert r["immediate_tax_saving_inr"] == pytest.approx(2000.0)
    assert r["carry_forward_created_stcl_inr"] == 0.0
    assert r["carry_forward_created_ltcl_inr"] == 0.0
    assert r["ltcg_exemption_inr"] == 125000.0

    # 2. LTCL can NEVER offset STCG (Sec 70(3)) — it stays unabsorbed
    r2 = T.compute_tax_position(
        pd.DataFrame(), {},
        realized_gains={"STCG": 50000.0, "LTCG": 0.0, "unpriced_events": 0},
        carried_forward={"unabsorbed_stcl_inr": 0.0, "unabsorbed_ltcl_inr": 50000.0},
        assessment_year="AY 2026-27",
    )
    assert r2["tax_without_harvest_inr"] == pytest.approx(10000.0)
    assert r2["without_harvest"]["unabsorbed_ltcl"] == pytest.approx(50000.0)

    # 3. Exemption after set-off: STCL 50k consumes LTCG 300k -> 250k;
    #    exemption 125k -> taxable 125k -> 12.5% = 15,625
    r3 = T.compute_tax_position(
        pd.DataFrame(), {},
        realized_gains={"STCG": 0.0, "LTCG": 300000.0, "unpriced_events": 0},
        carried_forward={"unabsorbed_stcl_inr": 50000.0, "unabsorbed_ltcl_inr": 0.0},
        assessment_year="AY 2026-27",
    )
    assert r3["tax_without_harvest_inr"] == pytest.approx(15625.0)

    # 4. Nothing anywhere -> honest NO TAX POSITION
    r4 = T.compute_tax_position(pd.DataFrame(), {})
    assert "NO TAX POSITION" in r4["verdict"]


def test_r24_5b_ledger_records_idempotent_ay_bucketing():
    from core.realized_gains_ledger import RealizedGainsLedger, assessment_year_for_date

    assert assessment_year_for_date("2026-01-15") == "AY 2026-27"
    assert assessment_year_for_date("2025-03-31") == "AY 2025-26"
    assert assessment_year_for_date("bad") is None

    led = RealizedGainsLedger(storage_path=Path(tempfile.mkdtemp()) / "rg.json")
    e = led.record_realized_close({
        "id": "T1", "ticker": "A.NS", "entry_date": "2025-06-01", "exit_date": "2026-01-10",
        "entry_price": 100.0, "exit_price": 90.0, "realized_pnl_%": -10.0, "shares": 50,
    })
    assert e["tax_category"] == "STCG" and e["realized_pnl_inr"] == -500.0
    assert e["assessment_year"] == "AY 2026-27"
    # Re-recording the same journal close is a no-op (no double-count)
    assert led.record_realized_close({"id": "T1", "ticker": "A.NS",
                                       "entry_date": "2025-06-01", "exit_date": "2026-01-10",
                                       "entry_price": 100.0, "exit_price": 90.0}) is None
    e2 = led.record_realized_close({
        "id": "T2", "ticker": "B.NS", "entry_date": "2024-01-01", "exit_date": "2026-02-01",
        "entry_price": 200.0, "exit_price": 240.0, "realized_pnl_%": 20.0, "shares": 100,
    })
    assert e2["tax_category"] == "LTCG" and e2["realized_pnl_inr"] == 4000.0
    nets = led.net_gains_by_category("AY 2026-27")
    assert nets["STCG"] == -500.0 and nets["LTCG"] == 4000.0
    # Unpriced event (no shares, no pv) is counted, not guessed
    led.record_realized_close({"id": "T3", "ticker": "C.NS", "entry_date": "2025-11-01",
                               "exit_date": "2025-12-01", "entry_price": 100.0,
                               "exit_price": 95.0, "realized_pnl_%": -5.0})
    assert led.net_gains_by_category("AY 2026-27")["unpriced_events"] == 1
    # With pv provided, weight_pct scaling prices the event
    led.record_realized_close({"id": "T4", "ticker": "D.NS", "entry_date": "2025-11-01",
                               "exit_date": "2025-12-01", "entry_price": 100.0,
                               "exit_price": 95.0, "realized_pnl_%": -5.0, "weight_pct": 10.0})
    nets_pv = led.net_gains_by_category("AY 2026-27", portfolio_value_inr=1_000_000)
    # T4: 10% of 1M x -5% = -5,000; T3 stays unpriced
    assert nets_pv["STCG"] == pytest.approx(-500.0 - 5000.0)
    assert nets_pv["unpriced_events"] == 1


def test_r24_5c_journal_close_paths_feed_ledger():
    from core.trade_journal import TradeJournalManager
    from core.realized_gains_ledger import RealizedGainsLedger

    tmp = Path(tempfile.mkdtemp())
    jm = TradeJournalManager(storage_path=tmp / "j.json")
    jm.realized_ledger = RealizedGainsLedger(storage_path=tmp / "rg.json")
    jm.trades = [{
        "id": "TX", "basket_name": "b", "ticker": "Z.NS", "entry_date": "2026-06-01",
        "entry_price": 100.0, "current_price": 100.0, "stop_loss_price": 95.0,
        "snell_target_price": 120.0, "weight_pct": 5.0, "profile_source": "t",
        "status": "ACTIVE", "unlevelled": False, "unrealized_pnl_%": 0.0,
        "realized_pnl_%": 0.0, "exit_date": None, "exit_price": None, "notes": "",
    }]
    stats = jm.update_live_prices({"Z.NS": 93.0})
    assert stats["stops_triggered"] == 1
    entries = jm.realized_ledger.entries()
    assert len(entries) == 1 and entries[0]["journal_trade_id"] == "TX"
    # Backfill of the same closed trade adds nothing (idempotent)
    assert jm.realized_ledger.backfill_from_journal_trades(jm.trades) == 0


def test_r24_5d_endpoint_net_position_wiring():
    app_code = _code_only(APP)
    m = re.search(r"def _handle_tax_optimizer\(.*?(?=\n    def )", app_code, re.S)
    assert m
    body = m.group(0)
    assert "compute_tax_position(" in body
    assert '"net_tax_position"' in body
    assert "net_gains_by_category(" in body
    assert "_persist_carry_forward_state(" in body
    assert "_ledger_carry_forward_state(" in body
    assert '"immediate_tax_saving_inr"' in body

    # Engine constants lock the now-modeled rules
    tax_code = _code_only(TAX_ENGINE)
    assert "LTCG_EXEMPTION_INR: float = 125_000.0" in tax_code
    assert "CARRY_FORWARD_YEARS: int = 8" in tax_code
    ledger_exists = LEDGER.exists()
    assert ledger_exists
    js_src = DASHBOARD_JS.read_text(encoding="utf-8")
    assert "net_tax_position" in js_src
    assert "brought_forward_stcl_inr" in js_src
