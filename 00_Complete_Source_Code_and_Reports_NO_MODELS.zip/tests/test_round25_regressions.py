"""Round 25 regression locks — completing the five residuals from
BUGFIX_REPORT_ROUND24.md §4 (the honest residual list).

  R25-1: ALLOCATION-LAYER REPLAY in the walk-forward re-selection — the
         production QUBO's core objective (alpha/vol/correlation/cardinality,
         same coefficient formulas as optimizer.build_qubo) is solved
         greedy + first-improvement local search per cutoff on trailing
         data, and the PRODUCTION optimizer.hrp_weights weights the fold
         basket (local mirror fallback). An inverse-vol reference series
         (R24 semantics) is reported alongside so the allocation-layer
         effect is MEASURED. TOP_N pool replay is opt-in
         (WFO_POOL_FULL_UNIVERSE supersample mode).
  R25-2: MULTI-EXPIRY GEX aggregation — the nearest GEX_EXPIRY_DEPTH
         expiries (each 120s-cached, each solved with its OWN T and
         per-strike IVs) are summed with a per-expiry breakdown; the
         single-expiry R24 path runs unchanged when only one chain is
         available; the (CallOI-putOI) dealer-sign convention is disclosed
         verbatim on every computed response (NSE publishes no per-trade
         direction — data-blocked, honestly).
  R25-3: CHARACTERISTIC FACTOR-MODEL beta priors — the R24 liquidity-aware
         estimator's shrinkage TARGET is now a stock-specific prior (LOO
         cross-sectional ridge of trailing OLS beta on log-ADV / 6m
         momentum / 63d vol, Barra-style, from the LOCAL universe), with
         cfg BETA_FACTOR_FEED as the licensed-feed integration point and
         the flat prior only as disclosed fallback.
  R25-4: THREE-LAYER equity marks — direct NSE quote-equity -> Yahoo .NS
         (Yahoo's NSE feed, survives datacenter IP blocks) -> BSE .BO, each
         300s-cached below the 60s NSE layer, with per-source counts in the
         endpoint's refresh note.
  R25-5: TAX COMPLETENESS — surcharge slabs (LTCG portion capped at 15%,
         Finance Act 2022) + 4% Health & Education Cess (marginal relief
         disclosed as unmodeled), pre/post-23-Jul-2024 per-tranche rate
         regimes (15%/10%/Rs1L vs 20%/12.5%/Rs1.25L), Sec 112A(2)
         grandfathering (FMV-31-Jan-2018 deemed cost via the
         TAX_FMV_31JAN2018 feed), and the trade-date holding-period
         convention (Sec 2(42A)).
         [R26 SUPERSESSION note: the 15% surcharge cap now covers the STCG
         component too (FA2022 Sec 2(11) proviso) and marginal relief IS
         modeled — see test_r25_5a's in-place supersession and
         tests/test_round26_regressions.py.]
"""

import io
import itertools
import re
import tempfile
import tokenize
from pathlib import Path
from unittest import mock

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "web_dashboard" / "app.py"
DATA_LAYER = ROOT / "data_layer.py"
OPTIMIZER = ROOT / "optimizer.py"
UTILS = ROOT / "utils.py"
HEDGER = ROOT / "math_engine" / "options_hedger.py"
INDICATORS = ROOT / "math_engine" / "indicators.py"
TAX_ENGINE = ROOT / "math_engine" / "tax_loss_harvesting.py"
WFO = ROOT / "math_engine" / "oos_walkforward.py"
LEDGER = ROOT / "core" / "realized_gains_ledger.py"
DASHBOARD_JS = ROOT / "web_dashboard" / "dashboard.js"


def _code_only(path: Path) -> str:
    """Return the source of `path` with comments and docstrings removed.

    Pattern locks must run against executable code only — AUDIT-FIX comments
    and docstrings legitimately QUOTE the eliminated bug patterns, which
    would otherwise trip `not in` assertions.
    """
    import ast
    src = path.read_text(encoding="utf-8")
    tree = ast.parse(src)
    docstring_lines = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                docstring_lines.add(node.body[0].lineno)
    kept = []
    for tok in tokenize.generate_tokens(io.StringIO(src).readline):
        if tok.type == tokenize.COMMENT:
            continue
        if tok.type == tokenize.STRING and tok.start[0] in docstring_lines:
            continue
        kept.append(tok)
    return tokenize.untokenize(kept)


# ══════════════════════════════════════════════════════════════════════
# R25-1 — allocation-layer replay (QUBO-core + HRP) in the WFO re-selection
# ══════════════════════════════════════════════════════════════════════

def test_r25_1a_qubo_core_select_finds_energy_argmin():
    """Hand-check: _qubo_core_select returns a subset whose energy (the
    documented objective: alpha diagonal + vol penalty + correlation
    off-diagonal + cardinality, production coefficient formulas) is the
    argmin over ALL k-subsets, and never worse than the greedy seed."""
    from math_engine.oos_walkforward import _qubo_core_select

    cands = ["P.NS", "Q.NS", "R.NS"]
    alpha_z = {"P.NS": 1.4, "Q.NS": 1.3, "R.NS": 0.9}
    vol_z = {"P.NS": 2.0, "Q.NS": 0.0, "R.NS": -1.0}
    corr = pd.DataFrame(np.eye(3), index=cands, columns=cands)
    corr.loc["P.NS", "Q.NS"] = corr.loc["Q.NS", "P.NS"] = 1.0   # P&Q perfectly correlated
    corr.loc["P.NS", "R.NS"] = corr.loc["R.NS", "P.NS"] = 0.0
    corr.loc["Q.NS", "R.NS"] = corr.loc["R.NS", "Q.NS"] = 0.0

    ALPHA, VOLP, GC, GR, TH, n, k = 1.8, 0.35, 12.0, 12.0, 4.0, 3, 2

    def energy(sub):
        diag = {s: (-ALPHA * alpha_z[s] + VOLP * vol_z[s] + GC * (1 - 2 * k)) / n for s in sub}
        pair = 0.0
        for a, b in itertools.combinations(sub, 2):
            pair += (2 * GR + TH * (n / k) ** 0.5 * corr.loc[a, b]) / n
        return sum(diag.values()) + pair

    best = min(itertools.combinations(cands, k), key=energy)
    sel = _qubo_core_select(cands, alpha_z, vol_z, corr, k, None)
    assert sorted(sel) == sorted(best), (
        f"QUBO-core replay returned {sel}; energy argmin is {list(best)}"
    )
    # local search never worsens on the greedy (alpha-ranked) seed
    seed = ["P.NS", "Q.NS"]
    assert energy(sel) <= energy(seed) + 1e-12


def test_r25_1b_reselection_replays_allocation_layer():
    """The fold payload discloses the QUBO-core selection + production HRP
    weighting, carries the inverse-vol REFERENCE series (R24 semantics), and
    the aggregate reports the measured allocation-layer effect; turning the
    replay off restores the R24 top-K + inverse-vol behavior."""
    from math_engine.oos_walkforward import walk_forward_reselection_backtest

    n = 200
    dates = pd.bdate_range("2025-01-01", periods=n)
    cols = {}
    for i in range(12):
        cols[f"N{i:02d}.NS"] = 100.0 * np.exp(0.0012 * np.arange(n))
    close = pd.DataFrame(cols, index=dates)
    vol = pd.DataFrame(1e6, index=dates, columns=close.columns, dtype=float)

    res = walk_forward_reselection_backtest(
        close, vol, n_folds=2, score_lookback=63, k_stocks=3,
        mode="balanced", benchmark_returns=pd.Series(0.0, index=dates),
        replay_allocation=True,
    )
    assert len(res["folds"]) >= 1
    f0 = res["folds"][0]
    assert "QUBO-core" in f0["selection"]
    assert "hrp_weights" in f0["weighting"].lower()
    assert "reference_topk_basket" in f0 and f0["reference_topk_basket"]
    assert "reference_invvol_fold_return_pct" in f0
    assert res.get("allocation_layer_effect_pct") is not None
    assert res.get("reference_invvol_total_return_pct") is not None
    assert res.get("weighting_sources")
    assert "QUBO-CORE" in res["method_disclosure"]

    res_off = walk_forward_reselection_backtest(
        close, vol, n_folds=2, score_lookback=63, k_stocks=3,
        mode="balanced", benchmark_returns=pd.Series(0.0, index=dates),
        replay_allocation=False,
    )
    f0_off = res_off["folds"][0]
    assert "allocation replay off" in f0_off["selection"]
    assert "inverse-vol (R24 semantics)" == f0_off["weighting"]
    assert res_off["weighting"] == "inverse-vol (allocation replay disabled)"


def test_r25_1c_allocation_replay_wiring_patterns():
    """Pattern locks: the replay functions exist, the sweep passes the run's
    coefficients + pool/supersample configuration, and the verdict log
    reports the measured allocation-layer effect."""
    wfo_code = _code_only(WFO)
    assert "def _qubo_core_select(" in wfo_code
    assert "def _hrp_weights_replay(" in wfo_code
    assert "def _hrp_local_mirror(" in wfo_code
    assert "def _point_in_time_factors(" in wfo_code
    assert "top_n_pool: Optional[int] = None" in wfo_code
    assert "replay_allocation: bool = True" in wfo_code
    assert "allocation_layer_effect_pct" in wfo_code
    assert "pool_cut_applied" in wfo_code
    # the QUBO objective mirrors the production coefficient formulas
    assert "2.0 * gamma_risk + theta_scaled * cij" in wfo_code

    opt_code = _code_only(OPTIMIZER)
    assert "replay_allocation=True" in opt_code
    assert "allocation_cfg=working_cfg" in opt_code
    assert "top_n_pool=_wfr_pool" in opt_code
    assert 'working_cfg.get("WFO_POOL_FULL_UNIVERSE", False)' in opt_code
    assert "_download_ohlcv_bundle(" in opt_code
    assert "QUBO-core + HRP replay vs inverse-vol reference" in opt_code


# ══════════════════════════════════════════════════════════════════════
# R25-2 — multi-expiry GEX aggregation
# ══════════════════════════════════════════════════════════════════════

def test_r25_2a_multi_expiry_gex_math():
    """Two synthetic expiries: the aggregate net GEX is the exact sum of
    per-expiry BS gamma x (CallOI-PutOI) x lot x S^2 with each expiry's own
    T; per-expiry breakdown + share; degenerate-IV strikes contribute 0;
    the single-chain path (no multi list) keeps R24 semantics; the
    dealer-sign convention is disclosed in BOTH paths."""
    from math_engine.options_hedger import OptionsTailHedger, _bs_gamma

    h = OptionsTailHedger(nifty_price=20000.0)
    near = pd.DataFrame([{"strikePrice": 20000.0, "callOI": 1000, "putOI": 0,
                          "callIV": 15.0, "putIV": 15.0}])
    far = pd.DataFrame([{"strikePrice": 20000.0, "callOI": 1000, "putOI": 0,
                         "callIV": 15.0, "putIV": 15.0}])
    res = h.calculate_net_gamma_exposure(
        option_chain=near, iv=0.15, dte_days=7,
        multi_expiry_chains=[{"frame": near, "dte_days": 7, "label": "near", "iv": 0.15},
                             {"frame": far, "dte_days": 60, "label": "far", "iv": 0.15}],
    )
    g_near = _bs_gamma(20000.0, 20000.0, 0.065, 0.15, 7 / 252)
    g_far = _bs_gamma(20000.0, 20000.0, 0.065, 0.15, 60 / 252)
    expect = (g_near + g_far) * 1000 * 75 * 20000.0 ** 2
    assert res["net_gex_rupees"] == pytest.approx(expect, abs=1.0)
    assert res["expiries_aggregated"] == 2
    labels = {e["label"]: e for e in res["per_expiry_gex"]}
    assert labels["near"]["gex_inr"] == pytest.approx(g_near * 1000 * 75 * 20000.0 ** 2, abs=1.0)
    assert labels["far"]["dte_days"] == 60
    assert abs(sum(e["share_pct"] for e in res["per_expiry_gex"]) - 100.0) < 0.5
    assert "Dealer-sign PROXY" in res["dealer_sign_convention"]

    # degenerate IV in the far expiry: that expiry contributes 0 (disclosed)
    bad = pd.DataFrame([{"strikePrice": 20000.0, "callOI": 1000, "putOI": 0,
                         "callIV": 0.0, "putIV": 0.0}])
    res2 = h.calculate_net_gamma_exposure(
        option_chain=near, iv=0.15, dte_days=7,
        multi_expiry_chains=[{"frame": near, "dte_days": 7, "label": "near", "iv": 0.15},
                             {"frame": bad, "dte_days": 60, "label": "far", "iv": 0.0}],
    )
    assert res2["net_gex_rupees"] == pytest.approx(g_near * 1000 * 75 * 20000.0 ** 2, abs=1.0)
    assert res2["per_expiry_gex"][1]["degenerate_iv_strikes"] == 1

    # no multi list -> single-chain R24 semantics, hand-checked
    res3 = h.calculate_net_gamma_exposure(option_chain=near, iv=0.15, dte_days=7)
    assert res3["net_gex_rupees"] == pytest.approx(g_near * 1000 * 75 * 20000.0 ** 2, abs=1.0)
    assert res3["expiries_aggregated"] == 1
    assert "Dealer-sign PROXY" in res3["dealer_sign_convention"]


def test_r25_2b_multi_expiry_wiring_patterns():
    """Pattern locks: the hedger exposes the multi-expiry path, the fetcher
    echoes every live expiry date, and the sweep aggregates the nearest
    GEX_EXPIRY_DEPTH expiries with per-expiry labels."""
    hedger_code = _code_only(HEDGER)
    assert "def _calculate_net_gamma_exposure_multi(" in hedger_code
    assert "multi_expiry_chains: Optional[List[Dict[str, Any]]] = None" in hedger_code
    assert "per_expiry_gex" in hedger_code
    assert "DEALER_SIGN_CONVENTION" in hedger_code
    assert "dealer_sign_convention" in hedger_code
    assert "expiries_aggregated" in hedger_code

    dl_code = _code_only(DATA_LAYER)
    assert '"expiry_dates": list(expiries)' in dl_code

    opt_code = _code_only(OPTIMIZER)
    assert 'working_cfg.get("GEX_EXPIRY_DEPTH", 3)' in opt_code
    assert "_gex_multi_chains" in opt_code
    assert "multi_expiry_chains=_gex_multi_chains" in opt_code


# ══════════════════════════════════════════════════════════════════════
# R25-3 — characteristic factor-model beta priors
# ══════════════════════════════════════════════════════════════════════

def _beta_panel(n_days=300, n_stk=24, seed=7):
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range("2025-01-01", periods=n_days)
    bench = pd.Series(rng.normal(0.0005, 0.01, n_days), index=dates)
    close_d, vol_d = {}, {}
    for i in range(n_stk):
        b = 0.6 + 0.8 * (i / n_stk)
        r = b * bench.values + rng.normal(0, 0.008 + 0.004 * (i / n_stk), n_days)
        close_d[f"S{i:02d}.NS"] = 100.0 * np.cumprod(1.0 + r)
        vol_d[f"S{i:02d}.NS"] = np.full(n_days, 5e6 * (1 + i))
    return (pd.DataFrame(close_d, index=dates),
            pd.DataFrame(vol_d, index=dates),
            bench)


def test_r25_3a_factor_beta_prior_recovers_characteristic_function():
    """A cross-section whose true beta is a smooth function of the
    characteristics: the LOO priors track it (median error small), the
    model discloses n/r2, a too-small cross-section returns EMPTY priors
    with a reason, and priors respect the band."""
    from math_engine.indicators import factor_model_beta_prior

    close, volume, bench = _beta_panel()
    rets = close.pct_change().dropna()
    out = factor_model_beta_prior(rets, close=close, volume=volume,
                                  benchmark_returns=bench, beta_window=126)
    assert out["model"]["available"] is True
    priors = out["priors"]
    assert len(priors) >= 20
    # true beta in this panel: 0.6 + 0.8 * i / 24 (n_stk = 24)
    errs = [abs(priors[f"S{i:02d}.NS"] - (0.6 + 0.8 * i / 24))
            for i in range(24) if f"S{i:02d}.NS" in priors]
    assert float(np.median(errs)) < 0.25, (
        f"LOO priors do not track the characteristic-implied betas (median err {np.median(errs):.3f})"
    )
    assert out["model"]["r2"] > 0.3
    assert out["model"]["n_stocks"] >= 20

    # too small -> empty + honest reason (never fabricated priors)
    out2 = factor_model_beta_prior(rets.iloc[:, :4], close=close.iloc[:, :4],
                                   volume=volume.iloc[:, :4], benchmark_returns=bench)
    assert out2["priors"] == {}
    assert "too small" in out2["model"]["reason"]

    # band clipping is honored
    out3 = factor_model_beta_prior(rets, close=close, volume=volume,
                                   benchmark_returns=bench, prior_band=(0.55, 0.56))
    assert all(0.55 <= v <= 0.56 for v in out3["priors"].values())


def test_r25_3b_signal_frame_factor_prior_wiring():
    """compute_signal_frame: beta_prior / beta_prior_source columns exist,
    the characteristic model supplies per-row priors by default, the
    licensed BETA_FACTOR_FEED overrides per-stock, and disabling the factor
    prior falls back to the flat disclosed prior."""
    import utils

    close, volume, bench = _beta_panel(n_days=400, n_stk=14)
    data = {"Close": close, "Volume": volume}
    rets = close.pct_change()

    frame = utils.compute_signal_frame(
        data, rets, bench, cfg={"USE_LIQUIDITY_AWARE_BETA": True})
    for col in ("beta_raw", "beta_shrink_weight", "beta_prior", "beta_prior_source"):
        assert col in frame.columns, f"signal frame lost the {col} disclosure column"
    assert frame["beta_prior_source"].str.contains("characteristic factor model").any()
    # priors are stock-specific (not a single constant)
    assert frame["beta_prior"].nunique() > 1

    # licensed feed override
    live_tk = frame.index[0]
    frame2 = utils.compute_signal_frame(
        data, rets, bench,
        cfg={"USE_LIQUIDITY_AWARE_BETA": True,
             "BETA_FACTOR_FEED": {live_tk: 1.75}})
    assert frame2.loc[live_tk, "beta_prior"] == pytest.approx(1.75)
    assert "licensed factor feed" in frame2.loc[live_tk, "beta_prior_source"]

    # factor prior disabled -> flat prior disclosed (R24 semantics)
    frame3 = utils.compute_signal_frame(
        data, rets, bench,
        cfg={"USE_LIQUIDITY_AWARE_BETA": True,
             "USE_FACTOR_MODEL_BETA_PRIOR": False})
    assert frame3["beta_prior"].eq(1.0).all()
    assert "flat market prior" in frame3["beta_prior_source"].iloc[0]

    # pattern locks on the wiring + hedger disclosure
    utils_code = _code_only(UTILS)
    assert "BETA_FACTOR_FEED" in utils_code
    assert "USE_FACTOR_MODEL_BETA_PRIOR" in utils_code
    assert "factor_model_beta_prior(" in utils_code
    assert '"beta_prior_source": _beta_prior_src_row' in utils_code
    hedger_code = _code_only(HEDGER)
    assert "CHARACTERISTIC factor-model beta" in hedger_code
    ind_code = _code_only(INDICATORS)
    assert "def factor_model_beta_prior(" in ind_code
    assert "leave-one-out" in INDICATORS.read_text(encoding="utf-8")


# ══════════════════════════════════════════════════════════════════════
# R25-4 — three-layer equity marks (NSE -> Yahoo .NS -> BSE .BO)
# ══════════════════════════════════════════════════════════════════════

def test_r25_4a_marks_three_layer_order_fallback_cache():
    """With the direct NSE leg blocked: Yahoo .NS serves NSE-listed names
    and the BSE leg is NEVER called; when .NS also fails the .BO leg serves
    the mark; a second call within the TTL is served from cache (no probe)."""
    import data_layer as dl

    calls = []
    _orig = (dl.fetch_nse_equity_last_prices,
             dl._nse_yahoo_last_price,
             dl._bse_last_price_yfinance)

    def _reset(clear_cache=True):
        calls.clear()
        if clear_cache:
            dl._YF_NS_QUOTE_CACHE.clear()
            dl._BSE_QUOTE_CACHE.clear()
        dl.fetch_nse_equity_last_prices = lambda symbols, log_cb=None, max_symbols=40: {}

    try:
        # .NS succeeds -> .BO never probed
        _reset()
        dl._nse_yahoo_last_price = lambda sym, log_cb=None: (123.45, "NSE via Yahoo (.NS)")
        dl._bse_last_price_yfinance = lambda sym, log_cb=None: (
            calls.append(("BO", sym)) or (99.0, "BSE (.BO) via yfinance"))
        out = dl.fetch_equity_last_prices_multi_source(["RELIANCE.NS", "TCS.NS"])
        assert calls == [], "BSE leg probed even though Yahoo .NS served the names"
        assert all(v["source"] == "NSE via Yahoo (.NS)" for v in out.values())
        assert out["RELIANCE.NS"]["price"] == pytest.approx(123.45)

        # cached second call -> no probe at all
        probes = []
        dl._nse_yahoo_last_price = lambda sym, log_cb=None: (
            probes.append(sym) or (123.45, "NSE via Yahoo (.NS)"))
        out2 = dl.fetch_equity_last_prices_multi_source(["RELIANCE.NS"])
        assert probes == [] and out2["RELIANCE.NS"]["source"] == "NSE via Yahoo (.NS)"

        # .NS fails -> .BO serves
        _reset()
        dl._nse_yahoo_last_price = lambda sym, log_cb=None: (None, "no NSE price")
        dl._bse_last_price_yfinance = lambda sym, log_cb=None: (
            calls.append(("BO", sym)) or (99.0, "BSE (.BO) via yfinance"))
        out3 = dl.fetch_equity_last_prices_multi_source(["XYZ.NS"])
        assert calls == [("BO", "XYZ")]
        assert out3["XYZ.NS"]["source"] == "BSE (.BO) via yfinance"

        # both Yahoo legs fail -> symbol omitted (never fabricated)
        _reset()
        dl._nse_yahoo_last_price = lambda sym, log_cb=None: (None, "no NSE price")
        dl._bse_last_price_yfinance = lambda sym, log_cb=None: (None, "no BSE price")
        out4 = dl.fetch_equity_last_prices_multi_source(["NOPE.NS"])
        assert "NOPE.NS" not in out4
    finally:
        # restore the real functions for other tests in this session
        (dl.fetch_nse_equity_last_prices,
         dl._nse_yahoo_last_price,
         dl._bse_last_price_yfinance) = _orig


def test_r25_4b_marks_wiring_patterns():
    """Pattern locks: the middle layer + its cache exist in data_layer, and
    the endpoint's refresh note counts all three layers."""
    dl_code = _code_only(DATA_LAYER)
    assert "def _nse_yahoo_last_price(" in dl_code
    assert "def _yf_ticker_last_price(" in dl_code
    assert "_YF_NS_QUOTE_CACHE" in dl_code
    assert "_YF_NS_QUOTE_CACHE_TTL = 300.0" in dl_code

    app_code = _code_only(APP)
    assert "NSE via Yahoo (.NS)" in app_code
    assert "via Yahoo NSE (.NS) fallback" in app_code


# ══════════════════════════════════════════════════════════════════════
# R25-5 — tax completeness (surcharge/cess, regimes, grandfathering,
#         trade-date convention)
# ══════════════════════════════════════════════════════════════════════

def test_r25_5a_surcharge_and_cess_math():
    """Hand-checked statutory math:
    * STCG 100k, total income Rs 6Cr: 20% tax = 20,000; surcharge capped at
      15% = 3,000; cess 4% x 23,000 = 920; total 23,920.
      SUPERSEDED (Round 26 — R26-1): the original R25 lock asserted "Sec
      111A has no cap" and took the 37% slab surcharge on STCG (28,496).
      The Finance Act 2022 Sec 2(11) proviso caps the surcharge on Sec
      111A/112/112A tax at 15% (verified against incometaxindia.gov.in and
      public effective-rate tables: max effective STCG 23.92% =
      20% x 1.15 x 1.04). Numbers updated in-place; the R26 locks
      (including the STCG marginal-relief cases) live in
      tests/test_round26_regressions.py.
    * LTCG 225k (taxable 100k after the 1.25L exemption), income 6Cr: the
      LTCG surcharge is CAPPED at 15% (Finance Act 2022) even in the 37%
      slab: 12,500 + 1,875 + 575 = 14,950.
    * Below the 50L bracket: surcharge 0 but 4% cess ALWAYS applies:
      STCG 100k -> 20,800.
    * Default include_surcharge_cess=False keeps the R24 flat-rate view.
    """
    from math_engine.tax_loss_harvesting import TaxLossHarvestingOptimizer as T

    r = T.compute_tax_position(
        pd.DataFrame(), {},
        realized_gains={"STCG": 100000.0, "LTCG": 0.0, "unpriced_events": 0},
        include_surcharge_cess=True, total_taxable_income_inr=60_000_000.0,
    )
    assert r["tax_without_harvest_inr"] == pytest.approx(23920.0)
    assert r["without_harvest"]["surcharge_rate"] == pytest.approx(0.37)
    assert r["without_harvest"]["surcharge_inr"] == pytest.approx(3000.0)
    assert r["without_harvest"]["cess_inr"] == pytest.approx(920.0)
    # R26-1: the STCG component is now capped alongside the LTCG component
    assert r["without_harvest"]["surcharge_rate_stcg_capped"] == pytest.approx(0.15)
    # R26-2: mixed-income basis (caller total income exceeds the gains
    # base) -> conservative relief; the crossed 5Cr bracket's excess income
    # (Rs 1Cr) dwarfs the surcharge, so relief is 0 here.
    assert r["without_harvest"]["marginal_relief_inr"] == pytest.approx(0.0)
    assert "approximate-conservative" in r["without_harvest"]["marginal_relief_basis"]

    r2 = T.compute_tax_position(
        pd.DataFrame(), {},
        realized_gains={"STCG": 0.0, "LTCG": 225000.0, "unpriced_events": 0},
        include_surcharge_cess=True, total_taxable_income_inr=60_000_000.0,
    )
    assert r2["tax_without_harvest_inr"] == pytest.approx(14950.0)
    assert r2["without_harvest"]["surcharge_rate_ltcg_capped"] == pytest.approx(0.15)

    r3 = T.compute_tax_position(
        pd.DataFrame(), {},
        realized_gains={"STCG": 100000.0, "LTCG": 0.0, "unpriced_events": 0},
        include_surcharge_cess=True,
    )
    assert r3["tax_without_harvest_inr"] == pytest.approx(20800.0)
    assert "gains-only proxy" in r3["without_harvest"]["surcharge_income_basis"]

    # default off -> flat-rate R24 contract even with income supplied
    r4 = T.compute_tax_position(
        pd.DataFrame(), {},
        realized_gains={"STCG": 100000.0, "LTCG": 0.0, "unpriced_events": 0},
        total_taxable_income_inr=60_000_000.0,
    )
    assert r4["tax_without_harvest_inr"] == pytest.approx(20000.0)
    assert r4["include_surcharge_cess"] is False
    assert "EXCLUDED" in r4["surcharge_cess_note"]

    # constants: the surcharge slabs + cap + cess rate are locked
    assert T.CESS_RATE == 0.04
    assert T.LTCG_SURCHARGE_CAP == 0.15
    assert (50_000_000.0, 0.37) in T.SURCHARGE_SLABS


def test_r25_5b_rate_regime_split_math():
    """Per-tranche Jul-2024 regimes: pre-cutover LTCG 300k + post-cutover
    300k -> (300k-1L)x10% + (300k-1.25L)x12.5% = 20,000 + 21,875 = 41,875;
    an all-pre tranche uses the old 10%/Rs1L regime; no split supplied ->
    all gains at the post-cutover rates (R24 semantics)."""
    from math_engine.tax_loss_harvesting import TaxLossHarvestingOptimizer as T

    r = T.compute_tax_position(
        pd.DataFrame(), {},
        realized_gains={"STCG": 0.0, "LTCG": 600000.0, "unpriced_events": 0,
                        "regime_split": {"LTCG": {"pre_cutoff": 300000.0,
                                                  "post_cutoff": 300000.0}}},
    )
    assert r["tax_without_harvest_inr"] == pytest.approx(41875.0)
    assert r["rate_regimes"]["cutoff_date"] == "2024-07-23"
    assert r["rate_regimes"]["pre_cutoff"]["ltcg_rate"] == 0.10
    assert r["rate_regimes"]["pre_cutoff"]["ltcg_exemption_inr"] == 100000.0

    r2 = T.compute_tax_position(
        pd.DataFrame(), {},
        realized_gains={"STCG": 0.0, "LTCG": 300000.0, "unpriced_events": 0,
                        "regime_split": {"LTCG": {"pre_cutoff": 300000.0,
                                                  "post_cutoff": 0.0}}},
    )
    assert r2["tax_without_harvest_inr"] == pytest.approx(20000.0)  # (300k-1L) x 10%

    # no split -> post-cutover rates on everything (R24 semantics preserved)
    r3 = T.compute_tax_position(
        pd.DataFrame(), {},
        realized_gains={"STCG": 0.0, "LTCG": 300000.0, "unpriced_events": 0},
    )
    assert r3["tax_without_harvest_inr"] == pytest.approx(21875.0)  # (300k-1.25L) x 12.5%


def test_r25_5c_ledger_grandfathering_and_trade_date():
    """Sec 112A(2) deemed cost = max(actual, min(FMV-31Jan2018, sale)):
    1,000 sh bought 2017 @100, sold 150; FMV 130 -> gain (150-130)x1000
    = 20,000 (adjustment -30,000); no FMV feed -> unadjusted + disclosed.
    AY bucketing on TRADE dates (a 2025-03-31 close belongs to AY 2025-26);
    364-day holding is STCG; new events carry shares + date_basis."""
    from core.realized_gains_ledger import (
        RealizedGainsLedger, TAX_REGIME_CUTOFF_DATE, GRANDFATHERING_ACQ_CUTOFF_DATE,
    )

    led = RealizedGainsLedger(storage_path=Path(tempfile.mkdtemp()) / "rg.json")
    led.record_realized_close({
        "id": "G1", "ticker": "OLD.NS", "entry_date": "2017-06-01",
        "exit_date": "2026-03-01", "entry_price": 100.0, "exit_price": 150.0,
        "shares": 1000,
    })
    led.record_realized_close({
        "id": "G2", "ticker": "EDGE.NS", "entry_date": "2025-03-01",
        "exit_date": "2025-03-31", "entry_price": 100.0, "exit_price": 110.0,
        "shares": 100,
    })
    led.record_realized_close({
        "id": "G3", "ticker": "D364.NS", "entry_date": "2025-01-01",
        "exit_date": "2025-12-31", "entry_price": 100.0, "exit_price": 105.0,
        "shares": 10,
    })

    n = led.net_gains_by_category("AY 2026-27")
    assert n["LTCG"] == 50000.0                      # raw, no feed
    assert n["grandfathering"]["applied_events"] == 0
    assert "NOT APPLIED" in n["grandfathering"]["basis"]
    assert n["holding_period_basis"].startswith("trade-date")
    assert n["regime_split"]["LTCG"]["post_cutoff"] == 50000.0
    assert n["regime_split"]["cutoff_date"] == TAX_REGIME_CUTOFF_DATE

    n2 = led.net_gains_by_category("AY 2026-27", fmv_31jan2018={"OLD.NS": 130.0})
    assert n2["LTCG"] == 20000.0                     # deemed cost 130
    assert n2["grandfathering"]["applied_events"] == 1
    assert n2["grandfathering"]["adjustment_inr"] == -30000.0

    entries = {e["journal_trade_id"]: e for e in led.entries()}
    assert entries["G1"]["shares"] == 1000
    assert entries["G1"]["date_basis"] == "trade-date"
    # FY-boundary: 2025-03-31 close (T+1 settles in April) -> AY 2025-26
    assert entries["G2"]["assessment_year"] == "AY 2025-26"
    # 364 days -> STCG (trade-date diff)
    assert entries["G3"]["tax_category"] == "STCG"
    # regime constants exposed
    assert GRANDFATHERING_ACQ_CUTOFF_DATE == "2018-02-01"


def test_r25_5d_endpoint_tax_wiring_patterns():
    """Pattern locks: the endpoint enables the statutory layers by default
    (TAX_INCLUDE_SURCHARGE_CESS), accepts total_taxable_income, feeds
    TAX_FMV_31JAN2018 into the ledger query, and publishes the surcharge/
    regime/grandfathering disclosures; the dashboard renders them; the
    build marker is at R25."""
    app_code = _code_only(APP)
    m = re.search(r"def _handle_tax_optimizer\(.*?(?=\n    def )", app_code, re.S)
    assert m, "tax optimizer handler not found"
    body = m.group(0)
    assert "include_surcharge_cess=_include_sc" in body
    assert "total_taxable_income_inr=_tti" in body
    assert 'params.get("total_taxable_income"' in body
    assert 'TAX_INCLUDE_SURCHARGE_CESS' in body
    assert "TAX_FMV_31JAN2018" in body
    assert "fmv_31jan2018=_fmv_feed" in body
    assert '"surcharge_cess_note"' in body
    assert '"rate_regimes"' in body
    assert '"grandfathering"' in body
    assert '"tax_before_surcharge_inr"' in body

    # engine: the locked R24 constants still exist verbatim + new constants
    tax_code = _code_only(TAX_ENGINE)
    assert "LTCG_EXEMPTION_INR: float = 125_000.0" in tax_code
    assert "CARRY_FORWARD_YEARS: int = 8" in tax_code
    assert "SURCHARGE_SLABS" in tax_code
    assert "LTCG_SURCHARGE_CAP" in tax_code
    assert "CESS_RATE" in tax_code
    assert "STCG_RATE_PRE_CUTOFF" in tax_code
    assert "LTCG_EXEMPTION_PRE_CUTOFF_INR" in tax_code

    # ledger: the R25-5 constants + shares persistence
    ledger_code = _code_only(LEDGER)
    assert "TAX_REGIME_CUTOFF_DATE" in ledger_code
    assert "GRANDFATHERING_ACQ_CUTOFF_DATE" in ledger_code
    assert "fmv_31jan2018: Optional[Dict[str, float]] = None" in ledger_code

    # dashboard renders the statutory layers
    js_src = DASHBOARD_JS.read_text(encoding="utf-8")
    assert "surcharge_inr" in js_src
    assert "grandfathering" in js_src
    assert "holding_period_basis" in js_src

    # build marker advanced to Round 25 (and still satisfies the R21 lineage)
    app_src = APP.read_text(encoding="utf-8")
    bm = re.search(r'APP_BUILD_ID\s*=\s*"([^"]+)"', app_src)
    assert bm, "APP_BUILD_ID definition not found in app.py"
    build_id = bm.group(1)
    assert re.search(r"QA-R(19|20)", build_id)
    assert "R21" in build_id and "R25" in build_id
    assert "SOVEREIGN-TIER-OMEGA" in build_id
