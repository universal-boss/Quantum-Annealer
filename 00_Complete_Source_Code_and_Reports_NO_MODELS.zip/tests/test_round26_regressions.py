"""Round 26 regression locks — statutory tax corrections + A–D anti-revert pins.

R26-1: STCG (Sec 111A) surcharge is now capped at 15%. The Finance Act 2022
       Sec 2(11) proviso caps the surcharge on tax on income under Sec
       111A, 112 AND 112A — the R25 code capped only the LTCG component and
       its lock asserted "Sec 111A has no cap" (verified wrong against
       incometaxindia.gov.in and public effective-rate tables: maximum
       effective STCG 23.92% = 20% x 1.15 x 1.04). The superseded R25 lock
       numbers were updated in-place in tests/test_round25_regressions.py
       (the R23->R24->R25 supersession precedent, documented in-test).
R26-2: marginal relief is modeled (the R25 §4 residual "marginal relief not
       modeled"): exact on the gains-only income basis; conservative
       (surcharge limited to the excess income over the crossed bracket) and
       disclosed when the caller's total income exceeds the gains base,
       because the non-CG tax is not modeled by this engine.
R26-3: A–D anti-revert pins — the round-25 conversational revert checklist
       (BS strike gamma; journal mark age from the EXCHANGE stamp; tax
       set-off / 8y carry / Rs1.25L exemption; method_disclosure re-selection
       depth + beta prior fallback) is locked as executable CI checks, so
       "check whether earlier fixes were reverted" becomes pytest -k r26_3
       instead of a manual audit.
"""

import io
import json
import re
import tempfile
import time
from pathlib import Path
from unittest import mock

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "web_dashboard" / "app.py"
UTILS = ROOT / "utils.py"
INDICATORS = ROOT / "math_engine" / "indicators.py"
HEDGER = ROOT / "math_engine" / "options_hedger.py"
TAX_ENGINE = ROOT / "math_engine" / "tax_loss_harvesting.py"
WFO = ROOT / "math_engine" / "oos_walkforward.py"
DASHBOARD_JS = ROOT / "web_dashboard" / "dashboard.js"


def _code_only(path: Path) -> str:
    """Source of `path` with comments and docstrings removed (the R22+ pattern
    lock convention: AUDIT-FIX comments legitimately QUOTE eliminated bug
    patterns, which would otherwise trip `not in` assertions)."""
    import ast
    import tokenize
    src = path.read_text(encoding="utf-8")
    tree = ast.parse(src)
    docstring_lines = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                docstring_lines.add(node.body[0].lineno)
    kept = []
    for tok in tokenize.generate_tokens(io.StringIO(src).readline):
        if tok.type == tokenize.COMMENT:
            continue
        if tok.type == tokenize.STRING and tok.start[0] in docstring_lines:
            continue
        kept.append(tok)
    return tokenize.untokenize(kept)


# ══════════════════════════════════════════════════════════════════════
# R26-1 — STCG (Sec 111A) surcharge capped at 15% (FA2022 Sec 2(11))
# ══════════════════════════════════════════════════════════════════════

def test_r26_1a_stcg_surcharge_capped_statutory():
    """Hand-checked statutory math (the R26-1 core lock):
    STCG 100k, total income Rs 6Cr -> 20% tax = 20,000; surcharge CAPPED at
    15% (FA2022 Sec 2(11) proviso covers Sec 111A/112/112A) = 3,000; cess
    4% x 23,000 = 920; total 23,920 = the statutory maximum effective STCG
    rate 23.92%. The pre-fix code took the UNCAPPED 37% slab (28,496) —
    wrong by Rs 4,576 per Rs 1L of STCG in the top bracket."""
    from math_engine.tax_loss_harvesting import TaxLossHarvestingOptimizer as T

    r = T.compute_tax_position(
        pd.DataFrame(), {},
        realized_gains={"STCG": 100000.0, "LTCG": 0.0, "unpriced_events": 0},
        include_surcharge_cess=True, total_taxable_income_inr=60_000_000.0,
    )
    w = r["without_harvest"]
    assert r["tax_without_harvest_inr"] == pytest.approx(23920.0)
    assert w["tax_before_surcharge_inr"] == pytest.approx(20000.0)
    assert w["surcharge_inr"] == pytest.approx(3000.0)
    assert w["cess_inr"] == pytest.approx(920.0)
    # the slab ECHO still reports the selected bracket (37%); the COMPONENT
    # rate is the capped one — both disclosed
    assert w["surcharge_rate"] == pytest.approx(0.37)
    assert w["surcharge_rate_stcg_capped"] == pytest.approx(0.15)
    assert w["surcharge_rate_ltcg_capped"] == pytest.approx(0.15)
    # effective-rate identity: 20% x 1.15 x 1.04 = 23.92%
    assert r["tax_without_harvest_inr"] == pytest.approx(100000.0 * 0.2392)
    # mixed-income marginal relief basis (caller TTI exceeds the gains
    # base): the conservative shortcut — the 5Cr bracket's excess income
    # (Rs 1Cr) dwarfs the surcharge, so relief is 0 here.
    assert w["marginal_relief_inr"] == pytest.approx(0.0)
    assert "approximate-conservative" in w["marginal_relief_basis"]
    # payload + note disclosure carry the statutory cap language
    assert "23.92" in r["surcharge_cess_note"]
    assert "111A" in r["surcharge_cess_note"]


def test_r26_1b_ltcg_path_unchanged():
    """The fix must not drift the LTCG path: LTCG 225k (taxable 100k after
    the 1.25L exemption) at Rs 6Cr income -> 12,500 + 1,875 + 575 = 14,950
    (the R25 number, already correctly capped)."""
    from math_engine.tax_loss_harvesting import TaxLossHarvestingOptimizer as T

    r = T.compute_tax_position(
        pd.DataFrame(), {},
        realized_gains={"STCG": 0.0, "LTCG": 225000.0, "unpriced_events": 0},
        include_surcharge_cess=True, total_taxable_income_inr=60_000_000.0,
    )
    assert r["tax_without_harvest_inr"] == pytest.approx(14950.0)
    assert r["without_harvest"]["surcharge_rate_ltcg_capped"] == pytest.approx(0.15)


def test_r26_1c_below_bracket_and_flat_contract_unchanged():
    """Below the 50L bracket: surcharge 0 but 4% cess ALWAYS applies
    (STCG 100k -> 20,800, gains-only basis). Default
    include_surcharge_cess=False keeps the R24 flat-rate contract (20,000)
    even with total income supplied."""
    from math_engine.tax_loss_harvesting import TaxLossHarvestingOptimizer as T

    r3 = T.compute_tax_position(
        pd.DataFrame(), {},
        realized_gains={"STCG": 100000.0, "LTCG": 0.0, "unpriced_events": 0},
        include_surcharge_cess=True,
    )
    assert r3["tax_without_harvest_inr"] == pytest.approx(20800.0)
    assert "gains-only proxy" in r3["without_harvest"]["surcharge_income_basis"]
    assert r3["without_harvest"]["marginal_relief_inr"] == pytest.approx(0.0)

    r4 = T.compute_tax_position(
        pd.DataFrame(), {},
        realized_gains={"STCG": 100000.0, "LTCG": 0.0, "unpriced_events": 0},
        total_taxable_income_inr=60_000_000.0,
    )
    assert r4["tax_without_harvest_inr"] == pytest.approx(20000.0)
    assert "EXCLUDED" in r4["surcharge_cess_note"]


def test_r26_1d_bracket_progression_direction():
    """Sanity: the 10% bracket (income Rs 60L) -> 20,000 + 2,000 + 880 =
    22,880; the top bracket with the cap -> 23,920. The capped top-bracket
    rate stays ABOVE the 10% bracket (progression direction) while sitting
    BELOW the pre-fix uncapped 37% (28,496) — the cap binds exactly between
    the two."""
    from math_engine.tax_loss_harvesting import TaxLossHarvestingOptimizer as T

    r_low = T.compute_tax_position(
        pd.DataFrame(), {},
        realized_gains={"STCG": 100000.0, "LTCG": 0.0, "unpriced_events": 0},
        include_surcharge_cess=True, total_taxable_income_inr=6_000_000.0,
    )
    assert r_low["tax_without_harvest_inr"] == pytest.approx(22880.0)
    assert r_low["without_harvest"]["surcharge_rate"] == pytest.approx(0.10)

    r_top = T.compute_tax_position(
        pd.DataFrame(), {},
        realized_gains={"STCG": 100000.0, "LTCG": 0.0, "unpriced_events": 0},
        include_surcharge_cess=True, total_taxable_income_inr=60_000_000.0,
    )
    assert 22880.0 < r_top["tax_without_harvest_inr"] < 28496.0


# ══════════════════════════════════════════════════════════════════════
# R26-2 — marginal relief (modeled; exact on the gains-only basis)
# ══════════════════════════════════════════════════════════════════════

def test_r26_2a_marginal_relief_exact_gains_only_ltcg():
    """LTCG 5,135,000 -> taxable 5,010,000 after the 1.25L exemption;
    gains-only income basis crosses the 50L surcharge bracket.
    tax 626,250; gross surcharge 10% = 62,625; marginal relief =
    (626,250 + 62,625) - (625,000 + 10,000) = 53,875; net surcharge 8,750;
    cess 4% x 635,000 = 25,400; total 660,400. All hand-computed."""
    from math_engine.tax_loss_harvesting import TaxLossHarvestingOptimizer as T

    r = T.compute_tax_position(
        pd.DataFrame(), {},
        realized_gains={"STCG": 0.0, "LTCG": 5135000.0, "unpriced_events": 0},
        include_surcharge_cess=True,
    )
    w = r["without_harvest"]
    assert w["surcharge_gross_inr"] == pytest.approx(62625.0)
    assert w["marginal_relief_inr"] == pytest.approx(53875.0)
    assert w["surcharge_inr"] == pytest.approx(8750.0)
    assert w["cess_inr"] == pytest.approx(25400.0)
    assert r["tax_without_harvest_inr"] == pytest.approx(660400.0)
    assert "exact" in w["marginal_relief_basis"]
    # headline payload mirrors the scenario-A breakdown
    assert r["marginal_relief_without_harvest_inr"] == pytest.approx(53875.0)


def test_r26_2b_marginal_relief_zero_far_above_threshold():
    """LTCG 5,235,000 (taxable 5,110,000): relief = (638,750 + 63,875) -
    (625,000 + 110,000) < 0 -> no relief; total 730,730. The relief must
    never go negative and never exceed the surcharge."""
    from math_engine.tax_loss_harvesting import TaxLossHarvestingOptimizer as T

    r = T.compute_tax_position(
        pd.DataFrame(), {},
        realized_gains={"STCG": 0.0, "LTCG": 5235000.0, "unpriced_events": 0},
        include_surcharge_cess=True,
    )
    w = r["without_harvest"]
    assert w["marginal_relief_inr"] == pytest.approx(0.0)
    assert w["surcharge_inr"] == pytest.approx(63875.0)
    assert w["cess_inr"] == pytest.approx(28105.0)
    assert r["tax_without_harvest_inr"] == pytest.approx(730730.0)
    # relief bounded: 0 <= relief <= gross surcharge (structural property)
    for _w in (r["without_harvest"], r["with_harvest"]):
        assert 0.0 <= _w["marginal_relief_inr"] <= _w["surcharge_gross_inr"] + 1e-9


def test_r26_2c_marginal_relief_stcg_case():
    """STCG 5,010,000 (gains-only, 20% post-cutoff rate): tax 1,002,000;
    gross surcharge 10% = 100,200; relief = (1,002,000 + 100,200) -
    (1,000,000 + 10,000) = 92,200; net surcharge 8,000; cess 40,400;
    total 1,050,400."""
    from math_engine.tax_loss_harvesting import TaxLossHarvestingOptimizer as T

    r = T.compute_tax_position(
        pd.DataFrame(), {},
        realized_gains={"STCG": 5010000.0, "LTCG": 0.0, "unpriced_events": 0},
        include_surcharge_cess=True,
    )
    w = r["without_harvest"]
    assert w["surcharge_gross_inr"] == pytest.approx(100200.0)
    assert w["marginal_relief_inr"] == pytest.approx(92200.0)
    assert w["surcharge_inr"] == pytest.approx(8000.0)
    assert w["cess_inr"] == pytest.approx(40400.0)
    assert r["tax_without_harvest_inr"] == pytest.approx(1050400.0)
    assert "exact" in w["marginal_relief_basis"]


# ══════════════════════════════════════════════════════════════════════
# R26-3 — A–D anti-revert pins (the round-25 conversational checklist,
#         now executable CI checks)
# ══════════════════════════════════════════════════════════════════════

def test_r26_3a_pin_bs_gamma_is_real_black_scholes():
    """Checklist A: BS strike gamma must be real Black-Scholes.
    Closed form: S=K=100, r=0, sigma=0.2, T=0.25 -> d1 = 0.05,
    phi(0.05) = 0.3984447, gamma = phi/(S sigma sqrt(T)) = 0.0398445.
    ATM peak, strike differentiation, wing decay, and degenerate inputs
    contribute 0.0 (never a fabricated constant, never NaN)."""
    from math_engine.options_hedger import _bs_gamma

    # closed-form value (independently hand-computed)
    assert _bs_gamma(100.0, 100.0, 0.0, 0.2, 0.25) == pytest.approx(0.0398445, abs=1e-6)
    # ATM peak (defaults r=0.065, sigma=0.18, T=30/252)
    g_atm = _bs_gamma(100.0, 100.0)
    assert g_atm > _bs_gamma(100.0, 90.0) and g_atm > _bs_gamma(100.0, 110.0)
    # strike differentiation — not a flat proxy applied uniformly
    assert abs(_bs_gamma(100.0, 90.0) - _bs_gamma(100.0, 110.0)) > 1e-9
    # wing gamma decays by ~2 orders of magnitude (the R24-2 rationale)
    assert _bs_gamma(100.0, 80.0) < 0.1 * g_atm
    # degenerate inputs contribute zero, never a placeholder/NaN
    assert _bs_gamma(100.0, 100.0, 0.065, 0.0, 0.1) == 0.0
    assert _bs_gamma(100.0, 100.0, 0.065, 0.2, 0.0) == 0.0
    # source: the BS formula is present verbatim (pattern lock on code only)
    hedger_code = _code_only(HEDGER)
    assert "norm.pdf(d1) / (spot * sigma * np.sqrt(T))" in hedger_code


def test_r26_3b_pin_mark_age_uses_exchange_stamp():
    """Checklist B: journal mark age must come from the EXCHANGE mark
    timestamp (last_mark_ts), never the fetch wall-clock; missing stamps
    disclose 'unmeasured' instead of implying freshness."""
    from core.trade_journal import TradeJournalManager

    tmp = Path(tempfile.mkdtemp())
    jm = TradeJournalManager(storage_path=tmp / "j.json")
    jm.trades = [{
        "id": "TX1", "basket_name": "b", "ticker": "Z.NS",
        "entry_date": "2026-06-01", "entry_price": 100.0,
        "current_price": 100.0, "stop_loss_price": 50.0,
        "snell_target_price": 500.0, "weight_pct": 5.0,
        "profile_source": "t", "status": "ACTIVE", "unlevelled": False,
        "unrealized_pnl_%": 0.0, "realized_pnl_%": 0.0,
        "exit_date": None, "exit_price": None, "notes": "",
    }]
    t_before = time.time()
    stats = jm.update_live_prices({"Z.NS": 99.0},
                                  price_sources={"Z.NS": "NSE via Yahoo (.NS)"})
    assert stats["stops_triggered"] == 0
    trade = jm.trades[0]
    # the stamp is round(ts, 3) — compare with a rounding tolerance
    assert isinstance(trade.get("last_mark_ts"), float) and trade["last_mark_ts"] >= t_before - 0.01
    assert "NSE via Yahoo (.NS)" in str(trade.get("price_mark_source", ""))
    # the measured age is (now - exchange mark ts)/3600, small and positive
    age_h = (time.time() - trade["last_mark_ts"]) / 3600.0
    assert 0.0 <= age_h < 0.01
    # app-level pattern lock: age is computed from last_mark_ts, the honest
    # 'unmeasured' state exists, and the endpoint echoes age_hours
    app_code = _code_only(APP)
    assert "last_mark_ts" in app_code
    assert "age_hours" in app_code
    assert "/ 3600.0" in app_code
    assert "unmeasured (no mark timestamp recorded)" in app_code


def test_r26_3c_pin_tax_setoff_carry_exemption():
    """Checklist C: Sec 70/74 set-off order (STCL -> STCG then LTCG; LTCL
    -> LTCG only), the Rs1.25L LTCG exemption after set-off, and the 8-year
    carry-forward vintage expiry at the endpoint."""
    from math_engine.tax_loss_harvesting import TaxLossHarvestingOptimizer as T

    # Sec 70/74 ordering (engine pools: brought-forward + intra-year):
    # STCL 30k -> STCG 50k first (net 20k, STCL exhausted); LTCL 10k ->
    # LTCG only (70k -> 60k); net LTCG 60k sits below the 1.25L exemption
    # -> taxable LTCG 0; tax = 20% x 20,000 + 4% cess = 4,160.
    r = T.compute_tax_position(
        pd.DataFrame(), {},
        realized_gains={"STCG": 50000.0, "LTCG": 70000.0, "unpriced_events": 0},
        carried_forward={"unabsorbed_stcl_inr": 30000.0, "unabsorbed_ltcl_inr": 10000.0},
        include_surcharge_cess=True,
    )
    w = r["without_harvest"]
    assert w["net_stcg"] == pytest.approx(20000.0)
    assert w["net_ltcg"] == pytest.approx(60000.0)
    assert w["unabsorbed_stcl"] == pytest.approx(0.0)
    assert w["unabsorbed_ltcl"] == pytest.approx(0.0)
    assert r["tax_without_harvest_inr"] == pytest.approx(4160.0)

    # LTCL can NEVER offset STCG (Sec 70(3)): STCG 50k vs LTCL 20k ->
    # net STCG unchanged 50k, the LTCL is unabsorbed (carries forward).
    r2 = T.compute_tax_position(
        pd.DataFrame(), {},
        realized_gains={"STCG": 50000.0, "LTCG": 0.0, "unpriced_events": 0},
        carried_forward={"unabsorbed_ltcl_inr": 20000.0, "unabsorbed_stcl_inr": 0.0},
        include_surcharge_cess=True,
    )
    assert r2["without_harvest"]["net_stcg"] == pytest.approx(50000.0)
    assert r2["without_harvest"]["unabsorbed_ltcl"] == pytest.approx(20000.0)
    assert r2["tax_without_harvest_inr"] == pytest.approx(10400.0)

    # R26-3: a net-NEGATIVE STCG bucket (the ledger nets the year's realized
    # STCL into STCG) is a LOSS — it must offset LTCG (Sec 70) instead of
    # vanishing: STCG -50k + LTCG 500k -> net LTCG 450k -> taxable 325k ->
    # 12.5% = 40,625 + cess 1,625 = 42,250 (the pre-R26 code computed 48,750
    # and dropped the 50k loss entirely).
    r3 = T.compute_tax_position(
        pd.DataFrame(), {},
        realized_gains={"STCG": -50000.0, "LTCG": 500000.0, "unpriced_events": 0},
        include_surcharge_cess=True,
    )
    w3 = r3["without_harvest"]
    assert w3["intra_year_stcl_inr"] == pytest.approx(50000.0)
    assert w3["net_stcg"] == pytest.approx(0.0)
    assert w3["net_ltcg"] == pytest.approx(450000.0)
    assert r3["tax_without_harvest_inr"] == pytest.approx(42250.0)

    # and with nothing to offset, the net-negative loss carries forward
    # (pre-R26 it vanished: neither offset nor carry)
    r4 = T.compute_tax_position(
        pd.DataFrame(), {},
        realized_gains={"STCG": -60000.0, "LTCG": 0.0, "unpriced_events": 0},
    )
    assert r4["without_harvest"]["unabsorbed_stcl"] == pytest.approx(60000.0)
    assert r4["carry_forward_created_stcl_inr"] == pytest.approx(60000.0)

    # 8-year vintage expiry (endpoint state loader): prior-AY remainders
    # inside the window load, older ones expire, the current AY is excluded
    # (re-derived fresh every request), and malformed keys are skipped.
    from web_dashboard import app as app_mod
    tmp = Path(tempfile.mkdtemp())
    state = {
        "AY 2025-26": {"unabsorbed_stcl_inr": 1000.0, "unabsorbed_ltcl_inr": 200.0},
        "AY 2017-18": {"unabsorbed_stcl_inr": 5000.0, "unabsorbed_ltcl_inr": 0.0},
        "AY 2026-27": {"unabsorbed_stcl_inr": 999.0, "unabsorbed_ltcl_inr": 0.0},
        "garbage": {"unabsorbed_stcl_inr": 7.0},
    }
    state_file = tmp / "tax_carry_forward.json"
    state_file.write_text(json.dumps(state), encoding="utf-8")
    with mock.patch.object(app_mod, "_CARRY_FORWARD_STATE_FILE", state_file):
        out = app_mod._ledger_carry_forward_state(None, "AY 2026-27")
    assert out["unabsorbed_stcl_inr"] == pytest.approx(1000.0)
    assert out["unabsorbed_ltcl_inr"] == pytest.approx(200.0)
    # R26-4: the per-vintage map rides along for the write-back path
    assert out["vintages"]["AY 2025-26"]["unabsorbed_stcl_inr"] == pytest.approx(1000.0)
    assert "AY 2017-18" not in out["vintages"] and "AY 2026-27" not in out["vintages"]


def test_r26_3d_pin_disclosure_and_beta_prior_ladder():
    """Checklist D: the method_disclosure still lists the NOT-replayed
    live-data layers (re-selection depth honesty), and the beta prior
    ladder (licensed feed -> characteristic model -> flat
    BETA_SHRINK_PRIOR fallback) survives intact."""
    from math_engine.oos_walkforward import _RESELECT_DISCLOSURE

    # every WFO response carries the disclosure, and it still enumerates
    # the live-data layers that are NOT replayed per cutoff
    assert "NOT replayed" in _RESELECT_DISCLOSURE
    for layer in ("ML-alpha", "Barra", "blackout", "Kelly"):
        assert layer in _RESELECT_DISCLOSURE
    assert "point-in-time" in _RESELECT_DISCLOSURE

    # the three-layer beta prior ladder survives in code (deletion = revert)
    utils_code = _code_only(UTILS)
    assert "BETA_FACTOR_FEED" in utils_code
    assert "USE_FACTOR_MODEL_BETA_PRIOR" in utils_code
    assert "BETA_SHRINK_PRIOR" in utils_code
    indicators_code = _code_only(INDICATORS)
    assert "def factor_model_beta_prior" in indicators_code


# ══════════════════════════════════════════════════════════════════════
# R26-4 — payload/wiring/build-marker locks
# ══════════════════════════════════════════════════════════════════════

def test_r26_4a_endpoint_and_dashboard_carry_the_layers():
    """The /api/tax_optimizer payload and the dashboard hover must carry the
    R26 statutory layers: the capped surcharge + marginal relief keys."""
    app_code = _code_only(APP)
    m = re.search(r"def _handle_tax_optimizer\(.*?(?=\n    def )", app_code, re.S)
    assert m, "_handle_tax_optimizer not found in app.py"
    body = m.group(0)
    assert '"marginal_relief_inr"' in body
    assert '"marginal_relief_basis"' in body
    assert '"surcharge_rate_stcg_capped"' in body
    assert '"surcharge_gross_inr"' in body

    js_src = DASHBOARD_JS.read_text(encoding="utf-8")
    assert "marginal_relief_inr" in js_src

    tax_code = _code_only(TAX_ENGINE)
    assert "surcharge_rate_stcg_capped" in tax_code
    assert "marginal_relief_basis" in tax_code
    # the STCG component is capped by the same constant as the LTCG one
    assert "min(sr_rate, CAP_CG_SR) * stcg_tax" in tax_code


def test_r26_4c_carry_forward_state_no_double_count():
    """R26-4: the per-vintage write-back. Three-year simulation on a temp
    state file:
      Y1 (AY 2025-26): the year's own realized STCL -100k (net-negative
      bucket, R26-3) -> persists as a NEW vintage under AY 2025-26.
      Y2 (AY 2026-27): 40k STCG gains consume 40k of that vintage -> the
      ORIGINAL key is decremented to 60k (no re-stamped duplicate key).
      Y3 (AY 2027-28): loads 60k ONLY — the pre-R26 code loaded the stale
      100k key PLUS the re-stamped 60k key (160k, double count).
    """
    from math_engine.tax_loss_harvesting import TaxLossHarvestingOptimizer as T
    from web_dashboard import app as app_mod

    tmp = Path(tempfile.mkdtemp())
    state_file = tmp / "tax_carry_forward.json"
    with mock.patch.object(app_mod, "_CARRY_FORWARD_STATE_FILE", state_file):

        # ── Year 1: net-negative STCG bucket ──
        y1 = T.compute_tax_position(
            pd.DataFrame(), {},
            realized_gains={"STCG": -100000.0, "LTCG": 0.0, "unpriced_events": 0},
        )
        assert y1["without_harvest"]["intra_year_stcl_inr"] == pytest.approx(100000.0)
        assert y1["without_harvest"]["unabsorbed_stcl"] == pytest.approx(100000.0)
        cf1 = app_mod._ledger_carry_forward_state(None, "AY 2025-26")
        app_mod._persist_carry_forward_state(
            "AY 2025-26", y1, loaded_vintages=(cf1 or {}).get("vintages"))
        state1 = json.loads(state_file.read_text(encoding="utf-8"))
        assert state1["AY 2025-26"]["unabsorbed_stcl_inr"] == pytest.approx(100000.0)
        assert len(state1) == 1

        # ── Year 2: 40k STCG gains consume part of the vintage ──
        cf2 = app_mod._ledger_carry_forward_state(None, "AY 2026-27")
        assert cf2["unabsorbed_stcl_inr"] == pytest.approx(100000.0)
        y2 = T.compute_tax_position(
            pd.DataFrame(), {},
            realized_gains={"STCG": 40000.0, "LTCG": 0.0, "unpriced_events": 0},
            carried_forward=cf2,
        )
        assert y2["tax_without_harvest_inr"] == pytest.approx(0.0)  # fully offset
        assert y2["without_harvest"]["unabsorbed_stcl"] == pytest.approx(60000.0)
        app_mod._persist_carry_forward_state(
            "AY 2026-27", y2, loaded_vintages=(cf2 or {}).get("vintages"))
        state2 = json.loads(state_file.read_text(encoding="utf-8"))
        # the ORIGINAL vintage is decremented in place; no new key, no stale key
        assert state2["AY 2025-26"]["unabsorbed_stcl_inr"] == pytest.approx(60000.0)
        assert "AY 2026-27" not in state2
        assert len(state2) == 1

        # ── Year 3: loads 60k only (pre-R26 double count: 160k) ──
        cf3 = app_mod._ledger_carry_forward_state(None, "AY 2027-28")
        assert cf3["unabsorbed_stcl_inr"] == pytest.approx(60000.0)

        # ── Year 10 (AY 2034-35): the vintage is 9 years old -> expired ──
        cf10 = app_mod._ledger_carry_forward_state(None, "AY 2034-35")
        assert cf10["unabsorbed_stcl_inr"] == pytest.approx(0.0)


def test_r26_4b_build_marker_designates_round_26():
    """APP_BUILD_ID must carry the R26 designation while still satisfying
    the R21 legacy lock pattern (QA-R(19|20) + 'R21')."""
    app_src = APP.read_text(encoding="utf-8")
    m = re.search(r'APP_BUILD_ID\s*=\s*"([^"]+)"', app_src)
    assert m, "APP_BUILD_ID definition not found in app.py"
    build_id = m.group(1)
    assert re.search(r"QA-R(19|20)", build_id)
    assert "R21" in build_id and "R25" in build_id and "R26" in build_id
    assert "23.92" in build_id and "marginal relief" in build_id
