"""Round 27 regression locks — residual fixes (full-layer WFO replay, exact
mixed-income marginal relief, TAX_FMV_31JAN2018 builder, mark-stamp floor).

R27-1 (WFO replay depth — the runtime x K structural residual): the QUBO
       penalty layers (beta / fold-local turnover / Barra when enabled /
       Wasserstein DRO / same-sector off-diagonal) are now REPLAYED
       point-in-time per cutoff on trailing data by default; the ML-alpha
       injection, the blackout filters, and the DRO-CVaR/BL/Kelly/MDP
       weighting stack above HRP replay through the PRODUCTION functions when
       the caller supplies point-in-time inputs (per-cutoff predictions +
       DSR, a historical calendar, the cfg opt-in flags). Every run carries a
       per-run replay_scope + dynamic method_disclosure (no static caveat).
R27-2 (tax): exact mixed-income marginal relief when total_taxable_income +
       non_cg_tax (the slab-rate tax on non-CG income, before surcharge/cess)
       are supplied — pro-rata reference at the crossed surcharge bracket,
       non-CG slab tax in the surcharge base at the UNCAPPED bracket rate.
       The conservative approximation survives only as the disclosed fallback.
R27-3 (grandfathering): the TAX_FMV_31JAN2018 record is buildable
       (scripts/build_tax_fmv_feed.py — Yahoo .NS daily High, Sec 112A(2)
       highest-quoted-price resolver) and the endpoint AUTO-LOADS it.
R27-4 (marks): the journal mark stamp is FLOORED to ms — a mark timestamp can
       never round into the future, so measured age is deterministically >= 0
       (the R26-3b pin flaked exactly this way: -3.8e-08 h).
"""

import math
import re
import tempfile
import time
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "web_dashboard" / "app.py"
TAX_ENGINE = ROOT / "math_engine" / "tax_loss_harvesting.py"
WFO = ROOT / "math_engine" / "oos_walkforward.py"
LEDGER = ROOT / "core" / "realized_gains_ledger.py"
JOURNAL = ROOT / "core" / "trade_journal.py"
OPTIMIZER = ROOT / "optimizer.py"
FMV_SCRIPT = ROOT / "scripts" / "build_tax_fmv_feed.py"


def _code_only(path: Path) -> str:
    """Source with comments and docstrings removed (R22+ pattern-lock
    convention: AUDIT-FIX comments quote eliminated bug patterns)."""
    import ast
    import tokenize
    src = path.read_text(encoding="utf-8")
    tree = ast.parse(src)
    docstring_lines = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                docstring_lines.add(node.body[0].lineno)
    kept = []
    skip_until = -1
    for i, line in enumerate(src.splitlines(), start=1):
        if i <= skip_until:
            continue
        if i in docstring_lines:
            skip_until = i + 1  # single-line docstring only (module funcs here)
            continue
        kept.append(line)
    code = "\n".join(kept)
    # strip full-line comments
    code = "\n".join(l for l in code.splitlines()
                     if not l.lstrip().startswith("#"))
    try:
        for tok in tokenize.generate_tokens(io_iter := iter(code.splitlines(True))):
            pass
    except Exception:
        pass
    return code


def _make_frame(n=200, n_names=8, seed=7):
    """Deterministic synthetic frame: smooth increasing drifts per name."""
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range("2025-01-01", periods=n)
    cols = {}
    for i in range(n_names):
        drift = 0.0005 + 0.0002 * i
        cols[f"N{i:02d}.NS"] = 100.0 * np.exp(drift * np.arange(n))
    close = pd.DataFrame(cols, index=dates)
    vol = pd.DataFrame(1e6, index=dates, columns=close.columns, dtype=float)
    return close, vol


def _make_oscillating_frame(n=200, n_names=8):
    """N{last} has the FASTEST growth but high downside vol (alternating
    +6% / -4.5% with seeded noise — the noise makes the negative-return
    dispersion, i.e. the downside vol, non-degenerate) — the Wasserstein DRO
    penalty replay should avoid it when epsilon is large, while a
    zero-epsilon run selects it."""
    dates = pd.bdate_range("2025-01-01", periods=n)
    cols = {}
    for i in range(n_names - 1):
        drift = 0.0005 + 0.0002 * i
        cols[f"N{i:02d}.NS"] = 100.0 * np.exp(drift * np.arange(n))
    rng = np.random.default_rng(23)
    rets = np.where(np.arange(n) % 2 == 0, 0.06, -0.045) + rng.normal(0, 0.012, n)
    cols[f"N{n_names - 1:02d}.NS"] = 100.0 * np.cumprod(1.0 + rets)
    close = pd.DataFrame(cols, index=dates)
    vol = pd.DataFrame(1e6, index=dates, columns=close.columns, dtype=float)
    return close, vol


# ══════════════════════════════════════════════════════════════════════
# R27-4 — journal mark stamp floor (age never negative)
# ══════════════════════════════════════════════════════════════════════

def test_r27_0a_mark_stamp_never_in_future():
    """R27-4: the exchange-mark stamp is FLOORED to ms, never rounded into
    the future — a consumer reading age = now - stamp an instant later
    measures a deterministically non-negative age (the R26-3b CI flake)."""
    from core.trade_journal import TradeJournalManager

    tmp = Path(tempfile.mkdtemp())
    jm = TradeJournalManager(storage_path=tmp / "j.json")
    jm.trades = [{
        "id": "TX1", "basket_name": "b", "ticker": "Z.NS",
        "entry_date": "2026-06-01", "entry_price": 100.0,
        "current_price": 100.0, "stop_loss_price": 50.0,
        "snell_target_price": 500.0, "weight_pct": 5.0,
        "profile_source": "t", "status": "ACTIVE", "unlevelled": False,
        "unrealized_pnl_%": 0.0, "realized_pnl_%": 0.0,
        "exit_date": None, "exit_price": None, "notes": "",
    }]
    stats = jm.update_live_prices({"Z.NS": 99.0},
                                  price_sources={"Z.NS": "NSE via Yahoo (.NS)"})
    assert stats["updated"] == 1
    trade = jm.trades[0]
    stamp = trade["last_mark_ts"]
    assert isinstance(stamp, float)
    # the floor semantics: stamp <= every later now-read (deterministic,
    # repeated to stress the sub-ms boundary where round() used to flip up)
    for _ in range(25):
        assert time.time() >= stamp
    age_h = (time.time() - stamp) / 3600.0
    assert 0.0 <= age_h < 0.01
    # pattern lock: the floor (not round) is what stamps the mark
    jcode = _code_only(JOURNAL)
    assert "math.floor(_mark_ts * 1000.0) / 1000.0" in jcode


# ══════════════════════════════════════════════════════════════════════
# R27-1 — full-layer WFO replay
# ══════════════════════════════════════════════════════════════════════

def test_r27_1a_qubo_core_extra_diag_flips_argmin():
    """Hand-check: the R27 penalty replay term enters the QUBO-core diagonal
    exactly like the production build_qubo penalties — a heavy extra_diag on
    the top-alpha name flips the 2-of-3 argmin from {P,Q} to {Q,R}."""
    from math_engine.oos_walkforward import _qubo_core_select

    cands = ["P.NS", "Q.NS", "R.NS"]
    alpha_z = {"P.NS": 1.4, "Q.NS": 1.3, "R.NS": 0.9}
    vol_z = {"P.NS": 0.0, "Q.NS": 0.0, "R.NS": 0.0}
    corr = pd.DataFrame(np.eye(3), index=cands, columns=cands)

    sel_plain = _qubo_core_select(cands, alpha_z, vol_z, corr, 2, None)
    assert sorted(sel_plain) == ["P.NS", "Q.NS"]

    sel_pen = _qubo_core_select(cands, alpha_z, vol_z, corr, 2, None,
                                extra_diag={"P.NS": 10.0})
    assert sorted(sel_pen) == ["Q.NS", "R.NS"]


def test_r27_1b_sector_offdiag_penalty_avoids_same_sector_pair():
    """Hand-check: with a sector map + a large same-sector penalty, the
    QUBO-core replay avoids the {P,Q} same-sector pair (argmin {P,R})."""
    from math_engine.oos_walkforward import _qubo_core_select

    cands = ["P.NS", "Q.NS", "R.NS"]
    alpha_z = {"P.NS": 1.4, "Q.NS": 1.3, "R.NS": 0.9}
    vol_z = {"P.NS": 0.0, "Q.NS": 0.0, "R.NS": 0.0}
    corr = pd.DataFrame(np.eye(3), index=cands, columns=cands)
    sectors = {"P.NS": "IT", "Q.NS": "IT", "R.NS": "FMCG"}

    sel = _qubo_core_select(cands, alpha_z, vol_z, corr, 2, None,
                            sectors=sectors, sector_penalty=50.0)
    assert sorted(sel) == ["P.NS", "R.NS"]

    # unknown-sector pairs carry the unknown penalty (production _unk_pen mirror)
    sel_unk = _qubo_core_select(cands, alpha_z, vol_z, corr, 2, None,
                                sectors={"P.NS": "IT", "Q.NS": "N/A", "R.NS": "FMCG"},
                                unknown_sector_penalty=50.0)
    assert sorted(sel_unk) == ["P.NS", "R.NS"]


def test_r27_1c_blackout_replay_filters_at_cutoff():
    """The caller-supplied historical blackout calendar drops a candidate at
    the cutoff it blackens (+/- window) and leaves other cutoffs untouched;
    the fold payload + replay_scope disclose the replay."""
    from math_engine.oos_walkforward import walk_forward_reselection_backtest

    close, vol = _make_frame()
    bench = pd.Series(0.0, index=close.index)

    base = walk_forward_reselection_backtest(
        close, vol, n_folds=2, score_lookback=63, k_stocks=3,
        mode="balanced", benchmark_returns=bench)
    f0 = base["folds"][0]
    fast = f0["basket"][0] if f0["basket"] else None
    assert fast, "baseline fold produced no basket"
    assert fast in f0["basket"]  # sanity: the name we will black out is selected

    cutoff0 = pd.Timestamp(f0["cutoff_date"])
    cal = {fast: [cutoff0 + pd.Timedelta(days=1)]}
    res = walk_forward_reselection_backtest(
        close, vol, n_folds=2, score_lookback=63, k_stocks=3,
        mode="balanced", benchmark_returns=bench,
        blackouts_by_symbol=cal, blackout_window_days=5)
    f0b = res["folds"][0]
    assert fast in f0b["blackouts_blocked"]
    assert fast not in f0b["basket"]
    # the second cutoff is ~68 business days away — not blacked out there
    f1b = res["folds"][1]
    assert fast not in f1b["blackouts_blocked"]
    # per-run replay scope: blackouts REPLAYED (with the window + count)
    assert res["replay_scope"]["blackouts"]["replayed"] is True
    assert "name-blocks" in res["replay_scope"]["blackouts"]["source"]
    assert "blackouts: REPLAYED point-in-time" in res["method_disclosure"]


def test_r27_1d_ml_alpha_replay_production_gate_semantics():
    """ML-alpha replay follows the PRODUCTION Phase-9 semantics exactly:
    weight = ML_ALPHA_WEIGHT x clip((DSR - floor)/(1 - floor)); DSR missing
    -> injection REFUSED (weight 0, note, replay_scope NOT replayed)."""
    from math_engine.oos_walkforward import (_ml_blend_scores,
                                             _ml_replay_weight,
                                             walk_forward_reselection_backtest)

    # blend formula hand-check: z(alpha)x(1-w) + z(ml)xw, plain mean/std z
    scores = {"A.NS": 0.2, "B.NS": 0.1, "C.NS": 0.0}
    ml = {"A.NS": -1.0, "B.NS": 0.0, "C.NS": 1.0}
    blended = _ml_blend_scores(scores, ml, 0.25)
    z = 1.0 / np.sqrt(3.0 / 3.0)  # std of (0.2,0.1,0.0) = 0.08165, z = 1.22474
    exp_a = 1.2247448713915892 * 0.75 + (-1.2247448713915892) * 0.25
    assert blended["A.NS"] == pytest.approx(exp_a, abs=1e-9)
    assert blended["B.NS"] == pytest.approx(0.0, abs=1e-12)
    assert blended["C.NS"] == pytest.approx(-exp_a, abs=1e-9)

    # DSR weight gate mirrors production scaling
    assert _ml_replay_weight(None, None) == 0.0
    assert _ml_replay_weight({}, 0.05) == 0.0            # below floor
    assert _ml_replay_weight({"ML_ALPHA_WEIGHT": 0.30, "ML_DSR_FLOOR": 0.10}, 0.50) \
        == pytest.approx(0.30 * (0.40 / 0.90), abs=1e-9)
    assert _ml_replay_weight({}, 1.0) == pytest.approx(0.30, abs=1e-9)

    close, vol = _make_frame()
    bench = pd.Series(0.0, index=close.index)
    base = walk_forward_reselection_backtest(
        close, vol, n_folds=2, score_lookback=63, k_stocks=3,
        mode="balanced", benchmark_returns=bench)
    key = base["folds"][0]["cutoff_date"]
    top = base["folds"][0]["basket"][0]

    ml_scores = {key: {top: -5.0, "N00.NS": 5.0}}
    # WITH per-cutoff DSR: injected at the production-scaled weight
    res = walk_forward_reselection_backtest(
        close, vol, n_folds=2, score_lookback=63, k_stocks=3,
        mode="balanced", benchmark_returns=bench,
        ml_alpha_by_cutoff=ml_scores, ml_dsr_by_cutoff={key: 0.5})
    assert res["folds"][0]["ml_alpha_weight"] == pytest.approx(0.30 * (0.4 / 0.9), abs=1e-3)
    assert res["replay_scope"]["ml_alpha"]["replayed"] is True
    assert "ml_alpha: REPLAYED point-in-time" in res["method_disclosure"]

    # WITHOUT DSR: injection REFUSED exactly like the live Phase-9 gate
    res2 = walk_forward_reselection_backtest(
        close, vol, n_folds=2, score_lookback=63, k_stocks=3,
        mode="balanced", benchmark_returns=bench,
        ml_alpha_by_cutoff=ml_scores)
    assert res2["folds"][0]["ml_alpha_weight"] == 0.0
    assert "REFUSED" in res2["folds"][0]["ml_alpha_note"]
    assert res2["replay_scope"]["ml_alpha"]["replayed"] is False
    assert "DSR" in res2["replay_scope"]["ml_alpha"]["reason"]


def test_r27_1e_dro_penalty_replay_flips_selection():
    """The Wasserstein DRO penalty replay changes the point-in-time selection
    when epsilon is large: the fast-but-oscillating name is selected at
    epsilon=0 and avoided at epsilon=50 (the penalty layer is REAL, not
    decorative — and it is replayed by default)."""
    from math_engine.oos_walkforward import walk_forward_reselection_backtest

    close, vol = _make_oscillating_frame()
    bench = pd.Series(0.0, index=close.index)
    fast = "N07.NS"

    res0 = walk_forward_reselection_backtest(
        close, vol, n_folds=2, score_lookback=63, k_stocks=3,
        mode="balanced", benchmark_returns=bench,
        allocation_cfg={"WASSERSTEIN_DRO_EPSILON": 0.0})
    assert fast in res0["folds"][0]["basket"]
    assert res0["replay_scope"]["qubo_penalties"]["replayed"] is True

    res50 = walk_forward_reselection_backtest(
        close, vol, n_folds=2, score_lookback=63, k_stocks=3,
        mode="balanced", benchmark_returns=bench,
        allocation_cfg={"WASSERSTEIN_DRO_EPSILON": 100.0})
    assert fast not in res50["folds"][0]["basket"]
    assert "DRO" in res50["folds"][0]["penalties_replayed"]
    assert "R27 penalty replay" in res50["folds"][0]["selection"]


def test_r27_1f_replay_scope_and_dynamic_disclosure():
    """Default run (no new inputs): replay_scope present with every layer
    status; the dynamic method_disclosure lists BOTH the replayed layers and
    the NOT-replayed ones with reasons (per-run, not a static caveat); the
    degenerate path still carries the base disclosure."""
    from math_engine.oos_walkforward import walk_forward_reselection_backtest

    close, vol = _make_frame()
    bench = pd.Series(0.0, index=close.index)
    res = walk_forward_reselection_backtest(
        close, vol, n_folds=2, score_lookback=63, k_stocks=3,
        mode="balanced", benchmark_returns=bench)

    rs = res["replay_scope"]
    for key in ("pool_cut", "qubo_core", "qubo_penalties", "ml_alpha",
                "blackouts", "weighting_stack", "regime_tilt", "cmf"):
        assert key in rs and isinstance(rs[key], dict)
        assert "replayed" in rs[key]
    # penalties replayed BY DEFAULT (all computable on trailing data)
    assert rs["qubo_penalties"]["replayed"] is True
    assert rs["qubo_core"]["replayed"] is True
    # ML-alpha and blackouts honestly NOT replayed without inputs
    assert rs["ml_alpha"]["replayed"] is False and "not supplied" in rs["ml_alpha"]["reason"]
    assert rs["blackouts"]["replayed"] is False

    md = res["method_disclosure"]
    assert "QUBO-CORE" in md                       # R25 lock parity
    assert "Round-27 per-run replay scope" in md
    assert "qubo_penalties: REPLAYED point-in-time" in md
    assert "ml_alpha: NOT replayed" in md
    assert "blackouts: NOT replayed" in md

    # degenerate run keeps the base disclosure (contains the NOT-replayed text)
    deg = walk_forward_reselection_backtest(pd.DataFrame(), None)
    assert "NOT replayed" in deg["method_disclosure"]


def test_r27_1g_weighting_stack_replays_or_discloses():
    """With USE_MDP enabled in allocation_cfg, the fold runs (or honestly
    skips + discloses) the PRODUCTION MDP layer above HRP; weights stay
    normalized either way."""
    from math_engine.oos_walkforward import walk_forward_reselection_backtest

    dates = pd.bdate_range("2025-01-01", periods=200)
    cols = {}
    rng = np.random.default_rng(11)
    for i in range(6):
        rets = 0.0004 + 0.0002 * i + rng.normal(0, 0.004 + 0.002 * i, 200)
        cols[f"W{i}.NS"] = 100.0 * np.cumprod(1.0 + rets)
    close = pd.DataFrame(cols, index=dates)
    vol = pd.DataFrame(1e6, index=dates, columns=close.columns, dtype=float)

    res = walk_forward_reselection_backtest(
        close, vol, n_folds=2, score_lookback=63, k_stocks=3,
        mode="balanced", benchmark_returns=pd.Series(0.0, index=dates),
        allocation_cfg={"USE_MDP": True})
    f0 = res["folds"][0]
    layers = f0["weighting_layers"]
    assert layers, "weighting_layers must be present when the stack replay runs"
    assert any("MDP" in l for l in layers)
    # either the production layer ran or its skip is DISCLOSED — never silent
    assert any("MDP (production)" in l for l in layers) or \
        any("MDP skipped" in l for l in layers)
    total_w = sum(f0["weights"].values())
    assert total_w == pytest.approx(1.0, abs=0.02)


# ══════════════════════════════════════════════════════════════════════
# R27-2 — exact mixed-income marginal relief
# ══════════════════════════════════════════════════════════════════════

def test_r27_2a_exact_mixed_income_marginal_relief():
    """Hand-derived vector: LTCG 50.5L (post-cutover), TI 50.5L, non-CG tax 0.
    tax_flat = 12.5% x (50.5L - 1.25L) = 615,625; surcharge 10% = 61,562.5;
    pro-rata reference at the crossed 50L threshold:
      s = 50L/50.5L, cg_thr = 615,625 x s = 609,529.70, rate at 50L = 0 ->
      cap = 609,529.70 + 50,000 = 659,529.70 -> relief = 17,657.80 (exact)
    vs the R26 conservative shortcut 61,562.5 - 50,000 = 11,562.5 — the
    exact path grants MORE relief (the old fallback overstated tax)."""
    from math_engine.tax_loss_harvesting import TaxLossHarvestingOptimizer as T

    rg = {"LTCG": 5_050_000.0,
          "regime_split": {"LTCG": {"pre_cutoff": 0.0, "post_cutoff": 5_050_000.0}}}

    res = T.compute_tax_position(
        None, {}, realized_gains=rg, include_surcharge_cess=True,
        total_taxable_income_inr=5_050_000.0, non_cg_tax_inr=0.0)
    a = res["without_harvest"]
    assert a["tax_before_surcharge_inr"] == pytest.approx(615_625.0, abs=0.01)
    assert a["surcharge_gross_inr"] == pytest.approx(61_562.5, abs=0.01)
    assert a["marginal_relief_inr"] == pytest.approx(17_657.8, abs=0.5)
    # relief binding -> tax + net surcharge sits exactly at the statutory cap
    assert a["marginal_relief_cap_reference_inr"] == pytest.approx(659_529.7, abs=0.5)
    assert (a["tax_before_surcharge_inr"] + a["surcharge_inr"]) == \
        pytest.approx(659_529.7, abs=0.5)
    assert a["marginal_relief_basis"].startswith("exact (mixed-income")
    assert a["non_cg_tax_supplied"] is True

    # without non_cg_tax_inr the R26 conservative branch stands (less relief)
    res_cons = T.compute_tax_position(
        None, {}, realized_gains=rg, include_surcharge_cess=True,
        total_taxable_income_inr=5_050_000.0)
    a_cons = res_cons["without_harvest"]
    assert a_cons["marginal_relief_inr"] == pytest.approx(11_562.5, abs=0.5)
    assert a_cons["marginal_relief_inr"] < a["marginal_relief_inr"]
    assert "non_cg_tax_inr" in a_cons["marginal_relief_basis"]  # upgrade path disclosed


def test_r27_2b_noncg_tax_enters_surcharge_base():
    """STCG 50L (post), TI 60L, non-CG tax 1L: the surcharge base now covers
    the non-CG slab tax at the UNCAPPED bracket rate — 10% x (100,000 CG tax
    + 10,000 non-CG tax) = 110,000 gross (vs 100,000 without the input);
    total = 1,000,000 + 110,000 + 4% cess = 1,154,400 (no relief binding)."""
    from math_engine.tax_loss_harvesting import TaxLossHarvestingOptimizer as T

    rg = {"STCG": 5_000_000.0,
          "regime_split": {"STCG": {"pre_cutoff": 0.0, "post_cutoff": 5_000_000.0}}}

    res = T.compute_tax_position(
        None, {}, realized_gains=rg, include_surcharge_cess=True,
        total_taxable_income_inr=6_000_000.0, non_cg_tax_inr=100_000.0)
    a = res["without_harvest"]
    assert a["surcharge_gross_inr"] == pytest.approx(110_000.0, abs=0.01)
    assert a["tax_inr"] == pytest.approx(1_154_400.0, abs=0.5)
    assert a["marginal_relief_inr"] == 0.0  # 1.21M < 1.916M cap — no relief
    assert a["non_cg_tax_inr"] == pytest.approx(100_000.0, abs=0.01)

    res_wo = T.compute_tax_position(
        None, {}, realized_gains=rg, include_surcharge_cess=True,
        total_taxable_income_inr=6_000_000.0)
    assert res_wo["without_harvest"]["surcharge_gross_inr"] == pytest.approx(100_000.0, abs=0.01)
    assert res_wo["without_harvest"]["non_cg_tax_supplied"] is False


def test_r27_2c_app_and_engine_wiring_patterns():
    """Pattern locks: the endpoint accepts ?non_cg_tax and threads it into
    compute_tax_position; the engine carries the exact mixed-income branch
    and the conservative fallback names the upgrade path."""
    app_code = _code_only(APP)
    assert 'params.get("non_cg_tax")' in app_code
    assert "non_cg_tax_inr=_ncg" in app_code
    assert '"fmv_feed_source": _fmv_src' in app_code

    tax_code = _code_only(TAX_ENGINE)
    assert "non_cg_tax_inr: Optional[float] = None" in tax_code
    assert "exact (mixed-income" in tax_code
    assert "marginal_relief_cap_reference_inr" in tax_code
    # the conservative fallback text names the exact-relief upgrade path
    assert tax_code.count("non_cg_tax_inr") >= 3


# ══════════════════════════════════════════════════════════════════════
# R27-3 — TAX_FMV_31JAN2018 builder + endpoint auto-load
# ══════════════════════════════════════════════════════════════════════

def test_r27_3a_fmv_resolver_vectors():
    """The Sec 112A(2) highest-quoted-price resolver: exact 31-Jan-2018 row;
    nearest trading day on-or-before within the window; nothing usable ->
    (None, None); non-positive/unparseable rows skipped, never invented."""
    from core.realized_gains_ledger import resolve_fmv_31jan2018

    assert resolve_fmv_31jan2018({"2018-01-31": 150.0}) == (150.0, "2018-01-31")
    assert resolve_fmv_31jan2018({"2018-01-30": 148.0, "2018-01-29": 145.0}) \
        == (148.0, "2018-01-30")
    # a later row (post-valuation) must NEVER be used
    assert resolve_fmv_31jan2018({"2018-02-02": 160.0}) == (None, None)
    assert resolve_fmv_31jan2018({"2018-01-20": 140.0}) == (None, None)
    assert resolve_fmv_31jan2018({}) == (None, None)
    assert resolve_fmv_31jan2018(None) == (None, None)
    assert resolve_fmv_31jan2018({"2018-01-31": -1.0, "garbage": "x"}) == (None, None)
    # window is configurable
    assert resolve_fmv_31jan2018({"2018-01-24": 141.0}, max_lookback_days=10) \
        == (141.0, "2018-01-24")
    assert resolve_fmv_31jan2018({"2018-01-24": 141.0}, max_lookback_days=3) \
        == (None, None)


def test_r27_3b_builder_script_and_autoload_patterns():
    """The feed builder exists, uses the PURE resolver, writes the exact
    {ticker: fmv} shape, and has an offline --selfcheck; the endpoint
    auto-loads qa_db/tax_fmv_31jan2018.json when the cfg lacks the feed."""
    assert FMV_SCRIPT.exists()
    script_src = FMV_SCRIPT.read_text(encoding="utf-8")
    assert "resolve_fmv_31jan2018" in script_src
    assert "--selfcheck" in script_src
    assert "tax_fmv_31jan2018.json" in script_src
    assert "build_tax_fmv_feed" in script_src

    app_code = _code_only(APP)
    assert 'tax_fmv_31jan2018.json' in app_code
    assert 'scripts/build_tax_fmv_feed.py' in app_code

    ledger_code = _code_only(LEDGER)
    assert "def resolve_fmv_31jan2018" in ledger_code
    assert "FMV_VALUATION_DATE" in ledger_code


# ══════════════════════════════════════════════════════════════════════
# R27 wiring + build marker
# ══════════════════════════════════════════════════════════════════════

def test_r27_4_sweep_wiring_and_build_marker():
    """The sweep passes the sector map + blackout window into the WFO replay;
    the WFO module carries the R27 layer-replay machinery; the build marker
    designates Round 27 while preserving the full lineage (R21/R25/R26,
    QA-R(19|20) prefix, SOVEREIGN-TIER-OMEGA, the 23.92 effective-rate pin
    and the marginal-relief mention)."""
    opt_code = _code_only(OPTIMIZER)
    assert "sectors=(sectors if isinstance(sectors, dict) and sectors else None)" in opt_code
    assert 'working_cfg.get("EARNINGS_BLACKOUT_DAYS", 5)' in opt_code
    assert "replay_scope" in opt_code

    wfo_code = _code_only(WFO)
    for sym in ("def _point_in_time_betas(", "def _point_in_time_penalties(",
                "def _ml_blend_scores(", "def _ml_replay_weight(",
                "def _blackout_replay_filter(", "def _weighting_stack_replay(",
                "def _clip_weights(", "def _reselect_disclosure_for("):
        assert sym in wfo_code, f"missing R27 helper: {sym}"
    assert '"replay_scope": replay_status' in wfo_code
    assert "extra_diag: Optional[Dict[str, float]] = None" in wfo_code
    assert "sector_penalty: float = 0.0" in wfo_code

    app_src = APP.read_text(encoding="utf-8")
    m = re.search(r'APP_BUILD_ID\s*=\s*"([^"]+)"', app_src)
    assert m, "APP_BUILD_ID definition not found in app.py"
    build_id = m.group(1)
    assert re.search(r"QA-R(19|20)", build_id)
    for tag in ("R21", "R25", "R26", "R27"):
        assert tag in build_id, f"build id missing {tag}"
    assert "SOVEREIGN-TIER-OMEGA" in build_id
    assert "23.92" in build_id and "marginal relief" in build_id
    assert "replay_scope" in build_id
