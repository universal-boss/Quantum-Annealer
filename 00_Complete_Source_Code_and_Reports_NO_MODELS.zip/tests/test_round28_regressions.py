"""Round 28 regression locks — the TAX_FMV_31JAN2018 feed goes LIVE.

R28-1 (one-time pull, executed): the pinned builder (R27-3) ran chunked over
       combined_universe.csv — 564/792 resolved, 228 honestly missing
       (post-31-Jan-2018 IPOs / retired symbols; per-ticker failures
       reported, NEVER invented). qa_db/tax_fmv_31jan2018.json now exists at
       the endpoint's auto-load path.
R28-2 (restatement overlay): the vendor back-adjusts history for some
       post-2018 splits/bonuses and its split metadata is unreliable in both
       directions (HDFCBANK's real 2025 bonus never applied to bars;
       BRITANNIA's real 2021 bonus missing from metadata). The overlay
       applies ONLY anchor-verified factors (web-verified event + clean
       price-band reconciliation: RELIANCE/TCS/INFY/HDFCBANK/BPCL/
       TORNTPHARM/HCLTECH x2, ITC raw); every other candidate factor is
       DISCLOSED but NOT applied (under-restating FMV overstates tax =
       conservative; over-restating would UNDERSTATE tax = never default).
R28-3 (activation): the ledger's Sec 112A(2) grandfathering consumes the
       feed value end-to-end (deemed cost = max(cost, min(FMV, sale))).
"""

import importlib.util
import json
import re
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "web_dashboard" / "app.py"
FMV_SCRIPT = ROOT / "scripts" / "build_tax_fmv_feed.py"
RESTATE_SCRIPT = ROOT / "scripts" / "restate_fmv_feed.py"
FEED = ROOT / "qa_db" / "tax_fmv_31jan2018.json"
META = ROOT / "qa_db" / "tax_fmv_31jan2018.meta.json"
RAW = ROOT / "qa_db" / "tax_fmv_31jan2018.raw.json"


def _code_only(path: Path) -> str:
    """Source with comments and docstrings removed (R22+ convention)."""
    import ast
    src = path.read_text(encoding="utf-8")
    tree = ast.parse(src)
    docstring_lines = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef,
                             ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                docstring_lines.add(node.body[0].lineno)
    kept = []
    skip_until = -1
    for i, line in enumerate(src.splitlines(), start=1):
        if i <= skip_until:
            continue
        if i in docstring_lines:
            skip_until = i + 1
            continue
        kept.append(line)
    return "\n".join(l for l in kept if not l.lstrip().startswith("#"))


def _load_restate_module():
    spec = importlib.util.spec_from_file_location("restate_fmv_feed", RESTATE_SCRIPT)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


# ══════════════════════════════════════════════════════════════════════
# R28-2 — the restatement overlay (pure semantics + discipline)
# ══════════════════════════════════════════════════════════════════════

def test_r28_1a_restatement_pure_vectors():
    """Verified factor applies (rounded 2dp); unverified stays RAW with no
    factor; factor 1.0 keeps the value; non-positive rows untouched."""
    mod = _load_restate_module()
    final, meta = mod.apply_restatement(
        {"AAA.NS": 100.0, "BBB.NS": 100.0, "CCC.NS": -1.0},
        verified={"AAA.NS": {"factor": 2.0, "provenance": "x"},
                  "CCC.NS": {"factor": 2.0, "provenance": "x"}})
    assert final["AAA.NS"] == pytest.approx(200.0)
    assert meta["AAA.NS"]["restated"] == pytest.approx(200.0)
    assert final["BBB.NS"] == pytest.approx(100.0)
    assert meta["BBB.NS"]["factor"] is None
    assert "conservative" in meta["BBB.NS"]["provenance"]
    assert "NOT applied" in meta["BBB.NS"]["provenance"]
    assert final["CCC.NS"] == -1.0  # guard: non-positive never touched
    f1, _ = mod.apply_restatement({"D.NS": 100.0},
                                  verified={"D.NS": {"factor": 1.0}})
    assert f1["D.NS"] == pytest.approx(100.0)


def test_r28_1b_phantom_exclusion_discipline():
    """THE HDFCBANK case: vendor metadata lists TWO continuous events
    (candidate x4) but the anchor-verified divisor is x2 — the overlay must
    apply x2, NOT x4, and must DISCLOSE the x4 candidate it refused.
    Applying the phantom would OVERSTATE FMV and UNDERSTATE tax (the
    forbidden direction).
    [R31 SUPERSESSION NOTE: the pure-function discipline is unchanged, but
    on the LIVE feed the record rebase supersedes this layer — the exchange
    record proved the true HDFCBANK divisor IS x4 (2019 split AND 2025
    bonus both back-applied; record High 2013.50). This test exercises the
    legacy fallback path with explicit arguments, which remains correct
    behavior for record-uncovered tickers.]"""
    mod = _load_restate_module()
    final, meta = mod.apply_restatement(
        {"HDFCBANK.NS": 503.38},
        verified={"HDFCBANK.NS": {"factor": 2.0, "provenance": "x",
                                  "excluded_events": [
                                      ("2025-08-26", 2.0, "real, never applied")]}},
        sweep={"HDFCBANK.NS": {
            "post_valuation_events": [
                {"date": "2019-09-19", "ratio": 2.0,
                 "class": "continuous(restamped-or-phantom)"},
                {"date": "2025-08-26", "ratio": 2.0,
                 "class": "continuous(restamped-or-phantom)"}],
            "candidate_factor": 4.0}})
    assert final["HDFCBANK.NS"] == pytest.approx(1006.76)
    assert final["HDFCBANK.NS"] != pytest.approx(503.38 * 4)
    assert meta["HDFCBANK.NS"]["candidate_evidence"]["candidate_factor"] == 4.0
    assert "unreliable" in meta["HDFCBANK.NS"]["candidate_evidence"]["note"]


def test_r28_1c_verified_registry_content():
    """The registry entries all carry a positive factor + provenance; the
    HDFCBANK entry documents the EXCLUDED real-but-never-applied bonus; the
    entry set matches the anchor-verified names from the R28 report.
    [R31 SUPERSESSION NOTE: the registry is now the LEGACY fallback layer —
    the live feed is record-rebased (559 tickers) and two of these anchors
    were corrected by the record (RELIANCE, HDFCBANK); the corrected
    narratives live in the entries and in the record overlay's
    anchor_corrections block.]"""
    mod = _load_restate_module()
    vf = mod.VERIFIED_FACTORS
    expected = {"RELIANCE.NS", "TCS.NS", "INFY.NS", "HDFCBANK.NS", "ITC.NS",
                "BPCL.NS", "TORNTPHARM.NS", "HCLTECH.NS"}
    assert set(vf) == expected
    for tk, v in vf.items():
        assert float(v["factor"]) > 0
        assert v.get("provenance")
    excl = vf["HDFCBANK.NS"].get("excluded_events") or []
    assert excl and "2025-08-26" in excl[0] and "UNDERSTATE tax" in excl[0][2]


def test_r28_1d_overlay_and_builder_pattern_locks():
    """Pattern locks: the overlay carries the discipline text (conservative
    direction, never-invent, raw backup for idempotency, --selfcheck) and
    the PINNED R27 builder remains untouched (its contract strings intact)."""
    assert RESTATE_SCRIPT.exists()
    src = RESTATE_SCRIPT.read_text(encoding="utf-8")
    for needle in ("VERIFIED_FACTORS", "never the default",
                   "under-restating FMV overstates tax",
                   "tax_fmv_31jan2018.raw.json", "--selfcheck",
                   "excluded_events", "--rebaseline"):
        assert needle in src, f"overlay missing: {needle}"
    code = _code_only(RESTATE_SCRIPT)
    assert "def apply_restatement(" in code

    builder_src = FMV_SCRIPT.read_text(encoding="utf-8")
    for needle in ("never invented", "resolve_fmv_31jan2018", "--selfcheck",
                   "tax_fmv_31jan2018.json", "HIGHEST QUOTED PRICE"):
        assert needle in builder_src, f"pinned builder damaged: {needle}"


# ══════════════════════════════════════════════════════════════════════
# R28-1 / R28-2 — the LIVE feed file contract (skip only if absent)
# ══════════════════════════════════════════════════════════════════════

@pytest.mark.skipif(not FEED.exists(), reason="feed not pulled in this checkout")
def test_r28_2a_live_feed_contract():
    """The built feed is a flat {ticker: positive float} map; the meta keeps
    the R27 shape (valuation_date / resolved / missing) with the enrichment
    (raw / restated / factor / provenance / candidates) and the
    never-invent + conservative-direction disclosures."""
    feed = json.loads(FEED.read_text(encoding="utf-8"))
    meta = json.loads(META.read_text(encoding="utf-8"))
    assert feed and isinstance(feed, dict)
    for tk, v in feed.items():
        assert isinstance(v, (int, float)) and float(v) > 0, f"bad row {tk}"
    assert meta["valuation_date"] == "2018-01-31"
    assert isinstance(meta.get("missing"), list)
    assert "resolved" in meta and set(meta["resolved"]) == set(feed)
    rs = meta["restatement"]
    assert rs["verified_tickers"] >= 1
    assert "conservative" in rs["discipline"]
    if meta["missing"]:
        assert meta.get("note") or rs.get("promotion_path")


@pytest.mark.skipif(not FEED.exists(), reason="feed not pulled in this checkout")
def test_r28_2b_verified_anchors_consistent():
    """[R31 SUPERSESSION — intent preserved, reference updated] The original
    lock asserted feed == round(raw x legacy_factor, 2) for the 8 R28
    anchor-verified tickers. R31 delivered the NSE 31-Jan-2018 exchange
    record (qa_db/tax_fmv_31jan2018.record.json) and the record rebase
    supersedes the legacy factor layer wherever the record covers the
    ticker — the record CORRECTED two of the R28 anchors (RELIANCE's true
    divisor is the compound 2.18739 = 2023 Jio demerger x 2024 bonus, not
    2.0; HDFCBANK's is 3.9998 = 2019 split AND 2025 bonus both back-applied,
    not 2.0). Intent preserved: 'the overlay is part of the pipeline' —
    record-rebased entries must equal the record overlay fmv exactly;
    record-uncovered entries with a legacy factor must still equal
    round(raw x factor, 2)."""
    feed = json.loads(FEED.read_text(encoding="utf-8"))
    meta = json.loads(META.read_text(encoding="utf-8"))
    overlay_path = ROOT / "qa_db" / "tax_fmv_31jan2018.record_overlay.json"
    overlay = None
    if overlay_path.exists():
        overlay = json.loads(overlay_path.read_text(encoding="utf-8"))["overlay"]
    n_record = 0
    for tk, rec in meta["resolved"].items():
        if rec.get("record_rebased"):
            n_record += 1
            assert overlay is not None and tk in overlay, f"missing overlay row {tk}"
            assert feed[tk] == pytest.approx(overlay[tk]["fmv"], abs=0.01), \
                f"feed value not record-rebased for {tk}"
            continue
        if rec.get("bse_record_promoted"):
            # [R32 SUPERSESSION — intent preserved, reference updated] R32
            # delivered the BSE 31-Jan-2018 record and ADDED the feed-missing
            # BSE-only ticker it covers at its record High (CARYSIL.NS). A
            # promotion is not a pulled row: raw is None and restated == the
            # record fmv by construction — the 'factor None implies untouched
            # raw' invariant below only ever described PULLED tickers. The
            # overlay-vs-feed exactness above still applies to all 559
            # record-rebased tickers, unchanged.
            assert rec.get("raw") is None
            assert feed[tk] == pytest.approx(rec["restated"], abs=0.01)
            continue
        f = rec.get("factor")
        if f is None:
            assert rec.get("restated") is None
            continue
        assert feed[tk] == pytest.approx(round(rec["raw"] * f, 2), abs=0.01)
    assert n_record >= 559, ("the R31 record rebase is missing — re-run "
                             "scripts/restate_fmv_feed.py")


# ══════════════════════════════════════════════════════════════════════
# R28-3 — activation: feed -> Sec 112A(2) grandfathering end-to-end
# ══════════════════════════════════════════════════════════════════════

@pytest.mark.skipif(not FEED.exists(), reason="feed not pulled in this checkout")
def test_r28_3_feed_flows_through_grandfathering():
    """A synthetic pre-Feb-2018 RELIANCE lot through the ledger: deemed cost
    = max(cost, min(FMV_feed, sale)); the LIVE feed value (restated where
    verified) must drive the adjustment; with the raw (pre-overlay) value the
    taxable LTCG is HIGHER — the restatement moves the estimate toward the
    statutory value, never silently."""
    import tempfile

    from core.realized_gains_ledger import RealizedGainsLedger

    feed = json.loads(FEED.read_text(encoding="utf-8"))
    tk = "RELIANCE.NS"
    if tk not in feed:
        pytest.skip("RELIANCE not in this feed")
    entry_px, exit_px, shares = 500.0, 1500.0, 10.0

    def _ltcg_with(fmv):
        led = RealizedGainsLedger(storage_path=Path(tempfile.mkdtemp()) / "rg.json")
        led.record_realized_close({
            "id": "R28T", "ticker": tk, "entry_date": "2017-06-01",
            "exit_date": "2026-03-02", "entry_price": entry_px,
            "exit_price": exit_px, "shares": shares})
        n = led.net_gains_by_category("AY 2026-27", fmv_31jan2018={tk: float(fmv)})
        return n

    n_live = _ltcg_with(feed[tk])
    deemed = max(entry_px, min(float(feed[tk]), exit_px))
    assert n_live["grandfathering"]["applied_events"] == 1
    assert n_live["LTCG"] == pytest.approx((exit_px - deemed) * shares, abs=0.01)
    assert n_live["grandfathering"]["basis"].startswith("Sec 112A(2)")

    if RAW.exists():
        raw_feed = json.loads(RAW.read_text(encoding="utf-8"))
        if tk in raw_feed and float(raw_feed[tk]) > 0 \
                and float(raw_feed[tk]) != float(feed[tk]):
            n_raw = _ltcg_with(raw_feed[tk])
            # restated FMV >= raw vendor High here -> taxable LTCG does not
            # increase (the conservative direction is the RAW side)
            assert n_live["LTCG"] <= n_raw["LTCG"] + 1e-9


# ══════════════════════════════════════════════════════════════════════
# R28 wiring + build marker
# ══════════════════════════════════════════════════════════════════════

def test_r28_4_build_marker():
    """The build marker designates Round 28 while preserving the full
    lineage (R21/R25/R26/R27, SOVEREIGN-TIER-OMEGA, the 23.92 pin, the
    marginal-relief and replay_scope mentions) and names the FMV feed +
    restatement overlay."""
    app_src = APP.read_text(encoding="utf-8")
    m = re.search(r'APP_BUILD_ID\s*=\s*"([^"]+)"', app_src)
    assert m, "APP_BUILD_ID definition not found"
    build_id = m.group(1)
    assert re.search(r"QA-R(19|20)", build_id)
    for tag in ("R21", "R25", "R26", "R27", "R28"):
        assert tag in build_id, f"build id missing {tag}"
    assert "SOVEREIGN-TIER-OMEGA" in build_id
    assert "23.92" in build_id and "marginal relief" in build_id
    assert "replay_scope" in build_id
    assert "TAX_FMV_31JAN2018" in build_id and "restate" in build_id
