"""Round 29 regression locks — the INPUT-GATED closure round.

Locks:
  r29_1  the historical earnings-calendar builder (pure vectors + artifact
         contract + the real feed content + pattern locks on the builder)
  r29_2  the calendar auto-load loader + replay blackout filter + the sweep
         wiring (pattern locks, skip-if-absent contract)
  r29_3  the walk-forward ML retraining driver — POINT-IN-TIME immutability
         (the leakage lock), key conventions, DSR range, provenance fidelity
  r29_4  the extracted cutoff grid == the replay's actual folds; the
         key-convention fallback; the opt-in default
  r29_5  build-marker lineage
"""
from __future__ import annotations

import importlib.util
import json
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from math_engine.oos_walkforward import (  # noqa: E402
    walk_forward_reselection_backtest,
    reselect_cutoff_positions,
    load_blackout_calendar_file,
    _blackout_replay_filter,
)
from ml_alpha.walkforward_replay_scores import compute_ml_scores_by_cutoff  # noqa: E402

CAL_PATH = ROOT / "qa_db" / "earnings_calendar_history.json"
BUILDER_PATH = ROOT / "scripts" / "build_earnings_calendar.py"
OPT_SRC = (ROOT / "optimizer.py").read_text(encoding="utf-8")
OOS_SRC = (ROOT / "math_engine" / "oos_walkforward.py").read_text(encoding="utf-8")
APP_SRC = (ROOT / "web_dashboard" / "app.py").read_text(encoding="utf-8")


def _load_builder():
    spec = importlib.util.spec_from_file_location("build_earnings_calendar", BUILDER_PATH)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _strip(src: str) -> str:
    """Source with comments and docstrings removed (R22+ pattern-lock
    convention: AUDIT-FIX comments quote eliminated bug patterns)."""
    src = re.sub(r'"""[\s\S]*?"""', "", src)
    src = re.sub(r"'''[\s\S]*?'''", "", src)
    return "\n".join(ln for ln in src.splitlines()
                     if not ln.strip().startswith("#"))


def _make_frame(n_days=320, n_tickers=24, seed=29):
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range("2025-01-01", periods=n_days)
    tickers = [f"T{i:02d}.NS" for i in range(n_tickers)]
    rets = rng.normal(0.0002, 0.015, (n_days, n_tickers))
    close = pd.DataFrame(100 * np.exp(np.cumsum(rets, axis=0)),
                         index=dates, columns=tickers)
    volume = pd.DataFrame(rng.lognormal(11, 0.5, (n_days, n_tickers)).round(),
                          index=dates, columns=tickers)
    return close, volume


# ── r29_1: the builder ─────────────────────────────────────────────────────
def test_r29_1a_builder_pure_vectors():
    b = _load_builder()
    assert b.to_ist_date(pd.Timestamp("2026-01-16 08:00", tz="America/New_York")) == "2026-01-16"
    assert b.to_ist_date(pd.Timestamp("2026-01-16 22:00", tz="America/New_York")) == "2026-01-17"
    assert b.to_ist_date(pd.Timestamp("2026-01-16 20:00")) == "2026-01-17"  # naive = UTC
    idx = pd.DatetimeIndex([
        pd.Timestamp("2026-03-01 09:00", tz="America/New_York"),
        pd.Timestamp("2025-12-01 09:00", tz="America/New_York"),
        pd.Timestamp("2026-03-01 09:00", tz="America/New_York"),
    ])
    assert b.normalize_events(idx) == ["2025-12-01", "2026-03-01"]
    assert b.normalize_events(pd.DatetimeIndex([])) == []
    meta = b.build_meta(["A.NS", "B.NS", "C.NS"],
                        {"A.NS": ["2026-01-01"], "C.NS": []},
                        {"B.NS": "HTTPError"},
                        completed=True, budget_exhausted=False)
    # the honest-coverage split is exhaustive: events + failed + empty = requested
    assert meta["n_with_events"] + meta["n_failed"] + meta["n_empty"] == 3
    assert meta["failures_reported_never_invented"] is True
    assert meta["n_failed"] == 1 and meta["n_empty"] == 1


def test_r29_1b_real_calendar_artifact_contract():
    assert CAL_PATH.exists(), "the R29-1 calendar artifact must ship with the workspace"
    obj = json.loads(CAL_PATH.read_text(encoding="utf-8"))
    meta = obj["meta"]
    assert set(obj.keys()) == {"meta", "calendar", "failures"}
    assert meta["completed"] is True
    assert meta["n_requested"] == 792
    assert meta["coverage_pct"] >= 80.0, "calendar coverage regressed below the built level"
    assert meta["failures_reported_never_invented"] is True
    # spot content: the anchor name's cadence (quarterly, 25 vendor records)
    rel = obj["calendar"].get("RELIANCE.NS") or []
    assert len(rel) >= 20 and "2026-01-16" in rel
    # events are ISO dates, sorted, deduped
    assert rel == sorted(set(rel))
    # honest failure record (never a fabricated event for that name)
    assert isinstance(obj["failures"], dict) and obj["failures"]


def test_r29_1c_builder_pattern_locks():
    src = BUILDER_PATH.read_text(encoding="utf-8")
    assert "--selfcheck" in src
    assert "earnings_calendar_history.json" in src
    assert "failures_reported_never_invented" in src
    assert "TIME_BUDGET" in src and "COMPLETE" in src
    assert "--rebaseline" in src
    # the idempotency + atomic-promotion discipline (a partial run must never
    # clobber a completed artifact)
    assert "_final_artifact_complete" in _strip(src)
    assert "partial.json" in _strip(src)
    # never-invent: failures are recorded, not guessed
    assert "raise RuntimeError(str(last_err))" in _strip(src)


# ── r29_2: the loader + blackout replay + sweep wiring ─────────────────────
def test_r29_2a_loader_contract():
    cal = load_blackout_calendar_file()
    assert isinstance(cal, dict) and cal, "real calendar must load"
    # symbols restriction
    sub = load_blackout_calendar_file(symbols=["RELIANCE.NS", "NOPE.NS"])
    assert set(sub.keys()) == {"RELIANCE.NS"}
    # skip-if-absent / corrupt -> None, never raises
    assert load_blackout_calendar_file(path=ROOT / "qa_db" / "no_such_file.json") is None
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        bad = Path(td) / "bad.json"
        bad.write_text("{not json", encoding="utf-8")
        assert load_blackout_calendar_file(path=bad) is None


def test_r29_2b_blackout_filter_blocks_within_window():
    candidates = ["A.NS", "B.NS"]
    cal = {"A.NS": ["2025-06-10"]}
    cutoff = pd.Timestamp("2025-06-12")
    kept, blocked = _blackout_replay_filter(candidates, cutoff, cal, 5)
    assert blocked == ["A.NS"] and kept == ["B.NS"]
    # outside the window -> kept
    kept2, blocked2 = _blackout_replay_filter(candidates, pd.Timestamp("2025-07-01"), cal, 5)
    assert blocked2 == [] and kept2 == candidates


def test_r29_2c_sweep_wiring_patterns():
    opt = _strip(OPT_SRC)
    # the auto-load + coverage disclosure + skip-if-absent
    assert "load_blackout_calendar_file(symbols=" in opt
    assert "_blackouts_by_symbol = load_blackout_calendar_file" in opt
    assert "Blackout calendar auto-loaded" in OPT_SRC
    assert "Blackout calendar absent/empty" in OPT_SRC
    # the replay call now carries the calendar
    assert "blackouts_by_symbol=_blackouts_by_symbol" in opt
    # payload disclosure keys
    assert '"blackout_calendar"' in opt
    assert '"ml_replay_provenance"' in opt


def test_r29_2d_calendar_feeds_the_replay_end_to_end():
    close, volume = _make_frame()
    cal = {close.columns[0]: [str(close.index[180].date())]}
    res = walk_forward_reselection_backtest(
        close, volume, n_folds=2, score_lookback=63, k_stocks=3,
        mode="balanced", blackouts_by_symbol=cal, blackout_window_days=5)
    st = res["replay_scope"]["blackouts"]
    assert st["replayed"] is True and "name-blocks applied" in st["source"]


# ── r29_3: the walk-forward ML retraining driver ───────────────────────────
def test_r29_3a_point_in_time_immutability():
    close, volume = _make_frame()
    cutoff = close.index[250]
    a1, d1, p1 = compute_ml_scores_by_cutoff(close, volume, [cutoff], cfg={})
    k = str(cutoff.date())
    assert k in a1 and a1[k], "cutoff must be scored on the clean run"
    # clobber EVERYTHING after the cutoff — scores must be bit-identical
    clobbered = close.copy()
    pos = clobbered.index.get_loc(cutoff)
    clobbered.iloc[pos + 1:] = clobbered.iloc[pos + 1:] * 7.0 + 555.0
    vol2 = volume.copy()
    vol2.iloc[pos + 1:] = vol2.iloc[pos + 1:] * 31.0
    a2, d2, _ = compute_ml_scores_by_cutoff(clobbered, vol2, [cutoff], cfg={})
    assert k in a2
    common = sorted(set(a1[k]) & set(a2[k]))
    assert common and all(a1[k][t] == a2[k][t] for t in common), \
        "LEAKAGE: post-cutoff data changed the cutoff's point-in-time scores"


def test_r29_3b_key_conventions_and_dsr_range():
    close, volume = _make_frame()
    cutoff = close.index[250]
    a, d, prov = compute_ml_scores_by_cutoff(close, volume, [cutoff], cfg={})
    k_date = str(cutoff.date())
    k_ts = str(cutoff)
    assert k_date in a and k_ts in a, "driver must emit both key conventions"
    assert a[k_date] == a[k_ts]
    v = d[k_date]
    assert v is None or (0.0 <= v <= 1.0), "DSR is a probability in [0,1] or None"
    # provenance: the fidelity disclosure must name the non-replayed layers
    note = prov["fidelity_note"]
    for token in ("alt-data", "Optuna", "CPCV", "point-in-time"):
        assert token in note
    assert prov["purge_rule"] == "s + forward_days + embargo_days <= cutoff"


def test_r29_3c_dsr_none_refuses_injection():
    from math_engine.oos_walkforward import _ml_replay_weight
    assert _ml_replay_weight({}, None) == 0.0
    close, volume = _make_frame()
    cutoff = close.index[250]
    a, d, _ = compute_ml_scores_by_cutoff(close, volume, [cutoff], cfg={})
    if d[str(cutoff.date())] is None:
        # honest-None path: scores without DSR must REFUSE the injection
        res = walk_forward_reselection_backtest(
            close, volume, n_folds=2, score_lookback=63, k_stocks=3,
            mode="balanced", ml_alpha_by_cutoff=a)
        assert res["replay_scope"]["ml_alpha"]["replayed"] is False


# ── r29_4: cutoff-grid identity + key fallback + opt-in default ────────────
def test_r29_4a_helper_matches_replay_folds():
    close, volume = _make_frame()
    res = walk_forward_reselection_backtest(
        close, volume, n_folds=4, score_lookback=126, k_stocks=5,
        mode="balanced")
    fold_dates = [f["cutoff_date"] for f in res["folds"]]
    pos = reselect_cutoff_positions(len(close.index), 126, 4)
    helper_dates = [str(close.index[p]) for p in pos]
    assert fold_dates == helper_dates, "cutoff grid drifted from the replay's folds"


def test_r29_4b_date_only_key_fallback():
    close, volume = _make_frame()
    base = walk_forward_reselection_backtest(
        close, volume, n_folds=2, score_lookback=63, k_stocks=3, mode="balanced")
    key = base["folds"][0]["cutoff_date"]          # str(Timestamp) form
    ts = pd.Timestamp(key)
    date_only = str(ts.date())                     # the R29-3 driver form
    top = base["folds"][0]["basket"][0]
    scores = {date_only: {top: -5.0, "T00.NS": 5.0}}   # keyed date-only
    res = walk_forward_reselection_backtest(
        close, volume, n_folds=2, score_lookback=63, k_stocks=3,
        mode="balanced", ml_alpha_by_cutoff=scores,
        ml_dsr_by_cutoff={date_only: 0.5})
    assert res["folds"][0]["ml_alpha_weight"] == pytest.approx(0.30 * (0.4 / 0.9), abs=1e-3)
    assert res["replay_scope"]["ml_alpha"]["replayed"] is True
    assert key != date_only  # the two conventions really are distinct strings


def test_r29_4c_ml_retrain_opt_in_default_off():
    opt = _strip(OPT_SRC)
    assert 'working_cfg.get("WFO_ML_REPLAY_RETRAIN", False)' in opt, \
        "the ML retraining path must stay opt-in (default False)"
    assert "ml_alpha_by_cutoff=_ml_alpha_by_cutoff" in opt
    assert "ml_dsr_by_cutoff=_ml_dsr_by_cutoff" in opt
    assert "reselect_cutoff_positions" in opt
    # the oos_walkforward lookup accepts both key conventions
    oos = _strip(OOS_SRC)
    assert "ml_alpha_by_cutoff.get(_ml_key)" in oos
    assert "str(pd.Timestamp(cutoff_date).date())" in oos


# ── r29_5: build-marker lineage ────────────────────────────────────────────
def test_r29_5_build_marker_lineage():
    m = re.search(r'APP_BUILD_ID\s*=\s*"([^"]+)"', APP_SRC)
    assert m, "APP_BUILD_ID missing"
    bid = m.group(1)
    for rnd in ("R20", "R21", "R22", "R23", "R24", "R25", "R26", "R27", "R28", "R29"):
        assert f"-{rnd}-" in f"-{bid}-" or rnd in bid, f"build marker lost {rnd}"
    assert "SOVEREIGN-TIER-OMEGA" in bid
