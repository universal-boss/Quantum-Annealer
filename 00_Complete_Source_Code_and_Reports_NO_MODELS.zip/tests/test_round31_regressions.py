"""Round 31 regression locks — the FMV-(a) residual CLOSED: the NSE
31-Jan-2018 exchange record DELIVERED and the record rebase EXECUTED.

R31 story: every direct egress route to the NSE/BSE archives has been
measured blocked from this environment since R23 (NSE 403/429; Wayback,
archive.org, sajagonline TCP-timeout; third-party mirrors PDF-only).
This round the record was finally DELIVERED via a relay: r.jina.ai
server-side PDF text extraction of the sajag secondary capture of the FULL
13-column NSE closing-rate bhavcopy for 31-Jan-2018 (1,870 rows: 1,717
equity + 153 debt/WDM; ISIN block zipped 1:1 with the OHLC block and
verified by the avg-price-inside-OHLC-band check on every row).

The promotion protocol then ran end-to-end:
  * every feed ticker joined to the record (direct / ISIN / symbol-change /
    4 manually-verified renames: PCBL<-PHILIPCARB, ORCHPHARMA<-ORCHIDPHAR,
    TECHNOE<-TECHNO, DOLPHIN<-DOLPHINOFF);
  * the vendor divisor measured across THREE independent fields (record
    High/vendor High, record Close/vendor Close, record PrevClose/vendor
    30-Jan Close — fresh live Yahoo re-fetch, 564/564, 0 consistency
    mismatches vs the R28 raw pull);
  * 559/564 tickers UNIFORM (spread <= 0.6%) -> rebased to the record High
    (the statutory Sec 112A(2) 'highest price'); the divisor is disclosed
    whatever its form (clean 2.0/4.0/10.0/0.125 or compound like RELIANCE's
    2.18739 = 2023 Jio demerger x 2024 1:1 bonus);
  * 5 tickers keep the raw vendor High (disclosed): TATASTEEL + FCL
    (non-uniform), PATANJALI (ex-Ruchi Soya, suspended in 2018), POCL,
    SPLPETRO (record-uncovered);
  * two R28 anchor verdicts CORRECTED by the record: RELIANCE (x2.0 was
    wrong; record High 964.50) and HDFCBANK (x2.0 was wrong — BOTH the
    2019 split and the 2025 bonus were back-applied; record High 2013.50);
  * the 228 missing tickers independently CONFIRMED absent from the record
    (0 ISIN hits; fuzzy candidates rejected) = post-2018 IPOs / BSE-only
    listings / suspended names — the R28 steady-state classification
    survives an independent test.
"""

import importlib.util
import json
import re
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "web_dashboard" / "app.py"
RESTATE_SCRIPT = ROOT / "scripts" / "restate_fmv_feed.py"
FEED = ROOT / "qa_db" / "tax_fmv_31jan2018.json"
META = ROOT / "qa_db" / "tax_fmv_31jan2018.meta.json"
RAW = ROOT / "qa_db" / "tax_fmv_31jan2018.raw.json"
RECORD = ROOT / "qa_db" / "tax_fmv_31jan2018.record.json"
RECORD_OVERLAY = ROOT / "qa_db" / "tax_fmv_31jan2018.record_overlay.json"

HAVE_LIVE = FEED.exists() and RECORD.exists() and RECORD_OVERLAY.exists()


def _load_restate_module():
    spec = importlib.util.spec_from_file_location("restate_fmv_feed", RESTATE_SCRIPT)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


# ══════════════════════════════════════════════════════════════════════
# R31-1 — the delivered record: integrity + provenance
# ══════════════════════════════════════════════════════════════════════

@pytest.mark.skipif(not RECORD.exists(), reason="record not delivered in this checkout")
def test_r31_1a_record_integrity():
    rec = json.loads(RECORD.read_text(encoding="utf-8"))
    rows = rec["equity_rows"]
    assert rec["valuation_date"] == "2018-01-31"
    assert "sajagonline" in rec["source"]
    assert "r.jina.ai" in rec["delivery"]
    assert len(rows) == 1717
    stats = rec["stats"]
    assert stats["alignment_violations"] == 0
    assert stats["anomalies"] == 0
    assert stats["series_counts"] == {"EQ": 1370, "BE": 253, "SM": 78, "BZ": 16}
    assert stats["debt_wdm_rows"] == 153
    isin_re = re.compile(r"^IN[A-Z0-9]{10}$")  # Indian ISIN: INE equity / INF funds / IN9 special
    for r in rows:
        assert isinstance(r["high"], (int, float)) and r["high"] > 0
        assert r["low"] <= r["high"]
        assert r["low"] - 1e-9 <= r["close"] <= r["high"] + 1e-9
        assert isin_re.match(r["isin"] or ""), f"bad ISIN {r['symbol']}: {r['isin']}"


# ══════════════════════════════════════════════════════════════════════
# R31-2 — the record overlay: the deterministic decision table
# ══════════════════════════════════════════════════════════════════════

@pytest.mark.skipif(not RECORD_OVERLAY.exists(), reason="overlay not built")
def test_r31_2a_overlay_contract():
    doc = json.loads(RECORD_OVERLAY.read_text(encoding="utf-8"))
    ov = doc["overlay"]
    assert doc["valuation_date"] == "2018-01-31"
    assert doc["rebased_tickers"] == 559
    assert len(ov) == 559
    for tk, e in ov.items():
        assert e["fmv"] > 0, f"non-positive fmv {tk}"
        d = e.get("divisor")
        assert d is None or d > 0, f"non-positive divisor {tk}"
        assert e.get("join"), f"missing join provenance {tk}"
    kr = doc["keep_raw_disclosed"]
    assert set(kr) == {"TATASTEEL.NS", "FCL.NS", "PATANJALI.NS",
                       "POCL.NS", "SPLPETRO.NS"}
    assert all("reason" in v and v["raw"] > 0 for v in kr.values())
    # the two corrected anchors are documented
    for tk in ("RELIANCE.NS", "HDFCBANK.NS"):
        note = doc["anchor_corrections"][tk]
        assert "WRONG" in note and "record High" in note


@pytest.mark.skipif(not RECORD_OVERLAY.exists(), reason="overlay not built")
def test_r31_2b_overlay_anchor_vectors():
    doc = json.loads(RECORD_OVERLAY.read_text(encoding="utf-8"))
    ov = doc["overlay"]
    # record-verified exact vectors (measured this round)
    assert ov["RELIANCE.NS"]["fmv"] == 964.5
    assert ov["RELIANCE.NS"]["divisor"] == pytest.approx(2.18739, abs=1e-3)
    assert ov["HDFCBANK.NS"]["fmv"] == 2013.5
    assert ov["HDFCBANK.NS"]["divisor"] == pytest.approx(3.9998, abs=1e-3)
    assert ov["TCS.NS"]["fmv"] == 3150.0
    assert ov["TCS.NS"]["divisor"] == 2.0
    assert ov["ITC.NS"]["fmv"] == 276.0
    # manual renames with exact reconciliation
    assert ov["PCBL.NS"]["fmv"] == 1295.0 and ov["PCBL.NS"]["divisor"] == 10.0
    assert ov["PCBL.NS"]["record_symbol"] == "PHILIPCARB"
    assert ov["DOLPHIN.NS"]["fmv"] == 121.3 and ov["DOLPHIN.NS"]["divisor"] == 0.125
    assert ov["DOLPHIN.NS"]["record_symbol"] == "DOLPHINOFF"
    assert ov["ORCHPHARMA.NS"]["record_symbol"] == "ORCHIDPHAR"
    assert ov["TECHNOE.NS"]["record_symbol"] == "TECHNO"
    # exotic-but-uniform divisors measured against the record
    assert ov["IEX.NS"]["fmv"] == 1610.0 and ov["IEX.NS"]["divisor"] == 30.0
    assert ov["BSE.NS"]["fmv"] == 902.6 and ov["BSE.NS"]["divisor"] == 9.0
    assert ov["CUPID.NS"]["fmv"] == 357.9


# ══════════════════════════════════════════════════════════════════════
# R31-3 — pure semantics: precedence + discipline (record overlay layer)
# ══════════════════════════════════════════════════════════════════════

def test_r31_3a_record_overlay_precedence():
    """record overlay > legacy verified factor > raw; candidate factors stay
    disclosed-not-applied; non-positive rows untouched."""
    mod = _load_restate_module()
    final, meta = mod.apply_restatement(
        {"HDFCBANK.NS": 503.38, "AAA.NS": 100.0, "BBB.NS": 100.0, "CCC.NS": -1.0},
        verified={"HDFCBANK.NS": {"factor": 2.0, "provenance": "x"},
                  "AAA.NS": {"factor": 2.0, "provenance": "x"}},
        sweep={"BBB.NS": {"post_valuation_events": [], "candidate_factor": 5.0}},
        record_overlay={"HDFCBANK.NS": {"fmv": 2013.5, "divisor": 3.9998,
                                        "record_symbol": "HDFCBANK",
                                        "reason": "uniform"}})
    assert final["HDFCBANK.NS"] == 2013.5  # record beats the legacy x2
    assert meta["HDFCBANK.NS"]["record_rebased"] is True
    assert meta["HDFCBANK.NS"]["factor"] == pytest.approx(3.9998)
    assert final["AAA.NS"] == 200.0        # uncovered -> legacy layer applies
    assert final["BBB.NS"] == 100.0        # candidate disclosed, NOT applied
    assert meta["BBB.NS"]["candidate_evidence"]["candidate_factor"] == 5.0
    assert final["CCC.NS"] == -1.0         # guard


def test_r31_3b_idempotent_from_raw():
    mod = _load_restate_module()
    ov = json.loads(RECORD_OVERLAY.read_text(encoding="utf-8"))["overlay"] \
        if RECORD_OVERLAY.exists() else None
    raw = {"X.NS": 100.0}
    f1, _ = mod.apply_restatement(raw, record_overlay={"X.NS": {"fmv": 123.45}})
    f2, _ = mod.apply_restatement(raw, record_overlay={"X.NS": {"fmv": 123.45}})
    assert f1 == f2 and f1["X.NS"] == 123.45


def test_r31_3c_overlay_pattern_locks():
    src = RESTATE_SCRIPT.read_text(encoding="utf-8")
    for needle in ("RECORD_OVERLAY", "record_rebased", "uniformity_spread_pct",
                   "record_symbol", "qa_db/tax_fmv_31jan2018.record.json",
                   "r.jina.ai", "2.18739", "anchor_corrections"):
        assert needle in src, f"restate script missing: {needle}"


# ══════════════════════════════════════════════════════════════════════
# R31-4 — the LIVE feed file: rebased values + conservative keep-raws
# ══════════════════════════════════════════════════════════════════════

@pytest.mark.skipif(not HAVE_LIVE, reason="live feed/record not present")
def test_r31_4a_live_feed_rebased_values():
    feed = json.loads(FEED.read_text(encoding="utf-8"))
    raw = json.loads(RAW.read_text(encoding="utf-8"))
    assert set(feed) == set(raw) | {"CARYSIL.NS"}  # [R32 SUPERSESSION —
    # intent preserved, reference updated] the original lock pinned
    # set(feed) == set(raw) (564 keys, nothing added or dropped). R32
    # delivered the BSE 31-Jan-2018 record and promoted the one feed-missing
    # BSE-only ticker it covers (CARYSIL.NS, gated by
    # scripts/restate_fmv_feed.py BSE_PROMOTIONS_VERIFIED against the
    # record file): the feed is raw + exactly the gated promotion, never
    # anything else added or dropped.
    for tk, v in feed.items():
        assert isinstance(v, (int, float)) and v > 0
    # corrected anchors
    assert feed["RELIANCE.NS"] == 964.5
    assert feed["HDFCBANK.NS"] == 2013.5
    # record-confirmed anchors
    assert feed["TCS.NS"] == 3150.0
    assert feed["INFY.NS"] == 1166.6
    assert feed["BPCL.NS"] == 493.6
    assert feed["TORNTPHARM.NS"] == 1369.95
    assert feed["HCLTECH.NS"] == 1017.9
    assert feed["ITC.NS"] == 276.0
    # manual-rename promotions
    assert feed["PCBL.NS"] == 1295.0
    assert feed["DOLPHIN.NS"] == 121.3
    # conservative keep-raws (disclosed, unchanged)
    assert feed["TATASTEEL.NS"] == raw["TATASTEEL.NS"]
    assert feed["FCL.NS"] == raw["FCL.NS"]
    assert feed["PATANJALI.NS"] == raw["PATANJALI.NS"]
    assert feed["POCL.NS"] == raw["POCL.NS"]
    assert feed["SPLPETRO.NS"] == raw["SPLPETRO.NS"]
    # [R32 SUPERSESSION — intent preserved, reference updated] the original
    # lock pinned missing == 228 (independently confirmed absent from the
    # NSE record). R32 promoted CARYSIL.NS from the delivered BSE record
    # (finlib capture) -> 227. POWERINDIA.NS stays missing but is
    # RECLASSIFIED: Hitachi Energy India (formerly ABB Power Products),
    # listed NSE+BSE on 2020-03-30 — a post-valuation-date listing; no
    # 31-Jan-2018 quotation can exist, so its absence is the correct steady
    # state (same class as the post-2018 IPOs), not a blocked BSE capture.
    meta = json.loads(META.read_text(encoding="utf-8"))
    assert len(meta["missing"]) == 227
    assert "CARYSIL.NS" not in meta["missing"]
    assert "POWERINDIA.NS" in meta["missing"]


@pytest.mark.skipif(not HAVE_LIVE, reason="live feed/record not present")
def test_r31_4b_meta_audit_blocks():
    meta = json.loads(META.read_text(encoding="utf-8"))
    rs = meta["restatement"]
    assert rs["verified_tickers"] >= 559
    assert "conservative" in rs["discipline"]
    assert "EXECUTED" in rs["promotion_path"]
    rr = meta["record_restatement"]
    assert rr["rebased_tickers"] == 559
    assert rr["record_file"] == "qa_db/tax_fmv_31jan2018.record.json"
    assert "RELIANCE.NS" in rr["anchor_corrections"]
    assert "HDFCBANK.NS" in rr["anchor_corrections"]
    assert rr["keep_raw_disclosed"]
    n_rebased_meta = sum(1 for v in meta["resolved"].values()
                         if v.get("record_rebased"))
    assert n_rebased_meta == 559
    # candidates still disclosed (the 185-candidate worklist question is
    # resolved by measurement but the disclosure trail stays)
    n_cand = sum(1 for v in meta["resolved"].values()
                 if (v.get("candidate_evidence") or {}).get("candidate_factor"))
    assert n_cand == 185


# ══════════════════════════════════════════════════════════════════════
# R31-5 — activation direction: the corrections move the estimate toward
# the statutory value (never silently, never in the forbidden direction)
# ══════════════════════════════════════════════════════════════════════

@pytest.mark.skipif(not HAVE_LIVE, reason="live feed/record not present")
def test_r31_5_grandfathering_direction_after_correction():
    import tempfile

    from core.realized_gains_ledger import RealizedGainsLedger

    feed = json.loads(FEED.read_text(encoding="utf-8"))
    raw = json.loads(RAW.read_text(encoding="utf-8"))
    tk = "HDFCBANK.NS"
    entry_px, exit_px, shares = 500.0, 2500.0, 10.0

    def _ltcg_with(fmv):
        led = RealizedGainsLedger(storage_path=Path(tempfile.mkdtemp()) / "rg.json")
        led.record_realized_close({
            "id": "R31T", "ticker": tk, "entry_date": "2017-06-01",
            "exit_date": "2026-03-02", "entry_price": entry_px,
            "exit_price": exit_px, "shares": shares})
        return led.net_gains_by_category("AY 2026-27",
                                         fmv_31jan2018={tk: float(fmv)})

    n_live = _ltcg_with(feed[tk])          # record-rebased 2013.50
    n_raw = _ltcg_with(raw[tk])            # raw vendor 503.38
    n_r28 = _ltcg_with(1006.76)            # the WRONG R28 x2 verdict
    # the correction moves deemed cost UP toward the statutory value:
    # LTCG(record) <= LTCG(R28 verdict) <= LTCG(raw)
    assert n_live["LTCG"] == pytest.approx((exit_px - feed[tk]) * shares, abs=0.01)
    assert n_live["LTCG"] <= n_r28["LTCG"] + 1e-9
    assert n_r28["LTCG"] <= n_raw["LTCG"] + 1e-9
    assert n_live["grandfathering"]["applied_events"] == 1


# ══════════════════════════════════════════════════════════════════════
# R31-6 — build marker lineage
# ══════════════════════════════════════════════════════════════════════

def test_r31_6_build_marker():
    app_src = APP.read_text(encoding="utf-8")
    m = re.search(r'APP_BUILD_ID\s*=\s*"([^"]+)"', app_src)
    assert m, "APP_BUILD_ID definition not found"
    build_id = m.group(1)
    for tag in ("R21", "R25", "R26", "R27", "R28", "R29", "R31"):
        assert tag in build_id, f"build id missing {tag}"
    assert "SOVEREIGN-TIER-OMEGA" in build_id
    assert "TAX_FMV_31JAN2018" in build_id and "restate" in build_id
    assert "record rebase" in build_id or "RECORD REBASE" in build_id
    assert "r.jina.ai" in build_id
