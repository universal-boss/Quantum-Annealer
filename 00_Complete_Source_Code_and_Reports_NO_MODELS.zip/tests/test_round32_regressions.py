"""Round 32 regression locks — the BSE-only-listing sub-path CLOSED: the BSE
31-Jan-2018 record DELIVERED, the CARYSIL.NS promotion EXECUTED, and
POWERINDIA.NS reclassified as a post-valuation-date listing.

R32 story: the only disclosed sub-path left after R31 was the BSE-only
listings (CARYSIL, POWERINDIA) — 'would close only with a BSE 31-Jan-2018
record (still egress-blocked; the same relay trick would work if a BSE
capture were located)'. This round the record was located and delivered:

  * finlib.in 'Fair Market Value of stocks on 31 Jan 2018 for LTCG'
    (https://finlib.in/fair-market-value-31-jan-2018/) — a server-rendered,
    ISIN-tagged WordPress table (DIRECT fetch — no relay needed) with BOTH
    exchange Highs plus the published FMV = max(available Highs):
    3,527 rows (1,826 BSE-only / 1,550 dual / 151 NSE-only; 471 rows carry
    an earlier applicable date — suspended names, disclosed).
  * VALIDATION (why the BSE column is trustworthy): the NSE-High column was
    joined to the R31 sajag NSE exchange record by ISIN/symbol — 1,657/1,657
    rows EXACT (100.00%): two INDEPENDENT captures of the NSE bhavcopy
    agree perfectly. All 3,527 ISIN check-digits valid; FMV == max(highs)
    on 3,527/3,527 rows; scribd 433201744 ('Share Prices and FMV on Jan 31,
    2018') independently corroborates the target row: 'ACRYCIL LTD.
    31/1/2018 BSE 575.95'.
  * PROMOTION: CARYSIL.NS (BSE-only on 31-Jan-2018, ISIN INE482D01016 — the
    2018 pre-split security) added to the feed at the BSE record High
    575.95 = the statutory Sec 112A(2) 'highest price'. Vendor CARYSIL.BO
    bars are back-adjusted: 575.95 / 115.19 = 4.9996 ~= the 1:5 Rs10->Rs2
    sub-division (record date 09-Jan-2019, ex 10-Jan-2019 — the event that
    also allotted the current ISIN INE482D01024); divisor disclosed, record
    value adopted. The promotion is gated fail-closed: the registry names
    the mapping, the FILE supplies the value, any disagreement -> no
    promotion (never invented, never overridden).
  * RECLASSIFICATION: POWERINDIA.NS = Hitachi Energy India Ltd (formerly
    ABB Power Products and Systems India Ltd), listed on NSE+BSE on
    30-Mar-2020 (first vendor bar 2020-03-30) — a POST-valuation-date
    listing, dual-listed: no 31-Jan-2018 quotation can exist. Its feed
    absence is the correct steady state (same class as the post-2018 IPOs),
    NOT a blocked BSE capture — the R28/R31 'BSE-only listing' class was
    imprecise and is corrected.
  * NET: missing 228 -> 227; feed 564 -> 565 keys; all 559 R31 record
    rebases and the 185-candidate disclosure trail intact.
"""

import importlib.util
import json
import re
import subprocess
import sys
import tempfile
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "web_dashboard" / "app.py"
RESTATE_SCRIPT = ROOT / "scripts" / "restate_fmv_feed.py"
FEED = ROOT / "qa_db" / "tax_fmv_31jan2018.json"
META = ROOT / "qa_db" / "tax_fmv_31jan2018.meta.json"
RAW = ROOT / "qa_db" / "tax_fmv_31jan2018.raw.json"
RECORD = ROOT / "qa_db" / "tax_fmv_31jan2018.record.json"
RECORD_BSE = ROOT / "qa_db" / "tax_fmv_31jan2018.record_bse.json"
HAVE_LIVE = FEED.exists() and RECORD.exists() and RECORD_BSE.exists()


def _load_restate_module():
    spec = importlib.util.spec_from_file_location("restate_fmv_feed", RESTATE_SCRIPT)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _code_only(p: Path) -> str:
    src = p.read_text(encoding="utf-8")
    src = re.sub(r'"""[\s\S]*?"""', "", src)
    src = re.sub(r"#[^\n]*", "", src)
    return src


# ══════════════════════════════════════════════════════════════════════
# R32-1 — the delivered BSE record: integrity, provenance, gates
# ══════════════════════════════════════════════════════════════════════

@pytest.mark.skipif(not RECORD_BSE.exists(), reason="BSE record not delivered")
def test_r32_1a_record_bse_integrity_and_gates():
    doc = json.loads(RECORD_BSE.read_text(encoding="utf-8"))
    assert doc["valuation_date"] == "2018-01-31"
    assert "finlib" in doc["source"].lower()
    assert "fair-market-value-31-jan-2018" in doc["source"]
    assert "scribd" in doc.get("secondary_corroboration", "").lower()
    assert "direct https fetch" in doc.get("delivery", "").lower()
    stats = doc["stats"]
    assert stats["rows"] == 3527
    assert stats["bse_only_rows"] == 1826
    assert stats["dual_rows"] == 1550
    assert stats["nse_only_rows"] == 151
    assert stats["non_31jan_rows"] == 471
    gates = doc["validation"]["gates"]
    assert gates["passed"] is True
    # G1: two independent captures of the NSE bhavcopy agree EXACTLY
    assert gates["G1_joined"] == 1657 and gates["G1_exact"] == 1657
    assert gates["G1_mismatch"] == 0
    assert gates["G1_nse_vs_record_exact_rate"] == 1.0
    # G2: the published FMV is max(available Highs) everywhere
    assert gates["G2_fmv_is_max_ok"] == 3527 and gates["G2_fmv_is_max_bad"] == 0
    # G4: every ISIN passes the ISO 6166 check-digit
    assert gates["G4_isin_valid"] == 3527 and gates["G4_rows"] == 3527
    # G5: POWERINDIA / Hitachi absent (listed 2020 — nothing to record)
    assert gates["G5_powerindia_rows"] == 0


@pytest.mark.skipif(not RECORD_BSE.exists(), reason="BSE record not delivered")
def test_r32_1b_the_acrycil_row():
    doc = json.loads(RECORD_BSE.read_text(encoding="utf-8"))
    rows = [r for r in doc["rows"]
            if r.get("isin") == "INE482D01016"]
    assert len(rows) == 1
    r = rows[0]
    assert r["bse_name"] == "ACRYCIL LTD."
    assert r["nse_symbol"] is None            # BSE-only on the valuation date
    assert r["date"] == "31/01/18"
    assert r["bse_high"] == 575.95
    assert r["fmv"] == 575.95                 # scribd 433201744 corroborates


@pytest.mark.skipif(not RECORD_BSE.exists() or not RECORD.exists(),
                    reason="records not delivered")
def test_r32_1c_two_capture_agreement_recomputed():
    """Re-join the finlib NSE-High column to the R31 sajag NSE record
    IN-TEST: 1,657/1,657 exact, zero mismatches (the two independent
    captures agreeing is exactly what makes the BSE column authoritative),
    plus pinned per-name vectors."""
    bse = json.loads(RECORD_BSE.read_text(encoding="utf-8"))
    nse = json.loads(RECORD.read_text(encoding="utf-8"))
    by_isin = {r["isin"]: r for r in nse["equity_rows"] if r.get("isin")}
    by_sym = {r["symbol"]: r for r in nse["equity_rows"]}
    joined = exact = 0
    for r in bse["rows"]:
        if r["nse_symbol"] and r["nse_high"] is not None and r["date"] == "31/01/18":
            rr = by_isin.get(r["isin"]) or by_sym.get(r["nse_symbol"])
            if rr:
                joined += 1
                if abs((rr["high"] or 0) - r["nse_high"]) < 0.005:
                    exact += 1
    assert (joined, exact) == (1657, 1657)
    # pinned vectors (measured this round, both captures)
    pinned = {"20MICRONS": 53.1, "3MINDIA": 18875.0, "8KMILES": 753.0,
              "5PAISA": 305.0, "TATASTEEL": 747.9}
    for sym, want in pinned.items():
        rr = by_sym[sym]
        got = next((r["nse_high"] for r in bse["rows"]
                    if r.get("nse_symbol") == sym and r["date"] == "31/01/18"),
                   None)
        assert got == pytest.approx(want), f"{sym}: finlib {got} vs pinned {want}"
        assert rr["high"] == pytest.approx(want), f"{sym}: record {rr['high']}"
    # keep-raw cross-check: the R31 conservative keep-raws are confirmed by
    # the third capture where it covers them (PATANJALI/POCL/SPLPETRO
    # remain uncovered — their keep-raw classification stands)
    krc = bse["keepraw_crosscheck"]
    assert len(krc["TATASTEEL"]) == 1 and krc["TATASTEEL"][0]["fmv"] == 747.9
    assert len(krc["FCL"]) == 1 and krc["FCL"][0]["fmv"] == 68.9
    for absent in ("PATANJALI", "POCL", "SPLPETRO"):
        assert krc[absent] == [], f"{absent} unexpectedly present"


# ══════════════════════════════════════════════════════════════════════
# R32-2 — the LIVE feed + meta: the promotion executed, nothing else moved
# ══════════════════════════════════════════════════════════════════════

@pytest.mark.skipif(not HAVE_LIVE, reason="live feed/records not present")
def test_r32_2a_live_feed_promotion():
    feed = json.loads(FEED.read_text(encoding="utf-8"))
    raw = json.loads(RAW.read_text(encoding="utf-8"))
    assert "CARYSIL.NS" not in raw                    # promotion-from-missing
    assert feed["CARYSIL.NS"] == 575.95
    assert set(feed) == set(raw) | {"CARYSIL.NS"}     # exactly one addition
    # every R31 rebased value is untouched by the R32 layer
    for tk, v in {"RELIANCE.NS": 964.5, "HDFCBANK.NS": 2013.5, "TCS.NS": 3150.0,
                  "ITC.NS": 276.0, "PCBL.NS": 1295.0}.items():
        assert feed[tk] == v
    for tk in ("TATASTEEL.NS", "FCL.NS", "PATANJALI.NS", "POCL.NS",
               "SPLPETRO.NS"):
        assert feed[tk] == raw[tk]                    # keep-raws unchanged


@pytest.mark.skipif(not HAVE_LIVE, reason="live feed/records not present")
def test_r32_2b_meta_audit_blocks():
    meta = json.loads(META.read_text(encoding="utf-8"))
    r = meta["resolved"]["CARYSIL.NS"]
    assert r["bse_record_promoted"] is True
    assert r["record_isin"] == "INE482D01016"
    assert r["bse_name"] == "ACRYCIL LTD."
    assert r["record_date"] == "2018-01-31"
    assert r["fmv"] == 575.95 and r["raw"] is None
    assert "qa_db/tax_fmv_31jan2018.record_bse.json" in r["provenance"]
    assert len(meta["missing"]) == 227
    assert "CARYSIL.NS" not in meta["missing"]
    assert meta["missing_before_r32"] == 228
    assert meta["bse_record_promoted_removed_from_missing"] == ["CARYSIL.NS"]
    b = meta["bse_record_restatement"]
    assert b["promoted_tickers"] == ["CARYSIL.NS"]
    assert b["promoted"] == 1
    assert b["gates_audit"]["loaded"] is True
    assert b["gates_audit"]["gates"]["G1_nse_vs_record_exact_rate"] == 1.0
    assert "2020-03-30" in b["powerindia_reclassification"]
    # the R31 numbers ride along intact
    assert meta["record_restatement"]["rebased_tickers"] == 559
    assert sum(1 for v in meta["resolved"].values() if v.get("record_rebased")) == 559
    assert sum(1 for v in meta["resolved"].values()
               if (v.get("candidate_evidence") or {}).get("candidate_factor")) == 185
    # missing_notes carry the R32 resolution + reclassification
    assert "RESOLVED in R32" in meta["missing_notes"]["CARYSIL.NS"]
    assert "30-Mar-2020" in meta["missing_notes"]["POWERINDIA.NS"]
    assert "POST" in meta["missing_notes"]["POWERINDIA.NS"]
    # the R28-2a contract still holds: resolved keys == feed keys
    feed = json.loads(FEED.read_text(encoding="utf-8"))
    assert set(meta["resolved"]) == set(feed)


# ══════════════════════════════════════════════════════════════════════
# R32-3 — pure semantics + the fail-closed loader
# ══════════════════════════════════════════════════════════════════════

def test_r32_3a_promotion_semantics():
    """A gated promotion ADDS a feed-missing ticker at its record High;
    it never overrides a present ticker; it is deterministic."""
    mod = _load_restate_module()
    promo = {"CARYSIL.NS": {"fmv": 575.95, "record_isin": "INE482D01016",
                            "bse_name": "ACRYCIL LTD.",
                            "record_date": "2018-01-31",
                            "bse_high": 575.95, "note": "n"}}
    final, meta = mod.apply_restatement({"AAA.NS": 100.0}, bse_promotions=promo)
    assert final["CARYSIL.NS"] == 575.95
    assert final["AAA.NS"] == 100.0
    assert meta["CARYSIL.NS"]["bse_record_promoted"] is True
    assert meta["CARYSIL.NS"]["raw"] is None
    assert meta["CARYSIL.NS"]["record_isin"] == "INE482D01016"
    # never an override: the precedence chain governs present tickers
    final2, _ = mod.apply_restatement({"CARYSIL.NS": 111.22}, bse_promotions=promo)
    assert final2["CARYSIL.NS"] == 111.22
    # deterministic
    f1, _ = mod.apply_restatement({}, bse_promotions=promo)
    f2, _ = mod.apply_restatement({}, bse_promotions=promo)
    assert f1 == f2 and f1["CARYSIL.NS"] == 575.95


@pytest.mark.skipif(not RECORD_BSE.exists(), reason="BSE record not delivered")
def test_r32_3b_loader_fail_closed(tmp_path):
    """The loader is the safety gate: the registry names the mapping, the
    FILE supplies the value. Tamper with the file -> NO promotion."""
    mod = _load_restate_module()
    # 1. the pristine file loads exactly the one gated promotion
    promos, audit = mod._load_bse_promotions()
    assert promos.get("CARYSIL.NS", {}).get("fmv") == 575.95
    assert audit["loaded"] is True
    # 2. tamper the row's value -> row_mismatch -> fail closed
    doc = json.loads(RECORD_BSE.read_text(encoding="utf-8"))
    for r in doc["rows"]:
        if r["isin"] == "INE482D01016":
            r["fmv"] = 999.99
    p2 = tmp_path / "tampered_value.json"
    p2.write_text(json.dumps(doc))
    mod.BSE_RECORD = p2
    promos, audit = mod._load_bse_promotions()
    assert promos == {} and audit["loaded"] is False
    assert any(k.startswith("row_mismatch:") for k in audit["gates"])
    # 3. falsify the G1 validation gate -> fail closed
    doc = json.loads(RECORD_BSE.read_text(encoding="utf-8"))
    doc["validation"]["gates"]["G1_nse_vs_record_exact_rate"] = 0.5
    p3 = tmp_path / "tampered_gate.json"
    p3.write_text(json.dumps(doc))
    mod.BSE_RECORD = p3
    promos, audit = mod._load_bse_promotions()
    assert promos == {} and audit["loaded"] is False
    # 4. drop the row entirely -> row_missing -> fail closed
    doc = json.loads(RECORD_BSE.read_text(encoding="utf-8"))
    doc["rows"] = [r for r in doc["rows"] if r["isin"] != "INE482D01016"]
    p4 = tmp_path / "tampered_missing.json"
    p4.write_text(json.dumps(doc))
    mod.BSE_RECORD = p4
    promos, audit = mod._load_bse_promotions()
    assert promos == {} and audit["loaded"] is False
    assert any(k.startswith("row_missing:") for k in audit["gates"])


def test_r32_3c_pattern_locks():
    src = RESTATE_SCRIPT.read_text(encoding="utf-8")
    for needle in ("BSE_PROMOTIONS_VERIFIED", "INE482D01016", "INE482D01024",
                   "575.95", "115.19", "ACRYCIL LTD.",
                   "qa_db/tax_fmv_31jan2018.record_bse.json",
                   "30-Mar-2020", "finlib"):
        assert needle in src, f"restate script missing: {needle}"
    code = _code_only(RESTATE_SCRIPT)
    for needle in ("BSE_PROMOTIONS_VERIFIED", "_load_bse_promotions",
                   "bse_record_promoted", "bse_promotions"):
        assert needle in code, f"promotion layer not in code: {needle}"


def test_r32_3d_selfcheck_all_pass():
    """The pinned selfcheck (18 vectors incl. the R32 promotion semantics)
    runs green as a subprocess — hermetic, no network."""
    cp = subprocess.run([sys.executable, str(RESTATE_SCRIPT), "--selfcheck"],
                        capture_output=True, text=True, timeout=120,
                        cwd=str(ROOT))
    assert cp.returncode == 0, cp.stdout + cp.stderr
    assert "ALL PASS" in cp.stdout
    assert "bse-promoted missing added: 575.95" in cp.stdout
    assert "bse-promotion no-override: 111.22" in cp.stdout


# ══════════════════════════════════════════════════════════════════════
# R32-4 — divisor evidence + activation direction through the REAL ledger
# ══════════════════════════════════════════════════════════════════════

def test_r32_4a_vendor_divisor_evidence():
    """The vendor CARYSIL.BO series is a scaled version of the as-traded
    series: record 575.95 / vendor High 115.19 = 4.9996, uniform with the
    web-verified 1:5 Rs10->Rs2 sub-division (record date 09-Jan-2019) well
    inside the R31 uniformity threshold (0.6%) — the record value is the
    measurement; the divisor is the disclosed explanation."""
    mod = _load_restate_module()
    reg = mod.BSE_PROMOTIONS_VERIFIED["CARYSIL.NS"]
    divisor = 575.95 / 115.19
    assert abs(divisor - 5.0) / 5.0 < 0.006
    assert reg["current_isin"] == "INE482D01024"   # new ISIN at the split
    assert "1:5" in reg["note"] and "Rs10 -> Rs2" in reg["note"]


@pytest.mark.skipif(not HAVE_LIVE, reason="live feed/records not present")
def test_r32_4b_grandfathering_activation_direction():
    """The promoted FMV flows through the production Sec 112A(2) path: a
    pre-Feb-2018 CARYSIL lot gets deemed cost = max(actual, min(FMV, sale))
    = 575.95, lowering taxable LTCG vs the actual-cost basis (statutory
    direction — the grandfathering benefit is now measurable for the last
    BSE-only name)."""
    from core.realized_gains_ledger import RealizedGainsLedger

    feed = json.loads(FEED.read_text(encoding="utf-8"))
    tk, entry_px, exit_px, shares = "CARYSIL.NS", 400.0, 1000.0, 10.0

    def _ltcg_with(fmv):
        led = RealizedGainsLedger(storage_path=Path(tempfile.mkdtemp()) / "rg.json")
        led.record_realized_close({
            "id": "R32T", "ticker": tk, "entry_date": "2017-06-01",
            "exit_date": "2026-03-02", "entry_price": entry_px,
            "exit_price": exit_px, "shares": shares})
        return led.net_gains_by_category("AY 2026-27",
                                         fmv_31jan2018={tk: float(fmv)} if fmv else {})

    n_live = _ltcg_with(feed[tk])     # the promoted record value 575.95
    n_none = _ltcg_with(None)         # no feed -> NOT APPLIED, disclosed
    assert n_live["LTCG"] == pytest.approx((exit_px - 575.95) * shares, abs=0.01)
    assert n_live["grandfathering"]["applied_events"] == 1
    assert n_live["grandfathering"]["adjustment_inr"] == pytest.approx(
        (exit_px - 575.95) * shares - (exit_px - entry_px) * shares, abs=0.02)
    # statutory direction: grandfathering lowers the taxable gain vs the
    # actual-cost basis (and the no-feed case stays un-adjusted)
    assert n_live["LTCG"] < (exit_px - entry_px) * shares
    assert n_none["LTCG"] == pytest.approx((exit_px - entry_px) * shares, abs=0.01)
    assert n_none["grandfathering"]["applied_events"] == 0


# ══════════════════════════════════════════════════════════════════════
# R32-5 — build marker lineage + endpoint wiring
# ══════════════════════════════════════════════════════════════════════

def test_r32_5_build_marker_and_wiring():
    app_src = APP.read_text(encoding="utf-8")
    m = re.search(r'APP_BUILD_ID\s*=\s*"([^"]+)"', app_src)
    assert m, "APP_BUILD_ID definition not found"
    build_id = m.group(1)
    for tag in ("R21", "R25", "R26", "R27", "R28", "R29", "R31", "R32"):
        assert tag in build_id, f"build id missing {tag}"
    assert "SOVEREIGN-TIER-OMEGA" in build_id
    assert "R32" in build_id and "BSE 31-Jan-2018 record" in build_id
    assert "575.95" in build_id and "finlib" in build_id
    # the auto-loaded feed path still drives the grandfathering integration
    assert "qa_db/tax_fmv_31jan2018.json" in app_src
    assert "restate_fmv_feed.py" in app_src
