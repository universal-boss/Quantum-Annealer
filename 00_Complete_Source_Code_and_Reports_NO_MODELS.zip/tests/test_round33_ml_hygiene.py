"""test_round33_ml_hygiene.py
===========================
Regression and architecture tests for Round 33:
  1. ML model artifact hygiene (size < 2 MB, stripped DataFrames).
  2. SHA-256 sidecar manifest integrity lock.
  3. Linux / CPU-safe deserialization (no MPS tensor failures).
  4. Bit-identical prediction parity.
  5. Hermetic PiT database seeding on clean seats.
  6. Universe feature pipeline integration.
"""
from __future__ import annotations

import hashlib
import os
import pickle
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from ml_alpha.engine import AlphaEngine
from ml_alpha.feature_store import FeatureStore
from ml_alpha.universe_pipeline import UniverseFeaturePipeline, load_universe_tickers

# AUDIT-FIX (Round 43): `models/ml_alpha_model.pkl` is the OPTIONAL legacy
# single-model artifact from the Round-33 era. The project has since moved to
# the five per-archetype models (ml_alpha_flow/momentum/quality/defensive/ipo
# .pkl), and the legacy artifact is no longer shipped with the source tree
# (the production reader in optimizer.py treats it as optional and only loads
# it when present). These tests therefore SKIP when the optional artifact is
# absent instead of failing — they still run their full assertions whenever
# an operator ships or regenerates the legacy model.
_LEGACY_MODEL = Path("models/ml_alpha_model.pkl")
_legacy_model_reason = "optional legacy models/ml_alpha_model.pkl not shipped (5-archetype models are the current artifacts)"


@pytest.mark.skipif(not _LEGACY_MODEL.exists(), reason=_legacy_model_reason)
def test_ml_model_lean_size_and_sha256():
    """Verify models/ml_alpha_model.pkl contains weights (< 100 MB) and SHA-256 matches."""
    pkl_path = Path("models/ml_alpha_model.pkl")
    sha_path = Path("models/ml_alpha_model.pkl.sha256")

    assert pkl_path.exists(), "models/ml_alpha_model.pkl must exist"
    assert sha_path.exists(), "models/ml_alpha_model.pkl.sha256 sidecar must exist"

    size_bytes = pkl_path.stat().st_size
    assert size_bytes < 2 * 1024 * 1024 * 1024, f"Model size must be < 2 GB, got {size_bytes:,} bytes"

    expected_sha = sha_path.read_text().strip().lower()
    actual_sha = hashlib.sha256(pkl_path.read_bytes()).hexdigest().lower()
    assert actual_sha == expected_sha, "SHA-256 sidecar must match model file"


@pytest.mark.skipif(not _LEGACY_MODEL.exists(), reason=_legacy_model_reason)
def test_ml_model_cpu_safe_deserialization():
    """Verify model unpickles safely on CPU without raising _mps_deserialize."""
    pkl_path = Path("models/ml_alpha_model.pkl")
    with open(pkl_path, "rb") as f:
        engine = pickle.load(f)

    assert isinstance(engine, AlphaEngine), f"Expected AlphaEngine, got {type(engine)}"
    assert hasattr(engine, "predict"), "Engine must expose predict()"

    # Verify predictions run and return finite scores across the expanded universe
    preds = engine.predict()
    assert len(preds) >= 50, f"Expected at least 50 predictions, got {len(preds)}"
    for ticker, score in preds.items():
        assert np.isfinite(score), f"Score for {ticker} must be finite, got {score}"

    # Verify healthy score dispersion (not flat noise)
    std_val = float(preds.std()) if hasattr(preds, "std") else float(np.std(list(preds.values())))
    assert std_val > 0.005, f"Expected meaningful alpha dispersion (std > 0.005), got {std_val}"


def test_universe_feature_pipeline_tickers():
    """Verify 792-equity universe loader functions properly."""
    tickers = load_universe_tickers()
    assert len(tickers) >= 500, f"Expected at least 500 universe tickers, got {len(tickers)}"
    assert "RELIANCE.NS" in tickers or "TCS.NS" in tickers


def test_fundamentals_pit_db_hermetic_clean_seat(tmp_path, monkeypatch):
    """Verify _ensure_pit_db creates the schema on a clean directory WITHOUT
    inventing data (R34-6): the Round 33 version seeded five FABRICATED
    fundamentals rows (RELIANCE/TCS/INFY/HDFCBANK/COALINDIA) whenever no
    scrape cache existed. A clean seat must get an honestly EMPTY
    fundamentals table — only a real cache (from the live NSE scrape) seeds.
    RUNTIME_DIR is monkeypatched to an empty temp dir so the test is
    hermetic on machines that DO have a populated runtime cache.
    """
    import sqlite3
    import data_layer
    from data_layer import _ensure_pit_db

    empty_runtime = tmp_path / "runtime"
    empty_runtime.mkdir()
    monkeypatch.setattr(data_layer, "RUNTIME_DIR", empty_runtime)

    temp_db = tmp_path / "test_fundamentals_history.db"
    ok = _ensure_pit_db(temp_db)
    assert ok is True
    assert temp_db.exists()

    conn = sqlite3.connect(str(temp_db))
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM fundamentals")
    count = cur.fetchone()[0]
    conn.close()
    assert count == 0, (
        "Clean-seat fundamentals table must be EMPTY (R34-6: no fabricated "
        f"fallback rows), got {count} rows"
    )


def test_fundamentals_pit_db_seeds_from_real_cache(tmp_path, monkeypatch):
    """Verify the seeding path only fires from a REAL fundamentals_cache.json
    (R34-6): monkeypatch RUNTIME_DIR to a temp dir containing a cache and
    confirm the DB seeds exactly those tickers — proving the clean-seat
    emptiness above is a missing-input condition, not a broken loader."""
    import sqlite3
    import json
    from pathlib import Path
    import data_layer
    from data_layer import _ensure_pit_db

    runtime_dir = tmp_path / "runtime"
    runtime_dir.mkdir()
    cache_payload = {
        "TESTCO.NS": {"roe": 0.21, "de_ratio": 0.33, "rev_growth": 0.17, "pe_ratio": 15.5},
        "OTHERCO.NS": {"roe": 0.09, "de_ratio": 0.55, "rev_growth": 0.04, "pe_ratio": 21.0},
    }
    (runtime_dir / "fundamentals_cache.json").write_text(json.dumps(cache_payload))
    monkeypatch.setattr(data_layer, "RUNTIME_DIR", runtime_dir)

    temp_db = tmp_path / "test_fundamentals_cached.db"
    ok = _ensure_pit_db(temp_db)
    assert ok is True

    conn = sqlite3.connect(str(temp_db))
    cur = conn.cursor()
    cur.execute("SELECT ticker FROM fundamentals ORDER BY ticker")
    rows = [r[0] for r in cur.fetchall()]
    conn.close()
    assert sorted(rows) == ["OTHERCO", "TESTCO"], f"Expected cache-seeded rows, got {rows}"


def test_universe_feature_pipeline_extraction(tmp_path):
    """Verify UniverseFeaturePipeline extracts and standardizes factor panels across dates."""
    dates = pd.date_range("2024-01-01", periods=100, freq="B")
    mock_prices = {}
    tickers = ["RELIANCE.NS", "TCS.NS", "INFY.NS", "HDFCBANK.NS", "ICICIBANK.NS"]
    np.random.seed(42)

    for t in tickers:
        p = 1000 + np.cumsum(np.random.randn(len(dates)) * 5)
        df = pd.DataFrame({
            "open": p + np.random.randn(len(dates)),
            "high": p + np.abs(np.random.randn(len(dates))) * 2,
            "low": p - np.abs(np.random.randn(len(dates))) * 2,
            "close": p,
            "volume": np.random.randint(100000, 5000000, size=len(dates)),
        }, index=dates)
        mock_prices[t] = df

    store = FeatureStore(tmp_path / "test_store")
    pipeline = UniverseFeaturePipeline(feature_store=store)
    panels = pipeline.extract_technical_factors(mock_prices)

    assert len(panels) > 20, f"Expected >20 computed factor panels, got {len(panels)}"
    # Verify winsorization and z-score properties
    for fname, panel in list(panels.items())[:5]:
        assert panel.shape[1] == len(tickers)
        # Standardized values should be bounded within [-3.5, 3.5]
        assert (panel.dropna().values <= 3.51).all()
        assert (panel.dropna().values >= -3.51).all()

    # Save to store
    saved = pipeline.save_to_feature_store(panels, version="v1")
    assert saved == len(panels)
    loaded = store.load(list(panels.keys())[0], version="v1")
    assert loaded is not None
    assert loaded.shape == panels[list(panels.keys())[0]].shape


def test_sector_neutralize_panel():
    """Verify sector neutralization forces within-sector mean to zero."""
    from ml_alpha.universe_pipeline import sector_neutralize_panel
    dates = pd.date_range("2024-01-01", periods=10, freq="B")
    tickers = ["T1", "T2", "T3", "T4", "T5", "T6"]
    data = np.random.randn(len(dates), len(tickers)) * 2.0 + 5.0  # shifted mean
    df = pd.DataFrame(data, index=dates, columns=tickers)

    sector_map = {
        "T1": "Tech", "T2": "Tech", "T3": "Tech",
        "T4": "Finance", "T5": "Finance", "T6": "Finance"
    }

    neut = sector_neutralize_panel(df, sector_map=sector_map)
    # Check that for each row, mean of Tech and Finance is zero
    for dt in dates:
        tech_mean = neut.loc[dt, ["T1", "T2", "T3"]].mean()
        fin_mean = neut.loc[dt, ["T4", "T5", "T6"]].mean()
        assert abs(tech_mean) < 1e-6, f"Tech sector mean must be zero, got {tech_mean}"
        assert abs(fin_mean) < 1e-6, f"Finance sector mean must be zero, got {fin_mean}"


def test_turnover_and_cost_evaluation():
    """Verify transaction cost and turnover metrics computation."""
    from ml_alpha.universe_pipeline import evaluate_turnover_and_costs
    dates = pd.date_range("2024-01-01", periods=20, freq="B")
    tickers = [f"T{i}" for i in range(20)]
    np.random.seed(42)

    preds = pd.DataFrame(np.random.randn(len(dates), len(tickers)), index=dates, columns=tickers)
    returns = pd.DataFrame(np.random.randn(len(dates), len(tickers)) * 0.02, index=dates, columns=tickers)

    res = evaluate_turnover_and_costs(preds, returns, holding_days=10, cost_bps=15.0)
    assert "net_sharpe_ratio" in res
    assert "annualized_turnover" in res
    assert "annualized_net_return" in res
    assert res["annualized_turnover"] >= 0.0


@pytest.mark.skipif(not _LEGACY_MODEL.exists(), reason=_legacy_model_reason)
def test_feature_drift_detection():
    """Verify AlphaEngine.detect_drift detects distribution shifts."""
    pkl_path = Path("models/ml_alpha_model.pkl")
    with open(pkl_path, "rb") as f:
        engine = pickle.load(f)

    report = engine.detect_drift()
    assert "drift_detected" in report
    assert "drift_ratio" in report
    assert "drifted_features" in report
    assert isinstance(report["drift_detected"], bool)
