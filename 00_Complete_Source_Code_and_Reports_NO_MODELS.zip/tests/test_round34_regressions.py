"""test_round34_regressions.py
===============================
Round 34 regression locks — the antigravity/gemini Round 33 audit corrections.

Locks:
  R34-1   hermetic live-NSE gate restored on test_r21_6b
  R34-2   price_discovery_coefficient is point-in-time (no forward-label leak)
  R34-3   PeerSpilloverExpert feeds the GAT non-constant base scores
  R34-4   PPOGatingRouter discloses its reward source (action-dependent vs exogenous)
  R34-5   PROFILE_MAP has exactly 10 profiles (no duplicate IPO entry)
  R34-7   save_run stores a measured 0.0 Sharpe (falsy-zero bug)
  R34-9/10/11 telemetry fabrication / identity-fallback label / hardcoded sweep
          counters removed (source-level locks)
  R34-12  FeatureStore pickle portability (machine-specific cache_dir relocation)
  R34-12b the shipped artifact's full 23-feature panel set resolves in the store
"""
from __future__ import annotations

import inspect
import pickle
import textwrap
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent


# ── R34-1: hermetic suite contract ────────────────────────────────────────────

def test_r34_1_live_nse_test_is_opt_in():
    """test_r21_6b must be gated behind QA_LIVE_NETTESTS=1 (R34-1)."""
    import tests.test_round21_regressions as r21

    fn = r21.test_r21_6b_nse_option_chain_live_smoke
    markers = getattr(fn, "pytestmark", [])
    marker_names = []
    for m in markers:
        mark = getattr(m, "mark", None)
        name = getattr(mark, "name", None) or getattr(m, "name", None)
        if name:
            marker_names.append(name)
    assert "skipif" in marker_names, (
        f"test_r21_6b must carry a skipif gate (hermetic default run); markers={marker_names}"
    )
    # The gate must key on QA_LIVE_NETTESTS
    src = inspect.getsource(fn)
    assert "QA_LIVE_NETTESTS" in src


# ── R34-2: point-in-time price discovery ─────────────────────────────────────

def test_r34_2_price_discovery_no_forward_leak():
    """Modifying the LAST close (future info) must not change any feature row
    except rows that legitimately observe it (R34-2 shift correction)."""
    from ml_alpha.microstructure_factors import price_discovery_coefficient

    idx = pd.date_range("2024-01-01", periods=80, freq="B")
    cols = ["A", "B", "C", "D"]
    rng = np.random.default_rng(7)
    close = pd.DataFrame(100 + np.cumsum(rng.normal(0, 1, (80, 4)), axis=0), index=idx, columns=cols)
    open_ = close.shift(1).fillna(100.0) + rng.normal(0, 0.2, (80, 4))
    volume = pd.DataFrame(rng.integers(1e5, 5e6, (80, 4)), index=idx, columns=cols).astype(float)

    feat_a = price_discovery_coefficient(close, open_, volume, window=20)

    # Perturb the FUTURE (the last bar's close) and recompute.
    close2 = close.copy()
    close2.iloc[-1] = close2.iloc[-1] * 1.5
    feat_b = price_discovery_coefficient(close2, open_, volume, window=20)

    # All rows strictly before the final row must be identical: the pre-fix
    # implementation's row t used ret_{t->t+1}, so row len-2 would change when
    # the last close changed (label leak into the feature).
    np.testing.assert_allclose(
        feat_a.iloc[:-1].values, feat_b.iloc[:-1].values, atol=1e-12,
        err_msg="price_discovery feature changed at historical rows when only FUTURE data changed (leak)"
    )


# ── R34-3: GAT receives non-constant base scores ─────────────────────────────

def test_r34_3_peer_spillover_feeds_gat_base_scores():
    """PeerSpilloverExpert.fit must aggregate per-ticker base predictions and
    pass them to the GAT (R34-3) so the attention training is non-degenerate."""
    from ml_alpha.hierarchical_moe import PeerSpilloverExpert

    rng = np.random.default_rng(3)
    n_dates, tickers = 60, ["T1.NS", "T2.NS", "T3.NS", "T4.NS"]
    rows = [(d, t) for d in range(n_dates) for t in tickers]
    X = pd.DataFrame(
        rng.normal(0, 1, (len(rows), 6)),
        index=pd.MultiIndex.from_tuples(rows, names=["date", "ticker"]),
        columns=[f"f{i}" for i in range(6)],
    )
    y = rng.normal(0, 0.01, len(rows))
    row_tickers = [t for _, t in rows]

    expert = PeerSpilloverExpert(use_gat=True)
    expert.fit(X, y, tickers=row_tickers, returns_df=None)

    assert expert.gat_engine_ is not None and expert.gat_engine_.fitted_
    # The GAT's feature matrix source (base scores aggregated per ticker) must
    # exist and be non-constant — a constant H makes the training degenerate.
    # We verify via the attention matrix: with varying base scores the softmax
    # rows cannot all be exactly uniform.
    attn = expert.gat_engine_.attention_adj_
    assert attn is not None
    if attn.shape[0] > 1:
        row_vars = np.var(attn, axis=1)
        assert float(np.max(row_vars)) > 0.0 or attn.shape[0] == 1, (
            "GAT attention fully uniform — base scores likely not wired (R34-3)"
        )


def test_r34_3_gat_with_varying_scores_is_non_uniform():
    from ml_alpha.graph_attention_network import DynamicGATEngine

    rng = np.random.default_rng(11)
    idx = pd.date_range("2024-01-01", periods=80, freq="B")
    cols = ["A", "B", "C", "D", "E"]
    rets = pd.DataFrame(rng.normal(0, 0.01, (80, 5)), index=idx, columns=cols)

    gat = DynamicGATEngine(n_heads=2, hidden_dim=4, n_epochs=3)
    gat.fit_dynamic_attention(cols, returns_df=rets, base_scores=np.linspace(-0.2, 0.3, 5))
    attn = gat.attention_adj_
    assert attn is not None
    assert float(np.max(np.var(attn, axis=1))) > 0.0, (
        "attention rows uniform despite varying base scores (R34-3 regression)"
    )
    assert np.allclose(attn.sum(axis=1), 1.0, atol=1e-6)


# ── R34-4: PPO reward-source disclosure ──────────────────────────────────────

def test_r34_4_ppo_diagnostics_disclose_reward_source():
    from ml_alpha.ppo_gating_router import PPOGatingRouter

    router = PPOGatingRouter(use_ppo=False)  # heuristic path (torch-free)
    bench = np.random.default_rng(5).normal(0.0005, 0.01, 120)
    router.fit(bench, n_episodes=1)
    diag = router.get_diagnostics()
    assert "reward_source" in diag, "PPO diagnostics must disclose the reward source (R34-4)"


@pytest.mark.skipif(
    __import__("importlib").util.find_spec("torch") is None,
    reason="PyTorch not installed — PPO path inert (heuristic fallback by design)",
)
def test_r34_4_ppo_expert_ic_reward_is_action_dependent():
    """With expert_ic_series supplied, different weights must earn different
    rewards at the same step (the pre-fix reward was exogenous to the action)."""
    import torch  # noqa: F401
    from ml_alpha.ppo_gating_router import PPOGatingRouter

    torch.manual_seed(0)
    np.random.seed(0)
    router = PPOGatingRouter(use_ppo=True)
    T = 120
    bench = np.random.default_rng(9).normal(0.0004, 0.01, T)
    # Expert 1 (trend) has consistently positive IC; expert 2 negative.
    expert_ic = np.zeros((T, 3))
    expert_ic[:, 0] = 0.08
    expert_ic[:, 1] = -0.06
    router.fit(bench, expert_ic_series=expert_ic, n_episodes=2)
    diag = router.get_diagnostics()
    assert diag["reward_source"] == "expert_ic (action-dependent)"

    # Sanity: the trained policy should NOT collapse to the initial weights —
    # with a strongly positive trend-expert IC the router tilts toward it.
    w = router.select_weights(bench)
    assert set(w.keys()) == {"trend_momentum", "mean_reversion", "peer_spillover"}
    total = sum(w.values())
    assert abs(total - 1.0) < 1e-3


# ── R34-5: profile registry integrity ────────────────────────────────────────

def test_r34_5_profile_map_exactly_five_archetypes_no_duplicate_ipo():
    from data_layer import PROFILE_MAP

    assert len(PROFILE_MAP) == 5, (
        f"PROFILE_MAP must have exactly 5 consolidated institutional archetypes, got {len(PROFILE_MAP)}: {list(PROFILE_MAP)}"
    )
    ipo_entries = [k for k in PROFILE_MAP if "IPO" in str(k)]
    assert len(ipo_entries) == 1, f"Exactly one IPO profile expected, got {ipo_entries}"
    assert ipo_entries[0] == "🦄 High-Growth IPO · Multibagger Hunter"
    assert "🌱" not in "".join(PROFILE_MAP.keys()), "duplicate 🌱 IPO entry must not exist (R34-5)"


# ── R34-7: measured zero Sharpe is not dropped ───────────────────────────────

def test_r34_7_zero_sharpe_is_stored_not_null(tmp_path):
    from qa_db.sqlite_store import SQLiteStore

    store = SQLiteStore(str(tmp_path / "test_r34.db"))
    payload = {
        "run_id": "r34_zero_sharpe",
        "backtest": {"Sharpe Ratio": 0.0, "Annual Return": 0.0},
        "tickers": ["RELIANCE.NS", "TCS.NS"],
        "weights": [0.5, 0.5],
    }
    ok = store.save_run(payload, config={"K_STOCKS": 2}, n_stocks=2)
    assert ok is True

    history = store.load_history(limit=10)
    assert history, "run not persisted"
    row = history[0]
    sharpe = float(row["Sharpe"])
    ann_ret = float(row["Ann Ret"])
    assert sharpe == 0.0, f"measured 0.0 Sharpe must persist as 0.0, got {sharpe} (R34-7 falsy-zero)"
    assert ann_ret == 0.0, f"measured 0.0 annual return must persist as 0.0, got {ann_ret}"


# ── R34-9/10/11: source-level fabrication removal locks ─────────────────────

def test_r34_9_telemetry_has_no_fabricated_dma_weights():
    src = (ROOT / "web_dashboard" / "app.py").read_text(encoding="utf-8")
    # The return-dict key form (quoted) must be absent; comments may reference it.
    assert '"dma_model_allocations"' not in src, (
        "fabricated dma_model_allocations telemetry key must stay removed (R34-9)"
    )
    assert "dma_weights = {" not in src, "fabricated dma_weights dict must stay removed (R34-9)"


def test_r34_10_identity_fallback_not_labeled_success():
    src = (ROOT / "web_dashboard" / "app.py").read_text(encoding="utf-8")
    block = src[src.find("Offline fallback identity matrix") - 400: src.find("Offline fallback identity matrix") + 200]
    assert "PARTIAL" in block and '"SUCCESS"' not in block, (
        "offline identity-matrix fallback must be labeled PARTIAL, not SUCCESS (R34-10)"
    )


def test_r34_11_no_hardcoded_sweep_counts():
    src = (ROOT / "web_dashboard" / "app.py").read_text(encoding="utf-8")
    assert "9/9 profiles succeeded" not in src, "hardcoded '9/9 profiles succeeded' must stay removed (R34-11)"
    assert "Starting 9-profile" not in src, "hardcoded 'Starting 9-profile' must stay removed (R34-11)"


# ── R34-12: artifact portability ─────────────────────────────────────────────

def test_r34_12_feature_store_pickle_relocates_missing_cache_dir(tmp_path):
    """A pickled FeatureStore whose cache_dir does not exist on this machine
    must relocate to the installation default on restore (R34-12)."""
    from ml_alpha.feature_store import FeatureStore, CACHE_DIR

    store = FeatureStore(tmp_path / "gone_soon")
    blob = pickle.dumps(store)
    # Remove the directory after pickling — simulate another machine.
    import shutil
    shutil.rmtree(tmp_path / "gone_soon")

    restored = pickle.loads(blob)
    assert Path(str(restored.cache_dir)).exists(), "restored cache_dir must exist"
    # Either relocated to the default or to an existing dir — never a dead path.
    assert Path(str(restored.cache_dir)) == Path(CACHE_DIR) or Path(str(restored.cache_dir)).exists()


def test_r34_12_engine_setstate_drops_dead_feature_store(tmp_path):
    """An engine unpickled with a dead _feature_store reference must discard it
    so predict() rebuilds a portable store (R34-12)."""
    from ml_alpha.engine import AlphaEngine
    from ml_alpha.feature_store import FeatureStore

    eng = AlphaEngine(model_type="ensemble")
    eng._feature_store = FeatureStore(tmp_path / "dead_dir")
    blob = pickle.dumps(eng)
    import shutil
    shutil.rmtree(tmp_path / "dead_dir")

    restored = pickle.loads(blob)
    fs = getattr(restored, "_feature_store", None)
    if fs is not None:
        assert Path(str(fs.cache_dir)).exists(), (
            "engine must not retain a FeatureStore pointing at a dead directory (R34-12)"
        )


# ── R34-12b: complete feature panel set for the shipped artifact ─────────────

def test_r34_12b_all_artifact_features_resolve_in_store():
    import pickle as _pkl

    pkl_path = ROOT / "models" / "ml_alpha_model.pkl"
    if not pkl_path.exists():
        pytest.skip("model artifact not present")
    with open(pkl_path, "rb") as f:
        eng = _pkl.load(f)

    from ml_alpha.feature_store import FeatureStore
    fs = FeatureStore()
    missing = [fname for fname in eng._feature_names if fs.load(fname) is None]
    assert not missing, (
        f"Every deployment feature must resolve in the feature store; missing: {missing} (R34-12b)"
    )


def test_r34_12b_artifact_predicts_after_portability_fix():
    import pickle as _pkl
    import numpy as np

    pkl_path = ROOT / "models" / "ml_alpha_model.pkl"
    if not pkl_path.exists():
        pytest.skip("model artifact not present")
    with open(pkl_path, "rb") as f:
        eng = _pkl.load(f)

    preds = eng.predict()
    assert len(preds) >= 50, f"expected >=50 predictions, got {len(preds)} (R34-12)"
    vals = np.asarray(preds.values if hasattr(preds, "values") else preds, dtype=float)
    assert bool(np.isfinite(vals).all()), "non-finite alpha scores"
    assert float(np.std(vals)) > 0.005, f"alpha dispersion too low: {float(np.std(vals))}"
