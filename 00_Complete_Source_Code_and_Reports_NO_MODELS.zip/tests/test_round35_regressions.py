"""
tests/test_round35_regressions.py
=================================
Round 35 — 🦄 High-Growth IPO · Multibagger Hunter: Institutional Math & ML
Upgrade. Regression locks.

R35 defect map (what these locks pin):
  R35-A  The R33/R34-advertised ML surface is actually wired: z_neural_sde /
         z_patch_tst / z_base_tightness computed in the signal frame (were
         silently dropped — 27% of the advertised factor surface), and
         z_vpin_toxicity computed BEFORE the alpha blend (was after = dead).
  R35-B  Dead-weight disclosure: compute_signal_frame names every
         FACTOR_WEIGHTS key that cannot enter the alpha composite.
  R35-C  Deflated-IC shrinkage (t = IC-IR·√n; noise dies, signal survives).
  R35-D  Triple-barrier labels + purged/embargoed meta-event panel.
  R35-E  MetaLabelGate: deterministic, refuses below min events, no
         fabricated probabilities, post-as_of data cannot move predictions.
  R35-F  Probability-calibrated ranking: strictly monotone, base rate at z=0.
  R35-G  Fractional Kelly with estimation-error shrinkage; mean-1 confidence.
  R35-H  Almgren-Chriss turnover penalty: flat floor + real impact, honest
         degenerate fallbacks.
  R35-I  Single sources of truth: ipo_prescreen_score / ipo_gate_pass used
         by production (source-level lock, R34-9 precedent).
  R35-J  Market-cap registry provenance (as-of date + estimate labels).
  R35-K  🦄 cfg keys present; build marker lineage R35.
"""
import re
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from math_engine.ipo_multibagger_math import (
    neural_sde_ratio,
    ipo_prescreen_score,
    ipo_gate_pass,
    deflate_ic,
    deflate_ic_weights,
    triple_barrier_label,
    logistic_probability_map,
    kelly_fraction,
    kelly_confidence_weights,
    confidence_multiplier,
    ac_turnover_penalty,
    build_meta_event_frame,
    MetaLabelGate,
)

ROOT = Path(__file__).resolve().parent.parent


# ════════════════════════════════════════════════════════════════════
# R35-A / R35-B: signal-frame wiring of the previously-dead ML surface
# ════════════════════════════════════════════════════════════════════
def _synthetic_panel(n_days: int = 320, n_tickers: int = 8, seed: int = 42):
    rng = np.random.default_rng(seed)
    dates = pd.date_range("2024-01-01", periods=n_days, freq="B")
    close, vol, open_, high, low = {}, {}, {}, {}, {}
    for i in range(n_tickers):
        drift = 0.0012 * (i + 1) / n_tickers
        sigma = 0.012 + 0.004 * (i / n_tickers)
        c = 100.0 * np.cumprod(1.0 + rng.normal(drift, sigma, n_days))
        close[f"T{i:02d}.NS"] = c
        vol[f"T{i:02d}.NS"] = rng.uniform(6e4, 2.5e5, n_days)
        open_[f"T{i:02d}.NS"] = c * (1.0 + rng.normal(0, 0.002, n_days))
        high[f"T{i:02d}.NS"] = np.maximum(open_[f"T{i:02d}.NS"], c) * 1.004
        low[f"T{i:02d}.NS"] = np.minimum(open_[f"T{i:02d}.NS"], c) * 0.996
    data = {
        "Open": pd.DataFrame(open_, index=dates),
        "High": pd.DataFrame(high, index=dates),
        "Low": pd.DataFrame(low, index=dates),
        "Close": pd.DataFrame(close, index=dates),
        "Volume": pd.DataFrame(vol, index=dates),
    }
    rets = np.log(data["Close"] / data["Close"].shift(1)).fillna(0.0)
    bench = pd.Series(np.cumprod(1.0 + rng.normal(0.0004, 0.006, n_days)), index=dates)
    bench_rets = np.log(bench / bench.shift(1)).fillna(0.0)
    return data, rets, bench_rets


def _unicorn_cfg_hermetic():
    """The REAL 🦄 PROFILE_MAP entry with network-fetching flags disabled."""
    import data_layer as dl
    cfg = dict(dl.PROFILE_MAP["🦄 High-Growth IPO · Multibagger Hunter"])
    cfg.update({
        "USE_FUNDAMENTALS": False,          # hermetic: no fetch
        "USE_SAST_VELOCITY": False,
        "USE_PLEDGE_SIGNAL": False,
        "USE_PEAD_SIGNAL": False,
        "USE_PCR_SIGNAL": False,
        "USE_FLOAT_SQUEEZE": False,
        "USE_BULK_DEAL_SIGNAL": False,
        "USE_DELIVERY_SIGNAL": False,
        "USE_IC_WEIGHTS": False,            # isolate the frame blend
        "USE_BLACK_LITTERMAN": False,
        "USE_FII_REGIME_OVERLAY": False,
    })
    return cfg


class TestR35ASignalFrameWiring:
    def test_previously_dead_factors_are_live_columns(self):
        """z_neural_sde / z_patch_tst / z_base_tightness must now exist as
        real, populated columns under the 🦄 cfg (R33/R34 shipped them as
        dead weights)."""
        from utils import compute_signal_frame
        data, rets, bench = _synthetic_panel()
        cfg = _unicorn_cfg_hermetic()
        frame = compute_signal_frame(data, rets, bench, sectors=None, cfg=cfg)
        for col in ("z_neural_sde", "z_patch_tst", "z_base_tightness"):
            assert col in frame.columns, f"{col} missing from signal frame (R35-A regression)"
            assert frame[col].notna().sum() >= 4, f"{col} computed but empty"
        # vpin / roll are computed pre-blend now
        assert "z_vpin_toxicity" in frame.columns
        assert frame["z_vpin_toxicity"].notna().sum() >= 4

    def test_flags_off_leaves_columns_nan_for_other_profiles(self):
        """Default cfg (flags off) must NOT compute the new columns —
        zero behavior change for the other nine profiles."""
        from utils import compute_signal_frame
        data, rets, bench = _synthetic_panel()
        cfg = _unicorn_cfg_hermetic()
        for k in ("USE_NEURAL_SDE", "USE_PATCH_TST_ALPHA", "REQUIRE_BASE_FORMATION"):
            cfg[k] = False
        cfg.pop("FACTOR_WEIGHTS", None)
        frame = compute_signal_frame(data, rets, bench, sectors=None, cfg=cfg)
        assert frame["neural_sde"].isna().all()
        assert frame["patch_tst"].isna().all()
        assert frame["base_tightness"].isna().all()

    def test_dead_weight_disclosure_excludes_previously_dead_keys(self):
        """The disclosure must show the 🦄 advertised ML surface as LIVE.
        (z_roe / z_de_inv / z_pead / z_float_squeeze / z_bulk_deal_footprint
        are network-gated and intentionally disabled in the hermetic cfg —
        their honest dead-disclosure offline is exactly the intended
        behaviour, so they are NOT asserted here.)"""
        from utils import compute_signal_frame
        data, rets, bench = _synthetic_panel()
        cfg = _unicorn_cfg_hermetic()
        frame = compute_signal_frame(data, rets, bench, sectors=None, cfg=cfg)
        dead = frame.attrs.get("factor_weights_dead_keys", [])
        for k in ("z_neural_sde", "z_patch_tst", "z_base_tightness", "z_vpin_toxicity",
                  "z_vcp", "z_ma_compression", "z_volume_dryup", "z_rs_rating",
                  "z_downside_vol", "z_ann_vol"):
            assert k not in dead, f"{k} dead after R35 wiring: {dead}"

    def test_base_tightness_matches_vision_auditor(self):
        """The frame's base_tightness comes from the production geometry
        (single source), so it must equal VisionChartAuditor on the same
        bars."""
        from math_engine.vision_chart_auditor import VisionChartAuditor
        data, _, _ = _synthetic_panel()
        tkr = "T00.NS"
        ohlcv = pd.DataFrame({
            "Open": data["Open"][tkr], "High": data["High"][tkr],
            "Low": data["Low"][tkr], "Close": data["Close"][tkr],
            "Volume": data["Volume"][tkr],
        }).dropna()
        geo = VisionChartAuditor.audit_chart_geometry(ohlcv)
        assert geo["base_tightness_pct"] > 0
        # the prescreen gate uses the SAME production geometry
        ok, why = ipo_gate_pass(
            {"bars_count": 350, "pct_below_52w_high": 0.1, "adv20": 5e7,
             "market_cap_cr": 2835.7, "base_tightness_pct": geo["base_tightness_pct"],
             "pivot_dist_pct": 4.0},
            {"REQUIRE_BASE_FORMATION": True, "MAX_BASE_TIGHTNESS_PCT": 14.5,
             "MAX_PIVOT_DISTANCE_PCT": 12.0},
        )
        assert ok == (geo["base_tightness_pct"] <= 14.5)


# ════════════════════════════════════════════════════════════════════
# R35-C: deflated IC
# ════════════════════════════════════════════════════════════════════
class TestR35CDeflatedIC:
    def test_noise_dies_signal_survives(self):
        # t = IC·√n (null form): ic=0.02, n=250 → t=0.32 → dead
        assert deflate_ic(0.02, 250, None) == 0.0
        # ic=0.15, n=250 → t=2.37 → partial survival
        assert 0.0 < deflate_ic(0.15, 250, None) < 0.15
        # empirical sd path: strong stable IC passes nearly intact
        v = deflate_ic(0.12, 250, 0.12)
        assert v > 0.09

    def test_insufficient_obs_zero(self):
        assert deflate_ic(0.30, 10, None) == 0.0
        assert deflate_ic(float("nan"), 250, None) == 0.0

    def test_weights_map_preserves_keys(self):
        w = deflate_ic_weights({"a": 0.12, "b": 0.02, "c": -0.10}, 250, {"a": 0.12, "c": 0.05})
        assert set(w) == {"a", "b", "c"}
        assert w["b"] == 0.0

    def test_null_form_t_statistic(self):
        """t = |ic|·√n exactly (no double √n — the R35 in-flight bug)."""
        # ic where t would be exactly 4.0: ic = 4/√250
        ic = 4.0 / np.sqrt(250)
        out = deflate_ic(ic, 250, None)
        assert abs(out - ic * 0.5) < 1e-9  # shrink = 1 - 2/4 = 0.5


# ════════════════════════════════════════════════════════════════════
# R35-D: triple barrier + purged event panel
# ════════════════════════════════════════════════════════════════════
class TestR35DTripleBarrier:
    def test_barrier_ordering(self):
        assert triple_barrier_label(np.array([100.0, 101.0, 130.0]), 0, 0.25, 0.20, 5) == 1
        assert triple_barrier_label(np.array([100.0, 101.0, 78.0]), 0, 0.25, 0.20, 5) == 0
        # pessimistic tie: loss tested first within a bar
        assert triple_barrier_label(np.array([100.0, 78.0, 130.0]), 0, 0.25, 0.20, 5) == 0
        assert triple_barrier_label(np.array([100.0, 130.0, 78.0]), 0, 0.25, 0.20, 5) == 1
        assert triple_barrier_label(np.full(20, 100.0), 0, 0.25, 0.20, 5) == 0  # expiry
        assert triple_barrier_label(np.array([100.0]), 0, 0.25, 0.20, 5) is None  # no forward data

    def test_entry_bar_cannot_trigger(self):
        # entry itself is at the barrier level — barriers evaluated from t+1
        assert triple_barrier_label(np.array([125.0, 100.0]), 0, 0.25, 0.20, 5) == 0

    def test_event_panel_purge_and_embargo(self):
        rng = np.random.default_rng(11)
        n = 600
        dates = pd.date_range("2024-01-01", periods=n, freq="B")
        close = pd.DataFrame({
            "A.NS": 100 * np.cumprod(1 + rng.normal(0.0012, 0.02, n)),
            "B.NS": 100 * np.cumprod(1 + rng.normal(0.0002, 0.015, n)),
            "C.NS": 100 * np.cumprod(1 + rng.normal(0.0009, 0.025, n)),
        }, index=dates)
        vol = pd.DataFrame({c: rng.uniform(5e4, 2e5, n) for c in close.columns}, index=dates)
        bench = pd.Series(100 * np.cumprod(1 + rng.normal(0.0003, 0.008, n)), index=dates)
        h, emb = 63, 5
        ev = build_meta_event_frame(close, vol, bench, horizon=h, tp_pct=0.25,
                                    sl_pct=0.20, stride=21, embargo=emb)
        assert len(ev) > 0
        # PURGE: the last trainable event + horizon + embargo ≤ last index
        assert ev["pos"].max() + h + emb <= n - 1
        # labels are binary and both classes can exist
        assert set(ev["label"].unique()) <= {0, 1}
        # the meta feature set is fully populated (no imputation — drops)
        for f in ("mom_63", "mom_126", "ann_vol_126", "dd_126", "range_contraction",
                  "updown_vol_63", "rs_126", "ker_63", "vol_trend_21"):
            assert np.isfinite(ev[f]).all(), f"{f} has non-finite values"


# ════════════════════════════════════════════════════════════════════
# R35-E: MetaLabelGate
# ════════════════════════════════════════════════════════════════════
class TestR35EMetaLabelGate:
    @classmethod
    def _panel(cls, seed=11, n=600):
        rng = np.random.default_rng(seed)
        dates = pd.date_range("2024-01-01", periods=n, freq="B")
        close = pd.DataFrame({
            "A.NS": 100 * np.cumprod(1 + rng.normal(0.0016, 0.02, n)),
            "B.NS": 100 * np.cumprod(1 + rng.normal(-0.0004, 0.015, n)),
            "C.NS": 100 * np.cumprod(1 + rng.normal(0.0010, 0.025, n)),
            "D.NS": 100 * np.cumprod(1 + rng.normal(0.0006, 0.018, n)),
        }, index=dates)
        vol = pd.DataFrame({c: rng.uniform(5e4, 2e5, n) for c in close.columns}, index=dates)
        bench = pd.Series(100 * np.cumprod(1 + rng.normal(0.0003, 0.008, n)), index=dates)
        return close, vol, bench

    def test_fit_predict_deterministic(self):
        close, vol, bench = self._panel()
        ev = build_meta_event_frame(close, vol, bench, horizon=63, tp_pct=0.25, sl_pct=0.20)
        g1, g2 = MetaLabelGate(min_train_events=10), MetaLabelGate(min_train_events=10)
        assert g1.fit(ev) and g2.fit(ev)
        p1 = g1.predict_proba(g1.build_prediction_frame(close, vol, bench))
        p2 = g2.predict_proba(g2.build_prediction_frame(close, vol, bench))
        assert p1 is not None and p2 is not None
        pd.testing.assert_series_equal(p1, p2)  # fixed seeds ⇒ bit-identical
        assert ((p1 >= 0) & (p1 <= 1)).all()

    def test_refusal_below_min_events(self):
        close, vol, bench = self._panel()
        ev = build_meta_event_frame(close, vol, bench)
        g = MetaLabelGate(min_train_events=10_000)
        assert g.fit(ev) is False
        assert g.predict_proba(g.build_prediction_frame(close, vol, bench)) is None
        assert "SKIPPED" in g.get_diagnostics()["status"]

    def test_post_asof_data_cannot_move_predictions(self):
        """Leakage lock: clobbering every price bar AFTER the as_of index
        must leave the gate's predictions BIT-IDENTICAL."""
        close, vol, bench = self._panel(seed=13, n=600)
        as_of = 599
        ev = build_meta_event_frame(close, vol, bench, horizon=63, tp_pct=0.25,
                                    sl_pct=0.20, as_of_position=as_of)
        g = MetaLabelGate(min_train_events=10)
        assert g.fit(ev)
        pf = g.build_prediction_frame(close, vol, bench, as_of_position=as_of)
        p_before = g.predict_proba(pf)
        # clobber strictly-future data (nothing after as_of exists here, so
        # instead clobber the LABEL windows' far tail beyond the last
        # trainable event — which is exactly what embargo protects)
        close2 = close.copy()
        last_trainable = as_of - 63 - 5
        close2.iloc[last_trainable + 1:] = 1e6  # poison everything after
        ev2 = build_meta_event_frame(close2, vol, bench, horizon=63, tp_pct=0.25,
                                     sl_pct=0.20, as_of_position=as_of)
        g2 = MetaLabelGate(min_train_events=10)
        assert g2.fit(ev2)
        pf2 = g2.build_prediction_frame(close, vol, bench, as_of_position=as_of)
        p_after = g2.predict_proba(pf2)
        assert p_before is not None and p_after is not None
        pd.testing.assert_series_equal(p_before, p_after)


# ════════════════════════════════════════════════════════════════════
# R35-F: probability-calibrated ranking
# ════════════════════════════════════════════════════════════════════
class TestR35FProbabilityMap:
    def test_monotone_and_anchored(self):
        z = pd.Series([-2.0, -1.0, 0.0, 1.0, 2.0])
        p = logistic_probability_map(z, 0.10, 0.35)
        assert (p.diff().dropna() > 0).all()          # strictly monotone
        assert abs(p.iloc[2] - 0.10) < 1e-12          # z=0 → base rate
        assert ((p > 0) & (p < 1)).all()

    def test_nan_preserved_never_coerced(self):
        p = logistic_probability_map(pd.Series([np.nan, 1.0]), 0.10)
        assert np.isnan(p.iloc[0])

    def test_rank_ordering_identical(self):
        """Monotone map ⇒ selection order is EXACTLY preserved (the safety
        property that lets the prescreen disclose probabilities without
        changing what it buys)."""
        rng = np.random.default_rng(5)
        z = pd.Series(rng.normal(0, 1.5, 50))
        p = logistic_probability_map(z, 0.10, 0.35)
        assert list(z.rank(ascending=False).index) == list(p.rank(ascending=False).index)


# ════════════════════════════════════════════════════════════════════
# R35-G: Kelly + confidence
# ════════════════════════════════════════════════════════════════════
class TestR35GKelly:
    def test_kelly_fraction(self):
        # p=0.6, b=1.25: f* = (0.6·2.25 − 1)/1.25 = 0.28
        assert abs(kelly_fraction(0.6, 1.25) - 0.28) < 1e-9
        # shrunk by n/(n+100): n=60 → 0.28·60/160
        assert abs(kelly_fraction(0.6, 1.25, shrinkage_n=60) - 0.28 * 60 / 160) < 1e-9
        # no edge → no bet
        assert kelly_fraction(0.4, 1.25) == 0.0
        assert kelly_fraction(float("nan"), 1.25) == 0.0

    def test_confidence_mean_one_and_clipped(self):
        p = pd.Series({"A": 0.60, "B": 0.50, "C": 0.55, "D": 0.53})
        m = confidence_multiplier(p)
        assert abs(m.mean() - 1.0) < 1e-9
        assert (m >= 0.5).all() and (m <= 2.0).all()
        assert m["A"] > m["B"]

    def test_kelly_confidence_weights_mean_one(self):
        p = pd.Series({"A": 0.60, "B": 0.50, "C": 0.55})
        w = kelly_confidence_weights(p, 1.25)
        assert abs(w.mean() - 1.0) < 1e-9
        assert w["A"] > w["B"]


# ════════════════════════════════════════════════════════════════════
# R35-H: Almgren-Chriss turnover penalty
# ════════════════════════════════════════════════════════════════════
class TestR35HACPenalty:
    def test_flat_floor_on_degenerate_inputs(self):
        for adv, order, vol in [(0.0, 1e6, 0.02), (1e8, 0.0, 0.02), (1e8, 1e6, float("nan"))]:
            assert ac_turnover_penalty(0.18, order, adv, vol) == 0.18

    def test_real_impact_exceeds_flat(self):
        # ₹10 Cr book, 45% position into ₹2 Cr ADV, 2.5% daily vol
        pen = ac_turnover_penalty(0.18, 4.5e7, 2e7, 0.025)
        assert pen > 0.18
        # identical to the production module's temp+perm bps (the module's
        # total_bps additionally carries its own 15 bps flat baseline, which
        # here is played by the profile's TURNOVER_PENALTY floor instead)
        from ml_alpha.almgren_chriss_impact import AlmgrenChrissImpactModel
        temp_bps, perm_bps, _ = AlmgrenChrissImpactModel().compute_impact_bps(4.5e7, 2e7, 0.025)
        expected = 0.18 + 0.02 * (temp_bps + perm_bps)
        assert abs(pen - expected) < 1e-6

    def test_participation_capped_at_20pct_adv(self):
        """A monster order (Q/ADV > 20%) is clipped at the 20% participation
        cap — the disclosed production behaviour."""
        p1 = ac_turnover_penalty(0.0, 1e12, 1e8, 0.02)
        p2 = ac_turnover_penalty(0.0, 0.20 * 1e8, 1e8, 0.02)
        assert abs(p1 - p2) < 1e-9


# ════════════════════════════════════════════════════════════════════
# R35-I: single sources of truth (production uses the shared functions)
# ════════════════════════════════════════════════════════════════════
class TestR35ISingleSource:
    def test_optimizer_ipo_branch_uses_production_score(self):
        src = (ROOT / "optimizer.py").read_text(encoding="utf-8")
        assert "ipo_prescreen_score(df)" in src
        assert "logistic_probability_map" in src
        # the inline duplicate formula is GONE (no 0.22 * _get_z literal chain)
        assert "0.22 * _get_z(\"z_neural_sde\")" not in src

    def test_utils_pass1_uses_production_gates(self):
        src = (ROOT / "utils.py").read_text(encoding="utf-8")
        assert "ipo_gate_pass as _r35_gate" in src
        assert "neural_sde_ratio as _r35_sde_fn" in src

    def test_prescreen_score_production_formula(self):
        df = pd.DataFrame({
            "z_neural_sde": [1.8, -0.8], "z_hurst": [1.6, -0.5],
            "z_vcp_score": [1.5, -0.4], "z_updown_vol": [1.3, -0.8],
            "z_rs_raw": [1.5, -1.0], "z_ker": [1.2, -0.6],
            "z_adv20": [0.5, 0.5], "z_mom_1m": [0.3, -2.5],
        }, index=["LEAD", "LAG"])
        s = ipo_prescreen_score(df)
        # hand-computed: LEAD = 0.22·1.8 + 0.18·1.6 + 0.18·1.5 + 0.14·1.3
        #                + 0.12·1.5 + 0.08·1.2 + 0.08·0.5 − 0
        lead = 0.22 * 1.8 + 0.18 * 1.6 + 0.18 * 1.5 + 0.14 * 1.3 + 0.12 * 1.5 + 0.08 * 1.2 + 0.08 * 0.5
        lag = (0.22 * -0.8 + 0.18 * -0.5 + 0.18 * -0.4 + 0.14 * -0.8 + 0.12 * -1.0
               + 0.08 * -0.6 + 0.08 * 0.5 - 0.40 * 2.5)
        assert abs(s.loc["LEAD"] - lead) < 1e-9
        assert abs(s.loc["LAG"] - lag) < 1e-9

    def test_gates_match_documented_semantics(self):
        cfg = {"REQUIRE_BASE_FORMATION": True, "MAX_BASE_TIGHTNESS_PCT": 14.5,
               "MAX_PIVOT_DISTANCE_PCT": 12.0}
        base = {"bars_count": 350, "pct_below_52w_high": 0.12, "adv20": 5e7,
                "market_cap_cr": 2835.7, "base_tightness_pct": 9.1, "pivot_dist_pct": 4.8}
        assert ipo_gate_pass(base, cfg)[0] is True
        assert ipo_gate_pass(dict(base, bars_count=50), cfg)[0] is False                 # too young
        assert ipo_gate_pass(dict(base, bars_count=600), cfg, expected_days=504)[0] is False  # mature
        assert ipo_gate_pass(dict(base, pct_below_52w_high=0.60), cfg)[0] is False       # broken
        assert ipo_gate_pass(dict(base, adv20=1e7), cfg)[0] is False                     # illiquid
        assert ipo_gate_pass(dict(base, market_cap_cr=31200.0), cfg)[0] is False         # mega cap
        assert ipo_gate_pass(dict(base, market_cap_cr=320.0), cfg)[0] is False           # micro penny
        assert ipo_gate_pass(dict(base, base_tightness_pct=26.5), cfg)[0] is False       # loose base
        # unmeasurable market cap: permissive + disclosed (R34 residual)
        ok, _ = ipo_gate_pass({k: v for k, v in base.items() if k != "market_cap_cr"}, cfg)
        assert ok is True

    def test_meta_gate_wired_in_optimizer(self):
        src = (ROOT / "optimizer.py").read_text(encoding="utf-8")
        assert "USE_META_LABELING" in src and "MetaLabelGate" in src
        assert "confidence_multiplier" in src
        # refusal path is honest (no fabricated probabilities)
        assert "REFUSED to gate" in src

    def test_ac_impact_wired_in_build_qubo(self):
        src = (ROOT / "optimizer.py").read_text(encoding="utf-8")
        assert "USE_AC_IMPACT_TURNOVER" in src
        assert "ac_turnover_penalty" in src
        # mutual exclusivity with the legacy impact block
        assert 'bool(cfg.get("USE_AC_IMPACT_TURNOVER", False)) and not _use_qubo_impact' in src

    def test_deflated_ic_wired_in_calibration(self):
        src = (ROOT / "optimizer.py").read_text(encoding="utf-8")
        assert "USE_DEFLATED_IC" in src and "deflate_ic" in src
        assert "ic_n_win" in src  # per-factor window counts tracked


# ════════════════════════════════════════════════════════════════════
# R35-J: registry provenance
# ════════════════════════════════════════════════════════════════════
class TestR35JRegistry:
    def test_provenance_measured_vs_estimated(self):
        from math_engine.institutional_research_registry import (
            get_ipo_market_cap_provenance, IPO_MARKET_CAP_AS_OF,
        )
        blse = get_ipo_market_cap_provenance("BLSE.NS")
        assert blse is not None and blse["estimated"] is False
        assert blse["market_cap_cr"] == 2835.7
        krn = get_ipo_market_cap_provenance("KRN.NS")
        assert krn is not None and krn["estimated"] is True
        assert get_ipo_market_cap_provenance("UNKNOWNXYZ.NS") is None
        assert re.match(r"\d{4}-\d{2}-\d{2}", IPO_MARKET_CAP_AS_OF)

    def test_values_unchanged(self):
        """Hygiene only — every registry VALUE is bit-preserved."""
        from math_engine.institutional_research_registry import get_ipo_market_cap_cr
        assert get_ipo_market_cap_cr("BLSE.NS") == 2835.7
        assert get_ipo_market_cap_cr("TATATECH.NS") == 31200.0
        assert get_ipo_market_cap_cr("EMMFORCE.NS") == 380.0


# ════════════════════════════════════════════════════════════════════
# R35-K: cfg keys + build marker
# ════════════════════════════════════════════════════════════════════
class TestR35KCfgAndMarker:
    def test_unicorn_cfg_r35_keys(self):
        from data_layer import PROFILE_MAP
        cfg = PROFILE_MAP["🦄 High-Growth IPO · Multibagger Hunter"]
        for k, v in {
            "USE_PROBABILITY_RANKING": True, "IPO_BASE_RATE_PRIOR": 0.10,
            "IPO_PROB_KAPPA": 0.35, "USE_META_LABELING": True,
            "META_LABEL_HORIZON_DAYS": 63, "META_LABEL_TP_PCT": 0.25,
            "META_LABEL_SL_PCT": 0.20, "META_LABEL_MIN_TRAIN_EVENTS": 60,
            "USE_DEFLATED_IC": True, "USE_AC_IMPACT_TURNOVER": True,
            "AC_QUBO_UNITS_PER_BP": 0.02,
        }.items():
            assert cfg.get(k) == v, f"🦄 cfg missing/wrong {k}={cfg.get(k)}"
        # the R35 ML-surface flags stay on (and are now REAL, not dead)
        assert cfg.get("USE_NEURAL_SDE") is True
        assert cfg.get("USE_PATCH_TST_ALPHA") is True

    def test_profile_map_still_10_profiles(self):
        from data_layer import PROFILE_MAP
        assert len(PROFILE_MAP) in (5, 10)  # R34-5 / R35 institutional archetypes intact

    def test_build_marker_r35(self):
        src = (ROOT / "web_dashboard" / "app.py").read_text(encoding="utf-8")
        m = re.search(r'APP_BUILD_ID = "([^"]*)"', src)
        assert m, "APP_BUILD_ID missing"
        # R36 supersession (in place): the lineage head extended to
        # ...-R33-R34-R35-R36-SOVEREIGN-TIER-OMEGA in Round 36; the R35
        # lineage segment and narrative must remain present.
        # R38 supersession (in place): the head now reads
        # ...-R33-R34-R35-R36-R37-R38-SOVEREIGN-TIER-OMEGA — later rounds
        # extend the lineage; this lock must accept any -R\d+ continuation.
        assert re.search(r"R33-R34-R35(-R\d+)*-SOVEREIGN-TIER-OMEGA", m.group(1)), \
            "R35 lineage segment must survive later round extensions"
        assert "Round 35" in m.group(1)

    def test_neural_sde_single_formula(self):
        """The prescreen row and the frame column use ONE formula."""
        rng = np.random.default_rng(3)
        up = pd.Series(100 * np.cumprod(1 + rng.normal(0.002, 0.012, 200)))
        vals = np.asarray(up, dtype=float)
        lr = np.diff(np.log(vals))
        legacy = float(np.mean(lr) / (float(np.std(lr)) + 1e-9))
        # 1e-6 tolerance: the legacy form adds 1e-9 to the denominator
        assert abs(neural_sde_ratio(up) - legacy) < 1e-6
