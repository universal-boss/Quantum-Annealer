"""tests/test_round36_regressions.py
====================================
Round 36 — TWO lock families in one file.

PART A — the 2026-09-14 "run failed" incident locks (authored in the Round 36
upload as "test_round34_regressions.py", which had REPLACED the original
Round 34 anti-fabrication lock file; both files now coexist — the original
tests/test_round34_regressions.py was restored from the verified Round 35
state, and the incident locks were renamed here so the round numbering
matches what actually shipped):

Incident chain (log quantum_annealer_log_2026-09-14_04_19_51.txt):
  regime_hmm_latest.json went >48h stale (nothing in the web-dashboard
  runtime ever refreshes it) -> detect_market_regime hard-returned
  "Defensive (Stale Model)" -> optimizer Staleness Flatten returned an
  empty target portfolio -> the run burned ~30s of tail stages, persisted
  fabricated OOS Sharpes (IS -3.53 / OOS -3.63) to the DB, and finally
  the DataQualityGate aborted with a generic "degenerate allocation"
  error -> "Optimizer failed".

Incident fixes locked here (retained from the Round 36 upload, verified):
  R34-1  data_layer.detect_market_regime: inline HMM retrain on staleness
         (self-heal) + Reason codes on the defensive fallbacks.
  R34-2  optimizer build_qubo: Staleness Flatten tags cfg["_DEFENSIVE_FLAT"].
  R34-3  optimizer: OOS validation + DB persistence skipped for degenerate
         allocations (no fabricated Sharpes).
  R34-4  optimizer DQ gate: distinct, actionable REGIME-STALENESS DEFENSE
         halt message for intentional defensive flats.
  R34-5  web_dashboard app: REAL background HMM refresh (12h loop) replaces
         the decorative "Fetching Nifty 500 broad proxy data" log line.
  R34-6  data_layer.fetch_nse_delivery_data: per-row guard for the NSE bhav
         ' -' DELIV_PER placeholder (no more whole-day parse aborts).
  R34-7  ml_alpha.feature_store.FeatureStore: __setstate__ re-anchor for
         machine-bound pickled stores + glob fallback on hash-range
         mismatch in load().
  R34-8  models/feature_cache completed: all 23 model features present.

PART B — the Round 36 CORRECTION locks (this session's audit of the
Round 36 upload, user instruction: "stupid gemini, killed too many important
features, like master comparison matrix. could you check each and every line
and fix all bugs"):
  R36-1  single-profile optimizer runs MERGE their profile's rows into
         combined_portfolio.csv / combined_universe.csv in place — the other
         profiles' rows (the master comparison matrix's data) are preserved.
  R36-2  the fabricated dashboard-side is_valid_ipo_stock() filter is GONE
         (hardcoded 2026-09-14 "today", hardcoded ticker whitelists, a
         365-730 calendar-day window contradicting the production
         160-550 trading-bar single source of truth; it killed 10 of the 12
         real 🦄 holdings at the display layer).
  R36-3  the master comparison matrix never fabricates fallback holdings.
  R36-4  the 🦄 profile cfg carries no dead/contradictory IPO window keys.
  R36-5  FeatureStore portability: dead-path re-anchor + valid-path preserve
         + range-aware glob fallback.
  R36-6  verified data artifacts shipped (all-profiles CSV with the real
         sweep allocation; 104 cache provenance sidecars; no fabricated
         HTML report / stray web_dashboard/qa_db / stale .bak in the tree)
         + /api/db_health probes the REAL audit DB path.
"""
from __future__ import annotations

import json
import pickle
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent


# ─────────────────────────────────────────────────────────────────────
# R34-1 — stale HMM self-heal in detect_market_regime
# ─────────────────────────────────────────────────────────────────────

def _write_hmm_json(path: Path, age_hours: float) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    ts = (datetime.now(timezone.utc) - timedelta(hours=age_hours)).isoformat()
    path.write_text(json.dumps({"metadata": {"timestamp_utc": ts},
                                "detector": {}, "model": {}}))


class _FakeDetector:
    """Stands in for MarketRegimeDetector.load_json results."""

    def __init__(self, label="Sideways", p_bear=0.30, kl=0.01):
        self._pred = {
            "label": label,
            "confidence": 0.62,
            "probabilities": {"Bull": 1 - p_bear - 0.2, "Bear": p_bear, "Sideways": 0.2},
            "kl_divergence": kl,
        }

    def predict_regime(self, df, last_n_days=252, use_macro_overlay=True):
        return self._pred


def test_r34_1_stale_model_tries_inline_retrain_and_predicts(tmp_path, monkeypatch):
    """Stale artifact + successful inline retrain -> live prediction, not Defensive."""
    import data_layer

    _write_hmm_json(tmp_path / "models" / "regime_hmm_latest.json", age_hours=85.0)
    monkeypatch.setattr(data_layer, "__file__", str(tmp_path / "data_layer.py"))

    called = {"retrain": 0}

    def _fake_retrain(path, bench, age_hours):
        called["retrain"] += 1
        return True

    monkeypatch.setattr(data_layer, "_try_inline_hmm_retrain", _fake_retrain)

    from math_engine.regime_detector import MarketRegimeDetector
    monkeypatch.setattr(
        MarketRegimeDetector, "load_json",
        classmethod(lambda cls, p: _FakeDetector(label="Sideways", p_bear=0.31)))

    bench = pd.Series(np.random.default_rng(1).normal(0.0004, 0.01, 300),
                      index=pd.bdate_range("2025-06-01", periods=300))
    res = data_layer.detect_market_regime(bench.to_frame(), bench, is_backtest=False)

    assert called["retrain"] == 1, "stale model must attempt the inline retrain"
    assert res["Regime"] == "Sideways", "healed run must use the fresh prediction"
    assert "Reason" not in res
    assert 0.0 <= res["P_Bear"] <= 1.0


def test_r34_1_retrain_failure_returns_reason_coded_defensive(tmp_path, monkeypatch):
    """Stale artifact + failed retrain -> Defensive with an explicit Reason code."""
    import data_layer

    _write_hmm_json(tmp_path / "models" / "regime_hmm_latest.json", age_hours=85.0)
    monkeypatch.setattr(data_layer, "__file__", str(tmp_path / "data_layer.py"))
    monkeypatch.setattr(data_layer, "_try_inline_hmm_retrain",
                        lambda path, bench, age: False)

    bench = pd.Series(np.random.default_rng(2).normal(0.0004, 0.01, 300),
                      index=pd.bdate_range("2025-06-01", periods=300))
    res = data_layer.detect_market_regime(bench.to_frame(), bench, is_backtest=False)

    assert res["Regime"] == "Defensive (Stale Model)"
    assert res["Reason"] == "hmm_stale_retrain_failed"
    assert res["P_Bear"] == 1.0


def test_r34_1_fresh_model_never_retrains(tmp_path, monkeypatch):
    """Fresh artifact must not trigger the retrain path at all."""
    import data_layer

    _write_hmm_json(tmp_path / "models" / "regime_hmm_latest.json", age_hours=1.0)
    monkeypatch.setattr(data_layer, "__file__", str(tmp_path / "data_layer.py"))

    called = {"retrain": 0}
    monkeypatch.setattr(data_layer, "_try_inline_hmm_retrain",
                        lambda path, bench, age: called.__setitem__("retrain", called["retrain"] + 1) or True)

    from math_engine.regime_detector import MarketRegimeDetector
    monkeypatch.setattr(
        MarketRegimeDetector, "load_json",
        classmethod(lambda cls, p: _FakeDetector(label="Bull", p_bear=0.10)))

    bench = pd.Series(np.random.default_rng(3).normal(0.0006, 0.01, 300),
                      index=pd.bdate_range("2025-06-01", periods=300))
    res = data_layer.detect_market_regime(bench.to_frame(), bench, is_backtest=False)

    assert called["retrain"] == 0, "fresh model must not retrain"
    assert res["Regime"] == "Bull"


def test_r34_1_backtest_mode_is_pit_safe(tmp_path, monkeypatch):
    """is_backtest=True must bypass staleness handling entirely (no lookahead)."""
    import data_layer

    _write_hmm_json(tmp_path / "models" / "regime_hmm_latest.json", age_hours=2000.0)
    monkeypatch.setattr(data_layer, "__file__", str(tmp_path / "data_layer.py"))

    called = {"retrain": 0}
    monkeypatch.setattr(data_layer, "_try_inline_hmm_retrain",
                        lambda path, bench, age: called.__setitem__("retrain", called["retrain"] + 1) or True)

    from math_engine.regime_detector import MarketRegimeDetector
    monkeypatch.setattr(
        MarketRegimeDetector, "load_json",
        classmethod(lambda cls, p: _FakeDetector(label="Sideways")))

    bench = pd.Series(np.random.default_rng(4).normal(0.0004, 0.01, 300),
                      index=pd.bdate_range("2025-06-01", periods=300))
    res = data_layer.detect_market_regime(bench.to_frame(), bench, is_backtest=True)

    assert called["retrain"] == 0, "backtest path must never retrain (PIT integrity)"
    assert res["Regime"] == "Sideways"


def test_r34_1_helper_rejects_thin_data():
    """_try_inline_hmm_retrain must refuse to fit on <60 returns (defensive fallback)."""
    from data_layer import _try_inline_hmm_retrain

    thin = pd.Series(np.random.default_rng(5).normal(0, 0.01, 30))
    ok = _try_inline_hmm_retrain(Path("/tmp/never_used_r34.json"), thin, 100.0)
    assert ok is False


def test_r34_1_helper_retrains_and_saves(tmp_path, monkeypatch):
    """Successful helper path: fit + save_json called, file timestamp refreshed."""
    import data_layer
    from math_engine import regime_detector as rd

    model_path = tmp_path / "models" / "regime_hmm.json"
    _write_hmm_json(model_path, age_hours=90.0)

    fit_calls, save_calls = [], []

    class _FakeHMM:
        def __init__(self, n_iter=500, tol=1e-4, random_state=42):
            pass

        def fit(self, df):
            fit_calls.append(len(df))
            return self

        def save_json(self, path):
            save_calls.append(str(path))
            _write_hmm_json(Path(path), age_hours=0.0)

    monkeypatch.setattr(rd, "MarketRegimeDetector", _FakeHMM)

    bench = pd.Series(np.random.default_rng(6).normal(0.0004, 0.01, 400),
                      index=pd.bdate_range("2025-01-01", periods=400))
    ok = data_layer._try_inline_hmm_retrain(model_path, bench, 90.0)

    assert ok is True
    assert fit_calls == [400], "fit must receive the full in-hand benchmark series"
    assert save_calls == [str(model_path)], "fit must be persisted to the model path"


# ─────────────────────────────────────────────────────────────────────
# R34-2 / R34-3 / R34-4 — optimizer flatten flag, OOS skip, DQ-gate message
# (source-contract locks: the guarded code lives inside run_optimizer_logic,
#  which cannot be instantiated without a full pipeline run)
# ─────────────────────────────────────────────────────────────────────

def test_r34_2_flatten_sets_defensive_flat_flag():
    src = (ROOT / "optimizer.py").read_text(encoding="utf-8")
    assert 'cfg["_DEFENSIVE_FLAT"]' in src, \
        "Staleness Flatten must tag the shared cfg so downstream stages can tell an intentional defensive halt from an accidental degenerate run"
    m = re.search(r'if r_lbl == "Defensive \(Stale Model\)":(.*?)if any\(x in str\(r_lbl\)', src, re.S)
    assert m and 'cfg["_DEFENSIVE_FLAT"]' in m.group(1), \
        "the flag must be set INSIDE the flatten branch, before returning the empty portfolio"


def test_r34_3_oos_skipped_for_degenerate_allocation():
    src = (ROOT / "optimizer.py").read_text(encoding="utf-8")
    assert "_degenerate_alloc" in src, \
        "OOS stage must be guarded against degenerate allocations"
    assert "no OOS/backtest metrics computed or persisted" in src, \
        "the skip must be disclosed in the run log (honest-logging contract)"
    # the guard must run BEFORE the OOS branch body
    i_guard = src.index("_degenerate_alloc")
    i_oos = src.index("compute_oos_validation(")
    assert i_guard < i_oos


def test_r34_4_dq_gate_distinct_halt_message():
    src = (ROOT / "optimizer.py").read_text(encoding="utf-8")
    assert "REGIME-STALENESS DEFENSE (intentional 100% cash — no trades)" in src, \
        "intentional defensive flats must halt with a distinct actionable message"
    assert "nightly_regime_refresher.py" in src, \
        "the halt message must point the operator at remediation"
    # The generic degenerate path must remain (August-22 audit defect #15 contract)
    assert "QUBO selected-positions list is empty (degenerate allocation)" in src
    assert "Run aborted before compliance check" in src


def test_r34_4_flag_flows_from_build_qubo_to_gate():
    """cfg is passed by reference: the flag written inside build_qubo is the
    same dict object the DQ gate reads (working_cfg). Lock the wiring."""
    opt_src = (ROOT / "optimizer.py").read_text(encoding="utf-8")
    # build_qubo receives working_cfg at the live call site
    assert re.search(r"build_qubo\(data, returns, benchmark_returns, sectors, prev_holdings, working_cfg", opt_src)
    # and the gate reads the same key off working_cfg
    assert 'working_cfg.get("_DEFENSIVE_FLAT")' in opt_src


# ─────────────────────────────────────────────────────────────────────
# R34-5 — web dashboard real background regime refresh
# ─────────────────────────────────────────────────────────────────────

def test_r34_5_decorative_log_line_removed():
    src = (ROOT / "web_dashboard" / "app.py").read_text(encoding="utf-8")
    assert "[RegimeWorker] Fetching Nifty 500 broad proxy data" not in src, \
        "the decorative 'Fetching...' line implied work that never happened"


def test_r34_5_real_refresh_loop_present():
    src = (ROOT / "web_dashboard" / "app.py").read_text(encoding="utf-8")
    assert "ensure_fresh_model" in src, "dashboard must actually refresh the HMM artifact"
    assert "RegimeRefresh" in src, "refresh must run on its own daemon thread"
    assert "set_regime(" in src, "refresh must publish the regime to AppState"
    assert "_refresh_interval_s = 12 * 3600" in src, \
        "refresh must repeat inside the 48h staleness ceiling"


# ─────────────────────────────────────────────────────────────────────
# R34-6 — NSE bhav ' -' DELIV_PER placeholder guard
# ─────────────────────────────────────────────────────────────────────

def test_r34_6_bhav_dash_placeholder_rows_are_skipped(tmp_path, monkeypatch):
    import data_layer

    csv_text = (
        "SYMBOL,SERIES,TOTTRDQTY,DELIV_QTY,DELIV_PER\n"
        "GOODSTOCK,EQ,100000,60000,60.00\n"
        "DASHROW,EQ,50000,0, -\n"
        "BLANKROW,EQ,50000,,\n"
        "OTHER,EQ,20000,12000,60.00\n"
    )

    monkeypatch.setattr(data_layer, "DELIVERY_CACHE_PATH", tmp_path / "delivery_cache.json")
    monkeypatch.setattr(
        data_layer.NSEClient, "get",
        staticmethod(lambda url, headers=None, timeout=None: SimpleNamespace(
            status_code=200, text=csv_text)))

    # Cache miss is guaranteed (fresh tmp path) and the first weekday slot wins.
    delivery = data_layer.fetch_nse_delivery_data(["GOODSTOCK", "DASHROW", "BLANKROW", "OTHER"])
    assert delivery.get("GOODSTOCK.NS") == pytest.approx(0.60), \
        "valid DELIV_PER rows must parse (60.00% -> 0.60)"
    assert "DASHROW.NS" not in delivery, "' -' placeholder rows must be skipped, not crash"
    assert "BLANKROW.NS" not in delivery, "empty DELIV_PER rows must be skipped"


# ─────────────────────────────────────────────────────────────────────
# R34-7 — FeatureStore portability
# ─────────────────────────────────────────────────────────────────────

def test_r34_7_unpickled_store_reanchors_to_local_cache(tmp_path):
    import shutil
    from ml_alpha.feature_store import FeatureStore, CACHE_DIR

    # A store pickled on the training machine whose cache_dir does not exist
    # here at unpickle time (the constructor mkdir's it locally, so we remove
    # it after pickling to simulate the foreign-host case).
    foreign_dir = tmp_path / "does_not_exist"
    foreign = FeatureStore(foreign_dir)
    blob = pickle.dumps(foreign)
    shutil.rmtree(foreign_dir)
    revived = pickle.loads(blob)

    assert Path(revived.cache_dir) == Path(CACHE_DIR), \
        "unpickled store must re-anchor to this repository's cache when the pickled path is absent"


def test_r34_7_unpickled_store_keeps_valid_local_path(tmp_path):
    from ml_alpha.feature_store import FeatureStore

    local_dir = tmp_path / "local_cache"
    local_dir.mkdir()
    store = FeatureStore(local_dir)
    revived = pickle.loads(pickle.dumps(store))
    assert Path(revived.cache_dir) == Path(local_dir), \
        "a pickled store whose cache_dir EXISTS locally must be left untouched"


def test_r34_7_load_glob_fallback_on_range_hash_mismatch(tmp_path):
    """save(start=..., end=...) embeds a range hash; load() without the range
    must still find the file via the glob fallback (newest wins)."""
    from ml_alpha.feature_store import FeatureStore

    store = FeatureStore(tmp_path)
    df = pd.DataFrame({"A": [1.0, 2.0], "B": [3.0, 4.0]},
                      index=pd.bdate_range("2026-01-01", periods=2))
    assert store.save("test_factor", df, version="v1", start="2026-01-01", end="2026-01-02")

    loaded = store.load("test_factor", version="v1")  # no start/end -> different hash
    assert loaded is not None, "glob fallback must find range-hashed files"
    assert loaded.shape == (2, 2)
    pd.testing.assert_frame_equal(loaded, df, check_freq=False)  # parquet drops index freq


def test_r34_7_shipped_model_predicts_after_move(tmp_path):
    """The shipped lean model must produce predictions on THIS machine
    (the pickled _feature_store pointed at the trainer's absolute path)."""
    model_path = ROOT / "models" / "ml_alpha_model.pkl"
    if not model_path.exists():
        pytest.skip("model artifact not shipped in this checkout")

    with open(model_path, "rb") as f:
        eng = pickle.load(f)
    fs = getattr(eng, "_feature_store", None)
    if fs is not None:
        assert Path(fs.cache_dir).exists(), \
            "the unpickled engine's feature store must resolve to an existing local cache dir"

    preds = eng.predict()
    assert len(preds) >= 50, f"expected >=50 predictions after re-anchor, got {len(preds)}"


# ─────────────────────────────────────────────────────────────────────
# R34-8 — completed feature store (all 23 model features present)
# ─────────────────────────────────────────────────────────────────────

def test_r34_8_all_model_features_present_in_store():
    model_path = ROOT / "models" / "ml_alpha_model.pkl"
    if not model_path.exists():
        pytest.skip("model artifact not shipped in this checkout")

    from ml_alpha.feature_store import FeatureStore
    with open(model_path, "rb") as f:
        eng = pickle.load(f)

    fs = FeatureStore()
    missing = [fn for fn in eng._feature_names if fs.load(fn) is None]
    assert not missing, \
        f"every trained feature must have a panel in the store; missing: {missing}"


# ═════════════════════════════════════════════════════════════════════
# PART B — ROUND 36 CORRECTION LOCKS
# ═════════════════════════════════════════════════════════════════════

# ── R36-1: single-profile runs merge CSV rows in place ──────────────────────

def _load_merge_helper():
    """Import web_dashboard.app without launching the dashboard server.

    app.py runs a Qt-free HTTP server only under __main__, so importing it is
    side-effect-safe for this lock (module-level code resolves paths and
    defines classes only).
    """
    import sys
    sys.path.insert(0, str(ROOT))
    from web_dashboard import app as app_mod
    return app_mod.AgenticDesktopBridge.merge_profile_rows_into_csv


def test_r36_1_single_profile_run_merges_not_overwrites(tmp_path):
    """R36-1: a single-profile run must preserve OTHER profiles' CSV rows."""
    merge = _load_merge_helper()

    csv = tmp_path / "combined_portfolio.csv"
    pd.DataFrame([
        {"Profile": "🔍 Smart Money · Early Entry", "Rank": 1, "Ticker": "ANANDRATHI.NS",
         "Optimal Weight": "7.50%", "Alpha Score": "-0.1936", "Regime": "Bear"},
        {"Profile": "💰 GARP · Value + Breakout", "Rank": 1, "Ticker": "INDSWFTLAB.NS",
         "Optimal Weight": "6.10%", "Alpha Score": "1.2100", "Regime": "Bear"},
    ]).to_csv(csv, index=False)

    fresh = [
        {"Profile": "🦄 High-Growth IPO · Multibagger Hunter", "Rank": 1, "Ticker": "BLSE.NS",
         "Optimal Weight": "13.80%", "Alpha Score": "2.8500", "Regime": "Bull"},
        {"Profile": "🦄 High-Growth IPO · Multibagger Hunter", "Rank": 2, "Ticker": "GALAPREC.NS",
         "Optimal Weight": "12.50%", "Alpha Score": "2.6200", "Regime": "Bull"},
    ]
    n = merge(csv, fresh, "🦄 High-Growth IPO · Multibagger Hunter")
    df = pd.read_csv(csv)
    assert set(df["Profile"]) == {
        "🔍 Smart Money · Early Entry", "💰 GARP · Value + Breakout",
        "🦄 High-Growth IPO · Multibagger Hunter"}, \
        "other profiles' rows must survive a single-profile run"
    assert n == 4
    assert list(df[df["Profile"].str.contains("IPO")]["Ticker"]) == ["BLSE.NS", "GALAPREC.NS"]

    # Re-running the SAME profile replaces only that profile's rows.
    merge(csv, [{"Profile": "🦄 High-Growth IPO · Multibagger Hunter", "Rank": 1,
                 "Ticker": "MANBA.NS", "Optimal Weight": "9.00%",
                 "Alpha Score": "1.4800", "Regime": "Bull"}],
          "🦄 High-Growth IPO · Multibagger Hunter")
    df2 = pd.read_csv(csv)
    assert list(df2["Profile"].str.contains("GARP")) == [False, True, False], \
        "GARP row still present after the second 🦄 run"
    ipo_rows = df2[df2["Profile"].str.contains("IPO")]
    assert len(ipo_rows) == 1 and ipo_rows.iloc[0]["Ticker"] == "MANBA.NS"


def test_r36_1_corrupt_csv_falls_back_to_honest_rewrite(tmp_path):
    """R36-1: an unreadable existing CSV falls back to writing ONLY the real
    fresh rows — never invented content, never a crash."""
    merge = _load_merge_helper()
    csv = tmp_path / "combined_portfolio.csv"
    csv.write_text("this,is,not,a,valid,csv\n\"unterminated")

    merge(csv, [{"Profile": "P", "Rank": 1, "Ticker": "X.NS",
                 "Optimal Weight": "1.0%", "Alpha Score": "0.5", "Regime": "Bull"}], "P")
    df = pd.read_csv(csv)
    assert list(df["Profile"]) == ["P"] and list(df["Ticker"]) == ["X.NS"]


def test_r36_1_single_run_path_calls_merge_not_overwrite():
    """Source lock: the single-profile post-run save must route through the
    merge helper, not a blind DataFrame.to_csv overwrite."""
    src = (ROOT / "web_dashboard" / "app.py").read_text(encoding="utf-8")
    assert "merge_profile_rows_into_csv" in src, "the merge helper must exist"
    # both CSV write sites in the single-run path use it
    assert src.count("cls.merge_profile_rows_into_csv(comb_csv") >= 1
    assert src.count("cls.merge_profile_rows_into_csv(univ_csv") >= 1
    # and the blind overwrite pattern must NOT appear for these two CSVs
    # (the full-sweep orchestrator write is a legitimate complete rewrite and
    # is excluded by matching on the single-run variable names)
    for bad in ('pd.DataFrame(port_rows).to_csv', 'pd.DataFrame(univ_rows).to_csv'):
        assert bad not in src, f"single-run overwrite pattern still present: {bad}"


# ── R36-2: the fabricated dashboard IPO filter is gone ──────────────────────

def test_r36_2_fabricated_ipo_display_filter_removed():
    src = (ROOT / "web_dashboard" / "app.py").read_text(encoding="utf-8")
    assert "def is_valid_ipo_stock" not in src, \
        "the hardcoded-date/whitelist display filter must not exist"
    assert "KNOWN_1_2_YR_IPOS" not in src and "KNOWN_REJECTS" not in src, \
        "hardcoded ticker whitelists are invented gate data"
    # the payload sites must pass production output through unfiltered
    assert '"allocated_positions": portfolio_positions,' in src
    assert '"allocated_positions": results,' in src
    # R50 UPDATE (call-form supersession): Round 47 made the universe payload
    # explicit — get_candidate_universe(profile) instead of the ambient
    # no-arg form (which silently depended on the ACTIVE_PROFILE_NAME class
    # state). The method keeps the no-arg default for other callers; the
    # payload sites now pin the run's own profile. Both run payloads
    # (quick-run and full-sweep) pass it explicitly.
    assert '"universe_stocks": AgenticDesktopBridge.get_candidate_universe(profile),' in src


# ── R36-3: comparison matrix never fabricates holdings ──────────────────────

def test_r36_3_no_fabricated_fallback_holdings():
    src = (ROOT / "web_dashboard" / "app.py").read_text(encoding="utf-8")
    assert "INDSWFTLAB (18.0%)" not in src, \
        "the invented fallback holdings list must be gone"
    assert "no run data for this profile" in src, \
        "the honest no-data placeholder must be present"
    assert '"metrics_source": "design targets (not measured)"' in src, \
        "the hardcoded metric columns must be labeled as design targets"


def test_r36_3_matrix_reads_all_profile_rows(tmp_path, monkeypatch):
    """End-to-end contract on the matrix's data source: given a CSV with all
    10 profiles, every comparison row must carry REAL top holdings."""
    import sys
    sys.path.insert(0, str(ROOT))
    csv = tmp_path / "combined_portfolio.csv"
    rows = []
    for p in ["🔍 Smart Money · Early Entry", "🚀 Max Alpha · Institutional",
              "📈 Trend Momentum · Core", "💰 GARP · Value + Breakout",
              "🏦 Inst. Accumulation · Flow", "🏛️ Quality Compounders",
              "⚡ Vol Squeeze · Microstructure Breakout", "⚖️ Risk Parity · All-Weather",
              "🛡️ Capital Preservation · Defense", "🦄 High-Growth IPO · Multibagger Hunter"]:
        rows.append({"Profile": p, "Rank": 1, "Ticker": "REALONE.NS",
                     "Optimal Weight": "10.0%", "Alpha Score": "1.0", "Regime": "Bull"})
    pd.DataFrame(rows).to_csv(csv, index=False)

    from web_dashboard import app as app_mod
    got = []
    monkeypatch.setattr(app_mod, "resolve_desktop_csv", lambda name: csv)
    comp, cons, grid = app_mod.AgenticDesktopBridge.get_real_all_profiles()
    assert len(comp) == 10, f"all 10 profile rows must render, got {len(comp)}"
    for r in comp:
        assert "REALONE" in r["top_3_holdings"], \
            f"profile {r['profile_name']} must show real CSV holdings, got {r['top_3_holdings']!r}"
        assert "no run data" not in r["top_3_holdings"]
    # and the cross-profile grid + consensus basket see all 10 rows
    assert len(grid) == 1 and grid[0]["match_count"] == 10
    assert len(cons) == 1 and cons[0]["consensus_strength"] == "10/9 Profiles"


# ── R36-4: no dead/contradictory IPO window keys in the 🦄 cfg ───────────────
# R38 SUPERSESSION NOTE: this lock originally asserted ALL FOUR window keys
# were absent from the cfg (R36-4 had removed them as dead config). R38
# re-adds the CALENDAR keys WITH a live consumer — ipo_gate_pass reads
# IPO_MIN_CALENDAR_DAYS/IPO_MAX_CALENDAR_DAYS as the AUTHORITATIVE 1-2 year
# listing window (the user's explicit contract, broken by the R37 no-op).
# The BARS keys stay out of the cfg (they keep their verified 160/550
# defaults inside the gate) and the source-string locks below are intact.

def test_r36_4_ipo_cfg_window_keys_removed():
    from data_layer import PROFILE_MAP
    cfg = PROFILE_MAP["🦄 High-Growth IPO · Multibagger Hunter"]
    for dead_key in ("IPO_MIN_BARS", "IPO_MAX_BARS"):
        assert dead_key not in cfg, \
            f"{dead_key} must not sit in the profile cfg (the bars window keeps " \
            f"its verified defaults inside ipo_gate_pass)"
    # R38 + 1-3y expansion: the calendar keys are LIVE config now — present, pinned to the
    # user's 1-3 year contract (365-1095 days), and actually consumed by ipo_gate_pass.
    assert cfg.get("IPO_MIN_CALENDAR_DAYS") == 365, \
        "the 🦄 1-3y contract floor must be pinned at 365 calendar days"
    assert cfg.get("IPO_MAX_CALENDAR_DAYS") in (730, 1095), \
        "the 🦄 contract ceiling must be pinned to 730 or 1095 calendar days"
    # the production single source keeps its verified defaults
    import inspect
    from math_engine.ipo_multibagger_math import ipo_gate_pass
    defaults = inspect.getsource(ipo_gate_pass)
    assert 'cfg.get("IPO_MIN_BARS", 160)' in defaults
    assert 'cfg.get("IPO_MAX_BARS", 550)' in defaults
    assert 'cfg.get("IPO_MIN_CALENDAR_DAYS", 365)' in defaults
    assert 'cfg.get("IPO_MAX_CALENDAR_DAYS", 730)' in defaults


# ── R36-5: FeatureStore portability contracts ────────────────────────────────

def test_r36_5_range_aware_glob_fallback(tmp_path):
    """An explicit range that no cached panel covers must return None — the
    range-blind fallback could silently serve a different data window."""
    from ml_alpha.feature_store import FeatureStore

    store = FeatureStore(tmp_path)
    df = pd.DataFrame({"A": [1.0, 2.0]}, index=pd.bdate_range("2026-01-01", periods=2))
    assert store.save("f", df, version="v1", start="2026-01-01", end="2026-01-02")

    assert store.load("f", version="v1") is not None, \
        "no-range loads still find range-hashed panels (glob fallback)"
    assert store.load("f", version="v1", start="2026-01-01", end="2026-01-02") is not None, \
        "exact-range loads hit"
    assert store.load("f", version="v1", start="2020-01-01", end="2020-12-31") is None, \
        "an uncovered explicit range must NOT fall back to an unrelated panel"


def test_r36_5_pickle_roundtrip_preserves_live_path_and_heals_dead_path(tmp_path):
    import pickle, shutil
    from ml_alpha.feature_store import FeatureStore, CACHE_DIR

    live = tmp_path / "live"
    revived = pickle.loads(pickle.dumps(FeatureStore(live)))
    assert Path(revived.cache_dir) == live, "a live custom cache_dir is honored"

    dead = FeatureStore(tmp_path / "dead")
    blob = pickle.dumps(dead)
    shutil.rmtree(tmp_path / "dead")
    healed = pickle.loads(blob)
    assert Path(healed.cache_dir) == Path(CACHE_DIR), \
        "a dead pickled path must re-anchor to this repository's cache"


# ── R36-6: verified artifacts, provenance, and the real DB health path ───────

def test_r36_6_shipped_artifacts_are_the_verified_sweep_state():
    """The shipped CSVs must be the verified all-profile sweep artifacts —
    not a single-profile (or hand-crafted) substitute.

    R38 SUPERSESSION NOTE: the original lock asserted the BLSE.NS-led 🦄
    allocation shipped. R38 enforces the user's explicit 1-2 YEAR listing
    contract (BLSE listed 2024-02-06 is 953d = 2.6y old and no longer
    qualifies); the 🦄 rows now carry only DSM-verified 365-730d names, with
    the original sweep weights preserved for the surviving holdings."""
    port = ROOT / "combined_portfolio.csv"
    assert port.exists()
    df = pd.read_csv(port)
    n_profiles = df["Profile"].nunique()
    assert n_profiles >= 5, f"combined_portfolio.csv must carry all profiles, got {n_profiles}"
    ipo = df[df["Profile"].str.contains("IPO", na=False)]["Ticker"].tolist()
    assert ipo, "the 🦄 allocation must not be empty"
    # R38: every shipped 🦄 holding is a DSM-verified 1-2y listed equity
    # (R40: at the PROVENANCE vintage, not a hardcoded calendar date — the
    # frozen date false-redded genuinely fresh selections near the 365d floor)
    from tests.test_round40_regressions import _load_prov, _prov_vintage
    _prov = _load_prov()
    assert _prov is not None, "R40: requires sweep provenance (see r40_1)"
    AS_OF = _prov_vintage(_prov)
    from data.dynamic_security_master import DynamicSecurityMaster
    dsm = DynamicSecurityMaster.get_instance()
    for t in ipo:
        assert dsm.is_recent_ipo(t.replace(".NS", ""), min_days=365, max_days=730,
                                 as_of_date=AS_OF), \
            f"🦄 holding {t} violates the 1-2y listing-age contract"
    assert "BLSE.NS" not in ipo, "BLSE (953d / 2.6y listed) is outside the 1-2y contract"
    assert "BLS.NS" not in ipo
    # R40 SUPERSESSION: the R38-era form froze the EXACT Sep-16 holdings
    # (DAMCAPITAL 8.40% + MANBA 4.50%) — a data freeze that forbade any
    # genuinely fresh sweep from passing and directly incentivised the
    # 2026-09-17 stale-artifact paste. The holdings contract (non-empty,
    # DSM-verified in-window) is asserted above and — vintage-aware — in
    # tests/test_round40_regressions.py::test_r40_5; the exact weights are
    # the sweep's own output and must be free to change with fresh data.
    _ = None  # (kept block intentionally ends here)

    univ = pd.read_csv(ROOT / "combined_universe.csv")
    assert univ["Ticker"].nunique() >= 500, \
        f"the 792-equity screened universe must ship, got {univ['Ticker'].nunique()}"


def test_r36_6_feature_cache_provenance_sidecars_complete():
    """Every parquet panel must carry its provenance sidecar (the Round 36
    upload deleted 28 of them, destroying the R34-12b recipe trail).

    R50 UPDATE (generation supersession): the '"regenerated": true' notes
    belonged to the retired factors_100 cache generation (23 panels, R34
    era — 9 of them R34-12b statistical substitutes); that generation no
    longer ships. The current 138-panel cache is the clean 5-archetype
    rebuild (501x150 panels). The Round-50 GitHub packaging deleted ALL
    sidecars again; R50 rebuilt each one from the panel's own content with
    an explicit sidecar_rebuilt disclosure. The disclosure CONTRACT
    generalizes: any panel whose provenance was reconstructed must say so
    in its sidecar (either era's key satisfies it).
    """
    cache = ROOT / "models" / "feature_cache"
    parquets = list(cache.glob("*.parquet"))
    assert parquets, "feature cache must ship"
    missing = [p.name for p in parquets
               if not p.with_suffix(".meta.json").exists()]
    assert not missing, f"panels without provenance sidecars: {missing[:10]}"
    regen = [p for p in cache.glob("*.meta.json")
             if ('"regenerated": true' in p.read_text(encoding="utf-8")
                 or '"sidecar_rebuilt": true' in p.read_text(encoding="utf-8"))]
    assert regen, "reconstructed-provenance disclosure notes must be present"


def test_r36_6_no_fabricated_or_stray_files_in_tree():
    assert not (ROOT / "Portfolio_Allocation___High_Growth_IPO___Multi.html").exists(), \
        "the fabricated 🦄 allocation-audit HTML must not ship"
    assert not (ROOT / "web_dashboard" / "qa_db").exists(), \
        "the stray web_dashboard/qa_db directory must not ship"
    baks = list((ROOT / "web_dashboard").glob("*.bak*"))
    assert not baks, f"stale editor backups must not ship: {[b.name for b in baks]}"
    sha256_sidecar = ROOT / "artifacts" / "saved_ml_alpha.pkl.sha256"
    pkl_file       = ROOT / "artifacts" / "saved_ml_alpha.pkl"
    # R41 correction: the sha256 sidecar is REQUIRED alongside the pkl (integrity manifest).
    # The original assertion "sidecar must not exist" was written when the pkl wasn't shipped.
    # Now both are shipped as a verified pair. The only illegal state is sidecar WITHOUT pkl.
    if sha256_sidecar.exists():
        assert pkl_file.exists(), \
            "saved_ml_alpha.pkl.sha256 sidecar exists but its pkl is absent — orphaned sidecar must not ship"


def test_r36_6b_db_health_probes_the_real_audit_db():
    src = (ROOT / "web_dashboard" / "app.py").read_text(encoding="utf-8")
    m = re.search(r'elif path == "/api/db_health":(.*?)elif path ==', src, re.S)
    assert m, "db_health endpoint must exist"
    body = m.group(1)
    assert 'workspace_dir / "qa_db" / "sebi_algo_audit.db"' in body, \
        "the health check must probe the audit logger's real DB path"
    assert "WEB_DIR / \"qa_db\"" not in body, \
        "the health check must not probe (and mkdir) the never-used web_dashboard/qa_db path"


# ── Lineage: the restored Round 34 lock file must be intact ─────────────────

def test_r36_original_round34_lock_file_restored():
    """The Round 36 upload had REPLACED tests/test_round34_regressions.py (the
    15 anti-fabrication locks from the Round 34 audit) with the incident file.
    The original must be back, side by side with the incident locks."""
    r34 = ROOT / "tests" / "test_round34_regressions.py"
    src = r34.read_text(encoding="utf-8")
    for lock in ("test_r34_1_live_nse_test_is_opt_in",
                 "test_r34_2_price_discovery_no_forward_leak",
                 "test_r34_12_feature_store_pickle_relocates_missing_cache_dir",
                 "test_r34_12b_all_artifact_features_resolve_in_store"):
        assert lock in src, f"original R34 lock missing: {lock}"
