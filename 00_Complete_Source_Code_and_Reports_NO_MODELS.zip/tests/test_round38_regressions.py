"""Round 38 regression locks — the 1-2 YEAR listing-age contract.

User contract (verbatim intent): "i specifically asked for 1-2 year listed
stocks in the 🦄 High-Growth IPO · Multibagger Hunter."

R37 state being locked against (all found in the 2026-09-16 02:16 upload):
  * ipo_gate_pass referenced ``age_days`` BEFORE assignment inside a bare
    ``except: pass`` — the DSM listing-age cross-check was a silent NO-OP.
  * web_dashboard.is_disqualified_ipo_stock hardcoded ``age > 1000`` while
    accepting (and ignoring) a ``max_days=730`` parameter; age=None passed.
  * A second display path used ``age > 1000`` with no floor at all.
  * The universe CSV shipped 31 🦄 names of which only 10 were 365-730d old
    (20 mature up to 1,167d; 1 unseasoned at 351d).
  * get_candidate_universe's combined_universe fallback referenced
    clean_sym on the non-IPO path before assignment (NameError swallowed by
    the outer except, or worse: stale-symbol price resolution).

All locks pin as_of_date=2026-09-16 against the shipped DSM cache, so the
suite is fully deterministic and hermetic.
"""

import datetime
import inspect
from pathlib import Path

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
AS_OF = datetime.date(2026, 9, 16)

# ── R38-1: the production gate enforces the 365-730d window ─────────────────

def test_r38_1_gate_window_both_bounds_on_real_dsm_ages():
    from math_engine.ipo_multibagger_math import ipo_gate_pass
    cfg = {"REQUIRE_BASE_FORMATION": False}
    base = {"adv20": 50_000_000.0, "pct_below_52w_high": 0.10,
            "market_cap_cr": 1500.0, "bars_count": 350}

    # in-window survivors (real listing dates from the shipped DSM cache)
    for sym, age in (("DAMCAPITAL", 628), ("KRN", 713), ("MANBA", 716),
                     ("ARKADE", 722), ("BAJAJHFL", 730)):
        ok, why = ipo_gate_pass({**base, "ticker": f"{sym}.NS"}, cfg,
                                expected_days=504, as_of_date=AS_OF)
        assert ok is True, f"{sym} ({age}d, in-window) must pass: {why}"

    # mature (> 730d) — INCLUDING the 731-1000d band the R37 code leaked
    for sym, age in (("GALAPREC", 737), ("ORIENTTECH", 749), ("INTERARCH", 751),
                     ("UNIECOM", 764), ("AVANTEL", 777), ("BLSE", 953),
                     ("EPACK", 960), ("EMSLIMITED", 1091), ("YATHARTH", 1136),
                     ("IDEAFORGE", 1167)):
        ok, why = ipo_gate_pass({**base, "ticker": f"{sym}.NS"}, cfg,
                                expected_days=504, as_of_date=AS_OF)
        assert ok is False, f"{sym} ({age}d, mature) must be rejected"
        assert "730" in (why or ""), f"{sym} rejection must cite the 730d ceiling: {why}"

    # unseasoned (< 365d)
    ok, why = ipo_gate_pass({**base, "ticker": "ARSSBL.NS"}, cfg,
                            expected_days=504, as_of_date=AS_OF)
    assert ok is False and "365" in (why or ""), \
        f"ARSSBL (351d) must be rejected by the 365d floor: {why}"


def test_r38_1_gate_fail_closed_on_unverifiable_tickers():
    from math_engine.ipo_multibagger_math import ipo_gate_pass
    cfg = {"REQUIRE_BASE_FORMATION": False}
    base = {"adv20": 50_000_000.0, "pct_below_52w_high": 0.10,
            "market_cap_cr": 1500.0, "bars_count": 350}
    ok, why = ipo_gate_pass({**base, "ticker": "PHANTOM_R38.NS"}, cfg,
                            expected_days=504, as_of_date=AS_OF)
    assert ok is False, "phantom ticker must be rejected, not waved through"
    assert "security master" in (why or "")

    # a DSM-active name whose listing date cannot be parsed is ALSO rejected
    from data.dynamic_security_master import DynamicSecurityMaster
    dsm = DynamicSecurityMaster.get_instance()
    real = dsm._active_equities  # INSTANCE state (initialize() shadows the class attr)
    saved = real.get("DAMCAPITAL")
    assert saved is not None, "DAMCAPITAL must be present in the shipped DSM cache"
    try:
        real["DAMCAPITAL"] = {**saved, "listing_date": "NOT-A-DATE"}
        dsm._resolved_cache.pop("DAMCAPITAL", None)
        ok, why = ipo_gate_pass({**base, "ticker": "DAMCAPITAL.NS"}, cfg,
                                expected_days=504, as_of_date=AS_OF)
        assert ok is False and "fail-closed" in (why or ""), \
            f"unparseable listing date must be a disclosed fail-closed reject: {why}"
    finally:
        real["DAMCAPITAL"] = saved
        dsm._resolved_cache.pop("DAMCAPITAL", None)


def test_r38_1_gate_no_bare_except_and_no_1000_day_escape():
    """The R37 no-op mechanics must never come back."""
    from math_engine import ipo_multibagger_math as m
    src = inspect.getsource(m.ipo_gate_pass)
    assert "except Exception:\n                pass" not in src, \
        "the bare except-pass that swallowed the R37 NameError is forbidden"
    assert "1000" not in src, "no 1000-day window may appear in the gate"
    assert "as_of_date" in src, "the gate must accept a pinned as_of_date"
    # the NameError itself: age_days must be assigned before use
    assert "age_days = dsm.get_listing_age_days(" in src


def test_r38_1_gate_cfg_keys_are_live():
    from math_engine.ipo_multibagger_math import ipo_gate_pass
    base = {"adv20": 50_000_000.0, "pct_below_52w_high": 0.10,
            "market_cap_cr": 1500.0, "bars_count": 350, "ticker": "BLSE.NS"}
    assert ipo_gate_pass(base, {"REQUIRE_BASE_FORMATION": False,
                                "IPO_MAX_CALENDAR_DAYS": 730},
                         expected_days=504, as_of_date=AS_OF)[0] is False
    assert ipo_gate_pass(base, {"REQUIRE_BASE_FORMATION": False,
                                "IPO_MAX_CALENDAR_DAYS": 1000},
                         expected_days=504, as_of_date=AS_OF)[0] is True
    assert ipo_gate_pass(base, {"REQUIRE_BASE_FORMATION": False,
                                "IPO_MIN_CALENDAR_DAYS": 1000},
                         expected_days=504, as_of_date=AS_OF)[0] is False


# ── R38-2: DynamicSecurityMaster single-source contracts ────────────────────

def test_r38_2_is_recent_ipo_bounds_and_no_extended_window():
    from data.dynamic_security_master import DynamicSecurityMaster
    dsm = DynamicSecurityMaster.get_instance()
    assert dsm.is_recent_ipo("KRN", as_of_date=AS_OF) is True
    assert dsm.is_recent_ipo("BLSE", as_of_date=AS_OF) is False
    assert dsm.is_recent_ipo("ARSSBL", as_of_date=AS_OF) is False
    assert dsm.is_recent_ipo("PHANTOM_R38", as_of_date=AS_OF) is False
    # boundary inclusivity at exactly 365 / 730
    assert dsm.is_recent_ipo("KRN", min_days=713, max_days=713, as_of_date=AS_OF) is True
    # the escape hatch is gone from the signature entirely
    sig = inspect.signature(DynamicSecurityMaster.is_recent_ipo)
    assert "allow_extended_window" not in sig.parameters, \
        "the 1000-day allow_extended_window hatch contradicts the contract"


def test_r38_2_resolved_cache_cleared_on_resync():
    from data.dynamic_security_master import DynamicSecurityMaster
    dsm = DynamicSecurityMaster.get_instance()
    dsm._resolved_cache["STALE_R38"] = ["RELIAANCE"]  # poisoned entry
    called = {"n": 0}
    def _fake_sync():
        called["n"] += 1
        dsm._active_equities = dict(dsm._active_equities)  # new master state
        dsm._resolved_cache.clear()
        dsm._rebuild_indices()
        return True
    orig = dsm.sync_with_exchange_master
    try:
        dsm.sync_with_exchange_master = _fake_sync
        dsm.sync_with_exchange_master()
        assert "STALE_R38" not in dsm._resolved_cache, \
            "a successful resync must clear stale resolutions"
    finally:
        dsm.sync_with_exchange_master = orig


def test_r38_2_get_listing_age_days_deterministic_pin():
    from data.dynamic_security_master import DynamicSecurityMaster
    dsm = DynamicSecurityMaster.get_instance()
    assert dsm.get_listing_age_days("KRN", as_of_date=AS_OF) == 713
    assert dsm.get_listing_age_days("BLSE", as_of_date=AS_OF) == 953
    assert dsm.get_listing_age_days("DAMCAPITAL", as_of_date=AS_OF) == 628


# ── R38-3: dashboard display layer delegates — no ad-hoc windows ────────────

def test_r38_3_app_disqualification_delegates_to_single_source():
    import ast
    src = (ROOT / "web_dashboard" / "app.py").read_text(encoding="utf-8")
    # Walk the AST and collect every COMPARISON node — docstrings/comments
    # (where the R37 bug is documented) cannot trigger false positives.
    tree = ast.parse(src)
    thousand_comparisons = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Compare):
            for comp in node.comparators:
                if isinstance(comp, ast.Constant) and comp.value == 1000:
                    thousand_comparisons.append(node.lineno)
    assert not thousand_comparisons, \
        f"no live comparison against 1000 may remain in app.py: lines {thousand_comparisons}"
    # the delegation calls are present
    assert src.count("dsm.is_recent_ipo(") >= 2, \
        "both display paths must use the DSM single source"
    assert "dsm.is_recent_ipo(can, min_days=min_days, max_days=max_days)" in src
    # the gate segment (function body) contains the delegation
    seg_start = src.index("def is_disqualified_ipo_stock(")
    seg_end = src.index("# If a specific profile is active", seg_start)
    seg = src[seg_start:seg_end]
    assert "dsm.is_recent_ipo(can, min_days=min_days, max_days=max_days)" in seg


def test_r38_3_clean_sym_assigned_before_use_in_universe_fallback():
    """The R37 NameError/stale-symbol block in get_candidate_universe's third
    fallback: clean_sym must be assigned unconditionally BEFORE the is_ipo
    branch that rebinds it."""
    src = (ROOT / "web_dashboard" / "app.py").read_text(encoding="utf-8")
    anchor = 'if not sym or sym == "CASH" or sym == "nan" or sym in seen:'
    i = src.index(anchor)
    seg = src[i:i + 900]
    assign_pos = seg.index('clean_sym = sym.replace')
    ipo_pos = seg.index("if is_ipo:")
    assert assign_pos < ipo_pos, \
        "clean_sym must be assigned for EVERY row before the is_ipo branch"
    # and the ₹100.0 dummy fallback is gone from that block entirely
    assert "else 100.0" not in seg


def test_r38_3_verified_prices_cover_the_in_window_universe():
    from web_dashboard.app import DynamicPriceResolver
    for sym in ("DAMCAPITAL.NS", "MANBA.NS", "BAJAJHFL.NS", "KRN.NS", "KROSS.NS",
                "WCIL.NS", "DIFFNKG.NS", "TOLINS.NS", "NORTHARC.NS", "ARKADE.NS"):
        px = DynamicPriceResolver.get(sym)
        assert px > 0 and px != 100.0, f"{sym} must resolve a real price, got {px}"


# ── R38-4: the shipped artifacts satisfy the contract ───────────────────────

def test_r38_4_universe_and_portfolio_are_in_window():
    """R40 SUPERSESSION: the R38 form froze the EXACT Sep-16 vintage (exactly
    10 names, exactly DAMCAPITAL+MANBA, exactly 8.40%/4.50%) — which FORBADE
    any genuinely fresh sweep from passing and directly incentivised the
    2026-09-17 stale-artifact paste. The CONTRACT (every 🦄 row in the
    365-730d window, non-empty, well-formed) is unchanged but is now
    evaluated at the PROVENANCE vintage; the vintage-aware authority lives
    in tests/test_round40_regressions.py::test_r40_5. This lock keeps the
    R38 structural expectations that are vintage-free."""
    from tests.test_round40_regressions import (
        _load_prov, _prov_vintage, UNICORN_KEY,
    )
    prov = _load_prov()
    assert prov is not None, (
        "R40: the shipped artifacts carry no sweep provenance — regenerate on "
        "the trading machine (Run All Profiles) and re-ship; see r40_1"
    )
    as_of = _prov_vintage(prov)
    from data.dynamic_security_master import DynamicSecurityMaster
    dsm = DynamicSecurityMaster.get_instance()
    u = pd.read_csv(ROOT / "combined_universe.csv")
    ipo_u = u[u["Profile"].astype(str).str.contains("IPO", na=False)]
    assert len(ipo_u) > 0, "the 🦄 universe must not be empty (re-run the sweep)"
    for t in ipo_u["Ticker"]:
        assert dsm.is_recent_ipo(t.replace(".NS", ""), min_days=365, max_days=730,
                                 as_of_date=as_of), \
            f"{t} is out of the 1-2y window at the recorded vintage {as_of}"
    # ranks are contiguous 1..N ordered by score
    assert ipo_u["Rank"].tolist() == list(range(1, len(ipo_u) + 1))
    scores = ipo_u["AvgScore"].astype(float).tolist()
    assert scores == sorted(scores, reverse=True)

    p = pd.read_csv(ROOT / "combined_portfolio.csv")
    ipo_p = p[p["Profile"].astype(str).str.contains("IPO", na=False)]
    assert len(ipo_p) > 0, "the 🦄 allocation must not be empty (re-run the sweep)"
    for t in ipo_p["Ticker"]:
        assert dsm.is_recent_ipo(t.replace(".NS", ""), min_days=365, max_days=730,
                                 as_of_date=as_of), \
            f"holding {t} is out of the 1-2y window at the recorded vintage {as_of}"


def test_r38_4_no_out_of_window_unicorn_rows_anywhere():
    """R40 SUPERSESSION: as_of now comes from the provenance vintage (the
    R38 form hardcoded 2026-09-16, another freeze that forbade fresh data)."""
    from data.dynamic_security_master import DynamicSecurityMaster
    from tests.test_round40_regressions import _load_prov, _prov_vintage
    prov = _load_prov()
    assert prov is not None, "R40: requires sweep provenance (see r40_1)"
    as_of = _prov_vintage(prov)
    dsm = DynamicSecurityMaster.get_instance()
    for fname in ("combined_breakout.csv", "combined_prebreakout.csv",
                  "post_screening_intelligence.csv"):
        d = pd.read_csv(ROOT / fname)
        unicorn_rows = d[d.apply(lambda r: any("🦄" in str(v) for v in r.astype(str)), axis=1)]
        for t in unicorn_rows["Ticker"]:
            assert dsm.is_recent_ipo(str(t).replace(".NS", ""), min_days=365,
                                     max_days=730, as_of_date=as_of), \
                f"{fname}: 🦄 row {t} violates the 1-2y window at vintage {as_of}"


# ── R38-5: build marker ──────────────────────────────────────────────────────

def test_r38_5_build_marker_bumped():
    src = (ROOT / "web_dashboard" / "app.py").read_text(encoding="utf-8")
    assert src.startswith("#") or True  # file may start with comments
    # R39-AUDIT SUPERSESSION: the R38 form demanded the contiguous substring
    # "R36-R37-R38-SOVEREIGN-TIER-OMEGA", which freezes the marker's tail and
    # fails the moment any later round legitimately appends itself. The lock's
    # intent is that the marker CARRIES THE R38 ROUND — now asserted on the
    # version chain including R38 plus the R38 narrative, while permitting the
    # R39-audit extension ("R38-R39-SOVEREIGN-TIER-OMEGA") shipped on top.
    assert "R38" in src, "the build marker must carry the R38 round"
    assert "SOVEREIGN-TIER-OMEGA" in src, "the build marker must keep its tier chain"
    assert "Round 38" in src
    assert "Round 39 AUDIT" in src, "the R39-audit round must be recorded in the marker"
