"""Round 40 regression locks — artifact provenance & the anti-paste contract.

Forensic motive (the 2026-09-17 "Round39_Audit_Verified" ship): that zip
carried a Portfolio_Allocation_Report.html from the 02:16 regeneration
sweep (9 profiles, zero unicorn rows after a vendor throttle killed the
🦄 profile) next to combined_portfolio.csv / combined_universe.csv rows
pasted in from the Sep-16 R38 dev-machine artifacts (10 profiles, 2 unicorn
holdings — 776 non-unicorn rows bit-identical to the R37 ship, survivor
scores and weights exactly the R37 values, all three CSVs written in the
same 2-second window 4h15m AFTER the sweep). The entire project lock suite
passed because NO lock bound an artifact to the run that produced it, and
three R38-era locks (r38_4, r36_6 weight pins, ipo_holdings must-ship pins)
actively FORBADE fresh data by freezing the exact Sep-16 vintage.

R40 closes the class:
  * R40-1  every sweep / single-profile run writes qa_db/sweep_provenance.json
           binding all shipped artifacts with sha256
  * R40-2  the allocation HTML carries its producing run's id (meta + footer)
           and its profile roster must equal the CSV's
  * R40-3  the sweep fail-tally counts exceptions (the 02:16 sweep reported
           "9/10 succeeded, 0 failed" with the 10th profile hard-failed)
  * R40-4  the 🦄 profile runs FIRST (it was rate-starved to death running last)
  * R40-5  the 365-730d listing-age contract is enforced at the PROVENANCE
           VINTAGE (supersedes the frozen as_of=2026-09-16 artifact pins)
  * R40-6  hermetic writer unit tests (tamper detection, single-profile append)

The three data-state locks (r40_1 / r40_2 roster / r40_5) FAIL on the
current ship BY DESIGN — the shipped artifacts are not provenance-bound.
They go green only after a genuine sweep regenerates them on the trading
machine (the same intentional-red pattern the R39 audit used for the
missing-artifact locks).
"""

import re
from datetime import date
from pathlib import Path

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
UNICORN_KEY = "🦄 High-Growth IPO · Multibagger Hunter"


def _load_prov():
    from web_dashboard.app import load_sweep_provenance
    return load_sweep_provenance()


def _prov_vintage(prov: dict) -> date:
    """The newest recorded data touch (full sweep or single-profile run)."""
    dates = [prov.get("as_of_date")] + [
        e.get("as_of_date") for e in prov.get("single_profile_runs", [])
    ]
    parsed = [date.fromisoformat(d) for d in dates if d]
    assert parsed, "provenance carries no as_of_date"
    return max(parsed)


# ── R40-1: provenance existence + cryptographic binding ─────────────────────

def test_r40_1_sweep_provenance_exists_and_binds_artifacts():
    prov = _load_prov()
    assert prov is not None, (
        "qa_db/sweep_provenance.json is MISSING — the shipped artifacts are not "
        "bound to any recorded pipeline run. This is the exact state that let the "
        "2026-09-17 'Audit Verified' ship pass every lock while carrying pasted "
        "stale CSVs. Regenerate the artifacts on the trading machine (Run All "
        "Profiles — the 🦄 now runs first) and re-ship; never hand-place CSVs."
    )
    from web_dashboard.app import _qa_sha256_file
    mismatches, missing = [], []
    for name, meta in (prov.get("artifacts") or {}).items():
        if not meta.get("present"):
            continue
        cur = _qa_sha256_file(ROOT / name)
        if cur is None:
            missing.append(name)
        elif cur != meta.get("sha256"):
            mismatches.append(name)
    assert not missing, f"recorded artifacts unreadable: {missing}"
    assert not mismatches, (
        f"artifacts modified after the recorded run (hand-paste or hand-edit "
        f"detected): {mismatches}"
    )


def test_r40_1_csv_profiles_traceable_to_recorded_runs():
    prov = _load_prov()
    assert prov is not None, "requires sweep provenance (see r40_1 binding lock)"
    port = pd.read_csv(ROOT / "combined_portfolio.csv")
    csv_profiles = set(port["Profile"].astype(str))
    sweep_ok = {p for p, s in (prov.get("profiles") or {}).items()
                if isinstance(s, dict) and s.get("status") == "success"}
    sp_runs = {e.get("profile") for e in prov.get("single_profile_runs", [])}
    untraceable = csv_profiles - sweep_ok - sp_runs
    assert not untraceable, (
        f"combined_portfolio.csv carries rows for profiles no recorded run "
        f"produced (unknown-origin artifact / paste detected): {sorted(untraceable)}"
    )


# ── R40-2: the allocation HTML identifies its run and mirrors the CSV ───────

def test_r40_2_allocation_html_carries_a_recorded_runid():
    html_path = ROOT / "Portfolio_Allocation_Report.html"
    assert html_path.exists(), "the allocation HTML report must ship"
    html = html_path.read_text(encoding="utf-8", errors="replace")
    m = re.search(r'<meta name="qa-run-id" content="([^"]+)"', html)
    assert m, (
        "Portfolio_Allocation_Report.html carries no qa-run-id stamp — it "
        "predates R40 (or was produced by an unrecorded run) and cannot be "
        "verified against the provenance sidecar"
    )
    prov = _load_prov()
    assert prov is not None, "requires sweep provenance (see r40_1 binding lock)"
    stamped = m.group(1)
    recorded = {prov.get("run_id"), prov.get("last_writer", {}).get("run_id")}
    recorded |= {e.get("run_id") for e in prov.get("single_profile_runs", [])}
    recorded.discard(None)
    assert stamped in recorded, (
        f"the HTML's run-id stamp '{stamped}' matches NO recorded run "
        f"(recorded: {sorted(recorded)})"
    )


def test_r40_2_html_and_csv_profile_rosters_agree():
    """THE frankenstein catcher: the 2026-09-17 ship carried a 9-profile HTML
    (from the fresh sweep) next to a 10-profile CSV (pasted stale rows)."""
    from data_layer import PROFILE_MAP
    html_path = ROOT / "Portfolio_Allocation_Report.html"
    assert html_path.exists(), "the allocation HTML report must ship"
    html = html_path.read_text(encoding="utf-8", errors="replace")
    csv_profiles = set(pd.read_csv(ROOT / "combined_portfolio.csv")["Profile"].astype(str))
    html_profiles = {p for p in PROFILE_MAP if p in html}
    assert html_profiles == csv_profiles, (
        f"the allocation HTML roster {sorted(html_profiles)} and "
        f"combined_portfolio.csv roster {sorted(csv_profiles)} disagree — "
        f"mixed-vintage artifacts (one of them is NOT from the latest run)"
    )


# ── R40-3: the sweep fail-tally counts exceptions ────────────────────────────

def test_r40_3_sweep_fail_tally_counts_exceptions():
    """The 02:16:31 sweep logged '9/10 succeeded, 0 failed' while the 10th
    profile had hard-failed with a RuntimeError — the exception path escaped
    both tallies (the P0-6 fix only covered the returned-degenerate path)."""
    src = (ROOT / "web_dashboard" / "app.py").read_text(encoding="utf-8")
    anchor = "except Exception as p_err:"
    i = src.index(anchor)
    handler = src[i:i + 900]
    assert "_n_fail += 1" in handler, (
        "the sweep-worker exception handler must increment the failure tally"
    )
    assert '"status": "failed"' in handler, (
        "the exception handler must record a failed per-profile provenance entry"
    )


# ── R40-4: the 🦄 profile runs FIRST in the sweep ────────────────────────────

def test_r40_4_unicorn_profile_runs_first_in_sweep():
    from data_layer import PROFILE_MAP
    keys = list(PROFILE_MAP.keys())
    assert keys and keys[0] == UNICORN_KEY, (
        f"the 🦄 profile must run FIRST (vendor-rate-budget priority); it "
        f"currently runs at position {keys.index(UNICORN_KEY) + 1 if UNICORN_KEY in keys else 'ABSENT'}"
    )


# ── R40-5: the 365-730d contract at the PROVENANCE VINTAGE ───────────────────

def test_r40_5_unicorn_window_contract_at_provenance_vintage():
    """SUPERSEDES the frozen as_of=2026-09-16 artifact pins (r38_4's
    exact-10/exact-2/exact-weights and ipo_holdings' must-ship DAMCAPITAL/
    MANBA): those locks FORBADE fresh data and created the incentive to
    paste the stale Sep-16 artifacts. The contract itself is unchanged and
    non-negotiable — every shipped 🦄 row must be a DSM-verified 365-730d
    listed equity — evaluated at the vintage the provenance records."""
    prov = _load_prov()
    assert prov is not None, (
        "requires sweep provenance (see r40_1 binding lock) — the window "
        "contract cannot be evaluated against an unbound artifact set"
    )
    as_of = _prov_vintage(prov)
    from data.dynamic_security_master import DynamicSecurityMaster
    dsm = DynamicSecurityMaster.get_instance()

    u = pd.read_csv(ROOT / "combined_universe.csv")
    ipo_u = u[u["Profile"].astype(str).str.contains("IPO", na=False)]
    assert len(ipo_u) > 0, "the 🦄 universe must not be empty (re-run the sweep)"
    for t in ipo_u["Ticker"]:
        assert dsm.is_recent_ipo(str(t).replace(".NS", ""), min_days=365,
                                 max_days=730, as_of_date=as_of), \
            f"universe row {t} violates the 1-2y window at the recorded vintage {as_of}"
    # structural: contiguous ranks, descending scores (vintage-free)
    ranks = ipo_u["Rank"].tolist()
    assert ranks == list(range(1, len(ranks) + 1)), "universe ranks must be contiguous 1..N"
    scores = ipo_u["AvgScore"].astype(float).tolist()
    assert scores == sorted(scores, reverse=True), "universe scores must be descending"

    p = pd.read_csv(ROOT / "combined_portfolio.csv")
    ipo_p = p[p["Profile"].astype(str).str.contains("IPO", na=False)]
    assert len(ipo_p) > 0, "the 🦄 allocation must not be empty (re-run the sweep)"
    for t in ipo_p["Ticker"]:
        assert dsm.is_recent_ipo(str(t).replace(".NS", ""), min_days=365,
                                 max_days=730, as_of_date=as_of), \
            f"holding {t} violates the 1-2y window at the recorded vintage {as_of}"


# ── R40-6: hermetic writer unit tests ────────────────────────────────────────

def test_r40_6_provenance_writer_roundtrip_and_tamper_detection(tmp_path, monkeypatch):
    import web_dashboard.app as app_mod

    (tmp_path / "combined_universe.csv").write_text("Profile,Rank,Ticker,AvgScore\n", encoding="utf-8")
    (tmp_path / "combined_portfolio.csv").write_text("Profile,Rank,Ticker,Optimal Weight,Alpha Score,Regime\n", encoding="utf-8")
    monkeypatch.setattr(app_mod, "workspace_dir", tmp_path)

    stats = {UNICORN_KEY: {"status": "success", "selected": 2, "universe": 10,
                           "run_id": "qa_unit_sweep_1"}}
    app_mod.write_sweep_provenance("unit_test", "qa_unit_sweep_1", stats)
    prov = app_mod.load_sweep_provenance()
    assert prov and prov["run_id"] == "qa_unit_sweep_1"
    assert prov["artifacts"]["combined_universe.csv"]["sha256"]
    assert prov["artifacts"]["Portfolio_Allocation_Report.html"]["present"] is False

    # tamper: append a byte to a bound artifact -> recomputed hash must differ
    with open(tmp_path / "combined_universe.csv", "a", encoding="utf-8") as fh:
        fh.write("🦄,1,TAMPER.NS,9.99\n")
    from web_dashboard.app import _qa_sha256_file
    assert _qa_sha256_file(tmp_path / "combined_universe.csv") != \
        prov["artifacts"]["combined_universe.csv"]["sha256"], \
        "tampering a bound artifact must break the recorded sha256"


def test_r40_6_single_profile_provenance_appends_and_rebinds(tmp_path, monkeypatch):
    import web_dashboard.app as app_mod

    (tmp_path / "combined_universe.csv").write_text("Profile,Rank,Ticker,AvgScore\n", encoding="utf-8")
    monkeypatch.setattr(app_mod, "workspace_dir", tmp_path)

    app_mod.write_sweep_provenance("unit_test", "qa_unit_sweep_1", {})
    app_mod.record_single_profile_run_provenance(UNICORN_KEY, "qa_unit_single_1")
    prov = app_mod.load_sweep_provenance()
    assert prov["last_writer"] == {"kind": "single_profile", "profile": UNICORN_KEY,
                                   "run_id": "qa_unit_single_1",
                                   "at": prov["last_writer"]["at"]}
    assert len(prov["single_profile_runs"]) == 1
    assert prov["single_profile_runs"][0]["profile"] == UNICORN_KEY
    assert prov["artifacts"]["combined_universe.csv"]["sha256"]


def test_r40_6_runid_html_wrapper_hermetic():
    from web_dashboard.app import generate_portfolio_allocation_html
    row = [{"Profile": "Unit Profile", "Rank": 1, "Ticker": "UNITTEST.NS",
            "Optimal Weight": "5.00%", "Alpha Score": "1.0000", "Regime": "Bull"}]
    stamped = generate_portfolio_allocation_html(row, title="UNIT", run_id="qa_unit_html_1")
    assert '<meta name="qa-run-id" content="qa_unit_html_1">' in stamped
    assert "qa_unit_html_1" in stamped.rsplit("</body>", 1)[0].rsplit("<body", 1)[-1], \
        "the run-id must also appear as a VISIBLE provenance footer"
    unstamped = generate_portfolio_allocation_html(row, title="UNIT")
    assert "qa-run-id" not in unstamped, "run_id=None must leave the document untouched"


# ── R40-7: the 🦄 defensive vendor-rate-limit auto-retry lock ────────────────

def test_r40_7_unicorn_rate_limit_auto_retry_lock():
    """GLM Task 11/12 standing note lock: the sweep worker must defensively
    retry an IPO/Multibagger run if it yields 0 candidates (vendor rate-limiting).
    The retry must cool down 5s, re-run once, and still fail honestly if empty."""
    src = (ROOT / "web_dashboard" / "app.py").read_text(encoding="utf-8")
    assert '("IPO" in pname or "Multibagger" in pname)' in src, (
        "the rate-limiting retry must check for IPO/Multibagger profile"
    )
    assert "(n_stocks == 0 and n_screened == 0)" in src, (
        "the retry must trigger strictly on total candidate starvation (0 screened / 0 selected)"
    )
    assert "time.sleep(5)" in src, (
        "the retry path must cool down for 5 seconds to bypass vendor throttling"
    )

