

"""tests/test_round41_audit_fixes.py
===================================
Verification tests for Claude Round 41 audit fixes:
1. Dead-code sweep: Verify the 17 confirmed dead files are removed from active tree.
2. RiskLimitEnforcer: Verify rule checks (max position, sector limit, min stocks).
3. Pre-trade compliance gate in MultiDematRouter: Blocks or halts on violations.
4. TelegramNotifier: Verify unified send_message interface handles different parse_modes.
5. Kalman filter ordering and CDaR normalization stability.
"""
import os
import unittest
import numpy as np
import pandas as pd


class TestRound41AuditFixes(unittest.TestCase):

    def test_dead_files_removed_from_active_tree(self):
        """Verify the confirmed dead files are removed from active math_engine/ and ml_alpha/.

        SUPERSEDED (GLM R41-verify): almgren_chriss_impact.py is NOT dead —
        tests/test_tier1_alpha_engine.py::TestAlmgrenChrissImpactModel unit-tests its
        math and tests/test_round35_regressions.py::TestR35HACPenalty uses it as the
        independent reference implementation cross-validating the production inline
        ac_turnover_penalty (an R35 equivalence lock). The R41 deletion broke 3 tests;
        the file is restored and removed from this dead-list. The other 16 deletions
        are verified test-safe (no test imports them).
        """
        active_math_dead = [
            "kerr_singularity.py", "susy_quantum_barrier.py", "timeline_spawner.py",
            "dark_energy_modulator.py", "ontological_erasure.py", "hive_mind_consensus.py",
            "zeno_lock.py", "reversible_compute.py", "holographic_memory.py", "anthropic_steerer.py"
        ]
        active_ml_dead = [
            "neural_hawkes.py", "variational_autoencoder.py", "bayesian_structural_ts.py",
            "reinforcement_q_learning.py", "self_healing_alpha.py", "trade_crowding.py",
        ]
        for f in active_math_dead:
            self.assertFalse(
                os.path.exists(os.path.join("math_engine", f)),
                f"Dead file math_engine/{f} should not exist in active tree"
            )
        for f in active_ml_dead:
            self.assertFalse(
                os.path.exists(os.path.join("ml_alpha", f)),
                f"Dead file ml_alpha/{f} should not exist in active tree"
            )

    def test_risk_limit_enforcer_rules(self):
        """Verify RiskLimitEnforcer detects position, sector, and diversification violations."""
        from utils import RiskLimitEnforcer
        cfg = {"RISK_MAX_POSITION": 0.15, "RISK_MAX_SECTOR": 0.35, "RISK_MIN_STOCKS": 4}
        enforcer = RiskLimitEnforcer(cfg)

        # Empty basket
        self.assertTrue(any("empty" in v.lower() for v in enforcer.check({})))

        # Too few stocks
        v_few = enforcer.check({"INFY.NS": 0.10, "TCS.NS": 0.10})
        self.assertTrue(any("too few stocks" in v.lower() for v in v_few))

        # Position size breach
        v_pos = enforcer.check({
            "INFY.NS": 0.25, "TCS.NS": 0.10, "RELIANCE.NS": 0.10, "HDFCBANK.NS": 0.10
        })
        self.assertTrue(any("25.0% > max 15%" in v for v in v_pos))

        # Sector concentration breach
        sectors = {
            "INFY.NS": "IT", "TCS.NS": "IT", "WIPRO.NS": "IT", "HCLTECH.NS": "IT"
        }
        v_sec = enforcer.check({
            "INFY.NS": 0.12, "TCS.NS": 0.12, "WIPRO.NS": 0.12, "HCLTECH.NS": 0.10
        }, sectors=sectors)
        self.assertTrue(any("sector 'it'" in v.lower() for v in v_sec))

    def test_multi_demat_router_pretrade_compliance_block(self):
        """Verify MultiDematRouter blocks order routing when pre-trade compliance fails."""
        from enterprise.connectors.unified_broker_gateway import (
            MultiDematRouter, AngelOneSmartAPIConnector
        )
        router = MultiDematRouter()
        conn = AngelOneSmartAPIConnector({"paper": True})
        router.register_connector("Paper1", conn, 1.0)

        # Orders that exceed position limits under strict config
        orders = [
            {"ticker": "RELIANCE.NS", "qty": 100, "side": "BUY", "price": 2950.0},
            {"ticker": "TCS.NS", "qty": 10, "side": "BUY", "price": 4200.0},
        ]
        strict_cfg = {"MAX_POSITION_PCT": 0.10, "MAX_WEIGHT": 0.10}
        res = router.route_rebalanced_basket(orders, cfg=strict_cfg, compliance_override=False)
        self.assertIn(res["status"], ("BLOCKED", "BREACH"))
        self.assertEqual(res["accounts_routed"], [])

    def test_telegram_notifier_unified_interface(self):
        """Verify TelegramNotifier.send_message handles invalid credentials safely without crashing."""
        from utils import TelegramNotifier
        # Should gracefully return False without raising exceptions
        ok = TelegramNotifier.send_message(
            bot_token="invalid_token", chat_id="invalid_cid", text="test message",
            parse_mode="HTML", timeout=1
        )
        self.assertFalse(ok)

    def test_kalman_pair_trading_predict_step_ordering(self):
        """Verify Kalman filter ordering uses P_pred = P + Q in gain and Joseph form."""
        from math_engine.kalman_pair_trading import KalmanPairTradingEngine
        t = np.linspace(0, 10, 100)
        p1 = 100.0 + np.sin(t) + np.random.normal(0, 0.1, 100)
        p2 = 50.0 + 0.5 * np.sin(t) + np.random.normal(0, 0.1, 100)
        res = KalmanPairTradingEngine.filter_pair_spread(p1, p2)
        self.assertIn("hedge_ratio_beta", res)
        self.assertIn("spread_zscore", res)
        self.assertIn("trade_signal", res)
        self.assertFalse(np.isnan(res["hedge_ratio_beta"]))

    def test_cdar_optimal_weights_robustness_on_failure(self):
        """Verify cdar_optimal_weights falls back safely and never divides by negative or zero."""
        from math_engine.institutional.cdar_optimization import cdar_optimal_weights
        R = np.random.normal(0.001, 0.02, (50, 4))
        w = cdar_optimal_weights(R, alpha=0.95)
        self.assertEqual(len(w), 4)
        self.assertAlmostEqual(float(np.sum(w)), 1.0, places=4)
        self.assertTrue(np.all(w >= 0.0))

    def test_evaluate_options_skew_warning_dict_chain(self):
        """Verify evaluate_options_skew_warning accepts dict option chain with chain_rows."""
        from optimizer_compliance import evaluate_options_skew_warning
        chain = {
            "chain_rows": [
                {"strike": 2500.0, "expiry": "2026-10-30", "option_type": "call", "last_price": 45.0},
                {"strike": 2500.0, "expiry": "2026-10-30", "option_type": "put", "last_price": 42.0},
                {"strike": 2400.0, "expiry": "2026-10-30", "option_type": "put", "last_price": 20.0},
            ]
        }
        # Should not raise AttributeError: 'dict' object has no attribute 'iterrows'
        res = evaluate_options_skew_warning("RELIANCE.NS", option_chain=chain, cfg={"SPOT_PRICE": 2500.0})
        self.assertIsInstance(res, bool)

    def test_copula_empirical_alias(self):
        """Verify EmpiricalTailDependenceEngine alias exists and matches CopulaTailDependenceEngine."""
        from math_engine.copula_tail_dependence import (
            CopulaTailDependenceEngine,
            EmpiricalTailDependenceEngine,
        )
        self.assertIs(EmpiricalTailDependenceEngine, CopulaTailDependenceEngine)

    def test_apply_all_compliance_sector_cap_config(self):
        """Verify apply_all_compliance honors ENABLE_SECTOR_CAP and SECTOR_LIMIT."""
        from optimizer_compliance import apply_all_compliance
        weights = {"TCS.NS": 0.40, "INFY.NS": 0.40, "CASH": 0.20}
        sector_map = {"TCS.NS": "IT", "INFY.NS": "IT"}

        # With sector cap 0.35 enabled
        res_capped = apply_all_compliance(
            weights, sector_map=sector_map,
            cfg={"MAX_STOCK_PCT": 0.50, "ENABLE_SECTOR_CAP": True, "SECTOR_LIMIT": 0.35}
        )
        it_total = res_capped.get("TCS.NS", 0) + res_capped.get("INFY.NS", 0)
        self.assertLessEqual(it_total, 0.35 + 1e-6)

        # With sector cap disabled
        res_uncapped = apply_all_compliance(
            weights, sector_map=sector_map,
            cfg={"MAX_STOCK_PCT": 0.50, "ENABLE_SECTOR_CAP": False}
        )
        it_uncapped_total = res_uncapped.get("TCS.NS", 0) + res_uncapped.get("INFY.NS", 0)
        self.assertGreater(it_uncapped_total, 0.35)

    def test_evt_copula_tail_pairwise_exceedance(self):
        """Verify EVTCopulaTailEngine reports non-zero tail dependence under common shock."""
        from math_engine.evt_copula_tail import EVTCopulaTailEngine
        np.random.seed(42)
        T, N = 500, 15
        mkt = np.random.randn(T, 1)
        ret_corr = 0.8 * mkt + 0.6 * np.random.randn(T, N)
        df = pd.DataFrame(ret_corr, columns=[f"S{i}" for i in range(N)])
        res = EVTCopulaTailEngine.estimate_extreme_joint_loss(df, alpha=0.05)
        self.assertIn("joint_tail_dependence_coefficient", res)
        # Pairwise exceedance should detect common-shock tail coupling (> 0.20, not 0.0)
        self.assertGreater(res["joint_tail_dependence_coefficient"], 0.20)

    def test_liquid_ode_steady_state_order_independence(self):
        """Verify Liquid Neural ODE steady_state_readout is row-order independent (§5h)."""
        from ml_alpha.liquid_neural_ode import LiquidNeuralODE
        np.random.seed(42)
        X = np.random.randn(20, 16)
        ode = LiquidNeuralODE(input_dim=16, hidden_dim=8)

        _, _, y_orig = ode.steady_state_readout(X)

        # Shuffle row ordering
        perm = np.random.permutation(20)
        _, _, y_perm = ode.steady_state_readout(X[perm])

        np.testing.assert_allclose(y_orig[perm], y_perm, atol=1e-12)

    def test_pretrade_gate_compliance_overridden_status(self):
        """Verify pre-trade gate and router return OVERRIDDEN when breach is overridden (§5j)."""
        from optimizer_compliance import run_pretrade_gate
        from enterprise.connectors.unified_broker_gateway import (
            MultiDematRouter, AngelOneSmartAPIConnector
        )
        # Weight dict that violates 1% max position limit
        weights = {"RELIANCE.NS": 0.50, "TCS.NS": 0.50}
        strict_cfg = {"MAX_POSITION_PCT": 0.01, "MAX_WEIGHT": 0.01}

        # When overridden, run_pretrade_gate returns OVERRIDDEN, not PASSED
        gate_res = run_pretrade_gate(weights, cfg=strict_cfg, compliance_override=True)
        self.assertEqual(gate_res["status"], "OVERRIDDEN")
        self.assertGreater(len(gate_res["violations"]), 0)

        # In MultiDematRouter, overridden orders route with compliance_status OVERRIDDEN
        orders = [
            {"ticker": "RELIANCE.NS", "qty": 1000, "side": "BUY", "price": 2950.0},
            {"ticker": "TCS.NS", "qty": 1000, "side": "BUY", "price": 4200.0}
        ]
        router = MultiDematRouter()
        conn = AngelOneSmartAPIConnector({"paper": True})
        router.register_connector("Paper1", conn, 1.0)
        route_res = router.route_rebalanced_basket(orders, cfg=strict_cfg, compliance_override=True)
        self.assertEqual(route_res["compliance_status"], "OVERRIDDEN")
        self.assertGreater(len(route_res["violations"]), 0)

    def test_angelone_place_basket_without_signal_df_and_positive_qty(self):
        """Verify angelone_place_basket resolves price dynamically and passes SEBI audit without crash."""
        from optimizer_broker import angelone_place_basket
        from data_layer import DynamicPriceResolver
        # Pre-seed cache so test runs hermetically without external HTTP latency
        DynamicPriceResolver._CACHE["TCS.NS"] = 4000.0
        DynamicPriceResolver._CACHE["INFY.NS"] = 1800.0
        # AUDIT-FIX (Round 43, hermeticity): the earnings-blackout screen hits
        # the live NSE corporate-actions feed, so near quarter-end this test
        # could fail for reasons unrelated to what it verifies (TCS/INFY
        # legitimately entering a results blackout window). The documented
        # remediation for this pre-existing defect was "an earnings-calendar
        # stub": stub the blackout screen off here, simulating a calendar with
        # no events for these tickers, so the test exercises exactly what its
        # name claims — dynamic price resolution + positive-quantity SEBI
        # audit leg — deterministically.
        from unittest.mock import patch
        with patch("optimizer_compliance.check_earnings_blackout", return_value=False):
            # Placing basket without signal_df (default None) with compliance_override
            weights = {"TCS.NS": 0.50, "INFY.NS": 0.50, "CASH": 0.0}
            df = angelone_place_basket(weights, portfolio_value=500000.0, dry_run=True, compliance_override=True)
        self.assertFalse(df.empty)
        self.assertEqual(len(df), 2)

    def test_multi_demat_router_monetary_weighting(self):
        """Verify MultiDematRouter calculates implied weights by monetary notional (Q*P), not raw shares."""
        from enterprise.connectors.unified_broker_gateway import MultiDematRouter, AngelOneSmartAPIConnector
        router = MultiDematRouter()
        conn = AngelOneSmartAPIConnector({"paper": True})
        router.register_connector("Paper1", conn, 1.0)

        # Stock A: 1 share @ 100,000 = 100,000 INR (50% notional)
        # Stock B: 10,000 shares @ 10 = 100,000 INR (50% notional)
        orders = [
            {"ticker": "STOCK_A.NS", "qty": 1, "price": 100000.0, "side": "BUY"},
            {"ticker": "STOCK_B.NS", "qty": 10000, "price": 10.0, "side": "BUY"},
        ]
        # With MAX_POSITION_PCT = 0.60, each 50% notional should pass.
        cfg = {"MAX_POSITION_PCT": 0.60, "MAX_WEIGHT": 0.60, "MIN_STOCKS": 2, "MAX_SECTOR_PCT": 0.60}
        sec_map = {"STOCK_A.NS": "Auto", "STOCK_B.NS": "Finance"}
        sig_df = pd.DataFrame(
            {"Close": [100.0] * 30, "Volume": [1000] * 30, "price": [100.0] * 30},
            index=[f"d{i}" for i in range(30)]
        )
        res = router.route_rebalanced_basket(orders, cfg=cfg, signal_df=sig_df, sector_map=sec_map, compliance_override=False)
        self.assertEqual(res["compliance_status"], "PASSED")
        self.assertEqual(res["status"], "OK")

    def test_apply_two_pass_clipping_unresolved_sectors(self):
        """Verify apply_two_pass_clipping groups None, '', 'N/A' into UNKNOWN and clips them."""
        from optimizer_compliance import apply_two_pass_clipping
        weights = {"STOCK_A": 0.25, "STOCK_B": 0.25, "STOCK_C": 0.25, "CASH": 0.25}
        # Diverse missing sector representations
        sector_map = {"STOCK_A": None, "STOCK_B": "", "STOCK_C": "N/A"}
        # Max sector is 30%. Together STOCK_A + B + C = 75% in UNKNOWN sector.
        clipped = apply_two_pass_clipping(weights, sector_map=sector_map, max_stock=0.30, max_sector=0.30)
        tot_unk = clipped["STOCK_A"] + clipped["STOCK_B"] + clipped["STOCK_C"]
        self.assertAlmostEqual(tot_unk, 0.30, places=5)
        self.assertAlmostEqual(clipped["CASH"], 0.70, places=5)

    def test_evaluate_options_skew_warning_empty_chain_no_crash(self):
        """Verify evaluate_options_skew_warning handles empty chain without UnboundLocalError."""
        from optimizer_compliance import evaluate_options_skew_warning
        # Empty dict chain
        warn = evaluate_options_skew_warning("RELIANCE.NS", option_chain={"chain_rows": []})
        self.assertFalse(warn)

    def test_calibrate_factor_weights_ic_preserves_negative_risk_penalties(self):
        """Verify calibrate_factor_weights_ic does not flip negative risk-penalty factors positive."""
        from optimizer import calibrate_factor_weights_ic, DEFAULT_CFG
        # 10 days of returns for 10 tickers (insufficient data path test)
        df_short = pd.DataFrame(np.random.randn(20, 10), columns=[f"T{i}" for i in range(10)])
        res_short = calibrate_factor_weights_ic(df_short, cfg=DEFAULT_CFG, return_details=True)
        w_short = res_short["weights"]
        self.assertLessEqual(w_short.get("z_ann_vol", 0.0), 0.0)

        # 300 days of returns for 10 tickers (full calibration loop)
        np.random.seed(42)
        df_long = pd.DataFrame(np.random.randn(300, 10), columns=[f"T{i}" for i in range(10)])
        res_long = calibrate_factor_weights_ic(df_long, cfg=DEFAULT_CFG, return_details=True)
        w_long = res_long["weights"]
        self.assertLessEqual(w_long.get("z_ann_vol", 0.0), 0.0)

    def test_apply_regime_bias_nan_and_missing_columns(self):
        """Verify apply_regime_bias handles missing factor columns and NaNs safely without error."""
        from optimizer import apply_regime_bias
        df = pd.DataFrame({
            "alpha_score": [1.0, 2.0],
            "z_ann_vol": [np.nan, 0.5],
            # z_beta_dev is missing completely
        }, index=["A.NS", "B.NS"])
        # Test Defensive Bias
        res_def = apply_regime_bias(df, {"REGIME_FILTER": "Defensive Bias"}, {"Regime": "Defensive"})
        self.assertFalse(res_def["alpha_score"].isna().any())

    def test_compute_purged_embargo_cv_metrics_no_insample_fallback(self):
        """Verify compute_purged_embargo_cv_metrics returns 0 OOS Sharpe if folds fail."""
        from ml_alpha.archetype_models import compute_purged_embargo_cv_metrics
        X = np.random.randn(50, 4)
        y = np.ones(50)  # Constant return -> std=0 in folds -> fails to produce top returns
        def dummy_fit_predict(X_tr, y_tr, X_te):
            return np.ones(len(X_te)) # flat predictions
        metrics = compute_purged_embargo_cv_metrics(X, y, dummy_fit_predict, n_splits=5)
        self.assertEqual(metrics["oos_sharpe"], 0.0)
        self.assertEqual(metrics["dsr"], 0.50)

    def test_ipo_multibagger_model_uncalibrated_defaults(self):
        """Verify uncalibrated IPOMultibaggerModel starts with 0.50 DSR and 0.0 OOS Sharpe.

        R46 UPDATE (contract supersession): the original Round 41 contract
        expected dsr=0.50 (coin-flip) for an uncalibrated model. Round 44's
        C-1/C-2 fix — which this tree implements and verify_fixes.py
        confirms ("unmeasured models refused / DSR stays None") — tightened
        that: an uncalibrated model must report dsr=None so downstream
        gates can REFUSE it, rather than a fabricated 0.50 that looks like
        a measured, acceptable score. The safer R44 contract wins.
        """
        from ml_alpha.ipo_model import IPOMultibaggerModel
        model = IPOMultibaggerModel()
        self.assertIsNone(model.dsr, "uncalibrated model must NOT fabricate a DSR (R44 C-1/C-2)")
        self.assertEqual(model.oos_sharpe, 0.0)

    def test_risk_budgeting_solver_sector_capping_unknown(self):
        """Verify sector_concentration_cardinality_ceiling caps UNKNOWN/NA sectors."""
        from math_engine.risk_budgeting_solver import sector_concentration_cardinality_ceiling
        weights = {"S1": 0.4, "S2": 0.3, "S3": 0.3}
        sectors = {"S1": "N/A", "S2": None, "S3": ""}
        # All 3 are UNKNOWN, max_per_sector=2. The 3rd should be clipped to 0.
        capped = sector_concentration_cardinality_ceiling(weights, sectors, max_per_sector=2)
        self.assertEqual(capped["S3"], 0.0)
        self.assertAlmostEqual(sum(capped.values()), 1.0, places=5)

    def test_bloomberg_port_attribution_unassigned_sectors(self):
        """Verify BloombergPortEngine includes assets with missing sectors in attribution."""
        from math_engine.bloomberg_port import BloombergPortEngine
        p_weights = {"S1": 0.5, "S2": 0.5}
        b_weights = {"S1": 0.5, "S2": 0.5}
        p_rets = {"S1": 0.10, "S2": 0.04}
        b_rets = {"S1": 0.08, "S2": 0.02}
        sectors = {"S1": "IT"} # S2 sector is omitted / unassigned
        res = BloombergPortEngine.compute_brinson_fachler_attribution(p_weights, b_weights, p_rets, b_rets, sectors)
        self.assertAlmostEqual(res["total_active_alpha_bps"], 200.0, places=1)
        alloc_tot = sum(s["Allocation_Effect_bps"] for s in res["sector_attribution_table"])
        select_tot = sum(s["Selection_Effect_bps"] for s in res["sector_attribution_table"])
        interact_tot = sum(s["Interaction_Effect_bps"] for s in res["sector_attribution_table"])
        self.assertAlmostEqual(alloc_tot + select_tot + interact_tot, res["total_active_alpha_bps"], places=1)

    def test_compute_hyperparameter_sensitivity_with_covariance(self):
        """Verify compute_hyperparameter_sensitivity tests grid and retains covariance/sectors."""
        from optimizer import compute_hyperparameter_sensitivity
        np.random.seed(42)
        tickers = [f"T{i}" for i in range(6)]
        signal_df = pd.DataFrame({
            "alpha_score": [0.8, 0.6, 0.4, 0.2, 0.1, -0.1],
            "risk_score": [0.2, 0.3, 0.25, 0.4, 0.5, 0.6]
        }, index=tickers)
        sectors = {t: "Tech" if i < 3 else "Auto" for i, t in enumerate(tickers)}
        # Construct synthetic base Q
        base_q = {}
        for i, s1 in enumerate(tickers):
            base_q[(s1, s1)] = -1.0 * signal_df.loc[s1, "alpha_score"]
            for j in range(i + 1, len(tickers)):
                base_q[(s1, tickers[j])] = 0.5
        cfg = {"GAMMA": 10.0, "ALPHA": 1.5, "VOL_PENALTY": 0.5, "K_STOCKS": 3, "SENSITIVITY_DELTAS": [0.90, 1.00, 1.10]}
        df_sens = compute_hyperparameter_sensitivity(base_q, signal_df, sectors, cfg)
        self.assertFalse(df_sens.empty)
        for col in ["GAMMA×", "ALPHA×", "VOL×", "Overlap", "Stability%", "Selected"]:
            self.assertIn(col, df_sens.columns)
        self.assertEqual(len(df_sens), 27)

    def test_compute_per_stock_factor_contribution(self):
        """Verify compute_per_stock_factor_contribution decomposes alpha into factor drivers."""
        from optimizer import compute_per_stock_factor_contribution
        sig_df = pd.DataFrame({
            "alpha_score": [1.5, -0.5],
            "z_mom_1m": [2.0, -1.0],
            "z_roe": [1.0, 0.0],
            "z_ann_vol": [-0.5, 1.2]
        }, index=["RELIANCE.NS", "TCS.NS"])
        cfg = {"FACTOR_WEIGHTS": {"z_mom_1m": 0.5, "z_roe": 0.3, "z_ann_vol": -0.2}}
        df_contrib = compute_per_stock_factor_contribution(sig_df, cfg)
        self.assertEqual(len(df_contrib), 2)
        self.assertIn("Top Factor Drivers", df_contrib.columns)
        self.assertIn("mom_1m", df_contrib.loc[0, "Top Factor Drivers"])

    def test_check_multi_timeframe_confluence(self):
        """Verify check_multi_timeframe_confluence evaluates D, 4H, and 1H trends."""
        from optimizer import check_multi_timeframe_confluence
        # Uptrending daily prices (length 60)
        daily_px = pd.DataFrame({"Close": np.linspace(100, 200, 60)})
        res_bull = check_multi_timeframe_confluence(daily_px)
        self.assertTrue(res_bull["daily_bull"])
        self.assertTrue(res_bull["mtf_aligned"])
        self.assertGreater(res_bull["confluence_score"], 0.0)

        # Downtrending daily prices
        daily_bear = pd.DataFrame({"Close": np.linspace(200, 100, 60)})
        res_bear = check_multi_timeframe_confluence(daily_bear)
        self.assertFalse(res_bear["daily_bull"])
        self.assertFalse(res_bear["mtf_aligned"])

    def test_compute_rolling_ic(self):
        """Verify compute_rolling_ic measures rolling cross-sectional Spearman IC."""
        from optimizer import compute_rolling_ic
        np.random.seed(42)
        T, N = 100, 10
        fac = pd.DataFrame(np.random.randn(T, N), columns=[f"S{i}" for i in range(N)])
        # Forward returns strongly aligned with factor (perfect correlation + tiny noise)
        fwd = fac + 0.01 * np.random.randn(T, N)
        ic_arr = compute_rolling_ic(fac, fwd, forward_days=20, min_periods=5)
        self.assertGreater(len(ic_arr), 0)
        # All ICs should be close to 1.0
        self.assertGreater(float(np.mean(ic_arr)), 0.90)

    def test_profile_map_defines_positive_min_weights(self):
        """Verify all profiles in PROFILE_MAP define positive MIN_WEIGHT (§5)."""
        from data_layer import PROFILE_MAP
        self.assertEqual(len(PROFILE_MAP), 5)
        for pname, pcfg in PROFILE_MAP.items():
            self.assertIn("MIN_WEIGHT", pcfg, f"Profile {pname} missing MIN_WEIGHT")
            min_w = float(pcfg["MIN_WEIGHT"])
            self.assertGreater(min_w, 0.0, f"Profile {pname} MIN_WEIGHT must be > 0")
            self.assertLessEqual(min_w, 0.05, f"Profile {pname} MIN_WEIGHT must be <= 0.05")

    def test_calculate_qubo_aware_weights_honors_min_weight(self):
        """Verify calculate_qubo_aware_weights allocates >= MIN_WEIGHT to all selected assets (§5)."""
        from optimizer_broker import calculate_qubo_aware_weights
        selected = ["STOCK_A.NS", "STOCK_B.NS", "STOCK_C.NS", "STOCK_D.NS"]
        sig_df = pd.DataFrame({
            "ann_vol": [0.20, 0.35, 0.50, 0.15],
            "adv20": [1e7, 1e7, 1e7, 1e7]
        }, index=selected)
        q = {(s, s): -1.0 for s in selected}
        cfg = {"MIN_WEIGHT": 0.05, "MAX_WEIGHT": 0.50, "K_STOCKS": 4}
        weights = calculate_qubo_aware_weights(selected, sig_df, q, cfg)
        self.assertEqual(len(weights), 4)
        for s in selected:
            self.assertGreaterEqual(weights[s], 0.05 - 1e-4, f"Asset {s} received weight < MIN_WEIGHT")
        self.assertAlmostEqual(sum(weights.values()), 1.0, places=4)

    def test_calculate_qubo_aware_weights_with_bear_cash_bounds(self):
        """Verify calculate_qubo_aware_weights adjusts bounds when cash is active (§5)."""
        from optimizer_broker import calculate_qubo_aware_weights
        selected = ["STOCK_A.NS", "STOCK_B.NS"]
        sig_df = pd.DataFrame({
            "ann_vol": [0.20, 0.25],
            "adv20": [1e7, 1e7]
        }, index=selected)
        q = {(s, s): -1.0 for s in selected}
        # In bear regime, cash is 50%. Equity available is 50%.
        cfg = {"MIN_WEIGHT": 0.05, "MAX_WEIGHT": 0.50, "BEAR_RESIDUAL_CASH_FRACTION_ACTIVE": 0.50}
        weights = calculate_qubo_aware_weights(selected, sig_df, q, cfg)
        self.assertIn("CASH", weights)
        self.assertAlmostEqual(weights["CASH"], 0.50, places=3)
        self.assertAlmostEqual(sum(weights.values()), 1.0, places=4)
        for s in selected:
            self.assertGreaterEqual(weights[s], 0.0)

    def test_profile_map_category_caps_prevent_ipo_cash_drain(self):
        """Verify IPO profile allows 100% small-cap exposure so funds are not dumped into CASH."""
        from data_layer import PROFILE_MAP
        from optimizer_compliance import apply_sebi_constraints
        ipo_cfg = PROFILE_MAP["🦄 High-Growth IPO · Multibagger Hunter"]
        self.assertEqual(ipo_cfg.get("MAX_SMALL_CAP_PCT"), 1.0)
        self.assertEqual(ipo_cfg.get("MAX_MID_CAP_PCT"), 1.0)

        # 4 small cap IPO stocks, each 25% weight
        weights = {"IPO1.NS": 0.25, "IPO2.NS": 0.25, "IPO3.NS": 0.25, "IPO4.NS": 0.25}
        capped = apply_sebi_constraints(weights, cfg=ipo_cfg)
        # Under 1.0 cap, CASH should not be injected to confiscate 70% of portfolio
        self.assertEqual(capped.get("CASH", 0.0), 0.0)
        self.assertAlmostEqual(sum(capped.values()), 1.0, places=4)

    def test_apply_weight_constraints_no_phantom_zeros(self):
        """Verify apply_weight_constraints ensures all active stocks receive >= MIN_WEIGHT and never emits 0.00%."""
        from optimizer_compliance import apply_weight_constraints
        # 15 stocks with some very low weights from SEBI redistribution
        tickers = [f"TICKER_{i}.NS" for i in range(15)]
        w = {t: 0.01 for t in tickers}
        w["TICKER_0.NS"] = 0.35
        w["TICKER_1.NS"] = 0.35
        w["CASH"] = 0.20
        cfg = {"MIN_WEIGHT": 0.025, "MAX_WEIGHT": 0.30}

        w_out = apply_weight_constraints(w, cfg)
        eq_out = {k: v for k, v in w_out.items() if k != "CASH"}
        self.assertEqual(len(eq_out), 15, "All 15 stocks must be allocated valid non-zero weights")
        for sym, alloc in eq_out.items():
            self.assertGreaterEqual(alloc, 0.02499, f"Asset {sym} received below-min weight: {alloc}")
            self.assertLessEqual(alloc, 0.30001, f"Asset {sym} exceeded max weight: {alloc}")
        self.assertAlmostEqual(sum(w_out.values()), 1.0, places=4)

    def test_combined_portfolio_csv_has_no_zero_weights(self):
        """Verify combined_portfolio.csv contains strictly positive (> 0.00%) optimal weights."""
        from pathlib import Path
        comb = Path("combined_portfolio.csv")
        self.assertTrue(comb.exists(), "combined_portfolio.csv must exist")
        df = pd.read_csv(comb)
        self.assertFalse(df.empty, "combined_portfolio.csv must not be empty")
        float_weights = df["Optimal Weight"].astype(str).str.replace("%", "").astype(float)
        zero_rows = df[float_weights <= 0.0]
        self.assertEqual(len(zero_rows), 0, f"Found {len(zero_rows)} phantom zero-weight rows in combined_portfolio.csv: {zero_rows[['Profile', 'Ticker', 'Optimal Weight']]}")
        # Every profile must have positive holdings
        self.assertGreaterEqual(df["Profile"].nunique(), 5, "Must carry all 5 canonical profiles")

    def test_causal_direct_lingam_sink_constraint(self):
        """Verify DirectLiNGAM sink_variable forces target to be the final sink."""
        from ml_alpha.causal_structural_discovery import PearlianCausalDiscoveryEngine
        engine = PearlianCausalDiscoveryEngine()
        np.random.seed(42)
        n = 100
        x1 = np.random.normal(0, 1, n)
        x2 = 0.5 * x1 + np.random.normal(0, 0.5, n)
        # target constructed to look very clean
        target = 0.8 * x2 + np.random.normal(0, 0.2, n)
        data = pd.DataFrame({"feat1": x1, "feat2": x2, "target_y": target})

        engine.fit(data, sink_variable="target_y")
        # Target must be last in topological order
        self.assertEqual(engine.topological_order[-1], 2, "target_y must be placed last as the sink variable")

    def test_momentum_patch_tst_model_uses_patch_alpha(self):
        """Verify MomentumPatchTSTModel incorporates z_patch_tst_alpha in MOMENTUM_FACTOR_NAMES."""
        from ml_alpha.archetype_models import MomentumPatchTSTModel, MOMENTUM_FACTOR_NAMES
        self.assertIn("z_patch_tst_alpha", MOMENTUM_FACTOR_NAMES)
        model = MomentumPatchTSTModel()
        self.assertIn("z_patch_tst_alpha", model.feature_names)
        
        # Test feature augmentation with z_patch_tst_alpha
        X_norm = np.zeros((5, len(model.feature_names)))
        X_norm[:, model.feature_names.index("z_patch_tst_alpha")] = 1.5
        aug = model._build_augmented_features(X_norm)
        # The last column should match z_patch_tst_alpha value (1.5)
        self.assertEqual(aug.shape[1], len(model.feature_names) + 5)
        np.testing.assert_allclose(aug[:, -1], 1.5)

    def test_angel_dry_run_simulated_ltp(self):
        """Verify broker_router Angel dry-run simulation handles unresolvable prices safely."""
        from math_engine.broker_router import AngelOneExecutionRouter
        router = AngelOneExecutionRouter(cfg={})
        weights = {"UNRESOLVED_TICKER.NS": 0.50, "CASH": 0.50}
        df = router.route_basket_execution(weights, portfolio_value=100000.0, dry_run=True)
        self.assertFalse(df.empty)
        row = df.iloc[0]
        self.assertEqual(row["Status"], "LTP Fetch Failed")
        self.assertEqual(row["Qty"], 0)

    def test_kill_switch_resilient_order_cancellation(self):
        """Verify MasterKillSwitch.activate isolates individual order cancellation failures and reports accurate status."""
        from unittest.mock import patch, MagicMock
        from core.kill_switch import MasterKillSwitch

        # Case 1: Mid-loop order cancellation failure does not abort subsequent orders
        mock_db = MagicMock()
        mock_db.get_active_orders.return_value = [
            {"order_id": "ORD-001"},
            {"order_id": "ORD-002"},
            {"order_id": "ORD-003"},
        ]
        def update_mock(order_id, status, rejection_reason):
            if order_id == "ORD-002":
                raise RuntimeError("DB Lock on ORD-002")
        mock_db.update_order_status.side_effect = update_mock

        with patch("core.kill_switch.get_db", return_value=mock_db):
            res = MasterKillSwitch.activate(reason="Test Partial", operator="TEST_OP")
            self.assertEqual(res["status"], "SUCCESS_WITH_ORDER_ERRORS")
            self.assertEqual(res["cancelled_orders"], ["ORD-001", "ORD-003"])
            self.assertEqual(res["failed_to_cancel_orders"], ["ORD-002"])

        # Case 2: Active orders fetch failure reports PARTIAL status
        mock_db_fail = MagicMock()
        mock_db_fail.get_active_orders.side_effect = RuntimeError("Connection timeout")
        with patch("core.kill_switch.get_db", return_value=mock_db_fail):
            res_partial = MasterKillSwitch.activate(reason="Test Fetch Fail", operator="TEST_OP")
            self.assertEqual(res_partial["status"], "PARTIAL")
            self.assertIn("Connection timeout", res_partial["order_fetch_error"])

    def test_hard_risk_gateway_unknown_sector_capped(self):
        """Verify HardPreTradeRiskGateway enforces sector concentration limits on Unknown/unresolved sectors."""
        from core.risk_gateway import HardPreTradeRiskGateway
        gateway = HardPreTradeRiskGateway()
        # Default max_sector_concentration is 0.25 (25%)
        # Basket with 60% in Unknown / N/A sector stocks
        weights = {
            "UNKNOWN_1.NS": 0.30,
            "UNKNOWN_2.NS": 0.30,
            "KNOWN_1.NS": 0.20,
            "CASH": 0.20,
        }
        sector_map = {
            "UNKNOWN_1.NS": "Unknown",
            "UNKNOWN_2.NS": "N/A",  # Unresolved metadata
            "KNOWN_1.NS": "Information Technology",
        }
        res = gateway.validate_basket(weights, total_nav=1_000_000.0, sector_map=sector_map)
        self.assertEqual(res["status"], "BLOCKED", "Basket with 60% in Unknown sector must fail validation")
        sec_violations = [v for v in res["violations"] if v.get("rule") == "SECTOR_CONCENTRATION_LIMIT"]
        self.assertTrue(any(v.get("ticker") == "Unknown" for v in sec_violations), "Must report SECTOR_CONCENTRATION_LIMIT for Unknown sector")

        # Clean basket with 15% in Unknown sector (< 25% limit)
        clean_weights = {
            "UNKNOWN_1.NS": 0.08,
            "UNKNOWN_2.NS": 0.07,
            "KNOWN_1.NS": 0.10,
            "CASH": 0.75,
        }
        res_clean = gateway.validate_basket(clean_weights, total_nav=1_000_000.0, sector_map=sector_map)
        self.assertEqual(res_clean["status"], "PASSED")
        clean_sec_violations = [v for v in res_clean["violations"] if v.get("rule") == "SECTOR_CONCENTRATION_LIMIT"]
        self.assertEqual(len(clean_sec_violations), 0, "Basket with < 25% Unknown sector must not trigger sector violation")

    def test_hard_risk_gateway_respects_enable_sector_cap_false(self):
        """Verify HardPreTradeRiskGateway respects ENABLE_SECTOR_CAP=False for pure alpha / momentum portfolios."""
        from core.risk_gateway import HardPreTradeRiskGateway
        # Pure alpha configuration: ENABLE_SECTOR_CAP = False
        gateway = HardPreTradeRiskGateway({"ENABLE_SECTOR_CAP": False, "RISK_MAX_STOCK_CONCENTRATION": 0.20})
        self.assertFalse(gateway.enable_sector_cap)
        self.assertEqual(gateway.max_sector_concentration, 1.0)

        # Concentrated momentum basket with 40% in Defense / Capital Goods sector
        weights = {
            "HAL.NS": 0.15,
            "BEL.NS": 0.15,
            "BDL.NS": 0.10,
            "TCS.NS": 0.10,
            "CASH": 0.50,
        }
        sector_map = {
            "HAL.NS": "Aerospace & Defense",
            "BEL.NS": "Aerospace & Defense",
            "BDL.NS": "Aerospace & Defense",
            "TCS.NS": "Information Technology",
        }
        res = gateway.validate_basket(weights, total_nav=1_000_000.0, sector_map=sector_map)
        self.assertEqual(res["status"], "PASSED", "Pure alpha mode must allow sector concentration into top momentum leaders")
        sec_violations = [v for v in res["violations"] if v.get("rule") == "SECTOR_CONCENTRATION_LIMIT"]
        self.assertEqual(len(sec_violations), 0)

        # 100% unconstrained allocation: entire equity invested in top breakout leaders of a single winning sector
        weights_100pct = {
            "HAL.NS": 0.20,
            "BEL.NS": 0.20,
            "BDL.NS": 0.20,
            "MAZDOCK.NS": 0.20,
            "COCHINSHIP.NS": 0.20,
        }
        sector_map_100pct = {k: "Aerospace & Defense" for k in weights_100pct}
        res_100 = gateway.validate_basket(weights_100pct, total_nav=1_000_000.0, sector_map=sector_map_100pct)
        self.assertEqual(res_100["status"], "PASSED", "Pure alpha mode allows up to 100% in a single winning sector")
        sec_violations_100 = [v for v in res_100["violations"] if v.get("rule") == "SECTOR_CONCENTRATION_LIMIT"]
        self.assertEqual(len(sec_violations_100), 0)


if __name__ == "__main__":
    unittest.main()



