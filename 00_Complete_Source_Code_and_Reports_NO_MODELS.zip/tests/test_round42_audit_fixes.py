"""tests/test_round42_audit_fixes.py
===================================
Verification test suite for Institutional Systems Audit Report (Round 42):
- C-2: Unmeasured DSR / OOS Sharpe returns None / unmeasured in MoE router.
- C-3: Master Kill Switch gates run_pretrade_gate, AngelOneExecutionRouter, and cancel_order.
- C-4: Refusal of flat ₹100 price fabrication in OMS and SEBI pre-trade audit.
- H-1: GAT diffusion aligns by stock names and handles sub-graphs correctly.
- H-3: Reconcile positions marks unpriced holdings as HOLD, preventing liquidation.
- H-4: Basket-level risk gate wired into OMS submit_basket.
- H-5: Ledoit-Wolf correlation matrix shrinkage is not double-shrunk.
- M-1: QUBO re-sync preserves risk deflation on alpha score.
- M-2: Hyperparameter sensitivity analysis operates reliably without KeyError.
- M-3: Margin utilization check uses available margin / buying power.
- M-4: Circuit band check logs explicit degradation when prev_close unavailable.
- M-5: Greedy seed respects ENABLE_SECTOR_CAP and defines _sec_q safely.
- M-6: SEBI category caps respect ENFORCE_SEBI_CATEGORY_CAPS mandate gate.
- L-1: DhanAdapter is dedicated and not an alias for AngelOneAdapter.
- L-3: RiskGateway enable_sector_cap defaults to False.
"""

import unittest
import numpy as np
import pandas as pd
from unittest.mock import MagicMock, patch


class TestRound42AuditFixes(unittest.TestCase):

    def test_c2_unmeasured_dsr_oos_sharpe_reports_none(self):
        """C-2: Unmeasured models report None for DSR/OOS Sharpe instead of fabricated 0.85/0.90."""
        from ml_alpha.regime_ensemble import RegimeEnsembleRouter

        router = RegimeEnsembleRouter()

        class DummyModel:
            feature_names = ["z_test"]
            def predict(self, X):
                return np.array([0.1, 0.2, 0.3])

        sig_df = pd.DataFrame({"z_test": [1.0, 2.0, 3.0]}, index=["AAA", "BBB", "CCC"])
        with patch("ml_alpha.regime_ensemble.load_verified_model", return_value=DummyModel()):
            _, diags = router.predict_ensemble(sig_df)
            self.assertIn("ensemble_dsr", diags)
            self.assertIsNone(diags["ensemble_dsr"], "Unmeasured DSR must report None")
            self.assertIsNone(diags["ensemble_oos_sharpe"], "Unmeasured OOS Sharpe must report None")

    def test_c3_kill_switch_gates_pretrade_and_router(self):
        """C-3: MasterKillSwitch blocks pretrade gate and AngelOneExecutionRouter."""
        from core.kill_switch import MasterKillSwitch
        from optimizer_compliance import run_pretrade_gate
        from math_engine.broker_router import AngelOneExecutionRouter

        # Engage kill switch
        MasterKillSwitch.activate(reason="Round 42 Audit Test")
        try:
            self.assertTrue(MasterKillSwitch.is_active())

            # 1. run_pretrade_gate returns BLOCKED
            gate_res = run_pretrade_gate({"RELIANCE.NS": 0.5, "TCS.NS": 0.5})
            self.assertEqual(gate_res["status"], "BLOCKED")
            self.assertTrue(any(v.get("rule") == "GLOBAL_KILL_SWITCH" for v in gate_res["violations"]))

            # 2. AngelOneExecutionRouter blocks orders
            router = AngelOneExecutionRouter()
            df = router.route_basket_execution({"RELIANCE.NS": 0.5, "TCS.NS": 0.5}, portfolio_value=100000.0, dry_run=False)
            self.assertTrue(all("BLOCKED" in str(st) for st in df["Status"]))
        finally:
            MasterKillSwitch.deactivate()
            self.assertFalse(MasterKillSwitch.is_active())

    def test_c4_no_price_fabrication_in_oms_rejects_zero_ltp(self):
        """C-4: OMS submit_order rejects orders with zero/None LTP instead of fabricating ₹100."""
        from core.broker_oms import BrokerOrderManagementSystem

        oms = BrokerOrderManagementSystem()
        # Submit order with 0.0 price and None ltp
        res = oms.submit_order(
            broker="paper",
            symbol="TESTSTOCK.NS",
            side="BUY",
            qty=100,
            price=0.0,
            ltp=None,
            dry_run=True,
        )
        self.assertFalse(res["success"], "Order with zero LTP must be rejected")
        self.assertEqual(res["status"], "REJECTED")
        self.assertIn("NO_RELIABLE_PRICE", res.get("reason", ""))

    def test_h1_gat_propagate_name_alignment(self):
        """H-1: GAT propagate aligns scores by ticker name and supports sub-universes."""
        from ml_alpha.graph_attention_network import DynamicGraphAttentionEngine

        eng = DynamicGraphAttentionEngine(n_heads=2, hidden_dim=8)
        stocks = ["AAA", "BBB", "CCC", "DDD", "EEE"]
        np.random.seed(42)
        rets = pd.DataFrame(np.random.randn(50, 5), columns=stocks)
        base = np.array([0.9, 0.1, 0.5, 0.3, 0.7])
        eng.fit_dynamic_attention(stocks=stocks, returns_df=rets, base_scores=base)

        # 1. Permuted input names should be handled correctly
        perm_names = ["EEE", "DDD", "CCC", "BBB", "AAA"]
        perm_scores = np.array([0.7, 0.3, 0.5, 0.1, 0.9])
        diffused_perm = eng.propagate(perm_scores, alpha_blend=0.30, names=perm_names)
        self.assertEqual(len(diffused_perm), 5)
        # Position 0 (EEE) diffused value should match Position 4 of natural order
        diffused_nat = eng.propagate(base, alpha_blend=0.30, names=stocks)
        self.assertAlmostEqual(diffused_perm[0], diffused_nat[4], places=4)

        # 2. Sub-universe should extract sub-adjacency without error
        sub_names = ["AAA", "BBB", "CCC"]
        sub_scores = np.array([0.9, 0.1, 0.5])
        diffused_sub = eng.propagate(sub_scores, alpha_blend=0.30, names=sub_names)
        self.assertEqual(len(diffused_sub), 3)

    def test_h3_reconcile_positions_holds_unpriced(self):
        """H-3: Reconcile positions marks unpriced current holdings as HOLD rather than liquidating."""
        from math_engine.broker_router import AngelOneAdapter

        adapter = AngelOneAdapter()
        # Mock get_holdings and zero LTP
        adapter.get_holdings = MagicMock(return_value=[{"tradingsymbol": "HDFCBANK-EQ", "quantity": 100}])
        adapter.get_ltp = MagicMock(return_value=0.0)

        df = adapter.reconcile_positions({"HDFCBANK.NS": 0.10, "CASH": 0.90}, portfolio_value=1_000_000.0)
        self.assertFalse(df.empty)
        row = df[df["Ticker"] == "HDFCBANK.NS"].iloc[0]
        self.assertIn("HOLD", row["Action"], "Unpriced existing holding must HOLD, not SELL")
        self.assertNotIn("SELL 100", row["Action"])

    def test_h4_submit_basket_evaluates_portfolio_risk_gate(self):
        """H-4: OMS submit_basket executes portfolio-level risk gate."""
        from core.broker_oms import BrokerOrderManagementSystem

        oms = BrokerOrderManagementSystem(cfg={"RISK_MAX_STOCK_CONCENTRATION": 0.10})
        # Single order taking 100% of nav (exceeds 10% concentration)
        orders = [{"ticker": "SINGLE.NS", "qty": 1000, "price": 1000.0, "ltp": 1000.0}]
        res = oms.submit_basket("paper", orders, total_nav=1_000_000.0, dry_run=True)
        self.assertEqual(res["blocked_by"], "PORTFOLIO_RISK_GATE")
        self.assertEqual(res["executed_count"], 0)

    def test_h5_ledoit_wolf_correlation_no_double_shrinkage(self):
        """H-5: Ledoit-Wolf correlation matrix is not double shrunk."""
        from utils_chart_pipeline import build_correlation_matrix
        from sklearn.covariance import LedoitWolf

        np.random.seed(42)
        rets = pd.DataFrame(np.random.randn(100, 4), columns=["A", "B", "C", "D"])
        corr_out = build_correlation_matrix(rets, method="Ledoit-Wolf", shrinkage=0.25)
        lw = LedoitWolf().fit(rets.values)
        cov = lw.covariance_
        std = np.sqrt(np.diag(cov))
        expected_corr = cov / np.outer(std, std)

        np.testing.assert_allclose(corr_out.values, expected_corr, atol=1e-5)

    def test_m1_qubo_resync_preserves_risk_deflation(self):
        """M-1: QUBO re-sync deflation preserves risk score penalty."""
        ALPHA = 1.8
        risk_score = 1.0  # max risk stock
        alpha_raw = 1.0
        # Deflation rule: alpha * max(0.80, 1.0 - 0.20 * clip(risk, 0, 1))
        deflated_factor = max(0.80, 1.0 - 0.20 * float(np.clip(risk_score, 0.0, 1.0)))
        self.assertAlmostEqual(deflated_factor, 0.80)
        self.assertAlmostEqual(alpha_raw * deflated_factor, 0.80)

    def test_m2_compute_hyperparameter_sensitivity_rescale_fallback(self):
        """M-2: compute_hyperparameter_sensitivity completes without KeyError on raw_data=None."""
        from optimizer import compute_hyperparameter_sensitivity

        base_q = {("STOCK1.NS", "STOCK1.NS"): -1.0, ("STOCK2.NS", "STOCK2.NS"): -0.8}
        sig_df = pd.DataFrame({
            "alpha_score": [0.8, 0.6],
            "risk_score": [0.2, 0.3],
        }, index=["STOCK1.NS", "STOCK2.NS"])
        sectors = {"STOCK1.NS": "IT", "STOCK2.NS": "Finance"}
        cfg = {"GAMMA": 10.0, "ALPHA": 1.5, "VOL_PENALTY": 0.5, "K_STOCKS": 2}

        # Should complete cleanly without KeyError: 'Close'
        sens_df = compute_hyperparameter_sensitivity(base_q, sig_df, sectors, cfg, raw_data=None)
        self.assertFalse(sens_df.empty)
        self.assertIn("Stability%", sens_df.columns)

    def test_m3_risk_gateway_margin_utilization(self):
        """M-3: RiskGateway margin utilization evaluates against AVAILABLE_BUYING_POWER."""
        from core.risk_gateway import RiskGateway

        gw = RiskGateway(cfg={"AVAILABLE_BUYING_POWER": 1_000_000.0, "RISK_MAX_MARGIN_UTILIZATION": 0.90})
        # Allocations totaling ₹500,000 (50% utilization -> PASSED)
        res = gw.validate_basket({"A.NS": 0.5, "CASH": 0.5}, total_nav=1_000_000.0)
        self.assertNotIn("MARGIN_UTILIZATION_CEILING", [v.get("rule") for v in res["violations"]])

        # Allocations totaling ₹950,000 against ₹1,000,000 buying power -> 95% -> BLOCKED
        res_blocked = gw.validate_basket({"A.NS": 0.95, "CASH": 0.05}, total_nav=1_000_000.0)
        self.assertIn("MARGIN_UTILIZATION_CEILING", [v.get("rule") for v in res_blocked["violations"]])

    def test_m5_greedy_seed_defines_sec_q_and_respects_enable_sector_cap(self):
        """M-5: Greedy seed honors ENABLE_SECTOR_CAP=False and avoids NameError on _sec_q."""
        from optimizer import solve_qubo

        stocks = [f"STK_{i}.NS" for i in range(10)]
        sig_df = pd.DataFrame({"alpha_score": np.linspace(1.0, 0.1, 10)}, index=stocks)
        sectors = {s: "IT" for s in stocks}  # All in one sector
        q = {(s, s): -1.0 for s in stocks}

        # When ENABLE_SECTOR_CAP is False, all selected stocks can be from IT
        cfg = {"OPTIMIZER_MODE": "Greedy", "K_STOCKS": 5, "ENABLE_SECTOR_CAP": False, "MAX_PER_SECTOR": 2}
        sel, _, _ = solve_qubo(q, sig_df, sectors, cfg)
        self.assertEqual(len(sel), 5)

    def test_m6_sebi_mandate_gating(self):
        """M-6: SEBI category caps check ENFORCE_SEBI_CATEGORY_CAPS configuration."""
        cfg_retail = {"ENFORCE_SEBI_CATEGORY_CAPS": False}
        self.assertFalse(cfg_retail.get("ENFORCE_SEBI_CATEGORY_CAPS", False))

        cfg_mf = {"ENFORCE_SEBI_CATEGORY_CAPS": True}
        self.assertTrue(cfg_mf.get("ENFORCE_SEBI_CATEGORY_CAPS", False))

    def test_l1_dhan_adapter_is_dedicated_class(self):
        """L-1: DhanAdapter is an independent class, not an alias for AngelOneAdapter."""
        from math_engine.broker_router import DhanAdapter, AngelOneAdapter

        self.assertIsNot(DhanAdapter, AngelOneAdapter)
        adapter = DhanAdapter("fake_client", "fake_token")
        self.assertIsInstance(adapter, DhanAdapter)

    def test_l3_risk_gateway_enable_sector_cap_respects_config(self):
        """L-3: RiskGateway enable_sector_cap respects explicit configuration."""
        from core.risk_gateway import RiskGateway

        gw_pure_alpha = RiskGateway({"ENABLE_SECTOR_CAP": False})
        self.assertFalse(gw_pure_alpha.enable_sector_cap, "Explicit ENABLE_SECTOR_CAP=False must be respected")

        gw_default = RiskGateway()
        self.assertTrue(gw_default.enable_sector_cap, "Default standalone gateway enforces sector caps")

    def test_5q_differential_rebalancing_executes_buys_and_sells(self):
        """Claude §5q: Rebalancing router executes differential orders with real BUY and SELL sides."""
        from math_engine.broker_router import AngelOneExecutionRouter

        router = AngelOneExecutionRouter()
        self.assertTrue(hasattr(router, "execute_differential_orders"))

        diff_orders = [
            {"ticker": "RELIANCE.NS", "side": "BUY", "qty": 10, "price": 2500.0},
            {"ticker": "TCS.NS", "side": "SELL", "qty": 5, "price": 3500.0},
        ]
        df = router.execute_differential_orders(diff_orders, dry_run=True)
        self.assertEqual(len(df), 2)
        self.assertEqual(df.loc[df["Ticker"] == "RELIANCE.NS", "Side"].values[0], "BUY")
        self.assertEqual(df.loc[df["Ticker"] == "TCS.NS", "Side"].values[0], "SELL")


if __name__ == "__main__":
    unittest.main()
