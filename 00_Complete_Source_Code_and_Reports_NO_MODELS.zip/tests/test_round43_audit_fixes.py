"""tests/test_round43_audit_fixes.py
====================================
Verification suite for the Round-43 post-remediation audit (remaining bugs
found after the antigravity application of the GLM/Claude Round-41/42 fixes).

Covers:
  R1  (CRITICAL) core/kill_switch.py — `import os` present; live-broker orders
      without credentials are NOT marked CANCELLED locally and are reported as
      failed; with credentials the broker-side cancel is actually attempted.
  R7  (HIGH) core/broker_oms.py — submit_basket portfolio gate expresses
      weights against portfolio NAV (not basket notional), so a concentrated
      rebalance basket is no longer spuriously blocked.
  R9  (MEDIUM) core/risk_gateway.py — single-stock cap = min(MAX_WEIGHT, 10%)
      unless RISK_MAX_STOCK_CONCENTRATION is set explicitly.
  R10 (MEDIUM) math_engine/broker_router.py — freeze-quantity fallback for
      unknown symbols is 1,000 (not 50,000).
  R11 (MEDIUM) math_engine/__init__.py — CQMFormulator export is the real
      QuantumCQMFormulator class, not a silently-None placeholder.
  R6  (HIGH) ml_alpha/archetype_models.py — purged CV with as_of_dates:
      date-major folds are genuine time blocks; day-based embargo purges ALL
      train rows (every ticker) within the embargo window of the test block.
  R8  (MEDIUM) same file — fold-local z-scoring: fit_predict_fn receives
      train-fold-normalized features (train stats only, no test leakage).
  R2/R3/R4/R5 — NameError regressions (retrain_now pd, worker_threads
      urllib, web_dashboard datetime + profile_name).
  R12 — data_layer loud-degradation handlers present (regression lock).
"""

import os
import sys
import unittest
from unittest.mock import patch, MagicMock

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestR1KillSwitch(unittest.TestCase):
    """R1: kill switch emergency cancel path."""

def _make_kill_switch_test_cases():
    pass


class TestR1KillSwitchOsImport(unittest.TestCase):
    def test_os_imported_in_kill_switch_module(self):
        import core.kill_switch as ks
        self.assertTrue(hasattr(ks, "os"), "core/kill_switch.py must import os (R1a)")

    def test_dhan_order_without_creds_not_marked_cancelled(self):
        """R1b: live-broker order with missing credentials must NOT be locally
        marked CANCELLED nor counted in cancelled_orders — it stays active and
        is reported as failed (the order may still be LIVE at the broker)."""
        from core.kill_switch import MasterKillSwitch

        for k in ("DHAN_CLIENT_ID", "DHAN_ACCESS_TOKEN"):
            os.environ.pop(k, None)
        mock_db = MagicMock()
        mock_db.get_active_orders.return_value = [
            {"order_id": "LIVE-001", "broker": "dhan", "broker_order_id": "DH-777"},
        ]
        with patch("core.kill_switch.get_db", return_value=mock_db):
            res = MasterKillSwitch.activate(reason="R1 test", operator="TEST")
        self.assertEqual(res["status"], "SUCCESS_WITH_ORDER_ERRORS")
        self.assertEqual(res["cancelled_orders"], [])
        self.assertEqual(res["failed_to_cancel_orders"], ["LIVE-001"])
        self.assertFalse(mock_db.update_order_status.called,
                         "DB row must NOT be flipped to CANCELLED without broker confirmation")

    def test_dhan_order_with_creds_cancels_broker_side(self):
        """R1a: with credentials present, DhanV2Client.cancel_order is invoked
        (previously NameError('os') aborted this path) and the DB row is marked
        CANCELLED."""
        import core.broker_oms
        from core.kill_switch import MasterKillSwitch

        os.environ["DHAN_CLIENT_ID"] = "cid"
        os.environ["DHAN_ACCESS_TOKEN"] = "tok"
        calls = []

        class FakeDhan:
            def __init__(self, cid, tok):
                calls.append(("init", cid, tok))

            def cancel_order(self, oid):
                calls.append(("cancel", oid))
                return {"success": True}

        mock_db = MagicMock()
        mock_db.get_active_orders.return_value = [
            {"order_id": "LIVE-002", "broker": "dhan", "broker_order_id": "DH-888"},
        ]
        try:
            with patch("core.kill_switch.get_db", return_value=mock_db), \
                 patch("core.broker_oms.DhanV2Client", FakeDhan):
                res = MasterKillSwitch.activate(reason="R1 test", operator="TEST")
        finally:
            os.environ.pop("DHAN_CLIENT_ID", None)
            os.environ.pop("DHAN_ACCESS_TOKEN", None)

        self.assertEqual(res["status"], "SUCCESS")
        self.assertEqual(res["cancelled_orders"], ["LIVE-002"])
        self.assertIn(("cancel", "DH-888"), calls)
        self.assertTrue(mock_db.update_order_status.called)

    def test_kite_order_without_creds_not_marked_cancelled(self):
        from core.kill_switch import MasterKillSwitch

        for k in ("KITE_API_KEY", "KITE_ACCESS_TOKEN"):
            os.environ.pop(k, None)
        mock_db = MagicMock()
        mock_db.get_active_orders.return_value = [
            {"order_id": "LIVE-003", "broker": "zerodha_kite", "broker_order_id": "K-999"},
        ]
        with patch("core.kill_switch.get_db", return_value=mock_db):
            res = MasterKillSwitch.activate(reason="R1 test", operator="TEST")
        self.assertEqual(res["failed_to_cancel_orders"], ["LIVE-003"])
        self.assertEqual(res["cancelled_orders"], [])
        self.assertFalse(mock_db.update_order_status.called)

    def test_paper_order_still_cancelled_locally(self):
        """Regression guard: local/paper orders (no live broker side) keep the
        original behavior — DB cancelled, counted in cancelled_orders."""
        from core.kill_switch import MasterKillSwitch

        mock_db = MagicMock()
        mock_db.get_active_orders.return_value = [
            {"order_id": "P-001", "broker": "paper"},
        ]
        with patch("core.kill_switch.get_db", return_value=mock_db):
            res = MasterKillSwitch.activate(reason="R1 test", operator="TEST")
        self.assertEqual(res["status"], "SUCCESS")
        self.assertEqual(res["cancelled_orders"], ["P-001"])
        mock_db.update_order_status.assert_called_once()


class TestR7BasketGateNavBasis(unittest.TestCase):
    """R7: submit_basket weights must be NAV-based, not basket-notional-based."""

    def test_focused_rebalance_basket_not_blocked(self):
        """Two names at ~5% of NAV each (90% cash) must PASS the portfolio
        concentration gate (previously evaluated as 50%/50% and blocked)."""
        from core.broker_oms import BrokerOrderManagementSystem

        oms = BrokerOrderManagementSystem(cfg={"RISK_MAX_STOCK_CONCENTRATION": 0.10})
        # NAV = 1,000,000; orders: 25k + 25k = 5% each
        orders = [
            {"ticker": "AAA.NS", "qty": 100, "price": 250.0, "ltp": 250.0},
            {"ticker": "BBB.NS", "qty": 50, "price": 500.0, "ltp": 500.0},
        ]
        res = oms.submit_basket("paper", orders, total_nav=1_000_000.0, dry_run=True)
        self.assertNotEqual(res.get("blocked_by"), "PORTFOLIO_RISK_GATE",
                             "A 5%-of-NAV rebalance basket must not be spuriously blocked")
        self.assertEqual(res.get("executed_count"), 2)

    def test_full_allocation_concentration_still_blocked(self):
        """A basket that IS the full allocation and breaches the 10% cap must
        still be BLOCKED (keeps Round-42 H-4 semantics)."""
        from core.broker_oms import BrokerOrderManagementSystem

        oms = BrokerOrderManagementSystem(cfg={"RISK_MAX_STOCK_CONCENTRATION": 0.10})
        orders = [{"ticker": "SINGLE.NS", "qty": 1000, "price": 1000.0, "ltp": 1000.0}]
        res = oms.submit_basket("paper", orders, total_nav=1_000_000.0, dry_run=True)
        self.assertEqual(res.get("blocked_by"), "PORTFOLIO_RISK_GATE")
        self.assertEqual(res.get("executed_count"), 0)

    def test_dhan_kite_rebalance_baskets_execute(self):
        """End-to-end regression for
        tests/test_institutional_architecture.py::test_dhan_and_kite_basket_execution
        (which the basket-notional normalization had broken).

        ROUND-43 (merged tree): prices are seeded hermetically — this tree's
        dhan/zerodha builders refuse to fabricate a ₹100 fill price for
        unpriceable tickers (AUDIT-04 class fix), so the cache must carry a
        real LTP for both names."""
        from data_layer import DynamicPriceResolver
        from optimizer_broker import dhan_place_basket, zerodha_place_basket

        DynamicPriceResolver._CACHE["ITC.NS"] = 400.0
        DynamicPriceResolver._CACHE["ASIANPAINT.NS"] = 2800.0
        weights = {"ITC.NS": 0.05, "ASIANPAINT.NS": 0.05, "CASH": 0.90}
        dhan_res = dhan_place_basket(
            weights=weights, portfolio_value=500_000.0,
            api_key="mock_key", client_id="mock_client", dry_run=True,
        )
        self.assertEqual(dhan_res["executed_count"], 2)
        kite_res = zerodha_place_basket(
            weights=weights, portfolio_value=500_000.0,
            api_key="mock_key", dry_run=True,
        )
        self.assertEqual(kite_res["executed_count"], 2)


class TestR9GatewayStockCapClamp(unittest.TestCase):
    """R9 / AUDIT-15: gateway single-stock cap = min(MAX_WEIGHT, 10%)."""

    def test_max_weight_profile_cannot_loosen_statutory_cap(self):
        from core.risk_gateway import HardPreTradeRiskGateway

        gw = HardPreTradeRiskGateway(cfg={"MAX_WEIGHT": 0.45})
        self.assertAlmostEqual(gw.max_stock_concentration, 0.10)

    def test_explicit_override_wins(self):
        from core.risk_gateway import HardPreTradeRiskGateway

        gw = HardPreTradeRiskGateway(cfg={"MAX_WEIGHT": 0.45, "RISK_MAX_STOCK_CONCENTRATION": 0.05})
        self.assertAlmostEqual(gw.max_stock_concentration, 0.05)

    def test_default_is_ten_percent(self):
        from core.risk_gateway import HardPreTradeRiskGateway

        gw = HardPreTradeRiskGateway(cfg={})
        self.assertAlmostEqual(gw.max_stock_concentration, 0.10)


class TestR10RouterFreezeDefault(unittest.TestCase):
    """R10 / AUDIT-17: router-side freeze fallback is 1,000 shares."""

    def test_angelone_adapter_default_freeze_qty(self):
        from math_engine.broker_router import AngelOneAdapter

        adapter = AngelOneAdapter()
        self.assertEqual(getattr(adapter, "_default_freeze_qty", None), 1_000)

    def test_unknown_symbol_freeze_default_in_source(self):
        """Source-lock: no 50,000 fallback remains at the router's freeze call sites."""
        src_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "math_engine", "broker_router.py",
        )
        with open(src_path, "r", encoding="utf-8") as fh:
            src = fh.read()
        self.assertNotIn('get("freeze_qty", 50000)', src)
        self.assertNotIn('get("freeze_limit", 50000)', src)


class TestR11CQMExport(unittest.TestCase):
    """R11: math_engine.CQMFormulator is the real QuantumCQMFormulator class."""

    def test_cqm_formulator_exported_and_real(self):
        import math_engine
        from math_engine.cqm_formulator import QuantumCQMFormulator

        self.assertIsNotNone(math_engine.CQMFormulator)
        self.assertIs(math_engine.CQMFormulator, QuantumCQMFormulator)
        self.assertIn("CQMFormulator", math_engine.__all__)
        self.assertIn("QuantumCQMFormulator", math_engine.__all__)


class TestR6PurgedCVDateAxis(unittest.TestCase):
    """R6 / AUDIT-06 (H-2): date-major folds + day-based time-axis embargo."""

    def _build_ticker_major_data(self, n_tickers=10, n_dates=60):
        """Ticker-major assembly (exactly the pattern the audit proved leaky)."""
        dates = pd.date_range("2024-01-01", periods=n_dates, freq="D")
        rows_X, rows_y, rows_dates = [], [], []
        for t in range(n_tickers):
            for d in dates:
                rows_X.append([float(t), float(d.dayofyear), float(t) * 0.1 + d.dayofyear * 0.01])
                rows_y.append(float((t + d.dayofyear) % 7) - 3.0)
                rows_dates.append(d)
        return np.array(rows_X), np.array(rows_y), pd.DatetimeIndex(rows_dates)

    def test_folds_are_time_blocks_and_embargo_is_day_based(self):
        from ml_alpha.archetype_models import compute_purged_embargo_cv_metrics

        X, y, dates = self._build_ticker_major_data()
        # Column 1 encodes the day-of-year so the recorder can read the
        # effective as-of value of every row the CV hands to fit_predict_fn.
        seen_folds = []

        def recorder(X_tr, y_tr, X_te):
            seen_folds.append({
                "train_doy": set(X_tr[:, 1].astype(int).tolist()),
                "test_doy": set(X_te[:, 1].astype(int).tolist()),
            })
            return np.zeros(len(X_te))

        res = compute_purged_embargo_cv_metrics(
            X, y, recorder, n_splits=5, embargo_fraction=0.02,
            as_of_dates=dates, embargo_days=7, fold_local_zscore=False,
        )
        # At least some folds must have produced calls
        self.assertTrue(len(seen_folds) >= 3, f"expected several folds, got {len(seen_folds)}")

        # (a) Every fold's test block must be a contiguous time block: the
        # day-of-years within one fold must span <= ~1/3 of the full span
        # (with 5 folds each block should be ~1/5, allow slack).
        for f in seen_folds:
            t_span = max(f["test_doy"]) - min(f["test_doy"])
            self.assertLessEqual(
                t_span, 30,
                f"test block spans {t_span} days — folds are splitting tickers, not time",
            )

        # (b) Day-based embargo: no train row's as-of within 7 days of any
        # test row's as-of (regardless of ticker).
        for f in seen_folds:
            for tr_d in f["train_doy"]:
                for te_d in f["test_doy"]:
                    self.assertGreater(
                        abs(tr_d - te_d), 7,
                        f"train day-of-year {tr_d} within 7d embargo of test {te_d}",
                    )

        # (c) Metrics structure intact
        for key in ("oos_sharpe", "oos_ic", "oos_ir", "dsr"):
            self.assertIn(key, res)

    def test_legacy_mode_without_dates_still_works(self):
        """Backward compatibility: as_of_dates=None keeps row-position folds."""
        from ml_alpha.archetype_models import compute_purged_embargo_cv_metrics

        rng = np.random.default_rng(0)
        X = rng.normal(size=(120, 4))
        y = rng.normal(size=120)
        seen = []

        def recorder(X_tr, y_tr, X_te):
            seen.append((len(X_tr), len(X_te)))
            return np.zeros(len(X_te))

        res = compute_purged_embargo_cv_metrics(X, y, recorder, n_splits=5)
        self.assertTrue(len(seen) >= 3)
        self.assertIn("oos_sharpe", res)

    def test_mismatched_dates_fall_back_without_crash(self):
        from ml_alpha.archetype_models import compute_purged_embargo_cv_metrics

        rng = np.random.default_rng(1)
        X = rng.normal(size=(60, 3))
        y = rng.normal(size=60)
        res = compute_purged_embargo_cv_metrics(
            X, y, lambda a, b, c: np.zeros(len(c)), n_splits=5,
            as_of_dates=pd.date_range("2024-01-01", periods=10),  # wrong length
        )
        self.assertIn("oos_sharpe", res)


class TestR8FoldLocalZScoring(unittest.TestCase):
    """R8 / AUDIT-19 (L-2): fold-local z-scoring with train-fold statistics."""

    def test_fit_predict_receives_train_normalized_features(self):
        from ml_alpha.archetype_models import compute_purged_embargo_cv_metrics

        rng = np.random.default_rng(2)
        # Column 0 has a huge train-fold mean; column 1 has tiny scale —
        # if the CV normalizes with train stats, the recorder must see
        # mean ~ 0 and std ~ 1 on the TRAIN matrix.
        X = np.column_stack([
            1000.0 + rng.normal(size=100),
            0.001 * rng.normal(size=100),
            rng.normal(size=100),
        ])
        y = rng.normal(size=100)
        checks = []

        def recorder(X_tr, y_tr, X_te):
            checks.append((
                np.allclose(X_tr.mean(axis=0), 0.0, atol=1e-9),
                np.allclose(X_tr.std(axis=0), 1.0, atol=1e-6),
            ))
            return np.zeros(len(X_te))

        compute_purged_embargo_cv_metrics(X, y, recorder, n_splits=5)
        self.assertTrue(len(checks) >= 3)
        for mean_ok, std_ok in checks:
            self.assertTrue(mean_ok, "train features must be fold-normalized (mean 0)")
            self.assertTrue(std_ok, "train features must be fold-normalized (std 1)")

    def test_test_fold_transformed_with_train_stats(self):
        """A test-fold-only constant offset must survive as a large value
        (proof that TEST statistics were not used for scaling)."""
        from ml_alpha.archetype_models import compute_purged_embargo_cv_metrics

        rng = np.random.default_rng(3)
        X = rng.normal(size=(100, 3))
        # Make the LAST 20 rows (test fold territory) hugely offset in col 0
        X[-20:, 0] += 500.0
        y = rng.normal(size=100)
        seen_te = []

        def recorder(X_tr, y_tr, X_te):
            seen_te.append(X_te[:, 0].copy())
            return np.zeros(len(X_te))

        compute_purged_embargo_cv_metrics(X, y, recorder, n_splits=5)
        # At least one fold's test set must include offset rows; those rows
        # must remain FAR from 0 after scaling (train stats, not test stats).
        found_far = any(np.max(np.abs(v)) > 10.0 for v in seen_te if len(v))
        self.assertTrue(found_far,
                        "offset test rows should remain large under train-stat scaling")


class TestNameErrorRegressions(unittest.TestCase):
    """R2/R3/R4/R5: latent NameErrors fixed."""

    def test_retrain_now_has_pandas(self):
        import ml_alpha.retrain_now as rn
        self.assertTrue(hasattr(rn, "pd"))

    def test_worker_threads_imports_urllib_error(self):
        src_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "workers", "worker_threads.py",
        )
        with open(src_path, "r", encoding="utf-8") as fh:
            src = fh.read()
        self.assertIn("import urllib.error", src,
                      "workers/worker_threads.py must import urllib.error (R3)")
        self.assertIn("except urllib.error.HTTPError", src)

    def test_app_py_telegram_alert_uses_pname(self):
        import inspect
        import web_dashboard.app as app_mod

        src = inspect.getsource(
            app_mod.AgenticDesktopBridge.send_real_telegram_single_profile_alert
        )
        self.assertNotIn("profile_name=profile_name", src,
                         "R5: undefined profile_name reference must be replaced by the pname parameter")
        self.assertIn("profile_name=pname", src)

    def test_app_py_datetime_persist_fix_present(self):
        src_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "web_dashboard", "app.py",
        )
        with open(src_path, "r", encoding="utf-8") as fh:
            src = fh.read()
        # R4: the gov/pledge persistence block must use a locally imported
        # datetime (previously NameError swallowed by bare excepts).
        self.assertIn("_dt_r4", src)


class TestR12DataLayerLoudDegradation(unittest.TestCase):
    """R12 / AUDIT-16: the two priority data_layer silent-except sites now
    degrade loudly (regression lock against silent reverts)."""

    def test_loud_handlers_present(self):
        src_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "data_layer.py",
        )
        with open(src_path, "r", encoding="utf-8") as fh:
            src = fh.read()
        self.assertIn("OHLCV cache write failed", src)  # [PriceCache] warning marker (merged-tree wording)
        self.assertIn("PIT fundamentals persistence failed", src)


if __name__ == "__main__":
    unittest.main()
