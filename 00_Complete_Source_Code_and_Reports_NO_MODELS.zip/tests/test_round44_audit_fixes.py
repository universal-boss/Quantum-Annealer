"""
Round 44 — regression locks for every fix delivered this round.

Each test locks one empirically-verified defect from BUGFIX_REPORT_ROUND44.md:

  R44-1  ui/tabs/ai_copilot.py — unguarded top-level `import markdown`
         (missing from requirements.txt) crashed the ENTIRE desktop app at
         import time via ui/main_window.py's unconditional import.
  R44-2  optimizer_compliance.evaluate_options_skew_warning returned False
         for expiry-dict chains without falling through to the SVI path —
         the OTM-put tail-risk warning could never fire for that format.
         (Root cause of the perpetually-skipped test_p2_warnings skew test.)
  R44-3  30 P2-5 "swallowed exception" logging calls used `{}` placeholders
         on %-style logging -> TypeError inside logging on EVERY call: the
         instrumentation never logged anything.
  R44-4  6 math_engine.__all__ exports were silently None (wrong module or
         wrong class names); QAOAPortfolioCompiler pointed at a module that
         never existed.
  R44-5  AlphaEngine defined __setstate__ twice (first definition dead).
  R44-6  requirements.txt missing direct deps markdown / pydantic.
  R44-7  utils_nse quoted annotation referenced a pd never importable at
         module scope.
"""
from __future__ import annotations

import ast
import importlib
import sys
import unittest
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))


# ── R44-2: the skew warning must fire for expiry-dict chains ─────────────

def _steep_skew_chain():
    spot, T = 100.0, 30.0 / 365.0
    puts = [
        {"strike": spot + k, "imp_vol": 0.15 + 0.005 * abs(k), "spot": spot, "T": T, "type": "put"}
        for k in (-20, -15, -10, -5, -2)
    ]
    atm = [
        {"strike": spot, "imp_vol": 0.15, "spot": spot, "T": T, "type": "put"},
        {"strike": spot, "imp_vol": 0.15, "spot": spot, "T": T, "type": "call"},
    ]
    calls = [
        {"strike": spot + k, "imp_vol": 0.15 + 0.002 * k, "spot": spot, "T": T, "type": "call"}
        for k in (2, 5, 10, 15, 20)
    ]
    return {"2024-01-25": puts + atm + calls}


def _flat_chain():
    spot, T = 100.0, 30.0 / 365.0
    rows = [
        {"strike": spot + k, "imp_vol": 0.15, "spot": spot, "T": T, "type": "put"}
        for k in (-20, -10, -5, 0)
    ] + [
        {"strike": spot + k, "imp_vol": 0.15, "spot": spot, "T": T, "type": "call"}
        for k in (0, 5, 10, 20)
    ]
    return {"2024-01-25": rows}


class TestR44_02SkewWarningFallthrough(unittest.TestCase):
    """R44-2: expiry-dict chains must reach the SVI/heuristic fallback."""

    def _fn(self):
        mod = importlib.import_module("optimizer_compliance")
        return mod.evaluate_options_skew_warning

    def test_steep_skew_expiry_dict_chain_fires_warning(self):
        fn = self._fn()
        result = fn(ticker="NIFTY", option_chain=_steep_skew_chain(), threshold=1.25)
        self.assertIs(result, True, "steep-skew expiry-dict chain must fire the tail-risk warning")

    def test_flat_chain_does_not_fire_warning(self):
        fn = self._fn()
        result = fn(ticker="NIFTY", option_chain=_flat_chain(), threshold=1.25)
        self.assertIs(result, False, "flat-vol chain must not fire the warning")

    def test_chain_rows_format_still_evaluated_by_path_one(self):
        """A DataFrame-style chain (chain_rows) must keep its existing semantics."""
        fn = self._fn()
        chain = {"chain_rows": []}  # empty rows -> parsed but nothing to evaluate
        result = fn(ticker="NIFTY", option_chain=chain, threshold=1.25)
        self.assertIsInstance(result, bool)


# ── R44-4: math_engine exports must resolve to real symbols ──────────────

class TestR44_04MathEngineExports(unittest.TestCase):
    """R44-4: no silently-None exports in math_engine.__all__."""

    def test_all_exports_resolve(self):
        """Every name fixed in Round 44 (plus the Round-43 pair) must resolve
        to a real symbol. Optional-dependency exports (websocket feed needs
        kiteconnect, etc.) may legitimately degrade to None when their
        library is absent — those are NOT in this list."""
        import math_engine
        must_resolve = [
            # Round-44 fixes
            "ExecutionEnv", "PPOExecutionAgent",
            "ExecutionLOBEnvironment", "RLExecutionPolicy",
            "WassersteinRadiusCalibrator", "WassersteinCalibrator",
            "LatentSpaceScreener", "LatentManifoldScreener",
            "MarketRegimeDetector", "RegimeDetector",
            # Round-43 fixes that must stay fixed
            "CQMFormulator", "QuantumCQMFormulator",
            "DhanExecutionRouter", "DhanAdapter",
        ]
        none_exports = [a for a in must_resolve if getattr(math_engine, a, None) is None]
        self.assertEqual(
            none_exports,
            [],
            f"silently-None exports remain (these must resolve to real symbols): {none_exports}",
        )

    def test_legacy_aliases_point_at_real_classes(self):
        import math_engine
        self.assertIs(math_engine.RegimeDetector, math_engine.MarketRegimeDetector)
        self.assertIs(math_engine.WassersteinCalibrator, math_engine.WassersteinRadiusCalibrator)
        self.assertIs(math_engine.LatentManifoldScreener, math_engine.LatentSpaceScreener)
        self.assertIs(math_engine.ExecutionLOBEnvironment, math_engine.ExecutionEnv)
        self.assertIs(math_engine.RLExecutionPolicy, math_engine.PPOExecutionAgent)

    def test_dead_qaoa_export_removed(self):
        import math_engine
        self.assertNotIn("QAOAPortfolioCompiler", math_engine.__all__)
        self.assertFalse(hasattr(math_engine, "QAOAPortfolioCompiler"))

    def test_exports_survive_reverse_import_order(self):
        """R44-4b (circular import): importing web_dashboard.app BEFORE
        math_engine used to leave Latent*/Regime* exports None for the whole
        process, because latent_screener/regime_detector imported names from
        a partially-initialized utils. The imports are deferred now — verify
        in a FRESH subprocess that the hostile order resolves everything."""
        import subprocess
        code = (
            "import sys; sys.path.insert(0, r'%s')\n"
            "from web_dashboard.app import AgenticDesktopBridge\n"
            "import math_engine\n"
            "bad = [a for a in ('LatentSpaceScreener','LatentManifoldScreener',"
            "'MarketRegimeDetector','RegimeDetector') if getattr(math_engine, a, None) is None]\n"
            "assert not bad, f'silently-None exports under web-first import order: {bad}'\n"
            "print('ORDER-OK')\n"
        ) % str(PROJECT_ROOT)
        r = subprocess.run(
            [sys.executable, "-c", code], capture_output=True, text=True, timeout=600,
            cwd=str(PROJECT_ROOT),
        )
        self.assertIn(
            "ORDER-OK", r.stdout,
            f"math_engine exports degrade under web_dashboard-first import order "
            f"(circular import regression): stdout={r.stdout[-400:]!r} stderr={r.stderr[-800:]!r}",
        )


# ── R44-3: P2-5 logging calls must use %-style placeholders ───────────────

class TestR44_03LoggingFormat(unittest.TestCase):
    """R44-3: no `{}` placeholders left on %-style logging calls."""

    FILES = (
        "ml_alpha/engine.py",
        "optimizer.py",
        "optimizer_broker.py",
        "utils.py",
        "data_layer.py",
        "scripts/sweep_except_handlers.py",
    )

    def test_no_brace_placeholders_in_swallow_logging(self):
        offenders = []
        for rel in self.FILES:
            p = PROJECT_ROOT / rel
            if not p.exists():
                continue
            for i, line in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
                if "swallowed exception in {}" in line:
                    offenders.append(f"{rel}:{i}")
        self.assertEqual(offenders, [], f"broken %-vs-{{}} logging sites remain: {offenders}")

    def test_p25_message_actually_logs(self):
        """Behavioral lock: a fixed P2-5 call must emit its message with no logging error."""
        import io
        import logging
        stream = io.StringIO()
        handler = logging.StreamHandler(stream)
        lg = logging.getLogger("quantum_annealer.r44_t")
        lg.addHandler(handler)
        lg.setLevel(logging.DEBUG)
        try:
            lg.debug("[AUDIT-FIX P2-5] swallowed exception in %s", "ImportError", exc_info=True)
        finally:
            lg.removeHandler(handler)
        out = stream.getvalue()
        self.assertIn("swallowed exception in ImportError", out)
        self.assertNotIn("--- Logging error ---", out)


# ── R44-5: AlphaEngine must define __setstate__ exactly once ─────────────

class TestR44_05SingleSetstate(unittest.TestCase):
    def test_alpha_engine_has_exactly_one_setstate(self):
        src = (PROJECT_ROOT / "ml_alpha" / "engine.py").read_text(encoding="utf-8")
        tree = ast.parse(src)
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef) and node.name == "AlphaEngine":
                defs = [
                    n.lineno
                    for n in node.body
                    if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == "__setstate__"
                ]
                self.assertEqual(
                    len(defs), 1,
                    f"AlphaEngine must define __setstate__ exactly once (found at lines {defs}); "
                    f"a duplicate silently shadows the first definition",
                )
                return
        self.fail("AlphaEngine class not found")


# ── R44-1 / R44-6: markdown must be optional AND declared ─────────────────

class TestR44_01_06MarkdownDependency(unittest.TestCase):
    """R44-1: the markdown import in ai_copilot must be guarded (the module
    is imported unconditionally by ui/main_window.py, so an unguarded optional
    dep crashes the whole desktop app). R44-6: it must also be declared."""

    def _markdown_import_nodes(self):
        src = (PROJECT_ROOT / "ui" / "tabs" / "ai_copilot.py").read_text(encoding="utf-8")
        tree = ast.parse(src)
        nodes = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.name == "markdown":
                        nodes.append((node, alias))
            elif isinstance(node, ast.ImportFrom) and node.module == "markdown":
                nodes.append((node, None))
        return nodes, tree

    def test_markdown_import_is_guarded(self):
        nodes, tree = self._markdown_import_nodes()
        self.assertTrue(nodes, "ai_copilot no longer references markdown at all?")
        # every module-level `import markdown` must sit inside a Try block
        for node, _alias in nodes:
            inside_try = any(
                isinstance(parent, ast.Try)
                for parent in ast.walk(tree)
                if node in ast.iter_child_nodes(parent) or any(
                    node is child for child in _direct_children(parent)
                )
            )
            # simpler, position-based check: a Try whose body spans this line
            spans = any(
                isinstance(parent, ast.Try)
                and (parent.lineno <= node.lineno <= max(
                    getattr(parent, "end_lineno", parent.lineno),
                    max((getattr(b, "end_lineno", b.lineno) for b in parent.body), default=parent.lineno),
                ))
                for parent in ast.walk(tree)
            )
            self.assertTrue(
                spans or inside_try,
                f"`import markdown` at line {node.lineno} is not guarded by try/except — "
                f"an unguarded optional-dep import crashes the whole desktop app",
            )

    def test_requirements_declare_markdown_and_pydantic(self):
        req = (PROJECT_ROOT / "requirements.txt").read_text(encoding="utf-8")
        for lib in ("markdown", "pydantic"):
            self.assertTrue(
                any(line.strip().startswith(lib) for line in req.splitlines()),
                f"requirements.txt must declare the directly-imported dependency `{lib}`",
            )


def _direct_children(node):
    for _name, value in ast.iter_fields(node):
        if isinstance(value, list):
            for item in value:
                if isinstance(item, ast.AST):
                    yield item
        elif isinstance(value, ast.AST):
            yield value


# ── R44-7: utils_nse annotation must be statically resolvable ────────────

class TestR44_07UtilsNseAnnotation(unittest.TestCase):
    def test_type_checking_pd_import_present(self):
        src = (PROJECT_ROOT / "utils_nse.py").read_text(encoding="utf-8")
        self.assertIn("TYPE_CHECKING", src, "utils_nse must guard the pd annotation with TYPE_CHECKING")
        # and no unguarded module-level `import pandas` was added (module load must stay light)
        tree = ast.parse(src)
        for node in tree.body:
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                names = [a.name for a in node.names] if isinstance(node, ast.Import) else [node.module or ""]
                for n in names:
                    self.assertFalse(
                        n.split(".")[0] == "pandas",
                        "utils_nse must NOT import pandas at module level (design: local/deferred import)",
                    )


if __name__ == "__main__":
    unittest.main(verbosity=2)
