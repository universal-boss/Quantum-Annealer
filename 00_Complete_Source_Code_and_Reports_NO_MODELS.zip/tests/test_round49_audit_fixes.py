#!/usr/bin/env python3
"""Round 49 regression locks — Quantum Annealer.

Permanent pytest mirrors of the R49 fix contracts (see
_AUDIT_DELIVERY/verify_fixes_r49.py for the full behavioral proofs):

  R49-1  _AUDIT_DELIVERY/verify_fixes.py is machine-portable (no hardcoded
         auditor workspace path; ROOT resolved from __file__).
  R49-2  Six persisted-state writes are tear-proof (atomic tmp+os.replace or
         delegation to the atomic utils.write_json_cache); the tax
         carry-forward ledger additionally rotates a parse-guarded last-good
         .bak and the reader RECOVERS from a torn primary instead of
         silently zeroing the carry-forward position.
  R49-3  AlgoExecutionManager.record_fill keeps slice states as the single
         source of truth: cumulative partial updates never double-count
         manager totals, and avg_fill_price stays the true slice VWAP.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


# ═════════════════════════════════════════════════════════════════════════════
# R49-1 — portable verification suite
# ═════════════════════════════════════════════════════════════════════════════

class TestR49VerifySuitePortable:
    def test_no_hardcoded_workspace_path(self):
        src = (ROOT / "_AUDIT_DELIVERY" / "verify_fixes.py").read_text(encoding="utf-8")
        assert "/home/z/" not in src, (
            "the R44 suite must run on the owner's machine — it previously "
            "hardcoded the auditing agent's workspace path")

    def test_root_resolved_from_file(self):
        src = (ROOT / "_AUDIT_DELIVERY" / "verify_fixes.py").read_text(encoding="utf-8")
        assert "os.path.dirname(os.path.dirname(os.path.abspath(__file__)))" in src

    def test_r44_battery_runs_from_unrelated_cwd(self):
        """The exact crash class R49-1 fixed: any cwd other than the audit
        workspace used to kill the suite before the first check."""
        with tempfile.TemporaryDirectory() as td:
            proc = subprocess.run(
                [sys.executable, str(ROOT / "_AUDIT_DELIVERY" / "verify_fixes.py")],
                cwd=td, capture_output=True, text=True, timeout=600)
        assert proc.returncode == 0, proc.stderr[-800:]
        assert "fix verifications passed" in proc.stdout


# ═════════════════════════════════════════════════════════════════════════════
# R49-2 — tear-proof state writes
# ═════════════════════════════════════════════════════════════════════════════

class TestR49AtomicWrites:
    def test_app_has_atomic_helper_and_uses_it(self):
        import web_dashboard.app as app  # noqa: F401
        src = (ROOT / "web_dashboard" / "app.py").read_text(encoding="utf-8")
        assert "def _atomic_write_json" in src
        assert "os.replace" in src
        assert 'with open(_CARRY_FORWARD_STATE_FILE, "w"' not in src
        assert 'with open(SETTINGS_FILE, "w"' not in src

    def test_data_layer_sebi_cache_uses_atomic_helper(self):
        src = (ROOT / "data_layer.py").read_text(encoding="utf-8")
        assert "write_json_cache(LARGE_MID_SMALL_CACHE_PATH" in src, (
            "the SEBI caps cache mirror must go through the atomic "
            "utils.write_json_cache helper, not a manual open(w)+json.dump")

    @pytest.mark.parametrize("rel", [
        "data/dynamic_security_master.py",
        "math_engine/regime_detector.py",
        "math_engine/broker_router.py",
    ])
    def test_site_writes_atomically(self, rel):
        src = (ROOT / rel).read_text(encoding="utf-8")
        assert "os.replace" in src, f"{rel} must write caches atomically (R49-2)"

    def test_dsm_cache_save_atomic_roundtrip(self):
        import data.dynamic_security_master as dsm_mod
        with tempfile.TemporaryDirectory() as td:
            cache = Path(td) / "dsm.json"
            orig = dsm_mod.CACHE_FILE
            try:
                dsm_mod.CACHE_FILE = cache
                m = dsm_mod.DynamicSecurityMaster.__new__(dsm_mod.DynamicSecurityMaster)
                m._active_equities = {"RELIANCE": {"name": "Reliance",
                                                   "isin": "INE002A01018",
                                                   "series": "EQ",
                                                   "listing_date": "1995-01-01"}}
                m._symbol_changes = {}
                m._resolved_cache = {}
                m._last_sync_timestamp = time.time()
                m._save_local_cache()
                payload = json.loads(cache.read_text(encoding="utf-8"))
                assert payload["active_equities"]["RELIANCE"]["isin"] == "INE002A01018"
                assert not list(Path(td).glob("*.tmp*")), "tmp litter left behind"
            finally:
                dsm_mod.CACHE_FILE = orig

    def test_atomic_write_json_crash_leaves_old_content(self):
        """A write that dies mid-way must leave the previous file intact."""
        import web_dashboard.app as app
        with tempfile.TemporaryDirectory() as td:
            target = Path(td) / "state.json"
            app._atomic_write_json(target, {"v": 1})
            import builtins
            real_open = builtins.open

            class _Boom(RuntimeError):
                pass

            def crashing_open(p, *a, **k):
                if str(p).endswith(".tmp"):
                    raise _Boom("simulated crash mid-write")
                return real_open(p, *a, **k)

            builtins.open = crashing_open
            try:
                with pytest.raises(_Boom):
                    app._atomic_write_json(target, {"v": 2})
            finally:
                builtins.open = real_open
            assert json.loads(target.read_text(encoding="utf-8")) == {"v": 1}
            assert not list(Path(td).glob("*.tmp*"))


class TestR49CarryForwardRecovery:
    def test_torn_primary_recovers_bak(self):
        """The money-critical R49-2 member: a torn tax_carry_forward.json
        must recover the last-good .bak instead of silently zeroing every
        accumulated Sec 70/74 loss vintage (which the next write would then
        make permanent — the operator pays tax on losses already suffered)."""
        import web_dashboard.app as app
        with tempfile.TemporaryDirectory() as td:
            state = Path(td) / "tax_carry_forward.json"
            bak = state.with_suffix(state.suffix + ".bak")
            good = {"AY 2024-25": {"unabsorbed_stcl_inr": 120000.0,
                                   "unabsorbed_ltcl_inr": 0.0,
                                   "updated_at": "2025-04-01 10:00:00"}}
            bak.write_text(json.dumps(good), encoding="utf-8")
            state.write_text('{"AY 2024-25": {"unabsorbed_stcl_inr": 12000',
                             encoding="utf-8")  # torn mid-dump
            orig = app._CARRY_FORWARD_STATE_FILE
            try:
                app._CARRY_FORWARD_STATE_FILE = state
                out = app._ledger_carry_forward_state(None, current_ay="AY 2025-26")
            finally:
                app._CARRY_FORWARD_STATE_FILE = orig
            assert out["unabsorbed_stcl_inr"] == pytest.approx(120000.0)
            assert "AY 2024-25" in out["vintages"]

    def test_persist_rotates_parse_guarded_bak(self):
        """The writer rotates a last-good .bak — but never copies a TORN
        primary over a good backup (parse-guarded rotation)."""
        import web_dashboard.app as app
        with tempfile.TemporaryDirectory() as td:
            state = Path(td) / "tax_carry_forward.json"
            bak = state.with_suffix(state.suffix + ".bak")
            good = {"AY 2024-25": {"unabsorbed_stcl_inr": 90000.0,
                                   "unabsorbed_ltcl_inr": 0.0,
                                   "updated_at": "2025-04-01 10:00:00"}}
            bak.write_text(json.dumps(good), encoding="utf-8")
            state.write_text('{"AY 2024-25": {"unabsorbed', encoding="utf-8")  # torn
            orig = app._CARRY_FORWARD_STATE_FILE
            try:
                app._CARRY_FORWARD_STATE_FILE = state
                app._persist_carry_forward_state(
                    "AY 2025-26",
                    {"without_harvest": {
                        "brought_forward_stcl_inr": 90000.0,
                        "brought_forward_ltcl_inr": 0.0,
                        "intra_year_stcl_inr": 0.0,
                        "intra_year_ltcl_inr": 0.0,
                        "unabsorbed_stcl": 90000.0,
                        "unabsorbed_ltcl": 0.0}},
                    loaded_vintages={"AY 2024-25": {"unabsorbed_stcl_inr": 90000.0,
                                                    "unabsorbed_ltcl_inr": 0.0}})
            finally:
                app._CARRY_FORWARD_STATE_FILE = orig
            # primary holds the new state (nothing consumed, all survives)
            written = json.loads(state.read_text(encoding="utf-8"))
            assert written["AY 2024-25"]["unabsorbed_stcl_inr"] == pytest.approx(90000.0)
            # the .bak was NOT clobbered with the torn primary
            assert json.loads(bak.read_text(encoding="utf-8")) == good
            assert not list(Path(td).glob("*.tmp*"))


# ═════════════════════════════════════════════════════════════════════════════
# R49-3 — record_fill bookkeeping
# ═════════════════════════════════════════════════════════════════════════════

class TestR49RecordFill:
    def test_once_per_slice_full_fill_unchanged(self):
        """The production caller (ui/main_window.py) records each slice's
        full fill exactly once — totals and VWAP must match the classic
        arithmetic exactly."""
        from math_engine.algo_execution import AlgoExecutionManager
        mgr = AlgoExecutionManager("RELIANCE.NS", 1000, "TWAP", 60, 5, 100.0)
        mgr.record_fill(1, 200, 100.0)
        mgr.record_fill(2, 200, 101.0)
        assert mgr.filled_qty == 400
        assert mgr.remaining_qty == 600
        assert mgr.avg_fill_price == pytest.approx(100.5)
        assert mgr.slices[0]["status"] == "COMPLETED"

    def test_cumulative_partial_no_double_count(self):
        """The R49-3 defect: a second, larger cumulative update for the same
        slice used to ADD to the manager total while REPLACING the slice
        field (old code: 40 + 150 = 190 instead of 150)."""
        from math_engine.algo_execution import AlgoExecutionManager
        mgr = AlgoExecutionManager("TCS.NS", 1000, "TWAP", 60, 5, 100.0)
        mgr.record_fill(1, 40, 100.0)
        mgr.record_fill(1, 150, 100.8)  # cumulative 150 of 200
        assert mgr.filled_qty == 150
        assert mgr.remaining_qty == 850
        assert mgr.slices[0]["filled_qty"] == 150
        assert mgr.slices[0]["status"] == "PARTIAL"
        assert mgr.avg_fill_price == pytest.approx(100.8)

    def test_invariant_totals_equal_slice_sum(self):
        from math_engine.algo_execution import AlgoExecutionManager
        mgr = AlgoExecutionManager("INFY.NS", 600, "TWAP", 60, 3, 100.0)
        mgr.record_fill(1, 100, 99.0)
        mgr.record_fill(2, 200, 101.0)
        mgr.record_fill(2, 200, 101.5)   # re-stated avg for a completed slice
        mgr.record_fill(3, 50, 100.5)
        assert mgr.filled_qty == 350
        assert mgr.avg_fill_price == pytest.approx(
            (100 * 99.0 + 200 * 101.5 + 50 * 100.5) / 350)

    def test_is_adapter_total_remaining_path(self):
        """filled_qty feeds the IS adapter's total_remaining — an over-count
        used to zero pending slices early (L11 path) and under-execute."""
        from math_engine.algo_execution import AlgoExecutionManager
        mgr = AlgoExecutionManager("SBIN.NS", 300, "IMPLEMENTATION SHORTFALL",
                                   60, 3, 500.0)
        for i in (1, 2, 3):
            mgr.record_fill(i, 100, 500.0)
        mgr.update_market_price(505.0)
        assert mgr.filled_qty == 300
        assert all(s["status"] == "COMPLETED" for s in mgr.slices)


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-q"]))
