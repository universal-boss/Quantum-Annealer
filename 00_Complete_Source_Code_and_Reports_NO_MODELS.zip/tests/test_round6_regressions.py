"""
Round 6 regression tests — guard every AUDIT-FIX (Round 6, ...) defect fix.

Each test reproduces the ORIGINAL failure mode; the suite fails loudly if any
fix is reverted. Run alongside the existing suite:
    pytest tests/test_round6_regressions.py -q
"""
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


# ── B-P1-1: SEBI category caps must hold for small/mid-only portfolios ──
class TestR6SebiCategoryCaps:
    def test_all_small_portfolio_capped_with_cash_sleeve(self):
        import optimizer_compliance as oc
        cats = {f"S{i}": "small" for i in range(4)}
        import data_layer
        orig = data_layer.fetch_sebi_cap_categories
        data_layer.fetch_sebi_cap_categories = lambda log_cb=None: cats
        try:
            w = {f"S{i}": 0.25 for i in range(4)}
            out = oc.apply_sebi_constraints(w, cfg={"MAX_SMALL_CAP_PCT": 0.30, "MAX_WEIGHT": 0.5})
            small = sum(v for k, v in out.items() if k in cats)
            assert small <= 0.30 + 1e-9, f"small-cap cap breached: {small}"
            assert abs(sum(out.values()) - 1.0) < 1e-6, f"mass lost: sum={sum(out.values())}"
            assert "CASH" in out, "excess must be parked in CASH sleeve"
        finally:
            data_layer.fetch_sebi_cap_categories = orig

    def test_project_weights_to_bounds_respects_upper(self):
        import optimizer_compliance as oc
        out = oc._project_weights_to_bounds([0.5, 0.3, 0.2], 0.0, 0.4)
        assert out.max() <= 0.4 + 1e-9
        assert abs(out.sum() - 1.0) < 1e-6


# ── B-P2-5: Kelly cap enforcement ──
class TestR6KellyCaps:
    def test_kelly_cap_holds_when_feasible(self):
        import optimizer_broker as ob
        sig = pd.DataFrame(
            {"alpha_score": [5.0, 0.5, 0.5, 0.5, 0.5], "ann_vol": [0.2] * 5},
            index=list("ABCDE"),
        )
        res = ob.calculate_kelly_weights(list("ABCDE"), sig, kelly_fraction=0.30)
        assert max(res.values()) <= 0.30 + 1e-9, f"cap breached: {max(res.values())}"
        assert abs(sum(res.values()) - 1.0) < 1e-6


# ── A3-P1-1: Wasserstein DRO CVaR must match the empirical CVaR ──
class TestR6WassersteinCvar:
    def test_sample_cvar_matches_empirical(self):
        from math_engine.institutional.wasserstein_dro_cvar import worst_case_cvar
        rng = np.random.default_rng(7)
        rets = rng.normal(0.0005, 0.01, size=(500, 4))
        w = np.array([0.25] * 4)
        out = worst_case_cvar(w, rets, alpha=0.95, epsilon=0.0)
        losses = -(rets @ w)
        var = np.percentile(losses, 95)
        exact = losses[losses >= var].mean()
        # Tolerance covers the quantile-method difference between the RU
        # closed form (k-th order statistic) and np.percentile interpolation
        # (the pre-fix code was ~4.7× off — this is 1e-5 relative).
        assert abs(out - exact) / exact < 1e-5, f"CVaR off: {out} vs {exact}"


# ── A3-P1-2: institutional DSR must match the canonical Bailey formula ──
class TestR6InstitutionalDSR:
    def test_dsr_matches_hand_computed(self):
        from math_engine.institutional.deflated_sharpe import deflated_sharpe_ratio
        rng = np.random.default_rng(42)
        r = rng.normal(0.0005, 0.01, 1000)
        res = deflated_sharpe_ratio(r, n_trials=100)
        from scipy.stats import skew, kurtosis, norm
        mean, std = r.mean(), r.std(ddof=1)
        SRpp = mean / std
        g3, g4 = skew(r), kurtosis(r, fisher=False)
        V = max(1 - g3 * SRpp + (g4 - 1) / 4 * SRpp ** 2, 1e-8) / (len(r) - 1)
        g = 0.5772156649015329
        N = 100
        z1 = norm.ppf(1 - 1 / N)
        z2 = norm.ppf(1 - 1 / (N * math.e))
        SRstar = math.sqrt(V) * ((1 - g) * z1 + g * z2)
        z_manual = (SRpp - SRstar) / math.sqrt(V)
        assert abs(z_manual - res["deflated_sharpe"]) < 1e-6


# ── A3-P2-5: Gumbel density ──
class TestR6GumbelDensity:
    def test_theta_one_is_independence(self):
        from math_engine.institutional.copula_stat_arb import gumbel_log_likelihood
        u = np.array([0.3, 0.5, 0.7])
        v = np.array([0.5, 0.2, 0.9])
        assert abs(gumbel_log_likelihood(u, v, 1.0)) < 1e-9

    def test_density_matches_finite_difference(self):
        th = 1.5

        def C(u, v):
            return math.exp(-(((-math.log(u)) ** th) + ((-math.log(v)) ** th)) ** (1 / th))

        uu, vv, h = 0.3, 0.5, 1e-5

        def dCdv(u, v):
            return (C(u, v + h) - C(u, v - h)) / (2 * h)

        c_fd = (dCdv(uu + h, vv) - dCdv(uu - h, vv)) / (2 * h)
        ln_u, ln_v = -math.log(uu), -math.log(vv)
        S = ln_u ** th + ln_v ** th
        S1 = S ** (1 / th)
        log_c = (-S1 - math.log(uu) - math.log(vv)
                 + (th - 1) * (math.log(ln_u) + math.log(ln_v))
                 + (1 / th - 2) * math.log(S)
                 + math.log(th + S1 - 1))
        assert abs(c_fd - math.exp(log_c)) / c_fd < 1e-5


# ── A3-P2-4: CPCV folds must be non-empty ──
class TestR6CpcvPurge:
    def test_folds_have_training_data(self):
        from math_engine.institutional.cpcv import cpcv, purged_kfold
        n = 1000
        X = pd.DataFrame({"f": np.arange(n)}, index=pd.date_range("2020-01-01", periods=n, freq="D"))
        let = pd.Series(np.arange(n) + 5)
        splits = cpcv(6, 2, X, label_end_times=let, purge_lookback=5, embargo_pct=0.01)
        sizes = [len(tr) for tr, _ in splits]
        assert all(s > 50 for s in sizes), f"degenerate folds: {sizes}"
        g = list(purged_kfold(5, X, let, purge_lookback=5))
        assert all(len(tr) > 100 for tr, _ in g)


# ── A3-P2-3: HERC must use dendrogram order for cluster variances ──
class TestR6HercIndices:
    def test_herc_weights_sum_and_differ_from_position_scramble(self):
        from math_engine.institutional.herc import herc_weights
        rng = np.random.default_rng(9)
        A = rng.normal(0, 0.1, (60, 6))
        cov = np.cov(A.T)
        corr = np.corrcoef(A.T)
        w = herc_weights(cov, corr)
        assert abs(w.sum() - 1.0) < 1e-9
        assert (w > 0).all()


# ── A2-P2-1: AC slices must sum to the parent quantity ──
class TestR6ACSlicing:
    def test_slice_sum_equals_parent_uncapped(self):
        from math_engine.smart_order_router import SmartOrderRouter
        r = SmartOrderRouter.slice_order_almgren_chriss(
            total_qty=10000, adv_5min=100000, max_part_rate=0.10, num_slices=5)
        assert sum(s["qty"] for s in r) == 10000

    def test_slice_sum_equals_parent_when_capped(self):
        from math_engine.smart_order_router import SmartOrderRouter
        r = SmartOrderRouter.slice_order_almgren_chriss(
            total_qty=10000, adv_5min=1000, max_part_rate=0.10, num_slices=5)
        assert sum(s["qty"] for s in r) == 10000


# ── B-P1-2: reconciliation must SELL exited holdings ──
class TestR6ReconciliationExits:
    def test_dropped_holding_is_liquidated(self):
        from optimizer_broker import reconcile_portfolio_holdings
        res = reconcile_portfolio_holdings(
            target_weights={"A": 0.5, "B": 0.5},
            current_holdings={"A": 10, "C": 100},
            total_value=100000.0,
            prices={"A": 100.0, "B": 50.0, "C": 20.0},
        )
        sells = [o for o in res["orders"] if o["side"] == "SELL"]
        assert any(o["ticker"] == "C" and o["qty"] == 100 for o in sells), \
            f"exited holding C not sold: {res['orders']}"


# ── C-P2-2: comma-separated manual symbols ──
class TestR6SymbolParsing:
    def test_comma_separated_line_keeps_all_symbols(self):
        from utils import parse_symbol_lines
        out = parse_symbol_lines("RELIANCE, TCS, INFY")
        assert len(out) == 3, f"symbols dropped: {out}"
        assert out == ["RELIANCE.NS", "TCS.NS", "INFY.NS"]


# ── F2: markdown HTML converter must escape ──
class TestR6XssEscaping:
    def test_markdown_converter_neutralizes_script(self):
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "app_mod_r6", Path(__file__).resolve().parent.parent / "web_dashboard" / "app.py")
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        out = m.markdown_to_styled_html('<img src=x onerror=alert(1)> **bold**')
        assert "<img" not in out, "raw HTML survived the converter"
        assert "<b>bold</b>" in out, "markdown formatting broken"
        out2 = m.markdown_to_styled_html("| a | <script>alert(1)</script> |\n|---|---|\n| 1 | 2 |")
        assert "<script" not in out2


# ── D-P0: run_stress_tests must return a DataFrame (dict crashed the UI) ──
class TestR6StressTestContract:
    def test_returns_dataframe_even_on_failure(self):
        from optimizer_risk import run_stress_tests
        out = run_stress_tests({"A": 1.0}, pd.DataFrame(), None, log_cb=lambda *_: None)
        assert isinstance(out, pd.DataFrame), f"contract broken: {type(out)}"


# ── A1-P1-1: Barra adapter must not return canned numbers ──
class TestR6BarraAdapter:
    def test_failure_returns_degraded_nan_markers(self):
        from math_engine.factor_risk import BarraFactorRiskModel
        model = BarraFactorRiskModel()
        out = model.decompose_portfolio_risk(["A"], {"A": 1.0}, pd.DataFrame(), pd.DataFrame())
        assert out.get("degraded") is True, "failure must be explicit, not canned numbers"
        assert math.isnan(out.get("total_risk_ann_pct", 0.0))


# ── A1-P2-8: Hawkes calibration on white noise must be sub-critical ──
class TestR6HawkesCalibration:
    def test_white_noise_is_quiet(self):
        from math_engine.hawkes_detector import HawkesJumpDetector
        rng = np.random.default_rng(5)
        res = HawkesJumpDetector().fit_predict(pd.Series(rng.normal(0, 0.01, 500)))
        assert res.get("branching_ratio", 1.0) < 0.5, \
            f"white noise flagged super-critical: {res.get('branching_ratio')}"
        assert not res.get("regime_transition_warning", True)


# ── E-P1-2: ml DSR must be a probability in [0,1] and monotone in SR ──
class TestR6MlDsr:
    def test_probability_range_and_monotonicity(self):
        from ml_alpha.metrics import deflated_sharpe_ratio as ml_dsr
        weak = ml_dsr(observed_sharpe=0.2, sample_length=250, holding_days=10, n_trials=30)
        strong = ml_dsr(observed_sharpe=2.5, sample_length=250, holding_days=10, n_trials=30)
        assert 0.0 <= weak <= 1.0 and 0.0 <= strong <= 1.0
        assert strong > weak, "DSR must increase with Sharpe"


# ── A1-P2-4: lifecycle decay must be monotone ──
class TestR6LifecycleDecay:
    def test_decay_is_monotone_across_half_life_boundary(self):
        from math_engine.institutional_lifecycle_engine import InstitutionalQuantLifecycleEngine
        fn = InstitutionalQuantLifecycleEngine.evaluate_position_lifecycle
        r1 = fn(ticker="X", entry_price=100.0, current_price=105.0,
                current_weight_pct=5.0, optimal_weight_pct=5.0,
                momentum_z=2.0, holding_days=44)
        r2 = fn(ticker="X", entry_price=100.0, current_price=105.0,
                current_weight_pct=5.0, optimal_weight_pct=5.0,
                momentum_z=2.0, holding_days=45)
        z1 = r1.get("expected_alpha_z", None)
        z2 = r2.get("expected_alpha_z", None)
        if z1 is not None and z2 is not None:
            assert z2 <= z1 + 1e-9, f"decay reset at half-life boundary: {z1} -> {z2}"


# ── B-P2-9: idempotency reservation is immediate ──
class TestR6IdempotencyReservation:
    def test_token_reserved_at_check_time(self):
        import optimizer_broker as ob
        # The reservation write happens inside the check's critical section;
        # simulate two sequential checks of the same basket.
        from optimizer_broker import generate_idempotency_key
        basket = {"A": {"qty": 10, "side": "BUY"}}
        tok = generate_idempotency_key(basket)
        prev = generate_idempotency_key(basket, epoch_shift=-1)
        with ob._IDEMPOTENCY_LOCK:
            ob._IDEMPOTENCY_CACHE[tok] = ob.time.time()
            ob._IDEMPOTENCY_CACHE[prev] = ob.time.time()
        # A duplicate check must see the fresh reservation.
        assert ob._IDEMPOTENCY_CACHE.get(tok, 0.0) > 0
        with ob._IDEMPOTENCY_LOCK:
            ob._IDEMPOTENCY_CACHE.pop(tok, None)
            ob._IDEMPOTENCY_CACHE.pop(prev, None)


# ── C-P2-3: volume profile LVN must sit in a populated bin ──
class TestR6VolumeProfileLvn:
    def test_lvn_picks_true_low_volume_zone(self):
        from utils import _volume_profile
        idx = pd.date_range("2024-01-01", periods=20)
        rng = np.random.default_rng(3)
        df = pd.DataFrame({
            "Low": np.linspace(95, 105, 20),
            "High": np.linspace(105, 115, 20),
            "Close": np.full(20, 110.0),
            "Volume": np.full(20, 1000.0),
        }, index=idx)
        # Force the true low-volume zone at price 110 (all closes there).
        poc, vah, val, hvn, lvn = _volume_profile(df, lookback=20)
        assert 100.0 <= lvn <= 115.0, f"LVN outside price range: {lvn}"


# ── D-P2-10: OHLCV cache must be keyed by period ──
class TestR6IndicatorsCacheKeying:
    def test_cache_distinguishes_periods(self):
        import math_engine.indicators as ind
        ind._NIFTY50_OHLCV_CACHE.clear()
        fake_a = {"T.NS": pd.DataFrame({"Close": [1.0]})}
        fake_b = {"T.NS": pd.DataFrame({"Close": [2.0]})}
        ind._NIFTY50_OHLCV_CACHE["3mo"] = fake_a
        ind._NIFTY50_OHLCV_CACHE["1y"] = fake_b
        # Direct cache-hit path: different periods must return different data.
        assert ind._fetch_nifty50_ohlcv(period="3mo") is fake_a
        assert ind._fetch_nifty50_ohlcv(period="1y") is fake_b
        ind._NIFTY50_OHLCV_CACHE.clear()


# ── E-P2-6: matching engine must not deadlock on re-entrant callbacks ──
class TestR6MatchingEngineNoDeadlock:
    def test_cancel_on_ack_callback_completes(self):
        import time as _t
        from enterprise.connectors.matching_engine import MatchingEngine
        events = []

        def cb(cid, ev, qty, px):
            events.append((cid, ev))
            if ev == "NEW":
                eng.cancel_order(cid)

        eng = MatchingEngine(fill_callback=cb)
        eng.start()
        try:
            eng.submit_order("C1", "RELIANCE", "BUY", 100, 100.0)
            _t.sleep(1.5)
            assert ("C1", "CANCELED") in events
        finally:
            eng.stop()


# ── A3-P3-10: Hawkes orderflow first-event intensity is mu ──
class TestR6HawkesOrderflowLl:
    def test_first_event_uses_log_mu(self):
        # The module's log-likelihood is embedded inside fit_univariate_hawkes'
        # neg_log_lik closure; verify the math by reproducing the recursion and
        # asserting λ₀ = μ changes the total LL by exactly log(μ) vs the old
        # log(1)=0 seeding (regression guard for the A3-P3-10 fix).
        events = np.array([0.0, 1.0, 2.5, 3.0])
        mu, alpha, beta = 0.4, 0.2, 1.0
        T = events[-1]

        def ll_with_seed(first_log_lambda):
            A = np.zeros(len(events))
            log_lambda = np.zeros(len(events))
            log_lambda[0] = first_log_lambda
            for i in range(1, len(events)):
                dt = events[i] - events[i - 1]
                A[i] = np.exp(-beta * dt) * (1 + A[i - 1])
                log_lambda[i] = np.log(max(mu + alpha * A[i], 1e-10))
            integral = mu * T + (alpha / beta) * (len(events) - np.sum(np.exp(-beta * (T - events))))
            return float(np.sum(log_lambda) - integral)

        correct = ll_with_seed(math.log(mu))
        buggy = ll_with_seed(0.0)  # the pre-fix seeding
        assert abs((correct - buggy) - math.log(mu)) < 1e-12, \
            "log_lambda[0] must be log(mu): first-event contribution changed"
