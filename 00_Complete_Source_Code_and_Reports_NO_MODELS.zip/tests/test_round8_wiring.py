"""Round 8 — Production Wiring Regression Tests.

Verifies that the 10 institutional modules wired in Round 8 (via
`optimizer_risk_institutional.py` and re-exported from
`optimizer_risk.py`) behave correctly under both happy-path and
fail-open conditions.

Test conventions (per test_p2_warnings.py):
  - assertRaises used everywhere; no pytest.warns noise
  - All tests use synthetic data only — no I/O, no yfinance, no broker API
  - Fail-open paths explicitly tested by passing degenerate inputs
"""
from __future__ import annotations

import math
import sys
import unittest
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

# Resolve project root for in-tree imports
_QA_ROOT = Path(__file__).resolve().parent.parent
if str(_QA_ROOT) not in sys.path:
    sys.path.insert(0, str(_QA_ROOT))

# Suppress pyparsing / matplotlib deprecation noise
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=UserWarning)

from optimizer_risk_institutional import (
    apply_herc_weights,
    price_option_qmc_lsmc,
    detect_cointegrated_pairs,
    detect_copula_pairs,
    forecast_volatility_msm,
    conditional_var_es,
    multivariate_var_es,
    apply_cdar_constraint,
    detect_regime_changepoints,
    cpcv_backtest_distribution,
)


def _make_rng(seed: int = 42) -> np.random.Generator:
    return np.random.default_rng(seed)


class TestR81HERC(unittest.TestCase):
    """R8-1: Hierarchical Equal Risk Contribution (Raffinot 2017)."""

    def test_happy_path_produces_normalized_long_only(self):
        rng = _make_rng(101)
        R = pd.DataFrame(
            rng.normal(0, 0.01, (250, 5)),
            columns=["A", "B", "C", "D", "E"],
        )
        res = apply_herc_weights(R, method="ward", max_weight=0.30)
        self.assertEqual(res["source"], "herc")
        w = res["weights"]
        self.assertEqual(len(w), 5)
        self.assertAlmostEqual(sum(w.values()), 1.0, places=6)
        for v in w.values():
            self.assertGreaterEqual(v, 0.0)
            self.assertLessEqual(v, 0.30 + 1e-9)

    def test_insufficient_data_falls_back_to_equal(self):
        # <20 rows triggers fallback to equal weights
        R = pd.DataFrame(np.zeros((10, 3)), columns=["A", "B", "C"])
        res = apply_herc_weights(R, max_weight=0.30)
        self.assertEqual(res["source"], "fallback_equal")
        self.assertEqual(len(res["weights"]), 3)
        self.assertAlmostEqual(sum(res["weights"].values()), 1.0, places=6)

    def test_single_asset_degrades_gracefully(self):
        # Single asset → HERC needs ≥2 cols → fallback path
        R = pd.DataFrame(np.zeros((100, 1)), columns=["A"])
        res = apply_herc_weights(R, max_weight=0.30)
        # Either fallback_equal or fallback_current — both are acceptable
        self.assertIn(res["source"], ("fallback_equal", "fallback_current"))

    def test_invalid_input_does_not_raise(self):
        # None input must not raise — must return empty/dict fallback
        res = apply_herc_weights(None, current_weights={"X": 1.0})
        self.assertEqual(res["source"], "fallback_current")
        self.assertEqual(res["weights"], {"X": 1.0})


class TestR82QMCLSMC(unittest.TestCase):
    """R8-2: Quasi-Monte Carlo Longstaff-Schwartz option pricing."""

    def test_atm_put_close_to_black_scholes(self):
        # BS-put for ATM 1y @ σ=30%, r=7% ≈ 8.6 (analytic reference)
        res = price_option_qmc_lsmc(
            S0=100.0, K=100.0, r=0.07, sigma=0.30, T=1.0,
            n_paths=2048, n_steps=30, option_type="put",
        )
        self.assertEqual(res["source"], "qmc_lsmc")
        # Tolerance: QMC-LSMC ±25% around BS reference
        self.assertGreater(res["price"], 5.0)
        self.assertLess(res["price"], 14.0)

    def test_atm_call_close_to_black_scholes(self):
        # BS-call for ATM 1y @ σ=30%, r=7% ≈ 13.6
        res = price_option_qmc_lsmc(
            S0=100.0, K=100.0, r=0.07, sigma=0.30, T=1.0,
            n_paths=2048, n_steps=30, option_type="call",
        )
        self.assertEqual(res["source"], "qmc_lsmc")
        # put-call parity: call = put + S - K*exp(-rT) = 8.6 + 100 - 93.24 = 15.36
        self.assertGreater(res["price"], 9.0)
        self.assertLess(res["price"], 22.0)

    def test_invalid_option_type_falls_back_gracefully(self):
        # Should either error into BS-fallback or return source != qmc_lsmc
        res = price_option_qmc_lsmc(
            S0=100.0, K=100.0, r=0.07, sigma=0.30, T=1.0,
            option_type="bogus_type",  # invalid
        )
        self.assertIn(res["source"], ("qmc_lsmc", "fallback_black_scholes", "fallback_zero"))
        self.assertGreaterEqual(res["price"], 0.0)

    def test_zero_volatility_does_not_raise(self):
        # sigma=0 → degenerate dynamics; either returns K*exp(-rT)*0 or fallback
        res = price_option_qmc_lsmc(
            S0=100.0, K=100.0, r=0.07, sigma=0.0, T=1.0,
            n_paths=512, n_steps=10, option_type="put",
        )
        # Source may be either path; the only requirement is no exception
        self.assertGreaterEqual(res["price"], 0.0)


class TestR83KalmanCointegration(unittest.TestCase):
    """R8-3: Kalman-filter hedge-ratio cointegration (Elliott et al 2005)."""

    def test_strong_cointegrated_pair_is_detected(self):
        rng = _make_rng(202)
        n = 500
        x = np.cumsum(rng.normal(0, 0.01, n)) + 100.0
        y = 2.0 * x + rng.normal(0, 0.5, n)  # very strong cointegration
        pdf = pd.DataFrame({"X": x, "Y": y})
        res = detect_cointegrated_pairs(pdf, min_history=250, max_pairs=5)
        self.assertEqual(res["source"], "kalman_cointegration")
        self.assertGreaterEqual(res["n_tested"], 1)
        self.assertGreaterEqual(len(res["pairs"]), 1)
        self.assertEqual(res["pairs"][0]["x"], "X")
        self.assertEqual(res["pairs"][0]["y"], "Y")

    def test_no_cointegration_returns_empty_pairs(self):
        rng = _make_rng(303)
        n = 500
        # Two independent random walks
        x = np.cumsum(rng.normal(0, 0.01, n))
        y = np.cumsum(rng.normal(0, 0.01, n))
        pdf = pd.DataFrame({"X": x, "Y": y})
        res = detect_cointegrated_pairs(pdf, min_history=250, max_pairs=5)
        self.assertEqual(res["source"], "kalman_cointegration")
        # Independent walks should NOT be flagged as cointegrated
        self.assertEqual(len(res["pairs"]), 0)

    def test_short_history_falls_back(self):
        # Only 50 rows — below min_history=250
        rng = _make_rng(404)
        pdf = pd.DataFrame({
            "X": rng.normal(0, 1, 50),
            "Y": rng.normal(0, 1, 50),
        })
        res = detect_cointegrated_pairs(pdf, min_history=250)
        self.assertEqual(res["source"], "fallback_empty")
        self.assertEqual(res["pairs"], [])

    def test_none_input_does_not_raise(self):
        res = detect_cointegrated_pairs(None)
        self.assertEqual(res["source"], "fallback_empty")


class TestR84CopulaStatArb(unittest.TestCase):
    """R8-4: Copula-based statistical arbitrage pair screen."""

    def test_clayton_coupled_pair_is_detected(self):
        rng = _make_rng(505)
        n = 500
        # Generate Clayton-coupled uniforms → genuine lower-tail dependence
        theta = 4.0
        u1 = rng.uniform(0.01, 0.99, n)
        v_raw = rng.uniform(0.01, 0.99, n)
        v = (1 + u1 ** (-theta) * (v_raw ** (-1.0 / (theta + 1.0)) - 1.0)) ** (-1.0 / theta)
        from scipy.stats import norm
        x = pd.Series(np.cumsum(norm.ppf(u1)) * 0.01 + 100.0)
        y = pd.Series(np.cumsum(norm.ppf(v)) * 0.01 + 100.0)
        pdf = pd.DataFrame({"X": x, "Y": y})
        res = detect_copula_pairs(pdf, min_lambda=0.05, min_history=250, max_pairs=5)
        self.assertEqual(res["source"], "copula_stat_arb")
        self.assertGreaterEqual(res["n_tested"], 1)
        self.assertGreaterEqual(len(res["pairs"]), 1)

    def test_independent_pair_not_flagged(self):
        rng = _make_rng(606)
        n = 500
        # Use IID returns (not prices) — empirical CDFs are near-uniform → no
        # meaningful tail dependence should survive a tight min_lambda filter.
        x = pd.Series(rng.normal(0, 0.01, n))
        y = pd.Series(rng.normal(0, 0.01, n))
        pdf = pd.DataFrame({"X": x, "Y": y})
        # Tight min_lambda filter should reject an independent pair
        res = detect_copula_pairs(pdf, min_lambda=0.50, min_history=250, max_pairs=5)
        self.assertEqual(res["source"], "copula_stat_arb")
        # In a small synthetic sample there may be spurious fits; accept 0 or 1
        self.assertLessEqual(len(res["pairs"]), 1)

    def test_short_history_returns_empty(self):
        rng = _make_rng(707)
        pdf = pd.DataFrame({
            "X": rng.normal(0, 1, 50),
            "Y": rng.normal(0, 1, 50),
        })
        res = detect_copula_pairs(pdf, min_history=250)
        self.assertEqual(res["source"], "fallback_empty")


class TestR85MSMVolatility(unittest.TestCase):
    """R8-5: Markov-Switching Multifractal volatility forecast."""

    def test_regime_switching_data_produces_nonzero_vol(self):
        rng = _make_rng(808)
        n = 500
        sig = np.where(np.arange(n) < 250, 0.005, 0.030)
        r = pd.Series(rng.normal(0, sig))
        res = forecast_volatility_msm(r, horizon=22)
        self.assertEqual(res["source"], "msm")
        self.assertGreater(res["vol_forecast"], 1.0)
        self.assertLess(res["vol_forecast"], 100.0)
        self.assertEqual(len(res["vol_path"]), 22)

    def test_short_series_falls_back_to_realized(self):
        rng = _make_rng(909)
        r = pd.Series(rng.normal(0, 0.01, 50))  # below 100 threshold
        res = forecast_volatility_msm(r, horizon=22)
        # Should fall back to realized vol (positive value)
        self.assertGreater(res["vol_forecast"], 0.0)
        self.assertIn(res["source"], ("fallback_realized", "fallback_zero"))

    def test_none_input_does_not_raise(self):
        res = forecast_volatility_msm(None)
        self.assertEqual(res["source"], "fallback_zero")
        self.assertEqual(res["vol_forecast"], 0.0)


class TestR86ConditionalEVT(unittest.TestCase):
    """R8-6: Conditional EVT VaR/ES (McNeil & Frey 2000)."""

    def test_heavy_tailed_data_produces_positive_var_es(self):
        rng = _make_rng(110)
        r = pd.Series(rng.standard_t(4, 500) * 0.01)
        res = conditional_var_es(r, alpha=0.99, portfolio_value=1_000_000.0)
        self.assertEqual(res["source"], "conditional_evt")
        self.assertGreater(res["var_pct"], 0.0)
        self.assertGreater(res["es_pct"], 0.0)
        # ES ≥ VaR always (coherency)
        self.assertGreaterEqual(res["es_pct"], res["var_pct"])
        # INR translation correct
        self.assertAlmostEqual(res["var_inr"], res["var_pct"] * 1_000_000.0, places=2)
        self.assertAlmostEqual(res["es_inr"], res["es_pct"] * 1_000_000.0, places=2)

    def test_short_series_falls_back_to_historical(self):
        rng = _make_rng(111)
        r = pd.Series(rng.normal(0, 0.01, 50))  # below 100 threshold
        res = conditional_var_es(r, alpha=0.99)
        self.assertEqual(res["source"], "fallback_historical")
        self.assertGreaterEqual(res["var_pct"], 0.0)
        self.assertGreaterEqual(res["es_pct"], res["var_pct"])

    def test_none_input_does_not_raise(self):
        res = conditional_var_es(None)
        self.assertEqual(res["source"], "fallback_zero")
        self.assertEqual(res["var_pct"], 0.0)


class TestR87FhsDccGarch(unittest.TestCase):
    """R8-7: Filtered Historical Simulation + DCC-GARCH multivariate VaR."""

    def test_correlated_three_asset_produces_positive_var_es(self):
        rng = _make_rng(121)
        n_days, n_assets = 300, 3
        cov = np.array([[1.0, 0.3, 0.1], [0.3, 1.0, 0.2], [0.1, 0.2, 1.0]]) * 0.0001
        R = pd.DataFrame(
            rng.multivariate_normal([0, 0, 0], cov, n_days),
            columns=["A", "B", "C"],
        )
        w = np.array([0.4, 0.35, 0.25])
        res = multivariate_var_es(
            R, w, alpha=0.99, n_sim=2000, horizon=1, portfolio_value=1_000_000.0,
        )
        # Should succeed via institutional OR fallback_historical — both pass
        self.assertIn(res["source"], ("fhs_dcc_garch", "fallback_historical"))
        self.assertGreater(res["var_pct"], 0.0)
        self.assertGreaterEqual(res["es_pct"], res["var_pct"])
        self.assertGreater(res["var_inr"], 0.0)

    def test_short_history_falls_back(self):
        rng = _make_rng(122)
        R = pd.DataFrame(rng.normal(0, 0.01, (50, 3)), columns=["A", "B", "C"])
        w = np.array([0.4, 0.35, 0.25])
        res = multivariate_var_es(R, w, alpha=0.99)
        # With <100 rows the DCC fit fails → historical fallback runs on the
        # 50-row series, computing a (noisy but valid) historical VaR.
        self.assertIn(res["source"], ("fallback_historical", "fallback_zero"))

    def test_zero_weights_does_not_raise(self):
        rng = _make_rng(123)
        R = pd.DataFrame(rng.normal(0, 0.01, (300, 3)), columns=["A", "B", "C"])
        res = multivariate_var_es(R, np.array([0.0, 0.0, 0.0]), alpha=0.99)
        self.assertIn(res["source"], ("fallback_historical", "fallback_zero"))


class TestR88CDaROptimization(unittest.TestCase):
    """R8-8: Conditional Drawdown-at-Risk optimization (Chekhlov et al 2005)."""

    def test_happy_path_produces_normalized_weights(self):
        rng = _make_rng(131)
        R = pd.DataFrame(rng.normal(0, 0.01, (300, 4)), columns=["A", "B", "C", "D"])
        cw = np.array([0.25, 0.25, 0.25, 0.25])
        res = apply_cdar_constraint(R, current_weights=cw, alpha=0.95, lam=1.0, max_weight=0.40)
        self.assertEqual(res["source"], "cdar")
        w = res["weights"]
        self.assertEqual(len(w), 4)
        self.assertAlmostEqual(w.sum(), 1.0, places=6)
        for v in w:
            self.assertGreaterEqual(v, 0.0)
            self.assertLessEqual(v, 0.40 + 1e-9)
        # CDaR should be a positive loss fraction
        self.assertGreaterEqual(res["cdar"], 0.0)

    def test_short_history_falls_back_to_current(self):
        rng = _make_rng(132)
        R = pd.DataFrame(rng.normal(0, 0.01, (50, 4)), columns=["A", "B", "C", "D"])
        cw = np.array([0.25, 0.25, 0.25, 0.25])
        res = apply_cdar_constraint(R, current_weights=cw)
        self.assertEqual(res["source"], "fallback_current")
        np.testing.assert_array_equal(res["weights"], cw)

    def test_mismatched_weights_does_not_raise(self):
        rng = _make_rng(133)
        R = pd.DataFrame(rng.normal(0, 0.01, (300, 4)), columns=["A", "B", "C", "D"])
        # Wrong-length weights → ValueError caught → fallback_current
        cw = np.array([0.5, 0.5])  # only 2 weights for 4 assets
        res = apply_cdar_constraint(R, current_weights=cw)
        self.assertEqual(res["source"], "fallback_current")


class TestR89BOCPD(unittest.TestCase):
    """R8-9: Bayesian Online Change-Point Detection (Adams & MacKay 2007)."""

    def test_regime_switching_data_emits_change_points(self):
        rng = _make_rng(141)
        n = 500
        # 20x vol jump at t=250 — very strong regime change
        sig = np.where(np.arange(n) < 250, 0.0025, 0.050)
        r = pd.Series(rng.normal(0, sig))
        # Use loose threshold to ensure detection
        res = detect_regime_changepoints(r, hazard_lambda=50, cp_threshold=0.05)
        self.assertEqual(res["source"], "bocpd")
        self.assertGreater(len(res["changepoints"]), 0)
        self.assertGreaterEqual(res["most_recent_cp"], 0)
        self.assertGreaterEqual(res["regime_id"], 1)
        # Posterior should be available
        self.assertGreater(len(res["run_length_posterior"]), 0)

    def test_low_vol_stable_series_emits_no_change_points(self):
        rng = _make_rng(142)
        # Constant low volatility → no change points
        r = pd.Series(rng.normal(0, 0.005, 500))
        res = detect_regime_changepoints(r, hazard_lambda=250, cp_threshold=0.30)
        self.assertEqual(res["source"], "bocpd")
        # Some series may produce 0 changepoints; some may produce 1 spurious
        # at the first observation. We accept either.
        self.assertLessEqual(len(res["changepoints"]), 2)

    def test_short_series_falls_back(self):
        rng = _make_rng(143)
        r = pd.Series(rng.normal(0, 0.01, 50))
        res = detect_regime_changepoints(r)
        self.assertEqual(res["source"], "fallback_empty")
        self.assertEqual(res["changepoints"], [])
        self.assertEqual(res["most_recent_cp"], -1)

    def test_none_input_does_not_raise(self):
        res = detect_regime_changepoints(None)
        self.assertEqual(res["source"], "fallback_empty")


class TestR810CPCV(unittest.TestCase):
    """R8-10: Combinatorial Purged Cross-Validation (López de Prado 2018)."""

    def test_happy_path_produces_sharpe_distribution(self):
        rng = _make_rng(151)
        # ~0.8 annualized Sharpe synthetic series
        r = pd.Series(rng.normal(0.0005, 0.01, 500))
        res = cpcv_backtest_distribution(r, n_groups=6, n_paths=2, purge_lookback=5)
        self.assertEqual(res["source"], "cpcv")
        self.assertGreater(res["n_paths"], 0)
        self.assertEqual(len(res["sharpe_paths"]), res["n_paths"])
        # p05 ≤ mean ≤ p95 invariant
        self.assertLessEqual(res["sharpe_p05"], res["sharpe_mean"])
        self.assertLessEqual(res["sharpe_mean"], res["sharpe_p95"])

    def test_short_history_falls_back_to_single_path(self):
        rng = _make_rng(152)
        # 30 samples — below the 100 threshold
        r = pd.Series(rng.normal(0.0005, 0.01, 30))
        res = cpcv_backtest_distribution(r)
        # Expect fallback to either single_path or empty
        self.assertIn(res["source"], ("fallback_single_path", "fallback_empty"))
        if res["source"] == "fallback_single_path":
            self.assertEqual(res["n_paths"], 1)
            self.assertEqual(len(res["sharpe_paths"]), 1)

    def test_none_input_does_not_raise(self):
        res = cpcv_backtest_distribution(None)
        self.assertEqual(res["source"], "fallback_empty")
        self.assertEqual(res["n_paths"], 0)
        self.assertEqual(len(res["sharpe_paths"]), 0)


class TestR8BackwardCompatReexport(unittest.TestCase):
    """The 10 Round 8 functions must also be importable from `optimizer_risk`
    for backward compatibility with downstream code."""

    def test_optimizer_risk_reexports_all_ten(self):
        from optimizer_risk import (
            apply_herc_weights as h1,
            price_option_qmc_lsmc as h2,
            detect_cointegrated_pairs as h3,
            detect_copula_pairs as h4,
            forecast_volatility_msm as h5,
            conditional_var_es as h6,
            multivariate_var_es as h7,
            apply_cdar_constraint as h8,
            detect_regime_changepoints as h9,
            cpcv_backtest_distribution as h10,
        )
        from optimizer_risk_institutional import (
            apply_herc_weights as h1b,
            price_option_qmc_lsmc as h2b,
            detect_cointegrated_pairs as h3b,
            detect_copula_pairs as h4b,
            forecast_volatility_msm as h5b,
            conditional_var_es as h6b,
            multivariate_var_es as h7b,
            apply_cdar_constraint as h8b,
            detect_regime_changepoints as h9b,
            cpcv_backtest_distribution as h10b,
        )
        # Re-exported symbols must be the same object (identity check)
        for original, reexported in [
            (h1, h1b), (h2, h2b), (h3, h3b), (h4, h4b), (h5, h5b),
            (h6, h6b), (h7, h7b), (h8, h8b), (h9, h9b), (h10, h10b),
        ]:
            self.assertIs(original, reexported)


class TestR8FailOpenInvariants(unittest.TestCase):
    """Round 8 invariant: NO wiring function may raise on degenerate input."""

    def test_all_ten_functions_survive_none_inputs(self):
        # None inputs to every wiring function — must never raise
        try:
            apply_herc_weights(None)
        except Exception as e:
            self.fail(f"apply_herc_weights(None) raised: {e}")

        try:
            price_option_qmc_lsmc(S0=0, K=0, r=0, sigma=0, T=0, n_paths=1, n_steps=1)
        except Exception as e:
            self.fail(f"price_option_qmc_lsmc(zeros) raised: {e}")

        try:
            detect_cointegrated_pairs(None)
        except Exception as e:
            self.fail(f"detect_cointegrated_pairs(None) raised: {e}")

        try:
            detect_copula_pairs(None)
        except Exception as e:
            self.fail(f"detect_copula_pairs(None) raised: {e}")

        try:
            forecast_volatility_msm(None)
        except Exception as e:
            self.fail(f"forecast_volatility_msm(None) raised: {e}")

        try:
            conditional_var_es(None)
        except Exception as e:
            self.fail(f"conditional_var_es(None) raised: {e}")

        try:
            multivariate_var_es(None, None)
        except Exception as e:
            self.fail(f"multivariate_var_es(None, None) raised: {e}")

        try:
            apply_cdar_constraint(None, None)
        except Exception as e:
            self.fail(f"apply_cdar_constraint(None, None) raised: {e}")

        try:
            detect_regime_changepoints(None)
        except Exception as e:
            self.fail(f"detect_regime_changepoints(None) raised: {e}")

        try:
            cpcv_backtest_distribution(None)
        except Exception as e:
            self.fail(f"cpcv_backtest_distribution(None) raised: {e}")


# ── Round 5 regression tests (AUDIT-FIX 2-f-3 / 2-f-4 follow-ups) ──────────
class TestRound5CapRegressions(unittest.TestCase):
    """Weight-cap hard-enforcement regressions found in the Round 5 audit.

    The clip-then-renormalize pattern used by apply_herc_weights and
    apply_cdar_constraint re-inflated clipped weights past the documented
    hard cap (e.g. cap 0.30 on [0.9505, 0.0287, 0.0208] produced a 0.858
    top weight), and apply_cdar_constraint divided by the SIGNED weight sum,
    sign-flipping net-short portfolios 20x past the cap. The CDaR fail-open
    fallback also returned warm-start weights unclipped.
    """

    def test_herc_concentrated_weights_respect_cap(self):
        # 5 assets × 0.30 cap = 1.50 >= 1.0 → feasible: cap must hold exactly
        rng = _make_rng(202)
        R = pd.DataFrame(rng.normal(0, 0.01, (250, 5)),
                         columns=["A", "B", "C", "D", "E"])
        res = apply_herc_weights(R, max_weight=0.30)
        w = res["weights"]
        self.assertLessEqual(max(w.values()), 0.30 + 1e-9)
        self.assertAlmostEqual(sum(w.values()), 1.0, places=6)

    def test_cdar_cap_enforced_on_concentrated_result(self):
        rng = _make_rng(203)
        R = pd.DataFrame(rng.normal(0, 0.01, (250, 4)),
                         columns=["A", "B", "C", "D"])
        res = apply_cdar_constraint(
            R, current_weights=np.array([0.95, 0.03, 0.02, 0.0]),
            max_weight=0.30, long_only=True,
        )
        w = np.asarray(res["weights"], dtype=float)
        self.assertLessEqual(float(np.abs(w).max()), 0.30 + 1e-9)
        self.assertGreaterEqual(float(w.sum()), 0.0)

    def test_cdar_failopen_fallback_also_respects_cap(self):
        # math_engine absent / short history → fallback path must clip too
        rng = _make_rng(204)
        R = pd.DataFrame(rng.normal(0, 0.01, (10, 3)),  # < 60 rows → fallback
                         columns=["A", "B", "C"])
        res = apply_cdar_constraint(
            R, current_weights=np.array([0.90, 0.08, 0.02]),
            max_weight=0.30, long_only=True,
        )
        w = np.asarray(res["weights"], dtype=float)
        self.assertEqual(res["source"], "fallback_current")
        self.assertLessEqual(float(np.abs(w).max()), 0.30 + 1e-9)

    def test_cdar_never_sign_flips_net_short_vector(self):
        # A net-short warm-start on the non-long-only FALLBACK path must never
        # divide by a negative sum (old behaviour produced [6.0, -4.0, -1.0]).
        # Short history (< 60 rows) forces the fail-open path deterministically.
        rng = _make_rng(205)
        R = pd.DataFrame(rng.normal(0, 0.01, (10, 3)),
                         columns=["A", "B", "C"])
        res = apply_cdar_constraint(
            R, current_weights=np.array([-0.30, 0.20, 0.05]),
            max_weight=0.30, long_only=False,
        )
        w = np.asarray(res["weights"], dtype=float)
        self.assertEqual(res["source"], "fallback_current")
        self.assertTrue(np.all(np.abs(w) <= 0.30 + 1e-9), f"{w}")
        # signs preserved — no division by the negative net sum
        self.assertLess(float(w[0]), 0.0, f"net-short sign was flipped: {w}")
        self.assertGreater(float(w.sum()), -1.0, f"weights blew up: {w}")


if __name__ == "__main__":
    unittest.main()
