import numpy as np
import pandas as pd
import pytest

import utils
import data_layer
import optimizer


def test_normalize_sector_na_variations():
    na_inputs = ["N/A", "NA", "na", "n/a", "", "   ", None, "None", "null"]
    for val in na_inputs:
        assert utils.normalize_sector(val) == "UNKNOWN", f"Failed for {val!r} in utils"
        assert data_layer.normalize_sector(val) == "UNKNOWN", f"Failed for {val!r} in data_layer"
    
    assert utils.normalize_sector("Banking") == "Banking"
    assert data_layer.normalize_sector("IT") == "IT"


def test_sector_counts_tracks_unknown_sectors():
    sectors = {
        "S1": "N/A", "S2": "", "S3": None, "S4": "NA", "S5": "null",
        "S6": "Auto", "S7": "Auto", "S8": "IT"
    }
    selected = ["S1", "S2", "S3", "S4", "S5", "S6", "S7", "S8"]
    
    counts_utils = utils.sector_counts(selected, sectors)
    assert counts_utils.get("UNKNOWN") == 5
    assert counts_utils.get("Auto") == 2
    assert counts_utils.get("IT") == 1
    
    counts_dl = data_layer.sector_counts(selected, sectors)
    assert counts_dl.get("UNKNOWN") == 5
    assert counts_dl.get("Auto") == 2
    assert counts_dl.get("IT") == 1


def test_solve_qubo_greedy_and_local_search_enforces_sector_cap_on_unknown():
    stocks = ["UNK1", "UNK2", "UNK3", "UNK4", "IT1", "IT2"]
    sectors = {"UNK1": "N/A", "UNK2": "", "UNK3": None, "UNK4": "NA", "IT1": "IT", "IT2": "IT"}
    # Higher alphas on UNK stocks
    alphas = [10.0, 9.0, 8.0, 7.0, 6.0, 5.0]

    signal_df = pd.DataFrame({
        "alpha_score": alphas,
        "volatility": [0.1] * 6,
        "market_cap": [1e9] * 6
    }, index=stocks)

    cfg = dict(optimizer.DEFAULT_CFG)
    cfg["K_STOCKS"] = 4
    cfg["MAX_PER_SECTOR"] = 2
    cfg["ENABLE_SECTOR_CAP"] = True
    cfg["OPTIMIZER_MODE"] = "Greedy"

    q = { (s, s): -float(signal_df.loc[s, "alpha_score"]) for s in stocks }

    selected, energy, src = optimizer.solve_qubo(q, signal_df, sectors, cfg)
    sec_counts = utils.sector_counts(selected, sectors)

    assert sec_counts.get("UNKNOWN", 0) <= 2, f"Cap violated! UNKNOWN count was {sec_counts.get('UNKNOWN')}"
    assert len(selected) == 4
    assert "IT1" in selected and "IT2" in selected


def test_repair_selection_enforces_unknown_sector_cap():
    stocks = ["UNK1", "UNK2", "UNK3", "UNK4", "IT1", "IT2"]
    sectors = {"UNK1": "N/A", "UNK2": "", "UNK3": None, "UNK4": "NA", "IT1": "IT", "IT2": "IT"}
    alphas = [10.0, 9.0, 8.0, 7.0, 6.0, 5.0]

    signal_df = pd.DataFrame({
        "alpha_score": alphas,
        "volatility": [0.1] * 6,
        "market_cap": [1e9] * 6
    }, index=stocks)

    selected = ["UNK1", "UNK2", "UNK3", "UNK4"]
    cfg = {
        "K_STOCKS": 4,
        "MAX_PER_SECTOR": 2,
        "ENABLE_SECTOR_CAP": True
    }
    q = { (s, s): -float(signal_df.loc[s, "alpha_score"]) for s in stocks }

    repaired = utils.repair_selection(selected, stocks, q, signal_df, sectors, cfg)
    counts = utils.sector_counts(repaired, sectors)

    assert counts.get("UNKNOWN", 0) <= 2
    assert len(repaired) == 4


def test_gat_model_ticker_index_and_score_aggregation():
    from ml_alpha.archetype_models import InstitutionalFlowGATModel, FLOW_FACTOR_NAMES

    tickers = ["RELIANCE.NS", "TCS.NS", "INFY.NS"] * 10
    np.random.seed(42)
    X_data = {feat: np.random.randn(30) for feat in FLOW_FACTOR_NAMES}
    X_df = pd.DataFrame(X_data, index=pd.Index(tickers, name="ticker"))
    y_s = pd.Series(np.random.randn(30), index=X_df.index)

    model = InstitutionalFlowGATModel(feature_names=FLOW_FACTOR_NAMES)
    ok = model.fit(X_df, y_s)
    assert ok is True
    preds = model.predict(X_df)
    assert len(preds) == 30

