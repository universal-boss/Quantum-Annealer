"""
tests/test_sovereign_tier0.py
=============================
Automated test suite verifying the Sovereign Tier-0 mathematical and ML engines:
    1. Marchenko-Pastur RMT Spectral Denoising (Trace preservation & positive semi-definiteness)
    2. Terry Lyons' Path Signatures (Invariance, Levy stochastic area, compression)
    3. Conformal Trade Exit Ladder (Exact 1:2 and 1:4 risk-reward targets)
    4. Mamba State-Space Sequence Extractor (Linear scan stability)
    5. Hawkes Jump Cascade Detector (Branching ratio calibration)
    6. Inductive Conformal Risk Engine (Finite-sample coverage)
"""
import pytest
import numpy as np
import pandas as pd

from math_engine.matrix_denoising import rmt_eigenvalue_clipping, marchenko_pastur_spectral_boundary
from math_engine.path_signatures import PathSignatureEngine
from math_engine.trade_ladder import ConformalTradeLadder
from math_engine.hawkes_detector import HawkesJumpDetector
from math_engine.conformal_risk import ConformalRiskEngine
from ml_alpha.mamba_sequence import MambaSequenceExtractor
from utils import denoise_covariance_rmt


class TestSovereignTier0:

    def test_marchenko_pastur_rmt_denoising(self):
        """Proof of trace preservation, noise clipping, and positive semi-definiteness."""
        np.random.seed(42)
        T, N = 500, 50
        # Generate random noise matrix with 3 true common factors
        true_factors = np.random.normal(0, 1, size=(T, 3))
        factor_loadings = np.random.normal(0, 0.5, size=(3, N))
        noise = np.random.normal(0, 1, size=(T, N))
        returns = true_factors @ factor_loadings + noise

        raw_cov = np.cov(returns, rowvar=False)
        raw_corr = np.corrcoef(returns, rowvar=False)

        # Apply Marchenko-Pastur RMT spectral denoising
        denoised_corr = denoise_covariance_rmt(raw_corr, T, N)

        # 1. Check symmetry
        assert np.allclose(denoised_corr, denoised_corr.T, atol=1e-8), "Denoised correlation must be symmetric"

        # 2. Check diagonals are 1.0
        assert np.allclose(np.diag(denoised_corr), 1.0, atol=1e-5), "Diagonals must be 1.0"

        # 3. Check positive semi-definiteness (all eigenvalues >= 0)
        evals = np.linalg.eigvalsh(denoised_corr)
        assert np.all(evals >= -1e-8), f"Negative eigenvalue detected: {np.min(evals)}"

        # 4. Check trace preservation (sum of eigenvalues == N)
        assert np.isclose(np.sum(evals), N, rtol=1e-3), f"Trace violated: {np.sum(evals)} vs {N}"

        # 5. Check rmt_eigenvalue_clipping helper
        clippy = rmt_eigenvalue_clipping(raw_cov, N, T)
        assert clippy.shape == (N, N)
        assert np.allclose(clippy, clippy.T, atol=1e-7)

    def test_terry_lyons_path_signatures(self):
        """Validates path signatures: displacement, Levy area, and compression index."""
        # Simulated upward trending cyclical series
        t = np.linspace(0, 10, 100)
        prices = 100.0 + 2.0 * t + 5.0 * np.sin(t)
        volumes = 10000.0 + 2000.0 * np.cos(t)

        sig = PathSignatureEngine.compute_path_signature(prices, volumes, depth=2)

        # 1. Displacement must be strictly positive for upward trend
        assert sig["sig_displacement"] > 0, "Displacement must be positive for upward trend"

        # 2. Compression index must be in [0, 1]
        assert 0.0 <= sig["sig_compression_index"] <= 1.0, "Compression index out of bounds"

        # 3. Levy area must be finite
        assert np.isfinite(sig["sig_levy_area_pv"]), "Levy area must be finite"

        # 4. Universe scoring
        df = pd.DataFrame({"A": prices, "B": prices[::-1]})
        sig_df = PathSignatureEngine.score_universe_signatures(df)
        assert len(sig_df) == 2
        assert "sig_displacement" in sig_df.columns

    def test_conformal_trade_exit_ladder(self):
        """Validates entry, stop loss, and exact 1:2 / 1:4 risk-reward targets."""
        price_history = pd.Series([100, 102, 101, 103, 102, 104, 103, 105, 104, 106, 105, 107, 106, 108, 107, 109, 108, 110, 109, 111])
        ladder = ConformalTradeLadder.calculate_stock_ladder("TEST.NS", current_price=100.0, price_history=price_history)

        assert ladder["entry_price"] == 100.0
        assert ladder["stop_loss"] < 100.0
        assert 91.5 <= ladder["stop_loss"] <= 97.0, f"Stop loss {ladder['stop_loss']} outside SEBI guardrail [91.5, 97.0]"

        risk = 100.0 - ladder["stop_loss"]
        # Target 1 must be exactly Entry + 2 * Risk
        assert np.isclose(ladder["target_1"], 100.0 + 2.0 * risk, atol=0.05)
        # Target 2 must be exactly Entry + 4 * Risk
        assert np.isclose(ladder["target_2"], 100.0 + 4.0 * risk, atol=0.05)
        assert ladder["chandelier_trail"] >= ladder["stop_loss"]

    def test_mamba_sequence_extractor(self):
        """Validates linear-time Mamba state-space feature extraction."""
        mamba = MambaSequenceExtractor(d_state=16, d_model=4)
        prices = 100.0 * np.exp(np.cumsum(np.random.normal(0.001, 0.02, size=100)))
        volumes = np.random.uniform(5000, 50000, size=100)

        feats = mamba.extract_features(prices, volumes)

        assert "mamba_trend_drift" in feats
        assert "mamba_accel_state" in feats
        assert "mamba_vol_absorption" in feats
        assert 0.0 <= feats["mamba_coherence"] <= 1.0
        assert all(np.isfinite(v) for v in feats.values())

    def test_hawkes_jump_detector(self):
        """Validates Hawkes point process excitation and branching ratio boundedness."""
        detector = HawkesJumpDetector(threshold_std=2.0)
        # Generate series with clustered jump events
        returns = pd.Series(np.random.normal(0, 0.01, size=200))
        # Insert clustered shock aftershocks at t=100..105
        returns.iloc[100:106] = 0.04

        res = detector.fit_predict(returns)
        assert "branching_ratio" in res
        assert "hawkes_intensity" in res
        assert res["branching_ratio"] >= 0.0

    def test_conformal_risk_bounds(self):
        """Validates non-parametric conformal quantile bounds."""
        prices = pd.Series(np.linspace(100, 120, 50) + np.random.normal(0, 1, 50))
        bounds = ConformalRiskEngine.calculate_conformal_bounds(prices, horizon_days=10)

        assert "d_max_90_pct" in bounds
        assert "d_max_95_pct" in bounds
        assert bounds["d_max_95_pct"] >= bounds["d_max_90_pct"], "95% bound must be at least as conservative as 90%"

    def test_catboost_ordered_boosting(self):
        """Validates CatBoost with Ordered Boosting fits and produces bounded predictions."""
        from ml_alpha.expanded_ensemble import ExpandedAlphaEnsemble
        ensemble = ExpandedAlphaEnsemble(use_catboost=True, use_xgboost=False)
        np.random.seed(42)
        X = pd.DataFrame(np.random.normal(0, 1, size=(80, 5)), columns=[f"f_{i}" for i in range(5)])
        y = pd.Series(np.random.normal(0.01, 0.05, size=80))

        fit_res = ensemble.fit(X, y)
        assert "catboost" in fit_res["models_fitted"]
        preds = ensemble.predict(X)
        assert len(preds) == 80
        assert np.all(np.isfinite(preds))

    def test_options_tail_hedging(self):
        """Validates Nifty Options Put delta-neutral hedge calculations."""
        from math_engine.options_hedger import OptionsTailHedger
        hedger = OptionsTailHedger(nifty_price=24000.0)
        port_df = pd.DataFrame([
            {"Ticker": "RELIANCE.NS", "Weight": 0.40, "Beta": 1.10},
            {"Ticker": "TCS.NS", "Weight": 0.30, "Beta": 0.85},
            {"Ticker": "HDFCBANK.NS", "Weight": 0.30, "Beta": 1.05},
        ])
        hedge = hedger.calculate_hedge_recommendation(
            portfolio_df=port_df,
            portfolio_value=1000000.0,
            regime="Bear",
            hawkes_warning=True
        )
        assert "recommended_put_lots" in hedge
        assert hedge["recommended_put_lots"] >= 1
        assert "nifty_put_strike_5pct_otm" in hedge
        assert hedge["nifty_put_strike_5pct_otm"] < 24000.0  # Must be OTM put

    def test_algo_order_slicing(self):
        """Validates Almgren-Chriss / VWAP order slicing conserves total quantity."""
        from math_engine.algo_execution import AlgoExecutionManager
        total_qty = 500
        mgr = AlgoExecutionManager(
            ticker="BEL",
            quantity=total_qty,
            strategy="VWAP",
            duration_mins=360.0,
            slices_count=3,
            decision_price=280.0
        )
        assert len(mgr.slices) == 3
        slice_sum = sum(s["target_qty"] for s in mgr.slices)
        assert slice_sum == total_qty
        assert all(s["target_qty"] > 0 for s in mgr.slices)

    def test_broker_baskets_and_telemetry(self):
        """Validates telemetry and multi-broker basket schema generation.

        R50 UPDATE (hermetic guard): compute_frontier_telemetry reports
        ONLINE only when a REAL returns panel was fetchable from the live
        price provider; on a vendor outage / rate-limited long batch run it
        HONESTLY reports 'PARTIAL (offline inputs)' with null metrics (the
        R20-4 doctrine — telemetry reports only what it measures). The
        status assertion is now offline-aware: ONLINE when data is
        available, PARTIAL is the disclosed honest-offline state. The
        no-fabrication assertions below hold in BOTH states.
        """
        from web_dashboard.app import AgenticDesktopBridge
        telemetry = AgenticDesktopBridge.compute_frontier_telemetry()
        assert telemetry["status"] in ("ONLINE", "PARTIAL (offline inputs)"), (
            f"unexpected telemetry status {telemetry['status']!r}"
        )
        assert "rmt_spectral_denoising" in telemetry
        assert "kritzman_absorption_ratio" in telemetry
        if telemetry["status"].startswith("PARTIAL"):
            # honest-offline contract: the RMT block must carry nulls +
            # UNAVAILABLE, never fabricated numbers
            assert telemetry["rmt_spectral_denoising"]["rejection_pct"] is None
            assert telemetry["rmt_spectral_denoising"]["status"] == "UNAVAILABLE"
        else:
            assert telemetry["rmt_spectral_denoising"]["rejection_pct"] is not None
        # R34-9: the Round 33 upload had added a fabricated dma_model_allocations
        # table (hardcoded CatBoost/Mamba/ViT/LightGBM/Ridge weights presented as
        # a measured ensemble allocation). This test previously ASSERTED the
        # fabrication's presence. Per the R20-4 doctrine (telemetry reports only
        # what it measures) the key must stay ABSENT.
        assert "dma_model_allocations" not in telemetry, (
            "fabricated dma_model_allocations telemetry key must not exist (R34-9)"
        )

        suite = AgenticDesktopBridge.compute_trade_execution_suite(portfolio_value=500000.0)
        assert suite["status"] in ("SUCCESS", "NO_HOLDINGS")
        assert "trade_ladders" in suite
        assert "broker_baskets" in suite
        baskets = suite["broker_baskets"]
        assert "zerodha_kite" in baskets
        assert "dhan_hq" in baskets
        assert "angel_one" in baskets
        assert "csv_format" in baskets
        # Check Zerodha structure
        if baskets["zerodha_kite"]:
            first_z = baskets["zerodha_kite"][0]
            assert "tradingsymbol" in first_z
            assert "quantity" in first_z
            assert first_z["product"] == "CNC"
