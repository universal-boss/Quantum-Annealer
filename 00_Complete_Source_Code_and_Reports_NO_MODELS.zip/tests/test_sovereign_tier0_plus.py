"""
tests/test_sovereign_tier0_plus.py
==================================
Master Automated Test Suite for Sovereign Tier-0+ (Ultra-Institutional Quantitative Frontier):
    1. Score-Based Continuous-Time Generative Diffusion SDE (Reverse-time Ito SDE & VaR/ES)
    2. Liquid Time-Constant (LTC) Networks & Continuous Neural ODEs (RK4 & Lyapunov stability)
    3. Geodesic Sinkhorn Wasserstein Distributionally Robust Optimization (AIRM & SPD cone)
    4. Continuous DRL Avellaneda-Stoikov HJB Microstructure Execution (OFI, VPIN & SAC)
    5. Quantum-Inspired Matrix Product State (MPS) Tensor Networks (Schmidt rank truncation & S_vN)
    6. Unified Tier-0+ Telemetry Integration (Diagnostics & API payload)
"""
import time
import pytest
import numpy as np
import pandas as pd

from math_engine.score_diffusion_sde import ScoreDiffusionSDEEngine
from ml_alpha.liquid_neural_ode import LiquidNeuralODEEngine
from math_engine.wasserstein_manifold_dro import SinkhornWassersteinDROEngine
from math_engine.drl_hjb_execution import DRLHJBExecutionAgent
from math_engine.tensor_network_mps import MatrixProductStateEngine
from optimizer_risk import compute_sovereign_tier0_plus_telemetry


class TestSovereignTier0Plus:

    def test_score_diffusion_sde_engine(self):
        """Validates continuous-time Ito diffusion, Stein score function, and vectorized SDE sampler."""
        rng = np.random.RandomState(42)
        n_obs, n_assets = 80, 5
        returns = pd.DataFrame(
            rng.randn(n_obs, n_assets) * 0.015,
            columns=[f"EQ_{i}" for i in range(n_assets)]
        )

        engine = ScoreDiffusionSDEEngine(beta_min=0.1, beta_max=15.0, n_steps=50)
        engine.calibrate(returns)

        assert engine._is_calibrated is True
        assert len(engine.assets) == n_assets
        assert engine.cov_mat.shape == (n_assets, n_assets)

        # 1. Evaluate analytical score function (1D and 2D batch)
        x_1d = np.zeros(n_assets)
        s_1d = engine.score_function(x_1d, t=0.5)
        assert s_1d.shape == (n_assets,)

        x_2d = np.zeros((20, n_assets))
        s_2d = engine.score_function(x_2d, t=0.5)
        assert s_2d.shape == (20, n_assets)

        # 2. Vectorized SDE trajectory generation performance (< 500 ms for 500 paths)
        t0 = time.perf_counter()
        samples = engine.sample_trajectories(n_samples=500, seed=42)
        t1 = time.perf_counter()
        elapsed = t1 - t0

        assert samples.shape == (500, n_assets)
        assert elapsed < 1.0, f"Vectorized SDE sampler took too long: {elapsed:.3f}s"
        assert np.all(np.isfinite(samples)), "Generated diffusion samples must be finite"

        # 3. Portfolio synthetic risk evaluation
        weights = {f"EQ_{i}": 1.0 / n_assets for i in range(n_assets)}
        risk_res = engine.evaluate_portfolio_synthetic_risk(weights, n_samples=500)

        assert risk_res["status"] == "SUCCESS"
        assert risk_res["n_synthetic_paths"] == 500
        assert "synthetic_var_95" in risk_res
        assert "synthetic_var_99" in risk_res
        assert "synthetic_es_95" in risk_res
        assert "synthetic_volatility_ann_pct" in risk_res

    def test_liquid_neural_ode_engine(self):
        """Validates continuous-time Liquid Neural ODE, dynamic time-constant adaptation, and Lyapunov stability."""
        engine = LiquidNeuralODEEngine(input_dim=4, hidden_dim=16, tau_base=1.0, random_state=42)

        # 1. Lyapunov contractive stability: spectral radius < 1.0
        spectral_radius = np.max(np.abs(np.linalg.eigvals(engine.W_hh)))
        assert spectral_radius < 1.0, f"Lyapunov stability violated: spectral radius={spectral_radius}"

        # 2. Continuous vector field evaluation
        h = np.zeros(16)
        x_quiet = np.array([0.0, 0.0, 0.0, 0.0])
        dh_quiet = engine.vector_field(h, x_quiet)
        tau_quiet = engine.effective_tau(h, x_quiet)

        # During sudden market flash crash / volatility burst
        x_shock = np.array([3.0, 4.0, 3.5, 2.0])
        tau_shock = engine.effective_tau(h, x_shock)

        # Liquid time-constant must contract under shock (tau_shock < tau_quiet)
        assert np.mean(tau_shock) < np.mean(tau_quiet), "Dynamic time-constant did not adapt to volatility burst"

        # 3. Trajectory integration via RK4
        T = 40
        X_seq = np.random.randn(T, 4) * 0.5
        H_traj, tau_traj, Y_pred = engine.integrate_trajectory(X_seq)

        assert H_traj.shape == (T, 16)
        assert tau_traj.shape == (T, 16)
        assert Y_pred.shape == (T,)
        assert np.all(Y_pred >= -1.0) and np.all(Y_pred <= 1.0), "Continuous conviction bounded in [-1, 1]"

        # 4. Feature extraction on simulated price series
        prices = pd.Series(100.0 * np.exp(np.cumsum(np.random.randn(60) * 0.01)))
        lf = engine.extract_liquid_features(prices)

        assert -1.0 <= lf["liquid_conviction"] <= 1.0
        assert lf["liquid_effective_tau_mean"] > 0.0
        assert lf["liquid_adaptation_velocity"] >= 0.0
        assert lf["liquid_lyapunov_stability"] < 1.0

    def test_geodesic_sinkhorn_wasserstein_dro(self):
        """Validates Riemannian AIRM metric on SPD cone, entropic Sinkhorn transport, and DRO worst-case covariance."""
        dro = SinkhornWassersteinDROEngine(default_rho=0.20, default_kappa=0.10)

        # Create two valid Symmetric Positive Definite (SPD) covariance matrices
        rng = np.random.RandomState(42)
        A = rng.randn(4, 4)
        sigma1 = A @ A.T + np.eye(4) * 0.5
        B = rng.randn(4, 4)
        sigma2 = B @ B.T + np.eye(4) * 0.5

        # 1. Metric Properties on SPD Riemannian Manifold
        dist_self = dro.riemannian_distance(sigma1, sigma1)
        dist_cross = dro.riemannian_distance(sigma1, sigma2)
        dist_symm = dro.riemannian_distance(sigma2, sigma1)

        assert np.isclose(dist_self, 0.0, atol=1e-5), "Identity of indiscernibles violated"
        assert dist_cross > 0.0, "Riemannian distance must be positive"
        assert np.isclose(dist_cross, dist_symm, atol=1e-5), "Symmetry violated"

        # 2. Bures-Wasserstein distance between Gaussians
        mu1 = np.array([0.01, 0.02, -0.01, 0.0])
        mu2 = np.array([0.00, 0.01, 0.02, -0.01])
        w2_dist = dro.bures_wasserstein_distance(mu1, sigma1, mu2, sigma2)
        assert w2_dist >= 0.0

        # 3. Worst-Case Adversarial Covariance Matrix
        w = np.array([0.25, 0.25, 0.25, 0.25])
        rho = 0.25
        sigma_worst = dro.compute_worst_case_covariance(sigma1, w, rho=rho)

        # Must remain strictly Symmetric Positive Definite
        evals = np.linalg.eigvalsh(sigma_worst)
        assert np.all(evals > 0), "Worst-case covariance must be strictly positive definite"
        assert np.allclose(sigma_worst, sigma_worst.T, atol=1e-7), "Worst-case covariance must be symmetric"

        # Adversarial variance inflation check: w^T Sigma^* w == exp(rho) * (w^T Sigma w)
        var_nom = float(w @ sigma1 @ w)
        var_worst = float(w @ sigma_worst @ w)
        expected_worst_var = var_nom * np.exp(rho)
        assert np.isclose(var_worst, expected_worst_var, rtol=1e-3), "Theoretical adversarial inflation violated"

        # 4. Sinkhorn Optimal Transport Plan
        a = np.ones(4) / 4.0
        b = np.ones(4) / 4.0
        C = np.abs(np.subtract.outer(np.arange(4), np.arange(4)))
        P, ot_cost = dro.sinkhorn_optimal_transport(a, b, C, epsilon=0.05)

        assert np.isclose(np.sum(P), 1.0, atol=1e-5), "Transport coupling must sum to 1"
        assert np.allclose(np.sum(P, axis=1), a, atol=1e-3), "Row marginals must match"
        assert np.allclose(np.sum(P, axis=0), b, atol=1e-3), "Column marginals must match"

        # 5. Robust weights projected simplex solver
        w_rob = dro.solve_robust_weights(mu1, sigma1, risk_aversion=1.5, rho=0.20)
        assert np.isclose(np.sum(w_rob), 1.0, atol=1e-5), "Weights must sum to 1.0 on simplex"
        assert np.all(w_rob >= -1e-8), "Short selling prohibited (all w >= 0)"

    def test_drl_hjb_microstructure_execution(self):
        """Validates Avellaneda-Stoikov HJB reservation price, OFI/VPIN spreads, and SAC continuous policy."""
        agent = DRLHJBExecutionAgent(risk_aversion=0.10, order_book_intensity=1.5)

        mid = 1000.0
        vol = 0.015

        # 1. Inventory Monotonicity: long inventory lowers reservation price to encourage selling
        r_long = agent.reservation_price(mid, inventory=1000, time_remaining_sec=120.0, volatility=vol)
        r_flat = agent.reservation_price(mid, inventory=0, time_remaining_sec=120.0, volatility=vol)
        r_short = agent.reservation_price(mid, inventory=-1000, time_remaining_sec=120.0, volatility=vol)

        assert r_long < r_flat < r_short, "Avellaneda-Stoikov reservation price must decrease with inventory"

        # 2. Toxicity penalty: high VPIN widens spreads
        delta_b_clean, delta_a_clean = agent.optimal_half_spreads(mid, 0, 120.0, vol, vpin=0.05)
        delta_b_toxic, delta_a_toxic = agent.optimal_half_spreads(mid, 0, 120.0, vol, vpin=0.85)

        assert delta_a_toxic > delta_a_clean, "VPIN toxicity must widen ask half-spread"
        assert delta_b_toxic > delta_b_clean, "VPIN toxicity must widen bid half-spread"

        # 3. Soft Actor-Critic (SAC) Policy Action Forward Pass
        state_vec = np.array([0.2, 0.5, 0.1, 0.2, 1.0, 1.0])
        sac_act = agent.sac_policy_forward(state_vec)
        assert sac_act.shape == (3,)
        assert np.all(sac_act >= -1.0) and np.all(sac_act <= 1.0)

        # 4. Full Execution Decision
        decision = agent.evaluate_execution_decision(
            mid_price=mid,
            current_inventory=200,
            target_inventory=800,
            time_remaining_sec=150.0,
            volatility=vol,
            ofi=0.3,
            vpin=0.2,
        )

        assert decision["routing_mode"] in ["PASSIVE_MAKER", "PEGGED_MID", "CROSS_TAKER"]
        assert decision["optimal_bid"] < mid < decision["optimal_ask"]
        assert 0.0 <= decision["inventory_urgency"] <= 1.0
        assert 0.0 <= decision["aggression_score"] <= 1.0

    def test_tensor_network_mps_engine(self):
        """Validates Matrix Product State (MPS) tensor train, Schmidt rank truncation, and entanglement entropy."""
        mps = MatrixProductStateEngine(max_bond_dim=8)

        # Generate synthetic correlation matrix of 20 assets
        rng = np.random.RandomState(42)
        L = rng.randn(20, 5)
        cov = L @ L.T + np.eye(20) * 0.2
        d = np.sqrt(np.diag(cov))
        corr = cov / np.outer(d, d)
        np.fill_diagonal(corr, 1.0)

        # 1. MPS decomposition
        decomp = mps.decompose_matrix_mps(corr, max_bond_dim=8)

        assert decomp["bond_dim"] <= 8
        assert decomp["entanglement_entropy"] >= 0.0
        assert decomp["reconstruction_error"] < 0.15, f"Reconstruction error too high: {decomp['reconstruction_error']}"
        assert decomp["compression_ratio"] < 1.0, "MPS should compress 20x20 parameters"

        # 2. Linear O(N * chi) portfolio risk contraction vs exact matrix quadratic form
        w = np.ones(20) / 20.0
        contracted_risk = mps.contract_portfolio_risk(w, decomp)
        exact_risk = float(w @ (decomp["U"] * decomp["S"] @ decomp["Vt"]) @ w)

        assert np.isclose(contracted_risk, exact_risk, atol=1e-6), "MPS contraction must match tensor product"

        # 3. Market entanglement entropy & regime detection
        df_rets = pd.DataFrame(rng.randn(100, 15) * 0.01)
        entangle_res = mps.compute_market_entanglement(df_rets, max_bond_dim=10)

        assert entangle_res["market_coupling_regime"] in ["DECOUPLED", "TRANSITIONAL", "SYSTEMIC_CONTAGION"]
        assert entangle_res["entanglement_entropy"] >= 0.0
        assert entangle_res["effective_dof"] >= 1.0

    def test_tier0_plus_telemetry_integration(self):
        """Validates end-to-end telemetry compilation for the Tier-0+ dashboard endpoint."""
        rng = np.random.RandomState(42)
        dates = pd.date_range("2026-01-01", periods=100, freq="B")
        assets = ["RELIANCE", "TCS", "HDFCBANK", "INFY", "ICICIBANK"]
        returns_df = pd.DataFrame(rng.randn(100, 5) * 0.015, index=dates, columns=assets)

        weights = {"RELIANCE": 0.2, "TCS": 0.2, "HDFCBANK": 0.2, "INFY": 0.2, "ICICIBANK": 0.2}
        telemetry = compute_sovereign_tier0_plus_telemetry(returns_df, portfolio_weights=weights)

        assert telemetry["status"] == "SUCCESS"
        assert telemetry["diffusion_sde"]["status"] == "CALIBRATED"
        assert telemetry["liquid_neural_ode"]["status"] == "SOLVED"
        assert telemetry["wasserstein_dro"]["status"] == "OPTIMIZED"
        assert telemetry["drl_hjb_execution"]["status"] == "ACTIVE_POLICY"
        assert telemetry["tensor_network_mps"]["status"] == "COMPRESSED"
