"""
Comprehensive Test Suite: Sovereign Tier-Ω (The Singularity Quant Frontier)
Tests all 5 pinnacle mathematical and quantitative pillars:
1. Rough Fractional Volatility Dynamics (Rough Bergomi, H in (0.10, 0.14), power-law skew).
2. Topological Data Analysis (TDA) Persistent Homology (Vietoris-Rips, Betti beta_0/beta_1, persistence entropy).
3. Pearlian Structural Causal Models (SCMs) & Invariant Causal Prediction (DirectLiNGAM, Do-calculus).
4. Continuous-Time Mean-Field Game (MFG) Lasry-Lions Nash Execution (Predatory crowding, slippage savings).
5. Symplectic Geometric Integration & Hamiltonian Phase-Space ODEs (Störmer-Verlet leapfrog, |Delta H| < 1e-4).
6. End-to-End Orchestration & Web Telemetry Integration.
"""

import numpy as np
import pandas as pd
import pytest


# ─────────────────────────────────────────────────────────────────────────────
# 1. Rough Fractional Volatility Tests
# ─────────────────────────────────────────────────────────────────────────────
def test_rough_volatility_bergomi():
    from math_engine.rough_volatility_bergomi import RoughVolatilityBergomiEngine

    engine = RoughVolatilityBergomiEngine(default_hurst=0.12, vol_of_vol=0.35, n_steps=80)
    
    # Test 1: Simulate Fractional Brownian Motion
    fbm = engine.simulate_fractional_brownian_motion(hurst=0.12, n_paths=20, n_points=50, T=0.5)
    assert fbm.shape == (20, 50)
    assert np.allclose(fbm[:, 0], 0.0)

    # Test 2: Multi-Scale Hurst Exponent Estimation
    np.random.seed(42)
    # Generate synthetic subdiffusive series
    synthetic_series = np.cumsum(np.random.randn(200) * 0.01)
    estimated_h = engine.estimate_hurst_exponent(np.abs(synthetic_series))
    assert 0.02 <= estimated_h <= 0.60

    # Test 3: Rough Volatility Paths & Power-Law Skew
    res = engine.simulate_rough_volatility_paths(hurst=0.12, initial_vol=0.20, n_paths=50, n_points=40, T=0.5)
    assert res["hurst"] == 0.12
    assert res["skew_power_exponent"] == pytest.approx(-0.38, abs=0.01)
    assert res["short_dated_skew_1w"] > res["long_dated_skew_1y"]  # Power law short-dated explosion
    assert res["roughness_regime"] == "ULTRA_ROUGH"

    # Test 4: Universe Roughness Calibration
    dates = pd.date_range("2025-01-01", periods=60, freq="B")
    df = pd.DataFrame(np.random.randn(60, 3) * 0.015, index=dates, columns=["INFY", "TCS", "RELIANCE"])
    calib = engine.calibrate_universe_roughness(df)
    assert "portfolio_median_hurst" in calib
    assert calib["roughness_regime"] in ("ULTRA_ROUGH", "MODERATELY_ROUGH")


# ─────────────────────────────────────────────────────────────────────────────
# 2. Topological Persistent Homology (TDA) Tests
# ─────────────────────────────────────────────────────────────────────────────
def test_topological_persistent_homology():
    from math_engine.topological_tda_homology import TopologicalPersistentHomologyEngine

    engine = TopologicalPersistentHomologyEngine(max_dimension=1, n_filtration_steps=30)
    
    # Test 1: Correlation to distance conversion
    corr = np.array([[1.0, 0.8, -0.2], [0.8, 1.0, 0.1], [-0.2, 0.1, 1.0]])
    dist = engine.correlation_to_distance_matrix(corr)
    assert np.allclose(np.diag(dist), 0.0)
    assert dist[0, 1] == pytest.approx(np.sqrt(2.0 * (1.0 - 0.8)), abs=1e-5)
    assert np.all(dist >= 0.0)

    # Test 2: Vietoris-Rips Homology
    labels = ["ASSET_A", "ASSET_B", "ASSET_C"]
    res = engine.compute_vietoris_rips_homology(dist, asset_labels=labels)
    assert res["betti_0"] >= 1
    assert res["betti_1"] >= 0
    assert res["persistence_entropy"] >= 0.0
    assert res["topological_cavity_index"] >= 0.0
    assert res["market_topology_regime"] in (
        "TOPOLOGICAL_SINGULARITY_COLLAPSE",
        "HIGH_CONCENTRATION_CAVITY",
        "DECENTRALIZED_STABLE_MANIFOLD",
    )

    # Test 3: Universe Evaluation on Dataframe
    dates = pd.date_range("2025-01-01", periods=50, freq="B")
    df = pd.DataFrame(np.random.randn(50, 4) * 0.01, index=dates, columns=["A", "B", "C", "D"])
    univ_res = engine.evaluate_universe_topology(df)
    assert univ_res["universe_size"] == 4
    assert univ_res["betti_0"] >= 1


# ─────────────────────────────────────────────────────────────────────────────
# 3. Pearlian Causal Discovery & Invariant SCM Tests
# ─────────────────────────────────────────────────────────────────────────────
def test_pearlian_causal_discovery():
    from ml_alpha.causal_structural_discovery import PearlianCausalDiscoveryEngine

    engine = PearlianCausalDiscoveryEngine(prune_threshold=0.05)

    # Test 1: Ground-truth synthetic DAG: X0 -> X1 -> X2
    np.random.seed(42)
    n = 600
    x0 = np.random.uniform(-2, 2, n)
    x1 = 0.75 * x0 + np.random.laplace(0, 0.4, n)
    x2 = -0.60 * x1 + np.random.exponential(0.4, n)
    X = np.column_stack([x0, x1, x2])
    names = ["MACRO", "SECTOR", "STOCK"]

    engine.fit(X, variable_names=names)
    diag = engine.diagnostics()
    assert diag["status"] == "CONVERGED_DIRECT_LINGAM"
    assert diag["is_acyclic"] is True
    assert diag["dag_edges_count"] >= 1
    assert 0.0 <= diag["graph_causal_density"] <= 1.0

    # Test 2: Pearl's Do-Calculus Counterfactual Intervention
    # Intervening on MACRO = +2.0 should propagate downstream to STOCK
    intervention = engine.intervene_do({"MACRO": 2.0}, target="STOCK")
    assert "counterfactual_expectations" in intervention
    assert intervention["target_response"] is not None
    # Effect through negative edge from SECTOR -> STOCK should make STOCK response negative
    assert intervention["target_response"] < 0.0

    # Test 3: Invariant Causal Alpha Scoring
    alphas = engine.compute_invariant_causal_alphas(target_index=2)
    assert alphas["target_variable"] == "STOCK"
    assert 0.0 <= alphas["causal_stability_ratio"] <= 1.0


# ─────────────────────────────────────────────────────────────────────────────
# 4. Continuous-Time Mean-Field Game (MFG) Nash Execution Tests
# ─────────────────────────────────────────────────────────────────────────────
def test_mean_field_game_nash_execution():
    from math_engine.mean_field_nash_execution import MeanFieldGameNashExecutionEngine

    engine = MeanFieldGameNashExecutionEngine()
    Q0 = 25000.0
    T = 60.0
    res = engine.compute_nash_trajectory(
        initial_shares=Q0,
        horizon_minutes=T,
        n_steps=60,
        current_price=1200.0,
    )

    # Test 1: Trajectory endpoints
    samples = res["trajectory_samples"]
    nash_traj = samples["inventory_mfg_nash"]
    assert nash_traj[0] == pytest.approx(Q0, rel=1e-3)
    assert nash_traj[-1] == 0.0  # Complete liquidation

    # Test 2: Monotonic decrease of inventory
    for i in range(len(nash_traj) - 1):
        assert nash_traj[i] >= nash_traj[i + 1]

    # Test 3: Costs and slippage savings
    assert res["cost_mfg_nash_bps"] > 0.0
    assert res["cost_twap_bps"] > 0.0
    assert res["slippage_savings_vs_twap_bps"] >= 0.0  # Nash should be superior or equal to TWAP
    assert (
        "regime" in res["execution_regime"].lower()
        or "execution" in res["execution_regime"].lower()
        or "equilibrium" in res["execution_regime"].lower()
    )


# ─────────────────────────────────────────────────────────────────────────────
# 5. Symplectic Geometric Hamiltonian Phase-Space ODE Tests
# ─────────────────────────────────────────────────────────────────────────────
def test_symplectic_hamiltonian_ode():
    from math_engine.symplectic_hamiltonian_ode import SymplecticHamiltonianODEEngine

    engine = SymplecticHamiltonianODEEngine(n_assets=3, dt=0.01)
    q0 = np.array([0.2, -0.4, 0.1])
    p0 = np.array([0.05, 0.1, -0.05])
    cov = np.array([
        [0.04, 0.01, 0.005],
        [0.01, 0.03, 0.008],
        [0.005, 0.008, 0.05]
    ])

    res = engine.simulate_leapfrog(q_init=q0, p_init=p0, n_steps=600, covariance_matrix=cov)
    
    # Test 1: Energy conservation (|Delta H| < 1e-3)
    assert res["energy_conservation_satisfied"] is True
    assert res["max_relative_energy_drift"] < 1e-3
    assert res["symplectic_geometric_status"] in (
        "STRICT_SYMPLECTIC_CONSERVATION",
        "BOUNDED_QUASI_PERIODIC_ORBIT",
    )

    # Test 2: Dynamic stability
    assert res["orbit_stability_ratio"] > 0.0
    assert len(res["sampled_q"]) > 5
    assert len(res["sampled_p"]) > 5


# ─────────────────────────────────────────────────────────────────────────────
# 6. End-to-End Orchestration & Web Telemetry Tests
# ─────────────────────────────────────────────────────────────────────────────
def test_tier_omega_telemetry_integration():
    from optimizer_risk import compute_sovereign_tier_omega_telemetry

    np.random.seed(42)
    dates = pd.date_range("2025-01-01", periods=80, freq="B")
    symbols = ["RELIANCE", "TCS", "INFY", "HDFCBANK", "ICICIBANK"]
    rets = pd.DataFrame(np.random.randn(80, 5) * 0.015, index=dates, columns=symbols)
    weights = {"RELIANCE": 0.3, "TCS": 0.25, "INFY": 0.2, "HDFCBANK": 0.15, "ICICIBANK": 0.1}

    telemetry = compute_sovereign_tier_omega_telemetry(rets, portfolio_weights=weights)

    # Validate overall telemetry payload
    assert telemetry["status"] == "SUCCESS"
    assert "Sovereign Tier-Ω" in telemetry["architecture"]

    # Pillar 1: Rough Volatility
    rvol = telemetry["rough_volatility"]
    assert rvol["status"] == "CALIBRATED"
    assert "hurst_exponent" in rvol
    assert "skew_decay_power_law" in rvol

    # Pillar 2: Topological Persistent Homology
    tda = telemetry["topological_tda"]
    assert tda["status"] == "COMPUTED"
    assert tda["betti_0"] >= 1
    assert "persistence_entropy" in tda

    # Pillar 3: Pearlian Causal SCM
    causal = telemetry["causal_discovery"]
    assert causal["status"] == "DISCOVERED_DAG"
    assert "topological_causal_order" in causal
    assert len(causal["topological_causal_order"]) > 0

    # Pillar 4: Mean-Field Game Nash Execution
    mfg = telemetry["mean_field_game_execution"]
    assert mfg["status"] == "NASH_EQUILIBRIUM_SOLVED"
    assert mfg["slippage_savings_vs_twap_bps"] >= 0.0
    assert "trajectory_samples" in mfg

    # Pillar 5: Symplectic Hamiltonian ODE
    symp = telemetry["symplectic_hamiltonian"]
    assert symp["status"] == "CONSERVED"
    assert symp["energy_conservation_satisfied"] is True
    assert symp["max_relative_energy_drift"] < 1e-3


def test_app_tier_omega_bridge_and_endpoint():
    from web_dashboard.app import AgenticDesktopBridge

    telemetry = AgenticDesktopBridge.compute_tier_omega_telemetry()
    assert telemetry is not None
    assert telemetry.get("status") == "SUCCESS"
    assert "Sovereign Tier-Ω" in telemetry.get("architecture", "")
    assert "rough_volatility" in telemetry
    assert "topological_tda" in telemetry
    assert "causal_discovery" in telemetry
    assert "mean_field_game_execution" in telemetry
    assert "symplectic_hamiltonian" in telemetry

    # Verify cache idempotency
    cached = AgenticDesktopBridge.compute_tier_omega_telemetry()
    assert cached is telemetry
