"""
tests/test_stress_tester.py
===========================
Unit test suite for math_engine.stress_tester.MacroFactorStressTester.
Validates multi-factor joint shock propagation, Ridge regression calibration,
sector-based hedging mechanics, and the 6 canonical Sovereign Tier-0 historical crises.
"""
import pytest
import numpy as np
import pandas as pd
from math_engine.stress_tester import MacroFactorStressTester


def test_stress_tester_fit_ridge_regression():
    """Verify that multi-factor Ridge regression solver produces valid Betas and R2."""
    np.random.seed(42)
    dates = pd.date_range("2025-01-01", periods=60, freq="B")
    
    # Simulate 5 macro factor returns
    factors_df = pd.DataFrame({
        "MKT": np.random.normal(0.0005, 0.012, 60),
        "VIX": np.random.normal(0.0, 0.045, 60),
        "OIL": np.random.normal(0.0, 0.025, 60),
        "BOND": np.random.normal(0.0, 0.008, 60),
        "DXY": np.random.normal(0.0, 0.006, 60),
    }, index=dates)

    # Asset 1 (High MKT beta, negative oil)
    ret1 = 1.2 * factors_df["MKT"] - 0.3 * factors_df["OIL"] + np.random.normal(0, 0.005, 60)
    # Asset 2 (Low MKT beta, positive oil)
    ret2 = 0.6 * factors_df["MKT"] + 0.5 * factors_df["OIL"] + np.random.normal(0, 0.005, 60)

    assets_df = pd.DataFrame({"STOCK_A": ret1, "STOCK_B": ret2}, index=dates)

    tester = MacroFactorStressTester(portfolio_value_inr=2_000_000.0)
    tester.fit(assets_df, factors_df)

    assert tester._is_fitted is True
    assert set(tester.betas.index) == {"STOCK_A", "STOCK_B"}
    assert "MKT" in tester.betas.columns
    assert "OIL" in tester.betas.columns

    # Verify directional Beta signs
    assert tester.betas.loc["STOCK_A", "MKT"] > 0.8
    assert tester.betas.loc["STOCK_A", "OIL"] < 0.0
    assert tester.betas.loc["STOCK_B", "OIL"] > 0.0
    assert (tester.r_squared >= 0.0).all()


def test_stress_tester_fit_from_assets():
    """Verify calibration from active holdings metadata."""
    sample_holdings = [
        {"ticker": "ONGC.NS", "sector": "Energy", "weight_pct": 15.0, "beta": 0.72},
        {"ticker": "INDIGOPNTS.NS", "sector": "Paints & Chemicals", "weight_pct": 10.0, "beta": 0.83},
        {"ticker": "AUBANK.NS", "sector": "Financial Services", "weight_pct": 12.0, "beta": 0.65},
    ]

    tester = MacroFactorStressTester()
    tester.fit_from_assets(sample_holdings)

    assert tester._is_fitted is True
    assert "ONGC.NS" in tester.betas.index
    assert "INDIGOPNTS.NS" in tester.betas.index
    assert "AUBANK.NS" in tester.betas.index

    # ONGC has positive oil beta, Indigo Paints has negative oil beta
    assert tester.betas.loc["ONGC.NS", "OIL"] == 0.28
    assert tester.betas.loc["INDIGOPNTS.NS", "OIL"] == -0.26
    # AU Bank has bond yield sensitivity
    assert tester.betas.loc["AUBANK.NS", "BOND"] == -0.24


def test_simulate_custom_shock_telemetry():
    """Verify custom multi-factor shock calculation, Rupee loss, and role attribution."""
    sample_holdings = [
        {"ticker": "ONGC.NS", "sector": "Energy", "weight_pct": 50.0, "beta": 0.70},
        {"ticker": "INDIGOPNTS.NS", "sector": "Paints", "weight_pct": 50.0, "beta": 0.80},
    ]

    tester = MacroFactorStressTester().fit_from_assets(sample_holdings)
    weights = {"ONGC.NS": 50.0, "INDIGOPNTS.NS": 50.0}

    # Simulate an oil shock (+50% crude, -10% market)
    res = tester.simulate_custom_shock(
        weights=weights,
        mkt_pct=-10.0,
        vix_pct=30.0,
        oil_pct=50.0,
        bond_bps=50.0,
        dxy_pct=5.0,
        portfolio_val=1_000_000.0,
        asset_metadata=sample_holdings
    )

    assert res["status"] == "SUCCESS"
    assert "simulated_drawdown_pct" in res
    assert "simulated_loss_inr" in res
    assert res["benchmark_drawdown_pct"] == -10.0
    assert len(res["asset_impacts"]) == 2

    # ONGC benefits from crude oil surge, outperforming Indigo Paints
    ongc_impact = next(a for a in res["asset_impacts"] if a["ticker"] == "ONGC.NS")
    indigo_impact = next(a for a in res["asset_impacts"] if a["ticker"] == "INDIGOPNTS.NS")
    assert ongc_impact["simulated_return_pct"] > indigo_impact["simulated_return_pct"]
    assert "Crisis Anchor" in ongc_impact["role"]


def test_get_historical_scenarios_all_six():
    """Verify all 6 canonical Sovereign Tier-0 historical crises are populated."""
    tester = MacroFactorStressTester()
    scenarios = tester.get_historical_scenarios({}, portfolio_beta=0.85)

    assert len(scenarios) == 6
    names = [s["scenario"] for s in scenarios]
    assert "2008 Global Financial Crisis" in names
    assert "2020 COVID Market Crash" in names
    assert "2018 IL&FS Liquidity Crisis" in names
    assert "2022 Global Rate Hike Shock" in names
    assert "2013 Taper Tantrum" in names
    assert "2016 Demonetisation Squeeze" in names

    for s in scenarios:
        assert s["engine_status"] == "PASS (Sovereign Tier-0)"
        assert "%" in s["portfolio_drawdown"]
        assert "%" in s["nifty_drawdown"]
