"""
tests/test_tier1_alpha_engine.py
=================================
Tier 1 Alpha Engine — Unit & Integration Test Suite (12 tests)

Tests the four Tier 1 components:
  - Level-3 Microstructure Features (VPIN, Corwin-Schultz, Hasbrouck IS, etc.)
  - Dynamic Graph Attention Network (DynamicGATEngine)
  - PPO Gating Router (PPOGatingRouter)
  - Almgren-Chriss Non-Linear Market Impact (AlmgrenChrissImpactModel)
  - HierarchicalMoEPredictor Tier 1 wiring

Run with:
    pytest tests/test_tier1_alpha_engine.py -v
"""
import numpy as np
import pandas as pd
import pytest

# ─────────────────────────────────────────────────────────────────────────────
# Fixtures
# ─────────────────────────────────────────────────────────────────────────────

@pytest.fixture(scope="module")
def price_data():
    """Synthetic OHLCV data: 120 days × 5 stocks."""
    rng = np.random.default_rng(0)
    idx = pd.date_range("2022-01-01", periods=120, freq="B")
    tickers = ["RELIANCE", "TCS", "INFY", "HDFCBANK", "ICICIBANK"]

    close = pd.DataFrame(
        rng.lognormal(0, 0.02, (120, 5)) * 1000,
        index=idx, columns=tickers
    )
    high  = close * (1 + rng.uniform(0.001, 0.015, close.shape))
    low   = close * (1 - rng.uniform(0.001, 0.015, close.shape))
    open_ = close * (1 + rng.normal(0, 0.005, close.shape))
    vol   = pd.DataFrame(
        rng.integers(500_000, 50_000_000, (120, 5), dtype=int).astype(float),
        index=idx, columns=tickers
    )
    returns = close.pct_change()
    bench   = returns.mean(axis=1).dropna()
    return {"close": close, "high": high, "low": low, "open": open_,
            "volume": vol, "returns": returns, "bench": bench, "tickers": tickers}


# ─────────────────────────────────────────────────────────────────────────────
# Component 1: Level-3 Microstructure Features (Tests 1-3)
# ─────────────────────────────────────────────────────────────────────────────

class TestMicrostructureFeatures:
    """Tests for 8 Tier 1 Level-3 microstructure estimators."""

    def test_vpin_range_and_shape(self, price_data):
        """VPIN ∈ [0, 1] and returns correct DataFrame shape."""
        from ml_alpha.microstructure_factors import vpin_proxy
        result = vpin_proxy(price_data["close"], price_data["volume"], window=20)
        assert result.shape == price_data["close"].shape
        valid = result.dropna()
        assert (valid >= 0.0).all().all(), "VPIN has values < 0"
        assert (valid <= 1.0).all().all(), "VPIN has values > 1"

    def test_corwin_schultz_non_negative(self, price_data):
        """Corwin-Schultz spread is non-negative (bid-ask spread cannot be negative)."""
        from ml_alpha.microstructure_factors import corwin_schultz_spread
        result = corwin_schultz_spread(price_data["high"], price_data["low"], window=20)
        assert result.shape == price_data["close"].shape
        valid = result.dropna()
        assert (valid >= 0.0).all().all(), "Corwin-Schultz returned negative spread"
        # Spread should be < 50% of price range (sanity bound)
        assert (valid < 0.50).all().all(), "Corwin-Schultz spread unreasonably large"

    def test_all_8_tier1_factors_present_in_compute_100(self, price_data):
        """compute_100_institutional_factors returns all 8 Tier 1 microstructure keys."""
        from ml_alpha.microstructure_factors import compute_100_institutional_factors
        factors = compute_100_institutional_factors(
            price_data["close"], price_data["high"],
            price_data["low"], price_data["open"], price_data["volume"]
        )
        tier1_keys = [
            "z_vpin_20d", "z_cs_spread_20d", "z_hasbrouck_is_20d",
            "z_amihud_nl_20d", "z_intraday_mom", "z_order_imbalance_10d",
            "z_price_discovery_20d", "z_tii_20d"
        ]
        for key in tier1_keys:
            assert key in factors, f"Missing Tier 1 factor: {key}"
        # Total factor count: 59 raw + 8 Tier 1 = 67 unique → 67 z + 67 rank = 134 min
        assert len(factors) >= 100, f"Expected >= 100 factors, got {len(factors)}"


# ─────────────────────────────────────────────────────────────────────────────
# Component 2: Dynamic Graph Attention Network (Tests 4-6)
# ─────────────────────────────────────────────────────────────────────────────

class TestDynamicGATEngine:
    """Tests for the DynamicGATEngine (Veličković et al. 2018)."""

    def test_gat_fit_and_fitted_flag(self, price_data):
        """GAT must set fitted_=True after fit_dynamic_attention call."""
        from ml_alpha.graph_attention_network import DynamicGATEngine
        gat = DynamicGATEngine(n_heads=2, hidden_dim=4, n_epochs=2)
        gat.fit_dynamic_attention(
            price_data["tickers"],
            returns_df=price_data["returns"]
        )
        assert gat.fitted_ is True
        assert gat.attention_adj_ is not None
        n = len(price_data["tickers"])
        assert gat.attention_adj_.shape == (n, n)

    def test_gat_propagate_preserves_shape(self, price_data):
        """propagate() output has same length as input scores."""
        from ml_alpha.graph_attention_network import DynamicGATEngine
        gat = DynamicGATEngine(n_heads=2, hidden_dim=4, n_epochs=2)
        gat.fit_dynamic_attention(price_data["tickers"], returns_df=price_data["returns"])
        n = len(price_data["tickers"])
        scores = np.linspace(-0.1, 0.2, n)
        out = gat.propagate(scores, alpha_blend=0.30)
        assert len(out) == n
        assert np.isfinite(out).all(), "propagate returned non-finite values"

    def test_gat_attention_different_from_identity(self, price_data):
        """With real base scores the learned attention must be non-uniform.

        R34-16: the Round 33 version of this test was vacuous — its assertion
        `n_varied_rows >= 1 OR mean(|adj|) > 0` is always true (a softmax
        attention matrix always has positive mean). It now asserts that
        supplying cross-sectionally varying base_scores produces attention
        rows that are NOT all identical, i.e. the attention logits actually
        differentiate (the R34-3 fix requirement).
        """
        from ml_alpha.graph_attention_network import DynamicGATEngine
        gat = DynamicGATEngine(n_heads=2, hidden_dim=4, n_epochs=5)
        scores = np.linspace(-0.1, 0.2, len(price_data["tickers"]))
        gat.fit_dynamic_attention(
            price_data["tickers"],
            returns_df=price_data["returns"],
            base_scores=scores,
        )
        assert gat.fitted_ is True
        assert gat.fused_adj_ is not None, "Fused adjacency was not built"
        attn = gat.attention_adj_
        assert attn is not None and attn.shape == (len(scores), len(scores))
        # Attention rows must not all be identical (differentiated logits).
        row_vars = np.var(attn, axis=1)
        n_varied = int(np.sum(row_vars > 1e-8))
        assert n_varied >= 1, (
            f"Attention matrix fully uniform ({n_varied} varied rows) — with "
            "varying base_scores the logits must differentiate (R34-3/R34-16)"
        )
        # Rows must remain a valid simplex (softmax rows sum to ~1).
        row_sums = attn.sum(axis=1)
        assert np.allclose(row_sums, 1.0, atol=1e-6), "Attention rows must sum to 1"


# ─────────────────────────────────────────────────────────────────────────────
# Component 3: PPO Gating Router (Tests 7-9)
# ─────────────────────────────────────────────────────────────────────────────

class TestPPOGatingRouter:
    """Tests for the PPOGatingRouter (Schulman et al. 2017 PPO)."""

    def test_ppo_observation_shape(self, price_data):
        """build_ppo_observation must return a vector of exactly 8 elements."""
        from ml_alpha.ppo_gating_router import build_ppo_observation
        obs = build_ppo_observation(price_data["bench"].values)
        assert obs.shape == (8,), f"Expected (8,), got {obs.shape}"
        assert np.isfinite(obs).all(), "Observation contains NaN/inf"

    def test_heuristic_router_weights_sum_to_one(self, price_data):
        """Heuristic router weights must sum to 1.0 (valid probability simplex)."""
        from ml_alpha.ppo_gating_router import PPOGatingRouter
        router = PPOGatingRouter(use_ppo=False)  # heuristic mode
        router.fit(price_data["bench"].values, n_episodes=5)
        weights = router.select_weights(price_data["bench"].values)
        assert set(weights.keys()) == {"trend_momentum", "mean_reversion", "peer_spillover"}
        total = sum(weights.values())
        assert abs(total - 1.0) < 1e-3, f"Weights sum to {total}, expected 1.0"
        for k, v in weights.items():
            assert 0.0 <= v <= 1.0, f"Weight {k}={v} outside [0,1]"

    def test_ppo_router_diagnostics(self, price_data):
        """get_diagnostics() returns expected keys."""
        from ml_alpha.ppo_gating_router import PPOGatingRouter
        router = PPOGatingRouter(use_ppo=False)
        router.fit(price_data["bench"].values, n_episodes=3)
        diag = router.get_diagnostics()
        assert "type" in diag
        assert "fitted" in diag
        assert diag["fitted"] is True
        assert "current_weights" in diag


# ─────────────────────────────────────────────────────────────────────────────
# Component 4: Almgren-Chriss Market Impact (Tests 10-11)
# ─────────────────────────────────────────────────────────────────────────────

class TestAlmgrenChrissImpactModel:
    """Tests for the Almgren-Chriss (2001) market impact model."""

    def test_square_root_law_scaling(self):
        """
        Impact scales with sqrt(Q/ADV) for temporary component.
        Doubling order size should increase temp impact by ~√2 ≈ 1.41x.
        """
        from ml_alpha.almgren_chriss_impact import AlmgrenChrissImpactModel
        model = AlmgrenChrissImpactModel()

        # Compute temporary-only impact (exclude fixed baseline)
        adv = 100_000_000
        vol = 0.02
        eta = model.eta
        # Theoretical temp impact = eta * vol * sqrt(Q/ADV)
        q1_adv = 1_000_000 / adv
        q2_adv = 4_000_000 / adv
        temp1_theory = eta * vol * np.sqrt(q1_adv) * 10_000  # bps
        temp2_theory = eta * vol * np.sqrt(q2_adv) * 10_000  # bps
        ratio_theory = temp2_theory / (temp1_theory + 1e-9)
        # sqrt(4) = 2, so ratio must be between 1.8 and 2.2
        assert 1.8 < ratio_theory < 2.2, (
            f"Square-root law theory ratio: expected ≈ 2, got {ratio_theory:.3f}"
        )
        # Also verify model bps scale is sensible (> flat baseline, < 200 bps)
        _, _, total1 = model.compute_impact_bps(1_000_000, adv, vol)
        assert model.flat_bps_baseline * 10_000 < total1 < 200.0

    def test_thin_stock_penalized_more_than_liquid(self):
        """
        A thin illiquid stock should have higher total impact than a large-cap
        for the same order notional (verifies cross-sectional ranking correctness).
        """
        from ml_alpha.almgren_chriss_impact import AlmgrenChrissImpactModel
        model = AlmgrenChrissImpactModel()

        order = 500_000  # ₹5 Lakh — same order for both

        # Large-cap: ₹5000 Cr ADV, 1.5% daily vol
        _, _, total_large = model.compute_impact_bps(order, 50_000_000_000, 0.015)

        # Small-cap: ₹5 Cr ADV, 5.0% daily vol
        _, _, total_small = model.compute_impact_bps(order, 50_000_000, 0.05)

        assert total_small > total_large, (
            f"Small-cap impact ({total_small:.1f}bps) should exceed "
            f"large-cap impact ({total_large:.1f}bps)"
        )


# ─────────────────────────────────────────────────────────────────────────────
# Component 5: HierarchicalMoE Tier 1 Integration (Test 12)
# ─────────────────────────────────────────────────────────────────────────────

class TestHierarchicalMoETier1:
    """Integration test for Tier 1 MoE wiring (GAT + PPO)."""

    def test_moe_tier1_init_and_regime_breakdown(self, price_data):
        """
        HierarchicalMoEPredictor with Tier 1 flags initialises correctly and
        get_regime_breakdown() returns all expected Tier 1 diagnostic keys.
        """
        from ml_alpha.hierarchical_moe import HierarchicalMoEPredictor

        # Tier 1 mode
        moe = HierarchicalMoEPredictor(use_ppo_gating=True, use_gat_spillover=True)
        assert moe.use_ppo_gating is True or moe.ppo_router is None  # True if torch available
        assert moe.use_gat_spillover is True or not moe.use_gat_spillover  # True if GAT available

        # Tier 2 compat mode
        moe2 = HierarchicalMoEPredictor(use_ppo_gating=False, use_gat_spillover=False)
        assert moe2.ppo_router is None
        assert moe2.use_gat_spillover is False

        # Build a tiny feature matrix and fit for regime breakdown test
        from sklearn.preprocessing import StandardScaler
        import numpy as np
        rng = np.random.default_rng(1)
        n_samples = 60
        n_features = 10
        X = pd.DataFrame(
            rng.normal(0, 1, (n_samples, n_features)),
            columns=[f"z_feat_{i}" for i in range(n_features)]
        )
        y = rng.normal(0, 0.01, n_samples)
        tickers_rep = (price_data["tickers"] * ((n_samples // len(price_data["tickers"])) + 1))[:n_samples]
        bench = price_data["bench"].values[:n_samples]

        moe2.fit(X, y, tickers=tickers_rep, benchmark_returns=pd.Series(bench))
        breakdown = moe2.get_regime_breakdown()

        required_keys = {"current_regime", "expert_weights", "denoiser_diagnostics", "ppo_router"}
        assert required_keys.issubset(set(breakdown.keys())), (
            f"Missing keys in breakdown: {required_keys - set(breakdown.keys())}"
        )
        weights = breakdown["expert_weights"]
        assert abs(sum(weights.values()) - 1.0) < 1e-3, "Expert weights don't sum to 1"
