"""tests/test_unified_broker_gateway.py
========================================
Unit tests for Unified Multi-Broker Gateway & Multi-Demat Order Router.
"""
import sys, os, unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from enterprise.connectors.unified_broker_gateway import (
    AngelOneSmartAPIConnector,
    ZerodhaKiteConnector,
    DhanHQConnector,
    FyersAPIConnector,
    InteractiveBrokersConnector,
    MultiDematRouter,
)


class TestUnifiedBrokerGateway(unittest.TestCase):

    def test_angel_one_paper_trading(self):
        conn = AngelOneSmartAPIConnector({"paper": True})
        self.assertTrue(conn.connect())
        order = conn.place_order("RELIANCE.NS", 10, "BUY", "LIMIT", 2950.0)
        self.assertEqual(order["status"], "SIMULATED")
        self.assertEqual(conn.get_positions()["RELIANCE.NS"], 10)

    def test_zerodha_kite_paper_trading(self):
        conn = ZerodhaKiteConnector({"paper": True})
        self.assertTrue(conn.connect())
        order = conn.place_order("INFY.NS", 20, "BUY", "LIMIT", 1820.0)
        self.assertEqual(order["status"], "SIMULATED")
        self.assertEqual(conn.get_positions()["INFY.NS"], 20)

    def test_dhan_hq_paper_trading(self):
        conn = DhanHQConnector({"paper": True})
        self.assertTrue(conn.connect())
        order = conn.place_order("TCS.NS", 5, "BUY", "LIMIT", 4200.0)
        self.assertEqual(order["status"], "SIMULATED")

    def test_fyers_paper_trading(self):
        conn = FyersAPIConnector({"paper": True})
        self.assertTrue(conn.connect())
        order = conn.place_order("HDFCBANK.NS", 15, "BUY", "LIMIT", 1680.0)
        self.assertEqual(order["status"], "SIMULATED")

    def test_ibkr_paper_trading(self):
        conn = InteractiveBrokersConnector({"paper": True})
        self.assertTrue(conn.connect())
        order = conn.place_order("ICICIBANK.NS", 25, "BUY", "LIMIT", 1280.0)
        self.assertEqual(order["status"], "SIMULATED")

    def test_multi_demat_router_basket_splitting(self):
        router = MultiDematRouter()
        conn1 = AngelOneSmartAPIConnector({"paper": True})
        conn2 = ZerodhaKiteConnector({"paper": True})

        router.register_connector("Account_1", conn1, 0.60)
        router.register_connector("Account_2", conn2, 0.40)

        orders = [
            {"ticker": "RELIANCE.NS", "qty": 100, "side": "BUY", "price": 2950.0},
            {"ticker": "TCS.NS", "qty": 50, "side": "BUY", "price": 4200.0},
        ]
        # AUDIT-FIX (Round 41, GLM-verify): route_rebalanced_basket() now runs the
        # canonical run_pretrade_gate() before dispatch (Claude R41 audit — the
        # enterprise gateway previously had NO compliance screen). This test
        # exercises the 60/40 basket-SPLITTING mechanics, not compliance: the
        # 2-order basket's implied weights (66.7%/33.3%) legitimately breach the
        # default position limits, so the PM override flag is required to reach
        # the routing layer. The gate's own BLOCK/BREACH-halt behaviour (with
        # cfg=None and strict cfg) is independently locked by
        # tests/test_round41_audit_fixes.py::test_multi_demat_router_pretrade_compliance_block.
        res = router.route_rebalanced_basket(orders, compliance_override=True)
        self.assertEqual(res["status"], "OK")
        self.assertIn("Account_1", res["results"])
        self.assertIn("Account_2", res["results"])
        self.assertEqual(res["results"]["Account_1"]["executed"], 2)
        self.assertEqual(res["results"]["Account_2"]["executed"], 2)
        # AUDIT-FIX (Round 5, 2-g-21): the 60/40 split was never verified — a
        # router that duplicated the FULL basket to both accounts (double
        # execution) passed the executed-count assertions above. Sum the
        # per-account per-ticker quantities and check the allocation ratios.
        def _qty_by_ticker(account):
            acc = res["results"][account]
            fills = (acc.get("results") or acc.get("fills")
                     or acc.get("orders") or [])
            out = {}
            for f in fills:
                t = f.get("ticker") or f.get("symbol")
                out[t] = out.get(t, 0) + int(f.get("qty") or f.get("filled_qty") or 0)
            return out

        q1, q2 = _qty_by_ticker("Account_1"), _qty_by_ticker("Account_2")
        for o in orders:
            t = o["ticker"]
            total = q1.get(t, 0) + q2.get(t, 0)
            self.assertEqual(total, o["qty"],
                             f"{t}: split quantities {q1.get(t, 0)}+{q2.get(t, 0)} "
                             f"must sum to the original {o['qty']}")
            # 60/40 routing (paper connectors execute the routed quantity)
            self.assertAlmostEqual(q1.get(t, 0), round(o["qty"] * 0.60), delta=1,
                                   msg=f"{t}: Account_1 split {q1.get(t, 0)} != 60% of {o['qty']}")
            self.assertAlmostEqual(q2.get(t, 0), round(o["qty"] * 0.40), delta=1,
                                   msg=f"{t}: Account_2 split {q2.get(t, 0)} != 40% of {o['qty']}")


if __name__ == "__main__":
    unittest.main(verbosity=2)
