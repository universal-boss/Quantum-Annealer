# BUGFIX REPORT — Round 22
# Quantum Annealer — Round-21 Feature Integrity Audit (Wiring, Labels, Test Hermeticity)

*Prepared by: GLM (Super Z)*
*Date: 2026-09-11*
*Input reviewed: `Quantum Annealer.zip` (Round-21 workspace, build QA-R20-R21-SOVEREIGN-TIER-OMEGA, 262 Python files) + `quantum_annealer_log_2026-09-11_01_27_17.txt` (9-profile sweep runtime log, 9/9 succeeded) + `BUGFIX_REPORT_ROUND20.md`*
*Baseline for comparison: Round 20 (GLM) and Round 21 (Antigravity) reports*
*Build marker after this round: **QA-R20-R21-R22-SOVEREIGN-TIER-OMEGA***

---

## 1. VERDICT ON THE UPLOADED WORKSPACE

**What Round 21 (Antigravity) did right:**
- All 20 Round-18 fabrication eliminations, all 6 Round-19 display-honesty fixes, and all
  19 Round-20 fixes remain present and functional (verified by the full regression suite:
  334/335 tests green in the uploaded state).
- The six R21 claims are REAL in code: `PROFILE_NAME` is defined in all 9 `PROFILE_MAP`
  profiles and echoed by `ProfileCashOverlay` (confirmed in the user's log);
  `_CANONICAL_MARKET_REGIME` unifies the overlay / ChartV3 / pipeline-summary regime
  reporting (log shows consistent "Bear" across all three); OOS validation now reports
  `IS_Window_Days` / `OOS_Window_Days` / `Selection_Bias_Risk` / `Structural_Diagnosis`
  and the FactorAttr line carries the RETROACTIVE BASKET disclosure (all visible in the
  log); `fetch_nse_option_chain` is a genuine NSE v3 API client with correct max-pain
  math, TTL cache and honest `None` on failure; the tax engine's rate math (STCG 20% /
  LTCG 12.5%) is correct.
- The user's 9/9 sweep log shows every R21 feature operating with no crashes: ML-alpha
  honest refusals, OOS-Suspicious verdicts, Inst-DSR FAIL verdicts surfaced in the
  summary line, per-profile names in the cash overlay.

**What was broken (fixed this round):**

| # | Severity | Finding | Status |
|---|----------|---------|--------|
| R22-1 | **CRITICAL (functional)** | `/api/tax_optimizer` was **dead-on-arrival**: the handler passed the *same* price as both `BuyPrice` and current price (`curr_prices[tk] = ep`, where `entry_price` in holdings is populated from the screening CSV's *current* price) — unrealized PnL was identically zero, so the R21-5 tax engine could NEVER produce a nonzero result. It also (a) multiplied the measured savings by an invented `×1.25` "rebalance savings" markup and (b) silently hardcoded a ₹1,000,000 portfolio value. | **FIXED** — lots now come from `TradeJournalManager` ACTIVE paper trades (real entry prices recorded at fill time, last-marked current prices, `entry_date → HoldingDays`); position sizing uses an explicit `?portfolio_value=` query param (default ₹1,000,000, disclosed in `data_source`); savings equal the engine's measured values only; the `×1.25` markup is gone. End-to-end verified: journal lot (entry ₹3000 → marked ₹2500, 90d, 10% weight) → 33 shares → ₹16,500 loss → ₹3,300 STCG savings. |
| R22-2 | MEDIUM (dead code) | `optimizer.py` ran `TaxLossHarvestingOptimizer.identify_harvestable_lots(portfolio_df, {})` with an **empty** current-prices map inside the sweep pipeline — the result (`_tax_res`) was never read anywhere. Decorative no-op implying the sweep "ran" the tax engine. | **FIXED** — call removed with an AUDIT-FIX note; the real wiring lives in `/api/tax_optimizer` (journal-sourced). |
| R22-3 | HIGH (integrity / mislabel) | `fetch_nse_option_chain` served `iv_percentile = median(IV across all strikes)` — a cross-sectional IV **level** mislabeled as a **percentile** (a percentile ranks today's IV against its own 1-year history, which a single chain snapshot cannot produce; the two readings have opposite trading implications at extremes). Likewise `iv_skew_25d_delta` actually carried a fixed ±5%-moneyness OTM skew, not a strike solved for a 25-delta option. Also: a missing `underlyingValue` flowed through as `spot_price=0.0` (and anchored the skew lookup at `strike[0]`); the endpoint's `is not None` gate would have served it. | **FIXED** — keys renamed to `median_iv` and `iv_skew_5pct_otm` with an explicit `data_source` disclosure of what each number is; `spot <= 0` refuses honestly (returns `None`); the endpoint now requires a positive numeric spot before serving; fallback payload uses the same honest keys. |
| R22-4 | LOW (shape consistency) | `identify_harvestable_lots`'s empty-input early return omitted the `total_tax_saved_inr` key that the populated path returns. | **FIXED** — key added (0.0). |
| R22-5 | **CRITICAL (test suite reliability)** | `tests/test_round21_regressions.py::test_r21_6` called the **live nseindia.com endpoint** — the suite fails on any network where NSE is unreachable (verified: NSE returns HTTP 403 to this environment; NSE's Akamai WAF blocks most CI/datacenter IPs). The R21 claim "335 passed, 0 failed" was reproducible only from a network with NSE access; **1 failed here** (334/335). | **FIXED** — the test is now hermetic: `NSEClient.get` is monkeypatched with canned contract-info + option-chain-v3 payloads; max-pain, PCR, median-IV, ±5% skew, spot, expiry, cache-hit and stale-TTL refetch are all verified against hand-computed values (max pain 23000, PCR 0.52, median IV 17.0, skew 2.0). An opt-in live smoke (`QA_LIVE_NETTESTS=1`) skips honestly when NSE is unreachable. |

**Verified-but-not-bugs (documented for the record):**
- **GARP tail-hedge delta Rs16,296** (log line 43): `OptionsTailHedger` math verified
  correct in isolation (strike 22300 = 5% OTM of the real spot 23477.8, BS delta 0.162,
  lots = ceil(delta / (spot × lot × |Δ|))). The tiny delta implies GARP's 15 selected
  microcaps had near-zero 63-day betas vs NIFTY (plausible for the HFCL/CUPID-class
  illiquid names the IS-cost haircut surfaced) — while BarraRisk's 0.621 beta is a
  full-lookback factor-model estimate. Two different estimators, two different windows;
  the hedge uses per-stock trailing betas only. Recommendation for a future round: feed
  the hedge the Barra portfolio beta as a cross-check or floor.
- **Inst-DSR log naming**: `DSR=0.8445` in the log is the z-statistic
  (`deflated_sharpe`), not the DSR probability; `p=0.1992 = 1−Φ(z)` and the verdict
  (`p < 0.05`) are computed correctly and are self-consistent across all 6 logged
  profiles. Cosmetic only; left as-is to avoid churning the locked log format.
- **ChartV3 "Market Regime=bear" (lowercase)** vs overlay "Bear": intentional
  normalization for the regime-tagged cache key; values agree.
- **P_bear=0.52 → cash 52%**: `_default_cash = max(0.30, p_bear)` by design; the
  Capital Preservation profile's 50% is its configured cap.

---

## 2. VERIFICATION (independent, this session)

- **Parse/compile**: `ast.parse` + `py_compile` clean on **all 263** Python files
  (262 original + `tests/test_round22_regressions.py`).
- **Full regression suite**: **342 passed / 0 failed / 1 skipped** in 85s
  (was 334 passed / 1 failed on the uploaded state; +7 R22 locks, +1 opt-in live test).
  R6→R22 lineage intact: R16 (60), R17, R18 (19), R19 (17), R20 (20), R21 (8),
  R22 (7) all green.
- **End-to-end tax flow simulation** (temp journal): entry ₹3000 → marked ₹2500,
  90 days, 10% weight on ₹1M → 33 shares → ₹16,500 loss → **₹3,300 STCG savings**
  (engine produces a real result for the first time; previously identically zero).
- **Hermetic option-chain math**: canned NSE payloads → max pain 23000.0,
  PCR 0.52, median IV 17.0, skew +2.0, spot 24000.0, expiry discovery, 5-min cache
  hit (0 extra HTTP calls), stale-entry refetch.
- **Network reality check**: live `NSEClient.get` to nseindia.com returns
  **HTTP 403** from this environment — exactly the failure mode that broke the
  R21-6 test; the suite now passes with the network fully blocked.
- **Log cross-check**: every R21 feature line in the user's 9/9 sweep log
  (Profile= echo, OOS-Suspicious, RETROACTIVE BASKET, Inst-DSR FAIL tags,
  canonical regime) traces to code that still works after the R22 changes.

---

## 3. FILES CHANGED (Round 22)

| File | Sites |
|------|-------|
| `web_dashboard/app.py` | `_handle_tax_optimizer` rewritten (journal lot ledger, disclosed PV param, no ×1.25 markup); route dispatcher passes query params; `_handle_options_surface` honest keys + positive-spot gate + expanded fallback; `APP_BUILD_ID → QA-R20-R21-R22-SOVEREIGN-TIER-OMEGA` |
| `data_layer.py` | `fetch_nse_option_chain`: `median_iv` / `iv_skew_5pct_otm` honest keys + `data_source` disclosure; `spot <= 0` honest refusal; docstring corrected |
| `math_engine/tax_loss_harvesting.py` | empty-input return gains `total_tax_saved_inr` |
| `optimizer.py` | dead decorative `_tax_res` call removed (AUDIT-FIX R22-2 note at the site) |
| `tests/test_round21_regressions.py` | `test_r21_6` rewritten hermetic (mocked `NSEClient.get`, hand-verified math, cache + stale-TTL locks); new opt-in `test_r21_6b` live smoke |
| `tests/test_round22_regressions.py` | NEW — 7 locks: R22-1 pattern+behavior (journal sourcing, no `curr_prices[tk] = ep`, no `* 1.25`), R22-2 no dead tax call, R22-3 honest chain keys + spot guard, R22-4 empty-return shape, R22-5 endpoint gate + fallback keys, R22-6 R21-6 stays hermetic (all pattern locks run against comment/docstring-stripped code so AUDIT-FIX prose can't false-trip them) |

---

## 4. WHAT STILL REMAINS (honest residual list)

1. **Option-chain freshness in the sweep**: `fetch_nse_option_chain` is wired only to
   `/api/options_surface`; the GEX/tail-hedge modules still take spot from the price
   frame and IV from the 18% policy default. Wiring the live chain's median IV into
   `OptionsTailHedger(iv=...)` and its expiry into `dte_days` would make hedge deltas
   regime-accurate instead of policy-flat.
2. **Tax endpoint marks**: journal `current_price` is only as fresh as the last
   `update_live_prices` call — the disclosure in `data_source` says so; wiring a
   live quote refresh into the endpoint would close the gap.
3. **GARP-class beta divergence** (trailing 63d per-stock betas ≈ 0 for illiquid
   microcaps vs Barra 0.621): consider a beta floor or Barra cross-check in the
   tail hedge so the hedge size doesn't silently collapse for illiquid baskets.
4. The R20 residual list items already addressed by R21 (OOS bias labeling, regime
   unification, profile names) are now *disclosed* but the OOS **window redesign**
   itself (walk-forward selection instead of full-lookback prescreening) remains
   the structural root cause — Net Alpha 26–70% ann. magnitudes are still
   retroactive-basket artifacts, honestly labeled.
5. `identify_harvestable_lots` assumes losses are fully offsettable against
   same-category realized gains (no ₹-carried-forward-loss modeling, no
   LTCG ₹1.25L exemption handling) — fine for an "est." label, worth documenting
   on the panel.

*Every fix carries an `AUDIT-FIX (Round 22 — R22-n)` comment at the site, and
`tests/test_round22_regressions.py` locks each elimination — including a lock that
keeps the option-chain test hermetic — so the next edit that re-introduces any of
these patterns fails the suite immediately.*
