# BUGFIX REPORT — Round 23
# Quantum Annealer — Round-22 Residual List Closure (Live-Input Wiring, Mark Freshness, Beta Floor, WFO Diagnostics, Tax Disclosure)

*Prepared by: GLM (Super Z)*
*Date: 2026-09-11*
*Input reviewed: Round-22 workspace (build QA-R20-R21-R22-SOVEREIGN-TIER-OMEGA, 263 Python files) + `BUGFIX_REPORT_ROUND22.md` §4 residual list*
*Baseline for comparison: Round 22 (GLM) report — 342 passed / 0 failed / 1 skipped at hand-off*
*Build marker after this round: **QA-R20-R21-R22-R23-SOVEREIGN-TIER-OMEGA***

---

## 1. SCOPE OF THIS ROUND

Round 22 closed the five functional defects of the R21 features and left an explicit
"honest residual list" (§4 of the R22 report). The user asked to **fix the remaining
bugs one by one**. This round closes all five residuals:

| Residual (R22 §4) | Round-23 ID | Severity | Status |
|---|---|---|---|
| 1. Option-chain freshness in the sweep (GEX/tail-hedge on price-frame spot + 18%/30d policy IV/DTE) | **R23-1** | HIGH | **FIXED** |
| 2. Tax endpoint marks only as fresh as the last `update_live_prices` call | **R23-2** | MEDIUM-HIGH | **FIXED** |
| 3. GARP-class beta divergence (63d microcap betas ≈ 0 → hedge silently collapses) | **R23-3** | **CRITICAL** | **FIXED** |
| 4. OOS window redesign (walk-forward selection) — root cause of retroactive-basket alpha | **R23-4** | STRUCTURAL | **MEASURED** (diagnostics wired; full re-selection remains residual, see §4) |
| 5. `identify_harvestable_lots` simplifications undocumented on the panel | **R23-5** | LOW | **FIXED** |

**Final state: 265 Python files compile; full regression suite 356 passed / 0 failed / 1
skipped (opt-in live smoke) in ~81 s; end-to-end flow simulations for the tail hedge
and the tax refresh both verify against hand-computed values.**

---

## 2. WHAT WAS FIXED, IN ORDER

### R23-1 — Live option-chain inputs wired into GEX + the tail hedge (HIGH)

**The bug.** `fetch_nse_option_chain` existed and worked (R21-4/R22-3), but it was wired
*only* to `/api/options_surface`. Inside the sweep, `OptionsTailHedger` computed its put
delta from the flat policy inputs — IV 18%, DTE 30 days — regardless of the actual chain
(12%-IV low-vol regimes and 25%-IV stress regimes got the same delta; a 3-DTE expiry was
priced as a month). GEX was worse: `calculate_net_gamma_exposure()` was *always* called
without a chain, so every run served the canned fallback verdict
`net_gex = +Rs 150,000,000, Positive GEX (Mean-Reverting)` — a fabricated market-wide
gamma regime that never touched real OI. Collar premiums were a flat 1.2%-of-index
heuristic disconnected from the IV/DTE used for the delta.

**The fix.**
- `math_engine/options_hedger.py` gains `resolve_live_chain_inputs()`: converts the
  chain's `median_iv` (NSE reports **percent**) to a Black-Scholes fraction, parses the
  `expiry` string to calendar DTE (floored at 1; past/unparseable keeps the default),
  and returns honest `iv_source` / `dte_source` labels ("live NSE chain median IV
  11.80% (NIFTY)" vs "policy default (18%) — live chain unavailable/degraded").
  `_parse_nse_expiry` handles the NSE date formats and refuses garbage.
- `calculate_hedge_recommendation()` accepts `iv_source` / `dte_source` and echoes them
  (plus `premium_model`) in the response; the summary appends
  `[IV/DTE: policy defaults — live chain unavailable]` whenever the inputs are not live,
  so a policy-flat hedge can never masquerade as a regime-accurate one.
- Premiums now use `_bs_put_price` / `_bs_call_price` with the **same** (spot, strike,
  r, iv, T) as the delta; the 1.2% heuristic survives only as a *disclosed* fallback.
- `data_layer.fetch_nse_option_chain` additionally returns `chain_rows` (per-strike
  `strikePrice/callOI/putOI/callIV/putIV`) and a 120 s **negative cache**
  (`_OPTION_CHAIN_FAIL_TS`): a failed/non-200 fetch stamps the key so an offline sweep
  (9 profiles × GEX + tail-hedge call sites) doesn't re-burn 10 s timeouts per attempt;
  successes clear the stamp.
- `optimizer.py` (sweep): the GEX block fetches the chain once (best-effort), prefers
  the chain's live underlying spot over the close-frame spot (logged), and computes GEX
  **from the real per-strike OI rows**. The tail-hedge block resolves
  `resolve_live_chain_inputs` and passes `iv`/`dte_days` (+ sources) into the hedge.
  Offline, every step degrades to the previous behavior *with disclosure*.
- `web_dashboard/app.py` (trade-execution suite): the collar is priced from the same
  live chain (spot + IV + DTE) when reachable; the benchmark feed remains the fallback.

**Verified.** Hermetic unit locks (percent→fraction conversion, DTE parsing incl.
same-day/past/garbage, source labels); mocked-chain GEX (sums of OI rows = totals);
end-to-end: a simulated chain (spot 24,715.80, median IV 11.8%, expiry 30-Sep-2026)
produces `iv=0.118, dte=19` in the hedge and a GEX of **−Rs 146.6 B (negative, crash
accelerator)** from real OI — versus the old canned +150 M positive verdict.

### R23-2 — Tax endpoint live mark refresh (MEDIUM-HIGH)

**The bug.** R22-1 correctly sourced lots from the journal, but `current_price` marks
were only as fresh as the *last* `update_live_prices` call. On an idle dashboard the
"tax harvest savings" figure ran on days-old marks while the `data_source` prose implied
current prices.

**The fix.** New `data_layer.fetch_nse_equity_last_prices(symbols)` (NSE quote-equity
`priceInfo.lastPrice`, 60 s per-symbol cache, raw-ticker key preservation, hard symbol
cap). `_handle_tax_optimizer` now refreshes marks **at request time** before building
lots: successes are persisted through `TradeJournalManager.update_live_prices` (journal
lock; stop/target evaluation runs on the fresh marks and the lot snapshot is
re-filtered), failures keep the last marks **and say so** — the response carries
`marks_refreshed_count` plus a `data_source` line of either
"refreshed live via NSE quote-equity at HH:MM:SS (n/m symbols)" or
"LAST MARKED prices (live quote refresh unavailable — offline or rate-limited)".

**Verified.** Mocked-quote parsing (raw key `RELIANCE.NS` → 2987.65, cache hit makes no
second HTTP call, 403 → honest empty dict); end-to-end with a temp journal: entry
₹1,000 → refresh ₹850 (STCG, 90 d) and entry ₹800 → ₹600 (LTCG, 400 d) yield
₹3,000 + ₹2,500 = **₹5,500** measured from the *refreshed* marks.

### R23-3 — Disclosed beta floor + Barra cross-check in the tail hedge (CRITICAL)

**The bug.** The R22 residual: trailing 63-day betas of illiquid microcaps regress to
≈ 0, so the portfolio's beta-weighted delta (and therefore the whole hedge size)
silently collapsed — the GARP-profile anomaly (₹16,296 hedge) was exactly this: a
"verified-correct" hedger fed degenerate inputs. Nothing flagged it.

**The fix.** `calculate_hedge_recommendation(beta_floor=…, barra_portfolio_beta=…)`:
equity rows with beta below the floor are raised to it — **disclosed, never silent**:
the response lists `beta_floor_applied_to` (tickers), `beta_basis_note` (floored count +
NaN-defaulted count), the floor value, and the Barra factor-model portfolio beta +
`barra_cross_check_note` when available. CASH rows are exempt (beta 0 is legitimate).
The sweep passes `TAIL_HEDGE_BETA_FLOOR` (default 0.30) and
`risk_attrib["portfolio_beta"]`; both the sweep and the execution suite log the floor
application and the Barra comparison at the operator console.

**Verified.** 60/30/10 portfolio with microcap betas 0.05/1.2/0.0: delta basis
0.39 → **0.54** with floor (tickers listed, CASH exempt); NaN-beta rows counted;
end-to-end GARP-shaped basket (3 microcaps 0.02–0.07) → basis 0.0295 → 0.3825
(**13× larger hedge requirement, 5 lots**) with all three floored tickers disclosed.

### R23-4 — OOS walk-forward selection-bias diagnostics (STRUCTURAL → MEASURED)

**The problem.** The sweep prescreens the universe on the full lookback, then measures
"OOS" performance on the same window — the retroactive-basket artifact behind the
26–70 % ann. Net Alpha magnitudes. R20–R22 *labeled* this; nobody *measured* it per run.
The full fix (re-running the entire screen at each of K cutoffs inside the sweep)
multiplies runtime by K — a redesign, not a bugfix.

**What this round ships.** New `math_engine/oos_walkforward.py`:
- `walk_forward_selection_overlap(close_df, selected, n_folds, mom_lookback)` — at each
  of K historical cutoffs, re-ranks the universe by trailing momentum (the screener's
  own 6-month window), takes the point-in-time top-N, and measures overlap with the
  final basket. Mean overlap → explicit `retroactive_basket_risk` verdict
  (LOW ≥ 50 % / MODERATE 25–50 % / **HIGH < 25 % — retroactive-basket artifact**).
- `fold_alpha_concentration(port_ret, bench_ret, n_folds)` — per-fold realized alpha,
  annualized alpha, and the share of positive alpha from the single best fold
  (> 50 % → "CONCENTRATED — regime-episode dependent, not a persistent edge").
- Wired into the sweep (`payload["oos_walkforward_diagnostics"]`, cfg `WFO_DIAG_FOLDS` /
  `WFO_DIAG_MOM_LOOKBACK`, one `[WFO-Diag]` log line per profile). It **never changes
  selection** — it quantifies the look-ahead leakage so the operator sees a number, not
  a footnote.

**Verified.** Synthetic stable-leader basket → 100 % overlap / LOW; retroactive basket
(60-day late risers) → 16.7 % / HIGH; degenerate inputs → honest UNMEASURED. Alpha
concentration: all-alpha-in-one-fold series → CONCENTRATED (> 80 % share); broad series
→ BROAD-BASED.

### R23-5 — Tax assumption disclosure (LOW)

**The bug.** `identify_harvestable_lots` assumes losses are fully offsettable against
same-category realized gains (no unabsorbed / carried-forward-loss modeling, no 8-year
limit tracking) and ignores the LTCG ₹1.25 L annual exemption slab — but the panel
presented the number with only an implied "est." label.

**The fix.** `TaxLossHarvestingOptimizer.ENGINE_ASSUMPTIONS` (class constant) is
returned in **both** code paths; the endpoint response carries an `assumptions` list;
`dashboard.js` renders it on hover (with the mark-freshness note) and flags the figure
with a `*` (gross estimate). The R22-4 shape lock still passes (superset).

---

## 3. VERIFICATION

| Check | Result |
|---|---|
| `ast.parse` on all 265 workspace `.py` files | 0 failures |
| Full suite `pytest tests/` (hermetic) | **356 passed / 0 failed / 1 skipped** (~81 s) |
| New locks `tests/test_round23_regressions.py` | 14/14 green (units, pattern locks on stripped code, hermetic mocked-network tests) |
| R22 / R21 / R20 regression locks | all still green (R21-8 build-ID lock satisfied by the new marker) |
| End-to-end hedge flow (simulated live chain) | IV 0.118 / DTE 19 d / floored tickers disclosed / 5 lots; GEX −Rs 146.6 B from real OI rows |
| End-to-end tax flow (temp journal + refreshed marks) | ₹3,000 STCG + ₹2,500 LTCG = ₹5,500, assumptions disclosed |
| Test-order robustness | R21-6 hermetic test now clears the new negative cache (an earlier test's unmocked live NSE probe previously stamped it and suppressed the mock — bisected, root-caused, fixed at the test-setup layer without weakening any R22-6 lock) |

---

## 4. WHAT STILL REMAINS (honest residual list)

1. **Full walk-forward RE-SELECTION.** R23-4 measures the retroactive-basket bias per
   run; eliminating it requires re-running the whole screen at each of K cutoffs inside
   every profile (runtime × K). The honest interim posture: read the
   `oos_walkforward_diagnostics` verdict before trusting any Net Alpha figure — a HIGH
   verdict means the basket is a look-back artifact.
2. **Per-strike gamma is still the GEX approximation** (`0.0001` × spot² proxy), not a
   strike-solved BS gamma; the OI and flip price are now real, the gamma scaling is not.
3. **Beta floor is a policy, not a model.** 0.30 bounds the microcap collapse; a
   liquidity-aware beta estimator (or Barra per-stock betas) would replace the floor
   with real numbers. The Barra cross-check is disclosed alongside.
4. **Journal price-mark freshness for non-NSE-quoted symbols** (BSE-only / suspended
   tickers) still degrades to last marks — disclosed, not fabricated.
5. **Tax engine**: no carried-forward-loss ledger, no LTCG exemption slab — now stated
   on the panel itself; implementing them needs a realized-gains ledger that the
   journal does not yet record.

*Every fix carries an `AUDIT-FIX (Round 23 — R23-n)` comment at the site, and
`tests/test_round23_regressions.py` locks each elimination — pattern locks run on
comment/docstring-stripped code so AUDIT-FIX prose can't false-trip them.*
