# BUGFIX REPORT — Round 24
# Quantum Annealer — Round-23 Residual List Closure (True-OOS Re-Selection, Strike-Solved GEX Gamma, Liquidity-Aware Beta, Layered Price Marks, Realized-Gains Tax Ledger)

*Prepared by: GLM (Super Z)*
*Date: 2026-09-11*
*Input reviewed: Round-23 workspace (build QA-R20-R21-R22-R23-SOVEREIGN-TIER-OMEGA) + `BUGFIX_REPORT_ROUND23.md` §4 residual list*
*Baseline for comparison: Round 23 (GLM) report — 356 passed / 0 failed / 1 skipped at hand-off*
*Build marker after this round: **QA-R20-R21-R22-R23-R24-SOVEREIGN-TIER-OMEGA***

---

## 1. SCOPE OF THIS ROUND

Round 23 closed the R22 residuals and left five structural residuals, each honestly
labeled "measured/disclosed, not eliminated". The user asked to **fix the remaining
bugs**. This round eliminates all five at the level each one admits:

| Residual (R23 §4) | Round-24 ID | Severity | Status |
|---|---|---|---|
| 1. Full walk-forward RE-SELECTION (retroactive-basket bias measured, not eliminated) | **R24-1** | **STRUCTURAL** | **ELIMINATED at the selection layer** (true-OOS alpha + measured bias per run; pipeline-scope disclosed) |
| 2. GEX gamma is the `0.0001 × spot²` proxy, not a strike-solved BS gamma | **R24-2** | HIGH | **FIXED** (per-strike Black-Scholes gamma with per-strike IVs) |
| 3. Beta floor is a policy, not a model | **R24-3** | HIGH | **FIXED** (liquidity-aware shrinkage estimator; floor demoted to backstop) |
| 4. Journal price-mark freshness for non-NSE-quoted symbols degrades to last marks | **R24-4** | MEDIUM | **FIXED** (NSE→BSE layered quotes + measured per-mark staleness) |
| 5. Tax engine: no carried-forward-loss ledger, no LTCG exemption slab | **R24-5** | **CRITICAL** | **FIXED** (realized-gains ledger + Sec 70/74 set-off + 8y carry + Rs1.25L exemption modeled) |

**Final state: 263 Python files compile clean; full regression suite 373 passed / 0
failed / 1 skipped (opt-in live smoke) in ~99 s; two R23 pattern locks updated to the
stronger Round-24 wiring (supersession documented in-test); the BSE fallback was
verified against the live Yahoo feed from this network (NSE itself blocks, as
documented in Round 22).**

---

## 2. WHAT WAS FIXED, IN ORDER

### R24-1 — Full walk-forward RE-SELECTION: a TRUE out-of-sample alpha (STRUCTURAL)

**The bug.** The R23-4 diagnostics measured how historically unstable the final basket
was (point-in-time overlap + fold alpha concentration) but every reported performance
number still came from the retroactively-selected basket. The honest posture was "read
the verdict before trusting Net Alpha" — a HIGH verdict meant the headline was a
look-back artifact, and nothing told you what the number *should* have been.

**The fix.** `math_engine/oos_walkforward.py` gains
`walk_forward_reselection_backtest()` — the screen itself is re-run point-in-time:

- At each of K cutoffs (`WFO_RESELECT_FOLDS`, default 4; `WFO_RESELECT_SCORE_LOOKBACK`,
  default 126) the **prescreen factor family** is recomputed *vectorized* on the
  trailing window only (momentum 1m/3m/6m, annualized vol, range contraction, VCP
  BB-width contraction, OBV slope, up/down vol ratio, drawdown, ADV20, RS vs the
  benchmark over the same window), robust cross-sectional z-scored, and combined with
  the **same mode-weighted scoring the live prescreen uses** (all 12 profile modes:
  balanced, early_entry, garp, momentum_chase, accumulation, breakout_early,
  vol_squeeze, quality_*, defense, institutional_alpha).
- The top-K basket is selected point-in-time, weighted inverse-vol (trailing 63d), and
  forward-tested to the next cutoff with the same turnover-cost convention as the WFO
  backtest (fee+slippage bps × fraction of new names).
- Output: per-fold baskets/weights/turnover/returns/overlap, a **true-OOS total,
  annualized return, Sharpe, and annualized alpha vs the benchmark**, and the
  **measured retroactive-basket bias** (headline `Alpha vs Benchmark` − true-OOS alpha)
  with an explicit LOW/HIGH/NEGATIVE verdict.
- Wired into `run_optimizer_logic` (gated `WFO_FULL_RESELECTION`, default **True** —
  it runs in seconds on the in-memory frames, no network, no ×K solver cost) as
  `payload["oos_walkforward_reselection"]` + a `[WFO-ReSel]` console verdict line.

**Honest scope, disclosed in every payload (`method_disclosure`):** the QUBO/HRP
allocation is NOT re-run per cutoff (the runtime×K cost the R23 report refused to
impose silently — inverse-vol stands in); the TOP_N liquidity pool prescreen is not
replayed (the in-memory frame IS the full-lookback pool; liquidity ranking is
comparatively stable, momentum-mode pool leak remains); earnings/F&O-ban/corp-action
blackouts and CMF (needs intraday High/Low) are live-only and enter as disclosed
neutrals. This is the honest **prescreen-level true-OOS** measure — the selection-layer
leakage that created the retroactive-basket bias is gone; the residual list shrinks to
allocation- and pool-level effects, explicitly named.

**No look-ahead, locked by test:** a ticker that only starts rising at day 200 is never
selected at cutoffs ending before day 200 and is selected once its rise enters the
trailing window (`test_r24_1b`).

### R24-2 — GEX gamma is now strike-solved Black-Scholes, not a flat proxy (HIGH)

**The bug.** `calculate_net_gamma_exposure` scaled **every** strike with
`(call_oi − put_oi) × lot × spot² × 0.0001`. That 0.0001 is an ATM-ish gamma magnitude
applied uniformly: real BS gamma decays from ~5×10⁻⁴ (ATM, 14% IV, 14 DTE) to ~2×10⁻⁶
at 10% OTM — the proxy **overstated wing-strike gamma by ~245×**, misshaping both the
net GEX level and the flip-price location.

**The fix.** `math_engine/options_hedger.py` gains `_bs_gamma()` (N'(d1)/(S·σ·√T)) and
`calculate_net_gamma_exposure` now solves gamma per strike using the **chain's own
per-strike IVs** (`callIV`/`putIV` columns, NSE percent units) with the chain-level
median IV as fallback — which itself now flows in from `resolve_live_chain_inputs` via
the new `iv=…, dte_days=…, iv_source=…, dte_source=…` parameters wired at the sweep
call site. Convention disclosed in the response: `net_gex_rupees = Σ Γ_BS·(CallOI −
PutOI)·lot·S²` — the INR change in aggregate net dealer delta per 1-point index move.
Degenerate inputs are honest: strikes with no usable IV (per-strike AND chain-level)
contribute **zero** and are counted in `gex_source` ("N strike(s) … contributed 0 — no
fabricated gamma"); the no-chain fallback keeps the canned +Rs150M prior but now
labels itself `gex_source: "CANNED PRIOR — … placeholder, not a measurement"`. New
disclosure keys: `gex_source`, `gamma_model`, `gamma_range`, `dte_days_used`.

### R24-3 — Beta is now a liquidity-aware model; the flat floor is a backstop (HIGH)

**The bug.** R23-3 bounded the microcap beta collapse (63d OLS betas ≈ 0 from stale/
asynchronous microcap prices — the Epps/non-trading bias) with a flat 0.30 floor. A
policy, not a model: it bounded the collapse at an arbitrary constant without
estimating anything.

**The fix.** `math_engine/indicators.py` gains `liquidity_aware_beta()`:

```
beta_adj = w · beta_OLS + (1 − w) · 1.0,     w = n_eff / (n_eff + κ)
n_eff   = n_valid × clip(ADV20 / Rs 5 cr, 0, 1),     κ = 8 (default)
```

Illiquid rows (low ADV20) have attenuated measured covariance — the estimator shrinks
exactly those rows toward the market prior; a full-window liquid name retains ~89% of
its OLS beta; the collapse case (OLS −0.035, ADV Rs20L) lands at 0.75 instead of the
old floor's 0.30. `utils.compute_signal_frame` (the source of the hedge's betas)
computes betas through the estimator by default (`USE_LIQUIDITY_AWARE_BETA`, cfg
tunable: `BETA_WINDOW_DAYS`, `BETA_SHRINK_PRIOR`, `BETA_SHRINK_KAPPA`,
`BETA_LIQ_REF_ADV_INR`) and keeps **`beta_raw` + `beta_shrink_weight`** columns for
disclosure. The tail hedger's response gains `beta_estimation_note` (the model, the
κ, the prior) and the floor note now reads *backstop below the liquidity-aware
estimate* — the floor survives as a disclosed guard, no longer as the defense.
Behavior verified: liquid OLS 2.14 → 2.01; illiquid OLS 2.14 → 1.16; the collapse
case −0.035 → 0.75.

### R24-4 — Layered NSE→BSE price marks with measured staleness (MEDIUM)

**The bug.** The R23-2 mark refresh used NSE quote-equity only. BSE-only listings and
suspended NSE tickers got no refresh and silently degraded to the journal's last marks
— disclosed as "stale", but never measured and never given a second source.

**The fix.**
- `data_layer.fetch_equity_last_prices_multi_source()`: **layer 1** NSE quote-equity
  (same 60 s cache) → **layer 2** BSE `.BO` quote via yfinance (300 s cache,
  `fast_info` with a 1-day history probe fallback) for every symbol NSE could not
  serve. Returns `{symbol: {price, source, fetched_at}}`; symbols quoted by *neither*
  layer are omitted — the caller keeps last marks and discloses them, never invents
  prices. **Live-verified from this network:** NSE blocks (as documented in R22) but
  the BSE leg quoted RELIANCE at Rs 1,258.00 through Yahoo's BSE feed.
- `TradeJournalManager.update_live_prices(current_prices, price_sources=…)` stamps
  every refreshed row with **`last_mark_ts`** (epoch) and **`price_mark_source`**.
- `/api/tax_optimizer` refreshes through the layered fetcher, persists with sources,
  and the response gains a per-symbol **`marks`** array — `{ticker, mark_price,
  source, age_hours, state ∈ refreshed | recent | stale | unmeasured}` — plus a
  summary note ("N via NSE quote-equity, M via BSE (.BO) fallback; X lot(s) still on
  stale journal marks (older than 4h)"). The dashboard tax strip renders the stale
  marks and the net tax position on hover.

### R24-5 — Realized-gains ledger + Sec 70/74 set-off + LTCG exemption slab (CRITICAL)

**The bug.** The tax engine assumed every harvested loss was instantly and fully
offsettable against same-category gains, with no carry-forward and no LTCG exemption —
stated on the panel since R23-5, structurally unfixable "without a realized-gains
ledger the journal does not yet record".

**The fix — the ledger now exists and the rules are modeled:**
- **`core/realized_gains_ledger.py`** (new): persistent, atomic-write (mkstemp+fsync+
  rename, corrupt-file quarantine — the journal's durability discipline) ledger of
  realized events `{ticker, entry/exit dates+prices, holding_days, tax_category
  (STCG/LTCG at the 365d line), realized_pnl_pct, realized_pnl_inr when shares known,
  weight_pct, assessment_year}`. Idempotent per journal id; `net_gains_by_category(ay,
  portfolio_value_inr)` prices unpriced events from weight×pv with an honest
  `unpriced_events` count when neither is available.
- **`TradeJournalManager` funnels every close into it**: stop-outs, target hits, and
  the stale-row close in `log_basket` all call `_record_realized_close`; construction
  **backfills** historical CLOSED/STOPPED_OUT/TARGET_HIT rows (idempotent), so prior
  tax years are not silently lost.
- **`TaxLossHarvestingOptimizer.compute_tax_position()`** (new; the legacy gross
  estimate remains for compatibility): applies the actual rules on the ledger —
  **Sec 70/74 set-off order** (STCL → STCG first, then LTCG; **LTCL only ever against
  LTCG**), **brought-forward unabsorbed losses** consumed first, **8-year
  carry-forward**, and the **Rs 1,25,000 LTCG exemption slab applied to net LTCG
  *after* set-offs** (Sec 112A; STCG has no exemption). The harvesting value is the
  tax delta between harvesting and not — losses that cannot be absorbed this year are
  reported as carry-forward, not as same-year cash. Every figure hand-verified in
  tests (e.g. STCG 60k/LTCG 40k + harvest STCL 10k/LTCL 20k → tax 12,000 → 10,000,
  saving exactly 2,000; brought LTCL 50k can never touch STCG 50k).
- **`/api/tax_optimizer`** now computes the net position (ledger + carry-forward
  state), persists the *factual* (without-harvest) remainder to
  `qa_db/tax_carry_forward.json` for the next assessment year, and returns
  `net_tax_position` (realized nets, harvestable STCL/LTCL, brought-forward, tax
  without/with harvest, immediate saving, exemption applied, carry-forward created,
  verdict). The panel headline becomes the **immediate same-year saving**, not the
  gross estimate. Assumptions list now states what is genuinely unmodeled
  (surcharge/cess, settlement adjustments) — the two R23 "not modeled" items are gone
  because they are now modeled.

---

## 3. VERIFICATION

- **Full suite:** `373 passed / 0 failed / 1 skipped` (the skipped test is the opt-in
  live NSE smoke, `QA_LIVE_NETTESTS=1` — NSE blocks datacenter IPs). Suite runtime
  ~99 s. (Note: the venv had lost `arch`/`yfinance` since Round 23 — both restored
  this round; the 4 `arch`-conditional tests pass again.)
- **New locks:** `tests/test_round24_regressions.py` — 17 tests: deterministic
  single-fold re-selection math, no-look-ahead selection (day-200 riser never picked
  before day 200), honest UNMEASURED degenerates, sweep wiring pattern locks; BS
  gamma closed-form + wing decay + hand-verified per-strike-IV GEX (both IV paths,
  degenerate-IV-zero, canned-prior disclosure) + flat-proxy elimination lock;
  estimator behavior (liquid/illiquid/collapse/NaN/unknown-liquidity), signal-frame
  disclosure columns + opt-out, hedger backstop notes; layered-fetcher unit locks
  (BSE fallback, cache, honest omission), journal mark stamps, endpoint pattern
  locks; set-off/exemption/carry math, ledger idempotency + AY bucketing + unpriced
  honesty, journal→ledger funnel + backfill idempotency, endpoint net-position
  wiring.
- **Superseded locks:** two R23 pattern locks updated to the stronger Round-24 wiring
  (`test_r23_1b` GEX call now asserts the resolved-iv/dte parameters;
  `test_r23_2a` endpoint refresh now asserts the layered fetcher + staleness detail).
  Both carry an in-test "R24 supersession" note. All other R23/R22/R21/R20 locks pass
  unchanged.
- **Live checks from this network:** BSE fallback quoted RELIANCE at Rs 1,258.00 via
  Yahoo's BSE feed (NSE leg 403-blocked, disclosed as expected). The WFO re-selection
  and all engine math verified on synthetic data against hand-computed values.
- **Build marker** → `QA-R20-R21-R22-R23-R24-SOVEREIGN-TIER-OMEGA` (satisfies the R21
  build-id lock regex).
- **Pre-existing artifact observation:** `models/ml_alpha_model.pkl` (44.7 MB) is
  absent from the current workspace — only its `.sha256` manifest sidecar remains (it
  was present in the Round-23 package). This is not a Round-24 regression: the ML
  alpha overlay is optional, its loader is fail-safe (`[ML Alpha] Auto-load notice`
  without aborting), and the latent-embedding generator likewise falls back to its
  deterministic projection engine (logged). Retraining regenerates the artifact; the
  signed-pickle guard (SHA-256 manifest check) continues to protect the reload path.

---

## 4. WHAT STILL REMAINS (honest residual list)

1. **Re-selection depth.** The true-OOS alpha re-runs the *prescreen selection layer*
   point-in-time; the QUBO/HRP **allocation** and the TOP_N **pool** prescreen are not
   replayed per cutoff (runtime×K / full-universe history). The payload's
   `method_disclosure` states this on every run. A full-pipeline WFO would close both
   at the cost of ~K× sweep runtime.
2. **GEX dealer-positioning convention.** Strike gamma is real BS now, but the
   (CallOI − PutOI) dealer-sign proxy and the single-expiry chain remain conventions;
   a true dealer-positioning GEX needs per-trade direction data NSE does not publish.
3. **Beta prior is the market, not a factor model.** The shrinkage prior (β=1.0) is
   statistical honesty, not a Barra/Axioma per-stock beta; the Barra cross-check
   remains the reference, and the estimator's `BETA_SHRINK_PRIOR` is the integration
   point when a factor-model feed is licensed.
4. **BSE marks are best-effort Yahoo data.** The `.BO` feed can lag or miss symbols
   (one live test symbol was "not found" and honestly omitted); suspended tickers with
   no BSE quote still fall back to last journal marks — now *measured* (age in hours)
   and disclosed per symbol.
5. **Tax model scope.** Set-off order, 8-year carry, and the Rs 1.25L exemption are
   modeled on the ledger; surcharge/cess, Sec 112A grandfathering (pre-Jul-2024
   holdings), and trade-date settlement adjustments are not (stated in `assumptions`).
   Carry-forward persistence is per-dashboard-instance JSON — a multi-broker setup
   should source it from the broker's realized P&L statements.

*Every fix carries an `AUDIT-FIX (Round 24 — R24-n)` comment at the site, and
`tests/test_round24_regressions.py` locks each elimination — pattern locks run on
comment/docstring-stripped code so AUDIT-FIX prose can't false-trip them.*
