# BUGFIX REPORT — Round 25
# Quantum Annealer — Round-24 Residual List Closure (Allocation-Layer WFO Replay, Multi-Expiry GEX, Factor-Model Beta Priors, Three-Layer Marks, Tax Statutory Layers)

*Prepared by: GLM (Super Z)*
*Date: 2026-09-12*
*Input reviewed: Round-24 workspace (build QA-R20-R21-R22-R23-R24-SOVEREIGN-TIER-OMEGA) + `BUGFIX_REPORT_ROUND24.md` §4 residual list*
*Baseline for comparison: Round 24 (GLM) report — 373 passed / 0 failed / 1 skipped at hand-off*
*Build marker after this round: **QA-R20-R21-R22-R23-R24-R25-SOVEREIGN-TIER-OMEGA***

---

## 0. SESSION NOTE — interrupted round, verified no reverts

This round had been **started and abruptly interrupted** in a prior session: R25-1..R25-4
code changes were partially written to disk (QUBO/HRP replay, multi-expiry GEX,
factor-beta priors, the Yahoo `.NS` mark layer) with **no tests, no build-marker bump,
no report, and no zip**. The interruption also left two R24 regression locks failing
(the half-finished rewrite collided with the R24-1 locks).

Verification before any new work (user request: *"check earlier fixes might be reverted
back"*): **all R22/R23/R24 fixes were intact** — the workspace carried the R24 build
marker, all R24 symbols present, 267 files compiled, and 371 of 373 baseline tests
passed. The only two failures were the R24-1 locks colliding with the partial R25-1
rewrite — **superseded, not reverted** (see §3). The environment venv had lost its
packages (session restart) and was restored before verification.

This session: completed the interrupted round (reconciled the two locks, finished
auditing/verifying R25-1..4, implemented the never-started R25-5 tax completeness),
added the R25 regression suite, bumped the marker, and packaged.

---

## 1. SCOPE OF THIS ROUND

Round 24 closed the R23 residuals and left five structural residuals. The user asked to
**fix the remaining bugs**. This round closes all five at the level each admits:

| Residual (R24 §4) | Round-25 ID | Severity | Status |
|---|---|---|---|
| 1. Re-selection covers the selection layer only — QUBO/HRP allocation and the TOP_N pool not replayed | **R25-1** | **STRUCTURAL** | **ELIMINATED at the allocation layer** (QUBO-core + production HRP replayed point-in-time per cutoff; inverse-vol reference series isolates the measured allocation-layer effect; TOP_N pool replay opt-in via `WFO_POOL_FULL_UNIVERSE`) |
| 2. GEX single-expiry convention + dealer-sign proxy | **R25-2** | HIGH | **Multi-expiry FIXED** (nearest `GEX_EXPIRY_DEPTH` expiries, each solved with its own T and per-strike IVs, per-expiry breakdown); dealer-sign remains a **data-blocked disclosed proxy** (NSE publishes no per-trade direction) — now disclosed verbatim on every computed response |
| 3. Beta shrinkage prior is the market (flat 1.0); Barra feed is the integration point | **R25-3** | HIGH | **FIXED** (characteristic factor-model priors — LOO cross-sectional ridge on log-ADV / 6m momentum / 63d vol — built from the local universe; `BETA_FACTOR_FEED` remains the licensed-feed override) |
| 4. BSE marks best-effort Yahoo; NSE-missed names degrade to the BSE price | **R25-4** | MEDIUM | **FIXED** (genuine middle layer: direct NSE → Yahoo `.NS` → BSE `.BO`, each 300s-cached, per-source counts in the refresh note) |
| 5. Tax model excludes surcharge/cess, Sec 112A grandfathering, settlement adjustments | **R25-5** | **CRITICAL** | **FIXED** (surcharge slabs with the 112A 15% cap + 4% cess; pre/post-Jul-2024 per-tranche rate regimes; Sec 112A(2) FMV grandfathering via `TAX_FMV_31JAN2018`; trade-date Sec 2(42A) convention — the "settlement adjustment" gap was a non-issue by statute, now disclosed as such) |

**Final state: 268 Python files compile clean; full regression suite 386 passed / 0
failed / 1 skipped (opt-in live smoke) in ~134 s; every engine number hand-verified on
synthetic data (QUBO energy argmin, multi-expiry gamma sums, LOO prior recovery,
surcharge/cess/regime/grandfathering arithmetic).**

---

## 2. WHAT WAS FIXED, IN ORDER

### R25-1 — Allocation-layer replay in the walk-forward re-selection (STRUCTURAL)

**The bug.** The R24-1 true-OOS alpha replayed the *selection* layer point-in-time but
stood the *allocation* layer in with inverse-vol weights — the QUBO (which changes the
basket composition via its vol/correlation/cardinality terms) and the production HRP
weighting were never re-run at the cutoffs, and the TOP_N pool cut was inherited from
the full-lookback ranking. The disclosure said so; the numbers still carried the gap.

**The fix.** `math_engine/oos_walkforward.py`:

- `_qubo_core_select()` — the production `build_qubo` core objective
  (`q[s,s] = (−ALPHA·alpha_z + VOL_PENALTY·vol_z + GAMMA_CARD·(1−2K))/N`,
  `q[si,sj] = (2·GAMMA_RISK + THETA·√(N/K)·corr)/N` — the same coefficient formulas as
  `optimizer.build_qubo`) is rebuilt on **strictly trailing data** at each cutoff and
  solved with the production solve family: greedy alpha-ranked seed +
  first-improvement local search (mirrors `utils.local_search_improve`). Deterministic,
  no SA sampling noise.
- `_hrp_weights_replay()` — calls the **PRODUCTION** `optimizer.hrp_weights` on the
  fold's trailing returns (local Lopez de Prado mirror as hermetic fallback, disclosed
  per fold), then applies the production `MIN_WEIGHT`/`MAX_WEIGHT` bounds.
- An **inverse-vol reference series** (the exact R24 semantics: top-K mode-score +
  inverse-vol) is computed alongside, so the payload reports
  `allocation_layer_effect_pct` — the *measured* effect of replaying the allocation
  layer, not an assumption.
- **TOP_N pool replay** is opt-in (`WFO_POOL_FULL_UNIVERSE`, default False): the sweep
  re-downloads a supersample frame from the pre-cut prescreen ranking
  (`WFO_POOL_SUPERSAMPLE_N`, default 250) and applies the pool cut point-in-time per
  cutoff. Default runs keep the in-memory pool (disclosed per run).
- Fold payload now discloses `selection` (QUBO-core vs fallback), `weighting`
  (production HRP vs mirror), `reference_topk_basket`,
  `reference_invvol_fold_return_pct`, and `pool_cut_applied`.

Live-data layers NOT replayed per cutoff remain disclosed in `method_disclosure`:
sector/turnover/Barra/DRO/regime QUBO penalties, ML-alpha injection, the
DRO/BL/Kelly/MDP weighting layers above HRP, and earnings/F&O-ban blackouts.

**Wiring.** `optimizer.run_optimizer_logic` passes `replay_allocation=True`,
`allocation_cfg=working_cfg`, `hrp_lookback=WFO_HRP_LOOKBACK` (63d), `top_n_pool`
(supersample mode), and the `[WFO-ReSel]` log now reports the allocation-layer effect.

### R25-2 — Multi-expiry GEX aggregation + verbatim dealer-sign disclosure

**The bug.** The R24 GEX used the nearest expiry's chain only — the single-expiry
convention overstated near-dated gamma and ignored the calendar tail. The dealer-sign
convention was documented in the report but not on every response.

**The fix.**

- `data_layer.fetch_nse_option_chain` echoes **every live expiry date**
  (`expiry_dates`), so multi-expiry aggregation no longer needs to re-discover the
  contract calendar.
- The sweep fetches the nearest `GEX_EXPIRY_DEPTH` (default 3) expiries — each
  120s-cached by the data layer (bounded extra network cost) — and passes them as
  `multi_expiry_chains`.
- `OptionsTailHedger._calculate_net_gamma_exposure_multi()` — each expiry is solved
  with its **own T** and per-strike IVs (its own chain-level IV fallback); near-dated
  gamma decays with √T exactly like the real surface; strikes without usable IV
  contribute zero (counted per expiry). The aggregate is the SUM across expiries with a
  `per_expiry_gex` breakdown (gex / share / dte / degenerate count). The flip price is
  re-walked on the aggregated per-strike GEX.
- Only one chain available (degraded fetch) → the single-chain R24 path runs unchanged,
  disclosed. No chain at all → the disclosed canned prior.
- `DEALER_SIGN_CONVENTION` — the (CallOI − PutOI) proxy statement — is now a class
  constant returned on **every computed GEX response** (both paths). NSE does not
  publish per-trade direction; this is the honest data-blocked posture.

### R25-3 — Characteristic factor-model beta priors (the flat 1.0 target replaced)

**The bug.** The R24-3 liquidity-aware estimator shrank attenuated microcap betas
toward a **flat prior of 1.0** — honest statistics, but every illiquid name shrank
toward the same number regardless of what its characteristics implied.

**The fix.** `math_engine/indicators.factor_model_beta_prior()` builds a
**stock-specific prior from the local universe**, Barra-style:

- `y_i` = trailing OLS beta (the `beta_window` tail), `X_i` = [1, z(log ADV20 / ref),
  z(6m momentum), z(63d annualized vol)] — strictly trailing data.
- Ridge (intercept unpenalized, `ridge_lambda` default 1.0), **leave-one-out
  prediction** via the hat matrix (`PRESS`: `y_i − e_i/(1−h_ii)`, no refit loop) so a
  stock's own noisy beta never drives its own prior; clipped to `prior_band`
  (0.2–3.0).
- Cross-section < 12 stocks (or degenerate) → empty priors + reason; the caller falls
  back to the flat prior, **disclosed**.

Priority order in `utils.compute_signal_frame`: (1) cfg `BETA_FACTOR_FEED`
{ticker: beta} — the licensed Barra/Axioma per-stock feed **integration point**;
(2) the characteristic model (`USE_FACTOR_MODEL_BETA_PRIOR`, default True);
(3) flat `BETA_SHRINK_PRIOR` fallback. New per-row disclosure columns
`beta_prior` / `beta_prior_source` join R24's `beta_raw` / `beta_shrink_weight`. The
hedger's `beta_estimation_note` now describes the characteristic prior and the feed.

**Verification:** on a synthetic cross-section whose true beta is a smooth function of
the characteristics, the LOO priors track it (R² 0.92, median |err| 0.07); small
cross-sections return empty with a reason; the band clip holds.

### R25-4 — Three-layer equity marks (the missing Yahoo `.NS` middle layer)

**The bug.** The R24 layered fetcher went straight from the direct NSE quote-equity leg
(which datacenter networks cannot reach — NSE blocks them, documented since R22) to the
BSE `.BO` leg, so NSE-listed names degraded to the **BSE price** (different exchange)
even though Yahoo serves the same NSE instruments under `.NS`.

**The fix.** `data_layer` gains `_yf_ticker_last_price()` (shared Yahoo probing engine:
fast_info + 1-day history probe) and `_nse_yahoo_last_price()`. Layer order:
**(1) direct NSE quote-equity → (2) Yahoo `.NS` (300s cache) → (3) BSE `.BO`
(300s cache)**. The endpoint's refresh note counts all three layers; symbols quoted by
no layer are omitted (the caller keeps last marks and discloses staleness — unchanged
honesty rule). Verified by mocking: `.NS` serves and `.BO` is never probed; `.NS`
failure falls through to `.BO`; both-failure omits the symbol; the TTL cache serves
repeat calls with no probe.

### R25-5 — Tax completeness: surcharge/cess, rate regimes, grandfathering, trade dates

**The bug.** The R24-5 engine modeled set-off, carry-forward, and the exemption slab,
but disclosed "surcharge & cess excluded", "no grandfathering", "no trade-date
settlement adjustments".

**The fix.**

1. **Surcharge + cess** (`compute_tax_position(include_surcharge_cess=…,
   total_taxable_income_inr=…)`): individual surcharge slabs (10% > ₹50L, 15% > ₹1Cr,
   25% > ₹2Cr, 37% > ₹5Cr) chosen on `total_taxable_income_inr` when supplied, else the
   gains-only proxy (basis disclosed); the **LTCG portion's surcharge capped at 15%**
   (Finance Act 2022); **4% Health & Education Cess** on tax + surcharge. Marginal
   relief is NOT modeled — disclosed. Default `include_surcharge_cess=False` keeps the
   R24 flat-rate contract; the endpoint enables it (cfg `TAX_INCLUDE_SURCHARGE_CESS`,
   default True).
2. **Rate regimes** (pre/post 23-Jul-2024, from the ledger's `regime_split` by exit
   date): pre-tranche 15% STCG / 10% LTCG above ₹1L; post-tranche 20% / 12.5% above
   ₹1.25L. A mixed-tranche net is allocated pro-rata to the positive gross tranches
   (disclosed; exact whenever a single tranche is positive — every AY from 2025-26
   onward).
3. **Sec 112A(2) grandfathering** (ledger-level): lots acquired before 1-Feb-2018 get
   the deemed cost **max(actual cost, min(FMV-31-Jan-2018, sale price))** when the
   caller supplies the `fmv_31jan2018` feed (cfg `TAX_FMV_31JAN2018` — integration
   point; without it, unadjusted + disclosed). Applied/eligible event counts and the
   total adjustment ride on `net_gains_by_category`.
4. **Trade-date convention** (Sec 2(42A)): classification and AY bucketing use the
   CONTRACT date — a close executed on the last trading day of a FY belongs to that FY
   even though cash settles in the next. The ledger's dates were already trade dates;
   the convention is now recorded (`date_basis`, `holding_period_basis`) and locked by
   test (2025-03-31 close → AY 2025-26; 364-day holding → STCG). The old "no trade-date
   settlement adjustments" residual was a **non-issue by statute** — settlement dates
   never shift equity holding periods.

Endpoint: `?total_taxable_income` query param (validated), cfg keys, and the payload's
`net_tax_position` carries the surcharge/cess breakdown, `rate_regimes`,
`grandfathering`, and `holding_period_basis`. The dashboard hover renders them.

**Hand-verified arithmetic** (locked in tests): STCG ₹100k at ₹6Cr total income →
20,000 + 7,400 (37% slab, no 111A cap) + 1,096 cess = **₹28,496**; LTCG taxable ₹100k
at ₹6Cr → 12,500 + 1,875 (15% cap) + 575 = **₹14,950**; below ₹50L → surcharge 0 but
cess still applies (₹20,800); mixed pre/post LTCG ₹600k → **₹41,875**; grandfathered
lot (1,000 sh @100 → 150, FMV 130) → gain ₹20,000, adjustment −₹30,000.

---

## 3. LOCK SUPERSESSION (documented, intent preserved)

Two R24-1 locks collided with the completed R25-1 allocation replay and were superseded
**in-test with supersession notes** (the R23→R24 precedent):

- `test_r24_1b_reselection_is_point_in_time` — the QUBO-core basket legitimately
  contains a trailing-flat ticker at an early cutoff (zero **trailing** vol + zero
  correlation are trailing information; the production `risk_score` is vol-dominated
  the same way). The original momentum-semantics assertions now lock
  `reference_topk_basket` (the R24 top-K score semantics, reported per fold), and the
  no-look-ahead property is locked **directly** by cutoff-invariance: fold 1's basket
  is identical with and without the post-cutoff data in the frame.
- `test_r24_1d_optimizer_wires_reselection` — pattern locks updated to the stronger
  call-site wiring (`_wfr_close/_wfr_volume`, `replay_allocation=True`,
  `allocation_cfg=working_cfg`, `top_n_pool=_wfr_pool`, `WFO_POOL_FULL_UNIVERSE`,
  `WFO_HRP_LOOKBACK`); the R24 intent (default-on, volume frame, retroactive alpha,
  payload key, verdict log) unchanged.

The R23-5a assumption-string lock keywords ("offsettable" / "carried-forward" /
"exemption") were preserved verbatim in the reworded `ENGINE_ASSUMPTIONS`.

---

## 4. RESIDUALS (honest list)

1. **WFO replay scope**: the live-data QUBO penalty layers (sector concentration,
   turnover, Barra cross-check, DRO, regime), ML-alpha injection, the weighting layers
   above HRP (DRO/BL/Kelly/MDP), and earnings/F&O-ban blackout filters are NOT replayed
   per cutoff — disclosed in every `method_disclosure`. The TOP_N pool replay requires
   the supersample re-download (opt-in `WFO_POOL_FULL_UNIVERSE`) because the default
   in-memory frame IS the post-cut pool.
2. **GEX dealer positioning**: the (CallOI − PutOI) sign remains a disclosed proxy —
   NSE does not publish per-trade direction data, so a true dealer-positioning GEX is
   **data-blocked**, not fixable in code.
3. **Beta factor feed**: the local characteristic model is the default prior; a
   licensed Barra/Axioma feed (`BETA_FACTOR_FEED`) remains the authoritative
   integration point.
4. **Marks**: Yahoo `.NS`/`.BO` are best-effort; suspended tickers on neither Yahoo
   leg still fall back to the journal's last marks, with measured age disclosed.
5. **Tax**: marginal relief not modeled (near surcharge boundaries the statutory
   liability can be slightly lower); the surcharge bracket defaults to the gains-only
   proxy when total taxable income is not supplied (disclosed); the mixed-tranche
   pro-rata allocation is a disclosed convention; grandfathering needs the FMV feed
   (`TAX_FMV_31JAN2018`); carry-forward persistence remains per-instance JSON
   (multi-broker deployments should reconcile against broker realized-P&L statements).

---

## 5. HOW TO VERIFY

```bash
cd "Quantum Annealer"
python3 -m pytest -q                     # 386 passed / 0 failed / 1 skipped
python3 -m pytest -q tests/test_round25_regressions.py   # the 13 R25 locks
python3 -c "from web_dashboard.app import APP_BUILD_ID; print(APP_BUILD_ID)"
# → QA-R20-R21-R22-R23-R24-R25-SOVEREIGN-TIER-OMEGA (...)
```

The one skipped test is the opt-in live NSE smoke test (network-conditional since R22).
