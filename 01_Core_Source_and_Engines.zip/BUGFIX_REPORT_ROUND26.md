# BUGFIX REPORT — Round 26
# Quantum Annealer — A–D Revert Check (Executed), Statutory Tax Corrections, Carry-Forward Integrity

*Prepared by: GLM (Super Z)*
*Date: 2026-09-12*
*Input reviewed: Round-25 workspace (build QA-R20-R21-R22-R23-R24-R25-SOVEREIGN-TIER-OMEGA) + the round-25 conversational A–D revert checklist + `BUGFIX_REPORT_ROUND25.md` §4 residual list*
*Baseline for comparison: Round 25 (GLM) report — 386 passed / 0 failed / 1 skipped at hand-off*
*Build marker after this round: **QA-R20-R21-R22-R23-R24-R25-R26-SOVEREIGN-TIER-OMEGA***

---

## 0. SESSION NOTE — the promised A–D revert check, EXECUTED this round

Round 25's conversation ended with a paper checklist: "提供文件路径、粘贴代码或仓库访问，
我立即跑上面 A–D 清单并出 diff 报告". This round the workspace was present, so the
checklist was executed against the actual code before anything was changed:

| Checklist item | Verdict | Evidence |
|---|---|---|
| **A. BS strike gamma is real Black-Scholes** | **INTACT** | `options_hedger.py::_bs_gamma` = `norm.pdf(d1)/(S·σ·√T)` with the full d1 formula; degenerate inputs contribute 0.0 (disclosed), never a constant/NaN placeholder; multi-expiry R25-2 path present |
| **B. Journal mark age from the EXCHANGE stamp** | **INTACT** | `trade_journal.py::update_live_prices` stamps `last_mark_ts` + `price_mark_source`; `app.py` computes `age_hours = (now − last_mark_ts)/3600` — the mark's timestamp, not the fetch wall-clock; missing stamps disclose `"unmeasured"`, stale > 4h flagged |
| **C. Tax set-off / 8-year carry / Rs 1.25L exemption** | **INTACT (structure) — but see R26-3/R26-4** | Sec 70/74 order, vintage expiry (`0 < cur−yr ≤ 8` in `_ledger_carry_forward_state`), 1.25L/1L per-tranche exemptions all present; two adjacent integrity bugs found and fixed this round |
| **D. `method_disclosure` + `BETA_SHRINK_PRIOR` mitigations** | **INTACT** | `_RESELECT_DISCLOSURE` still enumerates the NOT-replayed live-data layers on all 5 call sites; the beta prior ladder (licensed `BETA_FACTOR_FEED` → characteristic model → flat prior fallback) survives in `utils.py` |

Environment: the venv had lost `dwave-neal` and `flask` again (the documented session-restart
pattern); restored before verification. Pre-change baseline: **386 passed / 0 failed /
1 skipped**, 268 files compiling — no reverts.

The A–D checklist is now **executable CI** (`tests/test_round26_regressions.py`,
`pytest -k r26_3`), so the recurring "check whether earlier fixes were reverted"
concern is guarded by the suite, not by manual audits.

---

## 1. SCOPE OF THIS ROUND

| Item | ID | Severity | Status |
|---|---|---|---|
| STCG (Sec 111A) surcharge took the UNCAPPED slab rate (37% top bracket) — the FA2022 Sec 2(11) 15% cap covers Sec 111A, 112 AND 112A | **R26-1** | **CRITICAL (statutory)** | **FIXED** (externally verified; max effective STCG rate now 23.92% = 20%×1.15×1.04) |
| Marginal relief unmodeled (R25 §4 residual #5a) | **R26-2** | MEDIUM | **FIXED** (exact on the gains-only income basis; conservative + disclosed when caller total income exceeds the gains base) |
| Net-NEGATIVE realized category buckets (the year's own STCL/LTCL, netted by the ledger) VANISHED in the engine — no Sec 70 cross-offset, no carry-forward | **R26-3** | **HIGH** | **FIXED** (routed into the set-off pools; tax was overstated) |
| Carry-forward state double-counted a surviving loss (full remainder re-stamped under the current AY while prior keys stayed stale) | **R26-4** | **HIGH** | **FIXED** (per-vintage write-back: oldest-first consumption, original vintage labels preserved, stale keys dropped) |
| A–D checklist → executable anti-revert pins | **R26-5** | — | **DONE** (14 new locks; `test_round26_regressions.py`) |

**Final state: 269 Python files compile clean; full regression suite
400 passed / 0 failed / 1 skipped (opt-in live smoke) in ~137 s; every corrected
number hand-verified and locked.**

---

## 2. WHAT WAS FIXED, IN ORDER

### R26-1 — STCG (Sec 111A) surcharge capped at 15% (CRITICAL, statutory)

**The bug.** R25-5 applied the Finance Act 2022 15% surcharge cap to the **LTCG**
tax component only and its lock asserted *"Sec 111A has no cap"*. The statute says
otherwise: the FA2022 proviso to Sec 2(11) caps the surcharge on tax on income under
**Sec 111A, 112 AND 112A** at 15% — confirmed against incometaxindia.gov.in (the
section text itself) and public effective-rate tables ("Effective STCG rate =
23.92% … the maximum surcharge is capped at 15% regardless of income level").
The R25 code charged the raw slab rate on the STCG tax: at Rs 6Cr total income,
Rs 100k STCG paid surcharge at **37%** (Rs 7,400) instead of the capped **15%**
(Rs 3,000) — an overstatement of Rs 4,576 per Rs 1L of STCG in the top bracket.

**The fix.** `tax_loss_harvesting.py`: `sr_stcg = min(sr_rate, CAP_CG_SR) * stcg_tax`
— the same constant now caps both components (name `LTCG_SURCHARGE_CAP` kept for
lock continuity; the comment states the full 111A/112/112A semantics). New payload
echo `surcharge_rate_stcg_capped`; the note text now states the statutory cap and
the maximum effective rates (STCG 23.92%, LTCG 14.95%).

**Hand-verified (locked):** STCG Rs 100k at Rs 6Cr total income → 20,000 + 3,000 +
920 = **Rs 23,920** (= 100,000 × 23.92%); the LTCG path unchanged at 14,950; below
the 50L bracket unchanged at 20,800 (surcharge 0, cess still applies); the 10%
bracket at Rs 60L income → 22,880 — the capped top-bracket liability sits correctly
between the 10% bracket and the pre-fix uncapped 28,496.

### R26-2 — Marginal relief modeled (R25 §4 residual #5a)

**The fix.** When a surcharge bracket is crossed, the aggregate
(tax + surcharge) is held at or below `tax(threshold) + (income − threshold)`:

- **Exact** when the income basis is the gains-only base (every rupee of income is
  taxed by this engine, so the tax-at-threshold scales proportionally).
- **Conservative-approximate and disclosed** when the caller-supplied
  `total_taxable_income_inr` exceeds the gains base: the non-CG tax is not modeled,
  so relief falls back to limiting the surcharge at the excess income — statutory
  liability can still be LOWER; disclosed verbatim in `marginal_relief_basis`.

Cess is now computed on (tax + **net** surcharge). New payload keys:
`surcharge_gross_inr`, `marginal_relief_inr`, `marginal_relief_basis` (engine + endpoint
+ dashboard hover).

**Hand-verified (locked):** taxable LTCG Rs 5,010,000 (gains-only) → tax 626,250,
gross surcharge 62,625, **relief 53,875**, net 8,750, cess 25,400, total **660,400**;
taxable 5,110,000 → relief 0, total 730,730; STCG 5,010,000 → relief 92,200, net
surcharge 8,000, total 1,050,400.

### R26-3 — Net-negative realized buckets no longer vanish (HIGH)

**The bug (found by the R26-3 pin test — the checklist C follow-through).** The
realized-gains ledger nets each AY's STCL into the STCG bucket and LTCL into the
LTCG bucket (`net_gains_by_category`). The engine then computed
`stcg_pos = max(0, net_stcg)` — a net-**negative** bucket (the year's realized
STCL exceeding its STCG) was silently clamped away: it never offset LTCG (Sec 70
allows STCL → LTCG), never entered `unabsorbed_stcl`, and never carried forward.
Consequence: tax overstated, and the loss was destroyed for future years.

**The fix.** `compute_tax_position` now splits each bucket into
`_realized_*_pos` (gains) and `_intra_*` (the year's own realized losses, routed
into the Sec 70/74 set-off pools alongside brought-forward losses). Scenario
breakdowns expose `intra_year_stcl_inr` / `brought_forward_stcl_inr` (and LTCL
equivalents) for the write-back path.

**Hand-verified (locked):** STCG −50k + LTCG 500k → the 50k STCL offsets LTCG →
net LTCG 450k → taxable 325k → **Rs 42,250** (pre-fix: 48,750 with the loss
destroyed). STCG −60k alone → 60k carries forward (pre-fix: vanished).

### R26-4 — Carry-forward state no longer double-counts (HIGH)

**The bug.** `_persist_carry_forward_state` wrote the FULL scenario-A remainder
(which includes brought-forward leftovers) under the CURRENT assessment-year key
while leaving prior-year keys in place. A loss that survived a year was then loaded
**twice** on subsequent requests — once from its original key, once re-stamped —
overstating future set-off capacity (an Rs 100k loss with Rs 40k absorbed loaded as
Rs 160k two years later).

**The fix.** Per-vintage write-back: the year's absorbed losses are consumed
**oldest-vintage-first** (disclosed convention); each ORIGINAL vintage is decremented
in place, so the Sec 70/74 8-year window still runs from the year the loss was FIRST
computed (no vintage laundering by re-stamping); the current year's own unabsorbed
realized losses (R26-3) enter as a NEW vintage; stale/garbage keys drop naturally.
`_ledger_carry_forward_state` now also returns the per-vintage map.

**Hand-verified (locked, 3-year simulation on a temp state file):** Y1 STCL −100k →
persists `{"AY 2025-26": 100k}`; Y2 consumes 40k → the original key decrements to
60k, no duplicate key; Y3 loads **60k only** (pre-fix: 160k); Y10 (9 years old) →
expired, 0.

### R26-5 — The A–D checklist as executable anti-revert pins

`tests/test_round26_regressions.py` (14 locks): the four R26-1/R26-2 statutory
groups, the R26-3/R26-3 carry integrity cases, and the four pins —
`r26_3a` (BS gamma: closed-form 0.0398445 @ S=K=100, σ=0.2, T=0.25, r=0; ATM peak;
wing decay; degenerate → 0.0), `r26_3b` (journal stamp + age math + honest
"unmeasured" state), `r26_3c` (set-off order, LTCL-never-STCG, net-negative
routing, vintage expiry), `r26_3d` (`_RESELECT_DISCLOSURE` layers + beta prior
ladder) — plus payload/wiring/marker locks.

---

## 3. LOCK SUPERSESSION (documented, intent preserved)

`test_r25_5a_surcharge_and_cess_math` was superseded **in-place with a supersession
note** (the R23→R24→R25 precedent): the STCG@6Cr case moves from 28,496 (37%
uncapped, "Sec 111A has no cap" — factually wrong) to **23,920** (15% cap), with
the statutory citation and the pointer to the R26 locks. The LTCG (14,950),
below-bracket (20,800) and default-off (20,000) assertions are unchanged — the fix
does not touch them. The R25 header docstring carries the supersession note; the
R23-5a assumption keywords ("offsettable" / "carried-forward" / "exemption") remain
verbatim in `ENGINE_ASSUMPTIONS`.

---

## 4. RESIDUALS (honest list)

1. **WFO replay scope** (unchanged from R25 §4): live-data QUBO penalty layers,
   ML-alpha injection, weighting layers above HRP, and blackouts are NOT replayed
   per cutoff — disclosed in every `method_disclosure`. TOP_N pool replay remains
   opt-in (`WFO_POOL_FULL_UNIVERSE`). This is the runtime×K structural residual.
2. **GEX dealer positioning** (unchanged, data-blocked): the (CallOI − PutOI) sign
   remains a disclosed proxy; NSE publishes no per-trade direction.
3. **Beta factor feed** (unchanged): the characteristic model is the default prior;
   licensed Barra/Axioma (`BETA_FACTOR_FEED`) remains the integration point.
4. **Marks** (unchanged): Yahoo `.NS`/`.BO` best-effort with measured age disclosed.
5. **Tax**: mixed-income marginal relief is the conservative approximation
   (disclosed) — pass a CA-computed total for exactness near boundaries; the
   surcharge bracket still defaults to the gains-only proxy when
   `total_taxable_income_inr` is not supplied (disclosed); the mixed-tranche
   pro-rata allocation convention is unchanged; grandfathering still needs the
   `TAX_FMV_31JAN2018` feed; carry-forward persistence remains per-instance JSON
   (now per-vintage and double-count-safe, but multi-broker deployments should
   still reconcile against broker realized-P&L statements).

---

## 5. HOW TO VERIFY

```bash
cd "Quantum Annealer"
python3 -m pytest -q                                    # 400 passed / 0 failed / 1 skipped
python3 -m pytest -q tests/test_round26_regressions.py  # the 14 R26 locks
python3 -m pytest -q tests/test_round26_regressions.py -k r26_3   # the A–D anti-revert pins
python3 -c "from web_dashboard.app import APP_BUILD_ID; print(APP_BUILD_ID)"
# → QA-R20-R21-R22-R23-R24-R25-R26-SOVEREIGN-TIER-OMEGA (...)
```

The one skipped test is the opt-in live NSE smoke test (network-conditional since R22).

Statutory verification trail for R26-1: incometaxindia.gov.in (First Schedule /
STCG pages — the Sec 111A/112/112A surcharge proviso text) and public effective-rate
tables (max effective STCG 23.92%). NOT TAX ADVICE — cross-check against a CA
before filing.
