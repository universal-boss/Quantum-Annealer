# BUGFIX REPORT — Round 27
# Quantum Annealer — Residual Fixes: Full-Layer WFO Replay, Exact Mixed-Income Marginal Relief, FMV Feed, Mark-Stamp Floor

*Prepared by: GLM (Super Z)*
*Date: 2026-09-12*
*Input reviewed: Round-26 workspace (build QA-R20-R21-R22-R23-R24-R25-R26-SOVEREIGN-TIER-OMEGA) + the R26 §4 residual list as restated by the operator at round-27 open*
*Baseline for comparison: Round 26 (GLM) report — 400 passed / 0 failed / 1 skipped at hand-off*
*Build marker after this round: **QA-R20-R21-R22-R23-R24-R25-R26-R27-SOVEREIGN-TIER-OMEGA***

---

## 0. SESSION NOTE — baseline flake root-caused (not a revert)

The pre-change baseline run came back **399 passed / 1 FAILED** —
`test_r26_3b_pin_mark_age_uses_exchange_stamp`. Root cause is NOT a revert: the
journal stamps `last_mark_ts = round(_mark_ts, 3)` and `round()` can push the
stamp up to 0.5 ms into the future, so the pin's immediately-following
`age_h = (time.time() − stamp)/3600` measured a tiny NEGATIVE age (−3.8e-08 h)
whenever the sub-millisecond alignment landed unluckily. A–D revert status:
**all intact** (the R26 suite's other 13 pins and the full 400-test body were
green). The flake is fixed production-side this round (R27-4): the stamp is now
`math.floor(_mark_ts*1000)/1000` — a mark timestamp can never precede a later
now-read, so measured age is deterministically ≥ 0 and the R26-3b pin can no
longer flake.

---

## 1. SCOPE OF THIS ROUND

| Item | ID | Severity | Status |
|---|---|---|---|
| WFO replay scope residual — live-data QUBO penalty layers, ML-alpha injection, weighting layers above HRP, blackouts NOT replayed per cutoff (the runtime×K structural residual) | **R27-1** | **STRUCTURAL** | **LARGELY ELIMINATED** — penalty layers replayed by default on trailing data; ML-alpha / blackouts / weighting stack replay through the PRODUCTION functions when point-in-time inputs are supplied; per-run `replay_scope` + dynamic `method_disclosure` |
| Mixed-income marginal relief is the conservative approximation (disclosed) | **R27-2** | MEDIUM (statutory) | **FIXED** — exact mixed-income marginal relief via the new `non_cg_tax_inr` input (pro-rata reference at the crossed bracket); conservative shortcut survives only as the disclosed fallback |
| Grandfathering "still needs the TAX_FMV_31JAN2018 feed" | **R27-3** | MEDIUM | **FIXED operationally** — pure Sec 112A(2) highest-quoted-price resolver + `scripts/build_tax_fmv_feed.py` (Yahoo .NS) + endpoint AUTO-LOAD of the built feed |
| Journal mark-age pin flake (stamp rounds into the future) | **R27-4** | LOW (CI flake) | **FIXED** — ms floor; age deterministically ≥ 0 |
| Regression locks for all of the above | **R27-5** | — | **DONE** — 14 new locks (`tests/test_round27_regressions.py`) |

**Final state: 270 Python files compile clean; full regression suite
414 passed / 0 failed / 1 skipped (opt-in live smoke) in ~135 s; every
corrected number hand-verified and locked.**

---

## 2. WHAT WAS FIXED

### R27-1 — Full-layer WFO replay (`math_engine/oos_walkforward.py`)

The R25/R26 re-selection replayed the prescreen scoring, the QUBO-CORE
selection and the production HRP weighting per cutoff, and DISCLOSED that the
live-data layers were not replayed. This round the live-data layers are
replayed to the extent point-in-time inputs exist:

* **QUBO penalty layers — replayed BY DEFAULT** (all computable on trailing
  data): `beta_cost` (trailing 63d beta vs benchmark, robust-z), `turnover_cost`
  (fold-local holdings = the previous cutoff's basket: new names pay
  `TURNOVER_PENALTY`, held names earn the production STCG retention bonus),
  `barra_conc_cost` (excess |z| over `FACTOR_EXPOSURE_THRESH` on the risk-factor
  family, when `FACTOR_CONC_PENALTY>0`), `Wasserstein DRO` cost
  (`WASSERSTEIN_DRO_EPSILON × max(0, downside_vol)`), and the production
  same-sector / unknown-sector OFF-DIAGONAL penalties when a sector map is
  supplied and `ENABLE_SECTOR_CAP` is on (mirrors `build_qubo`'s
  `_sec_pen`/`_unk_pen`). Terms enter the QUBO-core diagonal via the new
  `extra_diag` parameter of `_qubo_core_select` (R25 contract unchanged —
  default no-op).
* **ML-alpha injection — replayed when supplied**: `ml_alpha_by_cutoff` +
  `ml_dsr_by_cutoff` (keyed by cutoff date) replay the PRODUCTION Phase-9
  semantics exactly — z-blend `alpha = z(alpha)·(1−w) + z(ml)·w` with
  `w = ML_ALPHA_WEIGHT × clip((DSR − floor)/(1 − floor), 0, 1)`; DSR missing →
  injection REFUSED (the R20-8 honest-None gate). The reference series keeps
  the R24 no-ML semantics so the ML effect stays measurable.
* **Blackouts — replayed when supplied**: `blackouts_by_symbol` (historical
  earnings / F&O-ban / corporate-action calendar) drops candidates with an
  event within ±`blackout_window_days` of the cutoff — mirroring
  `apply_earnings_blackout`'s ±days semantics. The live NSE/yfinance feeds are
  now-only and cannot be replayed; the calendar must be caller-supplied.
* **Weighting stack above HRP — replayed per the cfg opt-in flags**:
  `_weighting_stack_replay` runs the PRODUCTION `black_litterman_weights` /
  `calculate_kelly_weights` / `compute_mdp_weights` /
  `optimizer_risk.apply_dro_cvar_constraint` in the live dispatch order
  (BL → Kelly → MDP → DRO-CVaR), lazy-imported, weight bounds re-enforced
  after every override; import/shape failures skip the layer AND disclose it.
* **Per-run honesty**: every response now carries `replay_scope` — a
  layer-by-layer {replayed: source | not-replayed: reason} map — and the
  `method_disclosure` is built per run (base text + "Round-27 per-run replay
  scope: …"), not a static caveat. Still NOT replayed and disclosed: the
  regime tilt of the alpha composite (no point-in-time regime state), CMF
  (needs intraday High/Low), and any layer whose input was not supplied.
* **Sweep wiring** (`optimizer.py`): the call site now passes the run's sector
  map + `EARNINGS_BLACKOUT_DAYS`; the [WFO-ReSel] log line reports the
  replayed-layer summary.

Hand-verified: extra_diag flips the 2-of-3 QUBO argmin ({P,Q} → {Q,R}); the
same-sector penalty avoids the {P,Q} pair; DRO ε=100 removes the
fast-but-oscillating name that ε=0 selects; the ML z-blend formula reproduces
the hand-computed 0.61237 on a 3-name vector; the DSR gate refuses at DSR
None/0.05 and scales 0.30×(0.4/0.9)=0.1333 at DSR 0.5.

### R27-2 — Exact mixed-income marginal relief (`math_engine/tax_loss_harvesting.py`)

New optional input `non_cg_tax_inr` (the slab-rate tax on the caller's
non-capital-gains income, BEFORE surcharge/cess). When supplied together with
`total_taxable_income_inr`:

* the surcharge base now covers the non-CG slab tax at the **UNCAPPED**
  bracket rate (the Sec 2(11) 15% cap covers only Sec 111A/112/112A tax);
* marginal relief is **exact**: at the crossed surcharge threshold, the
  pro-rata reference (the engine's pinned pro-rata allocation convention)
  scales the CG and non-CG tax components by threshold/income, applies the
  LOWER-bracket surcharge rate at the threshold income (0 at the first
  threshold — surcharge starts only above it), CG portions capped at 15%, and
  caps the aggregate at reference + (income − threshold).

Hand-verified and locked (LTCG 50.5L, TI 50.5L, non-CG tax 0): tax_flat
615,625.00; gross surcharge 61,562.50; exact relief **17,657.80** vs the R26
conservative shortcut 11,562.50 — and with relief binding, tax + net surcharge
sits exactly at the statutory cap 659,529.70. Second vector (STCG 50L, TI 60L,
non-CG tax 1L): surcharge 110,000.00 (vs 100,000 without the input), total tax
1,154,400.00, no relief binding. Without `non_cg_tax_inr` the R26 behavior is
byte-identical (400 pre-existing tests unchanged); the conservative fallback
text now names the exact-relief upgrade path. Endpoint wiring:
`/api/tax_optimizer?non_cg_tax=…`, payload keys `non_cg_tax_inr` /
`non_cg_tax_supplied` / `marginal_relief_cap_reference_inr`.

### R27-3 — TAX_FMV_31JAN2018: buildable + auto-loaded

* `core/realized_gains_ledger.py::resolve_fmv_31jan2018` — PURE resolver for
  the statute's valuation input (highest quoted price on 31-Jan-2018): exact
  date row, else nearest trading day on-or-before within `max_lookback_days`
  (weekends/holidays), never a post-valuation date, never a fabricated value.
* `scripts/build_tax_fmv_feed.py` — one-time best-effort builder (Yahoo .NS
  daily High around 31-Jan-2018; NSE remains 403-blocked in this environment,
  Yahoo is the verified working source since R25). Writes
  `qa_db/tax_fmv_31jan2018.json` ({ticker: fmv}) + a `.meta.json` with
  per-ticker as-of date and the unresolved list (nothing invented for them);
  `--selfcheck` runs the offline resolver vectors.
* `web_dashboard/app.py` — the tax endpoint AUTO-LOADS the built file when the
  cfg does not carry `TAX_FMV_31JAN2018`; the payload discloses
  `fmv_feed_source` ("cfg …" / "qa_db/tax_fmv_31jan2018.json (auto-loaded…)" /
  absent). The grandfathering integration is operational end-to-end.

### R27-4 — Mark-stamp floor (`core/trade_journal.py`)

`last_mark_ts` is floored to millisecond precision instead of rounded — a mark
timestamp can never precede a later now-read. The R26-3b pin's `0.0 ≤ age_h`
assertion is now deterministic (25× repeated now-reads ≥ stamp, locked).

### R27-5 — Regression locks

`tests/test_round27_regressions.py` — 14 locks: mark-stamp floor (+pattern),
extra_diag argmin flip, sector off-diagonal penalties, blackout replay at one
cutoff (fold payload + replay_scope + disclosure), ML gate/blend semantics
(unit + integration), DRO penalty flip, replay_scope + dynamic disclosure
(default + degenerate paths), weighting-stack replay-or-disclose + weight
normalization, both tax vectors + payload keys, app/engine/builder pattern
locks, sweep wiring patterns, and the R27 build-marker lineage.

---

## 3. VERIFICATION

* `python -m pytest -q`: **414 passed / 0 failed / 1 skipped** (opt-in live NSE
  smoke) in ~135 s. Baseline discrepancy (the R26-3b flake) explained and
  closed by R27-4.
* All 270 Python files compile (`py_compile`) clean, including the new
  `scripts/build_tax_fmv_feed.py` (selfcheck: 5/5 resolver vectors PASS).
* Functional smoke: multi-fold replay with `TURNOVER_PENALTY=0.35` +
  `ENABLE_SECTOR_CAP` + sector map — fold 2 keeps 3/3 names (the production
  retention-bonus stickiness), penalties + sector off-diagonal disclosed in
  the fold payload and replay_scope.
* The R24/R25/R26 WFO lock corpus passes unchanged on first run after the
  edits (44/44) — the R25 `_qubo_core_select` contract is backward-compatible
  (new parameters are optional no-ops by default).

---

## 4. REMAINING RESIDUALS (standing, with class)

1. **GEX dealer positioning** — DATA-BLOCKED, unchanged: NSE publishes no
   per-trade direction; the (CallOI − PutOI) sign remains a disclosed proxy
   on every computed response.
2. **Beta factor feed** — LICENSE-BLOCKED, unchanged: the characteristic
   factor-model prior is the default; licensed Barra/Axioma remains the
   `BETA_FACTOR_FEED` integration point (ladder locked by R26-3d).
3. **Marks** — EXTERNAL, unchanged: Yahoo .NS/.BO best-effort with measured
   age disclosed (the stamp semantics are now flake-proof, R27-4); .BO feed
   lag is a source property.
4. **Per-cutoff ML predictions / historical blackout calendar for the SWEEP** —
   INPUT-GATED: the replay machinery exists (R27-1) but the live sweep cannot
   supply point-in-time ML scores (final-model scores are not point-in-time)
   or a historical earnings calendar (now-only feeds). Closing the last mile
   needs a walk-forward ML retraining pipeline and/or a historical
   earnings-calendar export — runtime×K and data work, disclosed per run.
5. **Tax mixed-tranche pro-rata allocation convention** — unchanged (pinned,
   disclosed); the exact mixed-income marginal relief (R27-2) removes the
   approximation wherever `total_taxable_income` + `non_cg_tax` are supplied.
6. **Carry-forward persistence** — per-instance JSON, per-vintage and
   double-count-safe (R26); multi-broker deployments should still reconcile
   against broker realized-P&L statements (process-level).
7. **FMV feed network pull** — the builder is ready; the one-time Yahoo .NS
   download must run from a network-enabled host (per-ticker failures are
   reported, never invented).
