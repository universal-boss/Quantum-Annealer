# BUGFIX REPORT — Round 28
# Quantum Annealer — The TAX_FMV_31JAN2018 Feed Goes Live: One-Time Pull Executed, Adjustment Audit, Anchor-Verified Restatement

*Prepared by: GLM (Super Z)*
*Date: 2026-09-12*
*Input reviewed: Round-27 workspace (build QA-R20-…-R27-SOVEREIGN-TIER-OMEGA) + the operator's standing residual registry at round-28 open (7 items, class-labeled)*
*Baseline for comparison: Round 27 (GLM) report — 414 passed / 0 failed / 1 skipped at hand-off*
*Build marker after this round: **QA-R20-R21-R22-R23-R24-R25-R26-R27-R28-SOVEREIGN-TIER-OMEGA***

---

## 0. SESSION NOTE — workspace present; A–D revert check executed for real

The continuation context had lost track of the workspace: it IS present at
`qa_workspace/Quantum Annealer` (uploaded at R22, maintained through R27).
This round the A–D revert checklist ran against the actual repo:

* **Byte-identical to the R27 deliverable zip** (271/271 .py files, sha256-level diff: 0 added, 0 missing, 0 changed — the R27 report's "270" was prose drift, not state drift).
* All 271 files compile clean pre-change; full suite **414 passed / 0 failed / 1 skipped** (the exact R27 hand-off state) — the R22–R27 fix chain (BS gamma, journal mark age, tax order/vintage, the R26-3d ladder, R27-1..5) is fully intact. **No reverts.**

---

## 1. SCOPE OF THIS ROUND

The operator's residual registry at round open: 7 standing items, all classed
— GEX (DATA-BLOCKED), beta feed (LICENSE-BLOCKED), marks (EXTERNAL),
per-cutoff ML/blackout inputs (INPUT-GATED), tax pro-rata convention
(PINNED), carry-forward (process-level), and **FMV feed network pull —
"the builder is ready; the one-time Yahoo .NS download must run from a
network-enabled host (per-ticker failures are reported, never invented)"**.

The last item was the only one with a blocking ingredient that could exist
on this seat (network). It was executed end-to-end, and executing it
surfaced a data-quality problem nobody had measured yet — which this round
also fixes, conservatively and with full disclosure.

| Item | ID | Severity | Status |
|---|---|---|---|
| FMV feed one-time pull (the residual #7) | **R28-1** | MEDIUM | **EXECUTED** — 564/792 resolved, 228 honestly missing, feed file live at the endpoint's auto-load path |
| Vendor back-adjustment + unreliable split metadata (discovered by executing the pull) | **R28-2** | HIGH (statutory data quality) | **MEASURED + MITIGATED** — anchor-verified restatement overlay; candidates disclosed-not-applied (conservative direction) |
| Activation verification (feed → grandfathering → endpoint payload) | **R28-3** | — | **DONE** — regression lock proves the live feed value drives Sec 112A(2) deemed cost end-to-end |
| Regression locks for all of the above | **R28-4** | — | **DONE** — 8 new locks (`tests/test_round28_regressions.py`) |

**Final state: 273 Python files compile clean; full suite 422 passed / 0
failed / 1 skipped (opt-in live smoke) in ~139 s.**

---

## 2. WHAT WAS DONE

### R28-1 — The one-time pull, executed (chunked, resumable, never-invent)

`scripts/build_tax_fmv_feed.py` (the pinned R27-3 builder) is UNTOUCHED. It
was driven by an external chunked orchestrator (this session's tooling)
over the workspace universe:

* **792 tickers** (combined_universe.csv, deduplicated) in chunks of 100, with a retry pass over every builder-reported missing ticker after backoff.
* **564 resolved / 228 missing.** The retry pass recovered zero — the missing set is dominated by **post-31-Jan-2018 IPOs** (HAL, IRCTC, SBICARD, NYKAA, LICI, JIOFIN, CAMS, DELHIVERY, TARSONS, INDIGOPNTS, …), i.e. names that by definition cannot carry pre-Feb-2018 acquisition lots. Two renamed tickers were retried under their legacy symbols (CARYSIL←ACRYSIL, POWERINDIA←ABBPPS/HITACHIENERGY) — the vendor holds no pre-rename history; recorded in `missing_notes`, no value invented.
* Output: `qa_db/tax_fmv_31jan2018.json` — exactly the file the
  `/api/tax_optimizer` endpoint AUTO-LOADS when the cfg lacks
  `TAX_FMV_31JAN2018` (the R27-3 path). The grandfathering integration is
  now **operational with real data**, not just buildable.

### R28-2 — The adjustment audit (what executing the pull uncovered)

The vendor (Yahoo .NS) back-adjusts historical bars for some post-2018
splits/bonuses: the raw RELIANCE High for 31-Jan-2018 came back as 440.94 —
half the as-traded price — and TCS/INFY/HDFCBANK similarly. A naive
"splits metadata × raw" restatement was then disproven by measurement:

* **HDFCBANK**: metadata lists TWO post-2018 events (2019-09-19 ×2 split, 2025-08-26 ×2 bonus). The 2025 bonus is REAL (web-confirmed, ex 26-Aug-2025) — but the bars prove it was **never applied to history** (2018 and 2019 bars are as-traded/2, not /4). Applying the metadata product (×4) would have overstated FMV to ₹2,013.52 against the real ~₹1,006.76 band — i.e. **UNDERSTATED tax**, the forbidden direction.
* **BRITANNIA**: the 2021 1:1 bonus (ex 2021-04-25, web-confirmed) is **absent from the vendor's split metadata entirely**; its raw value reconciles to no clean divisor of the real-world band — dropped from the verified set.
* **GLAXO / PIDILITIND / EMAMILTD / PERSISTENT / REDINGTON / AUBANK**: sample anchors that do not reconcile cleanly — all dropped (never guessed).

**Vendor conclusion (measured, not assumed): both the split metadata AND
the price restamping are unreliable, in both directions.** The continuity
test (price behavior across each ex-date) cannot distinguish "restamped"
from "phantom" — HDFCBANK-2025 is real-but-unapplied and continuous,
exactly like a restamped event.

**The restatement protocol (scripts/restate_fmv_feed.py, new):**

* **Only anchor-verified factors are applied**: a factor enters
  `VERIFIED_FACTORS` when the corporate action is web-verified AND
  `raw × factor` lands inside the real-world 31-Jan-2018 as-traded High
  band. Eight entries qualify: **RELIANCE, TCS, INFY, HDFCBANK, BPCL,
  TORNTPHARM, HCLTECH (all ×2) and ITC (raw, no post-2018 action)** —
  e.g. RELIANCE 440.94→881.88, TCS 1575.00→3150.00, HDFCBANK
  503.38→1006.76 (the phantom 2025 bonus EXCLUDED, documented in
  `excluded_events`).
* **Everything else ships RAW with its candidate factor disclosed but NOT
  applied** — 185 tickers carry post-2018 events (from the .splits sweep +
  per-event continuity classification, archived as
  `qa_db/tax_fmv_31jan2018.splits_evidence.json`). Error direction:
  under-restated FMV overstates tax (conservative, disclosed);
  over-restating would understate tax (never the default).
* **Idempotency**: the pristine pull is preserved as
  `qa_db/tax_fmv_31jan2018.raw.json`; the overlay always derives from the
  raw backup (`--rebaseline` refreshes it after a fresh pull).
* **Promotion path (documented in the meta)**: verify a candidate against
  the NSE/BSE 31-Jan-2018 record (the exchange's own bhavcopy — NSE is
  403-blocked from this environment since R23, and the third-party NSE
  closing-rate sheet mirrors are TCP-blocked / PDF-only from here), add it
  to `VERIFIED_FACTORS`, re-run.

### R28-3 — Activation locked end-to-end

`tests/test_round28_regressions.py::test_r28_3_feed_flows_through_grandfathering`
pushes a synthetic pre-Feb-2018 RELIANCE lot through
`RealizedGainsLedger.net_gains_by_category(fmv_31jan2018=<live feed>)` and
asserts the LIVE (restated) value drives the deemed cost
(`max(cost, min(FMV, sale))`) — and that the raw (pre-overlay) value would
have produced a HIGHER taxable LTCG, i.e. the restatement moves the
estimate toward the statutory value, never the reverse.

### R28-4 — Locks (8)

Pure restatement vectors (verified/unverified/factor-1/non-positive),
the **phantom-exclusion discipline** (the HDFCBANK vector: candidate ×4
disclosed, verified ×2 applied, ×4 explicitly rejected), verified-registry
content, overlay + pinned-builder pattern locks (the builder's contract
strings are now pinned against accidental future edits), the live feed
file contract (skip-if-absent), verified-anchor consistency (re-pulling
without re-running the overlay fails on purpose), the end-to-end
activation lock, and the R28 build-marker lineage.

---

## 3. VERIFICATION

* `python -m pytest -q`: **422 passed / 0 failed / 1 skipped** (opt-in live NSE smoke) in ~139 s — 414 pre-existing tests unchanged on first run after the edits (the pinned builder and the endpoint code are untouched; only additions).
* All 273 Python files compile clean (271 + the overlay + the test file).
* Overlay `--selfcheck`: 7/7 offline vectors PASS (including the
  phantom-exclusion and idempotency vectors).
* The feed/meta/evidence/raw files live in `qa_db/` and are covered by the
  r28_2a/2b/3 locks.

---

## 4. REMAINING RESIDUALS (standing, with class)

1. **FMV feed — CLOSED as executed**, with two disclosed sub-items:
   (a) **185 candidate factors disclosed-not-applied** — the promotion
   worklist is `qa_db/tax_fmv_31jan2018.splits_evidence.json`; closing them
   needs the NSE/BSE 31-Jan-2018 record (DATA-BLOCKED from this
   environment: NSE archives 403, third-party sheet mirrors TCP-blocked /
   PDF-only — page_reader reaches them but cannot parse PDF binaries);
   (b) 228 missing tickers are post-2018 IPOs/retired symbols — correct
   steady state (they cannot carry pre-Feb-2018 lots).
2. **GEX dealer positioning** — DATA-BLOCKED, unchanged: NSE publishes no
   per-trade direction; the (CallOI − PutOI) sign remains a disclosed proxy
   on every computed response.
3. **Beta factor feed** — LICENSE-BLOCKED, unchanged: characteristic
   factor-model prior default; licensed Barra/Axioma remains the
   `BETA_FACTOR_FEED` integration point (ladder locked by R26-3d).
4. **Marks** — EXTERNAL, unchanged: Yahoo .NS/.BO best-effort with measured
   age disclosed (flake-proof stamps R27-4); .BO feed lag is a source
   property (re-confirmed this round: the vendor's .BO series carries no
   2018 history for most names).
5. **Per-cutoff ML predictions / historical blackout calendar for the
   SWEEP** — INPUT-GATED, unchanged: the replay machinery (R27-1) exists;
   closing the last mile needs a walk-forward ML retraining pipeline
   and/or a historical earnings-calendar export (runtime×K and data work,
   disclosed per run).
6. **Tax mixed-tranche pro-rata allocation convention** — unchanged
   (pinned, disclosed); exact mixed-income marginal relief (R27-2) applies
   wherever `total_taxable_income + non_cg_tax` are supplied; surcharge
   precision at boundaries still wants the CA-computed
   `total_taxable_income_inr`.
7. **Carry-forward persistence** — per-instance JSON, per-vintage and
   double-count-safe (R26); multi-broker deployments should reconcile
   against broker realized-P&L statements (process-level).
