# BUGFIX REPORT — Round 29
# Quantum Annealer — The INPUT-GATED Closure Round: Historical Earnings Calendar Built & Wired, Walk-Forward ML Retraining Driver

*Prepared by: GLM (Super Z)*
*Date: 2026-09-12*
*Input reviewed: Round-28 workspace (build QA-R20-…-R28-SOVEREIGN-TIER-OMEGA) + the operator's standing residual registry at round-29 open (7 items, class-labeled — the §4 list below, verbatim)*
*Baseline for comparison: Round 28 (GLM) report — 422 passed / 0 failed / 1 skipped at hand-off*
*Build marker after this round: **QA-R20-R21-R22-R23-R24-R25-R26-R27-R28-R29-SOVEREIGN-TIER-OMEGA***

---

## 0. BASELINE — no reverts (A–D executed as CI, not conversation)

The full suite ran BEFORE any change: **422 passed / 0 failed / 1 skipped**
(137 s) — the exact R28 hand-off state. The R26-5 conversion of the A–D
revert checklist into executable CI pins means every green run re-proves
A (BS gamma), B (BSE journal mark age), C (tax set-off/vintage/exemption),
D1 (flake-proof stamps), D2 (carry-forward double-count guard). **No
reverts.**

The one residual whose blocker could plausibly have moved — the FMV
185-candidate worklist (DATA-BLOCKED) — was re-probed for real this round
(§2.1): the block is re-confirmed with NEW evidence (the Wayback Machine
route is also TCP-blocked; the saved `cm31JAN2018bhav.csv.zip` in the
session tooling is a 429 error body, not data).

---

## 1. SCOPE OF THIS ROUND

The operator's registry named seven standing items. Five are blocked by
classes that cannot move from this seat (data/license/external/input —
re-verified, §2.1). The sixth — **the SWEEP's per-cutoff ML predictions /
historical blackout calendar (INPUT-GATED)** — is the one whose blocking
ingredients (data + build work) CAN exist here. This round closed it to the
extent the environment allows, honestly split into what was EXECUTED and
what was BUILT:

| Item | ID | Severity | Status |
|---|---|---|---|
| Historical earnings-calendar export (the "data work" half of the INPUT-GATED residual) | **R29-1** | MEDIUM | **EXECUTED** — 672/792 tickers with events, 12,134 events, coverage 84.85%, per-ticker failures reported never invented |
| Sweep auto-load of the calendar (blackout replay goes point-in-time-correct) | **R29-2** | MEDIUM | **DONE** — skip-if-absent contract (FMV-feed precedent), coverage disclosed per run, 9 real name-blocks applied in the live E2E |
| Walk-forward ML retraining driver (the "runtime×K" half) | **R29-3** | HIGH | **BUILT + LOCKED + LIVE-VERIFIED** — per-cutoff ridge refit, purge+embargo, production DSR; the point-in-time immutability lock proves zero leakage |
| Cutoff-grid single source of truth + key-convention hardening + opt-in wiring | **R29-4** | — | **DONE** — `reselect_cutoff_positions` shared by replay and driver; ML lookup accepts both key conventions; `WFO_ML_REPLAY_RETRAIN` default OFF |
| Regression locks | **R29-5** | — | **DONE** — 14 new locks (`tests/test_round29_regressions.py`) |

**Final state: 276 Python files compile clean; full suite 436 passed / 0
failed / 1 skipped (opt-in live smoke) in ~146 s.**

---

## 2. WHAT WAS DONE

### 2.0 The standing classes, re-verified (nothing silently assumed)

Egress matrix measured this round from this seat: **Yahoo endpoints
reachable** (the earnings endpoint answered; the chart endpoint returned a
transient 429 that cleared); **web.archive.org, archive.org, and
sajagonline.com all TCP-timeout** (DNS resolves, connections never open);
the third-party NSE closing-rate sheet mirrors remain PDF-only through the
reader service (the sajag PDF parses metadata, not body). The
`cm31JAN2018bhav.csv.zip` left in the session tooling is a saved **429
"Too Many Requests" body**, not a bhavcopy. Consequences, by class:

* **FMV (a) 185 candidate factors — DATA-BLOCKED, re-confirmed with new
  evidence**: the exchange record needs the NSE/BSE 31-Jan-2018 file; NSE
  403s, Wayback/sajag/finlib are TCP-blocked or bodyless from here. The
  R28 promotion protocol (add to `VERIFIED_FACTORS`, re-run the overlay)
  still closes it the moment the record is delivered — from a
  network-open host or as an upload.
* **GEX** — DATA-BLOCKED (structural: NSE publishes no per-trade
  direction). Unchanged; the (CallOI − PutOI) proxy stays disclosed on
  every computed response.
* **Beta feed** — LICENSE-BLOCKED. Unchanged; `BETA_FACTOR_FEED` ladder
  per R26-3d.
* **Marks** — EXTERNAL. Unchanged; best-effort with measured age,
  flake-proof stamps (R27-4), .BO lag a source property.
* **Tax / carry-forward** — input-gated / process-level. Unchanged (§4).

### 2.1 R29-1 — the historical earnings calendar, EXECUTED

`scripts/build_earnings_calendar.py` (new, pinned-builder pattern —
selfcheck 9/9 offline, resumable, time-budgeted, atomic writes):

* **Source**: the vendor's HISTORICAL quarterly earnings dates
  (`.earnings_dates`) — a dated historical record, NOT the now-only
  "next earnings" feed that made the live blackout unreplayable. America/
  New_York timestamps converted to **IST calendar dates** (convention
  disclosed in the artifact meta; the ±5-day window absorbs the
  same-day/next-trading-day reaction ambiguity).
* **Pull**: 792 tickers (combined_universe.csv) in ten bounded foreground
  passes with checkpoint/resume. **672 with events (84.85%), 12,134
  events spanning 2005-04-20 → 2026-12-02, 119 resolved-empty, 1 failed
  (HINDALCO.NS — the vendor frame lacked the expected column; recorded,
  never guessed).** Cadence spot-checks match reality (RELIANCE Jan/Apr/
  Jul/Oct, TCS mid-quarter-month, ITC quarter-ends).
* **Integrity bugs found and fixed while executing** (the R28 discipline —
  running the thing is how you find them): a re-invocation after COMPLETE
  restarted from scratch and **clobbered the completed artifact with a
  throttled partial**; an empty vendor frame is also the throttle
  signature, not only "no data". Fixes: idempotent re-invocation guard
  (complete artifact + no `--rebaseline` → no-op), **atomic promotion**
  (partials write only to a `.partial.json` sidecar; only a completed run
  may write the final path), empty re-verification with backoff, and a
  prior-events guard (a blank re-fetch can never discard verified
  events). All locked by the R29 tests.
* **Output**: `qa_db/earnings_calendar_history.json` — exactly the shape
  the sweep auto-loads.

### 2.2 R29-2 — the sweep wiring (blackout replay goes live)

At the WFO call site (`optimizer.py`): the calendar auto-loads
(skip-if-absent — the FMV-feed contract), restricts to the replay pool's
symbols, and passes `blackouts_by_symbol` into the R27-1 replay. The
per-run payload gains `blackout_calendar` (source, pool coverage %, events
available, convention) and a `[WFO-ReSel]` log line. No file → the
previous disclosed not-replayed steady state, unchanged. The replay's own
`replay_scope.blackouts` flips to REPLAYED automatically (R27-1 design:
dynamic disclosure, no static caveat to update).

### 2.3 R29-3 — the walk-forward ML retraining driver

`ml_alpha/walkforward_replay_scores.py` (new): at each cutoff t —
trailing-slice-only factor computation (backward-looking functions on data
≤ t — point-in-time by construction), **production** cross-sectional
winsorize + z-score (`preprocess_factors`), rebalance-grid training rows
with **purge + embargo** (label window and an embargo buffer must close
strictly before the cutoff), **production** `AlphaEnsemble` ridge refit,
prediction at the cutoff standardized exactly like `AlphaEngine.predict`,
and a **per-cutoff DSR** from an internal sequential CV (top-minus-bottom
quintile spread, R8-H7 overlap-adjusted effective sample size, R13-ML-5
trial count, degenerate-stat guards, NaN→0 refusal guard).

**The leakage lock is the centerpiece**: `test_r29_3a` clobbers every
price/volume value AFTER the cutoff (×7 + 555) and asserts the cutoff's
scores are **bit-identical** — the trailing-slice + purge discipline
proved, not claimed. The fidelity disclosure (provenance +
`method_disclosure`): a core-factor ridge refit; the production engine's
alt-data factors (NSE-blocked, now-only), triple-barrier labeling,
collinearity/IC selection, Optuna, CPCV and the TFT blend are NOT replayed
per cutoff — the scores are point-in-time predictions of a SIMPLER model,
disclosed per run.

**Live-verified end-to-end** on a real 15-name frame (500 trading days,
downloaded this round): all 4 cutoffs scored (345→1185 training rows);
the production DSR gate behaved exactly as designed — fold weights
**[0.024, 0.174]** with the two low-edge cutoffs (DSR 0.067 / 0.075 <
floor 0.10) **REFUSED at weight 0**; blackouts replayed from the real
calendar (9 name-blocks); QUBO penalty layers replayed.

### 2.4 R29-4 — drift-proofing and the opt-in

* `reselect_cutoff_positions()` extracted from the replay's inline grid —
  **single source of truth**; the sweep-side driver calls the SAME helper,
  so retrained cutoffs can never drift from the replay's (behavior
  identity locked by `test_r29_4a` against the actual fold dates).
* The ML lookup now accepts **both key conventions** (`str(Timestamp)`,
  the R27 contract, and `str(date)`, the driver's readable form) — the
  mismatch found in the live E2E (scores supplied but never injected) is
  now structurally impossible.
* `WFO_ML_REPLAY_RETRAIN` (default **False**): the runtime×K retraining
  path is opt-in; the default sweep behavior and its disclosure are
  unchanged. When on, provenance + runtime note attach to the payload.

---

## 3. VERIFICATION

* Full suite: **436 passed / 0 failed / 1 skipped** in ~146 s (422
  pre-existing unchanged + 14 new R29 locks; the R24/R25/R27 replay locks
  were additionally run standalone after the grid refactor — 44/44 before
  the full suite).
* All **276** Python files compile clean (273 + builder + driver + tests).
* Builder `--selfcheck`: 9/9 offline vectors (ET→IST same-day and
  next-day, naive=UTC, dedupe+sort, empty→none, the exhaustive
  honest-coverage meta split, artifact contract, loader normalization).
* The real artifact: meta.completed, coverage 84.85%, honest failure
  ledger, sorted/deduped ISO events (locked by `test_r29_1b`).
* Live E2E (session tooling, real prices + real calendar + retrained
  scores → replay): blackouts REPLAYED, ML injection gated per cutoff,
  DSR-refusing cutoffs at weight 0.

---

## 4. REMAINING RESIDUALS (standing, with class)

1. **FMV feed — CLOSED as executed** (R28), with sub-item (a) **185
   candidate factors disclosed-not-applied — DATA-BLOCKED, re-confirmed
   with new evidence this round** (Wayback + archive.org + sajag all
   TCP-timeout from this environment; the saved bhavcopy zip is a 429
   body; finlib's captured HTML carries no table). Promotion worklist
   `qa_db/tax_fmv_31jan2018.splits_evidence.json` + the R28 overlay
   protocol close it the moment the NSE/BSE 31-Jan-2018 record is
   delivered (network-open host or upload). Sub-item (b) 228 missing =
   post-2018 IPOs/retired — correct steady state.
2. **GEX dealer positioning** — DATA-BLOCKED (structural), unchanged: no
   per-trade direction exists to buy; (CallOI − PutOI) sign stays a
   disclosed proxy on every computed response.
3. **Beta factor feed** — LICENSE-BLOCKED, unchanged: characteristic
   factor-model prior default; licensed Barra/Axioma remains the
   `BETA_FACTOR_FEED` integration point (ladder locked by R26-3d).
4. **Marks** — EXTERNAL, unchanged: Yahoo .NS/.BO best-effort with
   measured age disclosed (flake-proof stamps R27-4); .BO feed lag is a
   source property.
5. **Per-cutoff ML / blackout calendar for the SWEEP** — **substantially
   closed this round**: (a) the historical earnings calendar is BUILT,
   EXECUTED, and AUTO-LOADED — the blackout replay now runs
   point-in-time-correct per cutoff (pool coverage disclosed per run; 119
   vendor-empty names + 1 failure remain honestly uncovered); (b) the
   walk-forward ML retraining pipeline EXISTS and is locked + live-verified
   — `WFO_ML_REPLAY_RETRAIN` (opt-in, runtime×K, default off). Remaining:
   the fidelity gap to the full production engine (alt-data factors /
   triple-barrier / Optuna / CPCV not replayed per cutoff — disclosed in
   `ml_replay_provenance`), and the operator's decision to run a live
   sweep with the opt-in ON over the full universe.
6. **Tax mixed-tranche pro-rata convention** — unchanged (pinned,
   disclosed); exact mixed-income marginal relief (R27-2) applies wherever
   `total_taxable_income + non_cg_tax` are supplied; surcharge precision
   at boundaries still wants the CA-computed `total_taxable_income_inr`.
7. **Carry-forward persistence** — per-instance JSON, per-vintage,
   double-count-safe (R26); multi-broker deployments should reconcile
   against broker realized-P&L statements (process-level).
