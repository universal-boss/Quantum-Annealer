# BUGFIX REPORT — ROUND 31
## The FMV-(a) DATA-BLOCKED residual: CLOSED. The exchange record was delivered and the promotion executed.

**Build marker:** `QA-R20-R21-R22-R23-R24-R25-R26-R27-R28-R29-R31-SOVEREIGN-TIER-OMEGA`
**Verification:** 277 files compile clean; FULL suite **446 passed / 0 failed / 1 skipped** (opt-in live NSE) in ~380 s; overlay `--selfcheck` 12/12.

---

## 1. What was standing at the start of this round

The R30 residual registry carried the FMV feed as `CLOSED as executed (R28)` with sub-item (a): **185 candidate split factors disclosed-not-applied — DATA-BLOCKED**. Every direct route to the NSE/BSE 31-Jan-2018 record had been measured blocked from this environment: NSE archives 403/429, Wayback + archive.org + sajagonline TCP-timeout, the saved bhavcopy zip a 429 body, finlib's page tableless (R29 re-confirmed with new negative evidence). The promotion worklist `qa_db/tax_fmv_31jan2018.splits_evidence.json` + the R28 overlay protocol were to close "the moment the NSE/BSE 31-Jan-2018 record is delivered".

## 2. The record was delivered (R31-1)

The unblocking move was a **relay**: `r.jina.ai` server-side PDF text extraction is reachable from this environment and fetches from Jina's own egress, bypassing the per-host blocks. The sajag secondary capture — the full 13-column NSE closing-rate bhavcopy print for 31-Jan-2018, published Apr 2022 — came back as 173 KB of text and was re-parsed locally:

* token-stream parse of the OHLC block (handles the PDF glue defect where a prevclose digit fuses with the next symbol, e.g. `…5.95 6ANIKINDS…`), dictionary-resolved;
* the ISIN/qty/val/trades tail block zipped **1,870/1,870 rows 1:1** with the OHLC block, alignment verified by the **avg-price-inside-OHLC-band check on every row — 0 violations**;
* **1,717 equity rows** (EQ 1,370 / BE 253 / SM 78 / BZ 16) + 153 debt/WDM rows (out of FMV scope, disclosed); every equity row ISIN-tagged (INE equities, INF fund units, IN9 special classes);
* independent date confirmation: the `TIMESTAMP` column carries `31-JAN-2018` on all 1,870 rows;
* cross-validated against fresh live Yahoo .NS bars: TCS/INFY/BPCL/TORNTPHARM/HCLTECH ratios exactly 2.0000 across O/H/L/C/PC; the record is genuine.

New file: `qa_db/tax_fmv_31jan2018.record.json`.

## 3. The promotion protocol, executed (R31-2)

Per the R28 overlay protocol's own promotion path — *verify a candidate against the record, then re-run* — with one generalization that the record itself forced: divisors in this vendor's history are not always clean split products, so the whitelist approach was replaced by a **three-field uniformity test**:

* every feed ticker joined to the record (direct 499 / ISIN-rename 49 / symbol-change 9 / 4 manually-verified renames);
* the vendor divisor measured across **three independent fields** (record High ÷ vendor High, record Close ÷ vendor Close, record PrevClose ÷ vendor 30-Jan Close; fresh live Yahoo re-fetch, 564/564, **0 consistency mismatches** vs the R28 raw pull);
* a **uniform** divisor (spread ≤ 0.6%) proves the vendor series is a scaled version of the as-traded series — whatever the divisor's numeric form. The record High is then adopted directly as the FMV: it is the statutory "highest price" of Sec 112A(2), so this is **measurement, not invention**;
* non-uniform or record-uncovered tickers keep the raw vendor High, disclosed (the conservative direction, unchanged).

New file: `qa_db/tax_fmv_31jan2018.record_overlay.json` (the deterministic decision table). `scripts/restate_fmv_feed.py` gained the record-rebase layer (precedence: record overlay → legacy R28 factor layer → raw), fully backward-compatible, `--selfcheck` 12/12.

**Result: 559/564 feed tickers rebased to the exchange record. 217 feed values changed. 5 keep-raws. 0 failures.**

## 4. Two R28 anchor verdicts were CORRECTED by the record

The R28 "web-verified event + price-band reconciliation" had relied on remembered price bands. The record corrected two of its eight verdicts — both in the direction that had been UNDER-stating FMV (the conservative side, disclosed at the time, now fixed):

| Ticker | R28 verdict | Record truth |
|---|---|---|
| RELIANCE | ×2.0 → 881.88 | High **964.50**; compound divisor **2.18739** (uniform across O/H/L/C/PC) = 2023 Jio Financial demerger (~1.094) × 2024-10-28 1:1 bonus (×2) |
| HDFCBANK | ×2.0 → 1006.76 (2025 bonus believed never applied) | High **2013.50**; divisor **3.9998** — BOTH the 2019-09-19 1:2 split AND the 2025-08-26 1:1 bonus were back-applied to 2018 bars; the R28 exclusion claim was mistaken |

The other five ×2 anchors (TCS, INFY, BPCL, TORNTPHARM, HCLTECH) were confirmed exactly; ITC's raw was corrected by a uniform 1.0385 vendor scaling (record High 276.0 adopted). All corrections are documented in the overlay's `anchor_corrections` block and in the updated `VERIFIED_FACTORS` provenance strings (the legacy layer is retained as the record-uncovered fallback, per the repo's supersession precedent).

## 5. Exotic divisors the record resolved (previously "muddy-unpromoted")

The uniformity test settled the previously-muddy class by direct measurement: IEX ÷30.0, BSE ÷9.0, BAJFINANCE ÷10.0, BAJAJFINSV ÷9.9999, ADANIPOWER ÷5.0, CONCOR ÷2.5, VBL ÷16.87499 (1:1 bonus × FV split × …), CUPID ÷120.00139, PCBL ÷10.0 (renamed from PHILIPCARB), DOLPHIN ÷8 consolidation back-adjustment, AVANTIFEED ÷3.0, plus 130+ of the 185 candidates confirmed at their metadata factors.

**Manual-rename promotions (exact reconciliation):** PCBL←PHILIPCARB (×10.0), DOLPHIN←DOLPHINOFF (÷8), ORCHPHARMA←ORCHIDPHAR (×1.0), TECHNOE←TECHNO (×1.0).

## 6. Conservative keep-raws (5, all disclosed)

* **TATASTEEL** — 4.96% field-ratio spread (vendor/record disagreement not explained by a uniform divisor);
* **FCL** — 3.74% spread;
* **PATANJALI** (ex-Ruchi Soya) — suspended on 31-Jan-2018, no record row exists (correct);
* **POCL**, **SPLPETRO** — absent from the record (BSE-only or record-subset; disclosed).

## 7. The 228 missing: independently confirmed

0 of the 228 missing tickers matched the record by current ISIN; fuzzy symbol candidates were inspected and rejected as different companies. The record therefore **independently confirms** the R28 classification: post-31-Jan-2018 IPOs dominate; CARYSIL / POWERINDIA are BSE-only listings (a BSE record would be needed to cover them — remains the only open sub-path, disclosed). The 228 stay missing — correct steady state, now with independent evidence.

## 8. Regression locks

`tests/test_round31_regressions.py` (10 locks): record integrity (1,717 rows / ISIN format / OHLC discipline / 0 alignment violations); overlay contract (559 rebased / keep-raw set / anchor corrections); pure-function precedence (record overlay > legacy factor > raw; candidates still disclosed-not-applied; non-positive guard; idempotency); live feed vectors (all anchor values, promotions, keep-raws); meta audit blocks (record_restatement, 185 candidates still disclosed); grandfathering direction after the HDFCBANK correction (LTCG record ≤ LTCG R28-verdict ≤ LTCG raw); build-marker lineage.

`tests/test_round28_regressions.py` — `r28_2b` superseded in place (intent preserved: "the overlay is part of the pipeline", now verified against the record overlay); `r28_1b` / `r28_1c` carry supersession notes (the phantom-exclusion discipline remains correct pure-function behavior for record-uncovered fallback). R28-3's direction check passes unchanged.

## 9. Residuals after Round 31

* **FMV feed — CLOSED, no sub-items outstanding.** (a) the 185 candidates resolved by direct record measurement; the disclosure trail (splits evidence, meta) stays intact for audit. (b) 228 missing confirmed correct steady state.
* Sub-path, disclosed: **BSE-only listings** (CARYSIL, POWERINDIA) would close only with a BSE 31-Jan-2018 record (still egress-blocked; same relay trick would work if a BSE capture is located).
* **GEX dealer positioning — DATA-BLOCKED (structural), unchanged.** (CallOI − PutOI) sign stays a disclosed proxy on every computed response.
* **Beta factor feed — LICENSE-BLOCKED, unchanged.** Characteristic factor-model prior default; licensed Barra/Axioma remains the `BETA_FACTOR_FEED` integration point (ladder locked by R26-3d).
* **Marks — EXTERNAL, unchanged.** Yahoo .NS/.BO best-effort with measured age disclosed (flake-proof stamps R27-4); .BO feed lag is a source property.
* **SWEEP per-cutoff ML / blackout calendar — closed in R29/R30** (calendar built/executed/auto-loaded; `WFO_ML_REPLAY_RETRAIN` locked, opt-in, runtime×K, default off; fidelity gap disclosed in `ml_replay_provenance`; operator decision on the opt-in live sweep remains).
* **Tax — pro-rata convention pinned; exact mixed-income marginal relief (R27-2) applies where `total_taxable_income + non_cg_tax` are supplied; surcharge boundary precision still wants the CA-computed `total_taxable_income_inr`.**
* **Carry-forward — per-instance JSON, per-vintage, double-count-safe (R26); multi-broker deployments reconcile against broker realized-P&L statements (process-level).**

## 10. Deliverables

* `qa_db/tax_fmv_31jan2018.record.json` — the delivered exchange record (parsed, validated, ISIN-tagged)
* `qa_db/tax_fmv_31jan2018.record_overlay.json` — the deterministic R31 rebase decisions
* `qa_db/tax_fmv_31jan2018.json` / `.meta.json` — the rebased feed + full audit meta (endpoint auto-loads unchanged)
* `scripts/restate_fmv_feed.py` — the record-rebase overlay (R28 layer retained as fallback)
* `tests/test_round31_regressions.py` — 10 new locks; `test_round28_regressions.py` — supersessions in place
* Session tooling under `/home/z/my-project/scripts/` (probe matrix, relay fetch, token parser, ISIN zip, decision engine, live Yahoo re-fetch cache) — the pinned workspace builder untouched
