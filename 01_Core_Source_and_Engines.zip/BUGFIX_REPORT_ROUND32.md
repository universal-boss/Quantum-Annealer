# BUGFIX REPORT — Round 32

**Build marker:** `QA-R20-R21-R22-R23-R24-R25-R26-R27-R28-R29-R31-R32-SOVEREIGN-TIER-OMEGA`
**Scope:** the operator's standing residual list after Round 31 — the one
disclosed sub-path still open was the BSE-only listings
(CARYSIL, POWERINDIA): *"would close only with a BSE 31-Jan-2018 record
(still egress-blocked; same relay trick would work if a BSE capture is
located)."* This round the BSE record was located, delivered, validated, and
promoted — the sub-path is now CLOSED with no sub-items outstanding.

**Correction of record (honesty first):** the R32 intake response in this
session stated "no code, file paths, or repository access has been provided
in this session — all states are faithful transcription." That was wrong:
it echoed a stale continuation summary. The workspace
(`qa_workspace/Quantum Annealer`, R31 state) IS present in this session —
Rounds 21–31 were executed here — and the A–D revert checklist was therefore
EXECUTED for real this round (baseline marker check, compile gate, full
suite with the R26-5 CI pins): **no reverts** (details in §4).

---

## 1. THE BSE 31-JAN-2018 RECORD — DELIVERED (R32-1)

**Source:** finlib.in — *"Fair Market Value of stocks on 31 Jan 2018 for
LTCG"* (`https://finlib.in/fair-market-value-31-jan-2018/`), a
server-rendered WordPress table fetched **DIRECTLY** (no relay needed —
unlike the NSE side, this host is not egress-blocked from this environment).
The article HTML (571,658 bytes) carries ONE table with the exact columns
the FMV protocol needs:

```
ISIN | BSE Name | NSE Symbol | Applicable date | High Price on BSE | High Price on NSE | Fair market value
```

**3,527 rows** parsed (89 junk/header rows skipped): 1,826 BSE-only,
1,550 dual-listed, 151 NSE-only; 471 rows carry an earlier applicable date
(suspended names — the last-trading-date convention, disclosed in the table
itself). Stored as `qa_db/tax_fmv_31jan2018.record_bse.json`.

**Validation — five gates, all PASSED (parser: scripts/r32_parse_finlib.py):**

| Gate | Check | Result |
|------|-------|--------|
| G1 | NSE-High column joined to the R31 sajag NSE exchange record (ISIN/symbol) | **1,657 / 1,657 EXACT (100.00%)**, 0 mismatches |
| G2 | Published FMV == max(available Highs) — the statutory rule | **3,527 / 3,527** |
| G3 | The ACRYCIL row present, BSE-only, dated 31/01/18 | **present** (see §2) |
| G4 | ISIN ISO-6166 check-digits | **3,527 / 3,527 valid** |
| G5 | POWERINDIA / Hitachi rows | **0** (correct — see §3) |

G1 is the load-bearing gate: **two INDEPENDENT captures of the NSE
bhavcopy** (sajag PDF, delivered R31; finlib table, delivered R32) agree
exactly on 1,657 joined names — which is what makes the finlib **BSE**
column authoritative for the names the NSE record cannot cover.
Cross-exchange sanity also holds (e.g. ACC: BSE 1,739.95 vs NSE 1,737.90;
the FMV column takes the max, exactly the Sec 112A(2) "highest price").

**Independent corroboration of the target row:** scribd document 433201744
(*"Share Prices and FMV on Jan 31, 2018"*, relayed via r.jina.ai) lists
`ACRYCIL LTD. 31/1/2018 BSE 575.95` — same name, same date, same value,
separate capture.

**Channel notes (egress matrix, re-measured):** `www.bseindia.com` 403
(re-confirmed); `beta.bseindia.com` bhavcopy page — jina relay 401 (IP
reputation); sajag has **no** BSE counterpart PDF (`BSE_31-Jan-2018-Closing-
Rate.pdf` → 404, verified via relay); scribd 418110198 (a BSE-specific FMV
doc) — jina 401; finlib wp-json posts endpoint 401 but the **article page
and wp-json search endpoint are directly reachable** — that is the channel
that delivered the record.

## 2. THE PROMOTION — EXECUTED (R32-2)

`scripts/restate_fmv_feed.py` gained a fourth layer (precedence unchanged
for everything already in the feed):

- **`BSE_PROMOTIONS_VERIFIED`** — a registry that names WHICH feed-missing
  universe ticker maps to WHICH record row. It does NOT carry authority over
  values: `_load_bse_promotions()` re-reads the record file at load time,
  re-checks its validation gates (G1 rate ≥ 0.99 on ≥ 1,000 joined rows),
  and matches every registry entry against the row EXACTLY (ISIN, BSE name,
  FMV, no NSE symbol, date 31/01/18). Any disagreement → **fail closed** (no
  promotion, gates recorded in the meta audit). Nothing can be invented or
  overridden through this path.
- **`apply_restatement(..., bse_promotions=...)`** — promotions ADD
  feed-missing tickers at their record High. Never an override: tickers
  present in the raw pull stay under the R31 precedence chain
  (record overlay > legacy factor > raw).

**The promotion executed:**

> `CARYSIL.NS` → **575.95** — the BSE record High on 31-Jan-2018
> (`ACRYCIL LTD.`, ISIN **INE482D01016** — the 2018 pre-split security),
> i.e. the statutory Sec 112A(2) "highest price" — a measurement, not an
> invention.

Carysil Ltd was BSE-ONLY on the valuation date (no NSE symbol in the
record; the R28 Yahoo .NS pull therefore had nothing for it — this was
exactly the sub-path). The vendor's `CARYSIL.BO` series DOES hold 2018
bars but back-adjusted: **575.95 / 115.19 = 4.9996 ≈ 5.0000**, matching the
web-verified **1:5 sub-division (₹10 → ₹2 face value, record date
09-Jan-2019, ex 10-Jan-2019)** — the same event that allotted the current
ISIN INE482D01024. Divisor disclosed; record value adopted (identical
discipline to the 559 R31 rebases).

**Feed state:** 564 → **565 keys**; missing 228 → **227**
(`CARYSIL.NS` removed, tracked in `meta.bse_record_promoted_removed_from_missing`);
all 559 R31 record rebases, the 1 legacy-verified entry, the 185-candidate
disclosure trail, and the 5 conservative keep-raws are **bit-identical**
(locked). Pinned selfcheck extended to **18/18 PASS** (new vectors:
promotion-adds / raw-is-None / ISIN disclosed / no-override / idempotent).

## 3. POWERINDIA — RECLASSIFIED, NOT BLOCKED (R32-3)

The second name of the sub-path closes by classification, not capture:
**POWERINDIA = Hitachi Energy India Ltd** (formerly *ABB Power Products and
Systems India Ltd* — the ABB India power-grids demerger). Web-verified
listing: **NSE + BSE, 30 March 2020** (ABB press release, moneycontrol, the
SEBI public announcement, BSE listing notice); the vendor series agrees
(first bar 2020-03-30 on both `.NS` and `.BO`).

Therefore: a **post-valuation-date listing, dual-listed** — no 31-Jan-2018
quotation can exist for it, by construction (G5: 0 rows in the BSE record).
Its absence from the FMV feed is the **correct steady state** (same class
as the post-2018 IPOs), NOT a blocked BSE capture. The R28/R31
"BSE-only listing" classification was imprecise on two counts
(single-exchange + egress-blocked); corrected in `LEGACY_RETIRED`, the meta
`bse_record_restatement.powerindia_reclassification` block, and the missing
notes. Nothing to fetch, nothing to promote — the residual class is closed.

## 4. Verification

- **A–D revert check (executed for real):** workspace at the R31 build
  marker before changes; venv restored first (the documented session-wipe
  pattern — dimod/neal/cvxpy/yfinance/flask reinstalled); **278 py files
  parse + compile clean**; **FULL suite 458 passed / 0 failed / 1 skipped
  (opt-in live NSE) in ~140 s** — that is the R31 hand-off (446) + 12 new
  R32 locks, with every R26-5 A–D pin green: BS gamma, journal mark-age,
  tax set-off/vintage/exemption, R27-4 stamps, R26 carry-forward — all
  intact.
- **New locks:** `tests/test_round32_regressions.py` (12 locks): record
  integrity + all five gates (pinned 3,527 / 1,826 / 1,550 / 151 / 471;
  G1 1,657/1,657); the ACRYCIL row (ISIN/name/date/High/FMV pinned); the
  two-capture join **recomputed in-test** + 5 pinned per-name vectors + the
  keep-raw cross-check (TATASTEEL/FCL confirmed by the third capture;
  PATANJALI/POCL/SPLPETRO remain uncovered — R31 decisions stand); live
  feed promotion (565 = raw ∪ {CARYSIL.NS}; R31 values untouched); meta
  audit blocks (promoted flag, ISIN, missing 227, before 228, gates audit,
  POWERINDIA reclassification, R31 numbers intact, resolved == feed keys);
  pure promotion semantics (add-missing / no-override / idempotent);
  **loader fail-closed** (tampered value → row_mismatch; falsified G1 →
  gates fail; dropped row → row_missing — all → no promotion); pattern
  locks (registry, loader, record file, ISINs, divisor numbers, on
  comment-stripped code for the code symbols); selfcheck subprocess
  (18/18); divisor evidence (4.9996 uniform vs the 1:5 event, current
  ISIN pinned); **grandfathering activation through the real ledger**
  (pre-Feb-2018 CARYSIL lot: deemed cost = max(400, min(575.95, 1000)) =
  575.95 → LTCG 4,240.50, applied 1, adjustment −1,759.50, statutory
  direction, no-feed case stays un-adjusted and disclosed); build-marker
  lineage + endpoint wiring.
- **Supersessions in place** (the R23→R24 precedent, intent preserved):
  `test_r31_4a` — feed keys `raw ∪ {CARYSIL.NS}` (was: `== raw`), missing
  227 with CARYSIL out / POWERINDIA in (was: 228);
  `test_r31_4b` unchanged and green (559 rebased / 185 candidates ride
  along); `test_r28_2b` — promotions branch (raw None, feed ==
  restated) ahead of the factor-None invariant that only ever described
  PULLED tickers.
- **Endpoint:** the auto-loaded feed drives the grandfathering path
  unchanged (`qa_db/tax_fmv_31jan2018.json` → `/api/tax_optimizer`); the
  `fmv_feed_source` string now names the R28/R31/R32 overlay lineage.

## §4. Residuals (standing, with class — updated)

1. **FMV feed — CLOSED, NO SUB-ITEMS OUTSTANDING.** (a) the 185 candidates
   resolved by direct measurement (R31; disclosure trail intact);
   (b) 228 missing confirmed correct steady state (R31);
   sub-path: BSE-only listings — **CLOSED (R32)**: CARYSIL promoted from the
   delivered+validated BSE record (measurement, fail-closed, divisor
   disclosed); POWERINDIA reclassified post-valuation-date listing
   (2020-03-30, dual-listed — no record can exist). Remaining 227 missing
   are post-2018 IPOs / suspended / delisted — correct steady state.
2. **GEX dealer positioning — DATA-BLOCKED (structural), unchanged.**
   (CallOI − PutOI) sign stays a disclosed proxy on every computed response.
3. **Beta factor feed — LICENSE-BLOCKED, unchanged.** Characteristic
   factor-model prior default; licensed Barra/Axioma remains the
   `BETA_FACTOR_FEED` integration point (ladder locked by R26-3d).
4. **Marks — EXTERNAL, unchanged.** Yahoo .NS/.BO best-effort with measured
   age disclosed (flake-proof stamps R27-4); .BO feed lag is a source
   property.
5. **SWEEP per-cutoff ML / blackout calendar — closed (R29/R30), tail
   unchanged:** operator decision on the opt-in ON live sweep
   (`WFO_ML_REPLAY_RETRAIN`, default off, runtime×K) remains; fidelity gap
   disclosed in `ml_replay_provenance`.
6. **Tax — unchanged:** pro-rata convention pinned; exact mixed-income
   marginal relief (R27-2) applies where `total_taxable_income` +
   `non_cg_tax` are supplied; surcharge boundary precision still wants the
   CA-computed `total_taxable_income_inr`.
7. **Carry-forward — unchanged:** per-instance JSON, per-vintage,
   double-count-safe (R26); multi-broker deployments reconcile against
   broker realized-P&L statements (process-level).

**Deliverables:** `download/Quantum_Annealer_Round32_Corrected.zip` +
this report. Session tooling persisted under `/home/z/my-project/scripts/`
(`r32_probe_bse_sources.py`, `r32_parse_finlib.py`, probes + captures) —
the pinned workspace builder/overlay remains the single authority for the
feed.
