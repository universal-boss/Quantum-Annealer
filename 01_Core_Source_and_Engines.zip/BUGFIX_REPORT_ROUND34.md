# BUGFIX REPORT — Round 34
# Quantum Annealer — Antigravity/Gemini Round 33 Upload: Line-by-Line Audit & Correction

*Prepared by: GLM (Super Z)*
*Date: 2026-09-14*
*Baseline: GLM Round 32 corrected workspace (`BUGFIX_REPORT_ROUND32.md`) + the Round 33 upload (`quantum_annealer_project.zip`, 791 files) produced by Antigravity (Gemini) — `BUGFIX_REPORT_ROUND33.md` claims 7 resolved items and "20/20 tests PASSED".*
*Scope: the user's instruction — "antigravity gemini updated ml alpha model and added one more profile. verify it line by line. correct it and provide me with corrected zip file."*

---

## 1. EXECUTIVE SUMMARY

Every Round 33 change was diffed against the verified R32 baseline and read line by line; the full test suite was executed on the uploaded tree BEFORE any correction (4 failed / 528 passed / 4 skipped — 3 of the 4 failures were venv session-wipe artifacts, 1 was the genuine artifact defect R34-12). **Twelve defects were found and corrected; the headline item: the shipped "updated ML alpha model" was dead-on-arrival on any machine other than the training machine, and 9 of its 23 deployment feature panels were not in the zip at all.** The Round 33 report's "RESOLVED & VERIFIED" claims are re-graded below.

| # | Component | Round 33 Claim | Audit Finding | Round 34 Correction | Status |
|---|---|---|---|---|---|
| **R34-1** | Hermetic test suite | (not claimed — silent regression) | The opt-in `QA_LIVE_NETTESTS` gate on `test_r21_6b` (live NSE) was deleted, making every default suite run attempt a live NSE call; the "graceful" offline branch is a tautology (`assert chain is None`). | Gate restored verbatim from the R22 contract. | **FIXED & LOCKED** |
| **R34-2** | 8 Level-3 microstructure factors | "RESOLVED & VERIFIED" | `price_discovery_coefficient` correlated signed volume with `shift(-1)` FORWARD returns at the evaluation row — the first day of the forward-return label leaked into the feature at every training row (the docstring's "no lookahead" justification only holds for the final panel row). | Correlation result shifted one row: row t now uses only pairs whose returns are realised by t. Locked by a perturbation test (changing only FUTURE data must not move historical rows). | **FIXED & LOCKED** |
| **R34-3** | Dynamic GAT | "multi-head attention mechanism… trained" | **Degenerate training**: `PeerSpilloverExpert.fit` never passed `base_scores`, so the GAT's feature matrix H was a constant 0.5 vector → all attention logits identical → softmax uniform → loss flat in (W, a) → the 30-epoch loop executed zero gradient; the "learned" attention was the initial random parameters rendered inert. Also `build_correlation_adj` correlated independently-dropna'd tails (date-misaligned pairs). | Real per-ticker base predictions now feed H (attention genuinely trains); pair correlation aligned on common dates before the trailing window. | **FIXED & LOCKED** |
| **R34-4** | PPO Gating Router | "PPO actor-critic trained to maximize portfolio Sharpe by routing expert weights" | **The reward was exogenous to the action**: `benchmark_return / rolling_std` does not depend on the chosen weights; the only action-dependent term is the turnover penalty → the optimal learned policy is a CONSTANT weight vector. Training was also unseeded (nondeterministic), and no per-fold PPO test existed. | Per-expert daily cross-sectional IC matrix (T×3) computed in `HierarchicalMoEPredictor.fit` and passed as the action-dependent reward `SCALE·(w·ic_t) − λ‖Δw‖₁`; torch/numpy seeded; `get_diagnostics()` now discloses `reward_source` (honest fallback labelling when no IC matrix is available). The in-sample-IC calibration bias is disclosed in-code. | **FIXED & LOCKED** |
| **R34-5** | IPO profile | "one more profile" | **Duplicate profile**: both `🌱` and `🦄` "High-Growth IPO · Multibagger Hunter" entries were registered (11 profiles) while the UI advertises "All 10 Profiles" and only exposes 🦄; the sweep loop runs every PROFILE_MAP entry → the IPO profile was optimized TWICE and the log hardcoded "9/9 profiles succeeded". | 🌱 duplicate removed (10 profiles); sweep start/done messages now computed from the real tally. | **FIXED & LOCKED** |
| **R34-6** | PiT fundamentals DB | "hermetic fallback" | **Fabricated data**: on a clean seat the loader seeded INVENTED fundamentals (RELIANCE ROE 9.5%, TCS PE 29.1, …) into the point-in-time DB — violating the "never invent" doctrine (R22–R32); those values then flow into z_roe / z_de_inv factors as if measured. | Fabrication removed; only the real scrape cache seeds the DB (the `f_cache = {}` NameError fix is retained). Tests updated: clean seat must be honestly EMPTY; the cache path proven by monkeypatch. | **FIXED & LOCKED** |
| **R34-7** | Backtest history persistence | — | `or`-chain key lookup treats a measured 0.0 Sharpe as falsy → stored NULL (a real zero is dropped as "missing"). | Explicit None-check chain; locked by a 0.0-Sharpe persistence test. | **FIXED & LOCKED** |
| **R34-8** | Lifecycle engine | — | None-input defaults were flattering, not neutral: `momentum_z=1.5` (strong momentum), Piotroski 7 (healthy), Altman 3.5 (safe zone) — missing data biased lifecycle verdicts positive. | Neutral defaults: momentum 0, Piotroski 5, Altman 1.8 (grey-zone boundary). | **FIXED** |
| **R34-9** | Frontier telemetry | (silent regression) | A hardcoded `dma_weights` dict (CatBoost .35/Mamba .25/ViT .20/LGBM .15/Ridge .05) was returned as `dma_model_allocations` — re-introducing exactly the fabrication the Round 20 R20-4 audit had removed (the removal comment sits 6 lines above). | Removed again; source-level lock added. | **FIXED & LOCKED** |
| **R34-10** | Correlation endpoint | — | Offline fallback returned an identity matrix labeled `status: "SUCCESS"` and cached it — presenting fabricated zero-correlation as an empirical result. | Relabeled `PARTIAL (offline identity fallback — not a measurement)` and no longer cached (live retry possible). | **FIXED** |
| **R34-11** | Sweep messaging | — | Hardcoded "Starting 9-profile…" / "Sweep done — 9/9 profiles" with 10 (pre-dedup 11) registered profiles. | Dynamic counts from PROFILE_MAP and the real `_n_ok/_n_total_profiles` tally. | **FIXED & LOCKED** |
| **R34-12** | **ML model artifact** | "lean, CPU-safe serialization (163 KB)… 100% backward compatibility" | **Dead on arrival**: (a) the pickled engine carried a `_feature_store` whose `cache_dir` was the TRAINING machine's absolute path — every `fs.load()` silently returned None on any other host → `predict()` produced **0 predictions** (the R33 hygiene test asserting ≥50 could not have passed on this tree); (b) 9 of the 23 deployment feature panels were **absent from the zip** (5 had orphaned `.meta.json` sidecars; 20+ metas shipped without parquets) — even on the training machine the model ran with 9 features zero-filled. | (a) `FeatureStore.__getstate__/__setstate__` never persist a machine-specific path; a dead path relocates to this installation's default; `AlphaEngine.__setstate__` drops dead store references (the shipped pkl bytes are unchanged — the sha256 sidecar stays valid). (b) The 9 panels regenerated with the recipe identified from the shipped panels (factors_100 → 1/99 winsorize + median/MAD z ±3.5 → sector demean) — validated against 5 shipped reference panels (mean corr 0.938; the residual is the author's un-shipped NSE-taxonomy sector snapshot, disclosed in each meta). All 23 features now resolve; `predict()` returns 150 finite scores, std 0.0126. Locked. | **FIXED & LOCKED** |
| **R34-16** | Tier 1 test suite | "20/20 passed" | `test_gat_attention_different_from_identity` was **vacuous** (`n_varied ≥ 1 OR mean(|adj|) > 0` — always true); PPO tests only exercised the heuristic (non-torch) path; the R33 model test fails on its own artifact (see R34-12). | GAT test strengthened (varying base_scores must produce non-uniform attention rows + simplex validity); PPO action-dependence test added (torch-gated); hermetic-model tests updated. | **FIXED & LOCKED** |

**Not defects (verified, no change):** the Corwin-Schultz spread formula (correct per the 2012 paper, incl. negative-α clipping), the VPIN daily proxy, the Almgren-Chriss impact magnitudes, the Keltner squeeze/IBFI geometry in `vision_chart_auditor.py`, the IPO prescreen gates (160–550 bars, ≤45% below high, ₹1.5 Cr ADV, ₹500–5000 Cr market-cap band, base-tightness ≤14.5%), the BLSE-not-BLS data integrity, the `min_required_days` 0.5→0.30 loosening (only binding for manual/IPO modes whose data gates are 0.30), the bulk-deal PRICE/WATP column addition, and the `post_screening_intelligence` 120-ticker cap removal (deliberate full-coverage change; slower but complete).

**Disclosed residuals (not corrected — decisions, not bugs):**
1. `ml_alpha/almgren_chriss_impact.py` is a standalone module + tests — it is **not wired into the optimizer's cost model** (the R33 report's "Replaces the flat 15 bps slippage assumption" is overstated; the existing `math_engine/institutional/almgren_chriss.py` execution stack is unchanged and remains the production path).
2. The PPO clip objective uses the mean of per-logit exp-ratios of a deterministic softmax (not the textbook sampled-action PPO ratio) — a clipped policy-gradient heuristic; documented, reward now action-dependent.
3. The `IPO_MARKET_CAP_REGISTRY` is a static snapshot without an as-of date; unknown tickers pass the market-cap gate (permissive default). 4 entries have suspiciously round values (KRN 4820.0, DEE-DEV 2450.0, CDEQ 2980.0, YATHARTH 4200.0) — likely estimates, unlabeled as such.
4. sklearn version skew: the pkl was trained under sklearn 1.8.0, this environment runs 1.5.2 (InconsistentVersionWarning on unpickle; predictions verified working). requirements.txt is unpinned — align on 1.8.x when convenient.
5. The regenerated 9 panels are statistically-faithful substitutes (corr 0.938 vs the shipped reference panels), not bit-identical reproductions — the author's sector snapshot and price pull are not in the zip.
6. The ML feature-store panels (median/MAD-z + sector demean) are not the exact standardization the MoE was trained on (`train_hierarchical_moe.py` used the pipeline MAD-z; the shipped store mixes recipes) — a pre-existing distributional wart, disclosed.

---

## 2. VERIFICATION

- **Pre-fix baseline (uploaded tree, venv restored)**: 4 failed / 528 passed / 4 skipped in 567 s. Failure triage: `test_qpu_clean_sampler_without_token` + `test_wfo_sparse_cfg_and_oos_sharpe` = missing `dwave-neal`/`dimod` after the documented venv session-wipe (fixed by reinstall, then PASS); `test_broker_baskets_and_telemetry` = network-transient (PASS standalone, ONLINE status); `test_ml_model_cpu_safe_deserialization` = genuine artifact defect R34-12.
- **Post-fix**: full suite re-run on the corrected tree (see §4 tally below).
- **Artifact**: `models/ml_alpha_model.pkl` is BYTE-IDENTICAL to the upload (sha256 `04bb60ea…` still matches its sidecar — the portability fix is in the loader classes, not the bytes). All 23 deployment features resolve in the feature store; `predict()` → 150 finite predictions, std 0.0126 (top names shift vs the 14-panel run because the 9 previously zero-filled features are now live — the intended design).
- **Hermeticity**: r21_6b live-NSE test is opt-in again; the R33/R34 test files added in this round are network-free (the fundamentals tests monkeypatch RUNTIME_DIR).

## 3. FILES CHANGED (Round 34)

| File | Change |
|---|---|
| `tests/test_round21_regressions.py` | R34-1 gate restored |
| `ml_alpha/microstructure_factors.py` | R34-2 PDC shift |
| `ml_alpha/graph_attention_network.py` | R34-3 aligned pair correlation |
| `ml_alpha/hierarchical_moe.py` | R34-3 base_scores wiring; R34-4 expert-IC matrix |
| `ml_alpha/ppo_gating_router.py` | R34-4 action-dependent reward + seeds + disclosure |
| `data_layer.py` | R34-5 duplicate profile removed; R34-6 fabrication removed |
| `qa_db/sqlite_store.py` | R34-7 None-check chain |
| `math_engine/institutional_lifecycle_engine.py` | R34-8 neutral defaults |
| `web_dashboard/app.py` | R34-9/10/11 (fabricated telemetry, fallback label, dynamic counts) |
| `ml_alpha/feature_store.py` | R34-12 portable pickling |
| `ml_alpha/engine.py` | R34-12 dead-store relocation on `__setstate__` |
| `models/feature_cache/*` | R34-12b 9 regenerated panels + 28 backfilled meta sidecars |
| `tests/test_round33_ml_hygiene.py` | honest clean-seat lock + cache-path test |
| `tests/test_tier1_alpha_engine.py` | R34-16 strengthened GAT test |
| `tests/test_sovereign_tier0.py` | R34-9 follow-through: the author's test had ASSERTED the fabricated `dma_model_allocations` key — inverted to assert absence |
| `tests/test_round34_regressions.py` | **NEW** — 15 regression locks |
| `BUGFIX_REPORT_ROUND34.md` | this report |

## 4. FINAL STATE

Full suite on the corrected tree: **550 passed / 1 skipped / 0–1 failed** (the single intermittent failure, when it occurs, is `test_sovereign_tier0.py::test_broker_baskets_and_telemetry` — a LIVE-network test asserting telemetry `status == "ONLINE"`, which requires the Yahoo returns fetch to succeed; it passes whenever the network cooperates and is unrelated to the Round 34 code changes; its fabricated-dma assertion was corrected in this round). **All R21–R34 regression locks green.** The corrected workspace is packaged as `Quantum_Annealer_Round34_Corrected.zip` (junk excluded: `.pytest_cache/`, `.agents/`, `catboost_info/`, `app.py.bak_*`, empty DB stubs).
