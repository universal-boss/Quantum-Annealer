# BUGFIX REPORT — Round 35
# Quantum Annealer — 🦄 High-Growth IPO · Multibagger Hunter: Institutional Math & ML Upgrade — Completion, Verification & Delivery

*Prepared by: GLM (Super Z)*
*Date: 2026-09-14*
*Baseline: the Round 34 corrected tree (`BUGFIX_REPORT_ROUND34.md`) + the Round 35 in-progress changes left un-packaged when the previous session's context expired.*
*Scope: the operator's instruction — "can you improve 🦄 'High-Growth IPO · Multibagger Hunter' mathematics and ml model to make it almost level of like Citadel, Renaissance Technologies, Millennium, Two Sigma, and Qube."*

---

## 1. EXECUTIVE SUMMARY

Round 35 upgrades the 🦄 profile's **estimation and decision mathematics** to institutional systematic-equity practice (Citadel/Millennium-style pod discipline, Two Sigma-style stacked models, Qube-style execution realism), and completes the round the previous session left 90% finished: this session verified every R35 code path line by line, found and fixed **one genuine defect** (a stale Antigravity-era test asserting the pre-R34-6 fabricated-seeding behaviour — it failed on any clean machine and had only ever passed through machine-DB state pollution), applied two honesty-disclosure docstring corrections, and delivered the full verification + packaging the expired session could not.

**The honesty contract is unchanged and explicit: this is a technique-level alignment with institutional practice — deterministic, pure, fully disclosed functions with refusal semantics. It is NOT a claim of performance parity with any named firm; no performance numbers are asserted anywhere.**

| # | Component | What was delivered | Status |
|---|---|---|---|
| **R35-1** | Institutional math core | `math_engine/ipo_multibagger_math.py` (744 lines): deflated-IC shrinkage, triple-barrier labeling, purged+embargoed event panel, calibrated logistic meta-label gate, probability-calibrated ranking, fractional Kelly with error shrinkage, Almgren-Chriss QUBO turnover | **VERIFIED & LOCKED** (36 regression tests) |
| **R35-2** | ML surface actually wired | `z_neural_sde` (0.12) + `z_patch_tst` (0.08) + `z_base_tightness` (0.07) were **silently dropped** by the base_cols filter — 27% of the 🦄 advertised alpha surface contributed nothing; `z_vpin_toxicity` (0.08) was computed **AFTER** the alpha blend. All four now computed in `compute_signal_frame` **before** the blend; per-run **DEAD-WEIGHT DISCLOSURE** names every FACTOR_WEIGHTS key that cannot enter the composite | **VERIFIED & LOCKED** |
| **R35-3** | Prescreen single source of truth | `ipo_prescreen_score` / `ipo_gate_pass` extracted to the shared module; production (optimizer.py / utils.py) and tests call the SAME functions — drift is structurally impossible | **VERIFIED & LOCKED** |
| **R35-4** | Probability-calibrated ranking | Monotone logistic map (κ=0.35, disclosed 10% prior anchored at z=0) ⇒ selection ordering **identical**, every disclosed number is now a calibrated P(multibagger); the empirical base rate measured from the pool's own trailing triple-barrier outcomes logged per run | **VERIFIED & LOCKED** |
| **R35-5** | Triple-barrier meta-labeling gate | Runtime-trained calibrated logistic P(primary-is-right): median/MAD → L2 class-balanced logistic → time-ordered validation → Platt calibration; purged (label window + 5d embargo before as-of) by construction; **REFUSES** to gate below 60 events (identity + honest log — no fabricated probabilities); mean-1 multiplicative conviction clip [0.5, 2.0] — book-neutral by construction | **VERIFIED & LOCKED** |
| **R35-6** | Deflated-IC multiple-testing correction | Freshly measured factor IC-IRs shrunk toward zero by their own t-statistics (t = IC-IR·√n_windows; anchors exempt); opt-in `USE_DEFLATED_IC` (🦄 default-on) | **VERIFIED & LOCKED** |
| **R35-7** | Almgren-Chriss impact-aware turnover | AC square-root impact (η=0.142, γ=0.314; Q/ADV capped 20%, vol confined [0.5%, 15%]) in disclosed QUBO units added above the flat 0.18 statutory floor; mutually exclusive with `MARKET_IMPACT_IN_QUBO` (no double counting); degenerate inputs honestly fall back to the flat penalty | **VERIFIED & LOCKED** |
| **R35-8** | Stale-test defect (found THIS session) | `tests/test_log_fixes.py::test_fundamentals_pit_db_seeded_and_queried` asserted `count > 0` on ANY seat — the **pre-R34-6 fabricated-seeding behaviour**. It failed on this clean seat (honestly-empty table, 0 rows) and had only ever passed in the R34 session because earlier suite runs had pre-seeded the machine-level `~/.quantum_annealer_pro_v17/fundamentals_history.db`. Corrected hermetically (monkeypatched RUNTIME_DIR): clean seat ⇒ honestly EMPTY; real cache present ⇒ seeds; seeded PiT DB ⇒ `fetch_fundamentals` reads it. Same pattern as `test_round33_ml_hygiene.py` | **FIXED & VERIFIED** |
| **R35-9** | Disclosure accuracy (docstrings) | (a) `ipo_gate_pass` docstring claimed pivot default 12.0% while the bare-function default is 15.0 (the 🦄 profile pins 12.0) — docstring now states both. (b) `kelly_confidence_weights` claimed "shrunk by its training support" while the common-`prior_n` shrink factor is a constant that cancels under mean-1 normalisation — docstring now discloses this explicitly, and names `confidence_multiplier` as the production conviction channel. Zero behavioural change | **FIXED** |

**Not defects (verified this session, no change):** the AC impact block's dimensional-consistency guard history (Round 6 B-P3-11 fix preserved); the QUBO diagonal DELTA update after meta-label re-weighting (preserves every penalty term); the `MLModel alpha` DSR-floor injection gate (refuses below 0.95 — unchanged from R29); the purged/embargo boundary arithmetic in `build_meta_event_frame` (last trainable event = as_of − horizon − embargo; features strictly trailing); the conservative loss-first barrier ordering in `triple_barrier_label`.

**Disclosed residuals (decisions, not bugs):**
1. `kelly_confidence_weights` is a tested pure utility, **not production-wired** — the production conviction channel is `confidence_multiplier` via the MetaLabelGate (wiring both would double-apply conviction). The book-level weight stack (HRP / BL / Kelly / MDP above HRP) remains the position-size authority, per the build-marker contract.
2. `deflate_ic`'s null form (t = IC·√N when σ_IC unmeasurable) is a disclosed analytic fallback; the profile's production path measures σ_IC from the walk-forward IC series when available.
3. The R34-reported sklearn version skew (pkl trained under 1.8.0, environment runs 1.5.2) remains — predictions verified working; requirements.txt still unpinned.
4. The 2 skipped tests are opt-in gates (live-NSE / torch paths), not failures.
5. Technique-level alignment is not a performance claim; live edge measurement is the WFO/DSR machinery's job (R24–R29), which this round composes with rather than replaces.

---

## 2. VERIFICATION (this session, executed for real)

- **Compile gate**: 296 .py files ast-parsed, **0 failures** (scripts/r35_compile_gate.py).
- **Full suite** (chunked foreground orchestrator `scripts/r35_suite_chunks.py` — the background-process reaping pattern documented in R28 recurred and was handled the same way): **586 passed / 0 failed / 2 skipped** (~400 s total). Pre-fix state: 585/1/2 with the single failure being R35-8; after the hermetic test correction the flows chunk re-ran **44 passed / 0 failed**. This beats the R34 hand-off (550 passed / 1 skipped / 0–1 intermittent) and includes the 36 new R35 locks.
- **R35 core**: `tests/test_round35_regressions.py` — 36 locks, all green after every edit (defect map R35-A…R35-K: ML-surface wiring, dead-weight disclosure, deflated IC, triple barrier + purge/embargo, gate determinism/refusal/no-future-data, monotone probability map, Kelly mean-1, AC penalty, single-source locks, registry provenance, cfg keys + build-marker lineage).
- **Line-by-line audit of the integration points** (this session): optimizer.py prescreen branch (5340–5365), MetaLabelGate block (6103–6168), deflated-IC pass (771–799), AC turnover block (3549–3581), QUBO diagonal delta update (6177–6208), utils.py signal-frame factor columns + pre-blend microstructure z-scores (4400–4536), dead-weight disclosure (5120–5144), gate call site (3667–3689), data_layer.py 🦄 profile cfg (993–1085), registry provenance (722–795). All verified consistent with the module's honesty contract.
- **Hermeticity**: the R35 test file is network-free; the corrected `test_log_fixes.py` monkeypatches RUNTIME_DIR (no machine-state dependence); `r21_6b` live-NSE gate restored per R34-1 remains opt-in.

## 3. FILES CHANGED (Round 35 — this session's completion pass)

| File | Change |
|---|---|
| `math_engine/ipo_multibagger_math.py` | (Carried from the R35 session, verified this session) institutional math core; docstring honesty fixes R35-9a/9b |
| `tests/test_round35_regressions.py` | (Carried) 36 regression locks — verified green |
| `tests/test_log_fixes.py` | **R35-8**: hermetic rewrite of the fundamentals PiT test (clean-seat empty / cache-path seeds / PiT read-back) |
| `optimizer.py`, `utils.py`, `data_layer.py`, `math_engine/institutional_research_registry.py`, `web_dashboard/app.py` | (Carried from the R35 session, verified line-by-line this session) the wiring documented in R35-1…R35-7 |
| `BUGFIX_REPORT_ROUND35.md` | this report |
| `scripts/` (session tooling, outside the zip) | `r35_suite_chunks.py` (chunked suite orchestrator + tally), `r35_compile_gate.py` |

## 4. FINAL STATE

- Build marker: `QA-R20-R21-R22-R23-R24-R25-R26-R27-R28-R29-R31-R32-R33-R34-R35-SOVEREIGN-TIER-OMEGA` (web_dashboard/app.py).
- Full suite: **586 passed / 0 failed / 2 skipped**; 296 files compile clean; all R21–R35 regression locks green.
- The corrected workspace is packaged as **`Quantum_Annealer_Round35_Corrected.zip`** (junk excluded: `__pycache__/`, `.pytest_cache/`, `catboost_info/`, `.agents/`, `*.bak*`, empty DB stubs, `models/experiments/` scratch).
- The canonical working tree after this round is `/home/z/my-project/qa_workspace/Quantum Annealer` (synced to the R35 state — see worklog Task ID 11).
