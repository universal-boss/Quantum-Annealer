# Quantum Annealer — Round 38 Audit & Correction Report

**Date**: 2026-09-16
**Build Marker**: `QA-R20-R21-R22-R23-R24-R25-R26-R27-R28-R29-R31-R32-R33-R34-R35-R36-R37-R38-SOVEREIGN-TIER-OMEGA`
**Audited upload**: `Quantum_Annealer_GLM_Share.zip` (2026-09-16 02:16 — the newest of the two 16-Sep uploads; it carries newer versions of every R37 core file than `Quantum_Annealer_GLM_Complete.zip`)

---

## 1. The Question That Started This Round

> "i specifically asked for 1-2 year listed stocks in 🦄 High-Growth IPO · Multibagger Hunter. did you fix that?"

**Answer as of the upload: NO — and the R37 "fix" was worse than absent.** The BUGFIX_REPORT_ROUND37.md claimed *"Enforces the strict 1–2 year IPO listing age contract (365 to 730 calendar days, both bounds enforced)"*. The code did nothing of the sort.

## 2. What Was Actually Broken (line-by-line findings)

### 2.1 The prescreen gate was a silent NO-OP (math_engine/ipo_multibagger_math.py)
`ipo_gate_pass` referenced **`age_days` before assignment** — the line computing it (`age_days = (as_of - ld).days`) simply did not exist. Every ticker with a DSM listing date raised `NameError`, which the surrounding **bare `except: pass` swallowed**. Net effect: the entire DynamicSecurityMaster listing-age cross-check never rejected anything at the prescreen layer. The R37 report described a gate that was never executed.

### 2.2 Three hardcoded 1000-day ceilings (web_dashboard/app.py)
* `is_disqualified_ipo_stock()` accepted a `max_days=730` parameter and then **ignored it**, comparing `age > 1000` instead — every 731–1000-day-old stock passed.
* The same function let `age is None` (unmeasurable) **pass through**.
* A second display path (the target-builder around line 3335) used `age > 1000` with **no floor check at all** and the same None-passes hole.

### 2.3 The shipped universe contradicted even the broken gate (combined_universe.csv)
31 🦄 names, of which exactly **10** were in the 365–730-day window at the 2026-09-16 master state:
* **20 mature** (731–1,167 days): IDEAFORGE 1,167d · YATHARTH 1,136d · EMSLIMITED 1,091d · EPACK 960d · BLSE 953d · EXICOM 925d · PLATIND 925d · JGCHEM 917d · AWFIS 839d · KRONOX 828d · DEEDEV 812d · STANLEY 810d · BANSALWIRE 798d · AVANTEL 777d · AKUMS 771d · CEIGALL 769d · UNIECOM 764d · INTERARCH 751d · ORIENTTECH 749d · GALAPREC 737d
* **1 unseasoned** (351 days): ARSSBL

Three of those (EMSLIMITED 1,091d, IDEAFORGE 1,167d, YATHARTH 1,136d) exceeded even the R37 code's own 1000-day ceiling — proof the CSV was hand-curated rather than produced by the gate.

### 2.4 The R37 clean_sym NameError (web_dashboard/app.py, get_candidate_universe)
In the combined_universe.csv fallback, `clean_sym` was assigned only inside `if is_ipo:` and then referenced unconditionally for dedup and price resolution. For **every non-IPO profile** this either raised NameError (swallowed into the error log, killing the fallback) or, when an earlier block had run, **price-resolved and deduplicated against the previous row's symbol** — stale-symbol contamination. This is the class of defect behind "check log. run failed".

### 2.5 The fake ₹100.0 price was only half-removed
`get_candidate_universe`'s fallback still emitted `"Current Price (₹)": ... else 100.0` for **non-IPO profiles** — R37 had only fixed the is_ipo branch.

### 2.6 The R37 upload silently deleted the feature cache
`models/feature_cache/` shipped **EMPTY** in both 16-Sep zips (the R36-verified 157-file cache — 81 panels + sidecars — was dropped), which broke `test_r34_7_shipped_model_predicts_after_move`, `test_r34_8_all_model_features_present_in_store`, both `test_r34_12b_*` locks and `test_r36_6_feature_cache_provenance_sidecars_complete` (0 predictions / "feature cache must ship"). The R37 report's "91 passed" run could not have included this state.

### 2.7 Build-marker inconsistency
The R37 report existed, but `APP_BUILD_ID` still read `...R36-SOVEREIGN-TIER-OMEGA`.

## 3. The Round 38 Engineering

### A. The 1–2 year contract is now real code (the user's requirement, verbatim)
* `ipo_gate_pass` **computes** the listing age from the official NSE master and enforces **both bounds**: `IPO_MIN_CALENDAR_DAYS=365` (seasoning floor) and `IPO_MAX_CALENDAR_DAYS=730` (mature ceiling). Inclusive bounds; no exceptions; **no 1000-day escape anywhere**.
* The keys are **live config** in the 🦄 profile (R36-4 had removed them as dead config with no consumer — the root cause of this whole saga; R38 re-adds them *with* the gate as their consumer). Explicit cfg still overrides — verified by lock.
* **Fail-closed everywhere**: phantom/delisted tickers, and active tickers whose listing date is missing or unparseable, are rejected with disclosed reasons. The bare `except: pass` is gone (locked by test).
* New `as_of_date` parameter makes the gate deterministic for the regression locks (the honesty contract in the module header now discloses the gate's clock/network use precisely).
* Trading-bar gates (160/550) are unchanged data-sufficiency proxies — the R36-4 source-string locks still pass.

### B. Single source of truth for eligibility
`DynamicSecurityMaster.is_recent_ipo()` (defaults 365/730) is now the only eligibility authority. All three app.py ad-hoc age checks delegate to it and fail closed on unmeasurable age. The dead `allow_extended_window` hatch (up to 1000 days, zero production callers) is **deleted** — its absence is locked.

### C. DSM self-healing hardening
* `resolved_cache` is **cleared on every successful master resync** — resolutions derived from a stale master can no longer outlive the exchange record.
* Module-level `datetime` import (the `Optional[datetime.date]` annotations previously referenced an unimported name, saved only by lazy annotation).

### D. The clean_sym / ₹100 fixes
* `clean_sym` is assigned **unconditionally per row** before the is_ipo branch (locked by test).
* No verified price → **no row, for any profile**. The `else 100.0` is gone from that path entirely.

### E. Artifacts regenerated THROUGH the corrected gate (not hand-tuned)
Script: `scripts/r38_regenerate_artifacts.py` (this repo's scripts tree). Every 🦄 row in every shipped artifact was re-evaluated against the same DSM the gate uses, as-of 2026-09-16:
* **combined_universe.csv**: 31 → **10** names, re-ranked 1–10 by AvgScore: DAMCAPITAL 1.92 · MANBA 1.48 · BAJAJHFL 1.02 · KRN 0.91 · KROSS 0.87 · WCIL 0.83 · DIFFNKG 0.71 · TOLINS 0.64 · NORTHARC 0.40 · ARKADE 0.37 — every one DSM-verified 365–730d. Other profiles' rows untouched.
* **combined_portfolio.csv**: 🦄 book filtered to the 2 in-window sweep holdings — DAMCAPITAL 8.40% + MANBA 4.50% — **original sweep weights preserved, not renormalized**; the freed **87.10% stays unallocated pending the next full sweep** (weights are the sweep's to produce, never invented here). All 10 profiles intact.
* **combined_breakout / combined_prebreakout / post_screening_intelligence**: out-of-window 🦄 rows dropped (4/3/3 in-window rows remain: KROSS, WCIL, MANBA, KRN / TOLINS, ARKADE, NORTHARC / KROSS, DIFFNKG, WCIL).
* Verified prices added to the `_VERIFIED_PRICES` registry for the 7 in-window names not previously covered (NSE-verified quotes 2026-09-15/16; direct Yahoo egress was 429-blocked from this seat, values confirmed via live NSE quote web search: BAJAJHFL 83.00 · KROSS 226.00 · WCIL 91.50 · DIFFNKG 428.00 · TOLINS 87.20 · NORTHARC 298.00 · ARKADE 116.00).

### F. Feature cache restored + provenance trail completed
* The 157-file `models/feature_cache/` restored from the verified Round36 snapshot (the R37 upload had dropped it).
* That snapshot itself carried 28 panels whose content-hash matched **no** shipped sidecar (and 23 orphan sidecars from prior panel generations). The 28 missing sidecars were **reconstructed from each panel's own content** with `"regenerated": true` + a provenance note naming the reconstruction — panel data untouched; the 76 original sidecars restored byte-identical; orphans kept as historical recipe trail.

### G. Tests — the contract is now what's locked
* `test_ipo_multibagger_profile.py`: the window test now calls the **production gate** on real DSM ages with pinned `as_of_date` (KRN 713d passes; BLSE 953d rejected citing the 730 ceiling; ARSSBL 351d rejected citing the 365 floor; phantom rejected; <160 bars still rejected; explicit cfg override honored). The holdings test now asserts **every** shipped 🦄 name is DSM-verified in-window, that the nine out-of-window names are gone, and that DAMCAPITAL/MANBA ship. **SUPERSEDED**: the old BLSE-presence asserts (BLSE is 2.6y listed — by the user's own spec it no longer belongs in this profile).
* `test_round36_regressions.py`: r36-4 updated (bars keys stay out of cfg; calendar keys are required, pinned 365/730, and consumed); r36-6 updated (all-🦄-in-window + original weights locks, supersession noted).
* `test_round35_regressions.py`: build-marker regex generalized to accept later lineage extensions (supersession noted in place).
* **NEW `tests/test_round38_regressions.py`** — 14 locks: gate bounds on 15 real ages (incl. the 731–1000d band R37 leaked), fail-closed on phantom/unparseable, no bare-except/no-1000 AST lock, cfg liveness, DSM bounds + no escape hatch + resync cache clearing + deterministic age pins, app.py AST-level no-1000-comparison lock, delegation locks, clean_sym ordering lock, verified-price coverage, artifact contract locks (10-name universe, contiguous ranks, 2-holding book with exact weights, no out-of-window 🦄 rows anywhere), build marker.

## 4. Verification

* **Compile gate**: all Python files compile.
* **Full suite**: **624 passed / 0 code failures / 2 skipped** (~10 min). The single failing test, `test_sovereign_tier0::test_broker_baskets_and_telemetry`, asserts broker telemetry `ONLINE` — it requires live broker-gateway connectivity and fails **identically on the untouched upload** in this seat (A/B-verified): environmental, pre-existing, not a regression. The R37 report ran only 91 of the 620+ tests it claimed covered.
* Targeted R38/IPO/R34–R36 suites: 103 passed, 1 skipped.
* The 🦄 universe is exactly the 10 DSM-verified 365–730d names; the full NSE 1–2y pool at this master state is 154 names, so the next **Force Full Rebuild** has a deep replenishment bench (recommended — see §5).

## 5. Residuals & Recommended Next Steps

1. **Run the full sweep (Force Full Rebuild)** with the corrected gate: the 🦄 book currently holds only the 2 in-window names the verified sweep selected (87.10% unallocated by construction). The sweep will re-derive the full book from the 154-name 1–2y pool — with live prices, ADV, base-formation geometry — under the same gate the tests now lock.
2. **`Post_Screening_Stock_Intelligence.html`** is a stale generated report (pre-R38 universe). It regenerates on the next intelligence run; it was not hand-edited here.
3. Broker-telemetry `ONLINE` assertion requires broker connectivity (environmental; unchanged).
4. Standing disclosures from earlier rounds (GEX data-feed, Barra/Axioma licensing, .BO lag, per-cutoff ML inputs) are unchanged.
