# Quantum Annealer — Round 39 Audit & Correction Report

**Date**: 2026-09-17
**Build Marker**: `QA-R20-…-R37-R38-R39-SOVEREIGN-TIER-OMEGA` (Round 39 AUDIT entry appended; the shipped R39 zip had silently reused the R38 marker)
**Audited upload**: `Quantum_Annealer_Round39_GLM_Share.zip`
**Focus**: Verification of the R39 Cache Manager round + preservation of the R38 1–2 year listing-age contract

---

## 1. Verdict Summary

| Area | Status |
|---|---|
| R38 IPO 365–730d listing-age contract | ✅ **CONFIRMED LIVE AND PRESERVED** — `ipo_gate_pass` enforces both calendar bounds fail-closed against the official NSE security master; `utils.py` prescreen call path live; `data_layer.py` 🦄 cfg carries `IPO_MIN/MAX_CALENDAR_DAYS = 365/730`; all three dashboard display checks delegate to `DynamicSecurityMaster.is_recent_ipo`; the R37 `clean_sym` NameError fix is intact. Nothing in R39 regressed the user's core requirement. |
| R39 Cache Manager UI/modal/wiring | ✅ Real and correctly wired (modal, per-target purge, purge-all, purge+rebuild, CSRF + session-token gated) |
| R39 prescreen purge | ❌ **SILENT NO-OP** — wrong path (fixed) |
| R39 memory/prices purge | ❌ **NO-OP** — cleared a nonexistent attribute (fixed) |
| Shipped data artifacts | ❌ **REGRESSION** — the three verified sweep CSVs were deleted from the ship (cannot be regenerated offline; disclosed below) |
| R39 report's "100% green" claim | ❌ **FALSE for the shipped state** — 6 of the project's own locks fail on the missing artifacts |

---

## 2. Issues Identified in the Shipped R39 Build

### 2.1 CRITICAL — Verified sweep artifacts deleted from the ship
`combined_universe.csv`, `combined_portfolio.csv`, and `post_screening_intelligence.csv` are **absent from the R39 zip** (present in every prior round's ship; the R38-era upload carried all three at 44.7 KB / 9.4 KB / 124.6 KB). Consequences:

- First dashboard run shows an empty universe, empty portfolio book, and empty intelligence panels until a full live sweep regenerates them.
- Six of the project's own regression locks fail **on the shipped state**:
  1. `test_r36_6_shipped_artifacts_are_the_verified_sweep_state`
  2. `test_r38_4_universe_and_portfolio_are_in_window`
  3. `test_r38_4_no_out_of_window_unicorn_rows_anywhere`
  4. `test_ipo_profile_holdings_and_pricing_integrity`
  5. `test_round33_ml_hygiene::test_universe_feature_pipeline_tickers`
  6. `test_breakouts_prebreakouts_all_profiles::test_all_10_profiles_resolve_breakouts_and_prebreakouts`
- The R39 report's claims "13/13 PASSED" (R38 locks) and "40/40 PASSED" (R36+IPO locks) were evidently run against artifacts **the zip does not contain**.
- The R38-corrected 10-name in-window 🦄 universe (DAMCAPITAL-led, DSM-verified 365–730d) exists only on the development machine — it has never been shipped. The last shipped universe (prior upload) is still the old 31-name BLSE.NS-led book, which fails the 1–2y contract.

**Resolution offline**: not possible — the artifacts require the live NSE/Yahoo sweep.
**Required action on the trading machine**: Cache Manager → 🔁 *Purge & Force Full Rebuild*, then **re-ship the three CSVs**. Never hand-edit them (the R36 incident class).

### 2.2 CRITICAL — Prescreen purge targeted a path production never writes
`_handle_clear_cache`/`_handle_cache_status` probed `{workspace}/qa_db/prescreen_cache.json`. The real Stage-1 prescreen cache is `utils.PRESCREEN_CACHE_PATH` = `~/.quantum_annealer_pro_v17/qa_prescreen_cache.json` (written by `optimizer.py:5248`; the source of every `"Stage 1/6 | Prescreen cache hit (...h old) — Skipping download"` message — i.e., exactly the staleness complaint R39 claimed to fix). **The purge button could never clear the real cache.** Additionally, the in-memory reset referenced `data_layer._PRESCREEN_CACHE`, an attribute that does not exist (dead code).

**Fixed**: both endpoints now use `utils.PRESCREEN_CACHE_PATH`; the item count reads `data["rows"]` (the structure optimizer actually writes) instead of `len(dict)`; the dead `data_layer._PRESCREEN_CACHE` block is removed; the status response and the dashboard card now disclose the real path.

### 2.3 CRITICAL — Memory/prices purge cleared a nonexistent attribute
The shipped form called `getattr(DynamicPriceResolver, "_PRICE_CACHE", {}).clear()` — `getattr` with a default returns a **fresh throwaway dict**, and `.clear()` on it is a no-op. The class has no `_PRICE_CACHE`; its real caches are `_CACHE` (1-hour TTL price memory), `_FILE_PRICES` (the CSV pre-index), and `_FILE_MTIMES` (the mtime guard). **Stale in-memory prices survived every purge**, and `cache_status` always reported `price_cache_tickers: 0`.

**Fixed**: the purge now flushes all three real caches; `cache_status` reports the true `_CACHE` count plus a new `file_price_index` KPI. Verified by execution against the real handler.

### 2.4 Vacuous price-indexing test
`test_dynamic_price_resolver_indexing` asserted `DynamicPriceResolver.get("TATATECH") > 0` unconditionally — which passes via the **hardcoded `_VERIFIED_PRICES` registry** (₹762.15) even when zero CSVs are shipped, proving nothing about file indexing. **Fixed**: the lock now asserts a non-empty `_FILE_PRICES` when the source CSVs exist, and a provably EMPTY index when they do not.

### 2.5 Window-preservation lock was a time bomb
`test_ipo_listing_age_contract_preservation_r38` called `is_recent_ipo` without pinning `as_of_date`. DAMCAPITAL crosses the 730-day ceiling around Dec 2026, after which the lock would fail with no code change. **Fixed**: pinned `as_of_date=2026-09-16` (the shipped DSM snapshot date), matching its R38 siblings.

### 2.6 Minor findings
- **Build marker not bumped** — R39 shipped with the R38 marker (same failure mode as R37). Fixed: `R38-R39-SOVEREIGN-TIER-OMEGA` + full Round 39 AUDIT narrative.
- **R39 report misnamed the handler class** (`UnifiedDashboardHandler`; the real class is `DashboardAPIHandler`) — noted for traceability.
- **Two R39 tests silently skip headless** (localhost:8088 probes) — retained but supplemented with headless handler-semantics locks (below).
- `models/regime_hmm_latest.json` is not shipped — regime detection falls back to heuristics and the Cache Manager shows "HMM Model: Missing" until the 12h background refresher trains one. Acceptable, disclosed.
- `build_stock_dict` (intel-CSV path) still carries a `REAL_PRICES.get(sym, 100.0)` fallback when an intel row lacks a price — the R38 "no fake ₹100" claim was scoped to the combined_universe path only. Left as disclosed residual (rows reaching that branch have a verified CSV row; the fallback fires only for malformed price cells).
- The shipped `test_round38_regressions.py::test_r38_5` used a rigid contiguous marker substring (`R36-R37-R38-SOVEREIGN-TIER-OMEGA`) that fails the moment a later round legitimately appends to the chain — superseded with intent-preserving assertions (marker carries R38 + the R39-audit entry).

---

## 3. Fixes Implemented (this audit round)

| # | File | Change |
|---|---|---|
| 1 | `web_dashboard/app.py` `_handle_cache_status` | Prescreen probe → `utils.PRESCREEN_CACHE_PATH`; items counted from `data["rows"]`; real path disclosed in response; price-cache KPI reads the real `_CACHE`; new `file_price_index` KPI |
| 2 | `web_dashboard/app.py` `_handle_clear_cache` | Prescreen purge → `utils.PRESCREEN_CACHE_PATH` (with honest "no file present" outcome); dead `data_layer._PRESCREEN_CACHE` block removed; memory/prices purge flushes `_CACHE` + `_FILE_PRICES` + `_FILE_MTIMES` |
| 3 | `web_dashboard/dashboard.js` | Prescreen card displays the API-disclosed path instead of the wrong hardcoded `qa_db/prescreen_cache.json` |
| 4 | `tests/test_round39_regressions.py` | Honest price-index lock (file-sourced when CSVs present, provably empty when absent); `as_of_date` pinned in the window-preservation lock; **new headless handler-semantics locks**: `test_clear_cache_memory_actually_flushes_price_caches`, `test_clear_cache_prescreen_targets_production_path`, `test_cache_status_reports_real_price_cache_count` (no live server required — the shipped R39 suite's server probes silently skip headless) |
| 5 | `tests/test_round38_regressions.py` | R38-5 marker lock superseded: asserts the marker carries R38 + `SOVEREIGN-TIER-OMEGA` + the R38 narrative **and** the new `Round 39 AUDIT` entry, instead of freezing the chain tail |
| 6 | `web_dashboard/app.py` `APP_BUILD_ID` | Bumped to `…-R38-R39-SOVEREIGN-TIER-OMEGA` with the full Round 39 AUDIT narrative (fixes 1–5 + the disclosed offline-unfixable artifact regeneration requirement) |

---

## 4. Verification

### Fixed-behavior locks (headless, no server):
- `tests/test_round39_regressions.py::TestRound39AuditHandlerSemantics` — 3/3 PASSED (memory purge really flushes; prescreen purge addresses the production path; status reports real counts)
- `tests/test_round39_regressions.py` overall: **6 passed, 2 skipped** (the two skips are the live-server probes, unchanged)

### Full suite (after fixes): `8 failed, 625 passed, 8 skipped`
- **6 failures = the missing shipped artifacts** (§2.1) — require *Purge & Force Full Rebuild* on the trading machine; **cannot be regenerated offline** and are locked intentionally (the locks exist precisely to catch artifact-less ships)
- 1 failure = `test_sovereign_tier0` telemetry requires live market-data network (environment-dependent by design)
- 1 failure = `test_round38_regressions.py::test_r38_5` was transiently broken by the marker bump and **fixed** by the supersession in §3.5 — now passing

### Execution proof of the cache fixes
The real handler methods were driven headless with a stub: memory purge flushes all three caches to 0/0/0; the prescreen purge outcome references `qa_prescreen_cache.json` (production path), never `qa_db`; `cache_status` reports `price_cache_tickers = 2` when `_CACHE` holds 2 entries.

---

## 5. Required Actions on the Trading Machine (cannot be done offline)

1. Launch the dashboard → Settings → 📁 Cache Manager → **🔁 Purge & Force Full Rebuild**.
2. Confirm the sweep regenerates `combined_universe.csv` (🦄 rows must be the 10 DSM-verified 365–730d names), `combined_portfolio.csv` (2 in-window 🦄 holdings, freed weight unallocated), and `post_screening_intelligence.csv`.
3. Re-run `pytest tests/` — the 6 artifact locks must go green before shipping.
4. Re-package the zip **including the three CSVs**.
