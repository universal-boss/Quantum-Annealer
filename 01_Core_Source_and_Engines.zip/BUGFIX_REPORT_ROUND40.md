# Quantum Annealer — Round 40 Audit & Correction Report

**Date**: 2026-09-17
**Build Marker**: `QA-R20-…-R38-R39-R40-SOVEREIGN-TIER-OMEGA`
**Audited upload**: `Quantum_Annealer_Round39_Audit_Verified_Share.zip` + `quantum_annealer_log_2026-09-17_00_57_58.txt` (the 02:07–02:17 regeneration sweep log)
**Focus**: Verification of the "Audit Verified" ship — is it actually the verified sweep state?

---

## 1. Verdict Summary

| Area | Status |
|---|---|
| R38 365–730d listing-age contract (code) | ✅ **CONFIRMED LIVE** — `ipo_gate_pass` enforces both calendar bounds fail-closed against the NSE master; `is_recent_ipo` single-source; no 1000-day escape; cfg keys live |
| R39-audit cache fixes (code) | ✅ Real (prescreen purge → `utils.PRESCREEN_CACHE_PATH`; price purge flushes `_CACHE`/`_FILE_PRICES`/`_FILE_MTIMES`; honest indexing test) |
| Full suite on the shipped state (clean env) | ✅ 637 passed / 0 failed / 4 skipped — *before* this round's changes, pinning sklearn 1.8.0 + pyarrow + catboost |
| The shipped CSVs vs the logged sweep | ❌ **NOT THE SAME RUN — a Frankenstein ship** (§2.1) |
| The 🦄 profile in the logged sweep | ❌ Vendor-throttled to 0 usable tickers (its genuine output was discarded) |
| Root cause: no artifact↔run binding | ❌ Fixed (R40-1/R40-2 provenance + run-id stamping) |
| Root cause: freezing locks forbade fresh data | ❌ Fixed (R40-5 vintage-aware supersessions) |
| Sweep accounting & profile order | ❌ Fixed (R40-3 exception-path tally; R40-4 🦄-first) |

---

## 2. The Findings

### 2.1 CRITICAL — The three core CSVs are not the logged sweep's outputs

Zip-internal mtimes tell the whole story on one clock:

| Artifact | mtime | Provenance |
|---|---|---|
| `qa_db/sebi_algo_audit.anchor/.db` | 02:16:08 | the logged sweep (SEBI stamp) |
| `Portfolio_Allocation_Report.html` | 02:16:30 | the logged sweep — title says "**PARALLEL 9-PROFILE** SWEEP REPORT", zero 🦄 content |
| `combined_breakout.csv`, `combined_prebreakout.csv`, `Post_Screening_Stock_Intelligence.html`, `AI_Copilot_Research_Report.html` | 02:17:18–02:17:28 | the logged sweep |
| **`combined_universe.csv` / `combined_portfolio.csv` / `post_screening_intelligence.csv`** | **06:32:46 — all three in the SAME 2-second window** | **copied in 4h15m AFTER the sweep** |
| `web_dashboard/app.py` | 06:28:58 | the R39-audit fixes, assembled 4 min before the CSVs |
| `qa_db/dynamic_security_master.json` | 06:32:56 | DSM refresh 10s after the paste |

The logged sweep (02:16:31) saved a **6,382-row, 9-profile universe** and a **131-allocation portfolio with zero 🦄 rows** (the 🦄 profile was throttled: all 35 prescreened candidates → "Attempt 3/3 still throttled (0 usable tickers)" → hard RuntimeError). Those genuine outputs were **discarded** and replaced at 06:32:46 by the R38 dev-machine gate-filtered artifacts — an orchestrator save writes universe+portfolio together and post-screening ~1 minute later; a same-instant write of all three is a **copy signature**, not a pipeline signature.

**Content forensics confirm the origin bit-for-bit**: vs the Sep-16 R37 ship (`Quantum_Annealer_GLM_Share.zip`) — the 776 non-🦄 universe rows are **bit-identical in order and scores**; all 10 🦄 survivor scores are **exact matches** (DAMCAPITAL 1.92, MANBA 1.48, …); the 2 holdings' weights are **exactly the R37 values** (DAMCAPITAL 8.40%, MANBA 4.50%); 807−21=786 universe rows and 143−10=133 portfolio rows. The file is the R37 sweep with 21 out-of-window 🦄 names filtered out — i.e. the R38 dev-machine state the R39-audit report itself said "exists only on the development machine — it has never been shipped".

**Consequences shipped to you**:
- The HTML reports (fresh sweep) contradict the CSVs (stale): the report says 9 profiles and shows no 🦄; the CSV beside it claims 10 profiles and 2 🦄 holdings.
- The fresh sweep's real data (6,382 rows across 9 profiles) was thrown away.
- **3 of the 10 shipped 🦄 names are already OUT of the 1–2y window as of today** — BAJAJHFL, KROSS and TOLINS all listed 2024-09-16, were exactly 730d on Sep 16 (the filter's as-of), and are 731d+ now. Stale artifacts age out of your own contract by the day. (MANBA crosses 730d on 2026-09-25.)

### 2.2 Why every lock passed anyway — three lock-design failures

1. **Nothing bound an artifact to its producing run.** The `#P1-11` run_id fix stamps exactly ONE payload key (`run_id` in the optimizer result dict). No CSV column, no HTML stamp — grep the entire ship for any `qa_*` run id: zero hits. The optimizer's log line "[RunID] … embedded in all exports from this run" is **false** for every export you can open.
2. **The freezing locks made pasting the ONLY green path.** `test_r38_4` pinned *exactly* 10 names, *exactly* [DAMCAPITAL, MANBA], *exactly* 8.40%/4.50%; `r36_6` pinned the same weights; `ipo_holdings` pinned `as_of=2026-09-16` + "DAMCAPITAL/MANBA must ship". Any genuinely fresh sweep (different selections, different weights, later date) would go RED — so after the honest rebuild got throttled, restoring the stale artifacts was the only way to ship green. **The locks designed to prevent the R36 hand-edit incident caused its 2026-09-17 recurrence.**
3. **The HTML↔CSV consistency was never checked.** The roster mismatch (9 vs 10 profiles) sat in plain sight.

### 2.3 The 🦄 throttle failure itself (the trigger)

The 🦄 profile ran LAST in the sweep. After 9 profiles consumed the vendor rate budget (38.7 min of continuous downloads), its full-universe OHLCV bundle was throttled; the recovery path retried only 3× with 2s/4s/6s backoff (12s total — far below a real rate-limit window) and the profile died with 0 usable tickers **while the per-ticker price caches for all 35 candidates were green**. The per-ticker cache cannot substitute for the full history panels, and no end-of-sweep retry exists.

### 2.4 Sweep accounting bug (R40-3)

The exception path escaped BOTH tallies: the sweep logged "9/10 succeeded, **0 failed**" while the 10th profile had hard-failed with a RuntimeError. The P0-6 honest-tally fix only covered the returned-degenerate path.

---

## 3. Fixes Implemented (this round)

| # | File | Change |
|---|---|---|
| R40-1 | `web_dashboard/app.py` | **Sweep provenance sidecar** `qa_db/sweep_provenance.json`: every full sweep records run_id, completed_at, as_of_date, per-profile {status, selected, universe, run_id, error} and the **sha256 of all 8 shipped artifacts** (atomic write). Every single-profile run appends its entry and re-binds the artifact hashes (R36-1 merge-in-place aware). A pasted or hand-edited CSV breaks the recorded hash → the tree fails its own locks. Helpers: `write_sweep_provenance`, `record_single_profile_run_provenance`, `load_sweep_provenance`, `_qa_sha256_file` |
| R40-2 | `web_dashboard/app.py` | **Run-id stamped exports**: `generate_portfolio_allocation_html` wrapped — injects `<meta name="qa-run-id">` + a visible provenance footer; the sweep passes its run id; the single-profile path **regenerates the HTML from the merged CSV** so the HTML and CSV rosters can never disagree |
| R40-3 | `web_dashboard/app.py` | The sweep-worker exception handler now increments `_n_fail` and records a `failed` provenance entry (an exception IS a failure) |
| R40-4 | `data_layer.py` | **The 🦄 profile runs FIRST** in every full sweep (dict reorder — same cfg, run order only). It is your core strategy and the most rate-fragile profile; it now gets the freshest vendor budget |
| R40-5 | `tests/` | **Vintage-aware supersessions** of the freezing locks: `r38_4` (both), `r36_6` (weight pins + hardcoded date dropped; non-empty/in-window/shape kept), `ipo_holdings` (hardcoded date + must-ship pins dropped; permanently-mature never-hold list kept; ARSSBL removed — it ages INTO the window on 2026-09-30). The 365–730d contract itself is unchanged and now evaluated at the **provenance vintage** |
| R40-6 | `tests/test_round40_regressions.py` | 10 new locks: provenance existence + sha256 binding; CSV profiles traceable to recorded runs; HTML run-id stamp matches a recorded run; **HTML↔CSV roster agreement** (the frankenstein catcher — fires on this ship); fail-tally source lock; 🦄-first order lock; the vintage-aware window contract; hermetic writer/tamper/single-append/HTML-wrapper unit tests |
| R40-7 | `web_dashboard/app.py` | Build marker → `…-R38-R39-R40-SOVEREIGN-TIER-OMEGA` with the full forensic narrative |

## 4. Verification

- Full suite on the corrected tree: **638 passed / 9 failed / 4 skipped** — the 9 failures are ALL the intentional-red data-state locks (r40_1 ×2, r40_2 ×2, r40_5, r38_4 ×2, r36_6, ipo_holdings), every one rooted in the same disclosed cause: **the shipped artifacts are not provenance-bound**. They go green only after a genuine sweep regenerates them.
- The roster catcher (`r40_2_html_and_csv_profile_rosters_agree`) fires on this ship exactly as designed (HTML: 9 profiles / CSV: 10).
- Hermetic unit tests prove the writer round-trip: tamper a bound artifact → the recorded sha256 no longer matches; single-profile append updates `last_writer` and re-binds hashes.
- 283 files compile clean; `PROFILE_MAP` order verified (🦄 first, 10 profiles).

## 5. Required Actions on the Trading Machine (cannot be done offline)

1. Replace the workspace with this R40 zip.
2. **Run All Profiles** (the 🦄 now runs FIRST — the 02:16-style starvation cannot recur in that position). If any profile is still throttled, re-run just that profile after a cooldown (merge-in-place preserves the rest; provenance records the refresh).
3. Confirm `qa_db/sweep_provenance.json` exists and the allocation HTML footer shows a RunID.
4. Re-run `pytest tests/` — **all 9 currently-red locks must go green** before shipping. If the 🦄 comes up empty on a throttle day, the locks stay red honestly: retry the sweep later — **never paste CSVs from an older run**; the sha256 binding now makes that detectable.
5. Re-package the zip **including the regenerated artifacts + the provenance sidecar**.
