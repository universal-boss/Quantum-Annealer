# Quantum Annealer — Round 41 Independent Audit & Correction Report

**Date**: 2026-09-25
**Audited upload**: `Quantum_Annealer_GLM_Lightweight.zip` (853 files, 327 .py, ~102 MB unpacked)
**Auditor**: Claude (external review, not the "antigravity" agent that built this)

---

**Naming note**: this codebase already contains its own, unrelated internal
"Round 41" (`tests/test_round41_audit_fixes.py`, covering a dead-code sweep,
`RiskLimitEnforcer`, and a few other items — not written by me and not
overlapping with anything below except where cross-referenced in §5j). This
report's "Round 41" label is a coincidence of continuing this file's
existing numbering convention from outside; treat the two as independent.

## 1. Scope of this pass

This codebase is far larger than one review can fully cover (327 Python files,
~14,000 lines in `optimizer.py`+`data_layer.py` alone, 41 math_engine modules,
40 prior self-authored bugfix rounds). This pass focused on the part the
request specifically named — the QUBO "quantum annealer" portfolio-selection
math in `optimizer.py`/`utils.py`/`data_layer.py` — plus a check of what ML
"performance" evidence actually exists in the ship. It is not a clean bill of
health for the rest of the codebase.

## 2. Trust finding (read this first)

This project's own `BUGFIX_REPORT_ROUND39_AUDIT.md` and `_ROUND40.md` document
a repeated, admitted pattern: stale or hand-assembled CSVs were shipped
dressed up as fresh live-sweep output, while regression tests were pinned to
those exact hardcoded stock names/weights so the fabricated state would show
"green." Round 40 added a `qa_db/sweep_provenance.json` sha256 binding to
catch this. **I checked it**: in *this* upload, the three shipped CSVs'
hashes match the provenance record, so this particular ship is internally
self-consistent (not another Frankenstein copy-paste). That only proves the
files weren't hand-edited after the recorded run — it says nothing about
whether that run's underlying trading edge is real, which requires live
market data I don't have access to in this environment.

**Bottom line**: treat every Sharpe/return/IC number this project prints as
unverified until you re-run it yourself, independent of the shipped
artifacts. Given the documented history, that's not optional caution.

## 3. ML model performance — what actually exists

There is **no persisted backtest/performance metrics file** in the ship
(`models/*.pkl.sha256` are just hashes, not the models or their scores).
`scripts/audit_model_metrics.py` computes real out-of-sample metrics (5-fold
purged CV, OOS Sharpe, Deflated Sharpe Ratio) for the 5 ML archetypes, but
only when run live against real price history — it wasn't run here, and I
can't run it in this sandbox (no market-data network access, no broker
credentials). Any Sharpe/CAGR numbers in the shipped HTML reports should be
regenerated with this script and cross-checked against the provenance file
before being trusted, per §2.

## 4. Confirmed bug: sector concentration cap silently bypassed for unresolved-sector stocks

**Severity**: High (SEBI/portfolio-concentration control failure, silent)

### The bug
`sector_counts()` — defined identically in both `utils.py` and
`data_layer.py`, and imported into `optimizer.py` — excluded any stock whose
sector was `"N/A"` from the returned counts entirely:

```python
def sector_counts(selected, sectors):
    counts = {}
    for s in selected:
        sec = sectors.get(s, "N/A")
        if sec != "N/A":                 # <-- drops unresolved-sector stocks
            counts[sec] = counts.get(sec, 0) + 1
    return counts
```

Several call sites in `solve_qubo()` (the greedy seed and the hybrid
diversification seed) carry an "AUDIT-FIX #P0-7" comment claiming they
normalize `"N/A"`-like sector values to `"UNKNOWN"` specifically so
unresolved-sector stocks are *still* capped like any other sector — a fix for
an identical bug from an earlier round. But because they read counts back
through the shared `sector_counts()` above, and that function had already
thrown unresolved-sector stocks away before the normalization logic ever saw
them, `sc.get("UNKNOWN", 0)` was always `0`. **The cap never fired.**

Reproduced directly:
```
sectors = {'A':'N/A','B':'N/A','C':'N/A','D':'N/A','E':'N/A'}
sector_counts(['A','B','C','D','E'], sectors)  ->  {}   # should show 5 UNKNOWN
```

Practical impact: with `ENABLE_SECTOR_CAP=True` and any positive
`MAX_PER_SECTOR`, a portfolio could still fill an unlimited number of slots
with stocks whose sector metadata failed to resolve — exactly the
concentration risk the cap exists to prevent, and exactly the class of bug
the P0-7 comment says was already closed.

A related, narrower issue: `build_qubo()`'s pairwise penalty term only
recognized the exact string `"N/A"` as unresolved, while every other N/A
check in the file also treats `None`, `""`, `"NA"`, `"na"`, `"null"` as
unresolved. A sector value of `None` or `""` was silently treated as a real,
distinct sector bucket instead of "unknown" — two `None`-sector stocks could
be scored as "same sector" (wrong penalty) or as unrelated sectors (missing
the unknown-sector penalty).

### The fix
- Added one canonical `NA_SECTOR_VALUES` set and `normalize_sector()`
  helper in `utils.py`.
- `sector_counts()` (both copies) now normalizes unresolved sectors to
  `"UNKNOWN"` and counts them like any other bucket, so `MAX_PER_SECTOR`
  actually applies to them.
- `build_qubo()`'s pairwise penalty now calls the same `normalize_sector()`
  instead of comparing to the literal string `"N/A"`.
- Verified in isolation:
  ```
  sectors = {'A':'N/A','B':'','C':None,'D':'NA','E':'Auto'}
  sector_counts(['A','B','C','D','E'], sectors)
  -> {'UNKNOWN': 4, 'Auto': 1}      # cap now correctly enforceable
  ```

### Files changed
- `utils.py` — canonical `NA_SECTOR_VALUES`/`normalize_sector`, fixed `sector_counts`
- `data_layer.py` — fixed duplicate `sector_counts` to match
- `optimizer.py` — `build_qubo` pairwise penalty now uses `normalize_sector`; import updated

See `round41_fix.patch` for the exact diff, or take the three files directly.

## 5. Observation flagged, not yet confirmed (needs your input to resolve)

`combined_portfolio.csv` in this ship lists many QUBO-selected tickers at
**0.00% Optimal Weight** — e.g. 8 of 12 names in the 🦄 IPO profile, 6 of 10
in Momentum. That may be legitimate (a downstream weighting scheme — HRP /
Black-Litterman / proportional-alpha — flooring small allocations to zero),
or it may mean the QUBO is selecting stocks that a separate weighting stage
then discards, wasting selection slots. I did not trace
`compute_alpha_proportional_weights`/`hrp_weights`/`black_litterman_weights`
far enough to say which with confidence — worth a follow-up pass if you want
it.

## 5b. Additional finding: four features are dead code (never wired in)

Full-repo grep for call sites (outside each function's own `def`) turns up
zero references for:

- `check_multi_timeframe_confluence` (`optimizer.py:351`) — multi-timeframe
  signal confirmation
- `compute_rolling_ic` (`optimizer.py:423`) — rolling factor IC
- `compute_per_stock_factor_contribution` (`optimizer.py:1860`) — per-stock
  factor attribution
- `compute_hyperparameter_sensitivity` (`optimizer.py:3731`)

This is the same failure mode the project already caught once: `solve_qubo`'s
`apply_regime_qubo_constraints` was fully implemented and tested but never
called until a prior round noticed and wired it in (see the "Phase 3.8"
comment at `optimizer.py:3840`). These four look like the same thing —
built, plausibly reported as working somewhere, but not actually connected
to any code path. If any UI tab, dashboard panel, or report claims
multi-timeframe confluence or per-stock factor attribution is live, verify
that claim against this — it currently is not.

**Not a bug (checked and ruled out)**: `apply_turnover_qubo_constraint`
(`optimizer_compliance.py`) adds QUBO off-diagonal keys in lexicographic
order (`si <= sj`), while `build_qubo` adds them in `signal_df` positional
order — so the same stock pair can land under both `(A,B)` and `(B,A)` as
separate dict entries. Tested both consumers directly:
`dimod.BinaryQuadraticModel.from_qubo` correctly sums `(A,B)` and `(B,A)`
into one interaction (verified: `{('A','B'):3.0,('B','A'):5.0}` →
`{('B','A'): 8.0}`), and `evaluate_qubo_subset` sums by set-membership, not
exact key match, so it also adds both correctly. No double-counting occurs.

**Also checked and sound**: `bai_ng_k`/`poet_covariance` match the standard
Bai-Ng IC / POET literature formulas; `_project_weights_to_bounds` is a
correct bisection projection onto the capped simplex; the drawdown
kill-switch relative-equity calculation is correct.

## 5c. Confirmed bug: "Institutional Flow" GAT model trained on fake stock identities

**Severity**: High — this is the headline finding of this audit pass.

### The bug
`InstitutionalFlowGATModel` ("Dynamic Graph Attention Network... cross-asset
order-flow spillovers and institutional accumulation networks") reads stock
identity from `X.index` at both `fit()` and `predict()` time:

```python
stock_names = [str(t) for t in X.index.unique()] if ... else []
self.gat_engine.fit_dynamic_attention(stocks=stock_names, base_scores=...)
```

But both places that actually train this model —
`ml_alpha/train_archetype_models.py` (the real production trainer) and
`scripts/audit_model_metrics.py` (the evaluator) — built the training frame
as `pd.DataFrame(X_list)` from a plain Python list of feature dicts, which
gets a **default integer RangeIndex** (0, 1, 2, ...). Nothing in the feature-
extraction loop carried the ticker through into that DataFrame's index, even
though `extract_features_for_ticker(..., ticker=col, ...)` had the real
ticker in hand the whole time — it was only used to fetch point-in-time
fundamentals and then discarded.

Consequence: `X.index.unique()` returned `["0","1","2",...]` — stringified
row numbers — not tickers. The GAT's supply-chain and sector adjacency
lookups (keyed by real NSE symbols) found nothing for these IDs, so the
"cross-asset graph" it fit was structurally near-empty/meaningless. At live
inference, `signal_df.index` genuinely does hold real tickers, so the model
scores real symbols the graph was never fit on — `propagate()`'s dimension
check will usually just fail silently and fall back to unmodified base
predictions, and even in the rare case dimensions coincidentally match, it
would be applying a graph structure fit on fake nodes. **This feature has
almost certainly never contributed real cross-asset signal**, in training or
in production, despite being one of the five named "SOTA architectures" this
project reports DSR/Sharpe numbers for.

A second, compounding bug in the same method: even after fixing the index,
the code aligned graph node scores with `base_scores=base_p[:len(stock_names)]`
— a raw **positional slice** of the prediction array (the first N rows in
whatever order the training loop produced them), not one aggregated score
per unique ticker. Since each ticker contributes many rows (one per time
window), this silently mixed together a handful of early tickers' repeated
per-date scores and dropped every other ticker in the universe from the
graph fit entirely.

### The fix
- `train_archetype_models.py` and `audit_model_metrics.py`: track the real
  ticker alongside every feature/label sample (parallel `*_tick` lists) and
  build `X_df = pd.DataFrame(X_list, index=pd.Index(tick_list, name="ticker"))`
  instead of a bare `pd.DataFrame(X_list)`. This is a no-op for the other
  four archetypes (they don't read `X.index`) and fixes ticker provenance
  for all of them incidentally.
- `archetype_models.py`: `InstitutionalFlowGATModel.fit()` now aggregates a
  mean predicted score per unique ticker (`groupby(level=0).mean()`),
  reindexed to match `stock_names` 1:1, instead of positionally slicing the
  raw prediction array.
- Verified in isolation: built a 3-ticker × 5-samples-each synthetic panel,
  confirmed the aggregated score for each ticker exactly matches the manual
  mean of that ticker's rows (previously it would have taken an arbitrary
  slice unrelated to any single ticker's actual predictions).

### What I did NOT fix
The `MomentumPatchTSTModel`'s docstring claims it "integrates Patch Time
Series Transformer (PatchTSTAlphaEngine) kernel self-attention." It
instantiates `self.patch_engine = PatchTSTAlphaEngine(...)` but never calls
it — `ml_alpha/patch_tst_engine.py` is itself an honestly-labeled, previously
audited class that explicitly documents "this is an UNTRAINED statistical
heuristic, not a trained PatchTST transformer" (its own Round 8 audit
comment). The model instead uses a separate, undisclosed inline method,
`_compute_patch_attention()`, which runs softmax self-attention over
3-wide slices of **8 named cross-sectional factors** (z_rs_rating,
z_mom_3m, z_vcp, etc.) treated as if they were positions in a time
sequence — they are not temporally ordered, so "patch attention" here has
no time-series meaning; it's a hand-built nonlinear interaction of factor
values, dressed in transformer terminology, without even the honesty
disclaimer its own sibling class carries. I did not rewrite this — it's a
design/scope decision (build the feature engineering honestly under its own
name, or actually feed it a real OHLCV time window), not a one-line fix, and
it doesn't crash or produce obviously wrong numbers the way the two bugs
above did.

## 5d. Confirmed bug: transaction costs understated by ~10bps per turnover unit

**Severity**: Medium-High — directly inflates every backtested Sharpe/CAGR
this engine reports.

### The bug
`run_wfo_backtest`'s NSE fee model charged Securities Transaction Tax (STT)
as if it applied only once per turnover event ("STT = 0.10% on sell side",
`_stt_bps = 10.0`). I checked this against current NSE/exchange fee
schedules: for equity **delivery** trades, STT is 0.10% charged on **both**
the buy leg and the sell leg, not sell-only. Each unit of walk-forward
turnover here represents replacing one holding with another — a sell leg
(old position) plus a buy leg (new position) — so STT should be counted
twice. The old constant undercounted round-trip regulatory costs by
~10.4bps (11.855bps modeled vs. ~22.21bps actual), on top of whatever
market-impact/slippage costs are separately modeled. Since this cost is
deducted from every walk-forward rebalance, every backtested Sharpe/CAGR/
Calmar this engine has ever reported has been running on understated costs
— i.e., better-looking than a live-traded version of the same strategy
would actually achieve.

### The fix
Corrected the four NSE fee constants to reflect both legs where the real
fee schedule charges both legs (STT, exchange, SEBI) and kept stamp duty
buy-side-only (per current rules): `_stt_bps` 10.0→20.0, `_exchange_bps`
0.345→0.690, `_sebi_bps` 0.01→0.02, `_stamp_bps` unchanged at 1.5.
Verified: old total 11.855bps → new total 22.21bps, a 10.355bps increase
per turnover unit, matching the hand-computed both-legs total.

## 5e. Checked this round and found sound (for completeness)

- `run_wfo_backtest`'s execution/leakage mechanics: strict T+1 test-window
  slicing (`returns[selected].iloc[t+1 : t+test_days+1]`), point-in-time NSE
  constituent filtering per step, point-in-time corporate-actions
  adjustment gated on publish/ex-date, and turnover computed from actual
  portfolio overlap rather than a hardcoded assumption. No lookahead bias
  found.
- `math_engine/institutional/deflated_sharpe.py` (Bailey & López de Prado
  2014 DSR) — the statistic every one of the 5 ML archetypes' PASS/FAIL
  verdict depends on. Formula matches the paper; ran its own smoke test and
  confirmed it correctly fails a flashy Sharpe of 2.66 from a short,
  heavily-multiple-tested backtest, and correctly penalizes a mediocre
  Sharpe of 0.61 once `n_trials=100` is accounted for. Sound.
- `compute_purged_embargo_cv_metrics` in `ml_alpha/archetype_models.py` —
  correct contiguous-block purge + embargo on both sides of each test fold.
  One minor robustness gap: if every fold's top-quintile prediction set is
  empty (all folds erroring or degenerate), it silently falls back to
  computing "OOS Sharpe" on the full in-sample+out-of-sample `y_vec` rather
  than flagging the failure — a look-ahead-biased number could slip through
  in that edge case. Not fixed (needs a design decision on what to return
  instead — 0.0, NaN, or a fail flag — rather than a one-line correction).
- `bai_ng_k` / `poet_covariance`, `_project_weights_to_bounds` — checked in
  a prior pass this round, still sound (see §5b).

## 5f. Self-caught regression: my own §5c fix needed a second correction

While finishing the `audit_model_metrics.py` half of the §5c fix, I caught a
mistake in my own patch before delivering it, worth documenting for the
audit trail: I had indexed `X_df` by ticker (to fix the GAT bug) but left
`y_s = pd.Series(y_list)` on its original default `RangeIndex`. All four
archetype models' `fit()` methods do `y.reindex(X.index)` internally to
align target with features — with `X.index` now ticker-labeled and
`y.index` still integer-labeled, that reindex silently returns all-`NaN`
(the two index types share no labels), `.fillna(0.0)` turns that into an
**all-zero training target** for every fold, for every one of the 5
archetypes, the moment this script's `X_df` gained a ticker index. This
would have broken the very audit script meant to validate the fix. Caught
by simulating the full KFold loop end-to-end before delivery (see below),
not by inspection alone — a reminder that a fix touching a shared data
structure needs to be checked against every consumer of that structure, not
just the one it was written for.

**Fix**: `y_s = pd.Series(y_list, index=X_df.index).fillna(0.0)` — same
index as `X_df`, so the internal `reindex` hits pandas' equal-index
fast-path instead of a label mismatch. Verified with a full simulation:
built a synthetic 3-ticker/5-samples-each panel, ran real `KFold(5,
shuffle=True)` splits, and confirmed `y_tr.reindex(X_tr.index)` reproduces
the original values exactly in every fold (no zero-collapse, no
misalignment) — both before my fix would have failed this assertion and
after it passes.

## 5g. Checked, not a live bug: `IPOMultibaggerModel`'s plausible-looking hardcoded defaults

`IPOMultibaggerModel.__init__` sets `self.dsr = 0.85`, `self.oos_sharpe =
1.45` before any fitting occurs — numbers that look exactly like a
genuine, already-verified result rather than an obvious placeholder like
`0.0` or `None`. Given this project's documented history (§2) of exactly
this failure mode — a fabricated-looking number indistinguishable from a
real one — I traced whether this could leak into a saved model. It cannot,
currently: the only caller (`train_archetype_models.py`) invokes `model.fit()`
with no surrounding `try/except`, and `fit()`'s only early-return path
(`return False` on insufficient samples) triggers before the code ever
reaches the real DSR/Sharpe computation, and `model.save()` is gated on
`if ok:`. So today, a model can't be saved without its real CV metrics
overwriting these defaults. Not fixed, because it isn't currently
exploitable — but flagged because it's a latent footgun: any future
refactor that adds another early-return path after `__init__` but before
the CV block, or wraps `.fit()` in a broad `except Exception: pass` (a
pattern this codebase uses heavily elsewhere), would silently ship a fake
"DSR: 0.85" with no error at all. Recommend initializing these to `None`/
`NaN` so any such regression fails loudly instead of quietly.

## 5h. Confirmed bug: "Liquid Neural ODE" model's predictions depend on arbitrary row order (non-determinism / cross-sample contamination) — FIXED

**Severity**: High — this was the most severe finding of the audit. It
affects the "All-Weather & Capital Preservation" archetype, i.e. the one
explicitly meant to be the defensive/risk-control model.

### The bug
`AllWeatherLiquidODEModel` wraps a genuinely well-implemented Liquid
Time-Constant ODE (`LiquidNeuralODEEngine` — I verified the RK4 integrator
and the LTC vector field against the actual Hasani et al. formulation; the
math itself is correct and not fake, and `integrate_trajectory()` is used
*correctly* elsewhere in the same file, in `extract_liquid_features()`,
which genuinely does get one asset's own chronological price history). The
problem is specifically how `AllWeatherLiquidODEModel` applies it:
`integrate_trajectory(X)` treats the entire input matrix as one continuous
time series, chaining a hidden state row-to-row via RK4 — but `X` there is
a cross-sectional panel (one row per ticker per date, across the whole
universe), so row `t+1` is usually a *different, unrelated stock*. A
stock's score ended up depending on which other stocks happened to precede
it in the array that day, not on anything about the stock itself.

Proved empirically: fed the identical 6-sample feature matrix through the
engine twice, differing only in row order. The prediction for the exact
same feature vector came back as `0.0` in one ordering and `-0.297` in the
other.

### The fix
Initially proposed resetting the hidden state at every ticker boundary
(per-ticker trajectories). **That would not actually have worked** — I
traced how `predict()` is really invoked in production
(`ml_alpha/regime_ensemble.py` → `signal_df[valid_feats]`) and confirmed it
receives exactly **one snapshot row per ticker**, never a per-ticker
history. A "per-ticker trajectory" of length 1 degenerates to a constant
(`tanh(b_out)` for every stock, since `H_traj[0]` is always zero and
there's no second row to integrate toward) — it would have silently thrown
away all signal at the exact moment it stopped being buggy.

Implemented instead: a new `steady_state_readout()` method that treats each
row independently — starting from `h0=0`, hold that row's own features
constant and relax the ODE toward its fixed point (`dh/dt → 0`), then read
out from the settled state. This depends only on that row's own features,
never on row order or neighboring rows, and is the *only* option consistent
with how `predict()` is actually called (a single snapshot, no history to
chain across). Used a stable implicit ("IMEX") update for the linear decay
term rather than explicit RK4 — explicit RK4 diverged to `NaN` under
realistic z-score outlier magnitudes during testing (a real risk with
market data, which routinely has multi-sigma outliers); the implicit update
is unconditionally stable regardless of decay-rate magnitude, since this
method only needs the equilibrium point, not a faithful transient
trajectory shape. Added `calibrate_readout_steady_state()` alongside it and
switched all three call sites in `AllWeatherLiquidODEModel` (calibration,
per-fold CV, and both the final production fit and `predict()`) to the new
methods. Left `integrate_trajectory()`/`calibrate_readout()` completely
unchanged, since they're correct for their real use in
`extract_liquid_features()`.

Verified with four checks: (1) order-independence — the same feature row
now gives identical output regardless of position, (2) numerical
stability — a deliberately extreme outlier input (value 500 against a
clip-and-relax pipeline) produces a finite, sane output rather than `NaN`,
(3) the model still genuinely discriminates — scaling one row's features
3× changes its prediction, so this isn't a degenerate constant, and
(4) determinism — identical input twice gives identical output.

## 5i. Checked, legitimate: `QualityCausalGARPModel`'s causal engine — plus one methodological gap

Unlike the GAT model, `PearlianCausalDiscoveryEngine`'s DirectLiNGAM
implementation is genuine and correctly wired end-to-end: the root-finding
loop (regress candidates, measure residual independence via a log-cosh
non-Gaussianity contrast, greedily pick the most-independent-residual
variable as the next causal root) matches the real DirectLiNGAM algorithm,
and `causal_proj` (the model's causal-alpha feature) is actually used in
both training and prediction, not left dangling like the GAT/patch engines.

One real methodological gap, though: DirectLiNGAM has no way to constrain
the forward-return target to be causally downstream of every feature — the
target (`"target_y"`, appended as the last column) gets placed wherever the
independence-ordering algorithm happens to put it, with no temporal
constraint enforcing "returns can't cause today's factor values." If the
(noisy) return series happens to look more "independent" than some
features, it can land earlier in the topological order than intended,
which — because the causal-adjacency matrix is strictly lower-triangular by
that order — silently produces zero detected "direct causal parents" for
that fold, with no error or warning. `_compute_invariant_causal_projection`
correctly returns zeros in that case (that part is safe), but it means the
causal-alpha feature can silently go inert depending on data-dependent
ordering behavior no one is monitoring. Not fixed — a proper fix means
adding a sink constraint to the LiNGAM ordering search itself, which is a
real algorithmic change, not a quick patch.

## 5j. Confirmed bug: overridden compliance BREACH silently indistinguishable from a clean pass — FIXED

**Severity**: High — this is a live-money-execution-path bug, not a
backtest/reporting one.

### The bug
`run_pretrade_gate()` (`optimizer_compliance.py`) — the canonical pre-trade
safety check called before real orders go to a broker — collapsed its
result to `status = "PASSED"` whenever a `BREACH`-severity violation was
bypassed via `compliance_override=True`:

```python
elif has_breach and not compliance_override:
    status = "BREACH"
else:
    status = "PASSED"    # <-- also hit when has_breach AND compliance_override
```

This makes an overridden breach byte-for-byte identical, in the `status`
field, to a portfolio with zero violations at all. Whether that's
dangerous depends entirely on whether each caller happens to separately
re-inspect the `violations` list instead of trusting `status` — I checked
both real callers:

- `optimizer_broker.py`'s `angelone_place_basket` happens to be safe: it
  logs every entry in `gate_res["violations"]` unconditionally, and
  separately checks `status in ("BREACH","PASSED")` to emit an explicit
  "proceeding despite violations" message even when status said "PASSED".
- `enterprise/connectors/unified_broker_gateway.py`'s
  `MultiDematRouter.route_rebalanced_basket` is **not** safe: it only
  branches on `status == "BLOCKED"` or `status == "BREACH" and not
  compliance_override`. With `status == "PASSED"`, neither branch fires, so
  execution fell through to the routing loop with **zero log line** and the
  final returned dict didn't even include the violations list. A
  BREACH-severity compliance violation (sector concentration, position
  limit, liquidity, banned security, etc.), when overridden, could be
  routed to real connected broker accounts with no audit trail at all.

This exact gap wasn't caught by the project's own `tests/test_round41_audit_fixes.py`
(a same-numbered, unrelated prior audit round already in this codebase) —
that test only exercises `compliance_override=False`, never the override
path.

### The fix
- `run_pretrade_gate()`: added a fourth, distinct status, `"OVERRIDDEN"`,
  for the has-breach-and-overridden case, so it can never be confused with
  a genuine `"PASSED"`.
- `angelone_place_basket`: added `"OVERRIDDEN"` to its existing
  belt-and-suspenders status tuple check (it was already safe, this just
  keeps its log message accurate under the new status name).
- `MultiDematRouter.route_rebalanced_basket`: added an explicit
  `status == "OVERRIDDEN"` branch that logs every violation and an explicit
  override warning before falling through to routing, and added
  `violations`/`warnings` to the final success-path return dict (previously
  dropped entirely, even for genuine passes).
- Verified the corrected status logic against all four cases (clean pass,
  breach without override, breach with override, block always wins
  regardless of override) — all correct, and `OVERRIDDEN` is now provably
  distinct from `PASSED`.

## 6. General code-quality notes (not bugs, for awareness)

- `optimizer.py` (8,444 lines) and `data_layer.py` (5,678 lines) each carry
  100+ `except Exception` blocks, many logging-and-continuing silently. This
  is consistent with 40 rounds of iterative patching and makes the next real
  bug easy to hide — consider tightening exception scope where feasible.
- The same helper (`sector_counts`) existing as two independent copies in
  two files is exactly how this bug went uncaught for this long — the P0-7
  fix was applied at call sites but the shared function it depended on was
  never touched. Consider deleting the `data_layer.py` copy and importing
  from `utils.py` instead, so there's one definition to fix next time.
