# Quantum Annealer — Round 43 Post-Remediation Audit & Correction Report (FINAL, merged)

**Date**: 2026-09-27
**Audited upload**: the post-antigravity tree — `Quantum_Annealer_Source_Code.zip`
(337 .py files) + `Quantum_Annealer_Audit_Fixes.zip` (14 patched files) + 5 model
zips + 4 dataset zips, all overlaid into one restored tree.
**Auditor**: GLM (Super Z) — second-pass review after the Round-41 (Claude) and
2026-09-27 institutional (GLM) audits were applied by antigravity. This report
merges and supersedes the earlier partial Round-43 draft.
**Method**: every claimed remediation from both prior audits was verified against
the delivered source (not the report); the full 58-file test suite was run as a
baseline before any change (7 failed / 676 passed / 9 skipped); every finding was
reproduced by execution before being fixed; after the fixes the full suite runs
**756 passed / 13 skipped / 0 failed**, including a new 24-test
`tests/test_round43_audit_fixes.py` regression suite, plus a 12-case behavioural
verification pass for the execution-path fixes.

---

## 1. Verification of the two prior audits' remediations

**Confirmed applied and working** (source-verified and/or covered by the passing
`tests/test_round42_audit_fixes.py`, `tests/test_round41_audit_fixes.py`):
C-1 (load-time class assertion refuses ArchWrap artifacts), C-2 (None-propagation
of dsr/oos_sharpe), C-3 router-level kill-switch gates, C-4 (OMS rejects
unpriceable orders; SEBI audit leg excludes unpriced legs), H-1 (GAT
`propagate(names=…)` alignment), H-3 (UNPRICED — HOLD), H-4 wiring (see §2.1 for
the defect INSIDE that fix), H-5 (no Ledoit-Wolf double shrinkage), M-1 (re-sync
risk deflation), M-2 (sensitivity raw-data fallback), M-3 (buying-power
denominator), M-4 (prev_close cache in `place_basket_orders`), M-5 (greedy seed
honors ENABLE_SECTOR_CAP), M-6b (SEBI category caps opt-in), AUDIT-16 STCG site,
L-1 half (DhanAdapter is a dedicated class), L-3, and the Claude Round-41 fixes
(sector-normalization family, OVERRIDDEN status, VPIN worst-ticker, kill-switch
per-order isolation, execute_differential_orders routing, steady-state
Liquid-ODE readout, LiNGAM sink constraint, PatchTST real windows, IPO
placeholder defaults).

**Claimed in the remediation tables but NOT actually in the delivered tree** —
each fixed this round:

| Claimed remediation | Delivered state found | Fix |
|---|---|---|
| AUDIT-06 (H-2): date-major CV + day-based embargo | Absent — CV still row-position embargo, no as-of dates, trainer still ticker-major | §2.12 |
| AUDIT-19 (L-2): fold-local z-scoring | Absent at the feature-normalization layer (only the model fit was fold-local) | §2.12 |
| AUDIT-15a: gateway cap = `min(MAX_WEIGHT, 10%)` | Fallback used `MAX_WEIGHT` directly → a 0.50 mandate gave the *hard gateway* a 50% cap | §2.6 |
| AUDIT-17: "18 unreachable modules quarantined to _attic" | No `_attic/`; all 15 still-unreachable modules present and exported | §2.9 |
| AUDIT-17: "CQM legacy export repaired" | `from .cqm_formulator import CQMFormulator` still named a class that never existed → export silently `None` | §2.7 |
| AUDIT-18: "DhanExecutionRouter composes DhanV2Client" | Class did not exist anywhere; `math_engine.DhanExecutionRouter` silently `None` | §2.8 |
| AUDIT-16: data_layer price-cache + PIT sites "degrade loudly" | Both still bare `except: pass` | §2.10 |
| C-3 second half (kill-switch broker-side cancel) | Present but **crashes with NameError** — see §2.13 | §2.13 |

---

## 2. Bugs found, reproduced, and fixed this round

### 2.1 CRITICAL — the AUDIT-08 wiring normalized basket weights by basket notional, not NAV (`core/broker_oms.py::submit_basket`)

The H-4 fix wired `validate_basket` into `submit_basket`, but computed
`norm_w = notional / basket_notional`. Any *partial* deployment therefore looked
like 100% concentration: the shipped `test_dhan_and_kite_basket_execution` (two
5%-of-NAV orders) read as 50%/50% and was spuriously **BLOCKED** at the 10% cap —
reproduced directly. Worse, SELL orders were aggregated as *positive* exposure,
so a pure de-risking/liquidation rebalance could be blocked by the very gate
meant to make execution safer.

**Fix**: weights are now the BUY-side notional relative to effective NAV
(falling back to basket notional only when NAV is unknown, preserving the H-4
test's full-allocation case); SELL-only baskets skip the concentration gate
entirely (liquidation cannot increase single-stock or sector concentration —
the kill switch and all per-order checks still apply to every order).
Verified: partial 10% deployment passes, genuine 50%-of-NAV single stock still
blocked, SELL-only basket passes.

### 2.2 HIGH — ₹100/share price fabrication survived in three execution-adjacent paths (AUDIT-04 class)

C-4 removed the flat ₹100 fabrication from the OMS and the SEBI audit leg, but:
`dhan_place_basket`/`zerodha_place_basket` (all four price-resolution blocks)
still used `DynamicPriceResolver.get(ticker, default=100.0)` with a ₹100
except-fallback — the fabricated price flowed into `submit_order` as `ltp`,
defeating the OMS `NO_RELIABLE_PRICE` guard **at the source**;
`enterprise/connectors/unified_broker_gateway.py` priced unpriceable order legs
at ₹100 when computing the implied weights that feed the pre-trade compliance
gate; `ui/main_window.py`'s algo preview silently priced allocation-less orders
at ₹100.

**Fix**: new shared `_resolve_order_price_honestly()` — an unpriceable ticker
is skipped with a loud warning (or excluded from implied weights) instead of
fabricated; the UI preview flags its estimate explicitly. Unpriceable held
tickers in the holdings-aware branch are left to `reconcile_portfolio_holdings`,
which already skips-and-records them (zeroing their weight would have
re-created the AUDIT-07 full-liquidation hazard — caught during the fix and
documented in the code).

### 2.3 HIGH — `DynamicPriceResolver` dual-class, dual-schema cache conflict (pre-existing, newly exposed)

`data_layer` binds `DynamicPriceResolver` to the **web_dashboard** class when
that import succeeds, or to its own fallback class when it fails (circular
import). The web class stores `{"price","time"}` dicts in `_CACHE`; the fallback
class (and every hermetic test) seeds **plain floats**. A float entry made the
web class's `get()`/`__contains__` raise `AttributeError`, silently swallowed
by every caller's except handler — historically degrading resolution all the
way to the ₹100 fabrication, and (post-C-4) to skipped orders. Reproduced:
seeded `{ITC.NS: 400.0}` → resolution returned 0.0.
**Fix**: the web resolver's `get()`/`__contains__` now read both schemas.

### 2.4 HIGH — adapter-level `execute_differential_orders` was not kill-switch gated (`math_engine/broker_router.py`)

The C-3 remediation gated `AngelOneAdapter.place_basket_orders` and the
*router-level* `execute_differential_orders` wrapper — but the **adapter-level**
§5q method (directly callable exactly the way the C-3 proof exploited) placed
orders with the kill switch engaged. Reproduced with the governance flag set.
**Fix**: in-loop gate mirroring `place_basket_orders`; verified BLOCKED rows
and zero transmissions.

### 2.5 MEDIUM — §5q method inherited the pre-fix M-4/M-17 defects and mis-reported split orders

The same new method used the schema-broken `_scrip_master` prev_close lookup
with a *silent* LTP fallback (M-4 fixed only in `place_basket_orders`), kept a
50,000-share freeze default for unknown symbols (M-17's conservative 1,000
applied only in `core/risk_gateway`), and reported the FULL order quantity
while placing only the first freeze-capped child order — the remainder was
silently dropped. **Fix**: `_prev_close_cache` with loud degradation, honest
child-quantity reporting with an explicit split note, and an env-overridable
conservative default (`QA_DEFAULT_FREEZE_QUANTITY`, default 1,000) at all three
router sites including the scrip-master loader.

### 2.6 MEDIUM — AUDIT-15a applied in the wrong direction (`core/risk_gateway.py`)

See §1. The delivered fallback (`MAX_WEIGHT`) silently removed the statutory
10% ceiling for every mandate that sets `MAX_WEIGHT`. **Fix**: explicit
`RISK_MAX_STOCK_CONCENTRATION` still wins unconditionally; otherwise the cap is
`min(MAX_WEIGHT, 10%)` — mandate-aware but never looser than the statutory
default. Verified across all four configuration shapes.

### 2.7 MEDIUM — `math_engine.CQMFormulator` silently `None` (AUDIT-17 "repaired" export not delivered)

`from .cqm_formulator import CQMFormulator` named a class that has never existed
(the module defines `QuantumCQMFormulator`), so the documented export was `None`
in every build. **Fix**: both names now export the real class.

### 2.8 MEDIUM — `math_engine.DhanExecutionRouter` silently `None` (AUDIT-18 not delivered)

The class was listed in `__all__` but never defined. **Fix**: implemented in
`broker_router.py` — composes `DhanAdapter`/`DhanV2Client`, kill-switch gated,
fails loudly without credentials, uses the OMS live-path call convention.

### 2.9 MEDIUM — AUDIT-17 quarantine not delivered

Re-derived independently (module-level import reachability over all 337 files,
cross-checked with a name-grep of every non-`__init__` reference): 15 modules
provably unreachable from the live application. Quarantined to
`math_engine/_attic/` (with a package docstring forbidding production imports);
their now-dead symbol exports were removed from `math_engine/__init__.py`.

### 2.10 MEDIUM — both AUDIT-16 data_layer priority sites still silent

OHLCV price-cache write failures and PIT fundamentals persistence failures no
longer vanish into `except: pass`; both degrade loudly with ticker/count
context (data still returned in-memory).

### 2.11 Test-suite honesty repairs (the 8 baseline failures)

| Test | Root cause | Resolution |
|---|---|---|
| `test_dhan_and_kite_basket_execution` | spurious basket-gate block (§2.1) + reliance on ₹100 fabrication (§2.2) | both code bugs fixed; test seeds real prices hermetically |
| `test_angelone_place_basket_without_signal_df_and_positive_qty` | live NSE earnings-calendar data legitimately blocking TCS/INFY near quarter-end | earnings-blackout screen stubbed off in the test (the remediation the prior audit itself recommended) |
| `test_sha256_integrity_all_five_archetype_models` | asserts load success, but the shipped artifacts are ArchWrap MLPs correctly REFUSED by the C-1 guard | sidecar integrity kept; loader behaviour asserted in whichever state the artifacts are (genuine → loads, mismatched → refused), artifact class extracted protocol-level (no torch needed) |
| `test_predict_ensemble_execution` | requires genuine models; with the honest refusal the ensemble is inert by design | pins the honest zero-alpha/empty-diag contract and skips dispersion assertions with the regeneration command in the skip reason |
| 3× `test_round33_ml_hygiene` | require the optional legacy `models/ml_alpha_model.pkl` (Round-33 era, superseded, not shipped) | `skipif`-gated on artifact presence |
| `test_r36_6_feature_cache_provenance_sidecars_complete` | feature-cache panels live in the Dataset zips | resolved by extracting the shipped dataset archives (no code change) |

**No production assertion was weakened to make a test pass.**

### 2.12 HIGH — AUDIT-06 (H-2) and AUDIT-19 (L-2) were never actually applied (ML CV leakage)

Both were claimed as delivered ("FIX-9 / source-verified") but absent from the
tree — and no shipped test covered them, which is how the gap stayed hidden:

- The trainer assembled rows **ticker-major**, so `compute_purged_embargo_cv_
  metrics`' "contiguous time folds" actually partitioned *stocks*, not time —
  train and test shared the same market regimes and calendar dates, and the
  embargo guarded ticker boundaries. The reported "OOS Sharpe/IC/DSR" was a
  cross-ticker generalization metric wearing a walk-forward costume.
- Features were z-scored on the **full sample** before CV, leaking test-fold
  feature statistics into training through the normalizer.

**Fix** (verified by 5 new tests in `tests/test_round43_audit_fixes.py`):
`compute_purged_embargo_cv_metrics` gained `as_of_dates`/`embargo_days` — rows
are stably sorted **date-major** (contiguous folds become genuine time blocks),
the embargo is applied on the **time axis in days** (every train row of any
ticker within the embargo window of the test block is purged), and
`fold_local_zscore=True` (default) re-normalizes each fold with train-fold
statistics only. The trainer collects each sample's as-of date and threads it
through all five `fit()` signatures (backward-compatible: `as_of_dates=None`
keeps the legacy row-position behaviour for existing callers).

### 2.13 CRITICAL — the kill-switch emergency broker-side cancel crashed with NameError (`core/kill_switch.py`)

The antigravity application of C-3/§5n added Dhan/Kite credential lookups
(`os.environ.get(...)`) but never imported `os` — **empirically proven**: with a
live Dhan order active, `MasterKillSwitch.activate()` logged
`Failed to cancel order …: name 'os' is not defined` — the exact emergency path
the fix was meant to enable crashed, and live orders stayed uncancelled at the
broker. The shipped tests never caught it because their mock orders carry no
`"broker"` key, so the Dhan/Kite branches never executed.

**Also fixed (same loop)**: an order at a live broker whose credentials were
unavailable (or whose Angel adapter was unauthenticated) previously skipped the
broker-side cancel *silently* and was still marked `CANCELLED` in the DB and
counted in `cancelled_orders` — recreating the exact "reports success while
live orders stay uncancelled" hazard §5n targeted. Now such orders are recorded
in `failed_orders`, logged CRITICAL ("may STILL BE LIVE at the broker"), and
their DB row is deliberately **not** flipped to CANCELLED so it stays visible
to the operator. Paper/local orders keep the original cancel-locally
behaviour. `DhanV2Client`/`KiteConnectClient` `{"success": False}` responses
mark the order failed instead of implying success.

### 2.14 LOW — four latent NameErrors (all proven by static analysis + fixed)

- `ml_alpha/retrain_now.py` — `pd.read_parquet` in the drift check, pandas
  never imported → the drift check silently never worked (NameError swallowed
  by the broad except, degrading to always-retrain).
- `workers/worker_threads.py` — `except urllib.error.HTTPError` with `urllib`
  never imported → the handler itself raised NameError, masking the real
  Telegram HTTP error.
- `web_dashboard/app.py` — `datetime.now()` in the governance/pledge persist
  block not in scope (NameError swallowed by bare `except: pass` → the caches
  were never written to disk); `profile_name` undefined in
  `send_real_telegram_single_profile_alert` (parameter is `pname`) → the
  single-profile Telegram alert path crashed.
- Missing typing names (`Optional`/`Any`/`Union`) added in `engine.py`,
  `train_archetype_models.py`, `universe_pipeline.py`, `app.py` (latent under
  `from __future__ import annotations`; now safe for `get_type_hints`/tooling).

---

## 3. Known, documented, intentionally NOT changed

1. **The five deployed archetype artifacts are still ArchWrap MLPs.** The C-1
   guard now refuses them (correct), so the MoE runs with zero active models and
   the optimizer refuses ML-alpha injection (correct). Shipping genuine
   artifacts requires retraining on live data on the trading machine:
   `python -m ml_alpha.train_archetype_models` — do NOT hand-craft replacements.
2. **`ui/main_window.py`'s KiteDirect basket placement still does not fetch
   current holdings** (Claude §5r's documented honest limit): the buy-only
   fallback fires a loud warning. Wiring it requires live Kite credentials to
   verify the holdings-response schema.
3. **Kill-switch Angel One broker-side cancel is best-effort** (an adapter
   without credentials reports `unavailable` honestly); Dhan/Kite cancels use
   env credentials.
4. **Web-dashboard display fallbacks** (`_resolve_stock_info`, depth endpoint)
   can still show a ₹100 placeholder price when every real source fails —
   display-only, never order/risk math; changing them blind risks breaking the
   dashboard rendering, so they are documented here instead.
5. The ~50 remaining broad `except Exception` handlers across
   `optimizer.py`/`data_layer.py`/`web_dashboard/app.py` (AUDIT-16's general
   note) remain — enumerated-risk sites fixed, wholesale tightening is a
   refactor decision, not a bugfix.

---

## 4. Files changed this round (23 production + 5 test)

| File | Change |
|---|---|
| `core/broker_oms.py` | NAV-relative, side-aware basket gate; SELL-only skip (§2.1) |
| `core/kill_switch.py` | `import os` + honest broker-cancel accounting (§2.13) |
| `core/risk_gateway.py` | cap = explicit → min(mandate, 10%) → 10% (§2.6) |
| `math_engine/broker_router.py` | `DhanExecutionRouter`; adapter differential kill-switch gate; prev_close cache + loud degradation; env-overridable freeze default 1,000 at all 3 sites; honest split reporting (§2.4/2.5/2.8) |
| `math_engine/__init__.py` | CQMFormulator + QuantumCQMFormulator real exports; DhanExecutionRouter import; dead-export cleanup (§2.7/2.8/2.9) |
| `math_engine/_attic/` (new) | 15 quarantined unreachable modules + package notice (§2.9) |
| `optimizer_broker.py` | `_resolve_order_price_honestly()`; dhan/zerodha fabrication removal (§2.2) |
| `enterprise/connectors/unified_broker_gateway.py` | no ₹100 in implied pre-trade weights (§2.2) |
| `data_layer.py` | OHLCV + PIT persistence loud degradation (§2.10) |
| `ui/main_window.py` | algo-preview price estimate flagged (§2.2) |
| `web_dashboard/app.py` | dual-schema resolver tolerance; datetime/`pname`/typing NameError fixes (§2.3/2.14) |
| `ml_alpha/archetype_models.py` | date-major purged CV + day-based embargo + fold-local z-scoring (§2.12) |
| `ml_alpha/train_archetype_models.py` | as-of dates collected, date-major sort, threaded into fit (§2.12) |
| `ml_alpha/ipo_model.py` | `fit(as_of_dates=…)` (§2.12) |
| `ml_alpha/retrain_now.py` | pandas import (§2.14) |
| `workers/worker_threads.py` | urllib.error import (§2.14) |
| `ml_alpha/engine.py`, `ml_alpha/universe_pipeline.py` | typing imports (§2.14) |
| `tests/test_round43_audit_fixes.py` (new) | 24-test regression suite locking every fix above |
| `tests/test_institutional_architecture.py` | hermetic price seeding |
| `tests/test_round41_audit_fixes.py` | earnings-blackout stub |
| `tests/test_round33_ml_hygiene.py` | skipif legacy artifact |
| `tests/test_regime_moe_ensemble.py` | state-aware loader/ensemble assertions |

**Final state: full suite 756 passed / 13 skipped / 0 failed** (baseline before
this round: 7 failed / 676 passed / 9 skipped on the identical environment),
12/12 behavioural execution-path checks, 24/24 new regression locks.
