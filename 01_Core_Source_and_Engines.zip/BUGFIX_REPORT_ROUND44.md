# Quantum Annealer — Round 44 Audit & Correction Report

**Date**: 2026-09-27/28
**Audited tree**: the Round-43 corrected build (`Quantum_Annealer_Round43_Corrected.zip`, 730 files / 339 `.py`).
**Auditor**: GLM (Super Z) — third-pass review. Round 43 was itself re-verified first
(baseline reproduced exactly: **756 passed / 13 skipped / 0 failed** on this machine before
any change), then a fresh audit hunted for (a) bugs the prior 43 rounds missed and (b)
defects surviving inside the Round-43 changes themselves.
**Method**: static sweep (pyflakes over all 339 files, AST bug-class scan, dependency
graph analysis) + full-suite bisection + **every finding reproduced by execution before
being fixed**. After the fixes the full suite runs **770 passed / 12 skipped / 0 failed**
(+1 test permanently un-skipped by fixing the code under it, +13 new regression locks in
`tests/test_round44_audit_fixes.py`), and the whole tree compile-checks clean.

---

## 1. Bugs found, reproduced, and fixed this round

### 1.1 HIGH — the OTM-put tail-risk warning could NEVER fire for expiry-dict chains (`optimizer_compliance.py`)

`evaluate_options_skew_warning` has two detection paths: (1) a derivatives-module path
that needs the chain as a DataFrame or a `{"chain_rows": [...]}` dict, and (2) an SVI /
heuristic fallback built for the **expiry-dict format** (`{"expiry": [{strike, imp_vol,
…}, …]}`). Path 1 returned `False` unconditionally whenever it could not parse the chain
into a DataFrame — so for every supplied expiry-dict chain the function answered
"no warning" **without ever reaching path 2**. Reproduced: a synthetic chain with a
genuinely steep OTM-put skew (max-put-IV / ATM-IV = **1.67** vs the 1.25 threshold)
returned `False`; the path-2 heuristic that should have fired was unreachable. This is
also the root cause of the perpetually-skipped `test_p2_warnings` skew test whose skip
reason said "investigate detect_skew_anomaly semantics" — that investigation is now
closed: the backend was fine, the dispatch was broken.
**Fix**: path 1 now only returns `False` when it actually *evaluated* the chain
(`chain_evaluated=True`); an unparseable chain falls through to path 2. Verified:
steep chain → `True`, flat chain → `False`, `chain_rows` chains keep their semantics.
The previously-skipping test now passes unmodified.

### 1.2 HIGH — unguarded `import markdown` crashed the ENTIRE desktop app (`ui/tabs/ai_copilot.py:15`)

`markdown` was a hard top-level import of the AI-Copilot tab, **never declared in
requirements.txt**. Because `ui/main_window.py` imports `ai_copilot` unconditionally at
its own top level, any environment without the library — including a fresh
`pip install -r requirements.txt` machine with PySide6 installed — raised
`ModuleNotFoundError` and the desktop application could not launch at all.
Reproduced in this sandbox (PyQt5/PySide6/markdown all absent → import chain dies at the
markdown line, before the Qt fallbacks are even reached).
**Fix**: the import is guarded (`markdown = None` on ImportError); both rendering call
sites already had `<pre>` fallbacks, which now activate gracefully; the deferred
`import markdown` inside `_export_ai_report` (which raised an *uncaught* ImportError)
was likewise removed in favour of the module-level optional reference. `markdown>=3.5`
is now declared in requirements.txt.

### 1.3 HIGH — circular imports silently nulled four math_engine exports under a common import order (`math_engine/latent_screener.py`, `math_engine/regime_detector.py`)

Round 43 fixed two silently-`None` exports (§2.7/§2.8) but the same disease survived in
six more names — and four of them had a *second*, deeper cause beyond wrong names:

* `latent_screener.py` did `from utils import apply_score_calibration` at module level,
  and `regime_detector.py` did `from data.price_feed import safe_download` (which pulls
  in `utils`). But `utils.py` imports `math_engine.indicators` part-way through **its
  own** module body — so whenever the import chain entered `utils` first (as it does
  when `web_dashboard.app` is imported before `math_engine`, e.g. by the very first test
  of the suite), `math_engine/__init__` ran while `utils` was partially initialized and
  both submodules failed with `ImportError: cannot import name … from partially
  initialized module 'utils'` — swallowed, leaving the exports `None` **for the whole
  process**. Proven by direct execution and by full-suite bisection (the failure order
  was reproducible and minimal: one preceding test file sufficed).

**Fix** (both edges cut): `latent_screener` now calls `apply_score_calibration` through
a deferred bridge function; `regime_detector` imports `safe_download` inside the
macro-overlay branch that uses it. Verified: importing `web_dashboard.app` before
`math_engine` now resolves every export (locked by a subprocess regression test).

### 1.4 MEDIUM — six more silently-`None` `math_engine.__all__` exports (AUDIT class of R43 §2.7/§2.8)

| Export | Delivered state | Fix |
|---|---|---|
| `ExecutionLOBEnvironment` | imported from `.rl_execution_agent` — module never existed (real module: `drl_execution_agent`) | import real `ExecutionEnv`, alias under the documented legacy name |
| `RLExecutionPolicy` | same nonexistent module | import real `PPOExecutionAgent`, alias |
| `LatentManifoldScreener` | class never existed (real: `LatentSpaceScreener`) | alias + export real name |
| `RegimeDetector` | class never existed (real: `MarketRegimeDetector`) | alias + export real name |
| `WassersteinCalibrator` | class never existed (real: `WassersteinRadiusCalibrator`) | alias + export real name |
| `QAOAPortfolioCompiler` | imported from `.qaoa_optimizer` — module AND class exist nowhere in the tree; zero references anywhere | dead export removed from `__all__`; stale "QAOA quantum circuit compilers" docstring claim removed |

Every fix follows the Round-43 precedents (§2.7 alias-the-documented-name-to-the-real-
class; §2.9 remove-provably-dead-exports). Verified: all 14 must-resolve exports (the 10
above + the 4 Round-43 ones) are real symbols; the 5 aliases point at exactly the real
classes.

### 1.5 MEDIUM — the P2-5 swallowed-exception instrumentation never logged anything (30 sites + the generator that produced them)

Every "[AUDIT-FIX P2-5] swallowed exception in {}" call passed a `{}` placeholder to
Python's **%-style** logging API — `msg % args` raised
`TypeError: not all arguments converted during string formatting` **inside the logging
framework on every single call**, so the message (and with `exc_info=True`, the entire
diagnostic traceback) was thrown away and a noise traceback printed to stderr instead.
In other words: the fix that was supposed to make swallowed exceptions *visible* was
itself silently broken at every one of its 30 sites (`utils.py` ×17, `data_layer.py`
×7, `optimizer.py` ×4, `optimizer_broker.py` ×1, `ml_alpha/engine.py` ×1). Reproduced
directly (the "Logging error" traceback, then — after the fix — the message logging
cleanly with no error).
**Fix**: all 30 sites converted to `%s`. The code **generator** that produced the
broken pattern (`scripts/sweep_except_handlers.py`, which would have re-injected the bug
into any future sweep) is fixed too.

### 1.6 MEDIUM — `AlphaEngine.__setstate__` was defined twice (`ml_alpha/engine.py`)

The class carried a minimal `__setstate__` near the top AND the complete one
(dsr/oos_sharpe restoration + the R34-12 FeatureStore relocation) near the bottom.
Python keeps only the **last** definition, so the first was dead code — a maintenance
trap where any edit to it would silently never take effect. (The surviving definition is
the complete one, so runtime behaviour is unchanged by the fix.)
**Fix**: dead first definition removed; a comment marks the single source of truth. A
regression test locks "exactly one `__setstate__`" via AST.

### 1.7 LOW — requirements.txt: two directly-imported dependencies undeclared

`markdown` (see §1.2) and `pydantic` — a hard top-level import of `ml_alpha/engine.py`,
`data_layer.py` and `enterprise/math_service.py` that was only ever satisfied
*transitively* through fastapi. Both are now declared explicitly
(`markdown>=3.5`, `pydantic>=2.0`).

### 1.8 LOW — unresolvable quoted annotation (`utils_nse.py`)

`normalize_nse_columns(df) -> "pd.DataFrame"` referenced a `pd` that is never importable
at module scope (pandas is imported inside the function by design) — a latent NameError
under `typing.get_type_hints()` and a standing static-analysis undefined-name.
**Fix**: `if TYPE_CHECKING: import pandas as pd` (no runtime cost, module load stays
pandas-free — enforced by a test that forbids a module-level pandas import there).

---

## 2. Verified-clean areas (no change needed)

These were audited this round and found sound, so the next auditor does not re-litigate them:

- **The 93 pyflakes "undefined name" warnings** in `utils_chart_pipeline.py` (89) and
  `optimizer_broker.py` (4): all documented late-binding via the end-of-file injection
  blocks — verified empirically that every name resolves at call time.
- **Round-43's own changes** (23 files diffed pre/post): the date-major purged CV
  rewrite (§2.12), the kill-switch honest accounting (§2.13), the NAV-relative basket
  gate (§2.1, one redundant-but-harmless condition noted), and the new
  `DhanExecutionRouter` (composition, credentials, kill-switch gating and the OMS
  `place_order` response contract all verified against `core/broker_oms.py`).
- **DB layer**: parameterized SQL throughout; the `orders.status` CHECK constraint
  holds against every writer; WAL + busy_timeout + atomic-write discipline intact.
- **Realized-gains ledger & tax calendar**: AY bucketing, Sec 112A grandfathering
  maths, idempotency and quarantine-on-corrupt all re-derived correctly.
- **dashboard.js** (5,343 lines, first JS audit): syntax-clean, `== null` uses are the
  correct idiom, all `JSON.parse` sites guarded, SSE/localStorage paths defensive.
- **Classic AST bug classes**: zero bare `except:`, zero mutable default arguments, no
  prod-file `is`-literal hazards (all remaining sites are fail-safe by design).
- **Timezone handling**: schedulers are IST-aware (`Asia/Kolkata` CronTrigger, pytz);
  apscheduler/pytz are deliberate soft dependencies with loud fallbacks.

## 3. Known, documented, intentionally NOT changed

1. **Dhan `securityId` is passed as the stripped ticker symbol** (e.g. `"ITC"`) in both
   the OMS live path and the new router. Dhan's v2 API documents a numeric instrument
   ID; no Dhan instrument master ships with the project, both call sites share the same
   convention, and every test mocks the client — so changing the semantics blind could
   not be verified. Resolving this needs a live Dhan instrument-master fetch on the
   trading machine.
2. **`is True` strictness on config flags** (`FORCE_REBUILD`, `ALLOW_LIVE_WITHOUT_
   PROMOTION_GATE`, `confirm_live`): values like `"true"`/`1` evaluate False — always in
   the fail-safe direction. Left as designed.
3. The ~50 broad `except Exception` handlers (R43 §3.5) remain, as do the ArchWrap
   artifact, Kite holdings-fetch, and display-only ₹100 placeholders documented in
   Round 43 §3.

---

## 4. Files changed this round (9 production + 1 script + 1 requirements + 1 test)

| File | Change |
|---|---|
| `optimizer_compliance.py` | skew-warning fall-through fix (§1.1) |
| `ui/tabs/ai_copilot.py` | guarded optional `markdown` import (§1.2) |
| `math_engine/latent_screener.py` | deferred `utils` import — circular edge cut (§1.3) |
| `math_engine/regime_detector.py` | deferred `data.price_feed` import — circular edge cut (§1.3) |
| `math_engine/__init__.py` | six exports fixed: 5 real-class aliases + dead QAOA export removed (§1.4) |
| `utils.py`, `data_layer.py`, `optimizer.py`, `optimizer_broker.py`, `ml_alpha/engine.py` | 30 P2-5 logging calls repaired to `%s` (§1.5); `ml_alpha/engine.py` also loses its dead duplicate `__setstate__` (§1.6) |
| `scripts/sweep_except_handlers.py` | generator no longer emits the broken `{}` logging pattern (§1.5) |
| `requirements.txt` | `markdown>=3.5`, `pydantic>=2.0` declared (§1.7) |
| `utils_nse.py` | TYPE_CHECKING `pd` import (§1.8) |
| `tests/test_round44_audit_fixes.py` (new) | 13-test regression suite locking every fix above |

**Final state: full suite 770 passed / 12 skipped / 0 failed** (baseline this round:
756/13/0 on the identical environment), whole-tree `compileall` clean, hostile
import-order regression locked.
