# Quantum Annealer — Round 45 Audit & Correction Report

**Date**: 2026-09-28
**Audited tree**: the Round-44 corrected build (761 entries / 340 `.py`).
**Auditor**: GLM (Super Z) — fourth-pass review. The Round-44 baseline was
reproduced exactly (**770 passed / 12 skipped / 0 failed**, clean caches, 248 s)
before any change was made.

**Method.** This round went after the layer the previous rounds could not see
with static tooling: **runtime logic in the 123 modules with zero test
references**. Three parallel deep-read passes covered 31 untested modules
(math_engine / ml_alpha / core / enterprise / qa_db), every candidate was
turned into an executable reproduction, and **all 21 findings were confirmed
by execution before a single fix was written** (probe harness:
`scripts/r45_verify.py` methodology — 21/21 reproduced pre-fix, 0/21
post-fix). Additionally 10 hardening fixes were applied to defects verified
by direct source reading (dead parameters, silent no-ops, docstring/contract
mismatches). After the fixes the full suite runs
**806 passed / 12 skipped / 0 failed** (+36 new regression locks in
`tests/test_round45_audit_fixes.py`), and the whole tree compile-checks clean.

---

## 1. Bugs found, reproduced, and fixed (21 — each with an executable repro)

### 1.1 HIGH — PSR fed the ANNUALIZED Sharpe → every portfolio reported ~99% confidence (`math_engine/master_institutional_suite.py`)

`compute_portfolio_analytics` line ~288 passed the raw annualized Sharpe to
`probabilistic_sharpe_ratio`, whose z-statistic expects the **per-period**
Sharpe (the codebase's own reference implementation and the DSR call three
lines up — which correctly de-annualizes — both document this). The z-stat
was inflated by √252 ≈ 15.9×. **Repro:** a pure-noise 250-day portfolio
(realized annualized SR = 0.15, statistically zero edge) reported
**PSR = 0.9922**; the correct value is 0.5609. Served verbatim to users by
`GET /api/portfolio_analytics`.
**Fix:** pass `sharpe_est / sqrt(252)` exactly as the DSR call already does.
Regression-locked (`test_psr_of_noise_portfolio_not_saturated`).

### 1.2 HIGH — MinBTL fed the annualized Sharpe → always clamped to the 0.1-year floor (same function)

`minimum_backtest_length` expects the daily SR; fed the annualized value the
required track record was understated ~250× and every strategy hit the
`max(0.1, …)` floor. **Repro:** SR ≈ 1.1 strategy, T=252, α=0.05 → reported
**0.10 years**; correct is **2.26 years** (a 6-week backtest would be
declared sufficient).
**Fix:** same de-annualization. Locked (`test_minbtl_not_floor_clamped`).

### 1.3 HIGH — "analytics" fabricated from hardcoded demo inputs (same function)

Six pillars of the user-facing analytics dict were computed from **literal
constants instead of the portfolio**: `information_ratio_annualized` came
from a hardcoded `[0.05, 0.08, 0.04, 0.09]` list — literally **50.05 for
every portfolio**, including loss-making ones; HMM transitions from
`[0,0,1,1,2,0,1]`; KL regime shift from `[0.7,0.2,0.1]` vs `[0.3,0.4,0.3]`;
Hawkes crash intensity from `[1.0, 5.0, 6.2, 6.8]`; Holm-Bonferroni from
`[0.01, 0.04, 0.12]`; macro Bayesian priors from invented priors and macro
values; Barra/Aladdin pillars from **unseeded** `np.random.randn` mocks
(nondeterministic `barra_factor_model_r2` across runs). **Repro:** a
strong-positive and a disaster portfolio returned the identical IR.
**Fix:** everything computable from the inputs is now computed from them —
IR from the realized active returns vs the benchmark series; HMM states from
the realized return-sign sequence; KL from the up-day/down-day return
distributions; Hawkes events from the actual sub-−2σ crash days;
Holm-Bonferroni over the real SPA p-value; Barra loadings from the top-5
eigenvectors of the sample covariance (deterministic, data-derived).
Quantities that genuinely require external data the function does not
receive (macro transmission, macro priors) are now returned as explicit
`null` with a comment — never fabricated numbers. Locked
(`test_information_ratio_reflects_portfolio`).

### 1.4 HIGH — TSRV annualized with a hardcoded 375-intraday-bars-per-day assumption → ~40× overstatement (`math_engine/two_scale_realized_vol.py` + both call sites)

`compute_tsrv`'s annualization factor `sqrt(252 * 375 / (n/subsampling_k))`
hardcoded 375 one-minute bars per day **and** carried an erroneous extra
√`subsampling_k`. Both production callers (`master_institutional_suite`,
`optimizer.py:1798`) feed it **daily closes**. **Repro:** 300 daily closes at
1.5% daily vol (true annual ≈ 23.8%) reported `tsrv_realized_vol_%` =
**968.75%**; the value flows verbatim into the user-facing
post-screening CSV ("TSRV Realized Vol %") and the optimizer signal table.
**Fix:** new `obs_per_day` parameter (default 375 preserved for genuine
intraday use), correct factor `sqrt(252 * obs_per_day / n)`, and both daily
call sites pass `obs_per_day=1.0`. Known-answer-locked for BOTH
interpretations (`test_tsrv_engine_obs_per_day_scaling`: daily series
recovered at 10–45%, a simulated 5-day 1-minute panel at 0.1%/min recovered
at 15–50% vs the true 30.7%).

### 1.5 HIGH — GNN lead-lag propagation ran in the WRONG direction — the follower got nothing, the leader got diluted (`ml_alpha/gnn_spillover.py`)

`build_empirical_leadlag_matrix` builds `adj[i,j] = corr(r_i(t-1), r_j(t))` —
"i LEADS j". The propagation `h1 = A·h0` aggregates into stock *i* the
momentum of the names **i leads** (its followers). Spillover semantics
require the opposite: propagate over incoming edges (Aᵀ). **Repro:** with
FOLLOWY = 1-day-lagged LEADERX (empirical edge 0.93) and base momenta
{LEADERX: 0.95, FOLLOWY: 0.50, UNREL: 0.50}, FOLLOWY's reported spillover
boost was **identical to the unrelated name** (zero boost); LEADERX's own
signal was diluted by its flat follower. For the empirical component (35% of
the fused graph) the published signal meant the opposite of what it claimed.
**Fix:** transpose the fused adjacency before self-loops/normalization and
propagate over the receiving graph. Locked
(`test_gnn_follower_receives_leader_momentum`).

### 1.6 HIGH — FII/DII flow factor z-scored with full-sample statistics → look-ahead leakage (`ml_alpha/alt_factors.py`)

`fii_dii_flow_factor` normalized the rolling flow by
`rolling_flow.mean()` / `.std()` — whole-series statistics including the
future. **Repro:** flows constant at −100 for 150 days with a −5000 spike in
the last 50 days: the z-score at t=150 (an observer who has seen only
constants) was **−0.57**, computed from the future spike. Any backtest with
this factor is contaminated. **Fix:** causal rolling z-score over the same
lookback (matching the correct sibling `india_factors.fii_net_flow_zscore`),
plus a whole-series degeneracy guard (constant flows still yield an honest
empty factor). Locked (`test_fii_dii_factor_is_causal`).

### 1.7 HIGH — Negative P/E and P/B clipped to the MOST BULLISH value score (`ml_alpha/alt_factors.py`)

`pe_value_factor` did `clip(lower=1.0)` on the raw multiple before inverting:
P/E = −25 (loss-making earnings — the most distressed name) became the
floor and scored **1.0** vs 0.1 for P/E = 10; P/B = −3 scored **10.0**
(100× the score of P/B = 1). Reachable in production: `engine.py` accepts
`forwardPE` (negative for expected losses) and yfinance reports negative
`priceToBook`. **Fix:** non-positive multiples masked to NaN (excluded from
the value rank). Locked (`test_negative_pe_pb_excluded_not_crowned`).

### 1.8 MEDIUM — CPCV silently dropped the most recent `T mod n_splits` observations (`math_engine/advanced_validation.py`)

`split_size = T // n_splits` left the tail out of every train AND test split
of every path. **Repro:** T=100, n_splits=6 → indices 96–99 appeared nowhere
(across all 15 paths); the suite's own call (T=250) dropped the last 10 days.
**Fix:** `np.array_split` partitions all T observations. Locked
(`test_cpcv_partitions_every_observation`).

### 1.9 MEDIUM — SPA test reseeding the PROCESS-WIDE NumPy RNG + iid bootstrap labeled "stationary" (same file)

`hansens_superior_predictive_ability` called `np.random.seed(42)` on every
invocation — the host process's global RNG stream froze to this function's
seed (verified: identical `np.random.random()` before/after). The comment
claimed a stationary bootstrap while the loop did iid row resampling
(invalid for autocorrelated returns). **Fix:** local
`np.random.default_rng(42)` and a genuine Politis-Romano stationary
bootstrap (random start + geometric block lengths, expected block ≈ 5% of
T). Same defect fixed in four more runtime paths:
`math_engine/aladdin_risk.py` (crisis replay, called by the suite),
`math_engine/wasserstein_calibrator.py` (optimizer pipeline),
`math_engine/score_diffusion_sde.py` (seeded sampling),
`ml_alpha/moe_walkforward_replay.py` + `ml_alpha/drift_monitor.py` (self-test).
Locked (`test_spa_does_not_mutate_global_rng`, `test_spa_uses_block_bootstrap`).

### 1.10 MEDIUM — VaR breach check used abs() on a signed percentile → false CRITICAL alerts on all-positive books (`math_engine/realtime_risk.py`)

The 5th-percentile return is signed; `abs(var_95) >= threshold` fired on
**positive** 5th percentiles too. **Repro:** `check_var(np.full(50, +0.10))`
— a portfolio whose every return is +10%, i.e. zero downside — emitted a
critical "VaR breach: 10.00%" alert. **Fix:** signed comparisons
(`var_95 <= -threshold`) in both `_check_risk` and `check_var`; real
breaches still fire. Locked both ways
(`test_var_no_false_breach_on_all_positive_returns`,
`test_var_fires_on_real_breach`).

### 1.11 MEDIUM — PSI silently discarded out-of-range actuals → drift systematically understated near the refit trigger (same file)

`np.histogram(actual, breakpoints)` drops actual observations outside
`[min(expected), max(expected)]` — precisely the mass that signals drift.
**Repro:** 1.5σ shift, 1000 obs/side: 9.5% of the actual mass vanished and
PSI was understated ~18% (1.89 vs 2.30 canonical) — enough to miss the 0.25
"significant shift" band boundary in production drift gates
(`ml_alpha/engine.py` feeds 100-obs windows).
**Fix:** clip actuals into the expected range (canonical edge-bin merge).
PSI now matches the reference implementation to 4 decimals. Locked
(`test_psi_counts_out_of_range_actuals`).

### 1.12 MEDIUM — feature extractor: disagreeing benchmark guards → UnboundLocalError swallowed → silent None (`ml_alpha/feature_extractor.py`)

Guard A bound `bench` only when `len(benchmark) >= len(prices)`; guard B
(20 lines later) required only `len(benchmark) > 20`. For a benchmark of
21..len(prices)−1 rows, B executed referencing an unbound `bench` — the
blanket except returned None with no log. A LONGER benchmark crashed earlier
on a broadcast. **Repro:** 60-day window + 50-day benchmark → None (a valid
128-d vector expected). **Fix:** single tail-alignment path — benchmarks
with ≥20 rows are tail-aligned to the window; unusable ones degrade to the
documented zero-benchmark mode. Locked
(`test_feature_extractor_bench_mid_length_returns_vector`).

### 1.13 MEDIUM — `inflow_breadth_20` fabricated 43 zero rows per ticker and ignored its `volume` parameter (`ml_alpha/india_factors.py`)

(a) For rows before the 63-day p65 baseline exists, `delivery_pct > NaN`
evaluates to False — a hard 0.0 ("zero accumulation-breadth days") was
fabricated for the first ~43 rows of every ticker and flowed into the factor
panel. (b) The documented volume-weighting was never implemented (parameter
accepted and ignored — the batch caller carefully passes it).
**Repro:** 100-row series → 40 exact-0.0 rows in the first 40 outputs.
**Fix:** NaN-mask pre-baseline rows; implement the documented volume
weighting (`sum(volume·above)/sum(volume)` over the window). Locked
(`test_inflow_breadth_no_fabricated_zeros`).

### 1.14 MEDIUM — `residual_momentum_6m` hedged sector exposure with a 63-day window against 126-day stock momentum (same file)

Docstring: "6-month momentum with benchmark beta and sector return removed".
The benchmark term correctly uses 21/126; the sector term used
`shift(21)/shift(63)` — a 3-month sector momentum — leaving months 3–6 of
sector exposure un-hedged in a factor designed to be sector-neutral.
**Fix:** aligned to the same 21/126 construction. Locked
(`test_residual_momentum_sector_window_126`).

### 1.15 MEDIUM — `pead_60d`'s documented binary signal was dead code (same file)

The function built a 0/1 `signal` series and never read it; the docstring
promised "Binary signal: +1 if within drift_window…" while the function
always returned the drift return since announcement. A caller following the
documented contract got different values than intended.
**Fix:** dead loop removed; docstring now describes the actual (and
point-in-time-safe) drift-return output. Locked
(`test_pead_docstring_matches_implementation`).

### 1.16 HIGH (latent) — Vault KDF salt: lazy per-instance mint with last-writer-wins → previously encrypted secrets permanently undecryptable (`enterprise/hsm_kms_vault.py`)

The PBKDF2 salt was minted on first `encrypt_secret()` and persisted with an
unconditional overwrite of the shared `~/.quantum_annealer/.vault_kdf_salt`
(non-atomic write; no existence check). **Repro (end-to-end, fresh HOME):**
two vault instances constructed before any encrypt → each minted its own
salt; the second encrypt overwrote the file; a fresh process could decrypt
instance B's blob but instance A's ciphertext raised
`RuntimeError: HSMKeyVault decrypt failed (wrong passphrase or tampered
ciphertext)`. A crash-truncated write triggered the same total loss.
**Fix:** the salt is minted EAGERLY at construction, atomically
(temp-file + `os.replace`), with a re-check that adopts any salt that
appeared concurrently. Two instances now always derive the same key. Locked
(`test_vault_salt_survives_two_instances_and_restart`).

### 1.17 HIGH — feed disconnect/connect resurrected the old worker → duplicate threads, duplicate ticks, data race (`math_engine/websocket_feed.py`)

`disconnect()` gives up after a 2-second join; `connect()` then cleared the
**shared** stop event and started a second worker — un-stopping the first.
**Repro:** `MockWebSocketClient(["TCS"], tick_interval=3.0)` → connect,
disconnect (join times out), connect → **2 live MockWSFeed threads** after
7 s (double tick dispatch; for the mock, two threads also race on
`prices[sym] *= …`). Any Angel One watchlist with >10 symbols routinely
exceeds the 2-second join. **Fix:** a fresh `threading.Event` per connect
cycle and the worker captures its own event via the target argument — a
timed-out worker can never be resurrected; zombie joins are now loudly
logged. Locked (`test_websocket_disconnect_connect_no_thread_resurrection`).

### 1.18 MEDIUM — TWAP/VWAP `intervals=0` → bare ZeroDivisionError (`enterprise/execution_algos/smart_router.py`)

Both child-order generators divided by `intervals` unguarded.
**Repro:** `generate_child_orders("TWAP", 100, 10, intervals=0)` →
`ZeroDivisionError`. **Fix:** explicit `ValueError` with a clear message.
Locked (`test_smart_router_rejects_zero_intervals`).

### 1.19 MEDIUM — Postgres pool lazy re-init was an unlocked check-then-act race (`enterprise/postgres_pool.py`)

N workers hitting a pool whose construction failed (Postgres briefly down)
each built their own `ThreadedConnectionPool` (5 eagerly-opened sockets
apiece); losers' pools were orphaned forever — a permanent connection leak
against pgBouncer. **Fix:** double-checked lazy init under a dedicated lock.
Locked (`test_postgres_pool_lazy_init_is_locked`).

### 1.20 MEDIUM — SEBI audit "tamper" alarm fired on transient DB errors (`qa_db/sebi_audit_logger.py`)

`verify_integrity`'s blanket except returned `valid: False` for ANY error —
including `sqlite3.OperationalError: database is locked` (busy timeout while
the web dashboard holds `BEGIN IMMEDIATE`) — and `__init__` logged it as
**CRITICAL "TAMPER CHECK FAILED at startup"**: a false regulatory alarm
indistinguishable from real chain corruption. **Fix:** infra errors return
`valid: None` + `error_type` + a `transient` flag, logged at WARNING as
"verification unavailable"; only a real chain violation logs CRITICAL
tampering. Locked (`test_sebi_verify_distinguishes_transient_errors`).

### 1.21 LOW — pandas 3.0 breakage: `fillna(method="ffill")` (`ml_alpha/train_archetype_models.py`)

Deprecated since pandas 2.1, **raises** in pandas 3.x (verified FutureWarning
on the pinned 2.2.3). **Fix:** `.ffill()`. Locked
(`test_train_archetype_models_no_fillna_method`).

---

## 2. Hardening fixes (verified by source-reading; same audit discipline)

1. **`ArchWrap.predict` mutated the caller's DataFrame** — added zero-filled
   feature columns in place (the sibling `UniversalAlphaEngine.predict`
   already worked on a copy). Now copies first. Locked.
2. **`StackingSuperLearner.predict` applied meta-weights positionally** — a
   differently-ordered base-prediction frame silently blended the wrong
   models. `fit` now remembers its column order; `predict` reindexes.
   Locked.
3. **`CopulaTailRiskScreener` short-history guard returned hard 0.0** — a
   6–9 day history was displayed as "ES = 0.0, no tail risk at all". Now
   returns `None` + `insufficient_history` flag; both optimizer callers
   report "insufficient data" honestly. Locked.
4. **`CacheLayer`: the advertised 2 GB byte cap was dead code**
   (`_local_bytes` never updated, `MAX_LOCAL_BYTES` never compared — only
   the 5000-entry cap ran; the docstring's OOM protection was
   half-imaginary). Byte accounting is now wired through `set()`,
   expiry-evictions and every eviction path (true deep `memory_usage` for
   DataFrames/Series). Locked functionally (tiny-cap eviction test).
5. **`CacheLayer.invalidate("")` / `clear()` in Redis mode ran FLUSHDB** —
   wiping EVERY key in the shared database (including other services' keys
   on the default `redis://…/0`), while local mode only cleared its own
   dict. Now deletes only this layer's owned namespaces via SCAN. Locked.
6. **`get_cache()` singleton was an unlocked check-then-act** — two threads
   on first call got divergent caches. Now double-checked under a module
   lock. Locked.
7. **`RayDistributedCoordinator.parallel_map` re-executed the whole batch on
   ANY Ray exception** — including business failures from the tasks
   themselves (silent double execution for side-effecting funcs, doubled
   runtime + re-raised error for pure ones; tracked in the repo worklog
   since Round 39). Ray **task** errors now propagate; only infrastructure
   failures fall back to local multiprocessing. Locked.
8. **`AppState.get_profile_result` handed out the live internal dict** (and
   `set_profile_result` stored the caller's dict by reference) — any consumer
   mutation corrupted the stored result (tracked LOW in the worklog since
   Round 37). Both directions now deep-copy. Locked.
9. **`MarketGatekeeper.evaluate_market_regime` boundary escalation** — for
   20 ≤ len < 200 bars, `sma_200` silently fell back to `sma_50`, so any dip
   below the 50-day SMA tripped the RED gate (25% sizing) with guidance
   claiming the market was "below key long-term moving averages" —
   fabricated, since no 200-day data existed. Missing long-term averages are
   now neutral (returned as `null`, cannot trigger RED); the 60-day vol
   baseline defaults to a neutral spike-ratio instead of a hardcoded 15%
   (which let a steady 16–18%-vol market trip the "vol spike" branch); an
   empty breadth universe no longer computes 0% breadth (RED on "no data").
   Locked (`test_gatekeeper_short_history_no_escalation_to_red`).
10. **`SolverCoordinator.solve_portfolio_optimization` ignored its `gamma`
    risk-aversion parameter** — `gamma=0.1` and `gamma=10.0` produced
    byte-identical weights (implicit risk aversion hardcoded at 1.0). The
    objective now scales the variance term by `gamma` as the signature
    implies. Locked.
11. **`DynamicFactorWeightEngine`: both constructor parameters were dead** —
    `lookback_days` never bounded the drift-penalty history (docstring
    promised "past 63 days"; the code used the ENTIRE series) and
    `shrinkage_lambda` was never read. Both are now honored; additionally
    the plug-in histogram mutual-information estimator gained a Miller-Madow
    bias correction — the old estimator's bias (~0.135 nats at N=300) was
    ~3× the signal of a genuine ρ≈0.29 predictor (a true factor ranked #1 in
    only 4/20 trials, chance level), laundering noise into factor weights.
    Locked.
12. **`GNNIndustrySpilloverEngine` spillover diagnostic included the softplus
    floor** — a stock with no incoming edges still reported ≈ +10.4%
    "spillover momentum". Now measured against the self-loop-only baseline;
    isolated nodes report 0.0%. Locked.
13. **`run_purged_walk_forward_backtest` was a silent no-op** — it accepted
    `purge_window`/`embargo_window` and ignored both, returning whole-sample
    buy-and-hold stats while the docstring advertised a "zero-leakage
    walk-forward backtester" (no folds existed). It now runs genuine
    sequential folds with purge gaps at boundaries, per-fold OOS stats, and
    capital-weighted aggregation. Locked.
14. **`patch_tst_engine` pocket-pivot scan off-by-one** — `range(-10, -1)`
    covered 9 prior days, not the documented 10 (and carried an always-true
    guard). Fixed to `range(-11, -1)`.
15. **Kite live feed**: double-`connect()` leaked the previous KiteTicker
    session (guard added — the polling/mock clients already had one), and
    symbols that failed instrument-token resolution were silently never
    subscribed (only a zero-mapping hard failure existed) — the unmapped
    list is now logged loudly as a WARNING.

---

## 3. Known issues intentionally NOT changed this round

1. **`optimizer.py:3163` calls `compute_dynamic_weights` with an empty
   `universe_factor_df`**, so the dynamic factor engine (HRP + RMT + MI +
   Wasserstein OT) returns equal weights in production even when
   `USE_DYNAMIC_FACTOR_WEIGHTS=True`. The engine itself is now correct, but
   wiring the real factor panel into this call site changes live portfolio
   construction and must be validated with a full retrain/backtest — not a
   silent audit change. Documented here for the next training run.
2. **`prototype_bank` bear-regime queries fall back to the bull partition**
   when no bear bank exists. The fallback order is explicitly commented as
   deliberate; changing it alters screener behavior without a revalidation
   path. Left as designed.
3. **`PPOExecutionAgent.fit` seeds `torch.manual_seed(42)` /
   `np.random.seed(42)`** — deliberate training determinism (Round 34 fix
   #4), rare entry point; left as designed.
4. The remaining broad `except` blocks (~50, mostly in UI glue) and the
   vendor minified assets are unchanged, as in prior rounds.

---

## 4. Test & verification state

| Check | Result |
|---|---|
| Baseline reproduced before any change | 770 passed / 12 skipped / 0 failed |
| Executable repro of every finding | 21/21 reproduced pre-fix |
| Post-fix probe re-run | 0/21 reproduce (all fixed) |
| New regression suite | `tests/test_round45_audit_fixes.py` — 36 tests, all passing |
| **Full suite after fixes** | **806 passed / 12 skipped / 0 failed** |
| `python -m compileall` over all touched packages | clean |

**Changed files (29):** `math_engine/` — master_institutional_suite,
two_scale_realized_vol, advanced_validation, realtime_risk, copula_risk,
market_gatekeeper, solver_coordinator, dynamic_factor_engine,
event_backtester, websocket_feed, aladdin_risk, wasserstein_calibrator,
score_diffusion_sde; `ml_alpha/` — gnn_spillover, alt_factors,
india_factors, feature_extractor, universal_engine, stacking_learner,
patch_tst_engine, drift_monitor, moe_walkforward_replay,
train_archetype_models; `core/state_manager.py`;
`enterprise/` — hsm_kms_vault, postgres_pool, cache_layer,
distributed_executor, execution_algos/smart_router;
`qa_db/sebi_audit_logger.py`; `optimizer.py`; plus the new test file.
