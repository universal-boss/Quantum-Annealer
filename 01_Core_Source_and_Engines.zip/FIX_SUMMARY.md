# Quantum Annealer — Bug Fix Changelog
**Date:** 2026-06-29
**Scope:** 72 bugs fixed across 30+ files (6 Critical, 12 High, 17 Medium, 37 Low)

## How to use this zip
1. Extract over your existing project (backup your current version first).
2. The corrected files preserve your original folder structure.
3. Run your test suite — particularly tests covering:
   - `live_verify.py` (HMM signals now emit the 4 expected keys)
   - Discovery scans (B10 fix from earlier conversation already in place)
   - LocalDB provider (C1 fix prevents destructive data overwrites)
   - ONNX inference (H7 fix may change behavior if your model uses non-default output names)

## Critical fixes (6) — stop-the-bleeding

### C1 — `data_layer.py:1208` LocalDB provider destructive seeding
**Before:** When ANY single ticker was missing from the local SQLite DB, the seeding loop iterated over ALL tickers and ran `INSERT OR REPLACE` for every one, permanently overwriting real historical OHLCV with `np.random.default_rng`-generated synthetic price walks.
**After:** Only missing tickers are seeded. Already-fetched real data is preserved in the return value.

### C2 — `enterprise/grpc_math_service.py:241` missing `import json`
**Before:** `json.load(f)` called at startup validation, but `json` was never imported → `NameError` → `sys.exit(1)` → gRPC server could not start in production.
**After:** Added `import json` to module imports.

### C3 — `enterprise/dwave_solver.py:82` diagonal covariance added as linear term
**Before:** For `dimod.Real` variables, diagonal terms `Sigma_{i,i} * w_i^2` were added with `add_linear(t_i, coeff)` (linear `coeff * w_i`) instead of `add_quadratic(t_i, t_i, coeff)` (quadratic `coeff * w_i^2`). D-Wave returned wrong portfolio weights.
**After:** Diagonal terms use `add_quadratic(t_i, t_i, coeff)`.

### C4 — `math_engine/regime_detector.py:491` missing signals keys
**Before:** `predict_regime()['signals']` only emitted `{macro_shock_applied, macro_shock_factor, kl_divergence}`. The 4 keys expected by `live_verify.py:83-90` (`ret_today_pct`, `ret_5d_avg_pct`, `vol_today_pct`, `vol_5d_avg_pct`) were absent → `KeyError` crash (the symptom you originally reported).
**After:** All 4 keys are now computed from `obs` and emitted in the signals dict.

### C5 — `data/cache_manager.py:128` + `enterprise/cache_layer.py` cache singleton mismatch
**Before:** Two separate `_DATA_CACHE` singletons existed. `live_verify.py` invalidated one; `safe_download` wrote to the other. Cache invalidation was a no-op. To make it worse, the enterprise `CacheLayer` class had neither `invalidate()` nor `clear()` methods.
**After:** `CacheLayer` now has `invalidate(prefix="")`, `clear()`, `__contains__`, and a `threading.RLock` around all local_cache operations. `cache_manager.py` re-exports the enterprise singleton so both share the same object.

### C6 — `qa_db/postgres_store.py` shared connection across all Qt worker threads
**Before:** `PostgresStore` stored a single psycopg2 connection on `self.conn` and shared it across all Qt worker threads. Concurrent transactions corrupted each other (thread A's `commit()` committed thread B's in-flight work).
**After:** Rewritten to use `enterprise.postgres_pool.DatabaseConnectionPool`. Each method leases its own connection via `with self._pool.connection() as conn:`. Added `close()` method and `__del__` for cleanup. Added `_handle_pg_failure()` that marks `_is_pg=False` on persistent failure (was silently True before).

## High fixes (12) — restore correctness

- **H1** `optimizer.py:4968` — `close_all` (undefined) → `close` (the real DataFrame). Restores 40% of breadth signal (NH/NL component).
- **H2** `data_layer.py` `fetch_pledge_reduction` — `write_json_cache` moved inside try; all-zero failure results no longer cached for the day.
- **H3** `data_layer.py` `fetch_fii_dii_flow` — added `fetch_ok` flag; cache write gated on success.
- **H4** `data_layer.py` `fetch_corp_actions_blackout` — added `return blocked` after HTTP non-200; empty `blocked` set no longer cached.
- **H5** `enterprise/cache_layer.py` — added `threading.RLock` around all `local_cache` operations (prevents TOCTOU races between concurrent batch workers).
- **H6** `data/price_feed.py:162` — guarded `pd.MultiIndex.from_product(...)` with `if not isinstance(cached_t.columns, pd.MultiIndex)` to prevent malformed 3-level index.
- **H7** `math_engine/onnx_inference.py:89` — `_output_names` dict now refreshed from `self._sess.get_outputs()` after session creation. Previously hardcoded defaults caused silent degradation to mock mode for any model with non-default output names.
- **H8** `ui/main_window.py:2792` — pre-initialized `vol_s = pd.Series(dtype=float)` before the conditional that defines it; prevents `NameError` that silently bypassed all scanner updates when `volume_df is None`.
- **H9** `ui/custom_widgets.py:713` — `QStyledItemDelegate` now imported via the binding-detection block (was hardcoded `from PySide6`, crashed app on PyQt5-only environments).
- **H10** `enterprise/grpc_math_service.py:80` — replaced `with ThreadPoolExecutor(...)` with explicit create/`future.result(timeout=...)`/`finally: shutdown(wait=False)` so the 100ms timeout isn't defeated by `__exit__`'s `shutdown(wait=True)`.
- **H11** `enterprise/connectors/fix_connector.py:83` — `_pool_get()` now detects when `db_pool.connection()` returns a context manager (DatabaseConnectionPool case), enters it, and stashes the cm in `_active_cms` for `_pool_put` to exit.
- **H12** `qa_db/postgres_store.py` — added `close()` method and `__del__`; pool explicitly closed on shutdown (was leaking server-side Postgres backend processes).

## Medium fixes (17) — fix soon

- **M3** Both `get_vix()` methods now fetch `^INDIAVIX` (was `^VIX` = US VIX) with fallback to `^VIX` on failure. India-VIX-calibrated thresholds now work correctly.
- **M4** `data/price_feed.py` — all cache keys now include `auto_adjust` (`:aa={int(auto_adjust)}` suffix).
- **M5** `data/price_feed.py:324` — single-ticker `_fetch_panel_metrics` now renames `Close` column to ticker; dict key is correct.
- **M6** `data/universe.py:64` — `pd.read_csv` on NSE EQUITY_L.csv now uses `dtype=`, `on_bad_lines="skip"`, `encoding="utf-8"`.
- **M7** `data/universe.py` — `fetch_nse_tickers` now returns `[]` when `as_of_date` requested but unavailable (was falling through to today's survivorship-biased cache).
- **M8** `math_engine/onnx_inference.py` — added warning log when single-input ONNX model detected (visual tower may be ignored).
- **M9** `math_engine/factor_risk.py:235` — `np.exp(size_col)` now wrapped in `np.clip(size_col, -20.0, 20.0)` and result clipped to `[1e-4, 1e6]` to prevent overflow → NaN propagation.
- **M10** `ui/main_window.py:795` — Telegram background thread's `QLabel.setText` calls now wrapped in `QTimer.singleShot(0, lambda: ...)` (was direct mutation from non-GUI thread).
- **M11** `ui/main_window.py:4041` — `closeEvent` now stops `LiveVerifyWorker` if running (was only waiting on OptimizerWorker).
- **M12** `ui/main_window.py:4022` — `_apply_pnl_update` now decorated with `@pyqtSlot()` (was silently no-op under PyQt5).
- **M13** `enterprise/math_service.py:102` — added `except HTTPException: raise` before generic `except Exception` so 500 status isn't re-raised as 400.
- **M14** `qa_db/postgres_store.py` — `_handle_pg_failure()` now marks `_is_pg=False` on persistent failure (was silently True, causing silent PG→SQLite degradation).
- **M15** `workers/worker_threads.py` — moved heavy imports (`utils`, `optimizer`, `safe_download`) from module top-level into the functions that need them, so spawn-context subprocesses don't re-import them.
- **M16** `data/indicators.py:62` — RSI now returns 100.0 (not NaN) for pure-uptrend stocks (Wilder's convention).
- **M17** `math_engine/regime_detector.py:525` — `emission_means` sqrt argument wrapped in `np.maximum(..., 0.0)` to prevent NaN when `alpha+beta > 1.0` (loaded model corruption case).

## Low fixes (37) — hygiene

### Dead code deleted (4 files)
- `data/pricefeed.py` (1-line shim, no importers)
- `ui/tabs/optionschain.py` (1-line shim, no importers)
- `ui/customwidgets.py` (1-line shim, no importers)
- `workers/workerthreads.py` (1-line shim, no importers)

### `data_layer.py`
- **L1** `solve_qubo_ensemble` docstring moved before early return (binds to `__doc__` now).
- **L2** `fetch_pead_scores` / `fetch_buyback_scores` hardcoded fallback dates → dynamic `(datetime.now() - timedelta(days=90)).strftime(...)`.

### `live_verify.py`
- **L3** Deleted dead variable `p_1d_vol`.

### `utils.py`
- **L4** `compute_breakout_tables._build_df` — `value or default` pattern (which converted legitimate `0.0` to NaN) replaced with explicit None checks across all 16 fields.

### `math_engine/`
- **L5** `black_litterman.py:152` — `np.linalg.eigvals` → `np.linalg.eigvalsh` (symmetric solver, real eigenvalues).
- **L6** `factor_risk.py:306` — added `logger.warning` in previously-empty `except Exception: pass` around eigh PSD projection.
- **L7** `black_litterman.py:173` — `signal_df["adv20"]` → `signal_df.get("adv20", pd.Series(1e6, index=signal_df.index))`.
- **L8** `latent_screener.py:142` — added `logger.warning` for unknown timeframes in `score_timeframe_bundle`.
- **L9** `latent_screener.py:109` — `agreement = 0.0` when `best_similarity < 1e-6` (was 1.0 = "perfect agreement" for empty match).
- **L10** `stress_tester.py:176` — `np.log(...)` wrapped in `np.maximum(..., 1e-9)` to prevent `-inf`/`NaN` for `level_pct <= -100`.
- **L11** `algo_execution.py:164` — added guard `if total_remaining <= 0: zero all pending slices; return` (was producing negative slice quantities).
- **L12** `algo_execution.py:226` — `eta = eta or self.NSE_PRIOR_ETA` → `if eta is None: eta = self.NSE_PRIOR_ETA` (was treating `eta=0.0` as falsy).
- **L13** `onnx_inference.py:109` — mock visual projection replaced with low-rank (512×4096) version + `_mock_visual_project()` helper that folds the flattened image (was 411MB per instance).
- **L14** `regime_detector.py` — added `"macro_bull_boost": 0.0` to top-level return dict (live_verify reads it).

### `data/`
- **L15** `price_feed.py:124` — retry loop now uses exponential backoff with jitter; no sleep on final attempt.
- **L16** `price_feed.py` — 4 bare `except Exception: pass` sites replaced with `log_emit` / `_log.warning` calls.
- **L18** `universe.py:52` — `_age` renamed to `_age_hours` for clarity.
- **L19** `universe.py:67` — ETF exclusion regex extended to include `NIFTY|BANKNIFTY|FINNIFTY|MIDCPNIFTY`.
- **L20** `indicators.py:6` — `max_drawdown` filters `s = s[s > 0]` after dropna (was producing nonsense values for zero/negative prices).
- **L21** `indicators.py:92` — `compute_beta` guard extended with `or benchmark_returns.empty` for symmetry.

### `ui/`
- **L23** `main_window.py:1017` — added `"Alert Log"`, `"MRC"`, `"Factor Attr."`, `"Watchlist"` to `results_tab_labels` (orphan pages now visible).
- **L24** `main_window.py` — deleted dead methods `_build_execution_params` and `_build_history_params`.
- **L25** `main_window.py:1947` — removed `importlib.reload(live_verify)` from worker thread (was racing with main thread).
- **L26** `interactive_chart.py:426` — pan guard now requires `w_chart > 0 and n_visible > 0` (prevents ZeroDivisionError).
- **L27** `interactive_chart.py:160,170,198` — added explicit `painter.end()` before early returns in `paintEvent`.
- **L28** `corporate.py:802` — removed "Both" from metric combo (was silently behaving same as "EBITDA").
- **L29** `ai_copilot.py:236` — `for future in future_to_ticker:` → `for future in as_completed(future_to_ticker):` (was blocking sequentially).

### `enterprise/`
- **L30** `grpc_math_service.py:79` — removed `TimeoutError` shadow import; simplified except clause.
- **L31** `fix_connector.py:346` — `_extract_field` now logs exceptions instead of silently returning `""`.
- **L32** `refinitiv_feed.py:62` — mutable default arg `fields=["TR.PriceClose"]` → `Optional[List[str]] = None` with `fields = fields or ["TR.PriceClose"]` inside body.
- **L33** `postgres_pool.py:88` — on rollback failure, connection now closed via `putconn(conn, close=True)` instead of being returned to pool poisoned.

### `qa_db/`
- **L34** `sqlite_store.py` — all 9 `with sqlite3.connect(...)` sites now use `contextlib.closing(sqlite3.connect(...))` so connections are deterministically closed (was relying on GC).

## Notes
- The B10 discovery-universe fallback (`data_layer.py:134`) was fixed in a prior conversation and is preserved here.
- `ui/legacy_widgets.py` (42,906 lines) is technically dead code (only reachable via `importlib.import_module` from a code path that's never triggered because `_dynamic_tab_classes = {}`), but it's left in place to avoid breaking the `importlib.import_module` call if it's ever reached. Safe to delete in a separate cleanup PR if desired.
- The defensive `.get()` fix in `live_verify.py:83-90` (applied earlier) is still in place as defense-in-depth, even though C4 now emits the correct keys.

## Verification
- All 58 remaining Python files pass `ast.parse` cleanly.
- All 6 Critical fixes verified by marker check.
- All 12 High fixes verified by marker check.
- 4 dead-code files confirmed deleted.
