# 🚀 Quantum Annealer — Partitioned GitHub Release Manifest

All zip archives below are **strictly < 20 MB** to guarantee zero-rejection upload to GitHub.

### 📌 Recommended for GLM / LLM Audit:
- **`Quantum_Annealer_01_Core_Source_and_Dashboard.zip`**: Primary file for GLM. Contains 100% of all Python modules, math engines, web dashboard, tests, and configs.
- **`Quantum_Annealer_02_Audit_Fixes_Round42.zip`**: Direct audit review package containing all 13 patched files and tests.

### 📦 All Archive Partitions (< 20 MB each):

| File Name | Size | Purpose |
|---|---|---|
| `Quantum_Annealer_01_Core_Source_and_Dashboard.zip` | **2.87 MB** | Complete source code, math engines, web app, tests (433 files) |
| `Quantum_Annealer_02_Audit_Fixes_Round42.zip` | **0.25 MB** | Dedicated Audit Fixes & Verification Suite (15 files) |
| `Quantum_Annealer_03_Artifacts_and_Embeddings.zip` | **10.74 MB** | Embeddings, ONNX models, prototype banks (129 files) |
| `Quantum_Annealer_04_FeatureCache_Part1.zip` | **13.38 MB** | Feature cache parquets batch 1/4 (70 files) |
| `Quantum_Annealer_05_FeatureCache_Part2.zip` | **14.01 MB** | Feature cache parquets batch 2/4 (70 files) |
| `Quantum_Annealer_06_FeatureCache_Part3.zip` | **16.91 MB** | Feature cache parquets batch 3/4 (70 files) |
| `Quantum_Annealer_07_FeatureCache_Part4.zip` | **13.87 MB** | Feature cache parquets batch 4/4 (66 files) |
| `Quantum_Annealer_08_Archetype_Momentum.zip` | **11.43 MB** | Archetype Neural Model (Momentum) |
| `Quantum_Annealer_09_Archetype_Quality.zip` | **11.43 MB** | Archetype Neural Model (Quality) |
| `Quantum_Annealer_10_Archetype_Defensive.zip` | **11.43 MB** | Archetype Neural Model (Defensive) |
| `Quantum_Annealer_11_Archetype_Flow.zip` | **11.43 MB** | Archetype Neural Model (Flow) |
| `Quantum_Annealer_12_Archetype_IPO.zip` | **11.43 MB** | Archetype Neural Model (IPO) |
| `Quantum_Annealer_13_DeepAlpha_Part01_of_09.zip` | **4.66 MB** | Deep Alpha Model chunk 1/9 |
| `Quantum_Annealer_13_DeepAlpha_Part02_of_09.zip` | **11.95 MB** | Deep Alpha Model chunk 2/9 |
| `Quantum_Annealer_13_DeepAlpha_Part03_of_09.zip` | **12.92 MB** | Deep Alpha Model chunk 3/9 |
| `Quantum_Annealer_13_DeepAlpha_Part04_of_09.zip` | **12.92 MB** | Deep Alpha Model chunk 4/9 |
| `Quantum_Annealer_13_DeepAlpha_Part05_of_09.zip` | **12.92 MB** | Deep Alpha Model chunk 5/9 |
| `Quantum_Annealer_13_DeepAlpha_Part06_of_09.zip` | **12.92 MB** | Deep Alpha Model chunk 6/9 |
| `Quantum_Annealer_13_DeepAlpha_Part07_of_09.zip` | **12.91 MB** | Deep Alpha Model chunk 7/9 |
| `Quantum_Annealer_13_DeepAlpha_Part08_of_09.zip` | **12.92 MB** | Deep Alpha Model chunk 8/9 |
| `Quantum_Annealer_13_DeepAlpha_Part09_of_09.zip` | **0.07 MB** | Deep Alpha Model chunk 9/9 |

### 🔄 How to Restore the Complete Project:
```bash
python3 restore_all.py ./My_Quantum_Annealer
```
