# Quantum Annealer — Round 19 Walkthrough: Display-Honesty Completion

**Session / Build ID:** `QA-R19 (2026-09-06: display-honesty completion — real technical scanner, labeled OHLCV, honest Brinson, correlation-from-history Monte Carlo)`
**Author:** GLM (Super Z)
**Date:** 2026-09-06
**Input reviewed:** `Quantum_Annealer_Round18_Corrected.zip` (deployed on Antigravity) + the independent R18 deployment verification
**Deliverable:** `Quantum_Annealer_Round19_Corrected.zip` (full corrected project)

---

## 1. Executive Summary

Round 19 closes the last chapter of the fabrication-elimination program. During the independent verification of Round 18's deployment, six residual fabrication sites were live-confirmed as having survived **both** Round 17 (Claude/Antigravity) and Round 18 (GLM). Round 19 eliminates all of them — and, during implementation, the deep sweep uncovered an entire additional display-layer fabrication family (the stock drill-down modal), two more table renderers, and a genuine serializer bug that had been silently converting every JSON boolean to `1`/`0`.

The headline changes:

1. **The Technical Scanner is now REAL.** It previously returned a hardcoded bullish panel (`BULLISH`, `ABOVE CLOUD`, `BULL CROSS (+4.5)`, adx 36.4, POC = price×0.985, Fib = price×0.965) for every holding. It now fetches real daily OHLCV bars and computes ADX-14 (Wilder), MACD (12/26/9), Supertrend (10, 3×ATR), Ichimoku (9/26/52), daily-bar volume-profile POC, 250d Fibonacci 0.618 and Camarilla R3 — reusing the already-tested `math_engine/indicators.py` implementations for MACD and volume profile. No price history → honest nulls with a refusal note.
2. **The OHLCV chart endpoint no longer serves random numbers as market data.** The synthetic random-walk fallback is now explicitly flagged `simulated: true` with a `data_source: "SYNTHETIC random-walk demonstration series — NOT market data"` label; NaN rows inside the real-data path are skipped instead of being filled with a fake ₹100 close and 100,000-share volume.
3. **Brinson attribution is measured, not invented.** Expected returns come only from real holding data; the benchmark is the measured trailing-1y ^NSEI total return; the 185/412/45/642 bps fallback fabrications are gone — zero is returned as zero, because zero is a valid Brinson result.
4. **The Monte Carlo frontier's covariance is measured.** The invented correlation matrix (same-sector 0.48, cross-sector 0.18) is replaced by correlations computed from real 2y daily log returns; missing screening inputs exclude an asset instead of silently becoming 25%/80/18/0.85 defaults; rf/erp are declared in an explicit `assumptions` block.
5. **The drill-down modal is honest.** An entire fabricated metric family (Piotroski 8, Altman 3.82, β 0.72, momentum +2.14σ, impact 3.2 bps, ₹100 price, 42.5 bps mCVaR, +18.4% Snell, 0.42 entropy, EVT 0.210/3.42, entry×0.92 disaster floor, and the HOLD_ACTIVE_ALPHA / CONTINUE_RIDE / ACTIVE_EXPANDING badges) now renders as "—" when data is missing.
6. **A real serializer bug is fixed.** Python's `bool` is a subclass of `int`, so `_send_json`'s sanitizer was converting every boolean payload value to `1`/`0` — `simulated: true` arrived as `simulated: 1`. Booleans now serialize as real JSON booleans.

**Verification:** 303 automated tests passed / 0 failed / 4 skipped (286 pre-R19 + 17 new Round 19 locks, with R16 17/17, R17 26/26 and R18 19/19 survival locks all intact). Live server smoke on port 8088 (build QA-R19): every reworked endpoint verified honest offline, TradingView fully intact, security gates intact.

---

## 2. Background: How Round 19 Was Triggered

Round 18's deployment on Antigravity was verified end-to-end (SHA-256 bundle identity, all 20 fabrication eliminations confirmed in live code, handler-level diff matching the report exactly, 286/0 tests, live smoke green). That verification also live-confirmed six residual fabrications that both prior rounds had missed:

| # | Site | What it still did |
|---|------|-------------------|
| 1 | `_handle_technical_scanner` | Hardcoded bullish signals for every ticker |
| 2 | `_handle_risk_attribution` | 24.5% default returns, flat 12% benchmark, 185/412/45/642 fallback bps |
| 3 | `_handle_ohlcv` | Random-walk bars served as market data, unlabelled; NaN→100.0 fillers |
| 4 | `_handle_monte_carlo_frontier` | Invented correlation matrix, fallback arrays, default screening inputs |
| 5 | Drill-down modal (JS) | `|| 'HOLD_ACTIVE_ALPHA'` badge + β formatting |
| 6 | `factor_tilts` interpretation | Unrounded β leaking into display strings |

Round 19 was scoped to eliminate these. During implementation, the deep sweep (the same "one layer deeper" discipline that drove R17→R18) found substantially more in the same display layer — see §4.

---

## 3. The Pattern That Kept Surviving: "One Layer Deeper"

Every round of this program has found the same class of bug one layer below the previous round's fixes:

- **R17 (Claude)** eliminated literal constants in response dicts — but the same endpoints still computed fabrications by formula (`Sharpe = max(1.85, …)`), and the chart it "honestly" re-wired was reading a still-fabricated source.
- **R18 (GLM)** eliminated the formula fabrications and the backend fallback defaults — but the JS display layer still carried its own client-side twin of every fabrication, and four backend endpoints still had hardcoded panels that no round had ever audited.
- **R19 (GLM)** eliminates the display-layer twins — the drill-down modal, the screening/consensus tables — and the last four unaudited backend endpoints.

The lesson now locked into the regression suite: **a fabrication pattern must be locked at every layer where it can appear — response dict, formula, fallback default, display default, and serializer.** The R19 test suite locks all five layers.

---

## 4. Everything Fixed in Round 19

### A. Backend (`web_dashboard/app.py`)

#### A1. `_handle_technical_scanner` — from hardcoded panel to real computation
The old handler (a "dynamic scan" in name only) printed `BULLISH`, `ABOVE CLOUD`, `BULL CROSS (+4.5)`, `adx 36.4`, `poc = px*0.985`, `fib = px*0.965` for every holding, computed from a default ₹100 price.

The new handler:
- Resolves the same holdings, then performs **one batched provider round-trip** for all tickers (`_get_price_bars_batch`) — a cold feed costs a single ~15s network timeout, not ten sequential ones (~170s), which was discovered and fixed during live smoke testing.
- Computes, per ticker, via the new module function `compute_technical_signals`:
  - **ADX(14)** — full Wilder smoothing (+DI/−DI/DX/ADX)
  - **MACD(12, 26, 9)** — reuses the tested `math_engine.indicators._calc_macd`; rendered as `ABOVE SIGNAL (+x.x)` / `BELOW SIGNAL (x.x)` (honest wording — "CROSS" would assert a crossover we don't verify)
  - **Supertrend(10, 3×ATR)** — carry-forward final-band recursion; direction + stop level
  - **Ichimoku(9/26/52)** — last close vs the cloud projected today (computed from data lagged 26 bars, as the indicator actually works): `ABOVE / INSIDE / BELOW CLOUD`
  - **Volume-profile POC** — reuses the tested `math_engine.indicators._calc_volume_profile` on daily bars
  - **Fibonacci 0.618** — of the trailing 250-bar window
  - **Camarilla R3** — standard formula on the last bar's H/L/C
- Returns `< 30 bars → None` (refusal) — it never invents a signal.
- The response carries `n_with_history`, a `data_source` provenance string, and a refusal `note` when the feed is offline.

#### A2. `_handle_risk_attribution` — measured benchmark, honest zeros
Three fabrication layers removed: the 24.5% expected-return default (assets without a real expected return are now excluded from attribution), the flat invented 12.0% benchmark (replaced by the measured trailing-1y ^NSEI total return via `_fetch_returns_panel`; feed offline → explicit refusal), and the 185/412/45/642 bps "fallback" values (replaced by `brinson_fachler_closed_form` — the same closed form, computed honestly; **zero is returned as zero** because zero is a valid Brinson result, not a failure). The response carries `benchmark_return_pct`, `n_assets_used`, and `data_source` provenance.

#### A3. `_handle_ohlcv` — labeled synthetic data, honest real data
- The synthetic random-walk fallback (kept as an offline demonstration) is now flagged **`simulated: true`** with `data_source: "SYNTHETIC random-walk demonstration series — NOT market data (price-history feed offline)"`. Real data responses carry `simulated: false` and their own provenance label.
- Inside the real-data path, rows with a NaN or non-positive close are **skipped** (previously they became ₹100 closes); NaN volumes serialize as `null` (previously 100,000).
- The `prev_c` fallback chain (`bars[-1]*0.99` / `100.0`) is gone — a single-bar series now reports an honest zero change.

#### A4. `_handle_monte_carlo_frontier` — measured covariance, declared assumptions
- The invented correlation matrix (same-sector 0.48, cross-sector 0.18) is replaced by the **measured correlation matrix of real 2y daily log returns** (via `_fetch_returns_panel`). Feed offline → explicit refusal (`simulations: []` + note) — the endpoint refuses to simulate a fabricated market.
- The fallback arrays `[0.22, 0.28, 0.19, 0.33]` / `[0.18, 0.24, 0.16, 0.28]` are deleted; fewer than 2 fully-specified assets → refusal.
- Missing screening inputs (6M return, quant score, downside vol, beta) **exclude the asset** instead of silently becoming 25.0 / 80.0 / 18.0 / 0.85.
- The CAPM+alpha expected-return model is retained but **declared** in an `assumptions` block (rf 6.5% and ERP 8.5% are labeled policy inputs; the weight sampling and its deterministic seed are declared).

#### A5. `_send_json` serializer — booleans are booleans
A genuine cross-cutting bug: `isinstance(o, (np.integer, int))` matches `bool` (a subclass of `int`), so **every boolean in every payload serialized as 1/0**. Found because the live smoke asserted `simulated is True` and received `1`. The sanitizer now checks `isinstance(o, bool)` first. This affected every boolean flag in the API surface (e.g. `telegram_dispatched`).

#### A6. Cosmetic
`factor_tilts` interpretation strings now round β to 2 decimals (`Cyclical (β=1.36)` instead of `Cyclical (β=1.3613555337904015)`). `APP_BUILD_ID` → `QA-R19` so the stale-process port detector can distinguish builds.

### B. Frontend (`web_dashboard/dashboard.js`)

#### B1. The drill-down modal — the biggest surviving fabrication family
The modal shown when clicking any portfolio row previously invented, for every missing field: Piotroski 8, Altman 3.82, β 0.72, momentum +2.14σ, Almgren-Chriss 3.2 bps, DTL 0.2d, ₹100 entry price, 6.67% optimal weight, alpha +2.10σ, 20d half-life, `ACTIVE_EXPANDING` signal state, 42.5 bps marginal CVaR, entry×0.92 "disaster floor", +18.4% Snell continuation, 0.42 Shannon entropy, 0.210 / 3.42 EVT parameters, HJB unwind days, plus `HOLD_ACTIVE_ALPHA` / `CONTINUE_RIDE` / `HOLD_CONTINUE` / `PRIME_QUALITY` / `Consensus Quant Core` badges and an invented rationale narrative ("High-conviction cross-factor leader with dominant relative strength…").

Every one of these now renders as **"—"** when the data is missing, via null-aware formatters (`fmtNum`, `dash`). The entropy classification and EVT annotations are suppressed (not fabricated) when their inputs are null. The rationale fallback is the honest "No rationale recorded for this holding."

#### B2. The technical scanner table
Null-aware cells (the old `Number(i.adx).toFixed(1)` rendered `NaN` for null), direction coloring applied only to real values, and a footnote row showing the backend's `data_source` provenance so the operator can see offline refusals directly in the UI.

#### B3. The Monte Carlo chart
Honest empty state: when the backend refuses (empty `simulations`), the chart shows an explicit label with the backend's refusal note instead of an empty-looking scatter that could be mistaken for a computed frontier.

#### B4. Screening table and consensus/profile tables
- Screening table: `Altman Z-Score || 3.5` and `Piotroski F-Score || 8` defaults → null-aware "—"; the `Primary Classification || "Consensus Quant Core"` badge → "—".
- Consensus/profile tables: the `|| 0` fake-zero family (weight, entry, Snell target, stop-loss rendered as `₹0.00`) → null-aware "—"; the classification badge → "—".

---

## 5. Verification

### 5.1 Syntax
```
py_compile web_dashboard/app.py — clean
node --check web_dashboard/dashboard.js — clean
```

### 5.2 Automated tests
```
tests/test_round19_regressions.py ................ 17 passed
Full repository suite ............ 303 passed, 4 skipped, 0 failed (313s)
   (286 pre-R19 + 17 new R19 locks;
    R16 17/17, R17 26/26, R18 19/19 survival locks all intact)
```

The 17 new locks:
- **A1/A1b** — technical scanner: no hardcoded panel / formula fabrications; must compute via `compute_technical_signals`, carry `data_source`, report coverage
- **A2** — risk attribution: no 24.5 / 0.120 / 185 / 412 / 45 / 642; benchmark must be measured; closed-form fallback required
- **A3** — OHLCV: no NaN→100.0 / NaN→100000 fillers; synthetic path must flag `simulated` and carry the SYNTHETIC label
- **A4** — Monte Carlo: no invented correlation matrix, no fallback arrays, no screening-input defaults; `assumptions` block + measured correlations required
- **A5** — the JS drill-down family (23 literal patterns) must stay gone
- **A6** — ADX cell must be null-aware
- **B1/B1b** — `compute_technical_signals` on synthetic 250-bar series: ADX bounded 0..100, Supertrend direction + finite stop, Ichimoku in {ABOVE, INSIDE, BELOW}, POC within the observed price range, finite Fib/Camarilla; < 30 bars → None
- **B2** — Brinson closed form: identical inputs → exactly zero (zero is valid); a hand-computed 2-asset case matches to the basis point (250 bps selection, 375 bps interaction, 625 bps total)
- **B3/B3b/B3c** — Wilder reference values; **bool-before-int serializer order lock**; **batch fetch wiring lock** (exactly ONE provider round-trip for N tickers; second call fully cached)
- **C1–C4** — survival: R18 patterns still gone, R17 literals still gone, R16 routes intact, TV frame + CSP + X-QA-Token gate + QA-R19 build marker intact

### 5.3 Live server smoke (port 8088, build QA-R19)
```
/api/build                     → QA-R19 build marker
(no token)                     → 401 on every gated endpoint            (W1 intact)
/api/technical_scanner         → 200, 10 tickers, ALL signal fields null,
                                 n_bars 0, n_with_history 0, refusal note (offline sandbox)
/api/ohlcv?symbol=TESTX.NS     → 200, simulated: true (real JSON boolean),
                                 data_source "SYNTHETIC random-walk demonstration series —
                                 NOT market data", 250 labeled demo bars
/api/risk_attribution          → 200, all effects null, refusal note (benchmark feed offline)
/api/monte_carlo_frontier      → 200, simulations [] (refusal), assumptions block present
/tv_frame?symbol=NSE:RELIANCE  → 200, 84,233 bytes, CSP frame-ancestors, Cache-Control no-store
/api/factor_tilts              → 200, real Z-scores (momentum +1.39σ)     (R18 intact)
/api/kelly_sizing              → 200, honest no_price_history refusals    (R16/R18 intact)
/api/dcc_garch_risk            → 200, honest UNAVAILABLE                  (R18 intact)
```

On a machine with outbound price-history access, the technical scanner and Monte Carlo frontier populate with real computed values (~5–15s on first call, then cached); every other endpoint behaves exactly as verified above.

---

## 6. Where the Files Are Located

**Changed files (Round 19):**
- `web_dashboard/app.py` — technical scanner, risk attribution, OHLCV, Monte Carlo, serializer, build marker
- `web_dashboard/dashboard.js` — drill-down modal, scanner table, MC chart, screening/consensus tables
- `tests/test_round19_regressions.py` — NEW, 17 locks
- `BUGFIX_REPORT_ROUND19.md` — the fix-by-fix catalog
- `WALKTHROUGH_ROUND19.md` — this file
- `worklog.md` — Task 25 entry

**Deliverable:**
- `Quantum_Annealer_Round19_Corrected.zip` — the complete corrected project (drop-in replacement for the workspace)

**Deployment (unchanged procedure):**
1. Stop every running dashboard process (`pkill -f web_dashboard/app.py ; pkill -f launch_web_dashboard`) — the QA-TVFIX-2 stale-process detector will also catch this and exit loudly.
2. Replace the project directory contents with the zip's contents.
3. Relaunch, then verify the live build at `http://127.0.0.1:8088/api/build` shows `QA-R19`.
4. Hard-refresh the browser (Cmd/Ctrl+Shift+R).

---

## 7. Honest Limitations (unchanged policy)

Panels that legitimately require external feeds remain honestly empty/labeled until those feeds are wired: block & bulk deals (NSE/BSE feed), sentiment/NLP filings (news provider), OFI depth (Level-2), arbitrage BSE leg (dual-exchange ticks), macro calendar, Barra-style factor decomposition, Brinson benchmark (needs ^NSEI history when offline). The stress-test shocks remain explicitly labeled beta-scaled historical-scenario approximations. The technical scanner's volume-profile POC is a daily-bar approximation (true POC needs intraday); it is labeled as such in the response provenance. The Monte Carlo expected-return model remains CAPM+screening-alpha — a declared model with declared assumptions, not a measurement.

## 8. Rating Impact

With Round 19, the "honesty" axis of the institutional-grade assessment (SR 11-7 model validation discipline: no fabricated outputs, labeled assumptions, explicit refusals, provenance on every panel) is now complete across all five layers — response dicts, formulas, fallback defaults, display defaults, and the serializer. The remaining gaps to Tier 1 are the ones that require infrastructure rather than code hygiene: point-in-time data history, execution realism (real broker fills), operational resilience (redundancy, monitoring, failover), and an immutable audit chain.
