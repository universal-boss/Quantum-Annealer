# WALKTHROUGH — Round 20
# Quantum Annealer: The Complete Journey & Current State

*GLM (Super Z) — 2026-09-09*
*Current build: **QA-R20-SOVEREIGN-TIER-OMEGA** — 323 tests passing, 20/20 live smoke green*

---

## 0. How to read this document

This is the comprehensive walkthrough of the Quantum Annealer project as it stands
after Round 20. It is written for the project owner (a hands-on operator running the
desktop app and the 9-profile sweep) and for any AI engineering assistant that will
work on the codebase next. Sections 1–3 tell the story of how the codebase evolved.
Sections 4–10 describe what the system actually does today, file by file, module by
module. Sections 11–14 are the honest residual-risk list and the recommended next
rounds. A companion document, `BUGFIX_REPORT_ROUND20.md`, contains the precise
defect-by-defect record of this round.

---

## 1. The project

**Quantum Annealer** is a locally-run, single-operator Indian-equities quant research
and portfolio-optimization workstation. In one runtime it combines:

- an NSE/NSE-scraper data layer (2,307-ticker universe, bulk/block deals, corporate
  announcements, delivery volumes, F&O ban lists, promoter pledges, PiT fundamentals);
- a 100+ module quant pipeline: 9 strategy profiles (GARP, Inst. Accumulation, Quality
  Compounders, Vol Squeeze, Risk Parity, Capital Preservation, and more), each running
  prescreen → factor construction (49+ factors) → ML-alpha blending → QUBO/quantum
  annealer portfolio optimization (D-Wave when `DWAVE_API_TOKEN` is set, simulated
  annealing otherwise) → SEBI-compliance overlay → lot-size rounding → Barra-style
  risk decomposition → OOS/WFO validation → Telegram reporting;
- a math engine with genuinely advanced quantitative machinery (see §6);
- a web dashboard (port 8088, loopback-only) with a dark trading-desk UI, TradingView
  advanced charts (proxied and ad-stripped), and ~60 API endpoints;
- a desktop launcher (`launch_desktop.py` / `launch_web_dashboard.py`).

The single most important property of this codebase — the property twenty rounds of
work have been spent defending — is **display honesty**: *every number shown to the
operator must either be computed from real data or visibly say that it isn't.*

---

## 2. The twenty-round arc (compressed)

| Round | What happened |
|-------|---------------|
| R1–R5 | Initial audits of the Antigravity-built app: security hardening (W1–W6), the first fabrication eliminations |
| R6–R14 | Progressive fabrication purge — hardcoded Sharpe floors, fake broker latencies, invented fundamentals, fabricated governance ratings, fake block deals; each round locked by regression suites that grew from ~200 to 286 tests |
| R16 | Institutional upgrades landed: Kelly sizing, factor-exposure, FF3/FF5 radar, LTTB charting, DCC-GARCH risk module, OOS policy targets — all provenance-real |
| R17 (Claude) | Partial accept/reject of my fixes; re-verified |
| R18 (GLM) | The 20-fabrication elimination bundle: energy `-16.42−n·0.25`, vol `14.8·β`, attribution 210/385/47, DTL fabrications, Barra defaults, ADV 25M, fake block deals, CONNECTED brokers, paper-order 189.22, governance AAA, pre-breakout zones — all replaced with real computation, nulls, or honest refusals. 286/0/4 tests |
| R19 (GLM) | Display-honesty completion: technical scanner computes real indicators (ADX-14 Wilder, MACD, Supertrend, Ichimoku, POC, Fib, Camarilla), Brinson-Fachler closed-form attribution (zero is a valid answer), OHLCV bars labeled `simulated: true`, Monte-Carlo frontier uses measured correlations, drill-down modal nulls, and a subtle **bool→int serializer bug** (every JSON boolean arrived as 1/0) — plus the batched provider fetch that cut scanner cold-start from ~170s to ~15s. 303/0/4 tests |
| Sep 7 (Antigravity) | **"Sovereign Tier-Ω" upgrade** on top of R19: +821 lines app.py, +756 lines dashboard.js — a real advanced-math layer (Rough Bergomi, TDA homology, causal discovery, MFG Nash execution, symplectic ODE, Score-SDE, Wasserstein DRO, MPS tensor networks, execution suite, telemetry endpoints). BUT: it also accidentally broke `data_layer.py` (two deleted if-blocks → module unimportable), re-introduced several fabrications R17/R18 had eliminated, and added new fabrication patterns of its own. The `tests/` directory was dropped from the workspace, so nothing caught any of it |
| **R20 (GLM, this round)** | **Honesty restoration on the Tier-Ω workspace**: 19 defect classes fixed (see §5), tests restored + 20 new locks, coherent CF Expected Shortfall, real block deals from local NSE history, real Kalman cointegration pairs scan, ML-alpha None-path refusal, OOS-suspicious verdict. **323/0/4 tests, 20/20 live smoke, build QA-R20** |

The recurring lesson of this arc: *every* editing session that touches this codebase —
human or AI — reintroduces fabrications unless the regression locks travel with the
code. The tests directory is now part of the delivered workspace and must stay so.

---

## 3. What "display honesty" means in this codebase

Five layers, each of which has been broken and fixed at least once:

1. **Response-dict layer** — no hardcoded plausible numbers in API responses
   (the R18/R20 eliminations).
2. **Formula layer** — computations must be real math, not pseudo-math dressed as
   named models (R20-13: the fake "Engle-Granger solver"; R20-9: swarm fed var99=2.0).
3. **Fallback-default layer** — `x or 0.85`, `else 4.25`, `else 1.85`,
   `abs(hash(ticker))%20` — defaults must be `None` + a note, never invented values.
4. **Display layer** — the frontend renders `None` as "—", never as a fabricated
   badge or zero (R19 drill-down modal; R20-16 screening table).
5. **Serializer layer** — types must survive the wire (R19's bool→int fix).

The enforcement mechanism is the `tests/test_round{6,8,13,16,17,18,19,20}_regressions.py`
suites: pattern locks scan the *live code* (docstrings/comments stripped via AST) for
fabrication patterns; behavior locks re-run the real math; survival locks verify
security and prior-round guarantees. 323 tests run in ~5 minutes.

---

## 4. Repository map (as of R20)

```
Quantum Annealer/
├── web_dashboard/           # The operator-facing app
│   ├── app.py               # 8.1k lines: HTTP server, 60+ API routes, AgenticDesktopBridge
│   ├── dashboard.js         # 4.3k lines: trading-desk UI, Tier-Ω panels, TradingView integration
│   ├── index.html / chart.umd.min.js / styles.css
├── optimizer.py             # 415k: the 9-profile pipeline, QUBO, ML-alpha, Barra risk call-sites
├── optimizer_risk.py        # Sovereign Tier-0+/Ω telemetry orchestrators, DRO/CVaR/HAR-RV
├── optimizer_broker.py      # Paper orders, broker reconciliation
├── optimizer_compliance.py  # SEBI category caps, compliance checks
├── data_layer.py            # 262k: all NSE data fetching + caches (PEAD, buybacks, bulk deals…)
├── utils.py                 # 416k: factors, WFO/OOS validation, profile configs, tax/lot logic
├── math_engine/             # 100+ quantitative modules (see §6)
│   └── institutional/       # DCC-GARCH, deflated Sharpe, LTTB, Kalman cointegration, CPCV…
├── ml_alpha/                # CatBoost/Mamba/ViT-ONNX ensemble, walk-forward, sample weights
├── enterprise/ core/ ui/    # Swarm desk, flight server, desktop UI
├── qa_db/                   # SQLite: SEBI audit trail, OOS results
├── models/                  # Trained artifacts (ml_alpha_model.pkl, ONNX dual-tower)
├── tests/                   # RESTORED IN R20 — the 323-test lock suite
├── scripts/ training/ workers/ artifacts/
└── launch_web_dashboard.py  # One-click launcher
```

---

## 5. Round 20 defect record (summary)

Nineteen defect classes were fixed; full detail in `BUGFIX_REPORT_ROUND20.md`:

**Boot-breaking:** R20-1 `data_layer.py` PEAD + Buyback if-bodies deleted → module
unimportable (restored verbatim from the R17 baseline).

**Fabrication regressions (re-introduced by the Sep-7 edit):** R20-2 block deals
(six invented institutional deals under a false NSE provenance); R20-3 governance
(hash-derived audit metrics, AA+ default, 4.25/7 defaults); R20-12 order-book depth
(ADV×0.02 bid/ask under a false Easley-O'Hara/CKS provenance — while keeping the
honest R17 docstring); R20-7 the 1.85 Sharpe floor and 0.952/0.048 DSR defaults.

**New fabrications in the Tier code:** R20-4 frontier telemetry offline constants
(68.4% RMT, 0.4215 absorption, Hawkes 0.52 "INSTITUTIONAL_ALGO_ACCUMULATION", static
DMA weights, "Active Wasserstein" claim); R20-5 unlabeled synthetic returns into
Tier-0+/Ω engines; R20-6 default portfolio + NIFTY 24500 + ₹100 price fallback;
R20-8 ML-alpha None→(0.95, 1.85) re-inflation (the log's constant "+1.85/0.9500/28%");
R20-9 swarm var99=2.0 + identity-covariance GPU Monte Carlo; R20-13 fabricated pairs;
R20-14 hardcoded tax; R20-15 hardcoded options surface.

**Mathematical bugs:** R20-10 CVaR(99%)≡VaR(99%) (incoherent Gaussian-ES at CF
quantile, hidden by a max() clamp — visible in the user's own log five times);
R20-11 one-sided OOS verdict ("Stable" for gap −5.25).

**Hygiene:** R20-16 JS fallback defaults; R20-17 DSR contradiction in the summary
line; R20-18 1-year cookie → 1-day; R20-19 tests/ restored + 20 new locks.

---

## 6. The quantitative stack (what is genuinely real)

The math layer — much of it landed by Antigravity and verified structurally this
round — is the strongest part of the system:

- **Risk**: Barra-style factor decomposition (Ledoit-Wolf/ridge-WLS covariance,
  MCR/CCR, active share, tracking error), ex-ante Cornish-Fisher VaR/ES (now with a
  coherent tail-average ES), DCC-GARCH conditional correlation, FHS-CVaR, EVT copula
  tails, CVaR/CDaR circuit breakers, HAR-RV volatility, absorption ratio.
- **Sovereign Tier-Ω (Sep 7)**: Rough Bergomi forward-variance (H≈0.10–0.14 fractional
  kernel), Vietoris-Rips persistent homology (Betti numbers, cavity collapse),
  DirectLiNGAM/Pearl do-calculus, Mean-Field Game Nash execution vs TWAP,
  Störmer-Verlet symplectic integration with energy-conservation check,
  Score-based SDE generative VaR, Sinkhorn-Wasserstein DRO on the SPD cone,
  MPS tensor-network market entanglement.
- **Validation**: walk-forward OOS with overfitting gap, Deflated Sharpe Ratio
  (multiple-testing aware), PBO-style IC pruning, CPCV, triple-barrier labeling,
  survivorship-bias estimation.
- **ML**: CatBoost + Mamba + dual-tower ViT-ONNX ensemble with DSR-gated alpha
  injection (now honestly refusing when stats are unmeasured — R20-8).

Honest caveats: several Tier-Ω telemetry panels display engine *demonstrations* on
portfolio data (e.g., the DRL-HJB execution profile evaluates a stylized 1000₹ mid /
500→1200 inventory decision) rather than live microstructure. They are computed and
labeled, but treat them as model exhibits, not measurements of your actual orders.

---

## 7. Security model (current, post-R20)

- **W5**: binds `127.0.0.1:8088` only — no remote connections possible.
- **W4**: Host header must be the local dashboard host (DNS-rebinding defense).
  Verified live: `Host: evil.example.com` → 403.
- **CSRF**: cross-site Origin → 403 (verified live).
- **W1 (evolved)**: session-token gate with three accepted credentials — the HttpOnly
  cookie (auto-healed seamlessly for the local operator), the `X-QA-Token` header
  (non-browser clients), or loopback auto-authorization with a valid local Host
  header. This is a deliberate UX trade-off made on Sep 7; given W4/W5/CSRF, the
  residual exposure is limited to other local processes, which the on-disk token
  never defended against anyway. Documented, kept, and the cookie lifetime was cut
  from 1 year to 1 day (R20-18).
- **W2**: constant-time token comparison throughout.
- **W3**: HttpOnly, SameSite cookie.

---

## 8. The 9-profile sweep (what your log showed)

The uploaded log (`quantum_annealer_log_2026-09-08_19_46_19.txt`) is a healthy
333-minute, 9/9-profile run: universe 2,307 → prescreen 636–761 → ~100-ticker factor
models → QUBO optimization → SEBI/lot-size overlays → Barra risk → OOS → Telegram
dispatch → post-screening intelligence CSV/HTML. Non-fatal items were handled honestly
(NSE bulk-deal 503 → skip with message; F&O throttle → cached signal reuse).

What the log ALSO revealed — and what Round 20 fixed at the code level:

1. `CVaR (99%): 67.28% | VaR (99%): 67.28%` (and four more identical pairs) → R20-10.
2. `OOS Sharpe=+1.85 | DSR=0.9500 | weight=28%` identical on every profile → R20-8.
3. `IS Sharpe=-0.32 | OOS Sharpe=4.93 | Gap=-5.25 | Verdict: Stable` → R20-11.
4. `Inst-DSR … Verdict=FAIL` vs `DSR: 95.4% … Swarm: PROCEED` → R20-9 + R20-17.

---

## 9. How to run

```bash
cd "Quantum Annealer"
python3 launch_web_dashboard.py        # boots 127.0.0.1:8088, opens browser

# Run the full regression suite (5 minutes, 323 tests):
python3 -m pytest tests/ -q

# Run just the honesty locks:
python3 -m pytest tests/test_round20_regressions.py -q
```

Operational tips: the bulk-deal/block-deal panel populates from the local
`~/.quantum_annealer_pro_v17/bulk_deals_raw_history.json` that sweeps maintain — run
a sweep first on a fresh machine. `DWAVE_API_TOKEN` in `.env` switches the QUBO
solver from simulated annealing to the quantum hybrid. The ML-alpha model auto-loads
from `models/ml_alpha_model.pkl`.

---

## 10. Endpoint honesty map (post-R20)

| Panel | Status |
|-------|--------|
| Technical scanner | REAL indicators from price history; nulls offline |
| Risk attribution | Brinson-Fachler closed-form; honest zeros |
| OHLCV chart | Real bars; `simulated: true` when synthetic |
| Block deals | Real local NSE history or honest empty |
| Governance | Real Altman/Piotroski/pledge; null audit fields |
| Frontier/Tier-0/Ω telemetry | Real engines; SYNTHETIC-labeled inputs offline; honest UNAVAILABLE |
| Execution suite | Real ladders/VWAP/baskets from holdings; NO_HOLDINGS otherwise |
| Tail risk / DCC-GARCH | Real FHS/DCC computation or UNAVAILABLE refusal |
| Kelly / factor tilts | Real Z-scores from holdings history |
| Order book / pairs / tax / options | Nulls + notes (feeds not wired); pairs = real Kalman scan when history exists |
| Paper orders | Require a real price — 400 otherwise |
| OOS backtest | Real returns panel; no floors; OOS-Suspicious flag |
| Macro intermarket | Labeled static long-run reference |
| TradingView | Full proxy, CSP + no-store, ad-stripped |

---

## 11. Honest residual risk list (priority order)

1. **The OOS anomaly is structural, not cosmetic.** Every profile: negative IS,
   positive OOS (gap −4.5 to −5.3). R20-11 flags it, but the root cause — window
   design, selection bias (OOS evaluated on the already-selected 15-ticker
   portfolio), IS/OOS cost asymmetry, or the 12%/yr benchmark fill — needs a
   dedicated audit round. Until then, do not trust OOS Sharpe / "Net Alpha 27–66%
   ann." magnitudes; trust the DSR FAIL verdicts, which are honest.
2. **Regime inconsistency**: three different regime labels can appear in one run
   (overlay "Bear P=0.95", ChartV3 "bear", summary "Bull"). Different estimators,
   different lookbacks — needs one canonical regime source.
3. **Unpopulated honest panels**: options surface, tax optimizer, auditor-fee/
   related-party governance fields — all correctly null, waiting for feeds.
4. **Profile label**: `ProfileCashOverlay Profile=Default` doesn't echo the active
   strategy profile name.
5. **Process risk**: this round proves edits can silently revert locked behaviors —
   run `pytest tests/ -q` after ANY workspace edit, and never ship without it.

---

## 12. Recommended Round 21

1. **OOS walk-forward audit**: instrument `compute_oos_validation` with window
   diagnostics (IS/OOS date ranges, cost treatment per side, benchmark-fill counts),
   evaluate OOS on the pre-selection universe (not the selected 15), and re-derive
   the Net Alpha / FactorAttr chain from the corrected series.
2. **Canonical regime service**: one regime estimator (HMM or the market gatekeeper)
   consumed by overlay, ChartV3, TrendGuard, and the summary line.
3. **Wire the honest panels**: NSE option-chain → options surface + GEX cross-check;
   broker lot export → tax optimizer; MCA filings → governance audit fields.
4. **Tier-Ω input realism**: replace the DRL-HJB stylized demo inputs (1000₹ mid,
   500→1200 inventory) with the actual primary holding's price/size.
5. **CI**: a GitHub Action running the 323-test suite on every push (`.github/`
   already exists in the workspace).

---

## 13. Deliverables of this round

- **`Quantum_Annealer_Round20_Corrected.zip`** — the full corrected workspace
  (source + math engine + ML + models + qa_db + tests + docs), build
  QA-R20-SOVEREIGN-TIER-OMEGA.
- **`BUGFIX_REPORT_ROUND20.md`** — the defect-by-defect record (this file's §5,
  expanded).
- **`WALKTHROUGH_ROUND20.md`** — this document.
- Updated `worklog.md` (Task ID: R20) appended to the project worklog.

## 14. One-paragraph summary

The Sovereign Tier-Ω workspace you uploaded contained a genuinely impressive new
quantitative layer — and, underneath it, two accidentally-deleted code blocks that
prevented the app from booting, a full regression of the block-deal/order-book/pairs
fabrications that Rounds 17–19 had eliminated, a handful of new fabrication patterns
in the telemetry offline paths, and a missing test suite that let all of it through
silently. Round 20 repaired the boot, removed every re-introduced and newly-invented
fabrication (19 defect classes), made the Expected Shortfall mathematically coherent,
taught the ML-alpha path to refuse injection when its statistics are unmeasured, made
the OOS verdict two-sided, restored the 323-test lock suite with 20 new locks, and
verified everything live: 323/0/4 tests, 20/20 smoke checks, TradingView and the
security gates intact. The remaining honest gap is structural, not cosmetic: the
in-sample/out-of-sample evaluation windows produce suspiciously favorable OOS results
across all profiles, now flagged but not yet root-caused — that is the recommended
Round 21.
