"""
core/broker_oms.py
==================
Event-Driven Broker Order Management System (OMS) & Execution Engine.

Replaces static text generators with active order lifecycle tracking and native
broker API execution clients:
  - Dhan HQ (Dhan API v2: /v2/orders, /v2/holdings)
  - Zerodha Kite Connect (Kite REST API: /orders/regular, /portfolio/holdings)
  - Angel One SmartAPI v2
  - Institutional Paper Execution Simulator with realistic micro-slippage

Every order transitions through a formal state machine:
  PENDING_RISK ➔ RISK_APPROVED ➔ SUBMITTED ➔ FILLED / REJECTED / CANCELLED

Protected by the HardPreTradeRiskGateway before submission and audited by the TCAEngine upon fill.
"""
from __future__ import annotations

import json
import logging
import random
import time
import uuid
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

import requests

from core.db_engine import get_db
from core.kill_switch import MasterKillSwitch
from core.risk_gateway import HardPreTradeRiskGateway, RiskViolationError
from core.tca_engine import TCAEngine

logger = logging.getLogger("quantum_annealer.broker_oms")


# ── Broker API Clients ───────────────────────────────────────────────────────

class DhanV2Client:
    """Native Dhan HQ API v2 client for direct execution."""

    BASE_URL = "https://api.dhan.co/v2"

    def __init__(self, client_id: str, access_token: str):
        self.client_id = client_id
        self.access_token = access_token
        self.headers = {
            "access-token": self.access_token,
            "client-id": self.client_id,
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    def place_order(
        self,
        security_id: str,
        exchange_segment: str,
        transaction_type: str,
        quantity: int,
        order_type: str = "MARKET",
        price: float = 0.0,
        trigger_price: float = 0.0,
        product_type: str = "CNC",
    ) -> Dict[str, Any]:
        """Submit single order to Dhan v2 order gateway."""
        url = f"{self.BASE_URL}/orders"
        payload = {
            "dhanClientId": self.client_id,
            "correlationId": f"QA-{uuid.uuid4().hex[:10]}",
            "transactionType": transaction_type.upper(),
            "exchangeSegment": exchange_segment.upper(),
            "productType": product_type.upper(),
            "orderType": order_type.upper(),
            "validity": "DAY",
            "securityId": str(security_id),
            "quantity": int(quantity),
            "price": float(price) if order_type.upper() == "LIMIT" else 0.0,
            "triggerPrice": float(trigger_price) if "SL" in order_type.upper() else 0.0,
        }
        try:
            resp = requests.post(url, json=payload, headers=self.headers, timeout=10)
            data = resp.json()
            if resp.status_code in (200, 201, 202) and data.get("orderStatus") in ("PENDING", "TRANSIT", "ACCEPTED"):
                return {"success": True, "order_id": data.get("orderId"), "raw": data}
            return {"success": False, "error": data.get("message", resp.text), "raw": data}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def cancel_order(self, order_id: str) -> Dict[str, Any]:
        """Cancel working order via Dhan v2."""
        url = f"{self.BASE_URL}/orders/{order_id}"
        try:
            resp = requests.delete(url, headers=self.headers, timeout=10)
            data = resp.json()
            return {"success": resp.status_code == 200, "raw": data}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def fetch_holdings(self) -> List[Dict[str, Any]]:
        """Fetch current equity holdings from Dhan."""
        url = f"{self.BASE_URL}/holdings"
        try:
            resp = requests.get(url, headers=self.headers, timeout=10)
            if resp.status_code == 200:
                return resp.json()
            return []
        except Exception:
            return []


class KiteConnectClient:
    """Native Zerodha Kite Connect API client."""

    BASE_URL = "https://api.kite.trade"

    def __init__(self, api_key: str, access_token: str):
        self.api_key = api_key
        self.access_token = access_token
        self.headers = {
            "X-Kite-Version": "3",
            "Authorization": f"token {self.api_key}:{self.access_token}",
        }

    def place_order(
        self,
        tradingsymbol: str,
        exchange: str,
        transaction_type: str,
        quantity: int,
        order_type: str = "MARKET",
        price: float = 0.0,
        product: str = "CNC",
    ) -> Dict[str, Any]:
        """Submit order to Zerodha Kite Connect."""
        url = f"{self.BASE_URL}/orders/regular"
        data = {
            "tradingsymbol": tradingsymbol.upper(),
            "exchange": exchange.upper(),
            "transaction_type": transaction_type.upper(),
            "order_type": order_type.upper(),
            "quantity": int(quantity),
            "product": product.upper(),
            "validity": "DAY",
        }
        if order_type.upper() == "LIMIT" and price > 0:
            data["price"] = str(price)

        try:
            resp = requests.post(url, data=data, headers=self.headers, timeout=10)
            res = resp.json()
            if res.get("status") == "success":
                return {"success": True, "order_id": res.get("data", {}).get("order_id"), "raw": res}
            return {"success": False, "error": res.get("message", resp.text), "raw": res}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def cancel_order(self, order_id: str) -> Dict[str, Any]:
        """Cancel order in Kite."""
        url = f"{self.BASE_URL}/orders/regular/{order_id}"
        try:
            resp = requests.delete(url, headers=self.headers, timeout=10)
            res = resp.json()
            return {"success": res.get("status") == "success", "raw": res}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def fetch_holdings(self) -> List[Dict[str, Any]]:
        """Fetch holdings from Kite."""
        url = f"{self.BASE_URL}/portfolio/holdings"
        try:
            resp = requests.get(url, headers=self.headers, timeout=10)
            res = resp.json()
            if res.get("status") == "success":
                return res.get("data", [])
            return []
        except Exception:
            return []


# ── Order Management System ──────────────────────────────────────────────────

class BrokerOrderManagementSystem:
    """Event-driven Order Management System with pre-trade risk and post-trade TCA."""

    def __init__(self, cfg: Optional[Dict[str, Any]] = None):
        self.cfg = cfg or {}
        self.db = get_db()
        self.risk_gateway = HardPreTradeRiskGateway(self.cfg)
        self.tca_engine = TCAEngine()

    def submit_order(
        self,
        broker: str,
        symbol: str,
        side: str,
        qty: int,
        price: float = 0.0,
        order_type: str = "MARKET",
        ltp: Optional[float] = None,
        decision_price: Optional[float] = None,
        dry_run: bool = True,
        credentials: Optional[Dict[str, str]] = None,
        adv: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Validate pre-trade risk, persist order, execute, and record TCA."""
        order_id = f"ORD-{uuid.uuid4().hex[:12].upper()}"
        creds = credentials or {}
        p_dec = decision_price if decision_price and decision_price > 0 else (ltp or price or 0.0)
        p_arr = ltp if ltp and ltp > 0 else (price if price > 0 else p_dec)
        if p_arr <= 0:
            self.db.update_order_status(
                order_id=order_id,
                status="REJECTED",
                rejection_reason="No reliable price available (LTP fetch failed) — refusing to fabricate fill price",
            )
            return {
                "success": False,
                "order_id": order_id,
                "status": "REJECTED",
                "reason": "NO_RELIABLE_PRICE: refusing to simulate at a fabricated price",
            }

        # 1. Record initial PENDING_RISK state in ACID database
        self.db.record_order(
            order_id=order_id,
            broker=broker,
            symbol=symbol,
            side=side,
            qty=qty,
            order_type=order_type,
            price=price,
            status="PENDING_RISK",
        )

        # 2. Hard Pre-Trade Risk Gateway Evaluation
        is_approved, rejection_reason = self.risk_gateway.validate_order(
            symbol=symbol,
            side=side,
            qty=qty,
            price=price,
            ltp=ltp,
            order_type=order_type,
        )

        if not is_approved:
            self.db.update_order_status(
                order_id=order_id,
                status="REJECTED",
                rejection_reason=rejection_reason,
            )
            return {
                "success": False,
                "order_id": order_id,
                "status": "REJECTED",
                "reason": rejection_reason,
            }

        # 3. Transition to RISK_APPROVED
        self.db.update_order_status(order_id=order_id, status="RISK_APPROVED")

        # 4. Route to Execution Engine (Live or Paper)
        if dry_run or broker.lower() in ("paper", "simulation"):
            # Simulated execution with realistic micro-slippage (± 2 to 5 bps)
            slippage_factor = 1.0 + (random.uniform(0.0002, 0.0005) if side.upper() == "BUY" else -random.uniform(0.0002, 0.0005))
            fill_price = round(p_arr * slippage_factor, 2)

            self.db.update_order_status(
                order_id=order_id,
                status="FILLED",
                filled_qty=qty,
                avg_fill_price=fill_price,
            )

            # Compute and persist TCA
            tca_metrics = self.tca_engine.analyze_and_record_trade(
                order_id=order_id,
                symbol=symbol,
                side=side,
                qty=qty,
                decision_price=p_dec,
                arrival_price=p_arr,
                execution_price=fill_price,
                adv=adv,
            )

            return {
                "success": True,
                "order_id": order_id,
                "status": "FILLED",
                "mode": "PAPER",
                "filled_qty": qty,
                "avg_fill_price": fill_price,
                "tca": tca_metrics,
            }

        # Live Broker Execution
        if broker.lower() == "dhan_hq":
            client = DhanV2Client(
                client_id=creds.get("DHAN_CLIENT_ID", ""),
                access_token=creds.get("DHAN_ACCESS_TOKEN", ""),
            )
            resp = client.place_order(
                security_id=symbol.replace(".NS", ""),
                exchange_segment="NSE_EQ",
                transaction_type=side,
                quantity=qty,
                order_type=order_type,
                price=price,
            )
        elif broker.lower() == "zerodha_kite":
            client = KiteConnectClient(
                api_key=creds.get("KITE_API_KEY", ""),
                access_token=creds.get("KITE_ACCESS_TOKEN", ""),
            )
            resp = client.place_order(
                tradingsymbol=symbol.replace(".NS", ""),
                exchange="NSE",
                transaction_type=side,
                quantity=qty,
                order_type=order_type,
                price=price,
            )
        else:
            resp = {"success": False, "error": f"Unsupported live broker '{broker}'"}

        if resp.get("success"):
            broker_order_id = resp.get("order_id", order_id)
            self.db.update_order_status(
                order_id=order_id,
                status="SUBMITTED",
            )
            return {
                "success": True,
                "order_id": order_id,
                "broker_order_id": broker_order_id,
                "status": "SUBMITTED",
                "mode": "LIVE",
            }
        else:
            err = resp.get("error", "Unknown broker error")
            self.db.update_order_status(
                order_id=order_id,
                status="REJECTED",
                rejection_reason=err,
            )
            return {
                "success": False,
                "order_id": order_id,
                "status": "REJECTED",
                "reason": err,
            }

    def submit_basket(
        self,
        broker: str,
        orders: List[Dict[str, Any]],
        total_nav: float,
        dry_run: bool = True,
        credentials: Optional[Dict[str, str]] = None,
        log_cb: Optional[Callable[[str], None]] = None,
    ) -> Dict[str, Any]:
        """Execute a basket of orders sequentially through the OMS."""
        _emit = log_cb or (lambda m: None)
        _emit(f"[OMS] Initiating basket execution of {len(orders)} orders via {broker} (dry_run={dry_run})...")

        # ── Basket-Level Pre-Trade Risk Gate ─────────────────────────────────
        # AUDIT-FIX (Round 43): the original wiring of this gate normalized each
        # order's notional by the TOTAL BASKET NOTIONAL (v / _basket_notional),
        # not by portfolio NAV. That made any partial deployment look like 100%
        # concentration: a 2-order basket deploying 10% of NAV read as 50%/50%
        # and was spuriously BLOCKED at the 10% single-stock cap (verified: the
        # dhan/zerodha dry-run regression test failed exactly this way). It also
        # counted SELL orders as *positive* exposure, so a pure de-risking /
        # liquidation rebalance could be blocked by the very gate meant to make
        # execution safer. Fixed: (a) weights are now the basket's BUY-side
        # notional relative to effective NAV (falls back to basket notional only
        # when NAV is unknown), so a basket deploying X% of NAV is evaluated as
        # X%; (b) SELL-only baskets skip the concentration gate entirely —
        # liquidation cannot increase single-stock or sector concentration
        # (the kill switch and per-order checks still apply to every order).
        if orders:
            buy_notional: Dict[str, float] = {}
            has_sell = False
            for ord_spec in orders:
                sym_t = ord_spec.get("ticker", ord_spec.get("symbol", ""))
                q_val = int(ord_spec.get("qty", ord_spec.get("shares", 0)))
                p_val = float(ord_spec.get("ltp", ord_spec.get("price", 0.0)))
                _side = str(ord_spec.get("side", "BUY")).upper()
                if sym_t and q_val > 0 and p_val > 0:
                    if _side == "SELL":
                        has_sell = True
                    else:
                        buy_notional[sym_t] = buy_notional.get(sym_t, 0.0) + (q_val * p_val)

            _basket_notional = sum(buy_notional.values())
            effective_nav = total_nav if total_nav > 0 else _basket_notional
            if buy_notional and _basket_notional > 0 and not (has_sell and not buy_notional):
                norm_w = {k: v / effective_nav for k, v in buy_notional.items()}
                basket_check = self.risk_gateway.validate_basket(
                    weights=norm_w,
                    total_nav=effective_nav,
                    sector_map=self.cfg.get("_SECTOR_MAP") or self.cfg.get("sector_map"),
                    available_cash=self.cfg.get("AVAILABLE_BUYING_POWER", self.cfg.get("AVAILABLE_MARGIN")),
                )
                if basket_check.get("status") == "BLOCKED":
                    violations = basket_check.get("violations", [])
                    _emit(f"[OMS] ⛔ Basket execution BLOCKED by pre-trade risk gateway ({len(violations)} violations)")
                    for v in violations:
                        _emit(f"[OMS]    - {v.get('rule')}: {v.get('message')}")
                    return {
                        "total_orders": len(orders),
                        "executed_count": 0,
                        "rejected_count": len(orders),
                        "executed": [],
                        "rejected": [{
                            "symbol": o.get("ticker", o.get("symbol", "")),
                            "status": "BLOCKED",
                            "reason": "PORTFOLIO_RISK_LIMIT_BREACH"
                        } for o in orders],
                        "mode": "PAPER" if dry_run else "LIVE",
                        "blocked_by": "PORTFOLIO_RISK_GATE",
                        "violations": violations,
                    }

        executed = []
        rejected = []

        for ord_spec in orders:
            sym = ord_spec.get("ticker", ord_spec.get("symbol", ""))
            side = ord_spec.get("side", "BUY")
            qty = int(ord_spec.get("qty", ord_spec.get("shares", 0)))
            px = float(ord_spec.get("price", ord_spec.get("ltp", 0.0)))
            ltp = float(ord_spec.get("ltp", px))
            dec_px = float(ord_spec.get("decision_price", ltp))

            if qty <= 0:
                continue

            res = self.submit_order(
                broker=broker,
                symbol=sym,
                side=side,
                qty=qty,
                price=px,
                ltp=ltp,
                decision_price=dec_px,
                dry_run=dry_run,
                credentials=credentials,
            )

            if res.get("success"):
                executed.append(res)
                st = res.get("status", "SUBMITTED")
                px_info = f"@ ₹{res.get('avg_fill_price'):.2f} " if res.get("avg_fill_price") and st == "FILLED" else ""
                _emit(f"[OMS] ✅ {sym}: {side} {qty:,} {px_info}[{st}]")
            else:
                rejected.append(res)
                _emit(f"[OMS] ❌ {sym}: REJECTED — {res.get('reason')}")

        return {
            "total_orders": len(orders),
            "executed_count": len(executed),
            "rejected_count": len(rejected),
            "executed": executed,
            "rejected": rejected,
            "mode": "PAPER" if dry_run else "LIVE",
        }
