"""
core/db_engine.py
=================
Production ACID Transactional Database Engine.

Implements SQLite Write-Ahead Logging (WAL) mode with strict ACID guarantees,
thread safety, connection timeouts, and relational integrity. Replaces
corruptible flat JSON state files for institutional-grade reliability.

Schema:
  - orders: Complete Order Management System (OMS) state machine records.
  - trades_tca: Perold (1988) Implementation Shortfall & execution slippage audit.
  - risk_audit_log: Pre-trade risk rule evaluations, blocks, and breaches.
  - system_governance: Persistent Kill Switch flags, statutory ceilings, overrides.
  - portfolio_history: Historical optimized allocations, NAV marks, and regimes.
"""
from __future__ import annotations

import json
import logging
import os
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Generator, List, Optional, Tuple, Union

logger = logging.getLogger("quantum_annealer.db_engine")

_PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_DB_PATH = _PROJECT_ROOT / "qa_db" / "institutional_orders.db"

_DB_LOCK = threading.RLock()


class TransactionalDBEngine:
    """Thread-safe, ACID-compliant database manager operating in SQLite WAL mode."""

    _instance: Optional["TransactionalDBEngine"] = None
    _singleton_lock: threading.Lock = threading.Lock()

    def __init__(self, db_path: Optional[Union[str, Path]] = None) -> None:
        self.db_path = Path(db_path) if db_path else DEFAULT_DB_PATH
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    @classmethod
    def get_instance(cls, db_path: Optional[Union[str, Path]] = None) -> "TransactionalDBEngine":
        """Singleton accessor for application-wide database engine."""
        if cls._instance is None:
            with cls._singleton_lock:
                if cls._instance is None:
                    cls._instance = cls(db_path)
        return cls._instance

    @contextmanager
    def connection(self) -> Generator[sqlite3.Connection, None, None]:
        """Lease a database connection with WAL mode and atomic transaction management."""
        with _DB_LOCK:
            conn = sqlite3.connect(
                str(self.db_path),
                timeout=15.0,
                check_same_thread=False,
                isolation_level="DEFERRED",
            )
            conn.row_factory = sqlite3.Row
            try:
                cursor = conn.cursor()
                cursor.execute("PRAGMA journal_mode = WAL;")
                cursor.execute("PRAGMA synchronous = NORMAL;")
                cursor.execute("PRAGMA foreign_keys = ON;")
                cursor.execute("PRAGMA busy_timeout = 15000;")
                cursor.close()
                yield conn
                conn.commit()
            except Exception as e:
                conn.rollback()
                logger.error(f"[DBEngine] Transaction rollback due to error: {e}")
                raise
            finally:
                conn.close()

    def _init_db(self) -> None:
        """Create tables and indexes with institutional schema."""
        with self.connection() as conn:
            cursor = conn.cursor()

            # 1. Orders table (OMS)
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS orders (
                order_id TEXT PRIMARY KEY,
                broker TEXT NOT NULL,
                symbol TEXT NOT NULL,
                exchange TEXT DEFAULT 'NSE',
                side TEXT NOT NULL CHECK(side IN ('BUY', 'SELL')),
                order_type TEXT DEFAULT 'MARKET' CHECK(order_type IN ('MARKET', 'LIMIT', 'SL', 'SL-M')),
                qty INTEGER NOT NULL CHECK(qty > 0),
                price REAL DEFAULT 0.0,
                trigger_price REAL DEFAULT 0.0,
                status TEXT NOT NULL CHECK(status IN (
                    'PENDING_RISK', 'RISK_APPROVED', 'SUBMITTED',
                    'PARTIALLY_FILLED', 'FILLED', 'REJECTED', 'CANCELLED'
                )),
                filled_qty INTEGER DEFAULT 0,
                avg_fill_price REAL DEFAULT 0.0,
                rejection_reason TEXT,
                idempotency_key TEXT UNIQUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            """)

            cursor.execute("CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_orders_symbol ON orders(symbol);")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_orders_created ON orders(created_at);")

            # 2. Trades & Transaction Cost Analysis (TCA)
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS trades_tca (
                tca_id TEXT PRIMARY KEY,
                order_id TEXT NOT NULL,
                symbol TEXT NOT NULL,
                side TEXT NOT NULL CHECK(side IN ('BUY', 'SELL')),
                qty INTEGER NOT NULL,
                decision_price REAL NOT NULL,
                arrival_price REAL NOT NULL,
                execution_price REAL NOT NULL,
                slippage_bps REAL NOT NULL,
                delay_bps REAL NOT NULL,
                total_shortfall_bps REAL NOT NULL,
                market_impact_bps REAL DEFAULT 0.0,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE
            );
            """)

            cursor.execute("CREATE INDEX IF NOT EXISTS idx_tca_symbol ON trades_tca(symbol);")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_tca_order ON trades_tca(order_id);")

            # 3. Pre-Trade Risk Audit Log
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS risk_audit_log (
                log_id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                rule_name TEXT NOT NULL,
                severity TEXT NOT NULL CHECK(severity IN ('BLOCK', 'BREACH', 'WARN')),
                ticker TEXT,
                attempted_value REAL,
                limit_value REAL,
                message TEXT NOT NULL,
                action_taken TEXT NOT NULL CHECK(action_taken IN ('REJECTED', 'OVERRIDDEN', 'WARNED'))
            );
            """)

            cursor.execute("CREATE INDEX IF NOT EXISTS idx_risk_severity ON risk_audit_log(severity);")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_risk_rule ON risk_audit_log(rule_name);")

            # 4. System Governance & Master Kill Switch
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS system_governance (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_by TEXT DEFAULT 'SYSTEM',
                reason TEXT
            );
            """)

            # Default kill switch to INACTIVE / ARMED
            cursor.execute("""
            INSERT OR IGNORE INTO system_governance (key, value, updated_at, updated_by, reason)
            VALUES ('KILL_SWITCH_ACTIVE', '0', CURRENT_TIMESTAMP, 'SYSTEM', 'Initial system startup');
            """)

            # 5. Portfolio Snapshots History
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS portfolio_history (
                run_id TEXT PRIMARY KEY,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                profile_name TEXT NOT NULL,
                nav REAL NOT NULL,
                holdings_json TEXT NOT NULL,
                regime TEXT,
                alpha_scores_json TEXT
            );
            """)
            cursor.close()

    # ── Order Methods ────────────────────────────────────────────────────────

    def record_order(
        self,
        order_id: str,
        broker: str,
        symbol: str,
        side: str,
        qty: int,
        order_type: str = "MARKET",
        price: float = 0.0,
        trigger_price: float = 0.0,
        status: str = "PENDING_RISK",
        idempotency_key: Optional[str] = None,
        exchange: str = "NSE",
    ) -> bool:
        """Insert a newly formulated order into the database."""
        with self.connection() as conn:
            cursor = conn.cursor()
            now_iso = datetime.utcnow().isoformat()
            cursor.execute(
                """
                INSERT INTO orders (
                    order_id, broker, symbol, exchange, side, order_type,
                    qty, price, trigger_price, status, idempotency_key,
                    created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    order_id, broker, symbol.upper(), exchange, side.upper(),
                    order_type.upper(), qty, price, trigger_price, status,
                    idempotency_key, now_iso, now_iso
                )
            )
            return True

    def update_order_status(
        self,
        order_id: str,
        status: str,
        filled_qty: Optional[int] = None,
        avg_fill_price: Optional[float] = None,
        rejection_reason: Optional[str] = None,
    ) -> bool:
        """Update order lifecycle status and fill telemetry."""
        with self.connection() as conn:
            cursor = conn.cursor()
            now_iso = datetime.utcnow().isoformat()
            updates = ["status = ?", "updated_at = ?"]
            params: List[Any] = [status, now_iso]

            if filled_qty is not None:
                updates.append("filled_qty = ?")
                params.append(filled_qty)
            if avg_fill_price is not None:
                updates.append("avg_fill_price = ?")
                params.append(avg_fill_price)
            if rejection_reason is not None:
                updates.append("rejection_reason = ?")
                params.append(rejection_reason)

            params.append(order_id)
            sql = f"UPDATE orders SET {', '.join(updates)} WHERE order_id = ?"
            cursor.execute(sql, params)
            return cursor.rowcount > 0

    def get_order(self, order_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve single order by order_id."""
        with self.connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM orders WHERE order_id = ?", (order_id,))
            row = cursor.fetchone()
            return dict(row) if row else None

    def get_active_orders(self) -> List[Dict[str, Any]]:
        """Retrieve all currently active/working orders."""
        with self.connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                SELECT * FROM orders
                WHERE status IN ('PENDING_RISK', 'RISK_APPROVED', 'SUBMITTED', 'PARTIALLY_FILLED')
                ORDER BY created_at DESC
                """
            )
            return [dict(r) for r in cursor.fetchall()]

    def get_orders_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Retrieve recent order history."""
        with self.connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM orders ORDER BY created_at DESC LIMIT ?", (limit,))
            return [dict(r) for r in cursor.fetchall()]

    # ── TCA Methods ──────────────────────────────────────────────────────────

    def record_tca(
        self,
        tca_id: str,
        order_id: str,
        symbol: str,
        side: str,
        qty: int,
        decision_price: float,
        arrival_price: float,
        execution_price: float,
        slippage_bps: float,
        delay_bps: float,
        total_shortfall_bps: float,
        market_impact_bps: float = 0.0,
    ) -> bool:
        """Persist execution transaction cost analysis."""
        with self.connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO trades_tca (
                    tca_id, order_id, symbol, side, qty,
                    decision_price, arrival_price, execution_price,
                    slippage_bps, delay_bps, total_shortfall_bps,
                    market_impact_bps, timestamp
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    tca_id, order_id, symbol.upper(), side.upper(), qty,
                    decision_price, arrival_price, execution_price,
                    slippage_bps, delay_bps, total_shortfall_bps,
                    market_impact_bps, datetime.utcnow().isoformat()
                )
            )
            return True

    def get_tca_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Retrieve recent TCA records."""
        with self.connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM trades_tca ORDER BY timestamp DESC LIMIT ?", (limit,))
            return [dict(r) for r in cursor.fetchall()]

    # ── Risk Audit Methods ───────────────────────────────────────────────────

    def log_risk_event(
        self,
        rule_name: str,
        severity: str,
        message: str,
        ticker: Optional[str] = None,
        attempted_value: Optional[float] = None,
        limit_value: Optional[float] = None,
        action_taken: str = "REJECTED",
    ) -> int:
        """Record a pre-trade risk rule intervention."""
        with self.connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO risk_audit_log (
                    rule_name, severity, ticker, attempted_value,
                    limit_value, message, action_taken, timestamp
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    rule_name, severity, ticker, attempted_value,
                    limit_value, message, action_taken, datetime.utcnow().isoformat()
                )
            )
            return cursor.lastrowid

    def get_risk_logs(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Retrieve recent risk gate audit logs."""
        with self.connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM risk_audit_log ORDER BY timestamp DESC LIMIT ?", (limit,))
            return [dict(r) for r in cursor.fetchall()]

    # ── Governance & Kill Switch Methods ─────────────────────────────────────

    def set_governance_value(
        self,
        key: str,
        value: str,
        updated_by: str = "OPERATOR",
        reason: Optional[str] = None,
    ) -> bool:
        """Update or insert a system governance parameter."""
        with self.connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO system_governance (key, value, updated_at, updated_by, reason)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(key) DO UPDATE SET
                    value = excluded.value,
                    updated_at = excluded.updated_at,
                    updated_by = excluded.updated_by,
                    reason = excluded.reason
                """,
                (key, value, datetime.utcnow().isoformat(), updated_by, reason)
            )
            return True

    def get_governance_value(self, key: str, default: Optional[str] = None) -> Optional[str]:
        """Fetch system governance parameter."""
        with self.connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT value FROM system_governance WHERE key = ?", (key,))
            row = cursor.fetchone()
            return row["value"] if row else default


# Global module-level convenience function
def get_db(db_path: Optional[Union[str, Path]] = None) -> TransactionalDBEngine:
    """Return the global transactional database instance."""
    return TransactionalDBEngine.get_instance(db_path)
