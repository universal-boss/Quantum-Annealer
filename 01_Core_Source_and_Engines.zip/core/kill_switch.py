"""
core/kill_switch.py
===================
Master Hardware & Software Emergency Kill Switch.

Provides an atomic, persistent, fail-closed kill switch mechanism.
When triggered:
  1. Instantly sets a persistent lock in the ACID database.
  2. Cancels all pending/active orders across the Order Management System (OMS).
  3. Halts running background optimization processes.
  4. Intercepts and rejects 100% of outgoing order attempts at the Pre-Trade Risk Gateway.
  5. Produces an immutable regulatory audit trail.
"""
from __future__ import annotations

import logging
import os
from datetime import datetime
from typing import Any, Dict, Optional

from core.db_engine import get_db

logger = logging.getLogger("quantum_annealer.kill_switch")


class MasterKillSwitch:
    """Atomic, persistent emergency kill switch for institutional risk management."""

    @classmethod
    def is_active(cls) -> bool:
        """Check if the global emergency kill switch is currently engaged."""
        try:
            db = get_db()
            val = db.get_governance_value("KILL_SWITCH_ACTIVE", default="0")
            return str(val).strip() in ("1", "true", "TRUE", "yes")
        except Exception as e:
            # FAIL-CLOSED: If the governance database cannot be read, assume kill switch is active for safety
            logger.critical(f"[KillSwitch] Database read failure — FAILING CLOSED (active=True): {e}")
            return True

    @classmethod
    def get_status(cls) -> Dict[str, Any]:
        """Return comprehensive telemetry and audit history of the kill switch."""
        try:
            db = get_db()
            with db.connection() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT * FROM system_governance WHERE key = 'KILL_SWITCH_ACTIVE'")
                row = cursor.fetchone()
                if row:
                    active = str(row["value"]).strip() in ("1", "true", "TRUE", "yes")
                    return {
                        "active": active,
                        "state": "TRIGGERED" if active else "ARMED",
                        "updated_at": row["updated_at"],
                        "updated_by": row["updated_by"],
                        "reason": row["reason"],
                    }
        except Exception as e:
            logger.error(f"[KillSwitch] Failed to fetch status: {e}")

        # Safe fallback
        return {
            "active": cls.is_active(),
            "state": "TRIGGERED" if cls.is_active() else "ARMED",
            "updated_at": datetime.utcnow().isoformat(),
            "updated_by": "SYSTEM",
            "reason": "System telemetry read",
        }

    @classmethod
    def activate(
        cls,
        reason: str = "Operator manual emergency stop",
        operator: str = "OPERATOR",
    ) -> Dict[str, Any]:
        """Engage the emergency kill switch: cancel active orders and freeze execution."""
        db = get_db()
        now_iso = datetime.utcnow().isoformat()
        logger.critical(f"🛑 [KILL SWITCH ACTIVATED] By {operator}: {reason}")

        # 1. Persist lock in database. This is the mechanism is_active() and
        # every pre-trade gate actually check, so new orders are blocked the
        # moment this line succeeds, independent of what happens below.
        db.set_governance_value(
            key="KILL_SWITCH_ACTIVE",
            value="1",
            updated_by=operator,
            reason=reason,
        )

        # 2. Cancel all active orders in database.
        # BUGFIX (Round 41): previously, a single db.update_order_status()
        # failure partway through the loop raised out to the outer except,
        # silently abandoning every remaining order in the list with no
        # record of which ones were never attempted — and regardless of any
        # of this, the function always returned "status": "SUCCESS", which
        # the web console (web_dashboard/app.py's kill-switch endpoint)
        # forwards verbatim to the operator. An operator hitting this literal
        # emergency-stop button could see "SUCCESS" while some live orders
        # were never cancelled, with nothing in the response to indicate it.
        # Fixed: each order is now cancelled in its own try/except so one
        # failure doesn't abort the rest, failures are tracked separately
        # from successes, and the returned status is downgraded from
        # "SUCCESS" to "PARTIAL" (fetch step failed) or
        # "SUCCESS_WITH_ORDER_ERRORS" (fetch succeeded, some cancellations
        # didn't) whenever anything went wrong — never silently "SUCCESS".
        cancelled_orders = []
        failed_orders = []
        fetch_error = None
        try:
            active_orders = db.get_active_orders()
        except Exception as e:
            fetch_error = str(e)
            active_orders = []
            logger.error(f"[KillSwitch] Failed to fetch active orders — cannot verify all live orders are cancelled: {e}")

        for o in active_orders:
            order_id = o["order_id"]
            broker_order_id = o.get("broker_order_id") or order_id
            broker_name = str(o.get("broker") or "").lower()
            # ROUND-43 FIX (R1a): the Dhan/Kite branches below read broker API
            # credentials from os.environ, but `os` was never imported — the
            # emergency-cancel path raised NameError('os') for every live Dhan/
            # Kite order, so those orders were never cancelled broker-side.
            # ROUND-43 FIX (R1b): honesty of the cancel accounting. Previously,
            # an order at a live broker whose credentials were unavailable (or
            # whose Angel adapter was not authenticated) skipped the broker-
            # side cancellation silently and was STILL marked CANCELLED in the
            # local DB and counted in cancelled_orders — recreating exactly the
            # "reports success while live orders stay uncancelled" hazard that
            # Round-41 §5n was meant to eliminate. Now: if a live-broker order
            # cannot be cancelled broker-side, it is recorded in
            # failed_orders, logged CRITICAL, and its local DB row is left in
            # its active state (so it stays visible to the operator) instead of
            # being marked CANCELLED without confirmation.
            try:
                # Attempt broker-side cancellation for live working orders.
                # broker_cancel_state: "none" = local/paper order, no live
                # broker side to cancel; "confirmed" = broker-side cancel
                # attempted; "unavailable" = live broker order but no
                # credentials/adapter — broker side NOT cancelled.
                broker_cancel_state = "none"
                if broker_name in ("dhan", "dhan_hq", "dhanhq"):
                    client_id = os.environ.get("DHAN_CLIENT_ID", "")
                    access_token = os.environ.get("DHAN_ACCESS_TOKEN", "")
                    if client_id and access_token:
                        from core.broker_oms import DhanV2Client
                        r = DhanV2Client(client_id, access_token).cancel_order(str(broker_order_id))
                        if isinstance(r, dict) and r.get("success") is False:
                            raise RuntimeError(f"Dhan API refused cancellation: {r.get('error') or r.get('raw')}")
                        broker_cancel_state = "confirmed"
                    else:
                        broker_cancel_state = "unavailable"
                elif broker_name in ("kite", "zerodha", "zerodha_kite"):
                    api_key = os.environ.get("KITE_API_KEY", "")
                    access_token = os.environ.get("KITE_ACCESS_TOKEN", "")
                    if api_key and access_token:
                        from core.broker_oms import KiteConnectClient
                        r = KiteConnectClient(api_key, access_token).cancel_order(str(broker_order_id))
                        if isinstance(r, dict) and r.get("success") is False:
                            raise RuntimeError(f"Kite API refused cancellation: {r.get('error') or r.get('raw')}")
                        broker_cancel_state = "confirmed"
                    else:
                        broker_cancel_state = "unavailable"
                elif broker_name in ("angel", "angelone", "angel_one"):
                    from math_engine.broker_router import AngelOneAdapter
                    adapter = AngelOneAdapter()
                    if hasattr(adapter, "_smart_api") and adapter._smart_api is not None:
                        adapter._smart_api.cancelOrder(str(broker_order_id), "NORMAL")
                        broker_cancel_state = "confirmed"
                    else:
                        broker_cancel_state = "unavailable"

                if broker_cancel_state == "unavailable":
                    # Live broker order that could NOT be cancelled broker-side.
                    # Keep the DB row in its active state so the order remains
                    # visible in active-order queries, and report it as failed.
                    failed_orders.append(order_id)
                    logger.critical(
                        f"[KillSwitch] Broker-side cancellation NOT POSSIBLE for {broker_name} order "
                        f"{order_id} (credentials/adapter unavailable) — the order may STILL BE LIVE "
                        f"at the broker. Local status intentionally NOT marked CANCELLED. Manual intervention required."
                    )
                    continue

                db.update_order_status(
                    order_id=order_id,
                    status="CANCELLED",
                    rejection_reason=f"Emergency Kill Switch Activated: {reason}",
                )
                cancelled_orders.append(order_id)
            except Exception as e:
                failed_orders.append(order_id)
                logger.error(f"[KillSwitch] Failed to cancel order {order_id}: {e} — the order may still be live at the broker")

        if cancelled_orders:
            logger.warning(f"[KillSwitch] Cancelled {len(cancelled_orders)} active orders: {cancelled_orders}")
        if failed_orders:
            logger.critical(f"[KillSwitch] FAILED to cancel {len(failed_orders)} active orders: {failed_orders} — manual intervention required")

        if fetch_error:
            activation_status = "PARTIAL"
        elif failed_orders:
            activation_status = "SUCCESS_WITH_ORDER_ERRORS"
        else:
            activation_status = "SUCCESS"

        # 3. Halt running background optimization threads if present
        try:
            from web_dashboard.app import AgenticDesktopBridge
            if hasattr(AgenticDesktopBridge, "STOP_EVENT"):
                AgenticDesktopBridge.STOP_EVENT.set()
                AgenticDesktopBridge.TASK_STATUS = "STOPPED"
                AgenticDesktopBridge.log(f"🛑 [KILL SWITCH] Background task halted by emergency kill switch: {reason}")
        except Exception:
            pass

        # 4. Log regulatory risk event
        db.log_risk_event(
            rule_name="GLOBAL_KILL_SWITCH",
            severity="BLOCK",
            message=f"Kill switch engaged by {operator}: {reason}. Cancelled orders: {len(cancelled_orders)}"
                     + (f". FAILED to cancel: {failed_orders}" if failed_orders else "")
                     + (f". Could not fetch active orders: {fetch_error}" if fetch_error else ""),
            action_taken="REJECTED",
        )

        return {
            "status": activation_status,
            "active": True,
            "state": "TRIGGERED",
            "cancelled_orders": cancelled_orders,
            "failed_to_cancel_orders": failed_orders,
            "order_fetch_error": fetch_error,
            "timestamp": now_iso,
            "reason": reason,
            "operator": operator,
        }

    @classmethod
    def deactivate(
        cls,
        reason: str = "Operator manual reset and clearance",
        operator: str = "OPERATOR",
    ) -> Dict[str, Any]:
        """Disarm the emergency kill switch and restore normal trading readiness."""
        db = get_db()
        now_iso = datetime.utcnow().isoformat()
        logger.info(f"🟢 [KILL SWITCH DISARMED] By {operator}: {reason}")

        # 1. Clear lock in database
        db.set_governance_value(
            key="KILL_SWITCH_ACTIVE",
            value="0",
            updated_by=operator,
            reason=reason,
        )

        # 2. Log regulatory risk event
        db.log_risk_event(
            rule_name="GLOBAL_KILL_SWITCH",
            severity="WARN",
            message=f"Kill switch disarmed by {operator}: {reason}. Normal execution resumed.",
            action_taken="WARNED",
        )

        return {
            "status": "SUCCESS",
            "active": False,
            "state": "ARMED",
            "timestamp": now_iso,
            "reason": reason,
            "operator": operator,
        }
