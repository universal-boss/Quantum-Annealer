"""
core/realized_gains_ledger.py
=============================
Realized-Gains Ledger for Indian capital-gains tax set-off modeling.

AUDIT-FIX (Round 24 — R24-5): the R23-5 disclosure honestly stated that the
tax engine modeled neither carried-forward losses nor the LTCG exemption
slab, because "implementing them needs a realized-gains ledger that the
journal does not yet record." This module IS that ledger. TradeJournalManager
now records every realized close (TARGET_HIT / STOPPED_OUT / CLOSED) here as
a structured gain/loss event with dates, prices, weight and P&L; the tax
engine consumes the ledger to apply the real Section 70/74 set-off rules and
the Rs 1,25,000 LTCG exemption (Finance (No. 2) Act 2024) instead of
assuming every harvested loss is instantly and fully offsettable.

Indian tax rules modeled here (flat-rate engine, see the R25-5 additions
below for surcharge/cess/regime detail in the consuming engine):
  * STCL (holding < 365d) may be set off against STCG AND LTCG in the same
    assessment year, in that order (Sec 70 + 74(1)).
  * LTCL (holding >= 365d) may be set off ONLY against LTCG (Sec 70(3)) —
    a long-term loss can never reduce short-term gains.
  * Unabsorbed losses carry forward: 8 assessment years for both STCL
    (Sec 70(3)/74) and LTCL (Sec 74(1)) — no speculative-loss 4-year rule
    applies to listed-equity capital losses.
  * LTCG exemption: the first Rs 1,25,000 of NET LTCG (after all set-offs)
    per assessment year is tax-free; 12.5% applies above it. STCG has no
    exemption slab and is taxed at 20% on the net figure.

AUDIT-FIX (Round 25 — R25-5): trade-date convention + Sec 112A
grandfathering + the Jul-2024 rate-regime split are now recorded/aggregated
HERE at the ledger level:
  * HOLDING-PERIOD BASIS (Sec 2(42A)): classification and AY bucketing use
    the TRADE date (the journal contract date). Settlement (T+1) is
    irrelevant — a close executed on the last trading day of a FY belongs
    to THAT FY even though cash settles in the next. Disclosed via the
    `holding_period_basis` key on every net_gains_by_category result.
  * REGIME SPLIT: exit dates before/on 23-Jul-2024 are taxed under the OLD
    regime (Sec 111A STCG 15%, Sec 112A LTCG 10% above Rs 1L) and after it
    under the Finance (No. 2) Act 2024 regime (20% / 12.5% above Rs 1.25L).
    The ledger aggregates a `regime_split` breakdown per category so the
    engine can apply per-tranche rates (the consuming engine discloses the
    allocation convention when both tranches are non-empty).
  * GRANDFATHERING (Sec 112A(2)): lots acquired BEFORE 1-Feb-2018 get the
    deemed-cost step-up — cost per share = max(actual cost, min(FMV on
    31-Jan-2018, sale price)) — when the caller supplies an FMV valuation
    record (`fmv_31jan2018` dict). No feed -> no adjustment, disclosed (the
    cfg key TAX_FMV_31JAN2018 is the integration point).
"""
from __future__ import annotations

import json
import logging
import os
import tempfile
import threading
import time
import numpy as np
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any, Union

logger = logging.getLogger(__name__)

LEDGER_FILE = Path(__file__).resolve().parent.parent / "qa_db" / "realized_gains.json"

_LEDGER_LOCK = threading.Lock()

# ── AUDIT-FIX (Round 25 — R25-5): Indian tax calendar constants ──
# Finance (No. 2) Act 2024 rate change: transfers BEFORE this date are taxed
# under the old regime (STCG 15% / LTCG 10% above Rs 1L); on/after it under
# the new regime (STCG 20% / LTCG 12.5% above Rs 1.25L).
TAX_REGIME_CUTOFF_DATE = "2024-07-23"
# Sec 112A(2) grandfathering: acquisitions BEFORE this date get the deemed
# cost step-up (higher of actual cost and the 31-Jan-2018 FMV, capped at the
# sale consideration).
GRANDFATHERING_ACQ_CUTOFF_DATE = "2018-02-01"
FMV_VALUATION_DATE = "2018-01-31"
# Sec 2(42A): the holding period / transfer date is the CONTRACT (trade)
# date, not the settlement date — the ledger's dates ARE trade dates.
HOLDING_PERIOD_BASIS = (
    "trade-date (Sec 2(42A): contract-note date; T+1 settlement date ignored)"
)

# Indian assessment year boundaries: AY 2026-27 covers FY 2025-26
# (Apr 2025 - Mar 2026). Gains realized in Apr-Mar of FY map accordingly.
def assessment_year_for_date(date_str: str) -> Optional[str]:
    """Map an exit date 'YYYY-MM-DD' to its Indian assessment year label.

    FY runs Apr 1 - Mar 31; AY = FY + 1. Returns None for unparseable input.
    """
    try:
        d = datetime.strptime(str(date_str)[:10], "%Y-%m-%d").date()
    except (ValueError, TypeError):
        return None
    fy_start_year = d.year if d.month >= 4 else d.year - 1
    return f"AY {fy_start_year + 1}-{str(fy_start_year + 2)[-2:]}"


def resolve_fmv_31jan2018(
    highs_by_date: Optional[Dict[str, float]],
    valuation_date: str = FMV_VALUATION_DATE,
    max_lookback_days: int = 7,
) -> tuple:
    """Sec 112A(2) FMV resolver (AUDIT-FIX Round 27 — R27-3).

    The statute's valuation input is the HIGHEST QUOTED PRICE on 31-Jan-2018.
    Given a daily {date_str: daily_high} record (from any EOD source), this
    pure function returns (fmv, as_of_date):
      * the High of the valuation date itself when present;
      * else the High of the nearest available trading day ON OR BEFORE it,
        within `max_lookback_days` (covers weekends/exchange holidays);
      * (None, None) when no usable row exists within the window.
    No network here — scripts/build_tax_fmv_feed.py feeds this from Yahoo
    .NS daily history to build the TAX_FMV_31JAN2018 record the endpoint
    auto-loads. Unparseable/non-positive rows are skipped, never invented.
    """
    if not highs_by_date:
        return None, None
    try:
        target = datetime.strptime(str(valuation_date)[:10], "%Y-%m-%d").date()
    except (ValueError, TypeError):
        return None, None
    parsed = []
    for k, v in highs_by_date.items():
        try:
            d = datetime.strptime(str(k)[:10], "%Y-%m-%d").date()
            fv = float(v)
        except (ValueError, TypeError):
            continue
        if fv > 0.0:
            parsed.append((d, fv))
    if not parsed:
        return None, None
    parsed.sort()
    for d, fv in parsed:
        if d == target:
            return fv, d.isoformat()
    best = None
    for d, fv in parsed:
        if d <= target:
            best = (d, fv)
    if best is not None and (target - best[0]).days <= int(max_lookback_days):
        return best[1], best[0].isoformat()
    return None, None


class RealizedGainsLedger:
    """Persistent ledger of realized gain/loss events from the trade journal.

    Storage mirrors TradeJournalManager's durability discipline: atomic
    mkstemp write + fsync + rename, and a corrupt file is quarantined (never
    silently reset — that would erase the tax record).
    """

    def __init__(self, storage_path: Optional[Union[str, Path]] = None):
        self.storage_path = Path(storage_path) if storage_path else LEDGER_FILE
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        self._entries: List[Dict[str, Any]] = self._load()

    # ── persistence ──────────────────────────────────────────────────────
    def _load(self) -> List[Dict[str, Any]]:
        if not self.storage_path.exists():
            return []
        try:
            with open(self.storage_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, list):
                raise ValueError(f"Ledger root is {type(data).__name__}, expected list")
            return data
        except Exception as e:
            quarantine = self.storage_path.with_name(
                f"{self.storage_path.stem}.corrupt-{int(time.time())}.json"
            )
            try:
                os.replace(self.storage_path, quarantine)
                logger.critical(
                    "[RealizedGains] Corrupt ledger quarantined to %s (%s). "
                    "Starting an EMPTY ledger — tax set-off history is lost "
                    "unless the quarantine is restored manually.", quarantine, e,
                )
            except OSError as qe:
                logger.critical(
                    "[RealizedGains] Quarantine failed: %s — original left at %s", qe, self.storage_path
                )
            return []

    def _save(self) -> None:
        fd, tmp_path = None, None
        try:
            fd, tmp_path = tempfile.mkstemp(
                dir=str(self.storage_path.parent),
                prefix=f"{self.storage_path.stem}.tmp-",
                suffix=".json",
            )
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                fd = None
                json.dump(self._entries, f, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp_path, self.storage_path)
            tmp_path = None
        except Exception as e:
            logger.error(f"[RealizedGains] Failed to save ledger: {e}")
        finally:
            if fd is not None:
                try:
                    os.close(fd)
                except OSError:
                    pass
            if tmp_path and os.path.exists(tmp_path):
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass

    # ── recording ────────────────────────────────────────────────────────
    def record_realized_close(
        self,
        trade: Dict[str, Any],
    ) -> Optional[Dict[str, Any]]:
        """Record one closed journal trade as a realized gain/loss event.

        The event stores the tax-relevant facts the journal row already
        carries (entry/exit dates and prices, realized P&L %, weight, shares
        when known). INR P&L is stored when a share count is derivable;
        otherwise it stays None and the consumer scales weight x portfolio
        value with a disclosed assumption (the same lot-sizing convention
        the /api/tax_optimizer uses).
        """
        try:
            exit_date = str(trade.get("exit_date") or datetime.now().strftime("%Y-%m-%d"))[:10]
            entry_date = str(trade.get("entry_date") or "")[:10]
            entry_px = float(trade.get("entry_price") or 0.0)
            exit_px = float(trade.get("exit_price") or 0.0)
            if entry_px <= 0 or exit_px <= 0:
                return None
            pnl_pct = trade.get("realized_pnl_%")
            if pnl_pct is None:
                pnl_pct = ((exit_px - entry_px) / entry_px) * 100.0
            holding_days = 0
            try:
                holding_days = max(0, (datetime.strptime(exit_date, "%Y-%m-%d")
                                       - datetime.strptime(entry_date, "%Y-%m-%d")).days)
            except ValueError:
                holding_days = 0
            shares = trade.get("shares")
            pnl_inr = None
            if isinstance(shares, (int, float)) and float(shares) > 0:
                pnl_inr = round((exit_px - entry_px) * float(shares), 2)
            event = {
                "event_id": f"RG_{datetime.now().strftime('%y%m%d')}_{trade.get('id', id(trade))}",
                "journal_trade_id": trade.get("id"),
                "ticker": str(trade.get("ticker", "")).strip().upper(),
                "basket_name": trade.get("basket_name"),
                "entry_date": entry_date,
                "exit_date": exit_date,
                "entry_price": round(entry_px, 2),
                "exit_price": round(exit_px, 2),
                "shares": (float(shares) if isinstance(shares, (int, float)) and float(shares) > 0 else None),
                "holding_days": int(holding_days),
                "tax_category": ("STCG" if holding_days < 365 else "LTCG"),
                "realized_pnl_pct": round(float(pnl_pct), 2),
                "realized_pnl_inr": pnl_inr,
                "weight_pct": trade.get("weight_pct"),
                "assessment_year": assessment_year_for_date(exit_date),
                # AUDIT-FIX (Round 25 — R25-5): the basis is the contract
                # (trade) date — settlement is irrelevant for classification
                # and AY bucketing (Sec 2(42A)).
                "date_basis": "trade-date",
                "recorded_at": datetime.now().isoformat(timespec="seconds"),
            }
            with _LEDGER_LOCK:
                # idempotent on journal_trade_id: re-logging the same close
                # (journal re-saves) never double-counts a realized event.
                jid = trade.get("id")
                if jid and any(e.get("journal_trade_id") == jid for e in self._entries):
                    return None
                self._entries.append(event)
                self._save()
            return event
        except Exception as e:
            logger.warning(f"[RealizedGains] Failed to record close: {e}")
            return None

    def backfill_from_journal_trades(self, trades: List[Dict[str, Any]]) -> int:
        """Backfill ledger events from journal rows that closed BEFORE this
        ledger existed (status in TARGET_HIT / STOPPED_OUT / CLOSED with an
        exit price). Returns the number of events added."""
        added = 0
        for t in trades or []:
            if t.get("status") not in {"TARGET_HIT", "STOPPED_OUT", "CLOSED"}:
                continue
            if not t.get("exit_price"):
                continue
            if self.record_realized_close(t):
                added += 1
        return added

    # ── queries ──────────────────────────────────────────────────────────
    def entries(self) -> List[Dict[str, Any]]:
        with _LEDGER_LOCK:
            return [dict(e) for e in self._entries]

    def entries_for_assessment_year(self, ay: str) -> List[Dict[str, Any]]:
        return [e for e in self.entries() if e.get("assessment_year") == ay]

    def net_gains_by_category(
        self,
        ay: str,
        portfolio_value_inr: Optional[float] = None,
        fmv_31jan2018: Optional[Dict[str, float]] = None,
    ) -> Dict[str, Optional[float]]:
        """Net realized STCG / LTCG (INR) for one assessment year.

        Events with a direct INR P&L (shares known) use it; others are
        scaled from weight_pct x portfolio_value_inr when provided. When
        neither is available the category total is None (honest unknown),
        never 0.0 masquerading as a measurement.

        AUDIT-FIX (Round 25 — R25-5):
          * SEC 112A(2) GRANDFATHERING — for priced LTCG events acquired
            before 2018-02-01 with an FMV supplied in `fmv_31jan2018`
            ({ticker: price_on_31Jan2018}), the cost per share becomes
            max(actual cost, min(FMV, sale price)) and the event P&L is
            recomputed on the deemed cost. Applied events + total
            adjustment are returned in `grandfathering` (no feed -> 0
            applied, disclosed — never a silent approximation).
          * REGIME SPLIT — the pre/post 23-Jul-2024 breakdown per category
            (by exit date) is returned as `regime_split` so the engine can
            apply per-tranche rates (old 15%/10%/Rs1L vs new 20%/12.5%/
            Rs1.25L).
          * `holding_period_basis` discloses the trade-date convention.
        """
        totals = {"STCG": 0.0, "LTCG": 0.0, "_unknown": 0}
        split = {
            "cutoff_date": TAX_REGIME_CUTOFF_DATE,
            "STCG": {"pre_cutoff": 0.0, "post_cutoff": 0.0},
            "LTCG": {"pre_cutoff": 0.0, "post_cutoff": 0.0},
        }
        gf_applied = 0
        gf_eligible = 0
        gf_adjustment = 0.0
        fmv_map = fmv_31jan2018 or {}
        for e in self.entries_for_assessment_year(ay):
            pnl = e.get("realized_pnl_inr")
            if pnl is None and portfolio_value_inr and e.get("weight_pct") is not None:
                pnl = (float(e["weight_pct"]) / 100.0) * float(portfolio_value_inr) * (float(e["realized_pnl_pct"]) / 100.0)
            if pnl is None:
                totals["_unknown"] += 1
                continue
            pnl = float(pnl)
            cat = e.get("tax_category", "STCG")
            entry_date = str(e.get("entry_date") or "")
            exit_date = str(e.get("exit_date") or "")
            # ── Sec 112A(2) grandfathering (priced LTCG acquired pre-Feb-2018)
            if (cat == "LTCG" and fmv_map
                    and entry_date and entry_date < GRANDFATHERING_ACQ_CUTOFF_DATE):
                gf_eligible += 1
                try:
                    exit_px_f = float(e.get("exit_price") or 0.0)
                    entry_px_f = float(e.get("entry_price") or 0.0)
                    tk = str(e.get("ticker") or "").strip().upper()
                    fmv = float(fmv_map.get(tk, float("nan")))
                    shares = e.get("shares")
                    if shares is None or not (isinstance(shares, (int, float)) and float(shares) > 0):
                        # legacy events: derive shares back from the stored P&L.
                        # AUDIT-FIX (Round 48 — R48-1): the previous derivation
                        # was broken on BOTH branches for LOSS events —
                        # (a) the guard `exit_px_f > entry_px_f > 0` only let
                        #     GAIN events through at all (a long-term LOSS has
                        #     exit < entry), so legacy loss events always fell
                        #     to shares=None;
                        # (b) even for a gain-shaped loss (short-style rows),
                        #     `abs(pnl) / (exit_px_f - entry_px_f)` produced a
                        #     NEGATIVE share count that the `float(shares) > 0`
                        #     gate below then rejected.
                        # Net effect: Sec 112A(2) grandfathering was silently
                        # skipped for pre-Feb-2018 long-term LOSS lots — the
                        # very events where the deemed-cost step-up REDUCES
                        # the loss (a larger deductible). Shares are now
                        # derived as |pnl| / |exit - entry| (always positive)
                        # for any non-degenerate price pair.
                        if exit_px_f > 0 and entry_px_f > 0 and (exit_px_f - entry_px_f) != 0:
                            shares = abs(pnl) / abs(exit_px_f - entry_px_f)
                        else:
                            shares = None
                    if (np.isfinite(fmv) and fmv > 0 and exit_px_f > 0 and entry_px_f > 0
                            and shares is not None and float(shares) > 0):
                        # deemed cost = max(actual, min(FMV, sale price))
                        deemed = max(entry_px_f, min(fmv, exit_px_f))
                        adj_pnl = (exit_px_f - deemed) * float(shares)
                        gf_adjustment += (adj_pnl - pnl)
                        pnl = adj_pnl
                        gf_applied += 1
                except (TypeError, ValueError):
                    pass
            totals[cat] += pnl
            tranche = ("pre_cutoff" if (exit_date and exit_date < TAX_REGIME_CUTOFF_DATE)
                       else "post_cutoff")
            split[cat][tranche] += pnl
        unknown = totals.pop("_unknown")
        totals["unpriced_events"] = unknown
        # AUDIT-FIX (Round 25 — R25-5): regime split + grandfathering +
        # trade-date-basis disclosure ride along on the category totals
        # (existing STCG/LTCG consumers are unchanged; the totals are
        # post-grandfathering when an FMV feed was supplied).
        totals["regime_split"] = split
        totals["holding_period_basis"] = HOLDING_PERIOD_BASIS
        if fmv_map:
            totals["grandfathering"] = {
                "applied_events": gf_applied,
                "eligible_events": gf_eligible,
                "adjustment_inr": round(gf_adjustment, 2),
                "basis": (f"Sec 112A(2): deemed cost = max(actual cost, min(FMV on "
                          f"{FMV_VALUATION_DATE}, sale price)) for lots acquired before "
                          f"{GRANDFATHERING_ACQ_CUTOFF_DATE}; FMV feed supplied per ticker"),
            }
        else:
            totals["grandfathering"] = {
                "applied_events": 0,
                "eligible_events": gf_eligible,
                "adjustment_inr": 0.0,
                "basis": ("NOT APPLIED — no FMV-on-31-Jan-2018 valuation supplied "
                          f"(cfg TAX_FMV_31JAN2018 integration point); pre-Feb-2018 "
                          f"lots keep their actual cost"),
            }
        return totals
