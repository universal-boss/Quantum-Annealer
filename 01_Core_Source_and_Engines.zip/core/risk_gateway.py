"""
core/risk_gateway.py
====================
Hard Pre-Trade Risk Gateway & Statutory Algorithmic Trading Safeguards.

Deterministic pre-trade risk gatekeeper. Enforces hard limits before any order
can be transmitted to an external broker or simulated matching engine:
  1. Master Kill Switch state verification (fail-closed).
  2. Maximum Single-Order Rupee Value ceiling (e.g., ₹25 Lakhs).
  3. Exchange Freeze Quantity limits per symbol.
  4. Single-Stock and Single-Sector portfolio concentration limits.
  5. Fat-Finger Limit Price deviation from Last Traded Price (LTP).
  6. Margin availability and portfolio leverage ceilings.

Every violation is recorded in the ACID relational risk audit log.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Tuple, Union

from core.db_engine import get_db
from core.kill_switch import MasterKillSwitch

logger = logging.getLogger("quantum_annealer.risk_gateway")


class RiskViolationError(Exception):
    """Raised when an order or portfolio violates statutory or firm pre-trade risk rules."""
    def __init__(self, rule_name: str, message: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(f"[{rule_name}] {message}")
        self.rule_name = rule_name
        self.message = message
        self.details = details or {}


# Standard NSE Cash Segment Freeze Quantities (conservative upper bounds)
NSE_FREEZE_QUANTITIES: Dict[str, int] = {
    "NIFTYBEES": 100_000,
    "BANKBEES": 50_000,
    "GOLDBEES": 100_000,
    "LIQUIDBEES": 200_000,
    "DEFAULT_LARGE_CAP": 50_000,
    "DEFAULT_MID_CAP": 25_000,
    "DEFAULT_SMALL_CAP": 10_000,
}


class HardPreTradeRiskGateway:
    """Institutional Pre-Trade Risk Engine enforcing statutory and risk limits."""

    DEFAULT_MAX_ORDER_VALUE: float = 2_500_000.0  # ₹25 Lakhs per order
    DEFAULT_MAX_STOCK_CONCENTRATION: float = 0.10  # Max 10% in any single stock
    DEFAULT_MAX_SECTOR_CONCENTRATION: float = 0.25  # Max 25% in any single sector
    DEFAULT_MAX_PRICE_DEVIATION_PCT: float = 0.03  # Max 3% deviation from LTP
    DEFAULT_MAX_MARGIN_UTILIZATION: float = 0.90   # Max 90% available margin

    def __init__(self, cfg: Optional[Dict[str, Any]] = None):
        self.cfg = cfg or {}
        self.db = get_db()

    @property
    def max_order_value(self) -> float:
        return float(self.cfg.get("RISK_MAX_ORDER_VALUE", self.DEFAULT_MAX_ORDER_VALUE))

    @property
    def max_stock_concentration(self) -> float:
        # AUDIT-FIX (Round 43 / AUDIT-15a mis-application): the delivered fix
        # used the mandate's MAX_WEIGHT directly as the gateway cap fallback,
        # which silently removed the statutory 10% institutional ceiling — a
        # MAX_WEIGHT=0.50 profile made the *hard risk gateway* content with a
        # 50% single-stock position. Per the documented remediation, the cap
        # now tracks the mandate but is never LOOSER than the statutory
        # default: min(MAX_WEIGHT, 10%). Mandates that genuinely need a higher
        # ceiling must set RISK_MAX_STOCK_CONCENTRATION explicitly, which still
        # wins unconditionally.
        _explicit = self.cfg.get("RISK_MAX_STOCK_CONCENTRATION")
        if _explicit is not None:
            return float(_explicit)
        _mandate = self.cfg.get("MAX_WEIGHT")
        if _mandate is not None:
            return float(min(float(_mandate), self.DEFAULT_MAX_STOCK_CONCENTRATION))
        return float(self.DEFAULT_MAX_STOCK_CONCENTRATION)

    @property
    def enable_sector_cap(self) -> bool:
        return bool(self.cfg.get("ENABLE_SECTOR_CAP", True))

    @property
    def max_sector_concentration(self) -> float:
        # When sector capping is disabled (e.g. Pure Alpha / Momentum profiles),
        # allow unconstrained concentration into market leaders (cap = 1.0 / 100%).
        if not self.enable_sector_cap:
            return 1.0
        return float(
            self.cfg.get(
                "RISK_MAX_SECTOR_CONCENTRATION",
                self.cfg.get("SECTOR_LIMIT", self.DEFAULT_MAX_SECTOR_CONCENTRATION),
            )
        )

    @property
    def max_price_deviation(self) -> float:
        return float(self.cfg.get("RISK_MAX_PRICE_DEVIATION", self.DEFAULT_MAX_PRICE_DEVIATION_PCT))

    # ── Single Order Checks ──────────────────────────────────────────────────

    def validate_order(
        self,
        symbol: str,
        side: str,
        qty: int,
        price: float,
        ltp: Optional[float] = None,
        order_type: str = "MARKET",
        exchange: str = "NSE",
    ) -> Tuple[bool, Optional[str]]:
        """Validate a single order against all pre-trade statutory checks.

        Returns:
            (is_approved: bool, rejection_reason: Optional[str])
        """
        symbol_clean = str(symbol).strip().upper()
        effective_price = price if price > 0 else (ltp if ltp and ltp > 0 else 0.0)
        order_value = qty * effective_price

        # 1. Kill Switch Check
        if MasterKillSwitch.is_active():
            msg = "Global emergency kill switch is active. All order submission is blocked."
            self._log_violation("GLOBAL_KILL_SWITCH", "BLOCK", symbol_clean, order_value, 0.0, msg)
            return False, msg

        # 2. Freeze Quantity Limit Check (Exchange Physical Limit)
        freeze_limit = self._get_freeze_limit(symbol_clean)
        if qty > freeze_limit:
            msg = f"Order quantity {qty:,} exceeds exchange freeze limit of {freeze_limit:,} shares"
            self._log_violation("FREEZE_QUANTITY_LIMIT", "BLOCK", symbol_clean, float(qty), float(freeze_limit), msg)
            return False, msg

        # 3. Maximum Single-Order Value Limit (Statutory Rupee Ceiling)
        if order_value > self.max_order_value:
            msg = (
                f"Single order value ₹{order_value:,.2f} exceeds statutory ceiling of "
                f"₹{self.max_order_value:,.2f}"
            )
            self._log_violation("MAX_ORDER_VALUE", "BLOCK", symbol_clean, order_value, self.max_order_value, msg)
            return False, msg

        # 4. Fat-Finger Price Deviation Check (for LIMIT orders)
        if order_type.upper() == "LIMIT" and ltp is not None and ltp > 0 and price > 0:
            deviation = abs(price - ltp) / ltp
            if deviation > self.max_price_deviation:
                msg = (
                    f"Limit price ₹{price:.2f} deviates {deviation:.2%} from market LTP ₹{ltp:.2f} "
                    f"(ceiling: {self.max_price_deviation:.2%})"
                )
                self._log_violation("FAT_FINGER_DEVIATION", "BLOCK", symbol_clean, deviation, self.max_price_deviation, msg)
                return False, msg

        return True, None

    # ── Basket / Portfolio Checks ────────────────────────────────────────────

    def validate_basket(
        self,
        weights: Dict[str, float],
        total_nav: float,
        sector_map: Optional[Dict[str, str]] = None,
        available_cash: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Validate an entire portfolio allocation or basket against concentration & margin rules.

        Returns:
            Dict containing status ('PASSED' | 'BLOCKED'), violations list, and summary.
        """
        violations: List[Dict[str, Any]] = []

        # 1. Kill Switch Check
        if MasterKillSwitch.is_active():
            v = {
                "rule": "GLOBAL_KILL_SWITCH",
                "severity": "BLOCK",
                "message": "Global emergency kill switch is active. Execution blocked.",
            }
            violations.append(v)
            self._log_violation("GLOBAL_KILL_SWITCH", "BLOCK", "BASKET", total_nav, 0.0, v["message"])
            return {"status": "BLOCKED", "violations": violations}

        # 2. Stock Concentration Checks
        for ticker, weight in weights.items():
            if str(ticker).upper() == "CASH":
                continue
            w_val = float(weight)
            if w_val > (self.max_stock_concentration + 1e-4):
                msg = (
                    f"Stock {ticker} weight {w_val:.2%} exceeds single-stock concentration cap "
                    f"of {self.max_stock_concentration:.2%}"
                )
                violations.append({
                    "rule": "STOCK_CONCENTRATION_LIMIT",
                    "severity": "BLOCK",
                    "ticker": ticker,
                    "message": msg,
                    "value": w_val,
                    "limit": self.max_stock_concentration,
                })
                self._log_violation("STOCK_CONCENTRATION_LIMIT", "BLOCK", ticker, w_val, self.max_stock_concentration, msg)

        # 3. Sector Concentration Checks (skipped if ENABLE_SECTOR_CAP=False for pure alpha/momentum)
        if sector_map and self.enable_sector_cap and self.max_sector_concentration < 1.0:
            sector_exposures: Dict[str, float] = {}
            for ticker, weight in weights.items():
                if str(ticker).upper() == "CASH":
                    continue
                raw_sec = sector_map.get(ticker, "Unknown")
                if raw_sec in (None, "", "N/A", "NA", "na", "null") or (isinstance(raw_sec, str) and not raw_sec.strip()):
                    sec = "Unknown"
                else:
                    sec = str(raw_sec)
                sector_exposures[sec] = sector_exposures.get(sec, 0.0) + float(weight)

            for sec, exp in sector_exposures.items():
                # BUGFIX (Round 41): this previously read `if sec != "Unknown"
                # and exp > (...)`, explicitly exempting the "Unknown" sector
                # bucket from the concentration cap entirely.
                # Unknown-sector exposure is now capped like any other sector.
                if exp > (self.max_sector_concentration + 1e-4):
                    msg = (
                        f"Sector '{sec}' exposure {exp:.2%} exceeds sector cap "
                        f"of {self.max_sector_concentration:.2%}"
                    )
                    violations.append({
                        "rule": "SECTOR_CONCENTRATION_LIMIT",
                        "severity": "BLOCK",
                        "ticker": sec,
                        "message": msg,
                        "value": exp,
                        "limit": self.max_sector_concentration,
                    })
                    self._log_violation("SECTOR_CONCENTRATION_LIMIT", "BLOCK", sec, exp, self.max_sector_concentration, msg)

        # 4. Margin Utilization Check
        available_margin = self.cfg.get("AVAILABLE_BUYING_POWER", self.cfg.get("AVAILABLE_MARGIN", available_cash))
        max_margin_util = float(self.cfg.get("RISK_MAX_MARGIN_UTILIZATION", self.DEFAULT_MAX_MARGIN_UTILIZATION))
        if available_margin is not None and float(available_margin) > 0:
            gross_equity_capital = sum(
                float(w) * total_nav for t, w in weights.items() if str(t).upper() != "CASH"
            )
            utilization = gross_equity_capital / float(available_margin)
            if utilization > max_margin_util:
                msg = (
                    f"Capital requirement ₹{gross_equity_capital:,.2f} consumes {utilization:.1%} "
                    f"of available buying power (ceiling: {max_margin_util:.1%})"
                )
                violations.append({
                    "rule": "MARGIN_UTILIZATION_CEILING",
                    "severity": "BLOCK",
                    "ticker": "BASKET",
                    "message": msg,
                    "value": utilization,
                    "limit": max_margin_util,
                })
                self._log_violation("MARGIN_UTILIZATION_CEILING", "BLOCK", "BASKET", utilization, max_margin_util, msg)

        status = "BLOCKED" if any(v["severity"] == "BLOCK" for v in violations) else "PASSED"
        return {
            "status": status,
            "violations": violations,
            "total_violations": len(violations),
        }

    # ── Helpers ──────────────────────────────────────────────────────────────

    def _get_freeze_limit(self, symbol: str) -> int:
        """Resolve exchange freeze quantity limit for a symbol."""
        sym = symbol.replace(".NS", "").replace(".BO", "").upper()
        if sym in NSE_FREEZE_QUANTITIES:
            return NSE_FREEZE_QUANTITIES[sym]
        # Conservative default for equities (1,000 to prevent oversized order exchange rejections)
        return int(self.cfg.get("DEFAULT_FREEZE_QUANTITY", 1_000))

    def _log_violation(
        self,
        rule: str,
        severity: str,
        ticker: str,
        attempted: float,
        limit_val: float,
        message: str,
    ) -> None:
        """Record risk event into persistent SQLite WAL log."""
        try:
            self.db.log_risk_event(
                rule_name=rule,
                severity=severity,
                ticker=ticker,
                attempted_value=attempted,
                limit_value=limit_val,
                message=message,
                action_taken="REJECTED",
            )
        except Exception as e:
            logger.error(f"[RiskGateway] Failed to log risk violation to DB: {e}")


# Backward-compatibility alias
RiskGateway = HardPreTradeRiskGateway
