"""
core/state_manager.py
======================
Thread-safe singleton holding live application state shared across all
QThread workers, the QUBO optimizer, and the PySide6 UI.

Design:
    - Pure RLock protection (re-entrant so the same thread can read inside
      a callback that was triggered by a write).
    - No Qt dependency — safe to import from worker process children without
      triggering a QApplication.
    - Weakref-free singleton implemented via __new__ class lock; avoids the
      double-checked locking race present in naïve module-level globals.

Usage:
    state = AppState.instance()
    state.set_regime("Bull", 0.87, {"Bear": 0.04, "Sideways": 0.09, "Bull": 0.87})
    label, confidence = state.current_regime, state.regime_confidence
"""
from __future__ import annotations

import copy
import threading
from typing import ClassVar, Dict, Optional


class AppState:
    """Thread-safe application state singleton.

    All public attributes are accessed via property getters that acquire
    ``_lock`` so cross-thread reads/writes are always consistent.

    Attributes (read via properties):
        current_regime (str):          "Bull" | "Sideways" | "Bear" | "Unknown"
        regime_confidence (float):     Posterior probability of current_regime ∈ (0, 1)
        regime_probabilities (dict):   Full posterior {"Bear": p0, "Sideways": p1, "Bull": p2}
        regime_transition_matrix:      3×3 numpy array or None before first HMM run
        latent_screener_scores (dict): {ticker: cosine_sim} populated by LatentScreenerWorker
        last_screener_run (float):     UNIX timestamp of last screener completion
    """

    _instance: ClassVar[Optional["AppState"]] = None
    _singleton_lock: ClassVar[threading.Lock] = threading.Lock()

    # ── Singleton ────────────────────────────────────────────────────────────

    def __new__(cls) -> "AppState":
        # Double-checked locking with class-level lock — thread-safe singleton.
        if cls._instance is None:
            with cls._singleton_lock:
                if cls._instance is None:
                    inst = super().__new__(cls)
                    inst._lock = threading.RLock()
                    inst._init_state()
                    cls._instance = inst
        return cls._instance

    @classmethod
    def instance(cls) -> "AppState":
        """Return (creating if necessary) the singleton AppState."""
        return cls()

    # ── Initialisation ───────────────────────────────────────────────────────

    def _init_state(self) -> None:
        """Set all mutable fields to safe defaults. Called once at creation."""
        # Market regime (updated by RegimeWorker)
        self._current_regime: str = "Unknown"
        self._regime_confidence: float = 0.0
        self._regime_probabilities: Dict[str, float] = {
            "Bear": 0.0, "Sideways": 0.0, "Bull": 0.0,
        }
        self._regime_transition_matrix = None   # NDArray[float64] | None

        # Latent screener (updated by LatentScreenerWorker)
        self._latent_screener_scores: Dict[str, float] = {}   # {ticker: cosine_sim}
        self._last_screener_run: float = 0.0                  # UNIX timestamp

        # QUBO override flags (set by regime-aware constraint function)
        self._qubo_bull_mode: bool = False

        # Legacy AppState fields consolidated from utils.py
        self.stop_event = None
        self.last_yf_warning: float = 0.0
        self.sector_cache: dict = {}
        self.ticker_cache: dict = {}
        self.active_workers: list = []
        self.regime: str = "UNKNOWN"
        self.india_vix: float = 15.0
        self._callbacks: dict = {}
        self._qpu_status: str = "Unknown"

        # ── Multi-profile parallel sweep results ──────────────────────────────
        # Populated by ProfileWorker threads as each profile completes.
        # Status values: "pending" | "running" | "done" | "failed"
        self._profile_results: Dict[str, dict] = {}        # {profile_name: payload}
        self._profile_status: Dict[str, str] = {}          # {profile_name: status}
        self._profile_runtimes: Dict[str, float] = {}      # {profile_name: seconds}

    @property
    def qpu_status(self) -> str:
        with self._lock:
            return self._qpu_status

    @qpu_status.setter
    def qpu_status(self, val: str) -> None:
        with self._lock:
            self._qpu_status = val

    # ── Regime State ─────────────────────────────────────────────────────────

    def set_regime(
        self,
        label: str,
        confidence: float,
        probabilities: Dict[str, float],
        transition_matrix=None,
    ) -> None:
        """Atomically update all regime fields from a single HMM inference result.

        Args:
            label:             "Bull" | "Sideways" | "Bear" | "Unknown"
            confidence:        Posterior of the dominant state.
            probabilities:     Full {"Bear": p, "Sideways": p, "Bull": p} dict.
            transition_matrix: Optional 3×3 numpy array (A-matrix, relabeled order).
        """
        with self._lock:
            # 1. Validate label
            valid_labels = {"Bull", "Sideways", "Bear", "Unknown", "Defensive (Stale Model)"}
            if label not in valid_labels:
                raise ValueError(f"Invalid regime label: '{label}'. Must be one of {valid_labels}")
            
            # 2. Validate confidence
            conf_val = float(confidence)
            if not (0.0 <= conf_val <= 1.0):
                raise ValueError(f"Regime confidence must be in range [0, 1], got {conf_val}")
            
            # 3. Validate probabilities
            probs_dict = {k: float(v) for k, v in probabilities.items() if k in {"Bull", "Sideways", "Bear"}}
            for k in {"Bull", "Sideways", "Bear"}:
                if k not in probs_dict:
                    probs_dict[k] = 0.0
                if not (0.0 <= probs_dict[k] <= 1.0):
                    raise ValueError(f"Regime probability for '{k}' must be in range [0, 1], got {probs_dict[k]}")
            
            # Derive confidence from probabilities to prevent contradiction
            prob_conf = probs_dict.get(label, conf_val)
            if abs(prob_conf - conf_val) > 1e-4:
                import logging
                logging.getLogger(__name__).warning(
                    "[AppState] Confidence passed (%s) disagrees with regime probability (%s). Overriding.",
                    conf_val, prob_conf
                )
            conf_val = prob_conf

            # 4. Store copies defensively
            self._current_regime = label
            self._regime_confidence = conf_val
            self._regime_probabilities = probs_dict
            
            if transition_matrix is not None:
                if hasattr(transition_matrix, "copy"):
                    self._regime_transition_matrix = transition_matrix.copy()
                else:
                    import copy
                    self._regime_transition_matrix = copy.deepcopy(transition_matrix)
            else:
                self._regime_transition_matrix = None
                
            self._qubo_bull_mode = (label == "Bull")

    @property
    def current_regime(self) -> str:
        with self._lock:
            return self._current_regime

    @property
    def regime_confidence(self) -> float:
        with self._lock:
            return self._regime_confidence

    @property
    def regime_probabilities(self) -> Dict[str, float]:
        with self._lock:
            return dict(self._regime_probabilities)

    @property
    def regime_transition_matrix(self):
        with self._lock:
            mat = self._regime_transition_matrix
            if mat is not None:
                if hasattr(mat, "copy"):
                    return mat.copy()
                else:
                    import copy
                    return copy.deepcopy(mat)
            return None

    @property
    def is_bull(self) -> bool:
        with self._lock:
            return self._qubo_bull_mode

    @property
    def is_risk_off(self) -> bool:
        """True when regime is Bear or Sideways → apply defensive QUBO constraints."""
        with self._lock:
            return self._current_regime in ("Bear", "Sideways")

    # ── Latent Screener State ─────────────────────────────────────────────────

    def update_latent_scores(
        self,
        scores: Dict[str, float],
        timestamp: float,
    ) -> None:
        """Replace latent screener scores atomically.

        Args:
            scores:    Mapping of {ticker: cosine_similarity}.
            timestamp: UNIX epoch time of the completed screener run.
        """
        with self._lock:
            self._latent_screener_scores = dict(scores)
            self._last_screener_run = float(timestamp)

    def get_latent_score(self, ticker: str, default: float = 0.0) -> float:
        """Return the cosine similarity score for a ticker, or ``default``."""
        with self._lock:
            return self._latent_screener_scores.get(ticker, default)

    @property
    def latent_screener_scores(self) -> Dict[str, float]:
        with self._lock:
            return dict(self._latent_screener_scores)

    @property
    def last_screener_run(self) -> float:
        with self._lock:
            return self._last_screener_run

    # ── Multi-Profile Parallel Sweep ─────────────────────────────────────────

    def set_profile_result(self, name: str, payload: dict, runtime_sec: float = 0.0) -> None:
        """Store the optimizer payload for a completed profile run (thread-safe)."""
        with self._lock:
            if not isinstance(payload, dict):
                return
            # ROUND 45 FIX: store a defensive DEEP copy — the caller's dict (or
            # nested lists/dicts inside it) could be mutated after hand-off
            # (breaking the snapshot-style contract the class documents).
            self._profile_results[name] = copy.deepcopy(payload)
            self._profile_status[name] = "done"
            self._profile_runtimes[name] = float(runtime_sec) if (runtime_sec and runtime_sec > 0) else 0.0

    def get_profile_result(self, name: str) -> Optional[dict]:
        """Return the stored payload for a profile, or None if not yet done."""
        with self._lock:
            payload = self._profile_results.get(name)
            # ROUND 45 FIX: return a DEEP copy — the previous `return self._profile_results.get(name)`
            # handed out the live internal dict, so any consumer mutation
            # corrupted the stored result (tracked LOW in the repo worklog).
            return copy.deepcopy(payload) if payload is not None else None

    def set_profile_status(self, name: str, status: str) -> None:
        """Set a profile's run status: 'pending' | 'running' | 'done' | 'failed'."""
        with self._lock:
            self._profile_status[name] = status

    def get_profile_status(self, name: str) -> str:
        """Return a profile's run status string."""
        with self._lock:
            return self._profile_status.get(name, "pending")

    def get_all_profile_statuses(self) -> Dict[str, str]:
        """Return a snapshot of all profile statuses."""
        with self._lock:
            return dict(self._profile_status)

    def get_profile_runtime(self, name: str) -> float:
        """Return a profile's runtime in seconds, or 0.0 if not done."""
        with self._lock:
            return self._profile_runtimes.get(name, 0.0)

    def reset_all_profiles(self) -> None:
        """Clear all profile results and statuses (called at start of a new sweep)."""
        with self._lock:
            self._profile_results.clear()
            self._profile_status.clear()
            self._profile_runtimes.clear()

    # ── Debug ────────────────────────────────────────────────────────────────

    def snapshot(self) -> Dict[str, object]:
        """Return a consistent read-snapshot of all state fields (no lock held by caller)."""
        with self._lock:
            return {
                "current_regime":       self._current_regime,
                "regime_confidence":    self._regime_confidence,
                "regime_probabilities": dict(self._regime_probabilities),
                "qubo_bull_mode":       self._qubo_bull_mode,
                "latent_scores_count":  len(self._latent_screener_scores),
                "last_screener_run":    self._last_screener_run,
            }

    @classmethod
    def get(cls) -> "AppState":
        """Alias for instance() to support legacy calls."""
        return cls.instance()

    def request_stop(self) -> None:
        with self._lock:
            ev = self.stop_event
        if ev is not None:
            ev.set()

    def is_stop_requested(self) -> bool:
        with self._lock:
            ev = self.stop_event
        return ev is not None and ev.is_set()

    def new_run(self) -> threading.Event:
        new_ev = threading.Event()
        with self._lock:
            self.stop_event = new_ev
        return new_ev

    def subscribe(self, event: str, callback) -> None:
        with self._lock:
            self._callbacks.setdefault(event, []).append(callback)

    def publish(self, event: str, payload=None) -> None:
        with self._lock:
            callbacks = list(self._callbacks.get(event, []))
        for cb in callbacks:
            try:
                cb(payload)
            except Exception as e:
                import logging
                logging.getLogger(__name__).warning("AppState.publish %s: %s", event, e)

    def __repr__(self) -> str:
        return (
            f"AppState(regime={self._current_regime}, "
            f"conf={self._regime_confidence:.2f}, "
            f"screener_n={len(self._latent_screener_scores)})"
        )
