"""
core/tca_engine.py
==================
Post-Trade Transaction Cost Analysis (TCA) & Market Impact Engine.

Implements Perold (1988) Implementation Shortfall and Almgren-Chriss (2000)
empirical market impact analysis.

Deconstructs execution drag into:
  1. Delay Slippage: Cost incurred between algorithmic decision and order arrival.
  2. Execution Slippage: Gap between arrival price at the market and actual fill.
  3. Total Implementation Shortfall: True economic friction of the trade.
  4. Almgren-Chriss Benchmark: Expected non-linear square-root market impact.

Every execution is audited and persisted to the relational database.
"""
from __future__ import annotations

import logging
import math
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

from core.db_engine import get_db

logger = logging.getLogger("quantum_annealer.tca_engine")


class TCAEngine:
    """Post-trade transaction cost analysis and execution slippage auditor."""

    ALMGREN_CHRISS_GAMMA: float = 0.314  # Standard empirical calibration factor

    def __init__(self):
        self.db = get_db()

    def analyze_and_record_trade(
        self,
        order_id: str,
        symbol: str,
        side: str,
        qty: int,
        decision_price: float,
        arrival_price: float,
        execution_price: float,
        adv: Optional[float] = None,
        daily_vol: Optional[float] = 0.02,
    ) -> Dict[str, Any]:
        """Compute Implementation Shortfall and record into database.

        Args:
            order_id: Unique OMS order identifier.
            symbol: Traded ticker symbol.
            side: 'BUY' or 'SELL'.
            qty: Total filled quantity.
            decision_price: Mid/LTP when the allocation decision was formulated.
            arrival_price: Mid/LTP when order reached the broker gateway.
            execution_price: Volume-weighted average fill price (VWAP).
            adv: 20-Day Average Daily Volume (shares) for market impact benchmark.
            daily_vol: Trailing daily price volatility (e.g. 0.02 = 2%).

        Returns:
            Dictionary with exact slippage metrics in basis points (bps).
        """
        side_clean = side.upper().strip()
        p_dec = max(float(decision_price), 1e-4)
        p_arr = max(float(arrival_price), 1e-4)
        p_exec = max(float(execution_price), 1e-4)

        # Perold (1988) Implementation Shortfall formulation
        if side_clean == "BUY":
            # For BUY, higher execution/arrival price than decision price is positive slippage (drag)
            delay_bps = ((p_arr - p_dec) / p_dec) * 10_000.0
            execution_bps = ((p_exec - p_arr) / p_arr) * 10_000.0
            total_shortfall_bps = ((p_exec - p_dec) / p_dec) * 10_000.0
        else:
            # For SELL, lower execution/arrival price than decision price is positive slippage (drag)
            delay_bps = ((p_dec - p_arr) / p_dec) * 10_000.0
            execution_bps = ((p_arr - p_exec) / p_arr) * 10_000.0
            total_shortfall_bps = ((p_dec - p_exec) / p_dec) * 10_000.0

        # Almgren-Chriss (2000) square-root theoretical impact
        market_impact_bps = 0.0
        if adv and adv > 0 and qty > 0:
            participation_rate = float(qty) / float(adv)
            sigma = daily_vol if (daily_vol and daily_vol > 0) else 0.02
            # I_AC = gamma * sigma * sqrt(participation) * 10,000 bps
            market_impact_bps = self.ALMGREN_CHRISS_GAMMA * sigma * math.sqrt(participation_rate) * 10_000.0

        tca_id = f"TCA-{uuid.uuid4().hex[:12].upper()}"

        # Persist to database
        try:
            self.db.record_tca(
                tca_id=tca_id,
                order_id=order_id,
                symbol=symbol,
                side=side_clean,
                qty=qty,
                decision_price=round(p_dec, 4),
                arrival_price=round(p_arr, 4),
                execution_price=round(p_exec, 4),
                slippage_bps=round(execution_bps, 2),
                delay_bps=round(delay_bps, 2),
                total_shortfall_bps=round(total_shortfall_bps, 2),
                market_impact_bps=round(market_impact_bps, 2),
            )
        except Exception as e:
            logger.error(f"[TCAEngine] Failed to save TCA record for order {order_id}: {e}")

        return {
            "tca_id": tca_id,
            "order_id": order_id,
            "symbol": symbol,
            "side": side_clean,
            "qty": qty,
            "decision_price": round(p_dec, 2),
            "arrival_price": round(p_arr, 2),
            "execution_price": round(p_exec, 2),
            "execution_slippage_bps": round(execution_bps, 2),
            "delay_slippage_bps": round(delay_bps, 2),
            "total_shortfall_bps": round(total_shortfall_bps, 2),
            "almgren_chriss_impact_bps": round(market_impact_bps, 2),
        }

    def get_summary_report(self, limit: int = 100) -> Dict[str, Any]:
        """Aggregate recent TCA execution statistics."""
        records = self.db.get_tca_history(limit=limit)
        if not records:
            return {
                "total_trades": 0,
                "mean_slippage_bps": 0.0,
                "mean_delay_bps": 0.0,
                "mean_total_shortfall_bps": 0.0,
                "max_slippage_bps": 0.0,
                "records": [],
            }

        slippages = [r["slippage_bps"] for r in records]
        delays = [r["delay_bps"] for r in records]
        shortfalls = [r["total_shortfall_bps"] for r in records]

        return {
            "total_trades": len(records),
            "mean_slippage_bps": round(sum(slippages) / len(slippages), 2),
            "mean_delay_bps": round(sum(delays) / len(delays), 2),
            "mean_total_shortfall_bps": round(sum(shortfalls) / len(shortfalls), 2),
            "max_slippage_bps": round(max(slippages), 2),
            "records": records,
        }
