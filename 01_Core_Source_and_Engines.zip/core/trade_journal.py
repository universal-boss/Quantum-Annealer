"""
core/trade_journal.py
=====================
Automated Paper Trading & Forward-Testing Trade Journal.

Tracks active swing baskets, entry prices, stop-loss levels, Snell profit targets,
and calculates live mark-to-market performance, win rates, and profit factors without Excel.
"""
from __future__ import annotations

import json
import logging
import math
import os
import tempfile
import threading
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any, Union
import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)

JOURNAL_FILE = Path(__file__).resolve().parent.parent / "qa_db" / "trade_journal.json"


_JOURNAL_LOCK = threading.Lock()

class TradeJournalManager:
    """Manages forward-testing trade records, live P&L tracking, and performance statistics."""

    def __init__(self, storage_path: Optional[Union[str, Path]] = None):
        self.storage_path = Path(storage_path) if storage_path else JOURNAL_FILE
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        with _JOURNAL_LOCK:
            self.trades: List[Dict[str, Any]] = self._load_journal()
            # AUDIT-FIX (Round 24 — R24-5): realized-gains ledger — every
            # close is recorded as a structured tax event so the tax engine
            # can model carry-forward losses and set-off rules on REAL
            # history instead of assuming full offsettability. Owned by the
            # manager so every close path (stale-row close in log_basket,
            # stop/target hits in update_live_prices) funnels through it.
            from core.realized_gains_ledger import RealizedGainsLedger
            self.realized_ledger = RealizedGainsLedger()
            # Backfill: closes recorded before the ledger existed (the
            # journal's CLOSED/STOPPED_OUT/TARGET_HIT rows with exit prices)
            # so prior tax years are not silently lost. Idempotent per id.
            try:
                _bf = self.realized_ledger.backfill_from_journal_trades(self.trades)
                if _bf:
                    logger.info(f"[RealizedGains] Backfilled {_bf} historical close(s) from the trade journal.")
            except Exception as _bf_e:
                logger.warning(f"[RealizedGains] Backfill skipped: {_bf_e}")

    def _record_realized_close(self, trade: Dict[str, Any]) -> None:
        """AUDIT-FIX (Round 24 — R24-5): funnel every close into the ledger."""
        try:
            self.realized_ledger.record_realized_close(trade)
        except Exception as _rg_e:
            logger.warning(f"[RealizedGains] Recording close failed: {_rg_e}")

    def _load_journal(self) -> List[Dict[str, Any]]:
        """Loads trade journal entries from disk.

        ROUND 7 FIX (R7-10, HIGH): a truncated/corrupt JSON previously
        returned [] and the NEXT _save_journal() OVERWROTE the file with
        an empty list — permanent, silent loss of the entire forward-test
        record from a single bad read. Now the unreadable original is
        QUARANTINED (renamed to trade_journal.corrupt-<ts>.json) and a
        RuntimeError raised so no save can destroy the evidence. Recovery
        becomes an explicit operator action, never a silent side effect.
        """
        if self.storage_path.exists():
            try:
                with open(self.storage_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if not isinstance(data, list):
                    raise ValueError(f"Journal root is {type(data).__name__}, expected list")
                return data
            except Exception as e:
                quarantine = self.storage_path.with_name(
                    f"{self.storage_path.stem}.corrupt-{int(datetime.now().timestamp())}.json"
                )
                try:
                    os.replace(self.storage_path, quarantine)
                except Exception as qe:
                    logger.critical(
                        "[TradeJournal] Quarantine of corrupt journal failed: %s "
                        "(original left in place — do NOT let the app overwrite it)", qe,
                    )
                    raise RuntimeError(
                        f"Trade journal unreadable ({e}) and could not be quarantined; "
                        f"original preserved at {self.storage_path}"
                    ) from e
                raise RuntimeError(
                    f"Trade journal corrupt: {e}. Original quarantined to {quarantine}. "
                    "Refusing to start from an empty journal (that would destroy the record)."
                ) from e
        return []

    def _save_journal(self) -> None:
        """Saves trade journal entries atomically to disk.

        ROUND 7 FIX (R7-11, MEDIUM): the previous atomic-write used a
        FIXED temp filename (trade_journal.tmp) — a pre-planted symlink
        writes through to arbitrary targets (TOCTOU) and two concurrent
        processes interleave on the same temp file. Now: mkstemp (unique,
        race-free name, O_EXCL), fsync before replace (crash-durability —
        previously the rename could be durable while the contents were
        not, producing the empty file that R7-10 then quarantined), and
        fsync of the parent directory so the rename itself is durable.
        """
        fd = None
        tmp_path = None
        try:
            fd, tmp_path = tempfile.mkstemp(
                dir=str(self.storage_path.parent),
                prefix=f"{self.storage_path.stem}.tmp-",
                suffix=".json",
            )
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                fd = None  # fdopen now owns it
                json.dump(self.trades, f, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp_path, self.storage_path)
            tmp_path = None
            # fsync the directory so the rename is durable too
            try:
                dir_fd = os.open(str(self.storage_path.parent), os.O_RDONLY)
                try:
                    os.fsync(dir_fd)
                finally:
                    os.close(dir_fd)
            except (OSError, AttributeError):
                pass  # not all platforms support directory fsync
        except Exception as e:
            logger.error(f"Failed to save trade journal: {e}")
        finally:
            if fd is not None:
                try:
                    os.close(fd)
                except OSError:
                    pass
            if tmp_path is not None and os.path.exists(tmp_path):
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass

    def log_basket(
        self,
        basket_name: str,
        positions: List[Dict[str, Any]],
        entry_date: Optional[str] = None
    ) -> int:
        """
        Logs a full optimized swing basket into the forward-testing journal with deduplication.
        """
        entry_date_str = entry_date or datetime.now().strftime("%Y-%m-%d")
        logged_count = 0

        with _JOURNAL_LOCK:
            self.trades = self._load_journal()
            # ROUND 7 FIX (R7-12, HIGH): the dedup key previously included
            # entry_date, so each new trading day appended a FRESH ACTIVE row
            # for the same (ticker, basket) while every prior day's row stayed
            # ACTIVE — the shipped journal had 1033 rows, ~20x overstated
            # "active" counts (WELSPUNLIV.NS x49 in one basket), and every
            # price update would book P&L once per phantom row. Dedup on
            # (ticker, basket_name) among ACTIVE entries: a same-day re-log
            # refreshes the levels; a NEW day for the same position marks the
            # stale row CLOSED (exit = its last price) before appending the
            # refreshed entry, so exactly one ACTIVE row per live position.
            existing_active = {
                (t.get("ticker"), t.get("basket_name")): i
                for i, t in enumerate(self.trades) if t.get("status") == "ACTIVE"
            }

            for pos in positions:
                ticker = pos.get("ticker", "").strip()
                if not ticker:
                    continue
                # ROUND 7 FIX (R7-13, MEDIUM): a position without an entry
                # price was journaled at a FABRICATED Rs.100 with invented
                # -5%/+18% levels — all downstream P&L, win-rate and
                # stop/target evaluation ran on fiction. Positions lacking
                # entry_price are now skipped with a warning (levels may be
                # absent -> marked None and exempt from stop/target eval).
                _raw_entry = pos.get("entry_price")
                if _raw_entry is None or float(_raw_entry) <= 0:
                    logger.warning(
                        "[TradeJournal] Skipping %s (%s): no entry_price — refusing "
                        "to journal a fabricated Rs.100 entry.", ticker, basket_name,
                    )
                    continue
                entry_px = float(_raw_entry)
                sl_raw = pos.get("stop_loss_price")
                target_raw = pos.get("snell_target_price")
                sl_px = float(sl_raw) if (sl_raw is not None and float(sl_raw) > 0) else None
                target_px = float(target_raw) if (target_raw is not None and float(target_raw) > 0) else None
                weight = round(float(pos.get("weight_pct", 5.0)), 2)

                key = (ticker, basket_name)
                if key in existing_active:
                    idx = existing_active[key]
                    old = self.trades[idx]
                    if old.get("entry_date") != entry_date_str:
                        # R7-12: same position re-logged on a NEW day — close
                        # the stale row at its last marked price, then append.
                        _last_px = old.get("current_price") or old.get("entry_price")
                        if _last_px and _last_px > 0:
                            old["status"] = "CLOSED"
                            old["exit_date"] = entry_date_str
                            old["exit_price"] = round(float(_last_px), 2)
                            old["realized_pnl_%"] = round(
                                ((float(_last_px) - float(old["entry_price"]))
                                 / float(old["entry_price"])) * 100.0, 2,
                            )
                            # AUDIT-FIX (Round 24 — R24-5): record the realized event
                            self._record_realized_close(old)
                        else:
                            old["status"] = "CLOSED"
                            old["exit_date"] = entry_date_str
                    else:
                        # same-day re-log: refresh levels in place
                        self.trades[idx]["entry_price"] = round(entry_px, 2)
                        self.trades[idx]["weight_pct"] = weight
                        logged_count += 1
                        continue

                trade_entry = {
                    # R7-14 (LOW): ids derived from len(trades) collide after any
                    # pruning; use a uuid suffix (readable prefix retained).
                    "id": f"TRD_{datetime.now().strftime('%y%m%d')}_{uuid.uuid4().hex[:8]}",
                    "basket_name": basket_name,
                    "ticker": ticker,
                    "entry_date": entry_date_str,
                    "entry_price": round(entry_px, 2),
                    "current_price": round(entry_px, 2),
                    "stop_loss_price": round(sl_px, 2) if sl_px is not None else None,
                    "snell_target_price": round(target_px, 2) if target_px is not None else None,
                    "weight_pct": weight,
                    "profile_source": pos.get("profile_source", "Quantum_Ensemble"),
                    "status": "ACTIVE",
                    "unlevelled": (sl_px is None or target_px is None),
                    "unrealized_pnl_%": 0.0,
                    "realized_pnl_%": 0.0,
                    "exit_date": None,
                    "exit_price": None,
                    "notes": pos.get("notes", "Auto-logged from Quantum Annealer sweep")
                }
                self.trades.append(trade_entry)
                existing_active[key] = len(self.trades) - 1
                logged_count += 1

            self._save_journal()
        return logged_count

    def update_live_prices(self, current_prices: Dict[str, float],
                           price_sources: Optional[Dict[str, str]] = None) -> Dict[str, int]:
        """
        Updates current prices for all active trades and evaluates stop-loss / target hits.

        AUDIT-FIX (Round 24 — R24-4): every successful mark now stamps
        `last_mark_ts` (epoch seconds) and `price_mark_source` on the trade
        row, so downstream consumers (tax optimizer, dashboard) can MEASURE
        per-symbol staleness and disclose which exchange feed produced the
        mark, instead of implying freshness. `price_sources` maps ticker ->
        source label (e.g. "NSE quote-equity", "BSE (.BO) via yfinance");
        rows refreshed without a source map are labeled generically.
        """
        stats = {"updated": 0, "targets_hit": 0, "stops_triggered": 0}

        # AUDIT-FIX (Round 6, E-P3): this mutates trades and saves WITHOUT the
        # journal lock (log_basket locks) — a concurrent price update + basket
        # log raced to last-writer-wins on the JSON file, losing trades.
        with _JOURNAL_LOCK:
            return self._update_live_prices_locked(current_prices, price_sources=price_sources)

    def _update_live_prices_locked(self, current_prices: Dict[str, float],
                                   price_sources: Optional[Dict[str, str]] = None) -> Dict[str, int]:
        stats = {"updated": 0, "targets_hit": 0, "stops_triggered": 0}
        _mark_ts = datetime.now().timestamp()
        _sources = price_sources or {}

        for trade in self.trades:
            if trade["status"] != "ACTIVE":
                continue

            ticker = trade["ticker"]
            if ticker in current_prices:
                curr_px = float(current_prices[ticker])
                trade["current_price"] = round(curr_px, 2)
                # AUDIT-FIX (Round 24 — R24-4): staleness + provenance stamps
                # AUDIT-FIX (Round 27 — R27-4): FLOOR to millisecond precision
                # instead of round(). round() can push the stamp up to 0.5ms
                # into the FUTURE, so a consumer reading age = now - stamp an
                # instant later could measure a tiny NEGATIVE age (the R26-3b
                # pin flaked exactly this way in CI: -3.8e-08 h). A mark
                # timestamp must never precede a later now-read — floor() is
                # the honest stamp; measured age is then deterministically >= 0.
                trade["last_mark_ts"] = math.floor(_mark_ts * 1000.0) / 1000.0
                trade["price_mark_source"] = str(_sources.get(ticker, "unlabeled refresh"))
                pnl_pct = ((curr_px - trade["entry_price"]) / trade["entry_price"]) * 100.0
                trade["unrealized_pnl_%"] = round(pnl_pct, 2)
                stats["updated"] += 1

                # Check if target hit (R7-13: only when a real level exists)
                if trade.get("snell_target_price") and curr_px >= trade["snell_target_price"]:
                    trade["status"] = "TARGET_HIT"
                    trade["exit_price"] = round(curr_px, 2)
                    trade["exit_date"] = datetime.now().strftime("%Y-%m-%d")
                    trade["realized_pnl_%"] = round(pnl_pct, 2)
                    stats["targets_hit"] += 1
                    # AUDIT-FIX (Round 24 — R24-5): record the realized event
                    self._record_realized_close(trade)

                # Check if stop loss hit (R7-13: only when a real level exists)
                elif trade.get("stop_loss_price") and curr_px <= trade["stop_loss_price"]:
                    trade["status"] = "STOPPED_OUT"
                    trade["exit_price"] = round(curr_px, 2)
                    trade["exit_date"] = datetime.now().strftime("%Y-%m-%d")
                    trade["realized_pnl_%"] = round(pnl_pct, 2)
                    stats["stops_triggered"] += 1
                    # AUDIT-FIX (Round 24 — R24-5): record the realized event
                    self._record_realized_close(trade)

        self._save_journal()
        return stats

    def get_summary_metrics(self) -> Dict[str, Any]:
        """Calculates portfolio journal performance statistics."""
        if not self.trades:
            return {
                "total_trades": 0,
                "active_trades": 0,
                "closed_trades": 0,
                "win_rate_%": 0.0,
                "profit_factor": 0.0,
                "average_gain_%": 0.0,
                "average_loss_%": 0.0,
                "total_realized_pnl_%": 0.0
            }

        active = [t for t in self.trades if t["status"] == "ACTIVE"]
        closed = [t for t in self.trades if t["status"] in {"TARGET_HIT", "STOPPED_OUT", "CLOSED"}]

        # R7-13: entry_price == 0 (hand-edited file) previously caused a
        # ZeroDivisionError in update_live_prices; guard here and in the
        # metrics below.
        _active_safe = [t for t in active if float(t.get("entry_price") or 0) > 0]
        wins = [t["realized_pnl_%"] for t in closed if t.get("realized_pnl_%", 0.0) > 0]
        losses = [t["realized_pnl_%"] for t in closed if t["realized_pnl_%"] <= 0]

        win_rate = (len(wins) / max(len(closed), 1)) * 100.0
        tot_win = sum(wins)
        tot_loss = abs(sum(losses))
        profit_factor = round(tot_win / max(tot_loss, 0.01), 2) if tot_loss > 0 else (round(tot_win, 2) if tot_win > 0 else 1.0)

        return {
            "total_trades": len(self.trades),
            "active_trades": len(active),
            "closed_trades": len(closed),
            "win_rate_%": round(win_rate, 1),
            "profit_factor": profit_factor,
            "average_gain_%": round(float(np.mean(wins)), 2) if wins else 0.0,
            "average_loss_%": round(float(np.mean(losses)), 2) if losses else 0.0,
            "total_realized_pnl_%": round(sum(t.get("realized_pnl_%", 0.0) for t in closed), 2)
        }

    def export_to_dataframe(self) -> pd.DataFrame:
        """Returns all trades as a pandas DataFrame."""
        if not self.trades:
            return pd.DataFrame()
        return pd.DataFrame(self.trades)
