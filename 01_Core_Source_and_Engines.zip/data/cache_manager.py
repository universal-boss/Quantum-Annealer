import threading
import time
import hashlib

class ThreadSafeCache:
    """Thread-safe key/value cache with optional TTL. No external dependencies."""
    def __init__(self, ttl_seconds: float = 0.0, name: str = "cache"):
        self._store = {}
        self._lock = threading.RLock()
        self._ttl = ttl_seconds
        self._name = name

    def get(self, key, default=None):
        with self._lock:
            e = self._store.get(key)
            if e is None:
                return default
            if self._ttl > 0 and (time.time() - e["ts"]) > self._ttl:
                del self._store[key]
                return default
            return e["value"]

    def set(self, key, value):
        with self._lock:
            self._store[key] = {"value": value, "ts": time.time()}

    def pop(self, key, default=None):
        with self._lock:
            e = self._store.pop(key, None)
            return e["value"] if e else default

    def __contains__(self, key) -> bool:
        """Support `key in cache` — honours TTL expiry.

        Uses a sentinel to distinguish 'key not found' from 'value is None',
        so `key in cache` correctly returns True even when the stored value
        is None (fixed from the naive `self.get(key) is not None` pattern).
        """
        _sentinel = object()
        return self.get(key, _sentinel) is not _sentinel

    def __getitem__(self, key):
        """Support `cache[key]` — raises KeyError on miss (same as dict)."""
        sentinel = object()
        val = self.get(key, sentinel)
        if val is sentinel:
            raise KeyError(key)
        return val

    def __repr__(self) -> str:
        with self._lock:
            return f"ThreadSafeCache(name={self._name!r}, entries={len(self._store)}, ttl={self._ttl}s)"



class DataCache:
    """Thread-safe TTL-aware cache shared by all panels.
    Prevents duplicate yfinance/NSE calls for same ticker+period."""
    DEFAULT_TTL = 300
    SLOW_TTL    = 3600
    FII_TTL     = 900

    def __init__(self):
        self._store: dict = {}
        self._lock  = threading.RLock()
        self._hits  = self._misses = 0

    def get(self, key: str, default=None):
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                self._misses += 1
                return default
            value, expiry = entry
            if time.monotonic() > expiry:
                del self._store[key]
                self._misses += 1
                return default
            self._hits += 1
            return value

    def set(self, key: str, value, ttl: float = 300):
        with self._lock:
            self._store[key] = (value, time.monotonic() + ttl)

    def invalidate(self, prefix: str = ""):
        with self._lock:
            if not prefix:
                self._store.clear()
            else:
                for k in [k for k in self._store if k.startswith(prefix)]:
                    del self._store[k]

    def stats(self) -> dict:
        with self._lock:
            total = self._hits + self._misses
            return {
                "entries": len(self._store),
                "hits": self._hits,
                "misses": self._misses,
                "hit_rate": f"{self._hits/total*100:.1f}%" if total else "n/a"
            }

    def __contains__(self, key: str) -> bool:
        """Support `key in cache` checks with automatic TTL eviction."""
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                return False
            value, expiry = entry
            if time.monotonic() > expiry:
                del self._store[key]
                return False
            return True

    def cache_key(self, tickers, period, suffix="") -> str:
        h = hashlib.md5(",".join(sorted(str(t) for t in tickers)).encode()).hexdigest()[:8]
        return f"ohlcv:{h}:{period}" + (f":{suffix}" if suffix else "")


# Global Thread-Safe Caches
_LAST_YF_WARNING = ThreadSafeCache(ttl_seconds=0, name='yf_warning')
_LAST_YF_WARNING_LOCK = threading.RLock()

_CHART_SSL_MODEL_CACHE = ThreadSafeCache(ttl_seconds=0, name='chart_ssl')
_CHART_SSL_MODEL_CACHE_LOCK = threading.RLock()

# C5-fix: previously this module created its own local DataCache() instance that was
# NEVER populated by safe_download (which uses enterprise.cache_layer.get_cache()).
# live_verify.py:153 imports _DATA_CACHE from here and calls invalidate("ohlcv:") on
# it, but the actual cache used by safe_download lives in enterprise.cache_layer — so
# the invalidation was a no-op. Re-export the singleton so both share the same object.
from enterprise.cache_layer import get_cache as _get_enterprise_cache
_DATA_CACHE = _get_enterprise_cache()
