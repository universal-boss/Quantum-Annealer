"""
data/corporate_actions_registry.py
====================================
Permanent Corporate Actions Registry for NSE/BSE (2024–2026).
Provides a canonical, live-verified mapping of all demergers, renamings,
and delistings so the Quantum Annealer screener never fetches stale tickers.

USAGE:
    from data.corporate_actions_registry import resolve_ticker, validate_ticker_list

    resolve_ticker("TATAMOTORS")  -> ["TATAMOTORS"]
    resolve_ticker("ITC")         -> ["ITC", "ITCHOTELS"]
    resolve_ticker("RAYMOND")     -> ["RAYMOND", "RAYMONDLSL"]
    resolve_ticker("ABBPPS")      -> ["POWERINDIA"]  # Hitachi Energy India (INR 34,190)
    resolve_ticker("ACRYSIL")     -> ["CARYSIL"]     # Carysil Ltd (INR 1,155)
    resolve_ticker("ABCPAPER")    -> ["KUANTUM"]     # Kuantum Papers (INR 74.2)
    resolve_ticker("ACCELFRONTLINE")-> ["INSPIRISYS"] # Inspirisys Solutions (INR 93.9)
    resolve_ticker("ACCELYAKALE") -> ["ACCELYA"]     # Accelya Solutions (INR 1,138)
    resolve_ticker("JINDALCOTEX") -> []              # delisted
    resolve_ticker("INFY")        -> ["INFY"]          # no change
"""
from __future__ import annotations
import logging

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# 1. DEMERGER MAP
# Format: OLD_RAW_SYMBOL: dict
# replacement: list of CURRENT active NSE symbols (raw, no .NS suffix)
# ---------------------------------------------------------------------------
DEMERGER_MAP: dict[str, dict] = {
    "TATAMOTORS": {
        "description": "Tata Motors demerged Nov 2025 into TML Commercial Vehicles (TMCV) and Tata Motors Passenger Vehicles (TMPV), both trading separately on NSE.",
        "replacement": ["TMCV", "TMPV"],
        "parent_stays_listed": False,
        "effective_date": "2025-11-12",
        "live_verified": True,
    },
    "ITC": {
        "description": "ITC Hotels demerged Jan 2025. ITC itself stays listed; ITCHOTELS.NS is the new spun-off entity.",
        "replacement": ["ITC", "ITCHOTELS"],
        "parent_stays_listed": True,
        "effective_date": "2025-01-01",
        "live_verified": True,
        "verified_ltps": {"ITC": 269.40, "ITCHOTELS": 164.98},
    },
    "RAYMOND": {
        "description": "Raymond Lifestyle demerged May 2025. RAYMOND stays listed; RAYMONDLSL is spun off.",
        "replacement": ["RAYMOND", "RAYMONDLSL"],
        "parent_stays_listed": True,
        "effective_date": "2025-05-01",
        "live_verified": True,
        "verified_ltps": {"RAYMOND": 643.15, "RAYMONDLSL": 726.95},
    },
    "ABFRL": {
        "description": "ABFRL demerged Madura Fashion May 2025. ABFRL stays listed.",
        "replacement": ["ABFRL"],
        "parent_stays_listed": True,
        "effective_date": "2025-05-01",
        "live_verified": True,
        "verified_ltps": {"ABFRL": 54.35},
        "note": "MADURAFS.NS not yet on yfinance as of Aug 2026.",
    },
    "GENUSPOWER": {
        "description": "Genus Power demerged Genus Smart Metering Feb 2026. GENUSPOWER stays.",
        "replacement": ["GENUSPOWER"],
        "parent_stays_listed": True,
        "effective_date": "2026-02-01",
        "live_verified": True,
        "verified_ltps": {"GENUSPOWER": 337.95},
        "note": "GENUSSMRT.NS not yet on yfinance as of Aug 2026.",
    },
    "ALLCARGO": {
        "description": "Allcargo demerged Terminals + ECU Nov 2025. ALLCARGO stays.",
        "replacement": ["ALLCARGO"],
        "parent_stays_listed": True,
        "effective_date": "2025-11-01",
        "live_verified": True,
        "verified_ltps": {"ALLCARGO": 12.17},
    },
    "TRIVENIENG": {
        "description": "Triveni Engineering demerged Power Transmission Jul 2026. Old ticker replaced by TRIVENI.",
        "replacement": ["TRIVENI"],
        "effective_date": "2026-07-01",
        "live_verified": True,
        "verified_ltps": {"TRIVENI": 295.28},
    },
    "GUJARATGAS": {
        "description": "Gujarat Gas demerged GSPL Transmission Jul 2026. Both returning 404 on yfinance.",
        "replacement": [],
        "effective_date": "2026-07-01",
        "live_verified": False,
        "note": "GUJARATGAS.NS and GSPLTRANS.NS both returning 404 on yfinance Aug 2026.",
    },
    "INOXGREEN": {
        "description": "Inox Green demerged Inox Renewable Solutions Aug 2026. INOXGREEN stays.",
        "replacement": ["INOXGREEN"],
        "parent_stays_listed": True,
        "effective_date": "2026-08-01",
        "live_verified": True,
        "verified_ltps": {"INOXGREEN": 178.34},
    },
    "VEDL": {
        "description": "Vedanta split into 6 sector entities May 2026. VEDL stays as holding co.",
        "replacement": ["VEDL"],
        "parent_stays_listed": True,
        "effective_date": "2026-05-01",
        "live_verified": True,
        "verified_ltps": {"VEDL": 279.0},
        "demerged_entities": [
            "Vedanta Aluminium & Power",
            "Vedanta Iron & Steel",
            "Vedanta Oil & Gas",
            "Vedanta Base Metals",
            "Vedanta Semiconductors & Display",
            "Vedanta Ltd (Residual Zinc+Silver)",
        ],
    },
}

# ---------------------------------------------------------------------------
# 2. RENAMED MAP  (OLD_TICKER -> NEW_TICKER, live-verified)
# ---------------------------------------------------------------------------
RENAMED_MAP: dict[str, str] = {
    "ABBPPS":          "POWERINDIA",    # Hitachi Energy India Ltd (NSE: POWERINDIA)
    "HITACHIENERGY":   "POWERINDIA",    # Alias -> POWERINDIA
    "ACRYSIL":         "CARYSIL",       # Carysil Ltd (NSE: CARYSIL)
    "ABCPAPER":        "KUANTUM",       # Kuantum Papers Ltd (NSE: KUANTUM)
    "ACCELFRONTLINE":  "INSPIRISYS",    # Inspirisys Solutions Ltd (NSE: INSPIRISYS)
    "ACCELYAKALE":     "ACCELYA",       # Accelya Solutions India Ltd (NSE: ACCELYA)
    "ACKNIT":          "ACKNIT.BO",     # Acknit Industries Ltd (BSE: ACKNIT)
    "ACKNITIND":       "ACKNIT.BO",     # Acknit Industries Ltd
    "SOFTSOL":         "SOFTSLIT",      # Softsol IT Solutions Ltd
    "INFIBEAM":        "INFIBEAM",      # Infibeam stays listed; ODIGMA spun off
}

# ---------------------------------------------------------------------------
# 3. PERMANENTLY DELISTED SET
# ---------------------------------------------------------------------------
DELISTED_SET: set[str] = {
    "ADITYABIRLAREAL",
    "VISTAARF",
    "GERA",
    "VARANIUMCLOUD",
    "SSINFRA",
    "PENTAGOLD",
    "JINDALCOTEX",
    "SONISOYA",
}


# ---------------------------------------------------------------------------
# 4. DYNAMIC SELF-HEALING & RESOLVER FUNCTIONS
# ---------------------------------------------------------------------------

def resolve_ticker(raw_symbol: str) -> list[str]:
    """
    Returns current valid NSE symbols for a given ticker.
    1. Checks DELISTED_SET -> drops permanently delisted stocks
    2. Checks DEMERGER_MAP / RENAMED_MAP -> fast resolution for structured actions
    3. DYNAMIC FALLBACK: Queries DynamicSecurityMaster (live NSE EQUITY_L.csv & symbolchange.csv)
       to automatically resolve any new or future corporate action without manual code edits.
    """
    sym = raw_symbol.strip().upper().replace(".NS", "").replace(".BO", "")
    if not sym or sym == "CASH":
        return []

    # 1. Delisted
    if sym in DELISTED_SET:
        logger.warning(f"[CorporateActions] {sym} is PERMANENTLY DELISTED — removed from universe.")
        return []

    # 2. Known Renamed
    if sym in RENAMED_MAP:
        new_sym = RENAMED_MAP[sym]
        return [new_sym]

    # 3. Known Demerged
    if sym in DEMERGER_MAP:
        record = DEMERGER_MAP[sym]
        replacements = record.get("replacement", [sym])
        if not replacements:
            logger.warning(f"[CorporateActions] {sym} DEMERGED but no active ticker on yfinance yet.")
            return []
        return replacements

    # 4. Fully Automated Dynamic Resolution from Live NSE Master
    try:
        from data.dynamic_security_master import resolve_dynamic_ticker
        dyn_resolved = resolve_dynamic_ticker(sym)
        if dyn_resolved and dyn_resolved != [sym]:
            logger.info(f"[CorporateActions] Dynamic Exchange Master auto-resolved {sym} -> {dyn_resolved}")
            return dyn_resolved
    except Exception as e:
        logger.debug(f"[CorporateActions] Dynamic master lookup error: {e}")

    return [sym]


def validate_ticker_list(tickers: list[str]) -> list[str]:
    """
    Bulk-resolve a portfolio ticker list.
    Expands demergers, removes delisted, corrects renamed — deduplicates output.
    """
    resolved: list[str] = []
    seen: set[str] = set()
    for t in tickers:
        for r in resolve_ticker(t):
            if r not in seen:
                seen.add(r)
                resolved.append(r)
    return resolved


def get_demerger_info(raw_symbol: str) -> dict | None:
    """Returns the full demerger record for a symbol, or None."""
    sym = raw_symbol.strip().upper().replace(".NS", "").replace(".BO", "")
    return DEMERGER_MAP.get(sym)
