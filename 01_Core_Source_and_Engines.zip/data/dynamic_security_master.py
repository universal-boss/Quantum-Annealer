"""
data/dynamic_security_master.py
=================================
Automated, Self-Healing Exchange Security Master & Corporate Action Ingestion Engine.

ELIMINATES MANUAL HARDCODING BY:
1. Automatically downloading the official NSE Security Master (EQUITY_L.csv - 2,500+ active equities)
2. Ingesting official NSE Symbol Change histories (symbolchange.csv)
3. Dynamic ISIN & Company Name Fuzzy Disambiguation for demerged/renamed tickers
4. Persistent 24-hour TTL caching in qa_db/dynamic_security_master.json
"""
from __future__ import annotations
import datetime
import logging
import json
import time
import io
import re
from pathlib import Path
from typing import List, Dict, Optional, Tuple, Set
import requests
import pandas as pd

logger = logging.getLogger(__name__)

WORKSPACE = Path(__file__).resolve().parent.parent
CACHE_FILE = WORKSPACE / "qa_db" / "dynamic_security_master.json"
CACHE_TTL_HOURS = 24

class DynamicSecurityMaster:
    """
    Self-Healing Security Master that dynamically synchronizes with official
    NSE master lists and automatically resolves renamed, demerged, or delisted tickers.
    """
    _instance: Optional[DynamicSecurityMaster] = None
    _active_equities: Dict[str, Dict] = {}       # SYMBOL -> {name, isin, series, listing_date}
    _isin_to_symbol: Dict[str, List[str]] = {}    # ISIN -> [SYMBOLS]
    _name_to_symbol: Dict[str, List[str]] = {}    # NORMALIZED_NAME -> [SYMBOLS]
    _symbol_changes: Dict[str, str] = {}         # OLD_SYMBOL -> NEW_SYMBOL
    _resolved_cache: Dict[str, List[str]] = {}   # QUERY_SYMBOL -> [ACTIVE_SYMBOLS]
    _last_sync_timestamp: float = 0.0

    NSE_EQUITY_MASTER_URL = "https://archives.nseindia.com/content/equities/EQUITY_L.csv"
    NSE_SYMBOL_CHANGE_URL = "https://archives.nseindia.com/content/equities/symbolchange.csv"
    HEADERS = {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': '*/*',
    }

    @classmethod
    def get_instance(cls) -> DynamicSecurityMaster:
        if cls._instance is None:
            cls._instance = DynamicSecurityMaster()
            cls._instance.initialize()
        return cls._instance

    def initialize(self) -> None:
        """Loads cached security master or syncs live from NSE feeds."""
        self._load_local_cache()
        # If cache is older than TTL or empty, trigger background sync
        if not self._active_equities or (time.time() - self._last_sync_timestamp > CACHE_TTL_HOURS * 3600):
            self.sync_with_exchange_master()

    def _load_local_cache(self) -> None:
        if CACHE_FILE.exists():
            try:
                with open(CACHE_FILE, "r") as f:
                    data = json.load(f)
                    self._active_equities = data.get("active_equities", {})
                    self._symbol_changes = data.get("symbol_changes", {})
                    self._resolved_cache = data.get("resolved_cache", {})
                    self._last_sync_timestamp = data.get("last_sync_timestamp", 0.0)
                    self._rebuild_indices()
                    logger.info(f"[DynamicSecurityMaster] Loaded {len(self._active_equities)} equities from local cache.")
            except Exception as e:
                logger.warning(f"[DynamicSecurityMaster] Could not read local cache: {e}")

    def _save_local_cache(self) -> None:
        try:
            CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
            payload = {
                "active_equities": self._active_equities,
                "symbol_changes": self._symbol_changes,
                "resolved_cache": self._resolved_cache,
                "last_sync_timestamp": self._last_sync_timestamp
            }
            # AUDIT-FIX (Round 49 — R49-2): atomic cache write (unique tmp +
            # os.replace). The previous plain open(w)+json.dump could leave a
            # truncated cache on a crash; the reader then started from an
            # EMPTY master, and whenever the NSE re-sync was unavailable the
            # R38/R40 fail-closed listing-age gates ran against no data at
            # all (every candidate unverifiable) instead of the last-good
            # 24h cache this file exists to provide.
            import os as _os
            import threading as _threading
            _tmp = CACHE_FILE.with_suffix(
                CACHE_FILE.suffix + f".{_os.getpid()}.{_threading.get_ident()}.tmp")
            with open(_tmp, "w") as f:
                json.dump(payload, f, indent=2)
            _os.replace(str(_tmp), str(CACHE_FILE))
            logger.info(f"[DynamicSecurityMaster] Persisted {len(self._active_equities)} equities to {CACHE_FILE}")
        except Exception as e:
            logger.warning(f"[DynamicSecurityMaster] Cache save failed: {e}")

    def _rebuild_indices(self) -> None:
        self._isin_to_symbol.clear()
        self._name_to_symbol.clear()
        for sym, meta in self._active_equities.items():
            isin = meta.get("isin", "")
            if isin:
                self._isin_to_symbol.setdefault(isin, []).append(sym)
            name = self._normalize_company_name(meta.get("name", ""))
            if name:
                self._name_to_symbol.setdefault(name, []).append(sym)

    @staticmethod
    def _normalize_company_name(name: str) -> str:
        clean = re.sub(r'[^A-Za-z0-9 ]+', ' ', str(name).upper())
        # Remove common legal entity suffixes
        for stop in ["LIMITED", "LTD", "PVT", "PRIVATE", "INDIA", "CORP", "CORPORATION", "HOLDINGS"]:
            clean = re.sub(rf'\b{stop}\b', '', clean)
        return ' '.join(clean.split())

    def sync_with_exchange_master(self) -> bool:
        """
        Dynamically downloads the official NSE Master list and symbol changes.
        """
        logger.info("[DynamicSecurityMaster] Syncing live exchange security master from NSE...")
        success = False
        try:
            # 1. Fetch EQUITY_L.csv
            resp = requests.get(self.NSE_EQUITY_MASTER_URL, headers=self.HEADERS, timeout=10)
            if resp.status_code == 200:
                df = pd.read_csv(io.StringIO(resp.text))
                df.columns = [c.strip() for c in df.columns]
                new_equities = {}
                for _, row in df.iterrows():
                    sym = str(row.get('SYMBOL', '')).strip().upper()
                    if not sym or sym == 'NAN':
                        continue
                    new_equities[sym] = {
                        "name": str(row.get('NAME OF COMPANY', '')).strip(),
                        "isin": str(row.get('ISIN NUMBER', '')).strip(),
                        "series": str(row.get('SERIES', 'EQ')).strip(),
                        "listing_date": str(row.get('DATE OF LISTING', '')).strip()
                    }
                if new_equities:
                    self._active_equities = new_equities
                    success = True
                    logger.info(f"[DynamicSecurityMaster] Successfully ingested {len(new_equities)} active NSE equities.")

            # 2. Fetch symbolchange.csv
            resp_change = requests.get(self.NSE_SYMBOL_CHANGE_URL, headers=self.HEADERS, timeout=10)
            if resp_change.status_code == 200:
                df_change = pd.read_csv(io.StringIO(resp_change.text), header=None)
                # Format: [Company Name, Old Symbol, New Symbol, Change Date]
                if len(df_change.columns) >= 3:
                    for _, row in df_change.iterrows():
                        old_s = str(row.iloc[1]).strip().upper()
                        new_s = str(row.iloc[2]).strip().upper()
                        if old_s and new_s and old_s != 'NAN' and new_s != 'NAN':
                            self._symbol_changes[old_s] = new_s

            if success:
                self._last_sync_timestamp = time.time()
                # R38: resolutions derived from the PREVIOUS master state
                # must not outlive a successful refresh — self-healing means
                # the answer can CHANGE when the exchange record changes.
                self._resolved_cache.clear()
                self._rebuild_indices()
                self._save_local_cache()

        except Exception as e:
            logger.warning(f"[DynamicSecurityMaster] Live sync from NSE encountered: {e}. Utilizing cached master.")

        return success

    def resolve(self, raw_query: str) -> List[str]:
        """
        Dynamically resolves any ticker string (even stale, renamed, or demerged)
        into current, active exchange-tradeable symbols.
        """
        sym = raw_query.strip().upper().replace(".NS", "").replace(".BO", "")
        if not sym or sym == "CASH":
            return []

        # Check memory cache first
        if sym in self._resolved_cache:
            return self._resolved_cache[sym]

        # 0. Check canonical NSE alias corrections (e.g. UNICOMM -> UNIECOM, DEE-DEV -> DEEDEV)
        _CANONICAL_NSE_ALIASES = {
            "UNICOMM": "UNIECOM",
            "DEE-DEV": "DEEDEV",
            "DIFFUSN": "DIFFNKG",
            "KRNHEAT": "KRN",
            "BHARTI-HEX": "BHARTIHEXA",
            "WESTERNECO": "WCIL",
            "PLATINUM": "PLATIND",
        }
        if sym in _CANONICAL_NSE_ALIASES:
            canonical_alias = _CANONICAL_NSE_ALIASES[sym]
            if canonical_alias in self._active_equities:
                self._resolved_cache[sym] = [canonical_alias]
                return [canonical_alias]

        # 1. Exact match in active NSE Master
        if sym in self._active_equities:
            self._resolved_cache[sym] = [sym]
            return [sym]

        # 2. Match in official NSE Symbol Change registry
        if sym in self._symbol_changes:
            new_sym = self._symbol_changes[sym]
            if new_sym in self._active_equities:
                logger.info(f"[DynamicSecurityMaster] Auto-corrected renamed symbol: {sym} -> {new_sym}")
                self._resolved_cache[sym] = [new_sym]
                self._save_local_cache()
                return [new_sym]

        # 3. Dynamic Name & Token Disambiguation (e.g. "TATAMOTORS", "ABBPPS", "ACRYSIL")
        normalized_q = self._normalize_company_name(sym)
        tokens = [t for t in re.findall(r'[A-Za-z0-9]+', sym) if len(t) > 2]
        
        candidates = []
        for active_sym, meta in self._active_equities.items():
            comp_name_norm = self._normalize_company_name(meta["name"])
            
            # Check token overlap
            if tokens and all(t in comp_name_norm for t in tokens):
                candidates.append(active_sym)
            elif normalized_q and normalized_q in comp_name_norm:
                candidates.append(active_sym)

        if candidates:
            logger.info(f"[DynamicSecurityMaster] Auto-resolved {sym} -> {candidates} via Dynamic Master")
            self._resolved_cache[sym] = candidates
            self._save_local_cache()
            return candidates

        # 4. Fallback pass-through
        return [sym]

    def is_active(self, symbol: str) -> bool:
        resolved = self.resolve(symbol)
        return bool(resolved and resolved[0] in self._active_equities)

    def get_company_meta(self, symbol: str) -> Optional[Dict]:
        resolved = self.resolve(symbol)
        if resolved:
            return self._active_equities.get(resolved[0])
        sym = symbol.strip().upper().replace(".NS", "").replace(".BO", "")
        return self._active_equities.get(sym)

    def get_listing_age_days(self, symbol: str, as_of_date: Optional[datetime.date] = None) -> Optional[int]:
        """Returns calendar days since NSE exchange listing date, or None if unknown.
        If as_of_date is provided, computes age relative to that date (defaults to today).
        Deterministic when as_of_date is pinned (the regression tests pin it).
        """
        meta = self.get_company_meta(symbol)
        if meta and meta.get("listing_date"):
            try:
                ld_str = meta["listing_date"]
                ld = datetime.datetime.strptime(ld_str, "%d-%b-%Y").date()
                ref_date = as_of_date if as_of_date is not None else datetime.date.today()
                return (ref_date - ld).days
            except Exception:
                pass
        return None

    def is_recent_ipo(
        self,
        symbol: str,
        min_days: int = 365,
        max_days: int = 730,
        as_of_date: Optional[datetime.date] = None,
    ) -> bool:
        """
        Single source of truth for 1–2 year IPO eligibility:
        1. Must be an active, verified NSE equity (not phantom/delisted/untradable).
        2. Must have an official exchange listing date strictly within [min_days, max_days] calendar days.
           Default: strictly [365, 730] calendar days (1 to 2 years post-listing, both bounds enforced).
           - Rejects unseasoned issues (< 365 days): needs at least 1 year seasoning / 4 quarters of public reporting.
           - Rejects mature legacy equities (> 730 days): outside the 1-2 year high-growth IPO window.

        R38: the allow_extended_window escape hatch (up to 1000 days) was
        REMOVED — it had zero production callers and directly contradicted
        the user's 1-2 year contract. Both bounds are now absolute.
        """
        if not self.is_active(symbol):
            return False
        age_days = self.get_listing_age_days(symbol, as_of_date=as_of_date)
        if age_days is None:
            return False
        return min_days <= age_days <= max_days



# Global Helper Functions for Clean Imports
def resolve_dynamic_ticker(ticker: str) -> List[str]:
    return DynamicSecurityMaster.get_instance().resolve(ticker)

def validate_universe_dynamically(tickers: List[str]) -> List[str]:
    master = DynamicSecurityMaster.get_instance()
    resolved = []
    seen = set()
    for t in tickers:
        for r in master.resolve(t):
            if r not in seen:
                seen.add(r)
                resolved.append(r)
    return resolved
