import time
import contextlib
import io
import logging
import random
import pandas as pd
try:
    import yfinance as yf
except ImportError:
    import logging as _swallow_log_mod
    _swallow_log_mod.getLogger("quantum_annealer").debug(
        "[AUDIT-FIX P2-5] swallowed exception", exc_info=True
    )
    yf = None  # type: ignore
from concurrent.futures import as_completed

_log = logging.getLogger(__name__)

from utils import (
    _ACTIVE_STOP_EVENT,
    _ACTIVE_STOP_EVENT_LOCK,
    check_stop,
    chunked,
    ConcurrencyPolicy,
    _DaemonThreadPoolExecutor,
    _DATA_PROVIDER,
    log_emit
)
from math_engine.indicators import (
    TRADING_DAYS_PER_YEAR,
    max_drawdown,
    trailing_return,
    annualized_vol,
    downside_vol,
    compute_rsi
)
from data.cache_manager import (
    _LAST_YF_WARNING,
    _LAST_YF_WARNING_LOCK
)
from enterprise.cache_layer import get_cache, CacheLayer as DataCache
_DATA_CACHE = get_cache()

def _download_batch(batch: list, period: str, auto_adjust: bool = True, interval: str = None, cfg: dict = None):
    buf = io.StringIO()
    raw = pd.DataFrame()
    from utils import get_provider
    provider = get_provider()
    provider_override = (cfg or {}).get("DATA_PROVIDER")
    
    max_retries = 3
    for attempt in range(max_retries):
        with contextlib.redirect_stderr(buf), contextlib.redirect_stdout(buf):
            try:
                if provider_override != "YFinance" and provider is not None and provider.__class__.__name__ != "YFinanceProvider":
                    raw = provider.get_prices(
                        tickers=batch if isinstance(batch, list) else [batch],
                        period=period,
                        interval=interval or "1d",
                        auto_adjust=auto_adjust)
                else:
                    raw = yf.download(
                        tickers=batch if isinstance(batch, list) else [batch],
                        period=period,
                        interval=interval or "1d",
                        auto_adjust=auto_adjust,
                        progress=False,
                        repair=True,
                    )
                if raw is not None and not raw.empty:
                    break
            except Exception as _exc:
                if attempt == max_retries - 1:
                    print(f"[DownloadError] Attempt {attempt+1}/{max_retries} failed: {type(_exc).__name__}: {_exc}")
                else:
                    time.sleep(1.5 * (attempt + 1))
    return raw, buf.getvalue()

def safe_download(tickers: list, period: str, auto_adjust: bool = True, log_cb=None, interval: str = None, batch_size_override: int = None, cfg: dict = None) -> pd.DataFrame:
    check_stop()
    if not tickers:
        return pd.DataFrame()
    unique = list(dict.fromkeys(tickers))
    _max_workers = min(len(unique), ConcurrencyPolicy.workers("download", cfg))
    
    # ── Check if cache bypass is requested via FORCE_REBUILD ──────────────
    force_rebuild = cfg is not None and cfg.get("FORCE_REBUILD") is True
    cache_prewarmed = cfg is not None and cfg.get("_CACHE_PREWARMED") is True
    bypass_cache = force_rebuild and not cache_prewarmed
    
    if bypass_cache:
        if log_cb:
            log_emit(log_cb, "[Cache] Bypassing cache checks due to FORCE_REBUILD.")
            
    # Define _cache_key for potential set() calls later
    _cache_key = _DATA_CACHE.cache_key(unique, period, suffix=str(interval or "") + f":aa={int(auto_adjust)}")

    # ── 1. Check full-list cache key ──────────────────────────────────────
    if not bypass_cache:
        _cached = _DATA_CACHE.get(_cache_key)
        if _cached is not None:
            return _cached
        
    # ── 2. Check individual ticker caches & fetch missing ─────────────────
    suffix = str(interval or "") + f":aa={int(auto_adjust)}"
    cached_singles = {}
    missing = []
    if not bypass_cache:
        for t in unique:
            single_df = _DATA_CACHE.get(f"ohlcv:single:{t}:{period}:{suffix}")
            if single_df is not None and not single_df.empty:
                cached_singles[t] = single_df
            else:
                missing.append(t)
    else:
        missing = list(unique)

    if not missing and cached_singles:
        try:
            dfs_to_concat = []
            cols_tuples = []
            for t, s_df in cached_singles.items():
                dfs_to_concat.append(s_df)
                for col_name in s_df.columns:
                    cols_tuples.append((col_name, t))
            merged = pd.concat(dfs_to_concat, axis=1)
            merged.columns = pd.MultiIndex.from_tuples(cols_tuples)
            _DATA_CACHE.set(_cache_key, merged, ttl=DataCache.DEFAULT_TTL)
            if log_cb:
                log_emit(log_cb, f"[Cache] ⚡ Hit individual ticker caches for all {len(unique)} assets!")
            return merged
        except Exception as e:
            if log_cb:
                log_emit(log_cb, f"[CacheReconstruct] skipped: {type(e).__name__}: {e}")

    tickers_to_download = missing if missing else unique
    # SF-fix1: Remember which tickers were already cached so we can merge them
    # back into outputs after the download loop (partial cache hits previously
    # returned only the newly-downloaded subset, silently dropping cached tickers).
    _partial_cached_singles = dict(cached_singles) if missing and cached_singles else {}

    # ── 3. Run download batches ───────────────────────────────────────────
    is_angelone = cfg is not None and cfg.get("DATA_PROVIDER") in ("AngelOne", "AngelOneSmartAPI")
    if batch_size_override is not None:
        batch_size = max(1, min(int(batch_size_override), len(tickers_to_download)))
    elif is_angelone:
        batch_size = 200  # High-speed batch size for API
    elif len(tickers_to_download) > 500:
        batch_size = 50  # Anti-ban batch size for large NSE universe downloads
    elif interval:
        batch_size = min(50, max(10, len(tickers_to_download)))
    else:
        batch_size = min(100, max(10, len(tickers_to_download)))

    batches = list(chunked(tickers_to_download, batch_size))
    outputs = []

    def fetch_batch(idx_batch):
        idx, batch = idx_batch
        if not is_angelone and len(tickers_to_download) > 500 and idx > 0:
            time.sleep(0.12)  # Tiny 120ms stagger between large universe batches prevents Yahoo burst rate-limiting
        if len(batches) <= 5 or idx == 0 or idx == len(batches) - 1 or (idx + 1) % 10 == 0:
            log_emit(log_cb, f"[DataBundle] Downloading batch {idx+1}/{len(batches)} ({len(batch)} tickers: {', '.join(batch[:3])}...)")
        raw_df = pd.DataFrame()
        for attempt in range(3):
            with _ACTIVE_STOP_EVENT_LOCK:
                _ev = _ACTIVE_STOP_EVENT
            if _ev is not None and _ev.is_set():
                break
            is_rate_limited = False
            try:
                raw_df, noise = _download_batch(batch, period, auto_adjust=auto_adjust, interval=interval, cfg=cfg)
                if noise and any(x in noise.lower() for x in ["rate limit", "invalid crumb", "unauthorized"]):
                    is_rate_limited = True
                    now = time.time()
                    with _LAST_YF_WARNING_LOCK:
                        w = _LAST_YF_WARNING.get("warning", {"text": "", "time": 0.0})
                        if w.get("text") != "rate_limit" or (now - w.get("time", 0.0)) >= 20:
                            _LAST_YF_WARNING.set("warning", {"text": "rate_limit", "time": now})
                            log_emit(log_cb, "Yahoo Finance is rate-limiting requests. Skipping blocked symbols.")
                if raw_df is not None and not raw_df.empty:
                    break
            except Exception as e:
                now = time.time()
                with _LAST_YF_WARNING_LOCK:
                    w = _LAST_YF_WARNING.get("warning", {"text": "", "time": 0.0})
                    msg = f"Download failed: {type(e).__name__}"
                    if w.get("text") != msg or (now - w.get("time", 0.0)) >= 20:
                        _LAST_YF_WARNING.set("warning", {"text": msg, "time": now})
                        log_emit(log_cb, f"[WARN] Download attempt failed: {type(e).__name__}: {e}")
            # L15-fix: exponential backoff with jitter, no sleep after final attempt
            if attempt < 2:  # max_attempts (3) - 1
                sleep_s = (2 ** attempt) + random.uniform(0, 0.5)
                if is_rate_limited:
                    sleep_s *= 5
                time.sleep(sleep_s)
            
        if raw_df is None or raw_df.empty:
            cached_dfs = []
            for t in batch:
                cached_t = _DATA_CACHE.get(f"ohlcv:single:{t}:{period}:{suffix}")
                if cached_t is not None:
                    # Explicitly convert the simple columns to a MultiIndex with ticker 't' as level 1
                    cached_t = cached_t.copy()
                    # H6-fix: guard against already-MultiIndex columns (newer yfinance)
                    if not isinstance(cached_t.columns, pd.MultiIndex):
                        cached_t.columns = pd.MultiIndex.from_product([cached_t.columns, [t]])
                    cached_dfs.append(cached_t)
            if len(cached_dfs) == len(batch) and len(batch) > 0:
                try:
                    raw_df = pd.concat(cached_dfs, axis=1)
                    if log_cb:
                        log_emit(log_cb, f"[Fallback Cache] ⚡ Reconstructed {len(batch)} symbols from offline cache tier to bypass yfinance rate-limiting.")
                except Exception as e:
                    # L16-fix: log cache reconstruct failure instead of silently swallowing
                    if log_cb:
                        log_emit(log_cb, f"[CacheReconstruct] skipped: {type(e).__name__}: {e}")

        # Cache each ticker individually for granular retrieval
        if raw_df is not None and not raw_df.empty:
            if isinstance(raw_df.columns, pd.MultiIndex):
                for t in batch:
                    if t in raw_df.columns.levels[0]:
                        single_df = raw_df[t].copy()
                        _DATA_CACHE.set(f"ohlcv:single:{t}:{period}:{suffix}", single_df, ttl=DataCache.SLOW_TTL)
                    elif t in raw_df.columns.levels[1]:
                        single_df = raw_df.xs(t, axis=1, level=1).copy()
                        _DATA_CACHE.set(f"ohlcv:single:{t}:{period}:{suffix}", single_df, ttl=DataCache.SLOW_TTL)
            else:
                if len(batch) == 1:
                    t = batch[0]
                    _DATA_CACHE.set(f"ohlcv:single:{t}:{period}:{suffix}", raw_df.copy(), ttl=DataCache.SLOW_TTL)
        return raw_df

    with _DaemonThreadPoolExecutor(max_workers=min(len(batches), _max_workers)) as executor:
        futures = [executor.submit(fetch_batch, (i, b)) for i, b in enumerate(batches)]
        for future in as_completed(futures):
            check_stop()
            result = future.result()
            if result is not None and not result.empty:
                outputs.append(result)

    # SF-fix1: Merge previously-cached frames back with newly-downloaded ones
    if _partial_cached_singles:
        try:
            cached_dfs_to_merge = []
            for t, s_df in _partial_cached_singles.items():
                s_df_copy = s_df.copy()
                if not isinstance(s_df_copy.columns, pd.MultiIndex):
                    s_df_copy.columns = pd.MultiIndex.from_product([s_df_copy.columns, [t]])
                cached_dfs_to_merge.append(s_df_copy)
            if cached_dfs_to_merge:
                outputs = cached_dfs_to_merge + outputs
                if log_cb:
                    log_emit(log_cb, f"[Cache] Merged {len(cached_dfs_to_merge)} cached + {len(outputs)-len(cached_dfs_to_merge)} downloaded frames.")
        except Exception as merge_e:
            if log_cb:
                log_emit(log_cb, f"[CacheMerge] skipped: {type(merge_e).__name__}: {merge_e}")

    if not outputs:
        return pd.DataFrame()

    def _cache_and_return(df):
        if not df.empty:
            _DATA_CACHE.set(_cache_key, df, ttl=DataCache.DEFAULT_TTL)
        return df

    if len(outputs) == 1:
        return _cache_and_return(outputs[0])
    try:
        merged = pd.concat(outputs, axis=1)
        if merged.columns.duplicated().any():
            merged = merged.loc[:, ~merged.columns.duplicated(keep='first')]
        return _cache_and_return(merged)
    except Exception as e:
        # L16-fix: log concat failure instead of silently swallowing
        if log_cb:
            log_emit(log_cb, f"[CacheReconstruct] skipped: {type(e).__name__}: {e}")
        return _cache_and_return(outputs[0])

def extract_field_panel(raw: pd.DataFrame, field: str, requested_tickers: list) -> pd.DataFrame:
    if raw is None or raw.empty:
        return pd.DataFrame(index=pd.Index([], name="Date"), columns=requested_tickers)
    if isinstance(raw.columns, pd.MultiIndex):
        level0_vals = [str(x) for x in raw.columns.get_level_values(0)]
        level1_vals = [str(x) for x in raw.columns.get_level_values(1)]
        level0_lower = [x.lower() for x in level0_vals]
        level1_lower = [x.lower() for x in level1_vals]
        if field.lower() in level0_lower:
            matched = level0_vals[level0_lower.index(field.lower())]
            out = raw[matched].copy()
        elif field.lower() in level1_lower:
            matched = level1_vals[level1_lower.index(field.lower())]
            out = raw.xs(matched, axis=1, level=1).copy()
        else:
            return pd.DataFrame(index=raw.index, columns=requested_tickers)
    else:
        col_lower = [c.lower() for c in raw.columns]
        if field.lower() in col_lower:
            matched = list(raw.columns)[col_lower.index(field.lower())]
            out = raw[[matched]].copy()
            if len(requested_tickers) == 1:
                out.columns = requested_tickers
        else:
            return pd.DataFrame(index=raw.index, columns=requested_tickers)
            
    if isinstance(out, pd.Series):
        # Phase 4.7: Use the actual requested ticker, not the first ticker in the raw frame.
        # Previously: _tname = str(raw.columns.get_level_values(1)[0]) returned the FIRST
        # ticker in the entire raw frame, which could be a DIFFERENT ticker than requested.
        # Downstream out[requested_tickers] would then KeyError or silently return empty.
        _tname = requested_tickers[0] if requested_tickers else "value"
        out = out.to_frame(name=_tname)
    for t in requested_tickers:
        if t not in out.columns:
            out[t] = pd.NA
    return out[requested_tickers].sort_index()

def clean_market_panels(close: pd.DataFrame, volume: pd.DataFrame, min_required_cols: int, min_obs_override: int = None):
    if close is None or volume is None or close.empty or volume.empty:
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

    close = close.sort_index()
    volume = volume.sort_index()

    common_cols = [c for c in close.columns if c in volume.columns]
    if not common_cols:
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

    close = close[common_cols]
    volume = volume[common_cols]

    close = close.ffill(limit=1)
    volume = volume.replace(0.0, pd.NA)
    volume = volume.ffill(limit=1).fillna(0.0)

    if min_obs_override is not None:
        min_obs = int(min_obs_override)
    else:
        # Capping min_obs at 160 ensures in-window 1-2 year IPOs (~160-500 bars) are never discarded
        min_obs = min(160, max(60, int(0.60 * len(close))))
        
    keep_cols = [c for c in close.columns if close[c].notna().sum() >= min_obs]
    if len(keep_cols) < min_required_cols:
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

    close = close[keep_cols]
    volume = volume[keep_cols].reindex(close.index).fillna(0.0)

    import numpy as np
    returns = np.log(close / close.shift(1))
    min_ret_obs = min_obs_override if min_obs_override is not None else min(120, max(40, int(0.50 * len(returns))))
    keep_cols = [c for c in returns.columns if returns[c].notna().sum() >= min_ret_obs]
    if len(keep_cols) < min_required_cols:
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

    close = close[keep_cols]
    volume = volume[keep_cols]
    returns = returns[keep_cols]

    # Drop early dates where fewer than min_required_cols assets were trading
    returns = returns.dropna(axis=0, thresh=min_required_cols)
    # Require each surviving asset to have sufficient non-null returns in the active overlap window
    returns = returns.dropna(axis=1, thresh=min(min_ret_obs, max(20, int(0.50 * len(returns)))))
    if returns.empty or returns.shape[1] < min_required_cols:
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

    common_cols = list(returns.columns)
    common_idx = returns.index
    close = close[common_cols].reindex(common_idx).ffill()
    volume = volume[common_cols].reindex(common_idx).fillna(0.0)
    returns = returns[common_cols].dropna(axis=0, thresh=min_required_cols)
    return close, volume, returns

def _download_ohlcv_bundle(tickers: list, period: str, log_cb=None, interval: str = None, batch_size_override: int = None) -> dict:
    raw = safe_download(
        tickers,
        period,
        auto_adjust=True,
        log_cb=log_cb,
        interval=interval,
        batch_size_override=batch_size_override,
    )
    return {
        "raw": raw,
        "Open": extract_field_panel(raw, "Open", tickers),
        "High": extract_field_panel(raw, "High", tickers),
        "Low": extract_field_panel(raw, "Low", tickers),
        "Close": extract_field_panel(raw, "Close", tickers),
        "Volume": extract_field_panel(raw, "Volume", tickers),
    }

def _fetch_panel_metrics(tickers: list, period: str = "1y") -> dict:
    try:
        tickers = [t if t.endswith(".NS") else t + ".NS" for t in tickers]
        prices = safe_download(tickers, period=period, auto_adjust=True)
        if prices is None or prices.empty:
            return {}
        if isinstance(prices.columns, pd.MultiIndex):
            close = prices["Close"] if "Close" in prices.columns.get_level_values(0) else prices.iloc[:, 0]
        else:
            # M5-fix: when single-ticker download, rename Close→ticker so the dict key is correct
            if len(tickers) == 1:
                close = prices[["Close"]].rename(columns={"Close": tickers[0]}) if "Close" in prices.columns else prices
            else:
                close = prices[["Close"]] if "Close" in prices.columns else prices
        close = close.dropna(how="all")
        if close.empty:
            return {}
        rets = close.pct_change().dropna()
        out = {}
        for col in close.columns:
            t_clean = col.replace(".NS", "")
            s = close[col].dropna()
            r = rets[col].dropna() if col in rets.columns else pd.Series(dtype=float)
            if s.empty:
                continue
            ret_1m_val = trailing_return(s, 20)
            ret_1m  = float(ret_1m_val * 100) if not pd.isna(ret_1m_val) else 0.0
            ret_6m_val = trailing_return(s, 125)
            ret_6m  = float(ret_6m_val * 100) if not pd.isna(ret_6m_val) else 0.0
            ret_12m_val = trailing_return(s, 251)
            ret_12m = float(ret_12m_val * 100) if not pd.isna(ret_12m_val) else 0.0
            vol_ann_val = annualized_vol(r)
            vol_ann = float(vol_ann_val * 100) if not pd.isna(vol_ann_val) else 0.0
            price   = float(s.iloc[-1])
            hi52    = float(s.tail(252).max()) if len(s) >= 20 else price
            lo52    = float(s.tail(252).min()) if len(s) >= 20 else price
            hi52pct = (price / hi52 - 1) * 100 if hi52 > 0 else 0.0
            mdd_val = max_drawdown(s, lookback=len(s))
            mdd     = float(mdd_val * 100) if not pd.isna(mdd_val) else 0.0
            sharpe  = float(r.mean() / (r.std() + 1e-9) * (TRADING_DAYS_PER_YEAR ** 0.5)) if len(r) >= 5 else 0.0
            rsi_val = compute_rsi(s, 14)
            rsi     = float(rsi_val) if not pd.isna(rsi_val) else 50.0
            ds_vol_val = downside_vol(r)
            ds_vol  = float(ds_vol_val * 100) if not pd.isna(ds_vol_val) else 0.0
            out[t_clean] = {
                "price":   price,
                "ret_1m":  ret_1m,
                "ret_6m":  ret_6m,
                "ret_12m": ret_12m,
                "vol_ann": vol_ann,
                "hi52":    hi52,
                "lo52":    lo52,
                "hi52pct": hi52pct,
                "mdd":     mdd,
                "sharpe":  sharpe,
                "rsi":     rsi,
                "downside_vol": ds_vol,
                "close_series": s,
                "ret_series": r,
            }
        return out
    except Exception as e:
        # L16-fix: log panel-metrics failure instead of silently swallowing
        _log.warning("[PanelMetrics] failed: %s: %s", type(e).__name__, e)
        return {}
