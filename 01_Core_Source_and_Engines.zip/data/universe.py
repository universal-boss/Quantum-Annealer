import io
from datetime import datetime
from pathlib import Path
import pandas as pd

from math_engine.indicators import max_drawdown
from data.price_feed import safe_download, extract_field_panel

from utils import (
    TICKERS_CACHE_PATH,
    read_json_cache,
    write_json_cache,
    NSEClient,
    NSE_EQUITY_CSV_URL,
    log_emit
)

# ── NSE index constituent CSV endpoints ──────────────────────────────────
# These are official NSE archive CSVs — one per index. Each row is one
# constituent with columns: Symbol, Company Name, Series, ISIN Code.
_NSE_INDEX_CSV_URLS = {
    "nifty50":           "https://archives.nseindia.com/content/indices/ind_nifty50list.csv",
    "niftynext50":       "https://archives.nseindia.com/content/indices/ind_niftynext50list.csv",
    "nifty100":          "https://archives.nseindia.com/content/indices/ind_nifty100list.csv",
    "nifty200":          "https://archives.nseindia.com/content/indices/ind_nifty200list.csv",
    "nifty500":          "https://archives.nseindia.com/content/indices/ind_nifty500list.csv",
    "nifty_midcap150":   "https://archives.nseindia.com/content/indices/ind_niftymidcap150list.csv",
    "nifty_smallcap250": "https://archives.nseindia.com/content/indices/ind_niftysmallcap250list.csv",
}

_INDEX_CACHE_DIR = TICKERS_CACHE_PATH.parent


def _fetch_index_csv(index_name: str, log_cb=None, timeout: int = 25) -> list:
    """Fetch an NSE index constituent list from the official NSE archive CSV.

    Returns tickers in 'SYMBOL.NS' format. Raises on failure.
    """
    url = _NSE_INDEX_CSV_URLS.get(index_name.lower())
    if not url:
        raise ValueError(f"Unknown NSE index: {index_name}")

    headers = {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                      "AppleWebKit/537.36 (KHTML, like Gecko) "
                      "Chrome/120.0.0.0 Safari/537.36",
        "Accept-Language": "en-US,en;q=0.9",
        "Accept": "text/csv,application/csv,*/*",
        "Referer": "https://www.nseindia.com/",
    }
    resp = NSEClient.get(url, headers=headers, timeout=timeout)
    resp.raise_for_status()
    if not resp.text or len(resp.text) < 50:
        raise RuntimeError(f"Empty response from {url}")

    df = pd.read_csv(
        io.StringIO(resp.text),
        dtype=str,
        on_bad_lines="skip",
        encoding="utf-8",
        encoding_errors="replace",
    )
    df.columns = [c.strip() for c in df.columns]
    sym_col = "Symbol" if "Symbol" in df.columns else df.columns[0]
    symbols = df[sym_col].dropna().astype(str).str.strip().str.upper()
    symbols = symbols[~symbols.str.contains(
        "INAV|ETF|INDEX|BEES|NIFTY|BANKNIFTY|GOLD|LIQUID", na=False, regex=True
    )]
    tickers = sorted(f"{s}.NS" for s in symbols.unique() if s)
    if not tickers:
        raise RuntimeError(f"No symbols parsed from {url}")
    return tickers


def _liquidity_filter(tickers: list, top_n: int, log_cb=None, period: str = "1y") -> list:
    """Filter a broad ticker list to the top-N most liquid names.

    Used as a last-resort fallback when NSE archive CSVs are unreachable:
    fetches 1y of daily volume for each ticker and ranks by average daily
    dollar volume (close × volume).
    """
    if not tickers:
        return []
    try:
        raw = safe_download(tickers, period=period, auto_adjust=True, log_cb=log_cb)
        close = extract_field_panel(raw, "Close", tickers)
        vol = extract_field_panel(raw, "Volume", tickers)
        doll_vol = (close * vol).mean(axis=0).dropna()
        if doll_vol.empty:
            return tickers[:top_n]
        ranked = doll_vol.sort_values(ascending=False).head(top_n)
        result = sorted(ranked.index.tolist())
        log_emit(log_cb, f"[Universe] Liquidity-filtered to top {len(result)} of {len(tickers)} tickers")
        return result
    except Exception as e:
        log_emit(log_cb, f"[Universe] Liquidity filter failed ({e}) — returning first {top_n}")
        return tickers[:top_n]


def fetch_index_constituents(
    index_name: str,
    log_cb=None,
    max_age_hours: int = 24,
    use_liquidity_fallback: bool = True,
    liquidity_fallback_size: int = 500,
) -> list:
    """Fetch NSE index constituents with multi-layer fallback.

    Sources tried in order:
      1. Local JSON cache (if fresh, <max_age_hours old)
      2. NSE archive CSV (archives.nseindia.com)
      3. Liquidity filter on the full NSE EQ universe (top N by avg turnover)

    Returns tickers in 'SYMBOL.NS' format. NEVER returns a hardcoded list —
    every ticker is sourced live from NSE or yfinance.
    """
    idx = (index_name or "").lower()
    cache_path = _INDEX_CACHE_DIR / f"index_{idx}_constituents.json"
    today = datetime.now().strftime("%Y-%m-%d")

    # Layer 1: fresh local cache
    try:
        cache = read_json_cache(cache_path, {})
        cache_fresh = False
        if cache.get("date") == today and cache.get("tickers"):
            cache_fresh = True
        elif cache_path.exists() and cache.get("tickers"):
            age_h = (datetime.now().timestamp() - cache_path.stat().st_mtime) / 3600
            if age_h < max_age_hours:
                cache_fresh = True
        if cache_fresh:
            tickers = list(cache.get("tickers", []))
            log_emit(log_cb, f"[Universe] Loaded {idx} from cache: {len(tickers)} tickers")
            return tickers
    except Exception:
        pass

    # Layer 2: NSE archive CSV
    try:
        tickers = _fetch_index_csv(idx, log_cb=log_cb)
        if tickers:
            write_json_cache(cache_path, {"date": today, "tickers": tickers})
            log_emit(log_cb, f"[Universe] Fetched {idx} from NSE archive: {len(tickers)} tickers")
            return tickers
    except Exception as e:
        log_emit(log_cb, f"[Universe] {idx} NSE archive fetch failed: {e}")

    # Layer 3: liquidity-filtered EQ universe (final fallback — still dynamic)
    if use_liquidity_fallback:
        try:
            log_emit(log_cb, f"[Universe] Falling back to liquidity-filtered EQ universe for {idx}")
            all_eq = fetch_nse_tickers(log_cb=log_cb)
            if all_eq:
                filtered = _liquidity_filter(
                    all_eq, liquidity_fallback_size, log_cb=log_cb
                )
                if filtered:
                    write_json_cache(cache_path, {"date": today, "tickers": filtered})
                    return filtered
        except Exception as e:
            log_emit(log_cb, f"[Universe] Liquidity fallback failed: {e}")

    log_emit(log_cb, f"[Universe] All sources failed for {idx}; returning []")
    return []


def fetch_nifty50_tickers(log_cb=None) -> list:
    """Fetch Nifty 50 constituents dynamically from NSE."""
    return fetch_index_constituents("nifty50", log_cb=log_cb, liquidity_fallback_size=50)


def fetch_niftynext50_tickers(log_cb=None) -> list:
    """Fetch Nifty Next 50 constituents dynamically from NSE."""
    return fetch_index_constituents("niftynext50", log_cb=log_cb, liquidity_fallback_size=50)


def fetch_nifty500_tickers(log_cb=None) -> list:
    """Fetch Nifty 500 constituents dynamically from NSE."""
    return fetch_index_constituents("nifty500", log_cb=log_cb, liquidity_fallback_size=500)


def fetch_nifty_midcap150_tickers(log_cb=None) -> list:
    """Fetch Nifty Midcap 150 constituents dynamically from NSE."""
    return fetch_index_constituents("nifty_midcap150", log_cb=log_cb, liquidity_fallback_size=150)


def fetch_nifty_smallcap250_tickers(log_cb=None) -> list:
    """Fetch Nifty Smallcap 250 constituents dynamically from NSE."""
    return fetch_index_constituents("nifty_smallcap250", log_cb=log_cb, liquidity_fallback_size=250)


def fetch_nse_tickers(log_cb=None, as_of_date=None):
    tickers = []   # v17.3 fix: always initialise so no UnboundLocalError
    from utils import RUNTIME_DIR
    
    # Point-in-Time constituent query to prevent survivorship bias
    if as_of_date is not None:
        db_path = RUNTIME_DIR / "fundamentals_history.db"
        if db_path.exists():
            import sqlite3, contextlib
            try:
                with contextlib.closing(sqlite3.connect(str(db_path))) as conn:
                    cursor = conn.cursor()
                    target_dt = pd.to_datetime(as_of_date).strftime("%Y-%m-%d")
                    query = """
                        SELECT ticker FROM constituent_history
                        WHERE join_date <= ? AND (leave_date IS NULL OR leave_date > ?)
                    """
                    cursor.execute(query, (target_dt, target_dt))
                    rows = cursor.fetchall()
                if rows:
                    tickers = sorted([r[0] for r in rows])
                    log_emit(log_cb, f"[Universe] Loaded {len(tickers)} PIT constituents for date {target_dt}")
                    return tickers
            except Exception as e:
                log_emit(log_cb, f"[Universe] Failed to load PIT constituents: {e}")
        # M7-fix: as_of_date requested but PIT DB unavailable / query failed / returned no rows.
        # Do NOT fall through to today's daily cache — that would introduce survivorship bias.
        log_emit(log_cb, f"[Universe] No PIT constituents available for {as_of_date}; returning [] to avoid survivorship bias")
        return []

    cache = read_json_cache(TICKERS_CACHE_PATH, {})
    cached_date = cache.get("date")
    today = datetime.now().strftime("%Y-%m-%d")
    cache_fresh = False
    if cached_date == today and cache.get("tickers"):
        cache_fresh = True
    elif TICKERS_CACHE_PATH.exists() and cache.get("tickers"):
        try:
            _age_hours = (datetime.now().timestamp() - TICKERS_CACHE_PATH.stat().st_mtime) / 3600
            if _age_hours < 36:  # 36h TTL allows overnight & weekend cache reuse
                cache_fresh = True
        except Exception:
            pass

    if cache_fresh:
        tickers = list(cache.get("tickers", []))
        log_emit(log_cb, f"[Universe] Loaded NSE universe from cache: {len(tickers)} EQ tickers")
        return tickers   # cache hit — return immediately

    # Cache miss or stale — fetch fresh from NSE
    try:
        headers = {"User-Agent": "Mozilla/5.0", "Accept-Language": "en-US,en;q=0.9"}
        resp = NSEClient.get(NSE_EQUITY_CSV_URL, headers=headers, timeout=25)
        resp.raise_for_status()
        df = pd.read_csv(
            io.StringIO(resp.text),
            dtype={"SYMBOL": str, "SERIES": str, "ISIN NUMBER": str},
            on_bad_lines="skip",
            encoding="utf-8",
            encoding_errors="replace",
        )
        df.columns = [c.strip().upper() for c in df.columns]
        eq = df[df["SERIES"].astype(str).str.upper().str.strip() == "EQ"].copy()
        raw_eq = sorted(f"{s}.NS" for s in eq["SYMBOL"].dropna().unique())
        
        # Build Institutional Tiered Prioritization (Nifty 50 -> Next 50 -> Midcap 150 -> Smallcap 250 -> Broad EQ)
        # This eliminates alphabetical bias and guarantees premier market leaders across all sectors and A-Z are screened first!
        seen_t = set()
        tiered_tickers = []
        try:
            n50 = fetch_nifty50_tickers(log_cb=log_cb)
            nn50 = fetch_niftynext50_tickers(log_cb=log_cb)
            mid150 = fetch_nifty_midcap150_tickers(log_cb=log_cb)
            small250 = fetch_nifty_smallcap250_tickers(log_cb=log_cb)
            for t_list in [n50, nn50, mid150, small250, raw_eq]:
                for t in t_list:
                    if t and t not in seen_t:
                        seen_t.add(t)
                        tiered_tickers.append(t)
        except Exception:
            tiered_tickers = raw_eq

        tickers = tiered_tickers if tiered_tickers else raw_eq
        write_json_cache(TICKERS_CACHE_PATH, {"date": today, "tickers": tickers})
        log_emit(log_cb, f"Loaded Tier-1 Institutional NSE universe: {len(tickers)} EQ tickers (Nifty 500 prioritized)")
    except Exception as e:
        log_emit(log_cb, f"[Universe] ⚠️  NSE fetch failed ({e}) — using cached tickers if available")
        if not tickers and cache.get("tickers"):
            tickers = list(cache["tickers"])
            log_emit(log_cb, f"[Universe] Fallback: {len(tickers)} tickers from stale cache")
        if not tickers:
            db_path = RUNTIME_DIR / "fundamentals_history.db"
            if db_path.exists():
                import sqlite3, contextlib
                try:
                    with contextlib.closing(sqlite3.connect(str(db_path))) as conn:
                        cursor = conn.cursor()
                        cursor.execute("SELECT DISTINCT ticker FROM constituent_history")
                        rows = cursor.fetchall()
                    if rows:
                        tickers = sorted([r[0] for r in rows])
                        log_emit(log_cb, f"[Universe] Local DB Fallback: Loaded {len(tickers)} tickers from history database")
                except Exception as db_err:
                    log_emit(log_cb, f"[Universe] Failed to load constituents from DB: {db_err}")
    return tickers


def fetch_and_filter_universe(max_tickers: int = 50, max_drawdown_limit: float = 0.5, log_cb=None) -> list:
    """Fetches NSE tickers, downloads their daily close prices, and filters out symbols
    exceeding the maximum drawdown limit.
    """
    tickers = fetch_nse_tickers(log_cb=log_cb)
    if not tickers:
        return []
    sample_tickers = tickers[:max_tickers]
    log_emit(log_cb, f"[Universe] Downloading data for {len(sample_tickers)} tickers to apply quality filter...")
    try:
        raw_data = safe_download(sample_tickers, period="1y", auto_adjust=True, log_cb=log_cb)
        close_df = extract_field_panel(raw_data, "Close", sample_tickers)
        filtered = []
        for t in sample_tickers:
            if t in close_df.columns:
                s = close_df[t].dropna()
                if len(s) >= 20:
                    mdd = max_drawdown(s, lookback=len(s))
                    if not pd.isna(mdd) and mdd <= max_drawdown_limit:
                        filtered.append(t)
                    else:
                        log_emit(log_cb, f"[Universe] Filtering out {t} due to high drawdown ({mdd*100:.1f}%)")
                else:
                    filtered.append(t)
            else:
                filtered.append(t)
        log_emit(log_cb, f"[Universe] Filtered active universe: {len(filtered)}/{len(sample_tickers)} passed quality check")
        return filtered
    except Exception as e:
        log_emit(log_cb, f"[Universe] Filtering failed due to: {e}. Returning unfiltered sample.")
        return sample_tickers


