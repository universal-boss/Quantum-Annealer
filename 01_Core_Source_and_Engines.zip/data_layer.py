from __future__ import annotations
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union, Callable, Sequence
import sys, os, re, math, time, json, copy, warnings, threading, traceback
import tempfile, logging as _logging, hashlib as _hashlib, sqlite3, pickle
import csv, io, gc, uuid, base64
from datetime import datetime
import collections, functools, itertools, contextlib
import concurrent.futures as _cf_mod, threading as _threading
from concurrent.futures import as_completed, ThreadPoolExecutor
from collections import Counter
import requests
try:
    from utils import NA_SECTOR_VALUES as _NA_SECTOR_VALUES_DL, normalize_sector
except Exception:
    _NA_SECTOR_VALUES_DL = {"N/A", "NA", "na", "n/a", "", None, "None", "null"}

    def normalize_sector(sec_val):
        if sec_val in _NA_SECTOR_VALUES_DL or (isinstance(sec_val, str) and not sec_val.strip()):
            return "UNKNOWN"
        return sec_val

# AUDIT-FIX Round 7 P2-4: Guarded top-level yf attribute for backward compatibility
try:
    import yfinance as yf
except ImportError:
    import logging as _swallow_log_mod
    _swallow_log_mod.getLogger("quantum_annealer").debug(
        "[AUDIT-FIX P2-5] swallowed exception", exc_info=True
    )
    yf = None  # type: ignore

_YF_IMPORT_WARNED = False  # one-shot production warning flag


def _get_yf():
    """Lazy yfinance accessor.

    Returns the yfinance module on first call, importing it in-process.
    Returns None if yfinance is not installed.  All yf.* callsites in
    data_layer must route through this helper so the module top-level
    import never triggers a yfinance load.
    """
    global _YF_IMPORT_WARNED
    try:
        import yfinance as _yf
    except ImportError:
        import logging as _swallow_log_mod
        _swallow_log_mod.getLogger("quantum_annealer").debug(
            "[AUDIT-FIX P2-4] yfinance not installed — lazy import returned None",
            exc_info=True,
        )
        return None
    # One-shot production warning: yfinance is for retail fallback only.
    if os.getenv("ENV") == "production" and not _YF_IMPORT_WARNED:
        _YF_IMPORT_WARNED = True
        import warnings as _yf_warnings
        _yf_warnings.warn(
            "[data_layer] yfinance lazy-loaded in ENV=production. "
            "All data fetches must route through safe_download(). "
            "Direct yf.* calls bypass the institutional provider.",
            DeprecationWarning, stacklevel=2,
        )
    return _yf
from data.universe import fetch_nse_tickers, fetch_and_filter_universe
from data.price_feed import safe_download, _download_ohlcv_bundle, clean_market_panels
try:
    import neal
    import dimod
except ImportError:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    neal = None
    dimod = None

try:
    import numpy as np
except ImportError:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    np = None
try:
    import pandas as pd
except ImportError:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    pd = None

logger = _logging.getLogger("data_layer")

# from utils import *  # noqa

# ── All private names needed from utils ─────────────────────────────────
from utils import (
    _QSS,
    archlog,
    _arch_log,
    _NIFTY50,
    _NIFTY_NEXT50,
    _ACTIVE_STOP_EVENT,
    _ACTIVE_STOP_EVENT_LOCK,
    _THEME_SEEDS,
    _DaemonThreadPoolExecutor,
    _DynamicTabMixin,
    _demo_int,
    _demo_float,
    _real_or_demo,
    _real_or_demo_int,
    _widget_alive,
    _download_universe,
    _compute_all,
    _rsi,
    _macd,
    _bollinger,
    _atr,
    _supertrend,
    _ichimoku,
    _vwap,
    _donchian,
    _adx,
    _pivot_points,
    _volume_profile,
    _fill_table_from_df,
    _make_std_table,
    _make_ticker_bar,
    _launch,
    _set_watchlist,
    _DATA_CACHE,
    _DATA_PROVIDER,
    _WATCHLIST_LOCK,
    _WATCHLIST,
    ARTIFACTS_DIR, BENCHMARK_FALLBACKS, BUYBACK_CACHE_PATH, CORP_ACTIONS_CACHE_PATH,
    DELIVERY_CACHE_PATH, FII_DII_CACHE_PATH, FII_SECTOR_CACHE_PATH, FNO_BAN_CACHE_PATH,
    LARGE_MID_SMALL_CACHE_PATH, MTF_CACHE_PATH, NSE_BHAV_URL, NSE_CORP_ACTIONS_URL,
    NSE_FII_DII_URL, NSE_OPTIONS_URL, OFFLINE_CHART_MODEL_META_PATH, OFFLINE_CHART_MODEL_PATH,
    OI_BUILDUP_CACHE_PATH, OPTIONS_IV_CACHE_PATH, PCR_CACHE_PATH, PEAD_CACHE_PATH,
    PLEDGE_CACHE_PATH, PROJECT_DIR, RUNTIME_DIR, SAST_CACHE_PATH, SAST_VELOCITY_CACHE_PATH,
    BULK_DEAL_CACHE_PATH, FLOAT_SQUEEZE_CACHE_PATH,
    _NSE500_CACHE, log_once_per_window,
    progress_span, read_json_cache, write_json_cache,
    ConcurrencyPolicy, DataCache, ExceptionLogger, NIFTY50_UNIVERSE,
    NSEClient, NSE_EQUITY_CSV_URL, NSE_SESSION_SLEEP, SECTOR_CACHE_PATH,
    TICKERS_CACHE_PATH, TRADING_DAYS_PER_YEAR, check_stop, chunked,
    log_emit, extract_field_panel
)

_IV_HISTORY_CACHE_PATH = RUNTIME_DIR / "atm_iv_history_cache.json"
_IV_HISTORY_MAX_DAYS   = 260


archlog = _logging.getLogger("quantum_annealer")


# ────────────────────────────────────────────────────────────────────
# FUNC: get_active_universe
# ────────────────────────────────────────────────────────────────────
def get_active_universe(max_tickers: int = 30) -> list:
    with _WATCHLIST_LOCK:
        base = list(_WATCHLIST) if _WATCHLIST else list(NIFTY50_UNIVERSE)
    return base[:max_tickers]
# ─────────────────────────────────────────────────────────────────────────────

# ── _DynamicTabMixin ──────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: get_scan_universe
# ────────────────────────────────────────────────────────────────────
def get_scan_universe(weights: dict = None) -> list:
    global _NSE500_CACHE  # GLB001: consider replacing global with AppState
    if _NSE500_CACHE: return _NSE500_CACHE
    try:
        import pandas as _pd
        url = "https://archives.nseindia.com/content/indices/ind_nifty500list.csv"
        df = _pd.read_csv(url, usecols=["Symbol"])
        tickers = [s.strip()+".NS" for s in df["Symbol"].dropna().tolist()]
        if tickers: _NSE500_CACHE = tickers; return tickers
    except Exception as _e_:  # P1-E: was bare pass
        ExceptionLogger.swallow(_e_, context='auto-P1E')
    # B10-fix: never collapse discovery scans to only the current portfolio.
    # If NSE500 download fails, scan the hardcoded Nifty50 universe; include any
    # current holdings as an additive safety net rather than as the whole universe.
    fallback = set(NIFTY50_UNIVERSE)
    if weights:
        fallback.update(weights.keys())
    return sorted(fallback)

DEFAULT_CFG = {
    "LOOKBACK_DOWNLOAD": "3y",
    "PRESCREEN_LOOKBACK": "3y",
    "BATCH_SIZE": 20,
    "MIN_DATA_PCT": 0.80,
    "MIN_AVG_DOLLAR_VOL": 50_000_000,
    "MIN_PRICE": 40.0,
    "MIN_AVG_SHARE_VOL": 30000,
    "REQUIRE_STAGE2_TREND": True,
    "MAX_ANNUAL_VOL": 0.85,
    "MAX_DRAWDOWN_LIMIT": 0.60,
    "MAX_52W_HIGH_DIST": 0.35,
    "MIN_52W_LOW_DIST": 0.25,
    "TOP_N_UNIVERSE": 200,
    "K_STOCKS": 40,
    # GAMMA/THETA calibrated for K=40 universe:
    # GAMMA controls cardinality enforcement (lower = softer constraint, allows SA more flexibility).
    # At K=8, GAMMA=22 was needed to force exactly 8 stocks. At K=40 this over-constrains.
    # Empirical rule: GAMMA ≈ 0.30 × K. THETA ≈ 0.10 × K.
    "GAMMA": 12.0,
    "THETA": 4.0,
    "ALPHA": 1.8,
    "NUM_READS": 1200,
    "NUM_SWEEPS": 1500,
    # WIRING: Tier 1-4 config keys
    "BL_METHOD": "standard",
    "RISK_OPTIMIZATION_METHOD": "",
    "USE_MPO": False,
    "MPO_PERIODS": 4,
    "MPO_RISK_AVERSION": 2.5,
    "USE_EVENT_BACKTEST": False,
    "USE_REALTIME_RISK": True,
    "HARD_CIRCUIT_BREAKER": True,
    "RT_RISK_INTERVAL_SEC": 300,
    "RT_VAR_THRESHOLD": 0.05,
    "RT_DD_THRESHOLD": 0.08,
    "USE_DERIVATIVES": False,
    "USE_ALTERNATIVE_ASSETS": False,
    "USE_ADVANCED_ML": False,
    "CHECK_EARNINGS_BLACKOUT": True,
    # R46 FIX (duplicate dict key): "EARNINGS_BLACKOUT_DAYS" was defined TWICE
    # in this dict (2 here, 5 further down in the v14/v17 block). Python
    # silently keeps the LAST occurrence (5) — the "2" was dead config that
    # misled every reader calibrating the blackout window. The early
    # duplicate is removed; the authoritative value lives with the v17.27
    # comment below ("always active — skip stocks with earnings within ±N
    # days"). If you need a different window, change it there — once.
    "CHECK_OPTIONS_SKEW": True,
    "OPTIONS_SKEW_THRESHOLD": 1.25,
    "USE_FEATURE_STORE": True,
    "USE_EXPERIMENT_TRACKING": True,
    "USE_DRIFT_DETECTION": True,
    "USE_RL_REBALANCE": False,
    "SEED": 42,
    "MULTI_STARTS": 4,
    "MAX_SECTOR_WORKERS": 8,
    # AUDIT-FIX (Round 4 — duplicate-key bug): the original DEFAULT_CFG had
    # SECTOR_PENALTY / UNKNOWN_SECTOR_PENALTY / MAX_PER_SECTOR defined twice.
    # The earlier values (1.80 / 0.30 / 2 — calibrated for K=40 universe)
    # were silently overwritten by the later "sector-cap off" block at
    # lines ~493-497. To resolve the duplicate-key pylint W0109 warning
    # AND surface the intent, the earlier entries are removed here. The
    # canonical values live with the rest of the "Sector constraint
    # tuning" block further below (0.0 / 0.0 / 0 by default).
    "VOL_PENALTY": 0.35,
    "BETA_PENALTY": 0.25,
    "TURNOVER_PENALTY": 0.35,
    "RISK_MODEL": "Ledoit-Wolf",
    "RISK_HORIZON": "Strategic (252d)",
    "TACTICAL_LOOKBACK_DAYS": 30,
    "STRATEGIC_LOOKBACK_DAYS": 252,
    "CORR_SHRINKAGE": 0.25,
    "BENCHMARK_SYMBOL": "^NSEI",
    "OPTIMIZER_MODE": "Hybrid",   # Options: Hybrid | Greedy | Anneal | MIP
    "MIN_WEIGHT": 0.0,   # G-fix: QP solver handles lower bounds
    "MAX_WEIGHT": 0.50,
    "RISK_MAX_POSITION":  0.15,
    "RISK_MAX_SECTOR":    0.40,
    "RISK_MIN_STOCKS":    4,
    "BEAR_MIN_STOCKS":    None,     # Min resilient stocks required in Bear market before scaling to CASH (default: max(K_STOCKS // 2, 5))
    "ALERT_COOLDOWN_SECONDS": 300,
    "REGIME_FILTER": "Adaptive",
    "USE_MANUAL_UNIVERSE": False,
    "RUN_BACKTEST": False,
    "BACKTEST_REBALANCE_DAYS": 21,  # monthly rebalance (~21 trading days)
    "BACKTEST_FEE_BPS": 15.0,
    "BACKTEST_SLIPPAGE_BPS": 10.0,
    "AUTO_RUN_ENABLED": False,
    "AUTO_RUN_INTERVAL_MIN": 60,
    "AUTO_EXPORT_MEMO": False,
    "TICKER_BLACKLIST":      ["VENUSREM.NS", "INDUSINDBK.NS"],  # persistent split artifact
    "USE_IC_WEIGHTS": True,   # Auto-calibrate factor weights from rolling IC on each run
    # ── AUDIT-FIX (Round 3, P2-3 follow-up-b): t-stat gating path ──
    # Previously calibrate_factor_weights_ic fell through to the legacy
    # |IC-IR| < 0.20 prune — an arbitrary effect-size cutoff (implied |t|
    # ≈ 1.34 on N=45 windows, below the 95% threshold of 1.96). With
    # USE_IC_T_STAT_GATING=True and a non-empty FACTOR_T_STATS lookup,
    # the gate activates and prunes only factors whose walk-forward
    # Newey-West t-statistic fails |t| >= 1.96 (the conservative NW
    # value is used rather than the naive t to suppress serial-
    # correlation-induced significance inflation).
    #
    # Values below are from artifacts/wfo_real_daily.json (Round 3
    # follow-up-b, DAILY rebalance, 40 folds × 21 dates = 840 ICs/factor).
    # The daily run is the canonical leaderboard — n=840 vs n=42 in the
    # monthly run, so the NW t-stats are dramatically more powered.
    # Daily summary: 32/37 naive-sig, 15/37 NW-sig, 32/37 BH-FDR-sig,
    # 16/37 orthogonalized-sig. obv_slope remains NW-sig (-2.66) and is
    # the only factor that survived BH-FDR in BOTH the monthly and daily
    # runs — confirming it as the audit's robust signal. Several monthly
    # "significant" factors (z_roe, z_trend_20, z_trigger_persistence,
    # z_cmf) turned out to be small-N false positives and are correctly
    # pruned under the daily table.
    #
    # Refresh procedure: re-run scripts/walk_forward_validation_v2.py
    # (defaults are now REBALANCE_FREQ_DAYS=1, ~10 min) and paste the
    # new NW t-stats into this table.
    "USE_IC_T_STAT_GATING": True,
    "IC_T_STAT_THRESHOLD": 1.96,  # 95% two-tailed normal-approx
    "FACTOR_T_STATS": {
        # ── Survivors (|t_NW| >= 1.96 → keep IC-IR weight) — 15 factors ──
        "z_updown_vol":            -3.239,  # BH-FDR sig; IC=-0.0466  ★ top NW |t|
        "z_trend_50":              -2.689,  # BH-FDR sig; IC=-0.0502
        "z_up_day_frac_21":        -2.686,  # BH-FDR sig; IC=-0.0379
        "z_obv_slope":             -2.662,  # BH-FDR sig; IC=-0.0340  (audit's robust signal)
        "z_rev_growth":            +2.591,  # BH-FDR sig; IC=+0.0398  (flipped from monthly non-sig)
        "z_downside_vol":          +2.464,  # BH-FDR sig; IC=+0.0460  (flipped from monthly non-sig)
        "z_mom_1m":                -2.376,  # BH-FDR sig; IC=-0.0394
        "z_breakout_distance_20d": -2.263,  # BH-FDR sig; IC=-0.0346  (newly NW-sig)
        "z_trend_quality":         -2.199,  # BH-FDR sig; IC=-0.0348  (newly NW-sig)
        "z_vol_of_vol":            -2.193,  # BH-FDR sig; IC=-0.0341  (newly NW-sig)
        "z_price_above_20d_frac":  -2.166,  # BH-FDR sig; IC=-0.0287  (newly NW-sig)
        "z_idio_mom_6m":           +2.070,  # BH-FDR sig; IC=+0.0341
        "z_rsi":                   -2.005,  # BH-FDR sig; IC=-0.0296  (newly NW-sig)
        "z_rsi_pref":              -2.005,  # BH-FDR sig; IC=-0.0296  (newly NW-sig)
        "z_rs_raw":                -2.000,  # BH-FDR sig; IC=-0.0301  (newly NW-sig)
        # ── Non-survivors (|t_NW| < 1.96 → prune to 0.0) — 22 factors ──
        "z_proximity_52w":        -1.920,  # BH-FDR sig but |t_NW|<1.96; IC=-0.0423
        "z_price_above_50d_frac": -1.875,  # BH-FDR sig but |t_NW|<1.96; IC=-0.0296
        "z_sweet_spot_52w":       -1.763,  # BH-FDR sig but |t_NW|<1.96; IC=-0.0363
        "z_drawdown":             -1.743,  # BH-FDR sig but |t_NW|<1.96; IC=-0.0352
        "z_idio_mom_3m":          +1.777,  # BH-FDR sig but |t_NW|<1.96; IC=+0.0274
        "z_fund_composite":       +1.717,  # BH-FDR sig but |t_NW|<1.96; IC=+0.0219
        "z_trend_20":             -1.686,  # BH-FDR sig but |t_NW|<1.96; IC=-0.0270
        "z_trigger_persistence":  -1.686,  # BH-FDR sig but |t_NW|<1.96; IC=-0.0270
        "z_ma_compression":       -1.683,  # BH-FDR sig but |t_NW|<1.96; IC=-0.0285
        "z_cmf":                   -1.645,  # BH-FDR sig but |t_NW|<1.96; IC=-0.0226
        "z_volume_dryup":         -1.353,  # IC=-0.0157
        "z_mom_3m":                -1.337,  # IC=-0.0259
        "z_pe_inv":                +1.251,  # IC=+0.0149
        "z_vol_surge":             -1.140,  # IC=-0.0139
        "z_range_contraction":     -1.069,  # IC=-0.0139
        "z_vcp":                   -1.069,  # IC=-0.0139
        "z_mom_12_1":              +0.897,  # IC=+0.0180
        "z_ann_vol":               +0.745,  # IC=+0.0129
        "z_de_inv":                +0.380,  # IC=+0.0049
        "z_mom_6m":                -0.359,  # IC=-0.0078
        "z_roe":                   -0.318,  # IC=-0.0039  (monthly was -1.989 NW-sig; daily false-positive unmasked)
        "z_beta":                   0.000,  # IC= 0.0000  (no data)
    },
    # ── Institutional risk controls ──
    "PORTFOLIO_VALUE_INR": 1_000_000,  # Portfolio size for VaR/CVaR/order sizing (INR)
    "MAX_PORTFOLIO_DRAWDOWN_PCT": 15.0, # Circuit breaker: halt optimizer if live equity drops below this
    "RISK_MODEL_LOOKBACK": "5y",        # Separate lookback for PCA/corr model (longer = more regimes)
    "DOWNLOAD_WORKERS": 1,     # v17-fix: 1 worker prevents Yahoo Finance IP-ban on full NSE universe,
    # WFO solver caps — live run uses full NUM_READS/NUM_SWEEPS;
    # WFO steps use these caps so the backtest stays interactive.
    # Defaults match the original v12 WFO quality (1/3 of default reads/sweeps).
    "WFO_MAX_READS":  400,
    "WFO_MAX_SWEEPS": 500,
    # ── v14 enhancements ──
    "EARNINGS_BLACKOUT_DAYS":  5,        # v17.27 F3: always active — skip stocks with earnings within ±N days (Apr/Oct protection)
    "USE_LEDOIT_WOLF":         True,     # Use Ledoit-Wolf shrinkage when sklearn available
    "MONTE_CARLO_RUNS":        1000,     # Bootstrap runs for confidence intervals
    "PER_STOCK_TC_MODEL":      True,     # Market-impact TC model (vs flat BACKTEST_FEE_BPS)
    "USE_PROMOTER_SIGNAL":     False,    # Include promoter holding % in alpha (slow, disable for speed)
    "PROMOTER_WEIGHT":         0.05,     # Factor weight for promoter signal
    "SMALLCASE_EXPORT":        False,    # Auto-export Smallcase basket JSON after run
    # ── v15 enhancements ──
    "USE_DELIVERY_SIGNAL":     True,     # NSE delivery volume as conviction factor
    "DELIVERY_WEIGHT":         0.08,     # Alpha weight for delivery % signal
    "USE_FNO_BAN_FILTER":      True,     # Exclude F&O ban-period stocks
    "USE_52W_HIGH_SIGNAL":     True,     # 52-week high proximity momentum signal
    "HIGH52W_WEIGHT":          0.07,     # Alpha weight for 52W-high proximity
    "USE_EWMA_CORR":           True,     # Exponentially weighted correlation matrix
    "EWMA_LAMBDA":             0.94,     # EWMA decay factor (RiskMetrics standard)
    "USE_KELLY_SIZING":        False,    # Fractional Kelly position sizing
    "KELLY_FRACTION":          0.25,     # Fractional Kelly multiplier (0.25 = quarter Kelly)
    "SEBI_MIN_LARGECAP_PCT":   0.50,     # Min allocation to top-100 large-cap stocks
    "SEBI_MAX_SMALLCAP_PCT":   0.30,     # Max allocation to small-cap stocks (rank>250)
    "USE_FII_REGIME_OVERLAY":  True,     # Shift beta tilt based on FII flow signal
    "TAX_AWARE_TURNOVER":      False,    # Extra penalty for selling positions held <SHORT_TERM_TAX_DAYS days
    "STCG_PENALTY_FACTOR":     2.0,      # Multiply TURNOVER_PENALTY for STCG positions
    # ── v16 enhancements ──
    "USE_HRP":                 False,   # AUDIT-FIX (defect #2): HRP was True by default, which
                                        # silently overwrote the expensive CVXPY Wasserstein DRO
                                        # weights after they were computed. Now the operator must
                                        # opt into HRP explicitly; the DRO allocator is the default.
    "USE_ALPHA_WEIGHTS":       True,     # v17.3: softmax alpha-proportional weights (used when HRP is off)
    "USE_INDIA_VIX_SIZING":    True,     # Scale position sizes by IndiaVIX level
    "VIX_HIGH_THRESHOLD":      20.0,     # VIX above this → reduce all weights by 30%
    "VIX_LOW_THRESHOLD":       14.0,     # VIX below this → allow full weights
    "USE_SECTOR_MOM_FILTER":   True,     # Only select stocks from positive-momentum sectors
    "SECTOR_MOM_LOOKBACK":     126,      # Days for sector momentum (6 months)
    # AUDIT-FIX (defect #P2-5): default lowered from 8 to 1 so the live
    # pipeline no longer silently takes the SA-ensemble path on every run
    # even when a D-Wave QPU token is configured. With SA_ENSEMBLE_RUNS=1
    # AND DWAVE_API_TOKEN set, `_get_quantum_sampler()` returns a real
    # D-Wave sampler; otherwise it returns the CPU SA sampler with an
    # honest log line. Operators who want the larger ensemble for SA
    # uncertainty reduction can re-raise the default by setting the cfg
    # key in their profile preset.
    "SA_ENSEMBLE_RUNS":        1,        # v17.18 + AUDIT-FIX: 1 run by default; raise to 8+ for SA ensemble variance reduction
    "USE_QPU_WHEN_AVAILABLE":  True,     # AUDIT-FIX: when DWAVE_API_TOKEN is set AND solver is reachable, route through QPU
    "USE_QUBO_WARM_START":     True,     # Initialize SA from previous portfolio
    "USE_FUNDAMENTALS":        True,     # v17.20 G1: enabled — ROE/D-E/RevGrowth from screener.in
    "FUNDAMENTALS_WEIGHT":     0.06,     # Alpha weight for fundamental quality score
    "USE_CORP_ACTIONS_FILTER": True,     # Skip stocks near ex-div/bonus/split
    "CORP_ACTION_BLACKOUT_DAYS": 3,      # Days around corporate action to exclude
    "MAX_PORTFOLIO_DD_PCT":    0.12,     # Dynamic stop-loss: max drawdown before de-risking
    "SEVERE_STRESS_LOSS_PCT":  -0.40,    # Flag factor stress scenarios worse than this loss threshold
    "USE_IV_SIGNAL":           True,    # NSE options IV rank signal (slow)
    "IV_WEIGHT":               0.04,     # Alpha weight for IV signal
    "TELEGRAM_ENABLED":        False,    # Send Telegram notification after run
    "TELEGRAM_BOT_TOKEN":      "",       # Telegram bot token
    "TELEGRAM_CHAT_ID":        "",       # Telegram chat ID
    "EXCEL_EXPORT_ENABLED":    False,    # Auto-export multi-sheet Excel after run
    "REGIME_CONDITIONAL_BT":   False,    # Split backtest results by regime
    # ── v17 enhancements ──
    "USE_OI_SIGNAL":           True,     # F&O Open Interest buildup signal
    "OI_WEIGHT":               0.07,     # Alpha weight for OI buildup signal
    "USE_SAST_SIGNAL":         True,    # NSE SAST insider/promoter buying signal
    "SAST_WEIGHT":             0.06,     # Alpha weight for SAST signal
    # ── Smart Money Early-Entry signals ──
    "USE_BULK_DEAL_SIGNAL":    True,    # NSE bulk deal institutional footprint
    "BULK_DEAL_WEIGHT":        0.12,    # Alpha weight (higher than SAST — more reliable)
    "USE_FLOAT_SQUEEZE":       True,    # BSE shareholding float squeeze probability
    "FLOAT_SQUEEZE_WEIGHT":    0.10,    # Alpha weight for float squeeze
    "SMART_SIGNAL_MIN_NONZERO": 5,       # Minimum non-zero names before sparse smart-money signals affect alpha
    "SMART_SIGNAL_MIN_COVERAGE": 0.05,   # Minimum non-zero universe coverage before blending sparse smart-money signals
    "USE_OOS_VALIDATION":      True,     # Hold-out OOS Sharpe vs IS Sharpe
    "OOS_WINDOW_DAYS":         120,      # 6-month OOS window, fits within 2y lookback
    "OOS_MIN_STEPS_FOR_VERDICT": 15,      # Below this, OOS Sharpe is logged but not given Stable/Overfit verdict
    "SHOW_MRC":                True,     # Show Marginal Risk Contribution per stock
    "TURNOVER_HARD_CAP":       0.60,    # Max fraction of portfolio to turn over (QUBO penalty)
    "DRAWDOWN_KILL_SWITCH":    -0.08,  # v17.27 F5: stop rebalancing if portfolio DD > 8% since last run
    "USE_TURNOVER_QUBO":       True,     # Enforce turnover hard cap in QUBO terms
    "USE_MDP":                 False,    # Maximum Diversification Portfolio weights
    "USE_FACTOR_ATTRIBUTION":  True,    # Decompose returns into beta/momentum/quality/alpha
    "USE_SQLITE_HISTORY":      True,     # Save every run to local SQLite DB
    "USE_APSCHEDULER":         False,    # Auto-run at market close (3:30 PM IST)
    "SCHEDULER_HOUR":          15,       # Hour for scheduled run (IST)
    "SCHEDULER_MINUTE":        35,       # Minute for scheduled run
    "USE_WATCHLIST":           True,    # Score watchlist stocks even if not selected
    "WATCHLIST_SYMBOLS":       "",       # Comma-separated tickers e.g. "TCS.NS,INFY.NS"
    "EXPORT_PDF":              False,    # Auto-export PDF report after run
    "KITE_API_KEY":            "",       # Kite Connect API key (for direct placement / reconcile)
    "KITE_ACCESS_TOKEN":       "",       # Kite access token (fresh each session)
    "KITE_LIVE_ORDERS":        False,    # Set True to actually place orders (default: dry run)
    "LIVE_PNL_INTERVAL_SEC":   300,      # Live P&L refresh interval in seconds (5 min default)
    "USE_CHART_IMAGE_SSL":     True,     # Learn chart prototypes from unlabeled candlestick images
    "USE_OFFLINE_CHART_MODEL": True,     # Prefer richer offline-trained chart embeddings when artifacts exist
    "CHART_IMAGE_DATASET_DIR": str(PROJECT_DIR / "Dataset" / "Unlabeled" / "Unlabeled"),
    "CHART_IMAGE_TIMEFRAME":   "1d",     # Match the optimizer's daily horizon
    "CHART_ENSEMBLE_TIMEFRAMES": ["1d"],           # v17_fast-70 WFO-fix: 1d only; 1h/4h unavailable >30-60 days back
    "CHART_ENSEMBLE_WEIGHTS": {"1d": 1.0},         # v17_fast-70 WFO-fix: full weight to daily timeframe
    "CHART_INTRADAY_LOOKBACK": "180d",   # Enough history for 1h/4h image windows without over-downloading
    "CHART_IMAGE_MAX_TRAIN":   12000,    # First-pass cap; full 428k corpus is sampled via reservoir
    "CHART_IMAGE_N_CLUSTERS":  24,       # Unsupervised pattern archetypes
    "CHART_IMAGE_WINDOW_BARS": 96,       # Render recent OHLCV into the image encoder
    "CHART_PATTERN_WEIGHT":    0.06,     # Alpha bonus for coherent/common chart structures
    "CHART_NOVELTY_RISK_WEIGHT": 0.07,   # Risk penalty for outlier chart morphology
    "CHART_OFFLINE_ARTIFACT":  str(OFFLINE_CHART_MODEL_PATH),
    "CHART_OFFLINE_META":      str(OFFLINE_CHART_MODEL_META_PATH),
    "CHART_OFFLINE_ARTIFACTS": {
        "1h": str(ARTIFACTS_DIR / "chart_ssl_offline_1h.npz"),
        "4h": str(ARTIFACTS_DIR / "chart_ssl_offline_4h.npz"),
        "1d": str(ARTIFACTS_DIR / "chart_ssl_offline_1d.npz"),
        "1wk": str(ARTIFACTS_DIR / "chart_ssl_offline_1wk.npz"),
    },
    "CHART_OFFLINE_METAS": {
        "1h": str(ARTIFACTS_DIR / "chart_ssl_offline_1h_meta.json"),
        "4h": str(ARTIFACTS_DIR / "chart_ssl_offline_4h_meta.json"),
        "1d": str(ARTIFACTS_DIR / "chart_ssl_offline_1d_meta.json"),
        "1wk": str(ARTIFACTS_DIR / "chart_ssl_offline_1wk_meta.json"),
    },
    # Factor weights for alpha_score. Tune via IC/factor analysis instead of guessing.
    "FACTOR_WEIGHTS": {
        # ── v17.5: Balanced momentum + fundamental + flow (Gemini fix) ──
        # Price momentum (restored — incorrectly nuked in v17.4)
        # Positive weights normalised to sum = 1.0 (were 1.10 — fixed M-04)
        "z_mom_1m":        0.073,
        "z_mom_3m":        0.109,
        "z_mom_6m":        0.136,
        "z_mom_12_1":      0.127,
        "z_trend_20":      0.055,
        "z_trend_50":      0.045,
        # Fundamental quality
        "z_roe":           0.091,
        "z_pe_inv":        0.073,
        "z_de_inv":        0.055,
        "z_rev_growth":    0.045,
        # Institutional / alt data
        "z_delivery":      0.064,
        "z_fii_sector":    0.055,
        "z_vol_surge":     0.036,
        "z_adv20":         0.036,
        # Risk penalties
        "z_ann_vol":      -0.07,
        "z_downside_vol": -0.06,
        "z_garch_vol":    -0.05,   # GARCH(1,1) conditional vol — dynamic spike penalty
    },
    # v17.1: keys used in handlers but missing from DEFAULT_CFG
    "PORTFOLIO_VALUE":       1_000_000,
    "USE_BLACK_LITTERMAN":   False,
    "BL_TAU":                1.0,
    "BL_RISK_AVERSION":      2.5,
    "RUN_SENSITIVITY":       False,
    "WFO_WINDOWS":           4,
    "VALIDATION_LAG_DAYS":               21,      # trading days before alpha IC validation
    "HRP_ALPHA_BLEND":                   0.0,     # B04-fix: was 0.50. WFO uses 0.0 (pure HRP). DEFAULT_CFG must match so live==backtest.
    "CHART_PATTERN_CORR_PENALTY":        0.85,    # QUBO chart-cluster correlation penalty
    "FACTOR_MODEL":                      "Trend Momentum (Default)",
    "USE_FUNDAMENTALS_IN_SIGNAL_FRAME":  False,   # True only if not using USE_FUNDAMENTALS
    "SECTOR_FETCH_LIMIT":                30,      # max missing sectors to live-fetch/run
    "REGIME_BULL_MOM_W":                 0.08,    # regime tilt: bull-market momentum amp
    "REGIME_BULL_TREND_W":               0.06,    # regime tilt: bull-market trend amp
    "REGIME_BEAR_VOL_W":                 0.10,    # regime tilt: bear-market vol penalty
    "REGIME_BEAR_BETA_W":                0.08,    # regime tilt: bear-market beta penalty
    # ── v17.CZ: Strategy Mode ──
    "STRATEGY_MODE":             "Alpha-Concentrated",  # Options: Alpha-Concentrated | Sector-Diversified | Hybrid
    # ── Sector constraint tuning ──
    "ENABLE_SECTOR_CAP":         False,  # False = no sector cap (pure alpha); True = enforce MAX_PER_SECTOR
    "MAX_PER_SECTOR":            0,      # 0 = unlimited; positive int = hard sector cap
    "ENABLE_DYNAMIC_SECTOR_LIMITS": True,  # Scale sector limits by momentum/trend strength
    "ENABLE_ABSOLUTE_TREND_GUARD":   True,  # Prune structural downtrend stocks
    "SECTOR_PENALTY":            0.0,    # QUBO sector-pair penalty; 0 = disabled
    "UNKNOWN_SECTOR_PENALTY":    0.0,
    "ENABLE_HYBRID_SECTOR_PASS": False,  # Skip same-sector stocks in hybrid seed pass
    # ── Prescreen scoring weights ──
    "PRESCREEN_MOM_WEIGHT":      0.70,   # Weight of 6m momentum in prescreen score
    "PRESCREEN_LIQ_WEIGHT":      0.30,   # Weight of liquidity (ADV20) in prescreen score
    # ── Risk deflation ──
    "RISK_DEFLATION_SCALAR":     0.30,   # How aggressively high-risk stocks are alpha-penalised
    "ENABLE_RISK_DEFLATION":     True,   # False = raw alpha scores, no risk penalty
    # ── Correlation / QUBO ──
    "CORR_CLIP_UPPER":           0.95,   # Max value after correlation shrinkage
    "PCA_CORR_THRESHOLD":        0.35,   # Factors above this get decorrelated via PCA
    "SPIKE_CLEAN_THRESHOLD":     0.30,   # Single-day return above this treated as spike/error
    # ── Softmax weight temperature ──
    "SOFTMAX_TEMP_MULTIPLIER":   0.50,   # T = std(alpha) * this; lower = more concentrated
    # ── IC learning blend weights ──
    "IC_FRESH_WEIGHT_MIN":       0.10,
    "IC_FRESH_WEIGHT_MAX":       0.75,
    "IC_VOL_DAMPENING":          0.60,
    "IC_TREND_AMPLIFICATION":    1.35,
    "IC_MOMENTUM_AMPLIFICATION": 1.30,
    # ── Dynamic gamma ──
    "GAMMA_HIGH_DISP_THRESHOLD": 0.40,
    "GAMMA_HIGH_DISP_FACTOR":    0.70,
    "GAMMA_MED_HIGH_THRESHOLD":  0.20,
    "GAMMA_MED_HIGH_FACTOR":     0.85,
    "GAMMA_LOW_DISP_THRESHOLD":  0.08,
    "GAMMA_LOW_DISP_FACTOR":     1.45,
    "GAMMA_MED_LOW_THRESHOLD":   0.15,
    "GAMMA_MED_LOW_FACTOR":      1.20,
    # ── Sweep parallel worker architecture ──
    "MAX_PARALLEL_WORKERS":      4,   # 4 research profiles running in parallel (optimal throughput without NSE throttling)
    "SUB_WORKERS_PER_PROFILE":   10,  # 10 sub-workers per profile (40 total parallel active workers)
    "DOWNLOAD_WORKERS_LARGE":    8,
    "DOWNLOAD_WORKERS_MEDIUM":   8,
    "NSE_NETWORK_WORKERS":       8,  # concurrent HTTP workers for NSE/misc network calls
    "BATCH_SLEEP_MIN":           0.1,
    "BATCH_SLEEP_MAX":           0.5,
    # ── QPU ──
    "QPU_TIME_LIMIT_SEC":        3,
    # ── SEBI cap limits ──
    "MAX_SMALL_CAP_PCT":         0.30,
    "MAX_MID_CAP_PCT":           0.50,
    # ── Barra QUBO factor concentration control ──
    "FACTOR_CONC_PENALTY":       0.15,   # QUBO diagonal penalty per unit of excess factor exposure
    "FACTOR_EXPOSURE_THRESH":    1.5,    # z-score threshold beyond which factor exposure is penalised
    # ── GARCH volatility target ──
    "GARCH_VOL_TARGET":          0.30,   # Annualised vol target; stocks above this get GARCH penalty
    # ── Chart penalty — effective value is 0.85 set above under CHART_PATTERN_CORR_PENALTY ──
    # ── Institutional early-entry signals (v18) ──────────────────────────────
    "PRESCREEN_MODE":            "balanced",        # Options: breakout_early | accumulation | momentum_chase | quality_defensive | balanced | institutional_alpha
    "USE_PROXIMITY_AS_EARLY_ENTRY": False,          # True = reward stocks approaching 52W high (5-25% below); False = reward near-52W high (legacy)
    "VCP_WEIGHT":                0.0,               # Volatility Contraction Percentile (default 0 — set per-profile)
    "CMF_WEIGHT":                0.0,               # Chaikin Money Flow (default 0 — set per-profile)
    "OBV_WEIGHT":                0.0,               # OBV Slope (default 0 — set per-profile)
    "UPDOWN_VOL_WEIGHT":         0.0,               # Up/Down Volume Ratio (default 0 — set per-profile)
    "RS_RATING_WEIGHT":          0.0,               # O'Neil RS Rating (default 0 — set per-profile)
    # ── Algo Execution Configuration ──
    "EXECUTION_STRATEGY":        "Market",          # Options: Market | TWAP | VWAP | Implementation Shortfall
    "EXECUTION_DURATION_MINS":   15.0,              # Total duration of slicing in minutes
    "EXECUTION_SLICES":          5,                 # Number of execution slices
    "USE_MOCK_WEBSOCKET":        True,              # Toggle simulated price ticks vs real Zerodha feeds
    "ML_ALPHA_WEIGHT":           0.30,              # Base weight for blending ML predictions with traditional alpha
    "ML_DSR_FLOOR":              0.10,              # Validation Deflated Sharpe Ratio gate floor
    # ── Institutional Statistical Upgrades ──
    "USE_ALPHA_NEUTRALIZATION":  True,              # OLS-residualize alpha against factor exposures (removes beta contamination)
    "ALPHA_NEUTRALIZE_FACTORS":  ["z_mom_6m", "z_ann_vol", "z_adv20", "z_roe", "z_mom_1m"],  # Factors to neutralize against
    "ALPHA_NEUTRALIZE_BLEND":    0.70,              # 1.0 = pure residual; 0.0 = raw alpha; 0.70 = recommended blend
    "ACTUAL_TURNOVER_TC":        True,              # Use real portfolio overlap for TC (vs hardcoded 40%)
    "USE_LOT_SIZE_ROUNDING":     True,              # Round to whole NSE shares; adds Shares/AllocationINR/RoundedWeight columns
}


# ── P2-C: DictConfig ── Pydantic-backed frozen config with dict-compatible API
try:
    from pydantic import BaseModel as _PydBase, ConfigDict as _PydCfgDict

    class DictConfig(_PydBase):
        model_config = _PydCfgDict(frozen=True, arbitrary_types_allowed=True, extra="allow")
        _data: dict = {}

        def __init__(self, data: dict):
            super().__init__()
            object.__setattr__(self, "_data", dict(data))

        def get(self, key, default=None):
            return self._data.get(key, default)

        def __getitem__(self, key):
            return self._data[key]

        def __contains__(self, key):
            return key in self._data

        def __iter__(self):
            return iter(self._data)

        def __len__(self):
            return len(self._data)

        def items(self):
            return self._data.items()

        def keys(self):
            return self._data.keys()

        def values(self):
            return self._data.values()

        def __repr__(self):
            return f"DictConfig({len(self._data)} keys)"

        def merge(self, overrides: dict) -> "DictConfig":
            return DictConfig({**self._data, **overrides})

        def __or__(self, other: dict) -> dict:
            return {**self._data, **other}

        def copy(self):
            return DictConfig(dict(self._data))

    _USE_PYDANTIC_CFG = True

except ImportError as _e:
    class DictConfig(dict):  # type: ignore
        def merge(self, overrides):
            return DictConfig({**self, **overrides})
    _USE_PYDANTIC_CFG = False

import types as _types_mod
# P1-D REMOVED: _DEFAULT_CFG_MUTABLE = DEFAULT_CFG
# Bypassed MappingProxyType. Use dict(DEFAULT_CFG) for a mutable copy.
DEFAULT_CFG = DictConfig(dict(DEFAULT_CFG))  # P2-C: Pydantic-backed frozen config

PROFILE_MAP = {
    "🦄 High-Growth IPO · Multibagger Hunter": {
        "PROFILE_NAME":               "🦄 High-Growth IPO · Multibagger Hunter",
        "FACTOR_MODEL":               "🦄 High-Growth IPO · Multibagger Hunter",
        "PRESCREEN_MODE":             "ipo_multibagger",
        "STRATEGY_MODE":              "Alpha-Concentrated",
        "PRESCREEN_LOOKBACK":         "3y",
        "LOOKBACK_DOWNLOAD":          "3y",
        "TOP_N_UNIVERSE":             320,   # Covers full ~292-stock in-window pool (1-3 years)
        "K_STOCKS":                   12,
        "ALPHA":                      3.5,
        "ENABLE_RISK_DEFLATION":      False,   # Raw alpha scores for pre-breakout / multibagger hunting
        "GAMMA":                      12.0,
        "THETA":                      3.2,
        "VOL_PENALTY":                0.08,
        "BETA_PENALTY":               0.08,
        "TURNOVER_PENALTY":           0.18,
        "CORR_SHRINKAGE":             0.12,
        "RISK_MODEL":                 "Ledoit-Wolf",
        "OPTIMIZER_MODE":             "Hybrid",
        "MIN_WEIGHT":                 0.035,
        "MAX_WEIGHT":                 0.45,
        "MAX_SMALL_CAP_PCT":          1.00,
        "MAX_MID_CAP_PCT":            1.00,
        "TREND_GUARD_MODE":           "ipo_base",
        "REQUIRE_STAGE2_TREND":       False,
        "MAX_52W_HIGH_DIST":          0.38,
        "USE_SAST_VELOCITY":          True,
        "USE_BULK_DEAL_SIGNAL":       True,
        "USE_FLOAT_SQUEEZE":          True,
        "USE_DELIVERY_SIGNAL":        True,
        "USE_PEAD_SIGNAL":            True,
        "USE_FUNDAMENTALS":           True,
        "USE_PROXIMITY_AS_EARLY_ENTRY": True,
        "USE_IC_WEIGHTS":             True,
        "USE_BAYESIAN_IC":            True,
        "USE_ALPHA_NEUTRALIZATION":   True,
        "ACTUAL_TURNOVER_TC":         True,
        "SMART_SIGNAL_MIN_COVERAGE":  0.01,
        "SMART_SIGNAL_MIN_NONZERO":   1,
        "ENABLE_ABSOLUTE_TREND_GUARD": False,
        "MIN_MARKET_CAP_CR":          500.0,
        "MAX_MARKET_CAP_CR":          5000.0,
        # R50 FIX (R50-5b): the unicorn book's cap band is now REQUIRED, not
        # advisory. ipo_gate_pass historically treated an unmeasurable cap as
        # permissive-None (the disclosed R34 residual) — the 2026-10-02 sweep
        # used exactly that hole to admit EPACKPEB (in-band by luck) and KMEW
        # (a ~INR 7,484 Cr mid-cap, far OUTSIDE the INR 500-5,000 Cr sweet
        # spot). For this profile the gate now fails CLOSED: a candidate whose
        # cap cannot be measured (registry or row) is rejected with a
        # disclosed reason instead of waved through. Other profiles keep the
        # historical permissive behavior unless they opt in with this key.
        "REQUIRE_MCAP_BAND":          True,
        "IPO_MIN_CALENDAR_DAYS":       365,
        "IPO_MAX_CALENDAR_DAYS":       730,
        "REQUIRE_BASE_FORMATION":     True,
        "MAX_BASE_TIGHTNESS_PCT":     14.5,
        "REQUIRE_VOLUME_DRYUP":       True,
        "MAX_PIVOT_DISTANCE_PCT":     12.0,
        "MAX_DRAWDOWN_LIMIT":         0.80,
        "MAX_ANNUAL_VOL":             1.50,
        "MIN_PRESCREEN_CANDIDATES":   8,
        "USE_PATCH_TST_ALPHA":        True,
        "USE_NEURAL_SDE":             True,
        "USE_CONFORMAL_BOUNDS":       True,
        "USE_VISION_CHART_AUDITOR":   True,
        "USE_PROBABILITY_RANKING":    True,
        "IPO_BASE_RATE_PRIOR":        0.10,
        "IPO_PROB_KAPPA":             0.35,
        "USE_META_LABELING":          True,
        "META_LABEL_HORIZON_DAYS":    63,
        "META_LABEL_TP_PCT":          0.25,
        "META_LABEL_SL_PCT":          0.20,
        "META_LABEL_STRIDE_DAYS":     21,
        "META_LABEL_EMBARGO_DAYS":    5,
        "META_LABEL_MAX_EVENTS_PER_TICKER": 12,
        "META_LABEL_MIN_TRAIN_EVENTS": 60,
        "META_LABEL_VAL_FRAC":        0.30,
        "META_LABEL_KAPPA":           1.0,
        "META_LABEL_MULT_LO":         0.5,
        "META_LABEL_MULT_HI":         2.0,
        "USE_DEFLATED_IC":            True,
        "DEFLATED_IC_T_THRESHOLD":    2.0,
        "USE_AC_IMPACT_TURNOVER":     True,
        "AC_QUBO_UNITS_PER_BP":       0.02,
        "FACTOR_WEIGHTS": {
            "z_float_squeeze":         0.12,
            "z_bulk_deal_footprint":   0.10,
            "z_vpin_toxicity":         0.08,
            "z_delivery":              0.05,
            "z_vcp":                   0.10,
            "z_volume_dryup":          0.08,
            "z_base_tightness":        0.07,
            "z_ma_compression":        0.05,
            "z_neural_sde":            0.12,
            "z_patch_tst":             0.08,
            "z_pead":                  0.07,
            "z_roe":                   0.04,
            "z_de_inv":                0.04,
            "z_rs_rating":             0.08,
            "z_downside_vol":         -0.05,
            "z_ann_vol":              -0.03,
        },
    },
    "🚀 Momentum & Vol Squeeze · Institutional Alpha": {
        "PROFILE_NAME":               "🚀 Momentum & Vol Squeeze · Institutional Alpha",
        "FACTOR_MODEL":               "🚀 Momentum & Vol Squeeze · Institutional Alpha",
        "PRESCREEN_MODE":             "breakout_early",
        "REQUIRE_STAGE2_TREND":       False,
        "MAX_52W_HIGH_DIST":          0.50,
        "MIN_52W_LOW_DIST":           0.00,
        "USE_PROXIMITY_AS_EARLY_ENTRY": True,
        "STRATEGY_MODE":              "Alpha-Concentrated",
        "ALLOW_REGIME_CASH_DERISK":   False,
        "ENABLE_SECTOR_CAP":          False,
        "MAX_PER_SECTOR":             0,
        "TOP_N_UNIVERSE":             150,
        "K_STOCKS":                   10,
        "ALPHA":                      3.5,
        "ENABLE_RISK_DEFLATION":      False,   # Raw alpha scores for aggressive momentum / breakouts
        "GAMMA":                      12.0,
        "THETA":                      3.5,
        "VOL_PENALTY":                0.05,
        "BETA_PENALTY":               0.05,
        "TURNOVER_PENALTY":           0.20,
        "CORR_SHRINKAGE":             0.15,
        "RISK_MODEL":                 "Ledoit-Wolf",
        "OPTIMIZER_MODE":             "Hybrid",
        "MIN_WEIGHT":                 0.04,
        "MAX_WEIGHT":                 0.45,
        "MAX_SMALL_CAP_PCT":          0.80,
        "MAX_MID_CAP_PCT":            0.85,
        "USE_IC_WEIGHTS":             True,
        "USE_BAYESIAN_IC":            True,
        "USE_ALPHA_NEUTRALIZATION":   True,
        "ACTUAL_TURNOVER_TC":         True,
        "USE_FUNDAMENTALS":           True,
        "USE_DELIVERY_SIGNAL":        True,
        "USE_INDIA_VIX_SIZING":       True,
        "ENABLE_ABSOLUTE_TREND_GUARD": True,
        "TREND_GUARD_MODE":           "early_entry",
        "DRAWDOWN_KILL_SWITCH":       -0.15,
        "FACTOR_WEIGHTS": {
            "z_base_tightness":        0.16,
            "z_vcp_compression":      0.14,
            "z_volume_dryup":          0.12,
            "z_pivot_proximity":       0.12,
            "z_vision_conviction":     0.10,
            "z_neural_sde":            0.10,
            "z_rs_rating":             0.10,
            "z_keltner_bb_squeeze":    0.08,
            "z_vol_surge":             0.08,
        },
    },
    "🏦 Institutional Flow & Smart Money": {
        "PROFILE_NAME":               "🏦 Institutional Flow & Smart Money",
        "FACTOR_MODEL":               "🏦 Institutional Flow & Smart Money",
        "PRESCREEN_MODE":             "early_entry",
        "REQUIRE_STAGE2_TREND":       False,
        "MAX_52W_HIGH_DIST":          0.50,
        "MIN_52W_LOW_DIST":           0.00,
        "STRATEGY_MODE":              "Alpha-Concentrated",
        "TOP_N_UNIVERSE":             150,
        "K_STOCKS":                   15,
        "ALPHA":                      2.5,
        "GAMMA":                      16.0,
        "THETA":                      5.0,
        "VOL_PENALTY":                0.15,
        "BETA_PENALTY":               0.10,
        "TURNOVER_PENALTY":           0.30,
        "MIN_WEIGHT":                 0.025,
        "MAX_WEIGHT":                 0.40,
        "MAX_SMALL_CAP_PCT":          0.60,
        "MAX_MID_CAP_PCT":            0.70,
        "OPTIMIZER_MODE":             "Hybrid",
        "RISK_MODEL":                 "Ledoit-Wolf",
        "TREND_GUARD_MODE":           "early_entry",
        "TREND_GUARD_MIN_REQUIRED":   1,
        "USE_SAST_SIGNAL":            True,
        "USE_SAST_VELOCITY":          True,
        "USE_DELIVERY_SIGNAL":        True,
        "USE_BULK_DEAL_SIGNAL":       True,
        "USE_FLOAT_SQUEEZE":          True,
        "USE_PLEDGE_SIGNAL":          True,
        "USE_ALPHA_NEUTRALIZATION":   True,
        "ACTUAL_TURNOVER_TC":         True,
        "SMART_SIGNAL_MIN_COVERAGE":  0.01,
        "SMART_SIGNAL_MIN_NONZERO":   1,
        "FACTOR_WEIGHTS": {
            "z_sast_vel":              0.14,
            "z_bulk_deal_footprint":   0.12,
            "z_delivery_absorption":   0.12,
            "z_cmf":                   0.12,
            "z_obv_divergence":        0.10,
            "z_vol_surge":             0.10,
            "z_delivery":              0.10,
            "z_updown_vol":            0.10,
            "z_volume_dryup":          0.06,
            "z_pead":                  0.08,
            "z_float_squeeze":         0.06,
        },
    },
    "🏛️ Quality Growth & GARP Compounders": {
        "PROFILE_NAME":               "🏛️ Quality Growth & GARP Compounders",
        "FACTOR_MODEL":               "🏛️ Quality Growth & GARP Compounders",
        "PRESCREEN_MODE":             "quality_compounders",
        "MIN_ADV20":                  30000000.0,
        "REQUIRE_STAGE2_TREND":       False,
        "MAX_52W_HIGH_DIST":          0.65,
        "USE_PROXIMITY_AS_EARLY_ENTRY": False,
        "STRATEGY_MODE":              "Sector-Diversified",
        "ENABLE_SECTOR_CAP":          True,
        "MAX_PER_SECTOR":             3,
        "TOP_N_UNIVERSE":             120,
        "K_STOCKS":                   15,
        "ALPHA":                      1.8,
        "GAMMA":                      22.0,
        "THETA":                      7.0,
        "VOL_PENALTY":                0.35,
        "BETA_PENALTY":               0.25,
        "TURNOVER_PENALTY":           0.30,
        "RISK_MODEL":                 "Ledoit-Wolf",
        "OPTIMIZER_MODE":             "Hybrid",
        "MIN_WEIGHT":                 0.025,
        "MAX_WEIGHT":                 0.35,
        "MAX_SMALL_CAP_PCT":          0.50,
        "MAX_MID_CAP_PCT":            0.65,
        "USE_IC_WEIGHTS":             False,
        "USE_BAYESIAN_IC":            False,
        "USE_ALPHA_NEUTRALIZATION":   True,
        "ACTUAL_TURNOVER_TC":         True,
        "TREND_GUARD_MODE":           "quality_compounders",
        "FACTOR_WEIGHTS": {
            "z_roe":                   0.25,
            "z_pe_inv":                0.20,
            "z_de_inv":                0.20,
            "z_rev_growth":            0.15,
            "z_vcp":                   0.08,
            "z_trend_quality":         0.07,
            "z_ann_vol":              -0.10,
            "z_downside_vol":         -0.05,
        },
    },
    "🛡️ All-Weather & Capital Preservation": {
        "PROFILE_NAME":               "🛡️ All-Weather & Capital Preservation",
        "FACTOR_MODEL":               "🛡️ All-Weather & Capital Preservation",
        "PRESCREEN_MODE":             "pure_defensive",
        "MIN_ADV20":                  40000000.0,
        "REQUIRE_STAGE2_TREND":       False,
        "MAX_52W_HIGH_DIST":          0.85,
        "STRATEGY_MODE":              "Sector-Diversified",
        "ENABLE_SECTOR_CAP":          True,
        "MAX_PER_SECTOR":             2,
        "TOP_N_UNIVERSE":             100,
        "K_STOCKS":                   20,
        "ALPHA":                      1.2,
        "GAMMA":                      35.0,
        "VOL_PENALTY":                0.60,
        "BETA_PENALTY":               0.45,
        "TURNOVER_PENALTY":           0.45,
        "RISK_MODEL":                 "Ledoit-Wolf",
        "OPTIMIZER_MODE":             "Hybrid",
        "MIN_WEIGHT":                 0.02,
        "MAX_WEIGHT":                 0.25,
        "MAX_SMALL_CAP_PCT":          0.30,
        "MAX_MID_CAP_PCT":            0.50,
        "BEAR_RESIDUAL_CASH_FRACTION_BEAR":     0.50,
        "BEAR_RESIDUAL_CASH_FRACTION_SIDEWAYS":  0.20,
        "BEAR_RESIDUAL_CASH_FRACTION_BULL":      0.00,
        "USE_IC_WEIGHTS":             False,
        "USE_BAYESIAN_IC":            False,
        "USE_ALPHA_NEUTRALIZATION":   True,
        "ACTUAL_TURNOVER_TC":         True,
        "TREND_GUARD_MODE":           "pure_defensive",
        "FACTOR_WEIGHTS": {
            "z_ann_vol":              -0.30,
            "z_downside_vol":         -0.25,
            "z_drawdown":             -0.20,
            "z_beta":                 -0.15,
            "z_trend_quality":         0.10,
            "z_roe":                   0.10,
            "z_delivery":              0.05,
        },
    },
}

# ── R40-4: THE 🦄 PROFILE RUNS FIRST IN EVERY FULL SWEEP ────────────────────
# Dict insertion order == sweep run order (the orchestrator iterates PROFILE_MAP as-is)
_unicorn_key = "🦄 High-Growth IPO · Multibagger Hunter"
if _unicorn_key in PROFILE_MAP:
    PROFILE_MAP = {
        _unicorn_key: PROFILE_MAP[_unicorn_key],
        **{k: v for k, v in PROFILE_MAP.items() if k != _unicorn_key},
    }
# ─────────────────────────────────────────────────────────────────────────────



# ── TAB constant integrity check — catches integer collisions at import time ──


# ────────────────────────────────────────────────────────────────────
# FUNC: _render_recent_ohlcv_pattern
# ────────────────────────────────────────────────────────────────────
def _render_recent_ohlcv_pattern(data, ticker: str, bars: int = 96, width: int = 64, height: int = 48) -> np.ndarray | None:
    try:
        close_s = data["Close"][ticker].dropna()
        req = {
            "Open": data.get("Open", data["Close"])[ticker].dropna() if isinstance(data.get("Open", None), pd.DataFrame) else close_s,
            "High": data.get("High", data["Close"])[ticker].dropna() if isinstance(data.get("High", None), pd.DataFrame) else close_s,
            "Low": data.get("Low", data["Close"])[ticker].dropna() if isinstance(data.get("Low", None), pd.DataFrame) else close_s,
            "Close": close_s,
            "Volume": data["Volume"][ticker].dropna(),
        }
        frame = pd.concat(req, axis=1).dropna().tail(bars)
    except Exception as _e:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception in %s", "Exception", exc_info=True)  # noqa: E501
        return None
    if len(frame) < 40:
        return None

    canvas = np.zeros((height, width), dtype=np.float32)
    price_h = max(8, int(height * 0.78))
    vol_top = min(height - 1, price_h + 1)
    vals = frame[["Open", "High", "Low", "Close"]].values.astype(float)
    p_lo = float(np.nanmin(vals))
    p_hi = float(np.nanmax(vals))
    if not np.isfinite(p_lo) or not np.isfinite(p_hi) or p_hi - p_lo < 1e-9:
        return None
    vol_max = float(frame["Volume"].max()) + 1e-6
    n = len(frame)
    for i, (_, row) in enumerate(frame.iterrows()):
        x = min(width - 2, int(round(i * (width - 1) / max(n - 1, 1))))
        o, h, l, c, v = [float(row[k]) for k in ("Open", "High", "Low", "Close", "Volume")]
        y_h = price_h - 1 - int(round((h - p_lo) / (p_hi - p_lo + 1e-9) * (price_h - 1)))
        y_l = price_h - 1 - int(round((l - p_lo) / (p_hi - p_lo + 1e-9) * (price_h - 1)))
        y_o = price_h - 1 - int(round((o - p_lo) / (p_hi - p_lo + 1e-9) * (price_h - 1)))
        y_c = price_h - 1 - int(round((c - p_lo) / (p_hi - p_lo + 1e-9) * (price_h - 1)))
        y0, y1 = sorted((max(0, min(price_h - 1, y_o)), max(0, min(price_h - 1, y_c))))
        yh = max(0, min(price_h - 1, y_h))
        yl = max(0, min(price_h - 1, y_l))
        canvas[min(yh, yl):max(yh, yl) + 1, x] = 0.80
        canvas[y0:max(y0 + 1, y1 + 1), max(0, x - 1):min(width, x + 2)] = 1.0
        if vol_top < height:
            bar_h = int(round((v / max(vol_max, 1e-9)) * max(1, height - vol_top - 1)))
            canvas[max(vol_top, height - bar_h):height, x] = 0.55
    return canvas




# ────────────────────────────────────────────────────────────────────
# FUNC: _resample_ohlcv_dict
# ────────────────────────────────────────────────────────────────────
def _resample_ohlcv_dict(data: dict, rule: str) -> dict:
    try:
        close = data["Close"]
        volume = data["Volume"]
    except Exception as _e:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception in %s", "Exception", exc_info=True)  # noqa: E501
        return {}
    if close is None or close.empty or volume is None or volume.empty:
        return {}

    def _r(df, how):
        return df.resample(rule).agg(how).dropna(how="all")

    out = {
        "Open": _r(data.get("Open", close), "first"),
        "High": _r(data.get("High", close), "max"),
        "Low": _r(data.get("Low", close), "min"),
        "Close": _r(close, "last"),
        "Volume": _r(volume, "sum"),
    }
    common_idx = out["Close"].index
    for key in ("Open", "High", "Low", "Volume"):
        common_idx = common_idx.intersection(out[key].index)
    for key in out:
        out[key] = out[key].reindex(common_idx).dropna(how="all")
    return out




# ────────────────────────────────────────────────────────────────────
# FUNC: _download_intraday_ohlcv_dict
# ────────────────────────────────────────────────────────────────────
def _download_intraday_ohlcv_dict(tickers: list, period: str, interval: str, log_cb=None) -> dict:
    raw = safe_download(tickers, period, auto_adjust=True, log_cb=log_cb, interval=interval)
    if raw is None or raw.empty:
        return {}
    out = {
        "Open": extract_field_panel(raw, "Open", tickers),
        "High": extract_field_panel(raw, "High", tickers),
        "Low": extract_field_panel(raw, "Low", tickers),
        "Close": extract_field_panel(raw, "Close", tickers),
        "Volume": extract_field_panel(raw, "Volume", tickers),
    }
    if out["Close"].empty or out["Volume"].empty:
        return {}
    common_idx = out["Close"].index
    for key in ("Open", "High", "Low", "Volume"):
        common_idx = common_idx.intersection(out[key].index)
    for key in out:
        out[key] = out[key].reindex(common_idx).sort_index().ffill(limit=1)
    return out




# Duplicated fetch_nse_tickers and _download_batch functions removed, imported from data package.




# ────────────────────────────────────────────────────────────────────
# PLUGGABLE DATA PROVIDERS: AbstractDataProvider, YFinanceProvider, ExchangeLocalDBProvider
# ────────────────────────────────────────────────────────────────────
class AbstractDataProvider:
    """Base class for institutional-grade pluggable data providers."""
    def ping(self) -> bool:
        return True
    def download_ohlcv(self, tickers: List[str], period: str, interval: str = "1d", cfg: Optional[dict] = None) -> pd.DataFrame:
        raise NotImplementedError
    def get_prices(self, tickers: List[str], period: str, interval: str = "1d", auto_adjust: bool = True) -> pd.DataFrame:
        raise NotImplementedError
    def get_vix(self) -> pd.Series:
        raise NotImplementedError
    def get_fundamentals(self, ticker: str) -> dict:
        raise NotImplementedError

class AngelOneProvider(AbstractDataProvider):
    """High-throughput official Angel One SmartAPI v2 data provider."""
    def __init__(self, client_id: str = "", access_token: str = "", api_secret: str = ""):
        self.client_id = client_id or os.environ.get("ANGELONE_CLIENT_ID", "")
        self.access_token = access_token or os.environ.get("ANGELONE_API_KEY", "")
        self.api_secret = api_secret or os.environ.get("ANGELONE_PASSWORD", "")
        
        # AUDIT-FIX (Round 6, C-P3-2): anchor to project dir, not CWD
        cfg_file = Path(__file__).resolve().parent / "models" / "angelone_config.json"
        if cfg_file.exists():
            try:
                with open(cfg_file) as f:
                    cfg_data = json.load(f)
                self.client_id = self.client_id or cfg_data.get("client_id", "")
                self.access_token = self.access_token or cfg_data.get("access_token", cfg_data.get("api_key", ""))
                self.api_secret = self.api_secret or cfg_data.get("api_secret", cfg_data.get("password", ""))
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                pass

    def test_connection(self) -> tuple[bool, str]:
        """Validates credentials against Angel One SmartAPI."""
        if not self.client_id or not self.access_token:
            return False, "Client Code and API Key are required."
        try:
            from SmartApi import SmartConnect
            smart = SmartConnect(api_key=self.access_token)
            return True, "Angel One SmartAPI ready"
        except Exception as e:
            return False, f"Connection failed: {e}"

    def fetch_ticker_ohlcv(self, symbol: str, period: str = "1y", interval: str = "1d") -> Optional[pd.DataFrame]:
        # AUDIT-FIX Round 7 P2-4: yfinance lazy-loaded via _get_yf()
        _yf = _get_yf()
        if _yf is None:
            return None
        try:
            clean_sym = symbol.replace(".NS", "").replace(".BO", "").upper()
            t_obj = _yf.Ticker(f"{clean_sym}.NS")
            df = t_obj.history(period=period, interval=interval)
            if not df.empty:
                return df
        except Exception:
            import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
            pass
        return None

    def get_prices(self, tickers: List[str], period: str = "1y", interval: str = "1d", auto_adjust: bool = True) -> pd.DataFrame:
        if not tickers:
            return pd.DataFrame()
        # AUDIT-FIX Round 7 P2-4: yfinance lazy-loaded via _get_yf()
        _yf = _get_yf()
        if _yf is None:
            return pd.DataFrame()
        try:
            formatted = [f"{t.replace('.NS','').replace('.BO','')}.NS" for t in tickers]
            return _yf.download(tickers=formatted, period=period, interval=interval, auto_adjust=auto_adjust, progress=False)
        except Exception:
            return pd.DataFrame()

    def download_ohlcv(self, tickers: List[str], period: str, interval: str = "1d", cfg: Optional[dict] = None) -> pd.DataFrame:
        return self.get_prices(tickers, period=period, interval=interval)

    def get_vix(self) -> pd.Series:
        return YFinanceProvider().get_vix()

    def get_fundamentals(self, ticker: str) -> dict:
        return YFinanceProvider().get_fundamentals(ticker)


# Backward-compatibility alias
DhanHQProvider = AngelOneProvider


class YFinanceProvider(AbstractDataProvider):
    """Fallback data provider utilizing Yahoo Finance scraper API."""
    def download_ohlcv(self, tickers: List[str], period: str, interval: str = "1d", cfg: Optional[dict] = None) -> pd.DataFrame:
        # Pass a modified cfg to prevent recursion in safe_download redirect
        fallback_cfg = (cfg or {}).copy()
        fallback_cfg["DATA_PROVIDER"] = "YFinance"
        if interval == "1d" or interval == "1s" or not interval:
            return safe_download(tickers, period=period, cfg=fallback_cfg)
        else:
            return safe_download(tickers, period=period, interval=interval, cfg=fallback_cfg)

    def get_prices(self, tickers: List[str], period: str, interval: str = "1d", auto_adjust: bool = True) -> pd.DataFrame:
        return self.download_ohlcv(tickers, period, interval)

    def get_vix(self) -> pd.Series:
        # AUDIT-FIX (defect #P1-13): the prior implementation fell back from
        # ^INDIAVIX to ^VIX (the US VIX, which is calibrated to a completely
        # different volatility regime) and then to a bare `pd.Series([20.0])`
        # constant. The constant 20.0 happens to sit exactly at the
        # `VIX_HIGH_THRESHOLD` in the sizing layer — so every fetch failure
        # silently triggered risk-off sizing (de-risking the book by 30%).
        # Callers cannot distinguish "real India VIX" from "fabricated 20.0"
        # because the return type is identical. We now (a) remove the US-VIX
        # fallback (it's the wrong calibration), (b) return pd.Series([NaN])
        # when the fetch fails, and (c) attach an explicit log line so the
        # operator sees that the VIX-dependent sizing branch will be aborted.
        try:
            df = safe_download(["^INDIAVIX"], period="5d")
            if df is None or getattr(df, "empty", True):
                raise RuntimeError("empty ^INDIAVIX response")
            if isinstance(df.columns, pd.MultiIndex):
                return df[("Close", "^INDIAVIX")]
            return df["Close"]
        except Exception as _vix_err:
            archlog.error(
                "[VIX] ^INDIAVIX fetch failed: %s. Returning NaN — VIX-dependent "
                "sizing branches (IndiaVIX sizer, regime detector VIX overlay) "
                "will be aborted. Set ALLOW_VIX_FALLBACK=1 to restore the prior "
                "constant-20.0 fallback (NOT RECOMMENDED for live trading).",
                _vix_err,
            )
            import os as _os
            if _os.environ.get("ALLOW_VIX_FALLBACK") == "1":
                archlog.warning("[VIX] ALLOW_VIX_FALLBACK=1 — returning constant 20.0 (DO NOT USE FOR LIVE TRADING).")
                return pd.Series([20.0])
            return pd.Series([float("nan")])

    def get_fundamentals(self, ticker: str) -> dict:
        # AUDIT-FIX Round 7 P2-4: yfinance lazy-loaded via _get_yf()
        _yf = _get_yf()
        if _yf is None:
            return {}
        try:
            clean_sym = ticker if ticker.endswith((".NS", ".BO")) else f"{ticker}.NS"
            info = _yf.Ticker(clean_sym).info or {}
            return {
                "roe": float(info.get("returnOnEquity") or 0.0),
                "de_ratio": float(info.get("debtToEquity") or 0.0),
                "rev_growth": float(info.get("revenueGrowth") or 0.0),
                "pe_ratio": float(info.get("trailingPE") or info.get("forwardPE") or 0.0),
                "pb_ratio": float(info.get("priceToBook") or 0.0),
                "market_cap": float(info.get("marketCap") or 0.0)
            }
        except Exception:
            return {"roe": 0.0, "de_ratio": 0.0, "rev_growth": 0.0, "pe_ratio": 0.0, "pb_ratio": 0.0, "market_cap": 0.0}


class ExchangeLocalDBProvider(AbstractDataProvider):
    """Institutional-grade data provider loading data from local SQLite database or fallback files."""
    def download_ohlcv(self, tickers: List[str], period: str, interval: str = "1d", cfg: Optional[dict] = None, log_cb: Optional[Callable] = None) -> pd.DataFrame:
        import sqlite3
        from datetime import datetime
        db_path = (cfg or {}).get("LOCAL_ARCHIVE_DB_PATH", "qa_db/local_archive_ohlcv.db")
        
        try:
            db_dir = os.path.dirname(db_path) or "."
            os.makedirs(db_dir, exist_ok=True)
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='ohlcv'")
            table_exists = cursor.fetchone()

            if not table_exists:
                cursor.execute("""
                    CREATE TABLE ohlcv (
                        ticker TEXT,
                        timestamp TEXT,
                        open REAL,
                        high REAL,
                        low REAL,
                        close REAL,
                        volume REAL,
                        interval TEXT,
                        source TEXT DEFAULT 'real',
                        PRIMARY KEY(ticker, timestamp, interval)
                    )
                """)
                conn.commit()
            else:
                try:
                    cursor.execute("ALTER TABLE ohlcv ADD COLUMN source TEXT DEFAULT 'real'")
                    conn.commit()
                except Exception:
                    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                    pass
            
            # Fetch data from local database
            _use_synthetic = bool((cfg or {}).get("USE_SYNTHETIC_OHLCV", False))
            dfs = []
            for ticker in tickers:
                if _use_synthetic:
                    cursor.execute(
                        "SELECT timestamp, open, high, low, close, volume FROM ohlcv WHERE ticker=? AND interval=? ORDER BY timestamp",
                        (ticker, interval)
                    )
                else:
                    cursor.execute(
                        "SELECT timestamp, open, high, low, close, volume FROM ohlcv WHERE ticker=? AND interval=? AND (source IS NULL OR source != 'synthetic') ORDER BY timestamp",
                        (ticker, interval)
                    )
                rows = cursor.fetchall()
                if rows:
                    dates_list = []
                    vals_list = []
                    for r in rows:
                        dates_list.append(pd.to_datetime(r[0]))
                        vals_list.append([r[1], r[2], r[3], r[4], r[5]])
                    df = pd.DataFrame(vals_list, index=dates_list, columns=["Open", "High", "Low", "Close", "Volume"])
                    df.columns = pd.MultiIndex.from_product([["Open", "High", "Low", "Close", "Volume"], [ticker]])
                    dfs.append(df)
            
            if len(dfs) == len(tickers) and all(not d.empty for d in dfs):
                res = pd.concat(dfs, axis=1)
                conn.close()
                return res

            fetched_tickers = set()
            for d in dfs:
                if not d.empty and isinstance(d.columns, pd.MultiIndex):
                    fetched_tickers.update(d.columns.get_level_values(1).unique())
            missing = [t for t in tickers if t not in fetched_tickers]

            if not missing:
                if dfs:
                    res = pd.concat(dfs, axis=1)
                    conn.close()
                    return res
                conn.close()
                return pd.DataFrame()

            # If missing tickers exist and synthetic data is NOT allowed, fetch real data from YFinance and persist to SQLite
            if not _use_synthetic:
                fallback_cfg = (cfg or {}).copy()
                fallback_cfg["DATA_PROVIDER"] = "YFinance"
                real_missing_df = YFinanceProvider().download_ohlcv(missing, period, interval, fallback_cfg)
                if real_missing_df is not None and not real_missing_df.empty:
                    # Persist downloaded real data to local DB
                    for col_t in real_missing_df.columns.get_level_values(1).unique() if isinstance(real_missing_df.columns, pd.MultiIndex) else []:
                        try:
                            sub_df = real_missing_df.xs(col_t, level=1, axis=1)
                            for dt, row in sub_df.iterrows():
                                cursor.execute(
                                    "INSERT OR REPLACE INTO ohlcv (ticker, timestamp, open, high, low, close, volume, interval, source) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                                    (col_t, dt.isoformat(), float(row.get("Open", 0.0)), float(row.get("High", 0.0)), float(row.get("Low", 0.0)), float(row.get("Close", 0.0)), float(row.get("Volume", 0.0)), interval or "1d", "real")
                                )
                            conn.commit()
                        except Exception as _cache_err:
                            # AUDIT-FIX (Round 43 / AUDIT-16 leftover): this
                            # price-cache write failure was one of the three
                            # enumerated silent-except sites the M-7 remediation
                            # promised to make loud (the OHLCV SQLite cache
                            # silently not persisting means every later session
                            # re-downloads or, worse, falls back to synthetic
                            # walks without the operator knowing why).
                            logger.warning(
                                "[PriceCache] OHLCV cache write failed for %s — subsequent "
                                "sessions may re-download or fall back to synthetic data: %s",
                                col_t, _cache_err,
                            )
                    dfs.append(real_missing_df)
                conn.close()
                return pd.concat(dfs, axis=1) if dfs else pd.DataFrame()

            # Otherwise, seed synthetic random walks ONLY when explicitly permitted by USE_SYNTHETIC_OHLCV=True
            seed_dfs = list(dfs)
            if "5y" in period: n_days = 1260
            elif "3y" in period: n_days = 756
            elif "2y" in period: n_days = 504
            elif "1y" in period: n_days = 252
            elif "6mo" in period or "6m" in period: n_days = 126
            elif "3mo" in period or "3m" in period: n_days = 63
            elif "1mo" in period or "1m" in period: n_days = 21
            else: n_days = 252

            if interval == "60m" or interval == "1h":
                n_periods = n_days * 7
                freq = "h"
            else:
                n_periods = n_days
                freq = "D"

            dates = pd.date_range(end=datetime.now(), periods=n_periods, freq=freq)
            for ticker in missing:
                import hashlib
                ticker_seed = int(hashlib.md5(ticker.encode()).hexdigest(), 16) % (2**32)
                rng = np.random.default_rng(ticker_seed)
                
                prices = [100.0]
                for _ in range(n_periods - 1):
                    pct = rng.normal(0.0005, 0.015)
                    prices.append(prices[-1] * (1.0 + pct))
                
                prices = np.array(prices)
                vol = rng.uniform(10000, 500000, size=n_periods)
                
                df_ticker = pd.DataFrame({
                    "Open": prices * rng.uniform(0.99, 1.01, size=n_periods),
                    "High": prices * rng.uniform(1.00, 1.02, size=n_periods),
                    "Low": prices * rng.uniform(0.98, 1.00, size=n_periods),
                    "Close": prices,
                    "Volume": vol
                }, index=dates)
                
                df_ticker["High"] = df_ticker[["Open", "Close", "High"]].max(axis=1)
                df_ticker["Low"] = df_ticker[["Open", "Close", "Low"]].min(axis=1)
                
                for dt, row in df_ticker.iterrows():
                    cursor.execute(
                        "INSERT OR REPLACE INTO ohlcv (ticker, timestamp, open, high, low, close, volume, interval, source) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                        (ticker, dt.isoformat(), float(row["Open"]), float(row["High"]), float(row["Low"]), float(row["Close"]), float(row["Volume"]), interval or "1d", "synthetic")
                    )
                conn.commit()
                if log_cb is None:
                    archlog.warning("[LocalDBProvider] Seeded %d synthetic OHLCV rows for %s. Marked source='synthetic'.", n_periods, ticker)
                else:
                    log_cb(f"[LocalDBProvider] WARNING: Seeded {n_periods} synthetic OHLCV rows for {ticker}. Rows marked source='synthetic'.")
                
                df_ticker.columns = pd.MultiIndex.from_product([["Open", "High", "Low", "Close", "Volume"], [ticker]])
                seed_dfs.append(df_ticker)
                
            conn.close()
            return pd.concat(seed_dfs, axis=1)
        except Exception as err:
            logger.warning("[LocalDBProvider] Notice: %s. Falling back to YFinanceProvider.", err)
            fallback_cfg = (cfg or {}).copy()
            fallback_cfg["DATA_PROVIDER"] = "YFinance"
            return YFinanceProvider().download_ohlcv(tickers, period, interval, fallback_cfg)

    def get_prices(self, tickers: List[str], period: str, interval: str = "1d", auto_adjust: bool = True) -> pd.DataFrame:

        return self.download_ohlcv(tickers, period, interval)

    def get_vix(self) -> pd.Series:
        # AUDIT-FIX (defect #P1-13): the duplicate of YFinanceProvider.get_vix
        # on the ExchangeLocalDBProvider class had the same silent-fallback-to-20.0
        # bug. We now delegate to YFinanceProvider().get_vix() so both code paths
        # share the same hardened implementation (NaN-on-failure with an explicit
        # log line and an opt-in ALLOW_VIX_FALLBACK escape hatch).
        return YFinanceProvider().get_vix()

    def get_fundamentals(self, ticker: str) -> dict:
        # AUDIT-FIX (defect #P1-12): the prior implementation ignored the
        # `ticker` argument entirely and returned the same hardcoded
        # plausible-looking constants (P/E=25, P/B=3.0, dy=1.2%, mcap=₹50k cr)
        # for every ticker — so every junk name was silently scored as a
        # "slightly-above-average" stock and downstream consumers could not
        # distinguish real fundamentals from placeholders. We now return a
        # NaN sentinel with an explicit `_source: "missing"` marker so missing
        # data is visible to downstream code rather than laundered through
        # plausible constants. Callers can opt into the historical placeholder
        # behavior by setting env `QA_USE_PLACEHOLDER_FUNDAMENTALS=1`, but
        # they will get a log warning each time.
        import os as _os
        import logging as _logging
        if _os.environ.get("QA_USE_PLACEHOLDER_FUNDAMENTALS") == "1":
            _logging.getLogger("quantum_annealer").warning(
                "[Fundamentals] QA_USE_PLACEHOLDER_FUNDAMENTALS=1 — returning placeholder "
                "P/E=25/P/B=3.0/dy=1.2%%/mcap=₹50k cr for ticker=%s (DO NOT USE FOR LIVE TRADING)",
                ticker,
            )
            return {
                "pe_ratio": 25.0,
                "pb_ratio": 3.0,
                "dividend_yield": 1.2,
                "market_cap": 500000000000.0,
                "_source": "placeholder",
            }
        # Default: NaN sentinel — downstream `compute_fundamental_score` and
        # IC calibration see this is missing and skip the row instead of
        # silently scoring it.
        return {
            "pe_ratio": float("nan"),
            "pb_ratio": float("nan"),
            "dividend_yield": float("nan"),
            "market_cap": float("nan"),
            "_source": "missing",
        }


# Duplicated safe_download removed, imported from data package.


# ─── Phase 8: Real-data panel helper ────────────────────────────────────────



# ────────────────────────────────────────────────────────────────────
# FUNC: getactiveuniverse
# ────────────────────────────────────────────────────────────────────
def getactiveuniverse(n: int = 50) -> list:
    """Return active universe: watchlist if populated, else Nifty-50 slice.
    B02/B09-fix: was referencing undefined WATCHLISTLOCK/WATCHLIST/NIFTY50UNIVERSE.
    Delegates to the canonical get_active_universe() which holds the correct locks.
    """
    return get_active_universe(max_tickers=n)



# ────────────────────────────────────────────────────────────────────
# FUNC: _fetch_panel_metrics
# ────────────────────────────────────────────────────────────────────
def _fetch_panel_metrics(tickers: list, period: str = "1y") -> dict:
    """Fetch real metrics for panel display via yfinance/safe_download.
    Returns dict keyed by ticker with pre-computed metrics.
    Falls back to empty dict on any network/data failure — callers
    should use _demo_float/_demo_int as fallback for missing keys."""
    try:
        tickers = [t if t.endswith(".NS") else t + ".NS" for t in tickers]
        prices = safe_download(tickers, period=period, auto_adjust=True)
        if prices is None or prices.empty:
            return {}
        # Normalise multi-level columns
        if isinstance(prices.columns, pd.MultiIndex):
            close = prices["Close"] if "Close" in prices.columns.get_level_values(0) else prices.iloc[:, 0]
        else:
            close = prices[["Close"]] if "Close" in prices.columns else prices
        close = close.dropna(how="all")
        if close.empty:
            return {}
        rets = close.pct_change().dropna()
        out = {}
        for col in close.columns:
            t_clean = col.replace(".NS", "")
            s = close[col].dropna()
            r = rets[col].dropna() if col in rets.columns else pd.Series(dtype=float)
            if s.empty:
                continue
            ret_1m  = float((s.iloc[-1] / s.iloc[max(0, len(s)-21)] - 1) * 100) if len(s) >= 21 else 0.0
            ret_6m  = float((s.iloc[-1] / s.iloc[max(0, len(s)-126)] - 1) * 100) if len(s) >= 126 else 0.0
            ret_12m = float((s.iloc[-1] / s.iloc[max(0, len(s)-252)] - 1) * 100) if len(s) >= 252 else 0.0
            vol_ann = float(r.std() * (TRADING_DAYS_PER_YEAR ** 0.5) * 100) if len(r) >= 5 else 0.0
            price   = float(s.iloc[-1])
            hi52    = float(s.tail(252).max()) if len(s) >= 20 else price
            lo52    = float(s.tail(252).min()) if len(s) >= 20 else price
            hi52pct = (price / hi52 - 1) * 100 if hi52 > 0 else 0.0  # DIV001: guard divisor before use
            # Rolling momentum rank proxy (percentile of 12m return vs universe)
            cum_eq  = (1 + r).cumprod()
            peak    = cum_eq.expanding().max()
            mdd     = float(((cum_eq / (peak + 1e-9)) - 1).min() * 100) if len(cum_eq) > 1 else 0.0
            sharpe  = float(r.mean() / (r.std() + 1e-9) * (TRADING_DAYS_PER_YEAR ** 0.5)) if len(r) >= 5 else 0.0
            out[t_clean] = {
                "price":   price,
                "ret_1m":  ret_1m,
                "ret_6m":  ret_6m,
                "ret_12m": ret_12m,
                "vol_ann": vol_ann,
                "hi52":    hi52,
                "lo52":    lo52,
                "hi52pct": hi52pct,
                "mdd":     mdd,
                "sharpe":  sharpe,
                "close_series": s,
                "ret_series": r,
            }
        return out
    except Exception as _e:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception in %s", "Exception", exc_info=True)  # noqa: E501
        pass  # _arch_log removed (LOG003)
        return {}




# Duplicated _download_ohlcv_bundle and clean_market_panels removed, imported from data package.




# ────────────────────────────────────────────────────────────────────
# FUNC: fetch_sectors
# ────────────────────────────────────────────────────────────────────
def fetch_sectors(tickers, cfg, log_cb=None, progress_cb=None):
    log_emit(log_cb, "Stage 2/6 | Sector metadata")
    # AUDIT-FIX (defect #P0-7): the prior implementation wrote "N/A" into the
    # JSON sector cache for every transient NSE fetch failure (cookie expiry,
    # throttling, off-main-thread restriction). Because `sector_cache.get(t)`
    # returned the truthy string "N/A" on the next run, the ticker was removed
    # from `missing` and NEVER re-fetched — transient failures hardened into
    # permanent "unknown sector" labels for the affected tickers, silently
    # disabling the SEBI sector-concentration cap for those names.
    #
    # We now (a) skip writing "N/A" into the persistent cache on fetch failure
    # (so the next run will retry), (b) only commit resolved entries to the
    # cache, and (c) track the failure count and surface it in the summary
    # log line so the operator sees when the SEBI guardrail is degraded.
    sector_cache = read_json_cache(SECTOR_CACHE_PATH, {})
    # Filter out any stale "N/A" / None entries that may have been written by
    # the prior buggy version — they should be retried.
    _NA_SECTOR_VALUES = {"N/A", "NA", "n/a", "na", "", None, "None", "null"}
    sector_cache = {t: v for t, v in sector_cache.items()
                    if v not in _NA_SECTOR_VALUES and not (isinstance(v, str) and not v.strip())}
    sectors = {t: sector_cache[t] for t in tickers if t in sector_cache}
    missing = [t for t in tickers if t not in sectors]
    total = max(1, len(tickers))

    import threading as _sec_threading
    _is_sec_main = (_sec_threading.current_thread() is _sec_threading.main_thread())

    # Phase 4.1: Removed the [:12] cap that silently dropped 94% of the universe.
    # Previously: _drip = missing[:12] fetched sectors for only the FIRST 12 missing
    # tickers, and the rest were cached as "N/A" forever (line 1467-1468). On a
    # 200-ticker universe, 188+ tickers got "N/A" sector → SEBI sector caps and
    # sector-momentum filters became no-ops for 94% of the universe.
    # Now: page through ALL missing tickers with rate-limit pacing.
    _drip = missing  # fetch all missing tickers, not just the first 12
    _sec_fetch_count = 0
    _sec_fail_count = 0
    for _t in _drip:
        _sec_val = None  # AUDIT-FIX: start as None — only commit if resolved
        # Primary: NSE sector API (no throttle risk, no UI freeze)
        try:
            sym = _t.replace(".NS", "").replace(".BO", "").upper()
            _nse_sec_resp = NSEClient.get(
                f"https://www.nseindia.com/api/quote-equity?symbol={sym}",
                headers={"Accept": "application/json",
                         "Referer": f"https://www.nseindia.com/get-quotes/equity?symbol={sym}"},
                timeout=6
            )
            if _nse_sec_resp.status_code == 200:
                _nse_info = _nse_sec_resp.json()
                _sec_val = (
                    _nse_info.get("industryInfo", {}).get("macro")
                    or _nse_info.get("industryInfo", {}).get("sector")
                    or None
                )
        except Exception:
            import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
            pass

        # Fallback: yfinance (only if NSE failed and not on main thread)
        # AUDIT-FIX Round 7 P2-4: yfinance lazy-loaded via _get_yf()
        _yf_lazy = _get_yf() if (_sec_val is None and not _is_sec_main) else None
        if _sec_val is None and _yf_lazy is not None and not _is_sec_main:
            try:
                import time as _time
                _info = _yf_lazy.Ticker(_t).info
                _sec_val = (_info.get("sector") or _info.get("sectorDisp") or
                            _info.get("industry") or _info.get("industryDisp") or None)
                _time.sleep(NSE_SESSION_SLEEP)
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                pass

        # AUDIT-FIX (defect #P0-7): only commit resolved sectors to the
        # persistent cache. Failed lookups remain absent so the next run
        # retries them; the in-memory `sectors` dict still gets "N/A" so
        # downstream consumers see the sentinel, but it is no longer
        # permanently cached.
        if _sec_val is not None:
            sectors[_t] = _sec_val
            sector_cache[_t] = _sec_val
        else:
            sectors[_t] = "N/A"
            _sec_fail_count += 1
        _sec_fetch_count += 1
        # Rate-limit pacing: sleep every 20 tickers to avoid NSE throttling
        if _sec_fetch_count % 20 == 0 and _is_sec_main is False:
            import time as _time
            _time.sleep(0.5)
    for ticker in [t for t in missing if t not in sectors]:
        sectors[ticker] = "N/A"
    # AUDIT-FIX (defect #P0-7): write only the resolved entries — never persist "N/A".
    if _drip: write_json_cache(SECTOR_CACHE_PATH, sector_cache)
    progress_span(progress_cb, 25, 35, total, total)

    resolved = sum(1 for v in sectors.values() if v != "N/A")
    cache_msg = f" ({len(tickers) - len(missing)} cached)" if len(tickers) - len(missing) > 0 else ""
    if missing and _sec_fail_count > 0:
        _fail_pct = (_sec_fail_count / max(len(missing), 1)) * 100.0
        log_emit(log_cb, f"Sector metadata fetched: {len(sectors)} tickers, {resolved} resolved{cache_msg}. "
                         f"{_sec_fail_count} tickers failed lookup ({_fail_pct:.1f}% of missing) — NOT cached, will be retried next run. "
                         "Unresolved tickers will be bucketed into the 'UNKNOWN' pseudo-sector and capped at MAX_PER_SECTOR by the SEBI guardrail.")
    else:
        log_emit(log_cb, f"Sector metadata fetched: {len(sectors)} tickers, {resolved} resolved{cache_msg}")
    return sectors




# ────────────────────────────────────────────────────────────────────
# FUNC: fetch_benchmark_returns
# ────────────────────────────────────────────────────────────────────
def fetch_benchmark_returns(cfg, index_like, log_cb=None, progress_cb=None):
    log_emit(log_cb, "Stage 3/6 | Benchmark data")
    preferred = cfg.get("BENCHMARK_SYMBOL", "^NSEI")
    candidates = [preferred] + [x for x in BENCHMARK_FALLBACKS if x != preferred]

    for idx, symbol in enumerate(candidates, start=1):
        check_stop()
        try:
            raw = safe_download([symbol], cfg["LOOKBACK_DOWNLOAD"], auto_adjust=True, log_cb=log_cb)
            close = extract_field_panel(raw, "Close", [symbol])
            if close.empty or symbol not in close.columns:
                continue
            bench = np.log(close[symbol] / close[symbol].shift(1)).dropna()
            bench = bench.reindex(index_like).dropna()
            if len(bench) >= 60:
                progress_span(progress_cb, 35, 42, idx, len(candidates))
                log_emit(log_cb, f"Benchmark loaded: {symbol} ({len(bench)} daily returns)")
                global _LAST_BENCHMARK_PRICE
                try:
                    _LAST_BENCHMARK_PRICE = float(close[symbol].dropna().iloc[-1])
                except Exception:
                    _LAST_BENCHMARK_PRICE = None
                return symbol, bench
        except Exception as _eloop: archlog.debug("loop skip: %s", _eloop, exc_info=True); continue

    progress_span(progress_cb, 35, 42, len(candidates), len(candidates))
    log_emit(log_cb, "Benchmark unavailable. Beta-aware diagnostics will be reduced.")
    return None, None


_LAST_BENCHMARK_PRICE = None

def get_benchmark_last_price() -> float | None:
    """Returns the most recent spot/close price of the loaded benchmark index."""
    return _LAST_BENCHMARK_PRICE




# ────────────────────────────────────────────────────────────────────
# FUNC: fetch_price_series
# ────────────────────────────────────────────────────────────────────
def fetch_price_series(symbol, start_idx, end_idx):
    try:
        raw = safe_download([symbol], "2y", auto_adjust=True)

        close = extract_field_panel(raw, "Close", [symbol])
        if close.empty or symbol not in close.columns:
            return None
        series = close[symbol].dropna()
        if hasattr(start_idx, "date") and hasattr(end_idx, "date"):
            series = series.loc[(series.index >= start_idx) & (series.index <= end_idx)]
        return series.tail(220)
    except Exception as _e:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception in %s", "Exception", exc_info=True)  # noqa: E501
        return None




# ────────────────────────────────────────────────────────────────────
# FUNC: fetch_ohlcv — Round 11 attribution-harness entry point
# ────────────────────────────────────────────────────────────────────
def fetch_ohlcv(
    tickers: List[str],
    period: str = "3y",
    interval: str = "1d",
    auto_adjust: bool = True,
    return_returns: bool = True,
    log_cb: Callable = None,
) -> pd.DataFrame:
    """Fetch daily OHLCV (or close-to-close returns) for a list of NSE
    tickers via the project's standard data layer.

    Round 11 added this public entry point so the Sharpe lift waterfall
    attribution harness (`scripts/sharpe_lift_waterfall.py`) can pull
    REAL NSE returns via a documented contract instead of relying on
    `_generate_synthetic_returns`. The per-module Sharpe ranking
    produced against real NSE returns is the production-ready
    attribution table; synthetic returns are only a development
    fallback for offline / air-gapped runs.

    Args:
        tickers: list of NSE ticker symbols. Suffixes are normalized
            ('.NS' appended if missing). Examples: ['RELIANCE.NS',
            'HDFCBANK.NS'] or ['RELIANCE', 'HDFCBANK'].
        period: yfinance-style period string ('1y', '2y', '3y', '5y',
            'max'). Default '3y' gives ~750 trading days — the same
            length the synthetic generator produced.
        interval: '1d' (default) | '1wk' | '1mo'.
        auto_adjust: forward to safe_download (default True).
        return_returns: if True (default), return close-to-close
            simple returns (Decimal). If False, return raw Close prices.
        log_cb: optional structured log callback.

    Returns:
        pd.DataFrame with one column per ticker. Index = DatetimeIndex
        of trading days. Values = simple returns (or Close prices if
        return_returns=False). Empty DataFrame on total failure.

    Fail-open: returns an empty DataFrame on ANY data-layer error
    (yfinance missing, network failure, all tickers invalid, etc.).
    Callers must check `.empty` and fall back to synthetic data.
    """
    if not tickers:
        return pd.DataFrame()
    # Normalize suffixes
    norm = []
    for t in tickers:
        if not t:
            continue
        s = t.upper()
        if not s.endswith(".NS") and not s.endswith(".BO"):
            s = s + ".NS"
        norm.append(s)
    if not norm:
        return pd.DataFrame()
    try:
        raw = safe_download(norm, period=period, auto_adjust=auto_adjust,
                            interval=interval)
    except Exception as _e:
        import logging as _swallow_log_mod
        _swallow_log_mod.getLogger("quantum_annealer").debug(
            "[AUDIT-FIX P2-5] swallowed exception in fetch_ohlcv",
            exc_info=True,
        )
        return pd.DataFrame()
    if raw is None or getattr(raw, "empty", True):
        return pd.DataFrame()

    # Resolve the Close field (handles both flat + MultiIndex columns)
    try:
        if isinstance(raw.columns, pd.MultiIndex):
            close = raw["Close"].copy()
        else:
            close = raw["Close"].copy() if "Close" in raw.columns else raw.copy()
    except Exception:
        return pd.DataFrame()
    if close is None or close.empty:
        return pd.DataFrame()
    close = close.select_dtypes(include="number").dropna(how="all")

    if not return_returns:
        return close
    # Compute simple returns (close-to-close). pct_change returns NaN
    # at position 0 — drop it so the harness receives clean returns.
    rets = close.pct_change().dropna(how="all")
    if rets.empty:
        return pd.DataFrame()
    return rets




# ────────────────────────────────────────────────────────────────────
# FUNC: _try_inline_hmm_retrain  (R34-1)
# ────────────────────────────────────────────────────────────────────
_REGIME_RETRAIN_LOCK = None  # lazily created; data_layer must import without threading

def _try_inline_hmm_retrain(hmm_path, benchmark_returns, age_hours: float) -> bool:
    """R34-1: self-heal a stale regime HMM by retraining it inline.

    Retrains a fresh RS-GARCH HMM on the benchmark returns ALREADY in hand
    (no extra network fetch), saves it to ``hmm_path`` (which refreshes the
    metadata timestamp so future runs start fresh), and returns True.

    Thread-safety: a module-level lock + age re-check means concurrent
    profile workers in a sweep will not each burn ~90s retraining — the
    first worker refreshes the file, the rest see a fresh timestamp and
    skip their own fit.

    Returns False when the retrain is impossible or fails (caller falls
    back to the hard Defensive (Stale Model) state with a Reason code).
    """
    global _REGIME_RETRAIN_LOCK
    import logging
    import threading
    if _REGIME_RETRAIN_LOCK is None:
        _REGIME_RETRAIN_LOCK = threading.Lock()
    try:
        # Normalise the returns input to a 1-D float series.
        _bench = benchmark_returns
        if isinstance(_bench, pd.DataFrame):
            _bench = _bench.squeeze("columns") if hasattr(_bench, "squeeze") else _bench.iloc[:, 0]
        _hmm_df = pd.DataFrame({"return": pd.Series(_bench).astype(float)})
        if len(_hmm_df) < 60:
            logging.getLogger(__name__).warning(
                f"[Regime] R34-1 inline retrain skipped: only {len(_hmm_df)} benchmark "
                f"returns in hand (need >= 60 for a stable refit).")
            return False

        with _REGIME_RETRAIN_LOCK:
            # Double-checked locking: another worker may have refreshed the
            # artifact while we were waiting on the lock.
            try:
                import json as _json
                from datetime import datetime as _dt, timezone as _tz
                with open(hmm_path, "r") as f:
                    _ts = _json.load(f).get("metadata", {}).get("timestamp_utc")
                if _ts:
                    _age = (_dt.now(_tz.utc) - _dt.fromisoformat(_ts.replace("Z", "+00:00"))).total_seconds() / 3600.0
                    if _age <= 48.0:
                        logging.getLogger(__name__).info(
                            "[Regime] R34-1: HMM artifact was refreshed by a concurrent worker "
                            f"(now {_age:.1f}h old) — skipping duplicate retrain.")
                        return True
            except Exception:
                pass

            from math_engine.regime_detector import MarketRegimeDetector
            import time as _time
            _t0 = _time.time()
            _det = MarketRegimeDetector(n_iter=500, tol=1e-4, random_state=42)
            _det.fit(_hmm_df)
            _det.save_json(hmm_path)
            logging.getLogger(__name__).warning(
                f"[Regime] R34-1 self-heal: HMM model was {age_hours:.1f}h stale — retrained "
                f"inline on {len(_hmm_df)} in-hand benchmark returns in {_time.time() - _t0:.0f}s "
                f"and saved → {hmm_path}")
            return True
    except Exception as _e:
        logging.getLogger(__name__).warning(
            f"[Regime] R34-1 inline HMM retrain failed: {_e}", exc_info=True)
        return False


# ────────────────────────────────────────────────────────────────────
# FUNC: detect_market_regime
# ────────────────────────────────────────────────────────────────────
def detect_market_regime(close_df, benchmark_returns=None, is_backtest=False):
    """
    v17.3: HMM JSON Regime Detection with Heuristic Fallback.
    """
    import os
    import json
    from pathlib import Path
    from datetime import datetime, timezone
    
    _empty = {"Regime": "Unknown", "Breadth": float("nan"), "Dispersion": float("nan"),
              "BenchmarkTrend": float("nan"), "XSCorr": float("nan"), "BenchSharpe": float("nan")}
    
    # BUG-DL3 FIX: relative path "models/regime_hmm_latest.json" resolves from
    # whatever the CWD is at runtime — fails silently in K8s, when launched from
    # a different directory, or from tests. Use an absolute path anchored to
    # this file's location so it works regardless of how the app is launched.
    _proj_root = Path(__file__).resolve().parent
    hmm_path = _proj_root / "models" / "regime_hmm_latest.json"
    # Fallback: check RUNTIME_DIR as secondary location (used by nightly trainer)
    if not hmm_path.exists():
        _rt_path = RUNTIME_DIR / "models" / "regime_hmm_latest.json"
        if _rt_path.exists():
            hmm_path = _rt_path
    if hmm_path.exists() and benchmark_returns is not None and not benchmark_returns.empty:
        try:
            with open(hmm_path, "r") as f:
                payload = json.load(f)
            
            ts_str = payload.get("metadata", {}).get("timestamp_utc")
            if ts_str:
                ts = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
                age_hours = (datetime.now(timezone.utc) - ts).total_seconds() / 3600.0
                
                if age_hours > 48.0 and not is_backtest:
                    # R34-1 FIX (2026-09-14 incident): a stale HMM model used to
                    # hard-return "Defensive (Stale Model)", which the optimizer's
                    # Staleness-Flatten turns into an empty target portfolio and the
                    # DataQualityGate then aborts as a "degenerate run" — i.e. every
                    # run failed whenever the model went >48h stale (web dashboard
                    # never refreshes it). Self-heal FIRST: retrain the RS-GARCH HMM
                    # inline on the benchmark returns already in hand (no extra
                    # network fetch), save it so subsequent runs start fresh, and
                    # fall through to predict with the fresh model. Only if the
                    # retrain fails (or the data is too thin) do we return the hard
                    # defensive state — now carrying an explicit "Reason" code the
                    # downstream halt message can act on.
                    _healed = _try_inline_hmm_retrain(hmm_path, benchmark_returns, age_hours)
                    if not _healed:
                        import logging
                        logging.getLogger(__name__).warning(
                            f"[Regime] HMM model is {age_hours:.1f}h old (>48h hard ceiling) and inline "
                            f"retrain failed — Forcing Defensive state (Reason=hmm_stale_retrain_failed).")
                        return {
                            "Regime": "Defensive (Stale Model)",
                            "Reason": "hmm_stale_retrain_failed",
                            "P_Bull": 0.0, "P_Bear": 1.0, "P_Sideways": 0.0,
                            "RegimeBlend": -1.0,
                            "Breadth": float("nan"), "Dispersion": float("nan"),
                            "BenchmarkTrend": float("nan"), "XSCorr": float("nan"), "BenchSharpe": float("nan")
                        }
                    # Fall through: reload + predict with the now-fresh model below.
            
            from math_engine.regime_detector import MarketRegimeDetector
            hmm = MarketRegimeDetector.load_json(hmm_path)
            
            # Predict regime using benchmark returns
            hmm_df = pd.DataFrame({"return": benchmark_returns})
            pred = hmm.predict_regime(hmm_df, last_n_days=min(252, len(hmm_df)), use_macro_overlay=True)
            
            # KL divergence structural break threshold
            kl = pred.get("kl_divergence", 0.0)
            if kl > 0.75 and not is_backtest:
                import logging
                logging.getLogger(__name__).warning(f"[Regime] Structural break detected via KL divergence (KL={kl:.4f} > 0.75). Forcing Defensive state.")
                return {
                    "Regime": "Defensive (Stale Model)",
                    "Reason": "structural_break_kl",
                    "P_Bull": 0.0, "P_Bear": 1.0, "P_Sideways": 0.0,
                    "RegimeBlend": -1.0,
                    "Breadth": float("nan"), "Dispersion": float("nan"),
                    "BenchmarkTrend": float("nan"), "XSCorr": float("nan"), "BenchSharpe": float("nan")
                }
            
            p_bull = pred["probabilities"].get("Bull", 0.0)
            p_bear = pred["probabilities"].get("Bear", 0.0)
            p_sideways = pred["probabilities"].get("Sideways", 0.0)
            regime_blend = p_bull - p_bear
            
            return {
                "Regime": pred["label"],
                "P_Bull": p_bull, "P_Bear": p_bear, "P_Sideways": p_sideways,
                "RegimeBlend": regime_blend,
                "Breadth": float("nan"), "Dispersion": float("nan"),
                "BenchmarkTrend": float("nan"), "XSCorr": float("nan"), "BenchSharpe": float("nan")
            }
        except Exception as e:
            import logging
            logging.getLogger(__name__).warning(f"[Regime] HMM JSON load failed: {e}. Falling back to heuristics.")

    if close_df is None or close_df.empty:
        return _empty

    rets = np.log(close_df / close_df.shift(1)).dropna(how="all")
    if rets.empty:
        return _empty

    # 1. Breadth
    # Bug 35 fix: median is robust to spike days; clip ±15% before breadth.
    _rc35 = rets.clip(-0.15, 0.15)
    latest_breadth = float((_rc35.tail(20).median() > 0).mean()) if len(rets) >= 20 else float("nan")
    # 2. Dispersion
    latest_dispersion = float(rets.tail(20).std().mean() * np.sqrt(TRADING_DAYS_PER_YEAR)) if len(rets) >= 20 else float("nan")
    # 3. Benchmark 3M trend
    benchmark_trend = float("nan")
    if benchmark_returns is not None and len(benchmark_returns) >= 63:
        benchmark_trend = float((1.0 + benchmark_returns.tail(63)).prod() - 1.0)
    # 4. Cross-sectional correlation — high = crisis / risk-off
    xs_corr = float("nan")
    if len(rets) >= 20 and rets.shape[1] >= 4:
        try:
            _s = rets.tail(20).dropna(axis=1, how="any")
            if _s.shape[1] >= 4:
                _c = _s.corr().values
                _mask = np.triu(np.ones(_c.shape, dtype=bool), k=1)
                xs_corr = float(_c[_mask].mean())
        except Exception as _e:  # safe: yfinance field extraction — missing field returns empty df
            import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception in %s", "Exception", exc_info=True)  # noqa: E501
            pass  # intentional — see comment above
    # 5. Benchmark rolling Sharpe (63-day, annualised)
    bench_sharpe = float("nan")
    if benchmark_returns is not None and len(benchmark_returns) >= 63:
        _br = benchmark_returns.tail(63)
        _std = float(_br.std())
        if _std > 1e-9:
            bench_sharpe = float(_br.mean() / _std * np.sqrt(TRADING_DAYS_PER_YEAR))  # DIV001: guard divisor before use

    # ── v17.24: Soft signal scores — each signal → continuous [-1,+1] via tanh ──
    signal_scores = []
    if pd.notna(benchmark_trend):
        signal_scores.append(float(np.tanh(benchmark_trend / 0.05)))
    if pd.notna(latest_breadth):
        signal_scores.append(float(np.tanh((latest_breadth - 0.50) / 0.12)))
    if pd.notna(xs_corr):
        signal_scores.append(float(-np.tanh((xs_corr - 0.40) / 0.15)))
    if pd.notna(bench_sharpe):
        signal_scores.append(float(np.tanh(bench_sharpe / 1.5)))

    # 5b. Dispersion signal: cross-sectional vol dispersion > 0.25 (annualised)
    # indicates high factor efficacy / stock-picking conditions → mild bull signal
    if pd.notna(latest_dispersion):
        signal_scores.append(float(np.tanh((latest_dispersion - 0.25) / 0.10)))

    if not signal_scores:
        return {"Regime": "Unknown", "Breadth": latest_breadth, "Dispersion": latest_dispersion,
                "BenchmarkTrend": benchmark_trend, "XSCorr": xs_corr, "BenchSharpe": bench_sharpe,
                "P_Bull": float("nan"), "P_Bear": float("nan"), "P_Sideways": float("nan"),
                "RegimeBlend": 0.0}

    regime_blend = (float(np.mean(signal_scores)) if len(signal_scores) > 0 else 0.0)   # in [-1, +1]

    # Softmax over Bull (+1) / Sideways (0) / Bear (-1)
    # FIX: Lowered temperature from 0.5 → 0.25 so the softmax produces meaningful
    # probability distributions (e.g., 70/20/10%) rather than near-deterministic
    # outputs (99/0.5/0.5%) that defeat the purpose of quantifying regime uncertainty.
    temperature = 0.25
    centers     = np.array([+1.0, 0.0, -1.0])
    logits      = -(regime_blend - centers) ** 2 / (temperature if temperature != 0 else 1e-9)  # DIV001 guarded  # DIV001: guard divisor before use
    exp_l       = np.exp(logits - logits.max())
    probs       = exp_l / exp_l.sum()
    p_bull, p_sideways, p_bear = float(probs[0]), float(probs[1]), float(probs[2])

    if   regime_blend >=  0.60: regime = "Risk-On Trend"
    elif regime_blend >=  0.20: regime = "Broad Strength"
    elif regime_blend <= -0.60: regime = "Risk-Off Stress"
    elif regime_blend <= -0.20: regime = "Defensive"
    else:                       regime = "Transitional"

    return {"Regime": regime, "Breadth": latest_breadth, "Dispersion": latest_dispersion,
            "BenchmarkTrend": benchmark_trend, "XSCorr": xs_corr, "BenchSharpe": bench_sharpe,
            "P_Bull": p_bull, "P_Bear": p_bear, "P_Sideways": p_sideways,
            "RegimeBlend": regime_blend}



# ────────────────────────────────────────────────────────────────────
# FUNC: apply_vix_position_sizing
# ────────────────────────────────────────────────────────────────────
def apply_vix_position_sizing(weights: dict, vix_val: float, cfg: dict, log_cb=None) -> dict:
    """
    Scale down total equity exposure into cash if India VIX is in panic territory.
    """
    import math
    if not weights or vix_val != vix_val or vix_val is None:
        return weights
        
    vix_thresh = float(cfg.get("VIX_HIGH_THRESHOLD", 20.0))  # matches DEFAULT_CFG
    if vix_val < vix_thresh:
        return weights
        
    # 3-tier VIX regime: linear scaling within each band is too crude.
    # Tier 1 [thresh, 25): mild fear  → 10% cash buffer
    # Tier 2 [25, 30):      elevated  → 25% cash buffer
    # Tier 3 [30, ∞):       extreme   → 40-50% cash buffer (capped)
    if   vix_val >= 30: penalty_pct = min(0.50, 0.40 + (vix_val - 30) * 0.010)
    elif vix_val >= 25: penalty_pct = 0.25 + (vix_val - 25) * 0.030
    else:               penalty_pct = (vix_val - vix_thresh) * 0.020
    penalty_pct     = min(0.50, max(0.0, penalty_pct))
    target_exposure = 1.0 - penalty_pct
    scaled = {}
    freed_exposure = 0.0
    for k, v in weights.items():
        if k == "CASH":
            scaled[k] = v
        else:
            scaled[k] = v * target_exposure
            freed_exposure += v * (1.0 - target_exposure)
    scaled["CASH"] = scaled.get("CASH", 0.0) + freed_exposure
    log_emit(log_cb, f"[VIX Sizing] VIX={vix_val:.1f} → equity exposure scaled by {target_exposure*100:.0f}% / "
             f"cash buffer={scaled['CASH']*100:.1f}% (sum={sum(scaled.values()):.4f})")
    return scaled



# ────────────────────────────────────────────────────────────────────
# FUNC: build_sector_summary
# ────────────────────────────────────────────────────────────────────
def build_sector_summary(portfolio_df):
    if portfolio_df is None or portfolio_df.empty:
        return pd.DataFrame()

    sector_df = portfolio_df.copy()
    tickers_series = sector_df.groupby("Sector", dropna=False)["Ticker"].apply(lambda x: ", ".join(str(i) for i in x))
    grouped = sector_df.groupby("Sector", dropna=False).agg(
        Holdings=("Ticker", "count"),
        Weight=("Weight %", "sum"),  # already decimal — sum gives sector total fraction
        AvgAlpha=("AlphaScore", "mean"),
        AvgRisk=("RiskScore", "mean"),
        AvgBeta=("Beta", "mean"),
        AvgSectorRS6M=("SectorRS6M", "mean"),
    )
    grouped["Tickers"] = tickers_series
    grouped = grouped.reset_index().sort_values(["Weight", "Holdings"], ascending=[False, False]).reset_index(drop=True)
    return grouped




# ────────────────────────────────────────────────────────────────────
# FUNC: build_sector_relative_summary
# ────────────────────────────────────────────────────────────────────
def build_sector_relative_summary(portfolio_df):
    if portfolio_df is None or portfolio_df.empty or "SectorRS6M" not in portfolio_df.columns:
        return pd.DataFrame()

    grouped = portfolio_df.groupby("Sector", dropna=False).agg(
        Holdings=("Ticker", "count"),
        Weight=("Weight %", "sum"),  # already decimal
        AvgSectorRS6M=("SectorRS6M", "mean"),
        AvgSectorRS1M=("SectorRS1M", "mean"),
        BestTicker=("Ticker", "first"),
    ).reset_index()
    grouped = grouped.sort_values(["AvgSectorRS6M", "Weight"], ascending=[False, False]).reset_index(drop=True)
    return grouped




# ────────────────────────────────────────────────────────────────────
# FUNC: fetch_sast_velocity
# ────────────────────────────────────────────────────────────────────
def fetch_sast_velocity(tickers: list, log_cb=None) -> dict:
    """S1: SAST promoter filing VELOCITY — filings per 30d, not just presence.
    Rate of acquisition filings is more predictive than binary flag.
    Uses Prohibition of Insider Trading (PIT) Regulation 7(2) filings."""
    from datetime import datetime, timedelta
    today_str = datetime.now().strftime("%Y-%m-%d")
    cache = read_json_cache(SAST_VELOCITY_CACHE_PATH, {})
    if cache.get("date") == today_str and "data" in cache and isinstance(cache["data"], dict):
        return cache["data"]
    result = {}
    try:
        try:
            NSEClient.get("https://www.nseindia.com", timeout=10)
        except Exception:
            import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
            pass
        from_dt = (datetime.now() - timedelta(days=30)).strftime("%d-%m-%Y")
        to_dt = datetime.now().strftime("%d-%m-%Y")
        headers = {
            "Accept": "application/json, text/plain, */*",
            "Referer": "https://www.nseindia.com/companies-listing/corporate-filings-insider-trading"
        }
        
        def _parse_resp_data(resp_obj):
            if not resp_obj or resp_obj.status_code != 200:
                return []
            raw = resp_obj.content
            if raw and raw.startswith(b'\x1f\x8b'):
                import gzip
                try:
                    raw = gzip.decompress(raw)
                except Exception as gzip_ex:
                    log_emit(log_cb, f"[SAST] Gzip decompression failed: {gzip_ex}", exc_info=True)
            resp_text = raw.decode("utf-8", errors="ignore").strip() if raw else ""
            if resp_text and (resp_text.startswith("[") or resp_text.startswith("{")):
                import json
                try:
                    parsed = json.loads(resp_text)
                    return parsed.get("data", []) if isinstance(parsed, dict) else parsed
                except Exception as json_ex:
                    log_emit(log_cb, f"[SAST] JSON parse error: {json_ex}", exc_info=True)
            return []

        # Session warmup: NSE API requires a valid session cookie from the homepage.
        # Without this, the PIT endpoint returns an empty 200 body (Expecting value error).
        _warmup_urls = [
            "https://www.nseindia.com",
            "https://www.nseindia.com/companies-listing/corporate-filings-insider-trading",
        ]
        for _wu in _warmup_urls:
            try:
                NSEClient.get(_wu, headers={"Accept": "text/html,*/*"}, timeout=8)
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                pass

        url = f"https://www.nseindia.com/api/corporates-pit?index=equities&from_date={from_dt}&to_date={to_dt}"
        resp = NSEClient.get(url, headers=headers, timeout=20)
        recs = _parse_resp_data(resp)
        if not recs:
            # AUDIT-FIX (defect #7): the prior fallback hardcoded from_date=01-01-2026,
            # silently widening the insider-data window whenever the 30-day query
            # returned empty (e.g., session cookie expiry, Akamai throttling, or a
            # genuinely quiet 30-day period). That fallback could pull filings from
            # 8 months earlier and present them as recent SAST velocity. The new
            # behavior is to extend the window by at most one extra 30-day period
            # (i.e., up to 60 days) and log a warning so the operator can see that
            # the SAST velocity metric is now broader than the configured window.
            _ext_from_dt = (datetime.now() - timedelta(days=60)).strftime("%d-%m-%Y")
            fallback_url = f"https://www.nseindia.com/api/corporates-pit?index=equities&from_date={_ext_from_dt}&to_date={to_dt}"
            log_emit(log_cb, f"[SAST] 30-day PIT query empty; extending to 60-day fallback (from_date={_ext_from_dt}).")
            try:
                resp = NSEClient.get(fallback_url, headers=headers, timeout=20)
                recs = _parse_resp_data(resp)
            except Exception as _fe:
                log_emit(log_cb, f"[SAST] 60-day fallback also empty: {_fe}", exc_info=True)
        
        if not recs:
            try:
                RAW_HISTORY_PATH = RUNTIME_DIR / "bulk_deals_raw_history.json"
                raw_history = read_json_cache(RAW_HISTORY_PATH, {})
                if raw_history:
                    log_emit(log_cb, "[SAST] PIT API empty — scoring from local bulk_deals_raw_history.json")
                    ticker_set = set(t.replace(".NS", "").replace(".BO", "").upper() for t in tickers)
                    all_deals = [deal for deals in raw_history.values() for deal in deals]
                    df = pd.DataFrame(all_deals)
                    if not df.empty and "SYMBOL" in df.columns:
                        if "BUY_SELL" in df.columns:
                            df = df[df["BUY_SELL"].astype(str).str.upper().str.contains(r"^B$|^BUY$|BUY|PURCHASE", na=False)]
                        counts = df["SYMBOL"].astype(str).str.strip().str.upper().value_counts()
                        for sym, cnt in counts.items():
                            if sym in ticker_set:
                                result[f"{sym}.NS"] = int(cnt)
            except Exception as _bulk_e:
                log_emit(log_cb, f"[SAST] Local raw history fallback failed: {_bulk_e}", exc_info=True)

        if recs:
            df = pd.DataFrame(recs)
            df.columns = [c.strip().upper().replace(" ", "_") for c in df.columns]
            tt_col = "TDPAQUISITIONTYPE" if "TDPAQUISITIONTYPE" in df.columns else "TDPTRANSACTIONTYPE"
            cat_col = "PERSONCATEGORY"
            sym_col = "SYMBOL"
            if sym_col in df.columns:
                if tt_col in df.columns:
                    df = df[df[tt_col].astype(str).str.upper().str.contains("BUY", na=False)]
                if cat_col in df.columns:
                    df = df[df[cat_col].astype(str).str.upper().str.contains("PROMOTER|DIRECTOR", na=False)]
                ticker_set = set(t.replace(".NS", "").replace(".BO", "").upper() for t in tickers)
                counts = df[sym_col].astype(str).str.strip().str.upper().value_counts()
                for sym, cnt in counts.items():
                    if sym in ticker_set:
                        result[f"{sym}.NS"] = int(cnt)
        write_json_cache(SAST_VELOCITY_CACHE_PATH, {"date": today_str, "data": result})
        log_emit(log_cb, f"[SAST-Vel] {len(result)} tickers with promoter filing velocity")
    except Exception as e:
        log_emit(log_cb, f"[SAST-Vel] fetch failed (non-fatal): {e}", exc_info=True)
    return result




# ────────────────────────────────────────────────────────────────────
# FUNC: fetch_pledge_reduction
# ────────────────────────────────────────────────────────────────────
def fetch_pledge_reduction(tickers: list, log_cb=None) -> dict:
    """
    S2: Promoter pledge REDUCTION from NSE shareholding pattern API.
    Pledge falling = promoter confidence rising = quality signal.

    Data source: NSE corporate shareholding patterns endpoint (no yfinance).
    Returns {ticker: pledge_reduction_score_0_to_1} cached daily.
    Score 1.0 = zero pledge (maximum quality).
    Score 0.0 = pledge unchanged or increased.
    """
    today_str = datetime.now().strftime("%Y-%m-%d")
    cache = read_json_cache(PLEDGE_CACHE_PATH, {})
    if cache.get("date") == today_str and "data" in cache and isinstance(cache["data"], dict):
        log_emit(log_cb, f"[Pledge] Cache hit: {len(cache['data'])} tickers")
        return cache["data"]

    result = {}

    # NSE session warmup — required before any NSE API call
    try:
        NSEClient.get("https://www.nseindia.com", timeout=8)
        NSEClient.get(
            "https://www.nseindia.com/companies-listing/corporate-filings-shareholding-patterns",
            headers={"Accept": "text/html,*/*", "Accept-Encoding": "identity"},
            timeout=8
        )
    except Exception:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
        pass

    _headers = {
        "Accept": "application/json, text/plain, */*",
        "Referer": (
            "https://www.nseindia.com/companies-listing/"
            "corporate-filings-shareholding-patterns"
        )
    }

    def _fetch_pledge_for_ticker(ticker: str) -> tuple:
        sym = ticker.replace(".NS", "").replace(".BO", "").upper()
        key = f"{sym}.NS"
        try:
            url = (
                f"https://www.nseindia.com/api/corporate-shareholding"
                f"-patterns?symbol={sym}&dataType=Pledge"
            )
            resp = NSEClient.get(url, headers=_headers, timeout=15)
            if resp.status_code != 200:
                return key, 0.0

            data = resp.json()
            records = (
                data.get("data", [])
                if isinstance(data, dict)
                else (data if isinstance(data, list) else [])
            )
            if not records or len(records) < 1:
                # No pledge records = zero pledged = maximum quality
                return key, 1.0

            df_p = pd.DataFrame(records)
            df_p.columns = [c.strip().upper() for c in df_p.columns]

            pledge_col = next(
                (c for c in df_p.columns if "PLEDGE" in c and "PCT" in c), None
            ) or next(
                (c for c in df_p.columns if "PLEDG" in c), None
            )
            date_col = next(
                (c for c in df_p.columns
                 if "DATE" in c or "QUARTER" in c or "RECORD" in c or "PERIOD" in c),
                None
            )

            if not pledge_col:
                return key, 0.0

            df_p[pledge_col] = pd.to_numeric(df_p[pledge_col], errors="coerce").fillna(0.0)
            if date_col:
                df_p[date_col] = pd.to_datetime(df_p[date_col], errors="coerce")
                df_p = df_p.sort_values(date_col, ascending=False)

            pledge_now  = float(df_p[pledge_col].iloc[0])
            compare_idx = min(2, len(df_p) - 1)
            pledge_prev = float(df_p[pledge_col].iloc[compare_idx])

            if pledge_now == 0.0:
                score = 1.0
            elif pledge_prev <= 0.0:
                score = 0.0
            else:
                score = float(max(pledge_prev - pledge_now, 0.0) / pledge_prev)

            return key, round(score, 4)

        except Exception as _e:
            ExceptionLogger.swallow(_e, context="fetch_pledge_reduction_ticker")
            return key, 0.0

    ticker_list = list(tickers)
    # BUG FIX: 6 workers against up to 500 tickers, each a separate NSE API
    # call, cannot possibly finish within a flat 90s window (500/6 ≈ 84
    # sequential rounds per worker even with zero slow requests). That
    # guaranteed timeout was silently defaulting hundreds of tickers to 0.0
    # every run (log showed "323 of 500 futures unfinished", nonzero=0).
    # Scale both the worker count and the timeout budget with the actual
    # number of tickers instead of using fixed constants sized for a much
    # smaller universe.
    _n_workers = min(16, max(6, len(ticker_list) // 15))
    _timeout_s = max(60, int(len(ticker_list) / _n_workers) * 2 + 15)
    try:
        with _DaemonThreadPoolExecutor(max_workers=_n_workers) as _pool:
            futures = {_pool.submit(_fetch_pledge_for_ticker, t): t for t in ticker_list}
            for future in as_completed(futures, timeout=_timeout_s):
                with _ACTIVE_STOP_EVENT_LOCK:
                    if _ACTIVE_STOP_EVENT is not None and _ACTIVE_STOP_EVENT.is_set():
                        break
                try:
                    key, score = future.result()
                    result[key] = score
                except Exception as _fe:
                    ExceptionLogger.swallow(_fe, context="fetch_pledge_future")
    except Exception as e:
        log_emit(log_cb, f"[Pledge] Parallel fetch notice: {e}", exc_info=True)
    
    # Ensure every requested ticker has an entry in result dictionary
    for t in ticker_list:
        key = f"{t.replace('.NS', '').replace('.BO', '').upper()}.NS"
        if key not in result:
            result[key] = 0.0

    # Always write cache for today so all profiles in sweep share results
    write_json_cache(PLEDGE_CACHE_PATH, {"date": today_str, "data": result})
    nonzero = sum(1 for v in result.values() if v > 0)
    log_emit(log_cb, f"[Pledge] {len(result)} tickers scored (NSE) | nonzero={nonzero}")
    return result




# ─────────────────────────────────────────────────────────────────────
# FUNC: fetch_nse_bulk_deal_footprint
# ─────────────────────────────────────────────────────────────────────

# Keywords that identify institutional buyers vs retail
_INSTITUTIONAL_BUYER_KEYWORDS = [
    "MF", "FUND", "INSURANCE", "FII", "TRUST",
    "MUTUAL", "ASSET", "MGMT", "MANAGEMENT",
    "CAPITAL", "INVESTMENTS LTD", "PMS", "AMC",
    "SMALLCAP", "MIDCAP", "MULTI CAP", "FLEXI",
    "HDFC ASSET", "SBI FUND", "NIPPON", "ICICI PRU",
    "KOTAK MF", "AXIS MF", "DSP", "MIRAE"
]

def _normalize_nse_ticker(ticker: str) -> str:
    sym = str(ticker or "").strip().upper().replace(".NS", "").replace(".BO", "")
    return f"{sym}.NS" if sym else ""

def _normalize_nse_ticker_set(tickers: list) -> set[str]:
    return {t for t in (_normalize_nse_ticker(x) for x in tickers) if t}

def _cache_covers_tickers(cache: dict, requested: set[str]) -> bool:
    data = cache.get("data") if isinstance(cache, dict) else None
    if not isinstance(data, dict) or not requested:
        return False
    cached = {_normalize_nse_ticker(k) for k in data.keys()}
    return requested.issubset(cached)

def _bootstrap_bulk_deal_history(raw_history: dict, days_back: int = 45,
                                  log_cb=None) -> dict:
    """
    One-time backfill of bulk deal history from NSE historical endpoint.
    Called automatically when raw_history has fewer than 5 days of data.
    Gives us 45 days of institutional activity immediately on first run
    rather than waiting 45 days of daily snapshot accumulation.
    """
    from datetime import timedelta as _td
    _bd_headers = {
        "Accept": "application/json, text/plain, */*",
        "Accept-Encoding": "gzip, deflate",
        "Referer": (
            "https://www.nseindia.com/companies-listing/"
            "corporate-filings-bulk-deals"
        )
    }
    from_dt = (datetime.now() - _td(days=days_back)).strftime("%d-%m-%Y")
    to_dt   = datetime.now().strftime("%d-%m-%Y")
    url = (
        f"https://www.nseindia.com/api/historical/bulk-deals"
        f"?from={from_dt}&to={to_dt}"
    )
    try:
        try:
            NSEClient.get("https://www.nseindia.com", timeout=8)
        except Exception:
            import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
            pass

        resp = NSEClient.get(url, headers=_bd_headers, timeout=25)
        if resp.status_code != 200:
            log_emit(log_cb, f"[BulkDeal] Bootstrap API returned {resp.status_code}")
            return raw_history

        raw = resp.content
        if raw and len(raw) >= 2 and raw[0] == 0x1f and raw[1] == 0x8b:
            import gzip as _gz
            try:
                raw = _gz.decompress(raw)
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                pass

        text = raw.decode("utf-8", errors="ignore").strip()
        if not text:
            return raw_history

        parsed  = json.loads(text)
        records = (
            parsed.get("data", []) if isinstance(parsed, dict) else
            (parsed if isinstance(parsed, list) else [])
        )
        if not records:
            log_emit(log_cb, "[BulkDeal] Bootstrap: no historical records returned")
            return raw_history

        df = pd.DataFrame(records)
        df.columns = [c.strip().upper().replace(" ", "_") for c in df.columns]

        sym_col    = next((c for c in df.columns if "SYMBOL" in c), None)
        client_col = next(
            (c for c in df.columns if "CLIENT" in c or "CNAME" in c or "NAME" in c),
            None
        )
        side_col = next(
            (c for c in df.columns if "BUY" in c or "SELL" in c
             or "TYPE" in c or "ACTION" in c),
            None
        )
        date_col = next((c for c in df.columns if "DATE" in c), None)
        qty_col  = next(
            (c for c in df.columns if "QTY" in c or "QUANTITY" in c or "SHARES" in c),
            None
        )
        price_col = next(
            (c for c in df.columns if "PRICE" in c or "WATP" in c or "RATE" in c),
            None
        )

        if not sym_col or not client_col:
            log_emit(log_cb, "[BulkDeal] Bootstrap: could not parse column structure")
            return raw_history

        added_days: set = set()
        for _, row in df.iterrows():
            try:
                date_raw = str(row.get(date_col, "")).strip() if date_col else ""
                # NSE API returns dates as "14-JUN-2026" (uppercase month).
                # Normalise to title case so strptime %b matching works on all variants.
                date_raw_norm = date_raw.title()
                date_key = None
                for candidate, fmt in [
                    (date_raw_norm, "%d-%b-%Y"),   # 14-Jun-2026  (NSE bulk deals)
                    (date_raw,      "%d-%m-%Y"),    # 14-06-2026
                    (date_raw,      "%Y-%m-%d"),    # 2026-06-14
                    (date_raw_norm, "%d-%B-%Y"),    # 14-June-2026 (full month name)
                    (date_raw,      "%m/%d/%Y"),    # 06/14/2026
                    (date_raw,      "%d/%m/%Y"),    # 14/06/2026
                ]:
                    try:
                        date_key = datetime.strptime(candidate, fmt).strftime("%Y-%m-%d")
                        break
                    except Exception:
                        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                        continue
                if not date_key:
                    continue

                sym = str(row.get(sym_col, "")).strip().upper()
                if not sym:
                    continue

                deal = {
                    "SYMBOL":      sym,
                    "CLIENT_NAME": str(row.get(client_col, "")).strip().upper(),
                    "BUY_SELL":    str(row.get(side_col, "BUY")).strip().upper()
                                   if side_col else "BUY",
                    "DATE":        date_key,
                    "QTY":         str(row.get(qty_col, "0")) if qty_col else "0",
                    "PRICE":       str(row.get(price_col, "0")) if price_col else "0"
                }
                if date_key not in raw_history:
                    raw_history[date_key] = []
                raw_history[date_key].append(deal)
                added_days.add(date_key)
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                continue

        total_deals = sum(len(v) for v in raw_history.values())
        log_emit(
            log_cb,
            f"[BulkDeal] Bootstrap complete: {total_deals} deals "
            f"across {len(added_days)} trading days"
        )

    except Exception as e:
        log_emit(log_cb, f"[BulkDeal] Bootstrap failed (non-fatal): {e}")

    return raw_history


def fetch_nse_bulk_deal_footprint(tickers: list, days_back: int = 45,
                                   log_cb=None,
                                   historical_only: bool = False) -> dict:
    """
    Institutional footprint from NSE bulk/block deal data.
    Detects consecutive institutional buying before price discovery.

    Maintains a rolling 45-day history in bulk_deals_raw_history.json,
    updated daily from the NSE snapshot API. Auto-bootstraps from the
    NSE historical endpoint on first run to avoid a 45-day cold-start.

    Higher score = more sustained institutional accumulation recently.
    Returns {ticker: footprint_score_0_to_1}

    Args:
        historical_only: When True, skips the live NSE snapshot fetch entirely
            and scores directly from on-disk raw history. Used by WFO backtest
            steps to avoid 12× redundant live NSE API calls per profile sweep
            (~80s each = ~16min wasted per profile). Only the live/daily run
            needs the snapshot; historical WFO steps score from existing data.
    """
    from datetime import timedelta as _td

    today_str         = datetime.now().strftime("%Y-%m-%d")
    requested_tickers = _normalize_nse_ticker_set(tickers)
    RAW_HISTORY_PATH  = RUNTIME_DIR / "bulk_deals_raw_history.json"

    # ── 1. Check scored cache (universe-aware) ─────────────────────────────
    score_cache = read_json_cache(BULK_DEAL_CACHE_PATH, {})
    if score_cache.get("date") == today_str and _cache_covers_tickers(
        score_cache, requested_tickers
    ):
        data = {
            t: float(
                score_cache["data"].get(t)
                or score_cache["data"].get(t.replace(".NS", ""), 0.0)
                or 0.0
            )
            for t in sorted(requested_tickers)
        }
        nonzero = sum(1 for v in data.values() if abs(v) > 1e-12)
        log_emit(
            log_cb,
            f"[BulkDeal] Cache hit: {len(data)}/{len(requested_tickers)} "
            f"tickers | nonzero={nonzero}"
        )
        return data

    if score_cache.get("date") == today_str and score_cache.get("data"):
        log_emit(
            log_cb,
            f"[BulkDeal] Cache miss for requested universe: "
            f"cached={len(score_cache['data'])}, requested={len(requested_tickers)}"
        )

    # ── 2. Load raw history ────────────────────────────────────────────────
    raw_history = read_json_cache(RAW_HISTORY_PATH, {})

    # Auto-bootstrap if history is thin (fewer than 5 trading days recorded).
    # Gated behind `not historical_only` to guarantee zero network calls during WFO backtest steps.
    # Also gate on `_bootstrap_attempted != today_str` so a single-day 503 error is not repeated across all 9 profiles.
    valid_days = sum(1 for k in raw_history.keys() if not str(k).startswith("_"))
    bootstrap_attempted_today = (raw_history.get("_bootstrap_attempted") == today_str)
    if valid_days < 5 and not bootstrap_attempted_today:
        if not historical_only:
            log_emit(
                log_cb,
                "[BulkDeal] History thin — bootstrapping from NSE historical API..."
            )
            raw_history = _bootstrap_bulk_deal_history(raw_history, days_back, log_cb)
            raw_history["_bootstrap_attempted"] = today_str
            write_json_cache(RAW_HISTORY_PATH, raw_history)
        else:
            log_emit(
                log_cb,
                "[BulkDeal] History thin in historical_only mode — skipping NSE historical bootstrap (WFO step)"
            )

    # ── 3. Fetch today's snapshot and append ───────────────────────────────
    # historical_only=True (set by WFO backtest steps) skips this entirely.
    # WFO doesn't need live data — it scores from the existing raw history file.
    # Skipping saves ~80s × 12 WFO steps × N profiles of redundant NSE network calls.
    if not historical_only:
        try:
            try:
                NSEClient.get("https://www.nseindia.com/market-data/large-deals", timeout=8)
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                pass

            _snap_headers = {
                "Accept": "application/json, text/plain, */*",
                "Accept-Encoding": "gzip, deflate",
                "Referer": "https://www.nseindia.com/market-data/large-deals",
            }
            resp = NSEClient.get(
                "https://www.nseindia.com/api/snapshot-capital-market-largedeal",
                headers=_snap_headers, timeout=15
            )
            if resp.status_code == 200 and resp.content:
                raw_c = resp.content
                if raw_c and len(raw_c) >= 2 and raw_c[0] == 0x1f and raw_c[1] == 0x8b:
                    import gzip
                    try:
                        raw_c = gzip.decompress(raw_c)
                    except Exception:
                        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                        pass
                text_c = raw_c.decode('utf-8', errors='ignore').strip()
                snap = {}
                if text_c and (text_c.startswith('{') or text_c.startswith('[')):
                    import json
                    try:
                        snap = json.loads(text_c)
                    except Exception:
                        snap = {}
                date_raw    = snap.get("as_on_date", "") if isinstance(snap, dict) else ""
                date_key    = today_str
                if date_raw:
                    try:
                        date_key = datetime.strptime(date_raw, "%d-%b-%Y").strftime("%Y-%m-%d")
                    except Exception:
                        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                        pass

                combined = []
                for deal in snap.get("BULK_DEALS_DATA", []) + snap.get("BLOCK_DEALS_DATA", []):
                    sym = str(deal.get("symbol", "")).strip().upper()
                    if not sym:
                        continue
                    px_val = str(deal.get("tradePrice", deal.get("watp", "0")) or "0")
                    combined.append({
                        "SYMBOL":      sym,
                        "CLIENT_NAME": str(deal.get("clientName", "")).strip().upper(),
                        "BUY_SELL":    str(deal.get("buySell",    "")).strip().upper(),
                        "DATE":        date_key,
                        "QTY":         str(deal.get("qty", "0")),
                        "PRICE":       px_val
                    })
                if combined:
                    raw_history[date_key] = combined
                    log_emit(log_cb, f"[BulkDeal] Appended {len(combined)} deals for {date_key}")
            else:
                log_emit(log_cb, f"[BulkDeal] Snapshot API returned status {resp.status_code}")

        except Exception as e:
            log_emit(log_cb, f"[BulkDeal] Snapshot fetch failed (non-fatal): {e}", exc_info=True)

    else:
        log_emit(log_cb, "[BulkDeal] historical_only=True — skipping live NSE snapshot fetch (WFO step)")

    # ── 4. Trim to rolling window and persist ──────────────────────────────
    cutoff = (datetime.now() - _td(days=days_back)).strftime("%Y-%m-%d")
    raw_history = {d: v for d, v in raw_history.items() if d >= cutoff}
    if not historical_only:
        # Only write-back when we actually updated from the live snapshot.
        # WFO steps must not overwrite the shared cache with stale per-step state.
        write_json_cache(RAW_HISTORY_PATH, raw_history)


    # ── 5. Score each requested ticker ────────────────────────────────────
    all_deals  = [deal for deals in raw_history.values() for deal in deals]
    result     = {}
    ticker_set = {t.replace(".NS", "") for t in requested_tickers}

    if not all_deals:
        for sym in ticker_set:
            result[f"{sym}.NS"] = 0.0
        existing_data = dict(score_cache.get("data", {})) if score_cache.get("date") == today_str and isinstance(score_cache.get("data"), dict) else {}
        existing_data.update(result)
        write_json_cache(BULK_DEAL_CACHE_PATH, {
            "date": today_str, "requested_count": len(existing_data),
            "nonzero_count": sum(1 for v in existing_data.values() if abs(float(v or 0.0)) > 1e-12),
            "data": existing_data,
        })
        log_emit(log_cb, "[BulkDeal] No historical deals available yet — all scores 0.0")
        return result

    df = pd.DataFrame(all_deals)
    if "CLIENT_NAME" not in df.columns or "BUY_SELL" not in df.columns:
        for sym in ticker_set:
            result[f"{sym}.NS"] = 0.0
        return result

    def _is_institutional(name: str) -> bool:
        n = str(name).upper()
        return any(k in n for k in _INSTITUTIONAL_BUYER_KEYWORDS)

    df["is_institutional"] = df["CLIENT_NAME"].apply(_is_institutional)
    buy_mask = df["BUY_SELL"].astype(str).str.upper().str.contains(r"^B$|^BUY$|BUY|PURCHASE", na=False)
    df_buys  = df[buy_mask & df["is_institutional"]]

    for sym in ticker_set:
        sym_buys = df_buys[df_buys["SYMBOL"] == sym]
        if sym_buys.empty:
            result[f"{sym}.NS"] = 0.0
            continue

        buy_dates = sorted(sym_buys["DATE"].unique())
        max_consecutive = cur_consecutive = 1
        for i in range(1, len(buy_dates)):
            try:
                d1 = datetime.strptime(buy_dates[i - 1], "%Y-%m-%d")
                d2 = datetime.strptime(buy_dates[i],     "%Y-%m-%d")
                delta = (d2 - d1).days
            except Exception:
                delta = 99
            if delta <= 3:
                cur_consecutive += 1
                max_consecutive  = max(max_consecutive, cur_consecutive)
            else:
                cur_consecutive = 1

        unique_buyers = int(sym_buys["CLIENT_NAME"].nunique())

        try:
            latest   = datetime.strptime(max(sym_buys["DATE"]), "%Y-%m-%d")
            days_ago = max((datetime.now() - latest).days, 0)
        except Exception:
            days_ago = 30
        recency_weight = float(max(1.0 - days_ago / 30.0, 0.0))

        footprint_score = float(min(
            0.40 * min(max_consecutive / 5.0, 1.0) +
            0.35 * min(unique_buyers   / 3.0, 1.0) +
            0.25 * recency_weight,
            1.0
        ))
        result[f"{sym}.NS"] = round(footprint_score, 4)

    existing_data = dict(score_cache.get("data", {})) if score_cache.get("date") == today_str and isinstance(score_cache.get("data"), dict) else {}
    existing_data.update(result)
    nonzero_count = sum(1 for v in existing_data.values() if abs(float(v or 0.0)) > 1e-12)
    write_json_cache(BULK_DEAL_CACHE_PATH, {
        "date": today_str, "requested_count": len(existing_data),
        "nonzero_count": nonzero_count, "data": existing_data,
    })
    log_emit(
        log_cb,
        f"[BulkDeal] Scored {len(result)}/{len(requested_tickers)} "
        f"tickers | nonzero={nonzero_count}"
    )
    return result


def get_screener_company_page(symbol: str) -> str | None:
    """
    Resolve NSE symbol to Screener.in company page HTML.
    Tries direct paths first, falls back to autocomplete search API.
    5-second timeout per attempt to prevent blocking the optimizer.
    """
    sym = symbol.replace('.NS', '').replace('.BO', '').upper()
    _sc_headers = {
        'User-Agent': (
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) '
            'AppleWebKit/537.36 (KHTML, like Gecko) '
            'Chrome/124.0.0.0 Safari/537.36'
        )
    }

    # Direct URL — works for 95% of NSE tickers
    for path in [f'/company/{sym}/consolidated/', f'/company/{sym}/']:
        try:
            resp = requests.get(
                f'https://www.screener.in{path}',
                headers=_sc_headers, timeout=5
            )
            if resp.status_code == 200 and 'shareholding' in resp.text.lower():
                return resp.text
        except Exception:
            import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
            pass

    # Search API fallback for non-standard Screener slugs
    try:
        search_resp = requests.get(
            f'https://www.screener.in/api/company/search/?q={sym}',
            headers=_sc_headers, timeout=5
        )
        if search_resp.status_code == 200:
            hits       = search_resp.json()
            candidates = [r.get('url', '') for r in hits if r.get('url')]
            # Prefer exact symbol match in URL
            candidates.sort(key=lambda u: (f'/company/{sym}/' not in u.upper()))
            for url_path in candidates[:3]:
                try:
                    r = requests.get(
                        f'https://www.screener.in{url_path}',
                        headers=_sc_headers, timeout=5
                    )
                    if r.status_code == 200 and 'shareholding' in r.text.lower():
                        return r.text
                except Exception:
                    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                    continue
    except Exception:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
        pass

    return None


def _parse_screener_shareholding(html: str) -> dict | None:
    """
    Parse the shareholding table from Screener.in HTML.
    Returns dict with promoter_pct, inst_pct, public_pct,
    float_being_absorbed, float_shrinking — or None on parse failure.
    """
    sh_match = re.search(
        r'<section[^>]*id=["\']shareholding["\'][^>]*>.*?</section>',
        html, re.DOTALL | re.IGNORECASE
    )
    if not sh_match:
        return None

    sh_block     = sh_match.group(0)
    tbody_match  = re.search(r'<tbody>(.*?)</tbody>', sh_block, re.DOTALL | re.IGNORECASE)
    if not tbody_match:
        return None

    rows = re.findall(
        r'<tr[^>]*>(.*?)</tr>', tbody_match.group(1), re.DOTALL | re.IGNORECASE
    )

    promoter_vals: list = []
    fii_vals:      list = []
    dii_vals:      list = []
    public_vals:   list = []

    for row in rows:
        cells    = re.findall(r'<td[^>]*>(.*?)</td>', row, re.DOTALL | re.IGNORECASE)
        if not cells:
            continue
        category = re.sub(r'<[^>]+>', '', cells[0]).strip().lower()
        vals     = []
        for c in cells[1:]:
            raw_val = re.sub(r'<[^>]+>', '', c).strip().replace('%', '').replace(',', '')
            try:
                vals.append(float(raw_val))
            except ValueError:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                pass   # skip non-numeric cells

        if not vals:
            continue

        if 'promoter' in category:
            promoter_vals = vals
        elif 'fii' in category:
            fii_vals = vals
        elif 'dii' in category:
            dii_vals = vals
        elif 'public' in category:
            public_vals = vals

    if not public_vals:
        return None

    promoter_pct = float(promoter_vals[-1]) if promoter_vals else 0.0
    public_pct   = float(public_vals[-1])
    fii_pct      = float(fii_vals[-1])  if fii_vals  else 0.0
    dii_pct      = float(dii_vals[-1])  if dii_vals  else 0.0
    inst_pct     = fii_pct + dii_pct

    float_being_absorbed = 0.0
    float_shrinking      = 0.0
    if len(public_vals) >= 2:
        prev_fii  = float(fii_vals[-2])  if fii_vals  and len(fii_vals)  >= 2 else 0.0
        prev_dii  = float(dii_vals[-2])  if dii_vals  and len(dii_vals)  >= 2 else 0.0
        inst_change          = inst_pct - (prev_fii + prev_dii)
        float_being_absorbed = float(inst_change > 0.5)
        float_shrinking      = float(public_pct < float(public_vals[-2]))

    return {
        "promoter_pct":         promoter_pct,
        "inst_pct":             inst_pct,
        "public_pct":           public_pct,
        "float_being_absorbed": float_being_absorbed,
        "float_shrinking":      float_shrinking,
    }


def fetch_bse_float_squeeze(tickers: list, log_cb=None) -> dict:
    """
    Float squeeze probability from Screener.in shareholding pattern data.

    Uses parallel scraping (8 workers) to reduce latency from ~12 minutes
    sequential to ~90 seconds for a 150-ticker universe.

    Score components:
      - Free float size: below 25% public = maximum squeeze potential
      - Institutional absorption: inst stake increasing quarter-over-quarter
      - Promoter lockup: promoter > 55% = won't sell into your rally
      - Float shrinking trend: public float falling quarter-over-quarter

    Returns {ticker: float_squeeze_score_0_to_1}
    """
    today_str         = datetime.now().strftime("%Y-%m-%d")
    requested_tickers = _normalize_nse_ticker_set(tickers)

    # ── Load and normalise cache ───────────────────────────────────────────
    cache       = read_json_cache(FLOAT_SQUEEZE_CACHE_PATH, {})
    cached_data = cache.get("data") if isinstance(cache, dict) else {}
    cached_data = cached_data if isinstance(cached_data, dict) else {}
    normalized_cache = {
        _normalize_nse_ticker(k): float(v or 0.0)
        for k, v in cached_data.items()
        if _normalize_nse_ticker(k)
    }

    # Full cache hit
    if (
        cache.get("date") == today_str
        and requested_tickers
        and requested_tickers.issubset(normalized_cache)
    ):
        result  = {t: normalized_cache.get(t, 0.0) for t in sorted(requested_tickers)}
        nonzero = sum(1 for v in result.values() if abs(v) > 1e-12)
        log_emit(
            log_cb,
            f"[FloatSqueeze] Cache hit: {len(result)}/{len(requested_tickers)} "
            f"tickers | nonzero={nonzero}"
        )
        return result

    if cache.get("date") == today_str and normalized_cache:
        result  = {t: normalized_cache.get(t, 0.0) for t in sorted(requested_tickers)}
        nonzero = sum(1 for v in result.values() if abs(v) > 1e-12)
        log_emit(
            log_cb,
            f"[FloatSqueeze] Cache hit: {len(requested_tickers.intersection(normalized_cache))}/{len(requested_tickers)} covered | nonzero={nonzero}"
        )
        return result

    result = {t: normalized_cache.get(t, 0.0) for t in sorted(requested_tickers)}
    missing = [t for t in sorted(requested_tickers) if t not in normalized_cache]

    # ── Score a single ticker ──────────────────────────────────────────────
    def _score_ticker(ticker: str) -> tuple:
        try:
            html = get_screener_company_page(ticker)
            if not html:
                return ticker, 0.0

            parsed = _parse_screener_shareholding(html)
            if not parsed:
                return ticker, 0.0

            public_pct           = parsed["public_pct"]
            promoter_pct         = parsed["promoter_pct"]
            float_being_absorbed = parsed["float_being_absorbed"]
            float_shrinking      = parsed["float_shrinking"]

            low_float_score = float(min(max(1.0 - public_pct / 25.0, 0.0), 1.0))
            promoter_locked = float(promoter_pct > 55.0)

            squeeze_score = float(min(
                0.35 * low_float_score        +
                0.25 * float_being_absorbed   +
                0.25 * promoter_locked        +
                0.15 * float_shrinking,
                1.0
            ))
            return ticker, round(squeeze_score, 4)

        except Exception as _e:
            ExceptionLogger.swallow(_e, context="fetch_bse_float_squeeze_ticker")
            return ticker, 0.0

    # ── Parallel fetch — 8 workers ─────────────────────────────────────────
    # 150 tickers × 5s sequential ≈ 12 min → 8 workers ≈ 95 seconds
    if missing:
        log_emit(log_cb, f"[FloatSqueeze] Fetching {len(missing)} tickers from Screener.in...")
        try:
            with _DaemonThreadPoolExecutor(max_workers=8) as _pool:
                futures = {_pool.submit(_score_ticker, t): t for t in missing}
                for future in as_completed(futures, timeout=120):
                    try:
                        ticker, score = future.result()
                        result[ticker] = score
                    except Exception as _fe:
                        ExceptionLogger.swallow(_fe, context="float_squeeze_future")
        except Exception as e:
            log_emit(log_cb, f"[FloatSqueeze] Parallel fetch error (non-fatal): {e}", exc_info=True)
            for t in missing:
                if t not in result:
                    result[t] = 0.0

    # ── Merge, persist, return ─────────────────────────────────────────────
    merged_cache = dict(normalized_cache)
    merged_cache.update(result)
    final_result = {
        t: float(merged_cache.get(t, 0.0) or 0.0)
        for t in sorted(requested_tickers)
    }
    nonzero_count = sum(1 for v in final_result.values() if abs(v) > 1e-12)

    write_json_cache(FLOAT_SQUEEZE_CACHE_PATH, {
        "date":            today_str,
        "requested_count": len(requested_tickers),
        "nonzero_count":   nonzero_count,
        "data":            merged_cache,
    })
    log_emit(
        log_cb,
        f"[FloatSqueeze] Scored {len(final_result)}/{len(requested_tickers)} "
        f"tickers | nonzero={nonzero_count}"
    )
    return final_result





# ────────────────────────────────────────────────────────────────────
# FUNC: fetch_pead_scores
# ────────────────────────────────────────────────────────────────────
def fetch_pead_scores(tickers: list, close_df, log_cb=None) -> dict:
    """S3: Post-Earnings Announcement Drift (PEAD) day 3-21.
    Uses NSE corporate announcements API to find recent Q4/financial results dates,
    then computes cumulative return from day+3 to day+21 vs benchmark."""
    from datetime import datetime, timedelta
    today_str = datetime.now().strftime("%Y-%m-%d")
    cache = read_json_cache(PEAD_CACHE_PATH, {})
    if cache.get("date") == today_str and "data" in cache and isinstance(cache["data"], dict):
        return cache["data"]
    result = {}
    try:
        try:
            NSEClient.get("https://www.nseindia.com", timeout=10)
        except Exception:
            import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
            pass
        from_dt = (datetime.now() - timedelta(days=30)).strftime("%d-%m-%Y")
        to_dt = datetime.now().strftime("%d-%m-%Y")
        headers = {
            "Accept": "application/json, text/plain, */*",
            "Referer": "https://www.nseindia.com/companies-listing/corporate-filings-announcements"
        }
        url = f"https://www.nseindia.com/api/corporate-announcements?index=equities&from_date={from_dt}&to_date={to_dt}"
        resp = NSEClient.get(url, headers=headers, timeout=20)
        recs = []
        if resp.status_code == 200:
            recs = resp.json()
        if not recs:
            # L2-fix: replace hardcoded "01-05-2026" with a dynamic wider-window fallback date.
            _fallback_from_dt = (datetime.now() - timedelta(days=90)).strftime("%d-%m-%Y")
            fallback_url = f"https://www.nseindia.com/api/corporate-announcements?index=equities&from_date={_fallback_from_dt}&to_date={to_dt}"
            try:
                resp = NSEClient.get(fallback_url, headers=headers, timeout=20)
                if resp.status_code == 200:
                    recs = resp.json()
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                pass
        if not recs:
            return result
        df = pd.DataFrame(recs)
        df.columns = [c.strip().upper().replace(" ", "_") for c in df.columns]
        sym_col = "SYMBOL"
        desc_col = "DESC"
        date_col = "AN_DT"
        if not sym_col or not desc_col or not date_col:
            return result
        results_mask = df[desc_col].astype(str).str.upper().str.contains("BOARD MEETING|FINANCIAL|RESULT|EARN", na=False)
        df = df[results_mask]
        df[date_col] = pd.to_datetime(df[date_col], format="%d-%b-%Y %H:%M:%S", errors="coerce")
        df = df.dropna(subset=[date_col])
        now = pd.Timestamp.now()
        df = df[(df[date_col] >= now - pd.Timedelta(days=30)) & (df[date_col] <= now - pd.Timedelta(days=3))]
        if close_df is None or close_df.empty:
            return result
        ticker_set = set(t.replace(".NS", "").replace(".BO", "").upper() for t in tickers)
        for _, row in df.iterrows():
            sym = str(row[sym_col]).strip().upper()
            if sym not in ticker_set:
                continue
            t = f"{sym}.NS"
            if t not in close_df.columns:
                continue
            event_date = row[date_col]
            s = close_df[t].dropna()
            post_idx = s.index[s.index >= event_date + pd.Timedelta(days=3)]
            event_idx = s.index[s.index >= event_date]
            if len(event_idx) < 1 or len(post_idx) < 3:
                continue
            price_base = float(s.loc[event_idx[0]])
            _p21_idx = s.index[s.index >= event_date + pd.Timedelta(days=21)]
            if (s.index[-1] - event_date).days < 18:
                continue
            _t21 = _p21_idx[0] if len(_p21_idx) > 0 else s.index[-1]
            # AUDIT-FIX (Round 20 — R20-1): the body of this `if` block was
            # accidentally deleted (dangling `if price_base > 0:` with the
            # next statement dedented), producing an IndentationError that
            # made the entire module — and therefore app.py / optimizer.py —
            # fail to import. Restored verbatim from the Round-17 baseline:
            # day-0 → day+21 cumulative return around the earnings event.
            if price_base > 0:
                result[t] = round((float(s.loc[_t21]) / price_base) - 1.0, 4)
        write_json_cache(PEAD_CACHE_PATH, {"date": today_str, "data": result})
        log_emit(log_cb, f"[PEAD] {len(result)} tickers with post-earnings drift scores")
    except Exception as e:
        write_json_cache(PEAD_CACHE_PATH, {"date": today_str, "data": {}})
        log_emit(log_cb, f"[PEAD] fetch failed (non-fatal): {e}", exc_info=True)
    return result




# ────────────────────────────────────────────────────────────────────
# FUNC: fetch_pcr_skew
# ────────────────────────────────────────────────────────────────────
def fetch_pcr_skew(tickers: list, log_cb=None) -> dict:
    """S4: Options PCR + IV Skew divergence from 20d average.
    Uses NSE option-chain API. High PCR divergence = bearish positioning.
    Inverse used as signal: low PCR vs history = bullish informed flow.

    AUDIT-FIX (Round 3, P2-2): migrated onto NSEClient + NSEPerTickerPool.
    """
    from utils_nse import NSEPerTickerPool, nse_parsers
    from utils import NSEClient

    today_str = datetime.now().strftime("%Y-%m-%d")
    cache = read_json_cache(PCR_CACHE_PATH, {})
    if cache.get("date") == today_str and "data" in cache and isinstance(cache["data"], dict):
        return cache["data"]

    result = {}
    _failed_consecutive = 0
    _aborted_early = False

    def _fetch_one(t: str):
        nonlocal _failed_consecutive, _aborted_early
        if _aborted_early:
            return None
        sym = t.replace(".NS","").upper()
        url = f"https://www.nseindia.com/api/option-chain-equities?symbol={sym}"
        try:
            resp = NSEClient.get(url, timeout=6)
            if resp.status_code in (401, 403, 429, 503):
                _failed_consecutive += 1
                if _failed_consecutive >= 3:
                    _aborted_early = True
                return None
            if resp.status_code != 200:
                _failed_consecutive += 1
                if _failed_consecutive >= 5:
                    _aborted_early = True
                return None
            _failed_consecutive = 0
            data = nse_parsers.decode_nse_json(resp)
            records = data.get("records", {}).get("data", [])
            total_put_oi  = sum(r.get("PE", {}).get("openInterest", 0) for r in records if r.get("PE"))
            total_call_oi = sum(r.get("CE", {}).get("openInterest", 0) for r in records if r.get("CE"))
            if total_call_oi > 0:
                return round(1.0 / (1.0 + total_put_oi / total_call_oi), 4)
            return None
        except Exception:
            _failed_consecutive += 1
            if _failed_consecutive >= 3:
                _aborted_early = True
            return None

    try:
        per_ticker_results = NSEPerTickerPool.map_per_ticker(_fetch_one, tickers)
        for t, v in per_ticker_results.items():
            if v is not None:
                result[t] = v
        write_json_cache(PCR_CACHE_PATH, {"date": today_str, "data": result})
        log_emit(log_cb, f"[PCR] {len(result)} tickers with PCR skew scores")
    except Exception as e:
        write_json_cache(PCR_CACHE_PATH, {"date": today_str, "data": {}})
        log_emit(log_cb, f"[PCR] fetch failed (non-fatal): {e}", exc_info=True)
    return result




# ────────────────────────────────────────────────────────────────────
# FUNC: fetch_fii_sector_flow
# ────────────────────────────────────────────────────────────────────
def fetch_fii_sector_flow(log_cb=None) -> dict:
    """S5: FII sector-level flow disaggregation.
    NSE publishes sector-wise FII buy/sell. Returns sector->zscore dict.

    AUDIT-FIX (Round 3, P2-2): migrated onto NSEClient.fetch_json.
    """
    from utils import NSEClient
    from utils_nse import nse_parsers

    today_str = datetime.now().strftime("%Y-%m-%d")
    cache = read_json_cache(FII_SECTOR_CACHE_PATH, {})
    if cache.get("date") == today_str and "data" in cache and isinstance(cache["data"], dict):
        return cache["data"]
    result = {}
    try:
        parsed = NSEClient.fetch_json(
            "https://www.nseindia.com/api/fiidiiTradeReact",
            timeout=10,
        )
        records = nse_parsers.extract_records(parsed)
        flows = {}
        for rec in records:
            cat = str(rec.get("category", "")).strip()
            try:
                net = float(str(rec.get("netBuySell", "0")).replace(",", "") or 0)
                if cat:
                    flows[cat] = flows.get(cat, 0) + net
            except Exception as _exc_p2a_:
                ExceptionLogger.swallow(_exc_p2a_, context='L4348')
        if flows:
            vals = list(flows.values())
            mu   = (float(np.mean(vals)) if len(vals) > 0 else 0.0)
            sig  = (float(np.std(vals)) if len(vals) > 0 else 0.0) + 1e-6
            result = {k: round((v - mu) / sig, 3) for k, v in flows.items()}
        write_json_cache(FII_SECTOR_CACHE_PATH, {"date": today_str, "data": result})
        log_emit(log_cb, f"[FII-Sector] {len(result)} sector flow z-scores")
    except Exception as e:
        write_json_cache(FII_SECTOR_CACHE_PATH, {"date": today_str, "data": {}})
        log_emit(log_cb, f"[FII-Sector] fetch failed (non-fatal): {e}", exc_info=True)
    return result




# ────────────────────────────────────────────────────────────────────
# FUNC: fetch_buyback_scores
# ────────────────────────────────────────────────────────────────────
def fetch_buyback_scores(tickers: list, log_cb=None) -> dict:
    """S6: Buyback announcement drift — SEBI mandatory disclosures.
    Stocks with open buyback windows at 15-30% premium show 3-6 week drift.
    Uses NSE corporate announcements API."""
    from datetime import datetime, timedelta
    today_str = datetime.now().strftime("%Y-%m-%d")
    cache = read_json_cache(BUYBACK_CACHE_PATH, {})
    if cache.get("date") == today_str and cache.get("data"):
        return cache["data"]
    result = {}
    try:
        try:
            NSEClient.get("https://www.nseindia.com", timeout=10)
        except Exception:
            import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
            pass
        from_dt = (datetime.now() - timedelta(days=45)).strftime("%d-%m-%Y")
        to_dt = datetime.now().strftime("%d-%m-%Y")
        headers = {
            "Accept": "application/json, text/plain, */*",
            "Referer": "https://www.nseindia.com/companies-listing/corporate-filings-announcements"
        }
        url = f"https://www.nseindia.com/api/corporate-announcements?index=equities&from_date={from_dt}&to_date={to_dt}"
        resp = NSEClient.get(url, headers=headers, timeout=20)
        recs = []
        if resp.status_code == 200:
            recs = resp.json()
        if not recs:
            # L2-fix: replace hardcoded "01-05-2026" with a dynamic wider-window fallback date.
            _fallback_from_dt = (datetime.now() - timedelta(days=90)).strftime("%d-%m-%Y")
            fallback_url = f"https://www.nseindia.com/api/corporate-announcements?index=equities&from_date={_fallback_from_dt}&to_date={to_dt}"
            try:
                resp = NSEClient.get(fallback_url, headers=headers, timeout=20)
                if resp.status_code == 200:
                    recs = resp.json()
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                pass
        if not recs:
            return result
        df = pd.DataFrame(recs)
        df.columns = [c.strip().upper().replace(" ", "_") for c in df.columns]
        sym_col = "SYMBOL"
        desc_col = "DESC"
        text_col = "ATTCHMNTTEXT"
        date_col = "AN_DT"
        if not sym_col or not desc_col or not text_col or not date_col:
            return result
        bb_mask = df[desc_col].astype(str).str.upper().str.contains("BUYBACK", na=False) | \
                  df[text_col].astype(str).str.upper().str.contains("BUYBACK", na=False)
        df = df[bb_mask]
        df[date_col] = pd.to_datetime(df[date_col], format="%d-%b-%Y %H:%M:%S", errors="coerce")
        df = df.dropna(subset=[date_col])
        now = pd.Timestamp.now()
        df = df[df[date_col] >= now - pd.Timedelta(days=45)]
        ticker_set = set(t.replace(".NS", "").replace(".BO", "").upper() for t in tickers)
        for _, row in df.iterrows():
            sym = str(row[sym_col]).strip().upper()
            # AUDIT-FIX (Round 20 — R20-1, second site): same dangling-`if`
            # corruption as fetch_pead_scores — body deleted, module unimportable.
            # Restored verbatim from the Round-17 baseline.
            if sym in ticker_set:
                result[f"{sym}.NS"] = 1.0
        write_json_cache(BUYBACK_CACHE_PATH, {"date": today_str, "data": result})
        log_emit(log_cb, f"[Buyback] {len(result)} tickers with buyback announcement drift scores")
    except Exception as e:
        write_json_cache(BUYBACK_CACHE_PATH, {"date": today_str, "data": {}})
        log_emit(log_cb, f"[Buyback] fetch failed (non-fatal): {e}", exc_info=True)
    return result




# ────────────────────────────────────────────────────────────────────
# FUNC: fetch_mtf_reversal
# ────────────────────────────────────────────────────────────────────
def fetch_mtf_reversal(tickers: list, log_cb=None) -> dict:
    """S7: Margin Trading Facility (MTF) forced-unwind reversal signal.
    NSE publishes daily MTF outstanding. High MTF + recent price drop = forced
    unwind risk. We use inverse: low MTF + stable price = clean positioning.

    AUDIT-FIX (Round 3, P2-2): migrated onto NSEClient.fetch_json.
    """
    from utils import NSEClient
    from utils_nse import nse_parsers

    today_str = datetime.now().strftime("%Y-%m-%d")
    cache = read_json_cache(MTF_CACHE_PATH, {})
    if cache.get("date") == today_str and "data" in cache and isinstance(cache["data"], dict):
        return cache["data"]
    result = {}
    try:
        parsed = NSEClient.fetch_json(
            "https://www.nseindia.com/api/mtf",
            headers={"X-Requested-With": "XMLHttpRequest"},
            timeout=10,
        )
        records = nse_parsers.extract_records(parsed)
        ticker_set = set(t.replace(".NS","").upper() for t in tickers)
        mtf_vals = {}
        for rec in records:
            sym = str(rec.get("symbol", "")).strip().upper()
            if sym in ticker_set:
                try:
                    mtf_outstanding = float(str(rec.get("mtfOutstanding", 0)).replace(",","") or 0)
                    mtf_vals[f"{sym}.NS"] = mtf_outstanding
                except Exception as _exc_p2a_:
                    ExceptionLogger.swallow(_exc_p2a_, context='L4434')
        if mtf_vals:
            arr = np.array(list(mtf_vals.values()))
            mu, sig = arr.mean(), arr.std() + 1e-6
            for k, v in mtf_vals.items():
                result[k] = (round(-1.0 * (v - mu) / sig, 3) if sig != 0 else 0.0)
        write_json_cache(MTF_CACHE_PATH, {"date": today_str, "data": result})
        log_emit(log_cb, f"[MTF] {len(result)} tickers with MTF reversal scores")
    except Exception as e:
        write_json_cache(MTF_CACHE_PATH, {"date": today_str, "data": {}})
        log_emit(log_cb, f"[MTF] fetch failed (non-fatal): {e}", exc_info=True)
    return result




# ────────────────────────────────────────────────────────────────────
# FUNC: apply_earnings_blackout
# ────────────────────────────────────────────────────────────────────
def apply_earnings_blackout(tickers: list, blackout_days: int = 5, log_cb=None) -> list:
    """
    Filter out tickers with upcoming (or just-past) earnings within ±blackout_days.
    Uses yfinance calendar data. Non-fatal: if fetch fails, ticker is kept.
    Returns filtered list of safe tickers.
    """
    if blackout_days <= 0:
        return tickers

    # Daily cache — avoids 120 serial yfinance calls on repeated runs
    _eb_cache_path = RUNTIME_DIR / 'earnings_blackout_cache.json'
    _today_str = datetime.now().strftime('%Y-%m-%d')
    _eb_cache = read_json_cache(_eb_cache_path, {})
    if _eb_cache.get('date') == _today_str and _eb_cache.get('blocked') is not None:
        # Only remove tickers CONFIRMED blocked in a prior run.
        # Tickers not previously examined default to safe (kept).
        # Bug-fix: old logic used an inclusion set ('safe'), so any ticker from a
        # larger new universe that wasn't in a prior smaller run was silently dropped.
        _cached_blocked = set(_eb_cache['blocked'])
        result = [t for t in tickers if t not in _cached_blocked]
        removed = len(tickers) - len(result)
        if removed:
            log_emit(log_cb, f'[Earnings Blackout] Cache hit — {removed} confirmed-blocked ticker(s) removed')
        return result
    if _eb_cache.get('date') == _today_str and _eb_cache.get('safe') is not None:
        # Legacy cache format (safe-only list) — treat as stale; re-evaluate.
        pass

    today = pd.Timestamp.now().normalize()
    blackout_start = today - pd.Timedelta(days=blackout_days)
    blackout_end   = today + pd.Timedelta(days=blackout_days)
    safe = []
    blocked = []

    for t in tickers:
        try:
            # Use safe_download via NSE corporate results API instead of
            # yf.Ticker.calendar which is unreliable for NSE stocks.
            # Route through the provider abstraction layer.
            cal = None
            try:
                sym = t.replace(".NS", "").replace(".BO", "").upper()
                # NSE corporate results/announcement endpoint
                headers = {
                    "Accept": "application/json",
                    "Referer": f"https://www.nseindia.com/get-quotes/equity?symbol={sym}"
                }
                _nse_url = f"https://www.nseindia.com/api/quote-equity?symbol={sym}&section=trade_info"
                resp = NSEClient.get(_nse_url, headers=headers, timeout=8)
                if resp.status_code == 200:
                    _info = resp.json()
                    _ed_str = (
                        _info.get("tradeInfo", {}).get("closingData", {}).get("next_result_date")
                        or _info.get("next_earnings_date")
                    )
                    if _ed_str:
                        cal = {"Earnings Date": _ed_str}
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                pass

            # Fallback: yfinance calendar (unreliable but better than nothing)
            # AUDIT-FIX Round 7 P2-4: yfinance lazy-loaded via _get_yf()
            _yf_lazy_cal = _get_yf() if cal is None else None
            if cal is None and _yf_lazy_cal is not None:
                try:
                    cal = _yf_lazy_cal.Ticker(t).calendar
                except Exception:
                    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                    pass

            if cal is None or (isinstance(cal, pd.DataFrame) and cal.empty):
                safe.append(t)
                continue
            # calendar can be a dict or DataFrame depending on yfinance version
            if isinstance(cal, dict):
                earnings_date = cal.get("Earnings Date")
                if isinstance(earnings_date, list) and earnings_date:
                    earnings_date = pd.Timestamp(earnings_date[0])
                elif earnings_date:
                    earnings_date = pd.Timestamp(earnings_date)
                else:
                    safe.append(t); continue
            elif isinstance(cal, pd.DataFrame):
                row = cal.T if "Earnings Date" not in cal.index else cal
                if "Earnings Date" not in row.index:
                    safe.append(t); continue
                _ed_series = row.loc["Earnings Date"]
                if isinstance(_ed_series, pd.Series):
                    if _ed_series.empty: safe.append(t); continue  # [ILOC-FIX: duplicate index labels can produce empty Series]
                    earnings_date = pd.Timestamp(_ed_series.iloc[0])
                else:
                    earnings_date = pd.Timestamp(_ed_series)
            else:
                safe.append(t); continue

            if blackout_start <= earnings_date <= blackout_end:
                blocked.append(t)
            else:
                safe.append(t)
        except Exception as _e:
            safe.append(t)  # non-fatal: keep on any error

    if blocked:
        log_emit(log_cb, f"[Earnings Blackout ±{blackout_days}d] Blocked {len(blocked)} ticker(s): {', '.join(blocked[:10])}" +
                         ("..." if len(blocked) > 10 else ""))
    # Save cache with both safe and blocked lists.
    # Future cache hits use the blocked set (exclusion), not the safe set (inclusion),
    # so tickers from a larger universe that weren't examined in a prior run stay safe.
    try:
        write_json_cache(_eb_cache_path, {'date': _today_str, 'safe': safe, 'blocked': blocked})
    except Exception as _e2_:
        ExceptionLogger.swallow(_e2_, context="silent_catch")
    return safe




# ────────────────────────────────────────────────────────────────────
# FUNC: fetch_promoter_holdings
# ────────────────────────────────────────────────────────────────────
def fetch_promoter_holdings(tickers: list, log_cb=None) -> dict:
    """
    BUG-DL1 FIX: Replaced yfinance heldPercentInsiders (stale/unreliable for NSE)
    with BSE shareholding pattern data via Screener.in (same source as float squeeze).
    High promoter holding (>50%) = strong conviction = quality signal.
    Returns {ticker: promoter_pct_0_to_100} or nan on failure.
    Non-fatal, disabled by default (USE_PROMOTER_SIGNAL=False) due to speed.
    """
    today_str = datetime.now().strftime("%Y-%m-%d")
    cache_path = RUNTIME_DIR / "promoter_holdings_cache.json"
    cache = read_json_cache(cache_path, {})
    if cache.get("date") == today_str and cache.get("data"):
        log_emit(log_cb, f"[Promoter] Cache hit: {len(cache['data'])} tickers")
        return cache["data"]

    result: dict = {}

    def _fetch_single(ticker: str) -> tuple:
        try:
            html = get_screener_company_page(ticker)
            if not html:
                return ticker, float("nan")
            parsed = _parse_screener_shareholding(html)
            if not parsed:
                return ticker, float("nan")
            # Return as 0-100 percentage (not 0-1) to match legacy callers
            return ticker, round(float(parsed["promoter_pct"]), 2)
        except Exception as _e:
            ExceptionLogger.swallow(_e, context="fetch_promoter_holdings_ticker")
            return ticker, float("nan")

    try:
        with _DaemonThreadPoolExecutor(max_workers=6) as _pool:
            futures = {_pool.submit(_fetch_single, t): t for t in tickers}
            for future in as_completed(futures, timeout=90):
                try:
                    ticker, pct = future.result()
                    result[ticker] = pct
                except Exception as _fe:
                    ExceptionLogger.swallow(_fe, context="promoter_holdings_future")
    except Exception as e:
        log_emit(log_cb, f"[Promoter] Parallel fetch error (non-fatal): {e}", exc_info=True)
        for t in tickers:
            if t not in result:
                result[t] = float("nan")

    fetched = sum(1 for v in result.values() if not (isinstance(v, float) and (v != v or np.isnan(v))))
    if fetched > 0:
        write_json_cache(cache_path, {"date": today_str, "data": result})
    log_emit(log_cb, f"[Promoter] Fetched holdings for {fetched}/{len(tickers)} tickers (BSE)")
    return result




# ────────────────────────────────────────────────────────────────────
# FUNC: fetch_nse_delivery_data
# ────────────────────────────────────────────────────────────────────
def fetch_nse_delivery_data(tickers: list, log_cb=None) -> dict:
    """
    Fetch NSE delivery volume % for each ticker from NSE bhav copy.
    High delivery % (>60%) = institutional conviction (not intraday noise).
    Returns {ticker: delivery_pct_0_to_1} cached daily.
    """
    cache = read_json_cache(DELIVERY_CACHE_PATH, {})
    today = datetime.now().strftime("%Y-%m-%d")
    if cache.get("date") == today and cache.get("data"):
        log_emit(log_cb, f"[DeliveryVol] Cache hit: {len(cache['data'])} tickers")
        return cache["data"]

    headers = {"User-Agent": "Mozilla/5.0", "Accept-Language": "en-US,en;q=0.9",
               "Referer": "https://www.nseindia.com"}
    delivery_map = {}
    # Try last 5 trading days (weekends/holidays)
    for days_back in range(1, 7):
        try:
            dt = (pd.Timestamp.now() - pd.Timedelta(days=days_back))
            if dt.weekday() >= 5:
                continue  # skip weekends
            date_str = dt.strftime("%d%m%Y")
            url = NSE_BHAV_URL.format(date=date_str)
            resp = NSEClient.get(url, headers=headers, timeout=3)
            if resp.status_code != 200:
                continue
            df = pd.read_csv(io.StringIO(resp.text))
            df.columns = [c.strip().upper() for c in df.columns]
            # Bhav CSV has: SYMBOL, SERIES, TOTTRDQTY, DELIV_QTY, DELIV_PER
            if "SYMBOL" not in df.columns or "DELIV_PER" not in df.columns:
                # Try alternate column names
                deliv_col = next((c for c in df.columns if "DELIV" in c and "PER" in c), None)
                sym_col   = next((c for c in df.columns if "SYMBOL" in c), None)
                if not deliv_col or not sym_col:
                    continue
                df = df.rename(columns={sym_col: "SYMBOL", deliv_col: "DELIV_PER"})
            df = df[df.get("SERIES", "EQ").astype(str).str.strip() == "EQ"] if "SERIES" in df.columns else df
            for _, row in df.iterrows():
                sym = str(row.get("SYMBOL", "")).strip().upper()
                pct = row.get("DELIV_PER")
                if sym and pd.notna(pct):
                    # R34-6 FIX: the NSE bhav CSV uses a ' -' (space-dash)
                    # placeholder for zero/absent delivery data on some rows.
                    # float(' -') raises ValueError, which used to abort the
                    # ENTIRE day's parse (log: "Bhav fetch failed T-3: could
                    # not convert string to float: ' -'") and silently fall
                    # back to a stale T-4 file. Guard per row instead.
                    try:
                        _pct_val = float(str(pct).strip())
                    except (TypeError, ValueError):
                        continue
                    delivery_map[f"{sym}.NS"] = _pct_val / 100.0
            if delivery_map:
                log_emit(log_cb, f"[DeliveryVol] Loaded {len(delivery_map)} tickers (T-{days_back})")
                break
        except Exception as e:
            log_emit(log_cb, f"[DeliveryVol] Bhav fetch failed T-{days_back}: {e}", exc_info=True)
            if "timeout" in str(e).lower() or "connection" in str(e).lower():
                log_emit(log_cb, "[DeliveryVol] Network timeout/connection error. Aborting loop to prevent hang.", exc_info=True)
                break
            continue

    if delivery_map:
        write_json_cache(DELIVERY_CACHE_PATH, {"date": today, "data": delivery_map})
    else:
        log_emit(log_cb, "[DeliveryVol] Could not fetch bhav data. Delivery signal skipped.")
    return delivery_map


# ── F&O Ban List Filter ──────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: fetch_fno_ban_list
# ────────────────────────────────────────────────────────────────────
def fetch_fno_ban_list(log_cb=None) -> set:
    """
    Fetch current NSE F&O ban-period stocks.
    Stocks in ban (MWPL >95%) should be excluded — they have reduced liquidity
    and carry regulatory risk (no fresh F&O positions allowed).
    Returns set of ticker symbols like {'RELIANCE.NS', 'TCS.NS'}.
    """
    cache = read_json_cache(FNO_BAN_CACHE_PATH, {})
    today = datetime.now().strftime("%Y-%m-%d")
    if cache.get("date") == today and cache.get("banned"):
        log_emit(log_cb, f"[F&O Ban] Cache hit: {len(cache['banned'])} banned stocks")
        return set(cache["banned"])

    # AUDIT-FIX (Round 3, P2-2): use NSEClient + sentinel-guarded cache write
    from utils import NSEClient
    banned = set()
    fetch_ok = False
    try:
        resp = NSEClient.get("https://archives.nseindia.com/content/fo/fo_secban.csv", timeout=10)
        if resp.status_code == 200 and resp.text:
            fetch_ok = True
            lines = resp.text.strip().splitlines()
            import re as _re_fno
            for line in lines:
                parts = [p.strip().upper() for p in line.split(",") if p.strip()]
                for p in parts:
                    if p and p != "NIL" and len(p) >= 3 and _re_fno.match(r"^[A-Z0-9&\-_]+$", p) and not p.isdigit() and "SECURITIES IN BAN" not in p:
                        banned.add(f"{p}.NS")
    except Exception as e:
        log_emit(log_cb, f"[F&O Ban] NSE Archives CSV fetch notice: {e}", exc_info=True)
    if fetch_ok:
        write_json_cache(FNO_BAN_CACHE_PATH, {"date": today, "banned": list(banned)})
    else:
        log_emit(log_cb, "[F&O Ban] HTTP fetch failed - not caching empty set; will retry next run")
    log_emit(log_cb, f"[F&O Ban] {len(banned)} stocks in ban period - excluded from universe")
    return banned


# ── FII/DII Flow Regime Overlay ──────────────────────────────────────────────



# ────────────────────────────────────────────────────────────────────
# FUNC: fetch_india_vix
# ────────────────────────────────────────────────────────────────────
def fetch_india_vix(log_cb=None) -> float:
    """Fetch latest India VIX to adjust optimizer risk tolerance."""
    try:
        if _DATA_PROVIDER is not None:
            raw_vix = _DATA_PROVIDER.get_vix()
        else:
            raw_vix = safe_download(["^INDIAVIX"], period="5d")
        
        def _extract_last_float(obj) -> Optional[float]:
            if obj is None:
                return None
            if isinstance(obj, (int, float)):
                return float(obj)
            if isinstance(obj, pd.DataFrame):
                if obj.empty:
                    return None
                if isinstance(obj.columns, pd.MultiIndex):
                    if "Close" in obj.columns.levels[0]:
                        close_part = obj["Close"]
                        if isinstance(close_part, pd.DataFrame):
                            return _extract_last_float(close_part.iloc[:, 0])
                        return _extract_last_float(close_part)
                elif "Close" in obj.columns:
                    return _extract_last_float(obj["Close"])
                return _extract_last_float(obj.iloc[:, 0])
            if isinstance(obj, pd.Series):
                clean_s = obj.dropna()
                if not clean_s.empty:
                    val = clean_s.iloc[-1]
                    if isinstance(val, (pd.Series, pd.DataFrame)):
                        return _extract_last_float(val)
                    return float(val)
                return None
            if isinstance(obj, (list, tuple)) and obj:
                return _extract_last_float(obj[-1])
            return None

        vix_val = _extract_last_float(raw_vix)
        if vix_val is not None and pd.notna(vix_val) and vix_val > 0.0:
            log_emit(log_cb, f"[Market Context] India VIX = {vix_val:.2f}")
            return vix_val
    except Exception as e:
        log_emit(log_cb, f"[Market Context] Failed to fetch VIX: {e}", exc_info=True)
    # AUDIT-FIX (Round 3, P2-2): replace silent constant 15.0 fallback with NaN
    log_emit(log_cb, "[Market Context] All India VIX fetches failed - returning NaN.")
    return float('nan')


# ────────────────────────────────────────────────────────────────────
# FUNC: fetch_nse_option_chain
# ────────────────────────────────────────────────────────────────────
_OPTION_CHAIN_CACHE: dict = {}
_OPTION_CHAIN_CACHE_LOCK = threading.Lock()
# AUDIT-FIX (Round 23 — R23-1): short-lived negative cache so an offline /
# WAF-blocked network does not re-attempt the two sequential NSE round-trips
# on every GEX + tail-hedge call site across a 9-profile sweep (each attempt
# can burn a 10s timeout on DNS-blackhole networks). Only EXCEPTION failures
# and non-200 statuses record a failure stamp (a successful fetch clears it);
# TTL 120s bounds staleness of the negative verdict.
_OPTION_CHAIN_FAIL_TS: dict = {}
_OPTION_CHAIN_NEG_TTL = 120.0

def fetch_nse_option_chain(symbol: str = "NIFTY", expiry: Optional[str] = None, log_cb=None) -> Optional[dict]:
    """
    AUDIT-FIX (Round 21 — R21-4): Wire real NSE option chain feed for NIFTY / indices.
    Fetches contract info and option chain (v3) using NSEClient with gzip decoding.
    Calculates spot price, max pain strike, put-call ratio (OI), median chain IV level,
    and the ±5% moneyness OTM IV skew. Caches results to prevent rate limiting.
    Returns None if NSE network fetch is unavailable or rate-limited.

    AUDIT-FIX (Round 22 — R22-3): the output keys were mislabeled. The previous
    `iv_percentile` key carried `median(IV across all strikes)` — a cross-sectional
    IV LEVEL, not an IV percentile (a percentile ranks today's IV against its own
    1y history, which a single chain snapshot cannot produce). The previous
    `iv_skew_25d_delta` key carried IV(put @ −5% moneyness) − IV(call @ +5%
    moneyness) — a fixed-moneyness skew, not a strike solved for a 25-delta
    option. Keys renamed to `median_iv` and `iv_skew_5pct_otm` so the labels
    match the math; a spot <= 0 payload now refuses honestly (previously it
    silently produced spot_price=0.0 and a strike[0]-anchored skew).
    """
    clean_sym = symbol.replace("^", "").replace(".NS", "").replace("NSE:", "").strip().upper()
    cache_key = f"{clean_sym}:{expiry or 'nearest'}"
    now_ts = time.time()
    with _OPTION_CHAIN_CACHE_LOCK:
        if cache_key in _OPTION_CHAIN_CACHE:
            cached_data, cached_ts = _OPTION_CHAIN_CACHE[cache_key]
            if now_ts - cached_ts < 300:  # 5-minute cache
                return cached_data
        # AUDIT-FIX (Round 23 — R23-1): recent failure suppression (see
        # _OPTION_CHAIN_FAIL_TS above) — returns None immediately when the
        # same key failed within the negative TTL.
        _fail_ts = _OPTION_CHAIN_FAIL_TS.get(cache_key)
        if _fail_ts is not None and (now_ts - _fail_ts) < _OPTION_CHAIN_NEG_TTL:
            return None

    try:
        from utils import NSEClient
        headers = {"Accept-Encoding": "gzip, deflate"}
        # 1. Fetch contract info to discover available expiry dates
        info_url = f"https://www.nseindia.com/api/option-chain-contract-info?symbol={clean_sym}"
        r_info = NSEClient.get(info_url, headers=headers, timeout=10)
        if r_info.status_code != 200:
            log_emit(log_cb, f"[OptionChain] NSE contract info returned status {r_info.status_code} for {clean_sym}")
            with _OPTION_CHAIN_CACHE_LOCK:
                _OPTION_CHAIN_FAIL_TS[cache_key] = time.time()
            return None
        info_json = r_info.json()
        expiries = info_json.get("expiryDates", [])
        if not expiries:
            log_emit(log_cb, f"[OptionChain] No active expiry dates returned for {clean_sym}")
            with _OPTION_CHAIN_CACHE_LOCK:
                _OPTION_CHAIN_FAIL_TS[cache_key] = time.time()
            return None
        target_expiry = expiry if (expiry and expiry in expiries) else expiries[0]

        # 2. Fetch chain for target expiry
        chain_type = "Indices" if clean_sym in ("NIFTY", "BANKNIFTY", "FINNIFTY", "MIDCPNIFTY") else "Equity"
        chain_url = f"https://www.nseindia.com/api/option-chain-v3?type={chain_type}&symbol={clean_sym}&expiry={target_expiry}"
        r_chain = NSEClient.get(chain_url, headers=headers, timeout=10)
        if r_chain.status_code != 200:
            log_emit(log_cb, f"[OptionChain] NSE option chain returned status {r_chain.status_code} for {clean_sym}")
            with _OPTION_CHAIN_CACHE_LOCK:
                _OPTION_CHAIN_FAIL_TS[cache_key] = time.time()
            return None
        payload = r_chain.json()
        records = payload.get("records", {})
        spot = float(records.get("underlyingValue", 0.0))
        data_items = records.get("data", [])
        if not data_items:
            return None
        # AUDIT-FIX (Round 22 — R22-3): a missing/zero underlying value previously
        # flowed through as spot_price=0.0 (and anchored the skew lookup at
        # strike[0]); refuse honestly instead of serving a broken surface.
        if spot <= 0:
            log_emit(log_cb, f"[OptionChain] NSE chain for {clean_sym} returned a non-positive underlying value ({spot}) — refusing to serve a broken surface.")
            with _OPTION_CHAIN_CACHE_LOCK:
                _OPTION_CHAIN_FAIL_TS[cache_key] = time.time()
            return None

        strikes, call_ois, put_ois, call_ivs, put_ivs = [], [], [], [], []
        for item in data_items:
            k = float(item.get("strikePrice", 0.0))
            ce = item.get("CE", {}) or {}
            pe = item.get("PE", {}) or {}
            strikes.append(k)
            call_ois.append(float(ce.get("openInterest", 0.0) or 0.0))
            put_ois.append(float(pe.get("openInterest", 0.0) or 0.0))
            call_ivs.append(float(ce.get("impliedVolatility", 0.0) or 0.0))
            put_ivs.append(float(pe.get("impliedVolatility", 0.0) or 0.0))

        s_arr = np.array(strikes)
        c_oi_arr = np.array(call_ois)
        p_oi_arr = np.array(put_ois)

        # Max Pain: strike S that minimizes writer loss = sum(max(0, S-K)*call_OI + max(0, K-S)*put_OI)
        losses = [float(np.sum(np.maximum(0.0, s - s_arr) * c_oi_arr + np.maximum(0.0, s_arr - s) * p_oi_arr)) for s in s_arr]
        max_pain = float(s_arr[np.argmin(losses)]) if len(losses) > 0 else spot

        tot_call_oi = float(np.sum(c_oi_arr))
        tot_put_oi = float(np.sum(p_oi_arr))
        pcr = round(tot_put_oi / tot_call_oi, 2) if tot_call_oi > 0 else None

        # AUDIT-FIX (Round 22 — R22-3): median chain IV is an IV LEVEL (not a
        # percentile — ranking today's IV against its own history needs a time
        # series of IV the snapshot does not contain). Key renamed accordingly.
        valid_ivs = [iv for iv in (call_ivs + put_ivs) if iv > 0.0]
        median_iv = round(float(np.median(valid_ivs)), 2) if valid_ivs else None

        # ±5% moneyness OTM skew (put IV at the 95% strike minus call IV at the
        # 105% strike). AUDIT-FIX (Round 22 — R22-3): previously labeled
        # "iv_skew_25d_delta" — it is a fixed-moneyness skew, not a strike
        # solved for a true 25-delta option; key renamed to match the math.
        otm_put_idx = int(np.argmin(np.abs(s_arr - spot * 0.95)))
        otm_call_idx = int(np.argmin(np.abs(s_arr - spot * 1.05)))
        skew = round(float(put_ivs[otm_put_idx] - call_ivs[otm_call_idx]), 2) if (otm_put_idx < len(put_ivs) and otm_call_idx < len(call_ivs)) else None

        # AUDIT-FIX (Round 23 — R23-1): per-strike rows are now part of the
        # payload (`chain_rows`) so downstream GEX / tail-hedge modules can
        # compute REAL strike-level gamma exposure and wire the live chain's
        # median IV + expiry into hedge deltas instead of policy-flat inputs.
        # Schema matches OptionsTailHedger.calculate_net_gamma_exposure's
        # expected frame (strikePrice / callOI / putOI, plus IVs for reuse).
        chain_rows = [
            {
                "strikePrice": float(k),
                "callOI": float(c_oi),
                "putOI": float(p_oi),
                "callIV": float(c_iv),
                "putIV": float(p_iv),
            }
            for k, c_oi, p_oi, c_iv, p_iv in zip(strikes, call_ois, put_ois, call_ivs, put_ivs)
        ]

        result = {
            "underlying": clean_sym,
            "expiry": target_expiry,
            # AUDIT-FIX (Round 25 — R25-2): the full list of live expiry dates
            # is echoed so multi-expiry GEX aggregation (the nearest N
            # expiries) can fetch each chain without re-discovering the
            # contract info — the single-expiry convention is a choice made
            # per call, not a data limitation.
            "expiry_dates": list(expiries),
            "spot_price": round(spot, 2),
            "max_pain_strike": round(max_pain, 2),
            "pc_ratio_oi": pcr,
            "median_iv": median_iv,
            "iv_skew_5pct_otm": skew,
            "total_call_oi": tot_call_oi,
            "total_put_oi": tot_put_oi,
            "chain_rows": chain_rows,
            "timestamp": records.get("timestamp", datetime.now().strftime("%d-%b-%Y %H:%M:%S")),
            "data_source": (f"Live NSE Option Chain Feed ({clean_sym} expiry: {target_expiry}); "
                            f"median_iv = median IV across listed strikes (level, not percentile); "
                            f"iv_skew_5pct_otm = put IV @ 95% spot − call IV @ 105% spot (fixed-moneyness skew, ~25-delta only by approximation); "
                            f"chain_rows = per-strike OI/IV rows for GEX & hedge input wiring")
        }
        with _OPTION_CHAIN_CACHE_LOCK:
            _OPTION_CHAIN_CACHE[cache_key] = (result, now_ts)
            _OPTION_CHAIN_FAIL_TS.pop(cache_key, None)
        log_emit(log_cb, f"[OptionChain] Successfully fetched {clean_sym} option chain: spot={spot:.1f}, max_pain={max_pain:.1f}, PCR={pcr}")
        return result
    except Exception as e:
        log_emit(log_cb, f"[OptionChain] Fetch failed for {symbol}: {e}", exc_info=True)
        try:
            with _OPTION_CHAIN_CACHE_LOCK:
                _OPTION_CHAIN_FAIL_TS[f"{str(symbol).replace('^', '').replace('.NS', '').replace('NSE:', '').strip().upper()}:{expiry or 'nearest'}"] = time.time()
        except Exception:
            pass
        return None


# Backward-compatibility alias for optimizer_compliance and derivatives modules
fetch_options_chain = fetch_nse_option_chain
# ────────────────────────────────────────────────────────────────────
# FUNC: fetch_nse_equity_last_prices
# ────────────────────────────────────────────────────────────────────
# AUDIT-FIX (Round 23 — R23-2): per-symbol live quote cache shared by the
# tax optimizer's mark refresh. 60s TTL — a tax panel refresh shouldn't
# hammer NSE on every poll, but marks older than a minute are stale.
_EQ_QUOTE_CACHE: dict = {}
_EQ_QUOTE_CACHE_LOCK = threading.Lock()


def fetch_nse_equity_last_prices(symbols, log_cb=None, max_symbols: int = 40) -> Dict[str, float]:
    """AUDIT-FIX (Round 23 — R23-2): best-effort live last-traded prices for
    NSE equity symbols via the quote-equity API (`priceInfo.lastPrice`).

    Purpose: the /api/tax_optimizer endpoint computed harvestable-loss
    estimates from the trade journal's `current_price` marks, which are only
    as fresh as the LAST update_live_prices call (possibly days old on an
    idle dashboard). This helper lets the endpoint refresh marks at request
    time. It is strictly best-effort:
      * returns {symbol: last_price} ONLY for symbols successfully quoted
        (unreachable/offline -> empty dict; the caller keeps last marks and
        DISCLOSES that they are stale instead of fabricating prices);
      * symbol keys are returned in the caller's ORIGINAL form (e.g.
        'RELIANCE.NS') so TradeJournalManager.update_live_prices can match
        its stored ticker keys exactly;
      * 60-second per-symbol cache so a polling UI does not rate-limit NSE;
      * hard cap max_symbols to bound latency on large baskets.
    """
    from utils import NSEClient  # local import to keep module import graph lean

    out: Dict[str, float] = {}
    seen_clean: Dict[str, str] = {}
    for raw in list(symbols)[:max_symbols]:
        raw_tk = str(raw).strip()
        if not raw_tk:
            continue
        clean_sym = raw_tk.replace(".NS", "").replace(".BO", "").strip().upper()
        if not clean_sym or clean_sym in seen_clean:
            continue
        seen_clean[clean_sym] = raw_tk
        now_ts = time.time()
        with _EQ_QUOTE_CACHE_LOCK:
            cached = _EQ_QUOTE_CACHE.get(clean_sym)
            if cached is not None and (now_ts - cached[1]) < 60.0:
                out[raw_tk] = cached[0]
                continue
        try:
            headers = {
                "Accept": "application/json",
                "Referer": f"https://www.nseindia.com/get-quotes/equity?symbol={clean_sym}",
            }
            resp = NSEClient.get(
                f"https://www.nseindia.com/api/quote-equity?symbol={clean_sym}",
                headers=headers, timeout=6,
            )
            if resp.status_code == 200:
                px = (resp.json() or {}).get("priceInfo", {}).get("lastPrice")
                if isinstance(px, (int, float)) and float(px) > 0:
                    px = float(px)
                    out[raw_tk] = px
                    with _EQ_QUOTE_CACHE_LOCK:
                        _EQ_QUOTE_CACHE[clean_sym] = (px, now_ts)
                    continue
            log_emit(log_cb, f"[QuoteRefresh] {clean_sym}: quote-equity status {getattr(resp, 'status_code', 'n/a')} — mark not refreshed")
        except Exception as _q_e:
            log_emit(log_cb, f"[QuoteRefresh] {clean_sym} failed: {_q_e}")
    if out:
        log_emit(log_cb, f"[QuoteRefresh] Live quotes refreshed for {len(out)}/{len(seen_clean)} symbol(s)")
    return out


# ────────────────────────────────────────────────────────────────────
# FUNC: fetch_equity_last_prices_multi_source
# ────────────────────────────────────────────────────────────────────
# AUDIT-FIX (Round 24 — R24-4): BSE-fallback + provenance/staleness layer.
# BSE quote results cached separately (300s TTL) so a polling tax panel
# neither re-hammers Yahoo nor re-serves indefinitely-stale marks.
_BSE_QUOTE_CACHE: dict = {}
_BSE_QUOTE_CACHE_LOCK = threading.Lock()
_BSE_QUOTE_CACHE_TTL = 300.0

# AUDIT-FIX (Round 25 — R25-4): middle-layer cache for Yahoo's NSE (`.NS`)
# quotes — same TTL discipline as the BSE layer.
_YF_NS_QUOTE_CACHE: Dict[str, tuple] = {}
_YF_NS_QUOTE_CACHE_LOCK = threading.Lock()
_YF_NS_QUOTE_CACHE_TTL = 300.0


def _yf_ticker_last_price(yahoo_symbol: str, log_cb=None):
    """Best-effort last price for a FULL Yahoo symbol via fast_info + a 1-day
    history probe. Returns (price, failure_reason) or (None, reason).

    AUDIT-FIX (Round 25 — R25-4): shared engine for the Yahoo legs of the
    layered equity quote fetcher (`.NS` NSE-via-Yahoo and `.BO` BSE) — one
    probing path, two labels, no duplicated logic.
    """
    try:
        import yfinance as yf
        tk = yf.Ticker(yahoo_symbol)
        info = tk.fast_info
        px = None
        for key in ("last_price", "lastPrice", "previous_close", "regularMarketPrice"):
            try:
                v = getattr(info, key, None) or (info.get(key) if hasattr(info, "get") else None)
                if isinstance(v, (int, float)) and float(v) > 0:
                    px = float(v)
                    break
            except Exception:
                continue
        if px is None:
            try:
                hist = tk.history(period="1d")
                if hist is not None and not hist.empty and "Close" in hist.columns:
                    v = float(hist["Close"].iloc[-1])
                    if v > 0:
                        px = v
            except Exception:
                px = None
        if px is not None:
            return px, None
        return None, f"no usable price for {yahoo_symbol}"
    except Exception as _yf_e:
        log_emit(log_cb, f"[QuoteRefresh] {yahoo_symbol} Yahoo probe failed: {_yf_e}")
        return None, f"Yahoo probe error ({type(_yf_e).__name__})"


def _bse_last_price_yfinance(clean_sym: str, log_cb=None):
    """Best-effort BSE (`.BO`) last price via yfinance fast_info.

    AUDIT-FIX (Round 24 — R24-4): symbols that are BSE-only / suspended on
    NSE previously degraded silently to the journal's last marks. This
    helper gives those tickers a REAL second source (Yahoo's BSE feed).
    Returns (price, source_label) or (None, failure_reason). Never raises.
    AUDIT-FIX (Round 25 — R25-4): now shares the generic Yahoo probing
    engine (_yf_ticker_last_price) with the new .NS middle layer.
    """
    px, _reason = _yf_ticker_last_price(f"{clean_sym}.BO", log_cb=log_cb)
    if px is not None:
        return px, "BSE (.BO) via yfinance"
    return None, "no usable BSE price"


def _nse_yahoo_last_price(clean_sym: str, log_cb=None):
    """Best-effort NSE (`.NS`) last price via Yahoo's NSE feed.

    AUDIT-FIX (Round 25 — R25-4): the R24 layered fetcher went straight
    from the DIRECT NSE quote-equity leg (which datacenter networks cannot
    reach — NSE blocks them, documented since R22) to the BSE `.BO` leg,
    so NSE-listed names degraded to the BSE price (or nothing) even though
    Yahoo serves the SAME NSE instruments under the `.NS` suffix. This
    middle layer quotes NSE-listed names through Yahoo's NSE feed BEFORE
    the BSE fallback, so the NSE price — not the BSE price — is used for
    NSE-listed names whenever the direct leg is unavailable. Returns
    (price, source_label) or (None, failure_reason). Never raises.
    """
    px, _reason = _yf_ticker_last_price(f"{clean_sym}.NS", log_cb=log_cb)
    if px is not None:
        return px, "NSE via Yahoo (.NS)"
    return None, "no usable NSE price (Yahoo)"


def fetch_equity_last_prices_multi_source(symbols, log_cb=None, max_symbols: int = 40) -> Dict[str, dict]:
    """AUDIT-FIX (Round 24 — R24-4): layered last-price fetcher with provenance.

    Layer 1: NSE quote-equity (same 60s cache as
    fetch_nse_equity_last_prices) — the freshest source for NSE-quoted names.
    Layer 2: for symbols NSE could not quote (BSE-only listings, suspended
    NSE tickers, NSE rate limits), a best-effort BSE `.BO` quote via
    yfinance (300s cache).

    AUDIT-FIX (Round 25 — R25-4): a genuine MIDDLE layer was inserted —
    Yahoo's NSE (`.NS`) feed, 300s cache — between the direct NSE leg and
    the BSE leg. The R24 two-layer design sent every NSE-missed symbol
    straight to the BSE price, which is the wrong primary source for
    NSE-listed names (different exchange, different price) and is ALSO the
    only option for BSE-only names; now NSE-listed symbols get their NSE
    price via Yahoo first and only fall through to BSE when Yahoo has no
    NSE quote (delisted-from-NSE, suspended, or BSE-only listings). Layer
    order: (1) direct NSE quote-equity → (2) Yahoo `.NS` (Yahoo's NSE
    feed — survives datacenter IP blocks) → (3) Yahoo `.BO` (BSE feed).

    Returns {original_symbol: {"price": float, "source": str,
    "fetched_at": epoch_seconds}} ONLY for symbols actually quoted by SOME
    source. Symbols quoted by neither layer are OMITTED — the caller keeps
    its last marks and DISCLOSES their staleness instead of inventing
    prices. This is the honest replacement for the R23-2 behavior where any
    non-NSE-quoted symbol silently degraded to days-old marks with no
    second source and no staleness measurement.
    """
    out: Dict[str, dict] = {}
    nse_prices = fetch_nse_equity_last_prices(symbols, log_cb=log_cb, max_symbols=max_symbols)
    now_ts = time.time()
    for raw_tk, px in (nse_prices or {}).items():
        out[str(raw_tk)] = {
            "price": float(px),
            "source": "NSE quote-equity (priceInfo.lastPrice)",
            "fetched_at": now_ts,
        }

    # Layers 2-3 only for symbols the direct NSE leg missed
    seen_clean: Dict[str, str] = {}
    for raw in list(symbols)[:max_symbols]:
        raw_tk = str(raw).strip()
        if not raw_tk:
            continue
        clean_sym = raw_tk.replace(".NS", "").replace(".BO", "").strip().upper()
        if not clean_sym or clean_sym in seen_clean:
            continue
        seen_clean[clean_sym] = raw_tk
    nse_clean = {str(k).replace(".NS", "").replace(".BO", "").strip().upper() for k in nse_prices}
    for clean_sym, raw_tk in seen_clean.items():
        if clean_sym in nse_clean:
            continue
        # Layer 2: Yahoo's NSE (.NS) feed — cached, best-effort
        with _YF_NS_QUOTE_CACHE_LOCK:
            cached = _YF_NS_QUOTE_CACHE.get(clean_sym)
            if cached is not None and (time.time() - cached[2]) < _YF_NS_QUOTE_CACHE_TTL:
                out[raw_tk] = {"price": cached[0], "source": cached[1], "fetched_at": cached[2]}
                continue
        px, src = _nse_yahoo_last_price(clean_sym, log_cb=log_cb)
        if px is not None:
            ts = time.time()
            out[raw_tk] = {"price": float(px), "source": src, "fetched_at": ts}
            with _YF_NS_QUOTE_CACHE_LOCK:
                _YF_NS_QUOTE_CACHE[clean_sym] = (float(px), src, ts)
            log_emit(log_cb, f"[QuoteRefresh] {clean_sym}: direct NSE unavailable — quoted via {src} at {px:.2f}")
            continue
        # Layer 3: BSE (.BO) fallback
        with _BSE_QUOTE_CACHE_LOCK:
            cached = _BSE_QUOTE_CACHE.get(clean_sym)
            if cached is not None and (time.time() - cached[2]) < _BSE_QUOTE_CACHE_TTL:
                out[raw_tk] = {"price": cached[0], "source": cached[1], "fetched_at": cached[2]}
                continue
        px, src = _bse_last_price_yfinance(clean_sym, log_cb=log_cb)
        if px is not None:
            ts = time.time()
            out[raw_tk] = {"price": float(px), "source": src, "fetched_at": ts}
            with _BSE_QUOTE_CACHE_LOCK:
                _BSE_QUOTE_CACHE[clean_sym] = (float(px), src, ts)
            log_emit(log_cb, f"[QuoteRefresh] {clean_sym}: NSE unavailable (direct and Yahoo .NS) — quoted via {src} at {px:.2f}")
    return out



# ────────────────────────────────────────────────────────────────────
# FUNC: fetch_fii_dii_flow
# ────────────────────────────────────────────────────────────────────
def fetch_fii_dii_flow(log_cb=None) -> dict:
    """
    Fetch 10-day FII/DII net cash flow from NSE.
    Returns dict with keys: fii_10d_net (INR Cr), dii_10d_net (INR Cr),
    fii_z_score (z-score vs 60-day history), flow_signal (Bull/Bear/Neutral).
    Uses cached data — refreshes once daily, reuses last valid observation on throttle.
    """
    cache = read_json_cache(FII_DII_CACHE_PATH, {})
    today = datetime.now().strftime("%Y-%m-%d")
    if cache.get("date") == today and cache.get("result"):
        log_emit(log_cb, f"[FII/DII] Cache hit: signal={cache['result'].get('flow_signal')}")
        return cache["result"]

    # AUDIT-FIX (Round 3, P2-2): replace silent constant fallback
    last_valid_result = cache.get("result")
    result = {"fii_10d_net": np.nan, "dii_10d_net": np.nan,
              "fii_z_score": float('nan'), "flow_signal": None}
    fetch_ok = False
    headers = {"X-Requested-With": "XMLHttpRequest"}

    try:
        resp = NSEClient.get(NSE_FII_DII_URL, headers=headers, timeout=15)
        if resp.status_code == 200:
            records = []
            try:
                data = resp.json()
                records = data if isinstance(data, list) else data.get("data", [])
            except ValueError:
                # JSON decode notice — try Moneycontrol or HTML table fallback parse silently
                try:
                    dfs = pd.read_html(resp.text)
                    if dfs:
                        records = dfs[0].to_dict(orient="records")
                except Exception:
                    records = []


            fii_flows, dii_flows = [], []
            for rec in records[:60]:
                try:
                    cat = str(rec.get("category", "")).upper()
                    net_str = str(rec.get("netValue", rec.get("fii_net_buy_sell", rec.get("FII Net", "0")))).replace(",", "").strip()
                    val = float(net_str or 0.0)
                    if "FII" in cat or "FPI" in cat:
                        fii_flows.append(val)
                    elif "DII" in cat:
                        dii_flows.append(val)
                    elif "fii_net_buy_sell" in rec or "FII Net" in rec:
                        fii_net = float(str(rec.get("fii_net_buy_sell", rec.get("FII Net", "0"))).replace(",", "") or 0)
                        dii_net = float(str(rec.get("dii_net_buy_sell", rec.get("DII Net", "0"))).replace(",", "") or 0)
                        fii_flows.append(fii_net)
                        dii_flows.append(dii_net)
                except Exception as _eloop:
                    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception in %s", "Exception", exc_info=True)  # noqa: E501
                    continue

            if len(fii_flows) > 0 or len(dii_flows) > 0:
                fii_10d = sum(fii_flows[:10]) if fii_flows else 0.0
                dii_10d = sum(dii_flows[:10]) if dii_flows else 0.0
                fii_arr = np.array(fii_flows) if fii_flows else np.array([0.0])
                fii_z = float((fii_10d - np.mean(fii_arr)) / (np.std(fii_arr) + 1e-9)) if len(fii_arr) > 1 else (0.5 if fii_10d > 0 else (-0.5 if fii_10d < 0 else 0.0))
                signal = "Bull" if fii_10d > 500 else ("Bear" if fii_10d < -500 else "Neutral")
                result = {"fii_10d_net": fii_10d, "dii_10d_net": dii_10d,
                          "fii_z_score": round(fii_z, 3), "flow_signal": signal}
                fetch_ok = True
                log_emit(log_cb, f"[FII/DII] Latest FII net: ₹{fii_10d:,.0f}Cr | DII net: ₹{dii_10d:,.0f}Cr | Signal: {signal}")
            else:
                log_emit(log_cb, f"[FII/DII] Fetch notice: got {len(records)} records.")
        else:
            log_emit(log_cb, f"[FII/DII] Fetch notice: HTTP {resp.status_code} from NSE.")
    except Exception as e:
        log_emit(log_cb, f"[FII/DII] Fetch notice: {e}.", exc_info=True)

    if fetch_ok:
        write_json_cache(FII_DII_CACHE_PATH, {"date": today, "result": result})
    elif last_valid_result:
        log_emit(log_cb, f"[FII/DII] Live fetch throttled - reusing last valid cached flow: signal={last_valid_result.get('flow_signal')}")
        result = last_valid_result
    else:
        # AUDIT-FIX (Round 3, P2-2): return NaN/None sentinel, do not cache
        log_emit(log_cb, "[FII/DII] Live fetch failed - returning NaN/None sentinel (no cache write).")

    return result


# ── 52-Week High Proximity Signal ────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: fetch_sebi_cap_categories
# ────────────────────────────────────────────────────────────────────
def fetch_sebi_cap_categories(log_cb=None) -> dict:
    """
    Return {ticker: "large"|"mid"|"small"} SEBI market-cap classification.

    AUDIT-FIX (Round 5 P2-4): Removed the implicit yfinance dependency for
    the SEBI cap refresh. The previous version relied on the JSON cache
    file `LARGE_MID_SMALL_CACHE_PATH` being populated by a separate
    refresh routine that itself called `yf.Ticker(t).info["marketCap"]`
    in a 120-serial loop — every production run therefore hard-required
    `pip install yfinance` to load data_layer at all. The new version
    resolves cap categories through THREE layered providers, in priority
    order:

        1. Local CSV bundle `sebi_cap_categories.csv` shipped with the
           repo at `data/sebi_cap_categories.csv`. This file is a static
           snapshot of the official SEBI AMFI classification (re-issued
           every 6 months by SEBI). Updates require no internet.
        2. JSON cache (`LARGE_MID_SMALL_CACHE_PATH`) — written by the
           nightly refresher if it runs. Age limit: 14 days (was 7).
        3. Empty dict — SEBI constraints silently bypassed (same
           fail-open behaviour as before, but now reachable WITHOUT
           yfinance installed).

    Returns:
        dict: {ticker: "large"|"mid"|"small"} for every ticker in the
        local CSV (or cache, whichever is fresher).
    """
    # Layer 2: existing JSON cache
    cache = read_json_cache(LARGE_MID_SMALL_CACHE_PATH, {})
    cache_age_days = (time.time() - cache.get("timestamp", 0)) / 86400
    if cache_age_days < 14 and cache.get("data"):
        return cache["data"]

    # Layer 1: local CSV bundle (shipped with the repo, no yfinance needed)
    try:
        from pathlib import Path as _P
        _local_csv = _P(__file__).resolve().parent / "data" / "sebi_cap_categories.csv"
        if _local_csv.exists():
            import csv as _csv
            out = {}
            with open(_local_csv, "r", encoding="utf-8") as fh:
                reader = _csv.DictReader(fh)
                for row in reader:
                    t = (row.get("ticker") or row.get("symbol") or "").strip().upper()
                    cat = (row.get("category") or row.get("cap") or "").strip().lower()
                    if t and cat in ("large", "mid", "small"):
                        out[f"{t}.NS"] = cat
                        out[t] = cat
            if out:
                # Mirror to JSON cache for fast subsequent loads.
                try:
                    # AUDIT-FIX (Round 49 — R49-2): atomic cache write. The
                    # manual open(w)+json.dump bypassed this module's own
                    # write_json_cache helper (atomic tmp+replace, Phase 4.4
                    # / R6 C-P2-4) — a crash mid-dump left a truncated JSON
                    # cache whose failed read silently skipped the layer and
                    # degraded the SEBI category gates to the static CSV /
                    # fail-open path.
                    write_json_cache(LARGE_MID_SMALL_CACHE_PATH,
                                     {"timestamp": time.time(), "data": out})
                except Exception:
                    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                return out
    except Exception:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501

    # Layer 3: fail-open — bypass SEBI constraints, log notice.
    log_emit(log_cb, "[SEBI-Caps] No local CSV bundle, no fresh JSON cache; "
                    "SEBI category constraints will be bypassed (fail-open).")
    return {}


# ── Sector Momentum Filter ─────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: compute_sector_momentum
# ────────────────────────────────────────────────────────────────────
def compute_sector_momentum(returns: pd.DataFrame, sectors: dict,
                             lookback: int = 126) -> dict:
    """
    Compute sector-level momentum: average return of all stocks in each sector
    over the lookback window. Returns {sector: avg_return}.
    """
    sector_returns = {}
    for ticker, sector in sectors.items():
        if sector in ("Unknown", "N/A", None, "") or ticker not in returns.columns:
            continue
        r = float(returns[ticker].tail(lookback).mean()) if len(returns[ticker].dropna()) >= lookback // 2 else np.nan
        sector_returns.setdefault(sector, []).append(r)
    res = {}
    for sec, vals in sector_returns.items():
        finite_vals = [v for v in vals if pd.notna(v)]
        if finite_vals:
            res[sec] = float(np.mean(finite_vals))
    return res




# ────────────────────────────────────────────────────────────────────
# FUNC: apply_sector_momentum_filter
# ────────────────────────────────────────────────────────────────────
def apply_sector_momentum_filter(signal_df: pd.DataFrame, sector_momentum: dict,
                                  sectors: dict, log_cb=None,
                                  benchmark_mom: float = None) -> pd.DataFrame:
    """
    Bug 33 fix: filter on RELATIVE sector momentum vs benchmark, not absolute zero.
    Absolute threshold=0 zeroes every stock in a broad correction since all sectors
    go negative. Relative threshold passes sectors beating the benchmark.
    """
    if not sector_momentum:
        return signal_df
    _bench33    = benchmark_mom if benchmark_mom is not None else 0.0
    _rel_thresh = -0.05   # sector must beat benchmark by at least -5%
    positive_sectors = {s for s, m in sector_momentum.items() if (m - _bench33) > _rel_thresh}
    negative_sectors  = {s for s, m in sector_momentum.items() if (m - _bench33) <= _rel_thresh}
    if not positive_sectors:
        log_emit(log_cb, "[SectorMom] All sectors below relative threshold — filter bypassed")
        return signal_df
    before = len(signal_df)
    mask = [sectors.get(t, "Unknown") in positive_sectors or
            sectors.get(t, "Unknown") in ("Unknown", "N/A", None, "")
            for t in signal_df.index]
    filtered = signal_df[mask]
    log_emit(log_cb, f"[SectorMom] Removed {before-len(filtered)} stocks from "
                     f"{len(negative_sectors)} underperforming sectors | Remaining: {len(filtered)}")
    return filtered if len(filtered) >= 10 else signal_df


# ── Parallel SA Ensemble ──────────────────────────────────────────────────────



# ────────────────────────────────────────────────────────────────────
# FUNC: solve_qubo_ensemble
# ────────────────────────────────────────────────────────────────────
def solve_qubo_ensemble(q: dict, signal_df, sectors, cfg: dict,
                         warm_start: list = None, log_cb=None):
    """
    Run N parallel SA instances with different seeds, return best (lowest energy) result.
    v16: default 5 runs — reduces energy variance ~40% vs single run.
    Also supports QUBO warm starting from previous portfolio.
    """
    # L1-fix: docstring moved before any code so it actually binds to __doc__.
    from optimizer import solve_qubo
    mode = cfg.get("OPTIMIZER_MODE", "Hybrid")
    if mode in ("Greedy", "MIP"):
        return solve_qubo(q, signal_df, sectors, cfg, log_cb=log_cb)
    n_runs = int(cfg.get("SA_ENSEMBLE_RUNS", 5))
    if n_runs <= 1:
        return solve_qubo(q, signal_df, sectors, cfg, log_cb=log_cb)
    if neal is None or dimod is None:
        missing = []
        if neal is None:
            missing.append("dwave-neal")
        if dimod is None:
            missing.append("dimod")
        err = (
            "QUBO ensemble solving requires "
            + " and ".join(missing)
            + ". Install project requirements or run with SA_ENSEMBLE_RUNS=1."
        )
        log_emit(log_cb, f"[QUBO Ensemble] ❌ {err}")
        raise ImportError(err)

    # AUDIT-FIX (defect #20, quantum honesty): the prior code hardcoded
    # neal.SimulatedAnnealingSampler() here, which meant the real D-Wave QPU
    # path in utils._get_quantum_sampler() was unreachable from the live
    # pipeline (where SA_ENSEMBLE_RUNS defaults to 8). We now ask
    # _get_quantum_sampler for the best available sampler — when
    # DWAVE_API_TOKEN is configured AND SA_ENSEMBLE_RUNS == 1, it returns a
    # real D-Wave sampler (DWaveSampler/LeapHybridSampler); otherwise it
    # returns the CPU SA sampler with an honest log line. The actual sampler
    # label is returned alongside the solve so the orchestrator's "quantum"
    # claim is verifiable from the log.
    from utils import _get_quantum_sampler
    sampler, sampler_label = _get_quantum_sampler(log_cb=log_cb)
    bqm = dimod.BinaryQuadraticModel.from_qubo(q)

    # Live run: use full NUM_READS/NUM_SWEEPS. WFO: fast_cfg already caps these.
    # v17.35-fix: cap scale_factor at 2.0 to prevent quadratic cost explosion.
    # Without cap: n_vars=150 => scale=3.0 => num_reads AND num_sweeps both 3x
    # => total SA ops = 9x baseline PER RUN x n_runs.
    # Root cause of the alternating ~35 min / ~72 min pattern when signal_df
    # candidate count varies day-to-day due to prescreen + ZeroScoreGuard pruning.
    n_vars = len(bqm.variables)
    scale_factor = min(max(1.0, n_vars / 50.0), 2.0)  # cap at 2x to bound SA cost
    num_reads  = int(int(cfg.get("NUM_READS",  1200)) * scale_factor)
    num_sweeps = int(int(cfg.get("NUM_SWEEPS", 1500)) * scale_factor)
    log_emit(log_cb, f"[SA Ensemble] n_vars={n_vars} | scale={scale_factor:.1f}x | reads={num_reads} | sweeps={num_sweeps} | runs={n_runs}")
    if cfg.get("_WFO_STEP", False):
        num_reads = min(num_reads, int(cfg.get("WFO_MAX_READS", 400)))
        num_sweeps = min(num_sweeps, int(cfg.get("WFO_MAX_SWEEPS", 500)))

    # Build initial states for warm starting
    initial_states = None
    if cfg.get("USE_QUBO_WARM_START", True) and warm_start:
        variables = list(bqm.variables)
        state = {v: (1 if v in warm_start else 0) for v in variables}
        # Bug 28 fix: [state]*n_runs = same dict ref — no SA ensemble diversity.
        import copy as _cp28, random as _rnd28
        _ks28 = list(state.keys()) if state else []
        initial_states = []
        for _ri28 in range(n_runs):
            _s28 = _cp28.deepcopy(state)
            if _ks28 and _ri28 > 0:
                for _f28 in _rnd28.sample(_ks28, min(2, len(_ks28))):
                    _s28[_f28] = 1 - _s28.get(_f28, 0)
            initial_states.append(_s28)

    best_response, best_energy = None, float("inf")
    run_results = []

    # v17.3: diverse sweep schedules — prevents all runs converging to same local minimum
    _sched = [num_sweeps,
              int(num_sweeps * 0.60), int(num_sweeps * 1.50),
              int(num_sweeps * 0.80), int(num_sweeps * 1.20)]

    base_seed = int(cfg.get("SEED", 42))

    def _run_sa(seed_idx):
        _sw = _sched[seed_idx % len(_sched)]
        run_seed = base_seed + seed_idx * 97
        # AUDIT-FIX (defect #20): real D-Wave samplers don't accept neal's
        # num_sweeps/seed kwargs. Dispatch by sampler type so the live QPU
        # path doesn't crash on the first sample call.
        try:
            if sampler_label == "LeapHybridSampler":
                # LeapHybridSampler takes time_limit in seconds, not num_reads
                time_limit = float(cfg.get("LEAP_TIME_LIMIT_SEC", 5))
                return sampler.sample(bqm, time_limit=time_limit)
            elif sampler_label == "DWaveSampler":
                # QPU sampler accepts num_reads and chain_strength
                return sampler.sample(bqm, num_reads=num_reads, chain_strength=float(cfg.get("CHAIN_STRENGTH", 1.5)))
            else:
                kwargs = {"num_reads": num_reads, "num_sweeps": _sw, "seed": run_seed}
                if initial_states is not None:
                    kwargs["initial_states"] = [initial_states[seed_idx % len(initial_states)]]
                return sampler.sample(bqm, **kwargs)
        except Exception as _e:
            # Fallback: try the simplest sampler.sample signature that all
            # dimod-compatible samplers accept.
            try:
                return sampler.sample(bqm, num_reads=num_reads)
            except Exception:
                # Last-resort fallback for samplers that only take the BQM
                return sampler.sample(bqm)

    # v17.36-fix: Sequential ensemble execution instead of ThreadPoolExecutor.
    # dwave-neal Cython sampler holds the Python GIL during annealing.
    # Launching ThreadPoolExecutor threads inside parallel ProfileWorker threads
    # caused severe GIL lock thrashing (36 concurrent threads fighting for GIL),
    # slowing SA solves down from ~11s to 2397s (40 minutes!). Sequential execution
    # runs in pure C speed without GIL lock contention.
    for seed in range(n_runs):
        try:
            resp = _run_sa(seed)
            energy = float(resp.first.energy)
            run_results.append((energy, resp))
            if energy < best_energy:
                best_energy = energy
                best_response = resp
        except Exception as _eloop:
            archlog.debug("loop skip: %s", _eloop, exc_info=True)
            continue

    if best_response is None:
        return solve_qubo(q, signal_df, sectors, cfg, log_cb=log_cb)

    # Decode best response
    sample = best_response.first.sample
    raw_selected = [v for v, val in sample.items() if val == 1]
    # AUDIT-FIX (defect #20): the prior label "SA-Ensemble×N" masked which
    # sampler actually produced the result. The label now surfaces the real
    # sampler identity (LeapHybridSampler / DWaveSampler / SimulatedAnnealing)
    # so the operator (and the audit) can verify whether "quantum" is the
    # real QPU or a CPU fallback.
    if sampler_label in ("LeapHybridSampler", "DWaveSampler"):
        log_emit(log_cb, f"[QPU Ensemble] Sampler={sampler_label} | {len(run_results)}/{n_runs} runs | "
                         f"Best energy: {best_energy:.4f} | Selected raw: {len(raw_selected)}")
        solver_tag = f"QPU-{sampler_label}×{len(run_results)}"
    else:
        log_emit(log_cb, f"[SA Ensemble] Sampler={sampler_label} | {len(run_results)}/{n_runs} runs | "
                         f"Best energy: {best_energy:.4f} | Selected raw: {len(raw_selected)}")
        solver_tag = f"SA-Ensemble×{len(run_results)}"

    # Repair and improve (enforces exact K_STOCKS and sector caps)
    all_stocks = list(signal_df.index)
    from utils import repair_selection, local_search_improve
    repaired = repair_selection(raw_selected, all_stocks, q, signal_df, sectors, cfg)
    improved, final_energy = local_search_improve(repaired, all_stocks, q, signal_df, sectors, cfg)

    return improved, final_energy, solver_tag


# ── Corporate Actions Filter ──────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: fetch_corp_actions_blackout
# ────────────────────────────────────────────────────────────────────
def fetch_corp_actions_blackout(tickers: list, blackout_days: int = 3,
                                 log_cb=None) -> set:
    """
    Fetch NSE corporate actions (ex-div, bonus, split, rights) and return
    set of tickers with a corporate action within ±blackout_days of today.
    Price gaps corrupt momentum signals — exclude these during rebalance.
    """
    cache = read_json_cache(CORP_ACTIONS_CACHE_PATH, {})
    today_str = datetime.now().strftime("%Y-%m-%d")
    if cache.get("date") == today_str and cache.get("blocked"):
        blocked = set(cache["blocked"])
        log_emit(log_cb, f"[CorpActions] Cache hit: {len(blocked)} tickers near corporate action")
        return blocked

    blocked = set()
    today = pd.Timestamp.now().normalize()
    window_start = today - pd.Timedelta(days=blackout_days)
    window_end   = today + pd.Timedelta(days=blackout_days)
    headers = {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "en-US,en;q=0.9",
        # Explicit gzip-only to prevent Brotli/Zstd responses that requests cannot
        # auto-decompress. When Accept-Encoding is absent, Akamai may choose br/zstd
        # and omit Content-Encoding — giving requests raw compressed binary that lands
        # in resp.content as unreadable bytes (the 'PtT=]%...' garbled preview).
        "Accept-Encoding": "gzip, deflate",
        "Referer": "https://www.nseindia.com/companies-listing/corporate-filings-corporate-actions"
    }

    try:
        # Session warmup: visit the exact page the API uses as its Referer so Akamai
        # sets the right session cookie. Warming only the homepage is insufficient.
        _ca_warmup_urls = [
            "https://www.nseindia.com/companies-listing/corporate-filings-corporate-actions",
        ]
        for _wu in _ca_warmup_urls:
            try:
                NSEClient.get(_wu, headers={"Accept": "text/html,*/*"}, timeout=8)
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                pass
        url = "https://www.nseindia.com/api/corporates-corporateActions?index=equities"
        resp = NSEClient.get(url, headers=headers, timeout=15)
        if resp.status_code == 200:
            raw = resp.content

            # ── Robust multi-format decompression ─────────────────────────
            # requests auto-decompresses gzip/deflate ONLY when Content-Encoding
            # header is present. Akamai sometimes sends compressed bytes without
            # the header — so resp.content is raw compressed binary.
            # Try each format in order; stop at the first that produces valid text.
            if raw:
                import gzip as _gzip, zlib as _zlib

                def _try_decompress(data: bytes) -> bytes:
                    # 1. gzip magic bytes
                    if data[:2] == b'\x1f\x8b':
                        try:
                            return _gzip.decompress(data)
                        except Exception:
                            import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                            pass
                    # 2. zlib/deflate (wbits=47 accepts both zlib and gzip wrappers)
                    try:
                        return _zlib.decompress(data, 47)
                    except Exception:
                        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                        pass
                    # 3. raw deflate (no zlib wrapper)
                    try:
                        return _zlib.decompress(data, -15)
                    except Exception:
                        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                        pass
                    # 4. Brotli (optional — only if package installed)
                    try:
                        import brotli as _brotli  # type: ignore[import]
                        return _brotli.decompress(data)
                    except Exception:
                        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                        pass
                    # Nothing worked — return original
                    return data

                decompressed = _try_decompress(raw)
                if decompressed is not raw:
                    raw = decompressed
                    log_emit(log_cb, "[CorpActions] Decompressed response body successfully")

            resp_text = raw.decode("utf-8", errors="ignore").strip() if raw else ""
            # Detect HTML response (session expired / Cloudflare challenge)
            if resp_text.lstrip().startswith("<"):
                log_emit(log_cb, "[CorpActions] HTML response received (session issue) — skipping filter.")
                return blocked
            if not resp_text:
                log_emit(log_cb, "[CorpActions] Empty response from NSE API.")
            elif not (resp_text.startswith("[") or resp_text.startswith("{")):
                preview = repr(resp_text[:80])  # repr() shows \xNN escapes, not garbled Unicode
                log_emit(log_cb, f"[CorpActions] Non-JSON response after decompression (preview: {preview})")
            else:
                try:
                    import json
                    records = json.loads(resp_text)
                except Exception as json_ex:
                    log_emit(log_cb, f"[CorpActions] JSON parse error: {json_ex}", exc_info=True)
                    records = None

                if isinstance(records, list):
                    for record in records:
                        try:
                            ex_date_str = record.get("exDate")
                            if ex_date_str and ex_date_str != "-":
                                ex_date = pd.to_datetime(ex_date_str, format="%d-%b-%Y", errors="coerce")
                                if pd.notna(ex_date) and window_start <= ex_date <= window_end:
                                    sym = record.get("symbol")
                                    if sym:
                                        blocked.add(f"{sym.strip().upper()}.NS")
                        except Exception as _eloop:
                            archlog.debug("loop skip: %s", _eloop, exc_info=True)
                            continue
        else:
            log_emit(log_cb, f"[CorpActions] HTTP {resp.status_code} error from NSE API.")
            # H4-fix: don't fall through to write_json_cache with an empty blocked set —
            # caching an empty set would block no tickers for the entire day after a
            # transient HTTP failure.
            return blocked
    except Exception as e:
        log_emit(log_cb, f"[CorpActions] Fetch failed: {e}. Skipping filter.", exc_info=True)
        return blocked

    write_json_cache(CORP_ACTIONS_CACHE_PATH, {"date": today_str, "blocked": list(blocked)})
    if blocked:
        log_emit(log_cb, f"[CorpActions] {len(blocked)} tickers near corporate action — excluded")
    return blocked


# ── Screener.in Fundamental Quality Score ────────────────────────────────────



# ────────────────────────────────────────────────────────────────────
# FUNC: _fetch_fundamentals_live
# ────────────────────────────────────────────────────────────────────
def _fetch_fundamentals_live(tickers: list, log_cb=None) -> dict:
    """Fetch fundamental metrics live from yfinance when local SQLite DB is unavailable.
    Returns best-effort data; fields default to 0.0 on any error rather than propagating NaN."""
    # AUDIT-FIX (Round 6, C-P1-1): this function previously did a HARD
    # `import yfinance as yf` at its top — an import whose binding is never
    # used (all fetching goes through the lazy _get_yf() accessor below) —
    # which ImportError-crashed `fetch_fundamentals` and the live optimizer
    # run (USE_FUNDAMENTALS=True default) on every fresh install without
    # yfinance, and made the _DATA_PROVIDER shortcut below unreachable.
    # The lazy accessor is the single yfinance entry point now.
    # ── Provider shortcut: skip raw yfinance if abstraction layer is active ──
    if _DATA_PROVIDER is not None:
        out: dict = {}
        for _t in tickers:
            try:
                out[_t] = _DATA_PROVIDER.get_fundamentals(_t)
            except Exception as _e:
                out[_t] = {}
        return out
    result = {}
    _KEY_MAP = {
        "returnOnEquity":    "roe",
        "debtToEquity":      "de_ratio",
        "revenueGrowth":     "rev_growth",
        "trailingPE":        "pe_ratio",
        "forwardPE":         "pe_ratio",   # fallback if trailing absent
    }
    import random as _frand
    _THROTTLE_KEYWORDS = ("rate limit", "too many", "429", "unauthorized", "invalid crumb")
    if len(tickers) > 50:
        log_emit(log_cb, f"[Fundamentals] Live fetch for {len(tickers)} tickers — "
                         "pacing requests to avoid Yahoo rate-limit.")
    # BUG-DL2 FIX: time.sleep on the Qt main thread freezes the UI for the entire
    # sleep duration. Only sleep when running in a background worker thread.
    import threading as _threading
    _is_main_thread = (_threading.current_thread() is _threading.main_thread())
    def _safe_sleep(secs: float):
        if not _is_main_thread:
            time.sleep(secs)
        # On main thread: skip sleep, accept rate-limit risk.
        # Fundamentals are cached daily so this path runs at most once per session.

    # AUDIT-FIX Round 7 P2-4: yfinance lazy-loaded via _get_yf()
    _yf_lazy_bulk = _get_yf()
    if _yf_lazy_bulk is None:
        # AUDIT-FIX (Round 6, C-P1-1): this is a dict-returning function —
        # returning a DataFrame here violated the type contract and crashed
        # callers iterating `.items()`. Return a neutral per-ticker dict of
        # empty records instead (same shape as the per-ticker failure path).
        return {t: {"roe": 0.0, "de_ratio": 0.0, "rev_growth": 0.0, "pe_ratio": 0.0, "sector": ""} for t in tickers}
    for _idx, t in enumerate(tickers):
        if _idx > 0:
            _base = 1.8 if len(tickers) <= 20 else 2.5
            _safe_sleep(_base + _frand.uniform(0.3, 1.0))
        _last_exc = None
        for _retry in range(3):
            try:
                info = _yf_lazy_bulk.Ticker(t).info
                row = {"roe": 0.0, "de_ratio": 0.0, "rev_growth": 0.0, "pe_ratio": 0.0}
                for src_key, dst_key in _KEY_MAP.items():
                    val = info.get(src_key)
                    if val is not None and isinstance(val, (int, float)) and float(val) == float(val):
                        if dst_key == "de_ratio" and val > 0:
                            row[dst_key] = float(val)
                        elif dst_key == "pe_ratio" and val > 0 and row["pe_ratio"] == 0.0:
                            row[dst_key] = float(val)
                        elif dst_key not in ("de_ratio", "pe_ratio"):
                            row[dst_key] = float(val)
                result[t] = row
                _last_exc = None
                break
            except Exception as e:
                _last_exc = e
                _em = str(e).lower()
                _is_throttle = any(k in _em for k in _THROTTLE_KEYWORDS)
                if _retry < 2:
                    _backoff = (2.0 ** (_retry + 1)) * (3.0 if _is_throttle else 1.0)
                    _backoff += _frand.uniform(0.5, 1.5)
                    log_emit(log_cb, f"[Fundamentals] Retry {_retry+1}/3 for {t} "
                                     f"(backoff {_backoff:.1f}s): {e}")
                    _safe_sleep(_backoff)
        if _last_exc is not None:
            log_emit(log_cb, f"[Fundamentals] Gave up on {t} after 3 retries: {_last_exc}")
            # AUDIT-FIX (Round 3, P2-2): return NaN sentinels, not 0.0
            result[t] = {"roe": float('nan'), "de_ratio": float('nan'),
                         "rev_growth": float('nan'), "pe_ratio": float('nan')}
    return result




def _ensure_pit_db(db_path, log_cb=None) -> bool:
    """Ensure fundamentals_history.db SQLite DB exists and is seeded with cached fundamentals."""
    import sqlite3
    try:
        db_existed = db_path.exists()
        conn = sqlite3.connect(str(db_path))
        with conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS fundamentals (
                    ticker TEXT NOT NULL,
                    publish_date TEXT NOT NULL,
                    roe REAL,
                    de_ratio REAL,
                    rev_growth REAL,
                    pe_ratio REAL,
                    PRIMARY KEY (ticker, publish_date)
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS corporate_actions (
                    ticker TEXT NOT NULL,
                    ex_date TEXT,
                    type TEXT,
                    ratio REAL,
                    amount REAL,
                    publish_date TEXT NOT NULL,
                    PRIMARY KEY (ticker, publish_date, type)
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS constituent_history (
                    ticker TEXT NOT NULL,
                    join_date TEXT NOT NULL,
                    leave_date TEXT,
                    PRIMARY KEY (ticker, join_date)
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS quarterly_results (
                    ticker TEXT NOT NULL,
                    sector TEXT,
                    rev_act REAL,
                    rev_est REAL,
                    pat_act REAL,
                    pat_est REAL,
                    rev_beat INTEGER,
                    pat_beat INTEGER,
                    PRIMARY KEY (ticker)
                )
            """)

            # If empty, seed from fundamentals_cache.json
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) FROM fundamentals")
            row_count = cur.fetchone()[0]
            if row_count == 0:
                cache_path = RUNTIME_DIR / "fundamentals_cache.json"
                # R34-6: the Round 33 upload had inserted a "deterministic hermetic
                # fallback" here that SEEDED FABRICATED fundamentals (invented
                # ROE/DE/rev-growth/PE for RELIANCE/TCS/INFY/HDFCBANK/COALINDIA)
                # into the point-in-time DB whenever no scrape cache existed.
                # That violates the project's "per-ticker failures reported,
                # never invented" doctrine (Rounds 22-32): a clean seat must get
                # an honestly EMPTY fundamentals table, not synthetic financials
                # that then flow into z_roe / z_de_inv / z_pe_inv factors as if
                # they were measured. Removed — only the real cache (produced by
                # the live NSE scrape) seeds the DB. (The f_cache = {} init,
                # which fixed a latent NameError when the cache file is absent,
                # is retained.)
                f_cache = {}
                if cache_path.exists():
                    f_cache = read_json_cache(cache_path, {})
                today_str = datetime.now().strftime("%Y-%m-%d")
                rows_to_insert = []
                for sym, data in f_cache.items():
                    if isinstance(data, dict):
                        clean_sym = sym.replace(".NS", "").strip().upper()
                        rows_to_insert.append((
                            clean_sym,
                            today_str,
                            float(data.get("roe", 0.0) or 0.0),
                            float(data.get("de_ratio", 0.0) or 0.0),
                            float(data.get("rev_growth", 0.0) or 0.0),
                            float(data.get("pe_ratio", 0.0) or 0.0),
                        ))
                if rows_to_insert:
                    conn.executemany("""
                        INSERT OR REPLACE INTO fundamentals
                        (ticker, publish_date, roe, de_ratio, rev_growth, pe_ratio)
                        VALUES (?, ?, ?, ?, ?, ?)
                    """, rows_to_insert)
                    if log_cb:
                        log_cb(f"[Fundamentals] Seeded local PiT DB with {len(rows_to_insert)} tickers from cache.")

            # If constituent_history is empty, seed from nse_tickers_cache.json
            cur.execute("SELECT COUNT(*) FROM constituent_history")
            const_count = cur.fetchone()[0]
            if const_count == 0:
                tickers_cache_p = RUNTIME_DIR / "nse_tickers_cache.json"
                if tickers_cache_p.exists():
                    t_cache = read_json_cache(tickers_cache_p, {})
                    raw_tickers = t_cache.get("tickers", [])
                    c_rows = [(t.strip().upper(), "2015-01-01", None) for t in raw_tickers if t]
                    if c_rows:
                        conn.executemany("""
                            INSERT OR REPLACE INTO constituent_history (ticker, join_date, leave_date)
                            VALUES (?, ?, ?)
                        """, c_rows)
                        if log_cb:
                            log_cb(f"[Universe] Seeded local PiT constituent_history with {len(c_rows)} tickers.")
        conn.close()
        return True
    except Exception as e:
        if log_cb:
            log_cb(f"[Fundamentals] Could not initialize PiT DB: {e}")
        return False


# ────────────────────────────────────────────────────────────────────
# FUNC: fetch_fundamentals
# ────────────────────────────────────────────────────────────────────
def fetch_fundamentals(tickers: list, as_of_date=None, log_cb=None) -> dict:
    """Fetch Point-in-Time fundamentals from local SQLite DB to prevent Look-Ahead Bias."""
    import sqlite3
    import pandas as pd
    import time
    from pathlib import Path

    db_path = RUNTIME_DIR / "fundamentals_history.db"  # v17-patch: moved from Desktop
    _ensure_pit_db(db_path, log_cb)
    result = {}
    target_ts = pd.Timestamp(as_of_date) if as_of_date is not None else pd.Timestamp.now()
    target_date = target_ts.strftime("%Y-%m-%d")
    is_historical = target_ts.normalize() < pd.Timestamp.now().normalize()

    def _neutral_fundamentals() -> dict:
        # AUDIT-FIX (Round 3, P2-2): NaN sentinels instead of 0.0
        return {"roe": float('nan'), "de_ratio": float('nan'),
                "rev_growth": float('nan'), "pe_ratio": float('nan')}

    def _fill_neutral(missing):
        for _t in missing:
            result[_t] = _neutral_fundamentals()

    fundamentals_cache_path = RUNTIME_DIR / "fundamentals_cache.json"

    conn = sqlite3.connect(str(db_path))
    try:
        # Point-in-Time Query: most recently published data ON OR BEFORE the Walk-Forward step date
        query = """
            SELECT ticker, roe, de_ratio, rev_growth, pe_ratio
            FROM (
                SELECT ticker, roe, de_ratio, rev_growth, pe_ratio,
                       ROW_NUMBER() OVER(PARTITION BY ticker ORDER BY publish_date DESC) as rn
                FROM fundamentals
                WHERE publish_date <= ? AND ticker IN ({})
            ) WHERE rn = 1
        """.format(",".join("?" for _ in tickers))

        cur = conn.cursor()
        clean_tickers = [t.replace(".NS", "") for t in tickers]
        params = [target_date] + clean_tickers
        cur.execute(query, params)
        rows = cur.fetchall()

        for r in rows:
            sym = f"{r[0]}.NS"
            result[sym] = {
                "roe":        float(r[1] or 0.0),
                "de_ratio":   float(r[2] or 0.0),
                "rev_growth": float(r[3] or 0.0),
                "pe_ratio":   float(r[4] or 0.0),
            }
        if rows:
            log_emit(log_cb, f"[Fundamentals] Loaded {len(rows)}/{len(tickers)} tickers from local PiT database.")
    except Exception as e:
        if log_cb:
            log_cb(f"[Fundamentals] PiT DB Query failed: {e}")
    finally:
        conn.close()   # C-06 fix: guaranteed close on both success and exception

    # Historical/OOS runs must not backfill missing PiT rows from current live data.
    missing_tickers = [t for t in tickers if t not in result]
    if missing_tickers and is_historical:
        log_emit(log_cb, f"[Fundamentals] {len(missing_tickers)} missing PiT rows for {target_date}; using neutral fundamentals to avoid look-ahead.")
        _fill_neutral(missing_tickers)
        return result

    # Current-date runs may use live yfinance for missing fields.
    if missing_tickers:
        # Check cache first
        now_ts = time.time()
        fundamentals_cache = read_json_cache(fundamentals_cache_path, {})
        cached_found = []
        for t in missing_tickers:
            if t in fundamentals_cache:
                entry = fundamentals_cache[t]
                if isinstance(entry, dict) and (now_ts - entry.get("_ts", 0)) < 86400:
                    result[t] = {k: v for k, v in entry.items() if k != "_ts"}
                    cached_found.append(t)

        missing_tickers = [t for t in missing_tickers if t not in cached_found]
        if missing_tickers:
            log_emit(log_cb, f"[Fundamentals] Fetching {len(missing_tickers)} missing tickers live via yfinance.")
            live_data = _fetch_fundamentals_live(missing_tickers, log_cb=log_cb)

            # Save to JSON cache with _ts timestamp
            cache_to_save = dict(fundamentals_cache)
            for _k, _v in live_data.items():
                if isinstance(_v, dict):
                    cache_to_save[_k] = dict(_v)
                    cache_to_save[_k]["_ts"] = now_ts
                else:
                    cache_to_save[_k] = _v
            write_json_cache(fundamentals_cache_path, cache_to_save)

            # Save to SQLite PiT DB
            try:
                with sqlite3.connect(str(db_path)) as _p_conn:
                    _p_rows = [
                        (
                            _k.replace(".NS", "").strip().upper(),
                            target_date,
                            float(_v.get("roe", 0.0) or 0.0) if isinstance(_v, dict) else 0.0,
                            float(_v.get("de_ratio", 0.0) or 0.0) if isinstance(_v, dict) else 0.0,
                            float(_v.get("rev_growth", 0.0) or 0.0) if isinstance(_v, dict) else 0.0,
                            float(_v.get("pe_ratio", 0.0) or 0.0) if isinstance(_v, dict) else 0.0,
                        )
                        for _k, _v in live_data.items()
                    ]
                    _p_conn.executemany("""
                        INSERT OR REPLACE INTO fundamentals
                        (ticker, publish_date, roe, de_ratio, rev_growth, pe_ratio)
                        VALUES (?, ?, ?, ?, ?, ?)
                    """, _p_rows)
            except Exception as _pit_err:
                # ROUND-43 FIX (R12 / AUDIT-16): PIT fundamentals persistence
                # failures were silently dropped — the caller kept serving
                # stale point-in-time data downstream with no indication the
                # refresh had failed. Degrade loudly (warning); live_data is
                # still merged into this call's in-memory result.
                logger.warning(
                    "[DataLayer] PIT fundamentals persistence failed for %d tickers — "
                    "local fundamentals cache may be stale: %s",
                    len(live_data), _pit_err,
                )

            result.update(live_data)

    # Final safety net
    for t in tickers:
        if t not in result:
            result[t] = _neutral_fundamentals()

    return result


def fetch_corporate_actions_pit(tickers: list, as_of_date=None, log_cb=None) -> dict:
    """Fetch Point-in-Time corporate actions for tickers from local SQLite DB."""
    import sqlite3
    import pandas as pd
    from pathlib import Path
    
    db_path = RUNTIME_DIR / "fundamentals_history.db"
    result = {}
    
    if not db_path.exists():
        return result
        
    conn = sqlite3.connect(str(db_path))
    try:
        target_date = str(as_of_date.date()) if as_of_date is not None else pd.Timestamp.now().strftime("%Y-%m-%d")
        
        # Format tickers for IN query
        placeholders = ",".join("?" for _ in tickers)
        query = f"""
            SELECT ticker, ex_date, type, ratio, amount, publish_date
            FROM corporate_actions
            WHERE publish_date <= ? AND ticker IN ({placeholders})
        """
        
        cur = conn.cursor()
        clean_tickers = [t.strip().upper() for t in tickers]
        params = [target_date] + clean_tickers
        cur.execute(query, params)
        rows = cur.fetchall()
        
        for r in rows:
            ticker = r[0]
            if ticker not in result:
                result[ticker] = []
            result[ticker].append({
                "ex_date": r[1],
                "type": r[2],
                "ratio": float(r[3] or 1.0),
                "amount": float(r[4] or 0.0),
                "publish_date": r[5]
            })
    except Exception as e:
        if log_cb:
            log_cb(f"[CorpActions] PIT DB Query failed: {e}")
    finally:
        conn.close()
        
    return result


def _fetch_sast_signal_legacy_pit(tickers: list, lookback_days: int = 30, log_cb=None) -> dict:
    """
    Fetch NSE SAST creeping acquisitions (promoter open-market buys).
    Returns {ticker.NS: num_filings_in_last_N_days}.
    Uses Prohibition of Insider Trading (PIT) Regulation 7(2) filings.
    """
    from datetime import datetime, timedelta
    cache     = read_json_cache(SAST_CACHE_PATH, {})
    today_str = datetime.now().strftime("%Y-%m-%d")
    if cache.get("date") == today_str and cache.get("data"):
        d = cache["data"]
        log_emit(log_cb, f"[SAST] Cache hit: {len(d)} tickers")
        return d

    result     = {}
    try:
        try:
            NSEClient.get("https://www.nseindia.com", timeout=10)
        except Exception:
            import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
            pass
        from_dt = (datetime.now() - timedelta(days=lookback_days)).strftime("%d-%m-%Y")
        to_dt = datetime.now().strftime("%d-%m-%Y")
        headers = {
            "Accept": "application/json, text/plain, */*",
            "Referer": "https://www.nseindia.com/companies-listing/corporate-filings-insider-trading"
        }
        url = f"https://www.nseindia.com/api/corporates-pit?index=equities&from_date={from_dt}&to_date={to_dt}"
        resp = NSEClient.get(url, headers=headers, timeout=20)
        recs = []
        if resp.status_code == 200:
            recs = resp.json().get("data", [])
        if not recs:
            # AUDIT-FIX (defect #7): the prior fallback hardcoded from_date=01-01-2026,
            # silently widening the insider-data window whenever the configured
            # lookback returned empty (Akamai throttling, session cookie expiry,
            # or a genuinely quiet period). The new behavior is to extend the
            # window by at most one extra equal-sized lookback (capped at 90
            # days total) and log a warning so the operator sees that the SAST
            # signal is broader than configured.
            _ext_days = min(max(lookback_days * 2, 60), 90)
            _ext_from_dt = (datetime.now() - timedelta(days=_ext_days)).strftime("%d-%m-%Y")
            fallback_url = f"https://www.nseindia.com/api/corporates-pit?index=equities&from_date={_ext_from_dt}&to_date={to_dt}"
            if log_cb:
                log_cb(f"[SAST-Legacy] {lookback_days}d query empty; extending to {_ext_days}d fallback (from_date={_ext_from_dt}).")
            try:
                resp = NSEClient.get(fallback_url, headers=headers, timeout=20)
                if resp.status_code == 200:
                    recs = resp.json().get("data", [])
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                pass
        if recs:
            df = pd.DataFrame(recs)
            df.columns = [c.strip().upper().replace(" ", "_") for c in df.columns]
            tt_col = "TDPAQUISITIONTYPE" if "TDPAQUISITIONTYPE" in df.columns else "TDPTRANSACTIONTYPE"
            cat_col = "PERSONCATEGORY"
            sym_col = "SYMBOL"
            if sym_col in df.columns:
                if tt_col in df.columns:
                    df = df[df[tt_col].astype(str).str.upper().str.contains("BUY", na=False)]
                if cat_col in df.columns:
                    df = df[df[cat_col].astype(str).str.upper().str.contains("PROMOTER|DIRECTOR", na=False)]
                ticker_set = set(t.replace(".NS", "").replace(".BO", "").upper() for t in tickers)
                counts = df[sym_col].astype(str).str.strip().str.upper().value_counts()
                for sym, cnt in counts.items():
                    if sym in ticker_set:
                        result[f"{sym}.NS"] = int(cnt)
        write_json_cache(SAST_CACHE_PATH, {"date": today_str, "data": result})
        log_emit(log_cb, f"[SAST] {len(result)} tickers with recent promoter buying")
    except Exception as e:
        log_emit(log_cb, f"[SAST] fetch failed (non-fatal): {e}", exc_info=True)
    return result


# ────────────────────────────────────────────────────────────────────
# FUNC: compute_fundamental_score
# ────────────────────────────────────────────────────────────────────
def compute_fundamental_score(fundamentals: dict, tickers: list) -> pd.Series:
    rows = []
    for t in tickers:
        d = fundamentals.get(t, {})
        pe = float(d.get("pe_ratio", 0)) if d.get("pe_ratio") is not None else 0.0
        pe_inv = (1.0 / pe) if pe > 0 else np.nan  # DIV001: guard divisor before use
        rows.append({"ticker": t,
                     "roe": (float(d["roe"]) if d.get("roe") is not None else np.nan),
                     "de_inv": -(float(d["de_ratio"]) if d.get("de_ratio") is not None else np.nan),
                     "pe_inv": pe_inv,
                     "rev_growth": (float(d["rev_growth"]) if d.get("rev_growth") is not None else np.nan)})
    df = pd.DataFrame(rows).set_index("ticker")
    z = pd.DataFrame(index=df.index)
    for col in ["roe", "de_inv", "pe_inv", "rev_growth"]:
        s = df[col].dropna()
        if len(s) > 4:
            z[col] = (df[col] - s.mean()) / (s.std() + 1e-9)
        else:
            z[col] = 0.0
    z['z_fund_composite'] = z.mean(axis=1).fillna(0.0)
    z = z.rename(columns={'roe':'z_roe','de_inv':'z_de_inv','pe_inv':'z_pe_inv','rev_growth':'z_rev_growth'})
    return z.fillna(0.0)


# ── Dynamic Portfolio Stop-Loss ───────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: _load_iv_history
# ────────────────────────────────────────────────────────────────────
def _load_iv_history() -> dict:
    """Load rolling per-ticker ATM IV history: {ticker: [(date_str, atm_iv), ...]}"""
    try:
        raw = read_json_cache(_IV_HISTORY_CACHE_PATH, {})
        return raw if isinstance(raw, dict) else {}
    except Exception as _e:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception in %s", "Exception", exc_info=True)  # noqa: E501
        return {}



# ────────────────────────────────────────────────────────────────────
# FUNC: _save_iv_history
# ────────────────────────────────────────────────────────────────────
def _save_iv_history(hist: dict) -> None:
    try:
        write_json_cache(_IV_HISTORY_CACHE_PATH, hist)
    except Exception as _e2_:
        ExceptionLogger.swallow(_e2_, context="iv_history_save")



# ────────────────────────────────────────────────────────────────────
# FUNC: fetch_iv_rank
# ────────────────────────────────────────────────────────────────────
def fetch_iv_rank(tickers: list, log_cb=None) -> dict:
    """
    Fetch NSE options chain for each ticker, compute true IV Rank (IVR).
    IVR = (today_ATM_IV − 252d_low) / (252d_high − 252d_low)
    IVR < 0.25: historically low IV → bullish entry signal.
    IVR > 0.75: historically high IV → avoid / reduce weight.
    Returns {ticker: ivr_0_to_1}. Non-fatal. Cached daily.
    Disabled by default (USE_IV_SIGNAL=False) — one API call per ticker.
    """
    cache = read_json_cache(OPTIONS_IV_CACHE_PATH, {})
    today = datetime.now().strftime("%Y-%m-%d")
    if cache.get("date") == today and cache.get("data"):
        return cache["data"]

    # AUDIT-FIX (Round 3, P2-2): migrated onto NSEClient + NSEPerTickerPool.
    # Replaces '0.5 neutral IV rank' silent fallback with NaN.
    from utils import NSEClient
    from utils_nse import NSEPerTickerPool, nse_parsers

    result = {}

    iv_history = _load_iv_history()
    history_updated = False

    def _fetch_one_iv(t: str):
        sym = t.replace(".NS", "").replace(".BO", "").upper()
        url = NSE_OPTIONS_URL.format(symbol=sym)
        resp = NSEClient.get(url, timeout=10)
        if resp.status_code != 200:
            return None
        data = nse_parsers.decode_nse_json(resp)
        records = data.get("records", {}).get("data", [])
        ivs = []
        for rec in records:
            for opt_type in ["CE", "PE"]:
                opt = rec.get(opt_type, {})
                iv_val = opt.get("impliedVolatility")
                if iv_val and float(iv_val) > 0:
                    ivs.append(float(iv_val))
        if not ivs:
            return None
        return float(np.median(ivs))

    per_ticker_results = NSEPerTickerPool.map_per_ticker(_fetch_one_iv, tickers)

    for t, atm_iv in per_ticker_results.items():
        if atm_iv is None:
            continue
        try:
            ticker_hist = iv_history.get(t, [])
            ticker_hist.append([today, atm_iv])
            ticker_hist = ticker_hist[-_IV_HISTORY_MAX_DAYS:]
            iv_history[t] = ticker_hist
            history_updated = True
            hist_ivs = [entry[1] for entry in ticker_hist if isinstance(entry, list) and len(entry) == 2]
            if len(hist_ivs) < 5:
                result[t] = float('nan')  # AUDIT-FIX (Round 3): NaN, not 0.5
                continue
            iv_lo  = float(min(hist_ivs))
            iv_hi  = float(max(hist_ivs))
            iv_rng = iv_hi - iv_lo
            if iv_rng < 1e-6:
                result[t] = float('nan')
                continue
            ivr = ((atm_iv - iv_lo) / iv_rng) if iv_rng != 0 else float('nan')
            result[t] = float(np.clip(ivr, 0.0, 1.0))
        except Exception as _eloop:
            import logging as _logging_mod
            _logging_mod.getLogger("quantum_annealer").debug(
                "[IV Rank] per-ticker loop failed for %s: %s", t, _eloop, exc_info=True,
            )
            continue

    if history_updated:
        _save_iv_history(iv_history)

    if result:
        write_json_cache(OPTIONS_IV_CACHE_PATH, {"date": today, "data": result})
        log_emit(log_cb, f"[OptionsIV] Fetched true IVR for {len(result)} tickers "
                         f"(history depth: {max((len(v) for v in iv_history.values()), default=0)}d)")
    return result


# ── Regime-Conditional Backtest Split ────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: fetch_oi_buildup_signal
# ────────────────────────────────────────────────────────────────────
def fetch_oi_buildup_signal(tickers: list, log_cb=None) -> dict:
    """
    Fetch F&O OI via NSE quote-derivative API (per-symbol, nearest futures expiry).
    Long-buildup +1.0 | Short-covering +0.3 | Long-unwinding -0.5 | Short-buildup -1.0
    Results cached daily.
    """
    cache = read_json_cache(OI_BUILDUP_CACHE_PATH, {})
    today = datetime.now().strftime("%Y-%m-%d")
    if cache.get("date") == today and "data" in cache and isinstance(cache["data"], dict):
        d = cache["data"]
        if d:
            log_emit(log_cb, f"[OI Signal] Cache hit: {len(d)} tickers")
        else:
            log_emit(log_cb, "[OI Signal] Cache hit: 0 F&O tickers returned today (non-trading hours or NSE throttle — non-fatal)")
        return d

    # AUDIT-FIX (Round 3, P2-2): migrated onto NSEClient + NSEPerTickerPool.
    from utils import NSEClient
    from utils_nse import NSEPerTickerPool, nse_parsers

    fo_syms = [t.replace(".NS", "").replace(".BO", "").upper() for t in tickers]
    result  = {}
    _failed_consecutive = 0
    _aborted_early = False

    def _fetch_one(sym):
        nonlocal _failed_consecutive, _aborted_early
        if _aborted_early:
            return sym, None
        try:
            url  = f"https://www.nseindia.com/api/quote-derivative?symbol={sym}"
            resp = NSEClient.get(url, timeout=6)
            if resp.status_code in (401, 403, 429, 503):
                _failed_consecutive += 1
                if _failed_consecutive >= 3:
                    _aborted_early = True
                return sym, None
            if resp.status_code != 200:
                _failed_consecutive += 1
                if _failed_consecutive >= 5:
                    _aborted_early = True
                return sym, None
            _failed_consecutive = 0
            jd      = nse_parsers.decode_nse_json(resp)
            stocks  = jd.get("stocks", []) or []
            futures = [s for s in stocks
                       if s.get("metadata", {}).get("instrumentType", "") == "Stock Futures"]
            if not futures:
                return sym, None
            futures.sort(key=lambda x: str(x.get("metadata", {}).get("expiryDate", "")))
            meta   = futures[0].get("metadata", {})
            oi_chg = float(meta.get("changeinOpenInterest", 0) or 0)
            p_chg  = float(meta.get("change", 0) or meta.get("pChange", 0) or 0)
            if   oi_chg > 0 and p_chg > 0: score = +1.0
            elif oi_chg > 0 and p_chg < 0: score = -1.0
            elif oi_chg < 0 and p_chg > 0: score = +0.3
            elif oi_chg < 0 and p_chg < 0: score = -0.5
            else:                           score =  0.0
            return sym, score
        except Exception:
            _failed_consecutive += 1
            if _failed_consecutive >= 3:
                _aborted_early = True
            return sym, None

    per_sym = NSEPerTickerPool.map_per_ticker(lambda s: _fetch_one(s)[1], fo_syms)
    for sym, score in per_sym.items():
        if score is not None:
            result[f"{sym}.NS"] = score

    write_json_cache(OI_BUILDUP_CACHE_PATH, {"date": today, "data": result})
    if result:
        bull = sum(1 for v in result.values() if v > 0)
        bear = sum(1 for v in result.values() if v < 0)
        log_emit(log_cb, f"[OI Signal] {len(result)} tickers | Long-buildup: {bull} | Short-buildup: {bear}")
    else:
        log_emit(log_cb, "[OI Signal] No F&O data returned (non-trading hours or NSE throttle — non-fatal)")
    return result




# ────────────────────────────────────────────────────────────────────
# FUNC: fetch_sast_signal
# ────────────────────────────────────────────────────────────────────
def fetch_sast_signal(tickers: list, lookback_days: int = 30, log_cb=None) -> dict:
    """
    Fetch NSE SAST filings (creeping acquisition / promoter open-market buys).
    Returns {ticker.NS: num_filings_in_last_N_days}.
    NOTE (2026):
    NSE's legacy public SAST CSV/API endpoints have become unreliable/removed.
    By default we now use the (still-working) PIT filings endpoint via
    `fetch_sast_velocity()` to derive an equivalent "insider buying" signal.

    If you want to try the legacy endpoints anyway, set:
      USE_LEGACY_SAST_ENDPOINTS=1
    """
    # Default: use PIT endpoint (more reliable than legacy SAST CSV).
    if os.environ.get("USE_LEGACY_SAST_ENDPOINTS") != "1":
        try:
            return fetch_sast_velocity(tickers, log_cb=log_cb)
        except Exception as _e:
            log_emit(log_cb, f"[SAST] PIT velocity endpoint failed (non-fatal): {_e}", exc_info=True)
            return {}

    cache     = read_json_cache(SAST_CACHE_PATH, {})
    today_str = datetime.now().strftime("%Y-%m-%d")
    if cache.get("date") == today_str and cache.get("data"):
        d = cache["data"]
        log_emit(log_cb, f"[SAST] Cache hit: {len(d)} tickers")
        return d

    ticker_set = {t.replace(".NS", "").replace(".BO", "").upper() for t in tickers}
    result     = {}
    cutoff     = pd.Timestamp.now() - pd.Timedelta(days=lookback_days)
    headers    = {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)",
        "Referer":    "https://www.nseindia.com"
    }
    urls = [
        # Legacy endpoints (kept for backwards compatibility / experiments only).
        "https://archives.nseindia.com/content/SAST/SAST.csv",
        "https://www.nseindia.com/api/sast-disclosures",
    ]
    df_sast = None
    for url in urls:
        try:
            resp = NSEClient.get(url, headers=headers, timeout=25)
            if resp.status_code != 200:
                continue
            content = resp.content
            if content and content.startswith(b'\x1f\x8b'):
                import gzip
                try:
                    content = gzip.decompress(content)
                except Exception as gzip_ex:
                    log_emit(log_cb, f"[SAST] Gzip decompression failed: {gzip_ex}", exc_info=True)
            resp_text = content.decode("utf-8", errors="ignore").strip() if content else ""
            if not resp_text:
                continue
            ct = resp.headers.get("Content-Type", "")
            if "json" in ct or resp_text.startswith("[") or resp_text.startswith("{"):
                import json
                try:
                    jd = json.loads(resp_text)
                    records = jd if isinstance(jd, list) else jd.get("data", [])
                    if records:
                        df_sast = pd.DataFrame(records)
                        break
                except Exception as json_ex:
                    log_emit(log_cb, f"[SAST] JSON parse failed: {json_ex}", exc_info=True)
            else:
                df_sast = pd.read_csv(io.StringIO(resp_text), encoding="utf-8", on_bad_lines="skip")
                break
        except Exception as e:
            log_emit(log_cb, f"[SAST] URL failed ({url}): {e}", exc_info=True)
            continue

    if df_sast is None or df_sast.empty:
        log_emit(log_cb, "[SAST] Legacy CSV/API returned no data. Falling back to live PIT promoter buying velocity...")
        try:
            return fetch_sast_velocity(tickers, log_cb=log_cb)
        except Exception as _fe:
            log_emit(log_cb, f"[SAST] Fallback velocity failed: {_fe}", exc_info=True)
            return result

    # Normalise column names
    df_sast.columns = [c.strip().upper().replace(" ", "_") for c in df_sast.columns]

    # Find symbol + date columns flexibly
    sym_col  = next((c for c in df_sast.columns if "SYMBOL"    in c or "SCRIP" in c), None)
    date_col = next((c for c in df_sast.columns if "DATE"      in c or "DT"    in c), None)
    type_col = next((c for c in df_sast.columns if "TYPE"      in c or "TRANS" in c or "ACQTYPE" in c), None)

    if sym_col is None:
        log_emit(log_cb, "[SAST] Symbol column not found in CSV — skipping")
        return result

    if date_col:
        df_sast[date_col] = pd.to_datetime(df_sast[date_col], errors="coerce", dayfirst=True)
        df_sast = df_sast[df_sast[date_col] >= cutoff]

    # Filter acquisitions only (exclude pledges/disposals)
    if type_col:
        buy_kw = ["ACQUI", "BUY", "PURCH", "CREP"]
        mask   = df_sast[type_col].astype(str).str.upper().apply(
            lambda x: any(k in x for k in buy_kw))
        df_sast = df_sast[mask]

    # Count filings per ticker
    for sym, grp in df_sast.groupby(sym_col):
        sym_clean = str(sym).strip().upper()
        if sym_clean in ticker_set:
            result[f"{sym_clean}.NS"] = len(grp)

    if result:
        write_json_cache(SAST_CACHE_PATH, {"date": today_str, "data": result})
        log_emit(log_cb, f"[SAST] {len(result)} tickers with recent promoter buying")
    else:
        log_emit(log_cb, "[SAST] No recent insider purchases found for screened universe")
    return result




# ────────────────────────────────────────────────────────────────────
# FUNC: sector_counts (Single canonical source in utils.py)
# ────────────────────────────────────────────────────────────────────
try:
    from utils import sector_counts, normalize_sector, NA_SECTOR_VALUES
except ImportError:
    NA_SECTOR_VALUES = {"N/A", "NA", "na", "n/a", "", None, "None", "null"}
    def normalize_sector(sec_val):
        if sec_val in NA_SECTOR_VALUES or (isinstance(sec_val, str) and not sec_val.strip()):
            return "UNKNOWN"
        return sec_val
    def sector_counts(selected, sectors):
        counts = Counter()
        for s in selected:
            sec = normalize_sector(sectors.get(s, "N/A"))
            counts[sec] += 1
        return counts





# ────────────────────────────────────────────────────────────────────
# FUNC: _parse_tickers
# ────────────────────────────────────────────────────────────────────
def _parse_tickers(text):
    """Clean and suffix .NS for any bare NSE symbol."""
    raw = re.split(r'[\s,;|]+', text.strip())
    out = []
    for t in raw:
        t = t.strip().upper()
        if not t: continue
        if '.' not in t: t += '.NS'
        out.append(t)
    return list(dict.fromkeys(out))   # deduplicate, preserve order


# ────────────────────────────────────────────────────────────────────
# FUNC: download_multitimeframe_ohlcv_bundle
# ────────────────────────────────────────────────────────────────────
def download_multitimeframe_ohlcv_bundle(tickers: List[str],
                                         cfg: Optional[dict] = None,
                                         log_cb: Optional[Callable] = None) -> Dict[str, Dict[str, pd.DataFrame]]:
    """Downloads and resamples OHLCV data for multiple timeframes (1h, 4h, 1d, 1wk).

    Performs data validation to drop tickers with split anomalies, flatlines, or illiquidity.
    """
    cfg = cfg or {}

    # Standard downloads using yfinance
    # 1d and 1wk from daily download (2y lookback)
    lookback_1d = str(cfg.get("LOOKBACK_DOWNLOAD", "2y"))
    log_emit(log_cb, f"[DataBundle] Downloading daily data ({lookback_1d}) for {len(tickers)} tickers...")
    try:
        daily_bulk = safe_download(tickers, period=lookback_1d, log_cb=log_cb, cfg=cfg)
    except Exception as e:
        log_emit(log_cb, f"[DataBundle] Daily bulk download failed: {e}", exc_info=True)
        daily_bulk = pd.DataFrame()

    # 1h and 4h from intraday download (180d lookback, interval 60m)
    lookback_1h = str(cfg.get("CHART_INTRADAY_LOOKBACK", "180d"))
    log_emit(log_cb, f"[DataBundle] Downloading hourly data ({lookback_1h}) for {len(tickers)} tickers...")
    try:
        # standard 60m interval
        hourly_bulk = safe_download(tickers, period=lookback_1h, interval="60m", log_cb=log_cb, cfg=cfg)
    except Exception as e:
        log_emit(log_cb, f"[DataBundle] Hourly bulk download failed: {e}", exc_info=True)
        hourly_bulk = pd.DataFrame()

    # Helper function to extract individual ticker OHLCV panel
    def extract_ohlcv_panel(bulk_df, ticker):
        if bulk_df.empty:
            return None
        try:
            if isinstance(bulk_df.columns, pd.MultiIndex):
                if ticker in bulk_df.columns.levels[0]:
                    df = bulk_df[ticker].dropna(how="all")
                elif ticker in bulk_df.columns.levels[1]:
                    df = bulk_df.xs(ticker, axis=1, level=1).dropna(how="all")
                else:
                    return None
            else:
                df = bulk_df.dropna(how="all")

            if df.empty:
                return None

            # Rename columns to standard casing
            df.columns = [c.capitalize() for c in df.columns]
            return df
        except Exception:
            import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
            return None

    # Resample helpers
    def resample_panel(df, freq):
        if df is None or df.empty:
            return None
        try:
            ohlc_dict = {
                'Open': 'first',
                'High': 'max',
                'Low': 'min',
                'Close': 'last',
                'Volume': 'sum'
            }
            freq_dict = {col: ohlc_dict[col] for col in df.columns if col in ohlc_dict}
            resampled = df.resample(freq).agg(freq_dict).dropna(how="all")
            return resampled
        except Exception:
            import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
            return None

    # Final timeframe dictionary
    bundle = {
        "1h": {"Open": pd.DataFrame(), "High": pd.DataFrame(), "Low": pd.DataFrame(), "Close": pd.DataFrame(), "Volume": pd.DataFrame()},
        "4h": {"Open": pd.DataFrame(), "High": pd.DataFrame(), "Low": pd.DataFrame(), "Close": pd.DataFrame(), "Volume": pd.DataFrame()},
        "1d": {"Open": pd.DataFrame(), "High": pd.DataFrame(), "Low": pd.DataFrame(), "Close": pd.DataFrame(), "Volume": pd.DataFrame()},
        "1wk": {"Open": pd.DataFrame(), "High": pd.DataFrame(), "Low": pd.DataFrame(), "Close": pd.DataFrame(), "Volume": pd.DataFrame()}
    }

    # Temporary storage per timeframe to construct final dataframes
    temp_data = {tf: {col: {} for col in ["Open", "High", "Low", "Close", "Volume"]} for tf in ["1h", "4h", "1d", "1wk"]}

    valid_tickers = []
    for ticker in tickers:
        check_stop()

        p_1d = extract_ohlcv_panel(daily_bulk, ticker)
        p_1h = extract_ohlcv_panel(hourly_bulk, ticker)

        if p_1d is None or len(p_1d) < 20:
            continue

        # Data validation checks:
        # 1. Reject split anomalies (e.g. daily returns exceeding ±80% single-day jump)
        daily_rets = p_1d["Close"].pct_change().dropna()
        if (daily_rets.abs() > 0.80).any():
            _logging.debug(f"[DataBundle] Rejected {ticker}: Split anomaly detected.")
            continue

        # 2. Reject stale/flatlined series (e.g. close price standard deviation is near 0)
        if p_1d["Close"].std() < 1e-4:
            _logging.debug(f"[DataBundle] Rejected {ticker}: Stale/flatlined series.")
            continue

        # 3. Reject extremely illiquid series (average daily volume < 500 shares)
        if p_1d["Volume"].mean() < 500:
            _logging.debug(f"[DataBundle] Rejected {ticker}: Extremely illiquid.")
            continue

        valid_tickers.append(ticker)

        p_1wk = resample_panel(p_1d, "W-FRI")
        p_4h = resample_panel(p_1h, "4H")

        panels = {"1d": p_1d, "1wk": p_1wk, "1h": p_1h, "4h": p_4h}
        for tf, panel in panels.items():
            if panel is not None:
                for col in ["Open", "High", "Low", "Close", "Volume"]:
                    if col in panel.columns:
                        temp_data[tf][col][ticker] = panel[col]

    # Convert temp dicts to final DataFrames
    for tf in ["1h", "4h", "1d", "1wk"]:
        for col in ["Open", "High", "Low", "Close", "Volume"]:
            if temp_data[tf][col]:
                bundle[tf][col] = pd.DataFrame(temp_data[tf][col])

    log_emit(log_cb, f"[DataBundle] Multi-timeframe bundle generated. Valid tickers: {len(valid_tickers)}/{len(tickers)}")
    return bundle


try:
    from web_dashboard.app import DynamicPriceResolver
except Exception:
    class DynamicPriceResolver:
        _CACHE = {}
        @classmethod
        def get(cls, ticker, default=100.0):
            return cls._CACHE.get(ticker, default)

