# System Architecture & Design Specification: Enterprise Migration
**Document Version:** 1.0.0  
**Target Architecture:** Distributed Containerized Cloud Platform (Aladdin/Bloomberg PORT Level)  
**Status:** Approved for Prototyping  

---

## 1. System Overview & High-Level Architecture

The target architecture transitions the Quantum Annealer desktop application from a single-user PySide GUI into a distributed, multi-tenant enterprise quantitative analytics platform. The system is divided into four key layers: API Ingestion, Distributed Computation (Ray/Arrow), Stateless Math Engines (FastAPI/gRPC), and Hybrid Quantum Cloud Solvers (D-Wave).

```
   ┌─────────────────────────────────────────────────────────┐
   │                  Presentation Layer                     │
   │            Web UI (React) / Terminal Client             │
   └────────────────────────────┬────────────────────────────┘
                                │ gRPC / WebSockets
                                ▼
   ┌─────────────────────────────────────────────────────────┐
   │             Distributed Orchestration (Ray)             │
   │     - Handles parallel ticker screens using Ray Tasks   │
   │     - Manages Shared Memory Arrow Plasma Store          │
   └─────────────┬─────────────────────────────┬─────────────┘
                 │                             │
                 ▼ gRPC                        ▼ REST/gRPC
   ┌───────────────────────────┐ ┌───────────────────────────┐
   │   Stateless Math Pods     │ │   Quantum Solver Pods     │
   │   - HMM Regime Classifier │ │   - D-Wave QUBO/CQM Model │
   │   - Barra Style Risk      │ │   - Local Fallback Solver │
   └───────────────────────────┘ └───────────────────────────┘
```

---

## 2. Containerized Microservices Layer (Stateless Math Pods)

To scale compute horizontally and decouple model code from UI updates, all financial models are extracted into containerized stateless microservices:
* **Protocol Selection**: gRPC is chosen as the primary communication protocol for high-performance intra-cluster calls (using Protocol Buffers for structured binary serialization). REST (FastAPI) is maintained as a fallback and external API surface.
* **Orchestration**: Run stateless pods on **Kubernetes (EKS/GKE)** with Horizontal Pod Autoscaler (HPA) targeting CPU utilization > 70% or request queue sizes.
* **Stateless Rationale**: Microservices hold zero persistent state. All parameters (e.g. historical price matrices, weights, options parameters) are passed via the request payload or read from high-performance shared cache clusters (Redis).

---

## 3. High-Performance Data Pipeline & Point-in-Time Database

To support institutional quantitative analysis, the data layer is upgraded from retail-grade `yfinance` fetches:
* **Ingestion Partners**: Integration with Refinitiv Real-Time SDK and Bloomberg Open API (WAPI) for sub-millisecond tick feeds and institutional-grade historical data.
* **Point-in-Time database Schema**: 
  * Every corporate action (split, merger, dividend) registers in an immutable log table.
  * Price queries require a historical timestamp parameters: `GET /prices?ticker=AAPL&as_of_date=2024-02-15T16:00:00Z`.
  * The database automatically reconstructs the splits/dividends adjusted price series *as they were known on that specific day*, eliminating look-ahead and survivorship biases during model backtests.
* **DB Architecture**: Remote PostgreSQL cluster deployed with multi-region active-passive replication, with high-performance Read Replicas serving the compute worker pods.

---

## 4. Low-Latency Computation & Memory Management

To eliminate the latency overhead of serializing/deserializing large pandas DataFrames (pickling) during parallel ticker screening, we employ Apache Arrow:
* **Zero-Copy Serialization**: Price history and feature vectors are serialized into Apache Arrow RecordBatches.
* **Arrow Plasma Store**: Shared-memory object store. Workers read matrices directly from memory addresses without copy overhead, reducing serialization latency by up to 98%.
* **Orchestration**: Ray is deployed as the execution framework, distributing quant screening and factor risk analysis across a cluster of CPU/GPU nodes.

---

## 5. Hybrid Quantum Portfolio Optimization

The optimization layer transitions from a simple classical simulated annealing loop to a true hybrid quantum system:
* **Problem Formulation**: The portfolio selection problem is formulated as a Constrained Quadratic Model (CQM):
  
  $$\text{Minimize } \quad \frac{Risk\_Aversion}{2} w^T \Sigma w - w^T \mu$$
  
  $$\text{Subject to } \quad \sum_{i=1}^N w_i = 1, \quad 0 \le w_i \le \text{Max\_Weight}$$

* **QUBO Mapping**: Discrete integer binary representations map weight selections ($w_i$) to D-Wave qubits.
* **Hybrid Quantum Solvers**: Solver jobs are sent to D-Wave Leap hybrid cloud services (`LeapHybridCQMSampler`), which use a combination of classical heuristic tabu searches and real physical quantum annealers (5000+ qubits Pegasus graph).

---

## 6. Security, Compliance, and Monitoring

* **Transport Security**: TLS 1.3 encryption for all REST/gRPC traffic within and outside the Kubernetes cluster.
* **Audit Trail**: Immutable write-ahead log recording all portfolio execution requests, optimization solver parameters, and trade decisions to comply with MiFID II and SEC regulations.
* **Observability**: Prometheus scraping gRPC/REST endpoints, feeding Grafana dashboards for latency and system memory tracking.
