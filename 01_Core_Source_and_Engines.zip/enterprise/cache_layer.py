import os
import json
import logging
import base64
import time
import threading
from typing import Any, Optional

logger = logging.getLogger(__name__)

class CacheLayer:
    """
    Distributed Redis cache wrapper for institutional data caching.
    Falls back to a local dictionary if Redis is not available or connection fails.

    Phase 4.5: Local cache now has LRU eviction with a max entry cap (5000) and
    approximate max bytes cap (2 GB). Without this, long-running sessions with
    Nifty 500 + 4 timeframes + 5y lookback + per-ticker caches grew unbounded
    until OOM kill.
    """
    DEFAULT_TTL = 3600
    SLOW_TTL = 3600 * 24
    MAX_LOCAL_ENTRIES = 5000
    MAX_LOCAL_BYTES = 2 * 1024 * 1024 * 1024  # 2 GB
    # ROUND 45: key namespaces written by THIS layer (the only patterns an
    # empty-prefix invalidate() may delete in Redis mode — never FLUSHDB).
    _OWNED_KEY_PREFIXES = ("ohlcv:",)

    def __init__(self, redis_url: Optional[str] = None):
        self.use_redis = False
        self.redis_client = None
        # Phase 4.5: use OrderedDict for LRU eviction (move-to-end on access)
        from collections import OrderedDict
        self.local_cache = OrderedDict()
        self._local_bytes = 0  # approximate bytes in local cache
        # C5/H5-fix: add a re-entrant lock around local_cache to prevent TOCTOU races
        # when concurrent batch workers in safe_download call get()/set() in parallel.
        self._lock = threading.RLock()

        # If running in production, enforce Redis usage if available
        env = os.environ.get("ENV", "development").lower()
        if env == "production" and not redis_url:
            redis_url = os.environ.get("REDIS_URL", "redis://localhost:6379/0")

        if redis_url:
            try:
                import redis
                self.redis_client = redis.Redis.from_url(redis_url, decode_responses=True)
                # Ping to check connection
                if self.redis_client.ping():
                    self.use_redis = True
                    logger.info(f"Connected to Redis cache at {redis_url}")
            except ImportError:
                logger.warning("redis package not installed. Falling back to local dict cache.")
            except Exception as e:
                logger.warning(f"Failed to connect to Redis: {e}. Falling back to local dict cache.")

    def get(self, key: str) -> Any:
        if self.use_redis:
            try:
                val = self.redis_client.get(key)
                if val is not None:
                    try:
                        payload = json.loads(val)
                        # SECURITY: pickle deserialization removed — arbitrary code execution risk.
                        # If an attacker compromises Redis, they can inject a malicious pickle payload.
                        # Only accept JSON-serialized data (safe) or pandas orient="split" (also JSON).
                        if isinstance(payload, dict) and payload.get("__kind__") == "json":
                            return payload.get("value")
                        # Backward compatibility for older pandas orient="split"
                        # cache entries. This preserves DataFrame behavior for
                        # pre-existing Redis values. orient="split" is JSON — safe.
                        if (
                            isinstance(payload, dict)
                            and {"columns", "index", "data"}.issubset(payload.keys())
                        ):
                            import pandas as pd
                            df = pd.read_json(val, orient="split")
                            if isinstance(df.columns, pd.Index) and len(df.columns) > 0 and isinstance(df.columns[0], (list, tuple)):
                                df.columns = pd.MultiIndex.from_tuples(df.columns)
                            return df
                        if isinstance(payload, dict) and payload.get("__kind__") == "json":
                            return payload.get("value")
                        return payload
                    except Exception:
                        import pandas as pd
                        df = pd.read_json(val, orient="split")
                        if isinstance(df.columns, pd.Index) and len(df.columns) > 0 and isinstance(df.columns[0], (list, tuple)):
                            df.columns = pd.MultiIndex.from_tuples(df.columns)
                        return df
                return None
            except Exception as e:
                logger.error(f"Redis GET failed for key {key}: {e}")
                return None
        else:
            # C5/H5-fix: lock the read-check-expiry-pop sequence so concurrent
            # workers don't TOCTOU-pop a freshly-cached entry written between
            # our .get() and our .pop().
            with self._lock:
                entry = self.local_cache.get(key)
                if entry is None:
                    return None
                value, expiry = entry
                if expiry is not None and time.monotonic() > expiry:
                    # ROUND 45: decrement byte accounting on expiry eviction
                    self._local_bytes -= self._entry_bytes(key, value)
                    self._local_bytes = max(0, self._local_bytes)
                    self.local_cache.pop(key, None)
                    return None
                # Phase 4.5: LRU — move accessed key to end (most-recently-used)
                self.local_cache.move_to_end(key)
                return value

    def set(self, key: str, value: Any, ttl: int = 3600) -> bool:
        if self.use_redis:
            try:
                import pandas as pd
                # SECURITY: no pickle serialization — use JSON only.
                # DataFrames/Series are serialized via pandas to_json (orient="split").
                if isinstance(value, (pd.DataFrame, pd.Series)):
                    serialized = value.to_json(orient="split")
                else:
                    serialized = json.dumps({"__kind__": "json", "value": value})
                self.redis_client.setex(key, ttl, serialized)
                return True
            except Exception as e:
                logger.error(f"Redis SET failed for key {key}: {e}")
                return False
        else:
            # C5/H5-fix: lock the write to prevent dict-changed-size-during-iteration errors
            with self._lock:
                expiry = time.monotonic() + ttl if ttl and ttl > 0 else None
                # Phase 4.5: If key already exists, remove old entry first (for byte accounting)
                if key in self.local_cache:
                    self._local_bytes -= self._entry_bytes(key, self.local_cache[key][0])
                    self.local_cache.pop(key)
                self.local_cache[key] = (value, expiry)
                self._local_bytes += self._entry_bytes(key, value)
                # Phase 4.5: LRU eviction — evict oldest entries if over EITHER cap.
                # ROUND 45 FIX: the 2 GB MAX_LOCAL_BYTES cap was dead code —
                # _local_bytes was never updated and never compared, so only
                # the 5000-entry cap ran (the docstring's OOM protection was
                # half-imaginary: 5000 cached OHLCV DataFrames can still OOM
                # the process). Byte accounting is now wired through set()
                # and every eviction path.
                while len(self.local_cache) > self.MAX_LOCAL_ENTRIES or (
                    self._local_bytes > self.MAX_LOCAL_BYTES and len(self.local_cache) > 1
                ):
                    ev_key, (ev_val, _exp) = self.local_cache.popitem(last=False)  # FIFO eviction (oldest first)
                    self._local_bytes -= self._entry_bytes(ev_key, ev_val)
                    self._local_bytes = max(0, self._local_bytes)
            return True

    @staticmethod
    def _entry_bytes(key: str, value: Any) -> int:
        """ROUND 45: approximate in-memory footprint of one cached entry.
        DataFrames/Series use their true deep memory usage; other objects fall
        back to sys.getsizeof plus a small key/entry overhead constant."""
        try:
            if hasattr(value, "memory_usage"):
                try:
                    return int(value.memory_usage(deep=True, index=True).sum()) + 128 + len(str(key))
                except TypeError:
                    return int(value.memory_usage(deep=True)) + 128 + len(str(key))
            import sys as _sys
            return int(_sys.getsizeof(value)) + 128 + len(str(key))
        except Exception:
            return 256 + len(str(key))

    def cache_key(self, tickers: list, period: str, suffix: str = "") -> str:
        """Generate a stable deterministic cache key for a batch request"""
        tickers_str = "-".join(sorted(tickers))
        return f"ohlcv:batch:{tickers_str}:{period}:{suffix}"

    def invalidate(self, prefix: str = "") -> int:
        """C5-fix: remove all cache entries whose key starts with `prefix`.
        Returns the number of entries removed. If prefix is empty, clears everything.
        Without this method, live_verify.py:153's invalidation call silently fell through
        both hasattr() branches and never invalidated anything.
        """
        if self.use_redis:
            try:
                # ROUND 45 FIX: an empty prefix previously ran FLUSHDB — wiping
                # EVERY key in the shared Redis database (including keys owned
                # by other services on the default redis://…/0 URL), while the
                # local-dict mode only cleared this cache's own dict. The two
                # modes are now symmetric: only keys written BY THIS CacheLayer
                # (tracked namespaced scan) are deleted.
                if not prefix:
                    removed = 0
                    for pattern in ("ohlcv:",) + tuple(self._OWNED_KEY_PREFIXES):
                        for key in list(self.redis_client.scan_iter(f"{pattern}*")):
                            self.redis_client.delete(key)
                            removed += 1
                    return removed
                # SCAN is non-blocking, unlike KEYS
                removed = 0
                for key in self.redis_client.scan_iter(f"{prefix}*"):
                    self.redis_client.delete(key)
                    removed += 1
                return removed
            except Exception as e:
                logger.error(f"Redis INVALIDATE failed for prefix {prefix!r}: {e}")
                return 0
        else:
            with self._lock:
                if not prefix:
                    n = len(self.local_cache)
                    self._local_bytes = 0  # ROUND 45: keep byte accounting consistent
                    self.local_cache.clear()
                    return n
                keys_to_drop = [k for k in self.local_cache if k.startswith(prefix)]
                for k in keys_to_drop:
                    self._local_bytes -= self._entry_bytes(k, self.local_cache[k][0])
                    self.local_cache.pop(k, None)
                self._local_bytes = max(0, self._local_bytes)
                return len(keys_to_drop)

    def clear(self) -> int:
        """C5-fix: alias for invalidate("") — clear the entire cache."""
        return self.invalidate("")

    def __contains__(self, key: str) -> bool:
        """C5-fix: thread-safe membership test."""
        if self.use_redis:
            try:
                return self.redis_client.exists(key) > 0
            except Exception:
                return False
        else:
            with self._lock:
                entry = self.local_cache.get(key)
                if entry is None:
                    return False
                value, expiry = entry
                if expiry is not None and time.monotonic() > expiry:
                    # ROUND 45: decrement byte accounting on expiry eviction
                    self._local_bytes -= self._entry_bytes(key, value)
                    self._local_bytes = max(0, self._local_bytes)
                    self.local_cache.pop(key, None)
                    return False
                return True

# Global singleton cache instance
_GLOBAL_CACHE = None
_GLOBAL_CACHE_LOCK = threading.Lock()  # ROUND 45 FIX: get_cache() was an unlocked check-then-act

def get_cache() -> CacheLayer:
    global _GLOBAL_CACHE
    if _GLOBAL_CACHE is None:
        with _GLOBAL_CACHE_LOCK:
            if _GLOBAL_CACHE is None:
                _GLOBAL_CACHE = CacheLayer()
    return _GLOBAL_CACHE
