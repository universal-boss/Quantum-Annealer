# Quantitative Cloud Deployment Guide: AWS EKS & RDS PostgreSQL

This guide details the step-by-step production deployment workflow to launch the containerized math service, pgBouncer connection pooler, and PostgreSQL database cluster on **Amazon Web Services (AWS)** using **Elastic Kubernetes Service (EKS)** and **RDS PostgreSQL**.

---

## 1. Prerequisites & CLI Configuration

Ensure you have the following administrative CLI utilities installed:
* `aws` (AWS Command Line Interface)
* `docker` (Local Docker Desktop runtime)
* `kubectl` (Kubernetes command-line tool)
* `helm` (Kubernetes package manager)

Authenticate your local session:
```bash
aws configure
# Verify credentials
aws sts get-caller-identity
```

---

## 2. Step 1: Create Amazon ECR Repository & Push Docker Image

Create an ECR private repository to store the math service Docker container:
```bash
# Create repository
aws ecr create-repository --repository-name quantum-annealer/math-service --region us-east-1

# Authenticate local Docker daemon to the ECR registry (replace <AWS_ACCOUNT_ID>)
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin <AWS_ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com
```

Build, tag, and push the docker image:
```bash
# Build (run from project root directory)
docker build -t quantum-annealer/math-service:latest -f enterprise/Dockerfile .

# Tag for ECR
docker tag quantum-annealer/math-service:latest <AWS_ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com/quantum-annealer/math-service:latest

# Push
docker push <AWS_ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com/quantum-annealer/math-service:latest
```

---

## 3. Step 2: Provision RDS PostgreSQL Database

Provision a managed PostgreSQL instance with read replicas:
```bash
aws rds create-db-instance \
    --db-instance-identifier qa-postgres-db \
    --db-instance-class db.t4g.medium \
    --engine postgres \
    --master-username postgres \
    --master-user-password YourSecurePasswordHere \
    --allocated-storage 20 \
    --region us-east-1
```
*Note down the returned DB Instance Endpoint address (e.g. `qa-postgres-db.xxxxxx.us-east-1.rds.amazonaws.com`).*

---

## 4. Step 3: Deploy pgBouncer Connection Pooler on EKS

### A. Create pgBouncer ConfigMap
Create the authentication user list file `/tmp/userlist.txt` containing the username and password MD5 hash:
```text
"postgres" "YourSecurePasswordHere"
```

Apply as a Kubernetes Secret and ConfigMap:
```bash
# Create namespace
kubectl create namespace qa-platform

# Secret for userlist
kubectl create secret generic pgbouncer-auth --from-file=userlist.txt=/tmp/userlist.txt -n qa-platform

# ConfigMap for pgbouncer.ini (copy enterprise/k8s/pgbouncer.ini contents)
kubectl create configmap pgbouncer-config --from-file=pgbouncer.ini=enterprise/k8s/pgbouncer.ini -n qa-platform
```

### B. Apply pgBouncer Deployment
Deploy pgBouncer to act as the transaction-level proxy service for Kubernetes pods:
```yaml
# pgbouncer-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: postgres-bouncer
  namespace: qa-platform
spec:
  replicas: 2
  selector:
    matchLabels:
      app: postgres-bouncer
  template:
    metadata:
      labels:
        app: postgres-bouncer
    spec:
      containers:
      - name: pgbouncer
        image: edoburu/pgbouncer:latest
        ports:
        - containerPort: 6432
        volumeMounts:
        - name: config-volume
          mountPath: /etc/pgbouncer
        - name: auth-volume
          mountPath: /etc/pgbouncer/userlist.txt
          subPath: userlist.txt
      volumes:
      - name: config-volume
        configMap:
          name: pgbouncer-config
      - name: auth-volume
        secret:
          secretName: pgbouncer-auth
---
apiVersion: v1
kind: Service
metadata:
  name: postgres-bouncer-svc
  namespace: qa-platform
spec:
  ports:
  - port: 6432
    targetPort: 6432
  selector:
    app: postgres-bouncer
```
Apply using:
```bash
kubectl apply -f pgbouncer-deployment.yaml
```

---

## 5. Step 4: Deploy the Stateless Math Service

Update the image parameter in [deployment.yaml](file:///Users/deepak/Desktop/Quantum%20Annealer/enterprise/k8s/deployment.yaml) to point to your ECR registry URL. Update the namespace to `qa-platform` and target `postgres-bouncer-svc` as host.

Apply the deployment and HPA configurations:
```bash
# Deploy pods
kubectl apply -f enterprise/k8s/deployment.yaml -n qa-platform

# Apply auto-scaling policies
kubectl apply -f enterprise/k8s/hpa.yaml -n qa-platform
```

---

## 6. Step 5: Configure ALB / Ingress Controller (HTTPS & gRPC routing)

Install the AWS Load Balancer Controller using Helm to provision an Application Load Balancer (ALB) dynamically:
```bash
helm repo add eks https://aws.github.io/eks-charts
helm install aws-load-balancer-controller eks/aws-load-balancer-controller \
  -n kube-system \
  --set clusterName=qa-eks-cluster
```

Deploy the Ingress manifest to route external traffic to your REST and gRPC endpoints:
```yaml
# ingress.yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: qa-math-ingress
  namespace: qa-platform
  annotations:
    kubernetes.io/ingress.class: alb
    alb.ingress.kubernetes.io/scheme: internet-facing
    alb.ingress.kubernetes.io/target-type: ip
    # Configures ALB to support both HTTP/1.1 REST and HTTP/2 gRPC traffic
    alb.ingress.kubernetes.io/backend-protocol-version: GRPC
spec:
  rules:
  - host: api.yourfirm.com
    http:
      paths:
      - path: /regime
        pathType: Prefix
        backend:
          service:
            name: qa-math-service-svc
            port:
              number: 8000
      - path: /mathservice.MathService
        pathType: Prefix
        backend:
          service:
            name: qa-math-service-svc
            port:
              number: 50051
```
Apply using:
```bash
kubectl apply -f ingress.yaml
```

Your REST API docs will now be live at `https://api.yourfirm.com/docs` and gRPC client requests can connect to `api.yourfirm.com:443`.
