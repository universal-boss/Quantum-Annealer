"""
enterprise/connectors/arrow_flight_server.py
============================================
High-speed data transport using Apache Arrow Flight gRPC protocol.
Enables zero-copy network streaming of price history and factor exposures
between quantitative compute nodes.
"""
from __future__ import annotations

import os
import json
import logging
import threading
import socket
from typing import Dict, List, Any, Optional

try:
    import pyarrow as pa
    import pyarrow.flight as flight
    HAS_FLIGHT = True
except ImportError:
    HAS_FLIGHT = False

try:
    import pandas as pd
except ImportError:
    pd = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)


if HAS_FLIGHT:
    class QuantumPortfolioFlightServer(flight.FlightServerBase):
        """Apache Arrow Flight gRPC server for quantitative datasets."""

        def __init__(self, host: str = "localhost", port: int = 5005, **kwargs):
            location = f"grpc://{host}:{port}"
            super().__init__(location, **kwargs)
            self._host = host
            self._port = port
            self.datasets: Dict[str, pa.Table] = {}
            logger.info(f"[FlightServer] Initializing Arrow Flight server at {location}...")

        def register_dataset(self, name: str, df: pd.DataFrame):
            """Register a Pandas DataFrame as an Arrow Table dataset on the server."""
            table = pa.Table.from_pandas(df)
            self.datasets[name] = table
            logger.info(f"[FlightServer] Registered dataset '{name}' ({len(df)} rows).")

        def _make_flight_info(self, key: str, table: pa.Table) -> flight.FlightInfo:
            """Build FlightInfo description for a dataset."""
            descriptor = flight.FlightDescriptor.for_path(key)
            endpoints = [flight.FlightEndpoint(key, [f"grpc://{self._host}:{self._port}"])]
            schema = table.schema
            return flight.FlightInfo(
                schema,
                descriptor,
                endpoints,
                table.num_rows,
                table.nbytes
            )

        def list_flights(self, context, criteria):
            """List all available datasets/flights on the server."""
            for key, table in self.datasets.items():
                yield self._make_flight_info(key, table)

        def get_flight_info(self, context, descriptor):
            """Get metadata info for a specific dataset descriptor."""
            key = descriptor.path[0].decode('utf-8')
            if key in self.datasets:
                return self._make_flight_info(key, self.datasets[key])
            raise KeyError(f"Dataset '{key}' not found.")

        def do_get(self, context, ticket):
            """Stream the requested dataset (Ticket) to the client."""
            key = ticket.ticket.decode('utf-8')
            if key in self.datasets:
                table = self.datasets[key]
                # Return Flight stream of RecordBatches
                return flight.RecordBatchStream(table)
            raise KeyError(f"Dataset '{key}' not found.")

        def do_put(self, context, descriptor, reader, writer):
            """Accept incoming dataset stream (RecordBatches) and write to datasets dictionary."""
            key = descriptor.path[0].decode('utf-8')
            # Read all incoming batches into a PyArrow Table
            table = reader.read_all()
            if key in self.datasets:
                # Append to existing dataset if schemas match
                try:
                    import pyarrow as pa
                    self.datasets[key] = pa.concat_tables([self.datasets[key], table])
                except Exception:
                    self.datasets[key] = table  # Overwrite on schema mismatch
            else:
                self.datasets[key] = table
            logger.info(f"[FlightServer] Received data stream for '{key}' ({table.num_rows} rows).")


class QuantumPortfolioFlightClient:
    """Arrow Flight client wrapper to pull and push datasets on the Flight server."""

    def __init__(self, host: str = "localhost", port: int = 5005):
        self.location = f"grpc://{host}:{port}"
        self.client = None
        if HAS_FLIGHT:
            self.client = flight.connect(self.location)

    def fetch_dataset(self, name: str) -> pd.DataFrame:
        """Fetch a dataset from the Flight server by name and return as Pandas DataFrame."""
        if not HAS_FLIGHT:
            raise RuntimeError("pyarrow.flight is not installed.")
        
        if not self.client:
            raise RuntimeError("Flight client not connected.")

        # Ticket represents the identifier of the dataset
        ticket = flight.Ticket(name.encode('utf-8'))
        reader = self.client.do_get(ticket)
        table = reader.read_all()
        return table.to_pandas()

    def stream_dataset(self, name: str, df: pd.DataFrame):
        """Stream a Pandas DataFrame to the Flight server using do_put."""
        if not HAS_FLIGHT:
            raise RuntimeError("pyarrow.flight is not installed.")
        
        if not self.client:
            raise RuntimeError("Flight client not connected.")

        table = pa.Table.from_pandas(df)
        descriptor = flight.FlightDescriptor.for_path(name)
        
        # Start the put operation
        writer, _ = self.client.do_put(descriptor, table.schema)
        with writer:
            writer.write_table(table)
        logger.info(f"[FlightClient] Streamed dataset '{name}' ({len(df)} rows) to server.")



def find_free_port() -> int:
    """Utility to find an open port for testing."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(('', 0))
        return s.getsockname()[1]
