import sys
import os
import json
import uuid
import datetime
import logging
import traceback
from typing import Dict, List, Optional, Callable
import threading
import time

try:
    from enterprise.connectors.matching_engine import MatchingEngine
except ImportError:
    MatchingEngine = None

try:
    from enterprise.execution_algos.smart_router import generate_child_orders
except ImportError:
    def generate_child_orders(*args, **kwargs): return []

logger = logging.getLogger("fix_connector")

# AUDIT-FIX (defect #P1-16): previously a silent ImportError fallback bound `fix`
# to a MockFIX() that returned True from sendToTarget() — so on hosts without the
# native quickfix library (notably Apple Silicon, per requirements.txt), every
# outbound order silently appeared "sent" with no socket, no FIX session, and no
# counter-party. The operator had no signal that the wire was dead.
#
# Remediation: the mock is still constructed (so the module imports cleanly for
# local development), but we now (a) log an ERROR-level announcement the first
# time the mock is bound, (b) expose a module-level `_FIX_NATIVE` flag, and
# (c) raise `MockFIXOrderError` from `Session.sendToTarget` unless the operator
# explicitly sets env `FIX_ALLOW_MOCK=1` to acknowledge that orders will not
# reach a counter-party.
_FIX_NATIVE = False

try:
    import quickfix as fix
    _FIX_NATIVE = True
except ImportError as _fix_import_err:
    class MockFIXOrderError(RuntimeError):
        """Raised when an order would be sent through the mock FIX adapter
        without explicit operator acknowledgement (FIX_ALLOW_MOCK=1)."""
        pass

    # R47-4 FIX (Round 47): MockFIX.Message used to be `class Message: pass`.
    # The main send_order path (and, after the R47-4 algo-child remediation,
    # the child path too) builds messages via getHeader()/setField() with the
    # standard quickfix field classes — none of which existed on the mock —
    # so in mock mode EVERY send_order raised AttributeError at message
    # construction (before the routing decision, before the audit ORDER_SENT
    # event), and the module's own __main__ demo crashed. The mock now
    # implements a minimal tag-store message + the FIX 4.4 field classes the
    # connector uses, so the construction path is complete and testable
    # offline. The P1-16 safety policy is UNCHANGED: Session.sendToTarget
    # still refuses to pretend an order was delivered unless the operator
    # sets FIX_ALLOW_MOCK=1.
    class _MockFixField:
        """Minimal stand-in for a quickfix field (typed or StringField)."""
        def __init__(self, tag=None, value=None):
            self.tag = tag
            self.value = value
        def getString(self):
            return str(self.value)
        def setValue(self, v):
            self.value = v

    class _MockFixHeader:
        """Header view over a MockMessage's tag store (real quickfix headers
        share the message's field space)."""
        def __init__(self, message):
            self._msg = message
        def setField(self, field):
            self._msg._fields[field.tag] = field.value

    class MockMessage:
        def __init__(self):
            self._fields = {}
        def getHeader(self):
            return _MockFixHeader(self)
        def setField(self, field):
            self._fields[field.tag] = field.value
        def getField(self, field):
            if field.tag not in self._fields:
                raise KeyError(f"tag {field.tag} not set on mock message")
            field.setValue(self._fields[field.tag])
            return field
        def hasField(self, tag):
            return tag in self._fields
        def getTagValue(self, tag):
            return self._fields.get(tag)

    # Typed field classes with their FIX 4.4 tags (same construction API as
    # quickfix: ClOrdID("x"), Side(fix.Side_BUY), StringField(tag), ...).
    class ClOrdID(_MockFixField):
        def __init__(self, value=None):
            super().__init__(11, value)
    class Symbol(_MockFixField):
        def __init__(self, value=None):
            super().__init__(55, value)
    class Side(_MockFixField):
        def __init__(self, value=None):
            super().__init__(54, value)
    class OrderQty(_MockFixField):
        def __init__(self, value=None):
            super().__init__(38, value)
    class OrdType(_MockFixField):
        def __init__(self, value=None):
            super().__init__(40, value)
    class Price(_MockFixField):
        def __init__(self, value=None):
            super().__init__(44, value)
    class TransactType(_MockFixField):
        def __init__(self, value=None):
            super().__init__(20, value)
    class TimeInForce(_MockFixField):
        def __init__(self, value=None):
            super().__init__(59, value)
    class MsgType(_MockFixField):
        def __init__(self, value=None):
            super().__init__(35, value)
    class StringField(_MockFixField):
        def __init__(self, tag=None, value=None):
            super().__init__(tag, value)

    # FIX 4.4 constants used by the connector (values as transmitted).
    MsgType_NewOrderSingle = "D"
    Side_BUY = "1"
    Side_SELL = "2"
    OrdType_LIMIT = "2"
    OrdType_MARKET = "1"
    TimeInForce_DAY = "0"

    class MockFIX:
        class Application: pass
        class SessionID: pass
        Message = MockMessage
        ClOrdID = ClOrdID
        Symbol = Symbol
        Side = Side
        OrderQty = OrderQty
        OrdType = OrdType
        Price = Price
        TransactType = TransactType
        TimeInForce = TimeInForce
        MsgType = MsgType
        StringField = StringField
        MsgType_NewOrderSingle = MsgType_NewOrderSingle
        Side_BUY = Side_BUY
        Side_SELL = Side_SELL
        OrdType_LIMIT = OrdType_LIMIT
        OrdType_MARKET = OrdType_MARKET
        TimeInForce_DAY = TimeInForce_DAY
        class Session:
            @staticmethod
            def sendToTarget(msg, sessionID=None):
                # Hard failure: refuse to silently mock-send an order.
                if os.environ.get("FIX_ALLOW_MOCK") == "1":
                    logger.error(
                        "[FIX] MOCK order 'sent' (FIX_ALLOW_MOCK=1 acknowledged) — "
                        "no counter-party will receive this message."
                    )
                    return True
                raise MockFIXOrderError(
                    "FIX native library unavailable; refusing to silently mock-send "
                    "order. Install quickfix on the deployment host or set "
                    "FIX_ALLOW_MOCK=1 to acknowledge mock mode."
                )
    fix = MockFIX()
    logger.error(
        "[FIX] native quickfix unavailable (%s); FIX connector entering MOCK mode. "
        "No orders will reach a counter-party until FIX_ALLOW_MOCK=1 is set or "
        "quickfix is installed on the host.",
        _fix_import_err,
    )

# AUDIT-FIX (defect #P1-16) note: duplicate logger definition below kept for backward
# compatibility with any external code that imports the symbol from this module; the
# canonical definition now lives above the try/except so the mock-mode ERROR log can
# use it.
logger = logging.getLogger("fix_connector")

class AuditLogger:
    """Immutable FIX audit logging (5.5)"""
    def __init__(self, log_path: str = "fix_audit.log", db_pool=None):
        self.log_path = log_path
        self.lock = threading.Lock()
        self.db_pool = db_pool
        # H11-fix: track context managers returned by DatabaseConnectionPool.connection()
        # so _pool_put can exit them. Keyed by id(conn).
        self._active_cms = {}
        if db_pool is not None:
            try:
                # BUG-F1 FIX: psycopg2 connection pools use getconn()/putconn(),
                # not db_pool.connection() context manager (that's SQLAlchemy API).
                # This pattern works for both psycopg2.pool and SQLAlchemy pools.
                conn = self._pool_get()
                try:
                    with conn.cursor() as cur:
                        cur.execute("""
                            CREATE TABLE IF NOT EXISTS fix_audit_log (
                                id             BIGSERIAL PRIMARY KEY,
                                timestamp_utc  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                                event_type     VARCHAR(64)  NOT NULL,
                                details        JSONB,
                                created_at     TIMESTAMPTZ  NOT NULL DEFAULT NOW()
                            );
                        """)
                        try:
                            cur.execute("CREATE RULE no_update_audit AS ON UPDATE TO fix_audit_log DO INSTEAD NOTHING;")
                        except Exception:
                            pass
                        try:
                            cur.execute("CREATE RULE no_delete_audit AS ON DELETE TO fix_audit_log DO INSTEAD NOTHING;")
                        except Exception:
                            pass
                    conn.commit()
                finally:
                    self._pool_put(conn)
            except Exception as e:
                logger.error(f"[Audit] Failed to initialize PostgreSQL audit log table: {e}")

    def _pool_get(self):
        """Get a connection from pool — handles psycopg2, SQLAlchemy, and DatabaseConnectionPool."""
        if hasattr(self.db_pool, 'getconn'):
            # psycopg2 connection pool
            return self.db_pool.getconn()
        elif hasattr(self.db_pool, 'connect'):
            # SQLAlchemy engine
            return self.db_pool.connect()
        elif hasattr(self.db_pool, 'connection'):
            # H11-fix: DatabaseConnectionPool.connection() is a @contextmanager and returns
            # a _GeneratorContextManager, not a raw connection. Enter it to extract the conn
            # and stash the cm so _pool_put can exit it cleanly.
            result = self.db_pool.connection()
            if hasattr(result, '__enter__'):
                conn = result.__enter__()
                self._active_cms[id(conn)] = result
                return conn
            return result
        raise AttributeError(f"Unknown db_pool type: {type(self.db_pool)}")

    def _pool_put(self, conn):
        """Return a connection to pool — handles psycopg2, SQLAlchemy, and DatabaseConnectionPool."""
        try:
            # H11-fix: if this conn came from a context manager, exit the cm to release it.
            cm = self._active_cms.pop(id(conn), None)
            if cm is not None:
                cm.__exit__(None, None, None)
                return
            if hasattr(self.db_pool, 'putconn'):
                # psycopg2 connection pool
                self.db_pool.putconn(conn)
            else:
                # SQLAlchemy connection — close returns it to pool
                conn.close()
        except Exception as e:
            logger.warning(f"[Audit] Could not return connection to pool: {e}")

    def log_event(self, event_type: str, details: dict):
        # Application-layer immutable log (append-only)
        entry = {
            "timestamp": datetime.datetime.utcnow().isoformat() + "Z",
            "event_type": event_type,
            "details": details
        }
        with self.lock:
            with open(self.log_path, "a") as f:
                f.write(json.dumps(entry) + "\n")

        if self.db_pool is not None:
            try:
                conn = self._pool_get()
                try:
                    with conn.cursor() as cur:
                        cur.execute("""
                            INSERT INTO fix_audit_log (timestamp_utc, event_type, details)
                            VALUES (%s, %s, %s)
                        """, (entry["timestamp"], event_type, json.dumps(details)))
                    conn.commit()
                finally:
                    self._pool_put(conn)
            except Exception as e:
                logger.error(f"[Audit] Dual-write to PostgreSQL failed: {e}")

class PreTradeRiskEngine:
    """SEC Rule 15c3-5 Pre-Trade Checks (5.2)"""
    def __init__(self, audit_logger: AuditLogger):
        self.kill_switch_active = False
        self.max_order_qty = 100000
        self.max_notional = 50000000.0  # e.g. 50M
        self.audit = audit_logger
        self.positions: Dict[str, int] = {}
        self.position_limit = 500000
        self.lock = threading.Lock()

    def activate_kill_switch(self):
        self.kill_switch_active = True
        self.audit.log_event("KILL_SWITCH_ACTIVATED", {"reason": "Manual or system triggered"})

    def check_order(self, symbol: str, side: str, qty: int, price: float) -> bool:
        if self.kill_switch_active:
            self.audit.log_event("ORDER_REJECTED", {"reason": "Kill switch active", "symbol": symbol})
            return False

        # Fat-finger checks
        if qty > self.max_order_qty:
            self.audit.log_event("ORDER_REJECTED", {"reason": "Fat-finger QTY limit exceeded", "qty": qty, "limit": self.max_order_qty})
            return False

        notional = qty * price
        if notional > self.max_notional:
            self.audit.log_event("ORDER_REJECTED", {"reason": "Fat-finger NOTIONAL limit exceeded", "notional": notional, "limit": self.max_notional})
            return False

        # Position limits
        with self.lock:
            current_pos = self.positions.get(symbol, 0)
            new_pos = current_pos + qty if side == "BUY" else current_pos - qty
            if abs(new_pos) > self.position_limit:
                self.audit.log_event("ORDER_REJECTED", {"reason": "Position limit exceeded", "symbol": symbol, "new_pos": new_pos, "limit": self.position_limit})
                return False

            # Phase 5.6: Reserve projected position to prevent bypass via rapid-fire orders.
            # Previously: new_pos was computed but NEVER written back to self.positions.
            # A strategy could submit N orders of size position_limit in rapid succession —
            # ALL passed the check because each call saw the stale pre-fill position.
            # The SEC Rule 15c3-5 pre-trade check was effectively bypassed for any
            # strategy that fired faster than fills arrived.
            # Now: write the projected position back immediately (reserved), then
            # reconcile against actual fills in update_execution.
            self.positions[symbol] = new_pos

        return True

class ExecutionStateMachine:
    """ExecutionReport lifecycle state machine (5.3)"""
    STATES = ["NEW", "PARTIALLY_FILLED", "FILLED", "CANCELED", "REJECTED"]
    
    def __init__(self, event_callback: Optional[Callable] = None, risk_engine: Optional[PreTradeRiskEngine] = None, audit_logger: Optional[AuditLogger] = None):
        self.orders: Dict[str, dict] = {}
        self.lock = threading.Lock()
        self.event_callback = event_callback
        self.risk_engine = risk_engine
        self.audit = audit_logger
        
    def create_order(self, cl_ord_id: str, symbol: str, side: str, qty: int):
        with self.lock:
            self.orders[cl_ord_id] = {
                "symbol": symbol,
                "side": side,
                "qty": qty,
                "cum_qty": 0,
                "status": "NEW",
                "avg_price": 0.0
            }
            if self.event_callback:
                self.event_callback({
                    "event": "ORDER_CREATED",
                    "id": cl_ord_id,
                    **self.orders[cl_ord_id]
                })
            
    def update_execution(self, cl_ord_id: str, exec_type: str, last_qty: int, last_px: float = 0.0):
        with self.lock:
            if cl_ord_id not in self.orders:
                return
            order = self.orders[cl_ord_id]
            if exec_type == "REJECTED":
                order["status"] = "REJECTED"
                # AUDIT-FIX (Round 6, E-P2-3): the pre-trade position
                # RESERVATION was never released on rejection/cancel — a
                # phantom position persisted forever, halving the effective
                # position limit and poisoning EOD reconciliation.
                #
                # R47-3 FIX (Round 47): the release is now IDEMPOTENT. FIX
                # retransmissions / duplicate ExecutionReports are routine
                # (gap-fill, resend requests), and each duplicate REJECTED or
                # CANCELED report used to subtract the unfilled remainder a
                # SECOND time — driving positions negative and re-creating the
                # exact phantom-position failure mode this fix originally
                # addressed, but in the opposite direction. A per-order flag
                # guarantees the reservation is released exactly once.
                if self.risk_engine is not None and not order.get("_res_released"):
                    order["_res_released"] = True
                    with self.risk_engine.lock:
                        _sym = order["symbol"]
                        _res_qty = order["qty"] - order.get("cum_qty", 0)
                        if _res_qty > 0:
                            _delta = -_res_qty if order["side"] == "BUY" else _res_qty
                            self.risk_engine.positions[_sym] = self.risk_engine.positions.get(_sym, 0) + _delta
            elif exec_type == "CANCELED":
                order["status"] = "CANCELED"
                # AUDIT-FIX (Round 6, E-P2-3): release the un-filled remainder.
                # R47-3 FIX (Round 47): idempotent release — see REJECTED above.
                if self.risk_engine is not None and not order.get("_res_released"):
                    order["_res_released"] = True
                    with self.risk_engine.lock:
                        _sym = order["symbol"]
                        _res_qty = order["qty"] - order.get("cum_qty", 0)
                        if _res_qty > 0:
                            _delta = -_res_qty if order["side"] == "BUY" else _res_qty
                            self.risk_engine.positions[_sym] = self.risk_engine.positions.get(_sym, 0) + _delta
            elif exec_type == "TRADE":
                old_cum = order["cum_qty"]
                new_cum = old_cum + last_qty
                if new_cum > 0:
                    order["avg_price"] = ((order.get("avg_price", 0.0) * old_cum) + (last_px * last_qty)) / new_cum
                order["cum_qty"] = new_cum
                
                if order["cum_qty"] >= order["qty"]:
                    order["status"] = "FILLED"
                else:
                    order["status"] = "PARTIALLY_FILLED"
                
                # Update risk engine position tracking on fills
                # AUDIT-FIX (Round 6, E-P2-3): the pre-trade check RESERVES the
                # projected position (qty added to positions at order time),
                # so a fill previously ADDING last_qty on top double-counted
                # every fill (repro: BUY 100 fully filled → positions 200).
                #
                # R47-2 FIX (Round 47): the previous remediation SET
                # positions[sym] to THIS order's (filled + remaining)
                # contribution — which silently WIPED every OTHER working
                # order's contribution on the same symbol (repro: order A BUY
                # 100 fully filled → positions=100; order B BUY 100 reserved →
                # positions=200; a 40-share partial fill on B SET positions=100,
                # erasing A's real 100-share position). The SEC 15c3-5-style
                # position limit could then be bypassed by exactly the
                # rapid-fire multi-order pattern the reservation was built to
                # stop. The update is now DELTA-BASED: each order contributes
                # (filled + remaining-reserved) from the moment it is checked,
                # and a fill merely converts reserved quantity into filled
                # quantity (net delta 0) — other orders' contributions are
                # never touched.
                if self.risk_engine is not None:
                    with self.risk_engine.lock:
                        sym = order["symbol"]
                        _sign = 1 if order["side"] == "BUY" else -1
                        _contribution = (
                            lambda filled: _sign
                            * (min(filled, order["qty"]) + max(order["qty"] - filled, 0))
                        )
                        _prev = _contribution(old_cum)
                        _new = _contribution(order["cum_qty"])
                        self.risk_engine.positions[sym] = (
                            self.risk_engine.positions.get(sym, 0) + (_new - _prev)
                        )
                        
                # Log execution report event
                if self.audit is not None:
                    self.audit.log_event("EXECUTION_REPORT", {
                        "cl_ord_id": cl_ord_id,
                        "exec_type": "TRADE",
                        "status": order["status"],
                        "last_qty": last_qty,
                        "last_px": last_px
                    })
                    
            if self.event_callback:
                self.event_callback({
                    "event": "EXECUTION",
                    "id": cl_ord_id,
                    "exec_type": exec_type,
                    "last_qty": last_qty,
                    **order
                })

class QuantumFIXApplication(fix.Application):
    """
    FIX Connector implementation with QuickFIX (5.1)
    Handles logon, logout, admin messages, and application messages.
    """
    def __init__(self, risk_engine: PreTradeRiskEngine, audit_logger: AuditLogger, matching_engine: Optional[MatchingEngine] = None, event_callback: Optional[Callable] = None):
        super().__init__()
        self.risk_engine = risk_engine
        self.audit = audit_logger
        self.state_machine = ExecutionStateMachine(event_callback, risk_engine, audit_logger)
        self.session_id = None
        self.matching_engine = matching_engine
        self.event_callback = event_callback
        # R47-4: per-parent child ClOrdID sequence for algo orders routed to a
        # live FIX session (FIX requires a unique ClOrdID per NewOrderSingle).
        self._algo_child_seq: Dict[str, int] = {}
        
        # Load data dictionary if running with real quickfix
        try:
            if hasattr(fix, "DataDictionary"):
                self.data_dict = fix.DataDictionary("enterprise/connectors/FIX44.xml")
        except Exception as e:
            logger.warning(f"Could not load FIX44.xml: {e}")
            
    def onCreate(self, sessionID):
        self.session_id = sessionID
        self.audit.log_event("SESSION_CREATED", {"session": str(sessionID)})
        
    def onLogon(self, sessionID):
        self.audit.log_event("LOGON", {"session": str(sessionID)})
        
    def onLogout(self, sessionID):
        self.audit.log_event("LOGOUT", {"session": str(sessionID)})
        
    def toAdmin(self, message, sessionID):
        pass
        
    def fromAdmin(self, message, sessionID):
        pass
        
    def toApp(self, message, sessionID):
        # Outbound checks if necessary
        pass
        
    def fromApp(self, message, sessionID):
        """Parse inbound FIX messages and update execution state."""
        try:
            msg_type = self._extract_field(message, tag=35)
            if msg_type == "8":  # ExecutionReport
                self._handle_execution_report(message)
            elif msg_type == "9":  # OrderCancelReject
                self._handle_cancel_reject(message)
            elif msg_type == "j":  # BusinessMessageReject
                self._handle_business_reject(message)
        except Exception as e:
            self.audit.log_event("APP_MESSAGE_ERROR", {
                "error": str(e),
                "traceback": traceback.format_exc()
            })

    def _handle_execution_report(self, message):
        """
        FIX Tag reference:
          11  = ClOrdID (our order ID)
          17  = ExecID
          39  = OrdStatus (0=New, 1=PartialFill, 2=Fill, 4=Canceled, 8=Rejected)
          150 = ExecType (0=New, F=Trade, 4=Canceled, 8=Rejected)
          32  = LastQty (shares filled this report)
          31  = LastPx (fill price this report)
        """
        cl_ord_id = self._extract_field(message, tag=11)
        exec_type = self._extract_field(message, tag=150)
        last_qty  = int(self._extract_field(message, tag=32) or 0)
        last_px   = float(self._extract_field(message, tag=31) or 0.0)
        ord_status = self._extract_field(message, tag=39)

        exec_type_map = {
            "0": "NEW", "F": "TRADE", "4": "CANCELED",
            "8": "REJECTED", "E": "PENDING_REPLACE", "6": "PENDING_CANCEL"
        }
        mapped = exec_type_map.get(str(exec_type), "UNKNOWN")

        self.state_machine.update_execution(cl_ord_id, mapped, last_qty, last_px)

        self.audit.log_event("EXECUTION_REPORT", {
            "cl_ord_id": cl_ord_id,
            "exec_type": mapped,
            "ord_status": ord_status,
            "last_qty": last_qty,
            "last_px": last_px
        })

    def _handle_cancel_reject(self, message):
        cl_ord_id = self._extract_field(message, tag=11)
        orig_cl_ord_id = self._extract_field(message, tag=41)
        self.audit.log_event("ORDER_CANCEL_REJECTED", {
            "cl_ord_id": cl_ord_id,
            "orig_cl_ord_id": orig_cl_ord_id
        })

    def _handle_business_reject(self, message):
        ref_seq_num = self._extract_field(message, tag=45)
        text = self._extract_field(message, tag=58)
        self.audit.log_event("BUSINESS_MESSAGE_REJECT", {
            "ref_seq_num": ref_seq_num,
            "text": text
        })

    def _extract_field(self, message, tag: int) -> str:
        """Safe field extraction — works with real quickfix or mock."""
        try:
            if hasattr(message, 'getField'):
                field = fix.StringField(tag)
                message.getField(field)
                return field.getString()
            else:
                # If mock message is a dict-like or object with attributes
                if hasattr(message, 'get'):
                    return str(message.get(tag, ""))
                return ""
        except Exception as e:
            # L31-fix: log the swallowed exception so missing FIX tags are visible
            logger.warning(f"[FIX] _extract_field failed for tag {tag}: {type(e).__name__}: {e}")
            return ""

    def send_order(self, symbol: str, side: str, qty: int, price: float, algo: str = None, algo_duration_mins: int = 60, time_compression: float = 1.0):
        # 1. Pre-trade risk check
        if not self.risk_engine.check_order(symbol, side, qty, price):
            logger.warning(f"Order rejected by pre-trade risk engine: {symbol} {side} {qty}")
            return None
            
        cl_ord_id = str(uuid.uuid4())
        
        # 2. State machine creation
        self.state_machine.create_order(cl_ord_id, symbol, side, qty)
        
        # 3. FIX Message construction
        # AUDIT-FIX (Round 6, E-P2-5): the previous construction built a BARE
        # fix.Message() — no MsgType, no tags (11/54/55/38/40/44) — so
        # sendToTarget shipped an empty NewOrderSingle that no acceptor could
        # execute while the audit trail logged ORDER_SENT. Populate the
        # standard FIX 4.4 NewOrderSingle fields now.
        msg = fix.Message()
        _hdr = msg.getHeader()
        _hdr.setField(fix.MsgType(fix.MsgType_NewOrderSingle))
        msg.setField(fix.ClOrdID(cl_ord_id))
        msg.setField(fix.Symbol(symbol))
        msg.setField(fix.Side(fix.Side_BUY if str(side).upper() == "BUY" else fix.Side_SELL))
        msg.setField(fix.OrderQty(int(qty)))
        msg.setField(fix.OrdType(fix.OrdType_LIMIT if price and price > 0 else fix.OrdType_MARKET))
        if price and price > 0:
            msg.setField(fix.Price(float(price)))
        msg.setField(fix.TransactType(0))
        msg.setField(fix.TimeInForce(fix.TimeInForce_DAY))
        
        # 4. Audit
        self.audit.log_event("ORDER_SENT", {"cl_ord_id": cl_ord_id, "symbol": symbol, "side": side, "qty": qty, "price": price, "algo": algo})
        
        # 5. Routing
        if algo and algo.upper() in ["VWAP", "TWAP"]:
            logger.info(f"Routing {qty} {symbol} via {algo} over {algo_duration_mins} mins (Compression: {time_compression}x)")
            schedule = generate_child_orders(algo, qty, algo_duration_mins, intervals=10)
            
            # Spin off background execution loop to drip-feed child orders
            t = threading.Thread(target=self._algo_execution_loop, args=(cl_ord_id, symbol, side, price, schedule, time_compression), daemon=True)
            t.start()
        else:
            if self.matching_engine:
                self.matching_engine.submit_order(cl_ord_id, symbol, side, qty, price)
            elif self.session_id:
                fix.Session.sendToTarget(msg, self.session_id)
                
        return cl_ord_id

    def _algo_execution_loop(self, cl_ord_id: str, symbol: str, side: str, price: float, schedule: list, time_compression: float):
        last_time = 0.0
        for delay_secs, chunk_qty in schedule:
            wait_time = (delay_secs - last_time) / time_compression
            if wait_time > 0:
                time.sleep(wait_time)
            last_time = delay_secs
            
            # Submit child chunk
            logger.info(f"[{symbol} ALGO] Releasing child order chunk: {chunk_qty}")
            
            if self.event_callback:
                self.event_callback({
                    "event": "ALGO_CHILD_ORDER",
                    "parent_id": cl_ord_id,
                    "symbol": symbol,
                    "side": side,
                    "qty": chunk_qty,
                    "price": price
                })
                
            if self.matching_engine:
                # We reuse the parent cl_ord_id so ExecutionStateMachine cleanly aggregates the fills.
                # (R47-5: the matching engine now ACCUMULATES same-ID resubmissions
                # instead of overwriting the working order — see its submit_order.)
                self.matching_engine.submit_order(cl_ord_id, symbol, side, chunk_qty, price)
            elif self.session_id:
                # R47-4 FIX (Round 47): this branch previously shipped a BARE
                # fix.Message() — no MsgType, no tags — the exact empty-
                # NewOrderSingle defect the E-P2-5 remediation fixed on the
                # main send_order path, regressed into the algo child path
                # ("Mock sending child order via FIX"). On a live FIX session
                # every child chunk was an empty message while the audit log
                # recorded a real release. Each child now carries a unique
                # child ClOrdID (FIX requires uniqueness per NewOrderSingle)
                # and a complete field set, and is registered in the execution
                # state machine so its fills are tracked (position tracking is
                # symbol-level, so the pre-checked parent reservation keeps
                # the 15c3-5 math correct).
                child_cl_ord_id = f"{cl_ord_id}-C{self._algo_child_seq.get(cl_ord_id, 0) + 1:03d}"
                self._algo_child_seq[cl_ord_id] = self._algo_child_seq.get(cl_ord_id, 0) + 1
                _child_msg = fix.Message()
                _chdr = _child_msg.getHeader()
                _chdr.setField(fix.MsgType(fix.MsgType_NewOrderSingle))
                _child_msg.setField(fix.ClOrdID(child_cl_ord_id))
                _child_msg.setField(fix.Symbol(symbol))
                _child_msg.setField(fix.Side(fix.Side_BUY if str(side).upper() == "BUY" else fix.Side_SELL))
                _child_msg.setField(fix.OrderQty(int(chunk_qty)))
                _child_msg.setField(fix.OrdType(fix.OrdType_LIMIT if price and price > 0 else fix.OrdType_MARKET))
                if price and price > 0:
                    _child_msg.setField(fix.Price(float(price)))
                _child_msg.setField(fix.TransactType(0))
                _child_msg.setField(fix.TimeInForce(fix.TimeInForce_DAY))
                self.state_machine.create_order(child_cl_ord_id, symbol, side, int(chunk_qty))
                fix.Session.sendToTarget(_child_msg, self.session_id)

class EODReconciler:
    """EOD Independent Reconciliation Hook (5.4)"""
    def __init__(self, state_machine: ExecutionStateMachine, audit_logger: AuditLogger):
        self.state_machine = state_machine
        self.audit = audit_logger
        
    def run_reconciliation(self, broker_eod_file: str) -> dict:
        """Compare internal position book against broker drop copy."""
        self.audit.log_event("RECONCILIATION_STARTED", {"file": broker_eod_file})
        logger.info(f"Running EOD reconciliation against {broker_eod_file}")

        mismatches = []
        broker_positions = {}
        try:
            import csv
            with open(broker_eod_file, newline='') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    if 'Symbol' in row and 'NetQty' in row:
                        broker_positions[row['Symbol'].strip().upper()] = int(row['NetQty'])
        except Exception as e:
            self.audit.log_event("RECONCILIATION_FAILED",
                                 {"reason": f"Failed to read broker file: {e}"})
            return {"status": "FAILED", "mismatches": []}

        # Compare internal book against broker
        internal_positions = {}
        if hasattr(self.state_machine, "risk_engine") and self.state_machine.risk_engine is not None:
            with self.state_machine.risk_engine.lock:
                internal_positions = {k.strip().upper(): v for k, v in self.state_machine.risk_engine.positions.items()}
        
        all_symbols = set(internal_positions) | set(broker_positions)

        for sym in all_symbols:
            internal = internal_positions.get(sym, 0)
            broker   = broker_positions.get(sym, 0)
            if internal != broker:
                mismatches.append({
                    "symbol": sym,
                    "internal": internal,
                    "broker": broker,
                    "delta": broker - internal
                })
                logger.warning(
                    "[EOD] MISMATCH %s: internal=%d broker=%d delta=%+d",
                    sym, internal, broker, broker - internal
                )

        result = {
            "status": "SUCCESS" if not mismatches else "MISMATCH",
            "mismatches": mismatches,
            "mismatch_count": len(mismatches)
        }
        self.audit.log_event("RECONCILIATION_COMPLETED", result)
        return result

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    audit = AuditLogger("test_fix_audit.log")
    risk = PreTradeRiskEngine(audit)
    
    app = QuantumFIXApplication(risk, audit)
    
    # Optional: Spin up matching engine locally
    if MatchingEngine:
        me = MatchingEngine(fill_callback=app.state_machine.update_execution)
        app.matching_engine = me
        me.start()
        
    recon = EODReconciler(app.state_machine, audit)
    
    print("Testing block order...")
    app.send_order("RELIANCE", "BUY", 100, 2500.0)
    
    print("Waiting 3 seconds for block order fill...")
    time.sleep(3.0)
    
    print("Testing VWAP Algo execution (60 mins compressed)...")
    app.send_order("INFY", "BUY", 5000, 1500.0, algo="VWAP", algo_duration_mins=60, time_compression=600.0) # 60 mins -> 6 seconds
    
    print("Waiting 10 seconds for VWAP to complete...")
    time.sleep(10.0)
    
    risk.activate_kill_switch()
    print("Testing order with kill switch...")
    app.send_order("TCS", "BUY", 10, 3500.0)
    
    recon.run_reconciliation("dummy_broker_statement.csv")
    
    if MatchingEngine and app.matching_engine:
        app.matching_engine.stop()
