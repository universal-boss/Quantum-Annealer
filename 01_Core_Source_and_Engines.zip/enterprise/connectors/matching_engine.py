import threading
import time
import random
import uuid
import logging
from typing import Dict, List, Callable

logger = logging.getLogger("matching_engine")

class Order:
    def __init__(self, cl_ord_id: str, symbol: str, side: str, qty: int, price: float):
        self.cl_ord_id = cl_ord_id
        self.symbol = symbol
        self.side = side.upper()
        self.qty = qty
        self.price = price
        self.cum_qty = 0
        self.status = "NEW"
        self.leaves_qty = qty
        self.timestamp = time.time()

class MatchingEngine:
    """
    Local Limit Order Book (LOB) matching simulation.
    Injects realistic slippage and partial fills for strategy testing.
    """
    def __init__(self, fill_callback: Callable[[str, str, int, float], None]):
        """
        fill_callback signature:
        def callback(cl_ord_id: str, exec_type: str, last_qty: int, last_px: float)
        """
        self.orders: Dict[str, Order] = {}
        self.lock = threading.Lock()
        self.fill_callback = fill_callback
        self._running = False
        self._thread = None
        
    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._matching_loop, daemon=True)
        self._thread.start()
        logger.info("Matching engine simulation started.")
        
    def stop(self):
        self._running = False
        if self._thread:
            self._thread.join(timeout=1.0)
            
    def submit_order(self, cl_ord_id: str, symbol: str, side: str, qty: int, price: float):
        # R47-5 FIX (Round 47): same-ID resubmission previously OVERWROTE the
        # dict entry, silently discarding any still-working order under that
        # ID. The FIX connector's algo child-chunking intentionally reuses the
        # parent cl_ord_id for every chunk so ExecutionStateMachine aggregates
        # fills — so under a VWAP/TWAP schedule (especially with time
        # compression, e.g. the built-in 600x demo), each new chunk destroyed
        # the previous chunk's unfilled remainder: the parent could never
        # complete and fills silently vanished. A resubmission onto a WORKING
        # order now ACCUMULATES (qty/leaves_qty added, price refreshed); a
        # resubmission after a terminal state (FILLED/CANCELED/REJECTED)
        # starts a fresh working order under the same ID, as a new logical
        # slice of the same parent.
        _acked = False
        with self.lock:
            existing = self.orders.get(cl_ord_id)
            if existing is not None and existing.status in ("NEW", "PARTIALLY_FILLED"):
                existing.qty += int(qty)
                existing.leaves_qty += int(qty)
                existing.price = float(price)
                logger.info(
                    f"[Exchange] Accumulated child chunk onto working order "
                    f"{cl_ord_id}: +{int(qty)} (total qty={existing.qty}, "
                    f"leaves={existing.leaves_qty})"
                )
            else:
                self.orders[cl_ord_id] = Order(cl_ord_id, symbol, side, qty, price)
                _acked = True
        if _acked:
            logger.info(f"[Exchange] Accepted order: {side} {qty} {symbol} @ {price}")
            # Acknowledge the order
            self.fill_callback(cl_ord_id, "NEW", 0, 0.0)

    def cancel_order(self, cl_ord_id: str):
        # AUDIT-FIX (Round 6, E-P2-6): callback outside the lock (see above).
        _do_cb = False
        with self.lock:
            if cl_ord_id in self.orders:
                order = self.orders[cl_ord_id]
                if order.status not in ["FILLED", "CANCELED", "REJECTED"]:
                    order.status = "CANCELED"
                    _do_cb = True
                    logger.info(f"[Exchange] Canceled order: {cl_ord_id}")
        if _do_cb:
            self.fill_callback(cl_ord_id, "CANCELED", 0, 0.0)

    def _matching_loop(self):
        """Simulates stochastic market fills based on an internal tick model."""
        # AUDIT-FIX (Round 6, E-P2-6): fill_callback was invoked WHILE HOLDING
        # the engine lock — any OMS callback that re-enters the engine
        # (cancel/replace on ack) deadlocked the engine thread AND the caller
        # (repro: fill→cancel callback hung submit_order). State transitions
        # are now snapshotted under the lock and callbacks fire AFTER release.
        while self._running:
            time.sleep(1.0)  # Tick every second
            _fill_events = []
            with self.lock:
                active_orders = [o for o in self.orders.values() if o.status in ["NEW", "PARTIALLY_FILLED"]]
                
                for order in active_orders:
                    # Stochastic matching logic (Mocked volume profile)
                    # 70% chance of a fill occurring in this tick
                    if random.random() < 0.70:
                        # Determine fill quantity (random chunking to simulate partials)
                        fill_qty = random.randint(1, max(1, order.leaves_qty // 2) if order.leaves_qty > 1 else 1)
                        if order.leaves_qty - fill_qty < (order.qty * 0.1): 
                            # If remaining is tiny, just sweep it
                            fill_qty = order.leaves_qty
                            
                        # Determine slippage (Price variance)
                        slippage = random.gauss(0, order.price * 0.001) # 10bps slippage stddev
                        if order.side == "BUY":
                            fill_px = order.price + abs(slippage) # Pay more
                        else:
                            fill_px = order.price - abs(slippage) # Receive less
                            
                        # Update order state
                        order.cum_qty += fill_qty
                        order.leaves_qty -= fill_qty
                        if order.leaves_qty <= 0:
                            order.status = "FILLED"
                        else:
                            order.status = "PARTIALLY_FILLED"
                            
                        logger.info(f"[Exchange] FILL: {fill_qty} {order.symbol} @ {fill_px:.2f} (Status: {order.status})")
                        _fill_events.append((order.cl_ord_id, fill_qty, fill_px))
            for _cid, _fq, _fp in _fill_events:
                self.fill_callback(_cid, "TRADE", _fq, _fp)
