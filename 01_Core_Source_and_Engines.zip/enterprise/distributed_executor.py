"""
enterprise/distributed_executor.py
==================================
Distributed execution coordinator using Ray cluster and ProcessPoolExecutor fallbacks.
Enables parallel quantitative screening, ONNX predictions, and volatility calibration
to scale horizontally across multi-node compute clusters.
"""
from __future__ import annotations

import os
import logging
from typing import List, Callable, Any, Dict
from concurrent.futures import ProcessPoolExecutor

try:
    import ray
    HAS_RAY = True
except ImportError:
    HAS_RAY = False

logger = logging.getLogger(__name__)


class RayDistributedCoordinator:
    """Manages high-throughput task parallelization with Ray or Multiprocessing."""

    def __init__(self, use_ray: bool = True):
        self.use_ray = use_ray and HAS_RAY
        self.ray_initialized = False
        
        if self.use_ray:
            try:
                # Initialize Ray locally/cluster if not already initialized
                if not ray.is_initialized():
                    ray.init(ignore_reinit_error=True, logging_level=logging.ERROR)
                self.ray_initialized = True
                logger.info("[DistributedExecutor] Ray cluster successfully connected/initialized.")
            except Exception as e:
                logger.error(f"[DistributedExecutor] Ray initialization failed: {e}. Falling back to multiprocessing.")
                self.use_ray = False

    def parallel_map(self, func: Callable[[Any], Any], items: List[Any]) -> List[Any]:
        """Execute a function concurrently over a list of items."""
        if not items:
            return []

        # 1. Ray cluster execution path
        if self.use_ray and self.ray_initialized:
            try:
                # Wrap the function dynamically as a remote task
                @ray.remote
                def remote_wrapper(item):
                    return func(item)
                
                # Submit tasks
                futures = [remote_wrapper.remote(item) for item in items]
                # Retrieve results
                results = ray.get(futures)
                return results
            except Exception as e:
                # ROUND 45 FIX: this handler previously caught EVERY exception —
                # including business exceptions raised by the tasks themselves —
                # and re-ran the whole batch on the local ProcessPoolExecutor.
                # With any side-effecting func that is silent double execution;
                # even with a pure func it doubles runtime and re-raises the same
                # error (tracked in the repo worklog since Round 39). Task
                # failures (ray.exceptions.RayTaskError) now propagate to the
                # caller; only infrastructure failures (worker crashes, object
                # store issues, connection loss) fall back to local execution.
                try:
                    import ray.exceptions as _ray_exc
                    if isinstance(e, _ray_exc.RayTaskError):
                        raise  # business failure in a task — do NOT re-execute
                except ImportError:
                    pass  # ray.exceptions unavailable: fall through to fallback
                except Exception:
                    raise
                logger.error(f"[DistributedExecutor] Ray infrastructure failure: {e}. Falling back to multiprocessing.")

        # 2. Local multiprocessing fallback path
        logger.info(f"[DistributedExecutor] Running parallel map over {len(items)} items using ProcessPoolExecutor...")
        with ProcessPoolExecutor() as executor:
            # list() forces execution and waits for completion
            results = list(executor.map(func, items))
            return results

    def shutdown(self):
        """Shutdown Ray cluster session if initialized."""
        if self.use_ray and self.ray_initialized:
            try:
                ray.shutdown()
                self.ray_initialized = False
                logger.info("[DistributedExecutor] Ray cluster session shut down cleanly.")
            except Exception as e:
                logger.error(f"[DistributedExecutor] Ray shutdown failed: {e}")
