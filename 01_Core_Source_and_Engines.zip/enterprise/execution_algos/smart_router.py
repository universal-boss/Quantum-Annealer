import math
import logging
from typing import List, Tuple

logger = logging.getLogger("smart_router")

class BaseRouter:
    @staticmethod
    def generate_schedule(qty: int, duration_mins: int, intervals: int) -> List[Tuple[float, int]]:
        raise NotImplementedError

class TWAPRouter(BaseRouter):
    @staticmethod
    def generate_schedule(qty: int, duration_mins: int, intervals: int) -> List[Tuple[float, int]]:
        """
        Time Weighted Average Price (TWAP)
        Slices order equally across time.
        Returns: list of (delay_seconds_from_start, child_qty)
        """
        if qty <= 0:
            return []
        # ROUND 45 FIX: intervals<=0 previously raised a bare ZeroDivisionError
        # (verified: generate_child_orders("TWAP", 100, 10, intervals=0)).
        if intervals <= 0:
            raise ValueError(f"TWAP requires intervals >= 1 (got {intervals})")
            
        child_qty = qty // intervals
        remainder = qty % intervals
        
        schedule = []
        interval_secs = (duration_mins * 60.0) / intervals
        
        current_time = 0.0
        for i in range(intervals):
            chunk = child_qty + (1 if i < remainder else 0)
            if chunk > 0:
                schedule.append((current_time, chunk))
            current_time += interval_secs
            
        logger.info(f"TWAP generated {len(schedule)} child orders over {duration_mins} mins.")
        return schedule

class VWAPRouter(BaseRouter):
    @staticmethod
    def _u_shape_volume_profile(intervals: int) -> List[float]:
        """
        Simulates a standard equities U-shaped intraday volume profile.
        High volume at open/close, thin midday.
        """
        profile = []
        for i in range(intervals):
            # Parabola centered at intervals/2
            x = (i / max(1, (intervals - 1))) * 2 - 1  # -1 to 1
            vol = 1.0 + 2.0 * (x ** 2)  # 1.0 at center, 3.0 at edges
            profile.append(vol)
            
        total = sum(profile)
        return [p / total for p in profile]

    @staticmethod
    def generate_schedule(qty: int, duration_mins: int, intervals: int) -> List[Tuple[float, int]]:
        """
        Volume Weighted Average Price (VWAP)
        Slices order according to expected volume profile.
        """
        if qty <= 0:
            return []
        # ROUND 45 FIX: same guard as TWAP — intervals<=0 crashed with a bare
        # ZeroDivisionError on the interval_secs division.
        if intervals <= 0:
            raise ValueError(f"VWAP requires intervals >= 1 (got {intervals})")
            
        profile = VWAPRouter._u_shape_volume_profile(intervals)
        
        schedule = []
        interval_secs = (duration_mins * 60.0) / intervals
        
        current_time = 0.0
        allocated = 0
        
        for i in range(intervals):
            if i == intervals - 1:
                # Last interval sweeps remaining qty to avoid rounding losses
                chunk = qty - allocated
            else:
                chunk = int(math.floor(qty * profile[i]))
                
            if chunk > 0:
                schedule.append((current_time, chunk))
            allocated += chunk
            current_time += interval_secs
            
        logger.info(f"VWAP generated {len(schedule)} child orders over {duration_mins} mins.")
        return schedule

def generate_child_orders(algo: str, qty: int, duration_mins: int, intervals: int = 10) -> List[Tuple[float, int]]:
    """
    Factory function for Algo routing.
    Returns: list of (delay_seconds_from_start, child_qty)
    """
    if algo.upper() == "TWAP":
        return TWAPRouter.generate_schedule(qty, duration_mins, intervals)
    elif algo.upper() == "VWAP":
        return VWAPRouter.generate_schedule(qty, duration_mins, intervals)
    else:
        # Default fallback to a single block trade at time 0
        logger.warning(f"Unknown algo '{algo}', defaulting to block trade.")
        return [(0.0, qty)]
