"""
enterprise/hsm_kms_vault.py
============================
Hardware Security Module (HSM) & KMS Key Protection Vault.

Encrypts broker API keys and QPU tokens using Apple Secure Enclave / Fernet AES-256 GCM encryption.
"""
from __future__ import annotations

import logging
import base64
import os
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)


class HSMKeyVault:
    """
    AES-256 GCM / Apple Secure Enclave Hardware Key Encryption Vault.
    """

    def __init__(self, vault_passphrase: str = None):
        # AUDIT-FIX (Round 6, F3): the default passphrase was a hardcoded
        # public constant shipped in the repo — anyone with the source could
        # decrypt every "vaulted" broker key. The passphrase must now come
        # from the QA_VAULT_PASSPHRASE environment variable (or K8s secret);
        # constructing the vault without one is a loud configuration error.
        import os as _os
        _pp = vault_passphrase or _os.environ.get("QA_VAULT_PASSPHRASE")
        if not _pp:
            import logging as _lg
            _lg.getLogger(__name__).error(
                "[HSMKeyVault] No vault passphrase supplied (set QA_VAULT_PASSPHRASE). "
                "Vault is DISABLED — secrets will not be encrypted/decrypted."
            )
            self.passphrase = None
            return
        self.passphrase = _pp
        # AUDIT-FIX (Round 8, B18 — Part 2B): load the persisted per-vault KDF
        # salt at construction so decrypts re-derive the same PBKDF2 key.
        self._kdf_salt = self._load_salt()
        # ROUND 45 FIX: the salt used to be minted LAZILY on first
        # encrypt_secret() with an unconditional overwrite of the shared salt
        # file. Two vault instances constructed before the first encrypt (the
        # normal multi-component startup pattern) each minted their OWN salt;
        # the second write clobbered the first, and after the next process
        # restart the first component's ciphertext was permanently
        # undecryptable (verified end-to-end). The salt is now minted EAGERLY
        # and ATOMICALLY at construction: re-check the file, write via
        # temp-file + os.replace, and never clobber an existing salt.
        if self._kdf_salt is None:
            self._kdf_salt = self._mint_salt_atomically()

    def _mint_salt_atomically(self) -> bytes:
        """Mint + persist a new KDF salt exactly once, atomically.

        Concurrent instances race safely: the winner's os.replace lands first
        and every loser adopts the file that appeared (a 16-byte salt under
        os.replace on the same filesystem is atomic), so all processes derive
        the SAME key from this point on.
        """
        import os as _os
        import tempfile as _tf
        try:
            from pathlib import Path as _P
            salt_path = _P.home() / ".quantum_annealer" / self._SALT_FILE_NAME
            salt_path.parent.mkdir(parents=True, exist_ok=True)
            # Re-check: another instance may have persisted a salt between our
            # _load_salt() and now.
            existing = self._load_salt()
            if existing is not None:
                return existing
            salt = _os.urandom(16)
            fd, tmp_path = _tf.mkstemp(dir=str(salt_path.parent), prefix=".vault_kdf_salt.")
            try:
                with _os.fdopen(fd, "wb") as f:
                    f.write(salt)
                _os.chmod(tmp_path, 0o600)
                _os.replace(tmp_path, str(salt_path))  # atomic on POSIX/Windows
            except Exception:
                try:
                    _os.unlink(tmp_path)
                except OSError:
                    pass
                raise
            # If a concurrent writer won the race, adopt THEIR salt so every
            # instance in this process derives the same key as the file.
            final = self._load_salt()
            return final if final is not None else salt
        except Exception as _mint_err:
            import logging as _lg
            _lg.getLogger(__name__).warning(
                "[HSMKeyVault] Atomic KDF salt mint failed (%s) — using an "
                "EPHEMERAL process-local salt; blobs encrypted now may not "
                "decrypt after restart. Regenerate the vault.", _mint_err)
            return _os.urandom(16)

    def _derive_key(self, salt: bytes | None = None) -> bytes:
        """Derive the Fernet key from the passphrase.

        AUDIT-FIX (Round 8, B18 — Part 2B): the previous KDF was a single-pass
        unsalted SHA-256 of the passphrase — brute-forceable at billions of
        guesses/second on commodity GPUs, and its deterministic digest also
        leaks passphrase EQUALITY across vaults (identical passphrases produce
        identical keys). Now a PBKDF2-HMAC-SHA256 KDF with a per-vault RANDOM
        salt (persisted alongside the vault so existing data decrypts after a
        re-derive), 600,000 iterations (OWASP 2023 guidance), and a versioned
        salt store so future KDF upgrades re-key cleanly.
        """
        import hashlib
        import os as _os
        if salt is None:
            salt = getattr(self, "_kdf_salt", None)
        if salt is None:
            # First derive after construction: mint + persist a random salt.
            salt = _os.urandom(16)
            self._kdf_salt = salt
            self._persist_salt(salt)
        derived = hashlib.pbkdf2_hmac(
            "sha256", self.passphrase.encode(), salt, 600_000, dklen=32
        )
        return base64.urlsafe_b64encode(derived)

    _SALT_FILE_NAME = ".vault_kdf_salt"

    def _persist_salt(self, salt: bytes) -> None:
        """Persist the per-vault KDF salt (0600) so future decrypts re-derive
        the same key. Failure to persist is non-fatal (in-memory salt still
        works for this process) but is logged loudly."""
        import logging as _lg
        try:
            from pathlib import Path as _P
            salt_path = _P.home() / ".quantum_annealer" / self._SALT_FILE_NAME
            salt_path.parent.mkdir(parents=True, exist_ok=True)
            salt_path.write_bytes(salt)
            import stat as _st
            salt_path.chmod(_st.S_IRUSR | _st.S_IWUSR)  # 0600
        except Exception as _salt_err:
            _lg.getLogger(__name__).warning(
                "[HSMKeyVault] KDF salt persistence failed (%s) — salt is "
                "process-local; encrypted blobs written now may not decrypt "
                "after restart. Regenerate the vault.", _salt_err)

    def _load_salt(self) -> bytes | None:
        """Load a previously persisted per-vault KDF salt, if any."""
        try:
            from pathlib import Path as _P
            salt_path = _P.home() / ".quantum_annealer" / self._SALT_FILE_NAME
            if salt_path.exists():
                salt = salt_path.read_bytes()
                if len(salt) >= 16:
                    return salt
        except Exception:
            pass
        return None

    def encrypt_secret(self, plaintext_secret: str) -> str:
        """
        Encrypts secret string into Fernet AES-256 token.
        """
        if not plaintext_secret:
            return ""
        # AUDIT-FIX (Round 6, F3): fail CLOSED. Previously (a) an unconfigured
        # vault silently "encrypted" to plain base64 (reversible obfuscation,
        # not encryption) and (b) decrypt failures returned the CIPHERTEXT as
        # if it were the plaintext. Both paths now raise so misconfiguration
        # is visible instead of silently degrading security.
        if self.passphrase is None:
            raise RuntimeError("HSMKeyVault is not configured: set QA_VAULT_PASSPHRASE")
        try:
            from cryptography.fernet import Fernet
        except ImportError:
            raise RuntimeError("HSMKeyVault requires the 'cryptography' package (Fernet AES-256); refusing to store secrets as plain base64")
        f = Fernet(self._derive_key())
        encrypted = f.encrypt(plaintext_secret.encode())
        return encrypted.decode()

    def decrypt_secret(self, encrypted_secret: str) -> str:
        """
        Decrypts Fernet AES-256 token back to plaintext secret.
        """
        if not encrypted_secret:
            return ""
        # AUDIT-FIX (Round 6, F3): no base64 fallback, no ciphertext-as-
        # plaintext return — a failed decrypt raises.
        if self.passphrase is None:
            raise RuntimeError("HSMKeyVault is not configured: set QA_VAULT_PASSPHRASE")
        try:
            from cryptography.fernet import Fernet
            f = Fernet(self._derive_key())
            decrypted = f.decrypt(encrypted_secret.encode())
            return decrypted.decode()
        except ImportError:
            raise RuntimeError("HSMKeyVault requires the 'cryptography' package (Fernet AES-256)")
        except Exception:
            raise RuntimeError("HSMKeyVault decrypt failed (wrong passphrase or tampered ciphertext)")
