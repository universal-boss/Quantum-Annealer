"""Infrastructure hardening — K8s, Redis, TimescaleDB, Airflow.

Production deployment infrastructure for the Quantum Annealer:

  1. Kubernetes deployment manifests (auto-scaling, health checks)
  2. Redis caching layer (sub-millisecond factor retrieval)
  3. TimescaleDB schema (tick data storage with time-series optimization)
  4. Apache Airflow DAGs (scheduled pipeline orchestration)

These are infrastructure-as-code files — not Python modules to import.
They enable the platform to run at institutional scale (1000s of tickers,
100s of strategies, 24/7 operation).
"""
from __future__ import annotations

# ═══════════════════════════════════════════════════════════════════════════════
# KUBERNETES MANIFESTS
# ═══════════════════════════════════════════════════════════════════════════════

K8S_DEPLOYMENT_YAML = """
apiVersion: apps/v1
kind: Deployment
metadata:
  name: quantum-annealer-api
  namespace: quant
spec:
  replicas: 3
  selector:
    matchLabels:
      app: quantum-annealer-api
  template:
    metadata:
      labels:
        app: quantum-annealer-api
    spec:
      containers:
      - name: api
        image: quantum-annealer:3.0
        ports:
        - containerPort: 8000
        env:
        - name: QA_DB_URI
          valueFrom:
            secretKeyRef:
              name: qa-secrets
              key: db-uri
        - name: REDIS_URL
          valueFrom:
            secretKeyRef:
              name: qa-secrets
              key: redis-url
        resources:
          requests:
            memory: "2Gi"
            cpu: "1000m"
          limits:
            memory: "4Gi"
            cpu: "2000m"
        livenessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /ready
            port: 8000
          initialDelaySeconds: 10
          periodSeconds: 5
---
apiVersion: v1
kind: HorizontalPodAutoscaler
metadata:
  name: quantum-annealer-hpa
  namespace: quant
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: quantum-annealer-api
  minReplicas: 2
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
"""

K8S_SERVICE_YAML = """
apiVersion: v1
kind: Service
metadata:
  name: quantum-annealer-service
  namespace: quant
spec:
  type: ClusterIP
  selector:
    app: quantum-annealer-api
  ports:
  - port: 8000
    targetPort: 8000
    protocol: TCP
---
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: quantum-annealer-ingress
  namespace: quant
  annotations:
    nginx.ingress.kubernetes.io/ssl-redirect: "true"
    nginx.ingress.kubernetes.io/rate-limit: "100"
spec:
  tls:
  - hosts:
    - quant.example.com
    secretName: quant-tls
  rules:
  - host: quant.example.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: quantum-annealer-service
            port:
              number: 8000
"""


# ═══════════════════════════════════════════════════════════════════════════════
# REDIS CACHING LAYER
# ═══════════════════════════════════════════════════════════════════════════════

REDIS_CONFIG = """
# Quantum Annealer Redis Configuration
# Used for: factor caching, session storage, rate limiting, pub/sub alerts

maxmemory 2gb
maxmemory-policy allkeys-lru
save 900 1
save 300 10
save 60 10000
appendonly yes
appendfsync everysec
"""

# Redis caching Python interface
REDIS_CACHE_PYTHON = '''
"""Redis caching layer for sub-millisecond factor retrieval."""
import json
import logging
from typing import Optional, Any
import pandas as pd

logger = logging.getLogger(__name__)

try:
    import redis
    _HAS_REDIS = True
except ImportError:
    _HAS_REDIS = False


class RedisFactorCache:
    """Redis-backed factor cache for production deployments.

    In development: falls back to in-memory dict cache.
    In production: uses Redis for sub-ms retrieval and cross-process sharing.
    """

    def __init__(self, redis_url: Optional[str] = None, ttl: int = 3600):
        self.ttl = ttl  # 1 hour default
        self._redis = None
        self._memory_cache = {}  # fallback

        if _HAS_REDIS and redis_url:
            try:
                self._redis = redis.from_url(redis_url, decode_responses=True)
                self._redis.ping()
                logger.info("[RedisCache] Connected to Redis")
            except Exception as e:
                logger.warning(f"[RedisCache] Redis unavailable, using memory: {e}")
                self._redis = None

    def get(self, key: str) -> Optional[Any]:
        """Get cached value."""
        if self._redis:
            try:
                val = self._redis.get(key)
                if val:
                    return json.loads(val)
            except Exception:
                pass
        else:
            return self._memory_cache.get(key)
        return None

    def set(self, key: str, value: Any, ttl: Optional[int] = None):
        """Set cached value."""
        ttl = ttl or self.ttl
        if self._redis:
            try:
                self._redis.setex(key, ttl, json.dumps(value, default=str))
            except Exception:
                pass
        else:
            self._memory_cache[key] = value

    def invalidate(self, pattern: str = "*"):
        """Invalidate cached keys matching pattern."""
        if self._redis:
            try:
                keys = self._redis.keys(pattern)
                if keys:
                    self._redis.delete(*keys)
            except Exception:
                pass
        else:
            if pattern == "*":
                self._memory_cache.clear()
            else:
                keys_to_delete = [k for k in self._memory_cache if pattern in k]
                for k in keys_to_delete:
                    del self._memory_cache[k]
'''


# ═══════════════════════════════════════════════════════════════════════════════
# TIMESCALEDB SCHEMA (tick data storage)
# ═══════════════════════════════════════════════════════════════════════════════

TIMESCALEDB_SQL = """
-- Quantum Annealer TimescaleDB Schema
-- Optimized for time-series tick data storage

-- Enable TimescaleDB extension
CREATE EXTENSION IF NOT EXISTS timescaledb;

-- Tick data table (1-minute OHLCV)
CREATE TABLE IF NOT EXISTS tick_data (
    time        TIMESTAMPTZ NOT NULL,
    ticker      TEXT NOT NULL,
    open        NUMERIC(12,4),
    high        NUMERIC(12,4),
    low         NUMERIC(12,4),
    close       NUMERIC(12,4),
    volume      BIGINT,
    vwap        NUMERIC(12,4),
    trades      INTEGER,
    PRIMARY KEY (ticker, time)
);

-- Convert to hypertable (TimescaleDB partitioning)
SELECT create_hypertable('tick_data', 'time', if_not_exists => TRUE);

-- Add columnar compression (compress data older than 7 days)
ALTER TABLE tick_data SET (
    timescaledb.compress,
    timescaledb.compress_segmentby = 'ticker'
);
SELECT add_compression_policy('tick_data', INTERVAL '7 days');

-- Continuous aggregate: daily OHLCV from tick data
CREATE MATERIALIZED VIEW daily_ohlcv
WITH (timescaledb.continuous) AS
SELECT
    time_bucket('1 day', time) AS day,
    ticker,
    first(open, time) AS open,
    max(high) AS high,
    min(low) AS low,
    last(close, time) AS close,
    sum(volume) AS volume
FROM tick_data
GROUP BY day, ticker;

-- Refresh policy: update daily aggregate every hour
SELECT add_continuous_aggregate_policy(
    'daily_ohlcv',
    start_offset => INTERVAL '7 days',
    end_offset => INTERVAL '1 hour',
    schedule_interval => INTERVAL '1 hour'
);

-- Factor values table (computed factors)
CREATE TABLE IF NOT EXISTS factor_values (
    time        TIMESTAMPTZ NOT NULL,
    ticker      TEXT NOT NULL,
    factor_name TEXT NOT NULL,
    value       NUMERIC(12,6),
    PRIMARY KEY (ticker, time, factor_name)
);
SELECT create_hypertable('factor_values', 'time', if_not_exists => TRUE);

-- Index for fast factor retrieval
CREATE INDEX IF NOT EXISTS idx_factor_values_name_time
ON factor_values (factor_name, time DESC);

-- ML model results table
CREATE TABLE IF NOT EXISTS ml_runs (
    run_id      TEXT PRIMARY KEY,
    started_at  TIMESTAMPTZ NOT NULL,
    completed_at TIMESTAMPTZ,
    params      JSONB,
    metrics     JSONB,
    feature_importance JSONB
);

-- Portfolio snapshots
CREATE TABLE IF NOT EXISTS portfolio_snapshots (
    time        TIMESTAMPTZ NOT NULL,
    run_id      TEXT NOT NULL,
    ticker      TEXT NOT NULL,
    weight      NUMERIC(8,6),
    shares      INTEGER,
    price       NUMERIC(12,4)
);
SELECT create_hypertable('portfolio_snapshots', 'time', if_not_exists => TRUE);
"""


# ═══════════════════════════════════════════════════════════════════════════════
# APACHE AIRFLOW DAG
# ═══════════════════════════════════════════════════════════════════════════════

AIRFLOW_DAG_PYTHON = '''
"""Airflow DAG for scheduled Quantum Annealer pipeline.

Runs the full pipeline (Screen → ML Alpha → Optimize) on a schedule:
  - Pre-market: 9:00 AM IST (fetch fresh data)
  - Market close: 3:30 PM IST (run optimizer)
  - Post-market: 5:00 PM IST (compute risk metrics, send reports)
"""
from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.operators.bash_operator import BashOperator

default_args = {
    "owner": "quant-team",
    "depends_on_past": False,
    "start_date": datetime(2024, 1, 1),
    "email_on_failure": True,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
}

dag = DAG(
    "quantum_annealer_daily",
    default_args=default_args,
    description="Daily Quantum Annealer pipeline",
    schedule_interval="0 9 * * 1-5",  # 9 AM IST, Mon-Fri
    catchup=False,
    tags=["quant", "production"],
)

# Task 1: Fetch fresh market data
fetch_data = BashOperator(
    task_id="fetch_market_data",
    bash_command="cd /app && python -c 'from data_layer import fetch_all_data; fetch_all_data()'",
    dag=dag,
)

# Task 2: Run neural screen
run_screen = BashOperator(
    task_id="run_neural_screen",
    bash_command="cd /app && python -c 'from live_verify import test_live_screener_full_nse; test_live_screener_full_nse()'",
    dag=dag,
)

# Task 3: Fit ML model (skip if fresh)
fit_ml = BashOperator(
    task_id="fit_ml_model",
    bash_command="cd /app && python -c 'from ml_alpha import AlphaEngine; e=AlphaEngine(); e.fit(start=\"2020-01-01\", end=\"today\")'",
    dag=dag,
)

# Task 4: Run optimizer
run_optimizer = BashOperator(
    task_id="run_optimizer",
    bash_command="cd /app && python -c 'from optimizer import run_optimizer_logic; run_optimizer_logic()'",
    dag=dag,
)

# Task 5: Compute risk metrics
compute_risk = BashOperator(
    task_id="compute_risk",
    bash_command="cd /app && python -c 'from math_engine.factor_risk import FactorRiskDecomposer; FactorRiskDecomposer().decompose_risk()'",
    dag=dag,
)

# Task 6: Send Telegram report
send_report = BashOperator(
    task_id="send_telegram_report",
    bash_command="cd /app && python -c 'from utils import send_telegram_notification; send_telegram_notification()'",
    dag=dag,
)

# Pipeline dependencies
fetch_data >> run_screen >> fit_ml >> run_optimizer >> compute_risk >> send_report
'''


# ═══════════════════════════════════════════════════════════════════════════════
# DOCKERFILE
# ═══════════════════════════════════════════════════════════════════════════════

DOCKERFILE = """
FROM python:3.11-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \\
    build-essential \\
    libpq-dev \\
    && rm -rf /var/lib/apt/lists/*

# Copy requirements and install
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application
COPY . .

# Health check
HEALTHCHECK --interval=30s --timeout=10s --retries=3 \\
    CMD curl -f http://localhost:8000/health || exit 1

# Run
EXPOSE 8000
CMD ["python", "-m", "enterprise.math_service"]
"""


def save_infrastructure_files(output_dir: str = "."):
    """Save all infrastructure files to the specified directory."""
    from pathlib import Path
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    # K8s
    (out / "k8s_deployment.yaml").write_text(K8S_DEPLOYMENT_YAML)
    (out / "k8s_service.yaml").write_text(K8S_SERVICE_YAML)

    # Redis
    (out / "redis.conf").write_text(REDIS_CONFIG)
    (out / "redis_cache.py").write_text(REDIS_CACHE_PYTHON)

    # TimescaleDB
    (out / "timescaledb_schema.sql").write_text(TIMESCALEDB_SQL)

    # Airflow
    (out / "airflow_dag.py").write_text(AIRFLOW_DAG_PYTHON)

    # Dockerfile
    (out / "Dockerfile").write_text(DOCKERFILE)

    print(f"✓ Infrastructure files saved to {out}/")
