"""
enterprise/postgres_pool.py
===========================
Thread-safe PostgreSQL connection pooling client wrapper.
Designed to target pgBouncer in transaction pooling mode for high-concurrency math worker execution.
"""
from __future__ import annotations

import logging
from contextlib import contextmanager
from typing import Generator, Optional

try:
    import psycopg2
    from psycopg2 import pool
    HAS_PSYCOPG2 = True
except ImportError:
    HAS_PSYCOPG2 = False
    psycopg2 = None
    pool = None
    logger = logging.getLogger(__name__)
    logger.warning("[PostgresPool] psycopg2 or psycopg2-binary SDK not found. PostgreSQL pooling will run in stub mode.")

logger = logging.getLogger(__name__)


class DatabaseConnectionPool:
    """Thread-safe Connection Pool Manager for Postgres / pgBouncer.
    
    Provides transactional connection lifecycle containment via context managers.
    """

    def __init__(
        self,
        dsn: str,
        min_connections: int = 5,
        max_connections: int = 40
    ) -> None:
        self.dsn = dsn
        self.min_conn = min_connections
        self.max_conn = max_connections
        self._pool: Optional[pool.ThreadedConnectionPool] = None
        # ROUND 45 FIX: guard the lazy re-initialization path — `connection()`'
        # check-then-act on `self._pool` was unlocked, so N workers hitting a
        # pool that failed at construction each built their OWN
        # ThreadedConnectionPool (5 eagerly-opened sockets apiece); losers'
        # pools were orphaned forever (connection leak against pgBouncer).
        import threading as _th
        self._init_lock = _th.Lock()
        self._initialize_pool()

    def _initialize_pool(self) -> None:
        """Instantiate ThreadedConnectionPool using DSN parameters."""
        if not HAS_PSYCOPG2:
            logger.error("[PostgresPool] Cannot initialize connection pool: psycopg2 is not installed.")
            self._pool = None
            return
        try:
            self._pool = pool.ThreadedConnectionPool(
                minconn=self.min_conn,
                maxconn=self.max_conn,
                dsn=self.dsn
            )
            logger.info(
                f"[PostgresPool] Connection pool initialized successfully. "
                f"Min connections: {self.min_conn}, Max connections: {self.max_conn}"
            )
        except Exception as e:
            logger.error(f"[PostgresPool] Failed to initialize connection pool: {e}")
            self._pool = None

    @contextmanager
    def connection(self) -> Generator[psycopg2.extensions.connection, None, None]:
        """Context manager to lease, yield, and automatically return pool connections.
        
        Usage:
            pool = DatabaseConnectionPool(dsn)
            with pool.connection() as conn:
                with conn.cursor() as cur:
                    cur.execute("SELECT 1")
        """
        if not HAS_PSYCOPG2:
            raise RuntimeError("psycopg2 is required to use PostgreSQL connection pooling.")
        if not self._pool:
            # Lazy reconnection retry if pool failed to initialize originally.
            # ROUND 45 FIX: double-checked under the init lock so exactly one
            # pool is ever created (was an unlocked check-then-act race).
            with self._init_lock:
                if not self._pool:
                    self._initialize_pool()
            if not self._pool:
                raise RuntimeError("PostgreSQL Connection Pool is not initialized.")

        conn = None
        try:
            conn = self._pool.getconn()
            yield conn
            # Commit changes on transaction success
            conn.commit()
        except Exception as e:
            if conn:
                try:
                    conn.rollback()
                except Exception:
                    # L33-fix: rollback failed — the connection is now in an aborted
                    # transaction state. If we putconn() it back, the next lessee
                    # inherits "current transaction is aborted" errors. Mark it for
                    # closure so the pool discards the poisoned connection instead.
                    try:
                        self._pool.putconn(conn, close=True)
                        conn = None  # already returned
                    except Exception:
                        pass
            logger.error(f"[PostgresPool] Transaction error (auto-rolled back): {e}")
            raise e
        finally:
            if conn and self._pool:
                try:
                    self._pool.putconn(conn)
                except Exception as put_err:
                    logger.warning(f"[PostgresPool] Failed to return connection to pool: {put_err}")

    def close_all(self) -> None:
        """Gracefully drain and terminate all connection pool instances (on shutdown)."""
        if self._pool:
            self._pool.closeall()
            self._pool = None
            logger.info("[PostgresPool] All connections inside the pool closed successfully.")
