import sys
import os
import faulthandler

# Print native crash tracebacks to stderr instead of a bare "segmentation fault".
# This dumps the active Python frame(s) at the moment of a low-level crash,
# which is the only reliable way to pinpoint a segfault's location.
faulthandler.enable()

# Phase 9: Force single-threaded BLAS for deterministic HMM fitting.
# Claude found that multi-threaded BLAS causes non-deterministic floating-point
# summation, which sends SLSQP down different convergence paths on the
# non-convex RS-GARCH likelihood surface. This produces different regime
# predictions on identical data (75.27% vs 97.93% on the same 1231-day window).
# Setting these BEFORE numpy/scipy import ensures deterministic behavior.
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["VECLIB_MAXIMUM_THREADS"] = "1"

# CRASH FIX (macOS EXC_BAD_ACCESS in libomp.dylib __kmp_suspend_initialize_thread):
# faiss-cpu, lightgbm, torch, and scikit-learn's compiled extensions each bundle
# their OWN private copy of the LLVM/Intel OpenMP runtime (libomp.dylib). A crash
# report confirmed FOUR separate libomp.dylib images loaded into this one process
# simultaneously. Their internal thread pools and barrier/synchronization state
# are not designed to coexist — on macOS this corrupts internal OpenMP state
# instead of the (Linux-only) "duplicate runtime" abort message, and segfaults
# deep inside libomp's own suspend/barrier code, typically the moment LightGBM
# or faiss actually spins up worker threads (e.g. mid-training in MLFitWorker).
# KMP_DUPLICATE_LIB_OK tells the runtime to tolerate multiple copies instead of
# racing on shared state. This does not "fix" the duplication, but avoids the
# collision path that was crashing the process.
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
# Belt-and-suspenders: also cap LightGBM's own internal thread pool, since the
# crash report's MLFitWorker thread died inside LightGBM::BinMapper's OpenMP
# region specifically. LightGBM reads this at import time.
os.environ["LIGHTGBM_NUM_THREADS"] = "1"
os.environ["GRPC_VERBOSITY"] = "NONE"
os.environ["GRPC_CPP_MIN_LOG_LEVEL"] = "3"

# Ensure the root directory is in the path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import multiprocessing

# Only the main UI process should import QtWebEngineWidgets and initialize QApplication.
# Worker sub-processes spawned by multiprocessing/ProcessPoolExecutor must NEVER initialize WebEngine.
if multiprocessing.current_process().name == "MainProcess":
    _webengine_preimported = False
    try:
        from PySide6 import QtWebEngineWidgets  # noqa: F401
        _webengine_preimported = True
    except ImportError:
        pass

    print(f"[launch_desktop] QtWebEngineWidgets pre-imported before QApplication: {_webengine_preimported}", file=sys.stderr)
    print(f"[launch_desktop] Running from: {os.path.abspath(__file__)}", file=sys.stderr)
    print(f"[launch_desktop] Python: {sys.executable} ({sys.version.split()[0]})", file=sys.stderr)

    from ui.main_window import main

    if __name__ == "__main__":
        main()
