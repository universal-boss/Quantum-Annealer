"""
launch_web_dashboard.py
=======================
One-Click Desktop Launcher for the Modern Institutional FinTech Web Dashboard.

Boots the local Python quantitative API server and automatically opens the sleek,
high-density FinTech workstation in your default web browser.
"""
from __future__ import annotations

import sys
import os
import webbrowser
import threading
import time
from pathlib import Path

# Force single-threaded BLAS and OpenMP for deterministic HMM fitting and math calculations
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["VECLIB_MAXIMUM_THREADS"] = "1"
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
os.environ["LIGHTGBM_NUM_THREADS"] = "1"
os.environ["GRPC_VERBOSITY"] = "NONE"
os.environ["GRPC_CPP_MIN_LOG_LEVEL"] = "3"

# Add project root to sys.path
workspace_dir = Path(__file__).resolve().parent
if str(workspace_dir) not in sys.path:
    sys.path.insert(0, str(workspace_dir))

from web_dashboard.app import run_dashboard_server, PORT, SESSION_TOKEN


def main():
    """Boots the server and opens the browser."""
    print("=" * 70)
    print("⚛️  LAUNCHING QUANTUM ANNEALER PRO: MODERN FINTECH WORKSTATION")
    print(f"🌐  Dashboard URL: http://localhost:{PORT}")
    print("=" * 70)

    # Start server in background daemon thread
    server_thread = threading.Thread(target=run_dashboard_server, args=(PORT,), daemon=True)
    server_thread.start()

    # Wait 0.8s for socket to bind, then open browser
    time.sleep(0.8)
    # AUDIT-FIX (Round 8, W1 — Part 2B): the dashboard now enforces the
    # per-session token gate — opening the bare root URL returns 401. The
    # launcher opens the token-minting /auth URL instead, which validates the
    # token (constant-time) and sets the HttpOnly session cookie before
    # redirecting to /. Manual/remote access: pass the token in the
    # X-QA-Token header, or open http://127.0.0.1:PORT/auth?token=<token>.
    _auth_url = f"http://127.0.0.1:{PORT}/auth?token={SESSION_TOKEN}"
    webbrowser.open(_auth_url)
    print("\n🔐 Opened the authenticated launcher URL (session cookie set automatically).")
    print(f"   Non-browser clients: send header X-QA-Token: {SESSION_TOKEN[:8]}…")

    print("\n✅ Web Dashboard is active. Press Ctrl+C in terminal to stop.")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n🛑 Dashboard server stopped.")


if __name__ == "__main__":
    main()
