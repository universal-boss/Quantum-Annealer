"""
live_verify.py
================
Runs a headless integration test of the upgraded v3 ML retrieval system.
Evaluates broad-market regime HMM and scores NSE equities using multi-timeframe dual-tower retrieval.
"""
from __future__ import annotations

import os
import sys
import logging
from typing import Optional
import pandas as pd
import numpy as np
from datetime import datetime

from math_engine.regime_detector import MarketRegimeDetector
from math_engine.onnx_inference import LatentEmbeddingGenerator
from math_engine.latent_screener import LatentSpaceScreener
from utils import compute_breakout_tables, check_stop

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")


def test_live_hmm() -> Optional[dict]:
    """Train MarketRegimeDetector on Nifty 500 proxy and predict today's regime."""
    print("\n" + "=" * 50)
    print("🧪 TEST 1: LIVE HMM REGIME DETECTION (NIFTY 500 BROAD PROXY)")
    print("=" * 50)

    # Use safe_download — never yf.download directly.
    # safe_download goes through the provider abstraction layer with caching,
    # rate-limit protection, and the ENV=production guard.
    from data.price_feed import safe_download

    _hmm_symbols = ["^CRSLDX", "^CNX500", "^NSEI"]
    nifty = pd.DataFrame()
    _used_sym = None
    for _sym in _hmm_symbols:
        try:
            _df = safe_download([_sym], period="5y")
            # safe_download returns a multi-level DataFrame; extract Close column
            if isinstance(_df.columns, pd.MultiIndex):
                _close = _df["Close"]
                if isinstance(_close, pd.DataFrame):
                    _close = _close.iloc[:, 0]
                _df = pd.DataFrame({"Close": _close, "Volume": _df.get("Volume", pd.Series(dtype=float)).squeeze()})
            if not _df.empty and len(_df) >= 500:
                nifty = _df
                _used_sym = _sym
                print(f"Downloaded {_sym}: {len(_df)} trading days")
                break
        except Exception as _e:
            print(f"  ⚠️ {_sym} failed: {_e}")
    if nifty.empty:
        print("❌ Failed to download Nifty data from any source.")
        return None
    print(f"Using {_used_sym} as Nifty 500 broad-market proxy for HMM training.")

    # Normalise column names to lowercase for MarketRegimeDetector.fit()
    if isinstance(nifty.columns, pd.MultiIndex):
        nifty.columns = nifty.columns.get_level_values(0)
    nifty.columns = nifty.columns.str.lower()
    # Ensure 'close' column exists (safe_download may return 'Close')
    if 'close' not in nifty.columns and 'Close' in nifty.columns:
        nifty = nifty.rename(columns={'Close': 'close'})

    print("Training MarketRegimeDetector...")
    hmm = MarketRegimeDetector()
    hmm.fit(nifty)

    print("Predicting today's regime...")
    pred = hmm.predict_regime(nifty, last_n_days=252, use_macro_overlay=True)

    print("\n✅ HMM RESULTS:")
    print(f"  -> Predicted State ID : {pred['state']} ({pred['label']})")
    print(f"  -> Confidence         : {pred['confidence']:.2%}")
    print(f"  -> Probabilities      : {pred['probabilities']}")
    if pred.get('raw_probabilities'):
        print(f"  -> Raw (pre-overlay)  : {pred['raw_probabilities']}")
    print(f"  -> Transition Matrix  :\n{np.round(pred['transition_matrix'], 2)}")
    if pred.get('signals'):
        s = pred['signals']
        # Defensive access — regime_detector.py may emit different key names
        # depending on version. Fall back to "n/a" and print available keys
        # so the next run tells us exactly what the HMM is emitting.
        _ret_today = s.get('ret_today_pct')
        _ret_5d    = s.get('ret_5d_avg_pct')
        _vol_today = s.get('vol_today_pct')
        _vol_5d    = s.get('vol_5d_avg_pct')
        _today_str  = f"{_ret_today:+.3f}%"  if isinstance(_ret_today, (int, float)) else "n/a"
        _5d_str     = f"{_ret_5d:+.3f}%"     if isinstance(_ret_5d,    (int, float)) else "n/a"
        _vtoday_str = f"{_vol_today:.3f}%"   if isinstance(_vol_today, (int, float)) else "n/a"
        _v5d_str    = f"{_vol_5d:.3f}%"      if isinstance(_vol_5d,    (int, float)) else "n/a"
        print(f"  -> Today Return       : {_today_str}  (5d avg: {_5d_str})")
        print(f"  -> Today Vol (σ)      : {_vtoday_str}  (5d avg: {_v5d_str})")
        if any(v is None for v in (_ret_today, _ret_5d, _vol_today, _vol_5d)):
            print(f"     [WARN] signals dict missing some expected keys.")
            print(f"             Expected: ret_today_pct, ret_5d_avg_pct, vol_today_pct, vol_5d_avg_pct")
            print(f"             Available: {sorted(s.keys())}")
    if pred.get('macro_shock_applied'):
        factor = pred.get('macro_shock_factor', 0)
        boost  = pred.get('macro_bull_boost', 0)
        if factor > 0:
            print(f"  -> Macro Bear Overlay : applied (factor={factor:.4f})")
        if boost > 0:
            print(f"  -> Macro Bull Boost   : applied (boost={boost:.4f})")
    else:
        print("  -> Macro Overlay      : none triggered")

    return pred


def test_live_screener_full_nse(regime: Optional[str] = None) -> Optional[dict]:
    """Runs upgraded v3 multi-timeframe dual-tower retrieval on live/mock market data.

    IMPORTANT:
    Despite the name, this function may *sample* the universe (e.g. QA_TEST_MODE)
    to avoid data-provider throttling. Callers should use the returned metadata
    (universe_size / target_count / is_full_universe) before treating results as
    "full-universe" signals.
    """
    print("\n" + "=" * 50)
    print("🧪 TEST 2: LIVE MULTI-TIMEFRAME DUAL-TOWER RETRIEVAL SYSTEM")
    print("=" * 50)

    print("Fetching full NSE listed equities list automatically...")
    try:
        from data_layer import fetch_nse_tickers
        tickers = fetch_nse_tickers()
        if not tickers:
            raise RuntimeError("NSE ticker fetch returned empty list.")
        print(f"✅ Loaded {len(tickers)} symbols from full NSE listed equities.")
    except Exception as e:
        print(f"⚠️ Failed to load automatic NSE list ({e}). Trying backup Nifty 500 list...")
        try:
            url = "https://archives.nseindia.com/content/indices/ind_nifty500list.csv"
            df_tickers = pd.read_csv(url, usecols=["Symbol"])
            tickers = [s.strip() + ".NS" for s in df_tickers["Symbol"].dropna().tolist()]
        except Exception:
            tickers = ["RELIANCE.NS", "TCS.NS", "HDFCBANK.NS", "INFY.NS", "SBIN.NS"]

    # Limit tickers for test mode to prevent Yahoo Finance throttling
    if os.environ.get("QA_TEST_MODE") == "1":
        _day_seed = int(datetime.now().strftime("%Y%m%d")) % (2**32)
        state = np.random.RandomState(_day_seed)
        target_tickers = list(state.choice(tickers, size=min(15, len(tickers)), replace=False))
    else:
        # Dynamically sample 100 tickers randomly from the entire NSE listed equities list
        # to ensure broad market coverage and discover fresh breakouts across the whole exchange.
        try:
            import time
            seed = int(time.time()) % (2**32)
            state = np.random.RandomState(seed)
            target_tickers = list(state.choice(tickers, size=min(100, len(tickers)), replace=False))
        except Exception:
            target_tickers = tickers[:25]

    print("Initializing upgraded v3 ML engines...")
    # Generates dual-tower Fallback Projections internally if ONNX weights do not exist
    vit = LatentEmbeddingGenerator("artifacts/vit_v3_fused.onnx")
    screener = LatentSpaceScreener("artifacts")
    is_mock = vit._is_mock

    # Attempt to invalidate OHLCV cache so live data is always fresh.
    # Wrapped defensively — different cache implementations may not have invalidate().
    try:
        from data.cache_manager import _DATA_CACHE
        if hasattr(_DATA_CACHE, "invalidate"):
            _DATA_CACHE.invalidate("ohlcv:")
            print("Cleared OHLCV cache to force fresh live data fetch.")
        elif hasattr(_DATA_CACHE, "clear"):
            _DATA_CACHE.clear()
            print("Cleared OHLCV cache (full clear).")
    except Exception as ce:
        print(f"Note: Could not invalidate cache ({ce}) — proceeding with cached data.")

    from data_layer import download_multitimeframe_ohlcv_bundle
    from utils import build_multitimeframe_input_bundle

    cfg = {"LOOKBACK_DOWNLOAD": "2y", "CHART_INTRADAY_LOOKBACK": "180d", "FORCE_REBUILD": True}
    bundle_data = download_multitimeframe_ohlcv_bundle(target_tickers, cfg=cfg, log_cb=print)

    scored_count = 0
    matches = []
    screener_rows = []

    for t in target_tickers:
        try:
            check_stop()
            tf_bundle = build_multitimeframe_input_bundle(bundle_data, t, benchmark_series=None, cfg=cfg)
            if not tf_bundle:
                continue

            # Generate fused embeddings per timeframe
            tf_embeddings = {}
            for tf, inputs in tf_bundle.items():
                img = inputs["image"]
                ts = inputs["ts"]
                tf_embeddings[tf] = vit.generate_fused_embedding(img, ts, regime=regime, timeframe=tf)

            # Score the timeframe bundle
            score = screener.score_timeframe_bundle(tf_embeddings, regime=regime)
            scored_count += 1

            matches.append((t, score["best_cosine_similarity"], score["calibrated_probability"], score["novelty"]))

            # Print standard progress log for every ticker so user sees real activity
            match_type = "OUTSTANDING" if score["best_cosine_similarity"] > 0.72 else "Scored"
            if is_mock:
                match_type += " (MOCK)"
            print(
                f"[LiveVerify] [{match_type}] {t:<15} | "
                f"Similarity: {score['best_cosine_similarity']:.3f} | "
                f"Pattern: {score['best_bank']} | "
                f"Calibrated Prob: {score['calibrated_probability']:.2%} | "
                f"Novelty: {score['novelty']:.4f}"
            )

            # Extract basic metrics from daily Close series to populate table
            p_1d = bundle_data["1d"]["Close"][t].dropna()
            # L3-fix: removed dead `p_1d_vol` assignment (was never used).

            rets = np.log(p_1d / p_1d.shift(1)).dropna()
            mom_1m = float(p_1d.iloc[-1] / p_1d.iloc[-21] - 1.0) if len(p_1d) >= 21 else 0.0
            mom_3m = float(p_1d.iloc[-1] / p_1d.iloc[-63] - 1.0) if len(p_1d) >= 63 else 0.0
            mom_6m = float(p_1d.iloc[-1] / p_1d.iloc[-126] - 1.0) if len(p_1d) >= 126 else 0.0

            delta = p_1d.diff()
            gain = delta.clip(lower=0).ewm(alpha=1/14, min_periods=14, adjust=False).mean()
            loss = (-delta.clip(upper=0)).ewm(alpha=1/14, min_periods=14, adjust=False).mean()
            rsi_val = float((100 - (100 / (1 + gain / (loss + 1e-9)))).iloc[-1]) if len(p_1d) >= 14 else 50.0

            drawdown_val = float(abs(p_1d.iloc[-1] / p_1d.cummax().iloc[-1] - 1.0))

            screener_rows.append({
                "ticker": t,
                "rsi": rsi_val, "vol_surge": 1.0,
                "ann_vol": float(rets.std() * np.sqrt(252)) if len(rets) > 0 else 0.3,
                "drawdown": drawdown_val,
                "mom_1m": mom_1m, "mom_3m": mom_3m, "mom_6m": mom_6m,
                "mom_12_1": float(p_1d.iloc[-22] / p_1d.iloc[-253] - 1.0) if len(p_1d) >= 253 else mom_6m,
                "trend_20": 0.0, "trend_50": 0.0,
                "proximity_52w": 0.85,
                "price_above_20d_frac": 0.5, "price_above_50d_frac": 0.5, "up_day_frac_21": 0.5,
                "chart_pattern_cohesion": score["best_cosine_similarity"],
                "chart_pattern_margin": score["margin"],
                "chart_cluster_agreement": score["agreement"],
                "chart_pattern_novelty": score["novelty"],
                "chart_pattern_dispersion": 1.0 - score["agreement"],
                "adv20": 1_000_000.0,
                "beta": 1.0,
                "alpha_score": score["calibrated_probability"],
                "risk_score": score["novelty"] * 0.5,
                "ma_compression": 0.0, "breakout_distance_20d": 0.0, "trigger_persistence": 0.5,
                "range_contraction": 0.0, "volume_dryup": 0.0,
            })
        except Exception as _ticker_ex:
            logging.debug("[LiveVerify] Skipped %s: %s", t, _ticker_ex)
            continue

    print(f"\n✅ Finished upgraded v3 neural screening for {scored_count}/{len(target_tickers)} sampled equities.")
    if matches:
        avg_sim = np.mean([m[1] for m in matches])
        print(f"  -> Mean Cosine Similarity of Universe: {avg_sim:.4f}")
        top_matches = sorted(matches, key=lambda m: m[1], reverse=True)[:5]
        top_title = "TOP 5 CHART MATCHES FOUND IN UNIVERSE" if not is_mock else "TOP 5 SIMULATED CHART MATCHES (MOCK PIPELINE)"
        print(f"\n🏆 {top_title}:")
        for idx, m in enumerate(top_matches):
            print(f"  {idx+1}. {m[0]:<15} | Cosine Similarity: {m[1]:.4f} | Calibrated Prob: {m[2]:.2%} | Novelty: {m[3]:.4f}")

    breakout_df = pd.DataFrame()
    prebreakout_df = pd.DataFrame()
    if screener_rows:
        try:
            signal_df = pd.DataFrame(screener_rows).set_index("ticker")
            sectors_dict = {row["ticker"]: "N/A" for row in screener_rows}
            breakout_df, prebreakout_df = compute_breakout_tables(signal_df, sectors=sectors_dict)
            if not breakout_df.empty:
                print(f"✅ Classed {len(breakout_df)} early breakout (🚀) setups across sampled universe.")
            if not prebreakout_df.empty:
                print(f"✅ Classed {len(prebreakout_df)} pre-breakout (🔍) setups across sampled universe.")
        except Exception as tb_ex:
            print(f"⚠️ Failed to construct breakout tables: {tb_ex}")

    universe_size = len(tickers)
    target_count = len(target_tickers)
    # A conservative "full universe" flag; current defaults (15/25 sampling) will be False.
    is_full_universe = (
        universe_size > 0
        and target_count >= int(0.8 * universe_size)
        and scored_count >= int(0.8 * universe_size)
    )

    return {
        "matches": matches,
        "breakout_df": breakout_df,
        "prebreakout_df": prebreakout_df,
        "scores": {m[0]: m[1] for m in matches},
        "is_mock": is_mock,
        "universe_size": universe_size,
        "target_count": target_count,
        "scored_count": scored_count,
        "is_full_universe": is_full_universe,
    }


def enforce_paper_trade_promotion_gate(
    min_trades: int = 30,
    min_sharpe: float = 0.80,
    max_age_days: float = 30.0
) -> dict:
    """Automated gate: blocks promotion to live trading unless paper-trade scorecard meets statistical and freshness criteria."""
    scorecard_path = os.path.join(os.path.dirname(__file__), "artifacts", "paper_trade_scorecard.json")
    if not os.path.exists(scorecard_path):
        msg = "paper_trade_scorecard.json missing. Complete paper-trading evaluation period first."
        print(f"⛔ [PROMOTION GATE] BLOCKED: {msg}")
        return {"promoted": False, "reason": msg}
    
    try:
        import json
        with open(scorecard_path, "r") as f:
            card = json.load(f)
        
        # 1. Check Scorecard Freshness (Staleness Check)
        ts_str = card.get("timestamp") or card.get("date")
        if ts_str:
            try:
                card_dt = datetime.fromisoformat(str(ts_str).replace("Z", "+00:00"))
                age_days = (datetime.now(card_dt.tzinfo) - card_dt).total_seconds() / 86400.0
                if age_days > max_age_days:
                    msg = f"Scorecard is stale ({age_days:.1f} days old, max allowed {max_age_days} days)."
                    print(f"⛔ [PROMOTION GATE] BLOCKED: {msg}")
                    return {"promoted": False, "reason": msg}
            except Exception as dt_e:
                print(f"⚠️ [PROMOTION GATE] Could not parse timestamp '{ts_str}': {dt_e}")

        # 2. Check Statistical Sample Size & Sharpe Bar
        n_trades = int(card.get("total_trades", 0))
        sharpe = float(card.get("sharpe_ratio", 0.0))
        
        if n_trades < min_trades:
            msg = f"Insufficient sample size: {n_trades} trades (minimum {min_trades} required)."
            print(f"⛔ [PROMOTION GATE] BLOCKED: {msg}")
            return {"promoted": False, "reason": msg}
            
        if sharpe < min_sharpe:
            msg = f"Sharpe ratio ({sharpe:.2f}) below minimum threshold ({min_sharpe:.2f})."
            print(f"⛔ [PROMOTION GATE] BLOCKED: {msg}")
            return {"promoted": False, "reason": msg}
            
        print(f"✅ [PROMOTION GATE] PASSED: Scorecard verified (trades={n_trades}, Sharpe={sharpe:.2f}). Ready for live deployment.")
        return {"promoted": True, "reason": "Scorecard verified"}
    except Exception as e:
        msg = f"ERROR evaluating scorecard: {e}"
        print(f"⛔ [PROMOTION GATE] {msg}")
        return {"promoted": False, "reason": msg}


def check_paper_trade_gate_or_raise():
    """Hard boundary enforcement helper: call before placing live orders."""
    res = enforce_paper_trade_promotion_gate()
    if not res.get("promoted", False):
        raise RuntimeError(f"PROMOTION_BLOCKED: {res.get('reason')}")
    return True


if __name__ == "__main__":
    pred = test_live_hmm()
    regime = pred.get("label") if pred else None
    res = test_live_screener_full_nse(regime=regime)
    gate_status = enforce_paper_trade_promotion_gate()
    print("\n🎉 ALL LIVE VERIFICATIONS COMPLETED.")

