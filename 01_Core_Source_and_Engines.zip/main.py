#!/usr/bin/env python3
"""
Quantum Portfolio — entry point
Run: python main.py
"""
import sys, os
# Prevent OpenMP/PyTorch crashes in background QThreads on macOS
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["VECLIB_MAXIMUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import multiprocessing
if multiprocessing.current_process().name == "MainProcess":
    try:
        from PySide6 import QtWebEngineWidgets  # noqa: F401
    except ImportError:
        pass

def main():
    from ui.main_window import main as ui_main
    ui_main()

if __name__ == "__main__":
    main()
