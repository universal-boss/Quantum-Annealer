"""
math_engine
===========
Unified Quantum Annealer Quantitative Math Engine.

Exposes high-performance vector optimizers, CVaR risk managers,
copula tail risk screeners, RL order execution agents,
NLP sentiment view extractors, factor risk models, and broker routers.
"""

from .indicators import *

# Core Solvers & Optimizers
try:
    from .jax_optimizer import JaxPortfolioOptimizer
except Exception:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    JaxPortfolioOptimizer = None

try:
    from .expected_shortfall import ExpectedShortfallOptimizer
except Exception:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    ExpectedShortfallOptimizer = None

try:
    from .copula_risk import CopulaTailRiskScreener
except Exception:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    CopulaTailRiskScreener = None

try:
    # ROUND-44 FIX (AUDIT class of R43 §2.7/§2.8): this import named a module
    # `rl_execution_agent` that has never existed in the tree (the DRL module
    # is `drl_execution_agent`, from the Round-34 refactor) and class names
    # (`ExecutionLOBEnvironment` / `RLExecutionPolicy`) that never existed
    # either — so BOTH documented exports silently resolved to None in every
    # build. Import the real classes and alias them under the documented
    # legacy names (same treatment as CQMFormulator -> QuantumCQMFormulator).
    from .drl_execution_agent import ExecutionEnv, PPOExecutionAgent
    ExecutionLOBEnvironment = ExecutionEnv
    RLExecutionPolicy = PPOExecutionAgent
except Exception:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    ExecutionEnv = None
    PPOExecutionAgent = None
    ExecutionLOBEnvironment = None
    RLExecutionPolicy = None

# ROUND-44 FIX: `from .qaoa_optimizer import QAOAPortfolioCompiler` named a
# module that does not exist anywhere in the tree, and no QAOA class is
# defined in any module — the export was silently None in every build with
# zero references outside this file. Dead export removed from __all__
# (same treatment as the Round-43 AUDIT-17 dead-export cleanup).

# AUDIT-FIX (Round 43 / AUDIT-17): filing_sentiment.py quarantined to
# math_engine/_attic/ — provably unreachable from the live application.
# from .filing_sentiment import FilingSentimentViewsExtractor

try:
    from .solver_coordinator import SolverCoordinator
except Exception:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    SolverCoordinator = None

try:
    # ROUND-44 FIX: `WassersteinCalibrator` never existed in
    # wasserstein_calibrator.py (the class is `WassersteinRadiusCalibrator`),
    # so the documented export was silently None in every build. Export the
    # real class under both names.
    from .wasserstein_calibrator import WassersteinRadiusCalibrator
    WassersteinCalibrator = WassersteinRadiusCalibrator
except Exception:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    WassersteinRadiusCalibrator = None
    WassersteinCalibrator = None

try:
    # AUDIT-FIX (Round 43 / AUDIT-17 leftover): this import used the name
    # `CQMFormulator`, which never existed in cqm_formulator.py (the class is
    # `QuantumCQMFormulator`), so the documented legacy export silently
    # resolved to None in every build. Expose the real class under the
    # documented name (and under its real name, for direct importers).
    from .cqm_formulator import QuantumCQMFormulator
    CQMFormulator = QuantumCQMFormulator
except Exception:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    CQMFormulator = None
    QuantumCQMFormulator = None

try:
    from .ring_buffer import RingBufferMemoryRegister, RingBuffer
    from .baryonic_memory import BaryonicMemoryBuffer
except Exception:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    RingBufferMemoryRegister = None
    RingBuffer = None
    BaryonicMemoryBuffer = None

try:
    from .dynamic_factor_engine import DynamicFactorWeightEngine
except Exception:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    DynamicFactorWeightEngine = None

try:
    # ROUND-44 FIX: `LatentManifoldScreener` never existed in latent_screener.py
    # (the class is `LatentSpaceScreener`) — silently-None export. Export the
    # real class under both names.
    from .latent_screener import LatentSpaceScreener
    LatentManifoldScreener = LatentSpaceScreener
except Exception:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    LatentSpaceScreener = None
    LatentManifoldScreener = None

try:
    # ROUND-44 FIX: `RegimeDetector` never existed in regime_detector.py (the
    # class is `MarketRegimeDetector`, which internal callers already import
    # directly) — silently-None export. Export the real class under both names.
    from .regime_detector import MarketRegimeDetector
    RegimeDetector = MarketRegimeDetector
except Exception:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    MarketRegimeDetector = None
    RegimeDetector = None

try:
    from .smart_order_router import SmartOrderRouter
except Exception:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    SmartOrderRouter = None

try:
    # AUDIT-FIX (Round 43 / AUDIT-18 leftover): `DhanExecutionRouter` was
    # exported in __all__ but never defined anywhere — the documented
    # remediation ("DhanExecutionRouter composes DhanV2Client, fails loudly")
    # was never applied, so `math_engine.DhanExecutionRouter` silently
    # resolved to None. It is now a real class in broker_router.py.
    from .broker_router import (
        AngelOneAdapter,
        AngelOneExecutionRouter,
        DhanAdapter,
        DhanExecutionRouter,
    )
except Exception:
    AngelOneAdapter = None
    AngelOneExecutionRouter = None
    DhanAdapter = None
    DhanExecutionRouter = None

try:
    from .websocket_feed import AngelOnePollingFeedClient, MockWebSocketClient, DhanPollingFeedClient
except Exception:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    AngelOnePollingFeedClient = None
    MockWebSocketClient = None
    DhanPollingFeedClient = None

# AUDIT-FIX (Round 43 / AUDIT-17): integrated_gems.py / ultimate_pinnacle_
# engine.py / master_pinnacle_suite.py quarantined to math_engine/_attic/ —
# provably unreachable from the live application.
# from .integrated_gems import InstitutionalGemsEngine
# from .ultimate_pinnacle_engine import UltimatePinnacleEngine
# from .master_pinnacle_suite import MasterPinnacleSuite

__all__ = [
    "JaxPortfolioOptimizer",
    "ExpectedShortfallOptimizer",
    "CopulaTailRiskScreener",
    "ExecutionEnv",
    "PPOExecutionAgent",
    "ExecutionLOBEnvironment",
    "RLExecutionPolicy",
    "SolverCoordinator",
    "WassersteinRadiusCalibrator",
    "WassersteinCalibrator",
    "CQMFormulator",
    "QuantumCQMFormulator",
    "BaryonicMemoryBuffer",
    "DynamicFactorWeightEngine",
    "LatentSpaceScreener",
    "LatentManifoldScreener",
    "MarketRegimeDetector",
    "RegimeDetector",
    "SmartOrderRouter",
    "AngelOneAdapter",
    "AngelOneExecutionRouter",
    "DhanAdapter",
    "DhanExecutionRouter",
    "AngelOnePollingFeedClient",
    "MockWebSocketClient",
    "DhanPollingFeedClient",
]
