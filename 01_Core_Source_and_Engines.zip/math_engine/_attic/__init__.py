"""Quarantine area — AUDIT-17 / Round 43.

Modules in this package are provably unreachable from the live application
(module-level import-graph analysis; nothing outside math_engine imports them,
directly or transitively). They are retained for reference, not deleted, but
are excluded from the shipped package surface. Do NOT import from here in
production code; wire a module back into the live app by moving it up to
math_engine/ and adding an explicit import at the call site first.
"""
