"""
math_engine/barra_axioma.py
===========================
Pillar 2: MSCI Barra Global Equity Factor Model & Axioma SOCP Optimization Engine.
Implements:
1. Barra 10-Style Factor Exposure Matrix & Cross-Sectional Standardization.
2. Pure Factor Return Extraction via Generalized Least Squares (GLS: f = (X^T V^-1 X)^-1 X^T V^-1 R).
3. Axioma-Style Second-Order Cone Programming (SOCP) with piecewise turnover & market impact penalties.
"""
from __future__ import annotations

import logging
from typing import Dict, List, Tuple, Optional, Any, Union
import numpy as np
import pandas as pd
from scipy.optimize import minimize

logger = logging.getLogger(__name__)


class BarraAxiomaEngine:
    """MSCI Barra style cross-sectional factor modeling and Axioma robust SOCP optimization."""

    BARRA_STYLE_FACTORS = [
        "Size", "Value", "Momentum", "Volatility", "Liquidity",
        "Quality", "Growth", "Leverage", "Dividend_Yield", "Beta"
    ]

    @classmethod
    def standardize_factor_exposures(cls, raw_factors_df: pd.DataFrame) -> pd.DataFrame:
        """
        Cross-sectional Winsorization (+-3 sigma) and Z-Score standardization
        to ensure zero mean and unit standard deviation across the equity universe.
        """
        std_df = pd.DataFrame(index=raw_factors_df.index)
        for col in raw_factors_df.columns:
            series = raw_factors_df[col].astype(float)
            # 1. Winsorize at 3 sigma
            med = series.median()
            mad = (series - med).abs().median() + 1e-6
            z = (series - med) / (1.4826 * mad)
            clipped = np.clip(z, -3.0, 3.0)
            # 2. Re-standardize
            std_df[col] = (clipped - clipped.mean()) / (clipped.std() + 1e-6)
        return std_df

    @classmethod
    def extract_pure_factor_returns_gls(
        cls,
        exposure_matrix_X: np.ndarray,
        asset_returns_R: np.ndarray,
        idiosyncratic_var_V: Optional[np.ndarray] = None
    ) -> Tuple[np.ndarray, np.ndarray, float]:
        """
        Generalized Least Squares (GLS) Factor Return Extraction:
        f_t = (X^T V^-1 X)^-1 X^T V^-1 R_t
        Residuals: epsilon_t = R_t - X * f_t
        """
        X = np.asarray(exposure_matrix_X, dtype=float)
        R = np.asarray(asset_returns_R, dtype=float)
        N, K = X.shape

        if idiosyncratic_var_V is None:
            # WLS using inverse of sample variance proxy
            V_inv_diag = np.ones(N)
        else:
            V_inv_diag = 1.0 / np.maximum(np.asarray(idiosyncratic_var_V, dtype=float), 1e-6)

        # X^T * V^-1 * X
        X_weighted = X * V_inv_diag[:, None]
        Xt_Vinv_X = X.T @ X_weighted
        Xt_Vinv_R = X_weighted.T @ R

        # Solve system
        try:
            f_returns = np.linalg.solve(Xt_Vinv_X, Xt_Vinv_R)
        except np.linalg.LinAlgError:
            f_returns = np.linalg.pinv(Xt_Vinv_X) @ Xt_Vinv_R

        residuals = R - (X @ f_returns)
        r_squared = float(1.0 - (np.var(residuals) / (np.var(R) + 1e-9)))

        return f_returns, residuals, max(0.0, min(1.0, r_squared))

    @classmethod
    def axioma_robust_socp_optimization(
        cls,
        expected_returns: np.ndarray,
        factor_exposures_X: np.ndarray,
        factor_cov_F: np.ndarray,
        specific_var_D: np.ndarray,
        current_weights: np.ndarray,
        target_turnover: float = 0.20,
        risk_aversion: float = 2.5,
        max_weight: float = 0.15,
        market_impact_quad_cost: float = 0.05
    ) -> Dict[str, Any]:
        """
        Axioma-Style Second-Order Cone Programming (SOCP) Portfolio Solver:
        min_w - mu^T w + 0.5 * lambda * (w^T X F X^T w + w^T D w) + Impact_Cost * ||w - w_0||_2^2
        subject to:
        - Sum w_i = 1, 0 <= w_i <= max_weight
        - ||w - w_0||_1 <= target_turnover
        """
        mu = np.asarray(expected_returns, dtype=float)
        X = np.asarray(factor_exposures_X, dtype=float)
        F = np.asarray(factor_cov_F, dtype=float)
        D = np.asarray(specific_var_D, dtype=float)
        w0 = np.asarray(current_weights, dtype=float)
        N = len(mu)

        # Precompute systematic covariance: Sigma_sys = X * F * X^T
        Sigma_sys = X @ F @ X.T

        def objective(w):
            w = np.asarray(w, dtype=float)
            # Alpha
            alpha_term = -float(np.dot(w, mu))
            # Barra Factor Risk: Systematic + Specific
            sys_risk = float(w @ Sigma_sys @ w)
            spec_risk = float(np.sum((w ** 2) * D))
            total_risk = 0.5 * risk_aversion * (sys_risk + spec_risk)
            # Quadratic market impact
            turnover_l2 = float(np.sum((w - w0) ** 2))
            impact_penalty = market_impact_quad_cost * turnover_l2
            return alpha_term + total_risk + impact_penalty

        cons = [
            {'type': 'eq', 'fun': lambda w: np.sum(w) - 1.0},
            {'type': 'ineq', 'fun': lambda w: target_turnover - np.sum(np.abs(w - w0))}
        ]
        bnds = tuple((0.0, max_weight) for _ in range(N))

        res = minimize(objective, w0, method='SLSQP', bounds=bnds, constraints=cons)
        optimal_w = res.x if res.success else w0

        # Decompose optimal portfolio risk
        opt_sys_var = float(optimal_w @ Sigma_sys @ optimal_w)
        opt_spec_var = float(np.sum((optimal_w ** 2) * D))
        total_opt_vol = np.sqrt(opt_sys_var + opt_spec_var) * np.sqrt(252.0)

        return {
            "optimal_weights": optimal_w,
            "annualized_volatility_%": round(total_opt_vol * 100.0, 2),
            "systematic_risk_share_%": round((opt_sys_var / max(opt_sys_var + opt_spec_var, 1e-9)) * 100.0, 2),
            "specific_risk_share_%": round((opt_spec_var / max(opt_sys_var + opt_spec_var, 1e-9)) * 100.0, 2),
            "realized_turnover_%": round(float(np.sum(np.abs(optimal_w - w0))) * 100.0, 2)
        }
