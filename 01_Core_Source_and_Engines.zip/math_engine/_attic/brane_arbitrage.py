"""
math_engine/brane_arbitrage.py
==============================
Backward-compatibility alias. The canonical module is now:
`math_engine.cross_exchange_basis`.
"""
from __future__ import annotations
from math_engine.cross_exchange_basis import CrossExchangeArbitrageEngine

__all__ = ["CrossExchangeArbitrageEngine"]
