"""
math_engine/ctc_causality.py
============================
Backward-compatibility alias. The canonical module is now:
`math_engine.granger_causality`.
"""
from __future__ import annotations
from math_engine.granger_causality import GrangerCausalityEngine, ContinuousTimeGrangerCausality

__all__ = ["GrangerCausalityEngine", "ContinuousTimeGrangerCausality"]
