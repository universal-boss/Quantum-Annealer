"""
math_engine/godelian_oracle.py
==============================
Backward-compatibility alias. The canonical module is now:
`math_engine.stationarity_filter`.
"""
from __future__ import annotations
from math_engine.stationarity_filter import StationarityCointegrationValidator

__all__ = ["StationarityCointegrationValidator"]
