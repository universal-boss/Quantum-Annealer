"""
math_engine/integrated_gems.py
==============================
Unified Production Integration Layer for the 4 Quantitative Gems:
  1. FinBERT Corporate Filing NLP & Governance Sentiment
  2. Multi-Asset Lead-Lag Cross-Correlation Network
  3. Multivariate DCC-GARCH Dynamic Conditional Correlation
  4. Snell Envelope Optimal Stopping Exit Calculator
"""

from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, List, Optional

from ml_alpha.finbert_sentiment import FinBERTSentimentEngine
from math_engine.cross_correlation_leadlag import CrossCorrelationLeadLagEngine
from math_engine.dcc_garch import DCCGARCHEngine
from math_engine.optimal_stopping_time import OptimalStoppingEngine
from math_engine.stochastic_control_hjb import HJBOptimalControlEngine
from math_engine.hawkes_detector import HawkesJumpDetector

logger = logging.getLogger(__name__)


class InstitutionalGemsEngine:
    """
    Unified Orchestrator for NLP Sentiment, Lead-Lag Arbitrage, DCC-GARCH Risk,
    Snell Exit Stopping, HJB Stochastic Control, and Hawkes Flow Spillovers.
    """

    def __init__(self):
        self.finbert = FinBERTSentimentEngine()
        self.leadlag = CrossCorrelationLeadLagEngine()
        self.dcc = DCCGARCHEngine()
        self.stopping = OptimalStoppingEngine()
        self.hjb = HJBOptimalControlEngine()
        self.hawkes = HawkesJumpDetector()

    def evaluate_corporate_sentiment(self, text_filings: Dict[str, str]) -> pd.Series:
        """
        Parses text filings and returns NLP sentiment scores for tickers in range [-1.0, +1.0].
        """
        scores = {}
        for ticker, text in text_filings.items():
            res = self.finbert.analyze_filing_text(text)
            score = res.get("sentiment_score", 0.0)
            if res.get("is_red_flag_alert"):
                score -= 0.50
            scores[ticker] = max(min(score, 1.0), -1.0)
        return pd.Series(scores)

    def evaluate_lead_lag_signals(self, returns_df: pd.DataFrame, max_lag: int = 5) -> Dict[str, Any]:
        """
        Identifies sector leaders and lagging breakout candidates.
        """
        return self.leadlag.estimate_lead_lag_offsets(returns_df, max_lag=max_lag)

    def evaluate_dcc_risk(self, returns_df: pd.DataFrame) -> Dict[str, Any]:
        """
        Computes dynamic conditional correlation matrix and portfolio correlation stress.
        """
        return self.dcc.fit_dynamic_correlation(returns_df)

    def evaluate_optimal_exits(self, prices_df: pd.DataFrame, stop_loss_pct: float = -0.05, target_profit_pct: float = 0.15) -> pd.DataFrame:
        """
        Calculates optimal exit decisions per stock.
        """
        exit_rows = []
        for col in prices_df.columns:
            series = prices_df[col].dropna()
            if len(series) > 10:
                cum_ret = (series / series.iloc[0]) - 1.0
                res = self.stopping.calculate_optimal_exit(cum_ret, stop_loss_pct=stop_loss_pct, target_profit_pct=target_profit_pct)
                exit_rows.append({
                    "Ticker": col,
                    "Should_Exit": res.get("should_exit_now", False),
                    "Exit_Reason": res.get("exit_reason", "HOLD_CONTINUE"),
                    "Snell_Val": res.get("snell_continuation_val", 0.0)
                })
        return pd.DataFrame(exit_rows)

    def evaluate_hjb_optimal_allocation(self, mu: float = 0.12, r: float = 0.065, sigma: float = 0.18, gamma: float = 2.5) -> Dict[str, Any]:
        """
        Calculates continuous HJB stochastic control equity vs cash allocation.
        """
        return self.hjb.solve_merton_hjb(mu=mu, r=r, sigma=sigma, gamma_risk_aversion=gamma)
