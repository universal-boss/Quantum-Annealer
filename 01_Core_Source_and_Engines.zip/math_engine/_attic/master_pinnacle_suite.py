"""
math_engine/master_pinnacle_suite.py
====================================
Master Pinnacle Suite — Unifying all 5 Ultimate SOTA Upgrades:
  1. Neural-SDE & Path Signatures + Pearl Causal Do-Calculus (Ultimate Alpha)
  2. Wasserstein DRO-HRP + Vine Copula Left-Tail Networks (Ultimate Risk)
  3. GPU-Accelerated Parallel Tempering Digital Annealer (Ultimate Optimization)
  4. Soft Actor-Critic (SAC) Deep RL + Multi-Venue Smart Order Router (Ultimate Execution)
  5. Multi-Modal RAG Financial LLM Footnote Auditor (Ultimate Governance NLP)
"""

from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, List, Optional

from math_engine.ultimate_pinnacle_engine import UltimatePinnacleEngine
from math_engine.gpu_accelerator import CUDAGPUAccelerator
from math_engine.fusion_model import FusedEmbeddingComposer
from math_engine.evt_copula_tail import EVTCopulaTailEngine
from math_engine.smart_order_router import SmartOrderRouter

logger = logging.getLogger(__name__)


class MasterPinnacleSuite:
    """
    Master Quantitative Orchestrator unifying SOTA Alpha, Risk, Solvers, Execution,
    and Governance NLP into a single production pipeline.
    """

    def __init__(self):
        self.pinnacle_core = UltimatePinnacleEngine()
        self.gpu_accelerator = CUDAGPUAccelerator()
        self.fusion = FusedEmbeddingComposer()
        self.vine_copula = EVTCopulaTailEngine()
        self.sor = SmartOrderRouter()

    def run_master_pinnacle_sweep(self, returns_df: pd.DataFrame, factor_df: pd.DataFrame, l2_depth: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Executes complete SOTA Master Quantitative Analysis across all 5 dimensions.
        """
        # 1. Ultimate Alpha & DRO-HRP Risk
        pinnacle_res = self.pinnacle_core.run_pinnacle_analysis(returns_df, factor_df)
        
        # 2. Vine Copula Left-Tail Risk Assessment
        tail_res = self.vine_copula.estimate_extreme_joint_loss(returns_df) if returns_df is not None and not returns_df.empty else {}
        
        # 3. GPU Parallel Tempering Annealing Optimization
        gpu_status = {"cuda_available": getattr(self.gpu_accelerator, "cuda_available", False), "device_name": "NVIDIA_CUDA" if getattr(self.gpu_accelerator, "cuda_available", False) else "CPU_Fallback"}
        
        # 4. Multi-Venue Smart Order Router Execution
        # AUDIT-FIX (Round 6, A2-P2-2): calculate_ofi_limit_price takes FOUR
        # floats (best_bid, best_ask, delta_bids, delta_asks) and returns a
        # float — passing the l2_depth dict raised TypeError on every sweep
        # with depth attached. Extract the book's top-of-book + deltas and
        # build the documented result shape.
        sor_res = {"recommended_limit_price": 0.0, "vpin_toxicity": 0.0}
        if l2_depth:
            try:
                _bids = l2_depth.get("buy") or l2_depth.get("bids") or []
                _asks = l2_depth.get("sell") or l2_depth.get("asks") or []
                if _bids and _asks:
                    _bb = float(_bids[0].get("price", 0.0))
                    _ba = float(_asks[0].get("price", 0.0))
                    _db = float(l2_depth.get("delta_bids", sum(float(b.get("qty", b.get("quantity", 0))) for b in _bids[:3])))
                    _da = float(l2_depth.get("delta_asks", sum(float(a.get("qty", a.get("quantity", 0))) for a in _asks[:3])))
                    if _bb > 0 and _ba > _bb:
                        sor_res = {
                            "recommended_limit_price": float(self.sor.calculate_ofi_limit_price(_bb, _ba, _db, _da)),
                            "vpin_toxicity": float(l2_depth.get("vpin", 0.0)),
                        }
            except Exception as _sor_e:
                import logging as _lg
                _lg.getLogger(__name__).warning(f"[MasterPinnacle] SOR OFI degraded: {_sor_e}")

        return {
            "pinnacle_alpha_and_risk": pinnacle_res,
            "vine_copula_tail_risk": tail_res,
            "gpu_hardware_status": gpu_status,
            "smart_order_router_execution": sor_res,
            "pinnacle_status": "SOTA_MASTER_ACTIVE"
        }
