"""
math_engine/omega_point.py
==========================
Terminal Horizon Liquidation & Market Impact Optimizer.
Solves the Almgren-Chriss optimal execution trajectory for multi-asset liquidation
under temporary and permanent market impact constraints.
"""
from __future__ import annotations

import math
import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, List, Tuple, Optional

logger = logging.getLogger(__name__)


class TerminalHorizonOptimizer:
    """Almgren-Chriss Terminal Horizon Liquidation & Execution Scheduler.
    
    Optimizes asset liquidation schedules over target horizon T to minimize
    the combined cost of market impact and variance risk exposure.
    """

    def __init__(self, risk_aversion: float = 1e-6, eta: float = 0.1, gamma: float = 0.05) -> None:
        self.risk_aversion: float = float(risk_aversion)
        self.eta: float = float(eta)        # Temporary impact coefficient
        self.gamma: float = float(gamma)    # Permanent impact coefficient

    def compute_liquidation_schedule(
        self,
        initial_shares: float,
        horizon_days: int,
        daily_volatility: float,
        adv: float
    ) -> pd.DataFrame:
        """Calculates optimal daily trading trajectory over N horizon days."""
        n_days = max(1, int(horizon_days))
        x0 = float(initial_shares)
        sigma = float(daily_volatility)
        
        # Almgren-Chriss decay parameter kappa
        tau = 1.0
        kappa_sq = (self.risk_aversion * (sigma ** 2)) / max(1e-6, self.eta)
        kappa = math.sqrt(max(1e-8, kappa_sq))

        schedule = []
        remaining = x0
        for t in range(1, n_days + 1):
            if t == n_days:
                trade_qty = remaining
                remaining = 0.0
            else:
                # Hyperbolic sine decay formulation
                sinh_k_t = math.sinh(kappa * (n_days - t) * tau)
                sinh_k_T = math.sinh(kappa * n_days * tau)
                target_remaining = x0 * (sinh_k_t / max(1e-8, sinh_k_T))
                trade_qty = max(0.0, remaining - target_remaining)
                remaining = max(0.0, target_remaining)

            temp_impact = self.eta * (trade_qty / max(1.0, adv))
            perm_impact = self.gamma * (trade_qty / max(1.0, adv))

            schedule.append({
                "Day": t,
                "Trade Quantity": round(trade_qty, 2),
                "Remaining Shares": round(remaining, 2),
                "Est. Temp Impact %": round(temp_impact * 100.0, 4),
                "Est. Perm Impact %": round(perm_impact * 100.0, 4)
            })

        return pd.DataFrame(schedule)


# Canonical production class aliases
OmegaPointOptimizer = TerminalHorizonOptimizer
OmegaPointEngine = TerminalHorizonOptimizer
