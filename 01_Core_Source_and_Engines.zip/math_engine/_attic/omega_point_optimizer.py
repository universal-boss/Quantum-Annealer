"""
math_engine/omega_point_optimizer.py
====================================
Terminal Horizon Liquidation & Market Impact Optimizer (Alias Wrapper).
"""
from __future__ import annotations

from math_engine.omega_point import TerminalHorizonOptimizer, OmegaPointOptimizer

__all__ = ["TerminalHorizonOptimizer", "OmegaPointOptimizer"]
