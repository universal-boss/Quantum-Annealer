"""
math_engine/ontological_compiler.py
===================================
Backward-compatibility alias. The canonical module is now:
`math_engine.signal_robust_scaler`.
"""
from __future__ import annotations
from math_engine.signal_robust_scaler import SignalRobustScaler, SignalTaxonomyCompiler

__all__ = ["SignalRobustScaler", "SignalTaxonomyCompiler"]
