"""
math_engine/pit_adjuster.py
===========================
Point-in-Time price and corporate action adjustments calculator.
Ensures that backtesting queries retrieve split/dividend adjusted price series
exactly as they were known at a specific assertion system_timestamp.
"""
from __future__ import annotations

import logging
import pandas as pd
from typing import List, Dict, Any, Optional

logger = logging.getLogger(__name__)


class CorporateActionsPITAdjuster:
    """Manages Point-in-Time price reconstruction for backtests."""

    def __init__(self, db_store=None):
        self.db_store = db_store

    def get_adjusted_price_history_pit(
        self,
        tickers: List[str],
        as_of_system_timestamp: str,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> pd.DataFrame:
        """Retrieves raw price history from bi_temporal_price_history and reconstructs it.
        Aligns adjusted prices with dynamic PIT adjustments.
        """
        if self.db_store is None:
            return pd.DataFrame()

        # Fetch the PIT raw price history from DB
        raw_df = self.db_store.get_pit_price_history(
            tickers=tickers,
            as_of_system_timestamp=as_of_system_timestamp,
            start_date=start_date,
            end_date=end_date
        )
        if raw_df.empty:
            return pd.DataFrame()

        # Group by ticker and apply point-in-time adjustments
        adjusted_dfs = []
        for ticker, group in raw_df.groupby("ticker"):
            group = group.copy()
            group["date"] = pd.to_datetime(group["date"])
            group.set_index("date", inplace=True)
            
            rename_map = {
                "open": "Open", "high": "High", "low": "Low", 
                "close": "Close", "volume": "Volume"
            }
            group.rename(columns=rename_map, inplace=True)
            
            if "adjustment_factor" in group.columns:
                for col in ["Open", "High", "Low", "Close"]:
                    if col in group.columns:
                        group[col] = group[col] * group["adjustment_factor"]
                if "Volume" in group.columns:
                    group["Volume"] = group["Volume"] / group["adjustment_factor"]

            group.rename(columns={v: k for k, v in rename_map.items()}, inplace=True)
            adjusted_dfs.append(group)

        if not adjusted_dfs:
            return pd.DataFrame()
        return pd.concat(adjusted_dfs)
