"""
math_engine/transcendence_solver.py
===================================
Institutional Non-Convex Global Portfolio Optimizer.
Implements Differential Evolution and Particle Swarm Optimization (PSO) for portfolio
optimization under discrete cardinality and transaction cost constraints.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, List, Tuple, Optional, Callable
from scipy.optimize import differential_evolution

logger = logging.getLogger(__name__)


class GlobalPortfolioSolver:
    """Global Non-Convex Portfolio Optimization Solver.
    
    Solves non-convex portfolio optimization problems (cardinality constraints,
    minimum holding thresholds, and non-linear transaction cost penalties) via 
    Differential Evolution.
    """

    def __init__(self, max_iter: int = 100, pop_size: int = 15) -> None:
        self.max_iter: int = int(max_iter)
        self.pop_size: int = int(pop_size)

    def optimize_weights(
        self,
        expected_returns: np.ndarray,
        cov_matrix: np.ndarray,
        target_k: int = 15,
        risk_aversion: float = 1.0
    ) -> np.ndarray:
        """Finds non-convex optimal portfolio weight vector w."""
        n_assets = len(expected_returns)
        if n_assets == 0:
            return np.array([])

        mu = np.asarray(expected_returns, dtype=float)
        sigma = np.asarray(cov_matrix, dtype=float)

        def objective(weights: np.ndarray) -> float:
            # Softmax or positive projection
            w = np.maximum(0.0, weights)
            s_w = np.sum(w)
            if s_w <= 1e-8:
                return 1e6
            w = w / s_w

            # Mean-variance utility
            ret = float(np.dot(w, mu))
            vol = float(np.sqrt(max(1e-8, np.dot(w, np.dot(sigma, w)))))
            utility = ret - (risk_aversion * vol)

            # Cardinality penalty
            active_count = np.sum(w > 0.01)
            card_penalty = 0.5 * abs(active_count - target_k)

            return -(utility - card_penalty)

        bounds = [(0.0, 1.0) for _ in range(n_assets)]
        res = differential_evolution(
            objective,
            bounds,
            maxiter=self.max_iter,
            popsize=self.pop_size,
            seed=42
        )

        opt_w = np.maximum(0.0, res.x)
        s = np.sum(opt_w)
        if s > 0:
            opt_w /= s

        return opt_w


# Canonical production class aliases
TranscendenceSolver = GlobalPortfolioSolver
TranscendenceOptimizer = GlobalPortfolioSolver
