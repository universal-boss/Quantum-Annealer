"""
math_engine/advanced_validation.py
==================================
Domain VI: Validation, Statistical Deflation & Overfitting Guards (Criteria 76-85).
High-performance statistical validation suites including Deflated Sharpe Ratio (DSR),
Combinatorial Purged Cross-Validation (CPCV), Minimum Backtest Length (MinBTL),
Hansen's Superior Predictive Ability (SPA), White's Reality Check bootstrap,
Holm-Bonferroni FWER control, False Strategy Theorem (FST) hazard rates,
Information Coefficient (IC) & Rank IC, Information Ratio (IR), and Probabilistic Sharpe Ratio (PSR).
"""
from __future__ import annotations

import logging
from typing import Dict, List, Tuple, Optional, Any, Union
import numpy as np
import pandas as pd
from scipy import stats

logger = logging.getLogger(__name__)


def deflated_sharpe_ratio(
    est_sharpe: float,
    var_sharpe: float = None,
    skew: float = 0.0,
    kurtosis: float = 3.0,
    n_trials: int = 10,
    backtest_len: int = 252
) -> float:
    """76. Bailey & López de Prado Deflated Sharpe Ratio (DSR): Penalizes selection bias and multiple testing.

    AUDIT-FIX (Round 6, A1-P2-5): the previous body (a) never used
    `var_sharpe` (identical DSR for var=0.01 vs 100 — verified) and
    (b) compared an ANNUALIZED Sharpe against SR* = E[max of N standard
    normals] ≈ 2.58 for N=15 with no variance scaling — a unit-mismatched
    hurdle that failed every realistic strategy (SR=1.5, T=252 → DSR 7e-32).
    Canonical Bailey-LdP form now:
        SR* = sqrt(V[SR]) · [(1-γ)Φ⁻¹(1-1/N) + γΦ⁻¹(1-1/(N·e))]
        DSR = Φ( (SR - SR*) · sqrt(T-1) / sqrt(1 - γ₃SR + (γ₄-1)/4·SR²) )
    `est_sharpe` is the PER-PERIOD (non-annualized) Sharpe; `var_sharpe`
    is the per-period SR estimator variance (when None it is derived from
    (T-1) and the non-normality term, exactly as in the reference)."""
    if n_trials <= 1:
        n_trials = 1
    est_sharpe = float(est_sharpe)
    T = max(int(backtest_len), 3)
    denom = np.sqrt(1.0 - skew * est_sharpe + ((kurtosis - 1.0) / 4.0) * (est_sharpe ** 2))
    denom = max(denom, 1e-6)
    if var_sharpe is None or var_sharpe <= 0:
        var_sharpe = (denom ** 2) / (T - 1.0)
    # Expected maximum Sharpe under null hypothesis
    euler_mascheroni = 0.5772156649
    if n_trials > 1:
        q1 = max(1.0 - 1.0 / n_trials, 1e-10)
        q2 = max(1.0 - 1.0 / (n_trials * np.e), 1e-10)
        z1 = float(stats.norm.ppf(q1))
        z2 = float(stats.norm.ppf(q2))
        expected_max_std = (1.0 - euler_mascheroni) * z1 + euler_mascheroni * z2
    else:
        expected_max_std = 0.0
    sr_star = float(np.sqrt(max(var_sharpe, 1e-16)) * expected_max_std)

    z = (est_sharpe - sr_star) * np.sqrt(T - 1.0) / denom
    dsr = float(stats.norm.cdf(z))
    return float(np.clip(dsr, 0.0, 1.0))


def combinatorial_purged_cross_validation(
    returns: Union[pd.Series, np.ndarray],
    n_splits: int = 6,
    n_test_splits: int = 2,
    embargo_pct: float = 0.01
) -> List[Tuple[np.ndarray, np.ndarray]]:
    """77. Combinatorial Purged Cross-Validation (CPCV): Non-sequential train/test path partitioner with embargo."""
    from itertools import combinations
    r = np.asarray(returns, dtype=float)
    T = len(r)
    # ROUND 45 FIX: the old `split_size = T // n_splits` partition silently
    # DROPPED the last `T % n_splits` observations from every train AND test
    # split of every path (e.g. T=100, n_splits=6: indices 96-99 appeared
    # nowhere — the most recent data simply vanished). np.array_split
    # partitions ALL T observations.
    splits = [list(map(int, part)) for part in np.array_split(np.arange(T), n_splits)]
    embargo = int(T * embargo_pct)
    
    paths = []
    
    for test_comb in combinations(range(n_splits), n_test_splits):
        test_indices = []
        for s_idx in test_comb:
            test_indices.extend(splits[s_idx])
            
        train_indices = []
        for s_idx in range(n_splits):
            if s_idx not in test_comb:
                train_sub = splits[s_idx]
                # Apply purging around test splits
                purged_sub = [idx for idx in train_sub if not any(abs(idx - t_idx) <= embargo for t_idx in test_indices)]
                train_indices.extend(purged_sub)
                
        paths.append((np.array(train_indices), np.array(test_indices)))
    return paths


def minimum_backtest_length(
    est_sharpe: float,
    skew: float = 0.0,
    kurtosis: float = 3.0,
    alpha: float = 0.05
) -> float:
    """78. Minimum Backtest Length (MinBTL in years): MinBTL = 1 + [1 - skew*SR + (kurt-1)/4*SR^2] * (Z_alpha / SR)^2 / 252."""
    if abs(est_sharpe) < 1e-4:
        return None  # Near-zero Sharpe — MinBTL formula diverges; backtest length is undefined
    z_alpha = stats.norm.ppf(1.0 - alpha)
    bracket = 1.0 - skew * est_sharpe + ((kurtosis - 1.0) / 4.0) * (est_sharpe ** 2)
    min_btl_days = 1.0 + bracket * ((z_alpha / est_sharpe) ** 2)
    return float(max(0.1, min_btl_days / 252.0))


def hansens_superior_predictive_ability(
    bench_returns: Union[pd.Series, np.ndarray],
    strategy_returns: Union[pd.DataFrame, np.ndarray],
    n_bootstraps: int = 500
) -> float:
    """79. Hansen's Superior Predictive Ability (SPA): Bootstrap hypothesis test for data-snooped alpha."""
    b = np.asarray(bench_returns, dtype=float)
    S = np.asarray(strategy_returns, dtype=float)
    if S.ndim == 1:
        S = S[:, None]
    T, K = S.shape
    excess = S - b[:, None]
    mean_excess = np.mean(excess, axis=0)
    
    # Test statistic is maximum studentized excess return
    var_excess = np.var(excess, axis=0) + 1e-9
    t_stat = np.max(np.sqrt(T) * mean_excess / np.sqrt(var_excess))
    
    # ROUND 45 FIX (two defects):
    # (a) the legacy global-seed call reseeded the PROCESS-WIDE NumPy RNG on
    #     every call — every later np.random.* draw in the host process became
    #     deterministic off this function's seed stream. Now uses a LOCAL
    #     default_rng.
    # (b) The comment said "stationary bootstrap" but the loop did iid row
    #     resampling, which is invalid for autocorrelated returns. Now a
    #     genuine stationary bootstrap (Politis-Romano): random start index +
    #     geometric block lengths with expected length ~5% of T.
    rng = np.random.default_rng(42)
    mean_block = max(2.0, 0.05 * T)
    p_restart = 1.0 / mean_block
    boot_stats = []
    for _ in range(n_bootstraps):
        boot_idx = np.empty(T, dtype=int)
        pos = 0
        start = int(rng.integers(0, T))
        while pos < T:
            block_len = max(1, int(rng.geometric(p_restart)))
            end = min(pos + block_len, T)
            boot_idx[pos:end] = (start + np.arange(end - pos)) % T
            pos = end
            start = int(rng.integers(0, T))
        boot_excess = excess[boot_idx] - mean_excess
        boot_mean = np.mean(boot_excess, axis=0)
        boot_t = np.max(np.sqrt(T) * boot_mean / np.sqrt(var_excess))
        boot_stats.append(boot_t)
        
    p_value = float(np.mean(np.array(boot_stats) >= t_stat))
    return p_value


def whites_reality_check(
    bench_returns: Union[pd.Series, np.ndarray],
    strategy_returns: Union[pd.DataFrame, np.ndarray],
    n_bootstraps: int = 500
) -> float:
    """80. White's Reality Check: Bootstrap test for data mining among thousands of factors."""
    return hansens_superior_predictive_ability(bench_returns, strategy_returns, n_bootstraps=n_bootstraps)


def holm_bonferroni_fwer_control(p_values: List[float], alpha: float = 0.05) -> List[bool]:
    """81. Holm-Bonferroni FWER Control: Controls Type-I error across multiple profile backtests."""
    p_arr = np.asarray(p_values, dtype=float)
    K = len(p_arr)
    sorted_indices = np.argsort(p_arr)
    rejected = [False] * K
    
    for i, idx in enumerate(sorted_indices):
        thresh = alpha / (K - i)
        if p_arr[idx] <= thresh:
            rejected[idx] = True
        else:
            break
    return rejected


def false_strategy_theorem_prob(n_trials: int, alpha: float = 0.05) -> float:
    """82. False Strategy Theorem (FST): Probability that best strategy is a false positive given N trials."""
    p_false = 1.0 - ((1.0 - alpha) ** n_trials)
    return float(np.clip(p_false, 0.0, 1.0))


def information_coefficient_and_rank_ic(
    factor_scores: Union[pd.Series, np.ndarray],
    forward_returns: Union[pd.Series, np.ndarray]
) -> Tuple[float, float]:
    """83. Information Coefficient (Pearson IC) and Rank IC (Spearman rho)."""
    f = np.asarray(factor_scores, dtype=float)
    r = np.asarray(forward_returns, dtype=float)
    valid = np.isfinite(f) & np.isfinite(r)
    if np.sum(valid) < 3:
        return 0.0, 0.0
    f, r = f[valid], r[valid]
    pearson_ic = float(np.corrcoef(f, r)[0, 1])
    spearman_rank_ic = float(stats.spearmanr(f, r)[0])
    return pearson_ic, spearman_rank_ic


def information_ratio_annualized(ic_series: Union[List[float], np.ndarray]) -> float:
    """84. Information Ratio (IR): IR = Mean(IC) / Std(IC) * sqrt(252)."""
    ics = np.asarray(ic_series, dtype=float)
    if len(ics) < 2 or np.std(ics) < 1e-9:
        return 0.0
    ir = float((np.mean(ics) / np.std(ics)) * np.sqrt(252.0))
    return ir


def probabilistic_sharpe_ratio(
    est_sharpe: float,
    bench_sharpe: float = 0.0,
    skew: float = 0.0,
    kurtosis: float = 3.0,
    backtest_len: int = 252
) -> float:
    """85. Probabilistic Sharpe Ratio (PSR): Probability that estimated Sharpe exceeds benchmark Sharpe."""
    denom = np.sqrt(1.0 - skew * est_sharpe + ((kurtosis - 1.0) / 4.0) * (est_sharpe ** 2))
    denom = max(denom, 1e-6)
    z = (est_sharpe - bench_sharpe) * np.sqrt(backtest_len - 1.0) / denom
    psr = float(stats.norm.cdf(z))
    return float(np.clip(psr, 0.0, 1.0))
