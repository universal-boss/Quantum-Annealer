"""
math_engine/aladdin_macro_transmission.py
=========================================
BlackRock Aladdin Macro-to-Style Factor Transmission Matrix Engine.

Maps macroeconomic scenario shifts (e.g. Brent Crude, 10Y Yield, USD/INR, VIX)
into multi-factor style shifts via Ridge Regression:
T = (M^T M + lambda I)^-1 M^T F
Delta f = T * Delta M
"""
from __future__ import annotations

import logging
from typing import Dict, List, Tuple, Optional, Any, Union
import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


class AladdinMacroTransmissionEngine:
    """Aladdin Macro Factor Transmission & Ridge Multi-Factor Shock Projector."""

    DEFAULT_MACRO_FACTORS = ["Brent_Crude_Shock", "India_10Y_Yield_Shock", "USD_INR_Shock", "India_VIX_Shock"]

    @classmethod
    def fit_transmission_matrix(
        cls,
        macro_history_M: np.ndarray,
        style_factors_F: np.ndarray,
        ridge_penalty: float = 1.0
    ) -> np.ndarray:
        """
        Fits Macro-to-Style Transmission Matrix T:
        T = (M^T M + lambda I)^-1 M^T F
        """
        M = np.asarray(macro_history_M, dtype=float)
        F = np.asarray(style_factors_F, dtype=float)
        K_macro = M.shape[1]

        Mt_M = M.T @ M
        ridge_diag = np.eye(K_macro) * ridge_penalty
        T_matrix = np.linalg.inv(Mt_M + ridge_diag) @ M.T @ F
        return T_matrix

    @classmethod
    def project_macro_scenario_on_portfolio(
        cls,
        portfolio_weights: np.ndarray,
        factor_exposures_X: np.ndarray,
        transmission_matrix_T: np.ndarray,
        macro_shock_vector: np.ndarray
    ) -> Dict[str, Any]:
        """
        Projects an explicit macro scenario vector onto the portfolio:
        Delta f = T * Delta M
        Delta Portfolio = w^T * X * Delta f
        """
        w = np.asarray(portfolio_weights, dtype=float)
        X = np.asarray(factor_exposures_X, dtype=float)
        T = np.asarray(transmission_matrix_T, dtype=float)
        dM = np.asarray(macro_shock_vector, dtype=float)

        # 1. Transmit macro shock into style factor shifts
        delta_f = dM @ T

        # 2. Transmit factor shifts into stock-level return impacts
        stock_impacts = X @ delta_f

        # 3. Portfolio level impact
        port_impact_pct = float(np.dot(w, stock_impacts)) * 100.0

        return {
            "projected_portfolio_impact_%": round(port_impact_pct, 2),
            "factor_shift_vector": delta_f,
            "stock_impact_vector_%": np.round(stock_impacts * 100.0, 2)
        }
