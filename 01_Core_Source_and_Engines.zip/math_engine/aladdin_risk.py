"""
math_engine/aladdin_risk.py
===========================
Pillar 3: BlackRock Aladdin Multi-Asset Risk Suite & Stress Replay Engine.
Implements:
1. Macro Historical Crisis Scenario Replay (2008 GFC, 2020 Covid, 2022 Rates, 2024 VIX Spike).
2. Liquidity Horizon Days-to-Liquidate Analysis with Participation Constraints & Slippage.
3. High-Dimensional Monte Carlo Student-t Copula Tail Risk Simulations (10,000 Paths).
"""
from __future__ import annotations

import logging
from typing import Dict, List, Tuple, Optional, Any, Union
import numpy as np
import pandas as pd
from scipy import stats

logger = logging.getLogger(__name__)


class AladdinRiskSuite:
    """BlackRock Aladdin style enterprise multi-asset stress testing and liquidity horizon analyzer."""

    HISTORICAL_CRISIS_SCENARIOS = {
        "2008_Global_Financial_Crisis": {
            "Equity_Market_Shock": -0.38,
            "Volatility_Multiple": 3.2,
            "Credit_Spread_Widening_bps": 450,
            "Liquidity_Haircut_Factor": 0.40
        },
        "2020_Covid_Liquidity_Freeze": {
            "Equity_Market_Shock": -0.28,
            "Volatility_Multiple": 4.1,
            "Credit_Spread_Widening_bps": 320,
            "Liquidity_Haircut_Factor": 0.35
        },
        "2022_Global_Rate_Hike_Shock": {
            "Equity_Market_Shock": -0.18,
            "Volatility_Multiple": 1.6,
            "Credit_Spread_Widening_bps": 180,
            "Liquidity_Haircut_Factor": 0.75
        },
        "2024_Emerging_Market_Flight_to_Safety": {
            "Equity_Market_Shock": -0.12,
            "Volatility_Multiple": 1.8,
            "Credit_Spread_Widening_bps": 140,
            "Liquidity_Haircut_Factor": 0.80
        }
    }

    @classmethod
    def replay_historical_crisis_scenarios(
        cls,
        portfolio_weights: Dict[str, float],
        asset_betas: Dict[str, float],
        asset_vols: Dict[str, float]
    ) -> Dict[str, Any]:
        """
        Replays the current portfolio through BlackRock Aladdin historical macro crisis scenarios.
        Evaluates factor-driven drawdown, volatility expansion, and worst-case loss.
        """
        scenario_results = {}
        port_beta = sum(portfolio_weights.get(a, 0.0) * asset_betas.get(a, 1.0) for a in portfolio_weights)
        port_vol = sum(portfolio_weights.get(a, 0.0) * asset_vols.get(a, 0.20) for a in portfolio_weights)

        for sc_name, sc_params in cls.HISTORICAL_CRISIS_SCENARIOS.items():
            mkt_shock = sc_params["Equity_Market_Shock"]
            vol_mult = sc_params["Volatility_Multiple"]
            
            # Simulated portfolio loss
            sim_drawdown_pct = port_beta * mkt_shock * 100.0
            # Stressed annualized volatility
            stressed_vol_pct = port_vol * vol_mult * 100.0
            # Stressed 99% 1-day VaR
            stressed_var99_pct = 2.326 * (stressed_vol_pct / np.sqrt(252.0))

            scenario_results[sc_name] = {
                "Simulated_Drawdown_%": round(sim_drawdown_pct, 2),
                "Stressed_Volatility_%": round(stressed_vol_pct, 2),
                "Stressed_1D_VaR_99_%": round(stressed_var99_pct, 2),
                "Liquidity_Haircut": sc_params["Liquidity_Haircut_Factor"]
            }

        return {
            "portfolio_beta": round(port_beta, 2),
            "baseline_volatility_%": round(port_vol * 100.0, 2),
            "crisis_replay_scenarios": scenario_results
        }

    @classmethod
    def compute_liquidity_horizon_analysis(
        cls,
        portfolio_weights: Dict[str, float],
        portfolio_value_inr: float,
        daily_turnover_cr: Dict[str, float],
        max_participation_rate: float = 0.10,
        stressed_liquidity_haircut: float = 0.50
    ) -> Dict[str, Any]:
        """
        BlackRock Aladdin Days-to-Liquidate (DTL) Risk Model:
        DTL_i = (Position_Value_i) / (Max_Participation * Daily_Turnover_i)
        """
        asset_dtl = {}
        total_value = float(portfolio_value_inr)
        
        weighted_dtl_normal = 0.0
        weighted_dtl_stressed = 0.0

        for asset, w in portfolio_weights.items():
            pos_val_cr = (w * total_value) / 1e7
            adv_cr = max(daily_turnover_cr.get(asset, 1.0), 0.1)
            
            # Normal participation
            max_daily_flow_cr = adv_cr * max_participation_rate
            dtl_normal = pos_val_cr / max(max_daily_flow_cr, 1e-4)
            
            # Stressed liquidity participation
            stressed_flow_cr = max_daily_flow_cr * stressed_liquidity_haircut
            dtl_stressed = pos_val_cr / max(stressed_flow_cr, 1e-4)

            weighted_dtl_normal += w * dtl_normal
            weighted_dtl_stressed += w * dtl_stressed

            asset_dtl[asset] = {
                "Position_Value_₹Cr": round(pos_val_cr, 2),
                "ADV20_₹Cr": round(adv_cr, 2),
                "Normal_Days_to_Liquidate": round(dtl_normal, 2),
                "Stressed_Days_to_Liquidate": round(dtl_stressed, 2)
            }

        return {
            "portfolio_weighted_dtl_normal_days": round(weighted_dtl_normal, 2),
            "portfolio_weighted_dtl_stressed_days": round(weighted_dtl_stressed, 2),
            "liquidity_tier": "Highly Liquid (< 1 Day)" if weighted_dtl_normal <= 1.0 else ("Moderate (1-3 Days)" if weighted_dtl_normal <= 3.0 else "Illiquid (> 3 Days)"),
            "asset_liquidity_breakdown": asset_dtl
        }

    @classmethod
    def monte_carlo_copula_tail_simulation(
        cls,
        weights: np.ndarray,
        cov_matrix: np.ndarray,
        nu_degrees_of_freedom: float = 4.0,
        n_simulations: int = 10000
    ) -> Dict[str, float]:
        """
        10,000-Path Monte Carlo Student-t Copula Multi-Asset Tail Risk Simulation.
        Accurately captures fat tails and joint crash dependence.
        """
        w = np.asarray(weights, dtype=float)
        cov = np.asarray(cov_matrix, dtype=float)
        N = len(w)

        # Generate Student-t Copula returns
        # x ~ N(0, Cov), s ~ Chi2(nu), t = x * sqrt(nu / s)
        # ROUND 45 FIX: was np.random.seed(42) + global-state draws — this
        # reseeding ran on every crisis-replay call in the host process. Local
        # Generator keeps the deterministic intent without mutating global RNG.
        _rng = np.random.default_rng(42)
        norm_samples = _rng.multivariate_normal(np.zeros(N), cov, size=n_simulations)
        chi2_samples = _rng.chisquare(df=nu_degrees_of_freedom, size=(n_simulations, 1))
        
        t_copula_returns = norm_samples * np.sqrt(nu_degrees_of_freedom / chi2_samples)
        sim_port_returns = t_copula_returns @ w

        # Extract Tail Statistics
        var95 = float(-np.percentile(sim_port_returns, 5.0))
        var99 = float(-np.percentile(sim_port_returns, 1.0))
        cvar95 = float(-np.mean(sim_port_returns[sim_port_returns <= -var95]))
        cvar99 = float(-np.mean(sim_port_returns[sim_port_returns <= -var99]))
        worst_drawdown = float(-np.min(sim_port_returns))

        return {
            "copula_var_95_1d_%": round(var95 * 100.0, 2),
            "copula_cvar_95_1d_%": round(cvar95 * 100.0, 2),
            "copula_var_99_1d_%": round(var99 * 100.0, 2),
            "copula_cvar_99_1d_%": round(cvar99 * 100.0, 2),
            "copula_worst_tail_loss_%": round(worst_drawdown * 100.0, 2)
        }
