"""
math_engine/algo_execution.py
==============================
Algorithmic execution strategies (TWAP, VWAP, and Implementation Shortfall).
Divides large portfolio order weights into execution slices to minimize market impact.
"""
from __future__ import annotations

import logging
import numpy as np
from typing import Dict, List, Any, Optional

logger = logging.getLogger(__name__)


class AlgoExecutionManager:
    """Manages the state and slicing logic for a set of algorithmic orders."""

    def __init__(
        self,
        ticker: str,
        quantity: int,
        strategy: str,
        duration_mins: float,
        slices_count: int,
        decision_price: float,
        is_buy: bool = True,
        sigma_daily: Optional[float] = None,
        avg_daily_vol: Optional[float] = None,
        portfolio_gamma: Optional[float] = None
    ):
        # Normalize symbols to a consistent broker-friendly format.
        # (The rest of the app uses Zerodha Kite symbols, which are typically uppercase
        # and do NOT include Yahoo suffixes like ".NS".)
        self.ticker = str(ticker).strip().upper().replace(".NS", "").replace(".BO", "")
        self.total_qty = int(quantity)
        self.strategy = strategy.upper()
        self.duration_mins = float(duration_mins)
        self.slices_count = int(max(1, slices_count))
        self.decision_price = float(decision_price)
        self.is_buy = is_buy
        self.sigma_daily = sigma_daily
        self.avg_daily_vol = avg_daily_vol
        self.portfolio_gamma = portfolio_gamma
        
        self.remaining_qty = self.total_qty
        self.filled_qty = 0
        self.avg_fill_price = 0.0
        self.current_price = decision_price

        # Track state of each slice
        self.slices: List[Dict[str, Any]] = []
        self._initialize_slices()

    def _initialize_slices(self):
        """Pre-compute base slice quantities according to the chosen strategy."""
        if self.total_qty <= 0:
            return

        intervals = np.linspace(0, self.duration_mins, self.slices_count + 1)
        
        # 1. TWAP Slicing: Equal chunks
        if self.strategy == "TWAP" or self.slices_count == 1:
            base_qty = self.total_qty // self.slices_count
            qty_list = [base_qty] * self.slices_count
            qty_list[-1] += self.total_qty - sum(qty_list)  # Add remainder to last slice
            
        # 2. VWAP Slicing: Quadratic U-curve approximation
        elif self.strategy == "VWAP":
            # Normalized x from -1.0 to 1.0 representing opening to closing period of window
            xs = np.linspace(-1.0, 1.0, self.slices_count)
            # U-curve volume weights (higher at open/close, lower in middle)
            weights = xs**2 + 0.3
            norm_weights = weights / np.sum(weights)
            
            qty_list = []
            for w in norm_weights[:-1]:
                qty_list.append(int(round(self.total_qty * w)))
            qty_list.append(max(0, self.total_qty - sum(qty_list)))  # Remainder to last slice

        # 3. Almgren-Chriss Slicing: Hyperbolic optimal trajectory
        elif self.strategy == "ALMGREN-CHRISS" or self.strategy == "AC":
            # kappa represents trading speed/urgency parameter
            if self.sigma_daily is not None and self.avg_daily_vol is not None and self.portfolio_gamma is not None:
                calibrator = AlmgrenChrissCalibrator()
                kappa = calibrator.calibrate_kappa(
                    sigma_daily=self.sigma_daily,
                    avg_daily_vol=self.avg_daily_vol,
                    portfolio_gamma=self.portfolio_gamma
                )
                logger.info(f"Calibrated AC kappa for {self.ticker}: {kappa:.4f}")
            else:
                kappa = 0.4
                logger.info(f"Using default AC kappa for {self.ticker}: {kappa:.4f}")
                
            xs = np.zeros(self.slices_count + 1)
            xs[0] = self.total_qty
            denom = np.sinh(kappa * self.slices_count)
            if abs(denom) < 1e-9:
                denom = 1e-9
            for j in range(1, self.slices_count + 1):
                xs[j] = (np.sinh(kappa * (self.slices_count - j)) / denom) * self.total_qty
            
            qty_list = []
            for j in range(1, self.slices_count + 1):
                qty_list.append(int(round(xs[j-1] - xs[j])))
            
            # Correction for rounding differences
            diff = self.total_qty - sum(qty_list)
            if diff != 0:
                qty_list[-1] = max(0, qty_list[-1] + diff)

        # 4. Implementation Shortfall Slicing: Initialize as TWAP (will adapt dynamically)
        else:
            base_qty = self.total_qty // self.slices_count
            qty_list = [base_qty] * self.slices_count
            qty_list[-1] += self.total_qty - sum(qty_list)

        # Build schedule list
        for i in range(self.slices_count):
            self.slices.append({
                "slice_idx": i + 1,
                "target_qty": int(qty_list[i]),
                "filled_qty": 0,
                "avg_price": 0.0,
                "scheduled_time_offset": float(intervals[i]),
                "status": "PENDING"  # PENDING, ACTIVE, COMPLETED, FAILED
            })

    def update_market_price(self, price: float):
        """Update current market price and adapt Implementation Shortfall strategy if selected."""
        if price <= 0.0:
            return
        self.current_price = price

        # If IS, dynamically adjust sizes of remaining pending slices
        if self.strategy == "IMPLEMENTATION SHORTFALL" or self.strategy == "IS":
            self._adapt_is_slices()

    def _adapt_is_slices(self):
        """Implementation Shortfall adaptation logic.
        Accelerates execution if price shifts unfavorably (slippage rises),
        slows down if price shifts favorably.
        """
        if self.decision_price <= 0.0:
            return
        # Calculate price change relative to decision benchmark
        price_diff_pct = (self.current_price - self.decision_price) / self.decision_price

        # For BUY: price increase is unfavorable (drift > 0 -> accelerate)
        # For SELL: price decrease is unfavorable (drift < 0 -> accelerate)
        drift = price_diff_pct if self.is_buy else -price_diff_pct
        
        # Participation urgency multiplier: ranges from 0.5x to 2.0x
        urgency = float(np.clip(1.0 + 5.0 * drift, 0.5, 2.0))

        # Find remaining slices
        pending_slices = [s for s in self.slices if s["status"] == "PENDING"]
        if not pending_slices:
            return

        # Adapt target quantity for the next slice
        next_slice = pending_slices[0]
        
        # Calculate base target for remaining slices
        total_remaining = self.total_qty - self.filled_qty
        # L11-fix: when total_remaining is zero (or somehow negative) but pending slices still
        # exist, the original code would compute negative `rest_qty` and assign spurious
        # positive target quantities via `max(1, ...)`. Short-circuit by zeroing all pending
        # slices and returning early.
        if total_remaining <= 0:
            for s in pending_slices:
                s["target_qty"] = 0
            return
        if len(pending_slices) == 1:
            next_slice["target_qty"] = int(total_remaining)
        else:
            base_target = total_remaining // len(pending_slices)
            adjusted_target = int(max(1, min(total_remaining, round(base_target * urgency))))
            next_slice["target_qty"] = adjusted_target

            # Redivide the rest among remaining
            rest_qty = total_remaining - adjusted_target
            rest_slices = pending_slices[1:]
            if rest_slices:
                rest_base = rest_qty // len(rest_slices)
                for s in rest_slices[:-1]:
                    s["target_qty"] = int(rest_base)
                rest_slices[-1]["target_qty"] = max(0, int(rest_qty - sum(s["target_qty"] for s in rest_slices[:-1])))

    def execute_next_slice(self) -> Optional[Dict[str, Any]]:
        """Get the next slice to place in the market. Sets its status to ACTIVE."""
        pending_slices = [s for s in self.slices if s["status"] == "PENDING"]
        if not pending_slices:
            return None

        slice_to_run = pending_slices[0]
        slice_to_run["status"] = "ACTIVE"
        return slice_to_run

    def record_fill(self, slice_idx: int, filled_qty: int, price: float):
        """Record the filled transaction details for a given slice.

        AUDIT-FIX (Round 49 — R49-3): the argument contract is now explicit
        and the bookkeeping is consistent under PARTIAL fills:
        ``filled_qty`` is the CUMULATIVE number of shares filled for this
        slice so far, and ``price`` is the volume-weighted average fill price
        of that cumulative quantity. (Recording the FULL slice fill once —
        what the current production caller does — is the special case
        cumulative == target.)

        The previous implementation REPLACED the per-slice ``filled_qty`` but
        ADDED to the manager totals (``self.filled_qty += filled_qty``), so a
        second, larger cumulative update for the same slice double-counted
        the manager total, understated ``remaining_qty`` (which feeds the IS
        adapter's early-zero path), and corrupted the weighted
        ``avg_fill_price`` (its weight used the already-drifted total).
        Slice states are now the single source of truth: manager totals and
        the VWAP-style average are recomputed from the slice table after
        every update, which is exactly equivalent to the old arithmetic for
        the once-per-slice caller and correct for partial updates.
        """
        for s in self.slices:
            if s["slice_idx"] == slice_idx:
                s["filled_qty"] = int(filled_qty)
                s["avg_price"] = float(price)
                s["status"] = "COMPLETED" if filled_qty >= s["target_qty"] else "PARTIAL"

                # Manager-level state is DERIVED from the slice table — never
                # independently accumulated (R49-3: no drift is possible).
                self.filled_qty = sum(int(x["filled_qty"]) for x in self.slices)
                self.remaining_qty = max(0, self.total_qty - self.filled_qty)
                if self.filled_qty > 0:
                    _num = sum(float(x["avg_price"]) * int(x["filled_qty"])
                               for x in self.slices if int(x["filled_qty"]) > 0)
                    self.avg_fill_price = _num / self.filled_qty
                break


class AlmgrenChrissCalibrator:
    """
    Calibrate permanent and temporary market impact parameters
    from historical NSE intraday volume data.
    """
    NSE_PRIOR_ALPHA = 0.314   # Permanent impact (Almgren 2005 US equity estimate)
    NSE_PRIOR_ETA   = 0.142   # Temporary impact (higher for NSE due to lower liquidity)

    def calibrate_kappa(
        self,
        sigma_daily: float,    # GARCH conditional volatility
        avg_daily_vol: float,  # Average daily volume in shares
        portfolio_gamma: float,# Risk aversion from DRO optimizer
        trade_horizon_days: int = 1,
        default_eta: float = None
    ) -> float:
        """Compute empirically grounded kappa for a specific stock."""
        # L12-fix: use an explicit `is None` check instead of `eta or self.NSE_PRIOR_ETA`.
        # The old form treated eta=0.0 (legitimately zero temporary impact) as falsy and
        # silently substituted the prior, masking real calibration inputs.
        if default_eta is None:
            default_eta = self.NSE_PRIOR_ETA
        if sigma_daily <= 0 or portfolio_gamma <= 0 or default_eta <= 0:
            return 0.4
        kappa = np.sqrt(portfolio_gamma * (sigma_daily ** 2) / default_eta)
        kappa_scaled = kappa * np.sqrt(trade_horizon_days)
        return float(np.clip(kappa_scaled, 0.1, 2.0))


class AlmgrenChrissTrajectoryScheduler:
    """Computes the entire optimal trading trajectory schedule using Almgren-Chriss framework."""

    def __init__(self, calibrator: Optional[AlmgrenChrissCalibrator] = None):
        self.calibrator = calibrator or AlmgrenChrissCalibrator()

    def generate_optimal_schedule(
        self,
        total_qty: int,
        duration_mins: float,
        slices_count: int,
        sigma_daily: float,
        avg_daily_vol: float,
        portfolio_gamma: float,
        default_eta: Optional[float] = None
    ) -> List[Dict[str, Any]]:
        """Calculate optimal trading schedule sizes and time offsets."""
        kappa = self.calibrator.calibrate_kappa(
            sigma_daily=sigma_daily,
            avg_daily_vol=avg_daily_vol,
            portfolio_gamma=portfolio_gamma,
            default_eta=default_eta
        )
        
        N = slices_count
        xs = np.zeros(N + 1)
        xs[0] = total_qty
        denom = np.sinh(kappa * N)
        if abs(denom) < 1e-9:
            denom = 1e-9
            
        for j in range(1, N + 1):
            xs[j] = (np.sinh(kappa * (N - j)) / denom) * total_qty
            
        qty_list = []
        for j in range(1, N + 1):
            qty_list.append(int(round(xs[j-1] - xs[j])))
            
        # Correct for rounding differences
        diff = total_qty - sum(qty_list)
        if diff != 0:
            qty_list[-1] = max(0, qty_list[-1] + diff)
            
        # Build schedule details
        schedule = []
        intervals = np.linspace(0, duration_mins, N + 1)
        for i in range(N):
            schedule.append({
                "slice_idx": i + 1,
                "target_qty": int(qty_list[i]),
                "time_offset_mins": float(intervals[i]),
                "expected_fraction": float(qty_list[i] / total_qty) if total_qty > 0 else 0.0
            })
            
        return schedule

