"""Alternative asset classes — commodities, FX, bonds, crypto.

Extends the platform beyond Indian equities to enable multi-asset portfolios:
  1. Commodities: Gold, Silver, Crude Oil (MCX)
  2. Currencies: USD/INR, EUR/INR, GBP/INR
  3. Bonds: G-Sec yield curve, corporate bonds
  4. Crypto: BTC, ETH (if regulatory allows)

Each asset class has its own data fetcher and risk characteristics.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Optional, Dict, List
import logging

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════════════
# ASSET CLASS DEFINITIONS
# ═══════════════════════════════════════════════════════════════════════════════

COMMODITIES = {
    "GOLD":      {"symbol": "GC=F",     "exchange": "COMEX",    "currency": "USD"},
    "GOLD_MCX":  {"symbol": "GOLDM.NS", "exchange": "MCX",      "currency": "INR"},
    "SILVER":    {"symbol": "SI=F",     "exchange": "COMEX",    "currency": "USD"},
    "SILVER_MCX":{"symbol": "SILVER.NS","exchange": "MCX",      "currency": "INR"},
    "CRUDE":     {"symbol": "CL=F",     "exchange": "NYMEX",    "currency": "USD"},
    "CRUDE_MCX": {"symbol": "CRUDE.NS", "exchange": "MCX",      "currency": "INR"},
    "COPPER":    {"symbol": "HG=F",     "exchange": "COMEX",    "currency": "USD"},
    "NATGAS":    {"symbol": "NG=F",     "exchange": "NYMEX",    "currency": "USD"},
}

CURRENCIES = {
    "USDINR": {"symbol": "USDINR=X", "base": "USD", "quote": "INR"},
    "EURINR": {"symbol": "EURINR=X", "base": "EUR", "quote": "INR"},
    "GBPINR": {"symbol": "GBPINR=X", "base": "GBP", "quote": "INR"},
    "JPYINR": {"symbol": "JPYINR=X", "base": "JPY", "quote": "INR"},
    "DXY":    {"symbol": "DX-Y.NYB", "base": "USD", "quote": "INDEX"},
}

BONDS = {
    "IN_10Y":  {"symbol": "IN10YT=RR", "country": "India",  "maturity": "10Y"},
    "IN_2Y":   {"symbol": "IN2YT=RR",  "country": "India",  "maturity": "2Y"},
    "US_10Y":  {"symbol": "^TNX",      "country": "US",     "maturity": "10Y"},
    "US_2Y":   {"symbol": "^IRX",      "country": "US",     "maturity": "3M"},
}

CRYPTO = {
    "BTC":  {"symbol": "BTC-USD", "exchange": "Coinbase"},
    "ETH":  {"symbol": "ETH-USD", "exchange": "Coinbase"},
}


def fetch_alternative_asset(
    asset_class: str,
    symbol: str,
    period: str = "1y",
) -> Optional[pd.DataFrame]:
    """Fetch price data for an alternative asset.

    Args:
        asset_class: "commodity", "currency", "bond", or "crypto".
        symbol: Asset symbol (e.g., "GOLD", "USDINR", "IN_10Y", "BTC").
        period: Lookback period.

    Returns:
        DataFrame with OHLCV data, or None if fetch fails.
    """
    asset_map = {
        "commodity": COMMODITIES,
        "currency": CURRENCIES,
        "bond": BONDS,
        "crypto": CRYPTO,
    }

    mapping = asset_map.get(asset_class.lower(), {})
    asset_info = mapping.get(symbol.upper())

    if not asset_info:
        logger.warning(f"Unknown {asset_class}: {symbol}")
        return None

    try:
        from data.price_feed import safe_download
        data = safe_download([asset_info["symbol"]], period=period)
        if data is not None and not data.empty:
            return data
    except Exception as e:
        logger.warning(f"Failed to fetch {symbol}: {e}", exc_info=True)

    return None


# ═══════════════════════════════════════════════════════════════════════════════
# MULTI-ASSET PORTFOLIO
# ═══════════════════════════════════════════════════════════════════════════════

class MultiAssetPortfolio:
    """Multi-asset portfolio spanning equities, commodities, FX, bonds.

    Enables true institutional diversification across asset classes
    with different risk/return characteristics.
    """

    def __init__(self):
        self.assets: Dict[str, dict] = {}

    def add_equity(self, ticker: str, weight: float = 0.0):
        """Add an equity position."""
        self.assets[ticker] = {"class": "equity", "weight": weight}

    def add_commodity(self, symbol: str, weight: float = 0.0):
        """Add a commodity position."""
        self.assets[symbol] = {"class": "commodity", "weight": weight}

    def add_currency(self, symbol: str, weight: float = 0.0):
        """Add a currency position."""
        self.assets[symbol] = {"class": "currency", "weight": weight}

    def add_bond(self, symbol: str, weight: float = 0.0):
        """Add a bond position."""
        self.assets[symbol] = {"class": "bond", "weight": weight}

    def get_correlation_matrix(self, returns: pd.DataFrame) -> pd.DataFrame:
        """Compute cross-asset correlation matrix.

        Low correlation between asset classes is the whole point of
        multi-asset diversification.
        """
        return returns.corr()

    def optimize_allocation(
        self,
        returns: pd.DataFrame,
        target_vol: float = 0.15,
        max_weight_per_asset: float = 0.30,
        max_weight_per_class: float = 0.60,
    ) -> dict:
        """Optimize multi-asset allocation.

        Args:
            returns: DataFrame of asset returns.
            target_vol: Target portfolio volatility.
            max_weight_per_asset: Max weight per individual asset.
            max_weight_per_class: Max weight per asset class.

        Returns:
            Dict with optimal weights and metrics.
        """
        from scipy.optimize import minimize

        n = len(returns.columns)
        mean_returns = returns.mean().values
        cov = returns.cov().values

        # Asset class mapping for constraints
        asset_classes = []
        for col in returns.columns:
            if col in self.assets:
                asset_classes.append(self.assets[col]["class"])
            else:
                asset_classes.append("equity")

        def portfolio_vol(w):
            # AUDIT-FIX (Round 6, A1-P3-9): annualize to match target_vol's
            # scale. The previous daily-scale equality constraint against an
            # ANNUAL target (0.15) was infeasible for daily cov (max reachable
            # ≈ 0.0067) — SLSQP failed on every input and silently returned
            # the equal-weight start point.
            return np.sqrt(w @ cov @ w) * np.sqrt(252.0)

        # Constraints: sum to 1, target vol, class limits
        constraints = [
            {"type": "eq", "fun": lambda w: np.sum(w) - 1.0},
            {"type": "eq", "fun": lambda w: portfolio_vol(w) - target_vol},
        ]

        # Class weight constraints
        for cls in set(asset_classes):
            indices = [i for i, c in enumerate(asset_classes) if c == cls]
            constraints.append({
                "type": "ineq",
                "fun": lambda w, idx=indices: max_weight_per_class - np.sum(w[idx])
            })

        bounds = [(0, max_weight_per_asset)] * n
        x0 = np.ones(n) / n

        result = minimize(
            lambda w: -np.dot(w, mean_returns),  # maximize return
            x0, method="SLSQP",
            bounds=bounds, constraints=constraints,
            options={"maxiter": 500, "ftol": 1e-8}
        )

        if result.success:
            weights = result.x
        else:
            weights = x0

        # Compute metrics
        port_return = np.dot(weights, mean_returns) * 252
        port_vol = np.sqrt(weights @ cov @ weights) * np.sqrt(252)
        sharpe = port_return / port_vol if port_vol > 0 else 0

        return {
            "weights": dict(zip(returns.columns, weights)),
            "expected_return": port_return,
            "expected_volatility": port_vol,
            "sharpe_ratio": sharpe,
            "asset_class_weights": {
                cls: sum(weights[i] for i, c in enumerate(asset_classes) if c == cls)
                for cls in set(asset_classes)
            },
        }
