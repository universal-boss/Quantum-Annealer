"""
math_engine/aum_capacity.py
===========================
AUM Capacity & Market Impact Ceiling Calculator.

Calculates AUM_max = min_i (0.02 * ADV20_i / w_i) to prevent over-capitalizing
profiles beyond liquidity limits.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)


class AUMCapacityCalculator:
    """
    Computes Maximum Deployable AUM Capacity Ceiling per profile based on ADV20 liquidity limits.
    """

    @staticmethod
    def calculate_max_aum(weights: Dict[str, float], signal_df: pd.DataFrame, max_adv_pct: float = 0.02) -> Dict[str, Any]:
        """
        Calculates maximum deployable capital before market impact erodes alpha edge.
        """
        if not weights or signal_df is None or signal_df.empty:
            return {"max_deployable_aum_inr": 100_000_000.0, "constraining_ticker": "N/A", "is_capacity_exceeded": False}

        min_aum = float("inf")
        constraining_ticker = "N/A"

        for ticker, weight in weights.items():
            if ticker.upper() == "CASH" or weight <= 0.001:
                continue

            adv = 1e7
            if ticker in signal_df.index and "adv20" in signal_df.columns:
                val = signal_df.loc[ticker, "adv20"]
                if pd.notna(val) and float(val) > 0:
                    adv = float(val)

            # Max capital for this ticker: (max_adv_pct * ADV20) / weight
            max_stock_aum = (max_adv_pct * adv) / weight
            if max_stock_aum < min_aum:
                min_aum = max_stock_aum
                constraining_ticker = ticker

        if min_aum == float("inf"):
            min_aum = 100_000_000.0

        return {
            "max_deployable_aum_inr": round(float(min_aum), 2),
            "constraining_ticker": constraining_ticker,
            "max_adv_participation_pct": max_adv_pct * 100.0
        }
