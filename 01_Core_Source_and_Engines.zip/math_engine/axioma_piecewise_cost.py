"""
math_engine/axioma_piecewise_cost.py
====================================
Axioma 3-Tier Piecewise Non-Linear Transaction Cost Model.

Accurately models transaction frictions to prevent unnecessary portfolio turnover:
1. Tier 1: Fixed Exchange / Brokerage / STT Fee (e.g. 0.10% STT in India).
2. Tier 2: Bid-Ask Half-Spread Cost: 0.5 * Spread_i * |Delta w_i|.
3. Tier 3: Non-Linear Square-Root Market Impact Cost:
   Impact = gamma * sigma_i * (Trade_Value / ADV_i)^0.5
"""
from __future__ import annotations

import logging
from typing import Dict, List, Optional, Union
import numpy as np

logger = logging.getLogger(__name__)


class AxiomaPiecewiseCostModel:
    """Axioma 3-tier piecewise non-linear transaction cost and friction calculator."""

    DEFAULT_STT_RATE = 0.0010  # 0.10% Indian STT on delivery
    DEFAULT_BROKER_SLIP = 0.0005  # 5 bps brokerage/exchange fee
    DEFAULT_IMPACT_GAMMA = 0.142  # Almgren-Chriss / Kissell impact constant

    @classmethod
    def compute_total_turnover_friction(
        cls,
        target_weights: np.ndarray,
        current_weights: np.ndarray,
        portfolio_value_inr: float,
        daily_turnover_cr: np.ndarray,
        daily_volatilities: np.ndarray,
        effective_spreads: Optional[np.ndarray] = None,
        stt_rate: float = DEFAULT_STT_RATE,
        broker_fee: float = DEFAULT_BROKER_SLIP
    ) -> Dict[str, float]:
        """
        Calculates total 3-tier piecewise transaction cost for moving from current to target weights.
        """
        w_target = np.asarray(target_weights, dtype=float)
        w_current = np.asarray(current_weights, dtype=float)
        delta_w = np.abs(w_target - w_current)
        total_turnover = float(np.sum(delta_w))

        vols = np.asarray(daily_volatilities, dtype=float)
        adv_inr = np.maximum(np.asarray(daily_turnover_cr, dtype=float) * 1e7, 1e5)
        spreads = np.asarray(effective_spreads, dtype=float) if effective_spreads is not None else vols * 0.10

        # Tier 1: Fixed Taxes & Fees (STT + Exchange Turnover)
        tier1_fixed_cost = (stt_rate + broker_fee) * total_turnover * portfolio_value_inr

        # Tier 2: Bid-Ask Half-Spread
        tier2_spread_cost = float(np.sum(0.5 * spreads * delta_w * portfolio_value_inr))

        # Tier 3: Non-Linear Power-Law Market Impact
        trade_values = delta_w * portfolio_value_inr
        participation_rates = np.clip(trade_values / adv_inr, 0.0, 0.50)
        tier3_impact_cost = float(np.sum(cls.DEFAULT_IMPACT_GAMMA * vols * np.sqrt(participation_rates) * trade_values))

        total_cost_inr = tier1_fixed_cost + tier2_spread_cost + tier3_impact_cost
        cost_drag_bps = (total_cost_inr / max(portfolio_value_inr, 1.0)) * 10000.0

        return {
            "total_turnover_%": round(total_turnover * 100.0, 2),
            "tier1_fixed_stt_inr": round(tier1_fixed_cost, 2),
            "tier2_spread_cost_inr": round(tier2_spread_cost, 2),
            "tier3_impact_cost_inr": round(tier3_impact_cost, 2),
            "total_transaction_friction_inr": round(total_cost_inr, 2),
            "cost_drag_bps": round(cost_drag_bps, 1)
        }
