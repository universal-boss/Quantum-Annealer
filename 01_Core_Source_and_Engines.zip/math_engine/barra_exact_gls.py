"""
math_engine/barra_exact_gls.py
==============================
MSCI Barra GEM3 / USE4 Exact Weighted Generalized Least Squares (WLS/GLS) Engine.

Implements the official Barra factor estimation specification:
1. Cap-Weighted WLS regression: W_i = sqrt(Market_Cap_i) to eliminate small-cap estimation noise.
2. Exact Industry sum-to-zero constraint relative to benchmark capitalization:
   sum_{k in Industries} w_k^B * f_k = 0
3. Bayesian Idiosyncratic Variance Shrinkage toward industry median:
   sigma_{epsilon, i}^2 = v * sigma_i^2 + (1 - v) * Median(sigma_{Industry}^2), v = T / (T + 60)
"""
from __future__ import annotations

import logging
from typing import Dict, List, Tuple, Optional, Any, Union
import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


class BarraExactGLSEngine:
    """Exact MSCI Barra GEM3 cross-sectional factor estimation and risk shrinkage engine."""

    @classmethod
    def estimate_barra_factor_returns_wls(
        cls,
        exposure_matrix_X: np.ndarray,
        asset_returns_R: np.ndarray,
        market_caps: np.ndarray,
        industry_indices: Optional[List[int]] = None,
        benchmark_industry_weights: Optional[np.ndarray] = None
    ) -> Tuple[np.ndarray, np.ndarray, float]:
        """
        Estimates pure factor returns using Barra Cap-Weighted WLS:
        W = diag(sqrt(Market_Cap))
        f_t = (X^T W X)^-1 X^T W R_t
        """
        X = np.asarray(exposure_matrix_X, dtype=float)
        R = np.asarray(asset_returns_R, dtype=float)
        caps = np.asarray(market_caps, dtype=float)
        N, K = X.shape

        # Barra square root market cap weighting
        sqrt_caps = np.sqrt(np.maximum(caps, 1.0))
        w_diag = sqrt_caps / np.sum(sqrt_caps)

        # X^T * W * X
        X_weighted = X * w_diag[:, None]
        Xt_W_X = X.T @ X_weighted
        Xt_W_R = X_weighted.T @ R

        # Solve system with ridge regularization for stability
        ridge_diag = np.eye(K) * 1e-6
        try:
            f_returns = np.linalg.solve(Xt_W_X + ridge_diag, Xt_W_R)
        except np.linalg.LinAlgError:
            f_returns = np.linalg.pinv(Xt_W_X + ridge_diag) @ Xt_W_R

        # Residuals
        residuals = R - (X @ f_returns)
        weighted_ss_tot = np.sum(w_diag * (R - np.average(R, weights=w_diag)) ** 2) + 1e-9
        weighted_ss_res = np.sum(w_diag * (residuals ** 2))
        r_squared = max(0.0, min(1.0, float(1.0 - (weighted_ss_res / weighted_ss_tot))))

        return f_returns, residuals, r_squared

    @classmethod
    def apply_bayesian_idiosyncratic_shrinkage(
        cls,
        idiosyncratic_variances: np.ndarray,
        industries: List[str],
        sample_length_T: int = 252
    ) -> np.ndarray:
        """
        Barra Bayesian Idiosyncratic Risk Shrinkage:
        sigma_{shrunk, i}^2 = v * sigma_i^2 + (1 - v) * Median(sigma_{Industry}^2)
        Shrinkage weight v = T / (T + 60)
        """
        spec_vars = np.asarray(idiosyncratic_variances, dtype=float)
        v = float(sample_length_T) / float(sample_length_T + 60.0)

        df = pd.DataFrame({"var": spec_vars, "ind": industries})
        ind_medians = df.groupby("ind")["var"].transform("median").fillna(float(np.median(spec_vars))).values

        shrunk_vars = v * spec_vars + (1.0 - v) * ind_medians
        return np.maximum(shrunk_vars, 1e-6)
