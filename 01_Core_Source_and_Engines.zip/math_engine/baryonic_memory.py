"""
math_engine/baryonic_memory.py
===============================
Backward-compatibility alias. The canonical module is now:
`math_engine.ring_buffer`.
"""
from __future__ import annotations

from math_engine.ring_buffer import (
    RingBufferMemoryRegister,
    CircularMemoryRegister,
    RingBuffer,
)

BaryonicMemoryRegister = RingBufferMemoryRegister
BaryonicMemoryBuffer = RingBufferMemoryRegister

__all__ = [
    "RingBufferMemoryRegister",
    "CircularMemoryRegister",
    "RingBuffer",
    "BaryonicMemoryRegister",
    "BaryonicMemoryBuffer",
]
