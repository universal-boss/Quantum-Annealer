"""
math_engine/black_litterman.py
================================
Black-Litterman robust asset return estimator.
Blends equilibrium market priors with ML-driven investor views.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Any
from data.price_feed import safe_download

logger = logging.getLogger(__name__)


class BlackLittermanEstimator:
    """Calculates the Black-Litterman posterior expected return vector (mu_BL) by combining:
      1. Equilibrium market prior returns (derived from market capitalization weights)
      2. ML/Retrieval-driven views (derived from neural calibrated breakout probabilities)
    """

    def __init__(
        self,
        risk_aversion: float = 2.5,
        prior_weight_tau: float = 0.05,  # Phase 6.6: was 1.0 (wrong — standard BL uses 0.025-0.3)
        default_target_premium: float = 0.08,
    ) -> None:
        self.risk_aversion = risk_aversion
        # Phase 6.6: Fixed tau default.
        # Standard Black-Litterman uses τ ∈ [0.025, 0.3] to scale the prior covariance.
        # With τ=1.0, tau*Sigma = Sigma (prior precision too weak), and Omega is
        # inflated by 1/τ relative to standard calibration. Views are weighted far
        # more heavily than in canonical BL, producing posterior returns that swing
        # violently with view confidence.
        self.tau = prior_weight_tau
        self.target_premium = default_target_premium

    def estimate_posterior_returns(
        self,
        returns: pd.DataFrame,
        signal_df: pd.DataFrame,
        cfg: Optional[dict] = None,
    ) -> pd.Series:
        """Computes the Black-Litterman expected return vector for all tickers in signal_df.

        Falls back to raw alpha score if estimation fails.
        """
        tickers = list(signal_df.index)
        if not tickers:
            return pd.Series(dtype=np.float32)

        # Extract regime information from config
        regime = "Bull"
        if cfg and "_REGIME_INFO" in cfg:
            regime = cfg["_REGIME_INFO"].get("label", "Bull")

        # ── Dynamic Risk-Free Rate & Market Yield Integration ──
        rf_rate = 0.071  # Default fallback yield (7.10%)
        try:
            # Fetch India 10-Year Bond yield
            rf_data = safe_download(["IN10YT=RR"], period="5d")
            if not rf_data.empty:
                if isinstance(rf_data.columns, pd.MultiIndex):
                    close_col = rf_data[("Close", "IN10YT=RR")]
                else:
                    close_col = rf_data["Close"]
                val = float(close_col.dropna().iloc[-1])
                if 2.0 < val < 15.0:  # Sanity check range
                    rf_rate = val / 100.0
                    logger.info("[BlackLitterman] Live India 10Y Bond Yield: %.2f%%", val)
                else:
                    rf_rate = 0.065
            else:
                rf_rate = 0.065
        except Exception:
            rf_rate = 0.065  # RBI repo rate fallback — never silently use 0

        # Calibrate benchmark index returns (Nifty 50 proxy "^NSEI") over the last 1 year
        market_return = 0.14
        market_var = 0.0225  # 15% volatility squared
        try:
            nifty_data = safe_download(["^NSEI"], period="1y")

            if not nifty_data.empty:
                if isinstance(nifty_data.columns, pd.MultiIndex):
                    close_col = nifty_data[("Close", "^NSEI")]
                else:
                    close_col = nifty_data["Close"]
                close_col = close_col.dropna()
                nifty_rets = np.log(close_col / close_col.shift(1)).dropna()
                m_ret = nifty_rets.mean()
                m_var = nifty_rets.var()
                market_return = float(m_ret) * 252.0
                market_var = float(m_var) * 252.0
                logger.info("[BlackLitterman] Calibrated Nifty 50 returns: %.2f%%, Vol: %.2f%%", 
                            market_return * 100, np.sqrt(market_var) * 100)
        except Exception as e:
            logger.warning("[BlackLitterman] Failed to fetch benchmark index: %s. Using default Nifty metrics.", e, exc_info=True)

        # ── US Spillover & Global Risk Shock Integration ──
        us_spillover_return = 0.0
        vix_level = 15.0
        try:
            # Download US S&P 500 and VIX to capture global spillover shocks
            us_data = safe_download(["^GSPC", "^VIX"], period="5d")

            if not us_data.empty:
                if isinstance(us_data.columns, pd.MultiIndex):
                    close_col = us_data["Close"]
                else:
                    close_col = us_data
                if isinstance(close_col, pd.DataFrame):
                    if "^GSPC" in close_col.columns and "^VIX" in close_col.columns:
                        sp_close = close_col["^GSPC"].dropna()
                        vix_close = close_col["^VIX"].dropna()
                        if len(sp_close) >= 2:
                            us_spillover_return = float(np.log(sp_close.iloc[-1] / sp_close.iloc[-2]))
                        if len(vix_close) >= 1:
                            vix_level = float(vix_close.iloc[-1])
                        logger.info("[BlackLitterman] Live US S&P 500 1D Ret: %.2f%%, VIX: %.1f",
                                    us_spillover_return * 100.0, vix_level)
        except Exception as e:
            logger.warning("[BlackLitterman] Failed to fetch US spillover metrics: %s", e, exc_info=True)

        # Compute dynamic parameters
        dynamic_premium = max(0.04, min(0.12, market_return - rf_rate))
        if market_var > 1e-4:
            dynamic_lambda = max(1.5, min(4.0, dynamic_premium / market_var))
        else:
            dynamic_lambda = 2.5

        # Adjust parameters if a US market crash or global VIX spike occurs
        if us_spillover_return < -0.015:  # S&P 500 dropped > 1.5%
            dynamic_lambda = min(5.0, dynamic_lambda * 1.35)  # Spike risk aversion
            dynamic_premium = max(0.03, dynamic_premium * 0.8)  # Compress equity premium
            logger.info("[BlackLitterman] US Crash detected! Scaling parameters: Lambda=%.2f, Premium=%.2f%%",
                        dynamic_lambda, dynamic_premium * 100.0)

        if vix_level > 25.0:  # Elevated fear index
            dynamic_lambda = min(5.5, dynamic_lambda * 1.2)
            dynamic_premium = max(0.03, dynamic_premium * 0.9)
            logger.info("[BlackLitterman] High VIX fear (%.1f). Lambda adjusted: %.2f", vix_level, dynamic_lambda)
            
        logger.info("[BlackLitterman] Calibrated: Risk Aversion (Lambda) = %.2f, Target Premium = %.2f%% (Rf = %.2f%%)", 
                    dynamic_lambda, dynamic_premium * 100, rf_rate * 100)

        # Apply parameters
        self.risk_aversion = dynamic_lambda
        self.target_premium = dynamic_premium

        # 1. Compute Covariance Matrix (Sigma) — ANNUALIZED for BL formula consistency
        # FIX: Sigma must be annualized so Pi, Q (views), and tau*Sigma are all
        # in the same annual return scale. The old code left Sigma in daily scale
        # but expressed views Q in annual scale — a 252× unit mismatch.
        clean_rets = returns[tickers].fillna(0.0).to_numpy(dtype=np.float32)
        Sigma = np.cov(clean_rets, rowvar=False) * 252.0  # Annualized covariance
        if Sigma.ndim == 0:
            Sigma = Sigma.reshape(1, 1)

        # Ensure positive-definite covariance matrix
        # L5-fix: Sigma is symmetric → use np.linalg.eigvalsh (symmetric solver, returns real
        # eigenvalues) instead of np.linalg.eigvals (general solver, returns complex). The old
        # call returned complex eigenvalues, and np.min on a complex array raised / produced
        # inconsistent ordering; eigvalsh avoids the whole class of issues.
        min_eig = float(np.min(np.linalg.eigvalsh(Sigma)))
        if min_eig < 1e-6:
            Sigma += np.eye(len(tickers), dtype=np.float32) * (1e-6 - min_eig)

        # Apply Tail Copula Coupling under Bear stress regimes
        Sigma = self.apply_tail_copula_coupling(Sigma, regime)

        # Calculate annualized volatility of each asset to scale view target expected returns
        ann_vols = np.sqrt(np.diag(Sigma))  # Already annualized

        # 2. Compute Equilibrium Market Weights (w_eq) using true Market Capitalization if available
        mcap_col = None
        for col in ["marketCap", "mktcap", "mktcap_cr", "MktCap (Cr)"]:
            if col in signal_df.columns:
                mcap_col = col
                break
                
        if mcap_col is not None:
            mcap = pd.to_numeric(signal_df[mcap_col], errors="coerce").fillna(100.0).to_numpy(dtype=np.float32)
            # Ensure mcap is positive
            mcap = np.clip(mcap, 1.0, None)
            w_eq = mcap / (mcap.sum() + 1e-9)
            logger.info("[BlackLitterman] Derived equilibrium weights w_eq using true Market Capitalization (%s)", mcap_col)
        else:
            # L7-fix: KeyError-safe fallback. Previously assumed signal_df had an `adv20` column;
            # Phase 6.7: ADV is a LIQUIDITY proxy, NOT a market-cap proxy. The BL equilibrium
            # prior Pi = lambda * Sigma * w_eq is only valid when w_eq are true market-cap weights.
            # Using ADV weights produces a "liquidity-weighted" prior that has no theoretical
            # grounding and can be dominated by a single high-volume mid-cap name.
            # Now: fall back to EQUAL weights with a warning (mathematically neutral).
            n_assets = len(signal_df.index)
            w_eq = np.ones(n_assets, dtype=np.float32) / n_assets
            logger.warning(
                "[BlackLitterman] Phase 6.7: Market Cap columns not found. "
                "Using EQUAL-WEIGHT prior (was ADV20 — a liquidity proxy, not market-cap). "
                "BL prior is mathematically neutral; views will drive the posterior."
            )

        # 3. Calculate Prior Equilibrium Returns: Pi = lambda * Sigma * w_eq (annual scale)
        Pi = self.risk_aversion * (Sigma @ w_eq)

        # 4. Construct ML-driven views (P, Q, and Omega matrices)
        # Determine regime-aware view selectivity hurdle rate to maximize success rate
        # Stricter hurdles in bear/sideways regimes to filter out noise
        if regime == "Bear":
            bull_hurdle = 0.75
            bear_hurdle = 0.60
        elif regime == "Sideways":
            bull_hurdle = 0.70
            bear_hurdle = 0.65
        else:  # Bull
            bull_hurdle = 0.60
            bear_hurdle = 0.70

        views_P: List[np.ndarray] = []
        views_Q: List[float] = []
        views_conf: List[float] = []

        for idx, t in enumerate(tickers):
            calib_prob = float(signal_df.loc[t, "chart_calibrated_prob"]) if "chart_calibrated_prob" in signal_df.columns and pd.notna(signal_df.loc[t, "chart_calibrated_prob"]) else 0.0
            failed_risk = float(signal_df.loc[t, "chart_failed_breakout_risk"]) if "chart_failed_breakout_risk" in signal_df.columns and pd.notna(signal_df.loc[t, "chart_failed_breakout_risk"]) else 0.0

            # Absolute Bullish view (exceeds dynamic regime-aware hurdle)
            if calib_prob > bull_hurdle:
                p_row = np.zeros(len(tickers), dtype=np.float32)
                p_row[idx] = 1.0
                views_P.append(p_row)
                
                # FIX H3: Expected return scales with calibrated probability and target premium (drop asset_vol multiplier)
                expected_ret = calib_prob * self.target_premium
                views_Q.append(expected_ret)
                views_conf.append(calib_prob)

            # Absolute Bearish view (exceeds dynamic regime-aware hurdle)
            elif failed_risk > bear_hurdle:
                p_row = np.zeros(len(tickers), dtype=np.float32)
                p_row[idx] = 1.0
                views_P.append(p_row)
                
                # FIX H3: Expected negative return scales with risk and target premium (drop asset_vol multiplier)
                expected_ret = -failed_risk * self.target_premium * 1.5
                views_Q.append(expected_ret)
                # Confidence is matching strength
                views_conf.append(failed_risk)

            # Dynamic global US crash / VIX spillover shock view fallback
            elif (us_spillover_return < -0.015) or (vix_level > 25.0):
                beta_val = float(signal_df.loc[t, "beta"]) if "beta" in signal_df.columns and pd.notna(signal_df.loc[t, "beta"]) else 1.0
                if beta_val > 1.1:
                    p_row = np.zeros(len(tickers), dtype=np.float32)
                    p_row[idx] = 1.0
                    views_P.append(p_row)
                    
                    asset_vol = float(ann_vols[idx])
                    shock_mult = 1.5 if us_spillover_return < -0.015 else 1.0
                    expected_ret = -shock_mult * self.target_premium * beta_val * asset_vol
                    views_Q.append(expected_ret)
                    views_conf.append(0.80)

        # If no views were formulated, return Pi directly
        if not views_P:
            return pd.Series(Pi, index=tickers, dtype=np.float32)

        # Convert view containers to numpy matrices
        P = np.array(views_P, dtype=np.float32)  # (K, N)
        Q = np.array(views_Q, dtype=np.float32)  # (K,)
        
        # Build Omega (uncertainty of views)
        # Omega = diag(P * (tau * Sigma) * P^T) * ((1 - confidence) / confidence)
        K = len(views_P)
        Omega = np.zeros((K, K), dtype=np.float32)
        
        # Scale view uncertainty dynamically based on GARCH market regime (Phase 5)
        uncertainty_scalar = 1.0
        if regime == "Bear":
            uncertainty_scalar = 2.0
        elif regime == "Bull":
            uncertainty_scalar = 0.5

        for i in range(K):
            p_i = P[i]
            conf = min(max(views_conf[i], 0.01), 0.99)
            variance_prior = float(p_i @ (self.tau * Sigma) @ p_i)
            # Scaling factor: lower confidence = higher uncertainty (variance)
            uncertainty = variance_prior * ((1.0 - conf) / conf) * uncertainty_scalar
            Omega[i, i] = max(uncertainty, 1e-8)

        # 5. Compute Black-Litterman formula:
        # mu_BL = [ (tau * Sigma)^-1 + P^T * Omega^-1 * P ]^-1 * [ (tau * Sigma)^-1 * Pi + P^T * Omega^-1 * Q ]
        try:
            tau_Sigma_inv = np.linalg.pinv(self.tau * Sigma)
            Omega_inv = np.linalg.pinv(Omega)

            middle_inv = np.linalg.pinv(tau_Sigma_inv + P.T @ Omega_inv @ P)
            rhs = tau_Sigma_inv @ Pi + P.T @ Omega_inv @ Q
            mu_BL = middle_inv @ rhs
        except Exception as e:
            logger.warning("[BlackLitterman] Linear algebra solver failed: %s. Reverting to prior Pi.", e, exc_info=True)
            mu_BL = Pi

        return pd.Series(mu_BL, index=tickers, dtype=np.float32)

    def apply_tail_copula_coupling(
        self,
        Sigma: np.ndarray,
        regime: str,
        nu: float = 4.0,
        alpha_base: float = 0.40
    ) -> np.ndarray:
        """Applies bivariate Student-t copula tail coupling to covariance matrix during Bear stress regimes."""
        if regime != "Bear":
            return Sigma
            
        n = Sigma.shape[0]
        # Decompose Sigma = D * R * D
        vols = np.sqrt(np.diag(Sigma))
        D = np.diag(vols)
        
        # Calculate correlation matrix R
        inv_D = np.diag(1.0 / (vols + 1e-9))
        R = inv_D @ Sigma @ inv_D
        
        # Build tail-coupled correlation matrix R_coupled
        R_coupled = R.copy()
        for i in range(n):
            for j in range(i + 1, n):
                rho = float(np.clip(R[i, j], -0.99, 0.99))
                # Bivariate Student-t lower tail dependency:
                # lambda_L = 2 * t_cdf( -sqrt( (nu + 1) * (1 - rho) / (1 + rho) ), df = nu + 1 )
                try:
                    from scipy.stats import t
                    x = -np.sqrt((nu + 1.0) * (1.0 - rho) / (1.0 + rho))
                    lambda_l = 2.0 * t.cdf(x, df=nu + 1.0)
                except Exception:
                    # Fallback to analytical approximation of Student-t CDF if scipy fails or is missing
                    x = -np.sqrt((nu + 1.0) * (1.0 - rho) / (1.0 + rho))
                    # Normal approximation to Student-t cdf
                    lambda_l = 2.0 / (1.0 + np.exp(-1.7 * x))
                
                # AUDIT-FIX (Round 6, A1-P2-6): blending toward lambda_L (a
                # tail-dependence PROBABILITY, strictly < rho for rho > 0)
                # LOWERED every pairwise correlation in the Bear stress —
                # the exact opposite of the documented crisis-coupling intent
                # (verified: rho 0.5 -> 0.40, 0.7 -> 0.58), understating joint
                # crash risk. Blend toward a STRESS correlation instead:
                # crisis coupling pushes |rho| upward toward sign(rho)·min(1,
                # |rho| + alpha·lambda_L·(1-|rho|)) — tail dependence now
                # INCREASES co-movement instead of relaxing it.
                lambda_l = np.clip(lambda_l, 0.0, 1.0)
                rho = float(np.clip(R[i, j], -0.99, 0.99))
                _stress_rho = np.sign(rho) * min(1.0, abs(rho) + alpha_base * lambda_l * (1.0 - abs(rho)))
                R_coupled[i, j] = (1.0 - alpha_base) * rho + alpha_base * float(_stress_rho)
                R_coupled[j, i] = R_coupled[i, j]
                
        # Reconstruct Sigma_coupled = D * R_coupled * D
        Sigma_coupled = D @ R_coupled @ D
        return Sigma_coupled

