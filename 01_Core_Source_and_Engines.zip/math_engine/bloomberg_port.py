"""
math_engine/bloomberg_port.py
=============================
Pillar 1: Bloomberg PORT Portfolio Analytics & Factor Attribution Engine.
Implements:
1. Brinson-Fachler Multi-Asset Active Attribution (Allocation, Selection, Interaction).
2. Ex-Ante Active Tracking Error (TE) Decomposition & Marginal Contribution to Risk (MCTR).
3. Duration, Convexity & Key-Rate Rate Sensitivity Adjusters.
"""
from __future__ import annotations

import logging
from typing import Dict, List, Tuple, Optional, Any, Union
import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


class BloombergPortEngine:
    """Bloomberg PORT style active performance attribution and tracking error risk decomposer."""

    @classmethod
    def compute_brinson_fachler_attribution(
        cls,
        portfolio_weights: Dict[str, float],
        benchmark_weights: Dict[str, float],
        portfolio_returns: Dict[str, float],
        benchmark_returns: Dict[str, float],
        sectors: Dict[str, str]
    ) -> Dict[str, Any]:
        """
        Brinson-Fachler Attribution Decomposition:
        - Allocation Effect:  A_i = (w_i^P - w_i^B) * (R_i^B - R^B)
        - Selection Effect:   S_i = w_i^B * (R_i^P - R_i^B)
        - Interaction Effect: I_i = (w_i^P - w_i^B) * (R_i^P - R_i^B)
        - Total Active Alpha: Alpha = A + S + I = R^P - R^B
        """
        all_assets = set(portfolio_weights.keys()).union(benchmark_weights.keys())
        norm_sectors = {}
        for asset in all_assets:
            s_raw = sectors.get(asset)
            if not s_raw or str(s_raw).strip().upper() in ("", "NONE", "UNKNOWN", "N/A", "NAN", "NULL", "OTHER"):
                norm_sectors[asset] = "UNKNOWN"
            else:
                norm_sectors[asset] = str(s_raw).strip()

        all_sectors = sorted(set(norm_sectors.values()))

        # Aggregate weights and returns by sector
        sec_w_p = {sec: 0.0 for sec in all_sectors}
        sec_w_b = {sec: 0.0 for sec in all_sectors}
        sec_weighted_r_p = {sec: 0.0 for sec in all_sectors}
        sec_weighted_r_b = {sec: 0.0 for sec in all_sectors}

        for asset in all_assets:
            sec = norm_sectors[asset]
            w_p = portfolio_weights.get(asset, 0.0)
            w_b = benchmark_weights.get(asset, 0.0)
            r_p = portfolio_returns.get(asset, 0.0)
            r_b = benchmark_returns.get(asset, 0.0)

            sec_w_p[sec] += w_p
            sec_w_b[sec] += w_b
            sec_weighted_r_p[sec] += w_p * r_p
            sec_weighted_r_b[sec] += w_b * r_b

        # Compute sector average returns
        sec_r_p = {}
        sec_r_b = {}
        for sec in all_sectors:
            sec_r_p[sec] = sec_weighted_r_p[sec] / max(sec_w_p[sec], 1e-6) if sec_w_p[sec] > 0 else 0.0
            sec_r_b[sec] = sec_weighted_r_b[sec] / max(sec_w_b[sec], 1e-6) if sec_w_b[sec] > 0 else 0.0

        # Total benchmark & portfolio return
        r_total_p = sum(portfolio_weights.get(a, 0.0) * portfolio_returns.get(a, 0.0) for a in all_assets)
        r_total_b = sum(benchmark_weights.get(a, 0.0) * benchmark_returns.get(a, 0.0) for a in all_assets)

        sector_breakdown = []
        tot_alloc = 0.0
        tot_select = 0.0
        tot_interact = 0.0

        for sec in sorted(all_sectors):
            w_p = sec_w_p.get(sec, 0.0)
            w_b = sec_w_b.get(sec, 0.0)
            r_p = sec_r_p.get(sec, 0.0)
            r_b = sec_r_b.get(sec, 0.0)

            alloc = (w_p - w_b) * (r_b - r_total_b)
            select = w_b * (r_p - r_b)
            interact = (w_p - w_b) * (r_p - r_b)
            total_sec_active = alloc + select + interact

            tot_alloc += alloc
            tot_select += select
            tot_interact += interact

            sector_breakdown.append({
                "Sector": sec,
                "Weight_Port_%": round(w_p * 100.0, 2),
                "Weight_Bench_%": round(w_b * 100.0, 2),
                "Return_Port_%": round(r_p * 100.0, 2),
                "Return_Bench_%": round(r_b * 100.0, 2),
                "Allocation_Effect_bps": round(alloc * 10000.0, 1),
                "Selection_Effect_bps": round(select * 10000.0, 1),
                "Interaction_Effect_bps": round(interact * 10000.0, 1),
                "Total_Sector_Alpha_bps": round(total_sec_active * 10000.0, 1)
            })

        return {
            "portfolio_total_return_%": round(r_total_p * 100.0, 2),
            "benchmark_total_return_%": round(r_total_b * 100.0, 2),
            "total_active_alpha_bps": round((r_total_p - r_total_b) * 10000.0, 1),
            "total_allocation_effect_bps": round(tot_alloc * 10000.0, 1),
            "total_selection_effect_bps": round(tot_select * 10000.0, 1),
            "total_interaction_effect_bps": round(tot_interact * 10000.0, 1),
            "sector_attribution_table": sector_breakdown
        }

    @classmethod
    def compute_ex_ante_tracking_error(
        cls,
        portfolio_weights: np.ndarray,
        benchmark_weights: np.ndarray,
        cov_matrix: np.ndarray,
        annualization_factor: float = 252.0
    ) -> Dict[str, Any]:
        """
        Computes Ex-Ante Tracking Error (TE) and Marginal Contribution to Tracking Error (MCTR):
        - Active Weight: delta_w = w_p - w_b
        - Ex-Ante TE: TE = sqrt(delta_w^T * Cov * delta_w) * sqrt(252)
        - MCTR_i = (Cov * delta_w)_i / TE
        """
        w_p = np.asarray(portfolio_weights, dtype=float)
        w_b = np.asarray(benchmark_weights, dtype=float)
        cov = np.asarray(cov_matrix, dtype=float)

        delta_w = w_p - w_b
        active_variance = float(delta_w @ cov @ delta_w)
        active_variance = max(active_variance, 1e-12)
        
        te_daily = np.sqrt(active_variance)
        te_annual = float(te_daily * np.sqrt(annualization_factor))

        # MCTR (Marginal Contribution to Tracking Error)
        mctr_vec = (cov @ delta_w) / te_daily
        pct_contrib_mctr = (delta_w * mctr_vec) / active_variance

        return {
            "ex_ante_tracking_error_annual_%": round(te_annual * 100.0, 2),
            "active_variance_daily": active_variance,
            "mctr_vector": mctr_vec,
            "percentage_contribution_to_te": pct_contrib_mctr
        }

    @classmethod
    def compute_key_rate_duration_sensitivity(
        cls,
        weights: np.ndarray,
        durations: np.ndarray,
        rate_shocks_bps: Dict[str, float]
    ) -> Dict[str, float]:
        """
        Key-Rate Duration Rate Shock Model:
        Delta P / P = -Sum (Duration_k * Shock_k) + 0.5 * Convexity * (Shock)^2
        """
        w = np.asarray(weights, dtype=float)
        d = np.asarray(durations, dtype=float)
        port_duration = float(np.dot(w, d))

        estimated_impacts = {}
        for shock_name, shock_bps in rate_shocks_bps.items():
            delta_y = shock_bps / 10000.0
            price_impact_pct = -port_duration * delta_y * 100.0
            estimated_impacts[shock_name] = round(price_impact_pct, 3)

        estimated_impacts["Portfolio_Effective_Duration"] = round(port_duration, 2)
        return estimated_impacts
