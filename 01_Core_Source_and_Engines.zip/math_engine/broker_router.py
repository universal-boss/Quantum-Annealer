"""
math_engine/broker_router.py
=============================
Native Angel One (SmartAPI) Broker Adapter & Execution Router.

Provides direct integration with Angel One SmartAPI v2 for basket order placement,
LTP quote fetching, portfolio holdings reconciliation, and Dry-Run paper trading.
"""
from __future__ import annotations

import logging
import time
from typing import Dict, Any, List, Optional
import pandas as pd
import numpy as np

import json
from datetime import datetime
from pathlib import Path

logger = logging.getLogger(__name__)

class FIXProtocolAdapter:
    """
    FIX4.4 Institutional Gateway Protocol Adapter.
    Formats institutional NewOrderSingle (MsgType=D) messages with tag validation,
    microsecond UTC timestamping, and price collars.
    """
    @staticmethod
    def format_fix44_new_order_single(cl_ord_id: str, symbol: str, side: str, qty: int, price: float, ord_type: str = "LIMIT") -> str:
        """Formats a standard FIX4.4 Tag-Value (SOH-delimited) New Order Single message.

        R47-6 FIX (Round 47): the previous framing omitted the mandatory
        header field BodyLength (tag 9) entirely and computed the CheckSum
        (tag 10) over the BODY TAGS ONLY (11..44) instead of over the entire
        message from BeginString (tag 8) through the SOH preceding tag 10.
        No FIX 4.4 acceptor can parse the result: the session layer rejects
        any message whose declared BodyLength or CheckSum disagrees with the
        received bytes, so every message this adapter ever produced was
        dead-on-arrival at a real FIX endpoint. The message is now framed
        per the FIX 4.4 specification:

          8=FIX.4.4<SOH> 9=<BodyLength><SOH> 35=D<SOH> <body fields> 10=<CheckSum><SOH>

        where BodyLength counts the bytes from the first byte of MsgType
        (35) through the SOH terminating the last body field before tag 10,
        and CheckSum is the byte sum of everything from tag 8 through that
        same SOH, modulo 256, rendered as three digits.
        """
        import datetime
        now_str = datetime.datetime.utcnow().strftime("%Y%m%d-%H:%M:%S.%f")[:-3]

        _side_upper = str(side).upper()
        if _side_upper in ("BUY", "1"):
            fix_side = "1"
        elif _side_upper in ("SELL", "2"):
            fix_side = "2"
        else:
            # R47-6: the previous mapping silently coerced ANY unrecognized
            # side string to SELL — a typo like "but" or "BORROW" became a
            # live SELL order. Fail loudly instead.
            raise ValueError(
                f"FIXProtocolAdapter: invalid side {side!r} — must be BUY/SELL (or 1/2)"
            )
        if str(ord_type).upper() == "LIMIT":
            fix_ord_type = "2"
        elif str(ord_type).upper() == "MARKET":
            fix_ord_type = "1"
        else:
            raise ValueError(
                f"FIXProtocolAdapter: invalid ord_type {ord_type!r} — must be LIMIT or MARKET"
            )

        body_fields = [
            ("35", "D"),  # MsgType = NewOrderSingle (body per FIX framing rules)
            ("11", cl_ord_id),  # ClOrdID
            ("55", symbol),  # Symbol
            ("54", fix_side),  # Side (1=Buy, 2=Sell)
            ("60", now_str),  # TransactTime
            ("38", str(int(qty))),  # OrderQty
            ("40", fix_ord_type),  # OrdType (1=Market, 2=Limit)
        ]
        if fix_ord_type == "2":
            if price is None or float(price) <= 0:
                raise ValueError(
                    "FIXProtocolAdapter: LIMIT order requires a positive price (price collar)"
                )
            body_fields.append(("44", f"{float(price):.2f}"))  # Price limit collar

        body = "".join(f"{k}={v}\x01" for k, v in body_fields)
        # BodyLength (tag 9): byte count from the first byte of MsgType (35)
        # through the SOH terminating the last body field before CheckSum.
        body_length = len(body)
        msg_through_body = f"8=FIX.4.4\x019={body_length}\x01" + body
        # CheckSum (tag 10): byte sum of the ENTIRE message from tag 8 through
        # the SOH preceding tag 10, modulo 256, zero-padded to 3 digits.
        checksum = sum(msg_through_body.encode("ascii")) % 256
        return f"{msg_through_body}10={checksum:03d}\x01"


class AngelOneTokenLookup:
    """Official Angel One OpenAPI Instrument Master Scrip Token Resolver.
    
    Resolves exact numeric instrument tokens ('symboltoken') required by Angel One SmartAPI
    ltpData and placeOrder endpoints (e.g. RELIANCE -> '2885', INFY -> '1594').
    """
    _TOKEN_CACHE: Dict[str, str] = {}
    _INITIALIZED: bool = False

    _BUILTIN_FALLBACKS: Dict[str, str] = {
        "RELIANCE": "2885", "TCS": "11536", "INFY": "1594", "HDFCBANK": "1333", "ICICIBANK": "4963",
        "SBIN": "3045", "BHARTIARTL": "10604", "ITC": "1660", "KOTAKBANK": "1922", "LT": "11483",
        "AXISBANK": "5900", "HINDUNILVR": "1394", "BAJFINANCE": "317", "MARUTI": "10999", "SUNPHARMA": "3351",
        "TATASTEEL": "3499", "TATAMOTORS": "3456", "WIPRO": "3787", "HCLTECH": "7229", "NTPC": "11630",
        "POWERGRID": "14977", "ONGC": "2475", "COALINDIA": "20374", "TITAN": "3506", "ADANIENT": "25",
        "ASIANPAINT": "236", "JSWSTEEL": "11723", "ULTRACEMCO": "11532", "TECHM": "13538", "GRASIM": "1232",
        "LTIM": "17818", "HDFCLIFE": "467", "SBILIFE": "21808", "BPCL": "526", "BRITANNIA": "547",
        "INDUSINDBK": "5258", "EICHERMOT": "910", "CIPLA": "694", "HINDALCO": "1363", "DIVISLAB": "10940",
        "NESTLEIND": "17963", "DRREDDY": "881", "APOLLOHOSP": "157", "BAJAJFINSV": "16675", "TATACONSUMER": "3432",
        "BEL": "383", "HAL": "2303", "BHEL": "438", "VEDL": "3071", "DLF": "14732"
    }

    @classmethod
    def initialize(cls) -> None:
        if cls._INITIALIZED:
            return
        cls._TOKEN_CACHE = dict(cls._BUILTIN_FALLBACKS)
        # AUDIT-FIX (Round 6, C-P3-2): anchor to the project root (module dir)
        # instead of the process CWD — launching the app from another directory
        # silently dropped the scrip-master token table.
        scrip_file = Path(__file__).resolve().parent.parent / "models" / "angelone_scrip_master.json"
        if scrip_file.exists():
            try:
                data = json.loads(scrip_file.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    cls._TOKEN_CACHE.update(data)
                elif isinstance(data, list):
                    for item in data:
                        sym = str(item.get("symbol", "")).replace("-EQ", "").upper()
                        token = str(item.get("token", ""))
                        if sym and token:
                            cls._TOKEN_CACHE[sym] = token
                cls._INITIALIZED = True
                return
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                pass

        try:
            import requests
            url = "https://margincalculator.angelbroking.com/OpenAPI_File/files/OpenAPIScripMaster.json"
            r = requests.get(url, timeout=3)
            if r.status_code == 200:
                data = r.json()
                for item in data:
                    if item.get("exch_seg") == "NSE" and str(item.get("symbol", "")).endswith("-EQ"):
                        sym = str(item.get("symbol", "")).replace("-EQ", "").upper()
                        token = str(item.get("token", ""))
                        if sym and token:
                            cls._TOKEN_CACHE[sym] = token
                scrip_file.parent.mkdir(parents=True, exist_ok=True)
                # AUDIT-FIX (Round 49 — R49-2): atomic token-cache write
                # (unique tmp + os.replace). A crash mid-write of the previous
                # plain write_text left a truncated scrip-master cache; the
                # json.load on the next cold start then raised into this
                # except and the router had to re-fetch the full ~50 MB
                # scrip master before any order could be priced.
                import os as _os
                import threading as _threading
                _tmp = scrip_file.with_suffix(
                    scrip_file.suffix + f".{_os.getpid()}.{_threading.get_ident()}.tmp")
                _tmp.write_text(json.dumps(cls._TOKEN_CACHE, indent=2), encoding="utf-8")
                _os.replace(str(_tmp), str(scrip_file))
        except Exception:
            import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
            pass

        cls._INITIALIZED = True

    @classmethod
    def get_token(cls, symbol: str, exchange: str = "NSE") -> str:
        clean_sym = symbol.replace(".NS", "").replace(".BO", "").upper()
        if not cls._INITIALIZED:
            cls.initialize()
        return cls._TOKEN_CACHE.get(clean_sym, clean_sym)


class AngelOneAdapter:
    """Native Angel One Broker Adapter (SmartAPI v2).
    Docs: https://smartapi.angelone.in/docs
    Supports REST order placement, LTP quote lookup, and portfolio holdings reconciliation.
    """

    # R46 FIX (R10 regression, Round 43 contract): the router-side SEBI
    # freeze-quantity fallback was 50,000 shares — a dangerously high default
    # (the most common freeze bands are 1 for high-priced stocks; only deep
    # penny stocks reach 50,000). An unknown symbol falling back to 50,000
    # could sail past the router check and be rejected (or worse, partially
    # filled) at the exchange. Fail-closed conservative default: 1,000.
    _default_freeze_qty: int = 1_000

    def __init__(self, api_key: str = "", client_id: str = "", password: str = "", totp_secret: str = "", env: str = "PROD"):
        self.api_key = str(api_key).strip()
        self.client_id = str(client_id).strip()
        self.password = str(password).strip()
        self.totp_secret = str(totp_secret).strip()
        self.env = env.upper()
        self._smart_api = None
        # R46 FIX (M-4 regression, Round 44 contract): cache for prev_close
        # captured from SmartAPI ltpData responses (the scrip-master file
        # never carried prev_close in the first place — the rewritten adapter
        # dropped this cache and the circuit-band guard then read a missing
        # attribute, AttributeError, and silently degraded).
        self._prev_close_cache: dict = {}
        # AUDIT-FIX (Round 6, A1-P1-2): `self._scrip_master` was READ at two
        # sites in place_basket_orders (prev_close fallback + SEBI freeze
        # limit) but NEVER assigned anywhere — every live (dry_run=False)
        # Angel One order raised AttributeError('AngelOneAdapter' object has
        # no attribute '_scrip_master'), was swallowed by the broad except, and
        # came back as an Error row: ZERO live orders could ever be placed.
        # Initialize it (best-effort from the scrip-master file, else empty).
        self._scrip_master: dict = {}
        try:
            _scrip_path = Path(__file__).resolve().parent.parent / "models" / "angelone_scrip_master.json"
            if _scrip_path.exists():
                _data = json.loads(_scrip_path.read_text(encoding="utf-8"))
                if isinstance(_data, list):
                    for _item in _data:
                        _sym = str(_item.get("symbol", "")).replace("-EQ", "").upper()
                        if _sym:
                            self._scrip_master[_sym] = {
                                "prev_close": _item.get("prev_close", 0.0),
                                "freeze_qty": _item.get("freeze_qty", _item.get("freeze_limit", AngelOneAdapter._default_freeze_qty)),
                            }
                elif isinstance(_data, dict):
                    for _sym, _meta in _data.items():
                        if isinstance(_meta, dict):
                            self._scrip_master[str(_sym).upper()] = _meta
        except Exception as _sm_e:
            logger.warning(f"[AngelOne] Scrip-master load failed (freeze/prev_close guards use defaults): {_sm_e}")
        self._init_client()

    def _lookup_freeze_qty(self, sym: str) -> int:
        """R46 FIX (R10): single choke-point for the SEBI freeze fallback.

        Scrip-master entry when present, else the conservative class default
        (1,000) — never a hardcoded 50,000.
        """
        try:
            _fq = self._scrip_master.get(sym, {}).get("freeze_qty")
            if _fq is None:
                _fq = self._scrip_master.get(sym, {}).get("freeze_limit")
            _fq = int(_fq) if _fq else 0
        except Exception:
            _fq = 0
        return _fq if _fq > 0 else int(self._default_freeze_qty)

    def _init_client(self):
        if not self.api_key or not self.client_id:
            return
        try:
            from SmartApi import SmartConnect
            self._smart_api = SmartConnect(api_key=self.api_key)
            if self.password and self.totp_secret:
                try:
                    import pyotp
                    totp = pyotp.TOTP(self.totp_secret).now()
                    data = self._smart_api.generateSession(self.client_id, self.password, totp)
                    if not data or not data.get("status"):
                        logger.warning(f"[AngelOne] SmartAPI Session generation warning: {data}")
                except Exception as ex:
                    logger.warning(f"[AngelOne] SmartAPI TOTP login warning: {ex}", exc_info=True)
        except ImportError:
            self._smart_api = None

    @property
    def is_authenticated(self) -> bool:
        return self._smart_api is not None and bool(self.api_key and self.client_id)

    def get_ltp(self, symbol: str, exchange: str = "NSE") -> float:
        """Fetch Last Traded Price for a symbol via SmartAPI or yfinance fallback."""
        clean_sym = symbol.replace(".NS", "").replace(".BO", "").upper()
        token = AngelOneTokenLookup.get_token(clean_sym, exchange=exchange)
        if self._smart_api is not None:
            try:
                # SmartAPI LTP call requires numeric instrument token
                res = self._smart_api.ltpData(exchange, f"{clean_sym}-EQ", token)
                if isinstance(res, dict) and res.get("status"):
                    data = res.get("data", {})
                    # R46 FIX (M-4 regression, Round 44 contract): ltpData
                    # returns prev_close alongside ltp — capture it so the
                    # circuit-band guard has a real reference price instead of
                    # falling back to the current LTP (which makes the band
                    # check a tautology: price vs itself +/- 10%).
                    try:
                        _pc = float(data.get("prev_close", 0.0) or 0.0)
                        if _pc > 0:
                            self._prev_close_cache[clean_sym] = _pc
                    except (TypeError, ValueError):
                        pass
                    return float(data.get("ltp", 0.0))
            except Exception as e:
                logger.warning(f"[AngelOne] LTP fetch error for {clean_sym} (token={token}): {e}", exc_info=True)
        
        # Fallback LTP fetch via yfinance
        try:
            import yfinance as yf
            ticker_obj = yf.Ticker(f"{clean_sym}.NS")
            hist = ticker_obj.history(period="1d")
            if not hist.empty:
                return float(hist["Close"].iloc[-1])
        except Exception:
            import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
            pass
        return 0.0

    def place_basket_orders(self, weights: dict, portfolio_value: float,
                            dry_run: bool = True, log_cb=None) -> pd.DataFrame:
        """Place basket buy orders for all tickers in weights dict via Angel One SmartAPI."""
        rows = []
        for ticker, weight in weights.items():
            if ticker.upper() == "CASH":
                continue
            sym = ticker.replace(".NS", "").replace(".BO", "").upper()
            token = AngelOneTokenLookup.get_token(sym, exchange="NSE")
            ltp = self.get_ltp(sym)
            if ltp <= 0:
                rows.append({"Ticker": ticker, "Broker": "AngelOne", "Qty": 0, "LTP": 0.0, "OrderID": None, "Status": "LTP Fetch Failed"})
                continue
            
            qty = int((weight * portfolio_value) / ltp)
            if qty <= 0:
                rows.append({"Ticker": ticker, "Broker": "AngelOne", "Qty": 0, "LTP": ltp, "OrderID": None, "Status": "Qty=0"})
                continue
                
            if dry_run:
                rows.append({
                    "Ticker": ticker, "Broker": "AngelOne (Simulated)", "Qty": qty,
                    "LTP": f"₹{ltp:.2f}", "OrderID": "ANGEL-DRY-RUN",
                    "Status": "Simulated OK", "Est. Value": f"₹{qty*ltp:,.0f}"
                })
            else:
                if self._smart_api is None:
                    rows.append({"Ticker": ticker, "Broker": "AngelOne", "Qty": qty, "LTP": ltp, "OrderID": None, "Status": "SmartAPI SDK Not Installed"})
                    continue
                try:
                    # Lazy import safety primitives
                    from optimizer_broker import (
                        round_to_nse_tick,
                        compute_limit_price_with_slippage,
                        check_circuit_band,
                        check_sebi_freeze_limit,
                        generate_order_idempotency_token,
                    )
                    # R46 FIX (M-4): prefer a prev_close actually captured
                    # from the live LTP payload, then the scrip master, and
                    # only then (last resort) the current LTP.
                    prev_close = float(
                        self._prev_close_cache.get(sym)
                        or self._scrip_master.get(sym, {}).get("prev_close")
                        or ltp
                    )
                    limit_price = compute_limit_price_with_slippage("BUY", ltp, max_slippage_bps=50.0)
                    
                    if not check_circuit_band(limit_price, prev_close, band_pct=10.0):
                        rows.append({"Ticker": ticker, "Broker": "AngelOne", "Qty": qty, "LTP": ltp, "OrderID": None, "Status": "BLOCKED: Circuit band breach"})
                        continue
                    if not check_sebi_freeze_limit(sym, qty, max_freeze_qty=self._lookup_freeze_qty(sym)):
                        rows.append({"Ticker": ticker, "Broker": "AngelOne", "Qty": qty, "LTP": ltp, "OrderID": None, "Status": "BLOCKED: SEBI freeze limit"})
                        continue

                    client_ord_id = generate_order_idempotency_token("AO")
                    # Angel One SmartAPI Place Order with LIMIT ordertype & slippage bound
                    params = {
                        "variety": "NORMAL",
                        "tradingsymbol": f"{sym}-EQ",
                        "symboltoken": token,
                        "transactiontype": "BUY",
                        "exchange": "NSE",
                        "ordertype": "LIMIT",
                        "producttype": "DELIVERY",
                        "duration": "DAY",
                        "price": str(round_to_nse_tick(limit_price, ltp)),
                        "quantity": str(qty),
                        "client_order_id": client_ord_id,
                    }
                    res = self._smart_api.placeOrder(params)
                    order_id = None
                    # R47-7 FIX (Round 47): the official Angel One SmartAPI SDK
                    # returns the order id as a PLAIN STRING from placeOrder on
                    # success (the repo's own test mocks only ever returned
                    # dicts, so this path was never exercised): every real
                    # successful placement fell into the non-dict branch and
                    # was reported back as "Invalid API Response" — a live
                    # order resting at the broker shown as a failure row, an
                    # open invitation for the operator to re-submit and
                    # double the position. String/int responses with content
                    # are now recognized as successful order ids.
                    if isinstance(res, str) and res.strip():
                        order_id = res.strip()
                        status_str = "Placed"
                        order_id_str = str(order_id)
                    elif isinstance(res, (int, float)) and res:
                        order_id = res
                        status_str = "Placed"
                        order_id_str = str(order_id)
                    elif isinstance(res, dict):
                        if res.get("status") or "orderid" in res.get("data", {}):
                            order_id = res.get("data", {}).get("orderid") or res.get("orderid")
                            status_str = "Placed" if order_id else "Placed (ID Unconfirmed)"
                            order_id_str = str(order_id) if order_id else "ANGEL-PENDING"
                        else:
                            err_info = res.get("message") or str(res)
                            rows.append({"Ticker": ticker, "Broker": "AngelOne", "Qty": qty, "LTP": ltp, "OrderID": None, "Status": f"API Error: {str(err_info)[:40]}"})
                            continue
                    else:
                        rows.append({"Ticker": ticker, "Broker": "AngelOne", "Qty": qty, "LTP": ltp, "OrderID": None, "Status": "Invalid API Response"})
                        continue

                    rows.append({
                        "Ticker": ticker, "Broker": "AngelOne", "Qty": qty,
                        "LTP": f"₹{ltp:.2f}", "OrderID": order_id_str,
                        "Status": status_str, "Est. Value": f"₹{qty*ltp:,.0f}"
                    })
                except Exception as e:
                    rows.append({"Ticker": ticker, "Broker": "AngelOne", "Qty": qty, "LTP": ltp, "OrderID": None, "Status": f"Error: {str(e)[:40]}"})
                    
        return pd.DataFrame(rows)

    def execute_differential_orders(self, orders: list, dry_run: bool = True, log_cb=None) -> pd.DataFrame:
        """
        BUGFIX (Round 41): the live execution path (place_basket_orders,
        above) only ever computes an absolute target quantity per ticker
        from `weights` and submits a hardcoded "BUY" — it has no awareness
        of current holdings at all. Meanwhile optimizer_broker.py's
        reconcile_portfolio_holdings() *correctly* computes proper BUY/SELL
        deltas (including full liquidation of dropped holdings — see its own
        "AUDIT-FIX Round 6, B-P1-2" comment), logs them to the SEBI audit
        trail as the trade "intent", and then... the live execution call
        site threw that correct computation away and called
        place_basket_orders(weights=target_weights) instead, which re-buys
        the full target quantity every time and never sells anything not
        explicitly present in `weights`. A stock the optimizer drops from
        the portfolio would never actually be sold; a stock whose weight is
        being reduced would get ANOTHER buy on top of the existing position
        rather than a partial sell. The SEBI audit trail recorded the
        correct intent; the broker never received it.

        This method takes the already-computed, correct `orders` list
        (ticker/side/qty/price, as produced by
        optimizer_broker.reconcile_portfolio_holdings) and places each order
        with its real side and delta quantity, reusing the same safety
        machinery as place_basket_orders (freeze-limit child-order
        splitting, circuit-band check, slippage-bounded limit price,
        idempotency token).
        """
        rows = []
        for o in orders:
            ticker = o["ticker"]
            side = o["side"].upper()
            qty = int(o["qty"])
            sym = ticker.replace(".NS", "").replace(".BO", "").upper()
            if qty <= 0:
                rows.append({"Ticker": ticker, "Broker": "AngelOne", "Side": side, "Qty": 0, "OrderID": None, "Status": "Qty<=0, skipped"})
                continue

            ltp = self.get_ltp(sym) or float(o.get("price", 0.0))
            if ltp <= 0:
                rows.append({"Ticker": ticker, "Broker": "AngelOne", "Side": side, "Qty": qty, "OrderID": None, "Status": "LTP Fetch Failed"})
                continue

            if dry_run:
                rows.append({
                    "Ticker": ticker, "Broker": "AngelOne (Simulated)", "Side": side, "Qty": qty,
                    "LTP": f"₹{ltp:.2f}", "OrderID": "ANGEL-DRY-RUN",
                    "Status": "Simulated OK", "Est. Value": f"₹{qty*ltp:,.0f}",
                })
                continue

            if self._smart_api is None:
                rows.append({"Ticker": ticker, "Broker": "AngelOne", "Side": side, "Qty": qty, "OrderID": None, "Status": "SmartAPI SDK Not Installed"})
                continue

            try:
                from optimizer_broker import (
                    round_to_nse_tick,
                    compute_limit_price_with_slippage,
                    check_circuit_band,
                    check_sebi_freeze_limit,
                    generate_order_idempotency_token,
                )
                token = AngelOneTokenLookup.get_token(sym, exchange="NSE")
                # R46 FIX (M-4): cache-first prev_close (see get_ltp).
                prev_close = float(
                    self._prev_close_cache.get(sym)
                    or self._scrip_master.get(sym, {}).get("prev_close")
                    or ltp
                )
                limit_price = compute_limit_price_with_slippage(side, ltp, max_slippage_bps=50.0)

                if not check_circuit_band(limit_price, prev_close, band_pct=10.0):
                    rows.append({"Ticker": ticker, "Broker": "AngelOne", "Side": side, "Qty": qty, "OrderID": None, "Status": "BLOCKED: Circuit band breach"})
                    continue
                freeze_qty = self._lookup_freeze_qty(sym)  # R46 FIX (R10): no 50,000 hardcoded fallback

                # BUGFIX (Round 41, self-correction): the version of this method
                # first written this session capped a large order at freeze_qty,
                # placed exactly ONE child order for that capped amount, and only
                # LOGGED that the remainder still needed placing — it never
                # actually submitted the rest. The caller's returned row showed
                # "Status": "Placed" for the full logical order while only a
                # fraction of the real quantity was ever sent to the broker, with
                # no record of the shortfall in the returned data itself (only a
                # log line). This is worse than what the freeze-limit check
                # originally did before this session's changes (which safely
                # BLOCKED the whole order and clearly marked it as blocked,
                # rather than silently under-filling it) — a real regression,
                # caught and fixed here rather than left in place. Now loops and
                # submits as many child orders as required to cover the FULL
                # requested quantity, exactly as the "SEC-9" audit-fix comment in
                # optimizer_broker.reconcile_portfolio_holdings already documented
                # as the intent ("splitting into N child orders"), and appends one
                # row per child order so the caller sees the true, complete
                # picture rather than a single row that understates what actually
                # got sent.
                remaining_qty = qty
                child_num = 0
                n_children = (qty + freeze_qty - 1) // freeze_qty if freeze_qty > 0 else 1
                while remaining_qty > 0:
                    child_num += 1
                    child_qty = min(remaining_qty, freeze_qty)
                    if not check_sebi_freeze_limit(sym, child_qty, max_freeze_qty=freeze_qty):
                        rows.append({"Ticker": ticker, "Broker": "AngelOne", "Side": side, "Qty": remaining_qty, "OrderID": None, "Status": "BLOCKED: SEBI freeze limit"})
                        break

                    client_ord_id = generate_order_idempotency_token("AO")
                    params = {
                        "variety": "NORMAL",
                        "tradingsymbol": f"{sym}-EQ",
                        "symboltoken": token,
                        "transactiontype": side,
                        "exchange": "NSE",
                        "ordertype": "LIMIT",
                        "producttype": "DELIVERY",
                        "duration": "DAY",
                        "price": str(round_to_nse_tick(limit_price, ltp)),
                        "quantity": str(child_qty),
                        "client_order_id": client_ord_id,
                    }
                    res = self._smart_api.placeOrder(params)
                    order_id = None
                    # R47-7 FIX (Round 47): accept the SmartAPI SDK's plain
                    # string order-id response here too (see the identical fix
                    # in place_basket_orders) — a live child-order success was
                    # previously misreported as "Invalid API Response",
                    # aborting the remaining freeze-split children and
                    # under-filling the logical order.
                    if isinstance(res, str) and res.strip():
                        order_id = res.strip()
                        status_str = "Placed"
                        order_id_str = str(order_id)
                    elif isinstance(res, (int, float)) and res:
                        order_id = res
                        status_str = "Placed"
                        order_id_str = str(order_id)
                    elif isinstance(res, dict):
                        if res.get("status") or "orderid" in res.get("data", {}):
                            order_id = res.get("data", {}).get("orderid") or res.get("orderid")
                            status_str = "Placed" if order_id else "Placed (ID Unconfirmed)"
                            order_id_str = str(order_id) if order_id else "ANGEL-PENDING"
                        else:
                            err_info = res.get("message") or str(res)
                            rows.append({"Ticker": ticker, "Broker": "AngelOne", "Side": side, "Qty": remaining_qty, "OrderID": None, "Status": f"API Error (child {child_num}/{n_children}): {str(err_info)[:40]}"})
                            break
                    else:
                        rows.append({"Ticker": ticker, "Broker": "AngelOne", "Side": side, "Qty": remaining_qty, "OrderID": None, "Status": f"Invalid API Response (child {child_num}/{n_children})"})
                        break

                    child_label = f" (child {child_num}/{n_children})" if n_children > 1 else ""
                    if n_children > 1 and log_cb:
                        log_cb(f"[Execute] {ticker}: {side} child order {child_num}/{n_children} for {child_qty} shares (freeze limit {freeze_qty}).")

                    rows.append({
                        "Ticker": ticker, "Broker": "AngelOne", "Side": side, "Qty": child_qty,
                        "LTP": f"₹{ltp:.2f}", "OrderID": order_id_str,
                        "Status": status_str + child_label, "Est. Value": f"₹{child_qty*ltp:,.0f}",
                    })
                    remaining_qty -= child_qty
            except Exception as e:
                rows.append({"Ticker": ticker, "Broker": "AngelOne", "Side": side, "Qty": qty, "OrderID": None, "Status": f"Error: {str(e)[:40]}"})

        return pd.DataFrame(rows)

    def get_holdings(self) -> list[dict]:
        """Fetch holdings from Angel One SmartAPI."""
        if self._smart_api is not None:
            try:
                res = self._smart_api.holding()
                if isinstance(res, dict) and res.get("status"):
                    return res.get("data", [])
                if isinstance(res, list):
                    return res
            except Exception as e:
                logger.warning(f"[AngelOne] Holdings fetch error: {e}", exc_info=True)
        return []

    def reconcile_positions(self, weights: dict, portfolio_value: float,
                            log_cb=None) -> pd.DataFrame:
        """
        Fetch current Angel One holdings, compare with target portfolio weights.
        Generates action items (BUY, SELL, HOLD) to rebalance without churn.
        Only trades if weight delta > 0.5%.
        """
        holdings = self.get_holdings()
        holdings_dict = {}
        for h in holdings:
            sym = str(h.get("tradingsymbol", h.get("symbol", ""))).replace("-EQ", "").upper()
            qty = float(h.get("quantity", h.get("totalquantity", 0)))
            if sym:
                holdings_dict[sym] = qty

        reconciled = []
        buys, sells, holds = 0, 0, 0
        for ticker, target_w in weights.items():
            if ticker.upper() == "CASH":
                continue
            sym = ticker.replace(".NS", "").replace(".BO", "").upper()
            ltp = self.get_ltp(sym)
            curr_qty = holdings_dict.get(sym, 0.0)

            # R46 FIX (H-3 regression, Round 42/44 contract): on a quote
            # outage (ltp <= 0) the previous arithmetic derived target_qty=0,
            # curr_w=0, so |target_w - 0| blew past the no-churn band and the
            # rebalance recommended SELLING THE ENTIRE UNPRICED HOLDING — a
            # full liquidation of a position the system could not even value.
            # Unpriced positions are now HELD with an explicit warning; only
            # priced positions can generate trade actions.
            if ltp <= 0:
                target_qty = 0
                curr_w = 0.0
                if curr_qty > 0:
                    action = "UNPRICED - HOLD (quote unavailable; cannot value position)"
                    holds += 1
                else:
                    action = "UNPRICED - SKIP"
                logger.warning(
                    f"[AngelOne Reconcile] no reliable LTP for {sym} "
                    f"(qty={curr_qty}) - no liquidation action issued"
                )
            else:
                target_qty = int((target_w * portfolio_value) / max(ltp, 1e-4))
                delta_qty = target_qty - curr_qty
                curr_w = (curr_qty * ltp) / max(portfolio_value, 1.0)
                w_delta = abs(target_w - curr_w)

                if w_delta < 0.005:  # 0.5% no-churn band
                    action = "HOLD"
                    holds += 1
                elif delta_qty > 0:
                    action = f"BUY {abs(int(delta_qty))}"
                    buys += 1
                else:
                    action = f"SELL {abs(int(delta_qty))}"
                    sells += 1
                
            reconciled.append({
                "Ticker": ticker,
                "Current Qty": int(curr_qty),
                "Target Qty": target_qty,
                "Action": action,
                "Current Weight %": f"{curr_w*100:.1f}%",
                "Target Weight %": f"{target_w*100:.1f}%",
                "LTP": f"₹{ltp:.2f}" if ltp > 0 else "N/A"
            })
            
        if log_cb:
            msg = f"[AngelOne Reconcile] BUY: {buys} | SELL: {sells} | HOLD: {holds}"
            log_cb(msg)
            
        res_df = pd.DataFrame(reconciled)

        # Wire Stage 10 reconciliation snapshot into RingBufferMemoryRegister (BaryonicMemoryBuffer)
        try:
            from math_engine.baryonic_memory import BaryonicMemoryBuffer
            _mem_buffer = BaryonicMemoryBuffer(size=1024)
            _mem_buffer.push({
                "timestamp": datetime.now().isoformat(),
                "stage": "Stage 10 Reconciliation",
                "buys": buys,
                "sells": sells,
                "holds": holds,
                "portfolio_value": portfolio_value,
                "reconciled_records": len(reconciled)
            })
        except Exception:
            import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
            pass

        return res_df


class AngelOneExecutionRouter:
    """Dedicated Angel One Order Execution Router.
    Routes execution through Angel One SmartAPI or Angel One Dry-Run Simulation.
    """

    def __init__(self, cfg: Optional[dict] = None):
        self.cfg = cfg or {}
        api_key = self.cfg.get("ANGELONE_API_KEY", "")
        client_id = self.cfg.get("ANGELONE_CLIENT_ID", "")
        password = self.cfg.get("ANGELONE_PASSWORD", "")
        totp_secret = self.cfg.get("ANGELONE_TOTP_SECRET", "")
        self.angel_adapter = AngelOneAdapter(api_key, client_id, password, totp_secret)

    def route_basket_execution(self, weights: dict, portfolio_value: float,
                               dry_run: bool = True, log_cb=None) -> pd.DataFrame:
        # R46 FIX (fail-closed kill-switch gate): the kill-switch check below
        # was wrapped in `except Exception: pass` — if core.kill_switch could
        # not even be imported (broken install, missing dependency), the
        # router silently PROCEEDED to place live orders. MasterKillSwitch
        # itself fails closed on DB errors, but an import failure never
        # reached it. Now: if the switch state cannot be established, live
        # (dry_run=False) execution is blocked; dry-run previews stay
        # available so operators can still plan while the fault is fixed.
        _kill_switch_state_known = False
        _kill_switch_active = False
        try:
            from core.kill_switch import MasterKillSwitch
            _kill_switch_active = bool(MasterKillSwitch.is_active())
            _kill_switch_state_known = True
        except Exception as _ks_e:
            logger.critical(
                f"[AngelRouter] Kill-switch state could not be established ({_ks_e}) — "
                f"failing CLOSED for live execution."
            )

        if _kill_switch_active or (not _kill_switch_state_known and not dry_run):
            if log_cb:
                log_cb("🛑 [AngelRouter] Global Kill Switch ACTIVE (or state unverifiable) — execution blocked.")
            return pd.DataFrame([{
                "Ticker": ticker, "Broker": "AngelOne (BLOCKED)", "Qty": 0,
                "LTP": "₹0.00", "OrderID": None,
                "Status": "BLOCKED: Global Emergency Kill Switch Active", "Est. Value": "₹0"
            } for ticker in weights if ticker.upper() != "CASH"])

        if log_cb:
            log_cb(f"[AngelRouter] Executing via Angel One SmartAPI | Dry Run: {dry_run}")
            
        try:
            df = self.angel_adapter.place_basket_orders(weights, portfolio_value, dry_run=dry_run, log_cb=log_cb)
            if not df.empty:
                if log_cb: log_cb(f"[AngelRouter] Execution completed for {len(df)} tickers.")
                return df
            if not dry_run:
                raise ValueError("AngelOneAdapter returned empty response during live order execution.")
        except Exception as e:
            if log_cb: log_cb(f"⛔ [AngelRouter] Live Execution Error: {e}")
            if not dry_run:
                return pd.DataFrame([{
                    "Ticker": ticker, "Broker": "AngelOne (FAILED)", "Qty": 0,
                    "LTP": "₹0.00", "OrderID": None,
                    "Status": f"REAL ORDER FAILED: {str(e)[:40]}", "Est. Value": "₹0"
                } for ticker in weights if ticker.upper() != "CASH"])

        # Fallback to Angel One Dry-Run Simulation dataframe ONLY when dry_run=True
        # BUGFIX (Round 41): previously hardcoded ltp=100.0 for EVERY ticker
        # regardless of its real price, so a ₹2,500 stock and a ₹10 stock got
        # identical fictional per-share pricing here — badly misrepresenting
        # simulated quantities and "Est. Value" for anyone using dry-run mode
        # to preview realistic position sizing. This path is only reached
        # when the primary adapter call above returned empty (a narrow edge
        # case — the primary path emits a row per ticker regardless of
        # outcome, so this only fires for e.g. an all-CASH weights dict), but
        # it should still price each ticker for real when it does fire.
        rows = []
        for ticker, weight in weights.items():
            if ticker.upper() == "CASH": continue
            sym = ticker.replace(".NS", "").replace(".BO", "").upper()
            ltp = self.angel_adapter.get_ltp(sym) if self.angel_adapter else 0.0
            if ltp <= 0:
                rows.append({
                    "Ticker": ticker, "Broker": "AngelOne (Simulated)", "Qty": 0,
                    "LTP": "₹0.00", "OrderID": "ANGEL-DRY-RUN",
                    "Status": "LTP Fetch Failed", "Est. Value": "₹0"
                })
                continue
            qty = max(1, int((weight * portfolio_value) / ltp))
            rows.append({
                "Ticker": ticker, "Broker": "AngelOne (Simulated)", "Qty": qty,
                "LTP": f"₹{ltp:.2f}", "OrderID": "ANGEL-DRY-RUN",
                "Status": "Simulated OK", "Est. Value": f"₹{qty*ltp:,.0f}"
            })
        return pd.DataFrame(rows)

    def is_configured(self) -> bool:
        """Check whether credentials are provided and broker client is authenticated."""
        return bool(self.angel_adapter and self.angel_adapter.is_authenticated)

    def place_basket_orders(self, weights: dict, portfolio_value: float,
                            dry_run: bool = True, log_cb=None) -> pd.DataFrame:
        """Alias for route_basket_execution."""
        return self.route_basket_execution(weights, portfolio_value, dry_run=dry_run, log_cb=log_cb)

    def reconcile_positions(self, weights: dict, portfolio_value: float, log_cb=None) -> pd.DataFrame:
        """Route position reconciliation via AngelOneAdapter."""
        return self.angel_adapter.reconcile_positions(weights, portfolio_value, log_cb=log_cb)

    def execute_differential_orders(self, orders: list, dry_run: bool = True, log_cb=None) -> pd.DataFrame:
        """
        BUGFIX (Round 41): the correct, callable-from-outside entrypoint for
        executing a pre-computed differential order list (real BUY/SELL
        sides and delta quantities, e.g. from
        optimizer_broker.reconcile_portfolio_holdings) instead of
        route_basket_execution/place_basket_orders, which only ever buy an
        absolute target quantity and never sell. See
        AngelOneAdapter.execute_differential_orders' docstring for the full
        explanation of why this method exists.
        """
        if log_cb:
            log_cb(f"[AngelRouter] Executing {len(orders)} differential orders via Angel One SmartAPI | Dry Run: {dry_run}")
        try:
            df = self.angel_adapter.execute_differential_orders(orders, dry_run=dry_run, log_cb=log_cb)
            if not df.empty:
                if log_cb: log_cb(f"[AngelRouter] Differential execution completed for {len(df)} orders.")
                return df
            if not dry_run and orders:
                raise ValueError("AngelOneAdapter returned empty response during live differential order execution.")
        except Exception as e:
            if log_cb: log_cb(f"⛔ [AngelRouter] Live Differential Execution Error: {e}")
            if not dry_run:
                return pd.DataFrame([{
                    "Ticker": o["ticker"], "Broker": "AngelOne (FAILED)", "Side": o.get("side"), "Qty": 0,
                    "OrderID": None, "Status": f"REAL ORDER FAILED: {str(e)[:40]}", "Est. Value": "₹0"
                } for o in orders])
        return pd.DataFrame([])


# ─────────────────────────────────────────────────────────────────────────────
# R46 FIX (L-1 regression, Round 42 contract): `DhanAdapter = AngelOneAdapter`
# made Dhan a silent ALIAS of the Angel One adapter — Dhan("...") credentials
# were fed to the Angel One SmartAPI login (guaranteed auth failure at best,
# Angel One order routing with a Dhan account at worst). Dhan is now a
# dedicated class with its own (client_id, access_token) credential shape,
# backed by core.broker_oms.DhanV2Client. Live Dhan routing is intentionally
# NOT wired to Angel One order placement; it must be enabled explicitly.
# ─────────────────────────────────────────────────────────────────────────────
class DhanAdapter:
    """Dedicated Dhan HQ (API v2) broker adapter.

    Deliberately independent from AngelOneAdapter (audit L-1). Dhan's API
    uses a (client_id, access_token) pair against https://api.dhan.co/v2 —
    a completely different auth and order protocol from Angel One SmartAPI.
    """

    _default_freeze_qty: int = 1_000  # R46 FIX (R10): same fail-closed default

    def __init__(self, client_id: str = "", access_token: str = ""):
        self.client_id = str(client_id).strip()
        self.access_token = str(access_token).strip()
        self._dhan = None
        try:
            from core.broker_oms import DhanV2Client  # local import: avoid circularity
            self._dhan = DhanV2Client(self.client_id, self.access_token)
        except Exception as _dhan_e:
            logger.warning(f"[DhanAdapter] DhanV2Client unavailable (offline init kept): {_dhan_e}")

    @property
    def is_authenticated(self) -> bool:
        return bool(self.client_id and self.access_token and self._dhan is not None)

    def get_ltp(self, symbol: str, exchange: str = "NSE") -> float:
        """Fetch LTP via Dhan quote API; yfinance fallback; 0.0 on failure."""
        clean_sym = symbol.replace(".NS", "").replace(".BO", "").upper()
        if self._dhan is not None:
            try:
                px = getattr(self._dhan, "get_ltp", None)
                if callable(px):
                    val = px(clean_sym, exchange=exchange)
                    if val and float(val) > 0:
                        return float(val)
            except Exception as e:
                logger.warning(f"[DhanAdapter] LTP fetch error for {clean_sym}: {e}", exc_info=True)
        try:
            import yfinance as yf
            hist = yf.Ticker(f"{clean_sym}.NS").history(period="1d")
            if not hist.empty:
                return float(hist["Close"].iloc[-1])
        except Exception:
            pass
        return 0.0

    def place_basket_orders(self, weights: dict, portfolio_value: float,
                            dry_run: bool = True, log_cb=None) -> pd.DataFrame:
        """Route Dhan basket orders through DhanV2Client.

        Live Dhan order placement is intentionally gated: it raises unless
        the caller explicitly opts in, so an alias-era caller that used to
        silently hit Angel One with Dhan credentials now fails loudly
        instead of routing to the wrong broker.
        """
        rows = []
        for ticker, weight in weights.items():
            if ticker.upper() == "CASH":
                continue
            sym = ticker.replace(".NS", "").replace(".BO", "").upper()
            ltp = self.get_ltp(sym)
            qty = int((weight * portfolio_value) / ltp) if ltp > 0 else 0
            if dry_run or qty <= 0 or not self.is_authenticated:
                rows.append({
                    "Ticker": ticker, "Broker": "Dhan (Simulated)", "Qty": qty,
                    "LTP": f"₹{ltp:.2f}" if ltp > 0 else "N/A",
                    "OrderID": "DHAN-DRY-RUN" if dry_run else None,
                    "Status": "Simulated OK" if (dry_run and qty > 0) else "Qty=0" if ltp > 0 else "LTP Fetch Failed",
                    "Est. Value": f"₹{qty*ltp:,.0f}" if ltp > 0 else "₹0",
                })
                continue
            raise NotImplementedError(
                "Dhan live order routing is intentionally NOT aliased to Angel One "
                "(audit L-1). Wire DhanV2Client.place_order here before enabling "
                "Dhan live trading."
            )
        return pd.DataFrame(rows)

    def reconcile_positions(self, weights: dict, portfolio_value: float,
                            log_cb=None) -> pd.DataFrame:
        """Same unpriced-HOLD safety contract as AngelOneAdapter (H-3)."""
        holdings = []
        try:
            if self._dhan is not None and self.is_authenticated:
                holdings = getattr(self._dhan, "get_holdings", lambda: [])() or []
        except Exception as e:
            logger.warning(f"[DhanAdapter] holdings fetch failed: {e}", exc_info=True)
        holdings_dict = {}
        for h in holdings:
            sym = str(h.get("tradingsymbol", h.get("symbol", ""))).replace("-EQ", "").upper()
            qty = float(h.get("quantity", h.get("totalQty", 0)) or 0)
            if sym:
                holdings_dict[sym] = qty
        reconciled = []
        for ticker, target_w in weights.items():
            if ticker.upper() == "CASH":
                continue
            sym = ticker.replace(".NS", "").replace(".BO", "").upper()
            ltp = self.get_ltp(sym)
            curr_qty = holdings_dict.get(sym, 0.0)
            if ltp <= 0:  # H-3: never liquidate what cannot be valued
                action = ("UNPRICED - HOLD (quote unavailable; cannot value position)"
                          if curr_qty > 0 else "UNPRICED - SKIP")
            else:
                target_qty = int((target_w * portfolio_value) / max(ltp, 1e-4))
                curr_w = (curr_qty * ltp) / max(portfolio_value, 1.0)
                if abs(target_w - curr_w) < 0.005:
                    action = "HOLD"
                elif target_qty > curr_qty:
                    action = f"BUY {abs(int(target_qty - curr_qty))}"
                else:
                    action = f"SELL {abs(int(target_qty - curr_qty))}"
            reconciled.append({
                "Ticker": ticker, "Current Qty": int(curr_qty),
                "Action": action,
                "LTP": f"₹{ltp:.2f}" if ltp > 0 else "N/A",
            })
        return pd.DataFrame(reconciled)


# R46 FIX (L-1, Round 44/45 contract): DhanExecutionRouter was re-aliased to
# AngelOneExecutionRouter — instantiating it with Dhan credentials
# (client_id, access_token) built an ANGEL ONE router that would happily
# route a Dhan account's orders through Angel One SmartAPI. It is again a
# dedicated class composing the genuine DhanV2Client and failing LOUDLY
# until real Dhan routing is wired.
class DhanExecutionRouter:
    """Dhan execution router composing the genuine DhanV2Client
    (no silent Angel One fallback — AUDIT-FIX L-1)."""

    def __init__(self, client_id: str = "", access_token: str = ""):
        from core.broker_oms import DhanV2Client  # local import: avoid circularity
        self.dhan = DhanV2Client(client_id, access_token)

    def route_basket_execution(self, weights: dict, portfolio_value: float,
                               dry_run: bool = True, log_cb=None):
        raise NotImplementedError(
            "Dhan live routing is intentionally NOT aliased to Angel One "
            "(audit L-1). Wire DhanV2Client order placement here before "
            "enabling Dhan live trading."
        )


# Backward-compatibility aliases (generic router names only — Dhan and
# Angel One adapters/routers stay distinct per audit L-1)
BrokerExecutionRouter = AngelOneExecutionRouter
BrokerRouter = AngelOneExecutionRouter

__all__ = [
    "FIXProtocolAdapter",
    "AngelOneTokenLookup",
    "AngelOneAdapter",
    "AngelOneExecutionRouter",
    "DhanAdapter",
    "DhanExecutionRouter",
    "BrokerExecutionRouter",
    "BrokerRouter",
]

