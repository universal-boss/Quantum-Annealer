"""
math_engine/chaos_lyapunov.py
==============================
Largest Lyapunov Exponent Chaos & Phase-Space Reconstruction Engine.

Estimates Largest Lyapunov Exponent (lambda_1 > 0 indicates deterministic chaos vs stochastic noise)
using Rosenstein's phase-space reconstruction method.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any

logger = logging.getLogger(__name__)


class ChaosLyapunovEngine:
    """
    Largest Lyapunov Exponent (LLE) Deterministic Chaos Detector.
    """

    @staticmethod
    def estimate_lyapunov_exponent(series: pd.Series, m: int = 3, tau: int = 1) -> Dict[str, Any]:
        """
        Estimates Largest Lyapunov Exponent lambda_1.
        lambda_1 > 0 -> Deterministic Chaotic Regime (Sensitive dependence on initial conditions).
        """
        x = series.dropna().values
        n = len(x)
        if n < (m * tau + 20):
            return {"largest_lyapunov_exponent": 0.0, "is_chaotic_regime": False}

        # Reconstruct phase-space delay vectors Y_i = (x_i, x_{i+tau}, ..., x_{i+(m-1)tau})
        n_vectors = n - (m - 1) * tau
        y = np.zeros((n_vectors, m))
        for i in range(n_vectors):
            y[i] = [x[i + j * tau] for j in range(m)]

        # Find nearest neighbor for each vector Y_i (excluding temporal neighbors)
        dists = []
        for i in range(min(50, n_vectors - 5)):
            distances = np.linalg.norm(y - y[i], axis=1)
            distances[max(0, i - 5):min(n_vectors, i + 6)] = np.inf
            nearest_idx = np.argmin(distances)
            d0 = distances[nearest_idx]
            if d0 > 1e-9 and (i + 5) < n_vectors and (nearest_idx + 5) < n_vectors:
                d5 = np.linalg.norm(y[i + 5] - y[nearest_idx + 5])
                if d5 > 0:
                    dists.append(np.log(d5 / d0))

        lle = float(np.mean(dists) / 5.0) if dists else 0.0

        return {
            "largest_lyapunov_exponent": round(lle, 4),
            "is_chaotic_regime": bool(lle > 0.05),
            "embedding_dimension_m": m
        }
