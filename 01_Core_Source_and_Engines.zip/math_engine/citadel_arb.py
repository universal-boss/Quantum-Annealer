"""
math_engine/citadel_arb.py
==========================
Pillar 4: Citadel & Millennium Statistical Arbitrage & Multi-Manager Pod Risk Engine.
Implements:
1. Ornstein-Uhlenbeck (OU) Cointegration Statistical Arbitrage Engine with Half-Life & Z-Score signals.
2. Multi-Manager "Pod Shop" Risk Governance (Gross/Net Leverage, Beta Neutrality, Drawdown Circuit Breakers).
3. High-Frequency Avellaneda-Stoikov Inventory Skew & Reservation Price Quoting Engine.
"""
from __future__ import annotations

import logging
from typing import Dict, List, Tuple, Optional, Any, Union
import numpy as np
import pandas as pd
from scipy import stats

logger = logging.getLogger(__name__)


class CitadelArbEngine:
    """Citadel & Millennium style statistical arbitrage and multi-manager pod risk engine."""

    @classmethod
    def fit_ornstein_uhlenbeck_spread(
        cls,
        price_series_y: Union[pd.Series, np.ndarray],
        price_series_x: Union[pd.Series, np.ndarray],
        dt: float = 1.0
    ) -> Dict[str, Any]:
        """
        Ornstein-Uhlenbeck (OU) Mean-Reverting Spread Estimator:
        Spread_t = Y_t - beta * X_t
        d S_t = theta * (mu - S_t) dt + sigma dW_t
        Half-life: tau = ln(2) / theta
        """
        y = np.asarray(price_series_y, dtype=float)
        x = np.asarray(price_series_x, dtype=float)
        n = min(len(y), len(x))
        if n < 10:
            return {"half_life_days": 10.0, "current_z_score": 0.0, "signal": "HOLD"}
        y, x = y[-n:], x[-n:]

        # 1. Cointegration Hedge Ratio (OLS)
        slope, intercept, r_val, p_val, _ = stats.linregress(x, y)
        spread = y - (slope * x + intercept)

        # 2. AR(1) representation for OU process: S_t = a * S_{t-1} + b + eps
        s_t = spread[1:]
        s_prev = spread[:-1]
        a, b, _, _, _ = stats.linregress(s_prev, s_t)

        # theta = -ln(a) / dt
        if 0.0 < a < 1.0:
            theta = -float(np.log(a) / dt)
            half_life = float(np.log(2.0) / max(theta, 1e-4))
            ou_mu = float(b / (1.0 - a))
            residuals = s_t - (a * s_prev + b)
            ou_sigma = float(np.std(residuals) / np.sqrt(dt))
        else:
            theta = 0.05
            half_life = 14.0
            ou_mu = float(np.mean(spread))
            ou_sigma = float(np.std(spread))

        # Current Z-Score of the spread
        spread_std = max(np.std(spread), 1e-6)
        current_z = float((spread[-1] - np.mean(spread)) / spread_std)

        # Multi-threshold Stat-Arb Signals
        if current_z >= 2.0:
            signal = "SHORT_SPREAD (Short Y, Long X)"
        elif current_z <= -2.0:
            signal = "LONG_SPREAD (Long Y, Short X)"
        elif abs(current_z) <= 0.5:
            signal = "CLOSE_EXIT"
        else:
            signal = "NEUTRAL"

        return {
            "hedge_ratio_beta": round(float(slope), 4),
            "correlation_r2": round(float(r_val ** 2), 4),
            "ou_mean_reversion_speed_theta": round(theta, 4),
            "half_life_days": round(half_life, 2),
            "current_z_score": round(current_z, 2),
            "stat_arb_signal": signal
        }

    @classmethod
    def evaluate_pod_shop_risk_governance(
        cls,
        long_exposure_inr: float,
        short_exposure_inr: float,
        portfolio_equity_inr: float,
        portfolio_beta: float,
        trailing_drawdown_pct: float,
        max_gross_leverage: float = 3.0,
        max_net_beta: float = 0.10,
        soft_stop_drawdown_pct: float = -5.0,
        hard_stop_drawdown_pct: float = -8.0
    ) -> Dict[str, Any]:
        """
        Millennium & Citadel Pod-Shop Risk Engine:
        - Gross Leverage = (Long + Short) / Equity <= max_gross_leverage
        - Net Exposure = (Long - Short) / Equity
        - Beta-Neutrality: |Net_Beta| <= max_net_beta
        - Multi-Tier Drawdown Halts
        """
        equity = max(float(portfolio_equity_inr), 1.0)
        long_exp = float(long_exposure_inr)
        short_exp = float(short_exposure_inr)

        gross_exp = long_exp + short_exp
        net_exp = long_exp - short_exp

        gross_leverage = gross_exp / equity
        net_leverage = net_exp / equity
        net_market_beta = float(portfolio_beta * (net_exp / equity))

        # Risk Rule Violations
        breaches = []
        if gross_leverage > max_gross_leverage:
            breaches.append(f"Gross Leverage Breach: {gross_leverage:.2f}x > {max_gross_leverage:.2f}x limit")
        if abs(net_market_beta) > max_net_beta:
            breaches.append(f"Beta Neutrality Breach: Net Beta={net_market_beta:.2f} outside [{-max_net_beta:.2f}, {max_net_beta:.2f}]")

        # Drawdown Circuit Breakers
        pod_status = "ACTIVE_NORMAL"
        action = "MAINTAIN"

        if trailing_drawdown_pct <= hard_stop_drawdown_pct:
            pod_status = "HARD_HALT_LIQUIDATE"
            action = "EMERGENCY_DE_RISK_100%"
        elif trailing_drawdown_pct <= soft_stop_drawdown_pct:
            pod_status = "SOFT_DE_LEVERAGE"
            action = "CUT_GROSS_EXPOSURE_50%"

        return {
            "gross_leverage_ratio": round(gross_leverage, 2),
            "net_leverage_ratio": round(net_leverage, 2),
            "net_market_beta": round(net_market_beta, 3),
            "trailing_drawdown_%": round(trailing_drawdown_pct, 2),
            "pod_governance_status": pod_status,
            "required_risk_action": action,
            "compliance_breaches": breaches
        }

    @classmethod
    def compute_avellaneda_stoikov_quotes(
        cls,
        mid_price: float,
        inventory_q: float,
        volatility_sigma: float,
        gamma_risk_aversion: float = 0.1,
        kappa_order_intensity: float = 1.5,
        time_horizon_t: float = 1.0
    ) -> Dict[str, float]:
        """
        Avellaneda-Stoikov High-Frequency Market Making Reservation Model:
        - Reservation Price: r(s, q, t) = s - q * gamma * sigma^2 * (T - t)
        - Optimal Spread: delta^a + delta^b = gamma * sigma^2 + 2/gamma * ln(1 + gamma/kappa)
        - Ask Quote: r + delta^a, Bid Quote: r - delta^b
        """
        s = float(mid_price)
        q = float(inventory_q)
        sigma = float(volatility_sigma)
        gamma = float(gamma_risk_aversion)
        kappa = float(kappa_order_intensity)
        T = float(time_horizon_t)

        # 1. Reservation Price (inventory skew)
        r_price = s - q * gamma * (sigma ** 2) * T

        # 2. Optimal Half-Spread
        half_spread = 0.5 * (gamma * (sigma ** 2) * T + (2.0 / gamma) * np.log(1.0 + gamma / max(kappa, 1e-4)))

        bid_quote = r_price - half_spread
        ask_quote = r_price + half_spread

        return {
            "mid_price": round(s, 2),
            "inventory_units": q,
            "reservation_price": round(r_price, 2),
            "optimal_bid_quote": round(bid_quote, 2),
            "optimal_ask_quote": round(ask_quote, 2),
            "quoted_spread_bps": round(((ask_quote - bid_quote) / s) * 10000.0, 1)
        }
