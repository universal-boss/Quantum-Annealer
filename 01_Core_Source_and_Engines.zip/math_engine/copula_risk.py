"""
math_engine/copula_risk.py
==========================
Copula tail risk stress-testing engine.
Simulates joint asset dependency tails during market crashes using Archimedean copulas (Clayton/Gumbel)
to model non-linear correlation increases.

AUDIT-FIX (Round 8, math residual — Part 2B): honesty note — the dependency
structure is Archimedean (single-parameter Clayton), NOT a vine copula (the
previous title claimed "Vine Copula"); and the simulator is now SEEDED by
default (deterministic, reproducible risk numbers — previously every call
redrew global-RNG samples, so reported VaR/ES numbers moved run-to-run).
"""
from __future__ import annotations

import logging
from typing import Dict, Any, List, Tuple
import numpy as np
from scipy.stats import rankdata, norm

logger = logging.getLogger(__name__)


class CopulaTailRiskScreener:
    """Simulates tail-risk scenarios using Archimedean copula structures."""

    @staticmethod
    def simulate_clayton_copula(
        n_samples: int,
        n_assets: int,
        theta: float = 2.0,
        seed: int | None = 42,
    ) -> np.ndarray:
        """Simulates Uniform marginal samples from a Clayton Copula.
        
        Clayton Copula models asymmetric LEFT-tail dependence (joint crashes).
        Parameter theta > 0 regulates the strength of tail dependence.
        Uses Marshall-Olkin algorithm for Archimedean copula generation.

        AUDIT-FIX (Round 8, math residual — Part 2B): `seed` parameter added
        (default 42, deterministic); pass seed=None for live randomized draws.
        """
        rng = np.random.default_rng(seed)
        if theta <= 0:
            # Independent Uniforms
            return rng.uniform(0, 1, (n_samples, n_assets))

        # 1. Sample Gamma variables: t ~ Gamma(shape=1/theta, scale=1)
        t = np.maximum(rng.gamma(shape=1.0 / theta, scale=1.0, size=n_samples), 1e-9)
        
        # 2. Sample independent Uniforms for each asset (clipped to avoid log(0) -inf)
        u = np.clip(rng.uniform(0, 1, (n_samples, n_assets)), 1e-9, 1.0 - 1e-9)
        
        # 3. Apply Clayton inverse generator transform
        t_expanded = t[:, np.newaxis]
        copula_samples = (1.0 - np.log(u) / t_expanded) ** (-1.0 / theta)
        
        return copula_samples

    @classmethod
    def stress_test_portfolio_tail_risk(
        cls,
        historical_returns: np.ndarray,   # shape: (S, N)
        weights: np.ndarray,              # shape: (N,)
        theta: float = 2.5,               # Left-tail dependence strength
        n_simulations: int = 5000,
        seed: int | None = 42,            # AUDIT-FIX (Round 8): reproducible by default
    ) -> Dict[str, float]:
        """Runs copula-simulated stress tests on the portfolio.
        
        Maps Clayton copula uniform samples to empirical return distributions
        to evaluate tail loss scenarios during joint asset crashes.
        """
        S, N = historical_returns.shape
        if S < 10 or N == 0:
            # ROUND 45 FIX: insufficient history previously returned hard 0.0
            # for every metric — a fabricated "no tail risk" for 6-9 day
            # histories. Now returns None markers plus an explicit flag so
            # callers can distinguish "insufficient data" from a true zero.
            return {
                "mean_loss": None,
                "value_at_risk_99": None,
                "stress_scenario_expected_shortfall_95": None,
                "insufficient_history": True,
            }

        # 1. Simulate joint tail dependencies (Clayton Uniforms)
        u_sim = cls.simulate_clayton_copula(n_samples=n_simulations, n_assets=N, theta=theta, seed=seed)

        # 2. Map Uniform marginals to empirical distributions using quantile lookup
        simulated_returns = np.zeros((n_simulations, N))
        for i in range(N):
            asset_rets = historical_returns[:, i]
            # Empirical Quantile function: lookup sorted returns
            sorted_rets = np.sort(asset_rets)
            # Clip index to valid bounds
            indices = np.clip(np.floor(u_sim[:, i] * S).astype(int), 0, S - 1)
            simulated_returns[:, i] = sorted_rets[indices]

        # 3. Calculate portfolio returns under stress scenario
        portfolio_sim_returns = simulated_returns @ weights
        portfolio_sim_losses = -portfolio_sim_returns

        # 4. Extract tail risk metrics
        mean_loss = float(portfolio_sim_losses.mean())
        var_95 = float(np.percentile(portfolio_sim_losses, 95))
        var_99 = float(np.percentile(portfolio_sim_losses, 99))
        
        # Expected Shortfall (CVaR) at 95%
        es_95_mask = portfolio_sim_losses >= var_95
        es_95 = float(portfolio_sim_losses[es_95_mask].mean()) if es_95_mask.any() else var_95

        return {
            "stress_scenario_mean_loss": mean_loss,
            "stress_scenario_var_95": var_95,
            "stress_scenario_var_99": var_99,
            "stress_scenario_expected_shortfall_95": es_95
        }

    @classmethod
    def evaluate_portfolio_tail_risk(
        cls,
        historical_returns: np.ndarray,
        weights: np.ndarray = None,
        theta: float = 2.5,
        n_simulations: int = 5000
    ) -> Dict[str, float]:
        """Convenience wrapper for tail risk evaluation with optional weights."""
        if weights is None:
            N = historical_returns.shape[1] if (historical_returns is not None and historical_returns.ndim > 1) else 1
            weights = np.ones(N) / max(1, N)
        return cls.stress_test_portfolio_tail_risk(historical_returns, weights, theta, n_simulations)
