"""
math_engine/copula_tail_dependence.py
=====================================
Copula Tail Dependence & Asymmetric Co-Movement Engine.

Computes non-parametric empirical lower tail dependence (lambda_L = P(U <= q | V <= q))
and upper tail dependence (lambda_U = P(U >= 1-q | V >= 1-q)) to measure asymmetric
downside crash correlation vs upside rally co-movement across portfolio assets.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any

logger = logging.getLogger(__name__)


class CopulaTailDependenceEngine:
    """
    Clayton & Gumbel Copula Lower/Upper Tail Dependence Calculator.
    """

    @staticmethod
    def estimate_tail_dependence(returns_df: pd.DataFrame, quantile_threshold: float = 0.05) -> Dict[str, Any]:
        """
        Calculates lower tail dependence lambda_L = P(U <= q | V <= q) and upper tail dependence lambda_U.
        """
        if returns_df is None or returns_df.empty or returns_df.shape[1] < 2:
            return {"lower_tail_dependence_lambda_L": 0.0, "upper_tail_dependence_lambda_U": 0.0, "is_asymmetric_crash_risk": False}

        clean_ret = returns_df.dropna().values
        if clean_ret.shape[0] < 20 or clean_ret.shape[1] < 2:
            return {"lower_tail_dependence_lambda_L": 0.0, "upper_tail_dependence_lambda_U": 0.0, "is_asymmetric_crash_risk": False}

        # Convert to uniform pseudo-observations via rank transform
        ranks = np.argsort(np.argsort(clean_ret, axis=0), axis=0) / (clean_ret.shape[0] + 1.0)
        
        # AUDIT-FIX (Round 6, A1-P2-7): the estimator previously read ONLY
        # columns 0 and 1 of the returns frame, but the optimizer passes the
        # full 10-15-ticker clean_returns — the reported portfolio tail
        # dependence was whatever the first two alphabetical tickers
        # happened to show. Average the pairwise lambdas over ALL column
        # pairs (portfolio-level crash coupling) with the same estimator.
        import itertools as _it
        _cols = range(ranks.shape[1]) if ranks.shape[1] >= 2 else [(0, 0)]
        _lows, _ups = [], []
        upper_q = 1.0 - quantile_threshold
        for c1, c2 in (_it.combinations(_cols, 2) if ranks.shape[1] >= 2 else [(0, 0)]):
            u1, u2 = ranks[:, c1], ranks[:, c2]
            lower_mask = (u1 <= quantile_threshold) & (u2 <= quantile_threshold)
            _lows.append(float(np.sum(lower_mask) / (np.sum(u1 <= quantile_threshold) + 1e-9)))
            upper_mask = (u1 >= upper_q) & (u2 >= upper_q)
            _ups.append(float(np.sum(upper_mask) / (np.sum(u1 >= upper_q) + 1e-9)))
        lambda_L = float(np.mean(_lows)) if _lows else 0.0
        lambda_U = float(np.mean(_ups)) if _ups else 0.0

        return {
            "lower_tail_dependence_lambda_L": round(min(max(lambda_L, 0.0), 1.0), 4),
            "upper_tail_dependence_lambda_U": round(min(max(lambda_U, 0.0), 1.0), 4),
            "is_asymmetric_crash_risk": bool(lambda_L > lambda_U + 0.15)
        }


# Non-parametric empirical estimator alias
EmpiricalTailDependenceEngine = CopulaTailDependenceEngine
