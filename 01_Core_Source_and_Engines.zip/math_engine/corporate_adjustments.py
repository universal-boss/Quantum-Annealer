"""
math_engine/corporate_adjustments.py
======================================
CRSP-compliant local corporate actions adjustment engine.
Adjusts historical price and volume series dynamically to prevent look-ahead bias and split anomalies.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Any

logger = logging.getLogger(__name__)


class CorporateActionsAdjuster:
    """Applies retroactive price and volume adjustments to historical market data
    for splits, bonus issues, and dividends, using CRSP-compliant formulas.
    """

    @staticmethod
    def adjust_prices_pit(
        raw_df: pd.DataFrame,
        corporate_actions: pd.DataFrame | List[Dict[str, Any]],
        as_of_date: pd.Timestamp | str
    ) -> pd.DataFrame:
        """Adjusts historical OHLCV DataFrame for a single asset up to as_of_date.

        Parameters
        ----------
        raw_df : pd.DataFrame
            Unadjusted OHLCV data. Index must be DatetimeIndex.
            Columns must include 'Open', 'High', 'Low', 'Close', 'Volume'.
        corporate_actions : pd.DataFrame or list of dicts
            Corporate action records with keys/columns:
                'ex_date'     : Date when action took effect (str or Timestamp)
                'type'        : 'SPLIT', 'BONUS', or 'DIVIDEND'
                'ratio'       : Split/bonus ratio (new_shares / old_shares). E.g. 2.0 for 2-for-1 split.
                'amount'      : Cash dividend amount per share (float).
                'publish_date': Date the action was officially announced/publicly known.
        as_of_date : Timestamp or str
            The point-in-time date. Actions published after this date are ignored.

        Returns
        -------
        pd.DataFrame
            Adjusted OHLCV DataFrame.
        """
        if raw_df.empty:
            return raw_df.copy()

        # Copy raw data and ensure float types for calculations
        adj_df = raw_df.copy()
        for col in ["Open", "High", "Low", "Close", "Volume"]:
            if col in adj_df.columns:
                adj_df[col] = adj_df[col].astype(float)

        # Convert corporate actions to DataFrame
        if isinstance(corporate_actions, list):
            ca_df = pd.DataFrame(corporate_actions)
        else:
            ca_df = corporate_actions.copy()

        if ca_df.empty:
            return adj_df

        # Standardize columns
        ca_df.columns = [c.lower() for c in ca_df.columns]
        if "ex_date" not in ca_df.columns or "type" not in ca_df.columns:
            return adj_df

        # Filter by publish_date to prevent look-ahead bias
        as_of = pd.to_datetime(as_of_date).normalize()
        if "publish_date" in ca_df.columns:
            ca_df["publish_date"] = pd.to_datetime(ca_df["publish_date"]).dt.normalize()
            ca_df = ca_df[ca_df["publish_date"] <= as_of]

        if ca_df.empty:
            return adj_df

        ca_df["ex_date"] = pd.to_datetime(ca_df["ex_date"]).dt.normalize()
        ca_df = ca_df[ca_df["ex_date"] <= as_of]

        # Sort actions in reverse chronological order (latest first) to compound retroactively
        ca_df = ca_df.sort_values(by="ex_date", ascending=False)

        # Phase 6.2: Track cumulative split factor for dividend adjustment.
        # When processing in reverse chronological order, a split is applied first
        # (dividing historical prices). Then when a dividend is processed, the
        # pre_ex_close is already SPLIT-ADJUSTED but the dividend amount is raw
        # nominal. The CRSP factor 1 - (amount / pre_ex_close) is computed with
        # mismatched units — wrong by a factor of the split ratio.
        # Fix: track cum_split_factor and divide the dividend amount by it.
        cum_split_factor = 1.0

        for _, action in ca_df.iterrows():
            ex_date = action["ex_date"]
            act_type = str(action["type"]).upper()

            # Locate the pre-ex closing price date
            pre_ex_idx = adj_df.index[adj_df.index < ex_date]
            if len(pre_ex_idx) == 0:
                continue
            pre_ex_date = pre_ex_idx[-1]

            if act_type in ("SPLIT", "BONUS"):
                # Phase 6.2a: Handle ratio as string ("2:1") or float (2.0)
                ratio_raw = action.get("ratio", 1.0)
                try:
                    if isinstance(ratio_raw, str):
                        import re
                        parts = re.split(r'[:\-]', ratio_raw.strip())
                        if len(parts) == 2 and float(parts[1]) != 0:
                            x, y = float(parts[0]), float(parts[1])
                            # BUGFIX (Round 41 / Claude Audit §5s): "X:Y" means something
                            # different for SPLIT vs BONUS notation. For a SPLIT, "X:Y" (e.g. "2:1")
                            # states the new-to-old ratio (2-for-1 -> multiplier = X/Y = 2.0).
                            # For a BONUS, Indian market convention states "X:Y" as "X additional
                            # shares issued per Y held" — a "1:1" bonus means 1 extra share per 1 held,
                            # so 1 share becomes 1+1=2 total, i.e. share-count multiplier is (X+Y)/Y = 2.0,
                            # NOT X/Y = 1.0. The old code used X/Y for both cases, so a "1:1" bonus
                            # parsed to ratio=1.0 and was skipped entirely via the `ratio == 1.0` guard.
                            if act_type == "BONUS":
                                ratio = (x + y) / y
                            else:
                                ratio = x / y
                        else:
                            ratio = float(ratio_raw)
                    else:
                        ratio = float(ratio_raw)
                except (ValueError, TypeError):
                    logger.warning("Could not parse ratio '%s' — skipping action", ratio_raw)
                    continue

                if ratio <= 0.0 or ratio == 1.0 or pd.isna(ratio):
                    continue

                # Retroactive adjustment: divide historical prices by ratio, multiply volume by ratio
                mask = adj_df.index <= pre_ex_date
                for col in ["Open", "High", "Low", "Close"]:
                    if col in adj_df.columns:
                        adj_df.loc[mask, col] /= ratio
                if "Volume" in adj_df.columns:
                    adj_df.loc[mask, "Volume"] *= ratio

                # Phase 6.2: Track cumulative split factor for dividend adjustment
                cum_split_factor *= ratio

                logger.debug(f"Applied retroactive SPLIT adjustment (ratio={ratio}, cum_split={cum_split_factor}) on index <= {pre_ex_date}")

            elif act_type == "DIVIDEND":
                amount = float(action.get("amount", 0.0))
                if amount <= 0.0 or pd.isna(amount):
                    continue

                # Phase 6.2: Split-adjust the dividend amount.
                # The pre_ex_close is already split-adjusted (prices were divided by
                # cum_split_factor). The dividend amount is raw nominal. To make the
                # CRSP factor consistent, divide amount by cum_split_factor.
                adjusted_amount = amount / cum_split_factor if cum_split_factor > 0 else amount

                # Get pre-ex Close price (already split-adjusted from prior actions)
                pre_ex_close = adj_df.loc[pre_ex_date, "Close"]
                if pd.isna(pre_ex_close) or pre_ex_close <= 0.0:
                    continue

                # CRSP Multiplier: 1 - (Adjusted Dividend / Pre-ex Close)
                factor = 1.0 - (adjusted_amount / pre_ex_close)
                if factor <= 0.0:
                    logger.warning("Dividend amount %.2f (adjusted %.2f) exceeds pre-ex close %.2f for action on %s — adjustment skipped", amount, adjusted_amount, pre_ex_close, ex_date)
                    continue
                if factor >= 1.0:
                    continue

                # Retroactive adjustment: multiply historical prices by factor
                mask = adj_df.index <= pre_ex_date
                for col in ["Open", "High", "Low", "Close"]:
                    if col in adj_df.columns:
                        adj_df.loc[mask, col] *= factor

                logger.debug(f"Applied retroactive DIVIDEND adjustment (amount={amount}, adjusted={adjusted_amount:.4f}, factor={factor:.4f}) on index <= {pre_ex_date}")

        # Final safety check: clip prices to prevent negative values
        for col in ["Open", "High", "Low", "Close"]:
            if col in adj_df.columns:
                adj_df[col] = np.clip(adj_df[col], 1e-4, None)

        return adj_df


# Backward compatibility alias
CorporateActionsPITAdjuster = CorporateActionsAdjuster
