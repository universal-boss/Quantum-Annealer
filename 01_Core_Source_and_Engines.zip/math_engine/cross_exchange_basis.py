"""
math_engine/cross_exchange_basis.py
===================================
Cross-Exchange Pair & Cash Arbitrage Engine (NSE vs BSE).

Calculates price discrepancies, bid-ask spread boundaries, and 
cross-exchange basis opportunities between NSE and BSE listings net of transaction costs.
"""

from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, Tuple

logger = logging.getLogger(__name__)


class CrossExchangeArbitrageEngine:
    """
    Cross-Exchange Cash Basis & Arbitrage Engine.
    Identifies price discrepancies between NSE and BSE listings.
    """

    @staticmethod
    def calculate_cross_exchange_basis(
        price_nse: float,
        price_bse: float,
        transaction_cost_bps: float = 10.0
    ) -> Dict[str, float]:
        """
        Calculates net cross-exchange basis:
        Basis_bps = ((Price_BSE - Price_NSE) / Price_NSE) * 10,000 - Total_Costs_bps
        """
        if price_nse <= 0 or price_bse <= 0:
            return {"gross_basis_bps": 0.0, "net_basis_bps": 0.0, "is_actionable": False}

        gross_basis_pct = (price_bse - price_nse) / price_nse
        gross_basis_bps = gross_basis_pct * 10000.0
        
        # Round-trip cost: STT, exchange turnover fees, SEBI charges (~10 bps total)
        total_costs_bps = transaction_cost_bps * 2.0
        net_basis_bps = abs(gross_basis_bps) - total_costs_bps

        is_actionable = net_basis_bps > 0.0

        return {
            "gross_basis_bps": float(round(gross_basis_bps, 2)),
            "net_basis_bps": float(round(max(0.0, net_basis_bps), 2)),
            "is_actionable": bool(is_actionable),
            "trade_direction": "BUY_NSE_SELL_BSE" if gross_basis_bps > 0 else "BUY_BSE_SELL_NSE"
        }
