"""
math_engine/cvar_optim.py
=========================
Rockafellar-Uryasev CVaR LP Minimization — institutional-grade tail risk optimizer.

Reference: Rockafellar & Uryasev (2000), "Optimization of Conditional Value-at-Risk",
Journal of Risk, 2(3), 21-42.

Unlike `compute_var_cvar` (which is monitoring-only), this module OPTIMISES the
portfolio weights to MINIMISE tail risk. The formulation is a Linear Program:

    min_{w, α, u}   α + 1/((1-β)·S) · Σ u_s
    subject to:
        u_s  ≥  L_s(w) - α        ∀ s = 1..S scenarios
        u_s  ≥  0
        Σ w_i = 1
        w_i  ≥  w_min             (long-only by default)
        w_i  ≤  w_max             (concentration limit)

where L_s(w) = -r_s·w is the portfolio loss in scenario s.

Solvers used (in priority order)
---------------------------------
1. cvxpy + ECOS   (free, academic-grade, works offline)
2. cvxpy + SCS    (fallback, slightly less accurate for LP)
3. scipy.optimize.linprog  (pure-scipy fallback, no cvxpy required)
4. 1/N equal weights  (last resort — always available)

Usage
-----
    from math_engine.cvar_optim import minimize_cvar_portfolio

    w_opt = minimize_cvar_portfolio(
        returns=clean_returns[selected],   # (T × N) DataFrame
        beta=0.95,                         # confidence level
        max_w=0.15,                        # per-stock concentration cap
        min_w=0.0,                         # long-only
    )
    weights = {t: float(w) for t, w in zip(selected, w_opt)}

cfg key
-------
    USE_CVAR_LP : bool  (default False — opt-in)
        When True, inserted AFTER HRP/MDP/BL in run_optimizer_logic as the
        final weight step, so it polishes weights already satisfying SEBI/QUBO.

    CVAR_BETA       : float  (default 0.95) — tail confidence level
    CVAR_MIN_WEIGHT : float  (default 0.0)  — minimum per-asset weight
    CVAR_MAX_WEIGHT : float  — defaults to working_cfg["MAX_WEIGHT"]
"""

from __future__ import annotations

import logging
import math
import numpy as np
import pandas as pd
from typing import Optional, Dict, Any

logger = logging.getLogger("quantum_annealer.cvar_optim")


# ─── Primary solver: cvxpy LP ────────────────────────────────────────────────

def _minimize_cvar_cvxpy(returns_mat: np.ndarray,
                         beta: float,
                         min_w: float,
                         max_w: float) -> Optional[np.ndarray]:
    """
    Rockafellar-Uryasev CVaR LP via cvxpy.

    Parameters
    ----------
    returns_mat : (S × N) scenario × asset returns matrix
    beta        : confidence level (e.g. 0.95)
    min_w, max_w: per-asset bounds

    Returns
    -------
    w : (N,) optimal weights, or None if solve failed
    """
    try:
        import cvxpy as cp
    except ImportError:
        logger.debug("[CVaR-LP] cvxpy not available; falling back to scipy")
        return None

    S, N = returns_mat.shape
    w = cp.Variable(N, name="weights")
    alpha = cp.Variable(name="VaR_threshold")          # Value-at-Risk threshold α
    u = cp.Variable(S, nonneg=True, name="excess_loss") # CVaR slack variables

    losses = -returns_mat @ w   # (S,) portfolio loss per scenario

    cvar_objective = alpha + (1.0 / ((1.0 - beta) * S)) * cp.sum(u)
    constraints = [
        u >= losses - alpha,
        cp.sum(w) == 1.0,
        w >= min_w,
        w <= max_w,
    ]

    prob = cp.Problem(cp.Minimize(cvar_objective), constraints)

    # Try ECOS first (fast LP solver), then SCS
    for solver in [cp.ECOS, cp.SCS]:
        try:
            prob.solve(solver=solver, verbose=False)
            if prob.status in ("optimal", "optimal_inaccurate") and w.value is not None:
                w_val = np.array(w.value, dtype=float)
                # Project to feasible set (handle tiny numerical violations)
                w_val = np.clip(w_val, min_w, max_w)
                w_sum = w_val.sum()
                if w_sum > 1e-9:
                    w_val /= w_sum
                    return w_val
        except Exception as _e:
            logger.debug(f"[CVaR-LP] {solver} failed: {_e}")
            continue

    return None


# ─── Fallback solver: scipy linprog ──────────────────────────────────────────

def _minimize_cvar_scipy(returns_mat: np.ndarray,
                         beta: float,
                         min_w: float,
                         max_w: float) -> Optional[np.ndarray]:
    """
    Rockafellar-Uryasev CVaR LP reformulated for scipy.optimize.linprog.

    Decision variable layout: x = [w (N), alpha (1), u (S)]
    Objective: minimize  alpha + 1/((1-beta)*S) * sum(u)

    Standard form Ax ≤ b constraints:
        u_s - r_s @ w + alpha ≥ 0  →  r_s @ w - alpha - u_s ≤ 0
    """
    try:
        from scipy.optimize import linprog
    except ImportError:
        return None

    S, N = returns_mat.shape
    scale = 1.0 / ((1.0 - beta) * S)

    # Objective coefficients: [w: 0, alpha: 1, u: scale*ones]
    c = np.concatenate([np.zeros(N), [1.0], scale * np.ones(S)])

    # Inequality: loss_s - alpha - u_s ≤ 0
    # loss_s = -returns_mat[s] @ w, so:  -returns_mat[s] @ w - alpha - u_s ≤ 0
    # Row s:  [-returns_mat[s, :], -1, -e_s]  where e_s = unit vector at position s
    A_ub_w = -returns_mat                                         # (S, N)
    A_ub_alpha = -np.ones((S, 1))                                 # (S, 1)
    A_ub_u = -np.eye(S)                                           # (S, S)
    A_ub = np.hstack([A_ub_w, A_ub_alpha, A_ub_u])               # (S, N+1+S)
    b_ub = np.zeros(S)

    # Equality: sum(w) = 1  →  [ones(N), 0, zeros(S)] @ x = 1
    A_eq = np.hstack([np.ones((1, N)), [[0.0]], np.zeros((1, S))])
    b_eq = np.array([1.0])

    # Bounds: w in [min_w, max_w], alpha free, u ≥ 0
    bounds = (
        [(min_w, max_w)] * N +     # w
        [(None, None)] +            # alpha (VaR)
        [(0.0, None)] * S           # u
    )

    res = linprog(c, A_ub=A_ub, b_ub=b_ub, A_eq=A_eq, b_eq=b_eq,
                  bounds=bounds, method="highs")

    if res.success and res.x is not None:
        w_val = np.clip(res.x[:N], min_w, max_w)
        w_sum = w_val.sum()
        if w_sum > 1e-9:
            return w_val / w_sum
    return None


# ─── Public API ────────────────────────────────────────────────────────────────

def minimize_cvar_portfolio(returns: pd.DataFrame,
                            beta: float = 0.95,
                            max_w: float = 0.15,
                            min_w: float = 0.0,
                            cfg: Optional[dict] = None) -> np.ndarray:
    """
    Minimize portfolio CVaR at confidence level beta via LP.

    Parameters
    ----------
    returns : (T × N) DataFrame of daily returns
    beta    : CVaR confidence level (default 0.95 = 95th-percentile tail)
    max_w   : maximum per-asset weight (default 0.15 = 15%)
    min_w   : minimum per-asset weight (default 0.0  = long-only)
    cfg     : optional cfg dict (may override DCC_BETA, CVAR_BETA, etc.)

    Returns
    -------
    w_opt : (N,) ndarray of optimal weights summing to 1.0
    """
    cfg = cfg or {}
    beta = float(cfg.get("CVAR_BETA", beta))
    min_w = float(cfg.get("CVAR_MIN_WEIGHT", min_w))
    max_w = float(cfg.get("CVAR_MAX_WEIGHT", max_w))

    N = len(returns.columns)
    equal_w = np.ones(N, dtype=float) / N

    if returns is None or returns.empty or N < 2:
        return equal_w

    # Clean: drop rows with all-NaN, fill remaining NaN with 0
    clean = returns.dropna(how="all").fillna(0.0)
    S, N = clean.shape

    if S < 30:
        logger.warning(
            f"[CVaR-LP] Only {S} scenarios available (need ≥30). "
            "Returning equal weights."
        )
        return equal_w

    # Clamp bounds for feasibility: min_w ≤ 1/N ≤ max_w (required for LP)
    min_w = min(min_w, 1.0 / N)
    max_w = max(max_w, 1.0 / N)

    returns_mat = clean.values  # (S × N) scenario returns

    # Try cvxpy LP → scipy linprog → equal weights
    w_opt = _minimize_cvar_cvxpy(returns_mat, beta, min_w, max_w)
    if w_opt is None:
        logger.info("[CVaR-LP] cvxpy solver failed or unavailable; trying scipy.linprog")
        w_opt = _minimize_cvar_scipy(returns_mat, beta, min_w, max_w)
    if w_opt is None:
        logger.warning("[CVaR-LP] All solvers failed; returning equal weights")
        return equal_w

    # Validate output
    if not np.all(np.isfinite(w_opt)) or abs(w_opt.sum() - 1.0) > 1e-4:
        logger.warning("[CVaR-LP] Output weights invalid; falling back to equal weights")
        return equal_w

    logger.info(
        f"[CVaR-LP] Optimized CVaR@{int(beta*100)}% over {S} scenarios × {N} assets. "
        f"Max weight={float(w_opt.max())*100:.1f}%"
    )
    return w_opt


def cvar_risk_metrics(weights: np.ndarray,
                      returns: pd.DataFrame,
                      beta: float = 0.95,
                      portfolio_value: float = 1_000_000.0) -> Dict[str, Any]:
    """
    Post-optimization CVaR diagnostics: compute CVaR and VaR of the LP-optimized portfolio.

    Returns
    -------
    dict with keys:
        portfolio_cvar_pct   : float — CVaR as % of portfolio
        portfolio_var_pct    : float — VaR (beta-quantile loss) as % of portfolio
        portfolio_cvar_inr   : float — CVaR in INR
        portfolio_var_inr    : float — VaR in INR
        beta                 : float — confidence level used
        n_scenarios          : int   — number of historical scenarios
    """
    clean = returns.dropna(how="all").fillna(0.0)
    S = len(clean)
    if S == 0:
        return {"portfolio_cvar_pct": float("nan")}

    w = np.array(weights, dtype=float)
    port_ret = clean.values @ w  # (S,) portfolio returns per scenario

    # Historical VaR and CVaR
    var_threshold = float(np.percentile(port_ret, (1.0 - beta) * 100))
    tail_losses = -port_ret[port_ret <= var_threshold]
    cvar = float(tail_losses.mean()) if len(tail_losses) > 0 else float(-var_threshold)
    var_val = float(-var_threshold)

    return {
        "portfolio_cvar_pct": round(cvar * 100, 3),
        "portfolio_var_pct": round(var_val * 100, 3),
        "portfolio_cvar_inr": round(cvar * portfolio_value, 0),
        "portfolio_var_inr": round(var_val * portfolio_value, 0),
        "beta": beta,
        "n_scenarios": S,
    }
