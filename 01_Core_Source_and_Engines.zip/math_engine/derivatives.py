"""Derivatives integration — options chain, futures basis, Greeks.

Provides:
  1. Options chain analysis — implied vol surface, skew
  2. Futures basis — cash-and-carry arbitrage detection
  3. Greeks calculation — delta, gamma, vega, theta, rho
  4. Volatility trading signals — long/short vol via options

All calculations use Black-Scholes for European options (index options in India
are European-style). Stock options in India are American-style but BS is a
good approximation for at-the-money near-expiry.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Optional
import logging
from math import log, sqrt, exp, pi
from scipy.stats import norm

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════════════
# BLACK-SCHOLES GREEKS
# ═══════════════════════════════════════════════════════════════════════════════

def black_scholes_call(S: float, K: float, T: float, r: float, sigma: float) -> float:
    """Black-Scholes call option price.

    Args:
        S: Underlying price.
        K: Strike price.
        T: Time to expiry (years).
        r: Risk-free rate (annualized).
        sigma: Volatility (annualized).

    Returns:
        Call option price.
    """
    if T <= 0 or sigma <= 0:
        return max(0, S - K)

    d1 = (log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * sqrt(T))
    d2 = d1 - sigma * sqrt(T)

    return S * norm.cdf(d1) - K * exp(-r * T) * norm.cdf(d2)


def black_scholes_put(S: float, K: float, T: float, r: float, sigma: float) -> float:
    """Black-Scholes put option price."""
    if T <= 0 or sigma <= 0:
        return max(0, K - S)

    d1 = (log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * sqrt(T))
    d2 = d1 - sigma * sqrt(T)

    return K * exp(-r * T) * norm.cdf(-d2) - S * norm.cdf(-d1)


def compute_greeks(S: float, K: float, T: float, r: float, sigma: float, option_type: str = "call") -> dict:
    """Compute all Black-Scholes Greeks.

    Returns:
        Dict with delta, gamma, vega, theta, rho.
    """
    if T <= 0 or sigma <= 0:
        return {"delta": 0, "gamma": 0, "vega": 0, "theta": 0, "rho": 0}

    d1 = (log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * sqrt(T))
    d2 = d1 - sigma * sqrt(T)

    # Delta: ∂C/∂S
    if option_type == "call":
        delta = norm.cdf(d1)
    else:
        delta = norm.cdf(d1) - 1

    # Gamma: ∂²C/∂S² (same for call and put)
    gamma = norm.pdf(d1) / (S * sigma * sqrt(T))

    # Vega: ∂C/∂σ (same for call and put, not divided by 100)
    vega = S * norm.pdf(d1) * sqrt(T)

    # Theta: ∂C/∂T (per day, not per year)
    if option_type == "call":
        theta = (-S * norm.pdf(d1) * sigma / (2 * sqrt(T))
                 - r * K * exp(-r * T) * norm.cdf(d2)) / 365
    else:
        theta = (-S * norm.pdf(d1) * sigma / (2 * sqrt(T))
                 + r * K * exp(-r * T) * norm.cdf(-d2)) / 365

    # Rho: ∂C/∂r (per 1% change)
    if option_type == "call":
        rho = K * T * exp(-r * T) * norm.cdf(d2) / 100
    else:
        rho = -K * T * exp(-r * T) * norm.cdf(-d2) / 100

    return {
        "delta": delta,
        "gamma": gamma,
        "vega": vega,
        "theta": theta,
        "rho": rho,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# IMPLIED VOLATILITY
# ═══════════════════════════════════════════════════════════════════════════════

def implied_volatility(
    option_price: float,
    S: float,
    K: float,
    T: float,
    r: float,
    option_type: str = "call",
    method: str = "newton",
    max_iter: int = 100,
    tol: float = 1e-6,
) -> float:
    """Compute implied volatility from option price.

    Uses Newton-Raphson method (fast) or bisection (robust fallback).
    """
    if option_price <= 0 or T <= 0:
        return 0.0

    # Initial guess: 30% vol
    sigma = 0.30

    if method == "newton":
        for _ in range(max_iter):
            try:
                if option_type == "call":
                    price = black_scholes_call(S, K, T, r, sigma)
                else:
                    price = black_scholes_put(S, K, T, r, sigma)

                # Vega is the derivative w.r.t. sigma
                d1 = (log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * sqrt(T))
                vega = S * norm.pdf(d1) * sqrt(T)

                if vega < 1e-9:
                    break

                diff = price - option_price
                if abs(diff) < tol:
                    return sigma

                sigma = sigma - diff / vega
                sigma = max(0.01, min(5.0, sigma))  # clamp
            except Exception:
                break

    # Bisection fallback
    lo, hi = 0.01, 5.0
    for _ in range(100):
        mid = (lo + hi) / 2
        if option_type == "call":
            price = black_scholes_call(S, K, T, r, mid)
        else:
            price = black_scholes_put(S, K, T, r, mid)

        if abs(price - option_price) < tol:
            return mid

        if price < option_price:
            lo = mid
        else:
            hi = mid

    return sigma


# ═══════════════════════════════════════════════════════════════════════════════
# VOLATILITY SURFACE & SKEW
# ═══════════════════════════════════════════════════════════════════════════════

def build_vol_surface(
    options_chain: pd.DataFrame,
    spot_price: float,
    risk_free_rate: float = 0.07,
) -> pd.DataFrame:
    """Build implied volatility surface from options chain.

    Args:
        options_chain: DataFrame with columns [strike, expiry, option_type, last_price].
                       expiry should be a date or days-to-expiry.
        spot_price: Current spot price.
        risk_free_rate: Risk-free rate (annualized).

    Returns:
        DataFrame with [strike, expiry, option_type, implied_vol, delta, gamma, vega].
    """
    results = []
    today = pd.Timestamp.now()

    for _, row in options_chain.iterrows():
        K = float(row["strike"])
        price = float(row["last_price"])
        opt_type = row.get("option_type", "call").lower()

        # Compute time to expiry
        expiry = row["expiry"]
        if isinstance(expiry, str):
            expiry = pd.Timestamp(expiry)
        if isinstance(expiry, pd.Timestamp):
            T = max(0, (expiry - today).days) / 365
        else:
            T = float(expiry) / 365  # assume days

        if T <= 0 or price <= 0:
            continue

        # Compute implied vol
        iv = implied_volatility(price, spot_price, K, T, risk_free_rate, opt_type)

        # Compute Greeks
        greeks = compute_greeks(spot_price, K, T, risk_free_rate, iv, opt_type)

        results.append({
            "strike": K,
            "expiry": expiry if isinstance(expiry, pd.Timestamp) else T * 365,
            "T_years": T,
            "option_type": opt_type,
            "market_price": price,
            "implied_vol": iv,
            **greeks,
        })

    return pd.DataFrame(results)


def compute_vol_skew(vol_surface: pd.DataFrame) -> dict:
    """Compute volatility skew metrics.

    Skew = IV(25-delta put) - IV(25-delta call)
    High skew = market expects downside (bearish sentiment)
    Low/negative skew = market expects upside (bullish sentiment)
    """
    calls = vol_surface[vol_surface["option_type"] == "call"]
    puts = vol_surface[vol_surface["option_type"] == "put"]

    if calls.empty or puts.empty:
        return {"skew": 0.0, "atm_vol": 0.0, "term_slope": 0.0}

    # Find 25-delta options
    call_25d = calls.iloc[(calls["delta"] - 0.25).abs().argsort()[:1]]
    put_25d = puts.iloc[(puts["delta"] + 0.25).abs().argsort()[:1]]

    if call_25d.empty or put_25d.empty:
        return {"skew": 0.0, "atm_vol": 0.0, "term_slope": 0.0}

    call_iv = float(call_25d["implied_vol"].iloc[0])
    put_iv = float(put_25d["implied_vol"].iloc[0])
    skew = put_iv - call_iv

    # ATM volatility (50-delta)
    atm_options = pd.concat([calls[calls["delta"].between(0.45, 0.55)],
                             puts[puts["delta"].between(-0.55, -0.45)]])
    atm_vol = float(atm_options["implied_vol"].mean()) if not atm_options.empty else 0.0

    return {
        "skew": skew,
        "atm_vol": atm_vol,
        "call_25d_iv": call_iv,
        "put_25d_iv": put_iv,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# FUTURES BASIS
# ═══════════════════════════════════════════════════════════════════════════════

def compute_futures_basis(
    spot_price: float,
    futures_price: float,
    time_to_expiry_days: int,
    risk_free_rate: float = 0.07,
    dividend_yield: float = 0.0,
) -> dict:
    """Compute futures basis and arbitrage signals.

    Fair futures = Spot × exp((r - q) × T)

    If actual futures > fair → contango (premium): cash-and-carry — sell
    futures, buy spot.
    If actual futures < fair → backwardation (discount): reverse
    cash-and-carry — buy futures, sell spot.
    """
    T = time_to_expiry_days / 365

    # Fair futures price (cost of carry model)
    fair_futures = spot_price * exp((risk_free_rate - dividend_yield) * T)

    # Basis
    basis = futures_price - spot_price
    fair_basis = fair_futures - spot_price

    # Annualized basis (cost of carry)
    if T > 0 and spot_price > 0:
        annualized_basis = (futures_price / spot_price - 1) / T
    else:
        annualized_basis = 0.0

    # Arbitrage signal
    spread = futures_price - fair_futures
    spread_pct = spread / spot_price if spot_price > 0 else 0

    # AUDIT-FIX (Round 6, A1-P3-10): futures ABOVE fair is CONTANGO
    # (premium; cash-and-carry = sell futures / buy spot); futures BELOW fair
    # is BACKWARDATION (discount; reverse cash-and-carry = buy futures /
    # sell spot). The previous labels were swapped (trade directions were
    # correct; the market-state names shown to users were inverted).
    if spread_pct > 0.005:  # > 50bps over fair
        signal = "CONTANGO: Sell futures, buy spot (cash-and-carry)"
    elif spread_pct < -0.005:  # > 50bps under fair
        signal = "BACKWARDATION: Buy futures, sell spot (reverse cash-and-carry)"
    else:
        signal = "NEUTRAL: No arbitrage opportunity"

    return {
        "spot_price": spot_price,
        "futures_price": futures_price,
        "fair_futures": fair_futures,
        "basis": basis,
        "fair_basis": fair_basis,
        "annualized_basis": annualized_basis,
        "spread": spread,
        "spread_pct": spread_pct,
        "signal": signal,
    }


def vol_trading_signal(vol_surface: pd.DataFrame) -> dict:
    """Generate volatility trading signal from vol surface.

    Signals:
      - Long vol: IV < historical vol (vol is cheap)
      - Short vol: IV > historical vol (vol is expensive)
      - Skew trade: buy put spread when skew is extreme
    """
    skew_metrics = compute_vol_skew(vol_surface)
    atm_vol = skew_metrics.get("atm_vol", 0.0)
    skew = skew_metrics.get("skew", 0.0)

    # Skew signal: extreme skew (>5%) = bearish sentiment → consider long put spreads
    if skew > 0.05:
        skew_signal = "EXTREME SKEW — consider long put spread (cheap downside protection)"
    elif skew < -0.02:
        skew_signal = "REVERSE SKEW — consider long call spread (bullish)"
    else:
        skew_signal = "NORMAL SKEW — no skew trade"

    return {
        "atm_vol": atm_vol,
        "skew": skew,
        "skew_signal": skew_signal,
        "vol_level": "HIGH" if atm_vol > 0.25 else "LOW" if atm_vol < 0.12 else "NORMAL",
    }
