"""
math_engine/dsr_calculator.py
==============================
Deflated Sharpe Ratio (DSR), Probabilistic Sharpe Ratio (PSR),
Minimum Track Record Length (MinTRL), and Gain-to-Pain Ratio (GPR).

Implements Marcos López de Prado's framework (2014, 2018) for adjusting
Sharpe ratios against non-normality (skewness/kurtosis) and multiple-testing
data-mining bias across parallel profile sweeps.
"""
from __future__ import annotations

import logging
import math
import numpy as np
import pandas as pd
from typing import Dict, Any, Union, Tuple, Optional, List
from scipy.stats import norm, skew, kurtosis

logger = logging.getLogger(__name__)


def compute_probabilistic_sharpe_ratio(
    returns: Union[pd.Series, np.ndarray],
    benchmark_sr: float = 0.0,
    annualization_factor: float = 252.0
) -> Dict[str, float]:
    """
    Computes the Probabilistic Sharpe Ratio (PSR) accounting for non-normal skewness & kurtosis.
    
    PSR(SR*) = Z[ (SR_hat - SR*) * sqrt(T-1) / sqrt(1 - skew * SR_hat + (kurt-1)/4 * SR_hat^2) ]
    """
    ret_arr = np.asarray(returns, dtype=float)
    ret_arr = ret_arr[np.isfinite(ret_arr)]
    n = len(ret_arr)
    
    if n < 10:
        return {
            "sharpe": 0.0,
            "psr": 0.50,
            "skewness": 0.0,
            "kurtosis": 3.0,
            "n_samples": n,
            "is_statistically_significant": False
        }
        
    mean = float(np.mean(ret_arr))
    std = float(np.std(ret_arr, ddof=1)) + 1e-9
    
    # Daily Sharpe ratio
    daily_sr = mean / std
    ann_sr = daily_sr * np.sqrt(annualization_factor)
    ann_benchmark_sr = benchmark_sr
    daily_benchmark_sr = ann_benchmark_sr / np.sqrt(annualization_factor)
    
    # Sample skewness (3rd moment) and kurtosis (4th moment, non-excess = excess + 3)
    sk = float(skew(ret_arr)) if std > 1e-8 else 0.0
    kt = float(kurtosis(ret_arr, fisher=False)) if std > 1e-8 else 3.0
    
    # Variance of annual Sharpe ratio estimator
    sr_var = (1.0 - sk * daily_sr + ((kt - 1.0) / 4.0) * (daily_sr ** 2)) / (n - 1.0)
    sr_std = np.sqrt(max(sr_var, 1e-12))
    
    z_stat = (daily_sr - daily_benchmark_sr) / sr_std
    psr_val = float(norm.cdf(z_stat))
    
    return {
        "sharpe": round(ann_sr, 4),
        "daily_sharpe": round(daily_sr, 6),
        "psr": round(psr_val, 4),
        "z_stat": round(z_stat, 4),
        "skewness": round(sk, 4),
        "kurtosis": round(kt, 4),
        "n_samples": n,
        "is_statistically_significant": bool(psr_val >= 0.95)
    }


def compute_deflated_sharpe_ratio(
    trial_sharpes: Union[List[float], np.ndarray],
    returns: Union[pd.Series, np.ndarray],
    annualization_factor: float = 252.0
) -> Dict[str, float]:
    """
    Computes the Deflated Sharpe Ratio (DSR) adjusting for multiple testing across N trials.
    
    SR* = sqrt( Var({SR_m}) ) * [ (1 - EulerGamma)*Z^-1(1 - 1/N) + EulerGamma*Z^-1(1 - 1/(N*e)) ]
    DSR = PSR(SR*)

    AUDIT-FIX (Round 6, A1-P3-11): the docstring previously claimed
    sqrt(Var/2) while the code computes sqrt(Var) — the canonical
    Bailey-LdP expected-max-of-N form. Docstring aligned to the code (a
    sqrt(2) discrepancy would shift the hurdle 41%).
    """
    trials = np.asarray(trial_sharpes, dtype=float)
    trials = trials[np.isfinite(trials)]
    n_trials = len(trials)
    
    if n_trials < 2:
        # Fallback to single-trial PSR against 0 benchmark
        return compute_probabilistic_sharpe_ratio(returns, benchmark_sr=0.0, annualization_factor=annualization_factor)
        
    var_sr = float(np.var(trials, ddof=1)) + 1e-9
    max_sr = float(np.max(trials))
    
    euler_gamma = 0.5772156649015328
    
    # Expected maximum Sharpe ratio under null hypothesis of 0 true alpha across N independent trials
    z_1 = norm.ppf(1.0 - 1.0 / n_trials) if n_trials > 1 else 0.0
    z_2 = norm.ppf(1.0 - 1.0 / (n_trials * math.e)) if n_trials > 1 else 0.0
    
    sr_star = np.sqrt(var_sr) * ((1.0 - euler_gamma) * z_1 + euler_gamma * z_2)
    
    # DSR is PSR computed against the benchmark SR*
    res = compute_probabilistic_sharpe_ratio(returns, benchmark_sr=sr_star, annualization_factor=annualization_factor)
    res.update({
        "dsr": res["psr"],
        "sr_benchmark_threshold": round(sr_star, 4),
        "max_trial_sharpe": round(max_sr, 4),
        "trial_sharpe_var": round(var_sr, 6),
        "n_trials": n_trials,
        "dsr_significant": bool(res["psr"] >= 0.95)
    })
    return res


def compute_min_track_record_length(
    ann_sharpe: float,
    skewness: float = 0.0,
    kurtosis_val: float = 3.0,
    target_confidence: float = 0.95,
    annualization_factor: float = 252.0
) -> float:
    """
    Computes Minimum Track Record Length (MinTRL) in years required to establish statistical significance.
    
    MinTRL = 1 + [1 - skew*SR + (kurt-1)/4 * SR^2] * (Z_alpha / SR)^2
    """
    daily_sr = ann_sharpe / np.sqrt(annualization_factor)
    if abs(daily_sr) < 1e-6:
        return 999.0
        
    z_alpha = norm.ppf(target_confidence)
    
    min_n_days = 1.0 + (1.0 - skewness * daily_sr + ((kurtosis_val - 1.0) / 4.0) * (daily_sr ** 2)) * ((z_alpha / daily_sr) ** 2)
    min_years = min_n_days / annualization_factor
    return round(max(min_years, 0.01), 2)


def compute_gain_to_pain_ratio(returns: Union[pd.Series, np.ndarray]) -> float:
    """
    Computes Jack Schwager's Gain-to-Pain Ratio (GPR).
    GPR = Sum(Positive Returns) / Abs(Sum(Negative Returns))
    """
    ret_arr = np.asarray(returns, dtype=float)
    ret_arr = ret_arr[np.isfinite(ret_arr)]
    if len(ret_arr) == 0:
        return 0.0
        
    total_gain = float(np.sum(ret_arr[ret_arr > 0]))
    total_loss = float(np.abs(np.sum(ret_arr[ret_arr < 0])))
    
    if total_loss < 1e-9:
        return round(total_gain * 100.0, 2) if total_gain > 0 else 0.0
        
    return round(total_gain / total_loss, 4)
