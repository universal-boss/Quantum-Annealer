"""
math_engine/entropy_decay.py
============================
Shannon Information Return Entropy & Market Decay Engine.

Calculates Shannon Entropy, Tsallis Entropy, and Information Decay Ratios
on historical return distributions to quantify market uncertainty, non-linear chaos,
and portfolio information dissipation.
"""

from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, List, Tuple
from scipy.stats import entropy as scipy_entropy

logger = logging.getLogger(__name__)


class ShannonInformationEntropyEngine:
    """
    Real Shannon & Tsallis Information Return Entropy Engine.
    Quantifies probability distribution dispersion and information disorder 
    in asset price return series.
    """

    @staticmethod
    def compute_shannon_return_entropy(
        returns: pd.Series | np.ndarray,
        bins: int = 20
    ) -> float:
        """
        Calculates normalized Shannon Entropy H(X) of asset returns:
        H(X) = - Σ p(x_i) * log2(p(x_i)) / log2(bins)
        
        Returns a normalized score between 0.0 (perfect order/predictability)
        and 1.0 (maximum disorder/random walk noise).
        """
        ret_vals = np.asarray(returns, dtype=float)
        ret_vals = ret_vals[~np.isnan(ret_vals)]

        if len(ret_vals) < 10:
            return None  # Insufficient data — entropy cannot be computed

        hist, _ = np.histogram(ret_vals, bins=bins, density=True)
        # Convert density to probabilities
        prob = hist / np.sum(hist)
        prob = prob[prob > 0]

        raw_h = float(scipy_entropy(prob, base=2))
        max_h = np.log2(bins)
        norm_h = round(raw_h / max_h, 4) if max_h > 0 else None
        if norm_h is None:
            return None  # bins=1 degenerate case — entropy undefined
        return float(min(1.0, max(0.0, norm_h)))

    @classmethod
    def compute_tsallis_entropy(
        cls,
        returns: pd.Series | np.ndarray,
        q: float = 1.5,
        bins: int = 20
    ) -> float:
        """
        Calculates Tsallis non-extensive entropy S_q(X) for fat-tailed market distributions:
        S_q = (1 - Σ p_i^q) / (q - 1)
        """
        ret_vals = np.asarray(returns, dtype=float)
        ret_vals = ret_vals[~np.isnan(ret_vals)]

        if len(ret_vals) < 10 or q == 1.0:
            return cls.compute_shannon_return_entropy(returns, bins=bins)

        hist, _ = np.histogram(ret_vals, bins=bins, density=True)
        prob = hist / np.sum(hist)
        prob = prob[prob > 0]

        tsallis = (1.0 - np.sum(prob ** q)) / (q - 1.0)
        return float(round(tsallis, 4))

    @classmethod
    def score_portfolio_information_decay(
        cls,
        returns_df: pd.DataFrame,
        window: int = 60
    ) -> Dict[str, float]:
        """
        Scores return entropy across assets in portfolio.
        High entropy (>0.85) indicates pure noise; Low entropy (<0.45) indicates strong directional trend.
        """
        scores = {}
        for col in returns_df.columns:
            series = returns_df[col].dropna()
            if len(series) >= 20:
                scores[str(col)] = cls.compute_shannon_return_entropy(series.iloc[-window:])
            else:
                scores[str(col)] = None  # Insufficient data — entropy unknown
        return scores
