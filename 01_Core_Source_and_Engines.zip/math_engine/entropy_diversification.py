"""
math_engine/entropy_diversification.py
======================================
Entropy-Weighted Portfolio Diversification Engine.

Computes Shannon Entropy H(w) = -sum w_i * ln(w_i) and Effective Number of Assets N_eff = exp(H(w))
to enforce minimum effective asset diversification bounds.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any

logger = logging.getLogger(__name__)


class EntropyDiversificationEngine:
    """
    Shannon Entropy & Effective Number of Assets Diversification Calculator.
    """

    @staticmethod
    def calculate_effective_assets(weights: Dict[str, float]) -> Dict[str, Any]:
        """
        Calculates Shannon entropy and N_eff = exp(-sum w_i * ln(w_i)).
        """
        if not weights:
            return {"n_effective_assets": 0.0, "shannon_entropy": 0.0, "is_well_diversified": False}

        w_arr = np.array([v for k, v in weights.items() if k.upper() != "CASH" and v > 0], dtype=float)
        if len(w_arr) == 0:
            return {"n_effective_assets": 0.0, "shannon_entropy": 0.0, "is_well_diversified": False}

        w_arr = w_arr / np.sum(w_arr)
        entropy = -float(np.sum(w_arr * np.log(w_arr + 1e-12)))
        n_eff = float(np.exp(entropy))

        return {
            "n_effective_assets": round(n_eff, 2),
            "shannon_entropy": round(entropy, 4),
            "n_nominal_assets": len(w_arr),
            "is_well_diversified": bool(n_eff >= min(5.0, len(w_arr) * 0.5))
        }
