"""
math_engine/expected_shortfall.py
==================================
Convex portfolio optimizer utilizing Expected Shortfall (ES / CVaR) risk constraints.
Optimizes expected returns subject to holding-limit bounds and a tail-risk budget.
"""
from __future__ import annotations

import logging
from typing import Dict, Any, List, Optional
import numpy as np
import cvxpy as cp

logger = logging.getLogger(__name__)


class ExpectedShortfallOptimizer:
    """Optimizes portfolios under Conditional Value-at-Risk (CVaR) constraints."""

    @staticmethod
    def solve_es_portfolio(
        historical_returns: np.ndarray,   # shape: (S, N) - scenarios of asset returns
        mu: np.ndarray,                   # shape: (N,) - expected return vector
        alpha: float = 0.95,              # Confidence level for ES (e.g., 95% tail risk)
        max_es: float = 0.05,             # Upper bound constraint on Expected Shortfall
        min_weight: float = 0.0,
        max_weight: float = 0.40
    ) -> np.ndarray:
        """Solve Mean-Expected Shortfall portfolio optimization.
        
        minimize   -mu^T * w
        subject to w >= min_weight, w <= max_weight
                   sum(w) == 1
                   ES_alpha(w) <= max_es
        """
        S, N = historical_returns.shape
        if S == 0 or N == 0:
            return np.ones(N) / N

        w = cp.Variable(N)
        
        # Auxiliary variables for Rockafellar-Uryasev CVaR formulation
        beta = cp.Variable()              # Represents VaR threshold
        u = cp.Variable(S, nonneg=True)   # Represents excess losses in each scenario

        # expected loss in scenario s: loss_s = -R_s^T * w
        losses = -historical_returns @ w

        # CVaR Formulation constraints: u_s >= loss_s - beta
        constraints = [
            cp.sum(w) == 1.0,
            w >= min_weight,
            w <= max_weight,
            u >= losses - beta
        ]

        # Conditional Value-at-Risk (Expected Shortfall) expression
        # AUDIT-FIX (Round 8, math residual — Part 2B): alpha=1.0 divided by
        # zero ((1 - alpha) = 0 → 1/0 → inf) and crashed the solver with an
        # opaque DCP error. Guard: alpha must be strictly inside (0, 1) for
        # the ES tail-mean to exist; degenerate values are rejected up front
        # with a clear error.
        if not (0.0 < float(alpha) < 1.0):
            raise ValueError(
                f"solve_es_portfolio: alpha must be in the open interval (0, 1) "
                f"for Expected Shortfall (got alpha={alpha}); the tail mean is "
                f"undefined at the boundaries."
            )
        cvar = beta + (1.0 / ((1.0 - alpha) * S)) * cp.sum(u)

        # Expected Shortfall risk ceiling limit
        constraints.append(cvar <= max_es)

        # Maximize expected returns (minimize negative returns)
        objective = cp.Minimize(-mu @ w)

        prob = cp.Problem(objective, constraints)
        
        try:
            prob.solve(solver=cp.CLARABEL)
        except Exception as e:
            logger.error(f"[ExpectedShortfall] Clarabel solver failed: {e}. Trying fallback ECOS.", exc_info=True)
            try:
                prob.solve(solver=cp.ECOS)
            except Exception as e2:
                logger.error(f"[ExpectedShortfall] Fallback failed: {e2}", exc_info=True)
                return np.ones(N) / N

        if w.value is None:
            logger.warning("[ExpectedShortfall] Optimization infeasible. Relaxing ES budget limit.")
            # Fallback: solve without risk ceiling, just minimize CVaR directly
            prob_fallback = cp.Problem(cp.Minimize(cvar), [cp.sum(w) == 1.0, w >= min_weight, w <= max_weight, u >= losses - beta])
            try:
                prob_fallback.solve(solver=cp.CLARABEL)
            except Exception:
                return np.ones(N) / N

        if w.value is None:
            return np.ones(N) / N

        from optimizer import _project_weights_to_bounds
        return _project_weights_to_bounds(w.value, lower=min_weight, upper=max_weight)
