"""
math_engine/factor_orthogonalizer.py
====================================
Institutional SVD & Gram-Schmidt Factor Orthogonalization Engine.

Removes cross-factor collinearity, market beta exposure, and size bias from raw
alpha signals to produce pure idiosyncratic factor scores matching Tier-1 quant hedge funds.
"""
from __future__ import annotations
import numpy as np
import pandas as pd
import logging

logger = logging.getLogger(__name__)


class FactorOrthogonalizer:
    """Performs cross-sectional SVD and Gram-Schmidt orthogonalization on multi-factor panels."""

    @staticmethod
    def orthogonalize_factors(
        factor_matrix: np.ndarray,
        method: str = "svd"
    ) -> np.ndarray:
        """
        Orthogonalizes factor matrix (N assets x K factors).
        
        Parameters:
            factor_matrix: (N, K) array of standardized factor z-scores.
            method: 'svd' (Singular Value Decomposition, symmetric) or 'gram_schmidt'.
            
        Returns:
            (N, K) array of mutually orthogonal factor scores with zero correlation.
        """
        if factor_matrix.ndim != 2 or factor_matrix.shape[1] <= 1:
            return factor_matrix

        N, K = factor_matrix.shape
        
        # Center and standardize columns
        clean_matrix = np.nan_to_num(factor_matrix, nan=0.0)
        mean_vec = np.mean(clean_matrix, axis=0, keepdims=True)
        centered = clean_matrix - mean_vec
        std = np.std(centered, axis=0, keepdims=True)
        std[std < 1e-8] = 1.0
        Z = centered / std

        if method.lower() == "svd":
            # Symmetric SVD orthogonalization: Z_ortho = U @ V^T
            U, S, Vt = np.linalg.svd(Z, full_matrices=False)
            ortho = U @ Vt
        else:
            # QR / Gram-Schmidt sequential orthogonalization
            Q, R = np.linalg.qr(Z)
            ortho = Q

        # Re-standardize orthogonal factors
        ortho_std = np.std(ortho, axis=0, keepdims=True)
        ortho_std[ortho_std < 1e-8] = 1.0
        return ortho / ortho_std

    @staticmethod
    def neutralize_against_market(
        factor_scores: np.ndarray,
        market_betas: np.ndarray,
        market_caps: np.ndarray | None = None
    ) -> np.ndarray:
        """
        Neutralizes factor scores against Market Beta and Log Market Cap via OLS residual projection:
        alpha_pure = (I - B (B^T B)^-1 B^T) alpha_raw
        """
        N = len(factor_scores)
        if N < 3:
            return factor_scores

        # Build design matrix B: [1, beta, log(cap)]
        intercept = np.ones((N, 1))
        beta_col = market_betas.reshape(N, 1)
        
        if market_caps is not None and len(market_caps) == N:
            cap_col = np.log(np.maximum(market_caps.reshape(N, 1), 1.0))
            B = np.hstack([intercept, beta_col, cap_col])
        else:
            B = np.hstack([intercept, beta_col])

        # Projection matrix P = B (B^T B)^-1 B^T
        try:
            BtB_inv = np.linalg.pinv(B.T @ B)
            P = B @ BtB_inv @ B.T
            # Residual alpha
            alpha_pure = (np.eye(N) - P) @ factor_scores.reshape(N, -1)
            return alpha_pure.flatten() if factor_scores.ndim == 1 else alpha_pure
        except Exception as e:
            logger.debug(f"OLS Factor Neutralization fallback: {e}", exc_info=True)
            return factor_scores

    @classmethod
    def compute_pure_profile_alpha(
        cls,
        universe_df: pd.DataFrame,
        profile_name: str
    ) -> pd.Series:
        """
        Extracts, orthogonalizes, and scores stocks for a specific investment profile.
        Guarantees mathematically pure, un-contaminated alpha.
        """
        if universe_df.empty:
            return pd.Series(dtype=float)

        tickers = universe_df["Ticker"].tolist()
        N = len(tickers)
        if N < 2:
            return pd.Series([1.0] * N, index=tickers)

        def _get_col(col_names: list[str] | str, default_val: float) -> np.ndarray:
            if isinstance(col_names, str):
                col_names = [col_names]
            for c in col_names:
                if c in universe_df.columns:
                    return pd.to_numeric(universe_df[c], errors="coerce").fillna(default_val).values
            return np.full(len(universe_df), default_val, dtype=float)

        # 1. Extract raw factor panel
        rs = _get_col(["RS Rating (1-99)", "RS Rating", "RS"], 80.0)
        ret3m = _get_col(["3M Return %", "3M Return", "Return 3M"], 10.0)
        ret6m = _get_col(["6M Return %", "6M Return", "Return 6M"], 15.0)
        beta = _get_col(["Market Beta (β)", "Market Beta", "Beta"], 0.8)
        vcp = _get_col(["VCP Squeeze Ratio", "KBS Ratio", "VCP", "BB Width"], 1.0)
        piot = _get_col(["Piotroski F-Score", "Piotroski", "F-Score"], 7.0)
        altman = _get_col(["Altman Z-Score", "Altman", "Z-Score"], 3.5)
        pe = _get_col(["PE Ratio", "PE", "P/E"], 30.0)
        adv20 = _get_col(["ADV20 (₹Cr)", "ADV20", "Turnover (₹Cr)"], 50.0)

        raw_factors = np.column_stack([
            rs, ret3m, ret6m, vcp, piot, altman, -pe, adv20
        ])

        # 2. SVD Orthogonalization across factors
        ortho_factors = cls.orthogonalize_factors(raw_factors, method="svd")
        
        # Columns: [0: Pure RS, 1: Pure 3M Mom, 2: Pure 6M Mom, 3: Pure VCP, 4: Pure Piotroski, 5: Pure Altman, 6: Pure Value, 7: Pure Flow]
        pure_rs = ortho_factors[:, 0]
        pure_3m = ortho_factors[:, 1]
        pure_6m = ortho_factors[:, 2]
        pure_vcp = ortho_factors[:, 3]
        pure_piot = ortho_factors[:, 4]
        pure_alt = ortho_factors[:, 5]
        pure_val = ortho_factors[:, 6]
        pure_flow = ortho_factors[:, 7]

        # 3. Strategy-specific pure linear combination
        p_lower = profile_name.lower()
        if "smart money" in p_lower:
            alpha = (pure_vcp * 0.40) + (pure_flow * 0.25) + (pure_rs * 0.20) + (pure_3m * 0.15)
            # Market beta neutral
            alpha = cls.neutralize_against_market(alpha, beta)
        elif "max alpha" in p_lower:
            alpha = (pure_3m * 0.40) + (pure_6m * 0.30) + (pure_rs * 0.20) + (pure_vcp * 0.10)
        elif "trend momentum" in p_lower:
            alpha = (pure_rs * 0.45) + (pure_3m * 0.35) + (pure_6m * 0.20)
        elif "garp" in p_lower:
            alpha = (pure_val * 0.45) + (pure_piot * 0.30) + (pure_alt * 0.15) + (pure_3m * 0.10)
        elif "inst. accumulation" in p_lower:
            alpha = (pure_flow * 0.50) + (pure_alt * 0.25) + (pure_piot * 0.15) + (pure_rs * 0.10)
        elif "quality compounders" in p_lower:
            alpha = (pure_piot * 0.45) + (pure_alt * 0.35) + (pure_val * 0.15) + (pure_flow * 0.05)
            # Penalize high beta
            alpha = alpha - (beta * 0.8)
        elif "vol squeeze" in p_lower:
            alpha = (pure_vcp * 0.55) + (pure_rs * 0.25) + (pure_3m * 0.20)
        elif "risk parity" in p_lower:
            alpha = (pure_piot * 0.35) + (pure_alt * 0.25) + (pure_val * 0.20) + (pure_flow * 0.20)
            alpha = alpha - (beta * 1.0)
        elif "capital preservation" in p_lower:
            alpha = (pure_alt * 0.45) + (pure_piot * 0.35) + (pure_val * 0.20)
            alpha = alpha - (beta * 1.5)
        else:
            alpha = pure_rs + pure_3m

        return pd.Series(alpha, index=tickers, name="Pure_Alpha")
