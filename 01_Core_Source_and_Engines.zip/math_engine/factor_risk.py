"""
math_engine/factor_risk.py
============================
Barra-style Factor Risk Decomposer.
Calculates factor loadings, constructs factor covariance matrices, and performs ex-ante portfolio risk attribution.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Any

logger = logging.getLogger(__name__)


class FactorRiskDecomposer:
    """Computes Barra-style factor exposures, builds the factor covariance matrix,
    and calculates portfolio-level risk decomposition (systematic vs specific risk)
    and Marginal Contribution to Risk (MCR).
    """

    def __init__(self, n_factors: int = 8) -> None:
        self.n_factors = n_factors
        self.factor_names = ["Size", "Value", "Momentum", "Volatility", "Liquidity", "Quality", "Leverage", "Growth"]

    @staticmethod
    def denoise_covariance_matrix(cov: np.ndarray, n_samples: int, n_features: int) -> np.ndarray:
        """
        Marcenko-Pastur Random Matrix Theory (RMT) Covariance Matrix De-noising.
        Filters noise eigenvalues lambda <= lambda_plus where lambda_plus = sigma^2 * (1 + sqrt(N/T))^2.
        """
        if cov is None or cov.size == 0 or n_samples <= n_features:
            return cov

        # Eigen-decomposition of sample correlation / covariance
        val, vec = np.linalg.eigh(cov)
        idx = val.argsort()[::-1]
        val = val[idx]
        vec = vec[:, idx]

        q = float(n_samples) / float(n_features)
        var_est = 1.0  # Normalized variance estimate
        lambda_plus = var_est * ((1.0 + np.sqrt(1.0 / q)) ** 2)

        # Shrink noise eigenvalues (below lambda_plus) to their average
        noise_mask = val <= lambda_plus
        if np.any(noise_mask):
            mean_noise_val = float(np.mean(val[noise_mask]))
            val[noise_mask] = mean_noise_val

        # Reconstruct de-noised covariance matrix
        cov_denoised = vec @ np.diag(val) @ vec.T
        return cov_denoised

    def compute_factor_exposures(
        self,
        signal_df: pd.DataFrame,
        returns: Optional[pd.DataFrame] = None,
        sectors: Optional[Dict[str, str]] = None,
        benchmark_returns: Optional[pd.Series] = None
    ) -> pd.DataFrame:
        """Calculate and normalize factor exposures (B matrix) for the asset universe.
        Includes style factors, sector/industry dummy factors, and macro factors.
        """
        exposures = pd.DataFrame(index=signal_df.index)

        # 1. Size Factor (log of ADV20)
        adv = pd.to_numeric(signal_df["adv20"], errors="coerce").fillna(1e6)
        exposures["Size"] = np.log(adv.clip(lower=1.0))

        # 2. Value Factor (inverse PE if available, fallback to composite score or 0.0)
        if "z_pe_inv" in signal_df.columns:
            exposures["Value"] = pd.to_numeric(signal_df["z_pe_inv"], errors="coerce").fillna(0.0)
        elif "z_fund_composite" in signal_df.columns:
            exposures["Value"] = pd.to_numeric(signal_df["z_fund_composite"], errors="coerce").fillna(0.0)
        else:
            exposures["Value"] = 0.0

        # 3. Momentum Factor (6M momentum)
        if "z_mom_6m" in signal_df.columns:
            exposures["Momentum"] = pd.to_numeric(signal_df["z_mom_6m"], errors="coerce").fillna(0.0)
        elif "mom_6m" in signal_df.columns:
            m = pd.to_numeric(signal_df["mom_6m"], errors="coerce").fillna(0.0)
            exposures["Momentum"] = (m - m.mean()) / (m.std() + 1e-9)
        else:
            exposures["Momentum"] = 0.0

        # 4. Volatility Factor (annualized volatility)
        if "z_ann_vol" in signal_df.columns:
            exposures["Volatility"] = pd.to_numeric(signal_df["z_ann_vol"], errors="coerce").fillna(0.0)
        elif "ann_vol" in signal_df.columns:
            v = pd.to_numeric(signal_df["ann_vol"], errors="coerce").fillna(0.3)
            exposures["Volatility"] = (v - v.mean()) / (v.std() + 1e-9)
        else:
            exposures["Volatility"] = 0.0

        # 5. Liquidity Factor
        if "z_delivery" in signal_df.columns:
            exposures["Liquidity"] = pd.to_numeric(signal_df["z_delivery"], errors="coerce").fillna(0.0)
        elif "z_adv20" in signal_df.columns:
            exposures["Liquidity"] = pd.to_numeric(signal_df["z_adv20"], errors="coerce").fillna(0.0)
        else:
            exposures["Liquidity"] = exposures["Size"]

        # 6. Quality Factor (z_roe)
        if "z_roe" in signal_df.columns:
            exposures["Quality"] = pd.to_numeric(signal_df["z_roe"], errors="coerce").fillna(0.0)
        else:
            exposures["Quality"] = 0.0

        # 7. Leverage Factor (z_de_inv)
        if "z_de_inv" in signal_df.columns:
            exposures["Leverage"] = pd.to_numeric(signal_df["z_de_inv"], errors="coerce").fillna(0.0)
        else:
            exposures["Leverage"] = 0.0

        # 8. Growth Factor (z_rev_growth)
        if "z_rev_growth" in signal_df.columns:
            exposures["Growth"] = pd.to_numeric(signal_df["z_rev_growth"], errors="coerce").fillna(0.0)
        else:
            exposures["Growth"] = 0.0

        # Style factor names
        self.factor_names = ["Size", "Value", "Momentum", "Volatility", "Liquidity", "Quality", "Leverage", "Growth"]

        # Cross-sectionally standardise style exposures
        for col in self.factor_names:
            series = exposures[col]
            std_val = series.std()
            if std_val > 1e-6:
                exposures[col] = (series - series.mean()) / std_val
            else:
                exposures[col] = 0.0

        # 9. Industry/Sector Factors (Barra-style dummies)
        if sectors:
            unique_sectors = sorted(list(set(v for v in sectors.values() if v and v not in ("N/A", "Other", "Unknown"))))
            for sec in unique_sectors:
                col_name = f"Sector_{sec}"
                exposures[col_name] = [1.0 if sectors.get(ticker) == sec else 0.0 for ticker in signal_df.index]
                self.factor_names.append(col_name)

        # 10. Macro Factors (Rolling Market Beta and Volatility Beta)
        if returns is not None and benchmark_returns is not None and not returns.empty and not benchmark_returns.empty:
            # Align indices
            aligned_returns = returns.reindex(benchmark_returns.index).fillna(0.0)
            bench_var = float(benchmark_returns.var())
            
            # Market Beta: Cov(R_s, R_b) / Var(R_b)
            market_betas = {}
            # Volatility Beta: Cov(R_s, rolling_vol_b) / Var(rolling_vol_b)
            rolling_vol_b = benchmark_returns.rolling(21).std().fillna(0.0)
            vol_var = float(rolling_vol_b.var())
            vol_betas = {}
            
            for ticker in signal_df.index:
                if ticker in aligned_returns.columns:
                    stock_rets = aligned_returns[ticker]
                    # Market beta
                    cov_m = float(np.cov(stock_rets, benchmark_returns)[0, 1])
                    market_betas[ticker] = cov_m / bench_var if bench_var > 1e-9 else 0.0
                    # Volatility beta
                    cov_v = float(np.cov(stock_rets, rolling_vol_b)[0, 1])
                    vol_betas[ticker] = cov_v / vol_var if vol_var > 1e-9 else 0.0
                else:
                    market_betas[ticker] = 1.0
                    vol_betas[ticker] = 0.0
                    
            exposures["Market_Beta"] = pd.Series(market_betas)
            exposures["Market_Vol"] = pd.Series(vol_betas)
            
            # Standardise macro exposures
            for col in ["Market_Beta", "Market_Vol"]:
                self.factor_names.append(col)
                series = exposures[col]
                std_val = series.std()
                if std_val > 1e-6:
                    exposures[col] = (series - series.mean()) / std_val
                else:
                    exposures[col] = 0.0

        self.n_factors = len(self.factor_names)
        return exposures

    def _compute_ewma_covariance(self, returns_matrix: np.ndarray, lam: float = 0.94) -> np.ndarray:
        """Compute the EWMA covariance matrix of returns.
        returns_matrix has shape (T, K) where T is time and K is variables.
        """
        T, K = returns_matrix.shape
        if T <= 1:
            return np.cov(returns_matrix, rowvar=False).reshape(K, K)
        
        # Calculate exponential weights
        weights = np.array([lam ** (T - 1 - t) for t in range(T)], dtype=np.float32)
        weights /= weights.sum()
        
        # Weighted mean
        weighted_mean = np.sum(returns_matrix * weights[:, np.newaxis], axis=0)
        
        # Demean
        demeaned = returns_matrix - weighted_mean
        
        # Weighted covariance
        cov = (demeaned.T * weights) @ demeaned
        return cov

    def decompose_risk(
        self,
        returns: pd.DataFrame,
        exposures: pd.DataFrame,
        weights: Dict[str, float],
        benchmark_returns: Optional[pd.Series] = None,
        use_ewma: bool = False,
        ewma_lambda: float = 0.94,
        use_ledoit_wolf: bool = True,
    ) -> Dict[str, Any]:
        """Decompose portfolio risk into Systematic (Factor) and Specific (Idiosyncratic) components.

        Computes ex-ante volatility, tracking error, portfolio beta, MCR, and factor contributions.
        """
        # Filter stocks to real assets present in returns and exposures (safely excluding CASH or un-indexed tickers)
        stocks = [s for s in weights.keys() if s != "CASH" and s in returns.columns and s in exposures.index]
        if not stocks:
            return {}

        # Dynamically align factor names with exposures columns to support expanded industry/macro factors
        self.factor_names = list(exposures.columns)
        self.n_factors = len(self.factor_names)

        # Parse weights
        w = np.array([weights[s] for s in stocks], dtype=np.float32)
        total_w = w.sum()
        if total_w > 1e-9:
            w = w / total_w  # Normalize

        # Slice exposures and returns for the selected stocks
        B = exposures.loc[stocks].to_numpy(dtype=np.float32)  # (N, K)

        # Calculate covariance of stock returns
        clean_rets = returns[stocks].fillna(0.0).to_numpy(dtype=np.float32)  # (T, N)
        
        # Apply EWMA or Ledoit-Wolf shrinkage on stock returns covariance
        if use_ewma:
            Sigma = self._compute_ewma_covariance(clean_rets, lam=ewma_lambda)
        elif use_ledoit_wolf:
            try:
                from sklearn.covariance import ledoit_wolf
                Sigma, _ = ledoit_wolf(clean_rets)
            except Exception:
                Sigma = np.cov(clean_rets, rowvar=False)
        else:
            Sigma = np.cov(clean_rets, rowvar=False)
            
        if Sigma.ndim == 0:
            Sigma = Sigma.reshape(1, 1)

        # Estimate factor covariance matrix F
        # Upgraded to Ridge-regularized Weighted Least Squares (WLS) factor returns
        try:
            if "Size" in self.factor_names:
                size_idx = self.factor_names.index("Size")
                size_col = B[:, size_idx]
                # Map standardized Size exposures to weighting scale: exp(Z)
                # M9-fix: clip the exponent argument and the resulting weights to avoid
                # np.exp overflow → inf → NaN propagating through the WLS solve.
                reg_weights = np.exp(np.clip(size_col, -20.0, 20.0))
                reg_weights = np.clip(reg_weights, 1e-4, 1e6)
                reg_weights /= reg_weights.sum()
                
                # WLS solver with L2 regularization: f = R @ W @ B @ (B^T @ W @ B + lambda * I)^-1
                W = np.diag(reg_weights)
                left = B.T @ W @ B
                # Add Ridge penalty lambda = 1e-4 to handle underdetermined regressions (N < K)
                ridge_lambda = 1e-4
                left += np.eye(left.shape[0], dtype=np.float32) * ridge_lambda
                right = B.T @ W @ clean_rets.T
                
                # Cast to float64 and use pinv to prevent macOS Accelerate Bus errors/crashes
                left_64 = left.astype(np.float64)
                right_64 = right.astype(np.float64)
                factor_returns_T = (np.linalg.pinv(left_64) @ right_64).astype(np.float32)
                factor_returns = factor_returns_T.T  # shape (T, K)
            else:
                # Regularized OLS fallback if Size factor is missing
                left = B.T @ B
                ridge_lambda = 1e-4
                left += np.eye(left.shape[0], dtype=np.float32) * ridge_lambda
                right = B.T @ clean_rets.T
                
                # Cast to float64 and use pinv to prevent macOS Accelerate Bus errors/crashes
                left_64 = left.astype(np.float64)
                right_64 = right.astype(np.float64)
                factor_returns_T = (np.linalg.pinv(left_64) @ right_64).astype(np.float32)
                factor_returns = factor_returns_T.T
            
            if use_ewma:
                F = self._compute_ewma_covariance(factor_returns, lam=ewma_lambda)
            elif use_ledoit_wolf:
                try:
                    from sklearn.covariance import ledoit_wolf
                    F, _ = ledoit_wolf(factor_returns)
                except Exception:
                    F = np.cov(factor_returns, rowvar=False)
            else:
                F = np.cov(factor_returns, rowvar=False)
                
            if F.ndim == 0:
                F = F.reshape(1, 1)
        except Exception:
            F = np.eye(self.n_factors, dtype=np.float32) * 1e-4

        # Bug-fix #3 (HIGH): Non-PSD F matrix. F (factor covariance) is computed
        # directly from np.cov(factor_returns, rowvar=False) without PSD projection.
        # When factor_returns has fewer rows than columns (T < K, common when the
        # backtest window is short) or when np.linalg.pinv returns NaN (singular
        # left matrix), F can have:
        #   - NaN entries (propagating to Sigma_factor, factor_ann_vol, all stress tests)
        #   - Negative eigenvalues (making Sigma_factor non-PSD, which corrupts
        #     specific_variances and the reconstructed covariance)
        # Fix: (a) replace NaN/inf with 0, (b) symmetrize, (c) PSD-project via eigvalsh.
        F = np.asarray(F, dtype=np.float64)
        # (a) NaN/inf guard
        if not np.all(np.isfinite(F)):
            logger.warning("[BarraRisk] F (factor covariance) contains NaN/inf — replacing with 0. "
                           "This usually indicates T < K (too few observations for factor count).")
            F = np.nan_to_num(F, nan=0.0, posinf=0.0, neginf=0.0)
        # (b) Symmetrize (numerical drift can make F slightly asymmetric)
        F = (F + F.T) / 2.0
        # (c) PSD projection: zero out negative eigenvalues
        try:
            _f_eigvals, _f_eigvecs = np.linalg.eigh(F)
            _neg_count = int(np.sum(_f_eigvals < 0))
            if _neg_count > 0:
                logger.info("[BarraRisk] F had %d negative eigenvalues — projecting to PSD.", _neg_count)
            _f_eigvals = np.clip(_f_eigvals, 1e-10, None)
            F = (_f_eigvecs * _f_eigvals) @ _f_eigvecs.T
            F = F.astype(np.float32)
        except Exception as _f_eigh_exc:
            logger.warning("[BarraRisk] F PSD projection failed: %s. Using identity fallback.", _f_eigh_exc, exc_info=True)
            F = np.eye(self.n_factors, dtype=np.float32) * 1e-4

        # Calculate residual idiosyncratic covariance
        # Sigma_resid = Sigma - B @ F @ B^T
        Sigma_factor = B @ F @ B.T
        Sigma_resid = Sigma - Sigma_factor
        # AUDIT-FIX (defect #P0-1): the prior implementation computed
        # specific_variances as `diag(Sigma) - diag(Sigma_factor)` — which
        # collapses to ≈ 0 (or negative) when K>N (more factor columns
        # than stocks) because the WLS factor-returns solve is underdetermined
        # and `factor_returns ≈ clean_rets`. The audit verified the live
        # pipeline shipped with K≈20-25 factors for N=15 stocks, producing
        # 98.6-99.98% factor-risk attribution per profile — implausibly high
        # for a concentrated 15-stock portfolio.
        # We now compute specific_variances from the ACTUAL per-day
        # regression residuals — `np.var(clean_rets - factor_returns @ B.T,
        # axis=0)` — which mirrors the working path in
        # `compute_barra_risk_decomposition` (optimizer.py:789/794) and
        # cannot be driven to a numerical 1e-8 by an over-parameterized fit.
        # For a 15-stock concentrated portfolio each name retains material
        # idiosyncratic risk the factors don't capture, so specific_variances
        # will be a realistic small-but-nonzero fraction of each stock's
        # total variance, and factor_ratio will fall to a realistic ~50-80%
        # instead of 99%.
        try:
            _residuals = clean_rets - (factor_returns @ B.T)
            specific_variances_resid = np.var(_residuals, axis=0, ddof=1) if _residuals.shape[0] > 1 else np.var(_residuals, axis=0)
        except Exception as _resid_exc:
            logger.warning(
                "[BarraRisk] Residual-based specific variance computation failed (%s) — "
                "falling back to the subtraction-based path (may under-report idiosyncratic risk).",
                _resid_exc,
            )
            specific_variances_resid = np.diag(Sigma) - np.diag(Sigma_factor)
        specific_variances = specific_variances_resid
        # Guard: specific_variances can be negative if the residual variance
        # estimator is biased (small-sample). Clip to small positive before
        # shrinkage.
        specific_variances = np.where(np.isfinite(specific_variances), specific_variances, 1e-8)

        # IDIOSYNCRATIC SHRINKAGE: Shrink specific variances towards their mean (Ledoit-Wolf-like diagonal shrinkage)
        # Prevents extreme values and zero idiosyncratic variance.
        shrinkage_coef = 0.10
        if len(specific_variances) > 1:
            # FIX: Clamp shrinkage target to non-negative. When the factor model
            # over-explains variance, mean_spec_var can be negative, which would
            # corrupt the shrinkage by pulling values towards a negative target.
            mean_spec_var = max(np.mean(specific_variances), 1e-8)
            specific_variances = (1.0 - shrinkage_coef) * specific_variances + shrinkage_coef * mean_spec_var

        # AUDIT-FIX (defect #P0-1): replace the 1e-8 hard floor with a
        # meaningful 5%-of-total-variance floor — even if the factor model
        # over-fits in-sample, the specific-risk component cannot be
        # structurally zeroed out, preventing the factor_ratio from
        # collapsing to ~1.0.
        _diag_sigma = np.diag(Sigma)
        _min_specific_floor = 0.05 * np.where(_diag_sigma > 0, _diag_sigma, 0.0)
        specific_variances = np.maximum(specific_variances, _min_specific_floor)
        specific_variances = np.clip(specific_variances, 1e-10, None)
        D_diag = np.diag(specific_variances)

        # Upgraded Residual Covariance Shrinkage (preserving off-diagonal sub-sector correlations)
        # We shrink the sample residual covariance matrix towards its diagonal D
        alpha_shrink = 0.15
        Sigma_residual_shrunken = (1.0 - alpha_shrink) * D_diag + alpha_shrink * Sigma_resid

        # Ensure the shrunken residual matrix is positive semi-definite (zero out negative eigenvalues)
        try:
            eigvals, eigvecs = np.linalg.eigh(Sigma_residual_shrunken)
            eigvals = np.clip(eigvals, 1e-8, None)
            Sigma_residual_shrunken = eigvecs @ np.diag(eigvals) @ eigvecs.T
        except Exception as _eigh_exc:
            # L6-fix: previously this exception was silently swallowed, which left
            # Sigma_residual_shrunken in whatever partially-corrupted state triggered
            # the failure. Log loudly so PSD projection failures are visible.
            logger.warning("[BarraRisk] np.linalg.eigh PSD projection failed: %s. Using unprojected residual matrix.", _eigh_exc, exc_info=True)

        # Reconstructed covariance matrix
        Sigma_reconstructed = Sigma_factor + Sigma_residual_shrunken

        # Ex-ante portfolio risk calculation
        total_var = float(w @ Sigma_reconstructed @ w)
        total_vol = float(np.sqrt(max(0.0, total_var)) * np.sqrt(252))  # Annualized

        # Factor variance = w^T * B * F * B^T * w
        factor_var = float(w @ Sigma_factor @ w)
        factor_vol = float(np.sqrt(max(0.0, factor_var)) * np.sqrt(252))

        # Specific variance = w^T * Sigma_residual_shrunken * w
        specific_var = float(w @ Sigma_residual_shrunken @ w)
        specific_vol = float(np.sqrt(max(0.0, specific_var)) * np.sqrt(252))

        # Margins & Contributions
        # Marginal contribution to risk (MCR) = (Sigma * w) / sqrt(w^T * Sigma * w)
        grad = Sigma_reconstructed @ w
        mcr = grad / (np.sqrt(total_var) + 1e-9)
        ccr = w * mcr

        # Portfolio exposures: Beta_p = B^T * w (K,)
        portfolio_exposures = B.T @ w

        # Individual factor risk contributions
        factor_risk_contributions = {}
        factor_mcr = F @ (B.T @ w)
        factor_ccr = (B.T @ w) * factor_mcr
        for idx, name in enumerate(self.factor_names):
            if idx < len(factor_ccr):
                factor_risk_contributions[name] = float(factor_ccr[idx])
            else:
                factor_risk_contributions[name] = 0.0

        # Total factor contribution ratio
        factor_ratio = max(0.0, factor_var / (total_var + 1e-9))
        specific_ratio = max(0.0, specific_var / (total_var + 1e-9))
        ratio_sum = factor_ratio + specific_ratio
        if ratio_sum > 1e-9:
            factor_ratio /= ratio_sum
            specific_ratio /= ratio_sum
        else:
            factor_ratio = 0.5
            specific_ratio = 0.5

        # ── Benchmark Risk Metrics (Tracking Error & Realized Beta) ──
        tracking_error = 0.0
        portfolio_beta = 1.0
        if benchmark_returns is not None and not benchmark_returns.empty:
            try:
                # Align dates
                aligned_df = pd.DataFrame({
                    "bench": benchmark_returns
                })
                port_rets_series = pd.Series(clean_rets @ w, index=returns.index)
                aligned_df["port"] = port_rets_series
                aligned_df = aligned_df.dropna()

                if len(aligned_df) >= 10:
                    # Portfolio Beta
                    # AUDIT-FIX (Round 6, A1-P3-13): np.cov uses ddof=1 while
                    # np.var defaults to ddof=0 — the mismatch inflated beta
                    # by T/(T-1) (+11% at T=10). Use ddof=1 on both.
                    cov_mat = np.cov(aligned_df["port"], aligned_df["bench"])
                    bench_var = float(np.var(aligned_df["bench"], ddof=1))
                    if bench_var > 1e-9:
                        portfolio_beta = float(cov_mat[0, 1] / bench_var)

                    # Ex-Ante Tracking Error (volatility of active returns)
                    active_rets = aligned_df["port"] - aligned_df["bench"]
                    te_val = float(np.std(active_rets) * np.sqrt(252)) if len(active_rets) > 0 else 0.0
                    tracking_error = 0.0 if np.isnan(te_val) else te_val
            except Exception as e:
                logger.warning("[BarraRisk] Failed to calculate benchmark relative metrics: %s", e, exc_info=True)

        # ── Factor-Based Stress Scenario Analysis (Aladdin-Style) ──
        # AUDIT-FIX (defect #P0-8): the prior implementation:
        #   1. Used `portfolio_exposures` (a cross-sectional z-score tilt,
        #      typical magnitude 0.5-2.0) instead of a regression beta —
        #      so `impact = z_tilt * shock_val * factor_ann_vol` was
        #      dimensionally wrong (dimensionless * dimensionless * vol)
        #      and produced impossible values like +34.3% gain in a
        #      "Momentum Crash" scenario (profile 1) and -83.5% loss in
        #      "Liquidity Squeeze" for the All-Weather profile.
        #   2. Treated `shock_val` (e.g. -4.0 for Liquidity) as a "4-SD
        #      shock", so `shock_val * factor_ann_vol` could already be
        #      -1.60 (-160%) by itself — bounded by nothing.
        #   3. Published the unbounded `impact` directly as a portfolio
        #      return fraction in the result dict, which the UI displayed
        #      as "Est. Portfolio Loss %" with no sanity clamp.
        # We now (a) compute asset-level factor BETAS via OLS regression of
        # asset returns on the already-estimated factor_returns matrix, (b)
        # treat `shock_val` as a FRACTIONAL factor-return shock (e.g.
        # Liquidity = -0.04 = -4%, not -4 SD), and (c) clamp both ends so
        # long-only returns are bounded by ±100%. We also raise a warning
        # if any scenario's |port_ret| > 0.60 (a hard 60% one-shot move).
        # Build asset-level factor betas: B_betas = lstsq(factor_returns, clean_rets)
        # so the stress formula uses true return sensitivities, not z-score tilts.
        try:
            _beta_coeffs, _, _, _ = np.linalg.lstsq(factor_returns, clean_rets, rcond=None)
            # _beta_coeffs shape: (K, N) — each column is the beta vector for one stock
            B_betas = _beta_coeffs.T  # shape (N, K)
            _portfolio_betas = B_betas.T @ w  # shape (K,)
        except Exception as _beta_exc:
            logger.warning(
                "[BarraRisk] Beta regression for stress scenarios failed (%s) — "
                "falling back to z-score-tilt path (stress impacts may be unreliable).",
                _beta_exc,
            )
            B_betas = B
            _portfolio_betas = portfolio_exposures

        factor_scenarios = {
            "Momentum Crash (Value Rotation)": {
                "Momentum": -0.03, "Value": 0.02, "Growth": -0.01
            },
            "Growth Compression (Tech Selloff)": {
                "Growth": -0.03, "Quality": -0.01, "Volatility": 0.02
            },
            "Liquidity Squeeze / Credit Crunch": {
                "Liquidity": -0.04, "Volatility": 0.03, "Leverage": -0.02
            },
            "Quality Flight to Safety": {
                "Quality": 0.03, "Size": -0.015, "Volatility": -0.02
            }
        }

        factor_stress_impacts = {}
        factor_stress_asset_impacts = {}
        for sc_name, shocks in factor_scenarios.items():
            port_ret = 0.0
            asset_impacts = {}
            for f_name, shock_val in shocks.items():
                if f_name in self.factor_names:
                    f_idx = self.factor_names.index(f_name)
                    # AUDIT-FIX (defect #P0-8): shock_val is now a fractional
                    # factor-return shock (e.g. -0.04 = -4%), bounded to ±1.0
                    # so no scenario can produce an impossible factor-return
                    # greater than ±100%.
                    shock_return_f = float(np.clip(shock_val, -1.0, 1.0))
                    port_ret += float(_portfolio_betas[f_idx] * shock_return_f)
                    for i, ticker in enumerate(stocks):
                        _asset_ret = float(B_betas[i, f_idx] * shock_return_f)
                        # Long-only asset returns bounded by ±100%.
                        _asset_ret = float(np.clip(_asset_ret, -1.0, 1.0))
                        asset_impacts[ticker] = asset_impacts.get(ticker, 0.0) + _asset_ret
            # AUDIT-FIX (defect #P0-8): final portfolio-level sanity clamp —
            # long-only portfolio return bounded by ±100%.
            port_ret = float(np.clip(port_ret, -1.0, 1.0))
            factor_stress_impacts[sc_name] = port_ret
            factor_stress_asset_impacts[sc_name] = asset_impacts
            # AUDIT-FIX (defect #P0-8): raise a warning when a scenario
            # produces an implausible one-shot move (>60% in a single
            # scenario is outside any historical precedent for NSE stocks).
            if abs(port_ret) > 0.60:
                logger.warning(
                    "[BarraRisk] Stress scenario '%s' produced an implausible "
                    "one-shot portfolio return of %.2f%% — betas or shock magnitudes "
                    "may need re-verification.",
                    sc_name, port_ret * 100.0,
                )

        # ── Institutional Portfolio Analytics (Aladdin & PORT standards) ──
        # 1. Diversification Ratio
        vols = np.sqrt(np.maximum(np.diag(Sigma_reconstructed), 1e-12))
        wtd_vol = np.sum(w * vols)
        div_ratio = wtd_vol / (np.sqrt(total_var) + 1e-9)

        # 2. Risk Entropy (Shannon entropy of component risk contributions)
        portfolio_daily_vol = np.sqrt(total_var)
        rc = ccr / (portfolio_daily_vol + 1e-9)
        rc_clean = np.maximum(rc, 0.0)
        rc_sum = np.sum(rc_clean)
        if rc_sum > 0:
            rc_clean = rc_clean / rc_sum
        else:
            rc_clean = np.ones_like(rc_clean) / len(rc_clean)
        entropy = -np.sum(rc_clean * np.log(np.clip(rc_clean, 1e-9, None)))
        normalized_entropy = entropy / np.log(len(stocks)) if len(stocks) > 1 else 0.0

        # 3. Active Share relative to equal-weighted parent universe
        all_univ = set(returns.columns).union(stocks)
        n_univ = len(all_univ)
        active_share = 0.0
        if n_univ > 0:
            bench_w = 1.0 / n_univ
            norm_w_dict = {stocks[idx]: float(w[idx]) for idx in range(len(stocks))}
            abs_diff = sum(abs(norm_w_dict.get(t, 0.0) - bench_w) for t in all_univ)
            active_share = 0.5 * abs_diff

        # 4. Ex-ante Cornish-Fisher VaR and CVaR (annualized)
        r_p = clean_rets @ w
        ex_ante_var_95 = 0.0
        ex_ante_var_99 = 0.0
        ex_ante_cvar_95 = 0.0
        ex_ante_cvar_99 = 0.0
        if len(r_p) > 2:
            try:
                # Calculate daily mean and standard deviation
                mu_d = float(r_p.mean())
                sigma_d = float(r_p.std())
                
                # Annualize parameters
                mu_a = mu_d * 252
                sigma_a = sigma_d * np.sqrt(252)
                
                # Calculate portfolio skewness and excess kurtosis
                # AUDIT-FIX (Round 6, A1-P3-15): removed stray debug print() that
                # polluted production stdout on every decompose_risk() call.
                from scipy.stats import skew, kurtosis
                S = float(skew(r_p))
                K = float(kurtosis(r_p))
                
                # Winsorize skewness and excess kurtosis to stabilize Cornish-Fisher under small/noisy samples
                S = np.clip(S, -1.0, 1.0)
                K = np.clip(K, 0.0, 5.0)
                
                # Standard normal quantiles
                # For 95% confidence (5% tail): z_95 = -1.644853
                # For 99% confidence (1% tail): z_99 = -2.326348
                
                def get_cf_quantile(z):
                    return z + (S / 6.0) * (z**2 - 1.0) + (K / 24.0) * (z**3 - 3.0 * z) - (S**2 / 36.0) * (2.0 * z**3 - 5.0 * z)

                z_cf_95 = get_cf_quantile(-1.644853)
                z_cf_99 = get_cf_quantile(-2.326348)

                z_cf_fallback_triggered = False
                if abs(z_cf_99) < abs(z_cf_95):
                    z_cf_99 = z_cf_95 * 1.30
                    z_cf_fallback_triggered = True

                # Positive Loss Magnitude: VaR represents maximum loss at alpha confidence
                # Conservative risk convention: drift set to min(0.0, mu_a) to avoid masking tail risk with optimistic expected returns.
                mu_a_var = min(0.0, mu_a)
                ex_ante_var_95 = max(0.0, -(mu_a_var + z_cf_95 * sigma_a))
                ex_ante_var_99 = max(ex_ante_var_95, -(mu_a_var + z_cf_99 * sigma_a))

                _phi_95 = np.exp(-0.5 * (z_cf_95**2)) / np.sqrt(2.0 * np.pi)
                _phi_99 = np.exp(-0.5 * (z_cf_99**2)) / np.sqrt(2.0 * np.pi)
                # AUDIT-FIX (Round 20 — R20-10): CVaR(99%) previously equaled
                # VaR(99%) EXACTLY on fat-tailed portfolios (confirmed in live
                # logs: 67.28=67.28, 45.28=45.28, ...) because the Gaussian ES
                # formula φ(z_cf)/α SHRINKS as the CF quantile grows
                # (φ(3.0)/0.01 = 0.44 < 3.0) while CF VaR grows — the max()
                # clamp then silently pinned CVaR to VaR, which is impossible
                # for continuous distributions (ES is strictly > VaR).
                # Fix: ES is computed under the SAME Cornish-Fisher quantile
                # mapping via the exact identity ES_α = (1/α)∫₀^α VaR_u du
                # (average of the CF VaR across tail levels), which is
                # guaranteed ≥ VaR_α by monotonicity of the tail quantile.
                from scipy.stats import norm as _norm_dist

                def _cf_tail_mean_z(alpha: float, n_grid: int = 256) -> float:
                    us = np.linspace(alpha / n_grid, alpha, n_grid)
                    zs = _norm_dist.ppf(us)
                    z_cf_grid = (
                        zs
                        + (S / 6.0) * (zs**2 - 1.0)
                        + (K / 24.0) * (zs**3 - 3.0 * zs)
                        - (S**2 / 36.0) * (2.0 * zs**3 - 5.0 * zs)
                    )
                    return float(np.mean(z_cf_grid))

                _es_z_95 = _cf_tail_mean_z(0.05)
                _es_z_99 = _cf_tail_mean_z(0.01)
                ex_ante_cvar_95 = max(0.0, -(mu_a_var + _es_z_95 * sigma_a))
                # numerical guard only — with the tail-average identity this
                # should never bind (ES ≥ VaR analytically); keep VaR monotonicity
                ex_ante_cvar_95 = max(ex_ante_cvar_95, ex_ante_var_95)
                ex_ante_cvar_99 = max(ex_ante_cvar_95, -(mu_a_var + _es_z_99 * sigma_a))
                if ex_ante_cvar_99 <= ex_ante_var_99:
                    # honest disclosure instead of a silent equality pin
                    ex_ante_cvar_99 = ex_ante_var_99
                    self._last_cvar_clamped = True  # diagnostic flag
                else:
                    self._last_cvar_clamped = False
            except Exception:
                # Fallback to standard historical VaR/CVaR if scipy or calculation fails.
                mu_d = float(r_p.mean())
                sigma_d = float(r_p.std())
                mu_a = mu_d * 252.0
                sigma_a = sigma_d * np.sqrt(252.0)
                mu_a_var = min(0.0, mu_a)

                # Normal-distribution VaR (no Cornish-Fisher adjustment)
                ex_ante_var_95 = max(0.0, -(mu_a_var + (-1.644853) * sigma_a))
                ex_ante_var_99 = max(0.0, -(mu_a_var + (-2.326348) * sigma_a))
                # CVaR under normality: CVaR_alpha = mu + sigma * phi(z) / alpha
                _phi_95 = np.exp(-0.5 * (-1.644853)**2) / np.sqrt(2.0 * np.pi)
                _phi_99 = np.exp(-0.5 * (-2.326348)**2) / np.sqrt(2.0 * np.pi)
                ex_ante_cvar_95 = max(ex_ante_var_95, sigma_a * _phi_95 / 0.05 - mu_a_var)
                ex_ante_cvar_99 = max(ex_ante_var_99, sigma_a * _phi_99 / 0.01 - mu_a_var)

        return {
            "covariance_matrix": Sigma_reconstructed,
            "portfolio_volatility": total_vol,
            "factor_volatility": factor_vol,
            "specific_volatility": specific_vol,
            "factor_risk_ratio": factor_ratio,
            "specific_risk_ratio": specific_ratio,
            "portfolio_exposures": {self.factor_names[i]: float(portfolio_exposures[i]) for i in range(self.n_factors)},
            "factor_contributions": {name: val / (total_var + 1e-9) for name, val in factor_risk_contributions.items()},
            "security_mcr": {stocks[i]: float(mcr[i]) for i in range(len(stocks))},
            "security_ccr": {stocks[i]: float(ccr[i]) for i in range(len(stocks))},
            "tracking_error": tracking_error,
            "portfolio_beta": portfolio_beta,
            "factor_stress_tests": factor_stress_impacts,
            "factor_stress_asset_tests": factor_stress_asset_impacts,
            "diversification_ratio": float(div_ratio),
            "risk_entropy": float(normalized_entropy),
            "active_share": float(active_share),
            "ex_ante_var_95": float(ex_ante_var_95),
            "ex_ante_var_99": float(ex_ante_var_99),
            "ex_ante_cvar_95": float(ex_ante_cvar_95),
            "ex_ante_cvar_99": float(ex_ante_cvar_99),
            "z_cf_fallback_triggered": bool(z_cf_fallback_triggered if 'z_cf_fallback_triggered' in locals() else False),
        }

    # ── Macroeconomic Factor Risk & Stress Tests ─────────────────────────────
    def compute_macro_beta(
        self,
        asset_returns: pd.DataFrame,
        macro_factors: pd.DataFrame
    ) -> pd.DataFrame:
        """Computes OLS regression exposures of assets against macroeconomic factors.
        
        Macro factors include: Inflation (CPI), Yield Spread (Interest Rates), Industrial Production.
        """
        # Align index
        common = asset_returns.index.intersection(macro_factors.index)
        if len(common) < 5:
            # Insufficient overlapping data, return zero matrix
            return pd.DataFrame(0.0, index=asset_returns.columns, columns=macro_factors.columns)
            
        Y = asset_returns.loc[common]
        X = macro_factors.loc[common].copy()
        X["Intercept"] = 1.0
        
        # Run OLS: Beta = (X^T * X)^-1 * X^T * Y
        x_mat = X.to_numpy()
        y_mat = Y.to_numpy()
        
        try:
            betas = np.linalg.lstsq(x_mat, y_mat, rcond=None)[0]
            # Exclude Intercept
            beta_df = pd.DataFrame(
                betas[:-1, :].T,
                index=asset_returns.columns,
                columns=macro_factors.columns
            )
            return beta_df
        except Exception:
            return pd.DataFrame(0.0, index=asset_returns.columns, columns=macro_factors.columns)

    def stress_test_scenario(
        self,
        weights: Dict[str, float],
        asset_returns: pd.DataFrame,
        macro_factors: pd.DataFrame,
        scenario_shifts: Dict[str, float]
    ) -> tuple[float, Dict[str, float]]:
        """Calculates expected portfolio impact under target macroeconomic shock shifts.
        
        Returns:
            Tuple[portfolio_impact_pct, asset_impacts_pct]
        """
        betas = self.compute_macro_beta(asset_returns, macro_factors)
        
        asset_impacts = {}
        port_impact = 0.0
        
        for asset in betas.index:
            impact = 0.0
            for factor, shift in scenario_shifts.items():
                if factor in betas.columns:
                    impact += float(betas.loc[asset, factor]) * shift
            asset_impacts[asset] = impact
            
            w = weights.get(asset, 0.0)
            port_impact += w * impact
            
        return port_impact, asset_impacts

    def calculate_macro_tracking_error(
        self,
        weights: Dict[str, float],
        asset_returns: pd.DataFrame,
        benchmark_returns: pd.Series,
        macro_factors: pd.DataFrame
    ) -> float:
        """Estimates active tracking error volatility explained purely by macro beta shocks."""
        betas = self.compute_macro_beta(asset_returns, macro_factors)
        
        # Build portfolio active exposures
        active_weights = []
        tickers = asset_returns.columns
        for t in tickers:
            w_p = weights.get(t, 0.0)
            # Benchmark is equal weighted for active tracking comparison
            w_b = 1.0 / len(tickers)
            active_weights.append(w_p - w_b)
            
        active_w_arr = np.array(active_weights)
        beta_mat = betas.to_numpy() # Shape: (N, K)
        
        # Active factor loading: active_beta = active_w^T * Beta
        active_beta = active_w_arr @ beta_mat
        
        # Factor covariance
        F_cov = np.cov(macro_factors.fillna(0.0).to_numpy(), rowvar=False)
        if F_cov.ndim == 0:
            F_cov = np.array([[F_cov]])
            
        # Explained tracking variance = active_beta * F_cov * active_beta^T
        tracking_var = active_beta @ F_cov @ active_beta.T
        tracking_error = float(np.sqrt(max(0.0, tracking_var * 252.0)))
        return tracking_error


class BarraFactorRiskModel:
    """Adapter wrapping FactorRiskDecomposer for Barra-style risk decomposition."""
    def __init__(self, cfg=None):
        self.cfg = cfg or {}
        self.decomposer = FactorRiskDecomposer()

    def decompose_portfolio_risk(self, selected, weights, signal_df, clean_returns, log_cb=None):
        # AUDIT-FIX (Round 6, A1-P1-1): the previous call passed `returns_matrix=`
        # — a kwarg compute_factor_exposures() never accepted — so EVERY call
        # raised TypeError before any math ran and the except-block returned
        # hardcoded canned risk numbers (total 21.5% vol etc.) on every optimizer
        # run. The success path also returned decompose_risk's raw key set while
        # the fallback returned the adapter's documented *_ann_pct keys, so the
        # two contracts never agreed. Fixed: correct kwarg + a merged result
        # carrying BOTH key sets, all derived from the REAL decomposition.
        try:
            # Filter out CASH or synthetic non-equity assets from risk decomposition weights
            if isinstance(weights, dict):
                clean_weights = {k: v for k, v in weights.items() if k != "CASH" and (clean_returns is None or k in clean_returns.columns)}
            elif isinstance(weights, pd.Series):
                clean_weights = weights[weights.index != "CASH"]
                if clean_returns is not None:
                    clean_weights = clean_weights[clean_weights.index.isin(clean_returns.columns)]
            else:
                clean_weights = weights

            exp_df = self.decomposer.compute_factor_exposures(signal_df, returns=clean_returns)
            result = self.decomposer.decompose_risk(returns=clean_returns, exposures=exp_df, weights=clean_weights)
            if not isinstance(result, dict) or not result:
                raise ValueError("FactorRiskDecomposer.decompose_risk returned an empty result")
            total_vol = float(result.get("portfolio_volatility", 0.0) or 0.0)
            factor_vol = float(result.get("factor_volatility", 0.0) or 0.0)
            specific_vol = float(result.get("specific_volatility", 0.0) or 0.0)
            factor_ratio = float(result.get("factor_risk_ratio", 0.5) or 0.5)
            specific_ratio = float(result.get("specific_risk_ratio", 0.5) or 0.5)
            result.update({
                "total_risk_ann_pct": total_vol * 100.0,
                "factor_risk_ann_pct": factor_vol * 100.0,
                "specific_risk_ann_pct": specific_vol * 100.0,
                "factor_risk_share_pct": factor_ratio * 100.0,
                "specific_risk_share_pct": specific_ratio * 100.0,
                "factor_exposures": result.get("portfolio_exposures", {}),
                "marginal_contributions": result.get("security_mcr", {}),
            })
            return result
        except Exception as ex:
            if log_cb:
                log_cb(f"[BarraRisk] Decomposition FAILED — returning empty result (no fabricated numbers): {ex}")
            logger.warning("[BarraRisk] Decomposition failed: %s", ex, exc_info=True)
            # AUDIT-FIX (Round 6, A1-P1-1): fail with explicit NaN markers and a
            # `degraded: True` flag instead of plausible-looking canned numbers —
            # downstream consumers must be able to tell real from fabricated.
            return {
                "total_risk_ann_pct": float("nan"),
                "factor_risk_ann_pct": float("nan"),
                "specific_risk_ann_pct": float("nan"),
                "factor_risk_share_pct": float("nan"),
                "specific_risk_share_pct": float("nan"),
                "factor_exposures": {},
                "marginal_contributions": {},
                "degraded": True,
                "degraded_reason": str(ex),
            }

