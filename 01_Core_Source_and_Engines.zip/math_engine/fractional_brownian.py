"""
math_engine/fractional_brownian.py
==================================
Fractional Brownian Motion (fBM) Rough Volatility Engine.

Models rough volatility persistent regimes (Hurst parameter H < 0.5) to forecast non-Markovian volatility jumps.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any

logger = logging.getLogger(__name__)


class FractionalBrownianVolEngine:
    """
    Fractional Brownian Motion (fBM) Rough Volatility Estimator.
    """

    @staticmethod
    def estimate_rough_volatility(returns_series: pd.Series, lag_window: int = 10) -> Dict[str, Any]:
        """
        Estimates rough volatility Hurst parameter H_vol from log volatility structure function.
        H_vol < 0.5 -> Rough volatility regime (high variance of volatility).
        """
        clean_ret = returns_series.dropna().values
        if len(clean_ret) < lag_window * 3:
            return {"hurst_vol": 0.50, "is_rough_volatility": False}

        log_vol = np.log(np.abs(clean_ret) + 1e-6)
        lags = range(1, lag_window + 1)
        variogram = [float(np.mean(np.abs(log_vol[lag:] - log_vol[:-lag]) ** 2)) for lag in lags]

        # Fit log(variogram) vs log(lags)
        poly = np.polyfit(np.log(lags), np.log(np.asarray(variogram, dtype=float) + 1e-9), 1)
        h_vol = float(poly[0] / 2.0)
        h_vol_clamped = round(min(max(h_vol, 0.05), 0.95), 4)

        return {
            "hurst_vol": h_vol_clamped,
            "is_rough_volatility": bool(h_vol_clamped < 0.45)
        }
