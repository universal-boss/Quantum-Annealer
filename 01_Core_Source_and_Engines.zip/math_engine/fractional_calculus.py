"""
math_engine/fractional_calculus.py
==================================
Fractional Calculus Volatility Memory Engine (Grünwald-Letnikov Derivative).

Computes fractional derivatives D^alpha f(t) (order alpha in (0, 1)) on log-volatility time series
to measure long-range memory and non-Markovian persistence.
"""
from __future__ import annotations

import logging
import math
import numpy as np
import pandas as pd
from typing import Dict, Any

logger = logging.getLogger(__name__)


class FractionalCalculusEngine:
    """
    Grünwald-Letnikov Fractional Derivative Volatility Memory Calculator.
    """

    @staticmethod
    def compute_fractional_derivative(series: pd.Series, alpha: float = 0.40, num_terms: int = 15) -> Dict[str, Any]:
        """
        Computes D^alpha f(t) = sum_{k=0}^{N} (-1)^k * binom(alpha, k) * f(t - k).
        """
        clean_vals = series.dropna().values
        n = len(clean_vals)
        if n < num_terms:
            return {"fractional_memory_val": 0.0, "is_high_memory_persistence": False}

        # Calculate Grünwald-Letnikov coefficients w_k = (-1)^k * binom(alpha, k)
        w = [1.0]
        for k in range(1, num_terms):
            w_k = w[-1] * (k - 1 - alpha) / float(k)
            w.append(w_k)

        w_arr = np.array(w)
        # Apply fractional convolution filter to recent window
        recent_window = clean_vals[-num_terms:][::-1]
        frac_deriv = float(np.sum(w_arr * recent_window))

        return {
            "fractional_memory_val": round(frac_deriv, 4),
            "fractional_order_alpha": alpha,
            "is_high_memory_persistence": bool(abs(frac_deriv) > 1.5 * float(np.std(clean_vals)))
        }
