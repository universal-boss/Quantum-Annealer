"""
math_engine/fusion_model.py
==============================
Fuses multi-tower embeddings (visual and temporal) into a single 512-d latent representation.
Supports timeframe-specific weights and regime-conditioned adjustments.
"""
from __future__ import annotations

import logging
import numpy as np
from typing import Optional

logger = logging.getLogger(__name__)


class FusedEmbeddingComposer:
    """Fuses multi-tower embeddings into a single unified 512-d retrieval embedding.

    Provides normalization, weighting adjustments based on timeframes and market regimes,
    and returns a normalized fused representation.
    """

    def __init__(self) -> None:
        # Default weighting maps: (visual_wt, temporal_wt, context_wt)
        # Visual represents the geometric image features.
        # Temporal represents raw time-series microstructure features.
        # Context represents metadata/regime features.
        self.default_weights = {
            "1h": (0.35, 0.45, 0.20),
            "4h": (0.40, 0.40, 0.20),
            "1d": (0.50, 0.30, 0.20),
            "1wk": (0.45, 0.35, 0.20),
        }

    def compose(
        self,
        visual_emb: np.ndarray,
        temporal_emb: np.ndarray,
        context_emb: Optional[np.ndarray] = None,
        regime: Optional[str] = None,
        timeframe: str = "1d",
    ) -> np.ndarray:
        """Compose the final fused embedding by blending visual, temporal, and context features.

        Normalizes input vectors, queries weighting coefficients, adjusts them based on the
        current market regime, and outputs an L2-normalized 512-d vector.

        Args:
            visual_emb: 1-D array of shape (512,) representing visual features.
            temporal_emb: 1-D array of shape (512,) representing temporal features.
            context_emb: Optional 1-D array of shape (512,) representing context features.
            regime: Optional market regime label e.g., 'Bull', 'Bear', 'Sideways'.
            timeframe: Timeframe code e.g., '1h', '4h', '1d', '1wk'.

        Returns:
            Normalized 1-D float32 array of shape (512,) ready for FAISS search.
        """
        # Load inputs as numpy arrays
        v = np.asarray(visual_emb, dtype=np.float32)
        t = np.asarray(temporal_emb, dtype=np.float32)

        # 1. Normalize individual vectors
        v_norm = float(np.linalg.norm(v))
        v = v / v_norm if v_norm > 1e-9 else np.zeros_like(v)

        t_norm = float(np.linalg.norm(t))
        t = t / t_norm if t_norm > 1e-9 else np.zeros_like(t)

        # 2. Retrieve timeframe weights
        tf_key = timeframe.lower()
        w_v, w_t, w_c = self.default_weights.get(tf_key, (0.50, 0.30, 0.20))

        # 3. Apply regime-conditioned adjustments
        if regime is not None:
            r = regime.lower()
            if r == "bull":
                w_v += 0.10
                w_t -= 0.05
                w_c -= 0.05
            elif r == "bear":
                w_v -= 0.10
                w_t += 0.15
                w_c -= 0.05
            elif r == "sideways":
                w_v += 0.05
                w_t -= 0.05

        # 4. Normalize weighting factors
        w_sum = w_v + w_t
        if context_emb is not None:
            w_sum += w_c

        w_v /= w_sum
        w_t /= w_sum
        if context_emb is not None:
            w_c /= w_sum

        # 5. Blend towers
        fused = w_v * v + w_t * t
        if context_emb is not None:
            c = np.asarray(context_emb, dtype=np.float32)
            c_norm = float(np.linalg.norm(c))
            c = c / c_norm if c_norm > 1e-9 else np.zeros_like(c)
            fused += w_c * c

        # 6. Re-normalize output vector
        f_norm = float(np.linalg.norm(fused))
        fused = fused / f_norm if f_norm > 1e-9 else np.zeros_like(fused)

        return fused.astype(np.float32, copy=False)
