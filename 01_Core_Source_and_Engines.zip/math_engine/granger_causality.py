"""
math_engine/granger_causality.py
================================
Econometric Granger Causality Analysis Engine.

Computes pairwise Vector Autoregressive (VAR) Granger causality tests 
between asset return series to identify lead-lag relationships and directional information flow.
"""

from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, Tuple, List

logger = logging.getLogger(__name__)


class GrangerCausalityEngine:
    """
    Econometric Granger Causality Engine.
    Evaluates whether past returns of Asset X provide statistically significant 
    information about future returns of Asset Y beyond Y's own history.
    """

    @staticmethod
    def test_granger_causality(
        x: pd.Series | np.ndarray,
        y: pd.Series | np.ndarray,
        max_lag: int = 5
    ) -> Dict[str, Any]:
        """
        Executes Granger Causality test (X -> Y).
        Null Hypothesis (H0): X does NOT Granger-cause Y.
        
        Returns F-statistic, p-value, optimal lag, and directional causality verdict.
        """
        x_vals = np.asarray(x, dtype=float)
        y_vals = np.asarray(y, dtype=float)

        min_len = min(len(x_vals), len(y_vals))
        if min_len < max_lag + 20:
            return {
                "causality_exists": False,
                "f_stat": 0.0,
                "p_value": 1.0,
                "optimal_lag": 1,
                "verdict": "Insufficient data points for VAR Granger causality"
            }

        x_trim = x_vals[-min_len:]
        y_trim = y_vals[-min_len:]

        try:
            from statsmodels.tsa.stattools import grangercausalitytests
            df_data = pd.DataFrame({"Y": y_trim, "X": x_trim})
            res = grangercausalitytests(df_data[["Y", "X"]], maxlag=max_lag, verbose=False)
            
            # Find best lag with minimum p-value on F-test (params_ftest)
            best_lag = 1
            min_p_val = 1.0
            best_f_stat = 0.0

            for lag, out in res.items():
                f_test = out[0]["params_ftest"]
                f_stat = float(f_test[0])
                p_val = float(f_test[1])
                if p_val < min_p_val:
                    min_p_val = p_val
                    best_f_stat = f_stat
                    best_lag = lag

            has_causality = min_p_val < 0.05
            verdict = f"Statistically Significant Lead-Lag (F={best_f_stat:.2f}, p={min_p_val:.4f}, lag={best_lag})" if has_causality else f"No Lead-Lag Causality (p={min_p_val:.4f})"

            return {
                "causality_exists": bool(has_causality),
                "f_stat": float(round(best_f_stat, 2)),
                "p_value": float(round(min_p_val, 4)),
                "optimal_lag": int(best_lag),
                "verdict": verdict
            }
        except Exception as ex:
            logger.debug(f"Granger causality execution notice: {ex}", exc_info=True)
            return {
                "causality_exists": False,
                "f_stat": 0.0,
                "p_value": 1.0,
                "optimal_lag": 1,
                "verdict": "Granger calculation unavailable"
            }


# Backward-compatible alias
ContinuousTimeGrangerCausality = GrangerCausalityEngine
