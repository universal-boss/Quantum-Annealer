"""
math_engine/hampel_outlier_filter.py
====================================
Microstructure Hampel Outlier & Tick Spike Filter Engine.

Detects and filters bad tick data and spurious exchange price spikes 
using Hampel Filters (Median Absolute Deviation / MAD bounds).
"""

from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, Tuple, List

logger = logging.getLogger(__name__)


class HampelOutlierFilter:
    """
    Microstructure Outlier & Spike Filter.
    Removes bad tick data spikes without distorting genuine market price trends.
    """

    @staticmethod
    def filter_hampel_outliers(
        prices: pd.Series | np.ndarray,
        window: int = 7,
        n_sigmas: float = 3.0
    ) -> Tuple[np.ndarray, List[int]]:
        """
        Executes Hampel Filter:
        Identifies outlier ticks where |P_t - Median_window| > n_sigmas * 1.4826 * MAD_window.
        Replaces outliers with the local rolling median.
        
        Returns:
            Tuple[clean_prices_array, outlier_indices_list]
        """
        p = np.asarray(prices, dtype=float).copy()
        n = len(p)

        if n < window:
            return p, []

        s = pd.Series(p)
        rolling_median = s.rolling(window=window, min_periods=1, center=True).median()
        rolling_mad = s.rolling(window=window, min_periods=1, center=True).apply(
            lambda x: np.median(np.abs(x - np.median(x))), raw=True
        )

        threshold = n_sigmas * 1.4826 * (rolling_mad + 1e-9)
        difference = np.abs(s - rolling_median)

        outlier_mask = difference > threshold
        outlier_indices = np.where(outlier_mask)[0].tolist()

        clean_p = p.copy()
        clean_p[outlier_mask] = rolling_median[outlier_mask]

        return clean_p, outlier_indices


# Backward-compatible alias
HampelGlitchFilter = HampelOutlierFilter
