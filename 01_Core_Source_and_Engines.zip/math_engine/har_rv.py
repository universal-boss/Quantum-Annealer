"""
math_engine/har_rv.py
=====================
HAR-RV: Heterogeneous Autoregressive Realized Volatility (Corsi 2009).

Replaces GARCH(1,1) for 1- to 30-day horizon vol forecasts.  Corsi
showed that RV decomposed into daily / weekly / monthly components
captures the multi-fractal structure of volatility better than
GARCH(1,1), beating it by 10-20% RMSE out-of-sample on most
equity indices.  The HAR specification is a simple constrained AR(22)
which makes it (a) trivially estimable by OLS, (b) interpretable
(short/medium/long-horizon components), and (c) much more robust in
small samples than multivariate GARCH.

Specification (Corsi 2009, eq. 5)
---------------------------------
    RV_{t+h} = β_0 + β_d · RV_t^{(d)} + β_w · RV_t^{(w)} + β_m · RV_t^{(m)} + ε_{t+h}

where:
    RV_t^{(d)} = RV at day t                        (1-day realized variance)
    RV_t^{(w)} = (1/5) · Σ_{i=0..4}  RV_{t-i}^{(d)} (weekly component)
    RV_t^{(m)} = (1/22) · Σ_{i=0..21} RV_{t-i}^{(d)} (monthly component)

Data dependency
---------------
True realized volatility requires intraday returns (e.g. 5-min bars).
When only daily OHLC is available, we approximate RV via the
Yang-Zhang (2000) drift-independent estimator (open-high-low-close
quadratic variation, minimises variance over Garman-Klass).  When
only close prices are available, we fall back to the bipower
variation of Barndorff-Nielsen & Shephard (2004), which is robust
to jumps.

References
----------
Corsi, F. (2009). "A simple approximate long-memory model of realized
volatility." Journal of Financial Econometrics 7(2): 174-196.

Yang, B. & Zhang, Q. (2000). "Drift-independent volatility estimation
based on high, low, open, close prices." Journal of Business 73(3):
477-491.

Barndorff-Nielsen, O.E. & Shephard, N. (2004). "Power and bipower
variation with application to finance." Econometric Reviews 23(2):
1-28.

Integration
-----------
Drop-in replacement for any `forecast_vol(...)` call that currently
uses GARCH(1,1).  In `optimizer_risk.compute_var_cvar`, use
`har_rv_forecast(yang_zhang_rv(ohlcv_panel))` as the 1-day-ahead vol
input to the VaR/ES formulas.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Optional, Tuple, Union

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# 1. Realized volatility estimators
# ---------------------------------------------------------------------------

def realized_variance_from_returns(returns: pd.Series) -> float:
    """Daily realized variance from intraday returns (sum of squared returns).

    This is the canonical estimator when intraday bars are available.
    """
    r = np.asarray(returns, dtype=float)
    r = r[np.isfinite(r)]
    if r.size == 0:
        return float("nan")
    return float(np.sum(r ** 2))


def bipower_variation(close_returns: pd.Series) -> float:
    """Barndorff-Nielsen-Shephard (2004) jump-robust realized variance.

    BV = (π/2) · (n/(n-1)) · Σ_{t=2..n} |r_{t-1}| · |r_t|

    Used as the close-to-close fallback when intraday bars / OHLC are
    not available.  BV converges to the integrated variance under
    no-jumps and stays finite under jumps, unlike Σ r_t² which
    explodes in the presence of discontinuities.
    """
    r = np.abs(np.asarray(close_returns, dtype=float))
    r = r[np.isfinite(r)]
    n = r.size
    if n < 2:
        return float("nan")
    bv = (np.pi / 2.0) * (n / (n - 1.0)) * np.sum(r[:-1] * r[1:])
    return float(bv)


def yang_zhang_rv(ohlcv: pd.DataFrame) -> pd.Series:
    """Yang-Zhang (2000) drift-independent daily realized variance.

    Approximates RV from daily OHLC when intraday bars are unavailable.

    Per-day Rogers-Satchell (1994) intraday variance (always ≥ 0 in
    theory, clip to 0 in finite samples to handle estimation noise):

        RS_t = (h_t - o_t)(h_t - c_t) + (l_t - o_t)(l_t - c_t)

    where o, h, l, c are log-prices on day t.

    Yang-Zhang (2000) decomposition into three orthogonal components:
        ON_t  = (u_t - mean(u))²       (overnight: open_t minus prev close)
        OC_t  = (c_t - o_t - mean(c-o))²   (open-to-close demeaned)
        RS_t  = Rogers-Satchell per-day intraday variance

    Optimal Yang-Zhang weight that minimizes estimator variance:
        α = mean(RS) / (mean(RS) + mean(OC))

    Rolling 22-day Yang-Zhang variance:
        σ²_YZ = (1/(n-1)) · Σ_{i} [ RS_i + α·OC_i + (1-α)·ON_i ]

    Returns a Series indexed by date of length len(ohlcv).
    """
    if not {"Open", "High", "Low", "Close"}.issubset(ohlcv.columns):
        raise ValueError("yang_zhang_rv requires Open/High/Low/Close columns")
    df = ohlcv.dropna(subset=["Open", "High", "Low", "Close"]).copy()
    if df.shape[0] < 2:
        return pd.Series(np.nan, index=df.index)

    log_o = np.log(df["Open"].astype(float)).values
    log_h = np.log(df["High"].astype(float)).values
    log_l = np.log(df["Low"].astype(float)).values
    log_c = np.log(df["Close"].astype(float)).values

    # Rogers-Satchell per-day intraday variance
    rs = (log_h - log_o) * (log_h - log_c) + (log_l - log_o) * (log_l - log_c)
    rs = np.clip(rs, 0.0, None)

    # Open-to-close demeaned
    oc = log_c - log_o
    oc_demean = oc - np.nanmean(oc)
    oc2 = np.clip(oc_demean ** 2, 0.0, None)

    # Overnight: open_t minus prev close
    on = log_o - np.roll(log_c, 1)
    on[0] = np.nan  # no prior close on first day
    on_demean = on - np.nanmean(on[1:])
    on2 = np.clip(on_demean ** 2, 0.0, None)

    # Optimal Yang-Zhang weight
    var_rs = float(np.nanmean(rs))
    var_oc = float(np.nanmean(oc2))
    denom = var_rs + var_oc
    alpha = float(var_rs / denom) if denom > 0 else 0.5

    rs_series = pd.Series(rs, index=df.index)
    oc_series = pd.Series(oc2, index=df.index)
    on_series = pd.Series(on2, index=df.index)

    n = 22
    rs_sum = rs_series.rolling(n, min_periods=5).sum()
    oc_sum = oc_series.rolling(n, min_periods=5).sum()
    on_sum = on_series.rolling(n, min_periods=5).sum()

    # AUDIT-FIX (Round 6, A1-P3-14): divide by the ACTUAL number of summed
    # terms, not the fixed (n-1)=21 — the first ~17 rolling values summed
    # only 5-21 terms yet divided by 21, biasing warm-up RV up to 4.7× low
    # and feeding the HAR fit with bad leading values.
    _counts = rs_series.rolling(n, min_periods=5).count()
    sigma2_yz = (rs_sum + alpha * oc_sum + (1.0 - alpha) * on_sum) / np.maximum(_counts - 1.0, 1.0)
    sigma2_yz.iloc[0] = np.nan
    sigma2_yz.name = "rv_yz"
    return sigma2_yz


def build_rv_series(
    ohlcv: Optional[pd.DataFrame] = None,
    close_returns: Optional[pd.Series] = None,
    intraday_returns: Optional[pd.DataFrame] = None,
) -> pd.Series:
    """Pick the best available realized-variance estimator.

    Preference order:
      1. intraday_returns (multi-column DataFrame of bar returns)
         -> Σ r² per day  (true RV)
      2. ohlcv (Open/High/Low/Close)
         -> Yang-Zhang (2000) drift-independent estimator
      3. close_returns (daily close-to-close)
         -> Barndorff-Nielsen-Shephard bipower variation (jump-robust)
    """
    if intraday_returns is not None and not intraday_returns.empty:
        # Aggregate intraday bars to daily RV: sum of squared intraday returns
        if isinstance(intraday_returns.index, pd.DatetimeIndex):
            grp = intraday_returns.groupby(intraday_returns.index.date)
        else:
            # Assume index has a 'date' or first column is timestamp
            grp = intraday_returns.groupby(intraday_returns.index)
        daily_rv = grp.apply(lambda x: float(np.nansum(np.asarray(x) ** 2)))
        daily_rv.index = pd.to_datetime(daily_rv.index)
        return daily_rv.sort_index()
    if ohlcv is not None and not ohlcv.empty:
        return yang_zhang_rv(ohlcv)
    if close_returns is not None:
        # Slide a 1-day window: RV_t = r_t²  (close-to-close)
        # Better: use rolling 22-day bipower variation as daily RV proxy
        n = len(close_returns)
        if n < 2:
            return pd.Series(np.nan, index=close_returns.index)
        return close_returns.rolling(22, min_periods=5).apply(
            lambda x: bipower_variation(pd.Series(x)), raw=False
        )
    raise ValueError("build_rv_series: at least one of ohlcv / close_returns / intraday_returns must be provided")


# ---------------------------------------------------------------------------
# 2. HAR-RV regression
# ---------------------------------------------------------------------------

def _build_har_design(rv: pd.Series, week_window: int = 5, month_window: int = 22) -> pd.DataFrame:
    """Build the HAR daily/weekly/monthly design matrix.

    Returns a DataFrame with columns ['rv_d', 'rv_w', 'rv_m', 'y']
    aligned such that row t predicts RV at day t+1.
    """
    rv_d = rv
    rv_w = rv.rolling(week_window, min_periods=min(3, week_window)).mean()
    rv_m = rv.rolling(month_window, min_periods=min(10, month_window)).mean()
    design = pd.concat([rv_d, rv_w, rv_m], axis=1)
    design.columns = ["rv_d", "rv_w", "rv_m"]
    # Predict next-day RV (Corsi's HAR-RV(1))
    design["y"] = rv.shift(-1)
    return design.dropna()


def fit_har_rv(rv: pd.Series, week_window: int = 5, month_window: int = 22, **kwargs) -> dict:
    """Fit HAR-RV(1) by OLS.

    Returns dict with betas, R², residual std, and historical context.
    """
    df = _build_har_design(rv, week_window=week_window, month_window=month_window)
    if df.shape[0] < 10:
        logger.warning(
            "[HAR-RV] not enough observations to fit (n=%d, need ≥10); "
            "returning degenerate model", df.shape[0]
        )
        return {
            "beta": np.zeros(4),
            "beta_intercept": 0.0,
            "beta_daily": 0.0,
            "beta_weekly": 0.0,
            "beta_monthly": 0.0,
            "r2": float("nan"),
            "resid_std": float("nan"),
            "n_obs": int(df.shape[0]),
            "rv_history": rv,
        }

    X = np.column_stack([np.ones(df.shape[0]),
                         df["rv_d"].values,
                         df["rv_w"].values,
                         df["rv_m"].values])
    y = df["y"].values
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    y_hat = X @ beta
    ss_res = float(np.sum((y - y_hat) ** 2))
    ss_tot = float(np.sum((y - y.mean()) ** 2))
    r2 = 1.0 - (ss_res / ss_tot) if ss_tot > 0 else float("nan")
    resid_std = float(np.std(y - y_hat, ddof=1)) if df.shape[0] > 1 else float("nan")
    return {
        "beta": beta,
        "beta_intercept": float(beta[0]),
        "beta_daily": float(beta[1]),
        "beta_weekly": float(beta[2]),
        "beta_monthly": float(beta[3]),
        "r2": r2,
        "resid_std": resid_std,
        "n_obs": int(df.shape[0]),
        "rv_history": rv,
    }


def har_rv_forecast(
    rv: pd.Series,
    horizon: int = 1,
    model: Optional[dict] = None,
) -> float:
    """Forecast RV at the given horizon (in trading days).

    For horizon > 1, uses the iterated HAR-RV forecast: feed back
    the forecast as rv_d at each step, with rv_w / rv_m updated as
    rolling means of (history + forecast).
    """
    if rv.empty:
        return float("nan")
    if model is None:
        model = fit_har_rv(rv)
    beta = model["beta"]
    if beta is None or np.all(beta == 0):
        return float("nan")

    # Work on a copy so we can extend with forecasts
    rv_ext = rv.copy()
    forecast = float("nan")
    for h in range(horizon):
        rv_d = rv_ext.iloc[-1]
        rv_w = rv_ext.tail(5).mean()
        rv_m = rv_ext.tail(22).mean() if len(rv_ext) >= 22 else rv_ext.mean()
        x = np.array([1.0, rv_d, rv_w, rv_m])
        forecast = float(x @ beta)
        # Append forecast to series for the next iteration
        new_idx = rv_ext.index[-1] + pd.Timedelta(days=1)
        rv_ext = pd.concat([rv_ext, pd.Series([forecast], index=[new_idx])])
    return forecast


def har_rv_forecast_with_intervals(
    rv: pd.Series,
    horizon: int = 1,
    confidence: float = 0.90,
    model: Optional[dict] = None,
    n_bootstrap: int = 1000,
    rng: Optional[np.random.Generator] = None,
) -> Tuple[float, float, float]:
    """Forecast RV with a residual-bootstrap prediction interval.

    Returns (point_forecast, lower, upper) where lower/upper are the
    (1-confidence)/2 and 1-(1-confidence)/2 quantiles of the
    bootstrapped forecast distribution.

    The residual bootstrap re-samples the in-sample residuals, adds
    them to the 1-step forecast, then iterates h steps. This is the
    standard Corsi (2009) approach for HAR-RV interval construction.
    """
    if model is None:
        model = fit_har_rv(rv)
    if model["n_obs"] < 10 or not np.isfinite(model["resid_std"]):
        f = har_rv_forecast(rv, horizon=horizon, model=model)
        return f, f, f
    df = _build_har_design(rv)
    residuals = (df["y"].values
                 - np.column_stack([np.ones(df.shape[0]),
                                    df["rv_d"].values,
                                    df["rv_w"].values,
                                    df["rv_m"].values]) @ model["beta"])
    rng = rng or np.random.default_rng(42)
    draws = np.empty(n_bootstrap)
    for b in range(n_bootstrap):
        rv_ext = rv.copy()
        for h in range(horizon):
            rv_d = rv_ext.iloc[-1]
            rv_w = rv_ext.tail(5).mean()
            rv_m = rv_ext.tail(22).mean() if len(rv_ext) >= 22 else rv_ext.mean()
            x = np.array([1.0, rv_d, rv_w, rv_m])
            f = float(x @ model["beta"])
            # Add a random in-sample residual (bootstrap)
            f += rng.choice(residuals)
            new_idx = rv_ext.index[-1] + pd.Timedelta(days=1)
            rv_ext = pd.concat([rv_ext, pd.Series([f], index=[new_idx])])
        draws[b] = rv_ext.iloc[-1]
    alpha_lo = (1.0 - confidence) / 2.0
    alpha_hi = 1.0 - alpha_lo
    lo = float(np.quantile(draws, alpha_lo))
    hi = float(np.quantile(draws, alpha_hi))
    point = har_rv_forecast(rv, horizon=horizon, model=model)
    return point, lo, hi


# ---------------------------------------------------------------------------
# 3. Convenience: volatility (not variance) wrappers
# ---------------------------------------------------------------------------

def har_vol_forecast(
    rv: pd.Series,
    horizon: int = 1,
    annualize: bool = True,
    trading_days: int = 252,
) -> float:
    """Convenience: HAR-RV forecast expressed as volatility (std-dev).

    If annualize=True, scales by sqrt(trading_days) so the returned
    number is comparable to a GARCH annualized vol (e.g. 0.18 = 18%).
    """
    var = har_rv_forecast(rv, horizon=horizon)
    if not np.isfinite(var) or var < 0:
        return float("nan")
    vol = float(np.sqrt(var))
    if annualize:
        vol *= float(np.sqrt(trading_days))
    return vol


# ---------------------------------------------------------------------------
# 4. Smoke test
# ---------------------------------------------------------------------------

def _smoke_test() -> str:
    """End-to-end smoke test on synthetic data."""
    rng = np.random.default_rng(7)
    n = 300
    # Generate GARCH(1,1)-like daily RV with regime switch at t=150
    base_rv = np.where(np.arange(n) < 150, 1e-4, 4e-4)
    rv_series = pd.Series(
        base_rv * (1.0 + 0.5 * rng.standard_normal(n)),
        index=pd.date_range("2020-01-01", periods=n, freq="B"),
    )

    # 1) HAR-RV fit
    model = fit_har_rv(rv_series)
    assert model["n_obs"] >= 10, "HAR-RV fit needs ≥10 obs"
    assert model["beta"].shape == (4,), "HAR-RV beta should be (4,)"
    assert np.isfinite(model["r2"]), "R² should be finite"
    assert np.isfinite(model["resid_std"]), "resid_std should be finite"

    # 2) 1-day forecast
    f1 = har_rv_forecast(rv_series, horizon=1)
    assert np.isfinite(f1), "1-day forecast should be finite"
    assert f1 > 0, "RV forecast should be positive"

    # 3) 5-day forecast (iterated)
    f5 = har_rv_forecast(rv_series, horizon=5)
    assert np.isfinite(f5), "5-day forecast should be finite"

    # 4) Bootstrap interval
    pt, lo, hi = har_rv_forecast_with_intervals(
        rv_series, horizon=1, confidence=0.90, n_bootstrap=100
    )
    assert lo <= pt <= hi, "point forecast should lie inside the interval"
    assert hi > 0, "upper bound should be positive"

    # 5) Yang-Zhang on synthetic OHLC
    # Build synthetic OHLC consistent with daily RV ~ 1e-4
    n_ohlc = 250
    close = 100.0 * np.exp(np.cumsum(rng.normal(0, 0.01, n_ohlc)))
    open_ = np.r_[100.0, close[:-1]]
    high = np.maximum(open_, close) * (1.0 + np.abs(rng.normal(0, 0.002, n_ohlc)))
    low = np.minimum(open_, close) * (1.0 - np.abs(rng.normal(0, 0.002, n_ohlc)))
    ohlcv = pd.DataFrame({
        "Open": open_, "High": high, "Low": low, "Close": close,
    }, index=pd.date_range("2020-01-01", periods=n_ohlc, freq="B"))
    rv_yz = yang_zhang_rv(ohlcv)
    assert rv_yz.notna().sum() >= 100, "Yang-Zhang should produce ≥100 valid estimates"
    # RV is non-negative by construction (clipped).  Some days can be exactly
    # zero due to the clip when intraday OHLC is degenerate, but the aggregate
    # mean must be strictly positive.
    assert (rv_yz.dropna() >= 0).all(), "Yang-Zhang RV must be non-negative (clip invariant)"
    assert float(rv_yz.mean()) > 0, "Yang-Zhang RV mean must be strictly positive"

    # 6) Volatility convenience wrapper
    vol = har_vol_forecast(rv_series, horizon=1, annualize=True)
    assert 0.05 < vol < 2.0, f"annualized vol sanity check failed (got {vol:.4f})"

    return f"""
[HAR-RV smoke test] PASS
  n_obs fit           = {model['n_obs']}
  beta (intercept,d,w,m) = {model['beta']}
  R²                  = {model['r2']:.4f}
  resid_std           = {model['resid_std']:.6f}
  1-day RV forecast   = {f1:.6e}
  5-day RV forecast   = {f5:.6e}
  1-day interval      = [{lo:.6e}, {hi:.6e}]  point = {pt:.6e}
  Yang-Zhang RV mean  = {float(rv_yz.mean()):.6e}
  Annualized vol      = {vol:.4f}
"""


# ─────────────────────────────────────────────────────────────────────────────
# Volatility Regime & Position-Sizing Helpers (Round 7 institutional wiring)
# ─────────────────────────────────────────────────────────────────────────────

def compute_realized_variance(
    close: pd.Series,
    intraday_returns: Optional[pd.Series] = None,
    use_log_returns: bool = True,
) -> pd.Series:
    """
    Compute daily realized variance (RV_t).
    Uses intraday returns sum-of-squares if provided, otherwise daily return variance proxy.
    """
    if intraday_returns is not None and not intraday_returns.empty:
        sq = intraday_returns ** 2
        if isinstance(sq.index, pd.DatetimeIndex):
            grp_keys = sq.index.normalize()
        else:
            grp_keys = pd.to_datetime(sq.index).normalize()
        rv = sq.groupby(grp_keys).sum()
        rv.name = "RV_d"
        return rv.astype(np.float64)

    if close is None or len(close) < 2:
        return pd.Series(dtype=np.float64)

    s = pd.Series(close).dropna().astype(float)
    if use_log_returns:
        rets = np.log(s / s.shift(1)).dropna()
    else:
        rets = s.pct_change().dropna()

    rv = (rets ** 2).astype(np.float64)
    rv.name = "RV_d"
    return rv


def build_har_lags(
    rv: pd.Series,
    week_window: int = 5,
    month_window: int = 22,
) -> pd.DataFrame:
    """Constructs the lagged HAR design matrix [RV_d, RV_w, RV_m, Target]."""
    rv_s = pd.Series(rv).dropna().astype(float)
    rv_d = rv_s.shift(1)
    rv_w = rv_s.rolling(week_window).mean().shift(1)
    rv_m = rv_s.rolling(month_window).mean().shift(1)
    target = rv_s

    df = pd.DataFrame({
        "RV_d": rv_d,
        "RV_w": rv_w,
        "RV_m": rv_m,
        "Target": target,
    }).dropna()
    return df


def forecast_har_rv(fit: Dict[str, Any], horizon: int = 1) -> np.ndarray:
    """
    Forecast h-step ahead RV from a fitted HAR-RV model.
    """
    if not fit or "rv_history" not in fit:
        # If fit dictionary contains latest RV components
        b0 = fit.get("beta_intercept", fit.get("beta", [0,0,0,0])[0])
        bd = fit.get("beta_daily", fit.get("beta", [0,0,0,0])[1] if len(fit.get("beta", [])) > 1 else 0)
        bw = fit.get("beta_weekly", fit.get("beta", [0,0,0,0])[2] if len(fit.get("beta", [])) > 2 else 0)
        bm = fit.get("beta_monthly", fit.get("beta", [0,0,0,0])[3] if len(fit.get("beta", [])) > 3 else 0)
        rv_d = fit.get("latest_rv_d", 1e-4)
        rv_w = fit.get("latest_rv_w", 1e-4)
        rv_m = fit.get("latest_rv_m", 1e-4)
        fc = b0 + bd * rv_d + bw * rv_w + bm * rv_m
        return np.full(horizon, max(1e-8, float(fc)))

    rv_hist = fit["rv_history"]
    fc_list = []
    for h in range(1, horizon + 1):
        fc_list.append(har_rv_forecast(rv_hist, horizon=h))
    return np.array(fc_list, dtype=np.float64)


def classify_volatility_regime(fit: Dict[str, Any], rv_history: pd.Series) -> str:
    """
    Classify the current volatility regime based on the latest RV vs its
    long-run distribution.

    Returns one of:
        "LOW"        — current RV < 25th percentile of historical RV
        "NORMAL"     — 25th ≤ RV < 75th percentile
        "ELEVATED"   — 75th ≤ RV < 95th percentile
        "STRESS"     — RV ≥ 95th percentile
    """
    if not fit or rv_history is None or len(rv_history) < 30:
        return "NORMAL"

    latest_rv = float(rv_history.iloc[-1])
    vals = rv_history.dropna().values
    p25 = float(np.percentile(vals, 25))
    p75 = float(np.percentile(vals, 75))
    p95 = float(np.percentile(vals, 95))

    if latest_rv < p25:
        return "LOW"
    if latest_rv < p75:
        return "NORMAL"
    if latest_rv < p95:
        return "ELEVATED"
    return "STRESS"


def regime_to_size_multiplier(regime: str) -> float:
    """Map a volatility regime to a position-size multiplier."""
    return {
        "LOW":      1.25,
        "NORMAL":   1.00,
        "ELEVATED": 0.70,
        "STRESS":   0.40,
    }.get(str(regime).upper(), 1.00)


# Aliases
yang_zhang_realized_variance = yang_zhang_rv


if __name__ == "__main__":
    print(_smoke_test())
