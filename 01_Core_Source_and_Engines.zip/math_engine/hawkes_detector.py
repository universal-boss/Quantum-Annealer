"""
math_engine/hawkes_detector.py
===============================
Exponential Hawkes process self-exciting point process for financial jump detection.
Detects clustering of extreme market return events (>2 sigma) as an early indicator
of market regime transitions prior to HMM/RS-GARCH state shifts.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Dict, Any


class HawkesJumpDetector:
    """
    Self-exciting Hawkes process for market volatility jump intensity:
        λ(t) = μ + Σ_{t_i < t} α · exp(-β · (t - t_i))
    
    where:
        μ = baseline arrival rate of extreme shocks
        α = jump excitation magnitude  (data-calibrated from inter-arrival intervals)
        β = memory decay rate          (derived from half_life_days)
        n* = α / β = branching ratio   (n* >= 1.0 indicates super-critical cascade)
    """

    def __init__(self, threshold_std: float = 2.0, half_life_days: float = 5.0):
        self.threshold_std = threshold_std
        self.beta = np.log(2.0) / max(half_life_days, 1.0)  # decay rate β

    def _calibrate_alpha(self, jump_indices: np.ndarray, n_obs: int) -> float:
        """
        Data-driven alpha calibration from inter-arrival statistics.
        MLE proxy: alpha estimated as fraction of excitation from inter-jump
        clustering relative to baseline arrival rate.
        - If jumps are tightly clustered (short inter-arrivals), alpha is high.
        - If jumps are sparse and uniform, alpha approaches zero.

        AUDIT-FIX (defect #P0-4): the prior implementation returned
        `clip(beta * cv, 0.01*beta, 10*beta)` and the downstream branching_ratio
        `clip(alpha/beta, 0, 10)` reduced algebraically to `clip(cv, 0.01, 10)` —
        i.e. n* was just the coefficient of variation of jump inter-arrival indices,
        a single-statistic function of the input. When `optimizer.py:8509` fed the
        same cached `benchmark_returns` series to all 5 profiles in a sweep, the
        cv was identical, so n* was the canned 1.74 across every profile and date.
        We now couple alpha to BOTH the inter-arrival cv AND the baseline arrival
        rate μ so the output varies with the actual jump intensity fit, not just
        with one statistic of one shared input.
        """
        if len(jump_indices) < 2:
            return 0.01 * self.beta
        intervals     = np.diff(jump_indices).astype(float)
        mean_interval = float(np.mean(intervals)) + 1e-6
        std_interval  = float(np.std(intervals))  + 1e-6
        # Coefficient of variation: high CV => clustered arrivals => high alpha.
        cv        = std_interval / mean_interval
        # Baseline arrival rate (jumps per observation). When jumps are rare
        # (low μ), even tight clustering should not produce a super-critical
        # cascade — the system is quiet. When jumps are frequent (high μ) AND
        # tightly clustered, alpha should rise.
        mu = float(len(jump_indices)) / float(n_obs)
        # Coupled alpha: excitation grows with both cv and μ. The 0.5/0.5
        # weighting makes n* = alpha/beta sensitive to changes in either input,
        # so two profiles with different benchmark slices can no longer produce
        # byte-identical n*.
        # AUDIT-FIX (Round 6, A1-P2-8): the Round-5 calibration multiplied μ
        # (jumps per observation) by 50 — making n* = α/β exceed 1 on pure
        # GAUSSIAN white noise (repro: branching_ratio 1.348, super-critical
        # warning always on, permanent tail-hedge recommendations).
        # Calibration now anchors both inputs to their POISSON/null values so
        # pure randomness maps to ~0 excitation:
        #   - intervals between independent jumps are ~Exponential ⇒ cv ≈ 1,
        #     so EXCESS clustering is max(cv − 1, 0);
        #   - a 2σ jump occurs on ≈ 4.55% of days under normality
        #     (P(|z|>2) = 0.0455), so EXCESS frequency is max(μ/μ_ref − 1, 0).
        # Only clustering or frequency above the null can push n* toward 1.
        _mu_ref = 0.0455  # P(|z| > 2) under normality ≈ daily 2σ jump rate
        _cv_excess = max(cv - 1.0, 0.0)
        _mu_excess = max(mu / _mu_ref - 1.0, 0.0)
        raw_alpha = self.beta * (0.5 * _cv_excess + 0.5 * _mu_excess)
        return float(np.clip(raw_alpha, 0.01 * self.beta, 10.0 * self.beta))

    def fit_predict(self, returns: pd.Series) -> Dict[str, Any]:
        """
        Fit Hawkes intensity to return series and calculate excitation ratio n* = alpha / beta.
        """
        if returns is None or len(returns) < 30:
            return {
                "hawkes_intensity": 0.0,
                "branching_ratio": 0.0,
                "regime_transition_warning": False,
                "reason": "Insufficient data",
            }

        r       = returns.dropna().values
        mu_r    = np.mean(r)
        sigma_r = np.std(r) + 1e-9

        # Identify jump events (|r| > threshold sigma)
        abs_z        = np.abs((r - mu_r) / sigma_r)
        jump_indices = np.where(abs_z > self.threshold_std)[0]
        n_jumps = len(jump_indices)
        n_obs   = len(r)

        if n_jumps < 2:
            return {
                "hawkes_intensity": 0.01,
                "branching_ratio": 0.05,
                "regime_transition_warning": False,
                "reason": "Quiet (low jump frequency)",
            }

        # Baseline arrival rate μ
        mu = n_jumps / float(n_obs)

        # Data-calibrated alpha (excitation coefficient) — unclamped diagnostic metric
        alpha = self._calibrate_alpha(jump_indices, n_obs)

        # Recursive Hawkes intensity: λ(t) = μ + α * Σ exp(-β*(t-t_i))
        # Keep internal intensity calculation numerically stable
        alpha_bounded = min(alpha, 1.5 * self.beta)
        intensity = np.full(n_obs, mu, dtype=float)
        g = 0.0
        for t in range(1, n_obs):
            is_jump      = 1.0 if abs_z[t - 1] > self.threshold_std else 0.0
            g            = g * np.exp(-self.beta) + is_jump
            intensity[t] = mu + alpha_bounded * g

        latest_intensity = float(intensity[-1])

        # Branching ratio n* = α / β (unclamped up to 10.0 for accurate diagnostic reporting)
        branching_ratio = float(np.clip(alpha / (self.beta + 1e-9), 0.0, 10.0))

        # Super-critical threshold: n* >= 1.0 (actual cascade limit) OR intensity > 5× baseline
        transition_warning = branching_ratio >= 1.0 or latest_intensity > (mu * 5.0)

        return {
            "hawkes_intensity":          round(latest_intensity, 4),
            "branching_ratio":           round(branching_ratio, 4),
            "calibrated_alpha":          round(alpha, 6),
            "decay_beta":                round(self.beta, 6),
            "regime_transition_warning": bool(transition_warning),
            "jump_count_252d":           int(n_jumps),
            "reason": "SUPER-CRITICAL JUMP CLUSTERING" if transition_warning else "Sub-critical (stable)",
        }
