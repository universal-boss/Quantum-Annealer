"""
Automated Desktop Report Generator for Tier-1 Stock Intelligence
=================================================================
Generates a standalone, beautiful HTML & Markdown report on the user's Desktop
every time a screening sweep or portfolio export completes.

Categorizes all screened equities into:
1. 🔥 Immediate Breakout Candidates (VCP Squeeze, KBS Ratio < 0.85, VPIN Toxicity, Hasbrouck λ)
2. 🛡️ Best for Accumulation at Lower Price (Piotroski F-Score >= 7, Altman Z-Score, Low Downside Risk)
3. 🚀 High-Probability Multibagger Candidates (RS Rating 80-99, Neural-SDE Drift μ/σ, CMF Density)
"""

import os
import pandas as pd
from html import escape as _esc  # AUDIT-FIX (Round 6, F2): escape scraped ticker/summary text in HTML reports
import logging
from typing import Dict, Any

logger = logging.getLogger("HTMLReportGenerator")

class PostScreeningHTMLReportGenerator:
    
    @classmethod
    def generate_html_report(cls, combined_csv_path: str, intel_csv_path: str = None) -> str:
        if not os.path.exists(combined_csv_path):
            return ""
            
        desktop_dir = os.path.dirname(combined_csv_path)
        
        if not intel_csv_path or not os.path.exists(intel_csv_path):
            intel_csv_path = os.path.join(desktop_dir, "post_screening_intelligence.csv")
            if not os.path.exists(intel_csv_path):
                try:
                    from math_engine.post_screening_intelligence import PostScreeningIntelligenceEngine
                    intel_csv_path = PostScreeningIntelligenceEngine.generate_and_save_intelligence_report(combined_csv_path)
                except Exception as e:
                    logger.error(f"Could not generate intelligence report for HTML conversion: {e}", exc_info=True)
                    return ""

        if not os.path.exists(intel_csv_path):
            return ""
            
        df = pd.read_csv(intel_csv_path)
        if not df.empty:
            df = df.drop_duplicates(subset=["Ticker"], keep="first")
        
        breakout_df = df[df["Primary Classification"].str.contains("Breakout", na=False)]
        if breakout_df.empty and not df.empty:
            breakout_df = df.sort_values(by="Breakout Score", ascending=False).head(5)

        accum_df = df[df["Primary Classification"].str.contains("Accumulation|Defense", na=False)]
        if accum_df.empty and not df.empty:
            accum_df = df.sort_values(by="Accumulation Score", ascending=False).head(5)

        multibagger_df = df[df["Primary Classification"].str.contains("Multibagger|Alpha", na=False)]
        if multibagger_df.empty and not df.empty:
            multibagger_df = df.sort_values(by="Multibagger Score", ascending=False).head(5)
        
        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Quantum Annealer — Tier-1 Post-Screening Stock Intelligence</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; background: #0f172a; color: #f8fafc; margin: 0; padding: 24px; }}
        h1 {{ color: #38bdf8; border-bottom: 2px solid #334155; padding-bottom: 12px; margin-bottom: 8px; }}
        .subtitle {{ color: #94a3b8; font-size: 14px; margin-bottom: 28px; }}
        h2 {{ color: #f43f5e; margin-top: 36px; border-bottom: 1px solid #334155; padding-bottom: 8px; font-size: 18px; }}
        h2.accum {{ color: #10b981; }}
        h2.multi {{ color: #a855f7; }}
        .card {{ background: #1e293b; border-radius: 12px; padding: 16px; margin-bottom: 20px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.3); }}
        table {{ width: 100%; border-collapse: collapse; margin-top: 12px; background: #0f172a; border-radius: 8px; overflow: hidden; }}
        th {{ background: #334155; color: #cbd5e1; font-weight: 600; text-align: left; padding: 10px 12px; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px; }}
        td {{ padding: 10px 12px; border-bottom: 1px solid #1e293b; font-size: 13px; color: #e2e8f0; }}
        tr:hover {{ background: #1e293b; }}
        .badge {{ display: inline-block; padding: 4px 8px; border-radius: 6px; font-size: 11px; font-weight: bold; }}
        .badge-breakout {{ background: rgba(244, 63, 94, 0.2); color: #f43f5e; border: 1px solid #f43f5e; }}
        .badge-accum {{ background: rgba(16, 185, 129, 0.2); color: #10b981; border: 1px solid #10b981; }}
        .badge-multi {{ background: rgba(168, 85, 247, 0.2); color: #a855f7; border: 1px solid #a855f7; }}
        .ticker {{ font-weight: bold; color: #f8fafc; font-size: 14px; }}
        .score {{ font-weight: bold; color: #fbbf24; }}
        .footer {{ margin-top: 48px; text-align: center; color: #64748b; font-size: 12px; }}
    </style>
</head>
<body>
    <h1>⚡ Tier-1 Institutional Stock Intelligence Report</h1>
    <div class="subtitle">Powered by VPIN Order-Flow Toxicity, Hasbrouck Permanent Impact (λ), Piotroski F-Score, Altman Z-Score, and Neural-SDE Stochastic Drift.</div>

    <!-- SECTION 1: BREAKOUT -->
    <h2>🔥 1. Immediate Breakout Candidates (Short-to-Medium Term)</h2>
    <div class="card">
        <p style="color: #cbd5e1; font-size: 13px; margin: 0 0 12px 0;">Microstructure Volatility Squeeze (KBS Ratio &lt; 0.85), Order-Flow Toxicity (VPIN), and Hasbrouck Price Impact (&lambda;).</p>
        <table>
            <thead>
                <tr>
                    <th>Ticker</th>
                    <th>Tier-1 Score</th>
                    <th>KBS Ratio</th>
                    <th>VPIN Toxicity</th>
                    <th>Hasbrouck &lambda;</th>
                    <th>RS Rating</th>
                    <th>ADV20 (₹Cr)</th>
                    <th>Actionable Institutional Intelligence</th>
                </tr>
            </thead>
            <tbody>
"""
        if not breakout_df.empty:
            for _, r in breakout_df.iterrows():
                html += f"""
                <tr>
                    <td class="ticker">{_esc(r['Ticker'])}</td>
                    <td class="score">{r['Tier-1 Quant Score']}</td>
                    <td>{r['KBS Ratio']}x</td>
                    <td>{r['VPIN Toxicity']}</td>
                    <td>{r['Hasbrouck λ']}</td>
                    <td>{r['RS Rating (1-99)']}/99</td>
                    <td>₹{r['ADV20 (₹Cr)']} Cr</td>
                    <td><span class="badge badge-breakout">{_esc(r['Actionable Intelligence Summary'])}</span></td>
                </tr>"""
        else:
            html += "<tr><td colspan='8'>No tight microstructure breakout candidates triggered in current market regime.</td></tr>"

        html += """
            </tbody>
        </table>
    </div>

    <!-- SECTION 2: ACCUMULATION -->
    <h2 class="accum">🛡️ 2. Best for Accumulation at Lower Price (Buy on Dips)</h2>
    <div class="card">
        <p style="color: #cbd5e1; font-size: 13px; margin: 0 0 12px 0;">Deep Accounting Quality (Piotroski F-Score &ge; 7), Credit Stability (Altman Z-Score &ge; 3.0), and Low Downside Risk.</p>
        <table>
            <thead>
                <tr>
                    <th>Ticker</th>
                    <th>Tier-1 Score</th>
                    <th>Piotroski F</th>
                    <th>Altman Z</th>
                    <th>Market Beta (&beta;)</th>
                    <th>Downside Vol</th>
                    <th>ADV20 (₹Cr)</th>
                    <th>Actionable Institutional Intelligence</th>
                </tr>
            </thead>
            <tbody>
"""
        if not accum_df.empty:
            for _, r in accum_df.iterrows():
                html += f"""
                <tr>
                    <td class="ticker">{_esc(r['Ticker'])}</td>
                    <td class="score">{r['Tier-1 Quant Score']}</td>
                    <td>{r['Piotroski F-Score']}/9</td>
                    <td>{r['Altman Z-Score']}</td>
                    <td>{r['Market Beta']}</td>
                    <td>{r['Downside Vol %']}%</td>
                    <td>₹{r['ADV20 (₹Cr)']} Cr</td>
                    <td><span class="badge badge-accum">{_esc(r['Actionable Intelligence Summary'])}</span></td>
                </tr>"""
        else:
            html += "<tr><td colspan='8'>No high Piotroski defensive accumulation targets triggered.</td></tr>"

        html += """
            </tbody>
        </table>
    </div>

    <!-- SECTION 3: MULTIBAGGER -->
    <h2 class="multi">🚀 3. High-Probability Multibagger Candidates (3x to 5x Potential)</h2>
    <div class="card">
        <p style="color: #cbd5e1; font-size: 13px; margin: 0 0 12px 0;">Top-Decile Relative Strength (RS Rating 80-99), Neural-SDE Continuous Drift (&mu;/&sigma;), and Institutional Flow Density.</p>
        <table>
            <thead>
                <tr>
                    <th>Ticker</th>
                    <th>Tier-1 Score</th>
                    <th>RS Rating</th>
                    <th>6M Return</th>
                    <th>SDE Drift (&mu;/&sigma;)</th>
                    <th>CMF Density</th>
                    <th>PE Ratio</th>
                    <th>Actionable Institutional Intelligence</th>
                </tr>
            </thead>
            <tbody>
"""
        if not multibagger_df.empty:
            for _, r in multibagger_df.iterrows():
                html += f"""
                <tr>
                    <td class="ticker">{_esc(r['Ticker'])}</td>
                    <td class="score">{r['Tier-1 Quant Score']}</td>
                    <td>{r['RS Rating (1-99)']}/99</td>
                    <td>+{r['6M Return %']}%</td>
                    <td>{r['Neural-SDE Drift (μ/σ)']}</td>
                    <td>+{r['CMF Density']}</td>
                    <td>{r['PE Ratio']}</td>
                    <td><span class="badge badge-multi">{_esc(r['Actionable Intelligence Summary'])}</span></td>
                </tr>"""
        else:
            html += "<tr><td colspan='8'>No high-alpha multibagger candidates triggered.</td></tr>"

        html += f"""
            </tbody>
        </table>
    </div>

    <div class="footer">
        ⚡ Generated automatically by Tier-1 Institutional Quantitative Engine & Quantum Annealer
    </div>
</body>
</html>"""

        html_path = os.path.join(desktop_dir, "Post_Screening_Stock_Intelligence.html")
        with open(html_path, "w", encoding="utf-8") as f:
            f.write(html)
            
        logger.info(f"✅ Generated Standalone Tier-1 HTML Intelligence Report -> {html_path}")
        return html_path
