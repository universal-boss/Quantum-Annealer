"""Idzorek's confidence-weighted Black-Litterman views + relative views.

Upgrades the BL estimator with:
  1. Idzorek's method: confidence as % of prior→posterior shift
  2. Relative views: "RELIANCE will outperform TCS" (not just absolute)
  3. Dynamic view confidence: scale by ViT model similarity score
  4. View clustering: group correlated views to reduce redundancy

Reference: Idzorek (2007), "A Step-by-Step Guide to the Black-Litterman Model"
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import List, Tuple, Optional, Union
import logging

logger = logging.getLogger(__name__)


def idzorek_confidence(
    prior_weights: np.ndarray,
    cov_matrix: np.ndarray,
    view_vector: np.ndarray,
    pick_matrix: np.ndarray,
    confidence_pct: Union[float, np.ndarray, List[float]],
    risk_aversion: float = 2.5,
) -> np.ndarray:
    """Compute Idzorek's confidence-scaled Omega matrix.

    In Idzorek's method, confidence is expressed as the percentage of the
    distance between the prior and the view that the posterior should move.

    confidence_pct = 0% → posterior = prior (ignore view)
    confidence_pct = 100% → posterior = view (full weight on view)

    Args:
        prior_weights: Equilibrium prior weights (N,).
        cov_matrix: Covariance matrix (N, N).
        view_vector: View returns Q (K,).
        pick_matrix: P matrix (K, N) — view selection.
        confidence_pct: Confidence as percentage [0, 1] per view. May be a
            single float (broadcast to all K views) or an array-like of
            length K (one confidence per view).
        risk_aversion: Risk aversion λ.

    Returns:
        Omega matrix (K, K) — view uncertainty.
    """
    # Prior returns: Π = λ Σ w
    pi = risk_aversion * (cov_matrix @ prior_weights)

    # Normalize confidence_pct to a per-view array of length K.
    # BUG-FIX: previously the function annotated `confidence_pct: float` but the
    # caller (`idzorek_black_litterman`) passed `np.array(confidences[:len(Q)])`
    # — an array of length K. The body then did `if confidence_pct < 1e-6:`
    # inside a per-view loop, which raised
    # `ValueError: The truth value of an array with more than one element is
    # ambiguous` whenever K >= 2. This silently broke every Idzorek BL call
    # with 2+ views (i.e., every multi-ticker portfolio in optimizer.py:1926).
    K = len(view_vector)
    conf_arr = np.asarray(confidence_pct, dtype=float)
    if conf_arr.ndim == 0:
        conf_arr = np.full(K, float(conf_arr))
    if conf_arr.shape[0] != K:
        # If caller passed a wrong-length array, broadcast the mean to avoid
        # an IndexError — Idzorek's method still works with a single confidence.
        conf_arr = np.full(K, float(np.mean(conf_arr)))

    Omega = np.zeros((K, K))

    for k in range(K):
        p_k = pick_matrix[k]
        q_k = view_vector[k]

        # Prior implied view value
        pi_k = float(p_k @ pi)

        # Tilt: distance from prior to view
        tilt = q_k - pi_k

        if abs(tilt) < 1e-9:
            # View matches prior — no uncertainty
            Omega[k, k] = 1e-8
            continue

        # Idzorek's formula: Omega_kk such that posterior moves confidence_pct
        # of the way from prior to view.
        # Solve: confidence_pct = (tilt_new) / (tilt) where tilt_new depends on Omega
        # Simplified: Omega_kk = (1 - confidence_pct) / confidence_pct × p_k Σ p_k'
        prior_var = float(p_k @ cov_matrix @ p_k)
        conf_k = float(conf_arr[k])

        if conf_k < 1e-6:
            Omega[k, k] = 1e10  # near-zero confidence → huge uncertainty
        elif conf_k > 0.999:
            Omega[k, k] = 1e-10  # near-full confidence → tiny uncertainty
        else:
            Omega[k, k] = prior_var * (1 - conf_k) / conf_k

    return Omega


def relative_views(
    tickers: List[str],
    view_pairs: List[Tuple[str, str, float]],
) -> Tuple[np.ndarray, np.ndarray]:
    """Construct relative view matrices.

    A relative view: "ticker_a will outperform ticker_b by X%"

    Args:
        tickers: List of all tickers.
        view_pairs: List of (ticker_a, ticker_b, outperformance) tuples.

    Returns:
        (P, Q) — pick matrix (K, N) and view returns (K,).
    """
    n = len(tickers)
    k = len(view_pairs)
    ticker_idx = {t: i for i, t in enumerate(tickers)}

    P = np.zeros((k, n))
    Q = np.zeros(k)

    for i, (a, b, outperf) in enumerate(view_pairs):
        if a not in ticker_idx or b not in ticker_idx:
            continue
        P[i, ticker_idx[a]] = 1.0
        P[i, ticker_idx[b]] = -1.0
        Q[i] = outperf

    return P, Q


def cluster_views(
    pick_matrix: np.ndarray,
    view_returns: np.ndarray,
    correlation_threshold: float = 0.7,
) -> Tuple[np.ndarray, np.ndarray, List[int]]:
    """Cluster correlated views to reduce redundancy.

    If two views are highly correlated (same tickers, similar magnitudes),
    combine them into one to avoid double-counting.

    Args:
        pick_matrix: P matrix (K, N).
        view_returns: Q vector (K,).
        correlation_threshold: Views with |corr| > threshold get merged.

    Returns:
        (P_new, Q_new, cluster_labels) — reduced view matrices.
    """
    K = len(view_returns)
    if K <= 1:
        return pick_matrix, view_returns, list(range(K))

    # Compute correlation between view portfolios
    view_portfolios = pick_matrix  # each row is a view portfolio
    corr_matrix = np.corrcoef(view_portfolios)

    # Simple clustering: merge views with high correlation
    cluster_labels = list(range(K))
    for i in range(K):
        for j in range(i + 1, K):
            if abs(corr_matrix[i, j]) > correlation_threshold:
                # Merge j into i's cluster
                cluster_labels[j] = cluster_labels[i]

    # Build merged views
    unique_clusters = sorted(set(cluster_labels))
    P_new = []
    Q_new = []

    for cluster in unique_clusters:
        indices = [i for i, c in enumerate(cluster_labels) if c == cluster]
        if len(indices) == 1:
            P_new.append(pick_matrix[indices[0]])
            Q_new.append(view_returns[indices[0]])
        else:
            # Average the views in this cluster
            P_avg = np.mean(pick_matrix[indices], axis=0)
            Q_avg = np.mean(view_returns[indices])
            P_new.append(P_avg)
            Q_new.append(Q_avg)

    return np.array(P_new), np.array(Q_new), cluster_labels


def dynamic_confidence(
    base_confidence: float,
    vit_similarity: Optional[float] = None,
    ic_score: Optional[float] = None,
    regime_confidence: Optional[float] = None,
) -> float:
    """Compute dynamic view confidence from multiple signals.

    Scales base confidence by:
      - ViT model similarity score (higher = more confident)
      - Factor IC score (higher = more confident)
      - Regime detector confidence (higher = more confident)

    Args:
        base_confidence: Base confidence level [0, 1].
        vit_similarity: ViT chart similarity score [0, 1] (optional).
        ic_score: Factor information coefficient [-1, 1] (optional).
        regime_confidence: HMM regime confidence [0, 1] (optional).

    Returns:
        Adjusted confidence [0, 1].
    """
    confidence = base_confidence

    if vit_similarity is not None:
        # Scale by ViT similarity (0.5 = neutral, 1.0 = high confidence)
        vit_factor = 0.5 + 0.5 * max(0, min(1, vit_similarity))
        confidence *= vit_factor

    if ic_score is not None:
        # Scale by |IC| (higher IC = more confident in the view)
        ic_factor = 0.5 + 0.5 * abs(ic_score)
        confidence *= ic_factor

    if regime_confidence is not None:
        # Scale by regime confidence
        confidence *= regime_confidence

    return max(0.01, min(0.99, confidence))


def idzorek_black_litterman(
    prior_weights: np.ndarray,
    cov_matrix: np.ndarray,
    pick_matrix: np.ndarray,
    view_returns: np.ndarray,
    confidences: List[float],
    risk_aversion: float = 2.5,
    tau: float = 0.05,
    cluster: bool = True,
) -> np.ndarray:
    """Full Idzorek Black-Litterman with relative views and clustering.

    Args:
        prior_weights: Market-cap equilibrium weights (N,).
        cov_matrix: Covariance matrix (N, N).
        pick_matrix: P matrix (K, N) — can be absolute or relative views.
        view_returns: Q vector (K,) — view expected returns.
        confidences: List of K confidence percentages [0, 1] per view.
        risk_aversion: Risk aversion λ.
        tau: BL scaling parameter.
        cluster: If True, cluster correlated views before estimation.

    Returns:
        Posterior expected returns (N,).
    """
    # Cluster views if requested
    if cluster and len(view_returns) > 1:
        P, Q, _ = cluster_views(pick_matrix, view_returns)
        # Average confidences within clusters
        if len(P) != len(pick_matrix):
            # Recompute confidences for merged views
            confidences = [np.mean(confidences)] * len(P)  # simplified
    else:
        P, Q = pick_matrix, view_returns

    # Compute Idzorek Omega
    Omega = idzorek_confidence(
        prior_weights, cov_matrix, Q, P,
        np.array(confidences[:len(Q)]),
        risk_aversion
    )

    # Prior returns
    pi = risk_aversion * (cov_matrix @ prior_weights)

    # BL posterior
    tau_sigma = tau * cov_matrix
    tau_sigma_inv = np.linalg.pinv(tau_sigma)
    omega_inv = np.linalg.pinv(Omega)

    middle_inv = np.linalg.pinv(tau_sigma_inv + P.T @ omega_inv @ P)
    rhs = tau_sigma_inv @ pi + P.T @ omega_inv @ Q
    posterior = middle_inv @ rhs

    return posterior
