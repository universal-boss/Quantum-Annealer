"""
math_engine/indicators.py
=========================
Pure, Qt-free quantitative & technical indicator calculation suite and NSE NIFTY50 fetcher.
"""
from __future__ import annotations

import logging
import threading
from typing import Dict, List, Tuple, Optional, Any
import numpy as np
import pandas as pd

_logger = logging.getLogger(__name__)

TRADING_DAYS_PER_YEAR = 252

# ─────────────────────────────────────────────────────────────────────────────
# 1. Classical Quantitative Metrics & Risk Indicators
# ─────────────────────────────────────────────────────────────────────────────

def max_drawdown(series: pd.Series, lookback: int = TRADING_DAYS_PER_YEAR) -> float:
    """Calculates peak-to-trough maximum drawdown over lookback period."""
    s = series.dropna()
    s = s[s > 0]
    if len(s) < 20:
        return float('nan')
    if len(s) > lookback:
        s = s.iloc[-lookback:]
    peak = s.cummax()
    dd = s / (peak + 1e-9) - 1.0
    return float(abs(dd.min())) if len(dd) else float('nan')

def trailing_return(series: pd.Series, bars: int) -> float:
    """Calculates simple trailing return over the given number of bars."""
    s = series.dropna()
    if len(s) <= bars:
        return float('nan')
    return float(s.iloc[-1] / s.iloc[-bars - 1] - 1.0)

def momentum_skip_recent(series: pd.Series, long_bars: int = 252, skip_bars: int = 21) -> float:
    """Calculates long-term return skipping the most recent skip_bars period."""
    s = series.dropna()
    if len(s) <= long_bars + skip_bars:
        return float('nan')
    recent = s.iloc[-skip_bars - 1]
    old = s.iloc[-long_bars - skip_bars - 1]
    if old == 0 or pd.isna(old) or pd.isna(recent):
        return float('nan')
    return float(recent / old - 1.0)

def ema_gap(series: pd.Series, span: int) -> float:
    """Calculates deviation of last price from its EMA."""
    s = series.dropna()
    if len(s) < span + 5:
        return float('nan')
    ema = s.ewm(span=span, adjust=False).mean().iloc[-1]
    if pd.isna(ema) or ema == 0:
        return float('nan')
    return float(s.iloc[-1] / ema - 1.0)

def annualized_vol(returns: pd.Series) -> float:
    """Annualizes standard deviation of returns."""
    r = returns.dropna()
    if len(r) < 20:
        return float('nan')
    return float(r.std() * np.sqrt(TRADING_DAYS_PER_YEAR))

def downside_vol(returns: pd.Series) -> float:
    """Annualized downside semi-deviation (target 0, full-sample basis).

    AUDIT-FIX (Round 13, MATH-6): the previous implementation took
    `r[r < 0].std()`, which (a) re-centers the negative subset on its own
    mean and (b) divides by only the count of negative days — it is NOT
    the semi-deviation and measured ~0.88x the true value on symmetric
    samples (distortion direction varies with skew). The Sortino
    semi-deviation is sqrt( mean( min(r, 0)^2 ) ) over ALL observations
    (López de Prado AFML ch.14, Sortino-Forsey modification), so every
    observation contributes its downside magnitude (zeros for positive
    days) and the denominator is the full sample. Kept: >=20 obs required;
    if fewer than 8 negative days exist the semi-deviation is ~0 and we
    return 0.0 to match the previous de-minimis contract.
    """
    r = returns.dropna()
    if len(r) < 20:
        return float('nan')
    dn = r[r < 0]
    if len(dn) < 8:
        return 0.0
    downside_sq = np.minimum(r, 0.0) ** 2
    return float(np.sqrt(downside_sq.mean()) * np.sqrt(TRADING_DAYS_PER_YEAR))

def compute_rsi(series: pd.Series, period: int = 14) -> float:
    """Calculates standard Relative Strength Index (RSI)."""
    s = series.dropna()
    if len(s) < 2 * period:
        return float('nan')
    delta = s.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.ewm(alpha=1.0/period, min_periods=period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1.0/period, min_periods=period, adjust=False).mean()
    
    with np.errstate(divide="ignore", invalid="ignore"):
        rs = avg_gain / avg_loss
        rsi = 100.0 - (100.0 / (1.0 + rs))
        # Monotonic uptrend (zero loss) -> RSI = 100.0
        rsi = rsi.where(avg_loss > 1e-12, 100.0)
        # Flat (zero gain and zero loss) -> RSI = 50.0
        rsi = rsi.where(~((avg_loss <= 1e-12) & (avg_gain <= 1e-12)), 50.0)
    out = rsi.dropna()
    return float(out.iloc[-1]) if not out.empty else 50.0

def robust_zscore_series(series: pd.Series, clip: float = 4.0) -> pd.Series:
    """MAD-based robust Z-score with winsorization limits."""
    s = pd.to_numeric(series, errors="coerce")
    valid = s.dropna()
    if valid.empty:
        return pd.Series(0.0, index=s.index)
    med = valid.median()
    mad = (valid - med).abs().median()
    if pd.notna(mad) and mad > 1e-9:
        z = (s - med) / (1.4826 * mad)
    else:
        std = valid.std()
        if pd.notna(std) and std > 1e-9:
            z = (s - valid.mean()) / std
        else:
            z = pd.Series(0.0, index=s.index)
    return z.clip(-clip, clip)

def compute_beta(asset_returns: pd.Series, benchmark_returns: pd.Series, window: int = 63) -> float:
    """Calculates trailing systematic beta relative to benchmark returns."""
    if benchmark_returns is None or asset_returns.empty:
        return float('nan')
    common = asset_returns.index.intersection(benchmark_returns.index)
    if len(common) < 40:
        return float('nan')
    tail = common[-window:]
    a, b = asset_returns.loc[tail].values, benchmark_returns.loc[tail].values
    mask = ~(np.isnan(a) | np.isnan(b))
    a, b = a[mask], b[mask]
    if len(a) < 20:
        return float('nan')
    var_b = np.var(b, ddof=1)
    if var_b < 1e-12:
        return float('nan')
    return float(np.cov(a, b)[0, 1] / var_b)


def liquidity_aware_beta(
    asset_returns: pd.Series,
    benchmark_returns: pd.Series,
    adv20: Optional[float] = None,
    window: int = 63,
    prior: float = 1.0,
    kappa: float = 8.0,
    liq_ref_adv: float = 5.0e7,
) -> tuple:
    """Liquidity-aware shrinkage beta estimator.

    AUDIT-FIX (Round 24 — R24-3): the tail hedge's beta floor (0.30) was a
    POLICY, not a model — it bounded the microcap beta collapse at an
    arbitrary constant without estimating anything. This estimator replaces
    the policy with an actual model:

      beta_adj = w * beta_OLS + (1 - w) * prior,   w = n_eff / (n_eff + kappa)

    where n_eff = n_valid x liq_factor and liq_factor = clip(adv20 /
    liq_ref_adv, 0, 1). Illiquid microcaps (low ADV20) have stale/asynchronous
    prices whose measured covariance with the benchmark is ATTENUATED toward
    zero (the classic Epps-effect / non-trading bias) — not a real beta of 0.
    The estimator shrinks exactly those rows toward the prior (market beta 1.0
    by default) instead of letting them collapse; with kappa = 8 a fully
    observed liquid name retains ~89% of its OLS beta (mild, disclosed),
    a Rs 1cr-ADV name ~61%, and a Rs 50L-ADV microcap ~44%, so the collapse
    case (OLS ~ 0) lands near the prior instead of near zero. The flat floor
    then becomes a disclosed BACKSTOP at the hedge site (rarely triggered
    once the estimator runs), and the Barra cross-check remains the
    reference.

    Returns (beta_adj, diagnostics_dict) so callers can disclose raw beta,
    shrink weight, effective sample size and liquidity factor per row.
    Degenerate inputs return NaN with honest diagnostics (never a fabricated
    number).
    """
    diag = {
        "beta_ols": float("nan"),
        "beta_adjusted": float("nan"),
        "shrink_weight": 0.0,
        "n_valid": 0,
        "liquidity_factor": None,
        "prior": float(prior),
    }
    beta_ols = compute_beta(asset_returns, benchmark_returns, window=window)
    diag["beta_ols"] = beta_ols
    if not np.isfinite(beta_ols):
        return float("nan"), diag

    common = asset_returns.index.intersection(benchmark_returns.index)
    tail = common[-window:]
    a = asset_returns.loc[tail].values
    n_valid = int(np.sum(~np.isnan(a)))
    diag["n_valid"] = n_valid

    liq_factor = 1.0
    if adv20 is not None and np.isfinite(float(adv20)) and float(adv20) >= 0 and liq_ref_adv > 0:
        liq_factor = float(min(1.0, max(0.0, float(adv20) / float(liq_ref_adv))))
    diag["liquidity_factor"] = liq_factor

    n_eff = max(0.0, float(n_valid) * liq_factor)
    w = n_eff / (n_eff + float(kappa)) if (n_eff + float(kappa)) > 0 else 0.0
    diag["shrink_weight"] = round(w, 4)

    beta_adj = w * beta_ols + (1.0 - w) * float(prior)
    diag["beta_adjusted"] = beta_adj
    return beta_adj, diag


def factor_model_beta_prior(
    returns: pd.DataFrame,
    close: Optional[pd.DataFrame] = None,
    volume: Optional[pd.DataFrame] = None,
    benchmark_returns: Optional[pd.Series] = None,
    beta_window: int = 63,
    adv20_ref_inr: float = 5.0e7,
    ridge_lambda: float = 1.0,
    min_stocks: int = 12,
    prior_band: tuple = (0.2, 3.0),
) -> Dict[str, Any]:
    """Characteristic factor-model beta prior (Barra-style fundamental beta).

    AUDIT-FIX (Round 25 — R25-3): the R24-3 liquidity-aware estimator shrank
    attenuated microcap betas toward a FLAT prior of beta=1.0 ("the market")
    — honest statistics, but a stock-specific prior was unavailable without
    a licensed Barra/Axioma feed. This function builds that stock-specific
    prior FROM THE LOCAL UNIVERSE, the way Barra's fundamental-factor models
    do: a cross-sectional ridge regression of each stock's trailing OLS beta
    on observable characteristics (log-liquidity vs the ADV reference,
    6-month momentum, trailing volatility), predicted LEAVE-ONE-OUT so a
    stock's own noisy beta never drives its own prior. The prior for an
    illiquid microcap is then the beta its characteristics imply (typically
    high-beta small-cap behavior), not a flat 1.0.

    The returned dict is {"priors": {ticker: prior_beta}, "model":
    {...disclosure...}}. When the cross-section is too small (< min_stocks)
    or degenerate, "priors" is empty and the model note says why — the caller
    then falls back to the flat prior (BETA_SHRINK_PRIOR), which remains the
    licensed-feed integration point via the cfg key BETA_FACTOR_FEED
    ({ticker: beta} override dict, see utils.compute_signal_frame).

    Method (all on strictly trailing data):
      y_i     = OLS beta of stock i over the beta_window tail
      X_i     = [1, z(log ADV20 / ref), z(momentum_6m), z(vol_63d_ann)]
      ridge   = argmin ||y - Xb||^2 + lambda*||b_slopes||^2 (intercept unpenalized)
      LOO_i   = y_i - e_i / (1 - h_ii)   (PRESS/leave-one-out via the hat
                matrix of the ridge solve — no refit loop needed)
      prior_i = clip(LOO_i, prior_band)
    """
    out: Dict[str, Any] = {"priors": {}, "model": None}
    if (returns is None or returns.empty or benchmark_returns is None
            or benchmark_returns.empty or close is None or close.empty):
        out["model"] = {"available": False,
                        "reason": "insufficient frames (needs returns + benchmark + close)"}
        return out

    tickers = [c for c in returns.columns if c in (close.columns if close is not None else [])]
    if volume is not None and not volume.empty:
        tickers = [t for t in tickers if t in volume.columns]
    if len(tickers) < max(3, int(min_stocks)):
        out["model"] = {"available": False,
                        "reason": f"cross-section too small for a characteristic fit ({len(tickers)} < {min_stocks})"}
        return out

    # Per-ticker trailing stats (vectorized where possible)
    beta_ols: Dict[str, float] = {}
    mom6: Dict[str, float] = {}
    vol63: Dict[str, float] = {}
    adv20: Dict[str, float] = {}
    bench_aligned = benchmark_returns.reindex(returns.index)
    rets = returns[tickers]
    for t in tickers:
        a = rets[t].dropna()
        b = bench_aligned.reindex(a.index).dropna()
        common = a.index.intersection(b.index)
        if len(common) < 40:
            continue
        beta_ols[t] = compute_beta(a.loc[common], b.loc[common], window=beta_window)
        c = (close[t].dropna() if close is not None else None)
        if c is None or len(c) < 60:
            continue
        _cl = c.iloc[-min(127, len(c)):]
        mom6[t] = float(_cl.iloc[-1] / _cl.iloc[0] - 1.0) if float(_cl.iloc[0]) > 0 else 0.0
        vol63[t] = float(a.tail(63).std() * np.sqrt(252.0)) if len(a) >= 25 else np.nan
        if volume is not None and not volume.empty and t in volume.columns:
            cv = (close[t] * volume[t]).tail(20)
            adv20[t] = float(cv.mean()) if len(cv) else np.nan
        else:
            adv20[t] = np.nan

    names = [t for t in tickers if t in beta_ols and np.isfinite(beta_ols[t])
             and t in mom6 and np.isfinite(mom6[t])
             and t in vol63 and np.isfinite(vol63[t])]
    if len(names) < max(3, int(min_stocks)):
        out["model"] = {"available": False,
                        "reason": f"too few stocks with complete characteristics ({len(names)})"}
        return out

    def _z(d: Dict[str, float]) -> Dict[str, float]:
        arr = np.array([d[t] for t in names], dtype=float)
        mu, sd = float(np.nanmean(arr)), float(np.nanstd(arr))
        if sd < 1e-12:
            return {t: 0.0 for t in names}
        return {t: (d[t] - mu) / sd for t in names}

    z_liq = _z({t: (np.log10(adv20[t]) - np.log10(float(adv20_ref_inr))
                     if (t in adv20 and np.isfinite(adv20[t]) and adv20[t] > 0)
                     else 0.0) for t in names})
    z_mom = _z(mom6)
    z_vol = _z(vol63)

    X = np.column_stack([
        np.ones(len(names)),
        np.array([z_liq[t] for t in names]),
        np.array([z_mom[t] for t in names]),
        np.array([z_vol[t] for t in names]),
    ])
    y = np.array([beta_ols[t] for t in names], dtype=float)

    # Ridge with the intercept unpenalized
    n_feat = X.shape[1]
    P = np.eye(n_feat) * float(ridge_lambda)
    P[0, 0] = 0.0
    XtX_p_inv = np.linalg.pinv(X.T @ X + P)
    beta_hat = XtX_p_inv @ X.T @ y
    H = X @ XtX_p_inv @ X.T
    resid = y - X @ beta_hat
    h_diag = np.clip(np.diag(H), 0.0, 0.999)
    loo_pred = y - resid / (1.0 - h_diag)

    lo, hi = float(prior_band[0]), float(prior_band[1])
    priors: Dict[str, float] = {}
    for i, t in enumerate(names):
        p = float(loo_pred[i])
        if not np.isfinite(p):
            continue
        priors[t] = min(max(p, lo), hi)

    ss_t = float(np.sum((y - y.mean()) ** 2))
    ss_r = float(np.sum(resid ** 2))
    r2 = (1.0 - ss_r / ss_t) if ss_t > 1e-12 else 0.0

    out["priors"] = priors
    out["model"] = {
        "available": True,
        "method": ("cross-sectional ridge of OLS beta on [log-ADV vs Rs5cr, 6m momentum, "
                   "63d vol], leave-one-out prediction per stock, intercept unpenalized"),
        "n_stocks": len(names),
        "ridge_lambda": float(ridge_lambda),
        "r2": round(r2, 4),
        "coef_intercept": round(float(beta_hat[0]), 4),
        "coef_z_liquidity": round(float(beta_hat[1]), 4),
        "coef_z_momentum": round(float(beta_hat[2]), 4),
        "coef_z_volatility": round(float(beta_hat[3]), 4),
        "prior_band": [lo, hi],
        "beta_window": int(beta_window),
        "note": ("Characteristic-implied priors (Barra-style fundamental betas) built from "
                 "the LOCAL universe cross-section; the flat BETA_SHRINK_PRIOR / licensed "
                 "BETA_FACTOR_FEED remain the override path (see utils.compute_signal_frame)."),
    }
    return out

def compute_sector_rotation_radar(sector_dfs: dict, benchmark_df: pd.DataFrame = None) -> pd.DataFrame:
    """Sector Rotation Radar & Relative Rotation Graphs (RRG)."""
    if not sector_dfs:
        return pd.DataFrame()
    try:
        rows = []
        bm_px = benchmark_df["Close"].values if (benchmark_df is not None and not benchmark_df.empty and "Close" in benchmark_df.columns) else None
        
        for sec_name, sec_df in sector_dfs.items():
            if sec_df is None or sec_df.empty or "Close" not in sec_df.columns or len(sec_df) < 50:
                continue
                
            px = sec_df["Close"].dropna().values
            
            if bm_px is not None and len(bm_px) >= len(px):
                rs_raw = px / (bm_px[-len(px):] + 1e-9)
            else:
                sma50 = np.mean(px[-50:])
                rs_raw = px / (sma50 + 1e-9)
                
            rs_ratio = float(100.0 * (rs_raw[-1] / (np.mean(rs_raw[-50:]) + 1e-9)))
            rs_momentum = float(100.0 * (rs_raw[-1] / (rs_raw[-10] + 1e-9))) if len(rs_raw) >= 10 else 100.0
            
            if rs_ratio >= 100.0 and rs_momentum >= 100.0:
                quadrant = "Leading"
            elif rs_ratio >= 100.0 and rs_momentum < 100.0:
                quadrant = "Weakening"
            elif rs_ratio < 100.0 and rs_momentum < 100.0:
                quadrant = "Lagging"
            else:
                quadrant = "Improving"
                
            rows.append({
                "Sector": sec_name,
                "RS_Ratio": round(rs_ratio, 2),
                "RS_Momentum": round(rs_momentum, 2),
                "RRG_Quadrant": quadrant,
                "Current_Close": round(float(px[-1]), 2),
                "Return_1M_Pct": round(float((px[-1] / (px[-21] if len(px) >= 21 else px[0])) - 1.0) * 100.0, 2)
            })
            
        return pd.DataFrame(rows).sort_values(by="RS_Ratio", ascending=False)
    except Exception:
        return pd.DataFrame()


# ─────────────────────────────────────────────────────────────────────────────
# 2. Vectorized Technical Indicators & Nifty 50 Fetcher
# ─────────────────────────────────────────────────────────────────────────────

# Canonical Nifty 50 constituents (full 50 tickers)
NIFTY50 = [
    "RELIANCE.NS", "TCS.NS", "HDFCBANK.NS", "INFY.NS", "ICICIBANK.NS",
    "SBIN.NS", "BAJFINANCE.NS", "HCLTECH.NS", "WIPRO.NS", "AXISBANK.NS",
    "KOTAKBANK.NS", "LT.NS", "TITAN.NS", "SUNPHARMA.NS", "ONGC.NS",
    "MARUTI.NS", "NESTLEIND.NS", "POWERGRID.NS", "NTPC.NS", "TECHM.NS",
    "HINDUNILVR.NS", "ITC.NS", "BHARTIARTL.NS", "ASIANPAINT.NS", "COALINDIA.NS",
    "JSWSTEEL.NS", "TATASTEEL.NS", "GRASIM.NS", "ULTRACEMCO.NS", "TATACONSUM.NS",
    "BRITANNIA.NS", "DRREDDY.NS", "CIPLA.NS", "DIVISLAB.NS", "BAJAJFINSV.NS",
    "HEROMOTOCO.NS", "BAJAJ-AUTO.NS", "EICHERMOT.NS", "M&M.NS", "INDUSINDBK.NS",
    "BPCL.NS", "SHRIRAMFIN.NS", "ADANIPORTS.NS", "ADANIENT.NS", "HDFCLIFE.NS",
    "SBILIFE.NS", "TATAMOTORS.NS", "DABUR.NS", "IOC.NS", "GAIL.NS",
]

_NIFTY50_OHLCV_CACHE: dict[str, pd.DataFrame] = {}
_NIFTY50_CACHE_LOCK = threading.Lock()


def _fetch_nifty50_ohlcv(period: str = "3mo") -> dict[str, pd.DataFrame]:
    """Fetches real daily OHLCV for NIFTY50 tickers via yfinance with thread-safe caching.

    AUDIT-FIX (Round 6, D-P2-10): the cache previously ignored the `period`
    argument — the first caller's window (3mo) was served to every later
    request ('1y', '1mo' etc.), so ALL lookback selectors in the technical
    panels displayed identical data. Keyed per-period now."""
    global _NIFTY50_OHLCV_CACHE
    with _NIFTY50_CACHE_LOCK:
        cached = _NIFTY50_OHLCV_CACHE.get(period)
        if cached is not None:
            return cached

    try:
        import yfinance as yf
        data = yf.download(
            tickers=" ".join(NIFTY50),
            period=period,
            interval="1d",
            group_by="ticker",
            auto_adjust=True,
            progress=False,
            threads=True
        )
        res: dict[str, pd.DataFrame] = {}
        for tkr in NIFTY50:
            try:
                if isinstance(data.columns, pd.MultiIndex):
                    if tkr in data.columns.levels[0]:
                        df = data[tkr].dropna()
                    else:
                        continue
                else:
                    df = data.dropna()
                if not df.empty and len(df) >= 5:
                    res[tkr] = df
            except Exception:
                pass
        with _NIFTY50_CACHE_LOCK:
            _NIFTY50_OHLCV_CACHE[period] = res
        return res
    except Exception as _e:
        _logger.warning(f"Failed to fetch NIFTY50 live data: {_e}")
        return {}


def _calc_rsi(close: np.ndarray, period: int = 14) -> float:
    if len(close) < period + 1:
        return 50.0
    diff = np.diff(close)
    gains = np.where(diff > 0, diff, 0.0)
    losses = np.where(diff < 0, -diff, 0.0)
    avg_gain = np.mean(gains[:period])
    avg_loss = np.mean(losses[:period])
    for i in range(period, len(diff)):
        avg_gain = (avg_gain * (period - 1) + gains[i]) / period
        avg_loss = (avg_loss * (period - 1) + losses[i]) / period
    if avg_loss <= 1e-12:
        return 100.0 if avg_gain > 0 else 50.0
    rs = avg_gain / avg_loss
    return float(np.clip(100.0 - (100.0 / (1.0 + rs)), 0.0, 100.0))


def _calc_macd(close: np.ndarray, fast: int = 12, slow: int = 26, signal: int = 9) -> tuple[float, float, float]:
    if len(close) < slow + signal:
        return 0.0, 0.0, 0.0
    def ema(s, n):
        a = 2.0 / (n + 1)
        res = np.empty_like(s, dtype=float)
        res[0] = s[0]
        for i in range(1, len(s)):
            res[i] = a * s[i] + (1 - a) * res[i - 1]
        return res
    f_ema = ema(close, fast)
    s_ema = ema(close, slow)
    macd_line = f_ema - s_ema
    sig_line = ema(macd_line, signal)
    hist = macd_line[-1] - sig_line[-1]
    return float(macd_line[-1]), float(sig_line[-1]), float(hist)


def _calc_stoch(high: np.ndarray, low: np.ndarray, close: np.ndarray, k_period: int = 14, d_period: int = 3) -> tuple[float, float]:
    if len(close) < k_period + d_period:
        return 50.0, 50.0
    k_vals = []
    for i in range(d_period):
        idx = len(close) - d_period + 1 + i
        h_sub = high[max(0, idx - k_period):idx]
        l_sub = low[max(0, idx - k_period):idx]
        c_val = close[idx - 1]
        hh = np.max(h_sub) if len(h_sub) else c_val
        ll = np.min(l_sub) if len(l_sub) else c_val
        k_val = ((c_val - ll) / (hh - ll) * 100.0) if hh != ll else 50.0
        k_vals.append(k_val)
    k_latest = float(np.clip(k_vals[-1], 0.0, 100.0))
    d_latest = float(np.clip(np.mean(k_vals), 0.0, 100.0))
    return k_latest, d_latest


def _calc_cci(high: np.ndarray, low: np.ndarray, close: np.ndarray, period: int = 20) -> float:
    if len(close) < period:
        return 0.0
    tp = (high[-period:] + low[-period:] + close[-period:]) / 3.0
    sma_tp = np.mean(tp)
    mean_dev = np.mean(np.abs(tp - sma_tp))
    if mean_dev <= 1e-12:
        return 0.0
    return float((tp[-1] - sma_tp) / (0.015 * mean_dev))


def _calc_williams_r(high: np.ndarray, low: np.ndarray, close: np.ndarray, period: int = 14) -> float:
    if len(close) < period:
        return -50.0
    hh = np.max(high[-period:])
    ll = np.min(low[-period:])
    if hh == ll:
        return -50.0
    return float(np.clip(((hh - close[-1]) / (hh - ll)) * -100.0, -100.0, 0.0))


def _calc_bollinger(close: np.ndarray, period: int = 20, num_std: float = 2.0) -> tuple[float, float, float, float, float, float]:
    close = np.asarray(close, dtype=float)
    # AUDIT-FIX (Round 5 P2-2): use ddof=1 (sample std) to match industry-standard
    # Bollinger Bands (Bollinger 2001) and the vast majority of backtesting
    # libraries (TA-Lib `BBANDS`, pandas-ta `bbands`, QuantConnect `BB`).
    # The previous ddof=0 (population std) marginally narrowed the bands by
    # sqrt(N/(N-1)) ≈ 1.026 for N=20, producing slightly tighter bands and
    # a small systematic bias in mean-reversion backtests that depend on
    # band-touch frequency. With N=20 the bias is ~2.6% on std and ~0.5%
    # on bandwidth — small but cumulative over 1000s of trades.
    if len(close) < period:
        cmp_ = float(close[-1]) if len(close) > 0 else 100.0
        return cmp_ * 1.05, cmp_, cmp_ * 0.95, 50.0, 10.0, 1.0
    sma = float(np.mean(close[-period:]))
    std = float(np.std(close[-period:], ddof=1)) if period > 1 else float(np.std(close[-period:]))
    ub = sma + num_std * std
    lb = sma - num_std * std
    cmp_ = float(close[-1])
    bw = ((ub - lb) / sma * 100.0) if sma > 0 else 0.0
    pct_b = ((cmp_ - lb) / (ub - lb) * 100.0) if ub != lb else 50.0
    return ub, sma, lb, pct_b, bw, std


def _calc_gaps(open_: np.ndarray, high: np.ndarray, low: np.ndarray, close: np.ndarray) -> list[dict]:
    if len(close) < 2:
        return []
    res = []
    for i in range(1, min(len(close), 20)):
        idx = -i
        prev_idx = idx - 1
        po = open_[idx]
        ph = high[prev_idx]
        pl = low[prev_idx]
        pc = close[prev_idx]

        is_gap_up = po > ph
        is_gap_down = po < pl
        if not (is_gap_up or is_gap_down):
            continue

        gap_pct = abs(po - pc) / pc * 100.0 if pc > 0 else 0.0
        if gap_pct < 0.3:
            continue

        if is_gap_up:
            filled = low[idx:].min() <= ph
            fill_pct = 100.0 if filled else min(100.0, max(0.0, (po - low[idx:].min()) / max(po - ph, 1e-6) * 100.0))
        else:
            filled = high[idx:].max() >= pl
            fill_pct = 100.0 if filled else min(100.0, max(0.0, (high[idx:].max() - po) / max(pl - po, 1e-6) * 100.0))

        res.append({
            "days_ago": i,
            "gap_pct": gap_pct,
            "is_up": is_gap_up,
            "open": po,
            "prev_close": pc,
            "filled": filled,
            "fill_pct": fill_pct
        })
    return res


def _calc_volume_profile(close: np.ndarray, volume: np.ndarray, n_bins: int = 20) -> tuple[float, float, float, float, float, float]:
    if len(close) < 5 or len(volume) < 5:
        cmp_ = float(close[-1]) if len(close) > 0 else 100.0
        return cmp_, cmp_ * 1.05, cmp_ * 0.95, cmp_, cmp_ * 0.98, 15.0
    p_min, p_max = float(np.min(close)), float(np.max(close))
    if p_min == p_max:
        return p_min, p_min * 1.05, p_min * 0.95, p_min, p_min * 0.98, 15.0
    bin_edges = np.linspace(p_min, p_max, n_bins + 1)
    bin_centers = (bin_edges[:-1] + bin_edges[1:]) / 2.0
    bin_indices = np.clip(np.digitize(close, bin_edges) - 1, 0, n_bins - 1)
    vol_by_bin = np.zeros(n_bins)
    for bi, v in zip(bin_indices, volume):
        vol_by_bin[bi] += v
    poc_idx = int(np.argmax(vol_by_bin))
    poc = float(bin_centers[poc_idx])
    total_vol = float(np.sum(vol_by_bin))
    vol_poc_pct = (vol_by_bin[poc_idx] / total_vol * 100.0) if total_vol > 0 else 0.0

    sorted_bin_idx = np.argsort(vol_by_bin)[::-1]
    cum_vol = 0.0
    va_bins = []
    for bi in sorted_bin_idx:
        va_bins.append(bi)
        cum_vol += vol_by_bin[bi]
        if cum_vol >= 0.70 * total_vol:
            break
    vah = float(bin_centers[max(va_bins)])
    val = float(bin_centers[min(va_bins)])

    hvn_idx = sorted_bin_idx[1] if len(sorted_bin_idx) > 1 else poc_idx
    nonzero_mask = vol_by_bin > 0
    if np.any(nonzero_mask):
        lvn_idx = int(np.argmin(np.where(nonzero_mask, vol_by_bin, np.inf)))
    else:
        lvn_idx = 0
    hvn = float(bin_centers[hvn_idx])
    lvn = float(bin_centers[lvn_idx])
    return poc, vah, val, hvn, lvn, float(vol_poc_pct)
