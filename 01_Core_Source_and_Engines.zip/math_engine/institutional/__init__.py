"""Institutional-grade mathematical models package.

This package consolidates the world-class quantitative models implemented
in the Round 6 institutional upgrade:

  Tier 1 — Foundations
    wasserstein_dro_cvar  — Distributionally Robust CVaR (Mohajerin Esfahani & Kuhn 2018)
    herc                   — Hierarchical Equal Risk Contribution (Raffinot 2017)
    qmc_lsmc               — Quasi-Monte Carlo Longstaff-Schwartz (Glasserman 2003)
    svi_surface            — SVI implied-vol surface (Gatheral & Jacquier 2012)

  Tier 2 — Alpha generation
    triple_barrier        — Triple-Barrier Labeling + Meta-Labeling (López de Prado)
    hawkes_orderflow      — Hawkes-process order-flow modeling (Bacry et al 2015)
    almgren_chriss        — Almgren-Chriss optimal execution (2001)
    kalman_cointegration  — Kalman-filtered hedge ratio (Elliott et al 2005)
    copula_stat_arb       — Copula-based stat-arb (Clayton/Gumbel)
    msm_vol               — Markov-Switching Multifractal (Calvet & Fisher 2004)

  Tier 3 — Risk & tail
    conditional_evt       — Peaks-Over-Threshold + GPD (McNeil & Frey 2000)
    fhs_dcc_garch         — Filtered Historical Simulation + DCC-GARCH
    cdar_optimization     — Conditional Drawdown-at-Risk (Chekhlov et al 2005)

  Tier 4 — Adaptive
    bocpd                 — Bayesian Online Change-Point Detection (Adams & MacKay 2007)

  Tier 6 — Validation
    cpcv                  — Combinatorial Purged Cross-Validation (López de Prado)
    deflated_sharpe       — Deflated Sharpe Ratio (Bailey & López de Prado 2014)

All modules are pure-python with NumPy/SciPy/sklearn only — no proprietary
libraries required. Each implementation is annotated with the primary paper
reference and explicit theoretical assumptions.

This sub-package is the single source of truth for institutional-grade
quantitative models in the Quantum_Annealer stack. It is referenced by:
    - optimizer_compliance.evaluate_options_skew_warning (uses svi_surface)
    - optimizer_risk.apply_dro_cvar_constraint (uses wasserstein_dro_cvar)
    - ml_alpha.engine (uses triple_barrier, bocpd)
    - math_engine.smart_order_router (uses almgren_chriss, hawkes_orderflow)
"""
from __future__ import annotations

__all__ = [
    "svi_surface",
    "wasserstein_dro_cvar",
    "herc",
    "qmc_lsmc",
    "triple_barrier",
    "hawkes_orderflow",
    "almgren_chriss",
    "kalman_cointegration",
    "copula_stat_arb",
    "msm_vol",
    "conditional_evt",
    "fhs_dcc_garch",
    "cdar_optimization",
    "bocpd",
    "cpcv",
    "deflated_sharpe",
    # Round 16 institutional upgrades:
    "ff5_factor_model",      # Fama-French 5-factor PIT construction + Fama-MacBeth
    "kelly_betting",         # estimation-error-aware, drawdown-capped Kelly stack
    "lttb",                  # largest-triangle-three-buckets chart downsampling
    # Sovereign Tier-1 Quantitative Alpha & Profile Engines:
    "momentum_vcp",          # Multi-Stage Minervini VCP + Volume-Clock VPIN
    "quality_accounting",    # Sloan Accruals + Piotroski 9-Point F-Score + Novy-Marx Gross Profitability
    "risk_parity",           # Ledoit-Wolf Shrinkage + Hierarchical Risk Parity (HRP) + CVaR
    "ipo_microstructure",    # SEBI Anchor Lock-in Cliff + Free-Float Velocity + Base Tightness
]
