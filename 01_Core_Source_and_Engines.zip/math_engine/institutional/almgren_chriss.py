"""Almgren-Chriss Optimal Execution (2001).

Implements the seminal Almgren-Chriss framework for optimal execution
of equity block orders:

    minimize  E[IS] + λ * Var[IS]
    subject to  Σ_n x_n = X (total parent shares)

where IS = implementation shortfall (vs arrival price), and the
risk-aversion λ controls the trade-off between urgency and price risk.

The optimal trajectory is the solution of a deterministic LQR
problem with closed-form solution (Almgren & Chriss 2001, §4.2):

    x_n = (sinh(κ(T - t_n)) / sinh(κT)) * X

where κ is the "urgency parameter":
    κ = sqrt(λ * σ² / η)
    η = temporary market-impact cost per share per unit rate
    σ = stock volatility (daily)

References:
    Almgren, Robert, and Neil Chriss. "Optimal Execution of Portfolio
    Transactions." Journal of Risk, 3(2):5-39, 2000/2001.

    Cont, Rama, and Artem Kukanov. "Optimal Order Placement in Limit
    Order Markets." Quantitative Finance, 17(1):21-39, 2017.

Used by:
    math_engine.smart_order_router — uses Almgren-Chriss for parent
    order slicing, then Cont-Kukanov RL for child-order placement.
"""
from __future__ import annotations

import logging
import numpy as np
from typing import Optional

logger = logging.getLogger("quantum_annealer.almgren_chriss")


def optimal_trajectory(X: float,
                       T: float,
                       N: int,
                       sigma: float,
                       eta: float = 1e-4,
                       lam: float = 1e-6,
                       return_curve: bool = True) -> dict:
    """Compute the Almgren-Chriss optimal execution trajectory.

    Args:
        X:           total parent shares to execute (signed: + = buy, - = sell)
        T:           total execution horizon (days or hours)
        N:           number of time steps
        sigma:       stock daily volatility (per unit time)
        eta:         temporary market-impact parameter (per share per unit rate)
        lam:         risk aversion parameter (controls risk/return tradeoff)
        return_curve:  if True, return per-step shares remaining

    Returns:
        dict with:
            'times':       list of time-steps [0, T/N, 2T/N, ..., T]
            'shares_remaining': optimal trajectory (per step)
            'trade_rates': per-step execution rate (shares per Δt)
            'kappa':       urgency parameter
            'expected_cost': E[IS]
            'variance':    Var[IS]
    """
    if N < 1 or T <= 0:
        raise ValueError("N must be ≥1 and T > 0")

    dt = T / N
    kappa = np.sqrt(lam * sigma ** 2 / max(eta, 1e-12))
    if kappa < 1e-10:
        # Linear TWAP fallback when λ → 0
        shares_remaining = np.array([X * (1 - n / N) for n in range(N + 1)])
    else:
        # Optimal trajectory: x_n = X * sinh(κ(T - t_n)) / sinh(κT)
        # AUDIT-FIX (Round 13, MATH-8): sinh/sinh overflows to inf/inf = NaN
        # for κT ≳ 710 (e.g. λ=1.25e7 with σ=0.02, η=1e-4). Rewrite in the
        # exp-stable form: with y = κ(T - t_n), z = κT >= y >= 0,
        #   sinh(y)/sinh(z) = e^{-z} * (e^{y} - e^{-y}) / (1 - e^{-2z})
        #                   = (e^{-(z-y)} - e^{-(z+y)}) / (1 - e^{-2z})
        # which decays smoothly to the deterministic (λ→∞) liquidation
        # profile without ever exponentiating a positive argument.
        t_n = np.array([n * dt for n in range(N + 1)])
        z = kappa * T
        if z > 700.0:
            # e^{-2z} is negligible: x_n = X * (e^{-κ t_n} - e^{-κ(2T - t_n)})
            shares_remaining = X * (np.exp(-kappa * t_n) - np.exp(-kappa * (2.0 * T - t_n)))
        else:
            y = kappa * (T - t_n)
            shares_remaining = X * (np.exp(-(z - y)) - np.exp(-(z + y))) / (1.0 - np.exp(-2.0 * z))

    # Per-step execution rate (shares per Δt)
    trade_rates = -np.diff(shares_remaining) / dt

    # Expected IS cost: E[IS] = η * Σ (Δx_n/Δt)² * Δt + γ * Σ x_n² * Δt (γ=permanent)
    # We use only the temporary impact term (γ absorbed into arrival price):
    expected_cost = float(eta * np.sum(trade_rates ** 2 * dt))
    # Variance of IS: σ² * Σ x_n² * Δt
    variance = float(sigma ** 2 * np.sum(shares_remaining[:-1] ** 2 * dt))

    return {
        "times": (np.arange(N + 1) * dt).tolist(),
        "shares_remaining": shares_remaining.tolist(),
        "trade_rates": trade_rates.tolist(),
        "kappa": float(kappa),
        "expected_cost": expected_cost,
        "variance": variance,
        "efficiency": expected_cost + lam * variance,
    }


def calibrate_lambda(daily_sigma: float,
                     target_horizon_days: float = 1.0,
                     target_horizon_share_of_T: float = 0.5,
                     eta: float = 1e-4,
                     sigma: Optional[float] = None) -> float:
    """Pick λ such that κ*T ≈ asinh(some target curvature).

    A common calibration: pick κ such that the trajectory matches
    60-70% of the linear (TWAP) trajectory at the midpoint of T.

    Args:
        daily_sigma:              daily σ of the stock
        target_horizon_days:      expected holding time for the order
        target_horizon_share_of_T: curvature target (0.5 = moderate urgency)
        eta:                      temporary impact coefficient
        sigma:                    if None, use daily_sigma * sqrt(target_horizon_days)
    """
    sig = sigma or (daily_sigma * np.sqrt(target_horizon_days))
    # κ*T = 1 → mild curvature (TWAP-like)
    # κ*T = 5 → strong front-loading
    target_kappa_T = -np.log(1 - target_horizon_share_of_T) * 2  # heuristic
    kappa_target = target_kappa_T / max(target_horizon_days, 1e-6)
    return float(eta * kappa_target ** 2 / max(sig ** 2, 1e-12))


# ──────────────────────────────────────────────────────────────────────────
# Cont-Kukanov smart order router (2017)
# ──────────────────────────────────────────────────────────────────────────

def cont_kukanov_optimal_placement(bid_size: int, ask_size: int,
                                     own_position: int,
                                     own_q_position: int,
                                     p_fill_bid: float = 0.5,
                                     p_fill_ask: float = 0.5,
                                     rebate_bid: float = 0.0001,
                                     rebate_ask: float = 0.0001,
                                     cost_market: float = 0.0005,
                                     alpha_arrival: float = 1.0,
                                     gamma_inventory: float = 0.001,
                                     beta_adverse: float = 0.0005,
                                     max_q_per_level: int = 1000) -> dict:
    """Optimal limit-order placement strategy from Cont-Kukanov (2017).

    Uses a Markov decision process formulation: state = (own position,
    queue position, current L2 snapshot); actions = (place bid, place
    ask, place both, hold); rewards = expected fills × rebates minus
    inventory risk.

    This is the heuristic version (full RL requires online learning).
    The heuristic solves an explicit per-step optimization:

        max over (a_b, a_a) ∈ {0,1}²:
            E[profit | a_b, a_a] - γ * inventory_penalty - β * adverse_select

    Returns:
        dict with 'place_bid' (bool), 'place_ask' (bool), 'optimal_size_bid',
        'optimal_size_ask', 'expected_profit'
    """
    # Inventory penalty (we penalize large absolute positions)
    inv_penalty = gamma_inventory * abs(own_position + own_q_position)

    # Adverse selection: if our fill is at the bid, we risk being picked
    # off by informed flow → subtract expected loss
    adverse_loss_bid = beta_adverse * bid_size
    adverse_loss_ask = beta_adverse * ask_size

    # Expected profit per side
    profit_bid = p_fill_bid * rebate_bid * bid_size - adverse_loss_bid
    profit_ask = p_fill_ask * rebate_ask * ask_size - adverse_loss_ask

    # Decision: place each side independently if profit > 0
    place_bid = profit_bid > inv_penalty / 2
    place_ask = profit_ask > inv_penalty / 2

    # If both placed, double the inv penalty
    if place_bid and place_ask:
        # Pick the better side
        if profit_bid > profit_ask:
            place_ask = profit_ask > inv_penalty
        else:
            place_bid = profit_bid > inv_penalty

    # Optimal sizes (split equally)
    opt_size_bid = bid_size if place_bid else 0
    opt_size_ask = ask_size if place_ask else 0

    expected_profit = (profit_bid if place_bid else 0) + (profit_ask if place_ask else 0) - inv_penalty

    return {
        "place_bid": bool(place_bid),
        "place_ask": bool(place_ask),
        "optimal_size_bid": int(opt_size_bid),
        "optimal_size_ask": int(opt_size_ask),
        "expected_profit": float(expected_profit),
        "inventory_penalty": float(inv_penalty),
    }


# ──────────────────────────────────────────────────────────────────────────
# One-shot execution: parent order → child orders via Almgren-Chriss
# ──────────────────────────────────────────────────────────────────────────

def schedule_parent_order(parent_shares: float,
                            T_days: float = 1.0,
                            N_child_orders: int = 10,
                            daily_sigma: float = 0.015,
                            eta: float = 1e-4,
                            lam: Optional[float] = None,
                            current_position: float = 0.0) -> dict:
    """End-to-end execution scheduling: parent → child orders.

    Args:
        parent_shares:    signed total shares (+ = buy)
        T_days:           horizon in days
        N_child_orders:   number of child orders
        daily_sigma:      daily stock volatility (per day)
        eta:              temporary impact parameter (per share per unit rate)
        lam:              risk aversion; if None, auto-calibrate
        current_position: existing inventory

    Returns:
        dict with 'schedule' (list of (time, shares)), 'kappa', 'expected_cost',
        'variance', 'efficiency'
    """
    if lam is None:
        lam = calibrate_lambda(daily_sigma, target_horizon_days=T_days, eta=eta)

    # Sigma scaled to horizon
    sigma_horizon = daily_sigma * np.sqrt(T_days)
    if T_days <= 0:
        sigma_horizon = daily_sigma

    traj = optimal_trajectory(
        X=parent_shares,
        T=T_days,
        N=N_child_orders,
        sigma=sigma_horizon,
        eta=eta,
        lam=lam,
    )

    schedule = []
    for i, (t, rate) in enumerate(zip(traj["times"][1:], traj["trade_rates"])):
        schedule.append({
            "child_idx": i,
            "time_offset_days": t,
            "shares": float(rate * (T_days / N_child_orders)),
            "is_buy": rate > 0,
        })

    return {
        "schedule": schedule,
        "kappa": traj["kappa"],
        "expected_cost": traj["expected_cost"],
        "variance": traj["variance"],
        "efficiency": traj["efficiency"],
        "lambda_used": lam,
        "parent_shares": float(parent_shares),
        "current_position": float(current_position),
    }


if __name__ == "__main__":
    # Smoke test: schedule 10,000-share buy over 1 day
    res = schedule_parent_order(parent_shares=10000, T_days=1.0,
                                  N_child_orders=10, daily_sigma=0.015)
    print(f"Almgren-Chriss trajectory:")
    print(f"  κ = {res['kappa']:.4f}, λ = {res['lambda_used']:.2e}")
    print(f"  Expected cost: {res['expected_cost']:.4f}")
    print(f"  Variance: {res['variance']:.4f}")
    print(f"  Efficiency: {res['efficiency']:.4f}")
    print(f"  Schedule:")
    for s in res["schedule"][:5]:
        print(f"    t={s['time_offset_days']:.3f}d: {s['shares']:+.1f} shares (buy={s['is_buy']})")
    print("    ...")

    # Cont-Kukanov test
    ck = cont_kukanov_optimal_placement(bid_size=500, ask_size=500,
                                          own_position=200, own_q_position=100)
    print(f"\nCont-Kukanov placement:")
    print(f"  place_bid={ck['place_bid']} (size={ck['optimal_size_bid']})")
    print(f"  place_ask={ck['place_ask']} (size={ck['optimal_size_ask']})")
    print(f"  expected_profit={ck['expected_profit']:.4f}")
