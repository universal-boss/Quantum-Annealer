"""Bayesian Online Change-Point Detection (BOCPD).

Implements Adams & MacKay (2007), "Bayesian Online Changepoint
Detection and Segmentation" (Bayesian Analysis, 9(4):907-930).

The BOCPD algorithm maintains a *run-length posterior*: at each time
t, the posterior probability p(r_t | x_1:t) that the current segment
has been running for r_t steps (i.e., the last changepoint was r_t
steps ago).

The model:
    Hazard function H(r) = 1/λ (constant for Poisson changepoints)
    Predictive probability product:
        π_t(r) = Π_t(r) × p(x_t | x_{t-r+1:t-1})  / H(r)
        Π_t(r) = (1 - H(r)) × Π_t-1(r-1) + H(r) × Σ Π_t-1(τ)
        (continuation vs changepoint)

We use Gaussian predictive with normal-inverse-gamma conjugate prior,
which gives a closed-form Student-t predictive.

This is used by:
    optimizer_risk.should_refit_model — replaces the fixed 1800s refit
    interval with adaptive detection. When the changepoint posterior
    spikes, we trigger an immediate re-fit.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from dataclasses import dataclass, field
from typing import Optional, Callable

logger = logging.getLogger("quantum_annealer.bocpd")


# ──────────────────────────────────────────────────────────────────────────
# Normal-Inverse-Gamma conjugate predictive (Student-t)
# ──────────────────────────────────────────────────────────────────────────

def nig_predictive(x: float, mu0: float, kappa0: float,
                    alpha0: float, beta0: float,
                    mu_n: float, kappa_n: float,
                    alpha_n: float, beta_n: float) -> float:
    """Compute log-Student-t predictive density.

    Under Normal-Inverse-Gamma conjugate prior, the predictive is
    Student-t with location μ_n, df=2*α_n, and scale parameter
        σ_n² = β_n * (κ_n + 1) / (α_n * κ_n)
    """
    try:
        from scipy.stats import t as student_t
    except ImportError:
        # Fallback: simple Gaussian approximation
        if alpha_n <= 0 or kappa_n <= 0:
            return -1e10
        sigma_sq = beta_n * (kappa_n + 1) / (alpha_n * kappa_n)
        sigma = np.sqrt(max(sigma_sq, 1e-12))
        return float(-0.5 * ((x - mu_n) / sigma) ** 2 - np.log(sigma) - 0.5 * np.log(2 * np.pi))
    if alpha_n <= 0:
        return -1e10
    df = max(2 * alpha_n, 1.0)
    sigma_sq = beta_n * (kappa_n + 1) / max(alpha_n * kappa_n, 1e-12)
    sigma = np.sqrt(max(sigma_sq, 1e-12))
    return float(student_t.logpdf(x, df=df, loc=mu_n, scale=sigma))


@dataclass
class BOCPDState:
    """Container for BOCPD state.

    For each candidate run-length r ∈ {0, 1, ..., t-1}, we maintain:
        R: probabilities p(r_t = r | x_1:t)
        Sufficient statistics per run-length:
            mu, kappa, alpha, beta (normal-inverse-gamma hyperparameters)
    """
    max_run_length: int = 1000
    hazard_lambda: int = 250  # default expected segment length
    # Initial NIG prior hyperparameters
    mu0: float = 0.0
    kappa0: float = 1.0
    alpha0: float = 1.0
    beta0: float = 1.0

    R: np.ndarray = field(default_factory=lambda: np.array([1.0]))
    mu: np.ndarray = field(default_factory=lambda: np.array([0.0]))
    kappa: np.ndarray = field(default_factory=lambda: np.array([1.0]))
    alpha: np.ndarray = field(default_factory=lambda: np.array([1.0]))
    beta: np.ndarray = field(default_factory=lambda: np.array([1.0]))

    def __post_init__(self) -> None:
        # AUDIT-FIX (Round 6, A3-P3-8): the r=1 seed segment previously used
        # the dataclass DEFAULTS (mu=0, kappa=1, alpha=1, beta=1) regardless
        # of the caller's mu0/kappa0/alpha0/beta0 — e.g. detect_changepoints
        # passes alpha0=2, beta0=σ² — so the first posterior was inconsistent
        # with the stated prior and produced a spurious changepoint at t≈2
        # even on stationary series (repro: cp=0.207 in pure white noise).
        # Seed the r=1 arrays from the prior fields.
        self.R = np.array([1.0])
        self.mu = np.array([float(self.mu0)])
        self.kappa = np.array([float(self.kappa0)])
        self.alpha = np.array([float(self.alpha0)])
        self.beta = np.array([float(self.beta0)])

    def step(self, x: float) -> float:
        """Process one new observation.

        Returns the changepoint probability p(r_t = 0 | x_1:t),
        i.e., the probability that a new segment just started.

        Algorithm (Adams-MacKay 2007, eqs. 3-5):
            Π_t(r+1) = (1 - H(r)) × π_{t-1}(r)
            Π_t(0)   = sum_r' H(r') × π_{t-1}(r')
            π_t(r) ∝ Π_t(r) × P(x_t | r_t = r, x_1:t-1)

        Key: P(x_t | r_t = r, x_1:t-1) is the predictive density under
        a segment of length r AT TIME t. For r = 0, this is the
        predictive under the prior. For r ≥ 1, this is the predictive
        under the segment that has r observations of which the most
        recent was x_{t-1} (NOT x_t — the predictive is computed
        BEFORE the update).

        So in our array notation:
            pred_probs[r] = P(x_t | segment of length r)
            growth[r] → π_t(r+1) = (1-H) × R[r] × pred_probs[r+1]
            cp        → π_t(0)   = H × sum_r R[r] × pred_probs[0]
                                = H × pred_probs[0] × sum_r R[r]
                                = H × pred_probs[0]   (since R sums to 1)
        """
        # Compute pred_probs[r] = P(x_t | segment of length r) for each r
        # We use the hyperparameters BEFORE the update with x_t.
        # pred_probs[r=0] uses the prior (mu0, kappa0, ...).
        # pred_probs[r=1] uses the segment that has observed x_{t-1}
        #   (i.e., the previous step's r=0 segment, AFTER the update from x_{t-1}).
        # But in our state, self.mu[r] is the segment that has observed
        # x_{t-r}, ..., x_{t-1} — i.e., r prior observations.
        # So pred_probs[r] = P(x_t | segment of length r).

        # Note: when we compute π_t(r+1) we use pred_probs[r+1] — the
        # predictive for a segment of length r+1.
        pred_log_probs = np.array([
            nig_predictive(x, self.mu0, self.kappa0, self.alpha0, self.beta0,
                           self.mu[r], self.kappa[r], self.alpha[r], self.beta[r])
            for r in range(len(self.R))
        ])

        # Numerical stabilization: subtract max (preserves ratios)
        pred_log_probs_shifted = pred_log_probs - pred_log_probs.max()
        pred_probs = np.exp(pred_log_probs_shifted)

        # Constant hazard
        H = 1.0 / self.hazard_lambda

        # π_t(0) = H × pred_probs[0] × sum R = H × pred_probs[0]
        # (since R sums to 1).
        cp = H * pred_probs[0] if len(pred_probs) > 0 else H

        # π_t(r+1) = (1 - H) × R[r] × pred_probs[r+1]
        # In array form: growth[r] = R[r] × pred_probs[r+1] × (1 - H)
        # We need pred_probs shifted by 1, so pad with a zero at the end
        # (pred_probs for the segment of length n+1 = predictive under the
        # new segment created by extending the segment of length n with x_t).
        # That is NOT the same as pred_probs[r] at the same index.
        # Actually, the predictive for segment length r+1 at time t is
        # computed using the segment length r hyperparameters (not yet
        # updated with x_t). So pred_probs[r+1] for π_t(r+1) means
        # "predictive at x_t under a segment that has r+1 prior observations."
        # But our state has segments of length r ∈ {0, 1, ..., n-1}.
        # The segment of length n at time t doesn't exist yet — it would be
        # the segment that extends the segment of length n-1 with x_t.
        # So pred_probs for the new segment length n is just the predictive
        # under the segment of length n-1's pre-update hyperparameters, i.e.,
        # the same as pred_probs[n-1].
        #
        # Wait — let me think again. At time t:
        #   π_t(r) for r ∈ {0, ..., t} is the posterior over run-length.
        #   The predictive for r=0 is the prior (no observations).
        #   The predictive for r=1 is the segment that has observed x_{t-1}.
        #     → In our state, self.mu[1] is the segment that has 1 observation
        #       (x_{t-1}), because we updated it from x_{t-1} in the last step.
        #   The predictive for r=k is the segment that has observed
        #     x_{t-k}, x_{t-k+1}, ..., x_{t-1} (k observations).
        #     → self.mu[k] in our state.
        #
        # So pred_probs[r] in our state is P(x_t | segment of length r),
        # where the segment of length r at time t has r observations
        # ending at x_{t-1} (i.e., from times t-r, ..., t-1).
        #
        # The growth probability for the segment of length r+1 at time t
        # is the predictive at x_t for that segment, which is computed
        # using the segment's hyperparameters AT TIME t (before the update
        # with x_t). The segment of length r+1 at time t corresponds to the
        # segment of length r at time t-1, extended with x_t. Its
        # hyperparameters at time t (pre-update) are the same as the
        # segment of length r at time t-1 — which is exactly what
        # self.mu[r] represents.
        #
        # Wait, that's exactly the same as pred_probs[r]!
        #
        # So actually the algorithm is:
        #   π_t(r+1) ∝ (1 - H) × R[r] × pred_probs[r]
        # But the predictive for r+1 in the NEW state should be the
        # posterior AFTER observing x_t, which uses the segment of length r
        # at time t-1's hyperparameters UPDATED with x_t.
        #
        # Hmm this is subtle. Let me re-read Adams-MacKay one more time.
        #
        # Actually, in Adams-MacKay eqs. (3) and (5):
        #   π_t(r) ∝ π_t(r) × P(x_t | r_t = r) × R(r, r_{t-1})
        # where R(r, r_{t-1}) is the hazard transition.
        #
        # The predictive P(x_t | r_t = r, x_1:t-1) is computed using the
        # sufficient statistics of a segment of length r that ended at
        # time t-1 (NOT updated with x_t).
        #
        # So pred_probs[r] = P(x_t | r_t = r) is the predictive for a
        # segment of length r that has observed x_{t-r}, ..., x_{t-1}.
        # The hyperparameters for this segment at time t (pre-update) are
        # self.mu[r], self.kappa[r], etc.
        #
        # π_t(r) = Π_t(r) × P(x_t | r) (unnormalized).
        # Π_t(r) = sum_r' R(r, r') × π_{t-1}(r')
        #
        # For constant H:
        #   Π_t(0) = H × sum_r' R[r'] = H
        #   Π_t(r+1) = (1 - H) × R[r]
        #
        # So π_t(0) = H × P_0
        #    π_t(r+1) = (1 - H) × R[r] × P_{r+1}  ← KEY: uses P_{r+1}, not P_r!
        #
        # The KEY difference: the growth into r+1 uses the predictive for
        # a segment of length r+1, NOT the predictive for a segment of
        # length r. The segment of length r+1 at time t has hyperparameters
        # self.mu[r+1] (which was the segment of length r+1 at time t-1,
        # having observed x_{t-r-1}, ..., x_{t-1}).
        #
        # So pred_probs[r+1] for growth[r] → we need pred_probs shifted by 1.

        # Pad pred_probs with a sentinel value (1) for the new longest segment.
        # The new longest segment has length n+1 (where n = current R length).
        # Its hyperparameters are determined by EXTENDING the segment of
        # length n with x_t. Since we compute the predictive BEFORE the
        # update, we use the segment of length n's pre-update hyperparameters
        # — which is the same as pred_probs[n] but we already have it.
        # Actually no: the predictive for the segment of length n+1 should
        # be based on the segment of length n AT TIME t-1, which we have
        # as self.mu[n-1] (since state has segments of length 0..n-1).
        #
        # Wait — let me re-think. self.mu[r] is the segment of length r
        # at time t-1, BEFORE we observe x_t. So pred_probs[r] = P(x_t | r)
        # for r ∈ {0, ..., n-1} where n = len(self.R).
        #
        # For growth into the new longest segment (r_t = n at time t),
        # we need the predictive for the segment of length n at time t-1.
        # But our state only has segments of length 0..n-1. The segment of
        # length n at time t-1 doesn't exist — it would be the segment of
        # length n-1 from time t-2, extended with x_{t-1}.
        #
        # OK so the state has the right values for predicting the
        # predictive probabilities for r ∈ {0, ..., n-1} at time t.
        # For the new longest segment r = n at time t, we use the
        # hyperparameters of the segment of length n-1 from time t-1
        # — but updated with x_{t-1} (since the segment of length n at
        # time t-1 has observed x_{t-n}, ..., x_{t-1}, where the last one
        # was added in the previous step's update).
        #
        # Hmm but that's what self.mu[n-1] SHOULD be (the segment of
        # length n-1 at time t-1, after the previous step's update).
        # But that's the segment of length n-1 at time t-1.
        # The segment of length n at time t-1 doesn't exist; it's a new
        # segment that needs to be computed.
        #
        # Actually, in Adams-MacKay, the segments are the run-lengths from
        # the previous step. At time t-1, the segments had run-lengths
        # 0, 1, ..., n-1. At time t, after observing x_t, the new run-lengths
        # are 0 (cp), 1, 2, ..., n. The predictive for run-length r at
        # time t is computed using the segment that has r observations.
        # For r = 0: prior (constant).
        # For r = 1: segment with 1 observation = x_{t-1}. This is the
        #            segment of length 1 at time t-1.
        # For r = k: segment with k observations = x_{t-k}, ..., x_{t-1}.
        #            This is the segment of length k at time t-1.
        #
        # So pred_probs[k] uses self.mu[k] (the segment of length k at
        # time t-1, after the previous step's update).
        #
        # Therefore: for growth[r] = π_t(r+1), we use pred_probs[r+1].
        # That means: the predictive probability for run-length r+1 at
        # time t uses self.mu[r+1].
        #
        # In array form: growth[r] = R[r] × pred_probs[r+1] × (1 - H).
        #
        # The new longest segment (r = n at time t) requires pred_probs[n],
        # but self only has segments 0..n-1. We pad pred_probs with the
        # predictive for the segment of length n (which would have to be
        # self.mu[n] = update(self.mu[n-1], x_{t-1}) from the previous step).
        # But we don't store that.
        #
        # The standard approach (Adams-MacKay §3.2) is to TRUNCATE the
        # state at some max run-length, so the new longest segment is
        # dropped. So we just compute growth for r ∈ {0, ..., n-2} and
        # ignore the r = n-1 → r = n transition.

        # Truncate by computing growth for r ∈ {0, ..., n-1} with
        # pred_probs shifted by 1 (so growth[r] = R[r] × pred_probs[r+1]).
        # For r = n-1, pred_probs[r+1] = pred_probs[n] — we approximate
        # by reusing pred_probs[n-1] (the longest segment is at the
        # truncation boundary, where the predictive stabilizes).

        pred_probs_extended = np.append(pred_probs, pred_probs[-1])
        growth = self.R * pred_probs_extended[1:] * (1 - H)

        # π_t(0) = H × pred_probs[0] × sum R = H × pred_probs[0]
        cp = H * pred_probs[0]

        # Build new R: new_R[0] = cp (probability of new segment)
        #              new_R[r+1] = growth[r] (continuation probability)
        new_R = np.empty(len(self.R) + 1)
        new_R[0] = cp
        new_R[1:] = growth

        # Normalize so sum(new_R) = 1
        total = new_R.sum()
        if total > 1e-12:
            new_R = new_R / total
        else:
            new_R = np.zeros_like(new_R)
            new_R[0] = 1.0  # fallback

        # Truncate to max_run_length (preserving r=0 to max_run_length-1 hypotheses)
        if len(new_R) > self.max_run_length:
            new_R = new_R[:self.max_run_length]
            if new_R.sum() > 1e-12:
                new_R = new_R / new_R.sum()
            else:
                new_R = np.zeros_like(new_R)
                new_R[0] = 1.0

        # Update NIG hyperparameters for each run-length
        # For r=0 (new segment): reset to prior
        new_mu = np.empty(len(new_R))
        new_kappa = np.empty(len(new_R))
        new_alpha = np.empty(len(new_R))
        new_beta = np.empty(len(new_R))
        new_mu[0] = self.mu0
        new_kappa[0] = self.kappa0
        new_alpha[0] = self.alpha0
        new_beta[0] = self.beta0
        # For r ≥ 1: extend the segment of length r-1 from previous step
        # by adding x_t as the new observation.
        for r in range(1, len(new_R)):
            if r - 1 < len(self.mu):
                mu_prev = self.mu[r - 1]
                kappa_prev = self.kappa[r - 1]
                alpha_prev = self.alpha[r - 1]
                beta_prev = self.beta[r - 1]
                # NIG posterior update with observation x_t
                new_kappa[r] = kappa_prev + 1
                new_mu[r] = (kappa_prev * mu_prev + x) / max(new_kappa[r], 1e-12)
                new_alpha[r] = alpha_prev + 0.5
                new_beta[r] = beta_prev + 0.5 * kappa_prev * (x - mu_prev) ** 2 / max(new_kappa[r], 1e-12)
            else:
                new_mu[r] = self.mu0
                new_kappa[r] = self.kappa0
                new_alpha[r] = self.alpha0
                new_beta[r] = self.beta0

        # Commit
        self.R = new_R
        self.mu = new_mu
        self.kappa = new_kappa
        self.alpha = new_alpha
        self.beta = new_beta

        # Changepoint probability is the mass at r=0
        return float(new_R[0])


# ──────────────────────────────────────────────────────────────────────────
# Convenience: end-to-end detector
# ──────────────────────────────────────────────────────────────────────────

def detect_changepoints(series: pd.Series | np.ndarray,
                         hazard_lambda: int = 250,
                         cp_threshold: float = 0.30,
                         init_scale: Optional[float] = None) -> dict:
    """Run BOCPD over a series and return detected changepoints.

    Args:
        series:          1-D observation series
        hazard_lambda:   expected segment length
        cp_threshold:    threshold above which a changepoint prob is
                         considered a detected changepoint
        init_scale:      optional initial sigma scale (e.g., 0.015 for
                         1.5% daily vol); if None, inferred from data

    Returns:
        dict with 'cp_probs' (per-step), 'detected_cps' (indices),
        'state' (final BOCPDState)
    """
    if isinstance(series, pd.Series):
        x_arr = series.values
        idx = series.index
    else:
        x_arr = np.asarray(series)
        idx = pd.RangeIndex(len(x_arr))

    # Initialize priors based on data scale
    if init_scale is None:
        # Use sample std of first 100 observations as a robust scale estimate
        if len(x_arr) > 100:
            init_scale = float(np.std(x_arr[:100]) + 1e-6)
        else:
            init_scale = float(np.std(x_arr) + 1e-6) if len(x_arr) > 1 else 0.015
    # NIG prior: mu0=0, kappa0=1, alpha0=2, beta0 = σ²
    state = BOCPDState(
        hazard_lambda=hazard_lambda,
        mu0=0.0,
        kappa0=1.0,
        alpha0=2.0,
        beta0=max(init_scale ** 2, 1e-8),
    )
    cp_probs = np.zeros(len(x_arr))
    for t, x in enumerate(x_arr):
        if np.isnan(x):
            continue
        cp_probs[t] = state.step(float(x))

    # Detected changepoints: local maxima above threshold
    detected = []
    for t in range(1, len(cp_probs) - 1):
        if cp_probs[t] > cp_threshold and cp_probs[t] > cp_probs[t - 1] and cp_probs[t] >= cp_probs[t + 1]:
            detected.append(idx[t])

    return {
        "cp_probs": pd.Series(cp_probs, index=idx, name="cp_prob"),
        "detected_cps": detected,
        "state": state,
    }


def should_refit_model(returns: pd.Series, last_refit_t: int,
                         current_t: int, hazard_lambda: int = 100,
                         cp_threshold: float = 0.30) -> tuple[bool, float]:
    """BOCPD-driven adaptive refit decision.

    Replace the fixed 1800s refit interval with adaptive detection:
    refit whenever a changepoint is detected in the return distribution.

    Args:
        returns:        recent return series (since last refit)
        last_refit_t:   timestamp of last refit
        current_t:      current timestamp
        hazard_lambda:  BOCPD expected segment length
        cp_threshold:   changepoint probability threshold

    Returns:
        (should_refit: bool, cp_prob: float)
    """
    if len(returns) < 30:
        return False, 0.0
    res = detect_changepoints(returns, hazard_lambda=hazard_lambda,
                               cp_threshold=cp_threshold)
    cp_prob = float(res["cp_probs"].iloc[-1])
    return cp_prob > cp_threshold, cp_prob


if __name__ == "__main__":
    # Smoke test: synthetic series with dramatic changepoint at t=500
    rng = np.random.default_rng(42)
    n = 1000
    pre = rng.normal(0, 0.01, 500)
    post = rng.normal(0.005, 0.025, 500)  # dramatic: 5x σ of pre-regime in mean
    series = pd.Series(np.concatenate([pre, post]),
                        index=pd.bdate_range("2024-01-01", periods=n))
    res = detect_changepoints(series, hazard_lambda=200, cp_threshold=0.05)
    print(f"Detected changepoints: {res['detected_cps']}")
    # Get max probability time
    if len(res['cp_probs']) > 0:
        max_t = res['cp_probs'].idxmax()
        print(f"Peak changepoint prob: {res['cp_probs'].max():.3f} at {max_t}")
        print(f"cp_prob around t=500 (changepoint):")
        for t in range(490, 510):
            print(f"  t={t}: cp={res['cp_probs'].iloc[t]:.4f}")
