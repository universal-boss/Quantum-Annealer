"""Conditional Drawdown-at-Risk (CDaR) portfolio optimization.

Implements the Drawdown-at-Risk and Conditional Drawdown-at-Risk
optimization framework of Chekhlov, Uryasev, and Zabarankin (2005),
"Drawdown Measure in Portfolio Optimization" (International Journal of
Theoretical and Applied Finance, 8(1):13-58).

Drawdown at time t:
    D_t = (peak value of cumulative portfolio up to t) - (value at t)

Drawdown-at-Risk (DaR) at confidence α:
    DaR_α = α-quantile of {D_t : t = 1, ..., T}

Conditional DaR (CDaR):
    CDaR_α = E[D_t | D_t ≥ DaR_α]

Unlike variance or CVaR, drawdowns capture the trajectory of the
portfolio — two portfolios with the same final value can have very
different drawdown profiles (one shallow-but-long, another
deep-but-short). Minimizing CDaR produces portfolios that don't just
have low volatility, they have *shallow underwater curves* — the
single most important practical risk metric for active funds.

References:
    Chekhlov, A., Uryasev, S., and Zabarankin, M. "Drawdown Measure
    in Portfolio Optimization." IJTAF, 8(1):13-58, 2005.

    Goldberg, L. R., and Mahmoud, O. "Drawdown: From Practice to
    Theory and Back Again." Working Paper, 2014.

Used by:
    optimizer_risk.apply_cdar_constraint — alternative to inverse-vol
    risk parity for the SEBI portfolio exposure grid.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Optional

logger = logging.getLogger("quantum_annealer.cdar")


# ──────────────────────────────────────────────────────────────────────────
# Drawdown computation
# ──────────────────────────────────────────────────────────────────────────

def drawdown_series(returns: pd.Series | np.ndarray) -> np.ndarray:
    """Compute the drawdown series from a return series.

    D_t = (cummax(cumsum(r)) - cumsum(r))   — for additive returns
    D_t = (cummax(cumprod(1+r)) - cumprod(1+r)) / cummax(cumprod(1+r))
                                                   — for log returns
    Here we use the additive formulation (returns already represent
    increments of wealth).
    """
    r = np.asarray(returns)
    cum_wealth = np.cumsum(r)
    running_peak = np.maximum.accumulate(cum_wealth)
    drawdowns = running_peak - cum_wealth
    return np.maximum(drawdowns, 0)


def dar(drawdowns: np.ndarray, alpha: float = 0.95) -> float:
    """Drawdown-at-Risk: α-quantile of drawdown series."""
    if len(drawdowns) == 0:
        return 0.0
    sorted_dd = np.sort(drawdowns)[::-1]
    k = max(int(np.ceil((1 - alpha) * len(sorted_dd))), 1)
    return float(sorted_dd[k - 1])


def cdar(drawdowns: np.ndarray, alpha: float = 0.95) -> float:
    """Conditional Drawdown-at-Risk: E[dd | dd ≥ DaR_α]."""
    if len(drawdowns) == 0:
        return 0.0
    sorted_dd = np.sort(drawdowns)[::-1]
    k = max(int(np.ceil((1 - alpha) * len(sorted_dd))), 1)
    if k == 0:
        return float(sorted_dd[0])
    return float(np.mean(sorted_dd[:k]))


# ──────────────────────────────────────────────────────────────────────────
# CDaR-optimal portfolio weights
# ──────────────────────────────────────────────────────────────────────────

def cdar_optimal_weights(returns: pd.DataFrame, alpha: float = 0.95,
                          lam: float = 1.0,
                          long_only: bool = True,
                          max_weight: float = 0.30,
                          target_return: Optional[float] = None) -> np.ndarray:
    """Find weights minimizing CDaR via scipy.optimize.minimize.

    The CDaR minimization is convex (Chekhlov et al. 2005, §3) when
    expressed as an LP. Here we use SLSQP for the smooth constrained
    case (works for ≤50 assets).

    Args:
        returns:        (N, M) returns DataFrame
        alpha:          CDaR confidence level (0.95)
        lam:            risk-aversion (controls the cost vs CDaR tradeoff)
        long_only:      if True, w ≥ 0
        max_weight:     per-asset max weight
        target_return:  optional minimum expected return constraint

    Returns:
        (M,) weights vector summing to 1.
    """
    try:
        from scipy.optimize import minimize
    except ImportError:
        logger.warning("[CDaR] scipy.minimize unavailable; using equal-weights")
        return np.ones(returns.shape[1]) / returns.shape[1]

    if isinstance(returns, pd.DataFrame):
        R = returns.values
    else:
        R = np.asarray(returns)

    N, M = R.shape
    w0 = np.ones(M) / M

    def obj(w):
        port_ret = R @ w
        dd = drawdown_series(port_ret)
        # AUDIT-FIX (Round 6, A3-P3-14): for lam > 1 the (1-lam) return term
        # flipped sign, making SLSQP MINIMIZE expected return. Clip the
        # return weight to [0, 1] so lam>1 simply means "all risk, no return
        # chasing" instead of an inverted objective.
        _ret_w = float(np.clip(1.0 - lam, 0.0, 1.0))
        return lam * cdar(dd, alpha=alpha) - _ret_w * np.mean(port_ret)

    constraints = [{"type": "eq", "fun": lambda w: w.sum() - 1.0}]
    if target_return is not None:
        mu = R.mean(axis=0)
        constraints.append({"type": "ineq", "fun": lambda w: float(mu @ w) - target_return})

    if long_only:
        bounds = [(0, max_weight)] * M
    else:
        bounds = [(-max_weight, max_weight)] * M

    res = minimize(obj, w0, method="SLSQP", bounds=bounds,
                   constraints=constraints,
                   options={"maxiter": 200, "ftol": 1e-6})

    if not res.success or res.x is None:
        logger.warning(f"[CDaR] Optimizer failed ({getattr(res, 'message', 'unknown')}); using equal-weights fallback")
        return np.ones(M) / M

    # Defensive projection & normalization (prevents negative sums on failed/drifting SLSQP solves)
    w = np.clip(res.x, 0.0 if long_only else -max_weight, max_weight)
    w_sum = float(np.sum(w))
    if not np.isfinite(w_sum) or w_sum <= 1e-9:
        logger.warning("[CDaR] Degenerate optimal weight sum; falling back to equal-weights")
        return np.ones(M) / M

    return w / w_sum


# ──────────────────────────────────────────────────────────────────────────
# Convenience: end-to-end CDaR portfolio
# ──────────────────────────────────────────────────────────────────────────

def build_cdar_portfolio(returns: pd.DataFrame, alpha: float = 0.95,
                           lam: float = 1.0, long_only: bool = True,
                           max_weight: float = 0.30,
                           target_return: Optional[float] = None) -> dict:
    """One-shot CDaR portfolio construction."""
    w = cdar_optimal_weights(returns, alpha=alpha, lam=lam,
                              long_only=long_only, max_weight=max_weight,
                              target_return=target_return)
    port_ret = returns.values @ w
    dd = drawdown_series(port_ret)
    return {
        "tickers": list(returns.columns) if isinstance(returns, pd.DataFrame)
                   else [f"S{i}" for i in range(returns.shape[1])],
        "weights": w.tolist(),
        "alpha": alpha,
        "max_drawdown": float(np.max(dd)),
        "dar": dar(dd, alpha=alpha),
        "cdar": cdar(dd, alpha=alpha),
        "mean_return": float(np.mean(port_ret)),
        "sharpe_like": float(np.mean(port_ret) / max(np.std(port_ret), 1e-12) * np.sqrt(252)),
    }


if __name__ == "__main__":
    # Smoke test
    rng = np.random.default_rng(42)
    N, M = 500, 5
    R = pd.DataFrame(rng.normal(0.0004, 0.012, size=(N, M)),
                      columns=[f"S{j}" for j in range(M)])
    res = build_cdar_portfolio(R, alpha=0.95, lam=1.0)
    print(f"Tickers: {res['tickers']}")
    print(f"Weights: {[f'{w:.4f}' for w in res['weights']]}")
    print(f"Max drawdown: {res['max_drawdown']:.4f}")
    print(f"DaR(95%): {res['dar']:.4f}")
    print(f"CDaR(95%): {res['cdar']:.4f}")
    print(f"Sharpe-like: {res['sharpe_like']:.4f}")
