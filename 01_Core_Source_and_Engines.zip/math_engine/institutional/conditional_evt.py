"""Conditional Extreme Value Theory (Conditional EVT).

Implements McNeil & Frey (2000), "Estimation of Tail-Related Risk
Measures for Heteroscedastic Financial Time Series: An Extreme
Value Approach" (Journal of Empirical Finance 7(3-4):271-300).

The two-step conditional EVT approach:
    1. Fit an AR(1)-GARCH(1,1) to the return series; extract the
       standardized residuals (whitened, approximately iid).
    2. Apply Peaks-Over-Threshold (POT) to the residuals: fit the
       Generalized Pareto Distribution (GPD) to excesses over a
       high threshold u.
    3. Compute tail-VaR / ES via the GPD quantile function, then
       transform back through the conditional volatility forecast.

This produces tail-risk estimates that:
    - Account for volatility clustering (via GARCH pre-whitening)
    - Extrapolate beyond the empirical sample (true EVT tail)
    - Survive "Black Monday" style events that historical VaR
      fundamentally cannot (by construction)

References:
    McNeil, A. J., and Frey, R. "Estimation of Tail-Related Risk
    Measures for Heteroscedastic Financial Time Series: An Extreme
    Value Approach." Journal of Empirical Finance, 2000.

    Embrechts, P., Klüppelberg, C., and Mikosch, T. "Modelling
    Extremal Events for Insurance and Finance." Springer, 1997.

Used by:
    optimizer_risk.conditional_var_es — replaces the historical-VaR
    estimate in the SEBI exposure grid with a true tail-VaR.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Optional, Tuple

logger = logging.getLogger("quantum_annealer.cnd_evt")


# ──────────────────────────────────────────────────────────────────────────
# Step 1: AR(1)-GARCH(1,1) fit
# ──────────────────────────────────────────────────────────────────────────

def fit_ar1_garch(returns: pd.Series | np.ndarray) -> dict:
    """Fit an AR(1)-GARCH(1,1) and return standardized residuals.

    Args:
        returns: 1-D return series

    Returns:
        dict with:
            'ar_coef':    φ_1 in r_t = μ + φ_1 r_{t-1} + ε_t
            'garch_omega': ω in σ²_t = ω + α ε²_{t-1} + β σ²_{t-1}
            'garch_alpha': α
            'garch_beta': β
            'residuals':   standardized residuals (whitened)
            'cond_vol':    conditional σ_t series
            'next_sigma':  1-step-ahead forecast σ
    """
    try:
        from arch import arch_model
    except ImportError:
        logger.warning("[Cond-EVT] arch package unavailable; using GMM fallback")
        out = _garch_gmm_fallback(returns)
        out["garch_method"] = "gmm"
        return out

    if isinstance(returns, pd.Series):
        r = returns.values
    else:
        r = np.asarray(returns)

    try:
        am = arch_model(r * 100, mean="AR", lags=1, vol="GARCH", p=1, q=1)
        res = am.fit(disp="off")
        # Standardized residuals (drop leading NaN from AR(1) lag)
        raw_resid = res.resid / res.conditional_volatility
        if hasattr(raw_resid, "dropna"):
            std_resid = raw_resid.dropna().values
        else:
            arr = np.asarray(raw_resid)
            std_resid = arr[~np.isnan(arr)]
        return {
            "ar_coef": float(res.params.get("AR[1]", 0.0)),
            "garch_omega": float(res.params.get("omega", 0.0)),
            "garch_alpha": float(res.params.get("alpha[1]", 0.0)),
            "garch_beta": float(res.params.get("beta[1]", 0.0)),
            "residuals": std_resid,
            "cond_vol": res.conditional_volatility / 100,
            "next_sigma": float(np.sqrt(res.forecast().variance.dropna().iloc[-1, 0])) / 100,
            "fitted_obj": res,
            "garch_method": "arch_mle",
            "log_likelihood": float(res.loglikelihood),
        }
    except Exception as e:
        logger.warning(f"[Cond-EVT] arch fit failed: {e}; using GMM")
        out = _garch_gmm_fallback(returns)
        out["garch_method"] = "gmm"
        return out


def _garch_gmm_fallback(returns: pd.Series | np.ndarray) -> dict:
    """Closed-form method-of-moments GARCH(1,1) fit (no AR)."""
    if isinstance(returns, pd.Series):
        r = returns.values
    else:
        r = np.asarray(returns)
    eps = r - r.mean()
    var_uncond = np.var(r)
    # Method of moments:
    #   E[ε²] = ω / (1 - α - β)  →  ω = var * (1 - α - β)
    #   E[(ε²_t - var)(ε²_{t-1} - var)] = α * var² + β * Cov(ε²_{t-1}, ε²_{t-2})
    # Use moment equations and the relation β = α + β - α (constr. α+β<1)
    acf1_sq = float(np.corrcoef(eps[:-1] ** 2, eps[1:] ** 2)[0, 1])
    # Guard against NaN from constant series
    if not np.isfinite(acf1_sq):
        acf1_sq = 0.05
    alpha = max(acf1_sq, 0.01)
    beta = max(0.9 - alpha, 0.001)
    omega = max(var_uncond * (1 - alpha - beta), 1e-8)

    # Iterate conditional variance
    var_t = np.empty(len(r))
    var_t[0] = var_uncond
    for t in range(1, len(r)):
        var_t[t] = omega + alpha * eps[t - 1] ** 2 + beta * var_t[t - 1]

    std_resid = eps / np.sqrt(np.maximum(var_t, 1e-12))
    next_sigma = float(np.sqrt(omega + alpha * eps[-1] ** 2 + beta * var_t[-1]))
    return {
        "ar_coef": 0.0,
        "garch_omega": float(omega),
        "garch_alpha": float(alpha),
        "garch_beta": float(beta),
        "residuals": std_resid,
        "cond_vol": np.sqrt(var_t),
        "next_sigma": next_sigma,
        "fitted_obj": None,
        "garch_method": "gmm",
        "log_likelihood": float("-inf"),
    }


# ──────────────────────────────────────────────────────────────────────────
# Step 2: Generalized Pareto Distribution (GPD) fit via MLE
# ──────────────────────────────────────────────────────────────────────────

def fit_gpd(x: np.ndarray, threshold: Optional[float] = None,
            n_threshold: int = 50) -> dict:
    """Fit the Generalized Pareto Distribution to excesses over threshold.

    GPD CDF: F(y) = 1 - (1 + ξ y / β)^(-1/ξ), y > 0
    Parameters: ξ (shape), β (scale).

    Args:
        x:          1-D array of residuals (positive tail)
        threshold:  the threshold u (default: empirical 90th pct)
        n_threshold: number of obs above threshold (used if threshold=None)

    Returns:
        dict with 'xi', 'beta', 'threshold', 'n_excesses', 'log_lik'
    """
    if threshold is None:
        threshold = float(np.quantile(x, 0.90))
    excesses = x[x > threshold] - threshold
    n_exc = len(excesses)
    if n_exc < 5:
        logger.warning(f"[Cond-EVT] Too few excesses ({n_exc}) — GPD fit unreliable")
        return {"xi": 0.1, "beta": float(np.std(excesses) or 1.0),
                "threshold": threshold, "n_excesses": n_exc,
                "log_lik": -np.inf}

    try:
        from scipy.optimize import minimize
    except ImportError:
        # Method-of-moments GPD fit (Hosking-Wallis 1987)
        sample_mean = np.mean(excesses)
        sample_var = np.var(excesses)
        if sample_var <= 0 or sample_mean <= 0:
            xi, beta = 0.1, sample_mean
        else:
            ratio = sample_var / sample_mean ** 2
            xi = max(0.5 * (1 - 1 / (1 + ratio)), -0.5)
            beta = 0.5 * sample_mean * (1 + xi)
        return {"xi": float(xi), "beta": float(beta),
                "threshold": threshold, "n_excesses": n_exc,
                "log_lik": -np.inf}

    def neg_log_lik(params):
        xi, beta = params
        if beta <= 0 or xi < -0.5 or xi > 1.0:
            return 1e10
        # GPD log-density:
        #   if ξ != 0: log(f) = -log(β) - (1+1/ξ) * log(1 + ξ*y/β)
        z = 1 + xi * excesses / beta
        if np.any(z <= 0):
            return 1e10
        log_f = -np.log(beta) - (1 + 1.0 / xi) * np.log(z)
        return -float(np.sum(log_f))

    # Multi-restart
    best = None
    for x0 in [(0.1, np.std(excesses)), (0.2, np.mean(excesses)), (0.5, 0.5)]:
        try:
            res = minimize(neg_log_lik, x0, method="Nelder-Mead",
                           options={"maxiter": 500})
            if best is None or res.fun < best.fun:
                best = res
        except Exception:
            continue
    if best is None:
        return {"xi": 0.1, "beta": float(np.std(excesses)),
                "threshold": threshold, "n_excesses": n_exc,
                "log_lik": -np.inf}

    xi_hat, beta_hat = best.x
    return {
        "xi": float(xi_hat),
        "beta": float(beta_hat),
        "threshold": float(threshold),
        "n_excesses": int(n_exc),
        "log_lik": -float(best.fun),
    }


def gpd_quantile(p: float, xi: float, beta: float, threshold: float,
                  n_total: int, n_excesses: int) -> float:
    """Compute the p-quantile of the GPD-tail distribution.

    Following McNeil & Frey (2000):
        For p > n_exc / N (above the threshold), the quantile is:
            u + (β/ξ) * [ (N/n_exc * (1 - p))^(-ξ) - 1 ]
    """
    if xi <= 0:
        return threshold + beta * np.log(n_excesses / (n_total * (1 - p)))
    p_tail = (1 - p) * n_total / max(n_excesses, 1)
    return float(threshold + (beta / xi) * (p_tail ** (-xi) - 1))


# ──────────────────────────────────────────────────────────────────────────
# Step 3: Full conditional EVT pipeline
# ──────────────────────────────────────────────────────────────────────────

def conditional_evt_var_es(returns: pd.Series,
                              alpha: float = 0.99,
                              threshold_quantile: float = 0.90) -> dict:
    """Full McNeil-Frey conditional EVT pipeline.

    Args:
        returns:             1-D daily return series
        alpha:               VaR confidence level (0.99 = 99% VaR)
        threshold_quantile:  quantile above which to fit GPD

    Returns:
        dict with:
            'ar_garch_fit': dict from fit_ar1_garch
            'gpd_fit':      dict from fit_gpd
            'var':          tail-VaR at confidence α
            'es':           tail-ES (expected shortfall) at α
    """
    garch_res = fit_ar1_garch(returns)
    std_resid = garch_res["residuals"]
    next_sigma = garch_res["next_sigma"]

    # Negate because EVT works on the LEFT tail = negative residuals
    neg_resid = -np.asarray(std_resid)
    neg_resid = neg_resid[~np.isnan(neg_resid)]
    threshold = float(np.quantile(neg_resid, threshold_quantile))
    gpd_res = fit_gpd(neg_resid, threshold=threshold)

    # Compute quantile of standardized residuals at confidence α
    # If α is below the threshold, use empirical quantile
    if alpha <= threshold_quantile:
        z_alpha = float(np.quantile(neg_resid, alpha))
    else:
        z_alpha = gpd_quantile(
            p=alpha,
            xi=gpd_res["xi"],
            beta=gpd_res["beta"],
            threshold=gpd_res["threshold"],
            n_total=len(neg_resid),
            n_excesses=gpd_res["n_excesses"],
        )

    # Conditional VaR = -next_sigma * z_alpha  (sign conventions)
    var = -next_sigma * z_alpha
    # Expected shortfall: ES(α) = VaR + (β + ξ * (VaR - u)) / (1 - ξ)
    if gpd_res["xi"] < 1:
        excess = var / -next_sigma - gpd_res["threshold"]
        es_std = z_alpha + (gpd_res["beta"] + gpd_res["xi"] * excess) / max(1 - gpd_res["xi"], 1e-6)
        es = -next_sigma * es_std
    else:
        es = var * 1.5  # rough fallback

    return {
        "ar_garch_fit": {k: v for k, v in garch_res.items() if k != "fitted_obj"},
        "gpd_fit": gpd_res,
        "var": float(var),
        "es": float(es),
        "alpha": alpha,
        "next_sigma": float(next_sigma),
        "z_alpha": float(z_alpha),
    }


if __name__ == "__main__":
    # Smoke test: synthetic returns with GARCH effects
    rng = np.random.default_rng(42)
    n = 1500
    # GARCH(1,1) simulation
    eps = np.zeros(n)
    var = np.zeros(n)
    var[0] = 0.02 ** 2
    for t in range(1, n):
        eps[t] = rng.normal(0, np.sqrt(var[t - 1]))
        var[t] = 1e-5 + 0.1 * eps[t - 1] ** 2 + 0.88 * var[t - 1]
    r = pd.Series(eps, index=pd.bdate_range("2020-01-01", periods=n))

    res = conditional_evt_var_es(r, alpha=0.99)
    print(f"GARCH fit: α={res['ar_garch_fit']['garch_alpha']:.3f} β={res['ar_garch_fit']['garch_beta']:.3f}")
    print(f"GPD fit: ξ={res['gpd_fit']['xi']:.3f} β={res['gpd_fit']['beta']:.4f}")
    print(f"Threshold: {res['gpd_fit']['threshold']:.4f}")
    print(f"99% tail-VaR: {res['var']:.4f}")
    print(f"99% tail-ES: {res['es']:.4f}")
    print(f"Next-period σ forecast: {res['next_sigma']:.4f}")
