"""Copula-Based Statistical Arbitrage.

Replaces Pearson-correlation-based pair selection with copula-based
tail-dependence measures. Pearson correlation captures only linear
co-movement and is famously misleading for tail-risk regimes — two
stocks can have ρ ≈ 0 in normal markets yet exhibit strong
co-movement in crashes (tail dependence).

This module implements:
    1. Empirical CDF (PIT) transforms per asset returns
    2. Clayton copula fit (lower-tail dependence)
    3. Gumbel copula fit (upper-tail dependence)
    4. Tail-dependence coefficient (λ_L, λ_U)
    5. Mispricing index (e.g., conditional CDF vs traded CDF)

References:
    Bianchi, S., Calzolari, M., and Reyes, R. "Measuring Risk with
    Copulas." Statistics and Computing, 2024.

    Joe, H. "Dependence Modeling with Copulas." Chapman & Hall/CRC, 2014.

    Nelsen, R. B. "An Introduction to Copulas." Springer, 2006.

Used by:
    optimizer_risk.detect_copula_pairs — to replace the existing
    Pearson-based pair filter with a tail-aware version.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Optional, Tuple

logger = logging.getLogger("quantum_annealer.copula_arb")


# ──────────────────────────────────────────────────────────────────────────
# Empirical CDF (Probability Integral Transform)
# ──────────────────────────────────────────────────────────────────────────

def empirical_cdf(x: np.ndarray | pd.Series) -> np.ndarray:
    """Compute PIT transform to uniform [0, 1] via empirical CDF.

    Uses the rank-based transform u = rank(x) / (N + 1). This is the
    "Weibull plotting position" — well-known to avoid bias at the
    extremes (Burn 2003).

    Args:
        x: 1-D array

    Returns:
        array of u-values in (0, 1).
    """
    if isinstance(x, pd.Series):
        x_arr = x.values
    else:
        x_arr = np.asarray(x)
    n = len(x_arr)
    ranks = pd.Series(x_arr).rank(method="average").values
    return ranks / (n + 1)


# ──────────────────────────────────────────────────────────────────────────
# Clayton copula
# ──────────────────────────────────────────────────────────────────────────

def clayton_lower_tail_dependence(theta: float) -> float:
    """Clayton copula lower tail dependence λ_L.

    λ_L = 2^(-1/θ)   for θ > 0
    """
    if theta <= 0:
        return 0.0
    return float(2 ** (-1.0 / theta))


def clayton_log_likelihood(u: np.ndarray, v: np.ndarray, theta: float) -> float:
    """Clayton copula log-likelihood (bivariate).

    Clayton density:
        c(u,v) = θ(1+θ) / ((uv)^(1+θ)) * (u^(-θ) + v^(-θ) - 1)^(-(2+1/θ))

    We use the closed-form log-likelihood.
    """
    if theta <= 0:
        return -np.inf
    eps = 1e-10
    u = np.clip(u, eps, 1 - eps)
    v = np.clip(v, eps, 1 - eps)
    log_c = (
        # AUDIT-FIX (Round 13, MATH-4): the prefactor was θ(1+θ); the
        # Clayton density is c(u,v) = (1+θ)·u^(-1-θ)·v^(-1-θ)·
        # (u^(-θ)+v^(-θ)-1)^(-(2+1/θ)) — there is NO θ in the leading
        # factor. Verified by finite-difference differentiation of
        # C(u,v)=(u^(-θ)+v^(-θ)-1)^(-1/θ) (code/true density ratio was
        # exactly θ) and by the θ→0 independence limit (the old form
        # collapsed to c→0 instead of c→1). The spurious ln θ biased the
        # MLE θ̂ and the Clayton-vs-Gumbel likelihood comparison, inflating
        # lower-tail dependence λ_L and over-admitting pairs at the screen.
        np.log(1 + theta)
        - (1 + theta) * (np.log(u) + np.log(v))
        - (2 + 1.0 / theta) * np.log(np.maximum(u ** (-theta) + v ** (-theta) - 1, eps))
    )
    return float(np.sum(log_c))


def fit_clayton(u: np.ndarray, v: np.ndarray) -> dict:
    """Fit Clayton copula parameter θ via MLE.

    Clayton is parameterized by θ ∈ (0, ∞):
        θ > 0: positive lower-tail dependence
        θ → 0: independence copula
    """
    try:
        from scipy.optimize import minimize_scalar
    except ImportError:
        # Fallback: method-of-moments via Kendall τ
        # τ = θ / (θ + 2) → θ = 2τ / (1 - τ)
        rank_u = pd.Series(u).rank()
        rank_v = pd.Series(v).rank()
        tau = float(np.corrcoef(rank_u, rank_v)[0, 1])
        if tau >= 1 - 1e-3:
            theta = 50.0
        elif tau <= 0:
            theta = 0.01
        else:
            theta = 2 * tau / (1 - tau)
        return {"theta": float(theta), "log_lik": -np.inf, "lambda_L": clayton_lower_tail_dependence(theta)}

    def neg_ll(theta):
        return -clayton_log_likelihood(u, v, max(theta, 1e-3))

    res = minimize_scalar(neg_ll, bounds=(1e-3, 30), method="bounded")
    theta = float(res.x)
    return {
        "theta": theta,
        "log_lik": -res.fun,
        "lambda_L": clayton_lower_tail_dependence(theta),
    }


# ──────────────────────────────────────────────────────────────────────────
# Gumbel copula
# ──────────────────────────────────────────────────────────────────────────

def gumbel_upper_tail_dependence(theta: float) -> float:
    """Gumbel copula upper tail dependence λ_U.

    λ_U = 2 - 2^(1/θ)   for θ ≥ 1
    """
    if theta < 1:
        return 0.0
    return float(2 - 2 ** (1.0 / theta))


def gumbel_log_likelihood(u: np.ndarray, v: np.ndarray, theta: float) -> float:
    """Gumbel copula log-likelihood (bivariate)."""
    if theta < 1:
        return -np.inf
    eps = 1e-10
    u = np.clip(u, eps, 1 - eps)
    v = np.clip(v, eps, 1 - eps)
    # Gumbel: C(u,v) = exp(-((-ln u)^θ + (-ln v)^θ)^(1/θ))
    # Density: c = C * (uv)^(-1) * (ln u * ln v)^(θ-1) *
    #          ((-ln u)^θ + (-ln v)^θ)^(2/θ - 2) *
    #          (θ + ((-ln u)^θ + (-ln v)^θ)^(1/θ) - 1)
    ln_u = -np.log(u)
    ln_v = -np.log(v)
    sum_pow = ln_u ** theta + ln_v ** theta
    sum_pow_1_theta = sum_pow ** (1.0 / theta)
    log_C = -sum_pow_1_theta
    log_c = (
        log_C
        - np.log(u) - np.log(v)
        + (theta - 1) * (np.log(ln_u) + np.log(ln_v))
        # AUDIT-FIX (Round 6, A3-P2-5): Gumbel density exponent is
        # (1/θ − 2), NOT (2/θ − 2) — verified by finite differences of
        # C(u,v)=exp(−S^{1/θ}) (the code/FD ratio equalled S^{1/θ} exactly
        # at every point) and by the θ=1 edge case where the copula is
        # independence (density ≡ 1) but the old formula gave S ≠ 1. The
        # biased log-density corrupted the Gumbel MLE and the
        # Clayton-vs-Gumbel model comparison.
        + (1.0 / theta - 2) * np.log(sum_pow)
        + np.log(theta + sum_pow_1_theta - 1)
    )
    return float(np.sum(log_c))


def fit_gumbel(u: np.ndarray, v: np.ndarray) -> dict:
    """Fit Gumbel copula parameter θ via MLE."""
    try:
        from scipy.optimize import minimize_scalar
    except ImportError:
        # Fallback via Kendall τ: τ = 1 - 1/θ → θ = 1/(1-τ)
        rank_u = pd.Series(u).rank()
        rank_v = pd.Series(v).rank()
        tau = float(np.corrcoef(rank_u, rank_v)[0, 1])
        if tau <= 0:
            theta = 1.0
        elif tau >= 1 - 1e-3:
            theta = 50.0
        else:
            theta = 1 / (1 - tau)
        return {"theta": float(theta), "log_lik": -np.inf, "lambda_U": gumbel_upper_tail_dependence(theta)}

    def neg_ll(theta):
        return -gumbel_log_likelihood(u, v, max(theta, 1.001))

    res = minimize_scalar(neg_ll, bounds=(1.001, 30), method="bounded")
    theta = float(res.x)
    return {
        "theta": theta,
        "log_lik": -res.fun,
        "lambda_U": gumbel_upper_tail_dependence(theta),
    }


# ──────────────────────────────────────────────────────────────────────────
# Combined copula-based pair diagnostic
# ──────────────────────────────────────────────────────────────────────────

def copula_pair_diagnostic(x: pd.Series, y: pd.Series,
                            min_lambda: float = 0.10) -> dict:
    """Diagnose pair-trade-ability via Clayton + Gumbel copula fits.

    Args:
        x, y:      price series
        min_lambda: minimum tail dependence threshold

    Returns:
        dict with 'copula_fit' ( Clayton or Gumbel),
        'theta', 'lambda_L', 'lambda_U', 'is_pair_tradable'
    """
    # Convert to returns (or use levels if stationary)
    rx = np.log(x).diff().dropna()
    ry = np.log(y).diff().dropna()
    common = rx.index.intersection(ry.index)
    rx, ry = rx.loc[common], ry.loc[common]

    u = empirical_cdf(rx)
    v = empirical_cdf(ry)

    clayton = fit_clayton(u, v)
    gumbel = fit_gumbel(u, v)

    # Pick the better-fitting copula
    if clayton["log_lik"] >= gumbel["log_lik"]:
        chosen = "clayton"
        theta = clayton["theta"]
        lambda_L = clayton["lambda_L"]
        lambda_U = gumbel["lambda_U"]
    else:
        chosen = "gumbel"
        theta = gumbel["theta"]
        lambda_L = clayton["lambda_L"]
        lambda_U = gumbel["lambda_U"]

    is_pair = max(lambda_L, lambda_U) > min_lambda

    return {
        "copula_fit": chosen,
        "theta": theta,
        "lambda_L": lambda_L,
        "lambda_U": lambda_U,
        "max_tail_dependence": max(lambda_L, lambda_U),
        "is_pair_tradable": bool(is_pair),
        "clayton_log_lik": clayton["log_lik"],
        "gumbel_log_lik": gumbel["log_lik"],
    }


# ──────────────────────────────────────────────────────────────────────────
# Mispricing signal from copula
# ──────────────────────────────────────────────────────────────────────────

def copula_mispricing_signal(x: pd.Series, y: pd.Series,
                              entry_threshold: float = 0.10,
                              exit_threshold: float = 0.50,
                              window: int = 100) -> pd.DataFrame:
    """Generate pair-trade signal from copula conditional CDF.

    The signal is the divergence between the empirical conditional CDF
    P(U | V) under the fitted copula and the observed PIT transform.

    Signal:
        z_t = P̂(U_t ≤ u_t | V_t = v_t) - 0.5
        If z_t > entry_threshold: short U (i.e., short x)
        If z_t < -entry_threshold: long U (i.e., long x)
        Exit when |z_t| < exit_threshold

    This implementation uses the empirical rolling copula (simpler than
    the parametric one but robust to drift in dependence structure).
    """
    rx = np.log(x).diff().dropna()
    ry = np.log(y).diff().dropna()
    common = rx.index.intersection(ry.index)
    rx, ry = rx.loc[common], ry.loc[common]

    # Rolling copula signal via conditional rank
    n = len(rx)
    signal = np.zeros(n)
    for t in range(window, n):
        rx_w = rx.iloc[t - window:t]
        ry_w = ry.iloc[t - window:t]
        # PIT of today's value
        u_t = float(np.mean(rx_w < rx.iloc[t]))
        v_t = float(np.mean(ry_w < ry.iloc[t]))
        # Empirical conditional P(U < u | V = v) ≈ count(U<u AND V near v) / count(V near v)
        near_v = np.abs(ry_w.values - ry.iloc[t]) < ry_w.std()
        if near_v.sum() < 5:
            signal[t] = 0
            continue
        cond_u = float(np.mean((rx_w.values < rx.iloc[t])[near_v]))
        # Center: 0 = no mispricing, + = y underpriced
        signal[t] = cond_u - v_t

    sig = pd.Series(signal, index=rx.index)
    pos = pd.Series(0, index=rx.index, dtype=int)
    holding = 0
    for i, z in enumerate(sig):
        if pd.isna(z):
            continue
        if holding == 0:
            if z > entry_threshold:
                holding = -1
            elif z < -entry_threshold:
                holding = +1
        elif abs(z) < exit_threshold:
            holding = 0
        pos.iloc[i] = holding

    return pd.DataFrame({
        "signal": pos,
        "mispricing_z": sig,
    }, index=rx.index)


if __name__ == "__main__":
    # Smoke test: synthetic correlated assets with tail dependence
    rng = np.random.default_rng(42)
    n = 500
    # Generate correlated returns with lower-tail dependence via Clayton
    from scipy.stats import norm
    u = rng.random(n)
    v_clayton = ((u ** -2 + (1 - u) ** -2 - 1) ** (-1 / 2)).clip(0, 1)
    # Add noise to v
    v = 0.7 * v_clayton + 0.3 * rng.random(n)
    v = np.clip(v, 0, 1)

    x = pd.Series(norm.ppf(u), index=pd.bdate_range("2024-01-01", periods=n))
    y = pd.Series(norm.ppf(v), index=x.index)
    res = copula_pair_diagnostic(x, y)
    print(f"Copula fit: {res['copula_fit']}")
    print(f"θ = {res['theta']:.3f}")
    print(f"λ_L (lower tail) = {res['lambda_L']:.3f}")
    print(f"λ_U (upper tail) = {res['lambda_U']:.3f}")
    print(f"Pair tradable: {res['is_pair_tradable']}")
