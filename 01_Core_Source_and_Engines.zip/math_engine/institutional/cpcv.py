"""Combinatorial Purged Cross-Validation (CPCV).

Implements López de Prado (2018), "Advances in Financial Machine Learning"
(Wiley), Chapter 12 — Combinatorial Purged Cross-Validation.

Standard K-fold cross-validation is unsuitable for financial time series
because labels overlap (the triple-barrier label at time t uses future
returns up to t + vertical_days, which overlaps with labels at t+1,
t+2, etc.). The leakage is severe — backtest Sharpe ratios can be
inflated by 0.5-1.0 in practice.

CPCV solves this by:
  1. Splitting the dataset into N groups (not K folds), where N >= K.
  2. Forming C(N, K) paths, each TESTING on K groups and TRAINING on
     the remaining N-K groups (López de Prado AFML ch. 12 — the
     canonical N=6, K=2 example yields 15 paths, each testing 2 groups).
  3. Purging: removing training observations that are within
     max_label_lookahead of the test set.
  4. Embargo: further removing training observations that come right
     AFTER the test set (to prevent the lookahead from the test
     set into the post-test training data).

The result is K training sets and K test sets, each purged of leakage.
Backtesting K times gives a distribution of Sharpe ratios — the
"Deflated Sharpe Ratio" can then be computed.

References:
    López de Prado, Marcos. "Advances in Financial Machine Learning."
    Wiley, 2018. (Chapter 12)

Used by:
    optimizer_risk.validate_alpha_model — replaces the existing
    KFold(shuffle=False) with proper purged CV.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from itertools import combinations
from typing import Generator, List, Tuple

logger = logging.getLogger("quantum_annealer.cpcv")


# ──────────────────────────────────────────────────────────────────────────
# Standard Purged KFold (López de Prado ch. 7)
# ──────────────────────────────────────────────────────────────────────────

def get_purged_kfold_indices(test_idx: np.ndarray,
                                label_end_times: pd.Series,
                                purge_lookback: int = 5) -> np.ndarray:
    """Identify training observations that need to be purged.

    For each test index t_test, find training indices t_train such that
    label_end_times[t_train] >= t_test - purge_lookback.
    These training observations have labels that overlap into the
    test set's lookahead window.

    Args:
        test_idx:          indices in the test fold
        label_end_times:   Series mapping each observation index to the
                          time at which its label is finalized
        purge_lookback:    purge buffer (in number of observations)

    Returns:
        array of training indices to purge
    """
    if len(test_idx) == 0:
        return np.array([], dtype=int)
    test_start = test_idx.min()
    purge_mask = label_end_times.values >= (test_start - purge_lookback)
    return np.where(purge_mask)[0]


def purged_kfold(n_splits: int, X: pd.DataFrame,
                  label_end_times: pd.Series,
                  purge_lookback: int = 5) -> Generator[Tuple[np.ndarray, np.ndarray], None, None]:
    """Yield (train_idx, test_idx) with leakage-purged folds.

    Args:
        n_splits:        number of folds
        X:               feature DataFrame (used for its index)
        label_end_times: per-index time at which label is finalized
        purge_lookback:  purge buffer (in time units, same units as index)

    Yields:
        (train_idx, test_idx) per fold
    """
    n = len(X)
    fold_size = n // n_splits
    indices = np.arange(n)

    for k in range(n_splits):
        test_start = k * fold_size
        test_end = (k + 1) * fold_size if k < n_splits - 1 else n
        test_idx = indices[test_start:test_end]

        train_idx = np.concatenate([indices[:test_start], indices[test_end:]])

        # Purge training observations whose label end time is >= test_start
        # (i.e., labels that span into the test fold).
        # AUDIT-FIX (Round 6, A3-P2-4): the previous mask
        #   purge_mask = let_arr >= test_start
        # removed EVERY post-test training observation (their labels end
        # after the test starts by construction), collapsing each fold's
        # training set to the pre-test prefix only — or to NOTHING when the
        # test fold contains the first group (verified: 6-group CPCV folds
        # had train sizes 0,0,0,0,0,162). Correct LdP purge: only PRE-test
        # training observations whose labels spill INTO the test span
        # (optionally widened by the purge_lookback buffer) are removed.
        if len(label_end_times) > 0:
            let_arr = np.asarray(label_end_times.values)
            obs_positions = np.arange(n)
            try:
                # Numeric comparison against the test fold's boundaries
                _lo = test_start - (purge_lookback if isinstance(purge_lookback, (int, float)) else 0)
                purge_mask = (obs_positions < test_start) & (let_arr > _lo)
            except Exception:
                continue
            purge_idx = np.where(purge_mask)[0]
            train_idx = np.setdiff1d(train_idx, purge_idx)

        yield train_idx, test_idx


# ──────────────────────────────────────────────────────────────────────────
# Combinatorial Purged Cross-Validation (López de Prado ch. 12)
# ──────────────────────────────────────────────────────────────────────────

def cpcv(n_groups: int, n_paths: int,
          X: pd.DataFrame,
          label_end_times: pd.Series = None,
          purge_lookback: int = 5,
          embargo_pct: float = 0.01) -> List[Tuple[np.ndarray, np.ndarray]]:
    """Generate CPCV train/test splits.

    The dataset is split into N=n_groups contiguous groups. From these
    groups, K=n_paths paths are constructed, each selecting (N-K+1)
    groups for testing and the remainder for training. The result is
    a list of (train_idx, test_idx) pairs.

    Args:
        n_groups:        number of contiguous groups to split data into
        n_paths:         number of paths (= K)
        X:               feature DataFrame
        label_end_times: per-observation label end time (optional)
        purge_lookback:  purge buffer
        embargo_pct:     fraction of training data to embargo after test

    Returns:
        list of (train_idx, test_idx) pairs, one per path
    """
    n = len(X)
    indices = np.arange(n)
    group_boundaries = np.array_split(indices, n_groups)
    groups = [g for g in group_boundaries]

    # Number of test groups per path
    # AUDIT-FIX (Round 13, MATH-1): this was previously
    # `n_test_groups = n_groups - n_paths + 1`, which INVERTED the
    # train/test split — with the canonical N=6, K=2 configuration it
    # produced 6 paths that TESTED on 5/6 of the data and TRAINED on
    # 1/6 (verified numerically: 600 rows -> train=100, test=500).
    # Every "OOS" backtest statistic in cpcv_backtest_distribution was
    # therefore computed on ~83% in-sample data per path, understating
    # OOS variance and overstating strategy robustness. The AFML ch. 12
    # construction tests on K groups and trains on N-K: C(6,2) = 15
    # paths, each testing 1/3 and training 2/3 of the data.
    n_test_groups = n_paths
    if n_test_groups < 1:
        raise ValueError(f"n_paths ({n_paths}) too small for CPCV")
    if n_groups - n_test_groups < 1:
        raise ValueError(
            f"n_groups ({n_groups}) must exceed n_paths ({n_paths}) so each "
            f"path retains a non-empty training set"
        )

    # Enumerate all combinations of n_test_groups from n_groups
    test_combinations = list(combinations(range(n_groups), n_test_groups))

    splits = []
    n_embargo = max(int(n * embargo_pct), 1)
    for test_set in test_combinations:
        # Test indices: union of all groups in the test_set
        test_idx = np.unique(np.concatenate([groups[i] for i in test_set]))

        # Train indices: all groups not in test_set
        train_groups = [i for i in range(n_groups) if i not in test_set]
        train_idx = np.unique(np.concatenate([groups[i] for i in train_groups]))

        # Purge training observations whose labels leak into test
        # AUDIT-FIX (Round 6, A3-P2-4): see the purged_kfold fix above — the
        # previous `let_arr >= test_min` mask deleted ALL post-test training
        # rows (verified: 6-group/2-path CPCV → train sizes 0,0,0,0,0,162).
        # Only pre-test rows whose label spans into the test window are
        # purged now; `purge_lookback` finally does what it documents.
        #
        # AUDIT-FIX (Round 8, math residual — Part 2B): the embargo was applied
        # only after the LAST test group and the label-overlap purge only
        # before the FIRST test group. With combinatorial (non-contiguous)
        # test sets — the whole point of CPCV — train rows sitting BETWEEN
        # two test groups leaked in both directions: their label windows
        # realized inside the later test group, and serially-correlated rows
        # immediately following the earlier test group carried its outcomes.
        # Both purge and embargo are now applied at EVERY test-group boundary.
        if len(train_idx) > 0:
            obs_positions = np.arange(n)
            train_set = set(train_idx.tolist())
            for g in test_set:
                g_idx = groups[g]
                g_min, g_max = int(g_idx.min()), int(g_idx.max())
                # (a) label-window purge BEFORE this test group: train rows
                #     whose labels realize inside the group
                if label_end_times is not None and len(label_end_times) == n:
                    let_arr = np.asarray(label_end_times)
                    try:
                        # AUDIT-FIX (Round 13, MATH-2): the previous comparison
                        # `let_arr > _lo` mixed label END TIMES (often datetimes)
                        # with integer POSITION arithmetic — a TypeError that was
                        # silently swallowed by `except Exception: pass`, which
                        # DISABLED the purge entirely whenever datetime labels
                        # were supplied. Normalize both sides to integer
                        # positions: map each label end time to the index of the
                        # last observation at-or-before it (positional encoding),
                        # so the purge compares positions with positions.
                        if not np.issubdtype(let_arr.dtype, np.number):
                            # datetime-like label ends: encode positionally
                            # via searchsorted on the (sorted) X index.
                            _idx_values = np.asarray(X.index)
                            try:
                                _let_pos = np.searchsorted(
                                    _idx_values, let_arr, side="right"
                                ) - 1  # position of last obs at-or-before label end
                            except TypeError:
                                # index not comparable with label dtype
                                # (mixed types): fall back to ordinal encoding
                                _order = {
                                    v: i for i, v in enumerate(pd.unique(let_arr))
                                }
                                _let_pos = np.asarray(
                                    [_order.get(v, -1) for v in let_arr], dtype=int
                                )
                        else:
                            # numeric label ends. Two sub-cases:
                            #  * X.index numeric  -> values live on the same
                            #    numeric axis as the index (searchsorted is
                            #    the faithful positional encoding).
                            #  * X.index datetime  -> the values are INTEGER
                            #    POSITIONS (np.arange(n)+h is the canonical
                            #    construction in tests and in
                            #    cpcv_backtest_sharpe_distribution) — use them
                            #    directly, clamped to the sample range.
                            #    (Clamping label ends to the LAST observation
                            #    would instead mark every training row's label
                            #    as spanning the whole sample and purge the
                            #    entire pre-test history — verified failure.)
                            _idx_values = np.asarray(X.index)
                            if np.issubdtype(_idx_values.dtype, np.number):
                                _let_pos = np.searchsorted(
                                    _idx_values, let_arr, side="right"
                                ) - 1
                            else:
                                _let_pos = np.clip(
                                    let_arr.astype(int), 0, n - 1
                                )
                        _lo = g_min - (
                            purge_lookback
                            if isinstance(purge_lookback, (int, float))
                            else 0
                        )
                        purge_mask = (obs_positions < g_min) & (_let_pos > _lo)
                        train_set -= set(np.where(purge_mask)[0].tolist())
                    except Exception as _purge_err:
                        # AUDIT-FIX (Round 13, MATH-2): never silently disable
                        # the purge — a failure to purge is a leakage event.
                        logger.warning(
                            "CPCV label-purge failed (falling back to "
                            "embargo-only protection): %s",
                            _purge_err,
                        )
                # (b) embargo AFTER this test group: drop the immediately
                #     following n_embargo train rows
                train_set -= set(range(g_max + 1, g_max + 1 + n_embargo))
            train_idx = np.array(sorted(train_set), dtype=int)

        splits.append((train_idx, test_idx))

    return splits


# ──────────────────────────────────────────────────────────────────────────
# CPCV backtest: train N models, get distribution of Sharpe ratios
# ──────────────────────────────────────────────────────────────────────────

def cpcv_backtest_sharpe_distribution(returns: pd.Series,
                                         n_groups: int = 6,
                                         n_paths: int = 2,
                                         purge_lookback: int = 5,
                                         embargo_pct: float = 0.01) -> dict:
    """Run a simple CPCV backtest and compute the Sharpe distribution.

    For pedagogical purposes: uses a simple "buy-and-hold" strategy
    within each test set (no actual model training). The user should
    replace this with their own model fitting + signal generation.

    Args:
        returns:         Series of daily returns
        n_groups:         number of contiguous groups
        n_paths:          number of paths (= K, default 2)
        purge_lookback:   purge buffer
        embargo_pct:      embargo fraction

    Returns:
        dict with 'sharpe_distribution' (list of Sharpe per path),
        'mean_sharpe', 'std_sharpe', 'min_sharpe', 'max_sharpe'
    """
    X = pd.DataFrame({"r": returns.values}, index=returns.index)
    # Use integer positions for label_end_times for simplicity
    label_end_times = pd.Series(np.arange(len(returns)) + 5, index=returns.index)

    splits = cpcv(n_groups=n_groups, n_paths=n_paths, X=X,
                   label_end_times=label_end_times,
                   purge_lookback=purge_lookback,
                   embargo_pct=embargo_pct)

    sharpes = []
    for train_idx, test_idx in splits:
        if len(test_idx) < 5:
            continue
        test_returns = returns.iloc[test_idx]
        if test_returns.std() > 0:
            sharpe = float(np.mean(test_returns) / np.std(test_returns, ddof=1) * np.sqrt(252))
            sharpes.append(sharpe)

    return {
        "sharpe_distribution": sharpes,
        "n_paths_actual": len(sharpes),
        "mean_sharpe": float(np.mean(sharpes)) if sharpes else float("nan"),
        "std_sharpe": float(np.std(sharpes, ddof=1)) if len(sharpes) > 1 else 0.0,
        "min_sharpe": float(np.min(sharpes)) if sharpes else float("nan"),
        "max_sharpe": float(np.max(sharpes)) if sharpes else float("nan"),
    }


if __name__ == "__main__":
    # Smoke test: CPCV backtest on synthetic returns
    rng = np.random.default_rng(42)
    n = 1000
    returns = pd.Series(rng.normal(0.0004, 0.012, n),
                         index=pd.bdate_range("2020-01-01", periods=n))
    res = cpcv_backtest_sharpe_distribution(returns, n_groups=6, n_paths=2)
    print(f"Number of paths: {res['n_paths_actual']}")
    print(f"Sharpe distribution: {[f'{s:.3f}' for s in res['sharpe_distribution']]}")
    print(f"Mean Sharpe: {res['mean_sharpe']:.3f}")
    print(f"Std Sharpe:  {res['std_sharpe']:.3f}")
    print(f"Min Sharpe:  {res['min_sharpe']:.3f}")
    print(f"Max Sharpe:  {res['max_sharpe']:.3f}")
