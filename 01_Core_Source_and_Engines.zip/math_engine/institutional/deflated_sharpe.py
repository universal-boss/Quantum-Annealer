"""Deflated Sharpe Ratio (Bailey & López de Prado 2014).

Implements Bailey & López de Prado (2014), "The Deflated Sharpe Ratio"
(Journal of Portfolio Management, 40(5):94-107).

The Deflated Sharpe Ratio (DSR) is the probability that a strategy
with observed Sharpe ratio SR̂ is actually profitable (SR > 0),
accounting for:
    1. Sample size (shorter backtests → wider Sharpe distribution)
    2. Skewness and kurtosis of returns (non-normality)
    3. Multiple testing (the more strategies tried, the more likely
       the best is a fluke)

The DSR is:
    DSR = Φ( (SR̂ - SR_max) × √(T-1) / √(1 - γ₃ SR̂ + ((γ₄ - 1)/4) SR̂²) )

Where:
    SR_max       = E[max of N iid draws from the Sharpe distribution]
                  (Euler-Mascheroni approximation)
    γ₃, γ₄       = skewness and kurtosis of returns
    T            = number of observations

A DSR < 0.95 (or higher threshold like 0.99 for institutional) means
the strategy is NOT statistically distinguishable from noise, even if
the observed Sharpe looks impressive.

References:
    Bailey, D. H., and López de Prado, M. "The Deflated Sharpe Ratio."
    Journal of Portfolio Management, 40(5):94-107, 2014.

    Bailey, D. H., Borwein, J., López de Prado, M., and Zhu, Q. J.
    "The Probability of Backtest Overfitting." Journal of Risk,
    16(4):1-10, 2014.

Used by:
    optimizer_risk.validate_strategy — used in addition to CPCV
    Sharpe distribution to make a final go/no-go decision.
"""
from __future__ import annotations

import logging
import math
import numpy as np
import pandas as pd
from typing import Optional

logger = logging.getLogger("quantum_annealer.deflated_sharpe")


# ──────────────────────────────────────────────────────────────────────────
# Sharpe ratio with skewness/kurtosis adjustment
# ──────────────────────────────────────────────────────────────────────────

def sharpe_ratio(returns: pd.Series | np.ndarray,
                  freq_per_year: int = 252) -> dict:
    """Compute annualized Sharpe ratio with skewness and kurtosis.

    Lo (2002) shows that the standard Sharpe ratio (mean / std) is
    biased when returns are autocorrelated. We provide both:
        - standard Sharpe
        - Lo-corrected Sharpe (accounting for 1-lag autocorrelation)

    Returns:
        dict with 'sharpe', 'sharpe_lo', 'mean', 'std', 'skew', 'kurt',
        'autocorr_lag1', 'n_obs', 'freq_per_year'
    """
    r = np.asarray(returns)
    r = r[~np.isnan(r)]
    n = len(r)
    if n < 2:
        return {"sharpe": 0.0, "sharpe_lo": 0.0, "mean": 0.0,
                "std": 0.0, "skew": 0.0, "kurt": 0.0,
                "autocorr_lag1": 0.0, "n_obs": n, "freq_per_year": freq_per_year}

    mean = float(np.mean(r))
    std = float(np.std(r, ddof=1))
    skew = float(((r - mean) ** 3).mean() / (std ** 3)) if std > 0 else 0.0
    kurt = float(((r - mean) ** 4).mean() / (std ** 4) - 3.0) if std > 0 else 0.0
    ac1 = float(np.corrcoef(r[:-1], r[1:])[0, 1]) if n > 2 else 0.0

    sharpe = mean / std * math.sqrt(freq_per_year) if std > 0 else 0.0
    # Lo (2002) autocorrelation correction
    # σ_corrected² = σ² × (1 + 2 * sum_{k=1}^{K} ρ_k * (K-k)/K)
    # AUDIT-FIX (Round 6, A3-P3-13): the previous branch used 1 − 2·ac1 for
    # NEGATIVE autocorrelation — inflating σ for the wrong sign and
    # contradicting both Lo (2002) and the formula above. Always 1 + 2·ac1
    # (clamped to a small positive floor), per the module's own comment.
    sharpe_lo = mean / (std * math.sqrt(max(1.0 + 2 * ac1, 1e-8))) * math.sqrt(freq_per_year) \
                if std > 0 else 0.0

    return {
        "sharpe": float(sharpe),
        "sharpe_lo": float(sharpe_lo),
        "mean": mean,
        "std": std,
        "skew": skew,
        "kurt": kurt,
        "autocorr_lag1": ac1,
        "n_obs": n,
        "freq_per_year": freq_per_year,
    }


# ──────────────────────────────────────────────────────────────────────────
# Expected Maximum of N standard normal draws (Euler-Mascheroni approx)
# ──────────────────────────────────────────────────────────────────────────

def expected_max_sharpe(n_trials: int, freq_per_year: int = 252,
                          var_per_period: Optional[float] = None) -> float:
    """E[max of N Sharpe ratios] under the null hypothesis (all SR = 0).

    Bailey & López de Prado (2014, eq. 9):
        E[max] = sqrt(V[SR]) × ( (1 - γ) × Φ⁻¹(1 - 1/N) + γ × Φ⁻¹(1 - 1/(N×e)) )

    Where:
        γ = Euler-Mascheroni constant ≈ 0.5772
        Φ⁻¹ = inverse standard normal CDF
        V[SR] = variance of the Sharpe estimator
        N = number of trials

    AUDIT-FIX (Round 6, A3-P1-2): the previous body used
    σ = 1/sqrt(freq_per_year) — a frequency-proxy that ignores the sample
    size T — while the caller ALSO divided the result by sqrt(freq), a
    second scaling of the same factor (total error ≈ freq/√n ≈ 8× too
    lenient at n=1000, N=100, freq=252). The estimator variance is now
    passed explicitly by the DSR function (V = (1−γ₃SR+(γ₄−1)/4·SR²)/(T−1));
    when it is not supplied, the documented 1/T approximation with
    T = freq_per_year is used (kept for backward compatibility of the
    public signature). var_per_period semantics: the VARIANCE (not SD) of
    the per-period Sharpe estimator.

    Returns:
        E[max Sharpe ratio] (per-period scale) under the null
    """
    if n_trials <= 1:
        # With only 1 trial, expected max = 0 (no multiple-testing inflation)
        return 0.0
    if var_per_period is None or var_per_period <= 0:
        var_per_period = 1.0 / max(freq_per_year, 1)
    try:
        from scipy.stats import norm
    except ImportError:
        # Fallback when scipy is not available: E[max of N std normals]
        # ≈ sqrt(2 ln N); scale by the SR estimator SD.
        return float(math.sqrt(2 * math.log(n_trials)) * math.sqrt(var_per_period))

    euler_gamma = 0.5772156649015329
    # Clip quantiles to avoid ppf(0) = -inf
    q1 = max(1 - 1.0 / n_trials, 1e-10)
    q2 = max(1 - 1.0 / (n_trials * math.e), 1e-10)
    z1 = float(norm.ppf(q1))
    z2 = float(norm.ppf(q2))
    expected_max_std = (1 - euler_gamma) * z1 + euler_gamma * z2
    return expected_max_std * math.sqrt(max(var_per_period, 1e-16))


# ──────────────────────────────────────────────────────────────────────────
# Deflated Sharpe Ratio
# ──────────────────────────────────────────────────────────────────────────

def deflated_sharpe_ratio(returns: pd.Series | np.ndarray,
                            n_trials: int = 1,
                            freq_per_year: int = 252) -> dict:
    """Compute the Deflated Sharpe Ratio.

    Args:
        returns:        daily (or other period) returns
        n_trials:       number of backtests tried (default 1 = no multiple
                        testing correction)
        freq_per_year:   number of observations per year

    Returns:
        dict with:
            'sharpe':           observed annualized Sharpe
            'sharpe_lo':        Lo (2002) autocorrelation-corrected Sharpe
            'skew':             return skewness
            'kurt':             excess kurtosis
            'expected_max_SR':  expected max Sharpe under null (given N)
            'deflated_sharpe':  the deflated Sharpe (PSR > 0)
            'p_value':          probability SR > 0 after adjustment
    """
    sr_info = sharpe_ratio(returns, freq_per_year=freq_per_year)
    n = sr_info["n_obs"]
    if n < 5:
        return {
            "sharpe": 0.0, "sharpe_lo": 0.0, "skew": 0.0, "kurt": 0.0,
            "expected_max_SR": 0.0, "deflated_sharpe": 0.0, "p_value": 0.0,
        }

    SR = sr_info["sharpe"]
    SR_per_period = SR / math.sqrt(freq_per_year)  # de-annualize for SE

    # Variance of the Sharpe estimator under non-normality (Bailey-LdP 2014):
    #   V[SR] = (1/(T-1)) × (1 - γ₃ × SR + ((γ₄ - 1)/4) × SR²)
    # where γ₃ is skewness and γ₄ is raw kurtosis.
    gamma3 = sr_info["skew"]
    gamma4 = sr_info["kurt"] + 3.0  # raw kurtosis, not excess
    var_numerator = 1 - gamma3 * SR_per_period + ((gamma4 - 1) / 4.0) * SR_per_period ** 2
    var_numerator = max(var_numerator, 1e-8)
    # AUDIT-FIX (Round 6, A3-P1-2): V[SR] uses (T-1), and the multiple-testing
    # threshold SR* = sqrt(V)·[(1−γ)z₁+γz₂] is compared against the PERIODIC
    # SR directly (no second 1/√freq scaling — the previous code divided SR*
    # by √freq AGAIN after already embedding a 1/√freq proxy inside
    # expected_max_sharpe, understating the hurdle ~8× and flipping verdicts
    # from FAIL to PASS for mediocre strategies).
    V_SR = var_numerator / max(n - 1, 1)
    SR_max_per_period = expected_max_sharpe(n_trials, var_per_period=V_SR)
    SR_max = SR_max_per_period * math.sqrt(freq_per_year)  # annualized for display
    SE = math.sqrt(V_SR)

    # Z-statistic for testing H0: true SR ≤ SR* vs H1: true SR > SR*
    z = (SR_per_period - SR_max_per_period) / SE if SE > 0 else 0.0

    try:
        from scipy.stats import norm
        p_value = float(1 - norm.cdf(z))
    except ImportError:
        # Use math.erfc approximation
        p_value = 0.5 * math.erfc(z / math.sqrt(2))

    return {
        "sharpe": float(SR),
        "sharpe_lo": float(sr_info["sharpe_lo"]),
        "skew": float(gamma3),
        "kurt": float(gamma4 - 3.0),
        "n_obs": int(n),
        "freq_per_year": freq_per_year,
        "n_trials": int(n_trials),
        "expected_max_SR": float(SR_max),
        "deflated_sharpe": float(z),
        "p_value": float(p_value),
        "verdict": "PASS" if p_value < 0.05 else "FAIL",
    }


# ──────────────────────────────────────────────────────────────────────────
# Convenience: evaluate a strategy under multiple-testing correction
# ──────────────────────────────────────────────────────────────────────────

def evaluate_strategy(returns: pd.Series, n_trials: int = 1,
                       min_p_value: float = 0.05,
                       freq_per_year: int = 252) -> dict:
    """One-shot strategy evaluation via Deflated Sharpe Ratio.

    Returns:
        dict with all DSR fields plus 'is_significant' (bool)
    """
    res = deflated_sharpe_ratio(returns, n_trials=n_trials, freq_per_year=freq_per_year)
    res["is_significant"] = res["p_value"] < min_p_value
    return res


if __name__ == "__main__":
    # Smoke test
    rng = np.random.default_rng(42)
    # Case 1: Honest Sharpe ~ 1.0 (true mean = 0.001, std = 0.015)
    r1 = pd.Series(rng.normal(0.001, 0.015, 1000),
                    index=pd.bdate_range("2020-01-01", periods=1000))
    res1 = evaluate_strategy(r1, n_trials=1)
    print(f"Strategy 1 (n_trials=1):")
    print(f"  Sharpe: {res1['sharpe']:.3f}")
    print(f"  Expected max SR under null: {res1['expected_max_SR']:.3f}")
    print(f"  Deflated SR (z-stat): {res1['deflated_sharpe']:.3f}")
    print(f"  P-value: {res1['p_value']:.4f}")
    print(f"  Verdict: {res1['verdict']} (significant: {res1['is_significant']})")

    # Case 2: Same strategy, but with 100 trials (multiple testing)
    res2 = evaluate_strategy(r1, n_trials=100)
    print(f"\nStrategy 1 (n_trials=100, multiple testing):")
    print(f"  Sharpe: {res2['sharpe']:.3f}")
    print(f"  Expected max SR under null: {res2['expected_max_SR']:.3f}")
    print(f"  Deflated SR (z-stat): {res2['deflated_sharpe']:.3f}")
    print(f"  P-value: {res2['p_value']:.4f}")
    print(f"  Verdict: {res2['verdict']} (significant: {res2['is_significant']})")

    # Case 3: Spurious backtest (Sharpe ~ 2.0 from noise, n=100, 1000 trials)
    r3 = pd.Series(rng.normal(0, 0.01, 100),
                    index=pd.bdate_range("2020-01-01", periods=100))
    # Boost mean to get Sharpe ~2 by luck
    r3 = r3 + 0.001
    res3 = evaluate_strategy(r3, n_trials=1000)
    print(f"\nStrategy 3 (short backtest, n_trials=1000):")
    print(f"  Sharpe: {res3['sharpe']:.3f}")
    print(f"  Expected max SR under null: {res3['expected_max_SR']:.3f}")
    print(f"  P-value: {res3['p_value']:.4f}")
    print(f"  Verdict: {res3['verdict']} (significant: {res3['is_significant']})")
