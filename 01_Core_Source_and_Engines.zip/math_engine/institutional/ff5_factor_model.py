"""Fama-French 5-Factor Model — PIT-safe factor construction & attribution.

Implements the factor set of Fama & French (2015), "A Five-Factor Asset
Pricing Model" (Journal of Financial Economics, 116(1):1-22):

    MKT  market excess return
    SMB  small minus big (size), averaged across the B/M, OP and Inv sorts
    HML  high minus low (book-to-market, "value")
    RMW  robust minus weak (operating profitability)
    CMA  conservative minus aggressive (investment)

Key institutional properties of this implementation:

  1. POINT-IN-TIME (PIT) SAFETY. Accounting signals (BE, OP, Inv) must be
     supplied already lagged to the formation date by the caller (fiscal-year
     t data becomes investable July t+1 — the publication calendar of the
     Kenneth French data library). The module NEVER fabricates fundamentals:
     a ticker missing a characteristic is simply excluded from that
     characteristic's legs (fail-open to a smaller cross-section).

  2. 2x3 INDEPENDENT SORTS. Size breakpoint = cross-sectional median
     (small/big); characteristic breakpoints = 30th/70th percentiles
     (low/neutral/high). Legs are value-weighted by market equity.

  3. FF2015 SMB: the average of the three characteristic-specific size
     spreads, each computed from its full 2x3 grid:
        SMB_x = mean(S_x[low, neutral, high]) - mean(B_x[low, neutral, high])
        SMB   = mean(SMB_BM, SMB_OP, SMB_INV)
     and HML/RMW/CMA = small-half + big-half average of (high - low).

  4. FAMA-MACBETH (1973) two-stage cross-sectional regression with
     Newey-West (1987) HAC standard errors for premium hypothesis tests.

  5. ROLLING EXPOSURE / ATTRIBUTION. Rolling OLS betas per asset and a
     factor decomposition of portfolio returns (factor tilts vs. residual
     alpha), annualized with an explicit frequency assumption (252).

References:
    Fama & French (2015), JFE 116(1):1-22.
    Fama & MacBeth (1973), JPE 81(3):607-636.
    Newey & West (1987), Econometrica 55(3):703-708.
"""
from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

logger = logging.getLogger("quantum_annealer.ff5")

FACTORS = ("MKT", "SMB", "HML", "RMW", "CMA")

__all__ = [
    "FACTORS",
    "build_ff5_factors",
    "fama_macbeth",
    "rolling_exposures",
    "factor_attribution",
    "FF5Factors",
]


# ──────────────────────────────────────────────────────────────────────────
# Data structures
# ──────────────────────────────────────────────────────────────────────────

@dataclass
class FF5Factors:
    """Result of the factor construction."""
    factors: pd.DataFrame              # index=date, columns=FACTORS
    formation_years: List[int]
    n_names_median: float
    low_cross_section: bool
    notes: List[str] = field(default_factory=list)


# ──────────────────────────────────────────────────────────────────────────
# Core helpers
# ──────────────────────────────────────────────────────────────────────────

def _leg_return(rets: np.ndarray, me: np.ndarray, mask: np.ndarray) -> Optional[float]:
    """Value-weighted leg return; None when the leg is empty or degenerate."""
    if rets is None or me is None or mask is None or not np.any(mask):
        return None
    w = np.where(mask, np.maximum(me, 0.0), 0.0)
    total = float(w.sum())
    if total <= 0:
        return None
    return float(np.dot(w / total, rets))


def _breakpoints(vals: np.ndarray) -> Optional[Tuple[float, float]]:
    """30th/70th percentile breakpoints of the finite values (None if < 6)."""
    v = vals[np.isfinite(vals)]
    if len(v) < 6:
        return None
    return float(np.percentile(v, 30)), float(np.percentile(v, 70))


# ──────────────────────────────────────────────────────────────────────────
# Core construction
# ──────────────────────────────────────────────────────────────────────────

def build_ff5_factors(
    returns: pd.DataFrame,
    market_equity: pd.DataFrame,
    book_equity: Optional[pd.DataFrame] = None,
    operating_profitability: Optional[pd.DataFrame] = None,
    investment: Optional[pd.DataFrame] = None,
    risk_free: float = 0.0,
    rebalance_month: int = 6,
    min_cross_section: int = 8,
) -> FF5Factors:
    """Construct FF5 factor returns from a PIT cross-section.

    Args:
        returns:      DataFrame[date x ticker] of period returns.
        market_equity: DataFrame[date x ticker]; the first observation of
                      each formation year is the June formation snapshot.
        book_equity:  BE aligned to the formation date (already PIT-lagged).
                      None → HML and its SMB leg are skipped (never faked).
        operating_profitability: OP aligned PIT; None → RMW skipped.
        investment:   Inv aligned PIT; None → CMA skipped.
        risk_free:    scalar risk-free period return (MKT = Rm - rf).
        rebalance_month: 6 = the June/July publication calendar.
        min_cross_section: minimum names to form a year's factors.

    Returns:
        FF5Factors with a DataFrame[date x FACTORS] of period factor returns.
    """
    rets = returns.astype(float)
    me_all = market_equity.reindex(columns=rets.columns).astype(float)
    dates = pd.DatetimeIndex(rets.index)

    char: Dict[str, Optional[pd.DataFrame]] = {
        "bm": book_equity.reindex(columns=rets.columns).astype(float) if book_equity is not None else None,
        "op": operating_profitability.reindex(columns=rets.columns).astype(float) if operating_profitability is not None else None,
        "inv": investment.reindex(columns=rets.columns).astype(float) if investment is not None else None,
    }

    # Formation years run July(y) .. June(y+1)
    periods = []
    formation_years: List[int] = []
    for d in dates:
        y = d.year if d.month > rebalance_month else d.year - 1
        if not formation_years or formation_years[-1] != y:
            formation_years.append(y)
        periods.append(y)
    period_series = pd.Series(periods, index=dates)

    rows: List[Dict[str, Optional[float]]] = []
    n_names_list: List[float] = []
    notes: List[str] = []

    for y in formation_years:
        y_dates = period_series[period_series == y].index
        y_rets = rets.loc[y_dates]
        y_me = me_all.loc[y_dates]

        me0 = y_me.iloc[0].values                       # June formation ME
        mean_rets = y_rets.mean(axis=0).fillna(0.0).values
        finite_me = np.isfinite(me0) & (me0 > 0)

        n_names_list.append(float(finite_me.sum()))
        if finite_me.sum() < min_cross_section:
            notes.append(f"{y}: cross-section too small ({int(finite_me.sum())} names) — factors skipped")
            for _ in y_dates:
                rows.append({f: None for f in FACTORS})
            continue

        # ── Size split at the median (2x3 independent sort) ──
        med = float(np.median(me0[finite_me]))
        small = finite_me & (me0 <= med)
        big = finite_me & (me0 > med)

        # ── MKT: value-weighted market excess return ──
        w_mkt = np.where(finite_me, me0, 0.0)
        w_mkt = w_mkt / w_mkt.sum()
        mkt = float(np.dot(w_mkt, mean_rets)) - float(risk_free)

        # ── Per-characteristic 2x3 grid ──
        def _grid(vals: Optional[np.ndarray]) -> Optional[Dict[str, np.ndarray]]:
            """low/neutral/high masks for one characteristic, or None."""
            if vals is None:
                return None
            fin = np.isfinite(vals)
            bp = _breakpoints(np.where(fin, vals, np.nan))
            if bp is None or fin.sum() < min_cross_section:
                return None
            p30, p70 = bp
            return {
                "low": fin & (vals <= p30),
                "neutral": fin & (vals > p30) & (vals < p70),
                "high": fin & (vals >= p70),
                "any": fin,
            }

        bm_g = _grid(char["bm"].loc[y_dates].iloc[0].values if char["bm"] is not None else None)
        op_g = _grid(char["op"].loc[y_dates].iloc[0].values if char["op"] is not None else None)
        inv_g = _grid(char["inv"].loc[y_dates].iloc[0].values if char["inv"] is not None else None)

        smb_components: List[float] = []
        hml_parts: List[float] = []
        rmw_parts: List[float] = []
        cma_parts: List[float] = []

        for g, hi_name, lo_name, parts, note_name in (
            (bm_g, "high", "low", hml_parts, "B/M"),
            (op_g, "high", "low", rmw_parts, "OP"),
            (inv_g, "low", "high", cma_parts, "Inv"),   # CMA: conservative(low inv) - aggressive(high inv)
        ):
            if g is None:
                notes.append(f"{y}: {note_name} unavailable — factor + SMB leg skipped")
                continue

            # SMB_x: mean of 3 small legs - mean of 3 big legs
            s_legs = [_leg_return(mean_rets, me0, small & g[k]) for k in ("low", "neutral", "high")]
            b_legs = [_leg_return(mean_rets, me0, big & g[k]) for k in ("low", "neutral", "high")]
            s_vals = [v for v in s_legs if v is not None]
            b_vals = [v for v in b_legs if v is not None]
            if s_vals and b_vals:
                smb_components.append(float(np.mean(s_vals) - np.mean(b_vals)))

            # factor: mean of (hi - lo) across the small & big buckets
            s_hi = _leg_return(mean_rets, me0, small & g[hi_name])
            s_lo = _leg_return(mean_rets, me0, small & g[lo_name])
            b_hi = _leg_return(mean_rets, me0, big & g[hi_name])
            b_lo = _leg_return(mean_rets, me0, big & g[lo_name])
            diffs = [h - l for h, l in ((s_hi, s_lo), (b_hi, b_lo)) if h is not None and l is not None]
            if diffs:
                parts.append(float(np.mean(diffs)))

        smb = float(np.mean(smb_components)) if smb_components else None
        hml = float(np.mean(hml_parts)) if hml_parts else None
        rmw = float(np.mean(rmw_parts)) if rmw_parts else None
        cma = float(np.mean(cma_parts)) if cma_parts else None

        for _ in y_dates:
            rows.append({"MKT": mkt, "SMB": smb, "HML": hml, "RMW": rmw, "CMA": cma})

    factor_df = pd.DataFrame(rows, index=dates, columns=list(FACTORS))
    n_med = float(np.median(n_names_list)) if n_names_list else 0.0

    return FF5Factors(
        factors=factor_df,
        formation_years=formation_years,
        n_names_median=n_med,
        low_cross_section=bool(n_med < 20),
        notes=notes,
    )


# ──────────────────────────────────────────────────────────────────────────
# Stage-2: Fama-MacBeth cross-sectional regressions with Newey-West t-stats
# ──────────────────────────────────────────────────────────────────────────

def _newey_west_tstats(gammas: np.ndarray, lags: int) -> np.ndarray:
    """HAC (Newey-West 1987, Bartlett kernel) t-statistics for the mean of
    the per-period gamma estimates."""
    T, K = gammas.shape
    if T < 3:
        return np.zeros(K)
    g_bar = gammas.mean(axis=0)
    demeaned = gammas - g_bar
    S = demeaned.T @ demeaned / T
    for L in range(1, min(lags, T - 1) + 1):
        w = 1.0 - L / (lags + 1.0)          # Bartlett kernel
        G = demeaned[L:].T @ demeaned[:-L] / T
        S += w * (G + G.T)
    se = np.sqrt(np.maximum(np.diag(S), 0.0) / T)
    with np.errstate(divide="ignore", invalid="ignore"):
        t = np.where(se > 0, g_bar / se, 0.0)
    return t


def fama_macbeth(
    asset_returns: pd.DataFrame,
    factor_returns: pd.DataFrame,
    max_lags: Optional[int] = None,
) -> Dict[str, object]:
    """Fama-MacBeth (1973) two-stage risk-premium estimation.

    Stage 1: time-series OLS of each asset on the factors (full-sample betas).
    Stage 2: per-period cross-sectional OLS of returns on betas; reported
             premium = mean gamma, with Newey-West HAC t-statistics.

    Args:
        asset_returns:  DataFrame[date x asset].
        factor_returns: DataFrame[date x factor], same date index.
        max_lags:       HAC lags (default: NW rule-of-thumb 4(T/100)^(2/9)).

    Returns:
        dict with per-factor premium, t-stat, p-value, mean R², diagnostics.
    """
    common = asset_returns.index.intersection(factor_returns.index)
    if len(common) < 12:
        return {"premia": {}, "tstats": {}, "pvalues": {},
                "n_periods": int(len(common)), "note": "insufficient overlap (<12 periods)"}

    A = asset_returns.loc[common].astype(float)
    F = factor_returns.loc[common].astype(float)
    T, K = F.shape
    if max_lags is None:
        max_lags = max(1, int(math.floor(4 * (T / 100.0) ** (2.0 / 9.0))))

    # Stage 1: betas — A.values is (T, N): transpose to (N, T) then regress
    X = np.column_stack([np.ones(T), F.values])
    pinv_XtX = np.linalg.pinv(X.T @ X)
    betas = A.values.T @ X @ pinv_XtX                 # (N, K+1)
    B = betas[:, 1:]
    Z = np.column_stack([np.ones(B.shape[0]), B])     # (N, K+1)

    # Stage 2: per-period cross-sectional OLS
    gammas = np.zeros((T, K + 1))
    r2_list: List[float] = []
    for t in range(T):
        y = A.values[t]
        ok = np.isfinite(y)
        if ok.sum() > K + 1:
            ZtZ_inv = np.linalg.pinv(Z[ok].T @ Z[ok])
            gammas[t] = ZtZ_inv @ Z[ok].T @ y[ok]
            resid = y[ok] - Z[ok] @ gammas[t]
            ss_res = float(resid @ resid)
            ss_tot = float(((y[ok] - y[ok].mean()) ** 2).sum())
            r2_list.append(1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0)

    tstats = _newey_west_tstats(gammas, max_lags)
    names = ["const"] + [str(c) for c in F.columns]

    try:
        from scipy.stats import norm as _norm
        pvals = {n: float(2 * (1 - _norm.cdf(abs(float(tstats[j]))))) for j, n in enumerate(names)}
    except Exception:
        pvals = {n: None for n in names}

    return {
        "premia": {n: float(gammas[:, j].mean()) for j, n in enumerate(names)},
        "tstats": {n: float(tstats[j]) for j, n in enumerate(names)},
        "pvalues": pvals,
        "mean_r2": float(np.mean(r2_list)) if r2_list else None,
        "n_periods": int(T),
        "n_assets": int(A.shape[1]),
        "nw_lags": int(max_lags),
    }


# ──────────────────────────────────────────────────────────────────────────
# Rolling exposures & portfolio attribution
# ──────────────────────────────────────────────────────────────────────────

def rolling_exposures(
    asset_returns: pd.Series,
    factor_returns: pd.DataFrame,
    window: int = 60,
    min_periods: int = 36,
) -> pd.DataFrame:
    """Rolling OLS factor betas for one asset's returns.

    Returns DataFrame[date x factor]; rows appear once `min_periods` are
    available inside the window (never fabricated).
    """
    common = asset_returns.index.intersection(factor_returns.index)
    y = asset_returns.loc[common].astype(float)
    F = factor_returns.loc[common].astype(float)

    out = {f: [] for f in F.columns}   # type: ignore[assignment]
    idx_out = []
    for end in range(len(common)):
        start = end - window + 1
        if start < 0 or (end - start + 1) < min_periods:
            continue
        y_w = y.iloc[start:end + 1].values
        F_w = F.iloc[start:end + 1].values
        if not np.all(np.isfinite(y_w)):
            continue
        X = np.column_stack([np.ones(len(F_w)), F_w])
        try:
            coef = np.linalg.pinv(X.T @ X) @ X.T @ y_w
        except np.linalg.LinAlgError:
            continue
        for j, f in enumerate(F.columns):
            out[f].append(float(coef[1 + j]))
        idx_out.append(common[end])
    return pd.DataFrame(out, index=pd.DatetimeIndex(idx_out))


def factor_attribution(
    portfolio_returns: pd.Series,
    factor_returns: pd.DataFrame,
    rf: float = 0.0,
    periods_per_year: int = 252,
) -> Dict[str, object]:
    """Decompose realized portfolio performance into factor contributions.

    Full-sample OLS: r_p - rf = alpha + Σ beta_f·f. A factor's contribution
    is beta_f·mean(f), annualized. Residual alpha = intercept, annualized.
    Factors with insufficient data yield NaN — never invented numbers.
    """
    common = portfolio_returns.index.intersection(factor_returns.index)
    if len(common) < 12:
        return {"note": "insufficient overlap", "n_periods": int(len(common))}

    r = portfolio_returns.loc[common].astype(float).values
    F = factor_returns.loc[common].astype(float)
    y = r - float(rf)
    X = np.column_stack([np.ones(len(F)), F.values])

    coef = np.linalg.pinv(X.T @ X) @ X.T @ y
    alpha = float(coef[0])
    betas = {str(f): float(coef[1 + j]) for j, f in enumerate(F.columns)}

    resid = y - X @ coef
    ss_res = float(resid @ resid)
    ss_tot = float(((y - y.mean()) ** 2).sum())
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0

    contrib = {str(f): float(betas[str(f)] * float(F[f].mean()) * periods_per_year) for f in F.columns}

    return {
        "betas": betas,
        "factor_contributions_annual": contrib,
        "alpha_annual": float(alpha * periods_per_year),
        "r_squared": float(r2),
        "total_annual_return": float(float(np.mean(r)) * periods_per_year),
        "n_periods": int(len(common)),
        "periods_per_year": periods_per_year,
    }
