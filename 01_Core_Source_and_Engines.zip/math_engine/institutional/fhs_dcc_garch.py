"""Filtered Historical Simulation + DCC-GARCH.

Implements the Filtered Historical Simulation (FHS) approach of
Barone-Adesi, Bourgoin, and Giannopoulos (2002), "When to Hedge with
Stock-Index Options" (RISK Magazine), combined with the Dynamic
Conditional Correlation (DCC) multivariate GARCH model of Engle
(2002), "Dynamic Conditional Correlation" (Journal of Business &
Economic Statistics, 20(3):339-350).

FHS algorithm:
    1. Fit univariate GARCH(1,1) to each asset return series; extract
       standardized residuals.
    2. Bootstrap from the residual pool (with replacement) — preserving
       the joint distribution (no Gaussian assumption).
    3. Multiply each bootstrapped residual by the 1-step-ahead σ_t
       forecast to generate N simulated paths.
    4. Compute portfolio returns from each path; extract VaR/ES.

DCC-GARCH gives time-varying cross-asset correlations on top:
    H_t = D_t R_t D_t
    R_t = diag(Q_t)^(-1/2) Q_t diag(Q_t)^(-1/2)
    Q_t = (1 - a - b) Q̄ + a u_{t-1} u'_{t-1} + b Q_{t-1}

Combination: FHS with DCC-conditioned correlation structure =
multivariate tail-VaR that captures both vol-clustering and
correlation breakdown in stress regimes.

References:
    Barone-Adesi, G., Bourgoin, F., and Giannopoulos, K. "Don't Look
    Back." Risk, 12(8):99-103, 1999.

    Engle, R. F. "Dynamic Conditional Correlation." JBES, 2002.

Used by:
    optimizer_risk.multivariate_var_es — used in the SEBI portfolio
    exposure grid to estimate stress-scenario VaR.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Optional

logger = logging.getLogger("quantum_annealer.fhs_dcc_garch")


# ──────────────────────────────────────────────────────────────────────────
# Univariate GARCH(1,1) per-asset fit
# ──────────────────────────────────────────────────────────────────────────
# Round 10: arch package now wired in. Two paths available:
#   (a) fit_univariate_garch_mle  — full MLE via `arch.arch_model` (preferred
#       when arch>=6.3.0 is installed; produces statistically efficient
#       parameter estimates and properly whitened standardized residuals)
#   (b) fit_univariate_garch_gmm  — closed-form method-of-moments fallback
#       (no external dependency; used when arch import fails or fit diverges)
# The dispatcher `fit_univariate_garch(r)` tries (a) first, falls back to (b)
# on ANY error (ImportError, convergence failure, NaN in residual). Every
# return dict carries a `garch_method` field ('arch_mle' | 'gmm') so callers
# can attribute downstream result quality to the underlying estimator.

def fit_univariate_garch_mle(r: np.ndarray) -> dict:
    """Full MLE GARCH(1,1) fit via the `arch` package.

    Uses arch.arch_model with mean='Constant' (zero-mean if demeaned
    elsewhere), vol='GARCH', p=1, q=1. Returns the same dict shape as
    fit_univariate_garch_gmm so the two are interchangeable.

    Raises ImportError if arch is unavailable; raises ValueError or
    RuntimeError if the MLE fit fails to converge or produces NaN
    standardized residuals. Callers should catch and fall back to GMM.
    """
    from arch import arch_model  # ImportError propagates to caller

    eps = r - r.mean()
    # arch scales internally to %; we restore the original scale
    am = arch_model(eps * 100, mean="Zero", vol="GARCH", p=1, q=1,
                    rescale=False)
    res = am.fit(disp="off", show_warning=False)

    omega = float(res.params.get("omega", 0.0))
    alpha = float(res.params.get("alpha[1]", 0.0))
    beta = float(res.params.get("beta[1]", 0.0))

    cond_vol_pct = np.asarray(res.conditional_volatility, dtype=float)
    cond_vol = cond_vol_pct / 100.0
    std_resid = eps / np.maximum(cond_vol, 1e-12)

    # Validate before returning — MLE can fail silently with NaN if data is degenerate
    if not np.all(np.isfinite(std_resid)) or np.any(cond_vol <= 0):
        raise ValueError(f"arch MLE produced non-finite residuals or "
                         f"non-positive cond_vol (omega={omega}, "
                         f"alpha={alpha}, beta={beta})")

    next_sigma_pct = float(np.sqrt(
        res.forecast(horizon=1, reindex=False).variance.dropna().iloc[-1, 0]
    ))
    next_sigma = next_sigma_pct / 100.0

    return {
        "omega": omega,
        "alpha": alpha,
        "beta": beta,
        "std_resid": std_resid,
        "cond_vol": cond_vol,
        "next_sigma": next_sigma,
        "garch_method": "arch_mle",
        "log_likelihood": float(res.loglikelihood),
    }


def fit_univariate_garch_gmm(r: np.ndarray) -> dict:
    """Closed-form GARCH(1,1) fit via method-of-moments (no AR).

    Round 10: now also adds `garch_method='gmm'` and `log_likelihood=-inf`
    fields so its return shape matches fit_univariate_garch_mle.
    """
    eps = r - r.mean()
    var_uncond = np.var(r)
    if len(r) > 2:
        acf1_sq = float(np.corrcoef(eps[:-1] ** 2, eps[1:] ** 2)[0, 1])
    else:
        acf1_sq = 0.05
    # Guard against NaN from constant series
    if not np.isfinite(acf1_sq):
        acf1_sq = 0.05
    alpha = max(acf1_sq, 0.01)
    beta = max(0.9 - alpha, 0.001)
    omega = max(var_uncond * (1 - alpha - beta), 1e-8)

    var_t = np.empty(len(r))
    var_t[0] = var_uncond
    for t in range(1, len(r)):
        var_t[t] = omega + alpha * eps[t - 1] ** 2 + beta * var_t[t - 1]

    std_resid = eps / np.sqrt(np.maximum(var_t, 1e-12))
    next_sigma = float(np.sqrt(omega + alpha * eps[-1] ** 2 + beta * var_t[-1]))
    return {
        "omega": float(omega),
        "alpha": float(alpha),
        "beta": float(beta),
        "std_resid": std_resid,
        "cond_vol": np.sqrt(var_t),
        "next_sigma": next_sigma,
        "garch_method": "gmm",
        "log_likelihood": float("-inf"),
    }


def fit_univariate_garch(r: np.ndarray) -> dict:
    """Dispatcher: try arch MLE first, fall back to GMM on ANY error.

    Returns the union of the two underlying functions' fields. Always
    sets `garch_method` to either 'arch_mle' or 'gmm' so callers can
    attribute result quality.
    """
    try:
        return fit_univariate_garch_mle(r)
    except ImportError:
        logger.debug("[FHS-DCC] arch unavailable; using GMM univariate path")
        return fit_univariate_garch_gmm(r)
    except Exception as e:
        # Convergence failure, NaN residuals, singular data — anything
        logger.warning(f"[FHS-DCC] arch MLE failed ({e}); falling back to GMM")
        return fit_univariate_garch_gmm(r)


# ──────────────────────────────────────────────────────────────────────────
# DCC-GARCH (Engle 2002) — method-of-moments approximation
# ──────────────────────────────────────────────────────────────────────────

def fit_dcc_garch_gmm(returns: pd.DataFrame) -> dict:
    """Fit DCC-GARCH. Per-asset GARCH via arch MLE when available (else GMM).

    Round 10: per-asset univariate fits now route through the
    `fit_univariate_garch` dispatcher, which prefers `arch.arch_model`
    full MLE and falls back to method-of-moments on any error. The DCC
    step itself remains method-of-moments (arch.univariate.DCC is not
    exposed in arch 8.x's public API). The return dict gains a
    `garch_methods` list indicating which estimator was used per asset.

    Step 1: Univariate GARCH per asset (arch MLE preferred).
    Step 2: Standardize residuals.
    Step 3: Estimate DCC parameters (a, b) from cross-correlation
            dynamics of standardized residuals.

    Returns:
        dict with 'sigma_next' (vector), 'R_next' (correlation matrix),
        'std_resids' (N×M array of standardized residuals),
        'garch_methods' (list[str], len M)
    """
    if isinstance(returns, pd.DataFrame):
        returns = returns.values

    N, M = returns.shape
    sigma_next = np.zeros(M)
    std_resids = np.zeros((N, M))
    garch_methods: list[str] = []

    for j in range(M):
        r = returns[:, j]
        g = fit_univariate_garch(r)
        std_resids[:, j] = g["std_resid"]
        sigma_next[j] = g["next_sigma"]
        garch_methods.append(g.get("garch_method", "unknown"))

    # DCC: Q_t = (1-a-b) Q̄ + a u u' + b Q_{t-1}
    # Method of moments: estimate (a, b) from ACF of squared cross-products
    # Simpler approach: use sample correlation of std_resids as Q̄
    Qbar = np.corrcoef(std_resids.T)
    if Qbar.shape == ():
        Qbar = np.array([[1.0]])
        std_resids = std_resids.reshape(-1, 1)

    # Estimate DCC parameters from cross-product ACF
    if M > 1:
        # u u' across time — average correlation between lagged cross-products
        cross_products = np.array([np.outer(std_resids[t], std_resids[t])
                                    for t in range(N)])
        # ACF of average cross-product
        cp_avg = cross_products.mean(axis=(1, 2))
        if len(cp_avg) > 2:
            acf1_cp = float(np.corrcoef(cp_avg[:-1], cp_avg[1:])[0, 1])
        else:
            acf1_cp = 0.05
    else:
        acf1_cp = 0.05

    a_dcc = max(acf1_cp * 0.5, 0.01)
    b_dcc = max(0.95 - a_dcc, 0.001)

    # Iterate Q_t (N×M×M)
    R_t = np.zeros((N, M, M))
    Q_t = np.zeros((N, M, M))
    Q_t[0] = Qbar
    inv_sqrt_Q0 = np.diag(1.0 / np.sqrt(np.diag(Qbar)))
    R_t[0] = inv_sqrt_Q0 @ Qbar @ inv_sqrt_Q0

    for t in range(1, N):
        u_prev = std_resids[t - 1]
        Q_t[t] = (1 - a_dcc - b_dcc) * Qbar + a_dcc * np.outer(u_prev, u_prev) + b_dcc * Q_t[t - 1]
        inv_sqrt_diag = np.diag(1.0 / np.sqrt(np.diag(Q_t[t])))
        R_t[t] = inv_sqrt_diag @ Q_t[t] @ inv_sqrt_diag

    # 1-step-ahead forecast
    Q_next = (1 - a_dcc - b_dcc) * Qbar + a_dcc * np.outer(std_resids[-1], std_resids[-1]) + b_dcc * Q_t[-1]
    inv_sqrt_diag_next = np.diag(1.0 / np.sqrt(np.diag(Q_next)))
    R_next = inv_sqrt_diag_next @ Q_next @ inv_sqrt_diag_next

    return {
        "sigma_next": sigma_next,
        "R_next": R_next,
        "std_resids": std_resids,
        "a_dcc": float(a_dcc),
        "b_dcc": float(b_dcc),
        "Qbar": Qbar,
        "R_history": R_t,
        "garch_methods": garch_methods,
    }


# Forward-looking alias — same function. Round 10 onward, prefer this name
# since it no longer implies a single estimator; the dispatcher inside picks
# arch MLE when available. Back-compat: existing imports of fit_dcc_garch_gmm
# continue to work.
fit_dcc_garch = fit_dcc_garch_gmm


# ──────────────────────────────────────────────────────────────────────────
# FHS simulation: bootstrap from std_resid + scale by conditional σ
# ──────────────────────────────────────────────────────────────────────────

def fhs_simulate(dcc_fit: dict, weights: np.ndarray,
                  n_sim: int = 10000, horizon: int = 1,
                  seed: int = 42) -> np.ndarray:
    """Filtered Historical Simulation of portfolio returns.

    ROUND 7 FIX (R7-4, HIGH — methodology integrity + multi-horizon math):

    (a) The previous body computed `L = np.linalg.cholesky(R_next)` and
        then NEVER USED it — dead code that implied the simulation was
        conditioned on the DCC forecast correlation R_next when it was
        not. The joint dependence in this implementation comes from the
        *empirical* joint draw (one historical day's residual vector is
        drawn whole, preserving that day's cross-sectional dependence —
        the standard FHS vector bootstrap of Barone-Adesi et al.).
        R_next remains available in the fit dict for diagnostics, but we
        no longer pretend it drives the simulation. The docstring claim
        "FHS with DCC-conditioned correlation structure" is corrected
        accordingly.

    (b) The previous multi-horizon path scaled a SINGLE day's joint
        residual by sqrt(horizon) — an instantaneous √t-scaling that
        ignores the compounding of sequentially drawn shocks. Standard
        multi-step FHS draws `horizon` joint residual vectors (with
        replacement) and compounds them:  r_h = sum_{s=1..h} sigma * z_s
        (additive log-return convention). For horizon == 1 the two are
        equal in distribution ONLY under iid — under the empirical
        bootstrap the sequential version correctly accumulates
        independent daily draws instead of repeating one day h times.

    (c) NaN guard: rows with non-finite residuals are dropped from the
        pool before bootstrapping so a single NaN column cannot poison
        the entire VaR (previously NaN propagated silently through
        `weights @ eps` into var/es = NaN).

    Args:
        dcc_fit:  dict from fit_dcc_garch_gmm
        weights:  portfolio weights (M,)
        n_sim:    number of simulations
        horizon:  forecast horizon in days
        seed:     RNG seed

    Returns:
        (n_sim,) array of simulated portfolio P&L at horizon.
    """
    rng = np.random.default_rng(seed)
    std_resids = np.asarray(dcc_fit["std_resids"], dtype=float)
    # R7-4(c): drop any row containing non-finite residuals
    _finite_rows = np.all(np.isfinite(std_resids), axis=1)
    if not np.all(_finite_rows):
        logger.warning(
            "[FHS-DCC] %d of %d residual rows contain non-finite values — "
            "excluded from the bootstrap pool.",
            int((~_finite_rows).sum()), std_resids.shape[0],
        )
        std_resids = std_resids[_finite_rows]
    N, M = std_resids.shape
    if M != len(weights):
        raise ValueError(f"M={M} mismatch with weights len={len(weights)}")
    if N < 10:
        raise ValueError(f"Residual pool too small for FHS bootstrap (N={N})")

    sigma = np.asarray(dcc_fit["sigma_next"], dtype=float).copy()

    sim_pl = np.zeros(n_sim)
    for s in range(n_sim):
        # R7-4(b): draw `horizon` joint residual vectors (preserving the
        # empirical cross-sectional dependence of each historical day)
        # and compound them additively.
        idx = rng.integers(0, N, size=int(max(1, horizon)))
        z_path = std_resids[idx]                      # (horizon, M)
        eps_path = sigma[None, :] * z_path            # per-day shocks
        sim_pl[s] = float(weights @ eps_path.sum(axis=0))

    return sim_pl


def fhs_var_es(dcc_fit: dict, weights: np.ndarray,
                alpha: float = 0.99, n_sim: int = 10000,
                horizon: int = 1, seed: int = 42) -> dict:
    """One-shot FHS VaR / ES computation.

    Returns:
        dict with 'var', 'es', 'alpha', 'simulations'
    """
    sim = fhs_simulate(dcc_fit, weights, n_sim=n_sim, horizon=horizon, seed=seed)
    # Losses are negative PL
    losses = -sim
    sorted_losses = np.sort(losses)[::-1]
    k = max(int(np.ceil((1 - alpha) * n_sim)), 1)
    var = float(sorted_losses[k - 1])
    es = float(np.mean(sorted_losses[:k]))
    return {
        "var": var,
        "es": es,
        "alpha": alpha,
        "horizon": horizon,
        "n_sim": n_sim,
    }


if __name__ == "__main__":
    # Smoke test: synthetic 5-asset DCC-GARCH simulation
    rng = np.random.default_rng(42)
    N, M = 1000, 5
    # Generate correlated GARCH returns
    eps_raw = rng.standard_normal((N, M))
    L = np.linalg.cholesky(np.array([[1, 0.5, 0.3, 0.2, 0.1],
                                      [0.5, 1, 0.4, 0.3, 0.2],
                                      [0.3, 0.4, 1, 0.5, 0.3],
                                      [0.2, 0.3, 0.5, 1, 0.4],
                                      [0.1, 0.2, 0.3, 0.4, 1]]))
    eps_corr = eps_raw @ L.T
    # Add GARCH vol scaling
    var = np.ones((N, M)) * 0.02 ** 2
    for t in range(1, N):
        for j in range(M):
            var[t, j] = 1e-5 + 0.1 * eps_corr[t - 1, j] ** 2 + 0.88 * var[t - 1, j]
    eps = eps_corr * np.sqrt(var)
    R = pd.DataFrame(eps, columns=[f"S{j}" for j in range(M)])

    dcc = fit_dcc_garch_gmm(R)
    print(f"DCC fit: a={dcc['a_dcc']:.4f} b={dcc['b_dcc']:.4f}")
    print(f"Next-period σ: {dcc['sigma_next']}")
    print(f"Next-period correlation:")
    print(dcc['R_next'])

    w = np.array([0.2, 0.2, 0.2, 0.2, 0.2])
    res = fhs_var_es(dcc, w, alpha=0.99, n_sim=5000, horizon=1)
    print(f"\n99% FHS VaR (1-day): {res['var']:.4f}")
    print(f"99% FHS ES  (1-day): {res['es']:.4f}")
