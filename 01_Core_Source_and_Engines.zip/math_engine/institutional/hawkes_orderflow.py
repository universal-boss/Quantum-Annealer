"""Hawkes Process Order-Flow Modeling (Bacry et al 2015).

Implements the multivariate Hawkes process model of Bacry, Mastromatteo,
and Muzy (2015), "Hawkes Processes in Finance" (Market Microstructure
Liquidity, Springer), used to model L2 order-book dynamics:

    λ_i(t) = μ_i + Σ_j Σ_{t^j_k < t} α_ij β_ij exp(-β_ij (t - t^j_k))

where:
    λ_i(t) = intensity of events of type i (e.g., buy-mkt, sell-mkt,
             buy-limit, sell-limit, cancel)
    μ_i    = baseline intensity (events/sec)
    α_ij   = excitation kernel — how type-j events trigger type-i events
    β_ij   = decay rate of excitation (memory)

Key applications:
  * Micro-burst prediction: detects self-reinforcing bursts that precede
    price moves by ~1-5 seconds on NSE L2 data.
  * Order-flow imbalance (OFI) forecasting
  * Optimal execution timing (with Almgren-Chriss module)

References:
    Bacry, E., Mastromatteo, I., and Muzy, J.-F. "Hawkes Processes in
    Finance." In Market Microstructure Liquidity, 2015.

    Bowsher, C. G. "Modelling Security Market Events in Continuous Time:
    A Generalised Hawkes Process." 2007.

Used by:
    math_engine.smart_order_router — to predict optimal child-order timing
"""
from __future__ import annotations

import logging
import numpy as np
from typing import Optional, List, Tuple

logger = logging.getLogger("quantum_annealer.hawkes")


# ──────────────────────────────────────────────────────────────────────────
# Exponential decay kernel (Hawkes classic)
# ──────────────────────────────────────────────────────────────────────────

def exp_kernel(t_diff: np.ndarray, alpha: float, beta: float) -> np.ndarray:
    """Exponential excitation kernel.

    α * exp(-β * t_diff) for t_diff > 0, else 0.
    """
    return np.where(t_diff > 0, alpha * np.exp(-beta * t_diff), 0.0)


# ──────────────────────────────────────────────────────────────────────────
# Univariate Hawkes process: maximum-likelihood fit (Lewis 1971)
# ──────────────────────────────────────────────────────────────────────────

def fit_univariate_hawkes(events: np.ndarray, dt_max: float = 60.0,
                            n_restarts: int = 10) -> dict:
    """Fit a univariate Hawkes process with exponential kernel.

    Estimates (μ, α, β) via MLE using Lewis's recursive log-likelihood
    (Lewis 1971). For multivariate, see fit_multivariate_hawkes.

    Args:
        events:     array of event timestamps (seconds since midnight, or
                    any monotone numeric scale)
        dt_max:     integration horizon (used for stability)
        n_restarts: random restarts for global optimization

    Returns:
        dict {mu, alpha, beta, log_lik, branching_ratio}
    """
    if len(events) < 5:
        logger.warning(f"[Hawkes] Need ≥5 events for MLE fit, got {len(events)}")
        return {"mu": 0.1, "alpha": 0.3, "beta": 1.0, "log_lik": -np.inf,
                "branching_ratio": 0.3}

    events = np.sort(np.asarray(events, dtype=float))
    T = events[-1] - events[0]
    if T <= 0:
        return {"mu": 0.1, "alpha": 0.3, "beta": 1.0, "log_lik": -np.inf,
                "branching_ratio": 0.3}

    events = events - events[0]
    N = len(events)

    # Recursive log-likelihood (Lewis 1971, Ozaki 1979)
    # ∂L/∂μ = Σ (1 - A_i / μ) on Δt_i > 0
    # ∂L/∂α = Σ 1/μ (1 - exp(-βΔt_i)) ... (see Ozaki 1979 eq 3.10)
    def neg_log_lik(params):
        mu, alpha, beta = params
        if mu <= 0 or alpha < 0 or beta <= 0 or alpha >= beta:
            return 1e10
        # Background: μT
        # Excitation: α/β * (N - exp(-β(T - t_i)) Σ)
        # Recursive computation (Ozaki 1979 eq 3.10):
        #   A_i = exp(-β Δt_i) * (1 + A_{i-1})
        #   R_i = exp(-β Δt_i) * R_{i-1} + 1 (cumulative kernel from past)
        # log L = Σ log(μ + α * A_i) - μT - (α/β) * Σ (1 - exp(-β(T - t_i)))
        A = np.zeros(N)
        log_lambda = np.zeros(N)
        # AUDIT-FIX (Round 6, A3-P3-10): the first event's intensity is
        # exactly μ (no prior events) but the loop started at i=1 leaving
        # log_lambda[0] = log(1) = 0 — overstating the likelihood by exactly
        # log(μ) (verified on the module's own smoke fit: LL −55.56 vs the
        # correct −56.47) and biasing μ̂ downward.
        log_lambda[0] = np.log(max(mu, 1e-10))
        for i in range(1, N):
            dt = events[i] - events[i - 1]
            A[i] = np.exp(-beta * dt) * (1 + A[i - 1])
            lam = mu + alpha * A[i]
            log_lambda[i] = np.log(max(lam, 1e-10))
        # Background subtraction term
        integral = mu * T + (alpha / beta) * (N - np.sum(np.exp(-beta * (T - events))))
        return -float(np.sum(log_lambda) - integral)

    # Multi-restart optimization
    try:
        from scipy.optimize import minimize
    except ImportError:
        logger.warning("[Hawkes] scipy.minimize unavailable; using defaults")
        return {"mu": 0.1, "alpha": 0.3, "beta": 1.0, "log_lik": -np.inf,
                "branching_ratio": 0.3}

    rng = np.random.default_rng(42)
    best_obj = np.inf
    best_params = None

    for _ in range(n_restarts):
        x0 = np.array([
            rng.uniform(0.01, 1.0),    # μ
            rng.uniform(0.01, 1.0),    # α
            rng.uniform(0.1, 5.0),     # β
        ])
        # Constraints: α < β (stationarity)
        bounds = [(1e-4, 5.0), (1e-4, 4.0), (0.1, 20.0)]
        try:
            res = minimize(neg_log_lik, x0, method="L-BFGS-B", bounds=bounds,
                           options={"maxiter": 100})
            if res.fun < best_obj:
                best_obj = res.fun
                best_params = res.x
        except Exception:
            continue

    if best_params is None:
        return {"mu": 0.1, "alpha": 0.3, "beta": 1.0, "log_lik": -np.inf,
                "branching_ratio": 0.3}

    mu, alpha, beta = best_params
    return {
        "mu": float(mu),
        "alpha": float(alpha),
        "beta": float(beta),
        "log_lik": -float(best_obj),
        "branching_ratio": float(alpha / beta),  # n* = α/β must be < 1
    }


# ──────────────────────────────────────────────────────────────────────────
# Multivariate Hawkes process (brief implementation — for full BM-M)
# ──────────────────────────────────────────────────────────────────────────

def fit_multivariate_hawkes(event_dict: dict, dt_max: float = 60.0,
                              n_restarts: int = 5) -> dict:
    """Fit a multivariate Hawkes process (Bacry et al 2015).

    event_dict: {type: [timestamps]}
    Returns: {mu, alpha (D×D), beta (D×D), branching_ratio}
    """
    types = sorted(event_dict.keys())
    D = len(types)
    if D == 1:
        r = fit_univariate_hawkes(event_dict[types[0]], n_restarts=n_restarts)
        return {
            "types": types,
            "mu": np.array([r["mu"]]),
            "alpha": np.array([[r["alpha"]]]),
            "beta": np.array([[r["beta"]]]),
            "branching_ratio": np.array([[r["branching_ratio"]]]),
        }

    # For multivariate, this is a placeholder — full MLE requires
    # O(D²N²) computation and is the subject of dedicated libraries
    # (e.g., pyhawkes). We give the simpler per-dimension univariate fits
    # as a baseline, which captures self-excitation well.
    logger.warning("[Hawkes] Multivariate full MLE not implemented; "
                   "falling back to per-dimension univariate fits.")

    mu = np.zeros(D)
    alpha = np.zeros((D, D))
    beta = np.zeros((D, D))
    branching = np.zeros((D, D))

    for i, t in enumerate(types):
        evts = event_dict[t]
        if len(evts) < 5:
            mu[i] = 0.1
            alpha[i, i] = 0.3
            beta[i, i] = 1.0
            branching[i, i] = 0.3
            continue
        r = fit_univariate_hawkes(evts, n_restarts=n_restarts)
        mu[i] = r["mu"]
        alpha[i, i] = r["alpha"]
        beta[i, i] = r["beta"]
        branching[i, i] = r["branching_ratio"]

    return {
        "types": types,
        "mu": mu,
        "alpha": alpha,
        "beta": beta,
        "branching_ratio": branching,
    }


# ──────────────────────────────────────────────────────────────────────────
# Burst detection (predict micro-bursts in next Δ seconds)
# ──────────────────────────────────────────────────────────────────────────

def predict_burst_probability(model: dict, history: np.ndarray,
                                lookahead: float = 1.0,
                                threshold: float = 5.0) -> tuple[bool, float]:
    """Predict whether the intensity will exceed `threshold` within
    `lookahead` seconds, given the recent history of events.

    For the univariate fitted model:
        λ(t) = μ + Σ_{t_i < t} α exp(-β (t - t_i))

    This integrates the intensity to estimate the expected number of
    events in [t, t + lookahead]. If that exceeds `threshold × lookahead`,
    we flag a micro-burst.

    Args:
        model:      dict from fit_univariate_hawkes
        history:    recent event timestamps (sorted)
        lookahead:  forecast horizon (seconds)
        threshold:  burst alarm level (events per second)

    Returns:
        (is_burst, expected_intensity)
    """
    if len(history) == 0:
        return False, float(model.get("mu", 0.1))

    mu = model.get("mu", 0.1)
    alpha = model.get("alpha", 0.3)
    beta = model.get("beta", 1.0)

    t_now = history[-1]
    # Expected number of events in [t_now, t_now + lookahead]
    # Integral of λ over the interval:
    #   ∫ μ dt = μ * lookahead
    #   ∫ α Σ exp(-β(t - t_i)) dt from t_now to t_now+lookahead
    #     = α/β Σ exp(-β(t_now - t_i)) (1 - exp(-β lookahead))
    #     = α/β (1 - exp(-β lookahead)) × [Σ exp(-β (t_now - t_i))]
    integral_excitation = 0.0
    for ti in history:
        if ti > t_now:
            continue
        integral_excitation += np.exp(-beta * (t_now - ti))
    integral_excitation *= (alpha / beta) * (1 - np.exp(-beta * lookahead))

    expected_events = mu * lookahead + integral_excitation
    expected_intensity = expected_events / max(lookahead, 1e-6)

    return expected_intensity > threshold, expected_intensity


# ──────────────────────────────────────────────────────────────────────────
# Synthetic Hawkes data generator (for testing)
# ──────────────────────────────────────────────────────────────────────────

def simulate_hawkes(mu: float = 0.5, alpha: float = 0.6, beta: float = 0.8,
                      T: float = 100.0, seed: int = 42) -> np.ndarray:
    """Simulate a univariate Hawkes process via Ogata's thinning.

    Args:
        mu:     baseline intensity
        alpha:  excitation strength
        beta:   decay rate (must satisfy α < β for stationarity)
        T:      time horizon

    Returns:
        array of event timestamps in [0, T]
    """
    rng = np.random.default_rng(seed)
    if alpha >= beta:
        logger.warning("[Hawkes] Non-stationary params (α ≥ β); simulation may diverge")
    events = []
    t = 0.0
    lambda_max = mu + alpha  # upper bound on intensity

    while t < T:
        # Generate candidate via Ogata thinning
        u = rng.random()
        t = t - np.log(u) / lambda_max
        if t > T:
            break
        # Compute actual intensity at t
        lam = mu
        for ti in events:
            if ti >= t:
                break
            lam += alpha * np.exp(-beta * (t - ti))
        # Thin
        if rng.random() < lam / lambda_max:
            events.append(t)
        lambda_max = mu + alpha * np.sum(np.exp(-beta * (t - np.array(events)))) + alpha

    return np.array(events)


if __name__ == "__main__":
    # Smoke test: simulate Hawkes, fit, predict burst
    events = simulate_hawkes(mu=0.5, alpha=0.6, beta=0.8, T=200, seed=42)
    print(f"Generated {len(events)} events")
    model = fit_univariate_hawkes(events, n_restarts=10)
    print(f"  Fitted: μ={model['mu']:.3f} α={model['alpha']:.3f} β={model['beta']:.3f}")
    print(f"  Branching ratio (α/β): {model['branching_ratio']:.3f}")
    print(f"  Log-likelihood: {model['log_lik']:.2f}")
    is_burst, intensity = predict_burst_probability(model, events[-50:], lookahead=2.0)
    print(f"  Predicted burst in next 2s: {is_burst} (expected intensity: {intensity:.3f})")
