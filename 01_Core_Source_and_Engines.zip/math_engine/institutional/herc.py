"""Hierarchical Equal Risk Contribution (HERC) portfolio optimization.

Implements Raffinot (2017), "Hierarchical Clustering-Based Asset Allocation"
(Journal of Portfolio Management, vol 44, no 2, pp. 89-99).

The HERC algorithm extends Hierarchical Risk Parity (HRP, López de Prado
2016) by:
  1. Building a dendrogram via agglomerative clustering on a
     matrix-ordered distance matrix (derived from correlation).
  2. Traversing the tree top-down and assigning weights inversely
     proportional to cluster risk at every level.
  3. Recursively subdividing each cluster's allocation between its
     children proportional to inverse cluster variance.

This produces a robust, well-diversified portfolio that:
  - Survives correlation breakdowns in stress regimes (key advantage
    over inverse-vol risk parity)
  - Has no matrix inversion → no numerical instability
  - O(N²) compute, scaling to 1000+ assets

References:
    Raffinot, Thomas. "Hierarchical Clustering-Based Asset Allocation."
    Journal of Portfolio Management, 44(2):89-99, 2017.

    López de Prado, Marcos. "Building Diversified Portfolios that
    Outperform Out-of-Sample." Journal of Portfolio Management,
    42(4):59-69, 2016. (HRP, the predecessor algorithm)

Used by:
    optimizer_risk.apply_herc_weights (alternative to inverse-vol
    risk parity for portfolio construction step)
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Optional

logger = logging.getLogger("quantum_annealer.herc")


# ──────────────────────────────────────────────────────────────────────────
# Step 1: distance matrix from correlation
# ──────────────────────────────────────────────────────────────────────────

def correlation_distance(corr: np.ndarray | pd.DataFrame) -> np.ndarray:
    """Compute the distance matrix from correlation.

    Per López de Prado (2016):
        d_ij = sqrt(0.5 * (1 - ρ_ij))

    This gives a proper metric on the space of return time series:
        d ≥ 0, d_ii = 0, d_ij = d_ji, triangle inequality holds.
    """
    if isinstance(corr, pd.DataFrame):
        corr = corr.values
    return np.sqrt(np.clip(0.5 * (1 - corr), 0, 1))


# ──────────────────────────────────────────────────────────────────────────
# Step 2: agglomerative clustering with Ward linkage
# ──────────────────────────────────────────────────────────────────────────

def hierarchical_clusters(corr: np.ndarray | pd.DataFrame,
                          method: str = "ward") -> dict:
    """Build the hierarchical clustering dendrogram.

    Args:
        corr:   correlation matrix (M, M)
        method: linkage method ('ward', 'single', 'complete', 'average')

    Returns:
        dict with 'linkage' (scipy linkage matrix), 'labels' (cluster ids
        for each leaf), and 'ordered_corr' (the quasi-diagonalized
        correlation matrix).
    """
    from scipy.cluster.hierarchy import linkage, to_tree, leaves_list
    from scipy.spatial.distance import squareform

    if isinstance(corr, pd.DataFrame):
        tickers = list(corr.index)
        corr_arr = corr.values
    else:
        tickers = [f"S{i}" for i in range(len(corr))]
        corr_arr = corr

    dist = correlation_distance(corr_arr)
    # Ensure zero diagonal and symmetry
    np.fill_diagonal(dist, 0)
    dist = (dist + dist.T) / 2

    condensed = squareform(dist, checks=False)
    Z = linkage(condensed, method=method)

    # Quasi-diagonalization: reorder assets by dendrogram leaves
    order = leaves_list(Z)
    ordered_corr = corr_arr[np.ix_(order, order)]
    ordered_tickers = [tickers[i] for i in order]

    return {
        "linkage": Z,
        "order": order.tolist(),
        "ordered_corr": ordered_corr,
        "ordered_tickers": ordered_tickers,
        "tickers": tickers,
    }


# ──────────────────────────────────────────────────────────────────────────
# Step 3: recursive bisection (Raffinot's HERC weight assignment)
# ──────────────────────────────────────────────────────────────────────────

def _cluster_variance(cov: np.ndarray, idx: list[int]) -> float:
    """Compute sub-cluster variance for indices in idx."""
    sub = cov[np.ix_(idx, idx)]
    n = len(idx)
    w = np.ones(n) / n
    return float(w @ sub @ w)


def _recursive_bisection(cov: np.ndarray, order: list[int],
                         weights: np.ndarray) -> np.ndarray:
    """Top-down recursive weight assignment (López de Prado HRP step 3)."""
    n = len(order)
    weights = weights.copy()

    clusters = [list(range(n))]  # start with all indices

    while clusters:
        new_clusters = []
        for cluster in clusters:
            if len(cluster) <= 1:
                continue
            # Split the cluster in half along the dendrogram order
            mid = len(cluster) // 2
            left = cluster[:mid]
            right = cluster[mid:]

            # Compute sub-cluster variances
            # AUDIT-FIX (Round 6, A3-P2-3): `left`/`right` are POSITIONS in the
            # dendrogram-ordered list, but _cluster_variance used them directly
            # as ASSET indices into cov — scrambling which assets' variances
            # fed each split whenever order != identity (up to 0.035 absolute
            # weight error on a 6-asset repro; the produced portfolio was not
            # Raffinot HERC). Map positions → asset indices via order[i],
            # mirroring the weight update below.
            var_l = _cluster_variance(cov, [order[i] for i in left])
            var_r = _cluster_variance(cov, [order[i] for i in right])
            alpha = 1.0 - var_l / (var_l + var_r)

            # Allocate based on inverse-variance
            for i in left:
                weights[order[i]] *= alpha
            for i in right:
                weights[order[i]] *= (1 - alpha)

            new_clusters.extend([left, right])
        clusters = new_clusters
    return weights


def herc_weights(cov: np.ndarray | pd.DataFrame,
                 corr: np.ndarray | pd.DataFrame | None = None,
                 method: str = "ward") -> np.ndarray:
    """Compute HERC portfolio weights.

    Args:
        cov:    covariance matrix (M, M)
        corr:   correlation matrix (M, M). If None, derived from cov via
                cov → correlation. (When you already have a clean
                correlation estimate — e.g., from Ledoit-Wolf shrinkage
                — pass it explicitly.)
        method: scipy linkage method ('ward', 'single', 'complete',
                'average') — forwarded to the dendrogram construction.

    Returns:
        weights (M,) that sum to 1, diversified by hierarchical clusters.
    """
    if isinstance(cov, pd.DataFrame):
        tickers = list(cov.index)
        cov_arr = cov.values
    else:
        tickers = [f"S{i}" for i in range(len(cov))]
        cov_arr = cov

    if corr is None:
        # Derive correlation from covariance
        std = np.sqrt(np.diag(cov_arr))
        std_safe = np.where(std > 0, std, 1)
        corr_arr = cov_arr / np.outer(std_safe, std_safe)
        np.fill_diagonal(corr_arr, 1.0)
    else:
        corr_arr = corr.values if isinstance(corr, pd.DataFrame) else corr

    # Step 1+2: hierarchical clustering
    cluster_info = hierarchical_clusters(corr_arr, method=method)
    order = cluster_info["order"]

    # Step 3: recursive bisection
    weights = np.ones(len(tickers))
    weights = _recursive_bisection(cov_arr, order, weights)

    # Normalize
    s = weights.sum()
    if s > 1e-9:
        weights = weights / s
    return weights


# ──────────────────────────────────────────────────────────────────────────
# Helper: end-to-end portfolio builder
# ──────────────────────────────────────────────────────────────────────────

def build_herc_portfolio(returns: pd.DataFrame, method: str = "ward") -> dict:
    """One-shot HERC portfolio construction from returns."""
    cov = returns.cov().values
    corr = returns.corr().values
    # AUDIT-FIX (Round 13, MATH-9): `method` was accepted, echoed in the
    # result and in the log line ("weights computed via {method} linkage")
    # but NEVER forwarded — every run silently used 'ward'. The parameter
    # now controls the actual linkage.
    w = herc_weights(cov, corr, method=method)
    return {
        "tickers": list(returns.columns),
        "weights": w.tolist(),
        "method": method,
        "cluster_order": hierarchical_clusters(corr, method=method)["order"],
    }


if __name__ == "__main__":
    rng = np.random.default_rng(42)
    N, M = 250, 10
    R = pd.DataFrame(rng.normal(0.0005, 0.015, size=(N, M)),
                      columns=[f"S{i}" for i in range(M)])
    res = build_herc_portfolio(R)
    print(f"Tickers: {res['tickers']}")
    print(f"Weights: {[f'{w:.4f}' for w in res['weights']]}")
    print(f"Sum: {sum(res['weights']):.4f}")
    print(f"Cluster order: {res['cluster_order']}")
