"""math_engine/institutional/ipo_microstructure.py
=================================================
Institutional Microstructure Mathematics for 1-2 Year Listed Indian Equities:
  1. SEBI Anchor Investor Lock-in Expiry Cliff Mechanics
  2. Non-Promoter Free-Float Velocity Ratio
  3. Multi-Week Base Tightness Geometry

Regulatory & Market Context:
  - SEBI (Issue of Capital and Disclosure Requirements) Regulations:
    * 50% of Anchor Investor allocation is locked in for 30 days.
    * Remaining 50% of Anchor allocation is locked in for 90 days.
  - Institutional Multibaggers in India consistently demonstrate price resilience
    and high delivery absorption immediately during and following these lock-in expirations.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Optional, Tuple, Union
import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


def compute_sebi_anchor_lockin_impact(
    listing_age_days: int,
    recent_ohlcv: pd.DataFrame,
    free_float_shares: float,
) -> Dict[str, Union[float, str, bool]]:
    """Compute SEBI Anchor Lock-in Expiry proximity, supply shock risk, and absorption efficiency.

    Tracks:
      - 30-Day Lock-in Cliff: First 50% of anchor allocation unlocked.
      - 90-Day Lock-in Cliff: Remaining 50% of anchor allocation unlocked.
      - Post-Lockin Absorption: If listing age is between 365 and 730 days (1-2 years),
        measures whether the stock has structurally absorbed all anchor/pre-IPO supply
        and transitioned into institutional Stage-2 accumulation.

    Returns:
        Dict with lockin_status, absorption_score [0..100], and supply_cliff_risk [0..1].
    """
    age = int(listing_age_days)
    cols = {c.lower(): c for c in recent_ohlcv.columns} if recent_ohlcv is not None else {}
    closes = recent_ohlcv[cols["close"]].to_numpy(dtype=float) if "close" in cols else np.array([])
    volumes = recent_ohlcv[cols.get("volume", "close")].to_numpy(dtype=float) if "volume" in cols else np.array([])

    # If within 1-2 year window (365 to 730 days)
    if 365 <= age <= 730:
        # All anchor lock-in cliffs (30d and 90d) are long past.
        # Now evaluate secondary institutional supply absorption:
        # 1. Has price held above the 100-day or 200-day moving average?
        ma50 = np.mean(closes[-50:]) if len(closes) >= 50 else closes[-1] if len(closes) > 0 else 1.0
        ma150 = np.mean(closes[-150:]) if len(closes) >= 150 else ma50
        curr_price = closes[-1] if len(closes) > 0 else 1.0

        trend_resilience = 1.0 if (curr_price >= ma50 >= ma150) else 0.5 if (curr_price >= ma50) else 0.2

        # 2. Volume absorption: Ratio of up-day volume to down-day volume over trailing 40 bars
        if len(closes) >= 40:
            rets = np.diff(closes[-40:])
            vols = volumes[-39:]
            up_vol = np.sum(vols[rets > 0])
            dn_vol = np.sum(vols[rets < 0]) + 1e-9
            up_dn_ratio = float(up_vol / dn_vol)
        else:
            up_dn_ratio = 1.0

        # Score in [0..100]
        absorption_score = 50.0 + (30.0 * (trend_resilience - 0.5)) + (20.0 * np.clip(up_dn_ratio - 1.0, -0.5, 0.5))
        absorption_score = float(np.clip(absorption_score, 10.0, 99.0))

        return {
            "lockin_status": "FULLY_UNLOCKED_MATURE_BASE",
            "listing_age_days": age,
            "absorption_score": round(absorption_score, 2),
            "supply_cliff_risk": 0.05,
            "is_in_sweet_spot": True,
        }

    elif age < 365:
        # Young IPO (< 1 year): check proximity to 30d or 90d cliffs
        dist_30 = abs(age - 30)
        dist_90 = abs(age - 90)
        near_cliff = (dist_30 <= 5) or (dist_90 <= 7)

        return {
            "lockin_status": "HIGH_CLIFF_VOLATILITY" if near_cliff else "EARLY_SEASONING",
            "listing_age_days": age,
            "absorption_score": 35.0,
            "supply_cliff_risk": 0.85 if near_cliff else 0.40,
            "is_in_sweet_spot": False,
        }

    else:
        # > 730 days (older than 2 years)
        return {
            "lockin_status": "POST_IPO_MATURE",
            "listing_age_days": age,
            "absorption_score": 60.0,
            "supply_cliff_risk": 0.0,
            "is_in_sweet_spot": False,
        }


def compute_free_float_velocity(
    avg_daily_delivery_volume: float,
    free_float_shares: float,
) -> float:
    """Compute Free-Float Velocity Ratio.

    Velocity = Average Daily Delivery Volume / Non-Promoter Free-Float Shares.
    In small/mid-cap Indian equities, a delivery velocity > 0.015 (1.5% of tradeable float
    churned into delivery daily) signals aggressive institutional accumulation corners.

    Returns:
        float: Normalized float velocity score [0.0..1.0].
    """
    if free_float_shares <= 0 or avg_daily_delivery_volume <= 0:
        return None  # Missing or zero inputs \u2014 Float Velocity Ratio cannot be computed

    raw_velocity = float(avg_daily_delivery_volume / (free_float_shares + 1e-9))
    # Benchmark: 0.005 (0.5%/day) is normal; 0.020+ (2.0%/day) is extreme accumulation
    normalized = float(np.clip(raw_velocity / 0.025, 0.05, 0.99))
    return round(normalized, 4)


def compute_base_tightness_geometry(
    ohlcv_df: pd.DataFrame,
    consolidation_bars: int = 20,
) -> Dict[str, Union[float, bool]]:
    """Compute base tightness percentage for Stage-1 / Stage-2 bases.

    Measures highest high to lowest low spread over the consolidation window.
    Institutional pivot points require tightness spread <= 8% to 12%.

    Returns:
        Dict with 'tightness_pct', 'is_tight_base' (bool), and 'pivot_price'.
    """
    if ohlcv_df is None or len(ohlcv_df) < consolidation_bars:
        return {"tightness_pct": 25.0, "is_tight_base": False, "pivot_price": 0.0}

    cols = {c.lower(): c for c in ohlcv_df.columns}
    highs = ohlcv_df[cols.get("high", "close")].to_numpy(dtype=float)[-consolidation_bars:]
    lows = ohlcv_df[cols.get("low", "close")].to_numpy(dtype=float)[-consolidation_bars:]
    closes = ohlcv_df[cols["close"]].to_numpy(dtype=float)

    hh = np.max(highs)
    ll = np.min(lows)
    spread_pct = float(((hh - ll) / (hh + 1e-9)) * 100.0)

    is_tight = spread_pct <= 10.0
    pivot_price = float(hh)

    return {
        "tightness_pct": round(spread_pct, 2),
        "is_tight_base": is_tight,
        "pivot_price": round(pivot_price, 2),
    }
