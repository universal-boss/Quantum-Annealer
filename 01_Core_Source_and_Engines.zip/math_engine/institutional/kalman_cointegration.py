"""Kalman-Filtered Cointegration (Elliott, van der Putten & Tabak 2005).

Implements the time-varying cointegration model of Elliott et al. (2005),
"On the Robustness of Cointegration-Based Pairs Trading Strategies"
(Quantitative Finance, 5(5):449-460).

The standard Engle-Granger (1987) cointegration test:
    y_t = α + β x_t + ε_t

estimates a single static β via OLS. In real markets, β drifts over
time as macro regimes change — OLS estimates become stale and
spread-mean-reversion strategies break.

Elliott et al. model β as a latent state-space variable:

    State:        β_{t+1} = β_t + w_t,         w_t ~ N(0, Q)
    Observation: y_t    = α_t + β_t x_t + ε_t, ε_t ~ N(0, R)

Then run a Kalman filter to recursively estimate β_t at each time-step.
The smoothed β sequence gives a robust, time-varying hedge ratio that
significantly outperforms OLS in walk-forward backtests.

References:
    Elliott, R. J., van der Putten, S., and Tabak, G. "On the Robustness
    of Cointegration-Based Pairs Trading Strategies." Quantitative
    Finance, 5(5):449-460, 2005.

    Engle, R. F., and Granger, C. W. J. "Cointegration and Error
    Correction: Representation, Estimation, and Testing."
    Econometrica, 55(2):251-276, 1987.

Used by:
    optimizer_risk.detect_cointegrated_pairs — to replace the existing
    OLS-based static cointegration with time-varying Kalman estimate.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Optional, Tuple

logger = logging.getLogger("quantum_annealer.kalman_coint")


# ──────────────────────────────────────────────────────────────────────────
# Kalman filter for time-varying β
# ──────────────────────────────────────────────────────────────────────────

class KalmanCointegration:
    """State-space Kalman filter for time-varying hedge ratio β.

    State:  β_t ∈ R (constant walk: β_{t+1} = β_t + w_t)
    Obs:    y_t = β_t x_t + ε_t

    Optionally we include an intercept α that follows its own random walk.

    The state vector is [α, β] and the state transition is identity.
    The observation matrix is [1, x_t].
    """

    def __init__(self, Q: float = 1e-5, R: float = 1e-4,
                 init_alpha: float = 0.0, init_beta: float = 1.0,
                 init_P: float = 1e3):
        """
        Args:
            Q:           process noise covariance (per element)
            R:           observation noise covariance
            init_alpha:  initial intercept
            init_beta:   initial β
            init_P:      initial state covariance
        """
        self.Q = Q
        self.R = R
        self.state = np.array([init_alpha, init_beta], dtype=float)
        self.P = np.eye(2) * init_P

    def update(self, x_t: float, y_t: float):
        """One Kalman-update step.

        Args:
            x_t:  regressor value at time t
            y_t:  observation at time t
        """
        # Predict step: state unchanged (random walk), P = P + Q
        self.P = self.P + self.Q * np.eye(2)
        # Innovation / residual
        H = np.array([1.0, x_t])
        y_hat = float(H @ self.state)
        innovation = y_t - y_hat
        # Innovation covariance
        S = float(H @ self.P @ H.T) + self.R
        if S <= 1e-12:
            return
        # Kalman gain
        K = (self.P @ H.T) / S
        # State update
        self.state = self.state + K * innovation
        # Covariance update (Joseph form for stability)
        I_KH = np.eye(2) - np.outer(K, H)
        self.P = I_KH @ self.P @ I_KH.T + self.R * np.outer(K, K)

    def filter(self, x: np.ndarray | pd.Series, y: np.ndarray | pd.Series) -> pd.DataFrame:
        """Run the Kalman filter on the full series.

        Returns:
            DataFrame with columns: alpha_t, beta_t, spread_t, residual_t
        """
        if isinstance(x, pd.Series):
            x_arr = x.values
            idx = x.index
        else:
            x_arr = np.asarray(x)
            idx = pd.RangeIndex(len(x_arr))

        if isinstance(y, pd.Series):
            y_arr = y.values
        else:
            y_arr = np.asarray(y)

        n = len(x_arr)
        alpha = np.zeros(n)
        beta = np.zeros(n)
        spread = np.zeros(n)
        resid = np.zeros(n)

        for t in range(n):
            self.update(x_arr[t], y_arr[t])
            alpha[t] = self.state[0]
            beta[t] = self.state[1]
            spread[t] = y_arr[t] - (alpha[t] + beta[t] * x_arr[t])
            # Residual innovation (standardized)
            H = np.array([1.0, x_arr[t]])
            S = float(H @ self.P @ H.T) + self.R
            resid[t] = (y_arr[t] - (alpha[t] + beta[t] * x_arr[t])) / np.sqrt(max(S, 1e-12))

        return pd.DataFrame({
            "alpha_t": alpha,
            "beta_t": beta,
            "spread_t": spread,
            "residual_t": resid,
        }, index=idx)


# ──────────────────────────────────────────────────────────────────────────
# Cointegration detection with Kalman hedge ratio
# ──────────────────────────────────────────────────────────────────────────

def detect_kalman_cointegration(x: pd.Series, y: pd.Series,
                                  Q: float = 1e-5, R: float = 1e-4,
                                  max_lag: int = 1,
                                  min_beta_stability: float = 0.7) -> dict:
    """Detect cointegration between two price series using Kalman-filtered β.

    Tests:
        1. Run Kalman filter → time-varying β_t
        2. Check β_t stability: ratio std(β_t) / mean(β_t) below threshold
        3. ADF test on residuals: p-value < 0.05 indicates stationarity
        4. Half-life of mean reversion (Ornstein-Uhlenbeck fit)

    Args:
        x:                       price series 1
        y:                       price series 2
        Q:                       process noise
        R:                       observation noise
        max_lag:                 ADF max lag
        min_beta_stability:      minimum stability ratio (lower = more stable)

    Returns:
        dict with 'cointegrated' (bool), 'beta_t' (Series), 'adf_pvalue',
        'half_life_days', 'beta_mean', 'beta_std'
    """
    from statsmodels.tsa.stattools import adfuller
    x_clean = x.dropna()
    y_clean = y.dropna()
    common_idx = x_clean.index.intersection(y_clean.index)
    if len(common_idx) < 60:
        return {"cointegrated": False, "reason": "insufficient_overlap"}
    x_use = x_clean.loc[common_idx]
    y_use = y_clean.loc[common_idx]

    kf = KalmanCointegration(Q=Q, R=R)
    result = kf.filter(x_use, y_use)

    beta_t = result["beta_t"]
    spread_t = result["spread_t"]

    # β stability
    beta_mean = float(beta_t.mean())
    beta_std = float(beta_t.std())
    stability = beta_std / max(abs(beta_mean), 1e-6)

    # ADF on residuals
    try:
        adf_stat, adf_p, *_ = adfuller(spread_t.dropna(), maxlag=max_lag)
    except Exception as e:
        logger.warning(f"[KalmanCoint] ADF failed: {e}")
        adf_stat = adf_p = float("nan")

    # Half-life via OU regression: Δs_t = -λ s_{t-1} + η_t → HL = ln(2)/λ
    try:
        s_lag = spread_t.shift(1).dropna()
        ds = spread_t.diff().dropna()
        common = s_lag.index.intersection(ds.index)
        if len(common) > 30:
            x_reg = s_lag.loc[common].values
            y_reg = ds.loc[common].values
            coef = np.polyfit(x_reg, y_reg, 1)[0]
            if coef < 0:
                half_life = float(np.log(2) / -coef)
            else:
                half_life = float("inf")
        else:
            half_life = float("inf")
    except Exception:
        half_life = float("inf")

    # ROUND 7 FIX (R7-1, HIGH): the previous comparison
    #   `stability < 1.0 / min_beta_stability`
    # inverted the threshold semantics. `stability` is defined as
    # std(beta_t)/|mean(beta_t)| — LOWER is more stable. With the default
    # min_beta_stability=0.7 the inverted form required only
    # stability < 1/0.7 = 1.43, i.e. it admitted hedge ratios whose
    # Kalman-filtered beta varied by up to ±143% of its mean — nearly
    # no filter at all. Worse, the parameter direction was REVERSED:
    # passing a stricter min_beta_stability (e.g. 0.5) LOOSENED the
    # gate (1/0.5 = 2.0), while passing a looser 2.0 TIGHTENED it (0.5).
    # The correct semantics per the docstring ("minimum beta-stability
    # in [0,1]" — i.e. the stability ratio must be at most this value):
    #   cointegrated requires stability <= min_beta_stability.
    # The wrapper (optimizer_risk_institutional.detect_cointegrated_pairs)
    # passes stability_threshold=0.70 and logs "beta-stability >= 0.70";
    # with this fix that log line is finally truthful.
    _stability_limit = float(min_beta_stability) if (min_beta_stability and min_beta_stability > 0) else 1.0

    cointegrated = (
        adf_p < 0.05
        and stability <= _stability_limit  # R7-1: direct comparison, correct direction
        and 0 < half_life < 60
    )

    return {
        "cointegrated": bool(cointegrated),
        "beta_t": beta_t,
        "spread_t": spread_t,
        "beta_mean": beta_mean,
        "beta_std": beta_std,
        "beta_stability": stability,
        "adf_statistic": float(adf_stat),
        "adf_pvalue": float(adf_p),
        "half_life_days": half_life,
    }


# ──────────────────────────────────────────────────────────────────────────
# Convenience: build a backtest signal from the Kalman-filtered spread
# ──────────────────────────────────────────────────────────────────────────

def kalman_pair_signal(x: pd.Series, y: pd.Series,
                       entry_z: float = 2.0,
                       exit_z: float = 0.5,
                       stop_z: float = 5.0,
                       Q: float = 1e-5, R: float = 1e-4) -> pd.DataFrame:
    """Generate pair-trade signals from Kalman-filtered spread.

    Signal rules:
        z_t = (spread_t - rolling_mean) / rolling_std

        Entry long y - beta*x (when z > entry_z)
        Exit when |z| < exit_z
        Stop when |z| > stop_z

    Args:
        x, y:        price series
        entry_z:     z-score threshold for entry
        exit_z:      z-score threshold for exit (close at mean reversion)
        stop_z:      z-score threshold for stop-loss
        Q, R:        Kalman parameters
    """
    res = detect_kalman_cointegration(x, y, Q=Q, R=R)
    if not res["cointegrated"]:
        return pd.DataFrame({"signal": [0] * len(x)}, index=x.index)

    spread = res["spread_t"]
    # Rolling z-score (use a 60-day rolling window)
    rolling_mean = spread.rolling(60, min_periods=20).mean()
    rolling_std = spread.rolling(60, min_periods=20).std()
    z = (spread - rolling_mean) / rolling_std.replace(0, np.nan)
    z = z.fillna(0)

    signal = pd.Series(0, index=z.index)
    position = 0
    for i, zi in enumerate(z):
        if pd.isna(zi):
            continue
        if position == 0:
            if zi > entry_z:
                position = -1  # short spread (short y, long x)
            elif zi < -entry_z:
                position = +1  # long spread (long y, short x)
        elif position == 1:
            # AUDIT-FIX (Round 13, MATH-3): the stop-loss comparisons were
            # MIRRORED. A long spread is entered at z < -entry_z (spread
            # cheap); it loses when z falls FURTHER below -stop_z, and mean
            # reverts to profit as z rises toward 0. The previous condition
            # `zi > stop_z` exits only after z crosses to the far PROFIT
            # extreme (past +stop), and `zi < -stop_z` (the actual loss
            # side) never closed the position — losing trades were never
            # stopped. Correct: stop long-spread at z < -stop_z; stop
            # short-spread (entered z > +entry_z) at z > +stop_z.
            if abs(zi) < exit_z or zi < -stop_z:
                position = 0
        elif position == -1:
            if abs(zi) < exit_z or zi > stop_z:
                position = 0
        signal.iloc[i] = position

    return pd.DataFrame({
        "signal": signal,
        "z_score": z,
        "spread": spread,
        "beta_t": res["beta_t"],
    }, index=z.index)


if __name__ == "__main__":
    # Smoke test: synthetic cointegrated pair with time-varying β
    rng = np.random.default_rng(42)
    n = 500
    dates = pd.bdate_range("2024-01-01", periods=n)
    x = pd.Series(np.cumsum(rng.normal(0, 1, n)) + 100, index=dates)
    beta_true = pd.Series(1.5 + 0.5 * np.sin(np.arange(n) / 50), index=dates)
    alpha_true = pd.Series(0.5 + 0.1 * np.sin(np.arange(n) / 80), index=dates)
    eps = rng.normal(0, 0.5, n)
    y = pd.Series(alpha_true.values + beta_true.values * x.values + eps, index=dates)

    res = detect_kalman_cointegration(x, y)
    print(f"Cointegrated: {res['cointegrated']}")
    print(f"Beta mean: {res['beta_mean']:.3f} (true ~1.5)")
    print(f"Beta std: {res['beta_std']:.3f}")
    print(f"ADF p-value: {res['adf_pvalue']:.4f}")
    print(f"Half-life: {res['half_life_days']:.1f} days")
