"""Institutional Kelly Betting — estimation-error aware, drawdown-capped.

Implements the position-sizing stack recommended for institutional
deployment, drawing on:

  * Kelly (1956); Thorp (2006), "The Kelly Criterion in Blackjack, Sports
    Betting, and the Stock Market."
  * López de Prado (2015/2016), "The Deflated Sharpe Ratio" and
    "Optimal Betting as a Function of the Cross-Section of Volatility" —
    tying the deployable Kelly fraction to the STATISTICAL SIGNIFICANCE of
    the estimated edge, not just its point estimate.
  * Maier-Paape & Vu (2018) re-optimization of fractional Kelly under
    drawdown constraints (first-passage approximation).

The full stack (`kelly_position_size`):

  1. continuous_kelly            f* = (mu - r) / sigma^2 (univariate) or
                                 w* = Sigma^-1 (mu - r) (multi-asset)
  2. confidence scaling          multiply by the Deflated-Sharpe confidence
                                 that the edge is real (never > 1)
  3. drawdown cap                largest f whose (1-alpha) worst drawdown
                                 stays <= dd_max (first-passage bound)
  4. vol targeting               rescale to the realized/target vol ratio
  5. fractional overlay          final conservative fraction (default 0.25)

Design rules (institutional honesty):
  * Every stage DEGRADES, never invents: negative-edge inputs give f = 0.
  * Estimation inputs (mu, sigma) with insufficient history shrink the
    fraction toward zero, with an explicit `n_obs` diagnostic.
  * All outputs carry provenance (which caps bound, sample size).
"""
from __future__ import annotations

import logging
import math
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

logger = logging.getLogger("quantum_annealer.kelly")

__all__ = [
    "continuous_kelly",
    "multi_asset_kelly",
    "deflated_confidence",
    "drawdown_capped_kelly",
    "vol_target_scale",
    "kelly_position_size",
    "kelly_stack_report",
]

# Safety rail for any single-asset Kelly output (institutional prudence:
# even a monster edge cannot justify > 100% of capital in one name).
_MAX_LEVERAGE = 1.0


def continuous_kelly(
    returns: Optional[pd.Series] = None,
    mu: Optional[float] = None,
    sigma: Optional[float] = None,
    risk_free: float = 0.0,
    periods_per_year: int = 252,
) -> Optional[float]:
    """Univariate continuous-time Kelly fraction: f* = (mu - r) / sigma^2.

    Accepts either a return series or pre-computed (mu, sigma) ANNUALIZED
    inputs. Returns None when inputs are insufficient (never a guess).
    """
    if returns is not None:
        r = pd.Series(returns).astype(float).dropna().values
        if len(r) < 20:
            return None
        mu = float(np.mean(r) * periods_per_year)
        sigma = float(np.std(r, ddof=1) * math.sqrt(periods_per_year))
    if mu is None or sigma is None:
        return None
    if not (np.isfinite(mu) and np.isfinite(sigma)) or sigma <= 0:
        return None
    f_star = (mu - risk_free) / (sigma * sigma)
    # Negative or zero edge → no position (never short the Kelly fraction).
    return float(max(0.0, f_star)) if f_star > 0 else 0.0


def multi_asset_kelly(
    mu: np.ndarray,
    cov: np.ndarray,
    risk_free: float = 0.0,
    long_only: bool = True,
) -> np.ndarray:
    """Multi-asset Kelly vector: w* = Sigma^-1 (mu - r), projected to the
    long-only simplex (Thorp 2006 §"the stock market", institutional form).

    Degenerate covariance (singular / non-PD) is shrunk toward diagonal by
    a Ledoit-style ridge with an explicit note in the caller's report; the
    function NEVER returns unbounded leverage.
    """
    mu = np.asarray(mu, dtype=float).ravel()
    cov = np.asarray(cov, dtype=float)
    n = mu.shape[0]
    if n == 0 or cov.shape != (n, n):
        return np.zeros(0)
    if not np.all(np.isfinite(mu)) or not np.all(np.isfinite(cov)):
        return np.zeros(n)

    # PD repair: eigenvalue floor shrinkage (0.05 * mean(diag) ridge)
    diag_mean = float(np.mean(np.diag(cov)))
    ridge = 0.0
    try:
        np.linalg.cholesky(cov + 1e-12 * np.eye(n))
    except np.linalg.LinAlgError:
        ridge = max(0.05 * diag_mean, 1e-8)
        cov = cov + ridge * np.eye(n)

    excess = mu - risk_free
    try:
        w = np.linalg.solve(cov, excess)
    except np.linalg.LinAlgError:
        return np.zeros(n)

    if long_only:
        w = np.maximum(w, 0.0)
    total = float(np.sum(np.abs(w)))
    if total > _MAX_LEVERAGE:
        w = w * (_MAX_LEVERAGE / total)
    return w


def deflated_confidence(
    returns: pd.Series,
    n_trials: int = 1,
    periods_per_year: int = 252,
) -> float:
    """Deflated-Sharpe confidence that the edge is real (0..1).

    Uses math_engine.institutional.deflated_sharpe.deflated_sharpe_ratio:
    1 - p_value = P(true SR > expected-max-of-N-trials SR). This is the
    statistical significance of the edge after multiple-testing correction —
    exactly the quantity that should scale deployable Kelly (López de Prado
    2016). Falls back to 0.0 (no edge proven) on any computation failure.
    """
    try:
        from math_engine.institutional.deflated_sharpe import deflated_sharpe_ratio
        r = pd.Series(returns).astype(float).dropna()
        if len(r) < 20:
            return 0.0
        res = deflated_sharpe_ratio(r, n_trials=max(1, int(n_trials)), freq_per_year=periods_per_year)
        p = float(res.get("p_value", 1.0))
        return float(min(1.0, max(0.0, 1.0 - p)))
    except Exception:
        logger.debug("deflated_confidence failed", exc_info=True)
        return 0.0


def drawdown_capped_kelly(
    kelly_fraction: float,
    sigma: float,
    dd_max: float = 0.20,
    confidence: float = 0.95,
    horizon_years: float = 1.0,
) -> float:
    """First-passage drawdown cap on the Kelly fraction.

    For a fractional Kelly bettor the log-wealth drift and vol scale with f:
        nu(f)  = f·(mu - r) - f^2·sigma^2/2   [approx f·f*·sigma^2 - f^2·sigma^2/2]
        s(f)   = f·sigma
    Using the reflection-principle first-passage bound for Brownian motion
    with drift, P(max drawdown >= d within T) ≈ exp(-2·nu·d / s^2) (for
    nu > 0). Inverting gives the classic exponential drawdown bound:

        f_dd = the largest f with  exp(-2·nu(f)·ln(1/(1-d)) / s(f)^2) <= 1 - conf

    Substituting nu and s (with f* = (mu-r)/sigma^2, so (mu-r) = f*·sigma^2):

        -2·(f·f*·sigma^2 - f^2·sigma^2/2)·L / (f^2·sigma^2)
            = -2·(f* - f/2)·L / f        where L = ln(1/(1-dd_max))

    We solve exp(-2·(f* - f/2)·L/f) = 1 - conf numerically by bisection on
    (0, f*]. For f* = 0 (no edge) the cap is 0.

    Args:
        kelly_fraction: raw Kelly f* (from continuous_kelly / multi-asset).
        sigma: annualized vol of the underlying (decimal).
        dd_max: max acceptable drawdown (decimal, e.g. 0.20).
        confidence: e.g. 0.95 → P(DD > dd_max) <= 5%.
        horizon_years: informational; the exponential bound above is
            horizon-free (a worst-case over infinite horizon — conservative).

    Returns:
        The capped fraction (<= kelly_fraction).
    """
    if kelly_fraction <= 0 or sigma <= 0 or dd_max <= 0 or dd_max >= 1:
        return 0.0

    L = math.log(1.0 / (1.0 - dd_max))
    target = 1.0 - confidence            # acceptable breach probability

    def _breach_prob(f: float) -> float:
        # P(maxDD >= dd_max) ≈ exp(-2·(f* - f/2)·L / f); when drift term
        # (f* - f/2) <= 0 the drawdown probability saturates at 1.
        drift_term = kelly_fraction - f / 2.0
        if drift_term <= 0:
            return 1.0
        return math.exp(-2.0 * drift_term * L / f)

    if _breach_prob(kelly_fraction) <= target:
        return float(kelly_fraction)

    lo, hi = 1e-9, kelly_fraction
    for _ in range(200):
        mid = 0.5 * (lo + hi)
        if _breach_prob(mid) <= target:
            lo = mid
        else:
            hi = mid
    return float(min(lo, kelly_fraction))


def vol_target_scale(
    kelly_fraction: float,
    realized_vol: Optional[float],
    target_vol: float = 0.15,
) -> float:
    """Scale the fraction toward a target portfolio vol (Thorp/industry
    overlay). Insufficient vol history (None/0) returns the unscaled input —
    the cap chain still bounds it."""
    if realized_vol is None or realized_vol <= 0 or target_vol <= 0:
        return float(kelly_fraction)
    scale = target_vol / realized_vol
    # Only de-risk with this overlay (scale <= 1 when realized > target);
    # never let vol targeting LEVERAGE the Kelly fraction beyond f*.
    scale = min(scale, 1.0)
    return float(kelly_fraction * scale)


def kelly_position_size(
    returns: pd.Series,
    risk_free: float = 0.0,
    periods_per_year: int = 252,
    n_trials: int = 1,
    dd_max: float = 0.20,
    dd_confidence: float = 0.95,
    target_vol: Optional[float] = 0.15,
    kelly_fraction_cap: float = 0.25,
) -> Dict[str, object]:
    """Full institutional Kelly stack for one asset's return series.

    Pipeline: continuous Kelly → deflate by DSR confidence → cap by
    drawdown first-passage bound → vol-target overlay → conservative
    fractional overlay. Every stage's binding constraint is reported.

    Returns a provenance dict (never a bare number) so UIs and compliance
    logs can show WHY the size is what it is.
    """
    r = pd.Series(returns).astype(float).dropna()
    n = int(len(r))
    if n < 20:
        return {
            "position_fraction": 0.0,
            "binding_constraint": "insufficient_history",
            "n_obs": n,
            "note": ">=20 observations required; no position sized from thin samples.",
        }

    ann = periods_per_year
    mu = float(np.mean(r.values) * ann)
    sigma = float(np.std(r.values, ddof=1) * math.sqrt(ann))
    if not np.isfinite(sigma) or sigma <= 0:
        return {"position_fraction": 0.0, "binding_constraint": "degenerate_vol",
                "n_obs": n, "note": "zero/degenerate volatility — no position."}

    f_star = continuous_kelly(mu=mu, sigma=sigma, risk_free=risk_free)
    if f_star is None or f_star <= 0:
        return {
            "position_fraction": 0.0,
            "binding_constraint": "no_edge",
            "raw_kelly": 0.0, "mu_annual": mu, "sigma_annual": sigma, "n_obs": n,
            "note": "Non-positive Kelly edge — hold cash.",
        }

    conf = deflated_confidence(r, n_trials=n_trials, periods_per_year=ann)
    f_conf = f_star * conf

    f_dd = drawdown_capped_kelly(f_conf, sigma, dd_max=dd_max, confidence=dd_confidence)

    realized_vol = sigma if n >= 20 else None
    f_vol = vol_target_scale(f_dd, realized_vol, target_vol=target_vol) if target_vol else f_dd

    f_final = f_vol * kelly_fraction_cap

    binding = "kelly_fraction_overlay"
    if conf <= 0.0:
        binding = "dsr_confidence_zero"
    elif f_conf < f_star and f_dd >= f_conf * 0.999:
        binding = "dsr_confidence"
    elif f_dd < f_conf * 0.999:
        binding = "drawdown_cap"
    elif target_vol and f_vol < f_dd * 0.999:
        binding = "vol_target"

    return {
        "position_fraction": round(float(min(f_final, _MAX_LEVERAGE)), 6),
        "binding_constraint": binding,
        "raw_kelly": round(float(f_star), 6),
        "kelly_after_confidence": round(float(f_conf), 6),
        "kelly_after_drawdown_cap": round(float(f_dd), 6),
        "kelly_after_vol_target": round(float(f_vol), 6),
        "dsr_confidence": round(float(conf), 4),
        "mu_annual": round(mu, 6),
        "sigma_annual": round(sigma, 6),
        "n_obs": n,
        "params": {
            "dd_max": dd_max, "dd_confidence": dd_confidence,
            "target_vol": target_vol, "kelly_fraction_cap": kelly_fraction_cap,
            "risk_free": risk_free, "n_trials": n_trials,
        },
    }


def kelly_stack_report(
    holdings: Sequence[str],
    returns_by_asset: pd.DataFrame,
    risk_free: float = 0.0,
    periods_per_year: int = 252,
    n_trials: int = 1,
    **kwargs,
) -> Dict[str, object]:
    """Run the Kelly stack across a holdings panel and aggregate a portfolio
    view: per-asset fractions (equal-risk normalized to <= 100% gross),
    binding-constraint census, and total exposure.

    The aggregate never exceeds _MAX_LEVERAGE; fractional Kelly defaults
    keep gross exposure institutional (<= 100%).
    """
    R = returns_by_asset.astype(float)
    per_asset: Dict[str, Dict[str, object]] = {}
    for h in holdings:
        col = h if h in R.columns else str(h).replace(".NS", "").replace(".BO", "")
        if col not in R.columns:
            per_asset[str(h)] = {"position_fraction": 0.0, "binding_constraint": "no_data"}
            continue
        series = R[col].dropna()
        per_asset[str(h)] = kelly_position_size(
            series, risk_free=risk_free, periods_per_year=periods_per_year,
            n_trials=n_trials, **kwargs)

    fracs = np.array([float(v.get("position_fraction", 0.0)) for v in per_asset.values()])
    gross = float(np.sum(fracs))
    if gross > _MAX_LEVERAGE:
        scale = _MAX_LEVERAGE / gross
        for v in per_asset.values():
            v["position_fraction"] = round(float(v.get("position_fraction", 0.0)) * scale, 6)
        gross = _MAX_LEVERAGE

    census: Dict[str, int] = {}
    for v in per_asset.values():
        c = str(v.get("binding_constraint", "unknown"))
        census[c] = census.get(c, 0) + 1

    return {
        "per_asset": per_asset,
        "gross_exposure": round(gross, 6),
        "n_sized": int(np.sum(fracs > 0)),
        "binding_constraint_census": census,
        "max_gross_leverage": _MAX_LEVERAGE,
    }
