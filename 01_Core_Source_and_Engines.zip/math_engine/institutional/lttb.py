"""LTTB — Largest-Triangle-Three-Buckets downsampling (Sveinn Steinarsson).

Preserves the VISUAL character of a time series (peaks, troughs, trends)
when reducing N points to a smaller threshold — unlike naive slicing
(`.slice(-60)`) or uniform decimation, which can drop the exact drawdown
extremes a risk chart exists to show.

Algorithm (per bucket):
    1. Split the series into `threshold` buckets (first and last points
       always kept).
    2. For each bucket select the point forming the LARGEST triangle area
       with (a) the previously-selected point and (b) the average of the
       NEXT bucket's points — the next bucket's average keeps the selection
       globally aware of where the line is heading.

This is a vectorized NumPy implementation (O(N) per bucket, no per-point
Python loop inside a bucket) with:
    * NaN-safe selection (non-finite values never win the area comparison)
    * date/x-labelling preserved via index alignment
    * honest degradation: threshold >= N returns the input unchanged.

Reference:
    Steinarsson, S. (2013). "Downsampling Time Series for Visual
    Representation." MSc thesis, University of Iceland.

Used by:
    web_dashboard.app — chart payloads (backtest equity/drawdown series).
"""
from __future__ import annotations

import logging
from typing import Optional, Sequence, Tuple, Union

import numpy as np
import pandas as pd

logger = logging.getLogger("quantum_annealer.lttb")

__all__ = ["lttb", "lttb_indices", "lttb_series", "lttb_pair"]


def lttb_indices(n: int, threshold: int, y: np.ndarray) -> list:
    """Core LTTB selection over positional x: returns the sorted list of
    selected row indices (subset of range(n))."""
    if threshold is None or threshold >= n or threshold < 3 or n < 3:
        return list(range(n))

    x = np.arange(n, dtype=float)

    n_buckets = threshold - 2
    bucket_size = (n - 2) / n_buckets
    offsets = np.arange(n_buckets + 1) * bucket_size + 1  # bucket start indices (float)

    # Next-bucket average precomputation: mean of x & y over (offset[i], offset[i+1])
    next_x_avg = np.empty(n_buckets + 1)
    next_y_avg = np.empty(n_buckets + 1)
    for i in range(n_buckets + 1):
        start = int(offsets[i])
        end = int(offsets[i + 1]) if i + 1 <= n_buckets else n - 1
        if end <= start:
            end = min(start + 1, n)
        seg_y = y[start:end]
        seg_x = x[start:end]
        finite = np.isfinite(seg_y)
        if finite.any():
            next_y_avg[i] = float(np.mean(seg_y[finite]))
            next_x_avg[i] = float(np.mean(seg_x[finite]))
        else:
            next_y_avg[i] = np.nan
            next_x_avg[i] = float(np.mean(seg_x)) if len(seg_x) else np.nan

    selected = [0]
    prev_x, prev_y = float(x[0]), float(y[0])
    for i in range(n_buckets):
        start = int(offsets[i])
        end = int(offsets[i + 1]) if i + 1 <= n_buckets else n - 1
        end = max(end, start + 1)
        cand_x = x[start:end]
        cand_y = y[start:end]

        areas = _areas(prev_x, prev_y, cand_x, cand_y, next_x_avg[i + 1], next_y_avg[i + 1])
        # NaN candidates must never win: replace with -inf
        areas = np.where(np.isfinite(areas), areas, -np.inf)
        if not np.any(np.isfinite(areas)):
            # Degenerate bucket (all NaN): carry previous selection forward
            best = min(start, n - 1)
        else:
            best = start + int(np.argmax(areas))
            if best >= n:
                best = n - 1
        selected.append(best)
        prev_x, prev_y = float(x[best]), float(y[best])

    selected.append(n - 1)
    # Preserve order + drop duplicates from degenerate buckets
    uniq = sorted(set(selected))
    return uniq if len(uniq) >= 3 else list(range(n))


def _areas(prev_x: float, prev_y: float,
           cand_x: np.ndarray, cand_y: np.ndarray,
           next_x: float, next_y: float) -> np.ndarray:
    """Triangle areas of (prev, candidate, next) for all candidates."""
    return 0.5 * np.abs(
        prev_x * (cand_y - next_y)
        + cand_x * (next_y - prev_y)
        + next_x * (prev_y - cand_y)
    )


def lttb(x: np.ndarray, y: np.ndarray, threshold: int) -> Tuple[np.ndarray, np.ndarray]:
    """Downsample (x, y) to `threshold` points with LTTB.

    Args:
        x: 1-D array of x values (assumed ordered; timestamps as numeric).
        y: 1-D array of y values (may contain NaN — never selected).
        threshold: target number of output points (>= 2).

    Returns:
        (x_down, y_down) — a SUBSET of the input points (no interpolation,
        no fabricated values). If len(y) <= threshold, inputs are returned
        unchanged.
    """
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    if x.ndim != 1 or y.ndim != 1 or len(x) != len(y):
        raise ValueError("x and y must be aligned 1-D arrays")
    n = len(y)
    idx = lttb_indices(n, threshold, y)
    return x[idx], y[idx]


def lttb_series(values: pd.Series, threshold: int) -> pd.Series:
    """LTTB for a pandas Series with any index.

    Returns a Series that is a strict subset of the input rows — the index
    is preserved, values are never interpolated or fabricated.
    """
    if len(values) <= threshold or threshold < 3 or len(values) < 3:
        return values
    y = values.to_numpy(dtype=float)
    idx = lttb_indices(len(values), threshold, y)
    return values.iloc[idx]


def lttb_pair(
    dates: Sequence, values: Sequence, threshold: int
) -> Tuple[list, list]:
    """Convenience: downsample parallel date/value lists (dashboard payloads)."""
    if len(dates) != len(values):
        raise ValueError("dates and values must be aligned")
    s = pd.Series(list(values), index=pd.Index(list(dates)))
    out = lttb_series(s, threshold)
    return list(out.index), [float(v) if v is not None and np.isfinite(v) else None for v in out.values]
