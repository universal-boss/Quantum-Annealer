"""math_engine/institutional/momentum_vcp.py
========================================
Institutional Mathematical Engines for Momentum & Vol Squeeze Profile:
  1. Multi-Stage Minervini Volatility Contraction Pattern (VCP)
  2. Volume-Clock VPIN (Volume-Synchronized Probability of Toxicity)

Theoretical Foundations:
  - Minervini, M. (2013), "Trade Like a Stock Market Wizard: How to Achieve Super Performance in Stocks".
  - Easley, D., López de Prado, M., & O'Hara, M. (2012), "Flow Toxicity and Liquidity in a High-Frequency World",
    The Review of Financial Studies, 25(5), 1457-1493.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Optional, Tuple, Union
import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


def compute_minervini_vcp(
    ohlcv_df: pd.DataFrame,
    wave_windows: Tuple[int, int, int] = (50, 25, 10),
) -> Dict[str, Union[float, bool]]:
    """Compute authentic multi-stage Minervini Volatility Contraction Pattern (VCP) metrics.

    Evaluates:
      1. Monotonic Contraction: High-to-low percentage drawdowns across consecutive waves
         must compress monotonically: DD_1 > DD_2 > DD_3.
      2. Volume Dryup: Volume in the final pivot wave must contract relative to the base inception.
      3. Pivot Tightness: ATR_5 / ATR_20 ratio indicating price compression before breakout.

    Args:
        ohlcv_df: DataFrame containing ['high', 'low', 'close', 'volume'] (case-insensitive).
        wave_windows: Trailing window lengths for waves 1, 2, and 3.

    Returns:
        Dict with vcp_score [0..100], is_vcp_valid (bool), contraction_ratio, volume_dryup_ratio, pivot_tightness.
    """
    if ohlcv_df is None or len(ohlcv_df) < max(wave_windows):
        return {
            "vcp_score": 50.0,
            "is_vcp_valid": False,
            "contraction_ratio": 1.0,
            "volume_dryup_ratio": 1.0,
            "pivot_tightness": 0.5,
            "dd_wave1": 0.0,
            "dd_wave2": 0.0,
            "dd_wave3": 0.0,
        }

    # Normalize column names to lowercase
    cols = {c.lower(): c for c in ohlcv_df.columns}
    highs = ohlcv_df[cols.get("high", "close")].to_numpy(dtype=float)
    lows = ohlcv_df[cols.get("low", "close")].to_numpy(dtype=float)
    closes = ohlcv_df[cols["close"]].to_numpy(dtype=float)
    volumes = ohlcv_df[cols.get("volume", "close")].to_numpy(dtype=float) if "volume" in cols else np.ones_like(closes)

    n = len(closes)
    w1, w2, w3 = wave_windows

    # Calculate wave drawdowns: max high to min low depth in each sub-window
    h1, l1 = np.max(highs[-w1:]), np.min(lows[-w1:])
    h2, l2 = np.max(highs[-w2:]), np.min(lows[-w2:])
    h3, l3 = np.max(highs[-w3:]), np.min(lows[-w3:])

    dd1 = (h1 - l1) / (h1 + 1e-9)
    dd2 = (h2 - l2) / (h2 + 1e-9)
    dd3 = (h3 - l3) / (h3 + 1e-9)

    # 1. Contraction Ratio: Are drawdowns compressing monotonically?
    # Perfect VCP has dd1 > dd2 > dd3 (e.g. 25% -> 12% -> 5%)
    is_contracting = (dd1 > dd2) and (dd2 > dd3)
    # Contraction factor: ratio of final wave depth to initial wave depth
    contraction_ratio = float(dd3 / (dd1 + 1e-9))

    # 2. Volume Dryup: Average volume in wave 3 vs wave 1
    v1_mean = np.mean(volumes[-w1:-w2]) if w1 > w2 else np.mean(volumes[-w1:])
    v3_mean = np.mean(volumes[-w3:])
    volume_dryup_ratio = float(v3_mean / (v1_mean + 1e-9))
    has_volume_dryup = volume_dryup_ratio < 0.75  # 25%+ volume contraction at pivot

    # 3. Pivot Tightness: ATR(5) / ATR(20)
    # True range computation
    tr = np.maximum(
        highs[1:] - lows[1:],
        np.maximum(
            np.abs(highs[1:] - closes[:-1]),
            np.abs(lows[1:] - closes[:-1]),
        ),
    )
    atr5 = np.mean(tr[-5:]) if len(tr) >= 5 else 1.0
    atr20 = np.mean(tr[-20:]) if len(tr) >= 20 else 1.0
    # Tightness: 1.0 when ATR(5) is very small relative to ATR(20)
    tightness = float(np.clip(1.0 - (atr5 / (atr20 + 1e-9)), 0.0, 1.0))

    # 4. Composite VCP Score [0..100]
    # Reward monotonically contracting waves, volume dryup, and tight pivot base
    score = 40.0
    if is_contracting:
        score += 30.0 * (1.0 - np.clip(contraction_ratio, 0.0, 1.0))
    else:
        # Partial credit if at least dd2 > dd3
        if dd2 > dd3:
            score += 15.0

    if has_volume_dryup:
        score += 15.0 * (1.0 - np.clip(volume_dryup_ratio, 0.0, 1.0))

    score += 15.0 * tightness

    final_score = float(np.clip(score, 10.0, 99.0))
    is_vcp_valid = is_contracting and (contraction_ratio < 0.65) and (dd3 < 0.12)

    return {
        "vcp_score": round(final_score, 2),
        "is_vcp_valid": bool(is_vcp_valid),
        "contraction_ratio": round(contraction_ratio, 4),
        "volume_dryup_ratio": round(volume_dryup_ratio, 4),
        "pivot_tightness": round(tightness, 4),
        "dd_wave1": round(float(dd1), 4),
        "dd_wave2": round(float(dd2), 4),
        "dd_wave3": round(float(dd3), 4),
    }


def compute_volume_clock_vpin(
    ohlcv_df: pd.DataFrame,
    num_buckets: int = 50,
    bucket_vol_frac: float = 0.02,
) -> float:
    """Compute authentic Volume-Clock VPIN (Volume-Synchronized Probability of Toxicity).

    Partitions total transaction volume into equal volume buckets V = total_vol * bucket_vol_frac.
    Uses the tick rule / return sign to partition each bucket into buy volume V^B and sell volume V^S.
    Computes order imbalance per bucket and returns normalized VPIN in [0.0..1.0].

    Reference:
        Easley, López de Prado, O'Hara (2012), Review of Financial Studies.
    """
    if ohlcv_df is None or len(ohlcv_df) < 20:
        return None  # Insufficient data — VPIN cannot be computed

    cols = {c.lower(): c for c in ohlcv_df.columns}
    closes = ohlcv_df[cols["close"]].to_numpy(dtype=float)
    volumes = ohlcv_df[cols.get("volume", "close")].to_numpy(dtype=float) if "volume" in cols else np.ones_like(closes)

    # Valid mask
    valid = np.isfinite(closes) & np.isfinite(volumes) & (volumes > 0)
    closes = closes[valid]
    volumes = volumes[valid]

    if len(closes) < 20:
        return None  # Insufficient valid bars after NaN/zero filter — VPIN cannot be computed

    # Price differences to determine buy vs sell volume partition
    ret = np.diff(closes)
    ret = np.pad(ret, (1, 0), mode="edge")
    # Standard normal CDF approximation of trade direction probability: Z = ret / (rolling_std)
    std_ret = np.std(ret) + 1e-9
    z_scores = ret / std_ret
    # Probability of informed buy: P(B) = norm.cdf(z)
    p_buy = 0.5 * (1.0 + np.vectorize(np.tanh)(z_scores * 0.7978845608 * (1.0 + 0.044715 * z_scores**2)))
    p_buy = np.clip(p_buy, 0.01, 0.99)

    buy_vols = volumes * p_buy
    sell_vols = volumes * (1.0 - p_buy)

    total_vol = np.sum(volumes)
    bucket_size = max(1.0, total_vol * bucket_vol_frac)

    # Slice into volume buckets
    imbalances = []
    curr_v = 0.0
    curr_buy = 0.0
    curr_sell = 0.0

    for bv, sv in zip(buy_vols, sell_vols):
        bar_vol = bv + sv
        while curr_v + bar_vol >= bucket_size:
            needed = bucket_size - curr_v
            frac = needed / (bar_vol + 1e-9)
            curr_buy += bv * frac
            curr_sell += sv * frac
            imbalances.append(abs(curr_buy - curr_sell))
            # Reset bucket
            curr_v = 0.0
            curr_buy = 0.0
            curr_sell = 0.0
            bv *= (1.0 - frac)
            sv *= (1.0 - frac)
            bar_vol = bv + sv

        curr_v += bar_vol
        curr_buy += bv
        curr_sell += sv

    if not imbalances:
        return None  # No complete volume buckets formed — VPIN undefined

    # Average imbalance across the trailing num_buckets
    window = imbalances[-num_buckets:] if len(imbalances) >= num_buckets else imbalances
    vpin = float(np.mean(window) / (bucket_size + 1e-9))
    return float(np.clip(vpin, 0.01, 0.99))
