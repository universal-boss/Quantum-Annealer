"""math_engine/institutional/quality_accounting.py
=============================================
Institutional Forensic Accounting & Quality Mathematical Engines:
  1. Sloan Accrual Anomaly (Sloan 1996, Wharton)
  2. Piotroski 9-Point Fundamental Composite F-Score (Piotroski 2000, Stanford)
  3. Novy-Marx Gross Profitability / Total Assets (Novy-Marx 2013, Rochester)

Theoretical Foundations:
  - Sloan, R. G. (1996), "Do Stock Prices Fully Reflect Information in Accruals and Cash Flows About Future Earnings?",
    The Accounting Review, 71(3), 289-315.
  - Piotroski, J. D. (2000), "Value Investing: The Use of Historical Financial Statement Information to Separate Winners from Losers",
    Journal of Accounting Research, 38, 1-41.
  - Novy-Marx, R. (2013), "The Other Side of Value: The Gross Profitability Premium",
    Journal of Financial Economics, 108(1), 1-28.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Optional, Union
import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


def compute_sloan_accrual_ratio(
    net_income: float,
    operating_cash_flow: float,
    total_assets: float,
    prior_total_assets: Optional[float] = None,
) -> float:
    """Compute Sloan's Balance Sheet / Cash Flow Accrual Ratio.

    High accruals (Net Income significantly outstripping Operating Cash Flow) signal
    aggressive revenue recognition and poor earnings persistence (future earnings mean-reversion).
    Low or negative accruals indicate conservative accounting backed by cash generation.

    Formula:
        Accrual = (Net Income - Operating Cash Flow) / Average Total Assets

    Returns:
        float: Accrual ratio (typically in [-0.50, +0.50]).
               Institutional quality stocks have Accrual Ratio <= 0.05.
    """
    if total_assets <= 0:
        return 0.0

    avg_assets = 0.5 * (total_assets + prior_total_assets) if (prior_total_assets and prior_total_assets > 0) else total_assets
    accrual = (net_income - operating_cash_flow) / (avg_assets + 1e-9)
    return float(np.clip(accrual, -1.0, 1.0))


def compute_piotroski_f_score(
    roa_curr: float,
    roa_prev: float,
    cfo_curr: float,
    total_assets_curr: float,
    leverage_curr: float,
    leverage_prev: float,
    current_ratio_curr: float,
    current_ratio_prev: float,
    shares_curr: float,
    shares_prev: float,
    gross_margin_curr: float,
    gross_margin_prev: float,
    asset_turnover_curr: float,
    asset_turnover_prev: float,
) -> Dict[str, Union[int, Dict[str, int]]]:
    """Compute authentic Piotroski 9-point fundamental health F-Score.

    Nine binary signals (1 = favorable, 0 = unfavorable) across three dimensions:
      A. Profitability Signals:
         1. F_ROA: Return on Assets > 0
         2. F_CFO: Cash Flow from Operations > 0
         3. F_DROA: Change in ROA > 0 (YoY growth)
         4. F_ACCRUAL: CFO / Total Assets > ROA (Cash quality exceeds accounting net income)

      B. Leverage, Liquidity & Source of Funds:
         5. F_DLEVER: Change in Long-Term Debt / Leverage <= 0 (De-leveraging)
         6. F_DLIQUID: Change in Current Ratio > 0 (Improving working capital liquidity)
         7. F_EQ_OFFER: Shares outstanding <= Prior shares (No equity dilution)

      C. Operating Efficiency:
         8. F_DMARGIN: Change in Gross Margin > 0 (Pricing power)
         9. F_DTURN: Change in Asset Turnover > 0 (Asset productivity)

    Returns:
        Dict with 'f_score' (0..9) and detailed breakdown dict.
    """
    signals: Dict[str, int] = {}

    # Profitability
    signals["F_ROA"] = 1 if roa_curr > 0 else 0
    signals["F_CFO"] = 1 if cfo_curr > 0 else 0
    signals["F_DROA"] = 1 if roa_curr > roa_prev else 0
    cfo_scaled = cfo_curr / (total_assets_curr + 1e-9) if total_assets_curr > 0 else 0.0
    signals["F_ACCRUAL"] = 1 if cfo_scaled > roa_curr else 0

    # Leverage & Liquidity
    signals["F_DLEVER"] = 1 if leverage_curr <= leverage_prev else 0
    signals["F_DLIQUID"] = 1 if current_ratio_curr > current_ratio_prev else 0
    signals["F_EQ_OFFER"] = 1 if shares_curr <= (shares_prev * 1.01) else 0  # Allow 1% tolerance for stock options

    # Operating Efficiency
    signals["F_DMARGIN"] = 1 if gross_margin_curr > gross_margin_prev else 0
    signals["F_DTURN"] = 1 if asset_turnover_curr > asset_turnover_prev else 0

    total_score = sum(signals.values())
    return {
        "f_score": total_score,
        "is_high_quality": total_score >= 7,
        "signals": signals,
    }


def compute_novy_marx_gross_profitability(
    revenue: float,
    cogs: float,
    total_assets: float,
) -> float:
    """Compute Novy-Marx Gross Profitability / Total Assets.

    Novy-Marx (2013) proved that gross profitability (Revenue - COGS) / Assets
    has higher predictive power for true economic compounding than bottom-line earnings (P/E or ROE),
    because it is free from overhead distortions, non-cash amortization, and capital structure biases.

    Returns:
        float: Gross profitability ratio [0.0..1.5+].
    """
    if total_assets <= 0:
        return 0.0
    gross_profit = max(0.0, revenue - cogs)
    return float(gross_profit / (total_assets + 1e-9))
