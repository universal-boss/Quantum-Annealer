"""math_engine/institutional/risk_parity.py
=========================================
Institutional Risk Parity & Capital Preservation Mathematical Engines:
  1. Ledoit-Wolf Analytical Covariance Shrinkage (Ledoit & Wolf 2004)
  2. Hierarchical Risk Parity (HRP - López de Prado 2016)
  3. Conditional Value-at-Risk (CVaR / Expected Shortfall)

Theoretical Foundations:
  - Ledoit, O., & Wolf, M. (2004), "A well-conditioned estimator for large-dimensional covariance matrices",
    Journal of Multivariate Analysis, 88(2), 365-411.
  - López de Prado, M. (2016), "Building Diversified Portfolios that Outperform Out of Sample",
    The Journal of Portfolio Management, 42(4), 59-69.
  - Rockafellar, R. T., & Uryasev, S. (2000), "Optimization of Conditional Value-at-Risk",
    Journal of Risk, 2(3), 21-41.
"""
from __future__ import annotations

import logging
from typing import Dict, List, Optional, Tuple, Union
import numpy as np
import pandas as pd
from scipy.cluster.hierarchy import linkage
from scipy.spatial.distance import squareform

logger = logging.getLogger(__name__)


def ledoit_wolf_shrinkage_covariance(
    returns_matrix: Union[np.ndarray, pd.DataFrame],
    shrinkage_target: str = "constant_correlation",
) -> Tuple[np.ndarray, float]:
    """Compute optimal Ledoit-Wolf analytical covariance shrinkage.

    Eliminates high-dimensional sample eigenvalue dispersion noise by shrinking
    the sample covariance S toward a well-conditioned structured target F:
        Sigma_LW = delta* * F + (1 - delta*) * S

    Args:
        returns_matrix: Array or DataFrame of shape (T_dates, N_assets).
        shrinkage_target: 'constant_correlation' or 'identity'.

    Returns:
        Tuple[np.ndarray (N x N shrunk covariance), float (optimal shrinkage intensity delta*)].
    """
    X = np.asarray(returns_matrix, dtype=float)
    T, N = X.shape
    if T < 5 or N < 2:
        return np.cov(X, rowvar=False) if N > 1 else np.array([[np.var(X)]]), 0.0

    # Demean returns
    mean = np.mean(X, axis=0)
    X_c = X - mean

    # Sample covariance S
    S = (X_c.T @ X_c) / float(T)

    # Variances and sample correlation
    var = np.diag(S)
    std = np.sqrt(np.maximum(var, 1e-9))
    R = S / (std[:, None] @ std[None, :])

    if shrinkage_target == "constant_correlation":
        # Target F: Constant correlation model
        r_bar = (np.sum(R) - N) / float(N * (N - 1) + 1e-9)
        F = r_bar * (std[:, None] @ std[None, :])
        np.fill_diagonal(F, var)
    else:
        # Target F: Scaled identity matrix
        mu = np.mean(var)
        F = mu * np.eye(N)

    # Estimate optimal shrinkage intensity delta* (Ledoit & Wolf 2004 Theorem 1)
    # Pi-hat: sum of asymptotic variances of sample covariance entries
    X2 = X_c**2
    pi_mat = (X2.T @ X2) / float(T) - S**2
    pi_hat = np.sum(pi_mat)

    # Gamma-hat: squared Frobenius norm of (F - S)
    gamma_hat = np.sum((F - S)**2)

    # Rho-hat: covariance between entries of S and entries of F
    if shrinkage_target == "constant_correlation":
        term1 = (X_c**3).T @ X_c / float(T)
        rho_diag = np.sum(np.diag(pi_mat))
        rho_off = r_bar * np.sum(std[:, None] * term1) / float(N)
        rho_hat = rho_diag + rho_off
    else:
        rho_hat = np.sum(np.diag(pi_mat))

    # Kappa-hat = (pi_hat - rho_hat) / gamma_hat
    kappa_hat = (pi_hat - rho_hat) / (gamma_hat + 1e-9)
    delta_star = float(np.clip(kappa_hat / float(T), 0.0, 1.0))

    # Shrunk covariance matrix
    Sigma_LW = delta_star * F + (1.0 - delta_star) * S
    return Sigma_LW, delta_star


def hierarchical_risk_parity_weights(
    returns_matrix: Union[np.ndarray, pd.DataFrame],
    asset_names: Optional[List[str]] = None,
) -> Dict[str, float]:
    """Compute Marcos López de Prado's Hierarchical Risk Parity (HRP) weights.

    Three-stage mathematical architecture:
      1. Tree Clustering: Converts correlation matrix into distance metric D_ij = sqrt(0.5 * (1 - rho_ij))
         and constructs a single-linkage hierarchical dendrogram.
      2. Quasi-Diagonalization: Reorders the covariance matrix so similar assets are adjacent.
      3. Recursive Bisection: Allocates weights down the tree inversely proportional to cluster variance,
         completely bypassing matrix inversion and singularity problems.

    Returns:
        Dict[asset_name -> optimal_weight].
    """
    if isinstance(returns_matrix, pd.DataFrame):
        names = list(returns_matrix.columns)
        X = returns_matrix.to_numpy(dtype=float)
    else:
        X = np.asarray(returns_matrix, dtype=float)
        names = asset_names or [f"asset_{i}" for i in range(X.shape[1])]

    T, N = X.shape
    if N == 1:
        return {names[0]: 1.0}

    # 1. Shrunk covariance and correlation
    cov, _ = ledoit_wolf_shrinkage_covariance(X)
    std = np.sqrt(np.maximum(np.diag(cov), 1e-9))
    corr = cov / (std[:, None] @ std[None, :])
    corr = np.clip(corr, -1.0, 1.0)

    # Distance metric D_ij = sqrt(0.5 * (1 - rho_ij))
    dist = np.sqrt(np.maximum(0.0, 0.5 * (1.0 - corr)))
    np.fill_diagonal(dist, 0.0)

    # 2. Hierarchical Linkage
    condensed_dist = squareform(dist, checks=False)
    link = linkage(condensed_dist, method="single")

    # Quasi-diagonalization order
    def _get_quasi_order(link_mat: np.ndarray, num_items: int) -> List[int]:
        order = [int(link_mat[-1, 0]), int(link_mat[-1, 1])]
        while any(i >= num_items for i in order):
            new_order = []
            for item in order:
                if item < num_items:
                    new_order.append(item)
                else:
                    cluster_idx = item - num_items
                    new_order.append(int(link_mat[cluster_idx, 0]))
                    new_order.append(int(link_mat[cluster_idx, 1]))
            order = new_order
        return order

    sorted_order = _get_quasi_order(link, N)

    # 3. Recursive Bisection
    def _get_cluster_var(cov_mat: np.ndarray, indices: List[int]) -> float:
        sub_cov = cov_mat[np.ix_(indices, indices)]
        # Inverse variance allocation within cluster
        inv_diag = 1.0 / np.maximum(np.diag(sub_cov), 1e-9)
        w = inv_diag / np.sum(inv_diag)
        c_var = float(w.T @ sub_cov @ w)
        return max(c_var, 1e-9)

    weights = pd.Series(1.0, index=sorted_order)
    clusters = [sorted_order]

    while len(clusters) > 0:
        new_clusters = []
        for c in clusters:
            if len(c) > 1:
                mid = len(c) // 2
                c1 = c[:mid]
                c2 = c[mid:]
                var1 = _get_cluster_var(cov, c1)
                var2 = _get_cluster_var(cov, c2)

                alpha = 1.0 - (var1 / (var1 + var2))
                weights.loc[c1] *= alpha
                weights.loc[c2] *= (1.0 - alpha)

                new_clusters.append(c1)
                new_clusters.append(c2)
        clusters = new_clusters

    # Normalize and map back to asset names
    weights = weights / weights.sum()
    return {names[idx]: float(round(weights.loc[idx], 6)) for idx in range(N)}


def compute_cvar_expected_shortfall(
    returns_series: Union[np.ndarray, pd.Series],
    confidence: float = 0.95,
) -> Dict[str, float]:
    """Compute authentic Conditional Value-at-Risk (CVaR / Expected Shortfall).

    Measures average loss in the worst (1 - confidence)% tail of returns,
    strictly satisfying the sub-additivity axiom of coherent risk measures.

    Returns:
        Dict with 'var' and 'cvar'.
    """
    arr = np.asarray(returns_series, dtype=float)
    arr = arr[np.isfinite(arr)]
    if len(arr) < 10:
        return {"var": 0.0, "cvar": 0.0}

    cutoff_pct = (1.0 - confidence) * 100.0
    var_threshold = float(np.percentile(arr, cutoff_pct))
    tail_losses = arr[arr <= var_threshold]

    cvar = float(np.mean(tail_losses)) if len(tail_losses) > 0 else var_threshold
    return {
        "var": round(var_threshold, 6),
        "cvar": round(cvar, 6),
    }
