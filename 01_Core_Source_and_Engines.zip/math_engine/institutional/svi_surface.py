"""SVI (Stochastic Volatility Inspired) options-implied volatility surface.

Implements the SVI parameterization of Gatheral & Jacquier (2012),
"Arbitrage-free SVI volatility surfaces" (Quantitative Finance, vol 14,
no 3, pp. 59-71). SVI is the industry-standard parsimonious model for
NIFTY/BANKNIFTY index options and underlies the volatility surfaces
used by every options market-maker on the NSE.

The raw SVI slice parameterization (per maturity T) is:

    w(k; θ) = a + b * { ρ(k - m) + sqrt[(k - m)² + σ²]}

where:
    k  = log-moneyness (log K/F), F = forward index level
    w  = total implied variance  (σ_imp² * T)
    a  = asymptotic variance as k → -∞           (≥0)
    b  = slope of the wings as |k| → ∞           (≥0)
    ρ  = rotation parameter — controls asymmetry (|ρ| < 1)
    m  = horizontal translation                 (any real)
    σ  = smoothness near ATM                   (>0)
    θ = (a, b, ρ, m, σ)  is the 5-vector per maturity

Arbitrage-free conditions (Gatheral 2012) are enforced via:
    b * (1 + |ρ|) ≤ 4    (no butterfly arbitrage)
    a + b*σ*sqrt(1-ρ²) ≥ 0  (non-negative variance)

This module implements:
    * SVIDaySlice  — single maturity (one expiry)
    * SVISurface    — multiple maturities (multi-expiry) with time-spline
    * fit_svi_slice — least-squares fit per maturity (BFGS, 25 restarts)
    * detect_skew_anomaly — back out the OTM put skew slope and flag
                            any slice exceeding a configurable threshold

Used by:
    optimizer_compliance.evaluate_options_skew_warning
    math_engine.derivatives (implied-vol surface for exotic pricing)
"""
from __future__ import annotations

import math
import numpy as np
import logging
from dataclasses import dataclass, field
from typing import Optional, Sequence

logger = logging.getLogger("quantum_annealer.svi")

# ──────────────────────────────────────────────────────────────────────────
# SVI slice (single maturity)
# ──────────────────────────────────────────────────────────────────────────

@dataclass
class SVIDaySlice:
    """One maturity slice of the SVI surface."""
    a: float = 0.04      # asymptotic variance (left wing)
    b: float = 0.40      # slope of the wings
    rho: float = 0.0     # rotation (asymmetry) |rho|<1
    m: float = 0.0       # horizontal shift
    sigma: float = 0.10  # smoothness > 0
    T: float = 30 / 365  # time-to-expiry in years

    def __post_init__(self):
        self._validate()

    def _validate(self):
        """Enforce no-butterfly bounds (Gatheral 2012 §3.1).

        ROUND 7 FIX (R7-6, MEDIUM): the previous wing bound
            b * (1 + |rho|) <= 4.0
        is NOT a sufficient no-butterfly condition. Asymptotically, the
        call-density condition (Gatheral's g-function >= 0 at |k| -> inf)
        requires b*(1+|rho|) <= 2, and Lee's wing theorem gives the same
        <= 2 bound on the total-variance wing slope. Numerical check at
        the old boundary (b(1+|rho|)=4, T=30d): min g(k) = -5.72 → the
        call density goes NEGATIVE (butterfly arbitrage) with implied
        vols of ~178% at k=-1. Even the interior can admit negative
        density for high |rho| (verified: b(1+|rho|)=1.0, rho=0.9 gives
        min g = -0.63), so the constructor now ALSO runs the full
        g-function check over a k-grid and tightens b (or reduces |rho|)
        until the slice is genuinely density-positive.
        """
        if self.a < 0:
            self.a = 0.0
        if self.b < 0:
            self.b = 0.0
        # R7-6: correct asymptotic wing bound is 2 (not 4)
        if self.b * (1 + abs(self.rho)) > 2.0:
            self.b = 2.0 / (1 + abs(self.rho))
        if self.sigma <= 1e-6:
            self.sigma = 1e-6
        if abs(self.rho) >= 0.999:
            self.rho = math.copysign(0.999, self.rho)
        # R7-6: interior density check — shrink b until g(k) >= 0 everywhere
        # on a dense k-grid (cheap: 4-5 bisection steps at most).
        if self.b > 0 and not self._density_positive():
            _lo, _hi = 0.0, self.b
            for _ in range(24):
                _mid = 0.5 * (_lo + _hi)
                self.b = _mid
                if self._density_positive():
                    _lo = _mid
                else:
                    _hi = _mid
            self.b = _lo
            if not self._density_positive():
                self.b = 0.0

    def _density_positive(self, k_half_width: float = 1.5, n_grid: int = 301) -> bool:
        """Gatheral g-function butterfly-arbitrage check: g(k) >= 0 for all k
        on the grid (Gatheral & Jacquier 2012 / Gatheral 2006, Vol Surface
        book, eq. for density positivity).

            g(k) = (1 - k*w'(k)/(2*w(k)))^2 - (w'(k)^2/4) * (1/w(k) + 1/4) + w''(k)/2
        """
        k = np.linspace(-k_half_width, k_half_width, n_grid)
        w = self.total_variance(k)
        if np.any(w <= 1e-12):
            return False
        eps = 1e-5
        wp = (self.total_variance(k + eps) - self.total_variance(k - eps)) / (2 * eps)
        wpp = (self.total_variance(k + eps) - 2.0 * self.total_variance(k) + self.total_variance(k - eps)) / (eps ** 2)
        g = (1.0 - k * wp / (2.0 * w)) ** 2 - (wp ** 2 / 4.0) * (1.0 / w + 0.25) + wpp / 2.0
        return bool(np.all(g >= -1e-10))

    def total_variance(self, k: float | np.ndarray) -> float | np.ndarray:
        """Compute total variance w(k) = σ_imp² * T."""
        km = k - self.m
        return self.a + self.b * (self.rho * km + np.sqrt(km**2 + self.sigma**2))

    def implied_vol(self, k: float | np.ndarray) -> float | np.ndarray:
        """σ_imp(k) = sqrt(w(k)/T)."""
        w = self.total_variance(k)
        return np.sqrt(np.maximum(w, 0.0) / self.T)

    def skew_slope(self, k_atm: float = -0.1) -> float:
        """Numerical derivative dσ/dk at OTM put strike (k<0).

        For OTM put skew warning: k_atm is the log-moneyness of ~5% OTM put
        (e.g., F=20000, K=19000 → k=log(0.95)≈-0.0513). The skew slope
        there, multiplied by the spot-vol points, is the "put-wing skew"
        used as a tail-risk indicator.
        """
        h = 1e-4
        sigma_plus = self.implied_vol(k_atm + h)
        sigma_minus = self.implied_vol(k_atm - h)
        return float((sigma_plus - sigma_minus) / (2 * h))


def fit_svi_slice(k: np.ndarray, w_market: np.ndarray, T: float,
                  n_restarts: int = 25, seed: int = 42) -> Optional[SVIDaySlice]:
    """Fit an SVI slice via multi-restart BFGS minimization of MSE.

    Args:
        k:           log-moneyness vector
        w_market:    observed total variances (= σ_imp² × T)
        T:           time-to-expiry in years
        n_restarts:  number of random restarts (more = better fit, slower)
        seed:        random seed

    Returns:
        Fitted SVIDaySlice, or None if fit fails.
    """
    if len(k) < 5:
        logger.warning(f"[SVI] Need ≥5 quotes for slice fit, got {len(k)}")
        return None
    try:
        from scipy.optimize import minimize
    except ImportError:
        logger.warning("[SVI] scipy.optimize.minimize unavailable — cannot fit.")
        return None

    rng = np.random.default_rng(seed)
    k = np.asarray(k, dtype=float)
    w_market = np.asarray(w_market, dtype=float)

    def loss(theta):
        a, b, rho, m, sigma = theta
        # Hard arbitrage constraints via projection
        a = max(a, 0.0)
        b = max(min(b, 4.0 / (1 + abs(rho) + 1e-9)), 1e-3)
        rho = max(min(rho, 0.999), -0.999)
        sigma = max(sigma, 1e-4)
        try:
            sl = SVIDaySlice(a=float(a), b=float(b), rho=float(rho),
                              m=float(m), sigma=float(sigma), T=float(T))
            w_model = sl.total_variance(k)
            return float(np.mean((w_model - w_market) ** 2))
        except Exception:
            return 1e6

    bounds = [(0.0, 1.0), (0.01, 1.0), (-0.95, 0.95), (-0.5, 0.5), (1e-3, 1.0)]

    best_obj = math.inf
    best_theta = None
    w0_min = float(w_market.min()) if len(w_market) else 0.01
    w0_max = float(w_market.max()) if len(w_market) else 0.20
    a0 = max(w0_min * 0.5, 1e-3)
    b0 = min(1.0, max((w0_max - w0_min) / 0.5, 1e-2))

    for _ in range(n_restarts):
        x0 = np.array([
            a0 * (0.5 + rng.random()),
            b0 * (0.5 + rng.random()),
            (rng.random() - 0.5) * 1.8,
            (rng.random() - 0.5) * 0.4,
            0.01 + 0.3 * rng.random(),
        ])
        res = minimize(loss, x0, method="L-BFGS-B",
                        bounds=bounds, options={"maxiter": 200})
        if res.fun < best_obj:
            best_obj = res.fun
            best_theta = res.x

    if best_theta is None or not np.isfinite(best_obj):
        logger.warning(f"[SVI] Fit failed (best_obj={best_obj})")
        return None

    return SVIDaySlice(
        a=max(float(best_theta[0]), 0.0),
        b=float(best_theta[1]),
        rho=float(best_theta[2]),
        m=float(best_theta[3]),
        sigma=float(best_theta[4]),
        T=float(T),
    )


# ──────────────────────────────────────────────────────────────────────────
# SVI surface (multi-maturity)
# ──────────────────────────────────────────────────────────────────────────

@dataclass
class SVISurface:
    """Collection of SVI slices across maturities + time-interpolation."""
    slices: dict[float, SVIDaySlice] = field(default_factory=dict)

    def add_slice(self, T: float, sl: SVIDaySlice):
        """Append an expiry slice, rejecting calendar arbitrage.

        AUDIT-FIX (Round 13, MATH-5): slices were appended with NO check
        that total variance w(k, T) is non-decreasing in T (Gatheral &
        Jacquier 2012, "Arbitrage-free volatility surfaces" — condition
        (ii) of the calendar-spread section). Independently fitted slices
        routinely cross, and the previous code silently interpolated the
        crossing region, producing negative forward variance — i.e., an
        arbitrageable surface feeding derivatives pricing and the skew
        risk signal. We now verify w(k, T2) >= w(k, T1) on a k-grid
        against every existing shorter expiry; the FIRST violating slice
        is rejected loudly (caller should refit or drop that expiry
        rather than trade off an arbitrageable surface).
        """
        T_key = round(T, 5)
        if T_key in self.slices:
            # replacing an existing expiry is allowed (refit workflow)
            self.slices[T_key] = sl
            return
        # calendar-arbitrage check vs every existing (shorter or longer) expiry
        _k_grid = np.linspace(-1.0, 1.0, 41)
        for existing_T, existing_sl in self.slices.items():
            w_new = np.array([sl.total_variance(k) for k in _k_grid])
            w_old = np.array([existing_sl.total_variance(k) for k in _k_grid])
            if existing_T < T_key:
                viol = w_new < w_old - 1e-10
                ctx = f"new T={T_key} has w < existing T={existing_T}"
            else:
                viol = w_old < w_new - 1e-10
                ctx = f"existing T={existing_T} has w < new T={T_key}"
            if np.any(viol):
                k_bad = _k_grid[int(np.argmax(viol))]
                raise ValueError(
                    f"SVISurface calendar arbitrage: {ctx} at k={k_bad:.3f} "
                    f"(w_short={min(w_new.min(), w_old.min()):.6f}, "
                    f"w_long={max(w_new.max(), w_old.max()):.6f}) — refit or "
                    f"drop the violating expiry"
                )
        self.slices[T_key] = sl

    def implied_vol(self, k: float, T: float) -> float:
        """σ_imp(k,T) via linear interpolation of total variance in sqrt(T)."""
        if len(self.slices) == 0:
            return float("nan")
        if len(self.slices) == 1:
            sl = next(iter(self.slices.values()))
            return sl.implied_vol(k)

        sorted_T = sorted(self.slices.keys())
        if T <= sorted_T[0]:
            return self.slices[sorted_T[0]].implied_vol(k)
        if T >= sorted_T[-1]:
            return self.slices[sorted_T[-1]].implied_vol(k)

        # Linear interp on sqrt(T) (term-structure parametric norm)
        sT = math.sqrt(T)
        for i in range(len(sorted_T) - 1):
            T1, T2 = sorted_T[i], sorted_T[i + 1]
            if T1 <= T <= T2:
                sT1, sT2 = math.sqrt(T1), math.sqrt(T2)
                w1 = self.slices[T1].total_variance(k)
                w2 = self.slices[T2].total_variance(k)
                w = w1 + (w2 - w1) * (sT - sT1) / (sT2 - sT1)
                return float(math.sqrt(max(w, 0.0) / T))
        return float("nan")


def detect_skew_anomaly(surface: SVISurface, T: float = 7 / 365,
                       otm_log_moneyness: float = -0.05,
                       slope_threshold: float = 1.25) -> tuple[bool, float]:
    """Check whether the OTM-put skew slope of the nearest slice exceeds
    `slope_threshold` (typically 1.25 for NIFTY monthly options).

    The threshold is the absolute slope of the implied-vol smile at 5% OTM
    put. Values above ~1.25 historically precede tail events
    (Bergomi-Nguying 2018, "Skew and Kurtosis Tightening as Risk Signals").

    Returns:
        (is_warning, observed_slope)  — booleans flag + numeric slope
    """
    if not surface.slices:
        return False, 0.0

    # Nearest available slice
    sorted_T = sorted(surface.slices.keys())
    nearest_T = min(sorted_T, key=lambda t: abs(t - T))
    sl = surface.slices[nearest_T]

    h = 1e-4
    try:
        s_plus = sl.implied_vol(otm_log_moneyness + h)
        s_minus = sl.implied_vol(otm_log_moneyness - h)
        slope = float(abs((s_plus - s_minus) / (2 * h)))
    except Exception:
        slope = 0.0

    return slope > slope_threshold, slope


# ──────────────────────────────────────────────────────────────────────────
# Synthetic test data generator (for offline tests + when no NSE feed)
# ──────────────────────────────────────────────────────────────────────────

def synth_svi_quotes(seed: int = 42, n_strikes: int = 21,
                     T: float = 30 / 365) -> tuple[np.ndarray, np.ndarray, float]:
    """Generate synthetic noisy SVI quotes around a known slice.

    Useful for unit tests when NSE L2 option chain is unavailable.
    """
    rng = np.random.default_rng(seed)
    truth = SVIDaySlice(a=0.04, b=0.30, rho=-0.30, m=0.0, sigma=0.10, T=T)
    k = np.linspace(-0.20, 0.20, n_strikes)
    w_truth = truth.total_variance(k)
    w_obs = w_truth + rng.normal(0, 1e-4, size=n_strikes)
    w_obs = np.clip(w_obs, 1e-4, None)
    return k, w_obs, T


# ──────────────────────────────────────────────────────────────────────────
# Convenience: build a surface from a real or synthetic option chain
# ──────────────────────────────────────────────────────────────────────────

def build_surface_from_chain(chain: dict, log_cb=None) -> SVISurface:
    """Build an SVISurface from a chain dict.

    Expected shape:
        {
          "<expiry_date>": [
              {"strike": K, "imp_vol": σ, "spot": S, "T": years},
              ...
          ],
          ...
        }

    For each expiry, the function:
      1. Computes log-moneyness k = log(K / F) where F = S * exp(r*T)
         (uses r=0.065 for India 10y G-Sec yield).
      2. Computes total variance w = σ² × T.
      3. Fits a single SVI slice via fit_svi_slice.
      4. Adds the slice to the surface.
    """
    r = 0.065  # Indian 10y G-Sec yield
    surf = SVISurface()
    for expiry, quotes in (chain or {}).items():
        if not quotes:
            continue
        try:
            T = float(quotes[0].get("T", 30 / 365))
            spot = float(quotes[0].get("spot", 1.0))
            ks, ws = [], []
            for q in quotes:
                K = float(q["strike"])
                sigma = float(q.get("imp_vol") or q.get("iv") or 0.20)
                F = spot * math.exp(r * T)
                k = math.log(K / F)
                ks.append(k)
                ws.append(sigma ** 2 * T)
            sl = fit_svi_slice(np.array(ks), np.array(ws), T)
            if sl is not None:
                surf.add_slice(T, sl)
        except Exception as e:
            msg = f"[SVI] Slice build failed for {expiry}: {e}"
            if log_cb:
                log_cb(msg)
            else:
                logger.debug(msg)
    return surf
