"""Triple-Barrier Labeling + Meta-Labeling (López de Prado).

Implements the labeling methodology from López de Prado (2018),
"Advances in Financial Machine Learning" (Wiley), Chapter 3 (Triple
Barrier Method) and Chapter 14 (Meta-Labeling).

Triple-Barrier Labeling:
    For each observation at time t_0, set three barriers around the
    price S(t_0):
        - Upper: S(t_0) * (1 + τ·σ) where τ = take-profit width
        - Lower: S(t_0) * (1 - sl·σ) where sl = stop-loss width
        - Vertical: t_0 + n_days (time-stop)

    Walk forward through the path; the label is:
        - +1 if upper barrier hit first (long winner)
        - -1 if lower barrier hit first (long loser)
         0 if vertical barrier hit first (time-stop)

    The label is direction-aware — labels are computed RELATIVE TO
    A PRIMARY MODEL'S PREDICTION, not the raw price path. This is
    "meta-labeling."

Meta-Labeling:
    Use the primary model's predicted direction as the SIDE of the
    trade; use the triple-barrier label as the target. Train a
    secondary classifier (XGBoost typically) to predict whether
    to take the primary's trade. The secondary model's probability
    output becomes the POSITION SIZE.

References:
    López de Prado, Marcos. "Advances in Financial Machine Learning."
    Wiley, 2018. (Chapters 3, 14)

    De Prado, M. L. "The 10 Reasons Most Machine Learning Funds Fail."
    Journal of Portfolio Management, 46(2):89-104, 2020.

Used by:
    ml_alpha.expanded_ensemble (post-fit meta-labeling step)
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Optional, Union

logger = logging.getLogger("quantum_annealer.triple_barrier")


# ──────────────────────────────────────────────────────────────────────────
# Triple-Barrier Labeling
# ──────────────────────────────────────────────────────────────────────────

def triple_barrier_labels(prices: pd.Series,
                            upper_width: float = 2.0,
                            lower_width: float = 2.0,
                            vertical_days: int = 10,
                            side: pd.Series | None = None,
                            use_vol: bool = True,
                            vol_window: int = 20,
                            min_period: int = 5) -> pd.Series:
    """Generate triple-barrier labels for a price series.

    Args:
        prices:         close-price series (datetime index)
        upper_width:    upper barrier width in volatility units
                        (e.g., 2.0 = ±2σ)
        lower_width:    lower barrier width in volatility units
        vertical_days:  max holding period (time-stop)
        side:           optional Series of {-1, 0, +1} from the primary
                        model. If None, defaults to long-side (+1).
        use_vol:        if True, scale barrier by exponentially-weighted
                        volatility; if False, use fixed pct barriers
        vol_window:     rolling window for EWMA vol estimation
        min_period:     minimum number of bars before labeling starts

    Returns:
        Series of labels in {-1, 0, +1} indexed by entry-time.
    """
    if isinstance(prices, pd.DataFrame):
        if "close" in prices.columns:
            prices = prices["close"]
        else:
            prices = prices.iloc[:, 0]

    prices = prices.sort_index()
    n = len(prices)

    # Compute EWMA vol if requested
    if use_vol:
        rets = prices.pct_change()
        vol = rets.ewm(span=vol_window, min_periods=min_period).std()
        # AUDIT-FIX (Round 13, ML-1): was `vol.bfill().bfill().fillna(0.015)`
        # — bfill back-propagates FUTURE realized volatility into the first
        # min_periods bars (and the doubled bfill was a typo). Barrier
        # widths at the head of every series were set with future data —
        # look-ahead bias in the labels. Forward-fill the trailing
        # estimate instead (causal), then fall back to the 1.5% default
        # only while NO estimate exists yet.
        vol = vol.ffill().fillna(0.015)
    else:
        # AUDIT-FIX (Round 6, A3-P3-15): the previous `upper_width * 0.01`
        # made the barrier s0*(1 ± upper_width*vol) quadratic in the width
        # (width 2.0 → ±4% instead of the intended ±2%). vol is a SCALE
        # FACTOR here — with use_vol=False the barrier must be exactly the
        # configured percent.
        vol = pd.Series(0.01, index=prices.index)

    if side is None:
        side = pd.Series(1, index=prices.index)

    labels = pd.Series(index=prices.index, dtype="float64")
    arr = prices.values
    vol_arr = vol.values
    side_arr = side.values

    for i in range(n - vertical_days):
        s0 = arr[i]
        sigma = vol_arr[i] if not np.isnan(vol_arr[i]) else 0.015
        s = side_arr[i] if not np.isnan(side_arr[i]) else 1.0

        upper = s0 * (1 + s * upper_width * sigma)
        lower = s0 * (1 - s * lower_width * sigma)
        end = min(i + vertical_days, n - 1)

        # Walk forward to find first barrier hit
        label = 0
        for j in range(i + 1, end + 1):
            sj = arr[j]
            if s > 0:
                if sj >= upper:
                    label = 1
                    break
                elif sj <= lower:
                    label = -1
                    break
            elif s < 0:
                if sj <= upper:
                    label = 1  # short winner
                    break
                elif sj >= lower:
                    label = -1  # short loser
                    break
        labels.iloc[i] = label

    return labels.dropna()


# ──────────────────────────────────────────────────────────────────────────
# Meta-labeling (post-primary-model secondary classifier)
# ──────────────────────────────────────────────────────────────────────────

def meta_labeling_target(primary_side: pd.Series,
                            triple_labels: pd.Series) -> pd.Series:
    """Build meta-labeling target aligned with primary side predictions.

    The target is 1 only when the primary model's prediction matches
    the realized triple-barrier label (i.e., trade was a winner).

    Args:
        primary_side:    Series of {-1, 0, +1} from primary model
        triple_labels:   Series of {-1, 0, +1} from triple_barrier_labels

    Returns:
        Binary target {0, 1} indicating whether to take the trade.
    """
    aligned = triple_labels.reindex(primary_side.index).fillna(0)
    target = ((aligned > 0) & (primary_side != 0)).astype(int)
    # If primary side is 0 (no trade), meta target is 0
    target = target.where(primary_side != 0, 0)
    return target


def fit_meta_labeler(X: pd.DataFrame, y_meta: pd.Series,
                      model_type: str = "xgboost",
                      cv_folds: int = 5,
                      event_start: Optional[pd.Series] = None,
                      event_end: Optional[pd.Series] = None,
                      sample_weights: Optional[np.ndarray] = None,
                      weight_scheme: str = "uniqueness_decay",
                      **kwargs) -> dict:
    """Fit the meta-labeling secondary classifier.

    The meta-labeler is a binary classifier that predicts P(take trade |
    primary's signal). The probability output is then used as the
    position-size scalar: position = primary_side × P_meta.

    Args:
        X:          features DataFrame (N, K)
        y_meta:     binary target from meta_labeling_target
        model_type: 'xgboost', 'lightgbm', or 'logistic'
        cv_folds:   time-series CV folds for OOS estimate
        **kwargs:   passed to underlying model constructor

    Returns:
        dict with 'model', 'oof_proba', 'oof_score'
    """
    from sklearn.model_selection import TimeSeriesSplit  # noqa: F401 (kept for API compat)
    from sklearn.metrics import roc_auc_score, accuracy_score

    # ── Round 16 (AFML ch.4): overlap-aware sample weights ──
    # Triple-barrier labels from overlapping event windows violate i.i.d.
    # sampling; unweighted fits double-count dense clusters of concurrent
    # events. When event boundaries are supplied, average-uniqueness
    # weights (López de Prado 2018 ch. 4.5) are computed and threaded into
    # every fit call below.
    effective_n = None
    mean_uniqueness = None
    w_arr = None
    if sample_weights is not None:
        w_arr = np.asarray(sample_weights, dtype=float)
        if len(w_arr) != len(y_meta):
            logger.warning("[MetaLabel] sample_weights length mismatch — ignored")
            w_arr = None
    elif event_start is not None and event_end is not None:
        try:
            from ml_alpha.sample_weights import build_sample_weights
            bw = build_sample_weights(
                event_start, event_end, scheme=weight_scheme,
                decay_halflife=kwargs.get("decay_halflife", 252.0))
            w = bw["weights"]
            if w.index.equals(y_meta.index):
                w_series = w
            elif len(w) == len(y_meta):
                # Positional alignment: events supplied in row order
                w_series = pd.Series(w.to_numpy(dtype=float), index=y_meta.index)
            else:
                w_series = None
            if w_series is not None and w_series.notna().all():
                w_arr = w_series.to_numpy(dtype=float)
                effective_n = bw.get("effective_n")
                mean_uniqueness = bw.get("mean_uniqueness")
            else:
                logger.warning("[MetaLabel] event index misaligned — weights not applied")
        except Exception:
            logger.warning("[MetaLabel] sample-weight construction failed", exc_info=True)

    if model_type == "xgboost":
        try:
            from xgboost import XGBClassifier
            model = XGBClassifier(
                n_estimators=kwargs.get("n_estimators", 200),
                max_depth=kwargs.get("max_depth", 3),
                learning_rate=kwargs.get("learning_rate", 0.05),
                subsample=kwargs.get("subsample", 0.8),
                colsample_bytree=kwargs.get("colsample_bytree", 0.8),
                random_state=kwargs.get("random_state", 42),
                eval_metric="logloss",
                use_label_encoder=False,
            )
        except ImportError:
            logger.warning("[MetaLabel] xgboost unavailable; falling back to logistic")
            from sklearn.linear_model import LogisticRegression
            model = LogisticRegression(max_iter=500, class_weight="balanced")
            model_type = "logistic"
    elif model_type == "lightgbm":
        try:
            from lightgbm import LGBMClassifier
            model = LGBMClassifier(
                n_estimators=200, max_depth=3, learning_rate=0.05,
                subsample=0.8, colsample_bytree=0.8, random_state=42,
            )
        except ImportError:
            from sklearn.linear_model import LogisticRegression
            model = LogisticRegression(max_iter=500, class_weight="balanced")
            model_type = "logistic"
    else:
        from sklearn.linear_model import LogisticRegression
        model = LogisticRegression(max_iter=500, class_weight="balanced")

    # OOS probability estimates via time-series CV
    # ROUND 7 FIX (R7-5, MEDIUM-HIGH): the previous implementation used
    #   oof_proba = cross_val_predict(model, X, y, cv=TimeSeriesSplit(...))
    # which ALWAYS raises ValueError ("cross_val_predict only works for
    # partitions") because TimeSeriesSplit test sets do not cover the
    # head of the data (the first n/(splits+1) samples are only ever in
    # training). The except-block then silently fell back to an IN-SAMPLE
    # fit — so `oof_proba` and `oos_score['auc'/'acc']`, despite their
    # names, were always computed on the model's own training data
    # (empirically verified: sklearn cross_val_predict + TimeSeriesSplit
    # raises on every call). Consumers using oof_proba for position
    # sizing were consuming contaminated in-sample probabilities.
    # Replacement: manual expanding-window out-of-fold loop identical in
    # spirit to TimeSeriesSplit (train on the past, predict the next
    # block), with a label-horizon purge so a training row's forward
    # window cannot overlap the block being predicted. Rows never
    # assigned to a test block keep NaN and are excluded from scoring.
    import copy
    _X = np.asarray(X.values if hasattr(X, "values") else X, dtype=float)
    _y = np.asarray(y_meta.values if hasattr(y_meta, "values") else y_meta)
    _n = len(_y)
    _blocks = []
    if _n >= 2 * cv_folds + 2:
        _block_size = _n // (cv_folds + 1)
        _start = _block_size
        for _b in range(cv_folds):
            _end = _start + _block_size if _b < cv_folds - 1 else _n
            _blocks.append((_start, _end))
            _start = _end

    oof_proba = np.full(_n, np.nan)
    if _blocks:
        _label_purge = int(kwargs.get("label_purge_days", 10))
        for _s, _e in _blocks:
            _train_end = max(1, _s - _label_purge)
            _fit_model = copy.deepcopy(model)
            if w_arr is not None:
                _fit_model.fit(_X[:_train_end], _y[:_train_end], sample_weight=w_arr[:_train_end])
            else:
                _fit_model.fit(_X[:_train_end], _y[:_train_end])
            oof_proba[_s:_e] = _fit_model.predict_proba(_X[_s:_e])[:, 1]
    else:
        # Too few rows for any OOS block — record honestly as in-sample
        # (degenerate datasets are labelled, not silently OOS-branded).
        logger.warning(
            "[MetaLabel] n=%d too small for OOF blocks; reporting in-sample "
            "probabilities (not out-of-sample).", _n,
        )
        if w_arr is not None:
            model.fit(_X, _y, sample_weight=w_arr)
        else:
            model.fit(_X, _y)
        oof_proba = model.predict_proba(_X)[:, 1]

    # Final fit on all data
    if w_arr is not None:
        model.fit(X.values, y_meta.values, sample_weight=w_arr)
    else:
        model.fit(X.values, y_meta.values)

    # Compute scores — R7-5: score only the rows that received a genuine
    # out-of-fold prediction (NaN rows from the un-tested head are dropped).
    oos_score = {}
    _oos_mask = np.isfinite(oof_proba)
    try:
        if len(np.unique(_y[_oos_mask])) > 1 and _oos_mask.sum() > 5:
            oos_score["auc"] = float(roc_auc_score(_y[_oos_mask], oof_proba[_oos_mask]))
            oos_score["acc"] = float(accuracy_score(_y[_oos_mask], (oof_proba[_oos_mask] > 0.5).astype(int)))
            oos_score["n_oos_rows"] = int(_oos_mask.sum())
        else:
            oos_score["auc"] = float("nan")
            oos_score["acc"] = float("nan")
            oos_score["n_oos_rows"] = int(_oos_mask.sum())
    except Exception:
        oos_score["auc"] = float("nan")
        oos_score["acc"] = float("nan")

    return {
        "model": model,
        "oof_proba": oof_proba,
        "oos_score": oos_score,
        "model_type": model_type,
        # Round 16 (AFML ch.4) provenance:
        "sample_weights": w_arr,
        "effective_n": effective_n,
        "mean_uniqueness": mean_uniqueness,
    }


# ──────────────────────────────────────────────────────────────────────────
# Convenience: end-to-end meta-labeling pipeline
# ──────────────────────────────────────────────────────────────────────────

def build_meta_pipeline(prices: pd.Series,
                         features: pd.DataFrame,
                         primary_signal: pd.Series,
                         upper_width: float = 2.0,
                         lower_width: float = 2.0,
                         vertical_days: int = 10,
                         model_type: str = "xgboost") -> dict:
    """Run triple-barrier labeling + meta-labeler fit end-to-end."""
    labels = triple_barrier_labels(
        prices,
        upper_width=upper_width,
        lower_width=lower_width,
        vertical_days=vertical_days,
        side=primary_signal,
    )
    meta_target = meta_labeling_target(primary_signal, labels)

    # Align features with labels
    common_idx = features.index.intersection(meta_target.index)
    X = features.loc[common_idx]
    y = meta_target.loc[common_idx]

    result = fit_meta_labeler(X, y, model_type=model_type)
    result["labels"] = labels
    result["meta_target"] = meta_target
    return result


if __name__ == "__main__":
    # Smoke test: synthetic GBM path, random primary signal
    rng = np.random.default_rng(42)
    n = 500
    dates = pd.bdate_range("2024-01-01", periods=n)
    log_ret = rng.normal(0.0004, 0.012, size=n)
    prices = pd.Series(np.exp(np.cumsum(log_ret)) * 100, index=dates)
    primary = pd.Series(rng.choice([-1, 0, 1], size=n, p=[0.4, 0.2, 0.4]), index=dates)
    feats = pd.DataFrame({
        "ret_1d": prices.pct_change(),
        "vol_5d": prices.pct_change().rolling(5).std(),
        "rsi_14": np.clip(50 + 50 * np.tanh(prices.pct_change().rolling(14).mean() / 0.01), 0, 100),
    }).fillna(0)
    res = build_meta_pipeline(prices, feats, primary)
    print(f"Labels: {res['labels'].value_counts().to_dict()}")
    print(f"Meta target: {res['meta_target'].value_counts().to_dict()}")
    print(f"OOS AUC: {res['oos_score'].get('auc')}")
    print(f"OOS ACC: {res['oos_score'].get('acc')}")
