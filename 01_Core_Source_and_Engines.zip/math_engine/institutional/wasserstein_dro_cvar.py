"""Distributionally Robust CVaR optimization (Wasserstein ball).

Implements the Mohajerin Esfahani & Kuhn (2018) framework
"Data-Driven Distributionally Robust Optimization Using the Wasserstein
Metric: Performance Guarantees and Tractable Reformulations",
Mathematical Programming 171(1-2):115-166.

Key result (their Theorem 4.1): the worst-case Wasserstein CVaR is the
solution of a finite-dimensional linear program:

    min_w  ξ + (1/(N·ε)) * Σ_i τ_i
    s.t.  τ_i ≥ α_i^T w * ξ_term - ξ
          τ_i ≥ 0
          w ∈ simplex

This module provides:
    * worst_case_cvar       — exact LP solver via scipy.optimize.linprog
    * dr_cvar_optimal_w     — full portfolio-weights optimizer
    * calibrate_epsilon     — empirical choice of ε (radius) via
                              bootstrap quantile (Esponda-Pouokam 2019)

It is used by:
    optimizer_risk.apply_dro_cvar_constraint (post-step in
    apply_all_compliance pipeline, applied after SEBI bounds).
"""
from __future__ import annotations

import logging
import numpy as np
from typing import Optional

logger = logging.getLogger("quantum_annealer.dro_cvar")


def calibrate_epsilon(returns: np.ndarray, q: float = 0.75,
                      n_bootstrap: int = 100, seed: int = 42) -> float:
    """Pick Wasserstein radius ε via bootstrap.

    Following Esponda-Pouokam (2019), the radius is the q-th quantile
    of the empirical 1-Wasserstein distance between the full-sample
    distribution and N bootstrap resamples of the same size.

    Defaults: q=0.75 → "conservative but not paranoid" radius.
    """
    rng = np.random.default_rng(seed)
    N, M = returns.shape
    eps_list = []
    for _ in range(n_bootstrap):
        idx = rng.integers(0, N, size=N)
        boot = returns[idx]
        # Empirical 1-Wasserstein on 1-D marginals: average across assets
        for j in range(M):
            full_sorted = np.sort(returns[:, j])
            boot_sorted = np.sort(boot[:, j])
            w1 = np.mean(np.abs(full_sorted - boot_sorted))
            eps_list.append(w1)
    eps = float(np.quantile(eps_list, q))
    return max(eps, 1e-6)


def worst_case_cvar(w: np.ndarray, returns: np.ndarray, alpha: float = 0.95,
                    epsilon: float = 0.01) -> float:
    """Compute the worst-case CVaR over a Wasserstein-1 ball of radius ε.

    Closed-form from Mohajerin Esfahani & Kuhn (2018) Example 5.2,
    combined with Rockafellar-Uryasev (2000) CVaR dual representation.

    Derivation:
        max_P CVaR_α^P(-w^T ξ)  s.t.  W_1(P, P̂_N) ≤ ε
        = min_t ( t + (1/(1-α)) * max_P E_P[max(-w^T ξ - t, 0)] )
        = min_t ( t + (1/(1-α)) * ((1/N) Σ_i max(α_i - t, 0) + ε * ||w||_∞) )
        = min_t ( t + (1/(N(1-α))) Σ_i max(α_i - t, 0) + (ε ||w||_∞)/(1-α) )

    where:
        α_i = -w^T r_i  (sample losses)
        ||w||_∞ = max-norm of weights (dual of Wasserstein-1 primal)

    This is a 1-D convex problem in t with a closed-form solution via
    sorting the sample losses.

    Args:
        w:        portfolio weights (M,)
        returns:  sample returns (N, M)
        alpha:    CVaR confidence (0.95 = 95% CVaR)
        epsilon:  Wasserstein-1 radius

    Returns:
        worst-case CVaR (a scalar in [-inf, +inf])
    """
    losses = -returns @ w            # sample losses α_i
    N = len(losses)
    eps = max(epsilon, 1e-8)
    w_inf = float(np.max(np.abs(w)))

    # Sample CVaR via the Rockafellar-Uryasev closed form.
    # For α=0.95, the CVaR is the expected loss in the worst 5% tail:
    #   CVaR = VaR + (1/(N·(1-α))) · Σ_i max(ℓ_i - VaR, 0).
    # AUDIT-FIX (Round 6, A3-P1-1): the previous aggregation was
    #   VaR + (mean_top_k - VaR)/(1-α)
    # which omits the k/N tail-mass factor — inflating the CVaR ~4.7× on
    # realistic samples (500×4 daily returns, α=0.95: 0.0854 vs the exact
    # empirical 0.0181). This feeds apply_dro_cvar_constraint (optimizer_risk)
    # and the DRO-CVaR objective itself, so every DRO constraint was ~5×
    # tighter than designed. Also fixed the FP-ceil off-by-one: ceil() of
    # (1-α)·N can round a tail of exactly k/N points up by one rank.
    losses_np = np.asarray(losses, dtype=float)
    N = len(losses_np)
    k = max(int(np.ceil((1 - alpha) * N - 1e-9)), 1)
    sorted_losses = np.sort(losses_np)[::-1]  # descending
    sample_var = float(sorted_losses[k - 1])
    tail_excess = float(np.sum(np.maximum(losses_np - sample_var, 0.0)))
    sample_cvar = sample_var + tail_excess / max(N * (1 - alpha), 1e-9)
    # (this is the standard Rockafellar-Uryasev closed form when α is not
    # exactly equal to k/N — see Rockafellar-Uryasev 2000 eq. 3.)

    # Worst-case addition: ε * ||w||_∞ / (1 - α)
    wc_penalty = (eps * w_inf) / max(1 - alpha, 1e-6)
    return sample_cvar + wc_penalty


def dr_cvar_optimal_w(returns: np.ndarray, alpha: float = 0.95,
                       epsilon: Optional[float] = None,
                       long_only: bool = True,
                       max_weight: float = 0.30,
                       min_weight: float = 0.0,
                       target_return: Optional[float] = None) -> np.ndarray:
    """Find the portfolio weights minimizing the Wasserstein worst-case CVaR.

    Uses scipy.optimize.minimize with the SLSQP solver — gradient-free
    inner LP loop. For larger portfolios (>30 assets), we recommend
    CVXPY; this implementation works fine for ≤50 assets in <5 sec.

    Args:
        returns:        (N, M) sample returns matrix
        alpha:          CVaR confidence level (0.95 = 95% CVaR)
        epsilon:        Wasserstein radius. If None, auto-calibrate via
                        bootstrap (q=0.75).
        long_only:      If True, w ≥ 0; else w ∈ [-1, 1]
        max_weight:      upper bound on each weight
        min_weight:      lower bound on each weight
        target_return:   optional minimum expected return constraint
    """
    N, M = returns.shape
    if epsilon is None:
        epsilon = calibrate_epsilon(returns, q=0.75, n_bootstrap=50)
        logger.info(f"[DRO-CVaR] Auto-calibrated ε = {epsilon:.4f}")

    try:
        from scipy.optimize import minimize
    except ImportError:
        logger.warning("[DRO-CVaR] scipy.minimize unavailable; equal-weights fallback")
        return np.ones(M) / M

    w0 = np.ones(M) / M

    def obj(w):
        # AUDIT-FIX (Round 6, A3-P3-12): the previous blanket negativity check
        # `if np.any(w < -1e-6): return 1e6` made long_only=False a silent
        # no-op — ANY short position flattened the objective to 1e6, so the
        # optimizer could never explore shorts (verified: net-short-tilted
        # assets produced all-positive ~equal weights). Penalize shorts only
        # when long_only is set; the bounds already enforce the box either way.
        if long_only and np.any(w < -1e-6):
            return 1e6
        s = w.sum()
        if s <= 1e-9:
            return 1e6
        w_n = w / s
        return worst_case_cvar(w_n, returns, alpha=alpha, epsilon=epsilon)

    constraints = [{"type": "eq", "fun": lambda w: w.sum() - 1.0}]
    if target_return is not None:
        mu = returns.mean(axis=0)
        constraints.append({
            "type": "ineq",
            "fun": lambda w: float(mu @ w) - target_return
        })

    if long_only:
        bounds = [(min_weight, max_weight)] * M
    else:
        bounds = [(-max_weight, max_weight)] * M

    res = minimize(obj, w0, method="SLSQP", bounds=bounds,
                    constraints=constraints,
                    options={"maxiter": 200, "ftol": 1e-6})
    if not res.success:
        logger.warning(f"[DRO-CVaR] Optimizer failed: {res.message}")

    w_out = res.x / np.sum(res.x)
    return w_out


# ─────────────────────────────────────────────────────────────────────────
# Convenience: end-to-end one-shot DRO-CVaR portfolio
# ─────────────────────────────────────────────────────────────────────────

def optimize_dro_cvar_portfolio(returns: np.ndarray, alpha: float = 0.95,
                                epsilon: Optional[float] = None,
                                long_only: bool = True,
                                max_weight: float = 0.30,
                                target_return: Optional[float] = None,
                                ticker_names: Optional[list] = None) -> dict:
    """Run the full DRO-CVaR optimization and return a result dict."""
    N, M = returns.shape
    if epsilon is None:
        epsilon = calibrate_epsilon(returns)

    w = dr_cvar_optimal_w(returns, alpha=alpha, epsilon=epsilon,
                          long_only=long_only, max_weight=max_weight,
                          target_return=target_return)

    port = returns @ w
    # AUDIT-FIX (Round 6, A3-P3-11): sample_cvar was previously the mean of
    # the worst RETURNS (negative) while worst_case_cvar is a positive loss —
    # subtracting them produced a nonsense premium (0.078 vs the true 0.045).
    # Both terms are now in loss space; the int((1-α)·N) empty-slice NaN is
    # guarded too.
    _k = max(int(np.floor((1 - alpha) * N)), 1)
    sample_cvar = float(-np.mean(np.sort(port)[:_k]))
    wc_cvar = float(worst_case_cvar(w, returns, alpha=alpha, epsilon=epsilon))

    return {
        "weights": w.tolist(),
        "tickers": ticker_names or [f"S{i}" for i in range(M)],
        "alpha": alpha,
        "epsilon": epsilon,
        "sample_cvar": sample_cvar,
        "worst_case_cvar": wc_cvar,
        "robustness_premium": wc_cvar - sample_cvar,
    }


if __name__ == "__main__":
    # Quick smoke test
    rng = np.random.default_rng(42)
    N, M = 200, 8
    R = rng.normal(0.0005, 0.015, size=(N, M))
    print("Auto-calibrating ε...")
    eps = calibrate_epsilon(R, n_bootstrap=20)
    print(f"  ε = {eps:.4f}")
    res = optimize_dro_cvar_portfolio(R, epsilon=eps, alpha=0.95)
    print(f"  weights = {res['weights']}")
    print(f"  sample_cvar = {res['sample_cvar']:.4f}")
    print(f"  worst_case_cvar = {res['worst_case_cvar']:.4f}")
    print(f"  robustness_premium = {res['robustness_premium']:.4f}")
