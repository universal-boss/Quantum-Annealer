"""
math_engine/institutional_operators.py
======================================
Domain I: Institutional Alpha Signal Engineering & Factor Operators (Criteria 1-30).
High-performance vectorized implementations for Microstructure, Quality/Solvency,
and Technical/Geometric factor operators.
"""
from __future__ import annotations

import logging
from typing import Dict, List, Tuple, Optional, Any, Union
import numpy as np
import pandas as pd
from scipy import stats

logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# 1. Microstructure & Order Flow Toxicity Metrics (Criteria 1-10)
# ══════════════════════════════════════════════════════════════════════════════

def compute_kyles_lambda(prices: Union[pd.Series, np.ndarray], volume: Union[pd.Series, np.ndarray]) -> float:
    """1. Kyle's Lambda (Price impact per unit of flow): lambda = Cov(Delta P, Q) / Var(Q)"""
    p = np.asarray(prices, dtype=float)
    v = np.asarray(volume, dtype=float)
    if len(p) < 3 or len(v) < 3:
        return None  # Insufficient data — Kyle's Lambda cannot be estimated
    delta_p = np.diff(p)
    # Signed volume approximation: sign(delta_p) * volume
    signed_flow = np.sign(delta_p) * v[1:]
    var_flow = np.var(signed_flow)
    if var_flow < 1e-12:
        return None  # Zero flow variance — Lambda undefined (no order flow signal)
    cov_p_flow = np.cov(delta_p, signed_flow)[0, 1]
    lambda_val = float(cov_p_flow / (var_flow + 1e-9))
    return float(np.clip(lambda_val, 1e-6, 10.0))


def compute_vpin(close: Union[pd.Series, np.ndarray], volume: Union[pd.Series, np.ndarray], n_buckets: int = 50) -> float:
    """2. Volume-Synchronized Probability of Toxicity (VPIN): VPIN = Sum|V_b - V_s| / (N * V)"""
    c = np.asarray(close, dtype=float)
    v = np.asarray(volume, dtype=float)
    if len(c) < 10 or len(v) < 10:
        return None  # Insufficient data — VPIN cannot be computed
    delta_p = np.diff(c)
    vol = v[1:]
    total_vol = np.sum(vol)
    if total_vol <= 0 or n_buckets <= 0:
        return None  # Zero volume — VPIN undefined
    bucket_vol = total_vol / n_buckets
    if bucket_vol <= 0:
        return None  # Degenerate bucket size — VPIN undefined

    # Classify volume via tick rule
    # delta_p > 0 => buy volume, delta_p < 0 => sell volume, delta_p == 0 => split 50/50
    buy_vol = np.where(delta_p > 0, vol, np.where(delta_p < 0, 0.0, vol * 0.5))
    sell_vol = vol - buy_vol

    # Aggregate into volume buckets
    cum_vol = np.cumsum(vol)
    bucket_indices = np.clip(np.floor(cum_vol / bucket_vol).astype(int), 0, n_buckets - 1)
    
    bucket_imbalances = []
    for b in range(n_buckets):
        mask = (bucket_indices == b)
        if np.any(mask):
            b_buy = np.sum(buy_vol[mask])
            b_sell = np.sum(sell_vol[mask])
            bucket_imbalances.append(abs(b_buy - b_sell))
            
    if not bucket_imbalances:
        return None  # No populated buckets — VPIN cannot be computed
    vpin = float(np.sum(bucket_imbalances) / (len(bucket_imbalances) * bucket_vol + 1e-9))
    return float(np.clip(vpin, 0.0, 1.0))


def compute_order_flow_imbalance(
    bid_p: Union[pd.Series, np.ndarray],
    bid_v: Union[pd.Series, np.ndarray],
    ask_p: Union[pd.Series, np.ndarray],
    ask_v: Union[pd.Series, np.ndarray]
) -> float:
    """3. Order Flow Imbalance (OFI): Net continuous demand at the best bid/ask quotes."""
    bp, bv = np.asarray(bid_p, dtype=float), np.asarray(bid_v, dtype=float)
    ap, av = np.asarray(ask_p, dtype=float), np.asarray(ask_v, dtype=float)
    n = min(len(bp), len(bv), len(ap), len(av))
    if n < 2:
        return 0.0
    
    delta_bv = np.zeros(n - 1)
    delta_av = np.zeros(n - 1)
    for t in range(1, n):
        if bp[t] > bp[t-1]:
            delta_bv[t-1] = bv[t]
        elif bp[t] == bp[t-1]:
            delta_bv[t-1] = bv[t] - bv[t-1]
        else:
            delta_bv[t-1] = -bv[t-1]
            
        if ap[t] < ap[t-1]:
            delta_av[t-1] = av[t]
        elif ap[t] == ap[t-1]:
            delta_av[t-1] = av[t] - av[t-1]
        else:
            delta_av[t-1] = -av[t-1]
            
    ofi_series = delta_bv - delta_av
    total_flow = np.sum(np.abs(delta_bv) + np.abs(delta_av)) + 1e-9
    normalized_ofi = float(np.sum(ofi_series) / total_flow)
    return float(np.clip(normalized_ofi, -1.0, 1.0))


def compute_hasbrouck_informativeness(midpoints: Union[pd.Series, np.ndarray], trades: Union[pd.Series, np.ndarray]) -> float:
    """4. Hasbrouck Trade Informativeness: Ratio of permanent quote revision variance to total variance."""
    m = np.asarray(midpoints, dtype=float)
    q = np.asarray(trades, dtype=float)
    if len(m) < 10 or len(q) < 10:
        return None  # Insufficient data — Hasbrouck informativeness cannot be estimated
    delta_m = np.diff(np.log(np.clip(m, 1e-4, None)))
    signed_q = np.sign(q[1:])
    if np.var(delta_m) < 1e-12:
        return 0.0  # Zero midpoint variance — no trade informativeness (R²=0 is correct)
    # OLS regression delta_m on signed trade flow
    slope, intercept, r_value, p_value, std_err = stats.linregress(signed_q, delta_m)
    r_squared = float(r_value ** 2)
    return float(np.clip(r_squared, 0.0, 1.0))


def compute_amihud_illiquidity(returns: Union[pd.Series, np.ndarray], turnover_cr: Union[pd.Series, np.ndarray]) -> float:
    """5. Amihud Illiquidity Ratio: Mean(|R_d| / Turnover_d) scaled to bps per Crore."""
    r = np.asarray(returns, dtype=float)
    to = np.asarray(turnover_cr, dtype=float)
    n = min(len(r), len(to))
    if n == 0:
        return None  # Insufficient data — Amihud illiquidity cannot be computed
    r, to = r[-n:], to[-n:]
    valid = (to > 1e-4) & np.isfinite(r)
    if not np.any(valid):
        return None  # No valid (return, turnover) pairs — Amihud ratio undefined
    ratio = np.abs(r[valid]) / to[valid]
    return float(np.median(ratio))


def compute_rolls_effective_spread(prices: Union[pd.Series, np.ndarray]) -> float:
    """6. Roll's Effective Bid-Ask Spread: S = 2 * sqrt(-Cov(Delta P_t, Delta P_{t-1}))"""
    p = np.asarray(prices, dtype=float)
    if len(p) < 5:
        return None  # Insufficient data — Roll spread cannot be computed
    dp = np.diff(p)
    cov = np.cov(dp[:-1], dp[1:])[0, 1]
    if cov < 0:
        spread = 2.0 * np.sqrt(-cov)
        p_mean = np.mean(p)
        return float(spread / (p_mean + 1e-9))
    else:
        return 0.0  # Positive autocovariance — Roll model implies zero implied spread (correct)


def compute_corwin_schultz_spread(high: Union[pd.Series, np.ndarray], low: Union[pd.Series, np.ndarray]) -> float:
    """7. Corwin-Schultz High-Low Spread Estimator from consecutive 2-day high-low prices."""
    h = np.asarray(high, dtype=float)
    l = np.asarray(low, dtype=float)
    if len(h) < 4 or len(l) < 4:
        return None  # Insufficient data — Corwin-Schultz spread cannot be computed
    
    # 2-day high-low ratios
    gamma = [float(np.log(max(h[t], h[t-1]) / min(l[t], l[t-1])) ** 2) for t in range(1, len(h))]
    beta = [float(np.log(h[t]/l[t])**2 + np.log(h[t-1]/l[t-1])**2) for t in range(1, len(h))]
    
    gamma_mean = np.mean(gamma)
    beta_mean = np.mean(beta)
    
    denom = 3.0 - 2.0 * np.sqrt(2.0)
    alpha = (np.sqrt(2.0 * beta_mean) - np.sqrt(beta_mean)) / denom - np.sqrt(gamma_mean / denom)
    
    if alpha < 0:
        return 0.0  # Negative alpha — Corwin-Schultz implies zero spread (correct)
    spread = 2.0 * (np.exp(alpha) - 1.0) / (1.0 + np.exp(alpha))
    return float(np.clip(spread, 0.0001, 0.20))


def compute_cmf_density(high: Union[pd.Series, np.ndarray], low: Union[pd.Series, np.ndarray], close: Union[pd.Series, np.ndarray], volume: Union[pd.Series, np.ndarray], window: int = 20) -> float:
    """8. Chaikin Money Flow (CMF) Density: Sum(((C - L) - (H - C))/(H - L) * V) / Sum(V)"""
    h, l, c, v = np.asarray(high, dtype=float), np.asarray(low, dtype=float), np.asarray(close, dtype=float), np.asarray(volume, dtype=float)
    n = min(len(h), len(l), len(c), len(v))
    if n < window or window <= 0:
        return 0.0
    h_w, l_w, c_w, v_w = h[-window:], l[-window:], c[-window:], v[-window:]
    hl_range = h_w - l_w
    mf_mult = np.where(hl_range > 1e-9, ((c_w - l_w) - (h_w - c_w)) / (hl_range + 1e-9), 0.0)
    mf_vol = mf_mult * v_w
    tot_vol = np.sum(v_w)
    if tot_vol <= 0:
        return 0.0
    cmf = float(np.sum(mf_vol) / (tot_vol + 1e-9))
    return float(np.clip(cmf, -1.0, 1.0))


def compute_obv_linear_drift(close: Union[pd.Series, np.ndarray], volume: Union[pd.Series, np.ndarray], window: int = 20) -> float:
    """9. On-Balance Volume (OBV) Linear Drift: Normalized 1st-order OLS slope of cumulative volume."""
    c, v = np.asarray(close, dtype=float), np.asarray(volume, dtype=float)
    if len(c) < window or len(v) < window:
        return 0.0
    c_w, v_w = c[-window:], v[-window:]
    diff_c = np.diff(c_w)
    signed_v = np.where(diff_c > 0, v_w[1:], np.where(diff_c < 0, -v_w[1:], 0.0))
    obv = np.cumsum(signed_v)
    if len(obv) < 3 or np.std(obv) < 1e-9:
        return 0.0
    x = np.arange(len(obv))
    slope, _, _, _, _ = stats.linregress(x, obv)
    norm_slope = slope / (np.mean(v_w) + 1e-9)
    return float(np.clip(norm_slope, -5.0, 5.0))


def compute_delivery_spike_intensity(delivery_qty: Union[pd.Series, np.ndarray], window: int = 20) -> float:
    """10. Delivery Volume Spike Intensity: Ratio of latest delivery quantity to 20-day rolling median."""
    d = np.asarray(delivery_qty, dtype=float)
    if len(d) < window or window <= 0:
        return 1.0
    median_del = np.median(d[-window:-1]) if len(d) > 1 else d[-1]
    if median_del <= 0:
        return 1.0
    spike_ratio = float(d[-1] / (median_del + 1e-9))
    return float(np.clip(spike_ratio, 0.0, 10.0))


# ══════════════════════════════════════════════════════════════════════════════
# 2. Fundamental Quality, Solvency & Earnings Momentum (Criteria 11-20)
# ══════════════════════════════════════════════════════════════════════════════

def compute_piotroski_f_score(fin: Dict[str, Any]) -> int:
    """11. Piotroski F-Score (9 Boolean Criteria): Profitability, Leverage, and Operating Efficiency."""
    score = 0
    # Profitability (4 points)
    if fin.get("net_income", 0) > 0: score += 1
    if fin.get("roa", 0) > 0: score += 1
    if fin.get("cfo", 0) > 0: score += 1
    if fin.get("cfo", 0) > fin.get("net_income", 0): score += 1
    
    # Leverage, Liquidity and Source of Funds (3 points)
    if fin.get("delta_long_term_debt", 0) <= 0: score += 1
    if fin.get("delta_current_ratio", 0) > 0: score += 1
    if fin.get("delta_shares_outstanding", 0) <= 0: score += 1
    
    # Operating Efficiency (2 points)
    if fin.get("delta_gross_margin", 0) > 0: score += 1
    if fin.get("delta_asset_turnover", 0) > 0: score += 1
    return int(np.clip(score, 0, 9))


def compute_altman_z_score(
    working_cap: float, total_assets: float, retained_earnings: float,
    ebit: float, market_cap: float, total_liab: float, sales: float
) -> float:
    """12. Altman Z-Score: Z = 1.2*X1 + 1.4*X2 + 3.3*X3 + 0.6*X4 + 0.999*X5"""
    ta = max(total_assets, 1.0)
    tl = max(total_liab, 1.0)
    x1 = working_cap / ta
    x2 = retained_earnings / ta
    x3 = ebit / ta
    x4 = market_cap / tl
    x5 = sales / ta
    z = 1.2 * x1 + 1.4 * x2 + 3.3 * x3 + 0.6 * x4 + 0.999 * x5
    return float(np.clip(z, -5.0, 20.0))


def compute_beneish_m_score(
    dsri: float = 1.0, gmi: float = 1.0, aqi: float = 1.0, sgi: float = 1.0,
    depi: float = 1.0, sgai: float = 1.0, lvgi: float = 1.0, tata: float = 0.0
) -> float:
    """13. Beneish M-Score (Earnings Manipulation Index):
    M = -4.84 + 0.920*DSRI + 0.528*GMI + 0.404*AQI + 0.892*SGI + 0.115*DEPI - 0.172*SGAI + 4.037*TATA + 0.0327*LVGI
    """
    m = (-4.84 + 0.920 * dsri + 0.528 * gmi + 0.404 * aqi + 0.892 * sgi 
         + 0.115 * depi - 0.172 * sgai + 4.037 * tata + 0.0327 * lvgi)
    return float(m)


def compute_roic_wacc_spread(roic: float, wacc: float) -> float:
    """14. Return on Invested Capital Spread: ROIC - WACC (EVA Generation)."""
    return float(roic - wacc)


def compute_sloan_accruals(
    delta_ca: float, delta_cash: float, delta_cl: float,
    delta_std: float, delta_tp: float, dep: float, total_assets: float
) -> float:
    """15. Accruals Quality (Sloan Ratio):
    Accruals = ((Delta CA - Delta Cash) - (Delta CL - Delta STD - Delta TP) - Dep) / Total Assets
    """
    ta = max(total_assets, 1.0)
    accruals = ((delta_ca - delta_cash) - (delta_cl - delta_std - delta_tp) - dep) / ta
    return float(np.clip(accruals, -1.0, 1.0))


def compute_cf_to_ev(fcf: float, enterprise_value: float) -> float:
    """16. Cash Flow to Enterprise Value (CF / EV): Unlevered free cash flow yield."""
    ev = max(enterprise_value, 1.0)
    return float(fcf / ev)


def compute_sue(eps_actual: float, eps_expected: float, eps_std: float) -> float:
    """17. Standardized Unexpected Earnings (SUE): (EPS_t - E[EPS_t]) / sigma(EPS)"""
    denom = max(eps_std, 0.01)
    sue = (eps_actual - eps_expected) / denom
    return float(np.clip(sue, -5.0, 5.0))


def compute_asset_turnover_acceleration(sales_series: List[float], assets_series: List[float]) -> float:
    """18. Asset Turnover Acceleration (Delta ATO): Second derivative of sales-to-assets."""
    if len(sales_series) < 3 or len(assets_series) < 3:
        return 0.0
    ato = [s / max(a, 1.0) for s, a in zip(sales_series, assets_series)]
    d1 = np.diff(ato)
    d2 = np.diff(d1)
    return float(d2[-1]) if len(d2) > 0 else 0.0


def compute_gross_margin_expansion_drift(margin_series: List[float]) -> float:
    """19. Gross Margin Expansion Drift: OLS slope across trailing quarterly gross margins."""
    m = np.asarray(margin_series, dtype=float)
    if len(m) < 3:
        return 0.0
    x = np.arange(len(m))
    slope, _, _, _, _ = stats.linregress(x, m)
    return float(slope)


def compute_debt_to_ebitda_deleveraging_velocity(debt_series: List[float], ebitda_series: List[float]) -> float:
    """20. Debt-to-EBITDA Deleveraging Velocity: Negative rate of change in net debt / EBITDA."""
    if len(debt_series) < 2 or len(ebitda_series) < 2:
        return 0.0
    ratios = [d / max(eb, 1e-4) for d, eb in zip(debt_series, ebitda_series)]
    # Deleveraging velocity is negative of ratio delta (positive = good deleveraging)
    velocity = -(ratios[-1] - ratios[0]) / len(ratios)
    return float(velocity)


# ══════════════════════════════════════════════════════════════════════════════
# 3. Technical, Volatility Contraction & Spatial Geometry (Criteria 21-30)
# ══════════════════════════════════════════════════════════════════════════════

def compute_vcp_squeeze_ratio(high: Union[pd.Series, np.ndarray], low: Union[pd.Series, np.ndarray], close: Union[pd.Series, np.ndarray], window: int = 20) -> float:
    """21. Volatility Contraction Pattern (VCP) Squeeze Metric: (ATR_5 / ATR_20) * (BB_Width_20 / Keltner_Width_20)"""
    h, l, c = np.asarray(high, dtype=float), np.asarray(low, dtype=float), np.asarray(close, dtype=float)
    n = min(len(h), len(l), len(c))
    if n < window + 5:
        return 0.50
    tr = np.maximum(h[1:] - l[1:], np.maximum(np.abs(h[1:] - c[:-1]), np.abs(l[1:] - c[:-1])))
    atr_5 = np.mean(tr[-5:]) if len(tr) >= 5 else 1.0
    atr_20 = np.mean(tr[-window:]) if len(tr) >= window else 1.0
    
    std_20 = np.std(c[-window:])
    bb_width = (4.0 * std_20) / (np.mean(c[-window:]) + 1e-9)
    keltner_width = (2.0 * atr_20) / (np.mean(c[-window:]) + 1e-9)
    
    vcp_ratio = (atr_5 / (atr_20 + 1e-9)) * (bb_width / (keltner_width + 1e-9))
    return float(np.clip(vcp_ratio, 0.01, 5.0))


def compute_residual_momentum(returns_i: Union[pd.Series, np.ndarray], market_returns: Union[pd.Series, np.ndarray], smb: Optional[np.ndarray] = None, hml: Optional[np.ndarray] = None) -> float:
    """22. Residual Momentum (R_Residual): Fama-French 3-factor regression residual mean."""
    r_i = np.asarray(returns_i, dtype=float)
    r_m = np.asarray(market_returns, dtype=float)
    n = min(len(r_i), len(r_m))
    if n < 20:
        return 0.0
    r_i, r_m = r_i[-n:], r_m[-n:]
    
    if smb is not None and hml is not None and len(smb) >= n and len(hml) >= n:
        X = np.column_stack([np.ones(n), r_m, smb[-n:], hml[-n:]])
    else:
        X = np.column_stack([np.ones(n), r_m])
        
    try:
        beta = np.linalg.lstsq(X, r_i, rcond=None)[0]
        residuals = r_i - (X @ beta)
        res_mom = float(np.mean(residuals[-20:]) / (np.std(residuals) + 1e-9))
        return float(np.clip(res_mom, -3.0, 3.0))
    except Exception:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
        return 0.0


def compute_fractal_dimension_index(close: Union[pd.Series, np.ndarray], window: int = 30) -> float:
    """23. Fractal Dimension Index (FDI): D = 1 + (log(L) + log(2)) / log(2*N)"""
    c = np.asarray(close, dtype=float)
    if len(c) < window or window <= 1:
        return None  # Insufficient data — Fractal Dimension Index cannot be computed
    c_w = c[-window:]
    p_min = np.min(c_w)
    p_max = np.max(c_w)
    if p_max - p_min < 1e-9:
        return 1.0
    # Normalize price series
    norm_p = (c_w - p_min) / (p_max - p_min)
    length = 0.0
    for i in range(1, window):
        length += np.sqrt((norm_p[i] - norm_p[i-1])**2 + (1.0 / window)**2)
    fdi = 1.0 + (np.log(max(length, 1e-6)) + np.log(2.0)) / np.log(2.0 * window)
    return float(np.clip(fdi, 1.0, 2.0))


def compute_hurst_exponent(price_series: Union[pd.Series, np.ndarray], max_lag: int = 20) -> float:
    """24. Hurst Exponent (H): Rescaled range analysis determining mean-reversion (H<0.5) vs trend (H>0.5)."""
    p = np.asarray(price_series, dtype=float)
    if len(p) < 40:
        return 0.50
    rets = np.diff(np.log(np.clip(p, 1e-4, None)))
    lags = range(4, min(max_lag, len(rets) // 2))
    tau = []
    rs = []
    for lag in lags:
        sub_samples = len(rets) // lag
        rs_sub = []
        for i in range(sub_samples):
            sub = rets[i * lag : (i + 1) * lag]
            mean_adj = sub - np.mean(sub)
            cum_dev = np.cumsum(mean_adj)
            r = np.max(cum_dev) - np.min(cum_dev)
            s = np.std(sub)
            if s > 1e-9:
                rs_sub.append(r / s)
        if rs_sub:
            tau.append(lag)
            rs.append(np.mean(rs_sub))
    if len(tau) < 3:
        return 0.50
    poly = np.polyfit(np.log(tau), np.log(rs), 1)
    hurst = float(poly[0])
    return float(np.clip(hurst, 0.05, 0.95))


def compute_neural_sde_drift_diffusion(prices: Union[pd.Series, np.ndarray], dt: float = 1.0) -> Tuple[float, float, float]:
    """25. Neural-SDE Drift-to-Diffusion (mu / sigma): Continuous-time trend efficiency metric."""
    p = np.asarray(prices, dtype=float)
    if len(p) < 10:
        return 0.0, 0.01, 0.0
    log_p = np.log(np.clip(p, 1e-4, None))
    d_log_p = np.diff(log_p)
    mu = float(np.mean(d_log_p) / dt)
    sigma = float(np.std(d_log_p) / np.sqrt(dt))
    ratio = float(mu / (sigma + 1e-9))
    return mu, sigma, ratio


def compute_kaufman_efficiency_ratio(close: Union[pd.Series, np.ndarray], window: int = 10) -> float:
    """26. Kaufman Efficiency Ratio (KER): Directional displacement divided by total path length."""
    c = np.asarray(close, dtype=float)
    if len(c) < window + 1:
        return None  # Insufficient data — Kaufman Efficiency Ratio cannot be computed
    c_w = c[-(window + 1):]
    direction = abs(c_w[-1] - c_w[0])
    volatility = np.sum(np.abs(np.diff(c_w)))
    if volatility <= 1e-9:
        return 0.0
    ker = float(direction / volatility)
    return float(np.clip(ker, 0.0, 1.0))


def compute_relative_strength_rating(close: Union[pd.Series, np.ndarray], bench_close: Union[pd.Series, np.ndarray]) -> int:
    """27. Relative Strength (RS Rating): 1-year weighted return vs benchmark scaled to decile (1-99)."""
    c = np.asarray(close, dtype=float)
    b = np.asarray(bench_close, dtype=float)
    n = min(len(c), len(b))
    if n < 60:
        return 50
    c_n, b_n = c[-n:], b[-n:]
    
    # 40% 3M, 20% 6M, 20% 9M, 20% 12M
    ret_c = (c_n[-1] / c_n[0]) - 1.0
    ret_b = (b_n[-1] / b_n[0]) - 1.0
    excess_ret = ret_c - ret_b
    
    # Sigmoidal mapping to 1-99
    score = int(1.0 / (1.0 + np.exp(-5.0 * excess_ret)) * 98.0 + 1.0)
    return int(np.clip(score, 1, 99))


def compute_donchian_breakout_velocity(high: Union[pd.Series, np.ndarray], low: Union[pd.Series, np.ndarray], close: Union[pd.Series, np.ndarray], window: int = 252) -> float:
    """28. Donchian Channel Breakout Velocity: Standard deviations above channel midpoint."""
    h, l, c = np.asarray(high, dtype=float), np.asarray(low, dtype=float), np.asarray(close, dtype=float)
    n = min(len(h), len(l), len(c))
    if n < 20:
        return 0.0
    w = min(window, n)
    h_max = np.max(h[-w:])
    l_min = np.min(l[-w:])
    mid = (h_max + l_min) / 2.0
    spread = (h_max - l_min) / 2.0
    if spread <= 1e-9:
        return 0.0
    velocity = float((c[-1] - mid) / spread)
    return float(np.clip(velocity, -2.0, 2.0))


def compute_volume_dryup_index(volume: Union[pd.Series, np.ndarray], base_window: int = 50, dry_window: int = 5) -> float:
    """29. Volume Dry-Up Index (VDU): Minimum 5-day volume as a fraction of 50-day average during consolidation."""
    v = np.asarray(volume, dtype=float)
    if len(v) < base_window or base_window <= 0 or dry_window <= 0:
        return None  # Insufficient data — Volume Dry-Up Index cannot be computed
    avg_vol = np.mean(v[-base_window:])
    if avg_vol <= 0:
        return None  # Zero base volume — VDU undefined
    min_dry_vol = np.min(v[-dry_window:])
    vdu = float(min_dry_vol / (avg_vol + 1e-9))
    return float(np.clip(vdu, 0.0, 2.0))


def compute_ma_ribbon_compression(close: Union[pd.Series, np.ndarray], periods: Tuple[int, ...] = (10, 20, 50, 100, 200)) -> float:
    """30. Moving Average Ribbon Compression: Dispersion of exponential moving averages normalized by price."""
    c = np.asarray(close, dtype=float)
    if len(c) < max(periods):
        return None  # Insufficient history — MA Ribbon Compression cannot be computed
    s = pd.Series(c)
    mas = [float(s.ewm(span=p).mean().iloc[-1]) for p in periods]
    dispersion = float(np.std(mas) / (np.mean(mas) + 1e-9))
    return float(dispersion)
