"""
math_engine/institutional_tca.py
================================
Domain V: Execution Mathematics & Transaction Cost Analytics (Criteria 66-75).
High-performance algorithms for Almgren-Chriss liquidation schedules, Square-Root law,
Perold's 4-way Implementation Shortfall decomposition, Kissell-Glantz non-linear impact,
VPIN-adaptive participation rates, Iceberg shadow decay, Avellaneda-Stoikov limit spreads,
Broker routing optimization, Corporate action blackout filters, and Volatility-clamped slippage.
"""
from __future__ import annotations

import logging
from typing import Dict, List, Tuple, Optional, Any, Union
import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


def almgren_chriss_optimal_trajectory(
    total_qty: float,
    n_slices: int = 5,
    sigma: float = 0.015,
    lambda_impact: float = 1e-6,
    eta_transitory: float = 2.5e-6,
    risk_aversion: float = 1e-6
) -> np.ndarray:
    """66. Almgren-Chriss Optimal Liquidation Trajectory: x_j = sinh(kappa * (T - t_j)) / sinh(kappa * T) * X."""
    if n_slices <= 1:
        return np.array([float(total_qty)])
    T = float(n_slices)
    # Urgency parameter kappa:
    kappa_sq = (risk_aversion * (sigma ** 2)) / max(eta_transitory, 1e-9)
    kappa = float(np.sqrt(max(kappa_sq, 1e-6)))
    
    t = np.arange(n_slices + 1)
    holdings = total_qty * np.sinh(kappa * (T - t)) / (np.sinh(kappa * T) + 1e-9)
    # Trade slices are difference between successive holdings
    slices = -np.diff(holdings)
    return np.maximum(0.0, slices)


def square_root_market_impact_bps(
    trade_qty: float,
    adv: float,
    daily_vol: float = 0.015,
    y_coeff: float = 1.5
) -> float:
    """67. Square-Root Law of Market Impact: Impact_bps = Y * sigma_daily * sqrt(Q / ADV) * 10000."""
    adv_safe = max(adv, 1.0)
    qty_frac = float(trade_qty) / adv_safe
    impact = y_coeff * float(daily_vol) * float(np.sqrt(max(0.0, qty_frac)))
    return float(impact * 10000.0)


def perold_implementation_shortfall_decomp(
    p_decision: float,
    p_arrival: float,
    fills_prices: List[float],
    fills_quantities: List[float],
    p_close: float,
    target_qty: float
) -> Dict[str, float]:
    """68. Perold's Implementation Shortfall Decomposition (Delay, Impact, Opportunity)."""
    p_d = float(p_decision)
    p_a = float(p_arrival)
    p_c = float(p_close)
    q_tot = float(target_qty)
    
    fills_p = np.asarray(fills_prices, dtype=float)
    fills_q = np.asarray(fills_quantities, dtype=float)
    q_filled = float(np.sum(fills_q))
    q_unfilled = max(0.0, q_tot - q_filled)
    
    if q_filled > 0:
        p_exec = float(np.sum(fills_p * fills_q) / q_filled)
    else:
        p_exec = p_a
        
    delay_cost = (p_a - p_d) * q_filled
    impact_cost = (p_exec - p_a) * q_filled
    opp_cost = (p_c - p_d) * q_unfilled
    total_is = delay_cost + impact_cost + opp_cost
    
    return {
        "delay_cost_inr": float(delay_cost),
        "impact_cost_inr": float(impact_cost),
        "opportunity_cost_inr": float(opp_cost),
        "total_implementation_shortfall_inr": float(total_is),
        "is_bps": float((total_is / (p_d * q_tot + 1e-9)) * 10000.0)
    }


def kissell_glantz_nonlinear_impact(
    trade_qty: float,
    adv: float,
    volatility: float,
    spread_bps: float = 10.0,
    participation_rate: float = 0.10
) -> Dict[str, float]:
    """69. Kissell-Glantz Non-Linear Market Impact Engine (Instantaneous vs. Persistent dislocation)."""
    pov = min(max(participation_rate, 0.01), 0.50)
    inst_impact_bps = 0.5 * spread_bps + 0.3 * (volatility * 10000.0) * (pov ** 0.6)
    perm_impact_bps = 0.2 * (volatility * 10000.0) * float(np.sqrt(trade_qty / max(adv, 1.0)))
    total_impact = inst_impact_bps + perm_impact_bps
    return {
        "instantaneous_impact_bps": float(inst_impact_bps),
        "permanent_impact_bps": float(perm_impact_bps),
        "total_impact_bps": float(total_impact)
    }


def vpin_adaptive_participation_rate(
    base_rate: float = 0.10,
    vpin_score: float = 0.20,
    ofi_score: float = 0.0,
    alpha_vpin: float = 0.5,
    beta_ofi: float = 0.3
) -> float:
    """70. VPIN Toxicity-Adjusted Participation Rate: pi*(t) = pi_base * (1 - alpha*VPIN) * (1 + beta*OFI)."""
    rate = base_rate * (1.0 - alpha_vpin * np.clip(vpin_score, 0.0, 1.0)) * (1.0 + beta_ofi * np.clip(ofi_score, -1.0, 1.0))
    return float(np.clip(rate, 0.01, 0.50))


def dark_pool_iceberg_shadow_decay(shadow_size: float, display_size: float, decay_rate: float = 0.2) -> float:
    """71. Dark Pool & Iceberg Shadow Size Decay: Expected fill rate accounting for hidden liquidity."""
    hidden = max(0.0, shadow_size - display_size)
    fill_prob = float(np.exp(-decay_rate * (hidden / max(display_size, 1.0))))
    return float(fill_prob)


def avellaneda_stoikov_optimal_spread(
    gamma_risk: float = 0.1,
    sigma_vol: float = 0.015,
    kappa_order_arrival: float = 1.5,
    horizon: float = 1.0
) -> float:
    """72. Avellaneda-Stoikov Optimal Limit Spread: delta^a + delta^b = gamma*sigma^2 + 2/gamma * ln(1 + gamma/kappa)."""
    term1 = gamma_risk * (sigma_vol ** 2) * horizon
    term2 = (2.0 / gamma_risk) * np.log(1.0 + gamma_risk / max(kappa_order_arrival, 1e-4))
    optimal_spread = float(term1 + term2)
    return float(optimal_spread)


def broker_routing_cost_minimizer(
    venues_costs: List[float],
    venues_latencies: List[float],
    venues_fill_rates: List[float]
) -> int:
    """73. Broker Routing Minimum Cost Optimization: Selects venue minimizing cost + latency penalty - fill rebate."""
    costs = np.asarray(venues_costs, dtype=float)
    lats = np.asarray(venues_latencies, dtype=float)
    fills = np.asarray(venues_fill_rates, dtype=float)
    
    score = costs + 0.1 * lats - 50.0 * fills
    best_venue = int(np.argmin(score))
    return best_venue


def corporate_actions_blackout_filter(
    ex_dates: List[str],
    current_date: str,
    blackout_days: int = 3
) -> bool:
    """74. Corporate Actions Blackout Filter (T-3 to T+1): Returns True if within blackout window."""
    curr = pd.to_datetime(current_date)
    for ex in ex_dates:
        ex_dt = pd.to_datetime(ex)
        diff = (curr - ex_dt).days
        if -blackout_days <= diff <= 1:
            return True
    return False


def slippage_bps_volatility_clamped(
    base_fee_bps: float = 15.0,
    effective_spread_bps: float = 10.0,
    daily_vol: float = 0.015,
    dt_days: float = 1.0
) -> float:
    """75. Slippage BPS Estimator with Volatility Clamping: Slip = max(Fee, Spread + sigma*sqrt(dt))."""
    vol_slip_bps = (daily_vol * np.sqrt(dt_days)) * 10000.0
    total_slip = max(base_fee_bps, effective_spread_bps + 0.5 * vol_slip_bps)
    return float(total_slip)
