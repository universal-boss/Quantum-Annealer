"""
math_engine/ipo_multibagger_math.py
====================================
Institutional mathematics core for the 🦄 High-Growth IPO · Multibagger Hunter
profile (Round 35).

ROUND 35 — "Institutional Mathematics & ML Upgrade"
----------------------------------------------------
This module implements the estimation and decision mathematics that
institutional systematic equity shops (Citadel / Millennium-style pod risk,
Two Sigma-style stacked models, Qube-style execution realism) apply around a
small-cap IPO / multibagger thesis:

  1. DEFLATED-IC FACTOR SHRINKAGE        — multiple-testing-aware calibration:
                                            factor ICs are shrunk toward zero
                                            by their own t-statistics before
                                            becoming weights (López de Prado
                                            deflation logic applied to IC).
  2. EMPIRICAL BASE RATE                 — the P(multibagger) prior measured
                                            from the candidate pool's OWN
                                            trailing triple-barrier outcomes
                                            (no invented constants).
  3. TRIPLE-BARRIER META-LABELING        — a runtime-trained, purged and
                                            embargoed calibrated logistic
                                            gate (López de Prado meta-labeling)
                                            that estimates P(primary signal
                                            is right) per candidate and scales
                                            the composite alpha by relative
                                            confidence.
  4. PROBABILITY-CALIBRATED RANKING      — the prescreen composite score is
                                            mapped to a disclosed, monotone
                                            P(multibagger) so selection
                                            ordering is unchanged while every
                                            disclosed number is a calibrated
                                            probability, not a raw z soup.
  5. FRACTIONAL KELLY + ERROR SHRINKAGE  — per-name conviction weights from
                                            estimated edge with shrinkage
                                            toward the pool mean proportional
                                            to estimation error.
  6. SQUARE-ROOT IMPACT-AWARE TURNOVER   — Almgren-Chriss impact for the IPO
                                            book's QUBO turnover penalty
                                            (45%-max-weight small caps pay
                                            real impact, not flat bps).

HONESTY CONTRACT (R21–R38 doctrine):
  * Every ESTIMATION function here is PURE and DETERMINISTIC (no network,
    no clocks, no invented constants). Fallbacks are explicit, labelled,
    and never fabricate measurements.
  * The one deliberate exception (R38, disclosed): ``ipo_gate_pass`` is a
    VERIFICATION gate, not estimation — it cross-references the official
    NSE security master (``data.dynamic_security_master``, local-cache
    first) for the authentic exchange listing date. It reads the wall
    clock ONLY when the caller does not pin ``as_of_date``; tests pin
    ``as_of_date`` so every lock below is fully deterministic.
  * This is an estimation/decision-mathematics upgrade — technique-level
    alignment with institutional practice. It is NOT a claim of performance
    parity with any firm; no performance numbers are asserted anywhere.
  * The meta-labeling model trains ONLY on strictly trailing, purged and
    embargoed data at runtime, and refuses to gate (identity + disclosure)
    when training data is insufficient.
"""
from __future__ import annotations

import datetime
import logging
import math
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

logger = logging.getLogger("quantum_annealer")

__all__ = [
    "neural_sde_ratio",
    "ipo_prescreen_score",
    "ipo_gate_pass",
    "deflate_ic",
    "deflate_ic_weights",
    "triple_barrier_label",
    "logistic_probability_map",
    "kelly_fraction",
    "kelly_confidence_weights",
    "confidence_multiplier",
    "ac_turnover_penalty",
    "build_meta_event_frame",
    "MetaLabelGate",
]

TRADING_DAYS_PER_YEAR = 252


# ────────────────────────────────────────────────────────────────────
# 1. SHARED SIGNAL MATH (single source of truth)
# ────────────────────────────────────────────────────────────────────
def neural_sde_ratio(close: pd.Series, min_len: int = 20) -> float:
    """Itô SDE drift-to-diffusion efficiency: μ/σ of daily log-returns.

    This is the SAME formula the prescreen has used since Round 33
    (utils.py pass-1 ``neural_sde``). Extracted here so the prescreen row
    AND the signal-frame factor column are guaranteed identical — one
    formula, one source of truth, tested in lockstep.

    Deterministic: pure function of the series. Returns NaN below min_len.
    """
    if close is None or len(close) < min_len:
        return float("nan")
    vals = np.asarray(close, dtype=float)
    vals = vals[np.isfinite(vals) & (vals > 0)]
    if len(vals) < min_len:
        return float("nan")
    lr = np.diff(np.log(vals))
    if len(lr) == 0:
        return float("nan")
    sd = float(np.std(lr))
    if sd <= 1e-12:
        return float("nan")
    return float(np.mean(lr) / sd)


def ipo_prescreen_score(df: pd.DataFrame) -> pd.Series:
    """Production IPO-multibagger prescreen composite (single source).

    Institutional SOTA IPO scoring:
      1. Stochastic drift & persistence  — Neural-SDE μ/σ + Hurst exponent
      2. Microstructure float absorption — VCP + Up/Down volume ratio
      3. Relative strength & efficiency  — RS + Kaufman Efficiency Ratio
      4. Falling-knife deduction         — post-lockup distribution breakdown

    Called by optimizer.run_optimizer_logic (ipo_multibagger branch) and by
    the regression tests — the test locks are production locks, not local
    re-implementations.
    """
    def _z(col: str) -> pd.Series:
        if col in df.columns:
            return df[col].fillna(0.0)
        return pd.Series(0.0, index=df.index)

    score = (
        0.22 * _z("z_neural_sde")        # continuous-time jump-diffusion drift efficiency (μ/σ)
        + 0.18 * _z("z_hurst")           # fractional Brownian trend persistence (H > 0.60)
        + 0.18 * _z("z_vcp_score")       # volatility contraction / Keltner-Bollinger compression
        + 0.14 * _z("z_updown_vol")      # institutional order-flow accumulation ratio
        + 0.12 * _z("z_rs_raw")          # benchmark-excess relative strength
        + 0.08 * _z("z_ker")             # Kaufman Efficiency Ratio (signal-to-noise)
        + 0.08 * _z("z_adv20")           # liquidity floor
        - 0.40 * np.maximum(0.0, -_z("z_mom_1m"))  # heavy penalty for post-lockup breakdown
    )
    return score


def ipo_gate_pass(
    row: Dict[str, Any],
    cfg: Dict[str, Any],
    expected_days: int = 504,
    bars_count_default: int = 500,
    as_of_date: Optional[datetime.date] = None,
) -> Tuple[bool, Optional[str]]:
    """Production IPO-multibagger hard gates (single source).

    Returns (passed, rejection_reason). Gates, in order:
      1a. Data-sufficiency bars window: ≥ MIN_BARS (default 160) trading
          days — past the post-listing lockup turbulence; and ≤ MAX_BARS
          (default 550) when the lookback spans 2y+.
      1b. R38 AUTHORITATIVE listing-age window (the user contract): the
          official NSE listing date (DynamicSecurityMaster) must be
          ≥ IPO_MIN_CALENDAR_DAYS (default 365) and ≤ IPO_MAX_CALENDAR_DAYS
          (default 730) calendar days old — STRICTLY 1-2 year listed
          equities, BOTH bounds enforced, NO exceptions. Tickers the
          master cannot verify (phantom/delisted/unparseable listing
          date) are rejected fail-closed with a disclosed reason.
          (R37 shipped this check as a silent no-op: ``age_days`` was
          referenced before assignment inside a bare ``except: pass``.)
      2. Not broken: ≤ 45% below 52W high.
      3. Liquidity floor: ≥ ₹1.5 Cr ADV20 (15_000_000 INR).
      4. Market-cap band: ₹[MIN,MAX]_MARKET_CAP_CR (default 500–5,000 Cr) when
         a market cap is measurable (registry or row) — permissive-None with
         the gate disclosed as not-measured. R50 SUPERSESSION for profiles
         that pin REQUIRE_MCAP_BAND=True (the 🦄 profile does): the band is
         then a HARD contract and an unmeasurable cap fails CLOSED with a
         disclosed reason (the 2026-10-02 sweep admitted a ~₹7,484 Cr KMEW
         through the permissive hole).
      5. Base formation geometry: base tightness ≤ MAX_BASE_TIGHTNESS_PCT
         (14.5%) and pivot distance ≤ MAX_PIVOT_DISTANCE_PCT (the 🦄 profile
         pins 12.0%; the bare-function default when cfg omits the key is 15.0,
         byte-preserved from the R33 form).

    Called by the utils.py prescreen pass-1 loop and by regression tests.
    """
    mode_cfg = {
        "MIN_BARS": int(cfg.get("IPO_MIN_BARS", 160)),
        "MAX_BARS": int(cfg.get("IPO_MAX_BARS", 550)),
        "MAX_PCT_BELOW": float(cfg.get("IPO_MAX_PCT_BELOW_HIGH", 0.45)),
        "MIN_ADV20": float(cfg.get("IPO_MIN_ADV20_INR", 15_000_000.0)),
        "MIN_MCAP": float(cfg.get("MIN_MARKET_CAP_CR", 500.0)),
        "MAX_MCAP": float(cfg.get("MAX_MARKET_CAP_CR", 5000.0)),
        "REQUIRE_BASE": bool(cfg.get("REQUIRE_BASE_FORMATION", True)),
        "MAX_BASE_TIGHTNESS": float(cfg.get("MAX_BASE_TIGHTNESS_PCT", 14.5)),
        "MAX_PIVOT_DIST": float(cfg.get("MAX_PIVOT_DISTANCE_PCT", 15.0)),
        # R38: the 1-2 year listing-age contract, config-visible and LIVE
        # (R36-4 removed these keys as dead config; R38 re-adds them WITH
        # this live consumer — see data_layer.py profile cfg).
        "MIN_CAL_AGE": int(cfg.get("IPO_MIN_CALENDAR_DAYS", 365)),
        "MAX_CAL_AGE": int(cfg.get("IPO_MAX_CALENDAR_DAYS", 730)),
    }

    bars_count = row.get("bars_count", bars_count_default)
    if bars_count is not None and bars_count < mode_cfg["MIN_BARS"]:
        return False, f"listing_age<{mode_cfg['MIN_BARS']}d"
    if expected_days > 400 and bars_count is not None and bars_count > mode_cfg["MAX_BARS"]:
        return False, f"listing_age>{mode_cfg['MAX_BARS']}d (mature)"

    # ── R38: authoritative 1-2 year listing-age window (the USER CONTRACT) ──
    # The trading-bar gates above are data-sufficiency proxies; THIS calendar
    # window — cross-referenced against the official NSE security master —
    # is the single source of truth for listing age. Fail-closed: a ticker
    # the master cannot verify, or whose listing date cannot be parsed, is
    # rejected with a disclosed reason (never silently waved through).
    ticker = row.get("ticker") or row.get("Ticker")
    if ticker:
        clean_sym = str(ticker).replace(".NS", "").replace(".BO", "").strip().upper()
        if clean_sym and clean_sym != "CASH":
            try:
                from data.dynamic_security_master import DynamicSecurityMaster
            except ImportError as imp_err:
                return False, f"security master unavailable ({imp_err}) — cannot verify listing age"
            dsm = DynamicSecurityMaster.get_instance()
            resolved = dsm.resolve(clean_sym)
            check_sym = resolved[0] if resolved else clean_sym
            meta = dsm.get_company_meta(check_sym)
            if not meta:
                return False, f"ticker '{clean_sym}' not found in active NSE security master"
            age_days = dsm.get_listing_age_days(check_sym, as_of_date=as_of_date)
            if age_days is None:
                return False, f"listing_date missing/unparseable for '{check_sym}' (fail-closed)"
            if age_days < mode_cfg["MIN_CAL_AGE"]:
                return False, (
                    f"listing_age={age_days}d < {mode_cfg['MIN_CAL_AGE']}d seasoning floor "
                    f"(1-2y contract)"
                )
            if age_days > mode_cfg["MAX_CAL_AGE"]:
                return False, (
                    f"listing_age={age_days}d > {mode_cfg['MAX_CAL_AGE']}d mature ceiling "
                    f"(1-2y contract)"
                )

    pct_below = row.get("pct_below_52w_high", 0)
    if pd.notna(pct_below) and pct_below > mode_cfg["MAX_PCT_BELOW"]:
        return False, f"broken_issue>{mode_cfg['MAX_PCT_BELOW']:.0%}_below_high"

    adv20 = row.get("adv20", 0)
    if pd.notna(adv20) and adv20 < mode_cfg["MIN_ADV20"]:
        return False, f"adv20<{mode_cfg['MIN_ADV20']:.0f} INR"

    mcap_cr = row.get("market_cap_cr")
    if mcap_cr is None or (isinstance(mcap_cr, float) and np.isnan(mcap_cr)):
        # Market cap not measurable — gate disclosed as not-measured (permissive,
        # R34 disclosed residual: unknown tickers pass the mcap gate).
        mcap_cr = None
    else:
        mcap_cr = float(mcap_cr)
    # R50 FIX (R50-5b): profiles that pin REQUIRE_MCAP_BAND (the 🦄
    # Multibagger Hunter does, since the 2026-10-02 sweep admitted a
    # ~INR 7,484 Cr mid-cap through this exact hole) fail CLOSED on an
    # unmeasurable cap: the band is a hard selection contract, not an
    # advisory filter. Rejection carries a disclosed reason; the historical
    # permissive-None behavior is preserved for every other caller.
    if mcap_cr is None and bool(cfg.get("REQUIRE_MCAP_BAND", False)):
        return False, (
            f"mcap_unmeasurable (registry/row) — REQUIRED band "
            f"[{mode_cfg['MIN_MCAP']:.0f},{mode_cfg['MAX_MCAP']:.0f}] Cr for this profile"
        )
    if mcap_cr is not None:
        if mcap_cr < mode_cfg["MIN_MCAP"] or mcap_cr > mode_cfg["MAX_MCAP"]:
            return False, f"mcap_{mcap_cr:.0f}Cr_outside_[{mode_cfg['MIN_MCAP']:.0f},{mode_cfg['MAX_MCAP']:.0f}]"

    if mode_cfg["REQUIRE_BASE"]:
        bt = row.get("base_tightness_pct")
        if bt is not None and pd.notna(bt) and float(bt) > mode_cfg["MAX_BASE_TIGHTNESS"]:
            return False, f"base_tightness>{mode_cfg['MAX_BASE_TIGHTNESS']}%"
        p_dist = row.get("pivot_dist_pct", 0.0)
        if p_dist is not None and pd.notna(p_dist) and float(p_dist) > mode_cfg["MAX_PIVOT_DIST"]:
            return False, f"pivot_distance>{mode_cfg['MAX_PIVOT_DIST']}%"

    return True, None


# ────────────────────────────────────────────────────────────────────
# 2. DEFLATED-IC FACTOR SHRINKAGE (multiple-testing correction)
# ────────────────────────────────────────────────────────────────────
def deflate_ic(ic: float, n_obs: int, ic_std: float, t_threshold: float = 2.0,
               min_obs: int = 20) -> float:
    """Shrink a factor's information coefficient toward zero by its own
    t-statistic — the multiple-testing correction institutional factor
    desks apply before an IC becomes a weight.

    t = IC·√N / σ_IC  (σ_IC = std of the cross-sectional IC series; this is
    the standard t-statistic for a mean of N IC observations).
    Under the null, σ_IC ≈ 1/√N which is ALREADY the standard error of the
    mean — so the null fallback is t = IC·√N (the √N is not applied twice).

    shrink_factor = max(0, 1 − t_threshold / max(|t|, ε))
    deflated IC    = IC · shrink_factor

    |t| ≤ t_threshold (≈95% two-sided) ⇒ deflated IC = 0 (no significant
    edge survives the correction). |t| → ∞ ⇒ IC passes through unchanged.

    Deterministic and pure; NaN-safe (returns 0.0 on unmeasurable input).
    """
    try:
        ic_f = float(ic)
    except (TypeError, ValueError):
        return 0.0
    if not np.isfinite(ic_f) or n_obs is None or int(n_obs) < min_obs:
        return 0.0
    n = int(n_obs)
    if ic_std is not None and np.isfinite(float(ic_std)) and float(ic_std) > 1e-12:
        t_stat = abs(ic_f) * math.sqrt(n) / float(ic_std)
    else:
        # null form: SE(mean IC) = 1/√N  ⇒  t = IC·√N  (no second √N)
        t_stat = abs(ic_f) * math.sqrt(n)
    if t_stat <= 1e-12:
        return 0.0
    shrink = max(0.0, 1.0 - t_threshold / t_stat)
    return float(ic_f * shrink)


def deflate_ic_weights(ic_scores: Dict[str, float], n_obs: int,
                       ic_std: Optional[Dict[str, float]] = None,
                       t_threshold: float = 2.0, min_obs: int = 20) -> Dict[str, float]:
    """Apply :func:`deflate_ic` across a factor-IC dict → deflated-IC dict.

    Keys with unmeasurable ICs deflate to exactly 0.0 (they must not enter
    weights on the strength of noise). Pure; preserves key set.
    """
    ic_std = ic_std or {}
    out: Dict[str, float] = {}
    for f, ic in (ic_scores or {}).items():
        out[f] = deflate_ic(ic, n_obs, ic_std.get(f), t_threshold=t_threshold, min_obs=min_obs)
    return out


# ────────────────────────────────────────────────────────────────────
# 3. TRIPLE-BARRIER LABELING + EMPIRICAL BASE RATE
# ────────────────────────────────────────────────────────────────────
def triple_barrier_label(close: Sequence[float], i_start: int,
                         tp_pct: float, sl_pct: float, horizon: int,
                         vol_scaled: bool = False,
                         daily_vol: Optional[float] = None,
                         k_up: float = 2.5,
                         k_dn: float = 1.5) -> Optional[int]:
    """López de Prado triple-barrier label on a close-price path.

    From index ``i_start`` (entry), walk forward up to ``horizon`` days:
      * +1 → upper barrier (+tp_pct) touched BEFORE lower barrier
      *  0 → lower barrier (−sl_pct) touched first (or horizon expiry)
      * None → insufficient forward data (no label; never imputed)

    When vol_scaled=True:
      Barriers are dynamically scaled by the stock's daily volatility:
      tp_effective = clip(k_up * daily_vol * sqrt(horizon), 0.15, 0.50)
      sl_effective = clip(k_dn * daily_vol * sqrt(horizon), 0.10, 0.35)

    Barriers are evaluated on the path AFTER the entry bar (t+1 … t+horizon),
    so the entry price itself never triggers a barrier. Pure/deterministic.
    """
    if close is None:
        return None
    c = np.asarray(close, dtype=float)
    n = len(c)
    if i_start < 0 or i_start >= n - 1:
        return None
    entry = c[i_start]
    if not np.isfinite(entry) or entry <= 0:
        return None

    # Volatility-scaled dynamic barrier adjustment (López de Prado)
    up_eff = tp_pct
    dn_eff = sl_pct
    if vol_scaled:
        v_daily = daily_vol
        if v_daily is None or not np.isfinite(v_daily) or v_daily <= 0:
            trail_start = max(0, i_start - 21)
            trail = c[trail_start : i_start + 1]
            trail = trail[np.isfinite(trail) & (trail > 0)]
            if len(trail) >= 5:
                lrets = np.diff(np.log(trail))
                s_d = float(np.std(lrets))
                if s_d > 1e-6:
                    v_daily = s_d
        if v_daily is not None and np.isfinite(v_daily) and v_daily > 0:
            h_root = math.sqrt(float(horizon))
            up_eff = float(np.clip(k_up * v_daily * h_root, 0.15, 0.50))
            dn_eff = float(np.clip(k_dn * v_daily * h_root, 0.10, 0.35))

    up = entry * (1.0 + up_eff)
    dn = entry * (1.0 - dn_eff)
    end = min(i_start + 1 + int(horizon), n)
    for i in range(i_start + 1, end):
        px = c[i]
        if not np.isfinite(px):
            continue
        # Conservative ordering within a bar: test the LOSS barrier first
        # (a tie can only favor optimism; institutions price pessimism).
        if px <= dn:
            return 0
        if px >= up:
            return 1
    return 0  # horizon expired without the profit barrier


def logistic_probability_map(z: pd.Series, base_rate: float, kappa: float = 0.35) -> pd.Series:
    """Monotone map from composite z-score to a disclosed P(multibagger).

    p(z) = L(logit(base_rate) + κ·z)  with L the standard logistic.

    Semantics: z = 0 (pool-average candidate) ⇒ p = base_rate — the prior
    anchors the CENTER, not a fabricated tail. κ is the disclosed
    information-slope parameter (default 0.35, a conservative composite-signal
    slope; NOT a fitted performance claim).

    Strictly monotone in z ⇒ ranking/selection order is EXACTLY preserved;
    only the disclosed units change (raw composite → calibrated probability).
    Deterministic; NaN z ⇒ NaN probability (never coerced to the prior).
    """
    br = float(base_rate)
    if not (0.0 < br < 1.0):
        br = min(max(br, 1e-6), 1.0 - 1e-6)
    k = float(kappa)
    logit0 = math.log(br / (1.0 - br))
    x = k * pd.to_numeric(z, errors="coerce").astype(float) + logit0
    p = 1.0 / (1.0 + np.exp(-x))
    p = p.where(pd.to_numeric(z, errors="coerce").notna(), np.nan)
    return p


# ────────────────────────────────────────────────────────────────────
# 4. FRACTIONAL KELLY WITH ESTIMATION-ERROR SHRINKAGE
# ────────────────────────────────────────────────────────────────────
def kelly_fraction(p: float, b: float, shrinkage_n: Optional[int] = None,
                   prior_n: int = 100, cap: float = 1.0) -> float:
    """Fractional Kelly for a binary +b/−1 payoff with error shrinkage.

    f* = (p·(b+1) − 1) / b                      (full Kelly)
    f  = f* · n/(n + prior_n)  when the edge is estimated from n
    observations (shrink toward 0 as estimation error grows — the reason
    no institutional desk bets full Kelly). Clipped to [0, cap].

    Pure/deterministic; NaN p ⇒ 0.0 (no measurable edge ⇒ no bet).
    """
    try:
        pv = float(p)
    except (TypeError, ValueError):
        return 0.0
    if not np.isfinite(pv) or b is None or float(b) <= 0:
        return 0.0
    bv = float(b)
    if pv <= 0.0 or pv >= 1.0:
        f_star = 0.0 if pv <= 1.0 / (1.0 + bv) else cap
    else:
        f_star = (pv * (bv + 1.0) - 1.0) / bv
    f = f_star
    if shrinkage_n is not None and shrinkage_n > 0:
        f = f_star * (float(shrinkage_n) / (float(shrinkage_n) + float(prior_n)))
    return float(min(max(f, 0.0), cap))


def kelly_confidence_weights(p: pd.Series, b: float, prior_n: int = 100,
                             lo: float = 0.5, hi: float = 2.0) -> pd.Series:
    """Per-name relative conviction from Kelly fractions (mean-1 normalised).

    Institutional position sizing at the SELECTION layer: each name's
    fractional-Kelly share, shrunk by its estimation support, then
    normalised so the pool average multiplier is exactly 1.0 and clipped
    to [lo, hi]. Mean-1 normalisation guarantees the gate NEVER inflates
    or deflates the whole book — it only re-weights RELATIVE conviction.

    Shrinkage honesty note: with a common ``prior_n`` for every name (the
    only calling convention used today), the n/(n+prior_n) factor is a
    CONSTANT that cancels exactly under the mean-1 normalisation — it is
    retained because it makes the shrinkage FORM explicit (and it stops
    cancelling the moment per-name support counts are supplied). The
    production conviction channel is :func:`confidence_multiplier` driven
    by the MetaLabelGate probabilities (the p̂/p̄ log-optimal sizing rule);
    this function is the equivalent pure utility for a p̂-and-odds caller.

    The book-level weight stack (HRP / BL / Kelly / MDP above HRP) remains
    the position-size authority; this is the confidence channel into the
    selection objective, not a second weight stack.
    """
    ps = pd.to_numeric(p, errors="coerce")
    ns = pd.Series(prior_n, index=ps.index, dtype=float)
    kells = ps.apply(lambda pv: kelly_fraction(pv, b))
    shr = (ns / (ns + prior_n))
    raw = kells * shr
    mean_pos = float(raw[raw > 0].mean()) if (raw > 0).any() else 0.0
    if mean_pos <= 1e-12:
        return pd.Series(1.0, index=ps.index)
    mult = raw / mean_pos
    mult = mult.where(ps.notna() & (raw > 0), 1.0)
    return mult.clip(lo, hi)


def confidence_multiplier(p: pd.Series, kappa: float = 1.0,
                          lo: float = 0.5, hi: float = 2.0) -> pd.Series:
    """Meta-label confidence multiplier: (p̂ / p̄)^κ, mean-1, clipped.

    With common barriers, the log-optimal (Kelly) sizing rule reduces to
    weights ∝ p̂/odds — with a common odds structure the RELATIVE weight is
    p̂/p̄. This function is that channel: mean-1 by construction, so the
    book's aggregate risk budget is untouched; only relative conviction
    changes. Clipped to [lo, hi] so no single name's alpha can be
    amplified more than 2× or crushed below 0.5× by the meta-model.
    """
    ps = pd.to_numeric(p, errors="coerce")
    pbar = float(ps.mean()) if ps.notna().any() else float("nan")
    if not np.isfinite(pbar) or pbar <= 1e-9:
        return pd.Series(1.0, index=ps.index)
    ratio = (ps / pbar).clip(1e-6, 1e6)
    mult = ratio ** float(kappa)
    mult = mult.where(ps.notna(), 1.0)
    return mult.clip(lo, hi)


def ac_turnover_penalty(base_penalty: float, order_notional: float, adv_notional: float,
                        daily_vol: float, eta: float = 0.142, gamma: float = 0.314,
                        qubo_units_per_bp: float = 0.02) -> float:
    """Almgren-Chriss square-root impact, expressed in QUBO penalty units.

    Impact(Q) = η·σ·√(Q/ADV) + γ·σ·(Q/ADV)   [Almgren & Chriss (2001);
    coefficients from Almgren et al. (2005), NSE-calibrated]

    The flat profile penalty stays as the floor (statutory + spread
    baseline); the AC total impact in bps is added through the disclosed
    conversion ``qubo_units_per_bp`` (0.02 QUBO units per bp ⇒ a 60 bp
    small-cap impact adds 1.2 penalty units ≈ 6.7× the 0.18 flat penalty —
    the honest scale difference between flat-assumption and impact-aware
    costs for 45%-max-weight small caps).

    Degenerate inputs (no ADV, no vol, tiny order) fall back to the flat
    penalty — disclosed by return value equality, never an invented cost.
    Pure/deterministic.
    """
    base = float(base_penalty or 0.0)
    if adv_notional is None or not np.isfinite(float(adv_notional)) or float(adv_notional) <= 1.0:
        return base
    if order_notional is None or not np.isfinite(float(order_notional)) or float(order_notional) <= 0:
        return base
    if daily_vol is None or not np.isfinite(float(daily_vol)):
        return base
    # clipped exactly as the production module (ml_alpha/almgren_chriss_impact.py):
    # Q/ADV participation capped at 20%; daily vol confined to [0.5%, 15%].
    q = min(float(order_notional) / float(adv_notional), 0.20)
    sigma = min(max(float(daily_vol), 0.005), 0.15)
    temp = float(eta) * sigma * math.sqrt(q)
    perm = float(gamma) * sigma * q
    total_bps = (temp + perm) * 10_000.0
    return base + float(qubo_units_per_bp) * total_bps


# ────────────────────────────────────────────────────────────────────
# 5. META-LABEL EVENT PANEL + RUNTIME-TRAINED CALIBRATED GATE
# ────────────────────────────────────────────────────────────────────
# Feature set (OHLCV-only — recomputable at ANY historical date, which is
# what makes purged training possible without the full factor stack):
_META_FEATURES = [
    "mom_63", "mom_126", "ann_vol_126", "dd_126", "range_contraction",
    "updown_vol_63", "rs_126", "ker_63", "vol_trend_21",
]


def _row_features(c: np.ndarray, v: Optional[np.ndarray], bench_cum: Optional[np.ndarray],
                  i: int) -> Optional[Dict[str, float]]:
    """Compute the 9 OHLCV-only meta features at index ``i`` (inclusive).

    Returns None when the trailing warm-up (126 bars) is unavailable — a
    missing feature row is DROPPED, never imputed to a flattering value.
    """
    n = len(c)
    warm = 126
    if i < warm or i >= n:
        return None
    c_lo = c[max(0, i - warm): i + 1]
    if not np.all(np.isfinite(c_lo)) or np.any(c_lo <= 0):
        return None

    def _ret(arr: np.ndarray) -> float:
        a0 = float(arr[0])
        return (float(arr[-1]) / a0 - 1.0) if (a0 > 0 and len(arr) > 1) else float("nan")

    mom_63 = _ret(c[max(0, i - 63): i + 1])
    mom_126 = _ret(c_lo)
    lr126 = np.diff(np.log(c_lo))
    ann_vol = float(np.std(lr126) * math.sqrt(TRADING_DAYS_PER_YEAR)) if len(lr126) > 10 else float("nan")
    roll_max = np.maximum.accumulate(c_lo)
    dd_126 = float((roll_max - c_lo).max() / roll_max.min()) if roll_max.min() > 0 else float("nan")

    r21 = c[max(0, i - 20): i + 1]
    r63 = c[max(0, i - 62): i + 1]
    rng21 = float(r21.max() - r21.min())
    rng63 = float(r63.max() - r63.min())
    range_contraction = (rng21 / rng63) if rng63 > 1e-12 else float("nan")

    d = np.diff(c[max(0, i - 63): i + 1])
    up = d[d > 0]
    dn = d[d < 0]
    vol_up = float(np.std(up)) if len(up) > 3 else 0.0
    vol_dn = float(np.std(dn)) if len(dn) > 3 else 0.0
    updown_vol = vol_up / vol_dn if vol_dn > 1e-12 else float("nan")

    rs_126 = mom_126
    if bench_cum is not None and i < len(bench_cum):
        b_lo = bench_cum[max(0, i - warm): i + 1]
        if len(b_lo) == len(c_lo) and b_lo[0] > 0:
            rs_126 = mom_126 - (float(b_lo[-1]) / float(b_lo[0]) - 1.0)

    m63 = c[max(0, i - 63): i + 1]
    net = abs(float(m63[-1]) - float(m63[0]))
    path = float(np.sum(np.abs(np.diff(m63))))
    ker_63 = net / path if path > 1e-12 else float("nan")

    vol_trend = float("nan")
    if v is not None and i < len(v):
        v21 = v[max(0, i - 20): i + 1].astype(float)
        v63 = v[max(0, i - 62): i + 1].astype(float)
        if len(v21) > 5 and len(v63) > 5 and np.mean(v63) > 1e-9:
            vol_trend = float(np.mean(v21) / np.mean(v63))

    feats = {
        "mom_63": mom_63, "mom_126": mom_126, "ann_vol_126": ann_vol,
        "dd_126": dd_126, "range_contraction": range_contraction,
        "updown_vol_63": updown_vol, "rs_126": rs_126, "ker_63": ker_63,
        "vol_trend_21": vol_trend,
    }
    if not all(np.isfinite(x) for x in feats.values()):
        return None
    return feats


def build_meta_event_frame(close_df: pd.DataFrame, volume_df: Optional[pd.DataFrame],
                           benchmark_close: Optional[pd.Series],
                           horizon: int = 63, tp_pct: float = 0.25, sl_pct: float = 0.20,
                           stride: int = 21, embargo: int = 5,
                           max_events_per_ticker: int = 12,
                           as_of_position: Optional[int] = None,
                           vol_scaled: bool = True) -> pd.DataFrame:
    """Build the purged, embargoed triple-barrier meta-label training panel.

    Per ticker, events are sampled every ``stride`` days over the trailing
    history, each labelled by :func:`triple_barrier_label`. The LAST
    trainable event ends at ``as_of − horizon − embargo`` — the label's
    forward window plus an embargo — so NO future information can enter
    training (purged walk-forward by construction).

    When ``vol_scaled=True`` (default), barriers are dynamically scaled by
    each stock's daily volatility.

    ``as_of_position`` defaults to the last index of the panel (today).
    The TODAY feature row (unlabelled — used for prediction) is built
    separately by :class:`MetaLabelGate.build_prediction_frame`.

    Deterministic; drops (does not impute) any row with incomplete data.
    """
    if close_df is None or close_df.empty:
        return pd.DataFrame()
    dates = close_df.index
    n_all = len(dates)
    as_of = int(as_of_position) if as_of_position is not None else n_all - 1
    last_trainable = as_of - int(horizon) - int(embargo)

    bench_cum = None
    if benchmark_close is not None and len(benchmark_close) > 0:
        bench_close = benchmark_close.reindex(dates)
        if bench_close.notna().sum() > 126:
            bench_cum = bench_close.ffill().bfill().to_numpy(dtype=float)

    rows: List[Dict[str, Any]] = []
    for tkr in close_df.columns:
        cser = close_df[tkr].dropna()
        if len(cser) < 126 + horizon + 1:
            continue
        # operate on the panel-aligned array so dates map 1:1 with benchmark
        cfull = close_df[tkr].to_numpy(dtype=float)
        vfull = volume_df[tkr].to_numpy(dtype=float) if (volume_df is not None and tkr in volume_df.columns) else None
        n_events = 0
        i = 126
        while i <= last_trainable and n_events < max_events_per_ticker:
            feats = _row_features(cfull, vfull, bench_cum, i)
            if feats is not None:
                lab = triple_barrier_label(cfull, i, tp_pct, sl_pct, horizon, vol_scaled=vol_scaled)
                if lab is not None:
                    rows.append({"ticker": tkr, "pos": i, "date": dates[i], "label": int(lab), **feats})
                    n_events += 1
            i += stride
    df = pd.DataFrame(rows)
    if df.empty:
        return df
    return df.sort_values(["date", "ticker"]).reset_index(drop=True)


class MetaLabelGate:
    """Calibrated logistic meta-labeling gate (López de Prado meta-labeling).

    PRIMARY signal (the profile's composite factor score) decides candidacy;
    THIS secondary model, trained at runtime on strictly trailing, purged,
    embargoed triple-barrier events, estimates P(the primary is right) and
    re-weights conviction multiplicatively (mean-1 — never inflates the
    book, only re-ranks conviction within it).

    Training path: median/MAD standardisation (house style) → L2 logistic
    (class-balanced) → time-ordered validation split → Platt calibration on
    the validation logits. All seeds fixed; fully deterministic.

    Honesty contract: if the training panel has fewer than
    ``min_train_events`` usable rows, :meth:`fit` returns False and
    :meth:`predict_proba` returns None — the gate REFUSES to gate and the
    caller must disclose the skip. No fabricated probabilities, ever.
    """

    _SEED = 0

    def __init__(self, min_train_events: int = 60, val_frac: float = 0.30, C: float = 1.0):
        self.min_train_events = int(min_train_events)
        self.val_frac = float(val_frac)
        self.C = float(C)
        self.feature_names: List[str] = list(_META_FEATURES)
        self._model = None
        self._calibrator = None
        self._med: Optional[np.ndarray] = None
        self._mad: Optional[np.ndarray] = None
        self.metrics: Dict[str, Any] = {}

    # -- feature plumbing ------------------------------------------------
    def _standardize(self, X: np.ndarray) -> np.ndarray:
        med = self._med
        mad = self._mad
        if med is None or mad is None:
            return X
        mad_safe = np.where(mad > 1e-12, mad, 1.0)
        return (X - med) / mad_safe

    def build_prediction_frame(self, close_df: pd.DataFrame, volume_df: Optional[pd.DataFrame],
                               benchmark_close: Optional[pd.Series],
                               tickers: Optional[Iterable[str]] = None,
                               as_of_position: Optional[int] = None) -> pd.DataFrame:
        """Feature rows for TODAY (unlabelled) — the gate's scoring input."""
        if close_df is None or close_df.empty:
            return pd.DataFrame()
        dates = close_df.index
        as_of = int(as_of_position) if as_of_position is not None else len(dates) - 1
        bench_cum = None
        if benchmark_close is not None and len(benchmark_close) > 0:
            bc = benchmark_close.reindex(dates)
            if bc.notna().sum() > 126:
                bench_cum = bc.ffill().bfill().to_numpy(dtype=float)
        rows = []
        for tkr in (tickers if tickers is not None else close_df.columns):
            if tkr not in close_df.columns:
                continue
            cfull = close_df[tkr].to_numpy(dtype=float)
            vfull = volume_df[tkr].to_numpy(dtype=float) if (volume_df is not None and tkr in volume_df.columns) else None
            feats = _row_features(cfull, vfull, bench_cum, as_of)
            if feats is not None:
                rows.append({"ticker": tkr, "date": dates[as_of], **feats})
        return pd.DataFrame(rows)

    # -- training --------------------------------------------------------
    def fit(self, events: pd.DataFrame) -> bool:
        """Fit on a :func:`build_meta_event_frame` panel. True iff trained.

        Deterministic (fixed seeds, lbfgs solver). Class balance and the
        validation base rate are stored in ``metrics`` for disclosure.
        """
        self._model = None
        self._calibrator = None
        self._med = None
        self._mad = None
        self.metrics = {"status": "NOT_TRAINED"}
        if events is None or len(events) < self.min_train_events:
            self.metrics["status"] = f"SKIPPED_INSUFFICIENT_EVENTS (n={0 if events is None else len(events)} < {self.min_train_events})"
            return False
        df = events.copy()
        X = df[self.feature_names].to_numpy(dtype=float)
        y = df["label"].to_numpy(dtype=int)
        if len(np.unique(y)) < 2:
            self.metrics["status"] = "SKIPPED_DEGENERATE_LABELS (single class)"
            return False

        self._med = np.nanmedian(X, axis=0)
        self._mad = np.nanmedian(np.abs(X - self._med), axis=0) * 1.4826
        Xz = self._standardize(X)
        Xz = np.nan_to_num(Xz, nan=0.0, posinf=0.0, neginf=0.0)

        # time-ordered split (events are sorted by date) — never shuffled
        n_val = max(8, int(len(Xz) * self.val_frac)) if len(Xz) > 24 else 0
        n_train = len(Xz) - n_val
        if n_train < 20:
            self.metrics["status"] = f"SKIPPED_INSUFFICIENT_TRAIN (n_train={n_train} < 20)"
            return False
        Xtr, ytr = Xz[:n_train], y[:n_train]

        try:
            from sklearn.linear_model import LogisticRegression
        except ImportError:  # pragma: no cover — sklearn is a hard dep
            self.metrics["status"] = "SKIPPED_NO_SKLEARN"
            return False
        clf = LogisticRegression(C=self.C, max_iter=500, solver="lbfgs",
                                 class_weight="balanced", random_state=self._SEED)
        clf.fit(Xtr, ytr)
        self._model = clf

        # Platt calibration on the time-ordered validation tail
        if n_val > 0:
            Xva, yva = Xz[n_train:], y[n_train:]
            logits = self._model.decision_function(Xva).reshape(-1, 1)
            if len(np.unique(yva)) == 2:
                cal = LogisticRegression(C=1e6, max_iter=500, solver="lbfgs", random_state=self._SEED)
                cal.fit(logits, yva)
                self._calibrator = cal
                try:
                    from sklearn.metrics import roc_auc_score
                    self.metrics["val_auc"] = float(roc_auc_score(yva, logits.ravel()))
                except Exception:
                    self.metrics["val_auc"] = None
            self.metrics["val_base_rate"] = float(np.mean(yva))
        self.metrics["status"] = "TRAINED"
        self.metrics["n_events"] = int(len(events))
        self.metrics["n_train"] = int(n_train)
        self.metrics["n_val"] = int(n_val)
        self.metrics["train_base_rate"] = float(np.mean(ytr))
        self.metrics["calibrated"] = self._calibrator is not None
        return True

    # -- inference --------------------------------------------------------
    def predict_proba(self, prediction_frame: pd.DataFrame) -> Optional[pd.Series]:
        """P(primary-is-right) per ticker, or None when the gate refused."""
        if self._model is None or prediction_frame is None or prediction_frame.empty:
            return None
        missing = [f for f in self.feature_names if f not in prediction_frame.columns]
        if missing:
            logger.debug("[MetaLabel] prediction frame missing features %s", missing)
            return None
        X = prediction_frame[self.feature_names].to_numpy(dtype=float)
        Xz = self._standardize(X)
        Xz = np.nan_to_num(Xz, nan=0.0, posinf=0.0, neginf=0.0)
        logits = self._model.decision_function(Xz).reshape(-1, 1)
        if self._calibrator is not None:
            p = self._calibrator.predict_proba(logits)[:, 1]
        else:
            p = 1.0 / (1.0 + np.exp(-logits.ravel()))
        return pd.Series(p.astype(float), index=prediction_frame["ticker"].tolist())

    def get_diagnostics(self) -> Dict[str, Any]:
        """Honest disclosure block for logs/reports."""
        d = dict(self.metrics)
        d["model"] = "calibrated_logistic_meta_labeler" if self._model is not None else None
        d["features"] = list(self.feature_names) if self._model is not None else []
        return d
