"""
math_engine/jax_optimizer.py
============================
GPU-accelerated portfolio optimizer using JAX.
Employs JIT compilation and parallel vectorization (vmap) over projected gradient descent
to rebalance thousands of portfolios in parallel.
"""
from __future__ import annotations

import logging
from typing import Dict, Any, List, Tuple
import numpy as np

logger = logging.getLogger(__name__)

try:
    import jax
    import jax.numpy as jnp
    _HAS_JAX = True
except ImportError:
    _HAS_JAX = False


class JaxPortfolioOptimizer:
    """High-performance JAX portfolio optimizer with XLA compile support."""

    @staticmethod
    def is_available() -> bool:
        return _HAS_JAX

    @staticmethod
    def project_simplex_jax(v: jnp.ndarray) -> jnp.ndarray:
        """Projects a vector v onto the probability simplex (w >= 0, sum(w) = 1).
        Vectorized sorting-based projection algorithm.
        """
        n = v.shape[0]
        v_sorted = jnp.sort(v)[::-1]
        cssv = jnp.cumsum(v_sorted)
        indices = jnp.arange(1, n + 1)
        cond = v_sorted + (1.0 - cssv) / indices > 0.0
        # Find the last index satisfying the condition
        rho = jnp.maximum(jnp.max(jnp.where(cond, indices, 0)), 1)
        theta = (cssv[rho - 1] - 1.0) / rho
        return jnp.maximum(v - theta, 0.0)

    @classmethod
    def _optimize_single_portfolio_jax(
        cls,
        mu: jnp.ndarray,
        cov: jnp.ndarray,
        gamma: float = 2.5,
        lr: float = 0.1,
        steps: int = 150
    ) -> jnp.ndarray:
        """Runs Projected Gradient Descent on CPU/GPU to solve MVO.
        Fully compilable via jax.jit.
        """
        n = mu.shape[0]
        # Start with equal weights
        w_init = jnp.ones(n) / n

        def body_fun(i, val):
            w_curr = val
            # Compute gradient: grad = cov * w * gamma - mu
            grad = jnp.dot(cov, w_curr) * gamma - mu
            # Gradient step
            w_next = w_curr - lr * grad
            # Project onto simplex
            w_projected = cls.project_simplex_jax(w_next)
            return w_projected

        w_opt = jax.lax.fori_loop(0, steps, body_fun, w_init)
        return w_opt

    @classmethod
    def optimize_portfolios_batch(
        cls,
        mus: np.ndarray,      # shape: (B, N) - batch of expected returns
        covs: np.ndarray,     # shape: (B, N, N) - batch of covariances
        gamma: float = 2.5,
        steps: int = 150
    ) -> np.ndarray:
        """Solve B portfolios in parallel using jax.vmap.
        
        Returns:
            np.ndarray of shape (B, N) representing optimal weights.
        """
        if not _HAS_JAX:
            logger.warning("[JaxOptimizer] JAX is not installed. Falling back to CPU loop.")
            # Simple CPU NumPy fallback for testing
            B, N = mus.shape
            w_batch = []
            for b in range(B):
                w = np.ones(N) / N
                for _ in range(steps):
                    grad = covs[b] @ w * gamma - mus[b]
                    w = w - 0.1 * grad
                    # Numpy simplex projection fallback
                    w = np.maximum(w, 0.0)
                    if w.sum() > 0:
                        w = w / w.sum()
                w_batch.append(w)
            return np.array(w_batch)

        # Convert to JAX arrays
        j_mus = jnp.array(mus, dtype=jnp.float32)
        j_covs = jnp.array(covs, dtype=jnp.float32)

        # Vectorize using vmap over the optimization function
        optimize_vmap = jax.vmap(
            lambda m, c: cls._optimize_single_portfolio_jax(m, c, gamma=gamma, steps=steps)
        )
        
        # JIT compile the vectorized solver
        optimize_jit = jax.jit(optimize_vmap)
        
        # Execute batch optimization
        res_weights = optimize_jit(j_mus, j_covs)
        return np.array(res_weights)
