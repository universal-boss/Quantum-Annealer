"""
math_engine/kalman_pair_trading.py
===================================
Adaptive 2-State Kalman Filter Pair Trading & Cointegration Spread Engine.

Recursively updates hedge ratio beta_t and spread z-score:
z_t = (y_t - beta_t * x_t - alpha_t) / sigma_e
in real-time to track dynamic cointegration relationships without lookback lag.
"""
from __future__ import annotations

import logging
from typing import Dict, Any, Union
import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


class KalmanPairTradingEngine:
    """Adaptive Kalman Filter Cointegration Pair Trading Engine."""

    @staticmethod
    def filter_pair_spread(
        series_y: Union[pd.Series, np.ndarray],
        series_x: Union[pd.Series, np.ndarray]
    ) -> Dict[str, Any]:
        """Runs Kalman filter to estimate rolling hedge ratio beta and spread z-score.

        AUDIT-FIX (Round 48 — R48-4): when both inputs are pandas Series the
        two are now aligned on their COMMON index BEFORE dropping NaNs. The
        previous code dropna()'d each series independently, so any difference
        in NaN placement or date coverage between the legs shifted the y/x
        pairing — a hedge ratio estimated on mismatched dates is garbage
        (stock day t regressed against benchmark day t'). Plain array inputs
        keep the previous element-wise contract (caller guarantees pairing).
        """
        if isinstance(series_y, pd.Series) and isinstance(series_x, pd.Series):
            _aligned = pd.concat(
                [series_y.rename("_y"), series_x.rename("_x")], axis=1, join="inner"
            ).dropna()
            y = _aligned["_y"].to_numpy() if not _aligned.empty else np.array([])
            x = _aligned["_x"].to_numpy() if not _aligned.empty else np.array([])
        else:
            y = pd.Series(series_y).dropna().values
            x = pd.Series(series_x).dropna().values
        n = min(len(y), len(x))
        if n < 10:
            return {"hedge_ratio_beta": 1.0, "spread_zscore": 0.0, "trade_signal": "FLAT"}

        # State vector theta = [alpha, beta]^T
        theta = np.zeros(2)
        p_cov = np.eye(2) * 10.0
        r_var = 0.001
        q_var = 1e-5 * np.eye(2)

        spreads = []
        for t in range(n):
            f_t = np.array([1.0, x[t]])
            y_pred = float(np.dot(f_t, theta))
            e_t = y[t] - y_pred

            # Predict step: propagate covariance with process noise Q (Elliott et al. 2005)
            p_cov_pred = p_cov + q_var

            # Innovation covariance and Kalman gain using predicted covariance
            q_est = float(f_t @ p_cov_pred @ f_t.T + r_var)
            k_gain = (p_cov_pred @ f_t.T) / q_est

            # State update
            theta = theta + k_gain * e_t
            # Covariance update (Joseph form for guaranteed positive semi-definiteness)
            i_kh = np.eye(2) - np.outer(k_gain, f_t)
            p_cov = i_kh @ p_cov_pred @ i_kh.T + r_var * np.outer(k_gain, k_gain)
            spreads.append(e_t)

        spread_arr = np.array(spreads)
        std_s = float(np.std(spread_arr)) + 1e-9
        z_score = float(spread_arr[-1] / std_s)

        signal = "LONG_PAIR" if z_score < -2.0 else ("SHORT_PAIR" if z_score > 2.0 else "FLAT")

        return {
            "hedge_ratio_beta": round(float(theta[1]), 4),
            "intercept_alpha": round(float(theta[0]), 4),
            "spread_zscore": round(z_score, 4),
            "trade_signal": signal
        }
