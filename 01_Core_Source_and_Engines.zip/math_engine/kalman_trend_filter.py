"""
math_engine/kalman_trend_filter.py
==================================
2-State Linear Kalman Trend & Velocity Filter Engine.

Implements a noise-adaptive Linear Kalman Filter to extract true 
underlying price trends (x_1) and continuous price momentum/velocity (x_2)
from noisy market tick and daily bar price observations.
"""

from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, Tuple

logger = logging.getLogger(__name__)


class KalmanTrendFilter:
    """
    2-State Kalman Trend & Price Velocity Filter.
    State Vector X_t = [True_Price_t, Velocity_t]^T
    Eliminates measurement noise and calculates optimal state estimates.
    """

    def __init__(
        self,
        process_noise_var: float = 1e-4,
        measurement_noise_var: float = 1e-2
    ) -> None:
        self.q_var = process_noise_var
        self.r_var = measurement_noise_var
        
        # State vector: [price, velocity]
        self.x = np.zeros(2)
        # Estimation error covariance matrix P (2x2)
        self.P = np.eye(2) * 1.0
        # Measurement matrix H: we only observe price directly, H = [1, 0]
        self.H = np.array([[1.0, 0.0]])

    def filter_price_series(
        self,
        prices: pd.Series | np.ndarray
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Executes Kalman Filter across historical price series.
        
        Returns:
            Tuple[filtered_trend_prices, filtered_velocity_momentum]
        """
        p_vals = np.asarray(prices, dtype=float)
        n = len(p_vals)
        if n < 3:
            return p_vals, np.zeros(n)

        # Initialize state with first price
        self.x[0] = p_vals[0]
        self.x[1] = 0.0
        self.P = np.eye(2) * 1.0

        filtered_prices = np.zeros(n)
        filtered_velocities = np.zeros(n)

        # State transition matrix F: x_{t} = x_{t-1} + v_{t-1} * dt (dt=1)
        F = np.array([[1.0, 1.0],
                      [0.0, 1.0]])

        # Process noise covariance Q
        Q = np.eye(2) * self.q_var
        # Measurement noise covariance R (scalar)
        R = self.r_var

        for t in range(n):
            z = p_vals[t]
            if np.isnan(z):
                z = self.x[0]

            # 1. Predict
            x_pred = F @ self.x
            P_pred = F @ self.P @ F.T + Q

            # 2. Update (Kalman Gain)
            y = z - (self.H @ x_pred)[0]  # Innovation / measurement residual
            S = float(self.H @ P_pred @ self.H.T + R)
            K = (P_pred @ self.H.T) / S  # Kalman Gain (2x1)

            self.x = x_pred + K.flatten() * y
            self.P = (np.eye(2) - K @ self.H) @ P_pred

            filtered_prices[t] = self.x[0]
            filtered_velocities[t] = self.x[1]

        return filtered_prices, filtered_velocities
