"""
math_engine/latent_screener.py
================================
Upgraded FAISS-backed multi-bank latent space screener.
Supports breakout, prebreakout, failed_breakout, distribution, and trap banks,
with timeframe-bundle aggregation, score calibration, and two-stage reranked retrieval.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, Tuple, List, Optional, Any

import numpy as np
from numpy.typing import NDArray

from math_engine.prototype_bank import PrototypeBankManager

# ROUND-44 FIX (circular import): this used to be a module-level
# `from utils import apply_score_calibration`. utils.py imports
# math_engine.indicators part-way through ITS module body, so when the
# import chain entered utils first, math_engine/__init__ ran while utils
# was partially initialized and this import raised
# "cannot import name 'apply_score_calibration' from partially initialized
# module 'utils'" — silently degrading the LatentSpaceScreener /
# LatentManifoldScreener exports to None for the whole process (proven by
# importing web_dashboard.app before math_engine). Deferring the import to
# call time cuts the circular edge; the function bodies below import it
# lazily.
logger = logging.getLogger(__name__)


def _apply_score_calibration(raw_score, bank_name, **kwargs):
    """Deferred bridge to utils.apply_score_calibration (see note above)."""
    from utils import apply_score_calibration as _fn
    return _fn(raw_score, bank_name, **kwargs)


class LatentSpaceScreener:
    """FAISS-backed search layer that supports multi-bank retrieval,

    cross-timeframe voting, score calibration, and two-stage candidate reranking.
    """

    def __init__(self, embeddings_path_or_dir: str | Path) -> None:
        """Initialize the multi-bank latent space screener.

        Args:
            embeddings_path_or_dir: Path to legacy .npy embeddings file,
                                    or root directory containing `prototype_banks/`.
        """
        path = Path(embeddings_path_or_dir)
        if path.is_file():
            self.artifact_dir = path.parent
        else:
            self.artifact_dir = path

        self.bank_manager = PrototypeBankManager(self.artifact_dir)
        self.bank_manager.load_all()

    def score_setup(self, live_embedding: NDArray, top_k: int = 5) -> Dict[str, Any]:
        """Legacy v2 compatibility: scores query against default breakout bank daily."""
        res = self.bank_manager.search(live_embedding, timeframe="1d", bank="breakout", topk=top_k)
        best_cos = res["best_cosine_similarity"]
        l2 = float(np.sqrt(max(0.0, 2.0 - 2.0 * best_cos)))

        return {
            "cosine_similarity": round(res["cosine_similarity"], 6),
            "best_cosine_similarity": round(best_cos, 6),
            "l2_distance": round(l2, 6),
            "top_k_cosine": res["top_k_cosine"],
            "top_k_indices": res["top_k_indices"],
        }

    def score_setup_multibank(
        self,
        embedding: NDArray,
        regime: Optional[str] = None,
        timeframe: str = "1d",
        top_k: int = 5,
    ) -> Dict[str, Any]:
        """Scores a chart embedding against all available prototype pattern banks.

        Returns details for the bank with the highest matching similarity.
        """
        banks = ["breakout", "prebreakout", "failed_breakout", "distribution", "mean_reversion_trap"]
        best_bank = "breakout"
        best_similarity = 0.0
        best_res = None

        for bank in banks:
            res = self.bank_manager.search(embedding, timeframe=timeframe, regime=regime, bank=bank, topk=top_k)
            if res["best_cosine_similarity"] > best_similarity:
                best_similarity = res["best_cosine_similarity"]
                best_bank = bank
                best_res = res

        if best_res is None:
            # Fallback empty result
            return {
                "best_bank": "breakout",
                "best_regime_bank": "breakout",
                "best_cosine_similarity": 0.0,
                "topk_mean_similarity": 0.0,
                "margin": 0.0,
                "novelty": 1.414,
                "agreement": 1.0,
                "calibrated_probability": 0.0,
                "top_k_cosine": np.zeros(top_k, dtype=np.float32),
                "top_k_indices": -np.ones(top_k, dtype=np.int64),
                "metadata": [],
            }

        # Calculate margin, novelty, and calibrated probability
        cosine_sims = best_res["top_k_cosine"]
        margin = float(cosine_sims[0] - cosine_sims[1]) if len(cosine_sims) > 1 else 0.0
        novelty = float(np.sqrt(max(0.0, 2.0 - 2.0 * best_similarity)))
        prob = _apply_score_calibration(best_similarity, best_bank)

        # Regimes compatibility tag
        best_regime_bank = f"{best_bank}_{regime}" if regime else best_bank

        # Agreement: standard deviation of top-k neighbors (lower std = higher agreement)
        std_dev = float(np.std(cosine_sims)) if len(cosine_sims) > 1 else 0.0
        # L9-fix: guard against the empty/near-empty match case. When best_similarity is
        # essentially zero (no real prototype matched), the formula above would still return
        # agreement ≈ 1.0 (since std_dev of zeros is 0.0), falsely signaling perfect agreement.
        if best_similarity < 1e-6:
            agreement = 0.0
        else:
            agreement = float(1.0 - std_dev)

        return {
            "best_bank": best_bank,
            "best_regime_bank": best_regime_bank,
            "best_cosine_similarity": best_similarity,
            "topk_mean_similarity": float(cosine_sims.mean()),
            "margin": margin,
            "novelty": novelty,
            "agreement": agreement,
            "calibrated_probability": prob,
            "top_k_cosine": cosine_sims,
            "top_k_indices": best_res["top_k_indices"],
            "metadata": best_res["metadata"],
        }

    def score_timeframe_bundle(
        self,
        embeddings_by_tf: Dict[str, NDArray],
        regime: Optional[str] = None,
        top_k: int = 5,
    ) -> Dict[str, Any]:
        """Aggregate scores across 1h, 4h, 1d, and 1wk timeframes.

        Computes timeframe-weighted average similarities and calculates cross-timeframe
        agreement votes.
        """
        # Default timeframe weights
        tf_weights = {"1h": 0.15, "4h": 0.20, "1d": 0.40, "1wk": 0.25}

        results: Dict[str, Dict[str, Any]] = {}
        total_w = 0.0

        for tf, emb in embeddings_by_tf.items():
            if tf in tf_weights:
                res = self.score_setup_multibank(emb, regime=regime, timeframe=tf, top_k=top_k)
                results[tf] = res
                total_w += tf_weights[tf]
            else:
                # L8-fix: previously timeframes outside {"1h","4h","1d","1wk"} were silently
                # dropped from the bundle. Log loudly so misconfigured upstream callers can see
                # why an expected timeframe contributed nothing to the weighted aggregate.
                logger.warning("[LatentScreener] Timeframe '%s' not in weight map — skipped.", tf)

        if not results or total_w < 1e-9:
            return {
                "best_bank": "breakout",
                "best_cosine_similarity": 0.0,
                "margin": 0.0,
                "novelty": 1.414,
                "agreement": 1.0,
                "calibrated_probability": 0.0,
                "timeframe_votes": {},
            }

        # Weighted calculations
        weighted_similarity = 0.0
        weighted_probability = 0.0
        weighted_novelty = 0.0
        weighted_margin = 0.0

        bank_votes = []
        for tf, res in results.items():
            w = tf_weights[tf] / max(total_w, 1e-9)
            weighted_similarity += w * res["best_cosine_similarity"]
            weighted_probability += w * res["calibrated_probability"]
            weighted_novelty += w * res["novelty"]
            weighted_margin += w * res["margin"]
            bank_votes.append(res["best_bank"])

        # Determine dominant bank
        from collections import Counter
        vote_counts = Counter(bank_votes)
        best_bank = vote_counts.most_common(1)[0][0]

        # Agreement is defined as fraction of timeframes voting for the dominant pattern family
        agreement = float(vote_counts[best_bank] / len(bank_votes))

        return {
            "best_bank": best_bank,
            "best_cosine_similarity": weighted_similarity,
            "margin": weighted_margin,
            "novelty": weighted_novelty,
            "agreement": agreement,
            "calibrated_probability": weighted_probability,
            "timeframe_votes": {tf: r["best_bank"] for tf, r in results.items()},
        }

    def rerank_candidates(
        self,
        query: NDArray,
        bank: str,
        timeframe: str,
        regime: Optional[str] = None,
        top_k: int = 50,
    ) -> List[Dict[str, Any]]:
        """Retrieve shortlist candidates from FAISS index and apply a hybrid score reranking logic:

            hybrid_score = cosine + margin - 0.2 * novelty + (0.1 if matching regime)
        """
        res = self.bank_manager.search(query, timeframe=timeframe, regime=regime, bank=bank, topk=top_k)
        cosine_sims = res["top_k_cosine"]
        indices = res["top_k_indices"]
        metadata = res["metadata"]

        reranked = []
        for idx, sim in enumerate(cosine_sims):
            meta = metadata[idx] if idx < len(metadata) else {}
            item_regime = meta.get("regime")

            # Analytical metrics
            margin = float(sim - cosine_sims[-1]) if len(cosine_sims) > 1 else 0.0
            novelty = float(np.sqrt(max(0.0, 2.0 - 2.0 * sim)))

            # Rerank formula
            regime_bonus = 0.10 if (regime and item_regime == regime) else 0.0
            hybrid_score = sim + margin - 0.20 * novelty + regime_bonus

            reranked.append(
                {
                    "index": int(indices[idx]),
                    "cosine_similarity": float(sim),
                    "hybrid_score": float(hybrid_score),
                    "novelty": novelty,
                    "margin": margin,
                    "metadata": meta,
                }
            )

        # Sort by hybrid score descending
        reranked.sort(key=lambda x: x["hybrid_score"], reverse=True)
        return reranked

    def calibrate_score(
        self,
        raw_score: float,
        bank_name: str,
        timeframe: str = "1d",
        regime: Optional[str] = None,
    ) -> float:
        """Expose core score calibration mapping helper."""
        return _apply_score_calibration(raw_score, bank_name)
