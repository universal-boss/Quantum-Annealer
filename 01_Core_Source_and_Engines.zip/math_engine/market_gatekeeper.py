"""
math_engine/market_gatekeeper.py
================================
Macro & Index Market Gatekeeper Traffic Light Engine.

Evaluates broader market regime to protect swing trading capital:
1. Benchmark 50-day & 200-day SMA Trend Orientation.
2. GJR-GARCH / Volatility Expansion Shock.
3. Market Breadth (% of universe stocks above 50 SMA).
4. Outputs 3-tier actionable traffic light:
   - 🟢 GREEN (Bullish Uptrend): 100% position sizing, full risk budget.
   - 🟡 YELLOW (Choppy/Rangebound): 50% position sizing, tighter stops.
   - 🔴 RED (Defensive/Crash Regime): 0-25% position sizing, stay in cash.
"""
from __future__ import annotations

import logging
from typing import Dict, List, Optional, Any, Union
import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


class MarketGatekeeper:
    """Evaluates broader market health and sets position sizing safety multipliers."""

    @classmethod
    def evaluate_market_regime(
        cls,
        benchmark_close: Union[pd.Series, np.ndarray],
        universe_closes: Optional[pd.DataFrame] = None
    ) -> Dict[str, Any]:
        """
        Evaluates Nifty/Benchmark series to determine market health.
        """
        b = pd.Series(benchmark_close).dropna().astype(float)
        if len(b) < 20:
            return {
                "status": "GREEN",
                "traffic_light_badge": "🟢 BULLISH REGIME (100% Position Sizing)",
                "sizing_multiplier": 1.0,
                "regime_name": "Normal Uptrend",
                "guidance": "Favorable market conditions. Execute normal 100% swing allocations.",
                "nifty_above_50_sma": True,
                "nifty_above_200_sma": True,
                "market_breadth_pct": 70.0
            }

        curr_price = float(b.iloc[-1])
        sma_20 = float(b.rolling(20, min_periods=1).mean().iloc[-1])
        sma_50 = float(b.rolling(50, min_periods=1).mean().iloc[-1]) if len(b) >= 50 else sma_20
        # ROUND 45 FIX: short-series fallbacks previously ESCALATED — for
        # 20 <= len < 200, sma_200 silently became sma_50, so any dip below the
        # 50-day SMA tripped `not above_200` -> RED (25% sizing) with guidance
        # claiming the market is "below key long-term moving averages" —
        # fabricated, since no 200-day data exists. Missing long-term averages
        # are now neutral (None) and cannot trigger the RED gate by themselves.
        sma_200 = float(b.rolling(200, min_periods=1).mean().iloc[-1]) if len(b) >= 200 else None

        # Benchmark Trend Signals
        above_50 = curr_price >= sma_50
        above_200 = (curr_price >= sma_200) if sma_200 is not None else None
        golden_cross = (sma_50 >= sma_200) if sma_200 is not None else None

        # Realized Volatility Check
        daily_rets = b.pct_change().dropna()
        vol_20d = float(daily_rets.tail(20).std() * np.sqrt(252.0)) if len(daily_rets) >= 20 else 0.15
        vol_60d = float(daily_rets.tail(60).std() * np.sqrt(252.0)) if len(daily_rets) >= 60 else None
        # ROUND 45 FIX: when the 60d baseline is unavailable the old code used a
        # hardcoded 0.15, so a steady 16-18%-vol market could trip the "vol
        # spike" ratio spuriously. Neutral (1.0) when unmeasurable.
        vol_spike_ratio = (vol_20d / max(vol_60d, 0.05)) if vol_60d is not None else 1.0

        # Market Breadth (% above 50 SMA across universe)
        if universe_closes is not None and not universe_closes.empty:
            breadth_counts = []
            for col in universe_closes.columns:
                s = universe_closes[col].dropna()
                if len(s) >= 30:
                    s_50 = float(s.rolling(50, min_periods=1).mean().iloc[-1])
                    breadth_counts.append(1 if float(s.iloc[-1]) >= s_50 else 0)
            market_breadth = (sum(breadth_counts) / max(len(breadth_counts), 1)) * 100.0
            # ROUND 45 FIX: if NO universe column had >=30 valid rows, breadth
            # computed to 0% and hard-tripped the RED gate on "no data". A
            # neutral 65% (matching the no-universe fallback) is used instead.
            if not breadth_counts:
                market_breadth = 65.0 if above_50 else 35.0
        else:
            market_breadth = 65.0 if above_50 else 35.0

        # Determine Gatekeeper Regime Status
        # ROUND 45 FIX: `not above_200` only applies when the 200-day SMA exists
        # (above_200 is None on short histories — neutral, cannot trigger RED).
        _below_200 = (above_200 is False)
        if _below_200 or (not above_50 and vol_spike_ratio > 1.4) or market_breadth < 30.0:
            status = "RED"
            badge = "🔴 DEFENSIVE REGIME (Stay in Cash / Max 25% Sizing)"
            multiplier = 0.25
            regime_name = "Bearish Correction / Volatility Shock"
            guidance = "Market below key long-term moving averages or high volatility. Protect capital and avoid new breakout longs."
        elif not above_50 or market_breadth < 50.0 or vol_spike_ratio > 1.2:
            status = "YELLOW"
            badge = "🟡 SIDEWAYS CHOP (Cut Position Sizing to 50%)"
            multiplier = 0.50
            regime_name = "Rangebound / Choppy Market"
            guidance = "Market is in choppy consolidation. Cut trade sizes by 50% and use tighter trailing stop losses."
        else:
            status = "GREEN"
            badge = "🟢 BULLISH REGIME (100% Full Position Sizing)"
            multiplier = 1.0
            regime_name = "Strong Bullish Uptrend"
            guidance = "Broad market conditions are supportive. Full 100% swing trade allocation allowed."

        return {
            "status": status,
            "traffic_light_badge": badge,
            "sizing_multiplier": multiplier,
            "regime_name": regime_name,
            "guidance": guidance,
            "current_benchmark_price": round(curr_price, 2),
            "sma_50": round(sma_50, 2),
            # ROUND 45: None when insufficient history (was a fabricated
            # fallback to the 50-day value).
            "sma_200": round(sma_200, 2) if sma_200 is not None else None,
            "nifty_above_50_sma": bool(above_50),
            "nifty_above_200_sma": bool(above_200) if above_200 is not None else None,
            "annualized_vol_20d_%": round(vol_20d * 100.0, 1),
            "market_breadth_pct": round(market_breadth, 1)
        }
