"""
math_engine/microstructure.py
==============================
Institutional Microstructure & Order Flow Toxicity Engine.

Calculates:
  1. Volume-Synchronized Probability of Toxicity (VPIN — Easley, Lopez de Prado, O'Hara 2012)
  2. Order Flow Imbalance (OFI — Cont, Kukanov, Stoikov 2014)
  3. Roll's Implied Spread (Roll 1984)
  4. Amihud Illiquidity (Amihud 2002)

Generates microstructure alpha z-scores (z_vpin_toxicity, z_order_book_imbalance)
to prevent adverse selection and optimize trade execution timing.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, Tuple

logger = logging.getLogger(__name__)


class MicrostructureEngine:
    """
    Institutional Market Microstructure Engine:
    
    1. VPIN (Volume-Synchronized Probability of Toxicity):
       Groups volume into constant-volume buckets V.
       For each bucket, estimates buy volume V^B and sell volume V^S using tick rule / Lee-Ready algorithm.
       VPIN = Σ |V^B - V^S| / (N × V)
       High VPIN (>0.65) indicates informed toxic order flow -> delay execution / widen stop loss.
       
    2. OFI (Order Flow Imbalance):
       OFI_t = Bid_Qty_t - Ask_Qty_t
       Positive OFI indicates net institutional buy accumulation.
       
    3. Roll Spread:
       S = 2 × sqrt(-Cov(ΔP_t, ΔP_{t-1}))
    """

    @staticmethod
    def compute_vpin(close: pd.Series, volume: pd.Series, bucket_vol: float = 0.0, num_buckets: int = 50) -> float:
        """
        Compute Volume-Synchronized Probability of Toxicity (VPIN).

        Reference
        ---------
        Easley, D., López de Prado, M. M., O'Hara, M. (2012).
        "Flow Toxicity and Liquidity in a High-Frequency World."
        Review of Financial Studies, 25(5): 1457-1493.

        Implementation
        -------------
        Uses Bulk Volume Classification (BVC) — the standard, robust VPIN
        buy/sell estimator. For each volume bucket b:

          1. Aggregate bar volumes into V_b volume buckets (each bucket holds
             approximately `bucket_vol` shares; if `bucket_vol` is 0 or unset,
             total volume / num_buckets is used).
          2. Standardize the price change over the bucket:
                z_b = (ΔP_b) / (σ_ΔP + ε)
          3. Estimate buy probability from the standard normal CDF:
                Φ(z_b) = 0.5 * (1 + erf(z_b / sqrt(2)))
          4. Buy volume = V_b * Φ(z_b), Sell volume = V_b * (1 - Φ(z_b))
          5. Per-bucket imbalance ratio: |V^B_b - V^S_b| / V_b = |2·Φ(z_b) - 1|

        VPIN = (1/N) · Σ_{b=1..N} |2·Φ(z_b) - 1|

        Returns
        -------
        float
            VPIN ∈ [0.05, 0.95]. Clamped to prevent degenerate "always block"
            or "always pass" behaviour at the extremes.
        """
        from math import erf, sqrt as _sqrt

        if close is None or volume is None:
            return 0.50
        if len(close) < 20 or len(volume) < 20:
            return 0.50

        # Align close + volume on common index
        close = pd.Series(close).dropna()
        volume = pd.Series(volume).dropna()
        common_idx = close.index.intersection(volume.index)
        if len(common_idx) < 20:
            return 0.50
        close = close.loc[common_idx]
        volume = volume.loc[common_idx]

        p = close.values.astype(np.float64)
        v = volume.values.astype(np.float64)
        price_diff = np.diff(p)
        vol_trim = v[1:]

        if len(price_diff) == 0 or np.sum(vol_trim) <= 0:
            return 0.50

        # ── Determine bucket size ──
        total_vol = float(np.sum(vol_trim))
        if total_vol <= 0:
            return 0.50

        if bucket_vol is None or bucket_vol <= 0:
            # AUDIT-FIX (Round 6, A2-P3-7): the docstring (and parameter
            # `num_buckets`) promise total-volume/num_buckets sizing when
            # bucket_vol is unset, but the previous code used one TIME BAR
            # per bucket (num_buckets was dead). Honor the documented
            # behavior.
            bucket_vol = total_vol / max(int(num_buckets), 1)
            bucket_indices = np.zeros(len(vol_trim), dtype=np.int64)
            cum = 0.0
            b_idx = 0
            for i, vol_i in enumerate(vol_trim):
                cum += vol_i
                bucket_indices[i] = b_idx
                if cum >= bucket_vol:
                    cum = 0.0
                    b_idx += 1
        else:
            # Build proper volume-synchronized buckets
            bucket_indices = np.zeros(len(vol_trim), dtype=np.int64)
            cum = 0.0
            b_idx = 0
            for i, vol_i in enumerate(vol_trim):
                cum += vol_i
                bucket_indices[i] = b_idx
                if cum >= bucket_vol:
                    cum = 0.0
                    b_idx += 1

        n_buckets = int(bucket_indices.max()) + 1
        if n_buckets < 5:
            return 0.50

        # ── Per-bucket: aggregate volume + compute standardized price change ──
        bucket_vol_arr = np.zeros(n_buckets, dtype=np.float64)
        bucket_dp_arr = np.zeros(n_buckets, dtype=np.float64)
        bucket_count = np.zeros(n_buckets, dtype=np.int64)
        for i, b in enumerate(bucket_indices):
            bucket_vol_arr[b] += vol_trim[i]
            bucket_dp_arr[b] += price_diff[i]
            bucket_count[b] += 1

        # Standardize bucket price changes using their pooled std
        sigma_dp = float(np.std(price_diff)) + 1e-9
        z = bucket_dp_arr / (sigma_dp * np.sqrt(np.maximum(bucket_count, 1)))

        # BVC: buy probability = Φ(z) = 0.5 * (1 + erf(z / sqrt(2)))
        sqrt2 = _sqrt(2.0)
        phi_z = 0.5 * (1.0 + np.array([erf(zi / sqrt2) for zi in z]))

        # Per-bucket imbalance ratio (volume-weighted)
        imbalance_ratio = np.abs(2.0 * phi_z - 1.0)
        # Volume-weighted mean imbalance across buckets → VPIN
        vpin = float(np.sum(imbalance_ratio * bucket_vol_arr) /
                     (np.sum(bucket_vol_arr) + 1e-9))

        return min(max(vpin, 0.05), 0.95)

    @staticmethod
    def compute_roll_spread(close: pd.Series) -> float:
        """
        Compute Roll's (1984) implied bid-ask spread from price autocovariance.
        """
        if len(close) < 10:
            return 0.0
        dp = close.diff().dropna().values
        if len(dp) < 5:
            return 0.0
        cov = float(np.cov(dp[:-1], dp[1:])[0, 1])
        if cov >= 0:
            return 0.0  # Positive autocovariance -> zero implied spread
        spread = float(2.0 * np.sqrt(-cov))
        return spread

    @staticmethod
    def compute_order_flow_imbalance(depth_dict: Dict[str, Any]) -> float:
        """
        Compute Order Flow Imbalance (OFI) from order book depth.
        """
        if not depth_dict or not isinstance(depth_dict, dict):
            return 0.0
        
        buy_depth  = depth_dict.get("buy", [])
        sell_depth = depth_dict.get("sell", [])
        
        total_buy_qty  = sum(int(item.get("quantity", 0)) for item in buy_depth)
        total_sell_qty = sum(int(item.get("quantity", 0)) for item in sell_depth)
        
        total = total_buy_qty + total_sell_qty
        if total <= 0:
            return 0.0
            
        ofi = (total_buy_qty - total_sell_qty) / float(total)
        return float(ofi)

    @classmethod
    def compute_microstructure_zscores(cls, data: dict, stocks: list) -> pd.DataFrame:
        """
        Compute z_vpin_toxicity and z_order_book_imbalance for all stocks in universe.
        Returns DataFrame with index=stocks and columns=[z_vpin_toxicity, z_roll_spread].
        """
        close_df  = data.get("Close", data.get("close", pd.DataFrame())) if isinstance(data, dict) else pd.DataFrame()
        volume_df = data.get("Volume", data.get("volume", pd.DataFrame())) if isinstance(data, dict) else pd.DataFrame()
        
        rows = []
        for s in stocks:
            vpin_val = 0.50
            roll_val = 0.0
            if isinstance(close_df, pd.DataFrame) and s in close_df.columns:
                if isinstance(volume_df, pd.DataFrame) and s in volume_df.columns:
                    combined = pd.concat([close_df[s], volume_df[s]], axis=1, keys=["close", "vol"]).dropna()
                    if len(combined) > 20:
                        c = combined["close"]
                        v = combined["vol"]
                        vpin_val = cls.compute_vpin(c, v)
                        roll_val = cls.compute_roll_spread(c)
                else:
                    c = close_df[s].dropna()
                    if len(c) > 20:
                        roll_val = cls.compute_roll_spread(c)
            rows.append({"Ticker": s, "vpin": vpin_val, "roll_spread": roll_val})
            
        if not rows:
            return pd.DataFrame(index=stocks)
            
        df = pd.DataFrame(rows).set_index("Ticker")
        
        # Cross-sectional z-score standardization
        vpin_mu  = float(df["vpin"].mean());  vpin_std  = float(df["vpin"].std())  + 1e-6
        roll_mu  = float(df["roll_spread"].mean()); roll_std  = float(df["roll_spread"].std()) + 1e-6
        
        df["z_vpin_toxicity"] = - (df["vpin"] - vpin_mu) / vpin_std   # High VPIN = toxic -> lower z-score
        df["z_roll_spread"]   = - (df["roll_spread"] - roll_mu) / roll_std  # High spread = illiquid -> lower z-score
        return df[["z_vpin_toxicity", "z_roll_spread"]]
