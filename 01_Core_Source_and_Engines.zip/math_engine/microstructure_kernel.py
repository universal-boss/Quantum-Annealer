"""math_engine/microstructure_kernel.py
=======================================
High-Performance Microstructure & OFI Stream Kernel.

Provides sub-millisecond level order book analytics:
  1. FastHawkesIntensityEngine: Vectorized circular buffer computing
     self-exciting Hawkes process intensities and micro-burst probabilities.
  2. OrderFlowImbalanceStreamer: Real-time Level-2/Level-3 Order Flow
     Imbalance (OFI) calculator (Cont, Kukanov & Stoikov 2014).
  3. StreamingVPINAccumulator: Online Bulk Volume Classification (BVC)
     VPIN toxicity calculation (Easley, López de Prado, O'Hara 2012).
"""
from __future__ import annotations

import collections
import logging
import math
import time
from typing import Any, Dict, List, Optional, Tuple
import numpy as np

logger = logging.getLogger("quantum_annealer.microstructure_kernel")


class FastHawkesIntensityEngine:
    """Sub-millisecond vectorized circular buffer for Hawkes process event intensity."""

    def __init__(self, mu: float = 0.5, alpha: float = 0.8, beta: float = 2.0, max_events: int = 1000):
        self.mu = float(mu)
        self.alpha = float(alpha)
        self.beta = float(beta)
        self.max_events = int(max_events)
        self.event_timestamps = collections.deque(maxlen=self.max_events)

    def push_event(self, t: Optional[float] = None) -> float:
        """Record an event timestamp and return the current instantaneous intensity lambda(t)."""
        now = float(t if t is not None else time.time())
        self.event_timestamps.append(now)
        return self.compute_intensity(now)

    def compute_intensity(self, current_time: Optional[float] = None) -> float:
        """Compute lambda(t) = mu + sum_{t_k < t} alpha * exp(-beta * (t - t_k))."""
        if not self.event_timestamps:
            return self.mu

        now = float(current_time if current_time is not None else time.time())
        t_arr = np.array(self.event_timestamps)
        diffs = now - t_arr
        valid_diffs = diffs[diffs >= 0]

        if len(valid_diffs) == 0:
            return self.mu

        # Exponential excitation sum
        excitations = np.sum(self.alpha * np.exp(-self.beta * valid_diffs))
        return float(self.mu + excitations)

    def is_micro_burst(self, threshold_multiplier: float = 3.0) -> bool:
        """Returns True if current event intensity is in a high-conviction micro-burst regime."""
        curr_intensity = self.compute_intensity()
        return curr_intensity >= (self.mu * threshold_multiplier)


class OrderFlowImbalanceStreamer:
    """Computes Level-2 Order Flow Imbalance (OFI) from order book depth updates."""

    def __init__(self):
        self.prev_bid_px = None
        self.prev_bid_sz = None
        self.prev_ask_px = None
        self.prev_ask_sz = None
        self.cumulative_ofi = 0.0

    def update_depth(self, bid_px: float, bid_sz: float, ask_px: float, ask_sz: float) -> float:
        """
        Calculates instantaneous OFI delta:
        OFI = Delta(Bid) - Delta(Ask)
        """
        if self.prev_bid_px is None:
            self.prev_bid_px = bid_px
            self.prev_bid_sz = bid_sz
            self.prev_ask_px = ask_px
            self.prev_ask_sz = ask_sz
            return 0.0

        # Bid delta
        if bid_px > self.prev_bid_px:
            delta_bid = bid_sz
        elif bid_px == self.prev_bid_px:
            delta_bid = bid_sz - self.prev_bid_sz
        else:
            delta_bid = -self.prev_bid_sz

        # Ask delta
        if ask_px < self.prev_ask_px:
            delta_ask = ask_sz
        elif ask_px == self.prev_ask_px:
            delta_ask = ask_sz - self.prev_ask_sz
        else:
            delta_ask = -self.prev_ask_sz

        instantaneous_ofi = float(delta_bid - delta_ask)
        self.cumulative_ofi += instantaneous_ofi

        # Update cached previous state
        self.prev_bid_px = bid_px
        self.prev_bid_sz = bid_sz
        self.prev_ask_px = ask_px
        self.prev_ask_sz = ask_sz

        return instantaneous_ofi


class StreamingVPINAccumulator:
    """Online Bulk Volume Classification (BVC) VPIN accumulator."""

    def __init__(self, bucket_size_volume: float = 50000.0, num_buckets: int = 50):
        self.bucket_volume = float(bucket_size_volume)
        self.num_buckets = int(num_buckets)
        self.current_bucket_vol = 0.0
        self.current_bucket_buy_vol = 0.0
        self.current_bucket_sell_vol = 0.0
        self.bucket_imbalances = collections.deque(maxlen=self.num_buckets)

    def add_trade(self, price: float, volume: float, prev_price: float, sigma: float = 0.01):
        """Processes trade with Bulk Volume Classification (BVC)."""
        if volume <= 0:
            return

        # BVC probability of buy
        ret = (price - prev_price) / max(prev_price, 1e-6) if prev_price > 0 else 0.0
        z_score = ret / max(sigma, 1e-6)
        # Normal CDF approximation
        prob_buy = 0.5 * (1.0 + math.erf(z_score / 1.41421356))
        buy_vol = volume * prob_buy
        sell_vol = volume * (1.0 - prob_buy)

        self.current_bucket_vol += volume
        self.current_bucket_buy_vol += buy_vol
        self.current_bucket_sell_vol += sell_vol

        if self.current_bucket_vol >= self.bucket_volume:
            imbalance = abs(self.current_bucket_buy_vol - self.current_bucket_sell_vol)
            self.bucket_imbalances.append(imbalance / self.current_bucket_vol)
            # Reset bucket
            self.current_bucket_vol = 0.0
            self.current_bucket_buy_vol = 0.0
            self.current_bucket_sell_vol = 0.0

    def compute_vpin(self) -> float:
        """Computes current rolling VPIN toxicity metric."""
        if not self.bucket_imbalances:
            return 0.0
        return float(np.mean(self.bucket_imbalances))
