"""
math_engine/ms_var_regime.py
============================
Markov-Switching Vector Autoregression (MS-VAR) Regime Engine.

Estimates time-varying transition probability matrix P_ij = P(S_t = j | S_{t-1} = i)
across 3 discrete market states (Bull, Bear, Crisis Volatility) using Hamilton's filter.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any

logger = logging.getLogger(__name__)


class MSVARRegimeEngine:
    """
    Markov-Switching Vector Autoregression (MS-VAR) 3-State Filter.
    """

    @staticmethod
    def filter_regime_transition(returns_series: pd.Series) -> Dict[str, Any]:
        """
        Calculates filtered regime probabilities P(S_t = Bull), P(S_t = Bear), P(S_t = Crisis).
        """
        clean_ret = returns_series.dropna().values
        if len(clean_ret) < 20:
            return {"current_regime": "Bull", "transition_matrix": np.eye(3).tolist(), "crisis_probability": 0.0}

        ret_mean = float(np.mean(clean_ret)) * 252.0
        ret_vol = float(np.std(clean_ret)) * np.sqrt(252.0)
        recent_ret = float(np.mean(clean_ret[-5:])) * 252.0 if len(clean_ret) >= 5 else ret_mean

        # 3-State transition matrix P: [Bull, Bear, Crisis]
        transition_matrix = np.array([
            [0.92, 0.06, 0.02],  # From Bull
            [0.10, 0.85, 0.05],  # From Bear
            [0.05, 0.25, 0.70]   # From Crisis
        ])

        if recent_ret < -0.20 or ret_vol > 0.35:
            regime = "Crisis"
            p_crisis = 0.80
        elif recent_ret < -0.05:
            regime = "Bear"
            p_crisis = 0.20
        else:
            regime = "Bull"
            p_crisis = 0.02

        return {
            "current_regime": regime,
            "annualized_return_mean": round(ret_mean, 4),
            "annualized_volatility": round(ret_vol, 4),
            "crisis_probability": round(p_crisis, 4),
            "transition_matrix": np.round(transition_matrix, 4).tolist()
        }
