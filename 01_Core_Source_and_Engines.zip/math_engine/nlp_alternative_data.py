"""math_engine/nlp_alternative_data.py
======================================
Alternative Data & Live NLP Sentiment Ingestion Engine.

Provides deep regulatory filing intelligence for Indian equities:
  1. Regulatory Announcement Analyzer: Scans exchange filings for key
     fundamental events (Capex, USFDA 483, Order Wins, Credit Ratings).
  2. Promoter Pledge Tracker: Tracks promoter share pledging under SEBI SAST
     disclosures (flags high-risk pledging > 20%).
  3. Earnings Concall Sentiment Engine: Extracts quantified sentiment views
     to generate Black-Litterman prior vectors (P and Q).
"""
from __future__ import annotations

import re
import logging
from typing import Any, Dict, List, Optional, Tuple
import numpy as np

logger = logging.getLogger("quantum_annealer.nlp_alt_data")

# Financial regulatory filing taxonomy patterns
FILING_CATALYSTS = {
    "CAPEX_EXPANSION": [
        r"\bcapital expenditure\b", r"\bcapex expansion\b", r"\bnew facility\b",
        r"\bcapacity expansion\b", r"\bgreenfield plant\b", r"\bbrownfield expansion\b",
        r"\bcommercial production\b", r"\binvestment of inr\b"
    ],
    "ORDER_WIN": [
        r"\breceives order\b", r"\bawarded contract\b", r"\bl1 bidder\b",
        r"\bmajor order win\b", r"\bcontract worth\b", r"\bexport order\b",
        r"\bsupply agreement\b", r"\bmulti-year agreement\b"
    ],
    "CREDIT_UPGRADE": [
        r"\brating upgraded\b", r"\boutlook revised to positive\b", r"\bupgraded from\b",
        r"\bcrisil aa\b", r"\bicra aaa\b", r"\bcare aa\b", r"\bind aa\b"
    ],
    "USFDA_CLEARANCE": [
        r"\busfda approval\b", r"\beir received\b", r"\banda approval\b",
        r"\bzero 483\b", r"\bno form 483\b", r"\binspection completed without observation\b"
    ],
    "USFDA_WARNING": [
        r"\bform 483\b", r"\bwarning letter\b", r"\bimport alert\b",
        r"\boai classification\b", r"\binspection observation\b"
    ],
    "PROMOTER_BUYING": [
        r"\bacquisition by promoter\b", r"\bpromoter increases stake\b",
        r"\bopen market purchase\b", r"\bpreferential allotment to promoter\b"
    ],
    "PROMOTER_PLEDGE": [
        r"\bpledge of shares\b", r"\bencumbrance of shares\b", r"\brelease of pledge\b",
        r"\binvocation of pledge\b"
    ],
}


class CorporateFilingNLPAnalyzer:
    """Extracts fundamental catalysts from NSE/BSE corporate filings."""

    @classmethod
    def analyze_filing(cls, headline: str, full_text: str = "") -> Dict[str, Any]:
        """Classify filing catalysts and compute directional sentiment score."""
        combined_text = f"{headline} {full_text}".lower()
        catalysts_found = []
        sentiment_score = 0.0

        for cat_name, patterns in FILING_CATALYSTS.items():
            for p in patterns:
                if re.search(p, combined_text):
                    catalysts_found.append(cat_name)
                    break

        # Calculate sentiment score
        bullish_categories = {"CAPEX_EXPANSION", "ORDER_WIN", "CREDIT_UPGRADE", "USFDA_CLEARANCE", "PROMOTER_BUYING"}
        bearish_categories = {"USFDA_WARNING"}

        bull_hits = sum(1 for c in catalysts_found if c in bullish_categories)
        bear_hits = sum(1 for c in catalysts_found if c in bearish_categories)

        if bull_hits > 0 or bear_hits > 0:
            sentiment_score = (bull_hits - bear_hits) / max(bull_hits + bear_hits, 1)

        return {
            "headline": headline,
            "catalysts": list(set(catalysts_found)),
            "sentiment_score": float(sentiment_score),
            "is_material": len(catalysts_found) > 0,
            "high_impact": "USFDA_WARNING" in catalysts_found or "ORDER_WIN" in catalysts_found or "CAPEX_EXPANSION" in catalysts_found,
        }


class PromoterPledgeTracker:
    """Monitors promoter share encumbrances and flags governance risk."""

    @classmethod
    def evaluate_pledge_risk(cls, ticker: str, promoter_holding_pct: float, pledged_shares_pct: float) -> Dict[str, Any]:
        """
        Evaluate promoter pledge risk.
        Pledged shares > 20% is considered Elevated Risk.
        Pledged shares > 50% is considered High Risk.
        """
        risk_level = "LOW"
        risk_penalty = 0.0

        if pledged_shares_pct >= 50.0:
            risk_level = "HIGH"
            risk_penalty = -0.35
        elif pledged_shares_pct >= 20.0:
            risk_level = "ELEVATED"
            risk_penalty = -0.15
        elif pledged_shares_pct > 0.0:
            risk_level = "MODERATE"
            risk_penalty = -0.05

        return {
            "ticker": ticker,
            "promoter_holding_%": float(promoter_holding_pct),
            "pledged_shares_%": float(pledged_shares_pct),
            "risk_level": risk_level,
            "risk_penalty": float(risk_penalty),
            "safe_for_accumulation": pledged_shares_pct < 20.0,
        }


class ConcallTranscriptSentimentEngine:
    """Parses earnings conference call transcripts into Black-Litterman prior views."""

    MANAGEMENT_POSITIVE_CUES = [
        r"\bconfident of achieving\b", r"\bdouble digit growth\b", r"\border pipeline is strong\b",
        r"\bmarket share gains\b", r"\bmargin expansion expected\b", r"\bdemand tailwinds\b",
        r"\bexpanding capacity\b", r"\breducing debt\b"
    ]
    MANAGEMENT_NEGATIVE_CUES = [
        r"\bdemand slowdown\b", r"\bmargin compression\b", r"\binput cost inflation\b",
        r"\bpricing pressure\b", r"\bgeopolitical headwinds\b", r"\bguidance lowered\b",
        r"\bdelayed capex\b", r"\bclient deferrals\b"
    ]

    @classmethod
    def extract_concall_views(
        cls,
        transcripts: Dict[str, str],
        confidence_scaler: float = 0.05,
    ) -> Dict[str, Any]:
        """
        Processes conference call transcripts for a basket of tickers and returns
        Black-Litterman view vectors Q and pick matrix P.
        """
        views_dict = {}
        tickers = list(transcripts.keys())
        n = len(tickers)
        P = np.zeros((n, n))
        Q = np.zeros(n)
        omega_diag = []

        for i, ticker in enumerate(tickers):
            text = transcripts[ticker].lower()
            pos_count = sum(len(re.findall(p, text)) for p in cls.MANAGEMENT_POSITIVE_CUES)
            neg_count = sum(len(re.findall(p, text)) for p in cls.MANAGEMENT_NEGATIVE_CUES)

            total = pos_count + neg_count
            sentiment = (pos_count - neg_count) / max(total, 1) if total > 0 else 0.0

            # Absolute expected excess return view
            expected_excess_return = sentiment * confidence_scaler
            P[i, i] = 1.0
            Q[i] = expected_excess_return
            # Variance inversely proportional to total match confidence
            omega_diag.append(max(0.001, 0.01 / max(total, 1)))

            views_dict[ticker] = {
                "sentiment_score": float(sentiment),
                "pos_cues": pos_count,
                "neg_cues": neg_count,
                "implied_view_alpha": float(expected_excess_return),
            }

        return {
            "per_ticker_views": views_dict,
            "P_matrix": P.tolist(),
            "Q_vector": Q.tolist(),
            "omega_diag": omega_diag,
        }
