"""
math_engine/onnx_inference.py
==============================
Vision/Temporal Dual-Tower ONNX inference bridge.
Maps chart images and time-series vectors to a 512-d fused latent embedding space.
Optimized with an active fallback to a Deterministic Projected Multi-Tower Projection Engine
if the physical ONNX weights are missing.
"""
from __future__ import annotations

import logging
import os
import threading
from pathlib import Path
from typing import List, Optional, Tuple, Dict, Any

import numpy as np
import pandas as pd
from numpy.typing import NDArray

logger = logging.getLogger(__name__)

_SEQ_LEN: int = 60
_N_FEAT: int = 5
_EMB_DIM: int = 512


class LatentEmbeddingGenerator:
    """Runs dual-tower ONNX models (visual image + temporal time-series features)

    to construct a unified 512-dimensional retrieval embedding.
    """

    def __init__(self, model_path: Optional[str | Path] = None) -> None:
        """Create an ONNX session for the dual-tower model.

        If the model file does not exist, transparently falls back to a Deterministic
        Multi-Tower Projection Engine to enable offline test executions.
        """
        self._is_mock = False
        self._sess = None
        self._single_input = False  # Phase 6.1: track single-input models
        self._input_names: Dict[str, str] = {"image": "image_tensor", "ts": "feature_tensor"}
        self._output_names: Dict[str, str] = {
            "visual": "visual_embedding",
            "temporal": "temporal_embedding",
            "fused": "fused_embedding",
        }

        if model_path is None:
            self._is_mock = True
        else:
            path = Path(model_path).resolve()
            if not path.exists():
                logger.warning(
                    "[LatentEmbGen] Model path not found: %s. Falling back to Deterministic Projection Engine.",
                    path,
                )
                self._is_mock = True
            else:
                try:
                    import onnxruntime as ort

                    sess_opts = ort.SessionOptions()
                    sess_opts.enable_profiling = False
                    sess_opts.log_severity_level = 3
                    sess_opts.inter_op_num_threads = 1
                    sess_opts.intra_op_num_threads = 0

                    available = ort.get_available_providers()
                    providers = []
                    provider_options = []

                    if "CoreMLExecutionProvider" in available:
                        providers.append("CoreMLExecutionProvider")
                        provider_options.append({})

                    providers.append("CPUExecutionProvider")
                    provider_options.append({})

                    try:
                        self._sess = ort.InferenceSession(
                            str(path),
                            sess_options=sess_opts,
                            providers=providers,
                            provider_options=provider_options,
                        )
                    except Exception:
                        self._sess = ort.InferenceSession(
                            str(path),
                            sess_options=sess_opts,
                            providers=["CPUExecutionProvider"],
                        )

                    # Extract session details dynamically if possible
                    inputs = self._sess.get_inputs()
                    # Phase 6.1: Fixed single-input model handling.
                    # Previously: both "image" and "ts" keys were set to the same input name,
                    # so the feed dict {name: img, name: ts} silently overwrote img with ts.
                    # The visual tower was completely ignored for single-input models.
                    # Now: store a _single_input flag and the expected input shape so we can
                    # feed the correct tensor (or fall back to mock composer for fusion).
                    self._single_input = (len(inputs) == 1)
                    if len(inputs) >= 2:
                        self._input_names["image"] = inputs[0].name
                        self._input_names["ts"] = inputs[1].name
                    elif len(inputs) == 1:
                        self._input_names["image"] = inputs[0].name
                        self._input_names["ts"] = inputs[0].name
                        self._single_input_shape = inputs[0].shape  # e.g. [1, 4, 224, 224] or [1, 512]

                    if self._single_input:
                        logger.warning(
                            "[ONNX] Phase 6.1: Single-input model detected (input=%s, shape=%s). "
                            "Fused embedding will use mock composer; individual towers will feed "
                            "the correct tensor based on shape matching.",
                            self._input_names["image"], getattr(self, "_single_input_shape", "?"),
                        )

                    self._output_name = self._sess.get_outputs()[0].name
                    # H7-fix: refresh _output_names from the actual session outputs, not hardcoded defaults.
                    # Without this, any model whose output names deviate from the defaults silently degrades
                    # to mock-projection mode on every call (caught exception → _is_mock=True).
                    try:
                        _outs = self._sess.get_outputs()
                        if len(_outs) >= 3:
                            # Full dual-tower model: visual + temporal + fused
                            self._output_names["visual"]   = _outs[0].name
                            self._output_names["temporal"] = _outs[1].name
                            self._output_names["fused"]    = _outs[2].name
                        elif len(_outs) == 2:
                            # B28-fix: 2-output model (e.g. visual + fused only).
                            # Previously this fell through to the single-output branch
                            # and mapped all three slots to _outs[0].name — silently
                            # making temporal embedding identical to visual.
                            self._output_names["visual"]   = _outs[0].name
                            self._output_names["temporal"] = _outs[1].name
                            self._output_names["fused"]    = _outs[1].name
                        elif len(_outs) >= 1:
                            # Single-output model: use the same name for all three slots
                            self._output_names["visual"]   = _outs[0].name
                            self._output_names["temporal"] = _outs[0].name
                            self._output_names["fused"]    = _outs[0].name
                    except Exception:
                        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                        pass  # fall back to hardcoded defaults if introspection fails
                    self._warmed_up = False
                    self._warmup_lock = threading.Lock()
                    logger.info("[LatentEmbGen] Physical model loaded successfully from %s", path.name)
                except Exception as e:
                    logger.warning(
                        "[LatentEmbGen] Session creation failed: %s. Falling back to Deterministic Projection.",
                        e,
                    )
                    self._is_mock = True

        if self._is_mock:
            self._init_mock()

    def _init_mock(self) -> None:
        """Initialize mock projection matrices if they are not already initialized."""
        if not hasattr(self, "visual_proj"):
            # Set up reproducible projection matrices (seed=42)
            # L13-fix: low-rank projection to avoid 411MB resident per instance.
            # Hash-fold the flattened image to a 4096-dim intermediate, then project to 512.
            # Original full-rank matrix was 512 × (4*224*224) float32 ≈ 411MB per instance.
            _rng = np.random.default_rng(42)
            self.visual_proj = _rng.standard_normal((512, 4096)).astype(np.float32)
            self.visual_proj /= np.linalg.norm(self.visual_proj, axis=1, keepdims=True) + 1e-9
            # fold factor: how many flattened-image elements collapse into each of the 4096 slots.
            self._mock_visual_fold = (4 * 224 * 224) // 4096  # = 49

            # maps temporal features (512,) -> 512
            self.temporal_proj = _rng.standard_normal((512, 512), dtype=np.float32)
            self.temporal_proj /= np.linalg.norm(self.temporal_proj, axis=1, keepdims=True) + 1e-9

            from math_engine.fusion_model import FusedEmbeddingComposer
            self.composer = FusedEmbeddingComposer()
            logger.info("[LatentEmbGen] Running in Deterministic Projected Multi-Tower Mode")

    def _mock_visual_project(self, chart_image: np.ndarray) -> np.ndarray:
        """Project a 4-channel chart image to the 512-d mock visual embedding.

        L13-fix helper: pads/truncates the flattened image to the full 4*224*224 dim,
        then folds it down to 4096 dims (averaging `_mock_visual_fold` elements per slot)
        before applying the low-rank projection matrix.
        """
        flat_img = chart_image.flatten().astype(np.float32)
        full_dim = self.visual_proj.shape[1] * self._mock_visual_fold  # 200704
        if len(flat_img) < full_dim:
            flat_img = np.pad(flat_img, (0, full_dim - len(flat_img)), "constant")
        else:
            flat_img = flat_img[:full_dim]
        # Fold to 4096-dim intermediate by averaging non-overlapping chunks of size `_mock_visual_fold`.
        folded = flat_img.reshape(self.visual_proj.shape[1], self._mock_visual_fold).mean(axis=1)
        emb = self.visual_proj @ folded
        norm = float(np.linalg.norm(emb))
        return (emb / norm if norm > 1e-9 else np.zeros_like(emb)).astype(np.float32)

    def generate_visual_embedding(self, chart_image: np.ndarray) -> np.ndarray:
        """Encode a 4-channel visual chart image into a 512-dimensional embedding."""
        if self._is_mock:
            return self._mock_visual_project(chart_image)

        # Bug-fix #6 (MEDIUM): use the _single_input flag (set in constructor) to avoid
        # feed dict overwrite. When the model has only one input, _input_names["image"]
        # and _input_names["ts"] both point to the same name, so {name: img, name: dummy_ts}
        # silently overwrites the image with the dummy zero vector.
        _is_single_input = bool(getattr(self, "_single_input", False))

        # Physical ONNX path
        try:
            img_input = chart_image.reshape(1, 4, 224, 224).astype(np.float32)
            if _is_single_input:
                # Pure visual model — feed only the image. The model was trained
                # without a temporal tower, so it expects only the visual input.
                feed_dict = {self._input_names["image"]: img_input}
            else:
                # Dual-tower model — feed both image and a dummy zero ts vector.
                dummy_ts = np.zeros((1, 512), dtype=np.float32)
                feed_dict = {
                    self._input_names["image"]: img_input,
                    self._input_names["ts"]: dummy_ts,
                }
            outputs = self._sess.run(
                [self._output_names.get("visual", self._output_name)],
                feed_dict,
            )
            emb = outputs[0].squeeze()
            norm = float(np.linalg.norm(emb))
            return (emb / norm if norm > 1e-9 else np.zeros_like(emb)).astype(np.float32)
        except Exception as e:
            logger.warning("[LatentEmbGen] generate_visual_embedding physical inference failed: %s. Falling back to projection.", e, exc_info=True)
            self._is_mock = True
            self._init_mock()
            return self._mock_visual_project(chart_image)

    def generate_temporal_embedding(self, ts_features: np.ndarray) -> np.ndarray:
        """Encode a 1-D time-series feature vector into a 512-dimensional embedding."""
        if self._is_mock:
            # Projection dot product
            expected_dim = self.temporal_proj.shape[1]
            flat_ts = ts_features.flatten()
            if len(flat_ts) < expected_dim:
                flat_ts = np.pad(flat_ts, (0, expected_dim - len(flat_ts)), "constant")
            else:
                flat_ts = flat_ts[:expected_dim]

            emb = self.temporal_proj @ flat_ts
            norm = float(np.linalg.norm(emb))
            return (emb / norm if norm > 1e-9 else np.zeros_like(emb)).astype(np.float32)

        # Bug-fix #6 (MEDIUM): same single-input fix as visual — use _single_input flag.
        _is_single_input = bool(getattr(self, "_single_input", False))

        # Physical ONNX path
        try:
            ts_input = ts_features.reshape(1, 512).astype(np.float32)
            if _is_single_input:
                feed_dict = {self._input_names["ts"]: ts_input}
            else:
                dummy_img = np.zeros((1, 4, 224, 224), dtype=np.float32)
                feed_dict = {
                    self._input_names["image"]: dummy_img,
                    self._input_names["ts"]: ts_input,
                }
            outputs = self._sess.run(
                [self._output_names.get("temporal", self._output_name)],
                feed_dict,
            )
            emb = outputs[0].squeeze()
            norm = float(np.linalg.norm(emb))
            return (emb / norm if norm > 1e-9 else np.zeros_like(emb)).astype(np.float32)
        except Exception as e:
            logger.warning("[LatentEmbGen] generate_temporal_embedding physical inference failed: %s. Falling back to projection.", e, exc_info=True)
            self._is_mock = True
            self._init_mock()
            expected_dim = self.temporal_proj.shape[1]
            flat_ts = ts_features.flatten()
            if len(flat_ts) < expected_dim:
                flat_ts = np.pad(flat_ts, (0, expected_dim - len(flat_ts)), "constant")
            else:
                flat_ts = flat_ts[:expected_dim]
            emb = self.temporal_proj @ flat_ts
            norm = float(np.linalg.norm(emb))
            return (emb / norm if norm > 1e-9 else np.zeros_like(emb)).astype(np.float32)

    def generate_fused_embedding(
        self,
        chart_image: np.ndarray,
        ts_features: np.ndarray,
        context_emb: Optional[np.ndarray] = None,
        regime: Optional[str] = None,
        timeframe: str = "1d",
    ) -> np.ndarray:
        """Fuse visual and temporal towers to create a single normalized retrieval embedding."""
        v_emb = self.generate_visual_embedding(chart_image)
        t_emb = self.generate_temporal_embedding(ts_features)

        if self._is_mock:
            return self.composer.compose(v_emb, t_emb, context_emb, regime, timeframe)

        # Phase 6.1: For single-input models, can't feed both image and ts to one input.
        # Use the mock composer to fuse the individual tower embeddings instead.
        # Previously: the feed dict {name: img, name: ts} silently overwrote img with ts,
        # so the visual tower was completely ignored.
        if getattr(self, "_single_input", False):
            if not hasattr(self, "composer"):
                self._init_mock()
            return self.composer.compose(v_emb, t_emb, context_emb, regime, timeframe)

        try:
            img_input = chart_image.reshape(1, 4, 224, 224).astype(np.float32)
            ts_input = ts_features.reshape(1, 512).astype(np.float32)
            outputs = self._sess.run(
                [self._output_names.get("fused", self._output_name)],
                {self._input_names["image"]: img_input, self._input_names["ts"]: ts_input},
            )
            emb = outputs[0].squeeze()
            norm = float(np.linalg.norm(emb))
            return (emb / norm if norm > 1e-9 else np.zeros_like(emb)).astype(np.float32)
        except Exception as e:
            logger.warning("[LatentEmbGen] generate_fused_embedding physical inference failed: %s. Falling back to composer.", e, exc_info=True)
            self._is_mock = True
            self._init_mock()
            return self.composer.compose(v_emb, t_emb, context_emb, regime, timeframe)

    def generate_batch_embeddings(
        self,
        batch_inputs: List[Dict[str, np.ndarray]],
        regime: Optional[str] = None,
        timeframe: str = "1d",
    ) -> np.ndarray:
        """Compute fused embeddings for a batch of inputs in a single contiguous array."""
        embeddings = []
        for inp in batch_inputs:
            img = inp["image"]
            ts = inp["ts"]
            emb = self.generate_fused_embedding(img, ts, regime=regime, timeframe=timeframe)
            embeddings.append(emb)
        return np.array(embeddings, dtype=np.float32)

    def generate_embedding(self, ohlcv_df: pd.DataFrame) -> NDArray[np.float32]:
        """Legacy v2 fallback: extracts closes and maps them to a mock 512-d embedding."""
        close = ohlcv_df["close"].values if "close" in ohlcv_df.columns else ohlcv_df.iloc[:, 3].values
        if len(close) < 60:
            close = np.pad(close, (60 - len(close), 0), mode="edge")
        else:
            close = close[-60:]

        std = float(np.std(close))
        mean = float(np.mean(close))
        norm_close = (close - mean) / (std if std > 1e-9 else 1.0)

        # project norm_close (60,) to 512-d
        rng = np.random.default_rng(42)
        proj = rng.standard_normal((512, 60), dtype=np.float32)
        emb = proj @ norm_close
        norm = float(np.linalg.norm(emb))
        return (emb / norm if norm > 1e-9 else np.zeros_like(emb)).astype(np.float32)
