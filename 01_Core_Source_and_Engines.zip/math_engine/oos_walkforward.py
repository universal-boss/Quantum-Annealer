"""
math_engine/oos_walkforward.py
==============================
Point-in-time (walk-forward) selection-bias diagnostics.

AUDIT-FIX (Round 23 — R23-4): Rounds 20–22 DISCLOSED that the sweep's "OOS"
performance is measured on a basket that was prescreened on the full
lookback (retroactive-basket selection bias) — the headline Net Alpha
(26–70% ann.) magnitudes are artifacts of that design, honestly labeled but
never measured. This module QUANTIFIES the bias per run without pretending
to eliminate it:

  1. `walk_forward_selection_overlap`: at each of K historical fold
     boundaries, re-ranks the universe by the same trailing-momentum
     lookback the momentum screener uses, takes the top-N basket that
     WOULD have been selected point-in-time, and measures its overlap with
     the finally selected basket. Low overlap = the final basket could not
     have been known at most cutoffs → its full-window backtest is a
     retroactive artifact, and the honest expectation for live forward
     returns collapses toward the point-in-time baskets' returns.

  2. `fold_alpha_concentration`: splits the backtest window into K contiguous
     folds and reports per-fold realized alpha vs the benchmark, so an
     operator can see whether the headline alpha is broad-based or
     concentrated in a single regime episode (one lucky fold).

A full walk-forward RE-SELECTION (re-running the entire optimizer screen at
every cutoff inside the sweep) remains the structural fix; it multiplies
sweep runtime by K and is documented as the standing residual. These
diagnostics are the honest measurement layer until then — they never change
selection, they only measure how much of it is look-back leakage.

AUDIT-FIX (Round 24 — R24-1): the structural fix is now implemented BELOW as
`walk_forward_reselection_backtest`. It re-runs the SCREEN (the prescreen
factor scoring + ranking layer — the layer that created the retroactive-basket
bias) point-in-time at each of K cutoffs on the in-memory price/volume frames,
holds the point-in-time top-K basket to the next cutoff, and reports a
TRUE-OOS alpha that contains no look-back selection leakage, plus the measured
retroactive-basket bias (headline alpha minus true-OOS alpha). What it does
NOT re-run per cutoff (each disclosed in the payload): the QUBO solve/HRP
weighting (runtime x K — inverse-vol weights are used instead), the historical
earnings/F&O-ban/corporate-action blackouts, and the TOP_N liquidity pool
prescreen itself (the pool frame in memory is the full-lookback-prescreened
universe; liquidity ranking is comparatively stable, but momentum-mode pool
selection remains a disclosed residual).

AUDIT-FIX (Round 27 — R27-1): the live-data layer residual is closed to the
extent point-in-time inputs exist. Per cutoff, on strictly trailing data:
the QUBO PENALTY layers (beta / fold-local turnover / Barra factor-
concentration when enabled / Wasserstein DRO / same-sector off-diagonal when
a sector map is supplied) are rebuilt and injected into the QUBO-core
objective; the ML-alpha injection, the blackout filters, and the DRO/BL/
Kelly/MDP weighting layers above HRP replay through the PRODUCTION functions
when the caller supplies the corresponding point-in-time inputs (per-cutoff
ML predictions + DSR, a historical blackout calendar, the opt-in cfg flags).
Every run's method_disclosure enumerates exactly which layers were replayed
and which were NOT (with the reason) — the disclosure is now per-run, not a
static caveat.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path
import numpy as np
import pandas as pd
from typing import Dict, Any, List, Optional, Sequence, Tuple

logger = logging.getLogger(__name__)


def walk_forward_selection_overlap(
    close_df: pd.DataFrame,
    selected: Sequence[str],
    n_folds: int = 6,
    mom_lookback: int = 126,
    top_n: Optional[int] = None,
    min_history: Optional[int] = None,
) -> Dict[str, Any]:
    """Measure how historically stable the finally selected basket is.

    Args:
        close_df:      Close-price frame (index = trading dates, columns = tickers).
        selected:      The finally selected basket tickers.
        n_folds:       Number of historical fold boundaries to test.
        mom_lookback:  Trailing momentum window (days) used to rank the universe
                       at each cutoff — mirrors the screener's 6-month momentum
                       factor (126 trading days) by default.
        top_n:         Basket size the point-in-time screen would have picked
                       (defaults to len(selected)).
        min_history:   Minimum non-NaN price observations required for a ticker
                       to be rankable at a cutoff (defaults to mom_lookback).

    Returns a dict with per-fold overlap, the mean overlap, and an explicit
    `retroactive_basket_risk` verdict (LOW / MODERATE / HIGH). Degenerate
    inputs (empty frame, no history, empty selection) return an honest
    'insufficient data' verdict instead of fabricated numbers.
    """
    min_history = int(min_history if min_history is not None else mom_lookback)
    top_n = int(top_n if top_n is not None else len(selected))
    sel = [str(s).upper() for s in (selected or [])]
    base: Dict[str, Any] = {
        "n_folds": int(n_folds),
        "mom_lookback_days": int(mom_lookback),
        "top_n": top_n,
        "selected_count": len(sel),
    }
    if (close_df is None or close_df.empty or not sel or top_n <= 0
            or len(close_df.index) < mom_lookback + n_folds):
        return {
            **base,
            "folds": [],
            "mean_overlap_pct": None,
            "retroactive_basket_risk": "UNMEASURED (insufficient price history or empty selection)",
            "note": ("Point-in-time overlap needs at least mom_lookback + n_folds "
                     "observations of the universe; the run's price frame is shorter."),
        }

    dates = close_df.index
    total_len = len(dates)
    # Fold cutoffs: the last observation is fold K's "today"; earlier cutoffs
    # step back by an even stride so the K tested dates span the backtest tail.
    stride = max(1, (total_len - mom_lookback) // max(1, n_folds))
    cutoff_pos = [total_len - 1 - k * stride for k in range(n_folds)]
    cutoff_pos = sorted(p for p in cutoff_pos if p >= mom_lookback)

    cols = {str(c).upper(): c for c in close_df.columns}
    fold_rows: List[Dict[str, Any]] = []
    overlaps: List[float] = []
    for pos in cutoff_pos:
        cutoff_date = dates[pos]
        window = close_df.iloc[max(0, pos - mom_lookback): pos + 1]
        # Trailing momentum over the window for every ticker with full history
        pct = {}
        for c in close_df.columns:
            s = window[c].dropna()
            if len(s) >= min_history and float(s.iloc[0]) > 0:
                pct[str(c).upper()] = float(s.iloc[-1]) / float(s.iloc[0]) - 1.0
        if len(pct) < top_n:
            fold_rows.append({
                "cutoff_date": str(cutoff_date),
                "rankable_universe": len(pct),
                "overlap_pct": None,
                "note": "fewer rankable tickers than basket size at this cutoff",
            })
            continue
        ranked = sorted(pct.items(), key=lambda kv: kv[1], reverse=True)[:top_n]
        top_tickers = {t for t, _ in ranked}
        overlap = len(top_tickers.intersection(sel)) / len(sel) if sel else 0.0
        overlaps.append(overlap)
        fold_rows.append({
            "cutoff_date": str(cutoff_date),
            "rankable_universe": len(pct),
            "overlap_pct": round(overlap * 100.0, 1),
            "top_tickers_then": [t for t, _ in ranked][:10],
        })

    if not overlaps:
        return {
            **base,
            "folds": fold_rows,
            "mean_overlap_pct": None,
            "retroactive_basket_risk": "UNMEASURED (no fold produced a rankable universe)",
            "note": "Every cutoff lacked a rankable universe — overlap not computable.",
        }

    mean_overlap = float(np.mean(overlaps))
    if mean_overlap >= 0.50:
        verdict = "LOW (basket is historically stable under the momentum screen)"
    elif mean_overlap >= 0.25:
        verdict = "MODERATE (partial point-in-time stability)"
    else:
        verdict = ("HIGH — retroactive-basket artifact: the final basket would NOT "
                   "have been selected at most historical cutoffs; full-lookback "
                   "backtest alpha is look-ahead leakage")
    return {
        **base,
        "folds": fold_rows,
        "mean_overlap_pct": round(mean_overlap * 100.0, 1),
        "retroactive_basket_risk": verdict,
        "note": ("Overlap of the final basket with the point-in-time top-N momentum "
                 "basket at each historical cutoff. This DIAGNOSES selection bias; it "
                 "does not re-select. A full walk-forward re-selection remains the "
                 "structural fix (runtime x n_folds)."),
    }


def fold_alpha_concentration(
    portfolio_returns: pd.Series,
    benchmark_returns: pd.Series,
    n_folds: int = 6,
    trading_days: int = 252,
) -> Dict[str, Any]:
    """Split the backtest window into K folds and report per-fold alpha vs
    benchmark, plus the share of total positive alpha contributed by the
    single best fold.

    A basket whose alpha is >50% concentrated in one fold is regime-episode
    dependent, not a persistent edge — the diagnostic says so explicitly.
    Degenerate/short series return an honest 'insufficient data' verdict.
    """
    base: Dict[str, Any] = {"n_folds": int(n_folds)}
    if (portfolio_returns is None or benchmark_returns is None
            or len(portfolio_returns) < n_folds * 10):
        return {
            **base,
            "folds": [],
            "best_fold_share_pct": None,
            "alpha_concentration_verdict": "UNMEASURED (insufficient return history)",
            "note": "Fold alpha needs a return series at least n_folds x 10 long.",
        }
    pr = portfolio_returns.dropna()
    br = benchmark_returns.reindex(pr.index).fillna(0.0)
    n = len(pr)
    fold_len = max(1, n // n_folds)
    fold_rows: List[Dict[str, Any]] = []
    alphas: List[float] = []
    for k in range(n_folds):
        seg = slice(k * fold_len, (k + 1) * fold_len) if k < n_folds - 1 else slice(k * fold_len, n)
        p_seg, b_seg = pr.iloc[seg], br.iloc[seg]
        if len(p_seg) == 0:
            continue
        p_tot = float(np.prod(1.0 + p_seg.values) - 1.0)
        b_tot = float(np.prod(1.0 + b_seg.values) - 1.0)
        alpha = p_tot - b_tot
        alphas.append(alpha)
        fold_rows.append({
            "fold": k + 1,
            "start": str(p_seg.index[0]),
            "end": str(p_seg.index[-1]),
            "days": int(len(p_seg)),
            "portfolio_total_pct": round(p_tot * 100.0, 2),
            "benchmark_total_pct": round(b_tot * 100.0, 2),
            "fold_alpha_pct": round(alpha * 100.0, 2),
            "annualized_alpha_pct": round(alpha * 100.0 * trading_days / max(1, len(p_seg)), 2),
        })
    pos_total = sum(a for a in alphas if a > 0)
    best = max(alphas) if alphas else None
    if pos_total <= 0 or best is None or best <= 0:
        return {
            **base,
            "folds": fold_rows,
            "best_fold_share_pct": None,
            "alpha_concentration_verdict": "NO POSITIVE ALPHA to concentrate",
            "note": "No fold produced positive alpha vs the benchmark.",
        }
    share = best / pos_total
    verdict = (
        f"CONCENTRATED — {share:.0%} of positive alpha comes from the single best "
        f"of {n_folds} folds (regime-episode dependent, not a persistent edge)"
        if share > 0.50 else
        f"BROAD-BASED — best fold contributes {share:.0%} of positive alpha"
    )
    return {
        **base,
        "folds": fold_rows,
        "total_alpha_pct": round(sum(alphas) * 100.0, 2),
        "best_fold_share_pct": round(share * 100.0, 1),
        "alpha_concentration_verdict": verdict,
        "note": ("Per-fold realized alpha of the SELECTED basket (diagnostic only — "
                 "the basket was still selected on the full lookback, so per-fold "
                 "alpha remains in-sample for selection; concentration flags "
                 "regime dependence)."),
    }


# ═════════════════════════════════════════════════════════════════════════
# AUDIT-FIX (Round 24 — R24-1): FULL WALK-FORWARD RE-SELECTION
# ═════════════════════════════════════════════════════════════════════════

_MIN_FORWARD_DAYS = 10      # a fold's forward window must be at least this long
_MIN_RANKABLE_COVER = 0.80  # a ticker needs >= 80% non-NaN prices in the window


def _robust_z_cross(vals: Dict[str, float]) -> Dict[str, float]:
    """Robust cross-sectional z: (x - median) / (1.4826 * MAD).

    Mirrors the prescreen's robust_zscore semantics without importing utils
    (avoids a circular import). Degenerate spreads (MAD ~ 0) fall back to a
    plain standard deviation; still degenerate -> all zeros (neutral factor).
    """
    arr = np.array([v for v in vals.values() if np.isfinite(v)], dtype=float)
    if arr.size < 3:
        return {k: 0.0 for k in vals}
    med = float(np.median(arr))
    mad = float(np.median(np.abs(arr - med)))
    scale = 1.4826 * mad
    if scale < 1e-12:
        scale = float(np.std(arr))
    if scale < 1e-12:
        return {k: 0.0 for k in vals}
    return {k: ((v - med) / scale if np.isfinite(v) else 0.0) for k, v in vals.items()}


# Mode -> factor weight mapping, mirroring the LIVE prescreen scoring in
# optimizer.run_optimizer_logic (same coefficients, same sign conventions).
# Factors not computable point-in-time from Close/Volume frames alone
# (cmf needs intraday High/Low) enter as neutral zero z-scores — disclosed.
_RESELECT_MODE_WEIGHTS: Dict[str, Dict[str, float]] = {
    "breakout_early":  {"z_vcp": 0.35, "z_obv_slope": 0.25, "z_cmf": 0.20, "z_adv20": 0.20},
    "vol_squeeze":     {"z_vcp": 0.35, "z_obv_slope": 0.25, "z_cmf": 0.20, "z_adv20": 0.20},
    "accumulation":    {"z_cmf": 0.30, "z_updown_vol": 0.25, "z_obv_slope": 0.25, "z_adv20": 0.20},
    "momentum_chase":  {"z_mom_3m": 0.50, "z_rs_raw": 0.25, "z_adv20": 0.25},
    "quality_defensive":  {"z_cmf": 0.35, "z_rs_raw": 0.30, "z_adv20": 0.20, "z_ann_vol": -0.15},
    "quality_compounders": {"z_cmf": 0.35, "z_rs_raw": 0.30, "z_adv20": 0.20, "z_ann_vol": -0.15},
    "garp":            {"z_mom_6m": 0.35, "z_cmf": 0.30, "z_rs_raw": 0.20, "z_adv20": 0.15},
    "pure_defensive":  {"z_cmf": 0.40, "z_ann_vol": -0.35, "z_adv20": 0.25},
    "defense":         {"z_cmf": 0.40, "z_ann_vol": -0.35, "z_adv20": 0.25},
    "institutional_alpha": {"z_rs_raw": 0.30, "z_obv_slope": 0.25, "z_cmf": 0.25, "z_adv20": 0.20},
    "early_entry":     {"z_vcp": 0.30, "z_updown_vol": 0.25, "z_range_contraction": 0.20,
                        "z_obv_slope": 0.15, "z_adv20": 0.10, "z_mom_1m_penalty": -0.40},
    "balanced":        {"z_mom_6m": 0.55, "z_cmf": 0.15, "z_adv20": 0.30},
}


# ═════════════════════════════════════════════════════════════════════════
# AUDIT-FIX (Round 25 — R25-1): ALLOCATION-LAYER REPLAY (QUBO-core + HRP)
# ═════════════════════════════════════════════════════════════════════════
# The R24 disclosure honestly stated the re-selection did NOT replay the
# QUBO/HRP allocation per cutoff (runtime x K) nor the TOP_N pool prescreen
# (needs full-universe history). This round closes both:
#   * `_qubo_core_select` rebuilds the production QUBO's core objective
#     (alpha diagonal + vol penalty + correlation off-diagonal + cardinality)
#     on trailing data and solves it with the production greedy-seed +
#     first-improvement local search — the same solve family the live sweep
#     uses in "Greedy" mode;
#   * `_hrp_weights_replay` calls the PRODUCTION `optimizer.hrp_weights`
#     itself on each fold's trailing returns (local mirror fallback);
#   * `top_n_pool` applies the point-in-time TOP_N pool cut per cutoff when
#     the caller passes a frame larger than the pool (the opt-in
#     WFO_POOL_FULL_UNIVERSE supersample mode in optimizer.run_optimizer_logic).
# AUDIT-FIX (Round 27 — R27-1): the previously NOT-replayed live-data layers
# are now replayed per cutoff to the extent point-in-time inputs exist:
#   * `_point_in_time_penalties` rebuilds the production QUBO's beta /
#     turnover (fold-local holdings) / Barra / DRO penalty terms on trailing
#     data and injects them into the QUBO-core diagonal (plus the same-sector
#     off-diagonal penalty when a sector map is supplied);
#   * `ml_alpha_by_cutoff` + `ml_dsr_by_cutoff` replay the ML-alpha injection
#     with the PRODUCTION Phase-9 semantics (z-blend, DSR-scaled weight,
#     DSR-missing -> injection refused);
#   * `blackouts_by_symbol` replays the earnings/F&O-ban/corporate-action
#     blackout filters on a caller-supplied historical calendar;
#   * `_weighting_stack_replay` runs the PRODUCTION DRO-CVaR / BL / Kelly /
#     MDP weighting layers above HRP under the same cfg opt-in flags as the
#     live pipeline.
# Still NOT replayed (disclosed per run): the regime tilt of the alpha
# composite (no point-in-time regime state), CMF (no intraday High/Low), and
# any layer whose point-in-time input was not supplied.

# Production DEFAULT_CFG fallbacks (the call site passes the run's working_cfg).
_QUBO_REPLAY_DEFAULTS: Dict[str, Any] = {
    "ALPHA": 1.8, "VOL_PENALTY": 0.35,
    "GAMMA_CARDINALITY": 12.0, "GAMMA_RISK": 12.0, "THETA": 4.0,
    "MIN_WEIGHT": 0.0, "MAX_WEIGHT": 0.50,
}


def _qubo_core_select(
    candidates: List[str],
    alpha_z: Dict[str, float],
    vol_z: Dict[str, float],
    corr: Optional[pd.DataFrame],
    k_stocks: int,
    qubo_cfg: Optional[Dict[str, Any]],
    extra_diag: Optional[Dict[str, float]] = None,
    sectors: Optional[Dict[str, str]] = None,
    sector_penalty: float = 0.0,
    unknown_sector_penalty: float = 0.0,
) -> List[str]:
    """Point-in-time QUBO-CORE selection (AUDIT-FIX Round 25 — R25-1).

    Mirrors optimizer.build_qubo's core objective on strictly trailing data:
        q[s,s]   = ( -ALPHA*alpha_z[s] + VOL_PENALTY*vol_z[s]
                     + GAMMA_CARD*(1 - 2K) ) / N
        q[si,sj] = ( 2*GAMMA_RISK + THETA*sqrt(N/K)*corr_ij ) / N
    minimized over K-subsets with the production greedy seed (alpha-ranked)
    + first-improvement local search (mirrors utils.local_search_improve and
    optimizer.solve_qubo's Greedy path). Alpha term mapping: the mode-weighted
    composite z (production uses the risk-deflated alpha on the same factor
    family); risk term mapping: z(annualized vol) (production risk_score is a
    vol-dominated composite). Deterministic — no SA sampling noise.

    AUDIT-FIX (Round 27 — R27-1): `extra_diag` injects the point-in-time
    PENALTY-layer terms (beta / fold-local turnover / Barra / DRO) into the
    diagonal; `sectors` + penalties add the production same-sector /
    unknown-sector off-diagonal concentration terms (mirroring build_qubo's
    _sec_pen / _unk_pen, gated by ENABLE_SECTOR_CAP at the call site). Both
    default to no-op, so the R25 contract is unchanged.
    """
    n = len(candidates)
    if n == 0:
        return []
    k = max(1, min(int(k_stocks), n))
    cfg = {**_QUBO_REPLAY_DEFAULTS, **(qubo_cfg or {})}
    alpha_w = float(cfg.get("ALPHA", 1.8))
    vol_pen = float(cfg.get("VOL_PENALTY", 0.35))
    gamma_card = float(cfg.get("GAMMA_CARDINALITY", cfg.get("GAMMA", 12.0)))
    gamma_risk = float(cfg.get("GAMMA_RISK", cfg.get("GAMMA", 12.0)))
    theta = float(cfg.get("THETA", 4.0))
    theta_scaled = theta * (n / k) ** 0.5

    idx = {s: i for i, s in enumerate(candidates)}
    Q = np.zeros((n, n), dtype=float)
    for s in candidates:
        base = (-alpha_w * float(alpha_z.get(s, 0.0))
                + vol_pen * float(vol_z.get(s, 0.0))
                + float((extra_diag or {}).get(s, 0.0)))
        Q[idx[s], idx[s]] = (base + gamma_card * (1.0 - 2.0 * k)) / float(n)
    for i, si in enumerate(candidates):
        for sj in candidates[i + 1:]:
            cij = 0.0
            if corr is not None and si in corr.index and sj in corr.columns:
                try:
                    cij = float(corr.loc[si, sj])
                except Exception:
                    cij = 0.0
            if not np.isfinite(cij):
                cij = 0.0
            cij = min(max(cij, -0.95), 0.95)
            pair_pen = 2.0 * gamma_risk + theta_scaled * cij
            # AUDIT-FIX (Round 27 — R27-1): production same-sector / unknown-
            # sector off-diagonal concentration penalties (build_qubo's
            # _sec_pen / _unk_pen mirror), applied only when a sector map is
            # supplied and the call site gated them via ENABLE_SECTOR_CAP.
            if sectors is not None:
                _sec_i = str(sectors.get(si) or "").strip().upper()
                _sec_j = str(sectors.get(sj) or "").strip().upper()
                _is_unk_i = _sec_i in ("", "NONE", "UNKNOWN", "N/A", "NAN", "NULL")
                _is_unk_j = _sec_j in ("", "NONE", "UNKNOWN", "N/A", "NAN", "NULL")
                if _is_unk_i or _is_unk_j:
                    pair_pen += float(unknown_sector_penalty)
                elif _sec_i == _sec_j:
                    pair_pen += float(sector_penalty)
            pen = pair_pen / float(n)
            # symmetric halves so an ix-sum counts each pair exactly once
            Q[idx[si], idx[sj]] = pen / 2.0
            Q[idx[sj], idx[si]] = pen / 2.0

    def _energy(subset_names: List[str]) -> float:
        ids = [idx[s] for s in subset_names]
        return float(Q[np.ix_(ids, ids)].sum()) if ids else 0.0

    # Greedy seed: alpha-ranked (mirrors solve_qubo's ranked greedy)
    ranked = sorted(candidates, key=lambda s: float(alpha_z.get(s, 0.0)), reverse=True)
    current = list(ranked[:k])
    cur_energy = _energy(current)

    # First-improvement local search (mirrors utils.local_search_improve)
    pool = ranked[: max(30, 4 * k)]
    for _ in range(30):
        improved = False
        for out_s in list(current):
            base = [s for s in current if s != out_s]
            for in_s in pool:
                if in_s in base:
                    continue
                e = _energy(base + [in_s])
                if e + 1e-9 < cur_energy:
                    current = base + [in_s]
                    cur_energy = e
                    improved = True
                    break
            if improved:
                break
        if not improved:
            break
    return current[:k]


def _hrp_local_mirror(selected: List[str], ret_sub: pd.DataFrame) -> Dict[str, float]:
    """Local HRP mirror of optimizer.hrp_weights (same Lopez de Prado
    recursion; raw correlation instead of the Ledoit-Wolf shrunk matrix —
    used only when the production function cannot be imported)."""
    n = len(selected)
    if n == 0:
        return {}
    if n < 3 or ret_sub.shape[0] < 20:
        return {s: 1.0 / n for s in selected}
    try:
        from scipy.cluster.hierarchy import linkage, to_tree
        corr = ret_sub.corr().values
        cov_raw = ret_sub.cov().values
        vols = np.sqrt(np.maximum(np.diag(cov_raw), 1e-12))
        cov = np.outer(vols, vols) * corr
        dist = np.sqrt(np.clip((1.0 - corr) / 2.0, 0.0, 1.0))
        ut = dist[np.triu_indices(n, k=1)]
        if float(ut.max()) < 1e-3:
            return {s: 1.0 / n for s in selected}
        method = "ward" if n >= 15 else "average"
        root, _ = to_tree(linkage(ut, method=method), rd=True)

        def _cluster_var(idxs):
            sub_cov = cov[np.ix_(idxs, idxs)]
            w_iv = 1.0 / np.maximum(np.diag(sub_cov), 1e-12)
            w_iv /= w_iv.sum()
            return float(w_iv @ sub_cov @ w_iv)

        def _recurse(node, alloc):
            if node.is_leaf():
                return {node.id: alloc}
            left_ids, right_ids = node.left.pre_order(), node.right.pre_order()
            var_l, var_r = _cluster_var(left_ids), _cluster_var(right_ids)
            total = var_l + var_r + 1e-12
            split = var_r / total if total != 0 else 0.5
            out = {}
            out.update(_recurse(node.left, alloc * split))
            out.update(_recurse(node.right, alloc * (1.0 - split)))
            return out

        raw = _recurse(root, 1.0)
        weights = {selected[i]: raw.get(i, 1.0 / n) for i in range(n)}
        total = sum(weights.values()) or 1.0
        return {k: v / total for k, v in weights.items()}
    except Exception:
        return {s: 1.0 / n for s in selected}


def _hrp_weights_replay(
    basket: List[str],
    trailing_rets: pd.DataFrame,
    weight_cfg: Optional[Dict[str, Any]] = None,
) -> tuple:
    """HRP weighting replay (AUDIT-FIX Round 25 — R25-1).

    Calls the PRODUCTION `optimizer.hrp_weights` on the fold's trailing
    returns (lazy import — the sweep imports optimizer long before this runs);
    if that import fails (hermetic tests / stripped envs) a local mirror of
    the same recursion stands in, disclosed via the returned source label.
    Then the production weight bounds are applied (clip to
    [MIN_WEIGHT, MAX_WEIGHT] + renormalize, mirroring
    calculate_qubo_aware_weights' lo/hi feasibility adjustments — no CASH
    sleeve in the replay).

    Returns (weights_dict, source_label).
    """
    if not basket:
        return {}, "n/a (empty basket)"
    cols = [c for c in basket if c in trailing_rets.columns]
    if not cols:
        return {s: 1.0 / len(basket) for s in basket}, "equal-weight (no return history for basket names)"
    ret_sub = trailing_rets[cols].fillna(0.0)
    cfg = {**_QUBO_REPLAY_DEFAULTS, **(weight_cfg or {})}
    src = "local HRP mirror (production import unavailable)"
    w: Dict[str, float] = {}
    try:
        from optimizer import hrp_weights as _prod_hrp  # production function itself
        w = _prod_hrp(list(cols), ret_sub, cfg=dict(cfg)) or {}
        src = "production optimizer.hrp_weights() replayed point-in-time"
    except Exception:
        w = _hrp_local_mirror(list(cols), ret_sub)
    if not w or len(w) != len(cols):
        w = {s: 1.0 / len(cols) for s in cols}
        src += " (fell back to equal-weight)"

    # Production weight bounds (mirror calculate_qubo_aware_weights lo/hi logic)
    return _clip_weights(w, cfg), src


def _clip_weights(w: Dict[str, float], cfg: Optional[Dict[str, Any]]) -> Dict[str, float]:
    """Production weight bounds: clip to [MIN_WEIGHT, MAX_WEIGHT] +
    renormalize (mirrors calculate_qubo_aware_weights / apply_weight_constraints
    lo/hi feasibility adjustments). Degenerate totals fall back to equal-weight.
    AUDIT-FIX (Round 27 — R27-1): extracted so the weighting-stack replay can
    re-enforce the same bounds after every production layer override."""
    if not w:
        return {}
    n = len(w)
    lo = max(0.0, float((cfg or {}).get("MIN_WEIGHT", 0.0)))
    hi = min(1.0, float((cfg or {}).get("MAX_WEIGHT", 0.50)))
    if lo * n > 1.0:
        lo = 0.0
    if hi * n < 1.0:
        hi = 1.0
    clipped = {k: min(max(float(v), lo), hi) for k, v in w.items()}
    total = sum(clipped.values())
    if total <= 0:
        return {k: 1.0 / n for k in clipped}
    return {k: v / total for k, v in clipped.items()}


# ═════════════════════════════════════════════════════════════════════
# AUDIT-FIX (Round 27 — R27-1): POINT-IN-TIME LAYER REPLAY HELPERS
# (QUBO penalty layers, ML-alpha injection, blackouts, weighting stack)
# ═════════════════════════════════════════════════════════════════════

def _point_in_time_betas(win_close: pd.DataFrame,
                         bench_rets_window: Optional[pd.Series]) -> Dict[str, Dict[str, float]]:
    """Trailing 63d beta-vs-benchmark deviation and annualized downside vol
    per ticker, on strictly trailing data. Mirrors the z_beta_dev /
    downside_vol inputs of the production QUBO penalty layers (beta deviation
    from 1.0; downside vol = std of negative daily returns, annualized).
    Degenerate benchmark variance leaves beta_dev at 0 (neutral)."""
    rets = win_close.pct_change()
    out: Dict[str, Dict[str, float]] = {}
    for tkr in win_close.columns:
        r = rets[tkr].dropna()
        beta_dev = 0.0
        if bench_rets_window is not None and len(r) >= 40:
            b = bench_rets_window.reindex(r.index).fillna(0.0)
            var_b = float(np.var(b.values))
            if var_b > 1e-12:
                beta = float(np.cov(r.values, b.values)[0, 1] / var_b)
                beta_dev = beta - 1.0
        neg = r[r < 0]
        dvol = float(neg.std() * np.sqrt(252.0)) if len(neg) >= 5 else 0.0
        out[str(tkr)] = {"beta_dev": beta_dev, "downside_vol": dvol}
    return out


def _point_in_time_penalties(
    candidates: List[str],
    zs: Dict[str, Dict[str, float]],
    prev_basket: List[str],
    beta_map: Dict[str, Dict[str, float]],
    cfg: Optional[Dict[str, Any]],
) -> Tuple[Dict[str, float], List[str]]:
    """Per-candidate EXTRA QUBO-diagonal penalty terms, all point-in-time.

    Mirrors optimizer.build_qubo's live-data penalty layers on trailing data:
      * beta_cost        = BETA_PENALTY x z(beta_dev)          (production col z_beta_dev)
      * turnover_cost    = TURNOVER_PENALTY for names NOT in the fold-local
                           holdings (the previous cutoff's basket); held names
                           earn the STCG retention bonus
                           -TURNOVER_PENALTY x (STCG_TURNOVER_FACTOR - 1)
                           (production tax-aware churn deterrent, fold-local)
      * barra_conc_cost  = FACTOR_CONC_PENALTY x sum over the risk-factor family
                           {z_mom_6m, z_mom_3m, z_ann_vol, z_beta_dev,
                            z_downside_vol} of max(0, |z| - FACTOR_EXPOSURE_THRESH)
      * dro_cost         = WASSERSTEIN_DRO_EPSILON x max(0, downside_vol)
    Returns (extra_diag, applied_layer_names). All terms default to production
    defaults; zero-coefficient layers are reported as not applied.
    """
    cfg = cfg or {}
    beta_pen = float(cfg.get("BETA_PENALTY", 1.0))
    turn_pen = float(cfg.get("TURNOVER_PENALTY", 0.0))
    stcg_fac = float(cfg.get("STCG_TURNOVER_FACTOR", cfg.get("STCG_PENALTY_FACTOR", 2.0)))  # Round 41: honor documented key
    fconc = float(cfg.get("FACTOR_CONC_PENALTY", 0.0))
    fthresh = float(cfg.get("FACTOR_EXPOSURE_THRESH", 1.5))
    dro_eps = float(cfg.get("WASSERSTEIN_DRO_EPSILON", 0.05))
    prev = {str(s).upper() for s in (prev_basket or [])}

    beta_dev = {t: float(beta_map.get(t, {}).get("beta_dev", 0.0)) for t in candidates}
    dvol = {t: float(beta_map.get(t, {}).get("downside_vol", 0.0)) for t in candidates}
    z_beta = _robust_z_cross(beta_dev)
    z_dvol = _robust_z_cross(dvol)

    extra: Dict[str, float] = {}
    for t in candidates:
        beta_cost = beta_pen * float(z_beta.get(t, 0.0))
        if prev and str(t).upper() in prev:
            # held since the previous cutoff (< 365d by construction) — the
            # production retention bonus keeps the annealer sticky on them
            turnover_cost = -turn_pen * max(0.0, stcg_fac - 1.0)
        else:
            turnover_cost = turn_pen
        barra_cost = 0.0
        if fconc > 0.0:
            excess = 0.0
            for zf in (zs.get("mom_6m", {}).get(t, 0.0),
                       zs.get("mom_3m", {}).get(t, 0.0),
                       zs.get("ann_vol", {}).get(t, 0.0),
                       z_beta.get(t, 0.0),
                       z_dvol.get(t, 0.0)):
                excess += max(0.0, abs(float(zf)) - fthresh)
            barra_cost = fconc * excess
        dro_cost = dro_eps * max(0.0, dvol.get(t, 0.0))
        extra[t] = beta_cost + turnover_cost + barra_cost + dro_cost

    applied = ["beta"]
    if turn_pen > 0.0:
        applied.append("turnover(fold-local)")
    if fconc > 0.0:
        applied.append("Barra")
    applied.append("DRO")
    return extra, applied


def _ml_replay_weight(cfg: Optional[Dict[str, Any]], dsr: Optional[float]) -> float:
    """Production Phase-9 ML weight gate (optimizer.py ML DSR scaling):
    w = ML_ALPHA_WEIGHT x clip((DSR - ML_DSR_FLOOR)/(1 - floor), 0, 1);
    DSR not measured (None) -> weight 0 (injection refused — the R20-8
    honest-None semantics)."""
    if dsr is None or not np.isfinite(float(dsr)):
        return 0.0
    base = float((cfg or {}).get("ML_ALPHA_WEIGHT", 0.30))
    floor = float((cfg or {}).get("ML_DSR_FLOOR", 0.10))
    return base * float(np.clip((float(dsr) - floor) / max(1.0 - floor, 1e-9), 0.0, 1.0))


def _ml_blend_scores(scores: Dict[str, float], ml_scores: Dict[str, float],
                     ml_weight: float) -> Dict[str, float]:
    """Production ML-alpha blend semantics (optimizer.py Phase 9):
    alpha = z(alpha) x (1 - w) + z(ml) x w with plain (mean/std) z-scores,
    applied over the matched names; unmatched names keep their raw score
    (disclosed mirror — the live pipeline blends the full signal frame).
    """
    matched = [t for t in scores if t in ml_scores and np.isfinite(float(ml_scores[t]))]
    if not matched:
        return dict(scores)
    a = np.array([float(scores[t]) for t in matched], dtype=float)
    m = np.array([float(ml_scores[t]) for t in matched], dtype=float)
    a_std = float(a.std())
    m_std = float(m.std())
    z_a = (a - float(a.mean())) / (a_std if a_std > 1e-12 else 1.0)
    z_m = (m - float(m.mean())) / (m_std if m_std > 1e-12 else 1.0)
    blended = z_a * (1.0 - ml_weight) + z_m * ml_weight
    out = dict(scores)
    for i, t in enumerate(matched):
        out[t] = float(blended[i])
    return out


# AUDIT-FIX (Round 29 — R29-4): the cutoff grid is extracted to a SINGLE
# source of truth so the sweep-side ML retraining driver (R29-3) computes
# the exact same cutoffs as the replay — drift-free by construction.
def reselect_cutoff_positions(
    total_len: int,
    score_lookback: int,
    n_folds: int,
    min_forward_days: Optional[int] = None,
) -> List[int]:
    """The deterministic R24 re-selection cutoff grid: positions
    [score_lookback + i * stride] with stride = max(min_forward_days,
    span // n_folds), filtered to < usable_end. Identical semantics to the
    inline computation it replaces (behavior-locked by the R29 tests)."""
    mfd = _MIN_FORWARD_DAYS if min_forward_days is None else max(1, int(min_forward_days))
    total_len = int(total_len)
    score_lookback = int(score_lookback)
    n_folds = int(n_folds)
    usable_end = total_len - 1
    span = usable_end - score_lookback
    if span < n_folds * mfd:
        return []
    stride = max(mfd, span // n_folds)
    cutoff_pos = [score_lookback + i * stride for i in range(n_folds)]
    return sorted(p for p in cutoff_pos if p < usable_end)


_BLACKOUT_CALENDAR_DEFAULT_PATH = Path(__file__).resolve().parent.parent / "qa_db" / "earnings_calendar_history.json"


def load_blackout_calendar_file(
    path: Optional[Any] = None,
    symbols: Optional[Sequence[str]] = None,
) -> Optional[Dict[str, Sequence[str]]]:
    """Load the R29-1 historical earnings-calendar artifact
    (qa_db/earnings_calendar_history.json — skip-if-absent, never raises).

    Returns {SYMBOL.NS: ["YYYY-MM-DD", ...]} restricted to `symbols` when a
    list is given (the replay pool), else every symbol with events. A
    missing or corrupt file returns None — the caller discloses
    not-replayed, exactly like the FMV feed's skip-if-absent contract."""
    p = Path(path) if path is not None else _BLACKOUT_CALENDAR_DEFAULT_PATH
    try:
        obj = json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None
    cal = obj.get("calendar") if isinstance(obj, dict) else None
    if not isinstance(cal, dict):
        return None
    if symbols is None:
        out = {str(t): list(v) for t, v in cal.items() if isinstance(v, list) and v}
    else:
        want = {str(s) for s in symbols}
        out = {str(t): list(v) for t, v in cal.items()
               if str(t) in want and isinstance(v, list) and v}
    return out or None


def _blackout_replay_filter(
    candidates: List[str],
    cutoff_date: Any,
    blackouts_by_symbol: Dict[str, Sequence[Any]],
    window_days: int = 5,
) -> Tuple[List[str], List[str]]:
    """Blackout replay: drop candidates with a blackout event (earnings /
    F&O ban / corporate action) within +/- window_days CALENDAR days of the
    cutoff — mirroring data_layer.apply_earnings_blackout's +/- blackout_days
    semantics on a CALLER-SUPPLIED historical calendar (the live NSE /
    yfinance feeds are now-only and cannot be replayed). Returns
    (kept, blocked)."""
    try:
        cutoff = pd.Timestamp(cutoff_date)
    except Exception:
        return list(candidates), []
    w = pd.Timedelta(days=int(window_days))
    kept: List[str] = []
    blocked: List[str] = []
    for t in candidates:
        hit = False
        for d in (blackouts_by_symbol or {}).get(t) or []:
            try:
                ts = pd.Timestamp(d)
            except Exception:
                continue
            if abs(ts - cutoff) <= w:
                hit = True
                break
        (blocked if hit else kept).append(t)
    return kept, blocked


def _weighting_stack_replay(
    basket: List[str],
    w_in: Dict[str, float],
    trailing_rets: pd.DataFrame,
    scores: Dict[str, float],
    cfg: Optional[Dict[str, Any]],
) -> Tuple[Dict[str, float], List[str]]:
    """Replay the production weighting layers ABOVE HRP, per the SAME cfg
    opt-in flags and dispatch order as run_optimizer_logic (BL -> Kelly ->
    MDP -> DRO-CVaR refinement). Each layer lazy-imports the PRODUCTION
    function itself and runs on the fold's trailing returns; on import or
    shape failure the layer is skipped and DISCLOSED (the incoming weights
    are kept). Weight bounds are re-enforced after every override (the
    production Phase-3 final-constraint step). Returns (weights, layers)."""
    cfg = cfg or {}
    w = dict(w_in)
    layers: List[str] = []
    cols = [c for c in basket if c in trailing_rets.columns]
    ret_sub = trailing_rets[cols] if cols else trailing_rets
    signal_mini = pd.DataFrame(
        {"alpha_score": pd.Series(scores).reindex(basket).fillna(0.0)},
        index=list(basket),
    )

    if cfg.get("USE_BLACK_LITTERMAN", False) and basket and cols:
        try:
            from optimizer import black_litterman_weights as _prod_bl
            bl_w = _prod_bl(list(cols), signal_mini, ret_sub, cfg=dict(cfg))
            if bl_w:
                w = _clip_weights(bl_w, cfg)
                layers.append("Black-Litterman (production)")
        except Exception:
            layers.append("Black-Litterman skipped (import/shape failure — HRP kept)")

    if cfg.get("USE_KELLY_SIZING", False) and basket:
        try:
            from optimizer import calculate_kelly_weights as _prod_kelly
            k_w = _prod_kelly(list(basket), signal_mini,
                              float(cfg.get("KELLY_FRACTION", 0.25)))
            if k_w:
                w = _clip_weights(k_w, cfg)
                layers.append("Kelly (production)")
        except Exception:
            layers.append("Kelly skipped (import/shape failure — HRP kept)")

    if cfg.get("USE_MDP", False) and basket and len(basket) >= 3 and cols:
        try:
            from optimizer import compute_mdp_weights as _prod_mdp
            m_w = _prod_mdp(list(cols), ret_sub)
            if m_w:
                w = _clip_weights(m_w, cfg)
                layers.append("MDP (production)")
        except Exception:
            layers.append("MDP skipped (import/shape failure — HRP kept)")

    if cfg.get("USE_DRO_CVAR", False) and basket and len(basket) >= 3 and ret_sub.shape[0] >= 20:
        try:
            from optimizer_risk import apply_dro_cvar_constraint as _dro_fn
            tickers = [t for t in basket if t in w]
            arr = np.array([w[t] for t in tickers], dtype=float)
            res = _dro_fn(
                returns=ret_sub[[t for t in tickers if t in ret_sub.columns]].fillna(0.0).values,
                current_weights=arr,
                epsilon=float(cfg.get("DRO_EPSILON", 0.05)),
                alpha=float(cfg.get("DRO_ALPHA", 0.05)),
                lam=float(cfg.get("DRO_LAMBDA", 1.0)),
                log_cb=None,
            )
            if res.get("source") == "dro_cvar" and tickers:
                for _i, _t in enumerate(tickers):
                    w[_t] = float(res["weights"][_i])
                w = _clip_weights(w, cfg)
                layers.append("DRO-CVaR refinement (production)")
        except Exception:
            layers.append("DRO-CVaR skipped (import/shape failure — HRP kept)")

    if not layers:
        layers.append("no opt-in weighting flags enabled (production defaults — HRP stands)")
    return w, layers


def _point_in_time_factors(
    win_close: pd.DataFrame,
    win_volume: Optional[pd.DataFrame],
    bench_window_ret: Optional[float],
) -> Dict[str, Dict[str, float]]:
    """Compute the prescreen factor family vectorized over the window slice.

    All inputs are strictly data up to the cutoff (the window's last row IS
    the cutoff row). Factors mirror the live signal-frame computations:
    trailing momentum, annualized vol, range contraction, VCP BB-width
    contraction, OBV slope, up/down vol ratio, drawdown, ADV20, RS vs the
    benchmark over the same window. CMF needs intraday High/Low which the
    frame does not carry — it is honestly omitted (neutral z, disclosed).
    """
    c_ff = win_close.ffill()
    last = c_ff.iloc[-1]
    first = c_ff.bfill().iloc[0]
    n_rows = len(win_close)
    out: Dict[str, Dict[str, float]] = {}

    rets = win_close.pct_change()
    mom_look = last / first - 1.0
    mom_6m = last / c_ff.bfill().iloc[-min(127, n_rows)] - 1.0
    mom_3m = last / c_ff.bfill().iloc[-min(64, n_rows)] - 1.0
    mom_1m = last / c_ff.bfill().iloc[-min(22, n_rows)] - 1.0

    vol_21 = rets.tail(21).std() * np.sqrt(252.0)
    vol_63 = rets.tail(63).std() * np.sqrt(252.0)
    range_contraction = 1.0 - vol_21 / (vol_63 + 1e-12)

    if win_volume is not None:
        adv20 = (win_close * win_volume).tail(20).mean()
        obv = (np.sign(win_close.diff()) * win_volume).fillna(0.0).cumsum()
        obv_21 = 21
        obv_slope = (obv.iloc[-1] - obv.iloc[-min(obv_21 + 1, n_rows)]) / (
            win_volume.tail(obv_21).mean() * obv_21 + 1e-9)
    else:
        adv20 = pd.Series(np.nan, index=win_close.columns)
        obv_slope = pd.Series(np.nan, index=win_close.columns)

    ups = rets.where(rets > 0).tail(63).std()
    downs = rets.where(rets < 0).tail(63).std()
    updown_vol = ups / (downs + 1e-12)

    drawdown = last / win_close.cummax().iloc[-1] - 1.0

    # VCP: BB-width contraction percentile over the window (mirrors signal frame)
    sma20 = win_close.rolling(20).mean()
    std20 = win_close.rolling(20).std()
    bw = (std20 * 4.0) / (sma20 + 1e-12)
    bw_now = bw.iloc[-1]
    bw_90p = bw.quantile(0.90)
    vcp = (1.0 - bw_now / (bw_90p + 1e-12)).clip(lower=0.0)

    if bench_window_ret is not None and np.isfinite(bench_window_ret):
        rs_raw = (1.0 + mom_look) / (1.0 + bench_window_ret) - 1.0
    else:
        rs_raw = pd.Series(np.nan, index=win_close.columns)

    for tkr in win_close.columns:
        out[str(tkr)] = {
            "mom_1m": float(mom_1m.get(tkr, np.nan)) if np.isfinite(mom_1m.get(tkr, np.nan)) else 0.0,
            "mom_3m": float(mom_3m.get(tkr, np.nan)) if np.isfinite(mom_3m.get(tkr, np.nan)) else 0.0,
            "mom_6m": float(mom_6m.get(tkr, np.nan)) if np.isfinite(mom_6m.get(tkr, np.nan)) else 0.0,
            "ann_vol": float(vol_63.get(tkr, np.nan)) if np.isfinite(vol_63.get(tkr, np.nan)) else 0.0,
            "range_contraction": float(range_contraction.get(tkr, np.nan)) if np.isfinite(range_contraction.get(tkr, np.nan)) else 0.0,
            "adv20": float(adv20.get(tkr, np.nan)) if np.isfinite(adv20.get(tkr, np.nan)) else 0.0,
            "obv_slope": float(obv_slope.get(tkr, np.nan)) if np.isfinite(obv_slope.get(tkr, np.nan)) else 0.0,
            "updown_vol": float(updown_vol.get(tkr, np.nan)) if np.isfinite(updown_vol.get(tkr, np.nan)) else 0.0,
            "drawdown": float(drawdown.get(tkr, np.nan)) if np.isfinite(drawdown.get(tkr, np.nan)) else 0.0,
            "vcp": float(vcp.get(tkr, np.nan)) if np.isfinite(vcp.get(tkr, np.nan)) else 0.0,
            "rs_raw": float(rs_raw.get(tkr, np.nan)) if np.isfinite(rs_raw.get(tkr, np.nan)) else 0.0,
        }
    return out


def walk_forward_reselection_backtest(
    close_df: pd.DataFrame,
    volume_df: Optional[pd.DataFrame] = None,
    n_folds: int = 4,
    score_lookback: int = 126,
    k_stocks: int = 10,
    mode: str = "balanced",
    benchmark_returns: Optional[pd.Series] = None,
    fee_bps: float = 25.0,
    trading_days: int = 252,
    selected_final: Optional[Sequence[str]] = None,
    retroactive_alpha_ann: Optional[float] = None,
    top_n_pool: Optional[int] = None,
    replay_allocation: bool = True,
    allocation_cfg: Optional[Dict[str, Any]] = None,
    hrp_lookback: int = 63,
    sectors: Optional[Dict[str, str]] = None,
    blackouts_by_symbol: Optional[Dict[str, Sequence[Any]]] = None,
    blackout_window_days: int = 5,
    ml_alpha_by_cutoff: Optional[Dict[str, Dict[str, float]]] = None,
    ml_dsr_by_cutoff: Optional[Dict[str, float]] = None,
    replay_penalties: bool = True,
    replay_ml_alpha: bool = True,
    replay_blackouts: bool = True,
    replay_weighting_stack: bool = True,
) -> Dict[str, Any]:
    """Full walk-forward RE-SELECTION backtest — a TRUE out-of-sample alpha.

    AUDIT-FIX (Round 24 — R24-1): the R23-4 diagnostics measured how much of
    the final basket was a look-back artifact but did not eliminate the bias
    from any reported number. This function re-runs the SCREEN itself at each
    of K cutoffs: the prescreen factor family (momentum / liquidity / vol /
    VCP / OBV / RS, mode-weighted exactly like the live prescreen) is
    recomputed on data available ONLY up to the cutoff, the top-K basket is
    selected point-in-time, and forward-tested to the next cutoff with
    turnover costs. The resulting alpha contains no retroactive-basket
    selection leakage, and the difference vs the run's headline (retroactive)
    alpha is the measured selection bias.

    AUDIT-FIX (Round 25 — R25-1): the ALLOCATION layer is now REPLAYED per
    cutoff instead of standing in with inverse-vol weights. At each cutoff,
    after the point-in-time pool cut (top_n_pool, when the caller passes a
    frame larger than the pool — the opt-in full-universe supersample mode):
      * SELECTION: the production QUBO's core objective (alpha diagonal +
        vol penalty + trailing-correlation off-diagonal + cardinality
        constraint, same coefficient formulas as optimizer.build_qubo) is
        rebuilt on trailing data and solved greedy + first-improvement local
        search (the production "Greedy" solve family).
      * WEIGHTING: the PRODUCTION `optimizer.hrp_weights` runs on the fold
        basket's trailing returns (local mirror fallback), then the
        production MIN/MAX weight bounds are applied.
    An inverse-vol reference series (the R24 semantics) is computed
    alongside, so the payload reports the allocation-layer effect explicitly.

    AUDIT-FIX (Round 27 — R27-1): the live-data layer residual is closed to
    the extent point-in-time inputs exist. Per cutoff, on trailing data:
      * the QUBO PENALTY layers (beta / fold-local turnover / Barra when
        FACTOR_CONC_PENALTY>0 / Wasserstein DRO; same-sector off-diagonal when
        a sector map + ENABLE_SECTOR_CAP are supplied) are rebuilt and added
        to the QUBO-core diagonal;
      * ML-ALPHA injection replays with production Phase-9 semantics when
        `ml_alpha_by_cutoff` (+ per-cutoff DSR) is supplied — DSR missing
        refuses the injection exactly like the live gate;
      * BLACKOUT filters replay on a caller-supplied historical calendar
        (`blackouts_by_symbol`, +/- blackout_window_days);
      * the WEIGHTING STACK above HRP (BL / Kelly / MDP / DRO-CVaR) replays
        through the PRODUCTION functions under the same cfg opt-in flags.
    Still NOT replayed and disclosed per run: the regime tilt of the alpha
    composite (no point-in-time regime state), CMF (no intraday High/Low),
    and any layer whose point-in-time input was not supplied. The payload's
    `replay_scope` + per-run `method_disclosure` enumerate the exact status.
    """
    mode_key = str(mode or "balanced").strip().lower()
    weights_map = _RESELECT_MODE_WEIGHTS.get(mode_key, _RESELECT_MODE_WEIGHTS["balanced"])
    base: Dict[str, Any] = {
        "n_folds": int(n_folds),
        "score_lookback_days": int(score_lookback),
        "k_stocks": int(k_stocks),
        "mode": mode_key,
        "weighting": ("HRP replayed point-in-time on the QUBO-core selection "
                      "(+ R27 penalty-layer replay; DRO-CVaR/BL/Kelly/MDP "
                      "stack per cfg opt-ins; inverse-vol reference series "
                      "reported alongside)"
                      if replay_allocation else
                      "inverse-vol (allocation replay disabled)"),
    }
    k_stocks = max(1, int(k_stocks))
    n_folds = max(1, int(n_folds))
    score_lookback = max(21, int(score_lookback))

    if close_df is None or close_df.empty or len(close_df.index) < score_lookback + n_folds * _MIN_FORWARD_DAYS:
        return {
            **base,
            "folds": [],
            "true_oos_annualized_alpha_pct": None,
            "retroactive_basket_bias_pct": None,
            "verdict": "UNMEASURED (insufficient price history for K cutoffs with forward room)",
            "note": (f"Re-selection needs >= score_lookback + {n_folds} x {_MIN_FORWARD_DAYS} "
                     f"observations; the pool frame is shorter."),
            "method_disclosure": _RESELECT_DISCLOSURE,
        }

    total_len = len(close_df.index)
    usable_end = total_len - 1
    span = usable_end - score_lookback
    if span < n_folds * _MIN_FORWARD_DAYS:
        return {
            **base,
            "folds": [],
            "true_oos_annualized_alpha_pct": None,
            "retroactive_basket_bias_pct": None,
            "verdict": "UNMEASURED (no forward room after the first cutoff)",
            "note": "The frame has history but not enough forward days after cutoffs to measure OOS returns.",
            "method_disclosure": _RESELECT_DISCLOSURE,
        }
    # AUDIT-FIX (Round 29 — R29-4): the grid now comes from the SINGLE source
    # of truth (reselect_cutoff_positions) — identical semantics to the former
    # inline computation; the sweep-side ML retraining driver calls the SAME
    # helper so the retrained cutoffs can never drift from the replay's.
    cutoff_pos = reselect_cutoff_positions(total_len, score_lookback, n_folds)
    if not cutoff_pos:
        return {
            **base,
            "folds": [],
            "true_oos_annualized_alpha_pct": None,
            "retroactive_basket_bias_pct": None,
            "verdict": "UNMEASURED (no valid cutoffs)",
            "method_disclosure": _RESELECT_DISCLOSURE,
        }

    sel_final = {str(s).upper() for s in (selected_final or [])}
    rets_full = close_df.pct_change()
    bench_aligned = None
    if benchmark_returns is not None and not benchmark_returns.empty:
        bench_aligned = benchmark_returns.reindex(close_df.index)

    fold_rows: List[Dict[str, Any]] = []
    port_daily = []
    port_daily_ref = []      # R25-1: inverse-vol reference series (R24 semantics)
    bench_daily = []
    prev_basket: List[str] = []
    prev_basket_ref: List[str] = []
    overlap_pcts: List[float] = []
    weighting_sources: List[str] = []
    pool_cut_applied_any = False
    # R27-1 replay-scope trackers (feed the per-run replay_status + disclosure)
    blackouts_blocked_total = 0
    ml_blend_any = False
    ml_refused_any = False
    ml_weights_seen: List[float] = []
    penalties_applied_any = False
    sector_pen_any = False
    weighting_stack_any = False

    for j, p in enumerate(cutoff_pos):
        cutoff_date = close_df.index[p]
        fwd_end = cutoff_pos[j + 1] if j + 1 < len(cutoff_pos) else usable_end
        if fwd_end <= p:
            continue
        start = max(0, p - score_lookback)
        win_close = close_df.iloc[start:p + 1]
        win_volume = volume_df.iloc[start:p + 1] if (volume_df is not None and not volume_df.empty) else None

        # Benchmark total return over the SAME trailing window (point-in-time RS)
        bench_window_ret = None
        if bench_aligned is not None:
            bw = bench_aligned.iloc[start:p + 1].dropna()
            if len(bw) >= score_lookback * 0.5:
                bench_window_ret = float(np.prod(1.0 + bw.values) - 1.0)
        # R27-1: trailing benchmark returns for the point-in-time beta replay
        bench_trailing_rets = (bench_aligned.iloc[start:p + 1]
                               if bench_aligned is not None else None)

        # Rankable tickers: enough non-NaN price history in the window
        valid_counts = win_close.notna().sum()
        rankable = valid_counts[valid_counts >= max(20, int(score_lookback * _MIN_RANKABLE_COVER))].index
        rankable = [c for c in rankable if np.isfinite(win_close[c].ffill().iloc[-1]) and win_close[c].ffill().iloc[-1] > 0]
        if len(rankable) < k_stocks:
            fold_rows.append({
                "fold": j + 1,
                "cutoff_date": str(cutoff_date),
                "forward_days": int(fwd_end - p),
                "rankable_universe": len(rankable),
                "basket": [],
                "overlap_with_final_basket_pct": None,
                "note": "fewer rankable tickers than k_stocks at this cutoff",
            })
            continue

        factors = _point_in_time_factors(win_close, win_volume, bench_window_ret)
        fac = {t: factors[t] for t in rankable}

        # Robust cross-sectional z-scores per factor, then mode-weighted score
        zs: Dict[str, Dict[str, float]] = {}
        z_names = ["mom_1m", "mom_3m", "mom_6m", "ann_vol", "range_contraction",
                   "adv20", "obv_slope", "updown_vol", "drawdown", "vcp", "rs_raw"]
        for fname in z_names:
            z = _robust_z_cross({t: fac[t][fname] for t in fac})
            zs[fname] = z
        # CMF is not computable from Close/Volume frames (needs intraday High/Low)
        # — enters as neutral zero, disclosed.
        z_cmf = {t: 0.0 for t in fac}

        scores: Dict[str, float] = {}
        for t in fac:
            s = 0.0
            for wname, w in weights_map.items():
                if wname == "z_mom_1m_penalty":
                    s += w * max(0.0, -zs["mom_1m"][t])
                elif wname == "z_cmf":
                    s += w * z_cmf[t]
                else:
                    fname = wname[2:] if wname.startswith("z_") else wname
                    s += w * zs.get(fname, {}).get(t, 0.0)
            scores[t] = s
        ranked_all = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)

        # AUDIT-FIX (Round 25 — R25-1): point-in-time TOP_N pool cut. When the
        # frame is LARGER than the pool (the opt-in full-universe supersample
        # mode), each cutoff applies the same pool cut the live prescreen
        # applies — top TOP_N by mode-weighted score on trailing data — BEFORE
        # selection, so pool membership is replayed point-in-time instead of
        # inherited from the full-lookback cut.
        pool_candidates = [t for t, _ in ranked_all]
        pool_cut_this_fold = False
        if top_n_pool is not None and 0 < int(top_n_pool) < len(pool_candidates):
            pool_candidates = pool_candidates[:int(top_n_pool)]
            pool_cut_this_fold = True
            pool_cut_applied_any = True

        # AUDIT-FIX (Round 27 — R27-1): BLACKOUT replay — the caller-supplied
        # historical earnings/F&O-ban/corporate-action calendar applied at the
        # cutoff (drop names with an event within +/- blackout_window_days,
        # mirroring data_layer.apply_earnings_blackout). Both the replay and
        # the inverse-vol REFERENCE series use the post-blackout pool so the
        # allocation-layer comparison stays apples-to-apples. No calendar
        # supplied -> not replayed, disclosed per run.
        blacked_out: List[str] = []
        if replay_blackouts and blackouts_by_symbol:
            pool_candidates, blacked_out = _blackout_replay_filter(
                pool_candidates, cutoff_date, blackouts_by_symbol,
                int(blackout_window_days))
            if blacked_out:
                blackouts_blocked_total += len(blacked_out)

        # AUDIT-FIX (Round 27 — R27-1): ML-ALPHA injection replay — per-cutoff
        # predictions + per-cutoff DSR keyed by str(cutoff_date), blended
        # with the PRODUCTION Phase-9 semantics (z-blend; DSR-scaled weight;
        # DSR missing -> injection REFUSED, exactly the live gate). The blend
        # affects the QUBO alpha only — the reference series keeps the R24
        # no-ML semantics.
        ml_weight_this_fold = 0.0
        ml_note_this_fold = ""
        scores_fold = scores
        if replay_ml_alpha and ml_alpha_by_cutoff:
            _ml_key = str(cutoff_date)
            # R29-4: accept BOTH key conventions — str(Timestamp) (the R27
            # contract: "2025-03-12 00:00:00") and str(date) (the R29-3
            # driver's readable form: "2025-03-12") — so caller and driver
            # key conventions can never silently mismatch again.
            _ml_scores = (ml_alpha_by_cutoff.get(_ml_key)
                          or ml_alpha_by_cutoff.get(str(pd.Timestamp(cutoff_date).date()))
                          or {})
            if _ml_scores:
                _ml_dsr = ((ml_dsr_by_cutoff or {}).get(_ml_key)
                           or (ml_dsr_by_cutoff or {}).get(str(pd.Timestamp(cutoff_date).date())))
                ml_weight_this_fold = _ml_replay_weight(allocation_cfg, _ml_dsr)
                if ml_weight_this_fold > 0.0:
                    scores_fold = _ml_blend_scores(scores, _ml_scores,
                                                    ml_weight_this_fold)
                    ml_blend_any = True
                    ml_weights_seen.append(ml_weight_this_fold)
                else:
                    ml_refused_any = True
                    ml_note_this_fold = ("ML scores supplied for this cutoff but DSR "
                                         "not supplied/below floor — injection REFUSED "
                                         "(production Phase-9 gate semantics)")

        # Reference basket: the R24 semantics (top-K by mode score)
        basket_ref = pool_candidates[:k_stocks]

        # AUDIT-FIX (Round 27 — R27-1): QUBO PENALTY-LAYER replay — beta /
        # fold-local turnover / Barra (when enabled) / DRO terms rebuilt
        # on strictly trailing data and injected into the QUBO-core
        # diagonal, plus the production same-sector off-diagonal penalty
        # when a sector map is supplied and ENABLE_SECTOR_CAP is on.
        pen_names: List[str] = []
        if replay_allocation and len(pool_candidates) >= k_stocks and k_stocks >= 1:
            alpha_z = _robust_z_cross({t: scores_fold[t] for t in pool_candidates})
            vol_z = {t: float(zs["ann_vol"].get(t, 0.0)) for t in pool_candidates}
            try:
                corr_pool = rets_full.iloc[max(0, p - int(hrp_lookback)):p + 1][
                    [c for c in pool_candidates if c in rets_full.columns]].corr()
            except Exception:
                corr_pool = None
            # AUDIT-FIX (Round 27 — R27-1): QUBO PENALTY-LAYER replay — beta /
            # fold-local turnover / Barra (when enabled) / DRO terms rebuilt
            # on strictly trailing data and injected into the QUBO-core
            # diagonal, plus the production same-sector off-diagonal penalty
            # when a sector map is supplied and ENABLE_SECTOR_CAP is on.
            extra_diag = None
            if replay_penalties:
                beta_map = _point_in_time_betas(win_close, bench_trailing_rets)
                extra_diag, pen_names = _point_in_time_penalties(
                    pool_candidates, zs, prev_basket, beta_map, allocation_cfg)
                penalties_applied_any = True
            sec_pen = unk_pen = 0.0
            if sectors and (allocation_cfg or {}).get("ENABLE_SECTOR_CAP", False):
                sec_pen = float((allocation_cfg or {}).get("SECTOR_PENALTY", 0.0))
                unk_pen = float((allocation_cfg or {}).get("UNKNOWN_SECTOR_PENALTY", 0.0))
                sector_pen_any = sector_pen_any or bool(sec_pen or unk_pen)
            basket = _qubo_core_select(pool_candidates, alpha_z, vol_z, corr_pool,
                                       k_stocks, allocation_cfg,
                                       extra_diag=extra_diag, sectors=sectors,
                                       sector_penalty=sec_pen,
                                       unknown_sector_penalty=unk_pen)
            selection_src = "QUBO-core objective (alpha/vol/corr/cardinality; greedy+local-search)"
            if extra_diag is not None and pen_names:
                selection_src += " + R27 penalty replay [" + ", ".join(pen_names) + "]"
            if sec_pen or unk_pen:
                selection_src += " + sector-concentration penalty"
        else:
            basket = list(basket_ref)
            selection_src = ("top-K mode-score (allocation replay off or degenerate pool)"
                             if not replay_allocation else
                             "top-K mode-score (pool smaller than k_stocks — QUBO degenerate)")

        # Inverse-vol reference weights on trailing 63d vol (point-in-time)
        vol_series = rets_full.iloc[max(0, p - 63):p + 1].std() * np.sqrt(252.0)

        def _inv_vol_w(bnames: List[str]) -> Dict[str, float]:
            inv_v = {}
            for t in bnames:
                v = float(vol_series.get(t, np.nan)) if t in vol_series.index else np.nan
                inv_v[t] = (1.0 / v) if (np.isfinite(v) and v > 1e-6) else 0.0
            sum_iv = sum(inv_v.values())
            if sum_iv <= 0:
                return {t: 1.0 / len(bnames) for t in bnames}
            return {t: (v / sum_iv) for t, v in inv_v.items()}

        w_ref = _inv_vol_w(basket_ref)

        # AUDIT-FIX (Round 25 — R25-1): WEIGHTING replay — the production HRP
        # on the fold basket's trailing returns + production weight bounds.
        weighting_layers_this_fold: List[str] = []
        if replay_allocation and basket:
            w_map, weighting_src = _hrp_weights_replay(
                basket,
                rets_full.iloc[max(0, p - int(hrp_lookback)):p + 1],
                weight_cfg=allocation_cfg,
            )
            # AUDIT-FIX (Round 27 — R27-1): WEIGHTING-STACK replay above HRP —
            # the production BL / Kelly / MDP / DRO-CVaR layers under the
            # same cfg opt-in flags as the live pipeline (production functions
            # themselves, lazy-imported; failures skipped + disclosed).
            if replay_weighting_stack:
                w_map, weighting_layers_this_fold = _weighting_stack_replay(
                    basket, w_map,
                    rets_full.iloc[max(0, p - int(hrp_lookback)):p + 1],
                    scores_fold, allocation_cfg)
                if any("(production)" in _l for _l in weighting_layers_this_fold):
                    weighting_stack_any = True
                if weighting_layers_this_fold:
                    weighting_src = (weighting_src + "; stack: "
                                     + ", ".join(weighting_layers_this_fold))
            weighting_sources.append(weighting_src)
        else:
            w_map = _inv_vol_w(basket)
            weighting_src = "inverse-vol (R24 semantics)"
            weighting_sources.append(weighting_src)

        # Forward returns: days (p, fwd_end] — day p+1's return uses day p close
        fwd_idx = close_df.index[p + 1:fwd_end + 1]
        fwd_rets = rets_full.loc[fwd_idx, [c for c in basket if c in rets_full.columns]]
        fwd_rets = fwd_rets.fillna(0.0)
        port_fold = fwd_rets.mul(pd.Series(w_map), axis=1).sum(axis=1)
        # Reference series (R24 semantics): top-K score basket + inverse-vol
        fwd_rets_ref = rets_full.loc[fwd_idx, [c for c in basket_ref if c in rets_full.columns]]
        fwd_rets_ref = fwd_rets_ref.fillna(0.0)
        port_fold_ref = fwd_rets_ref.mul(pd.Series(w_ref), axis=1).sum(axis=1)

        # Turnover cost: fraction of NEW names vs the previous basket
        if prev_basket:
            turnover_frac = len(set(basket) - set(prev_basket)) / max(len(basket), 1)
        else:
            turnover_frac = 1.0  # initial buy
        prev_basket = list(basket)
        if len(port_fold) > 0:
            port_fold.iloc[0] -= (turnover_frac * fee_bps / 10000.0)
        if prev_basket_ref:
            turnover_frac_ref = len(set(basket_ref) - set(prev_basket_ref)) / max(len(basket_ref), 1)
        else:
            turnover_frac_ref = 1.0
        prev_basket_ref = list(basket_ref)
        if len(port_fold_ref) > 0:
            port_fold_ref.iloc[0] -= (turnover_frac_ref * fee_bps / 10000.0)

        port_daily.append(port_fold)
        port_daily_ref.append(port_fold_ref)
        if bench_aligned is not None:
            bench_daily.append(bench_aligned.loc[fwd_idx].fillna(0.0))

        if sel_final:
            _basket_up = {str(b).upper() for b in basket}
            ov = len(_basket_up & sel_final) / len(sel_final)
            overlap_pcts.append(ov)
            overlap_pct = round(ov * 100.0, 1)
        else:
            overlap_pct = None

        fold_rows.append({
            "fold": j + 1,
            "cutoff_date": str(cutoff_date),
            "forward_days": int(len(fwd_idx)),
            "rankable_universe": len(rankable),
            "pool_cut_applied": bool(pool_cut_this_fold),
            "basket": basket,
            "selection": selection_src,
            "weights": {t: round(w_map[t], 4) for t in basket},
            "weighting": weighting_src,
            "reference_topk_basket": list(basket_ref),
            "turnover_frac": round(turnover_frac, 3),
            "fold_total_return_pct": round(float((1.0 + port_fold).prod() - 1.0) * 100.0, 2),
            "reference_invvol_fold_return_pct": round(float((1.0 + port_fold_ref).prod() - 1.0) * 100.0, 2),
            "overlap_with_final_basket_pct": overlap_pct,
            # R27-1: per-fold layer-replay evidence
            "blackouts_blocked": list(blacked_out),
            "ml_alpha_weight": (round(ml_weight_this_fold, 4)
                                if ml_weight_this_fold else 0.0),
            "ml_alpha_note": ml_note_this_fold,
            "penalties_replayed": list(pen_names),
            "weighting_layers": list(weighting_layers_this_fold),
        })

    if not port_daily:
        return {
            **base,
            "folds": fold_rows,
            "true_oos_annualized_alpha_pct": None,
            "retroactive_basket_bias_pct": None,
            "verdict": "UNMEASURED (no fold produced a point-in-time basket)",
            "method_disclosure": _RESELECT_DISCLOSURE,
        }

    port_series = pd.concat(port_daily).sort_index()
    n_days = len(port_series)
    port_total = float((1.0 + port_series).prod() - 1.0)
    port_ann = (1.0 + port_total) ** (trading_days / max(1, n_days)) - 1.0 if port_total > -1.0 else -1.0
    sharpe = (float(port_series.mean()) / float(port_series.std()) * np.sqrt(trading_days)
              if len(port_series) > 1 and float(port_series.std()) > 0 else None)

    # AUDIT-FIX (Round 25 — R25-1): aggregate the inverse-vol REFERENCE series
    # (the R24 semantics) alongside the replayed-allocation series so the
    # payload quantifies the allocation layer's effect explicitly: the
    # reference total/alpha and the (replayed - reference) alpha difference.
    ref_total = ref_alpha_ann = None
    if port_daily_ref:
        ref_series = pd.concat(port_daily_ref).sort_index()
        ref_total = float((1.0 + ref_series).prod() - 1.0)

    bench_total = bench_ann = alpha_ann = None
    if bench_daily:
        bench_series = pd.concat(bench_daily).sort_index()
        bench_total = float((1.0 + bench_series).prod() - 1.0)
        if bench_total > -1.0:
            bench_ann = (1.0 + bench_total) ** (trading_days / max(1, len(bench_series))) - 1.0
        active = port_series - bench_series.reindex(port_series.index).fillna(0.0)
        alpha_ann = float(active.mean() * trading_days)
        if port_daily_ref:
            active_ref = ref_series - bench_series.reindex(ref_series.index).fillna(0.0)
            ref_alpha_ann = float(active_ref.mean() * trading_days)

    alloc_effect_pct = None
    if alpha_ann is not None and ref_alpha_ann is not None:
        alloc_effect_pct = round((alpha_ann - ref_alpha_ann) * 100.0, 2)

    bias_pct = None
    verdict_alpha = (round(alpha_ann * 100.0, 2) if alpha_ann is not None else None)
    if retroactive_alpha_ann is not None and alpha_ann is not None and np.isfinite(retroactive_alpha_ann):
        bias_pct = round((float(retroactive_alpha_ann) - alpha_ann) * 100.0, 2)

    if bias_pct is None:
        verdict = (f"TRUE-OOS annualized alpha {verdict_alpha}% (no retroactive comparison available — "
                   f"the run produced no benchmarked backtest alpha)")
    elif bias_pct > 10.0:
        verdict = (f"HIGH SELECTION BIAS — retroactive alpha oversells the point-in-time "
                   f"screen by {bias_pct:.1f}pp ann. (headline vs true-OOS {verdict_alpha}%)")
    elif bias_pct < -10.0:
        verdict = (f"NEGATIVE BIAS — the point-in-time screen OUTPERFORMED the headline by "
                   f"{abs(bias_pct):.1f}pp ann. (true-OOS {verdict_alpha}%)")
    else:
        verdict = (f"LOW SELECTION BIAS ({bias_pct:+.1f}pp ann.) — true-OOS alpha {verdict_alpha}% "
                   f"is within 10pp of the headline figure")

    # AUDIT-FIX (Round 27 — R27-1): per-run replay-scope status — every layer
    # is either REPLAYED point-in-time (with its source) or NOT replayed (with
    # the reason). This feeds the payload's replay_scope and the per-run
    # method_disclosure (the disclosure is no longer a static caveat).
    if ml_blend_any:
        _ml_src = ("per-cutoff predictions z-blended at the production DSR-scaled "
                   f"weight (fold weights: {[round(w, 3) for w in ml_weights_seen]})")
        _ml_status = {"replayed": True, "source": _ml_src}
    elif ml_refused_any:
        _ml_status = {"replayed": False,
                      "reason": ("scores supplied without per-cutoff DSR — injection REFUSED "
                                 "(production Phase-9 gate)")}
    else:
        _ml_status = {"replayed": False,
                      "reason": ("per-cutoff point-in-time ML predictions not supplied "
                                 "(the final model's scores are not point-in-time; the R29-3 "
                                 "walk-forward retraining driver is opt-in via "
                                 "WFO_ML_REPLAY_RETRAIN, runtime x K)"
                                 if replay_ml_alpha else "replay_ml_alpha=False")}
    replay_status: Dict[str, Dict[str, Any]] = {
        "pool_cut": (
            {"replayed": True, "source": "point-in-time TOP_N pool cut per cutoff (supersample frame)"}
            if pool_cut_applied_any else
            {"replayed": False, "reason": "supersample frame not supplied — in-memory full-lookback pool inherited (liquidity-ranking leak disclosed)"}),
        "qubo_core": (
            {"replayed": True, "source": "alpha/vol/correlation/cardinality objective, greedy+local-search (production coefficient formulas)"}
            if replay_allocation else
            {"replayed": False, "reason": "replay_allocation=False — top-K mode-score + inverse-vol (R24 semantics)"}),
        "qubo_penalties": (
            {"replayed": True,
             "source": "beta/turnover(fold-local)/Barra(if enabled)/Wasserstein DRO rebuilt on trailing data"
                       + (" + same-sector off-diagonal" if sector_pen_any else "")}
            if (replay_allocation and replay_penalties and penalties_applied_any) else
            {"replayed": False, "reason": ("replay_penalties=False" if not replay_penalties else "allocation replay off")}),
        "ml_alpha": _ml_status,
        "blackouts": (
            {"replayed": True,
             "source": f"caller-supplied historical calendar, +/- {int(blackout_window_days)}d window ({blackouts_blocked_total} name-blocks applied)"}
            if (replay_blackouts and blackouts_by_symbol) else
            {"replayed": False, "reason": ("no historical blackout calendar supplied (the live NSE/yfinance earnings/F&O-ban feed is now-only)"
                                           if replay_blackouts else "replay_blackouts=False")}),
        "weighting_stack": (
            {"replayed": True, "source": "production BL/Kelly/MDP/DRO-CVaR layers above HRP under the cfg opt-in flags"}
            if weighting_stack_any else
            {"replayed": False, "reason": "no opt-in weighting flags enabled in allocation_cfg (matches production defaults) or replay_weighting_stack=False"}),
        "regime_tilt": {"replayed": False,
                        "reason": "no point-in-time regime state supplied (apply_regime_bias is live-only)"},
        "cmf": {"replayed": False, "reason": "needs intraday High/Low — neutral z"},
    }

    return {
        **base,
        "folds": fold_rows,
        "oos_days": int(n_days),
        "mean_overlap_with_final_basket_pct": (round(float(np.mean(overlap_pcts)) * 100.0, 1) if overlap_pcts else None),
        "pool_replay": ("point-in-time TOP_N pool cut applied per cutoff (supersample frame)"
                        if pool_cut_applied_any else
                        "pool NOT replayed point-in-time — the in-memory frame IS the full-lookback "
                        "pool (liquidity-ranking leak disclosed)"),
        "weighting_sources": (list(dict.fromkeys(weighting_sources)) if weighting_sources else None),
        "true_oos_total_return_pct": round(port_total * 100.0, 2),
        "true_oos_annualized_return_pct": round(port_ann * 100.0, 2),
        "true_oos_sharpe": (round(float(sharpe), 3) if sharpe is not None else None),
        "benchmark_total_return_pct": (round(bench_total * 100.0, 2) if bench_total is not None else None),
        "benchmark_annualized_return_pct": (round(bench_ann * 100.0, 2) if bench_ann is not None else None),
        "true_oos_annualized_alpha_pct": verdict_alpha,
        "reference_invvol_total_return_pct": (round(ref_total * 100.0, 2) if ref_total is not None else None),
        "reference_invvol_annualized_alpha_pct": (round(ref_alpha_ann * 100.0, 2)
                                                  if ref_alpha_ann is not None else None),
        "allocation_layer_effect_pct": alloc_effect_pct,
        "retroactive_alpha_ann_pct": (round(float(retroactive_alpha_ann) * 100.0, 2)
                                      if retroactive_alpha_ann is not None and np.isfinite(retroactive_alpha_ann) else None),
        "retroactive_basket_bias_pct": bias_pct,
        "verdict": verdict,
        "replay_scope": replay_status,
        "note": ("Point-in-time re-selection at every cutoff: mode-weighted prescreen scoring "
                 "on trailing data, the QUBO-CORE selection objective (with the R27 penalty-layer "
                 "replay: beta/turnover/Barra/DRO on trailing data) replayed per cutoff, and the "
                 "PRODUCTION HRP weighting replayed on trailing returns (an inverse-vol reference "
                 "series is reported alongside so the allocation-layer effect is measured). "
                 "ML-alpha / blackouts / the weighting stack above HRP replay when their "
                 "point-in-time inputs are supplied — see replay_scope + method_disclosure for "
                 "the exact per-run status."),
        "method_disclosure": _reselect_disclosure_for(replay_status),
    }


_RESELECT_DISCLOSURE: str = (
    "Full walk-forward RE-SELECTION scope (Round 27): the prescreen factor "
    "scoring, the QUBO-CORE selection objective (alpha/vol/correlation/"
    "cardinality — same coefficient formulas as optimizer.build_qubo, solved "
    "greedy + first-improvement local search), and the PRODUCTION HRP "
    "weighting are all replayed point-in-time on trailing data at each of K "
    "cutoffs (no look-ahead in selection or weighting). An inverse-vol "
    "reference series (the R24 semantics) is reported alongside so the "
    "allocation-layer effect is measured, not assumed. When the caller "
    "enables the supersample frame, the TOP_N pool cut is also replayed "
    "point-in-time per cutoff. R27-1 additionally replays, per cutoff and on "
    "strictly trailing data, the QUBO PENALTY layers (beta / fold-local "
    "turnover / Barra factor-concentration when enabled / Wasserstein DRO) "
    "— and, WHEN the corresponding point-in-time input is supplied: the "
    "ML-alpha injection (per-cutoff predictions + per-cutoff DSR under the "
    "production Phase-9 blend/gate semantics), the earnings/F&O-ban/"
    "corporate-action blackout filters (caller-supplied historical "
    "calendar), and the DRO-CVaR / BL / Kelly / MDP weighting layers ABOVE "
    "HRP (same cfg opt-in flags as the live pipeline, production functions "
    "themselves). NOT replayed when their point-in-time input is not "
    "supplied (the default) and disclosed per run: ML-alpha (no per-cutoff "
    "predictions), blackout filters (no historical calendar), Kelly/BL/MDP/"
    "DRO-CVaR weighting (no opt-in flags enabled), the regime tilt of the "
    "alpha composite (live-only regime state), and CMF (needs intraday "
    "High/Low — neutral z). This remains the selection+allocation-level "
    "true-OOS measure — a full-pipeline WFO exists to the extent the caller "
    "supplies point-in-time inputs; the per-run replay_scope and this "
    "disclosure enumerate exactly what was and was not replayed."
)


def _reselect_disclosure_for(replay_status: Dict[str, Dict[str, Any]]) -> str:
    """Per-run method disclosure (AUDIT-FIX Round 27 — R27-1): the base scope
    text plus the layer-by-layer replay status of THIS run — every layer
    either REPLAYED point-in-time (with its source) or NOT replayed (with
    the reason). Attached to every computed response so the disclosure
    reflects what actually happened, not a static caveat."""
    parts = []
    for k, v in (replay_status or {}).items():
        if v.get("replayed"):
            parts.append(f"{k}: REPLAYED point-in-time ({v.get('source', '')})")
        else:
            parts.append(f"{k}: NOT replayed — {v.get('reason', 'input not supplied')}")
    return (_RESELECT_DISCLOSURE + "\nRound-27 per-run replay scope: "
            + " | ".join(parts))
