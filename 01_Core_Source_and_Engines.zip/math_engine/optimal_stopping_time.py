"""
math_engine/optimal_stopping_time.py
=====================================
American Option & Position Exit Optimal Stopping Time Engine (Snell Envelope).

Solves the Snell Envelope U_t = max( h_t, E[ U_{t+1} | F_t ] ) via backward dynamic
programming over Monte Carlo simulated GBM price paths to calculate optimal exit timing.

The Snell Envelope U_t is defined recursively:
    U_T = h_T  (terminal payoff = cumulative return at horizon)
    U_t = max( h_t, E[U_{t+1} | F_t] )  for t < T

Continuation value E[U_{t+1} | F_t] is estimated by averaging the Snell
values of next-step GBM simulated paths conditioned on current wealth level.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any

logger = logging.getLogger(__name__)


class OptimalStoppingEngine:
    """
    Snell Envelope Optimal Stopping Time Exit Calculator.

    Uses backward dynamic programming over Monte Carlo GBM simulations
    to compute the true continuation value E[U_{t+1} | F_t].
    """

    @staticmethod
    def _ls_continuation(
        x_state: np.ndarray,
        y_next: np.ndarray,
        h_t: np.ndarray,
        degree: int = 3
    ) -> np.ndarray:
        """
        Longstaff-Schwartz (2001) polynomial basis least-squares continuation estimator.
        Regresses realized continuation payoffs Y_{t+1} onto a polynomial basis of state X_t
        for in-the-money (ITM) paths.
        """
        itm_mask = h_t > 0
        if np.sum(itm_mask) < degree + 1:
            itm_mask = np.ones(len(x_state), dtype=bool)

        x_itm = x_state[itm_mask]
        y_itm = y_next[itm_mask]

        if len(x_itm) < degree + 1 or np.allclose(x_itm, x_itm[0]):
            return np.full_like(y_next, float(np.nanmean(y_next)) if len(y_next) > 0 else 0.0)

        try:
            # Polynomial basis: [1, X, X^2, ..., X^degree]
            A_itm = np.vander(x_itm, N=degree + 1, increasing=True)
            coeffs, _, _, _ = np.linalg.lstsq(A_itm, y_itm, rcond=None)

            # Predict conditional continuation for all paths
            A_all = np.vander(x_state, N=degree + 1, increasing=True)
            continuation = A_all @ coeffs

            # Sanitize numerical extremes without artificial positive bias
            continuation = np.nan_to_num(
                continuation,
                nan=float(np.nanmean(y_itm)),
                posinf=float(np.max(y_itm)),
                neginf=float(np.min(y_itm))
            )
            return continuation
        except Exception:
            return np.full_like(y_next, float(np.nanmean(y_next)) if len(y_next) > 0 else 0.0)

    @classmethod
    def calculate_optimal_exit(
        cls,
        cumulative_returns: pd.Series,
        stop_loss_pct: float = -0.05,
        target_profit_pct: float = 0.15,
        n_paths: int = 300,
        horizon_steps: int = 10,
        annual_vol: float | None = None
    ) -> Dict[str, Any]:
        """
        Calculates optimal exit stopping time tau* and Snell envelope continuation value.

        Implements backward Snell DP with Longstaff-Schwartz least-squares regression:
            U_T = h_T = terminal cumulative return
            U_t = max( h_t, E[U_{t+1} | state] )  via LS polynomial regression

        Args:
            cumulative_returns: Historical cumulative return series (e.g., (price / cost) - 1).
            stop_loss_pct: Stop-loss floor (triggers forced exit).
            target_profit_pct: Profit target ceiling (triggers exit).
            n_paths: Number of Monte Carlo simulation paths.
            horizon_steps: Number of discrete DP steps.
            annual_vol: Annual volatility override. If None, estimated from history.

        Returns:
            Dict with should_exit_now, exit_reason, snell_continuation_val, current_return.
        """
        clean_ret = cumulative_returns.dropna().values
        if len(clean_ret) == 0:
            return {"should_exit_now": False, "snell_continuation_val": 0.0, "optimal_stopping_step": 0}

        cur_return = float(clean_ret[-1])

        # Immediate exercise payoff check
        if cur_return <= stop_loss_pct:
            return {
                "should_exit_now": True,
                "exit_reason": "STOP_LOSS_TRIPPED",
                "snell_continuation_val": cur_return
            }

        if cur_return >= target_profit_pct:
            return {
                "should_exit_now": True,
                "exit_reason": "PROFIT_TARGET_REACHED",
                "snell_continuation_val": cur_return
            }

        # --- Backward Snell Envelope DP with Longstaff-Schwartz Regression ---
        if len(clean_ret) >= 5:
            daily_rets = np.diff(clean_ret)
            mu_daily = float(np.mean(daily_rets))
            std_val = float(np.std(daily_rets, ddof=1)) if len(daily_rets) > 1 else 0.01
            sigma_daily = std_val if std_val > 1e-4 else 0.01
        else:
            mu_daily = 0.0
            sigma_daily = 0.01

        if annual_vol is not None:
            sigma_daily = max(float(annual_vol) / np.sqrt(252), 1e-4)

        # Starting wealth level (1 + cur_return), floored at 1e-4
        w0 = max(1.0 + cur_return, 1e-4)
        dt = 1.0

        # Dynamic deterministic seed based on input array content
        seed_int = int(abs(hash(clean_ret.tobytes())) % (2**31 - 1))
        rng = np.random.RandomState(seed=seed_int)

        # Simulate n_paths GBM trajectories of horizon_steps steps
        # Shape: (n_paths, horizon_steps + 1)
        shocks = rng.randn(n_paths, horizon_steps)
        log_increments = (mu_daily - 0.5 * sigma_daily**2) * dt + sigma_daily * np.sqrt(dt) * shocks
        paths = np.zeros((n_paths, horizon_steps + 1))
        paths[:, 0] = w0
        for t in range(1, horizon_steps + 1):
            paths[:, t] = paths[:, t - 1] * np.exp(log_increments[:, t - 1])

        # Convert to cumulative returns: r_t = path_t - 1
        ret_paths = paths - 1.0

        # Terminal payoff at step T (immediate exercise = terminal cumulative return)
        h_T = ret_paths[:, -1]
        h_T = np.where(h_T <= stop_loss_pct, stop_loss_pct, h_T)
        h_T = np.where(h_T >= target_profit_pct, target_profit_pct, h_T)

        # Backward induction with Longstaff-Schwartz regression
        U = h_T.copy()

        for step in range(horizon_steps - 1, -1, -1):
            h_t = ret_paths[:, step]
            h_t = np.where(h_t <= stop_loss_pct, stop_loss_pct, h_t)
            h_t = np.where(h_t >= target_profit_pct, target_profit_pct, h_t)

            # Estimate conditional continuation value via LS regression
            continuation = cls._ls_continuation(ret_paths[:, step], U, h_t, degree=3)

            # Early exercise rule: exercise if immediate payoff > continuation value
            U = np.where(h_t > continuation, h_t, U)

        # Snell continuation value at t=0: average of U across all paths
        snell_continuation = float(np.mean(U))

        # If continuation value > current payoff: hold is optimal
        should_exit = cur_return >= snell_continuation

        logger.debug(
            f"[SnellEnvelope] cur_return={cur_return:.4f}, "
            f"snell_continuation={snell_continuation:.4f}, "
            f"should_exit={should_exit}"
        )

        return {
            "should_exit_now": bool(should_exit),
            "exit_reason": "SNELL_ENVELOPE_EXIT" if should_exit else "HOLD_CONTINUE",
            "snell_continuation_val": round(snell_continuation, 4),
            "current_return": round(cur_return, 4),
            "simulated_paths": n_paths,
            "horizon_steps": horizon_steps
        }
