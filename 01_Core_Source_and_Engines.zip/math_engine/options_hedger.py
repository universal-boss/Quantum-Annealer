"""
math_engine/options_hedger.py
==============================
Institutional Options Tail-Hedging & Synthetic Collar Overlay Engine.

Calculates exact Nifty 50 Put Option hedges and zero-cost synthetic collars
to protect 100% of equity portfolio delta during Bear market regimes or
Hawkes jump process transition warnings without liquidating equity positions.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from datetime import datetime, date
from typing import Dict, Any, Optional, List

logger = logging.getLogger(__name__)


def _parse_nse_expiry(expiry_str: str) -> Optional[date]:
    """AUDIT-FIX (Round 23 — R23-1): NSE expiry strings arrive in several
    formats ('25-Sep-2026', '25-Sep-26', '2026-09-25'). Parse to a date,
    returning None when unrecognized so callers keep their policy default
    instead of computing garbage DTE."""
    s = str(expiry_str).strip()
    for fmt in ("%d-%b-%Y", "%d-%b-%y", "%Y-%m-%d", "%d-%m-%Y"):
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    return None


def resolve_live_chain_inputs(
    chain: Optional[dict],
    default_iv: float = 0.18,
    default_dte: int = 30,
    today: Optional[date] = None,
) -> Dict[str, Any]:
    """AUDIT-FIX (Round 23 — R23-1): resolve hedge inputs from a live
    fetch_nse_option_chain() result, with honest source labels.

    The R22 residual list noted the GEX/tail-hedge modules took IV from the
    18% policy default and DTE from the 30-day policy default even when a
    live chain was fetched. This helper extracts:
      * iv        — chain `median_iv` is in PERCENT units (NSE convention)
                    and is converted to a Black-Scholes fraction (13.5 -> 0.135);
      * dte_days  — calendar days from today to the chain's `expiry` string,
                    floored at 1 (an expiry reached today still has ~1 day of
                    time value);
      * spot      — chain `spot_price` when positive.
    Any missing/degraded field falls back to its policy default and the
    `*_source` labels say exactly which basis was used, so a hedge computed
    on policy-flat inputs can never masquerade as a regime-accurate one.
    """
    out: Dict[str, Any] = {
        "iv": float(default_iv),
        "dte_days": int(default_dte),
        "spot": None,
        "expiry": None,
        "iv_source": f"policy default ({default_iv:.0%}) — live chain unavailable/degraded",
        "dte_source": f"policy default ({default_dte}d) — live chain unavailable/degraded",
    }
    if not isinstance(chain, dict):
        return out

    sp = chain.get("spot_price")
    if isinstance(sp, (int, float)) and float(sp) > 0:
        out["spot"] = float(sp)

    iv = chain.get("median_iv")
    if isinstance(iv, (int, float)) and float(iv) > 0:
        out["iv"] = round(float(iv) / 100.0, 4)
        out["iv_source"] = (
            f"live NSE chain median IV {float(iv):.2f}% "
            f"({chain.get('underlying', 'NIFTY')})"
        )

    exp = chain.get("expiry")
    if exp:
        parsed = _parse_nse_expiry(str(exp))
        if parsed is not None:
            ref = today or datetime.now().date()
            dte = (parsed - ref).days
            if dte >= 0:
                out["dte_days"] = max(1, dte)
                out["expiry"] = str(exp)
                out["dte_source"] = f"live NSE chain expiry {exp} ({dte}d)"
    return out


def _bs_put_delta(spot: float, strike: float, r: float = 0.065,
                  sigma: float = 0.18, T: float = 30 / 252) -> float:
    """
    Compute Black-Scholes Put Delta: Δ_put = N(d1) - 1
    Uses N(d1) approximation via the standard normal CDF.
    Typical 5% OTM 30-day Nifty Put has delta ≈ -0.20 to -0.30.
    
    Args:
        spot:   Current Nifty index price
        strike: Option strike price
        r:      Risk-free rate (annualised, default 6.5% = India repo rate)
        sigma:  Implied volatility (annualised, default 18% = Nifty avg IV)
        T:      Time to expiry in years (default 30/252 ≈ 1-month)
    Returns:
        Absolute value of put delta (positive float in [0, 1])
    """
    try:
        from scipy.stats import norm
        if spot <= 0 or strike <= 0 or sigma <= 0 or T <= 0:
            return None  # Degenerate BS inputs — delta cannot be computed
        d1 = (np.log(spot / strike) + (r + 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T))
        put_delta_signed = norm.cdf(d1) - 1.0   # always negative for put
        return float(abs(put_delta_signed))
    except Exception as _e:
        logger.warning(f"[_bs_put_delta] Black-Scholes computation failed ({_e}) — returning None")
        return None  # Do not invent a moneyness-proxy delta


def _bs_put_price(spot: float, strike: float, r: float = 0.065,
                   sigma: float = 0.18, T: float = 30 / 252) -> float:
    """Black-Scholes European put premium: K·e^(−rT)·N(−d2) − S·N(−d1).

    AUDIT-FIX (Round 23 — R23-1): premium estimates were previously a flat
    1.2%-of-index heuristic regardless of the IV/DTE actually used for the
    delta — a 3-DTE 10% IV put was quoted at the same premium as a 60-DTE
    25% IV put. The premium now uses the SAME Black-Scholes inputs (spot,
    strike, r, iv, T) as the delta so the collar legs stay internally
    consistent. Returns 0.0 on degenerate inputs (callers keep a disclosed
    heuristic fallback).
    """
    try:
        from scipy.stats import norm
        if spot <= 0 or strike <= 0 or sigma <= 0 or T <= 0:
            return 0.0
        d1 = (np.log(spot / strike) + (r + 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T))
        d2 = d1 - sigma * np.sqrt(T)
        return float(max(strike * np.exp(-r * T) * norm.cdf(-d2) - spot * norm.cdf(-d1), 0.0))
    except Exception:
        return 0.0


def _bs_call_price(spot: float, strike: float, r: float = 0.065,
                   sigma: float = 0.18, T: float = 30 / 252) -> float:
    """Black-Scholes European call premium (collar leg 2). See _bs_put_price."""
    try:
        from scipy.stats import norm
        if spot <= 0 or strike <= 0 or sigma <= 0 or T <= 0:
            return 0.0
        d1 = (np.log(spot / strike) + (r + 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T))
        d2 = d1 - sigma * np.sqrt(T)
        return float(max(spot * norm.cdf(d1) - strike * np.exp(-r * T) * norm.cdf(d2), 0.0))
    except Exception:
        return 0.0


def _bs_gamma(spot: float, strike: float, r: float = 0.065,
              sigma: float = 0.18, T: float = 30 / 252) -> float:
    """Black-Scholes gamma: N'(d1) / (S · sigma · sqrt(T)).

    AUDIT-FIX (Round 24 — R24-2): the GEX computation previously scaled every
    strike with a FLAT `0.0001 x spot^2` gamma proxy — an ATM-ish magnitude
    applied uniformly, which overstates deep-wing strike gamma by ~2 orders
    of magnitude (wing gamma decays to ~1e-6) and therefore misshapes both
    the net GEX level and the flip-price location. This solver returns the
    strike-specific BS gamma. Degenerate inputs return 0.0 (the strike then
    contributes nothing rather than a fabricated constant).
    """
    try:
        from scipy.stats import norm
        if spot <= 0 or strike <= 0 or sigma <= 0 or T <= 0:
            return 0.0
        d1 = (np.log(spot / strike) + (r + 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T))
        return float(norm.pdf(d1) / (spot * sigma * np.sqrt(T)))
    except Exception:
        return 0.0


class OptionsTailHedger:
    """
    Institutional Portfolio Options Hedging Engine:
    
    1. Delta-Neutral Tail Protection (Nifty Put Buying):
       Hedges total portfolio beta-weighted delta:
           Δ_portfolio = Portfolio_Value × Σ (w_i × β_i)
           Nifty_Put_Lots = ceil( Δ_portfolio / (Nifty_Price × Lot_Size × |Δ_Put| ) )
    
    2. Zero-Cost Synthetic Collar:
       - Buy 5% OTM Protective Put (Downside protection)
       - Sell 5% OTM Covered Call (Finances the Put premium -> Net Zero Premium Outlay)
    """

    # NSE Nifty 50 standard lot size (updated to 75 as per SEBI circular Nov 2024)
    NIFTY_LOT_SIZE: int = 75

    def __init__(self, nifty_price: float = 24000.0):
        self.nifty_price = float(nifty_price)

    def calculate_hedge_recommendation(
        self,
        portfolio_df: pd.DataFrame,
        portfolio_value: float = 1000000.0,
        regime: str = "Bear",
        hawkes_warning: bool = False,
        otm_pct: float = 0.05,
        iv: float = 0.18,
        dte_days: int = 30,
        risk_free_rate: float = 0.065,
        iv_source: Optional[str] = None,
        dte_source: Optional[str] = None,
        beta_floor: Optional[float] = None,
        barra_portfolio_beta: Optional[float] = None,
    ) -> Dict[str, Any]:
        """
        Compute optimal Nifty option tail-hedge contracts and synthetic collar structure.

        Args:
            portfolio_df:    DataFrame with Ticker, Weight, Beta columns
            portfolio_value: Total portfolio capital in INR
            regime:          Active market regime string
            hawkes_warning:  True if Hawkes jump detector fired a transition warning
            otm_pct:         OTM percentage for strikes (default 5%)
            iv:              Implied volatility for delta computation (default 18%)
            dte_days:        Days to expiry (default 30 days = monthly expiry)
            risk_free_rate:  Annualised risk-free rate (default 6.5% RBI repo)
            iv_source:       AUDIT-FIX (R23-1) provenance label for `iv` (live chain
                             median vs policy default) — echoed in the response
            dte_source:      AUDIT-FIX (R23-1) provenance label for `dte_days`
            beta_floor:      AUDIT-FIX (R23-3) optional floor applied to per-stock
                             betas below it — trailing 63d betas of illiquid
                             microcaps regress to ~0 and silently collapse the
                             hedge size; floored tickers are DISCLOSED in the
                             response, never applied silently
            barra_portfolio_beta: AUDIT-FIX (R23-3) optional Barra model portfolio
                             beta for cross-check disclosure (hedge basis vs
                             factor-model basis)
        """
        if portfolio_df is None or portfolio_df.empty:
            return {
                "hedging_required": False,
                "reason": "Empty portfolio",
                "recommended_put_lots": 0,
                "recommended_put_qty": 0,
                "summary": "No option hedge required in current regime."
            }

        # Calculate portfolio Beta-weighted Delta
        # AUDIT-FIX (Round 23 — R23-3): trailing 63d betas of illiquid microcaps
        # regress to ~0 (near-zero covariance over the window), which silently
        # collapsed the portfolio's beta-weighted delta and the hedge size with
        # it (the Rs16,296 GARP tail-hedge anomaly). A disclosed beta floor
        # (default 0.30, cfg TAIL_HEDGE_BETA_FLOOR) now bounds each equity
        # row's beta contribution from below; floored tickers are LISTED in the
        # response so the operator can inspect them, and the Barra portfolio
        # beta (when available) is echoed as a cross-check reference. CASH rows
        # are excluded before the floor (they legitimately carry beta 0).
        #
        # AUDIT-FIX (Round 24 — R24-3): the betas ARRIVING here are now the
        # liquidity-aware shrinkage estimates from the signal frame
        # (math_engine.indicators.liquidity_aware_beta) — illiquid rows are
        # already shrunk toward the market prior instead of collapsing to ~0.
        # The flat floor therefore runs as a disclosed BACKSTOP (it should
        # rarely trigger once the estimator is active), no longer as the
        # primary defense. The estimation basis is disclosed below.
        total_beta_delta = 0.0
        floored_tickers: List[str] = []
        nan_beta_rows = 0
        for _, row in portfolio_df.iterrows():
            ticker = str(row.get("Ticker", "")).upper()
            if ticker == "CASH":
                continue
            w = float(row.get("Weight %", row.get("Weight", 0.0)) or 0.0)
            if w > 1.0:
                w /= 100.0  # normalize percent to fraction
            _beta_raw = row.get("Beta", np.nan)
            if pd.isna(_beta_raw):
                nan_beta_rows += 1
            beta = float(_beta_raw if pd.notna(_beta_raw) else 1.0)
            if beta_floor is not None and beta < float(beta_floor):
                beta = float(beta_floor)
                floored_tickers.append(ticker)
            total_beta_delta += w * beta

        portfolio_delta_val = portfolio_value * total_beta_delta

        # Decide if hedging is recommended (only if we have positive equity exposure to protect)
        hedging_required = (any(x in regime for x in ("Bear", "Stress", "Defensive")) or hawkes_warning) and (portfolio_delta_val > 0.01)

        # Compute strikes (round to nearest 50 for NSE Nifty strike grid)
        put_strike  = round(self.nifty_price * (1.0 - otm_pct) / 50.0) * 50
        call_strike = round(self.nifty_price * (1.0 + otm_pct) / 50.0) * 50

        # Dynamically compute Put delta from Black-Scholes (no hardcoded value)
        T = dte_days / 252.0
        put_delta = _bs_put_delta(
            spot=self.nifty_price, strike=put_strike,
            r=risk_free_rate, sigma=iv, T=T
        )

        nifty_contract_val = self.nifty_price * self.NIFTY_LOT_SIZE * put_delta

        # Calculate number of Put lots needed to hedge portfolio delta
        n_lots = max(1, int(np.ceil(portfolio_delta_val / (nifty_contract_val + 1e-9)))) if hedging_required else 0

        # Premium estimates: Black-Scholes with the SAME iv/T inputs as the
        # delta. AUDIT-FIX (Round 23 — R23-1): previously a flat 1.2%-of-index
        # heuristic regardless of regime IV or expiry — a 3-DTE low-IV put was
        # quoted at the same premium as a 60-DTE high-IV put. The heuristic is
        # now only a DISCLOSED fallback when BS inputs degenerate.
        est_put_premium_per_share = _bs_put_price(
            spot=self.nifty_price, strike=put_strike, r=risk_free_rate, sigma=iv, T=T
        )
        est_call_premium_per_share = _bs_call_price(
            spot=self.nifty_price, strike=call_strike, r=risk_free_rate, sigma=iv, T=T
        )
        premium_model = f"Black-Scholes (iv={iv:.1%}, T={dte_days}d — same inputs as delta)"
        if est_put_premium_per_share <= 0.0:
            est_put_premium_per_share = self.nifty_price * 0.012
            est_call_premium_per_share = est_put_premium_per_share * 0.95
            premium_model = "heuristic 1.2%-of-index fallback (BS inputs degenerate)"
        est_total_put_outlay = n_lots * self.NIFTY_LOT_SIZE * est_put_premium_per_share
        est_total_call_credit = n_lots * self.NIFTY_LOT_SIZE * est_call_premium_per_share

        _beta_note = (
            f"{len(floored_tickers)} equity row(s) floored at beta {float(beta_floor):.2f} "
            f"(tickers: {', '.join(floored_tickers[:10])}{'…' if len(floored_tickers) > 10 else ''}; "
            f"backstop below the liquidity-aware estimate); "
            f"{nan_beta_rows} row(s) had NaN beta defaulted to 1.0"
            if (beta_floor is not None and floored_tickers) else
            (f"no equity row below beta floor {float(beta_floor):.2f}; "
             f"{nan_beta_rows} row(s) had NaN beta defaulted to 1.0"
             if beta_floor is not None else
             f"no beta floor applied; {nan_beta_rows} row(s) had NaN beta defaulted to 1.0")
        )
        # AUDIT-FIX (Round 24 — R24-3): disclose the beta estimation basis —
        # the floor is a backstop, the model is the liquidity-aware shrinkage
        # estimator upstream in the signal frame.
        # AUDIT-FIX (Round 25 — R25-3): the shrinkage TARGET is now a
        # stock-specific characteristic factor-model prior (Barra-style
        # cross-sectional ridge on log-ADV/momentum/vol, leave-one-out)
        # built from the local universe, or a licensed per-stock feed via
        # the cfg key BETA_FACTOR_FEED — the flat 1.0 prior is only the
        # fallback when the cross-section is too small.
        _beta_estimation_note = (
            "Per-stock betas are liquidity-aware shrinkage estimates "
            "(beta_adj = w·beta_OLS + (1−w)·prior, w = n_eff/(n_eff+κ), "
            "n_eff = valid obs × clip(ADV20/Rs5cr, 0..1), κ=8 default) computed "
            "in the signal frame — illiquid microcap betas are shrunk toward the "
            "prior instead of collapsing to ~0 (Epps/non-trading bias); "
            "a full-window liquid name retains ~89% of its OLS beta. The prior "
            "itself is a stock-specific CHARACTERISTIC factor-model beta "
            "(cross-sectional ridge on log-ADV/6m-momentum/63d-vol, "
            "leave-one-out — Barra-style fundamental beta from the local "
            "universe) or a licensed per-stock feed (cfg BETA_FACTOR_FEED); "
            "the flat market prior (1.0) is the disclosed fallback only. The "
            "flat beta floor is a disclosed BACKSTOP on top of the model, not "
            "the model itself."
        )
        _barra_beta_val = None
        _barra_note = None
        try:
            if barra_portfolio_beta is not None and np.isfinite(float(barra_portfolio_beta)):
                _barra_beta_val = round(float(barra_portfolio_beta), 4)
                _barra_note = (
                    f"Barra factor-model portfolio beta {float(barra_portfolio_beta):.3f} vs "
                    f"hedge beta-weighted delta basis {total_beta_delta:.3f} — divergence "
                    f"means the per-stock betas and the factor model disagree on "
                    f"systematic exposure (see beta_floor_applied_to for floored rows)"
                )
        except (TypeError, ValueError):
            _barra_beta_val = None

        collar_df = pd.DataFrame([
            {
                "Leg": "1. Buy Protective Put (5% OTM)",
                "Instrument": f"NIFTY {int(put_strike)} PE",
                "Lots": n_lots,
                "Qty": n_lots * self.NIFTY_LOT_SIZE,
                "Put Delta (BS)": f"{put_delta:.3f}",
                "Est. Premium/Share": f"Rs{est_put_premium_per_share:.1f}",
                "Total Outlay": f"Rs{est_total_put_outlay:,.0f}",
                "Role": "Floor Protection (Caps max portfolio drawdown at 5%)",
            },
            {
                "Leg": "2. Sell Covered Call (5% OTM)",
                "Instrument": f"NIFTY {int(call_strike)} CE",
                "Lots": n_lots,
                "Qty": n_lots * self.NIFTY_LOT_SIZE,
                "Put Delta (BS)": "N/A",
                "Est. Premium/Share": f"Rs{est_call_premium_per_share:.1f}",
                "Total Outlay": f"-Rs{est_total_call_credit:,.0f} (Credit)",
                "Role": "Finances Put Purchase -> Net Zero Outlay Collar",
            }
        ])

        return {
            "hedging_required":                hedging_required,
            "regime":                          regime,
            "hawkes_warning":                  hawkes_warning,
            "portfolio_beta_weighted_delta":   round(total_beta_delta, 4),
            "portfolio_delta_rupee_val":        round(portfolio_delta_val, 2),
            "nifty_index_price":               self.nifty_price,
            "nifty_lot_size":                  self.NIFTY_LOT_SIZE,
            "nifty_put_strike_5pct_otm":       put_strike,
            "nifty_call_strike_5pct_otm":      call_strike,
            "bs_put_delta":                    round(put_delta, 4),
            "implied_vol_used":                iv,
            # AUDIT-FIX (Round 23 — R23-1): input provenance disclosure — the
            # response says whether iv/dte came from the live NSE chain or the
            # policy flat defaults, so a policy-flat hedge cannot be read as a
            # regime-accurate one.
            "iv_source":                       iv_source or f"policy default ({iv:.0%})",
            "dte_source":                      dte_source or f"policy default ({dte_days}d)",
            "premium_model":                   premium_model,
            "dte_days":                        dte_days,
            # AUDIT-FIX (Round 23 — R23-3): beta-floor disclosure + Barra cross-check
            "beta_floor":                      (float(beta_floor) if beta_floor is not None else None),
            "beta_floor_applied_to":           floored_tickers,
            "beta_basis_note":                 _beta_note,
            "beta_estimation_note":            _beta_estimation_note,
            "barra_portfolio_beta":            _barra_beta_val,
            "barra_cross_check_note":          _barra_note,
            "recommended_put_lots":            n_lots,
            "recommended_put_qty":             n_lots * self.NIFTY_LOT_SIZE,
            "est_net_collar_cost":             f"Rs{est_total_put_outlay - est_total_call_credit:,.0f}",
            "collar_legs_df":                  collar_df,
            "summary": (
                f"RECOMMENDED HEDGE: Buy {n_lots} Lots NIFTY {int(put_strike)} PE "
                f"(BS Delta={put_delta:.3f}, Lot=75) to protect "
                f"Rs{portfolio_delta_val:,.0f} portfolio delta."
                + ("" if (iv_source and iv_source.startswith("live")) else
                   " [IV/DTE: policy defaults — live chain unavailable]")
                if hedging_required else "No option hedge required in current regime."
            )
        }

    def calculate_net_gamma_exposure(
        self,
        option_chain: Optional[pd.DataFrame] = None,
        iv: float = 0.18,
        dte_days: int = 30,
        risk_free_rate: float = 0.065,
        iv_source: Optional[str] = None,
        dte_source: Optional[str] = None,
        multi_expiry_chains: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """
        Computes NIFTY Net Gamma Exposure (GEX) across option strikes and identifies Gamma Flip Price.
        Positive GEX -> Market Makers buy dips/sell rallies (low volatility stability).
        Negative GEX -> Market Makers sell declines/buy rallies (high volatility crash acceleration).

        AUDIT-FIX (Round 24 — R24-2): gamma is now SOLVED per strike with
        Black-Scholes (`N'(d1) / (S sigma sqrt(T))`) using the chain's
        per-strike IVs when present (callIV/putIV columns, percent units)
        and the chain-level median IV as fallback. The previous flat
        `0.0001 x spot^2` proxy applied an ATM-ish magnitude to every
        strike — deep wings were overstated by ~100x. Convention (disclosed
        in the response): net_gex_rupees = sum over strikes of
        gamma_BS x (CallOI - PutOI) x lot x spot^2 — the change in aggregate
        net dealer delta per 1-point index move, in INR, using the classic
        (call OI - put OI) dealer-positioning sign proxy. `iv`/`dte_days`
        come from resolve_live_chain_inputs (live chain when available,
        policy defaults otherwise) and their provenance is echoed.

        AUDIT-FIX (Round 25 — R25-2): MULTI-EXPIRY aggregation. The R24
        computation used ONE expiry's chain (the nearest) — the
        single-expiry convention overstated near-dated gamma and ignored
        the calendar tail. `multi_expiry_chains` is a list of
        {"frame": DataFrame, "dte_days": int, "label": str, "iv": float}
        (one entry per expiry, nearest-first); each expiry is solved with
        its OWN T and per-strike IVs (falling back to its own chain-level
        IV) and the total is the sum across expiries, with a per-expiry
        breakdown in `per_expiry_gex`. When the list is absent/empty the
        single-chain path (R24 semantics) runs unchanged. The
        (CallOI - PutOI) dealer-sign convention remains a disclosed
        PROXY in both paths (see `dealer_sign_convention`) — NSE does not
        publish per-trade direction, so customer-vs-dealer side cannot be
        measured, only assumed.
        """
        spot = self.nifty_price

        if multi_expiry_chains:
            return self._calculate_net_gamma_exposure_multi(
                multi_expiry_chains, risk_free_rate=risk_free_rate)

        if option_chain is None or option_chain.empty or "strikePrice" not in option_chain.columns:
            # Fallback: no chain rows — a DISCLOSED canned prior, never an implied measurement.
            flip_price = spot * 0.985  # ~1.5% below spot
            return {
                "net_gex_rupees": +150_000_000.0,
                "gamma_flip_price": round(flip_price, 2),
                "is_negative_gex": False,
                "regime_volatility_mode": "Positive GEX (Mean-Reverting / Low Volatility)",
                "recommended_cash_override": False,
                "gex_source": ("CANNED PRIOR — no live option-chain rows (offline/degraded fetch); "
                               "the +Rs150M positive-GEX value is a placeholder, not a measurement"),
                "gamma_model": "n/a (canned prior)",
            }

        strikes = option_chain["strikePrice"].values
        call_oi = option_chain.get("callOI", pd.Series(0, index=option_chain.index)).values
        put_oi = option_chain.get("putOI", pd.Series(0, index=option_chain.index)).values
        # Per-strike IVs when the chain rows carry them (NSE chain schema: percent units).
        # AUDIT-FIX (Round 24 — R24-2): prefer the strike's own IV; fall back
        # to the chain-level median IV fraction for strikes with missing/zero
        # IV. A DEGENERATE chain-level IV (<= 0) stays 0.0 — strikes without
        # any usable IV contribute ZERO (disclosed), never a fabricated 18%
        # policy value.
        call_iv = option_chain.get("callIV", None)
        put_iv = option_chain.get("putIV", None)
        sigma_fb = float(iv) if (isinstance(iv, (int, float)) and iv > 0) else 0.0
        T = max(dte_days, 1) / 252.0 if isinstance(dte_days, (int, float)) and dte_days > 0 else 30.0 / 252.0

        def _strike_sigma(call_iv_col, put_iv_col, row_idx: int) -> float:
            for col in (call_iv_col, put_iv_col):
                if col is not None:
                    try:
                        v = col.iloc[row_idx] if hasattr(col, "iloc") else col[row_idx]
                        if pd.notna(v) and float(v) > 0:
                            return float(v) / 100.0  # NSE percent -> BS fraction
                    except (IndexError, TypeError, ValueError):
                        continue
            return sigma_fb

        n_degenerate_iv = 0
        gex_per_strike = np.zeros(len(strikes), dtype=float)
        gamma_min, gamma_max = None, None
        for i, k in enumerate(strikes):
            sigma_k = _strike_sigma(call_iv, put_iv, i)
            if sigma_k <= 0 or not np.isfinite(sigma_k):
                n_degenerate_iv += 1
                continue
            gamma_k = _bs_gamma(spot=float(spot), strike=float(k),
                                r=float(risk_free_rate), sigma=float(sigma_k), T=float(T))
            if gamma_k <= 0 or not np.isfinite(gamma_k):
                continue
            gamma_min = gamma_k if gamma_min is None else min(gamma_min, gamma_k)
            gamma_max = gamma_k if gamma_max is None else max(gamma_max, gamma_k)
            # GEX convention: change in net dealer delta per 1-point index move (INR)
            gex_per_strike[i] = gamma_k * (call_oi[i] - put_oi[i]) * self.NIFTY_LOT_SIZE * (spot ** 2)
        total_gex = float(np.sum(gex_per_strike))

        # Find strike where cumulative GEX flips sign
        sort_idx = np.argsort(strikes)
        sorted_strikes = strikes[sort_idx]
        sorted_gex = gex_per_strike[sort_idx]
        cum_gex = np.cumsum(sorted_gex)

        flip_price = spot * 0.985
        neg_idx = np.where(cum_gex < 0)[0]
        if len(neg_idx) > 0:
            flip_price = float(sorted_strikes[neg_idx[0]])

        is_neg_gex = bool(spot < flip_price or total_gex < 0)

        per_strike_iv_used = (call_iv is not None and put_iv is not None)
        gamma_model = (
            f"strike-solved Black-Scholes gamma N'(d1)/(S·σ·√T), "
            f"{'per-strike IV (chain callIV/putIV)' if per_strike_iv_used else 'chain-level IV'} "
            f"(fallback {sigma_fb:.1%}), T={max(dte_days, 1)}d"
        )
        gex_source = (
            f"Computed from live chain rows ({len(strikes)} strikes): "
            f"net GEX = Σ Γ_BS·(CallOI−PutOI)·lot·S² — INR change in net dealer delta per 1-point move"
        )
        if iv_source:
            gex_source += f"; IV basis: {iv_source}"
        if dte_source:
            gex_source += f"; DTE basis: {dte_source}"
        if n_degenerate_iv:
            gex_source += (f"; {n_degenerate_iv} strike(s) had no usable IV and contributed 0 "
                           f"(no fabricated gamma)")

        return {
            "net_gex_rupees": round(total_gex, 2),
            "gamma_flip_price": round(flip_price, 2),
            "is_negative_gex": is_neg_gex,
            "regime_volatility_mode": "Negative GEX (Crash Accelerator)" if is_neg_gex else "Positive GEX (Volatility Suppressor)",
            "recommended_cash_override": is_neg_gex,
            # AUDIT-FIX (Round 24 — R24-2): provenance + model disclosure
            "gex_source": gex_source,
            "gamma_model": gamma_model,
            "gamma_range": (None if gamma_min is None else
                            [float(f"{gamma_min:.3e}"), float(f"{gamma_max:.3e}")]),
            "dte_days_used": int(max(dte_days, 1)) if isinstance(dte_days, (int, float)) else 30,
            # AUDIT-FIX (Round 25 — R25-2): the dealer-sign convention is
            # disclosed as a PROXY in every computed path — OI is two-sided
            # (customer long AND short both count); the (CallOI - PutOI) sign
            # assumes customers are net call-buyers / put-buyers and dealers
            # sit on the other side. Per-trade direction data (needed for a
            # TRUE dealer-positioning GEX) is not published by NSE.
            "dealer_sign_convention": self.DEALER_SIGN_CONVENTION,
            "expiries_aggregated": 1,
        }

    # AUDIT-FIX (Round 25 — R25-2): the classic dealer-sign convention, now
    # disclosed verbatim on every computed GEX response.
    DEALER_SIGN_CONVENTION: str = (
        "Dealer-sign PROXY: NSE open interest is two-sided (every contract has a "
        "long AND a short — OI alone does not say who holds which side). Net GEX "
        "uses the classic (CallOI - PutOI) convention, which assumes customers "
        "are net buyers of calls and puts while dealers take the other side — "
        "net dealer gamma is then proportional to (CallOI - PutOI) per strike. "
        "A true dealer-positioning GEX needs per-trade direction data NSE does "
        "not publish; this sign convention is an assumption, not a measurement."
    )

    def _calculate_net_gamma_exposure_multi(
        self,
        chains: List[Dict[str, Any]],
        risk_free_rate: float = 0.065,
    ) -> Dict[str, Any]:
        """MULTI-EXPIRY GEX aggregation (AUDIT-FIX Round 25 — R25-2).

        Each entry of `chains` is {"frame": per-strike DataFrame, "dte_days":
        int, "label": str, "iv": chain-level IV fraction fallback}. Every
        expiry is solved with its OWN T (dte_days/252) and per-strike IVs
        (callIV/putIV, percent units) with its own chain-level IV fallback —
        near-dated gamma decays with the square-root of time exactly like
        the real surface, and the calendar tail contributes instead of being
        ignored. Strikes with no usable IV contribute ZERO and are counted
        per expiry (disclosed). The aggregate net GEX is the SUM across
        expiries; a per-expiry breakdown (gex + share + dte) is returned in
        `per_expiry_gex` so the operator can see which expiry drives the
        number.
        """
        spot = self.nifty_price
        per_expiry: List[Dict[str, Any]] = []
        n_degenerate_total = 0
        gamma_min, gamma_max = None, None
        total_gex = 0.0
        # strike -> gex AGGREGATED across the included expiries, for both the
        # total level and the flip-price walk (the cumulative sign flip of the
        # aggregated per-strike GEX)
        gex_by_strike: Dict[float, float] = {}

        for ch in (chains or []):
            frame = ch.get("frame")
            if frame is None or getattr(frame, "empty", True) or "strikePrice" not in frame.columns:
                continue
            dte = ch.get("dte_days", 30)
            try:
                dte = int(dte)
            except (TypeError, ValueError):
                dte = 30
            dte = max(1, dte)
            T = dte / 252.0
            iv_fb = float(ch.get("iv") or 0.0)
            if iv_fb <= 0 or not np.isfinite(iv_fb):
                iv_fb = 0.0
            strikes = frame["strikePrice"].values
            call_oi = frame.get("callOI", pd.Series(0, index=frame.index)).values
            put_oi = frame.get("putOI", pd.Series(0, index=frame.index)).values
            call_iv = frame.get("callIV", None)
            put_iv = frame.get("putIV", None)

            def _strike_sigma(call_iv_col, put_iv_col, row_idx: int) -> float:
                for col in (call_iv_col, put_iv_col):
                    if col is not None:
                        try:
                            v = col.iloc[row_idx] if hasattr(col, "iloc") else col[row_idx]
                            if pd.notna(v) and float(v) > 0:
                                return float(v) / 100.0  # NSE percent -> BS fraction
                        except (IndexError, TypeError, ValueError):
                            continue
                return iv_fb

            expiry_gex = 0.0
            n_degenerate = 0
            for i, k in enumerate(strikes):
                sigma_k = _strike_sigma(call_iv, put_iv, i)
                if sigma_k <= 0 or not np.isfinite(sigma_k):
                    n_degenerate += 1
                    continue
                gamma_k = _bs_gamma(spot=float(spot), strike=float(k),
                                    r=float(risk_free_rate), sigma=float(sigma_k), T=float(T))
                if gamma_k <= 0 or not np.isfinite(gamma_k):
                    continue
                gamma_min = gamma_k if gamma_min is None else min(gamma_min, gamma_k)
                gamma_max = gamma_k if gamma_max is None else max(gamma_max, gamma_k)
                g = gamma_k * (call_oi[i] - put_oi[i]) * self.NIFTY_LOT_SIZE * (spot ** 2)
                expiry_gex += g
                gex_by_strike[float(k)] = gex_by_strike.get(float(k), 0.0) + g
            n_degenerate_total += n_degenerate
            total_gex += expiry_gex
            per_expiry.append({
                "label": str(ch.get("label", "expiry")),
                "dte_days": dte,
                "n_strikes": int(len(strikes)),
                "gex_inr": round(expiry_gex, 2),
                "share_pct": None,  # filled after the loop
                "degenerate_iv_strikes": int(n_degenerate),
            })

        # Fill in per-expiry shares of the aggregate magnitude
        _abs_total = sum(abs(e["gex_inr"]) for e in per_expiry) or 1.0
        for e in per_expiry:
            e["share_pct"] = round(100.0 * abs(e["gex_inr"]) / _abs_total, 1)

        # Flip-price walk on the AGGREGATED per-strike GEX
        if gex_by_strike:
            sorted_strikes = np.array(sorted(gex_by_strike.keys()))
            cum_gex = np.cumsum([gex_by_strike[k] for k in sorted_strikes])
            flip_price = float(spot) * 0.985
            neg_idx = np.where(cum_gex < 0)[0]
            if len(neg_idx) > 0:
                flip_price = float(sorted_strikes[neg_idx[0]])
        else:
            flip_price = float(spot) * 0.985

        is_neg_gex = bool(spot < flip_price or total_gex < 0)
        gex_source = (
            f"Computed from {len(per_expiry)} live option-chain expiry(ies): "
            f"net GEX = sum over expiry, sum over strike of Gamma_BS x (CallOI - PutOI) x lot x S^2 "
            f"(each expiry solved with its own T and per-strike IVs) — INR change in net dealer "
            f"delta per 1-point move"
        )
        if n_degenerate_total:
            gex_source += (f"; {n_degenerate_total} strike-expiry pair(s) had no usable IV and "
                           f"contributed 0 (no fabricated gamma)")
        gamma_model = (
            f"strike-solved Black-Scholes gamma N'(d1)/(S-sigma-sqrt(T)) per expiry "
            f"(per-strike IV where present, chain-level IV fallback), aggregated over "
            f"{len(per_expiry)} expir(ies) nearest-first"
        )

        return {
            "net_gex_rupees": round(total_gex, 2),
            "gamma_flip_price": round(float(flip_price), 2),
            "is_negative_gex": is_neg_gex,
            "regime_volatility_mode": "Negative GEX (Crash Accelerator)" if is_neg_gex else "Positive GEX (Volatility Suppressor)",
            "recommended_cash_override": is_neg_gex,
            "gex_source": gex_source,
            "gamma_model": gamma_model,
            "gamma_range": (None if gamma_min is None else
                            [float(f"{gamma_min:.3e}"), float(f"{gamma_max:.3e}")]),
            "dte_days_used": (int(per_expiry[0]["dte_days"]) if per_expiry else 30),
            "dealer_sign_convention": self.DEALER_SIGN_CONVENTION,
            "expiries_aggregated": len(per_expiry),
            "per_expiry_gex": per_expiry,
        }

