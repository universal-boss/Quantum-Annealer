"""
math_engine/path_signatures.py
==============================
Terry Lyons' Path Signatures & Rough Path Theory for Financial Asset Trajectories.

Computes truncated iterated path integrals over multi-stream financial paths
X_t = (Price_t, Volume_t, Spread_t, Delivery_t):

    S(X)_{s, t} = (1, S^1(X), S^2(X), S^3(X))

where:
    S^1_i     = Net displacement of stream i
    S^2_{i,j} = Iterated integral \\int dX^i dX^j (captures cross-stream lead-lag)
    A_{i,j}   = Levy Stochastic Area = 0.5 * (S^2_{i,j} - S^2_{j,i}) (cyclical accumulation)
    S^3       = Third-order geometric curvature & compression invariants

References:
    - Lyons, T. (1998), "Differential equations driven by rough signals", Rev. Mat. Iberoamericana.
    - Chevyrev, I. & Kormilitzin, A. (2016), "A Primer on the Signature Method in Machine Learning".
"""
from __future__ import annotations

import logging
from typing import Dict, Any, List, Optional, Tuple, Union
import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


class PathSignatureEngine:
    """
    Computes universal geometric path signatures over normalized asset price-volume streams.
    """

    @staticmethod
    def compute_lead_lag_transform(stream: np.ndarray) -> np.ndarray:
        """
        Constructs the 2D lead-lag path from a 1D stream:
        X_lead(2t) = X(t+1), X_lag(2t) = X(t).
        The signature of the lead-lag path uniquely encodes quadratic variation and volatility.
        """
        n = len(stream)
        if n < 2:
            return np.column_stack([stream, stream])
        
        lead = np.repeat(stream, 2)[1:]
        lag = np.repeat(stream, 2)[:-1]
        return np.column_stack([lead, lag])

    @classmethod
    def compute_path_signature(
        cls,
        prices: Union[np.ndarray, pd.Series],
        volumes: Optional[Union[np.ndarray, pd.Series]] = None,
        depth: int = 2,
        add_time: bool = True
    ) -> Dict[str, float]:
        """
        Computes truncated path signature up to degree 2 or 3 over normalized (Price, Volume, Time).

        Args:
            prices: Array or Series of asset prices.
            volumes: Array or Series of volumes (optional).
            depth: Signature truncation degree (2 or 3).
            add_time: Whether to augment path with monotonic time channel t in [0, 1].

        Returns:
            Dictionary mapping signature channels to their exact iterated integral values.
        """
        px = np.asarray(prices, dtype=float)
        valid_mask = np.isfinite(px) & (px > 0)
        px = px[valid_mask]
        n = len(px)

        if n < 5:
            return {
                "sig_displacement": 0.0,
                "sig_levy_area_pv": 0.0,
                "sig_lead_lag_var": 0.0,
                "sig_curvature": 0.0,
                "sig_compression_index": 0.5,
            }

        # 1. Normalize price stream: cumulative log returns from base
        log_px = np.log(px)
        norm_px = (log_px - log_px[0]) / (np.std(log_px) + 1e-9)

        # 2. Build multi-channel path matrix X
        channels = [norm_px]

        if volumes is not None:
            vol = np.asarray(volumes, dtype=float)[valid_mask] if len(volumes) == len(valid_mask) else np.asarray(volumes, dtype=float)
            vol = np.nan_to_num(vol, nan=float(np.median(vol[vol > 0])) if np.any(vol > 0) else 1.0)
            log_vol = np.log(np.maximum(vol, 1.0))
            norm_vol = (log_vol - np.mean(log_vol)) / (np.std(log_vol) + 1e-9)
            channels.append(norm_vol)
        else:
            channels.append(np.zeros_like(norm_px))

        if add_time:
            time_channel = np.linspace(0.0, 1.0, n)
            channels.append(time_channel)

        # Path X has shape (n, d)
        X = np.column_stack(channels)
        d = X.shape[1]

        # Increments dX of shape (n-1, d)
        dX = np.diff(X, axis=0)

        # ── Level 1: Displacement Vector S^1_i = X_T - X_0 ────────────────────
        S1 = np.sum(dX, axis=0)  # Shape (d,)

        # ── Level 2: Iterated Double Integrals S^2_{i,j} ──────────────────────
        # S^2_{i,j} = sum_{1 <= s < t <= n-1} dX_s^i * dX_t^j
        # Fast vectorization: sum_{s < t} a_s b_t = (sum a * sum b - sum(a * b)) / 2 + skew
        # Exact cumulative sum implementation:
        cumsum_dX = np.cumsum(dX, axis=0)
        # Shift cumsum to represent s < t (excluding current t)
        prev_cumsum = np.vstack([np.zeros((1, d)), cumsum_dX[:-1]])
        # S2[i, j] = sum_t (prev_cumsum[t, i] * dX[t, j])
        S2 = np.zeros((d, d), dtype=float)
        for i in range(d):
            for j in range(d):
                S2[i, j] = float(np.sum(prev_cumsum[:, i] * dX[:, j]))

        # ── Levy's Stochastic Area A_{i, j} = 0.5 * (S^2_{i,j} - S^2_{j,i}) ───
        # In the (Price=0, Volume=1) plane, positive Levy area indicates volume
        # leads price in an accumulation loop; negative indicates distribution.
        levy_area_pv = 0.5 * (S2[0, 1] - S2[1, 0])

        # ── Lead-Lag Quadratic Variation of Price ─────────────────────────────
        lead_lag = cls.compute_lead_lag_transform(norm_px)
        d_ll = np.diff(lead_lag, axis=0)
        ll_area = float(np.sum(d_ll[:, 0] * np.cumsum(d_ll[:, 1])))

        # ── Compression Metric (Path Efficiency) ──────────────────────────────
        # Ratio of net displacement to total path arc length:
        arc_length = float(np.sum(np.abs(dX[:, 0]))) + 1e-9
        net_displacement = float(np.abs(S1[0]))
        compression_index = float(np.clip(net_displacement / arc_length, 0.0, 1.0))

        # ── Level 3 Curvature Approximation ───────────────────────────────────
        # Product of Price displacement with (Price, Time) area:
        curvature = float(S1[0] * S2[0, 2]) if d >= 3 else float(S1[0] * S2[0, 1])

        return {
            "sig_displacement": float(S1[0]),
            "sig_levy_area_pv": float(np.clip(levy_area_pv, -10.0, 10.0)),
            "sig_lead_lag_var": float(np.clip(ll_area, -10.0, 10.0)),
            "sig_curvature": float(np.clip(curvature, -10.0, 10.0)),
            "sig_compression_index": compression_index,
        }

    @classmethod
    def score_universe_signatures(
        cls,
        prices_df: pd.DataFrame,
        volumes_df: Optional[pd.DataFrame] = None
    ) -> pd.DataFrame:
        """
        Computes path signatures across the entire candidate universe DataFrame.
        Returns a DataFrame indexed by ticker with geometric signature columns.
        """
        results = []
        tickers = list(prices_df.columns)

        for sym in tickers:
            px = prices_df[sym]
            vol = volumes_df[sym] if (volumes_df is not None and sym in volumes_df.columns) else None
            sig = cls.compute_path_signature(px, vol)
            sig["ticker"] = sym
            results.append(sig)

        if not results:
            return pd.DataFrame()

        df_sig = pd.DataFrame(results).set_index("ticker")
        return df_sig
