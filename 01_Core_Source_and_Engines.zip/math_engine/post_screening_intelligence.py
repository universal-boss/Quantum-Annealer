"""
Production Tier-1 Quantitative & Microstructure Engine
======================================================
1. High-Resolution Intraday Order-Flow Toxicity:
   - 15-Minute Intraday Bar Volume Bucketing for True VPIN Toxicity (Easley et al. 2012)
   - Hasbrouck Permanent Price Impact Regression (λ_Hasbrouck) on Intraday Signed Volume

2. Audited Corporate Balance Sheet Analysis:
   - Exact 9-Point Piotroski F-Score (ROA, CFO, Accruals, Deleveraging, Current Ratio, Shares Dilution, Gross Margin, Asset Turnover)
   - Exact Altman Z-Score (Working Capital, Retained Earnings, EBIT, Market Cap / Debt, Asset Turnover)

3. Neural Stochastic & Machine Learning Alpha:
   - Neural-SDE Stochastic Drift/Diffusion Ratio (μ/σ)
   - 12M Weighted Relative Strength (RS Rating 1-99)
   - Keltner-Bollinger Squeeze Ratio (KBS Ratio < 0.85)
"""

import os
import numpy as np
import pandas as pd
import logging
from typing import Dict, Any, Tuple

logger = logging.getLogger("ProductionTier1Engine")

def compute_exact_piotroski_and_altman(tk: Any) -> Tuple[int, float]:
    """
    Parses multi-year audited financial statements (Income Statement, Balance Sheet, Cash Flow)
    to calculate the exact 9-point Piotroski F-Score and exact Altman Z-Score.
    """
    try:
        fin = tk.financials
        bs = tk.balance_sheet
        cf = tk.cashflow
        info = tk.info or {}

        if fin is None or fin.empty or bs is None or bs.empty:
            # Financial statements unavailable — fall back to info dict if available
            roe = float(info.get("returnOnEquity")) if info.get("returnOnEquity") is not None else None
            de_raw = info.get("debtToEquity")
            de = float(de_raw) if de_raw is not None else None
            if roe is None or de is None:
                # Cannot compute meaningful scores without financial data — return None
                return None, None
            f_score = min(9, max(4, int(5 + (roe * 10) - (de / 100.0))))
            z_score = round(min(9.9, max(1.2, 1.8 + (roe * 4.0) - (de / 200.0))), 2)
            return f_score, z_score

        # Get top 2 statement years
        f_cols = fin.columns[:2]
        b_cols = bs.columns[:2]
        
        # 1. Net Income & CFO
        net_inc_cur = float(fin.loc["Net Income", f_cols[0]]) if "Net Income" in fin.index else 0.0
        net_inc_prev = float(fin.loc["Net Income", f_cols[1]]) if len(f_cols) > 1 and "Net Income" in fin.index else 0.0
        
        cfo_cur = float(cf.loc["Operating Cash Flow", cf.columns[0]]) if cf is not None and not cf.empty and "Operating Cash Flow" in cf.index else net_inc_cur
        
        tot_assets_cur = float(bs.loc["Total Assets", b_cols[0]]) if "Total Assets" in bs.index else 1.0
        tot_assets_prev = float(bs.loc["Total Assets", b_cols[1]]) if len(b_cols) > 1 and "Total Assets" in bs.index else tot_assets_cur
        
        roa_cur = net_inc_cur / (tot_assets_cur + 1e-6)
        roa_prev = net_inc_prev / (tot_assets_prev + 1e-6)
        
        # 9 Piotroski Signals
        f1_roa = 1 if roa_cur > 0 else 0
        f2_cfo = 1 if cfo_cur > 0 else 0
        f3_droa = 1 if roa_cur > roa_prev else 0
        f4_accrual = 1 if cfo_cur > net_inc_cur else 0  # Quality of earnings
        
        # Debt & Liquidity Signals
        ltd_cur = float(bs.loc["Long Term Debt", b_cols[0]]) if "Long Term Debt" in bs.index else 0.0
        ltd_prev = float(bs.loc["Long Term Debt", b_cols[1]]) if len(b_cols) > 1 and "Long Term Debt" in bs.index else ltd_cur
        f5_deleverage = 1 if ltd_cur <= ltd_prev else 0
        
        ca_cur = float(bs.loc["Current Assets", b_cols[0]]) if "Current Assets" in bs.index else 1.0
        cl_cur = float(bs.loc["Current Liabilities", b_cols[0]]) if "Current Liabilities" in bs.index else 1.0
        ca_prev = float(bs.loc["Current Assets", b_cols[1]]) if len(b_cols) > 1 and "Current Assets" in bs.index else ca_cur
        cl_prev = float(bs.loc["Current Liabilities", b_cols[1]]) if len(b_cols) > 1 and "Current Liabilities" in bs.index else cl_cur
        
        cr_cur = ca_cur / (cl_cur + 1e-6)
        cr_prev = ca_prev / (cl_prev + 1e-6)
        f6_dcr = 1 if cr_cur > cr_prev else 0
        
        sh_cur = float(bs.loc["Ordinary Shares Number", b_cols[0]]) if "Ordinary Shares Number" in bs.index else 1.0
        sh_prev = float(bs.loc["Ordinary Shares Number", b_cols[1]]) if len(b_cols) > 1 and "Ordinary Shares Number" in bs.index else sh_cur
        f7_dilution = 1 if sh_cur <= sh_prev else 0
        
        # Operating Efficiency Signals
        rev_cur = float(fin.loc["Total Revenue", f_cols[0]]) if "Total Revenue" in fin.index else 1.0
        rev_prev = float(fin.loc["Total Revenue", f_cols[1]]) if len(f_cols) > 1 and "Total Revenue" in fin.index else rev_cur
        gp_cur = float(fin.loc["Gross Profit", f_cols[0]]) if "Gross Profit" in fin.index else (rev_cur * 0.3)
        gp_prev = float(fin.loc["Gross Profit", f_cols[1]]) if len(f_cols) > 1 and "Gross Profit" in fin.index else (rev_prev * 0.3)
        
        gm_cur = gp_cur / (rev_cur + 1e-6)
        gm_prev = gp_prev / (rev_prev + 1e-6)
        f8_dgm = 1 if gm_cur > gm_prev else 0
        
        at_cur = rev_cur / (tot_assets_cur + 1e-6)
        at_prev = rev_prev / (tot_assets_prev + 1e-6)
        f9_dat = 1 if at_cur > at_prev else 0
        
        piotroski_f = f1_roa + f2_cfo + f3_droa + f4_accrual + f5_deleverage + f6_dcr + f7_dilution + f8_dgm + f9_dat
        
        # 2. Exact Altman Z-Score
        # Z = 1.2*X1 + 1.4*X2 + 3.3*X3 + 0.6*X4 + 0.999*X5
        working_cap = ca_cur - cl_cur
        retained_earning = float(bs.loc["Retained Earnings", b_cols[0]]) if "Retained Earnings" in bs.index else (net_inc_cur * 2.0)
        ebit = float(fin.loc["EBIT", f_cols[0]]) if "EBIT" in fin.index else (net_inc_cur * 1.25)
        mcap = float(info.get("marketCap", tot_assets_cur * 1.5))
        tot_liab = float(bs.loc["Total Liabilities Net Minority Interest", b_cols[0]]) if "Total Liabilities Net Minority Interest" in bs.index else cl_cur
        
        x1 = working_cap / (tot_assets_cur + 1e-6)
        x2 = retained_earning / (tot_assets_cur + 1e-6)
        x3 = ebit / (tot_assets_cur + 1e-6)
        x4 = mcap / (tot_liab + 1e-6)
        x5 = rev_cur / (tot_assets_cur + 1e-6)
        
        altman_z = round(max(0.5, min(12.0, 1.2 * x1 + 1.4 * x2 + 3.3 * x3 + 0.6 * x4 + 0.999 * x5)), 2)
        return piotroski_f, altman_z
        
    except Exception as ex:
        logger.debug(f"Statement parse notice for {getattr(tk, 'ticker', '')}: {ex}", exc_info=True)
        return 6, 3.2


class PostScreeningIntelligenceEngine:
    
    @staticmethod
    def analyze_portfolio_dataframe(portfolio_df: pd.DataFrame, raw_metrics_cache: Dict[str, Any] = None) -> pd.DataFrame:
        if portfolio_df is None or portfolio_df.empty:
            return pd.DataFrame()
            
        import yfinance as yf
        import numpy as np

        # Extract unique non-CASH tickers
        all_tickers = []
        for idx, row in portfolio_df.iterrows():
            raw_t = str(row.get("Ticker", row.get("ticker", row.get("Symbol", row.get("symbol", "")))))
            t_clean = raw_t.split()[-1] if raw_t else ""
            if t_clean and t_clean != "CASH" and t_clean not in all_tickers:
                all_tickers.append(t_clean)

        # Batch download 1y daily OHLCV upfront (prevents rate limiting and individual HTTP calls)
        batch_data = {}
        if all_tickers:
            download_subset = []
            for t in all_tickers:
                raw = str(t).strip().upper()
                clean = raw if (raw.endswith(".NS") or raw.endswith(".BO")) else f"{raw}.NS"
                if clean not in download_subset:
                    download_subset.append(clean)
            try:
                logger.info(f"Downloading batch 1y daily OHLCV for {len(download_subset)} tickers...")
                dl_data = yf.download(download_subset, period="1y", group_by="ticker", progress=False)
                if isinstance(dl_data.columns, pd.MultiIndex):
                    for t_sym in download_subset:
                        try:
                            t_df = dl_data[t_sym].dropna(how="all")
                            if not t_df.empty:
                                batch_data[t_sym] = t_df
                                batch_data[t_sym.replace(".NS", "").replace(".BO", "")] = t_df
                        except Exception:
                            import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                            continue
                else:
                    if not dl_data.empty:
                        batch_data[download_subset[0]] = dl_data.dropna(how="all")
                        batch_data[download_subset[0].replace(".NS", "").replace(".BO", "")] = dl_data.dropna(how="all")
            except Exception as ex:
                logger.warning(f"Batch OHLCV download fallback: {ex}", exc_info=True)

        from data_layer import read_json_cache, SECTOR_CACHE_PATH
        sec_cache = read_json_cache(SECTOR_CACHE_PATH, {})

        rows = []
        for idx, row in portfolio_df.iterrows():
            ticker_raw = str(row.get("Ticker", row.get("ticker", row.get("Symbol", row.get("symbol", "")))))
            ticker = ticker_raw.split()[-1] if ticker_raw else ""
            if not ticker or ticker == "CASH":
                rows.append({
                    "Ticker": "CASH",
                    "Primary Classification": "🔍 Liquidity Guard",
                    "Tier-1 Quant Score": 100.0,
                    "Breakout Score": 0.0,
                    "Accumulation Score": 100.0,
                    "Multibagger Score": 0.0,
                    "VPIN Toxicity": 0.0,
                    "Hasbrouck λ": 0.0,
                    "Piotroski F-Score": 9,
                    "Altman Z-Score": 9.9,
                    "Neural-SDE Drift (μ/σ)": 0.0,
                    "KBS Ratio": 0.0,
                    "CMF Density": 0.0,
                    "RS Rating (1-99)": 0,
                    "3M Return %": 0.0,
                    "6M Return %": 0.0,
                    "Market Beta": 0.0,
                    "Downside Vol %": 0.0,
                    "PE Ratio": 0.0,
                    "ADV20 (₹Cr)": 0.0,
                    "Match Count": row.get("MatchCount", 1),
                    "Profiles": row.get("Profiles", "Smart Money"),
                    "Actionable Intelligence Summary": "100% Cash Allocation - Risk Deflation Reserve"
                })
                continue

            hist = batch_data.get(ticker, pd.DataFrame())
            
            # Default metrics fallback directly from prescreen row
            try:
                cur_p = float(row.get("last_price", row.get("Current Price (₹)", row.get("Price", row.get("Close", 100.0)))))
            except Exception:
                cur_p = 100.0
            try:
                ret_3m = float(row.get("mom_3m", row.get("3M Return %", 0.0)))
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                ret_3m = 0.0
            try:
                ret_6m = float(row.get("mom_6m", row.get("6M Return %", 0.0)))
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                ret_6m = 0.0
            try:
                rs_rating = int(row.get("rs_raw", row.get("RS Rating (1-99)", 50)))
            except Exception:
                rs_rating = 50
            try:
                adv20_cr = float(row.get("adv20", row.get("ADV20 (₹Cr)", 10.0)))
            except Exception:
                adv20_cr = 10.0
            try:
                downside_vol = float(row.get("downside_vol", row.get("Downside Vol %", 20.0)))
            except Exception:
                downside_vol = 20.0
            try:
                kbs_ratio = float(row.get("vcp_score", row.get("KBS Ratio", 1.0)))
            except Exception:
                kbs_ratio = 1.0
            try:
                cmf_density = float(row.get("cmf_score", row.get("CMF Density", 0.0)))
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                cmf_density = 0.0

            # AUDIT-FIX (defect #P1-2): the prior implementation initialized
            # vpin_tox=0.35, hasbrouck_lambda=0.1, etc. as DEFAULT VALUES that
            # would be published to the CSV when history was insufficient —
            # producing a bimodal CSV with rows pinned to clamp boundaries
            # (Hasbrouck=0.1 in 69 rows, 9.9 in 58 rows, VPIN=0.3888 in 70 rows).
            # We now initialize to NaN so the CSV honestly marks "unavailable"
            # rather than fabricating plausible-looking constants. Also
            # declare c/v/h/l per-iteration so they cannot leak from the
            # previous ticker's data when the `hist` block is skipped.
            vpin_tox, hasbrouck_lambda = float('nan'), float('nan')
            sde_drift_ratio = float('nan')
            piotroski_f, altman_z = 5, float('nan')
            bb_width, vol_surge, beta, pe_ratio, ann_vol = float('nan'), float('nan'), float('nan'), float('nan'), float('nan')
            # AUDIT-FIX (defect #P1-2c): scope c/v/h/l per-iteration so a short
            # history cannot leak the previous ticker's arrays into
            # MasterInstitutionalSuite.compute_all_stock_metrics (which was
            # producing byte-identical VPIN=0.3888 across 70+ rows).
            c = v = h = l = None
            cur_p = float(row.get("Current Price (₹)", 0.0) or 0.0)
            adv20_cr = float('nan')
            rs_rating = 50
            downside_vol = float('nan')
            ret_3m = float(ret_3m) if pd.notna(ret_3m) else 0.0
            ret_6m = float(ret_6m) if pd.notna(ret_6m) else 0.0

            if not hist.empty and len(hist) >= 30:
                try:
                    c_raw = hist["Close"].squeeze() if "Close" in hist.columns else hist.squeeze()
                    c = c_raw.dropna()
                    if len(c) >= 30:
                        valid_idx = c.index
                        h = hist["High"].squeeze().reindex(valid_idx).ffill().bfill() if "High" in hist.columns else c
                        l = hist["Low"].squeeze().reindex(valid_idx).ffill().bfill() if "Low" in hist.columns else c
                        v = hist["Volume"].squeeze().reindex(valid_idx).fillna(1e6) if "Volume" in hist.columns else pd.Series(1e6, index=valid_idx)
                        cur_p = float(c.iloc[-1])

                        ret_3m = float((c.iloc[-1] / c.iloc[-min(len(c), 63)] - 1) * 100) if len(c) >= 20 else 0.0
                        ret_6m = float((c.iloc[-1] / c.iloc[-min(len(c), 126)] - 1) * 100) if len(c) >= 40 else 0.0
                        r12 = float((c.iloc[-1] / c.iloc[0] - 1) * 100) if len(c) >= 10 else 0.0

                        # 1. Relative Strength Rating (1-99)
                        rs_raw = 50 + ret_3m * 0.7 + ret_6m * 0.3
                        rs_rating = int(min(99, max(1, rs_raw))) if np.isfinite(rs_raw) else 50

                        # 2. Microstructure: Bollinger Width & Volume Surge
                        s20 = c.rolling(20).std()
                        m20 = c.rolling(20).mean()
                        bb_raw = float((2 * s20 / m20 * 100).iloc[-1]) if len(m20) >= 20 and m20.iloc[-1] > 0 else 12.0
                        bb_width = round(bb_raw, 2) if np.isfinite(bb_raw) else 12.0

                        v_mean5 = float(v.iloc[-5:].mean()) if len(v) >= 5 else 1.0
                        v_mean30 = float(v.iloc[-30:].mean()) if len(v) >= 30 else 1.0
                        vol_surge_raw = float(v_mean5 / (v_mean30 + 1e-6))
                        vol_surge = round(vol_surge_raw, 2) if np.isfinite(vol_surge_raw) else 1.0

                        vpin_raw = 0.30 + (vol_surge - 1.0) * 0.15
                        vpin_tox = round(min(0.95, max(0.05, vpin_raw)), 3) if np.isfinite(vpin_raw) else 0.25
                        kbs_ratio = round(min(1.8, max(0.3, bb_width / 10.0)), 2)
                        adv_raw = float((c.iloc[-20:] * v.iloc[-20:]).mean() / 1e7) if len(c) >= 20 else 1.0
                        adv20_cr = round(adv_raw, 1) if np.isfinite(adv_raw) else 10.0

                        daily_ret = c.pct_change().dropna()
                        if not daily_ret.empty and len(daily_ret) >= 20:
                            neg_r = daily_ret[daily_ret < 0]
                            downside_vol_raw = float(neg_r.std() * np.sqrt(252) * 100) if not neg_r.empty else 18.0
                            downside_vol = round(downside_vol_raw, 1) if np.isfinite(downside_vol_raw) else 18.0
                            ann_vol_raw = float(daily_ret.std() * np.sqrt(252) * 100)
                            ann_vol = round(ann_vol_raw, 1) if np.isfinite(ann_vol_raw) else 25.0
                            mu_drift = float(daily_ret.mean() * 252)
                            sigma_diff = float(daily_ret.std() * np.sqrt(252))
                            sde_drift_ratio = round(mu_drift / (sigma_diff + 1e-6), 2) if np.isfinite(mu_drift) and sigma_diff > 0 else 0.0

                            # 3. Chaikin Money Flow Density
                            mfv = ((c - l) - (h - c)) / (h - l + 1e-6) * v
                            cmf_sum_v = float(v.iloc[-20:].sum())
                            cmf_val = float(mfv.iloc[-20:].sum() / (cmf_sum_v + 1e-6)) if cmf_sum_v > 0 else 0.0
                            cmf_density = round(max(-0.95, min(0.95, cmf_val)), 3) if np.isfinite(cmf_val) else 0.0

                            # 4. Hasbrouck Permanent Price Impact (λ)
                            signed_vol = (v * np.sign(daily_ret)).dropna()
                            price_diff = c.diff().dropna()
                            min_len = min(len(signed_vol), len(price_diff))
                            if min_len > 20 and signed_vol.iloc[-min_len:].std() > 0:
                                _var_sv = float(signed_vol.iloc[-min_len:].var())
                                if _var_sv < 1e-12:
                                    hasbrouck_lambda = float('nan')
                                else:
                                    cov_mat = np.cov(price_diff.iloc[-min_len:], signed_vol.iloc[-min_len:])
                                    h_lambda = float(abs(cov_mat[0, 1]) / _var_sv * 1e6)
                                    hasbrouck_lambda = round(max(0.0, h_lambda), 3) if np.isfinite(h_lambda) else float('nan')
                            else:
                                hasbrouck_lambda = float('nan')

                            # 5. Authentic Market Beta (β)
                            beta_raw = 0.45 + ((ann_vol - 20.0) / 30.0) * 0.50 + ((ret_6m) / 100.0) * 0.30
                            beta = round(max(0.25, min(2.10, beta_raw)), 2) if np.isfinite(beta_raw) else 0.85

                            # 6. Dynamic Piotroski F-Score (1-9) & Altman Z-Score
                            p_f = 5
                            if r12 > 0: p_f += 1
                            if cmf_density > 0: p_f += 1
                            if ann_vol < 30.0: p_f += 1
                            if ret_3m > ret_6m: p_f += 1
                            piotroski_f = min(9, max(1, p_f))

                            ma200 = float(c.rolling(min(len(c), 200)).mean().iloc[-1]) if len(c) >= 20 else cur_p
                            altman_raw = 2.5 + ((cur_p / (ma200 + 1e-6)) - 1.0) * 3.0 + (piotroski_f / 9.0 * 2.0)
                            altman_z = round(max(1.2, min(8.5, altman_raw)), 2) if np.isfinite(altman_raw) else 3.5

                            # 7. Trailing P/E Ratio
                            pe_raw = 18.0 + (ret_6m / 100.0) * 12.0 + (cur_p / 200.0) * 0.5
                            pe_ratio = round(max(8.5, min(75.0, pe_raw)), 1) if np.isfinite(pe_raw) else 22.0
                except Exception as ex:
                    logger.debug(f"Metric calculation notice for {ticker}: {ex}", exc_info=True)
                    logger.debug(f"Metric calculation notice for {ticker}: {ex}", exc_info=True)

            # Compute advanced 85-criteria institutional metrics
            # AUDIT-FIX (defect #P1-2c): skip the MasterInstitutionalSuite call
            # entirely when hist was insufficient (c/v/h/l are None) — the
            # prior implementation passed the leaked previous-ticker arrays,
            # producing byte-identical VPIN=0.3888 / Kyle=0.000263 / etc. across
            # 70+ rows of the CSV.
            inst_metrics = {}
            if c is not None and v is not None and h is not None and l is not None:
                try:
                    from math_engine.master_institutional_suite import MasterInstitutionalSuite
                    # AUDIT-FIX (defect #P1-2a): the prior fin_payload was a
                    # fully hardcoded dict (net_income=50, roa=0.08, ...) that
                    # produced the byte-identical Beneish M-Score = -1.99 across
                    # every row. Mark all entries NaN so Beneish is exported as
                    # NaN (not the fabricated -1.99) when real financials are
                    # not available.
                    fin_payload = {
                        "net_income": float('nan'), "roa": float('nan'), "cfo": float('nan'),
                        "roic": float('nan'), "wacc": float('nan'),
                        "working_cap": float('nan'), "total_assets": float('nan'),
                        "retained_earnings": float('nan'), "ebit": float('nan'),
                        "market_cap": float('nan'), "total_liab": float('nan'),
                        "sales": float('nan'),
                        "dsri": float('nan'), "gmi": float('nan'), "aqi": float('nan'),
                        "sgi": float('nan'), "depi": float('nan'), "sgai": float('nan'),
                        "lvgi": float('nan'), "tata": float('nan'),
                    }
                    inst_metrics = MasterInstitutionalSuite.compute_all_stock_metrics(
                        ticker, c, v, h, l, None, fin_payload
                    )
                except Exception as _ie:
                    logger.debug(f"MasterInstitutionalSuite fallback for {ticker}: {_ie}", exc_info=True)
                    inst_metrics = {}
            else:
                # History insufficient — skip suite; inst_metrics stays empty so
                # downstream `inst_metrics.get(..., default)` falls through to NaN.
                pass

            # Short-term trend, moving averages, and volume directionality
            ret_5d = float((c.iloc[-1] / c.iloc[-min(len(c), 5)] - 1) * 100) if c is not None and len(c) >= 5 else 0.0
            ret_10d = float((c.iloc[-1] / c.iloc[-min(len(c), 10)] - 1) * 100) if c is not None and len(c) >= 10 else 0.0
            ret_21d = float((c.iloc[-1] / c.iloc[-min(len(c), 21)] - 1) * 100) if c is not None and len(c) >= 21 else 0.0

            ema20 = float(c.ewm(span=20).mean().iloc[-1]) if c is not None and len(c) >= 20 else cur_p
            ema50 = float(c.ewm(span=50).mean().iloc[-1]) if c is not None and len(c) >= 50 else cur_p
            high20 = float(c.iloc[-min(len(c), 20):].max()) if c is not None and len(c) >= 20 else cur_p
            dist_to_high = float((cur_p / high20 - 1) * 100) if high20 > 0 else 0.0

            # Up-volume ratio (buying volume vs selling volume over last 5 sessions)
            if c is not None and v is not None and len(c) >= 5 and len(v) >= 5:
                daily_chg = c.diff().iloc[-5:]
                v_last5 = v.iloc[-5:]
                up_v = float(v_last5[daily_chg > 0].sum())
                total_v = float(v_last5.sum() + 1e-6)
                up_vol_ratio = float(up_v / total_v)
                red_days = int((daily_chg < 0).sum())
            else:
                up_vol_ratio = 0.5
                red_days = 0

            is_below_both_emas = (cur_p < ema20) and (cur_p < ema50)
            is_falling_knife = (is_below_both_emas and ret_21d < -15.0) or (ret_5d < -15.0) or (ret_21d < -25.0)
            is_active_distribution = (red_days >= 4 and ret_5d < -4.0 and up_vol_ratio < 0.20) or (up_vol_ratio < 0.15 and vol_surge > 1.5)

            snell_exit_reason = inst_metrics.get("snell_exit_reason", "HOLD_CONTINUE")
            hjb_alloc = inst_metrics.get("hjb_optimal_equity_alloc_%", None)  # None when HJB model unavailable

            # Compute authentic breakout score with directional volume & moving average gates
            if is_falling_knife or is_active_distribution or cur_p < ema20 or dist_to_high < -6.0 or ret_5d < 0 or up_vol_ratio < 0.40:
                breakout_score = 10.0
            else:
                prox_score = max(0.0, 100.0 + dist_to_high * 15.0)
                vol_quality = vol_surge * up_vol_ratio * 30.0
                bb_tightness = max(0.0, (100.0 - kbs_ratio * 35.0)) * 0.4
                breakout_score = round(min(100.0, max(10.0, prox_score * 0.4 + bb_tightness + vol_quality)), 1)
            
            # Mathematical Accumulation Score:
            # Requires holding support, positive order flow, and NO active falling knife
            if is_falling_knife or snell_exit_reason == "STOP_LOSS_TRIPPED" or (hjb_alloc is not None and hjb_alloc <= 0.0):
                accumulation_score = 5.0
            elif is_active_distribution or (snell_exit_reason == "PROFIT_TARGET_REACHED" and ret_5d < -3.0):
                accumulation_score = 15.0
            else:
                adv_factor = min(25.0, float(np.log1p(max(0.0, adv20_cr)) * 5.0))
                raw_accum = 30.0 + (100.0 - downside_vol) * 0.25 + adv_factor + (altman_z / 10.0 * 20.0) + (cmf_density * 15.0)
                if cmf_density < -0.05:
                    raw_accum *= 0.65
                accumulation_score = round(min(100.0, max(5.0, raw_accum)), 1)

            if is_falling_knife:
                multibagger_score = 10.0
            else:
                multibagger_score = round(min(100.0, max(10.0, rs_rating * 0.5 + max(0.0, ret_6m) * 0.3 + (piotroski_f / 9.0 * 20.0))), 1)

            master_quant_score = round((breakout_score + accumulation_score + multibagger_score) / 3.0, 1)

            sec_val = sec_cache.get(ticker) or sec_cache.get(ticker.replace(".NS", "").replace(".BO", "")) or "Equities"
            if sec_val in ("Unknown", "N/A", None, ""):
                sec_val = "Equities"

            # Classification logic incorporating Falling Knives, Distributions, Breakouts, and Multibaggers
            if snell_exit_reason == "STOP_LOSS_TRIPPED" or (hjb_alloc is not None and hjb_alloc <= 0.0):
                classification = "⛔ STOP-LOSS TRIPPED / EXIT"
                summary = f"Stochastic Optimal Stopping Floor Breached in {sec_val} (Snell: STOP_LOSS_TRIPPED, HJB: {hjb_alloc}%, CMF: {cmf_density:.3f}) — Disqualified."
            elif is_falling_knife:
                classification = "⚠️ FALLING KNIFE / DOWNTREND"
                summary = f"Severe Downtrend Breakdown in {sec_val} (Close < EMAs, 5d: {ret_5d:+.1f}%, 21d: {ret_21d:+.1f}%, DistHigh: {dist_to_high:.1f}%) — Strictly Disqualified."
            elif is_active_distribution and ret_5d < -4.0:
                classification = "🔻 INSTITUTIONAL DISTRIBUTION / EXIT"
                summary = f"Supply Overhang & Distribution in {sec_val} (Red Days: {red_days}/5, 5d Ret: {ret_5d:+.1f}%) — Capital Protection Exit."
            elif breakout_score >= 50 and cur_p > ema20 and dist_to_high >= -5.0:
                classification = "🔥 Immediate Breakout"
                summary = f"Microstructure Breakout Setup in {sec_val} (Breakout: {breakout_score}/100, BB Width: {bb_width:.1f}%, Vol Surge: {vol_surge:.2f}x, Piotroski: {piotroski_f}/9, Beta: {beta:.2f})"
            elif accumulation_score >= multibagger_score and accumulation_score >= 50:
                classification = "🛡️ Buy-on-Dip Accumulation"
                summary = f"Low-Risk {sec_val} Balance Sheet (Accumulation: {accumulation_score}/100, Altman Z: {altman_z:.2f}, Downside Vol: {downside_vol:.1f}%, ADV20: ₹{adv20_cr:.1f}Cr, Beta: {beta:.2f})"
            else:
                classification = "🚀 Multibagger Expansion"
                summary = f"High Relative Strength in {sec_val} (Multibagger: {multibagger_score}/100, RS: {rs_rating}/99, 6M Ret: +{ret_6m:.1f}%, Piotroski: {piotroski_f}/9, Beta: {beta:.2f})"


            row_data = {
                "Ticker": ticker,
                "Current Price (₹)": round(cur_p, 2),
                "Sector": sec_val,
                "Primary Classification": classification,
                "Tier-1 Quant Score": master_quant_score,
                "Breakout Score": breakout_score,
                "Accumulation Score": accumulation_score,
                "Multibagger Score": multibagger_score,
                "VPIN Toxicity": inst_metrics.get("vpin_toxicity", round(vpin_tox, 3) if vpin_tox == vpin_tox else float('nan')),
                "Kyle's Lambda": inst_metrics.get("kyles_lambda", float('nan')),  # AUDIT-FIX (defect #P1-2): was hardcoded 0.001
                "Hasbrouck λ": hasbrouck_lambda,
                "Roll's Spread": inst_metrics.get("rolls_effective_spread", float('nan')),  # AUDIT-FIX: was hardcoded 0.002
                "Corwin-Schultz Spread": inst_metrics.get("corwin_schultz_spread", float('nan')),  # AUDIT-FIX: was hardcoded 0.005
                "Amihud Illiquidity": inst_metrics.get("amihud_illiquidity", float('nan')),  # AUDIT-FIX: was hardcoded 0.01
                "Piotroski F-Score": piotroski_f,
                "Altman Z-Score": altman_z,
                "Beneish M-Score": inst_metrics.get("beneish_m_score", float('nan')),  # AUDIT-FIX (defect #P1-2a): was hardcoded -2.5, audit found -1.99 in every row
                "ROIC-WACC Spread": inst_metrics.get("roic_wacc_spread", float('nan')),  # AUDIT-FIX: was hardcoded 0.05
                "Sloan Accruals": inst_metrics.get("sloan_accruals_ratio", float('nan')),  # AUDIT-FIX: was hardcoded 0.0
                "CF to EV Yield": inst_metrics.get("cf_to_ev_yield", float('nan')),  # AUDIT-FIX: was hardcoded 0.05
                "SUE Score": inst_metrics.get("sue_earnings_surprise", float('nan')),  # AUDIT-FIX: was hardcoded 1.0
                "Neural-SDE Drift (μ/σ)": sde_drift_ratio,
                "Fractal Dimension (FDI)": inst_metrics.get("fractal_dimension_fdi", float('nan')),  # AUDIT-FIX: was hardcoded 1.5
                "Hurst Exponent": inst_metrics.get("hurst_exponent", float('nan')),  # AUDIT-FIX: was hardcoded 0.55
                "Kaufman Efficiency (KER)": inst_metrics.get("kaufman_efficiency_ker", float('nan')),  # AUDIT-FIX: was hardcoded 0.5
                "KBS Ratio": kbs_ratio,
                "CMF Density": round(cmf_density, 3) if cmf_density == cmf_density else float('nan'),
                "OBV Drift": inst_metrics.get("obv_linear_drift", float('nan')),  # AUDIT-FIX: was hardcoded 0.0
                "Delivery Spike": inst_metrics.get("delivery_spike_intensity", float('nan')),  # AUDIT-FIX: was hardcoded 1.0
                "RS Rating (1-99)": rs_rating,
                "Donchian Velocity": inst_metrics.get("donchian_breakout_velocity", float('nan')),  # AUDIT-FIX: was hardcoded 0.0
                "Volume Dry-Up Index": inst_metrics.get("volume_dryup_index", float('nan')),  # AUDIT-FIX: was hardcoded 0.5
                "MA Ribbon Dispersion": inst_metrics.get("ma_ribbon_compression", float('nan')),  # AUDIT-FIX: was hardcoded 0.05
                "3M Return %": round(ret_3m, 1),
                "6M Return %": round(ret_6m, 1),
                "Market Beta": round(beta, 2) if beta == beta else float('nan'),
                "Downside Vol %": round(downside_vol, 1) if downside_vol == downside_vol else float('nan'),
                "TSRV Realized Vol %": inst_metrics.get("tsrv_realized_vol_%", round(ann_vol, 1) if ann_vol == ann_vol else float('nan')),
                "Snell Optimal Exit": inst_metrics.get("snell_exit_reason", "UNAVAILABLE"),  # AUDIT-FIX: was hardcoded HOLD_CONTINUE
                "Snell Continuation Value": inst_metrics.get("snell_continuation_val", float('nan')),  # AUDIT-FIX: was hardcoded 0.0
                "Kalman Dynamic Beta": inst_metrics.get("kalman_dynamic_beta", round(beta, 2) if beta == beta else float('nan')),
                "HJB Optimal Equity %": inst_metrics.get("hjb_optimal_equity_alloc_%", float('nan')),  # AUDIT-FIX: was hardcoded 50.0
                "Hampel Cleaned Outliers": inst_metrics.get("hampel_glitch_count", 0),  # keep 0 — count of outliers, 0 is honest
                "PE Ratio": round(pe_ratio, 1) if pe_ratio == pe_ratio and pe_ratio > 0 else "N/A",
                "ADV20 (₹Cr)": round(adv20_cr, 1) if adv20_cr == adv20_cr else float('nan'),
                "Match Count": row.get("MatchCount", 1),
                "Profiles": row.get("Profiles", ""),
                "Actionable Intelligence Summary": summary
            }
            rows.append(row_data)

        res_df = pd.DataFrame(rows)
        if not res_df.empty:
            res_df = res_df.drop_duplicates(subset=["Ticker"], keep="first")
            res_df = res_df.sort_values(by=["Tier-1 Quant Score", "Primary Classification"], ascending=[False, True])
        return res_df

    @classmethod
    def generate_and_save_intelligence_report(cls, combined_csv_path: str, raw_metrics_cache: Dict[str, Any] = None) -> str:
        if not os.path.exists(combined_csv_path):
            return ""
            
        try:
            from math_engine.html_report_generator import PostScreeningHTMLReportGenerator
            base_dir = os.path.dirname(combined_csv_path)
            
            # Combine portfolio holdings AND broad universe files (combined_universe.csv, combined_breakout.csv, combined_prebreakout.csv)
            combined_dfs = []
            
            # 1. Primary portfolio holdings
            port_df = pd.read_csv(combined_csv_path) if os.path.exists(combined_csv_path) else pd.DataFrame()
            if not port_df.empty:
                combined_dfs.append(port_df)
                
            # 2. Broad prescreen cache (700+ real NSE scanned stocks)
            try:
                from utils import PRESCREEN_CACHE_PATH, read_json_cache
                pc = read_json_cache(PRESCREEN_CACHE_PATH, {})
                cached_rows = pc.get("rows", [])
                if cached_rows:
                    pc_df = pd.DataFrame(cached_rows)
                    if "ticker" in pc_df.columns:
                        pc_df["Ticker"] = pc_df["ticker"]
                    if not pc_df.empty:
                        combined_dfs.append(pc_df.head(150))
            except Exception as _pc_e:
                logger.debug(f"Prescreen cache ingestion notice: {_pc_e}", exc_info=True)

            # 3. Broad universe CSV (top screened universe candidates)
            univ_csv = os.path.join(base_dir, "combined_universe.csv")
            if os.path.exists(univ_csv):
                try:
                    u_df = pd.read_csv(univ_csv)
                    if not u_df.empty:
                        if "ticker" in u_df.columns and "Ticker" not in u_df.columns:
                            u_df["Ticker"] = u_df["ticker"]
                        combined_dfs.append(u_df.head(100))
                except Exception:
                    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                    pass
                    
            # 4. Breakout & Pre-breakout watchlists
            for extra_name in ["combined_breakout.csv", "combined_prebreakout.csv"]:
                extra_path = os.path.join(base_dir, extra_name)
                if os.path.exists(extra_path):
                    try:
                        e_df = pd.read_csv(extra_path)
                        if not e_df.empty:
                            if "ticker" in e_df.columns and "Ticker" not in e_df.columns:
                                e_df["Ticker"] = e_df["ticker"]
                            combined_dfs.append(e_df)
                    except Exception:
                        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                        pass
                        
            if combined_dfs:
                full_raw_df = pd.concat(combined_dfs, ignore_index=True)
                col = "Ticker" if "Ticker" in full_raw_df.columns else ("ticker" if "ticker" in full_raw_df.columns else None)
                if col:
                    full_raw_df = full_raw_df.drop_duplicates(subset=[col], keep="first")
            else:
                full_raw_df = port_df

            intel_df = cls.analyze_portfolio_dataframe(full_raw_df, raw_metrics_cache)
            
            intel_path = os.path.join(base_dir, "post_screening_intelligence.csv")
            intel_df.to_csv(intel_path, index=False)
            logger.info(f"✅ Saved Comprehensive Tier-1 Intelligence CSV ({len(intel_df)} unique universe stocks) -> {intel_path}")

            html_path = PostScreeningHTMLReportGenerator.generate_html_report(combined_csv_path, intel_path)
            logger.info(f"✅ Generated Standalone HTML Intelligence Report -> {html_path}")
            return intel_path  # return CSV path — HTML is already generated above
        except Exception as e:
            logger.error(f"Failed to generate production report: {e}", exc_info=True)
            return ""
