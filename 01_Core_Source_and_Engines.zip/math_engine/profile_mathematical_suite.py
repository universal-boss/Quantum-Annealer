"""
math_engine/profile_mathematical_suite.py
=========================================
Tier-1 Quantitative Mathematical Specialization Suite for Quantum Annealer Profiles.

Implements rigorous stochastic models:
1. Sortino Downside Semi-Variance Matrix (Sigma_down) & Half-Kelly Sizing
2. Hawkes Self-Exciting Process for Microstructural Institutional Flow Clustering
3. Idzorek Extended Black-Litterman Matrix Blending with View Uncertainty
4. Equal Risk Contribution (ERC) Cyclical Coordinate Descent Solver
5. Conditional Value-at-Risk (CVaR 99%) & Downside Tail Dependence
6. Adaptive Volatility-Scaled (k-ATR & TSRV) Dynamic Target & Stop-Loss Engine
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, List, Tuple, Optional

logger = logging.getLogger(__name__)


# ── 1. Sortino Downside Semi-Variance Matrix & Half-Kelly ─────────────────────
class SortinoDownsideCovariance:
    """
    Computes the downside semi-variance covariance matrix Sigma_down.
    Penalizes strictly negative excess returns relative to a target return tau,
    preserving upside variance for high-momentum alpha compounders.
    """

    @staticmethod
    def compute_downside_covariance(
        returns: pd.DataFrame | np.ndarray,
        target_return: float = 0.0
    ) -> np.ndarray:
        """
        Calculates the semi-covariance matrix:
        Sigma_down[i, j] = 1/T * sum_t min(r_{i,t} - tau, 0) * min(r_{j,t} - tau, 0)
        """
        if isinstance(returns, pd.DataFrame):
            R = returns.values
        else:
            R = np.asarray(returns)

        if R.ndim != 2 or R.shape[0] < 2:
            n = R.shape[1] if R.ndim == 2 else (len(R) if R.ndim == 1 else 1)
            return np.eye(n) * 0.04

        # Downside deviations below target return
        downside_diff = np.minimum(R - target_return, 0.0)
        T, N = downside_diff.shape
        
        sigma_down = np.dot(downside_diff.T, downside_diff) / max(T - 1, 1)

        # Regularize to guarantee positive semi-definiteness
        diag = np.diag(sigma_down)
        min_var = 1e-5
        if np.any(diag < min_var):
            sigma_down += np.eye(N) * min_var

        return sigma_down

    @staticmethod
    def calculate_half_kelly_bounds(
        expected_returns: np.ndarray,
        volatilities: np.ndarray,
        risk_free_rate: float = 0.065 / 252.0,
        fraction: float = 0.40,
        max_bound: float = 0.35
    ) -> np.ndarray:
        """
        Computes continuous Half-Kelly allocation caps:
        w_i* = fraction * (mu_i - r_f) / sigma_i^2
        """
        mu = np.asarray(expected_returns)
        sigma = np.asarray(volatilities)
        sigma_sq = np.maximum(sigma**2, 1e-4)

        excess_ret = np.maximum(mu - risk_free_rate, 0.0)
        kelly_weights = fraction * (excess_ret / sigma_sq)
        
        # Clamp to reasonable portfolio risk bounds
        return np.clip(kelly_weights, 0.02, max_bound)


# ── 2. Hawkes Self-Exciting Process for Institutional Clustering ───────────────
class HawkesOrderflowIntensity:
    """
    Models institutional block orderflow clustering using a Hawkes self-exciting point process:
    lambda(t) = mu_0 + sum_{t_i < t} alpha * exp(-beta * (t - t_i))
    where alpha / beta is the branching ratio representing self-excitation.
    """

    @staticmethod
    def fit_hawkes_intensity(
        volume_series: pd.Series | np.ndarray,
        lookback: int = 30,
        beta: float = 0.8
    ) -> Dict[str, float]:
        """
        Estimates the Hawkes clustering intensity and branching ratio from volume spikes.
        """
        v = np.asarray(volume_series)
        if len(v) < 10:
            return {"hawkes_intensity": 1.0, "branching_ratio": 0.2, "is_clustered": False}

        v_recent = v[-lookback:] if len(v) >= lookback else v
        med_vol = np.median(v_recent)
        std_vol = np.std(v_recent) or 1.0

        # Identify jump arrival times where volume exceeds median + 1.25 std
        spike_indices = np.where(v_recent > (med_vol + 1.25 * std_vol))[0]
        n_spikes = len(spike_indices)

        if n_spikes == 0:
            return {"hawkes_intensity": 0.5, "branching_ratio": 0.1, "is_clustered": False}

        T = len(v_recent)
        t_now = T - 1

        # Calculate decay intensity from past spikes
        decay_sum = np.sum(np.exp(-beta * (t_now - spike_indices)))
        base_intensity = n_spikes / max(T, 1)
        alpha_est = min(0.65, base_intensity * 1.5)
        
        current_intensity = base_intensity + alpha_est * decay_sum
        branching_ratio = alpha_est / beta

        return {
            "hawkes_intensity": float(round(current_intensity, 4)),
            "branching_ratio": float(round(branching_ratio, 4)),
            "is_clustered": bool(branching_ratio > 0.45 or current_intensity > 1.20)
        }


# ── 3. Idzorek Extended Black-Litterman Matrix Blending ────────────────────────
class IdzorekBlackLitterman:
    """
    Bayesian portfolio return shrinkage blending reverse-optimized CAPM equilibrium returns
    with explicit quantitative views (GARP, Growth, Quality) and user confidence matrices.
    mu_BL = [(tau * Sigma)^-1 + P^T * Omega^-1 * P]^-1 * [(tau * Sigma)^-1 * Pi + P^T * Omega^-1 * Q]
    """

    @staticmethod
    def blend_views(
        cov_matrix: np.ndarray,
        market_weights: np.ndarray,
        views_dict: Dict[int, float],
        view_confidences: Dict[int, float] | None = None,
        risk_aversion: float = 2.5,
        tau: float = 0.05
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Blends equilibrium returns with custom profile views.
        """
        N = cov_matrix.shape[0]
        if len(market_weights) != N:
            market_weights = np.ones(N) / N

        # 1. Reverse-optimized equilibrium returns: Pi = delta * Sigma * w_mkt
        Pi = risk_aversion * np.dot(cov_matrix, market_weights)

        if not views_dict:
            return Pi, cov_matrix

        # 2. Pick matrix P and View vector Q
        K = len(views_dict)
        P = np.zeros((K, N))
        Q = np.zeros(K)
        Omega = np.zeros((K, K))

        for row_idx, (asset_idx, view_val) in enumerate(views_dict.items()):
            if 0 <= asset_idx < N:
                P[row_idx, asset_idx] = 1.0
                Q[row_idx] = view_val
                conf = 0.65
                if view_confidences and asset_idx in view_confidences:
                    conf = np.clip(view_confidences[asset_idx], 0.1, 0.95)
                # Idzorek variance proportional to view uncertainty
                var_view = (1.0 - conf) / conf * (cov_matrix[asset_idx, asset_idx] * tau)
                Omega[row_idx, row_idx] = max(var_view, 1e-5)

        # 3. Closed-form Bayesian posterior
        tau_sigma = tau * cov_matrix
        try:
            inv_tau_sigma = np.linalg.pinv(tau_sigma)
            inv_omega = np.linalg.pinv(Omega)

            M = np.linalg.pinv(inv_tau_sigma + np.dot(P.T, np.dot(inv_omega, P)))
            mu_bl = np.dot(M, (np.dot(inv_tau_sigma, Pi) + np.dot(P.T, np.dot(inv_omega, Q))))
            sigma_bl = cov_matrix + M
            return mu_bl, sigma_bl
        except Exception as e:
            logger.warning(f"Black-Litterman inversion warning: {e}, falling back to Pi", exc_info=True)
            return Pi, cov_matrix


# ── 4. Equal Risk Contribution (ERC) Risk Parity Solver ───────────────────────
class EqualRiskContributionSolver:
    """
    Solves for True Risk Parity weights via Cyclical Coordinate Descent where:
    w_i * (Sigma * w)_i = 1/N * w^T * Sigma * w for all assets i.
    """

    @staticmethod
    def solve_erc(
        cov_matrix: np.ndarray,
        max_iter: int = 150,
        tol: float = 1e-6
    ) -> np.ndarray:
        """
        Computes ERC risk parity weight vector.
        """
        N = cov_matrix.shape[0]
        if N <= 1:
            return np.ones(N)

        # Target risk budget: equal risk 1/N
        b = np.ones(N) / N
        w = 1.0 / np.sqrt(np.diag(cov_matrix))
        w = w / np.sum(w)

        for _ in range(max_iter):
            w_prev = w.copy()
            for i in range(N):
                # Sprow: (Sigma * w)_i without asset i
                sigma_i = cov_matrix[i, :]
                a_i = cov_matrix[i, i]
                c_i = np.dot(sigma_i, w) - a_i * w[i]

                total_var = float(np.dot(w.T, np.dot(cov_matrix, w)))
                target_rc = b[i] * total_var

                discriminant = c_i**2 + 4.0 * a_i * target_rc
                if discriminant >= 0:
                    w[i] = (-c_i + np.sqrt(discriminant)) / (2.0 * a_i)
                w[i] = max(w[i], 1e-5)

            w = w / np.sum(w)
            if np.max(np.abs(w - w_prev)) < tol:
                break

        return w


# ── 5. Conditional Value-at-Risk (CVaR 99%) Engine ────────────────────────────
class CVaROptimizer:
    """
    Computes parametric and historical Conditional Value-at-Risk (Expected Shortfall) at 99% confidence.
    Penalizes fat-tailed losses and left-tail market contagion.
    """

    @staticmethod
    def compute_portfolio_cvar(
        weights: np.ndarray,
        returns_history: np.ndarray,
        confidence_level: float = 0.99
    ) -> Tuple[float, float]:
        """
        Calculates VaR and CVaR for the given weight vector.
        """
        w = np.asarray(weights)
        R = np.asarray(returns_history)
        if R.ndim != 2 or len(R) < 10:
            return None, None  # Insufficient data — VaR/CVaR cannot be computed

        port_returns = np.dot(R, w)
        alpha = 1.0 - confidence_level
        var_val = float(np.percentile(port_returns, alpha * 100))
        tail_losses = port_returns[port_returns <= var_val]
        cvar_val = float(np.mean(tail_losses)) if len(tail_losses) > 0 else var_val

        return abs(var_val), abs(cvar_val)


# ── 6. Adaptive Volatility-Scaled (k-ATR & TSRV) Dynamic Target & Stop-Loss ────
class AdaptiveVolatilityRiskEngine:
    """
    Computes asset-specific, mathematically calibrated Target & Stop-Loss levels:
    - Stop-Loss: P_entry - max(1.5 * ATR_14, 2.0 * sigma_TSRV * P_entry)
    - Target: P_entry + 2.5 * (P_entry - Stop-Loss)
    - Risk/Reward Ratio: strictly >= 2.50 : 1
    - Chandelier Ratchet: for a running position, the stop-loss only ever moves up
      (toward the current price) as new highs are made — it never retreats, protecting
      profit already earned without ever giving back the volatility/VAL-VAH-aware sizing
      logic already in place for the initial stop.
    - Time Barrier: a risk-profile-tiered maximum holding horizon to flag dead capital.
    """

    # Tier 5: Market-Regime Conditional Volatility Scaling
    _REGIME_SCALING = {
        "bull_lowvol": {"sl_mult": 0.90, "rr_mult": 1.15, "desc": "Bull Trending (Tight Stop, Expanded Target)"},
        "bull":        {"sl_mult": 1.00, "rr_mult": 1.05, "desc": "Bull Normal"},
        "sideways":    {"sl_mult": 1.10, "rr_mult": 0.95, "desc": "Sideways Consolidation (Mean Reversion)"},
        "neutral":     {"sl_mult": 1.05, "rr_mult": 1.00, "desc": "Neutral Market"},
        "bear":        {"sl_mult": 1.30, "rr_mult": 0.85, "desc": "Bear / High Volatility (Shock Absorber Stop)"},
        "bear_highvol":{"sl_mult": 1.45, "rr_mult": 0.80, "desc": "High Vol Shock (Max Buffer Stop, Deficit Target)"},
    }

    # Risk-profile-tiered maximum holding horizon (days). Aggressive/momentum setups
    # decay faster (thesis usually resolves quickly or doesn't); defensive/compounder
    # setups are given more room, consistent with the existing k_atr/rr_multiplier tiering.
    _TIME_BARRIER_DAYS = {
        "aggressive": 15, "breakout": 15, "max_alpha": 15,
        "defensive": 30, "capital_preservation": 30, "risk_parity": 30,
    }
    _DEFAULT_TIME_BARRIER_DAYS = 20

    @staticmethod
    def calculate_atr_14(highs: np.ndarray, lows: np.ndarray, closes: np.ndarray) -> float:
        """Computes 14-period Average True Range."""
        if len(closes) < 2:
            return float(closes[-1] * 0.03) if len(closes) > 0 else 5.0
        
        tr_list = []
        for i in range(1, len(closes)):
            h = highs[i]
            l = lows[i]
            prev_c = closes[i - 1]
            tr = max(h - l, abs(h - prev_c), abs(l - prev_c))
            tr_list.append(tr)

        if len(tr_list) >= 14:
            return float(np.mean(tr_list[-14:]))
        return float(np.mean(tr_list)) if tr_list else float(closes[-1] * 0.03)

    @classmethod
    def compute_chart_structural_levels(
        cls,
        current_price: float,
        highs: np.ndarray | None = None,
        lows: np.ndarray | None = None,
        closes: np.ndarray | None = None,
        risk_profile: str = "balanced",
        regime: str = "Bull",
    ) -> Dict[str, Any]:
        """
        Computes deterministic, stock-specific Stop-Loss and Target levels derived strictly
        from the stock's actual daily candlestick price action (OHLCV):
        - Stop-Loss: Lowest low of the most recent pullback trough within the last 20 bars
          minus 0.5 * ATR (adaptive for IPOs with <14 bars), bounded within [3.0%, 10.0%].
        - Target: Nearest overhead resistance peak (5-bar local peak) across up to 504 bars (2 years),
          or classical base height measured move if at All-Time Highs.
        - Reward-to-Risk: Computed directly from the resulting chart geometry.
        """
        P = float(current_price)
        if P <= 0:
            P = 100.0

        if highs is None or lows is None or closes is None or len(closes) < 2:
            sl = round(P * 0.95, 2)
            tgt = round(P * 1.15, 2)
            return {
                "entry_price": round(P, 2),
                "stop_loss_price": sl,
                "target_1_price": tgt,
                "snell_target_price": tgt,
                "target_upside_pct": 15.0,
                "target_1_upside_pct": 15.0,
                "stop_loss_pct": 5.0,
                "risk_reward_ratio": "3.00 : 1",
                "atr_14": round(P * 0.03, 2),
                "swing_low": round(P * 0.97, 2),
                "overhead_resistance": tgt,
                "is_ath": False,
                "time_barrier_days": cls._TIME_BARRIER_DAYS.get(risk_profile, cls._DEFAULT_TIME_BARRIER_DAYS),
                "stop_loss_ratcheted": False,
                "target_1_action": "SELL 50% (De-Risk)",
                "runner_strategy": "UNCAPPED (Trailing ATR)",
                "profit_taking_plan": f"Target 1 at ₹{tgt:,.2f} (+15.0%), Stop Loss at ₹{sl:,.2f} (-5.0%)",
            }

        h_arr = np.asarray(highs, dtype=np.float64)
        l_arr = np.asarray(lows, dtype=np.float64)
        c_arr = np.asarray(closes, dtype=np.float64)
        N = len(c_arr)

        # 1. Adaptive ATR & Institutional Base Contraction Analysis
        if N < 14:
            # Stage 1: Brand new IPO (<14 days of data) — Anchor to listing floor
            tr_list = [max(h_arr[i] - l_arr[i], abs(h_arr[i] - c_arr[i - 1]), abs(l_arr[i] - c_arr[i - 1])) for i in range(1, N)]
            atr = float(np.mean(tr_list)) if tr_list else float(P * 0.03)
            l_swing = float(np.min(l_arr))
            base_depth = max(float(np.max(h_arr) - np.min(l_arr)), P * 0.08)
            ema_21 = float(np.mean(c_arr))
        else:
            atr = cls.calculate_atr_14(h_arr, l_arr, c_arr)
            # Scan structural consolidation base over last 15-65 trading days
            base_window = min(65, N)
            h_base = float(np.max(h_arr[-base_window:]))
            l_base = float(np.min(l_arr[-base_window:]))
            base_depth = max(h_base - l_base, P * 0.08)

            # Institutional Handle / Pullback Trough: Scan tight contraction low (last 10-20 bars)
            window = min(20, N)
            recent_lows = l_arr[-window:]
            l_swing = float(np.min(recent_lows))

            # Compute 21-day EMA for institutional trend trailing
            ema_window = min(21, N)
            weights = np.exp(np.linspace(-1., 0., ema_window))
            weights /= weights.sum()
            ema_21 = float(np.dot(c_arr[-ema_window:], weights))

        # 2. Institutional Structural Stop-Loss with anti-hunt buffer
        raw_sl = l_swing - (0.5 * atr)
        min_sl = P * 0.90  # Max 10% risk ceiling (SEBI institutional limit)
        max_sl = P * 0.97  # Min 3% breathing buffer from entry
        stop_loss_px = round(min(max_sl, max(min_sl, raw_sl)), 2)
        risk_pct = round((P - stop_loss_px) / P * 100.0, 2)

        # 3. Two-Tier Institutional Targets & Fractal Resistance Peaks
        hist_len = min(N, 504)
        h_hist = h_arr[-hist_len:]
        
        # Scan for major overhead resistance peaks above entry (peaks > P * 1.025)
        overhead_peaks = []
        if hist_len >= 7:
            for i in range(3, hist_len - 1):
                if h_hist[i] >= np.max(h_hist[max(0, i-3):i]) and h_hist[i] >= np.max(h_hist[i+1:min(hist_len, i+4)]):
                    if h_hist[i] > P * 1.025:
                        overhead_peaks.append(float(h_hist[i]))
        
        # Also check absolute historical maximum in the lookback
        hist_max = float(np.max(h_hist))
        if hist_max > P * 1.025 and hist_max not in overhead_peaks:
            overhead_peaks.append(hist_max)

        is_ath = False
        r_overhead = None

        # Filter peaks that offer a meaningful swing target (>= P * 1.06)
        meaningful_peaks = [p for p in overhead_peaks if p >= P * 1.06]

        if meaningful_peaks:
            r_overhead = min(meaningful_peaks)
            target_1_px = round(r_overhead, 2)
        elif overhead_peaks:
            pivot_level = min(overhead_peaks)
            target_1_px = round(pivot_level + base_depth, 2)
            r_overhead = pivot_level
        else:
            is_ath = True
            target_1_px = round(P + base_depth, 2)

        # Guard: ensure target has at least 5% room
        if target_1_px < P * 1.05:
            target_1_px = round(P + base_depth, 2)

        # Target 2: Fibonacci 1.618x Base Expansion for Multibaggers
        target_2_px = round(P + (1.618 * base_depth), 2)

        # Runner Trail Stop: 21-EMA / Chandelier ATR Ratchet
        runner_trail = round(max(stop_loss_px, min(P, ema_21), P - (2.5 * atr)), 2)

        upside_pct = round((target_1_px - P) / P * 100.0, 2)
        target_2_upside_pct = round((target_2_px - P) / P * 100.0, 2)
        actual_rr = round(upside_pct / max(risk_pct, 0.01), 2)

        # Sizing: Risk exactly 1.0% NAV (₹1,000 per ₹100,000 portfolio equity)
        risk_per_share = max(0.01, P - stop_loss_px)
        shares_per_100k = int(1000.0 / risk_per_share) if risk_per_share > 0 else 1
        pos_weight_pct = round(min(20.0, (1.0 / max(risk_pct, 0.1)) * 100.0), 1)

        return {
            "entry_price": round(P, 2),
            "stop_loss_price": stop_loss_px,
            "target_1_price": target_1_px,
            "target_2_price": target_2_px,
            "snell_target_price": target_1_px,
            "target_upside_pct": upside_pct,
            "target_1_upside_pct": upside_pct,
            "target_2_upside_pct": target_2_upside_pct,
            "stop_loss_pct": risk_pct,
            "risk_reward_ratio": f"{actual_rr:.2f} : 1",
            "atr_14": round(atr, 2),
            "swing_low": round(l_swing, 2),
            "base_depth": round(base_depth, 2),
            "ema_21": round(ema_21, 2),
            "runner_trail_stop": runner_trail,
            "overhead_resistance": round(r_overhead, 2) if r_overhead else None,
            "is_ath": is_ath,
            "time_barrier_days": cls._TIME_BARRIER_DAYS.get(risk_profile, cls._DEFAULT_TIME_BARRIER_DAYS),
            "stop_loss_ratcheted": False,
            "target_1_action": "SELL 50% (De-Risk & Move SL to Cost)",
            "target_2_action": "SELL 25% (Multibagger Milestone)",
            "runner_strategy": "UNCAPPED (Trail 21-Day EMA)",
            "position_sizing_guidance": f"Buy {shares_per_100k} shares / ₹100k NAV ({pos_weight_pct}% weight) for 1.0% risk budget",
            "profit_taking_plan": f"Target 1 at ₹{target_1_px:,.2f} (+{upside_pct}%), Target 2 at ₹{target_2_px:,.2f} (+{target_2_upside_pct}%), Stop Loss at ₹{stop_loss_px:,.2f} (-{risk_pct}%)",
        }

    @classmethod
    def compute_dynamic_levels(
        cls,
        current_price: float,
        highs: np.ndarray | None = None,
        lows: np.ndarray | None = None,
        closes: np.ndarray | None = None,
        atr_val: float | None = None,
        realized_vol_annual: float | None = None,
        risk_profile: str = "balanced",
        regime: str = "Bull",
        val_support: float | None = None,
        vah_resistance: float | None = None,
        previous_stop_loss: float | None = None,
        highest_high_since_entry: float | None = None,
        risk_per_trade_pct: float = 1.0,
        max_position_weight_pct: float = 25.0,
        portfolio_nav_inr: float | None = None,
        overnight_gap_buffer: bool = True,
        opens: np.ndarray | None = None,
    ) -> Dict[str, Any]:
        """
        Computes dynamic, volatility-tailored Entry, Snell Target, Stop Loss, and Risk/Reward
        derived directly from each stock's unique ATR, realized volatility, and chart structure.

        Integrates Tier 5 Regime-Conditional Volatility Scaling, Tier 7 Kelly-Linked Joint Sizing,
        and Merton Jump-Diffusion Overnight Gap Risk Modeling:
          - Tier 5: Scales ATR & target multipliers dynamically based on the detected market regime.
          - Tier 7: Automatically couples stop loss distance to recommended position size so that
            every trade risks an identical constant fraction of total portfolio equity (Default 1.0% NAV).
          - Merton Jump-Diffusion: Computes an empirical overnight gap buffer from opening price jumps,
            ensuring the stop loss is not triggered by normal 9:15 AM opening noise.
        """
        P = float(current_price)
        if P <= 0:
            P = 100.0

        # 1. Calculate stock-specific ATR
        if atr_val is not None and atr_val > 0:
            atr = float(atr_val)
        elif highs is not None and lows is not None and closes is not None and len(closes) >= 5:
            atr = cls.calculate_atr_14(np.asarray(highs), np.asarray(lows), np.asarray(closes))
        else:
            vol_daily = (realized_vol_annual or 0.28) / np.sqrt(252.0)
            atr = P * vol_daily * 1.5

        vol_ann = realized_vol_annual if realized_vol_annual and realized_vol_annual > 0 else (atr / P * np.sqrt(252.0))
        daily_vol_amount = P * (vol_ann / np.sqrt(252.0))

        # 2. Base Stop-Loss Delta calibrated to profile
        if risk_profile in ["aggressive", "breakout", "max_alpha"]:
            base_sl_delta = max(atr * 1.6, daily_vol_amount * 2.0)
            base_rr = 2.65
        elif risk_profile in ["defensive", "capital_preservation", "risk_parity"]:
            base_sl_delta = max(atr * 1.25, daily_vol_amount * 1.6)
            base_rr = 2.40
        else:
            base_sl_delta = max(atr * 1.5, daily_vol_amount * 1.8)
            base_rr = 2.50

        # ── Tier 5: Regime-Conditional Multipliers ─────────────────────────
        reg_key = str(regime).lower().replace(" ", "_")
        reg_cfg = cls._REGIME_SCALING.get(reg_key, cls._REGIME_SCALING.get("bull", {"sl_mult": 1.0, "rr_mult": 1.0, "desc": "Normal"}))
        
        sl_delta = base_sl_delta * reg_cfg["sl_mult"]
        rr_multiplier = base_rr * reg_cfg["rr_mult"]

        # ── Merton Jump-Diffusion Overnight Gap Buffer ─────────────────────
        gap_buffer_amount = 0.0
        if overnight_gap_buffer:
            if opens is not None and closes is not None and len(opens) >= 5 and len(closes) >= 5:
                # Compute empirical log overnight returns ln(Open_t / Close_{t-1})
                min_len = min(len(opens), len(closes))
                gaps = np.abs(np.log(np.maximum(opens[1:min_len], 1e-4) / np.maximum(closes[:min_len-1], 1e-4)))
                gap_sigma = float(np.std(gaps)) if len(gaps) > 0 else (vol_ann / np.sqrt(252.0) * 0.35)
                gap_buffer_amount = P * min(0.025, max(0.003, gap_sigma * 1.28))
            else:
                gap_buffer_amount = P * (vol_ann / np.sqrt(252.0) * 0.25)
            
            # Incorporate overnight jump buffer into stop loss delta
            sl_delta = sl_delta + gap_buffer_amount

        # If Value Area Low (VAL) or structural base support is present, anchor stop below support with anti-hunt buffer
        if val_support is not None and val_support > 0 and val_support < P:
            chart_sl = val_support - (atr * 0.25)
            # Bound risk distance to sensible technical limits [1.0*ATR, max_risk]
            min_sl_dist = max(atr * 1.0, P * 0.02)
            max_sl_dist = max(atr * 3.5, P * 0.16)
            effective_sl = min(P - min_sl_dist, max(P - max_sl_dist, chart_sl))
            stop_loss_px = round(effective_sl, 2)
        else:
            stop_loss_px = round(P - sl_delta, 2)

        # 2b. Chandelier ratchet for a running position
        ratcheted = False
        if previous_stop_loss is not None and previous_stop_loss > 0:
            anchor_high = highest_high_since_entry if (highest_high_since_entry and highest_high_since_entry > P) else P
            if val_support is not None and val_support > 0 and val_support < anchor_high:
                chandelier_sl = round(min(anchor_high - sl_delta, val_support - (atr * 0.25)), 2)
            else:
                chandelier_sl = round(anchor_high - sl_delta, 2)
            stop_loss_px = max(stop_loss_px, chandelier_sl, round(float(previous_stop_loss), 2))
            ratcheted = True

        # 3. Dynamic Profit Target anchored to chart resistance or Fibonacci extension
        if vah_resistance is not None and vah_resistance > P:
            target_px = round(max(P + (sl_delta * rr_multiplier), vah_resistance + (atr * 0.5)), 2)
        else:
            target_delta = round(sl_delta * rr_multiplier, 2)
            target_px = round(P + target_delta, 2)

        upside_pct = round((target_px - P) / P * 100.0, 2)
        risk_pct = round((P - stop_loss_px) / P * 100.0, 2)
        actual_rr = round(upside_pct / max(risk_pct, 0.01), 2)

        # ── Tier 7: Kelly-Linked Sizing & Fixed-Risk Parity ───────────────
        # Formula: w_i = min(w_max, TargetRisk% / StopLoss%)
        eff_risk_pct = max(risk_pct, 0.5)
        raw_kelly_weight = (risk_per_trade_pct / eff_risk_pct) * 100.0
        kelly_position_weight_pct = round(min(max_position_weight_pct, raw_kelly_weight), 2)

        implied_alloc_inr = None
        implied_risk_inr = None
        if portfolio_nav_inr and portfolio_nav_inr > 0:
            implied_alloc_inr = round(portfolio_nav_inr * (kelly_position_weight_pct / 100.0), 2)
            implied_risk_inr = round(implied_alloc_inr * (risk_pct / 100.0), 2)

        runner_trail_stop = round(max(P - (atr * 2.5), stop_loss_px), 2)
        breakeven_stop = round(P, 2)
        profit_plan = f"Book 50% at Target 1 (₹{target_px:,.2f} / +{upside_pct}%), move stop to Cost (₹{P:,.2f}), trail 50% runner uncapped via Chandelier ATR (₹{runner_trail_stop:,.2f})"

        return {
            "entry_price": round(P, 2),
            "snell_target_price": target_px,
            "target_1_price": target_px,
            "target_1_upside_pct": upside_pct,
            "target_1_action": "SELL 50% (De-Risk)",
            "runner_strategy": "UNCAPPED (Trailing ATR)",
            "breakeven_stop_loss": breakeven_stop,
            "runner_trailing_stop": runner_trail_stop,
            "profit_taking_plan": profit_plan,
            "stop_loss_price": stop_loss_px,
            "stop_loss_ratcheted": ratcheted,
            "target_upside_pct": upside_pct,
            "stop_loss_pct": risk_pct,
            "risk_reward_ratio": f"{actual_rr:.2f} : 1",
            "atr_14": round(atr, 2),
            "realized_vol_annual": round(vol_ann * 100.0, 1),
            "time_barrier_days": cls._TIME_BARRIER_DAYS.get(risk_profile, cls._DEFAULT_TIME_BARRIER_DAYS),
            "regime_applied": reg_cfg["desc"],
            "regime_sl_multiplier": reg_cfg["sl_mult"],
            "overnight_gap_buffer_pct": round(gap_buffer_amount / P * 100.0, 2),
            "merton_jump_adjusted": overnight_gap_buffer,
            "kelly_position_weight_pct": kelly_position_weight_pct,
            "risk_per_trade_pct": risk_per_trade_pct,
            "implied_allocation_inr": implied_alloc_inr,
            "implied_risk_inr": implied_risk_inr,
        }


