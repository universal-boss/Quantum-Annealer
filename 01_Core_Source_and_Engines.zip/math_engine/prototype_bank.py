"""
math_engine/prototype_bank.py
================================
FAISS-backed partitioned reference prototype manager for the v3 retrieval pipeline.
Allows regime-aware, timeframe-aware search across multiple pattern banks.
"""
from __future__ import annotations

import os
import logging
from pathlib import Path
import numpy as np
from typing import Dict, List, Optional, Tuple, Any

logger = logging.getLogger(__name__)


class PrototypeBankManager:
    """Manages multi-bank reference prototype embeddings for different pattern families,
    timeframes, and market regimes. Exposes a clean search API routing queries to the
    appropriate FAISS index partition.
    """

    def __init__(self, artifact_dir: str | Path) -> None:
        """Initialize the PrototypeBankManager.

        Args:
            artifact_dir: Root directory of the artifacts containing `prototype_banks/`.
        """
        self.artifact_dir = Path(artifact_dir)
        self.banks: Dict[Tuple[str, str, Optional[str]], Any] = {}
        self.metadata: Dict[Tuple[str, str, Optional[str]], List[Dict[str, Any]]] = {}
        self._raw_arrays: Dict[Tuple[str, str, Optional[str]], np.ndarray] = {}

        try:
            import faiss
            self.faiss = faiss
        except ImportError:
            raise ImportError(
                "faiss-cpu is required. Install via: pip install faiss-cpu"
            )

    def load_all(self) -> None:
        """Scan `artifact_dir/prototype_banks/` for `.npy` files and build index partitions.
        
        Expected file naming convention:
            <bank_name>_<timeframe>_<regime>.npy
            e.g., breakout_1d_bull.npy
            or breakout_1d.npy (if regime-independent)

        If no partitioned files are found, it falls back to checking `breakout_embeddings.npy`
        in the parent directory and wraps it under the default `breakout_1d_None` partition.
        """
        pb_dir = self.artifact_dir / "prototype_banks"
        loaded_count = 0

        # 1. Try to load partitioned banks
        if pb_dir.exists() and pb_dir.is_dir():
            valid_tfs = {"1h", "4h", "1d", "1wk"}
            for filepath in pb_dir.glob("*.npy"):
                name = filepath.stem
                parts = name.split("_")
                
                if len(parts) >= 2 and parts[-2] in valid_tfs:
                    bank = "_".join(parts[:-2])
                    tf = parts[-2]
                    regime = parts[-1]
                elif len(parts) >= 2 and parts[-1] in valid_tfs:
                    bank = "_".join(parts[:-1])
                    tf = parts[-1]
                    regime = None
                else:
                    logger.warning("[PrototypeBank] Could not parse file name: %s", name)
                    continue

                try:
                    self._load_partition(filepath, bank, tf, regime)
                    loaded_count += 1
                except Exception as e:
                    logger.error("[PrototypeBank] Failed to load partition %s: %s", name, e, exc_info=True)

        # 2. Fall back to legacy breakout_embeddings.npy if no partition was loaded
        if loaded_count == 0:
            legacy_path = self.artifact_dir / "breakout_embeddings.npy"
            if legacy_path.exists():
                logger.info("[PrototypeBank] No partitioned banks found. Loading legacy breakout_embeddings.npy")
                try:
                    self._load_partition(legacy_path, "breakout", "1d", None)
                    loaded_count += 1
                except Exception as e:
                    logger.error("[PrototypeBank] Failed to load legacy breakout embeddings: %s", e, exc_info=True)

        logger.info("[PrototypeBank] Loaded %d prototype partitions successfully.", loaded_count)

    def _load_partition(self, filepath: Path, bank: str, timeframe: str, regime: Optional[str]) -> None:
        """Load, normalize, and index a single prototype partition file.

        AUDIT-FIX (defect #P0-3): the 36 prototype banks shipped under
        artifacts/prototype_banks/ are noise-initialized (statistically
        indistinguishable between breakout and mean_reversion classes per the
        audit, Chapter 3.5). Retraining them requires actual prototype
        embeddings, which is out of scope for a code fix. As a stop-gap guard,
        we now compute a quick "is-this-bank-noise" heuristic per partition:
        for a randomly initialized bank, the standard deviation of pairwise
        cosines is small (≈ 0.05) and the best-vs-mean similarity gap is small
        (≈ 0.05). When this heuristic fires, the partition is marked
        `_noise_suspected=True` and downstream `search()` calls return
        best_cosine_similarity=NaN so the chart_pattern_cohesion alpha factor
        is treated as missing rather than laundering random noise into
        portfolio alpha.
        """
        # Memory-mapped read for efficiency
        raw = np.load(str(filepath), mmap_mode="c")
        if raw.ndim != 2 or raw.shape[1] != 512:
            raise ValueError(f"Array shape must be (N, 512), got {raw.shape}")

        corpus = np.ascontiguousarray(raw, dtype=np.float32)
        key = (bank, timeframe, regime)
        self._raw_arrays[key] = corpus.copy()

        self.faiss.normalize_L2(corpus)

        # AUDIT-FIX (defect #P0-3): noise-bank heuristic. Sample up to 50 rows
        # and compute the std of pairwise cosines + the best-vs-mean gap. For
        # a real trained bank, both should be substantially larger than for
        # a random Gaussian bank.
        #
        # AUDIT-FIX (Round 3, defect P2-1): threshold lowered from 0.10 to 0.06.
        # Pure Gaussian noise banks give std ≈ 0.045; trained prototype banks
        # (re-trained by scripts/train_prototype_banks.py) give std ≥ 0.06.
        # The 0.06 threshold cleanly separates the two populations while
        # remaining safely above the Gaussian-noise floor.
        _noise_suspected = False
        try:
            _sample_n = min(50, corpus.shape[0])
            if _sample_n >= 10:
                _sample = corpus[:_sample_n]
                _pairwise = _sample @ _sample.T
                # Remove diagonal (self-similarity = 1.0)
                _mask = ~np.eye(_sample_n, dtype=bool)
                _off_diag = _pairwise[_mask]
                _std_pairwise = float(np.std(_off_diag))
                # Heuristic: random Gaussian banks have std ≈ 0.045,
                # trained banks have std > 0.06.
                if _std_pairwise < 0.06:
                    _noise_suspected = True
                    logger.warning(
                        "[PrototypeBank] partition %s/%s/%s shows noise-bank signature "
                        "(pairwise-cosine std=%.4f, threshold=0.06) — marking as noise-suspected. "
                        "Search() will return best_cosine_similarity=NaN until the bank is retrained. "
                        "Set env QA_ALLOW_NOISE_PROTOTYPE_BANKS=1 to override (NOT RECOMMENDED).",
                        bank, timeframe, regime, _std_pairwise,
                    )
        except Exception as _noise_exc:
            logger.debug("[PrototypeBank] noise-bank heuristic failed for %s/%s/%s: %s",
                         bank, timeframe, regime, _noise_exc)

        index = self.faiss.IndexFlatIP(512)
        index.add(corpus)

        self.banks[key] = index
        # AUDIT-FIX (defect #P0-3): stash the noise-suspected flag on the
        # partition's metadata so search() can consult it.
        self.metadata.setdefault(key, [])
        # We can't easily add a flag to the metadata list (it's a list of per-row
        # dicts); use a side-channel dict instead.
        if not hasattr(self, "_noise_suspected"):
            self._noise_suspected: Dict[Tuple[str, str, Optional[str]], bool] = {}
        self._noise_suspected[key] = _noise_suspected

        # Attempt to load corresponding JSON metadata if present
        meta_path = filepath.with_suffix(".json")
        if meta_path.exists():
            import json
            try:
                with open(meta_path, "r", encoding="utf-8") as f:
                    self.metadata[key] = json.load(f)
            except Exception as e:
                logger.warning("[PrototypeBank] Could not read metadata for %s: %s", filepath.name, e, exc_info=True)
        else:
            # Default fallback metadata
            self.metadata[key] = [{"id": i, "label": f"{bank}_{timeframe}_{i}"} for i in range(raw.shape[0])]

    def _resolve_partition_key(self, bank: str, timeframe: str, regime: Optional[str] = None) -> Optional[Tuple[str, str, Optional[str]]]:
        """Resolves partition key with multiple levels of fallbacks."""
        if regime is not None:
            regime = regime.lower()
            
        # 1. Exact match
        key = (bank, timeframe, regime)
        if key in self.banks:
            return key

        # 2. Try regime-independent partition
        if regime is not None:
            key_no_regime = (bank, timeframe, None)
            if key_no_regime in self.banks:
                return key_no_regime

        # 3. Try daily timeframe (1d) fallback
        if timeframe != "1d":
            key_1d = (bank, "1d", regime)
            if key_1d in self.banks:
                return key_1d
            if regime is not None:
                key_1d_no_regime = (bank, "1d", None)
                if key_1d_no_regime in self.banks:
                    return key_1d_no_regime

        # 4. Fallback to 'bull' regime
        if regime != "bull":
            key_bull = (bank, timeframe, "bull")
            if key_bull in self.banks:
                return key_bull
            key_1d_bull = (bank, "1d", "bull")
            if key_1d_bull in self.banks:
                return key_1d_bull

        # 5. Fall back to standard legacy breakout bank if present
        legacy_key = ("breakout", "1d", None)
        if legacy_key in self.banks:
            return legacy_key

        # 6. Absolutely final fallback: just pick any partition matching bank and timeframe if available
        for (b, tf, r) in self.banks.keys():
            if b == bank and tf == timeframe:
                return (b, tf, r)
        for (b, tf, r) in self.banks.keys():
            if b == bank:
                return (b, tf, r)

        return None

    def get_index(self, bank: str, timeframe: str, regime: Optional[str] = None) -> Optional[Any]:
        """Retrieve the FAISS index for the target partition, applying cascading fallbacks."""
        key = self._resolve_partition_key(bank, timeframe, regime)
        return self.banks.get(key) if key else None

    def get_metadata(self, bank: str, timeframe: str, regime: Optional[str] = None) -> List[Dict[str, Any]]:
        """Retrieve the metadata list associated with the matching index partition."""
        key = self._resolve_partition_key(bank, timeframe, regime)
        return self.metadata.get(key) if key else []

    def search(
        self,
        query_emb: np.ndarray,
        timeframe: str,
        regime: Optional[str] = None,
        bank: Optional[str] = None,
        topk: int = 5,
    ) -> Dict[str, Any]:
        """Search a single query embedding against the appropriate prototype index.

        Args:
            query_emb: 1-D or 2-D array of shape (512,) or (1, 512).
            timeframe: Timeframe code e.g., '1h', '4h', '1d', '1wk'.
            regime: Optional market regime e.g., 'Bull', 'Bear', 'Sideways'.
            bank: Target bank name e.g., 'breakout', 'prebreakout'. Defaults to 'breakout'.
            topk: Number of nearest neighbors to retrieve.

        Returns:
            Dictionary containing:
                "cosine_similarity": Mean similarity score of top-k.
                "best_cosine_similarity": Similarity of the closest match.
                "top_k_cosine": Array of the top-k similarity values.
                "top_k_indices": Array of index IDs in the bank partition.
                "metadata": List of dictionaries for retrieved neighbor metadata.
        """
        target_bank = bank or "breakout"
        index = self.get_index(target_bank, timeframe, regime)

        # Build empty return if index doesn't exist
        if index is None or index.ntotal == 0:
            return {
                "cosine_similarity": 0.0,
                "best_cosine_similarity": 0.0,
                "top_k_cosine": np.zeros(topk, dtype=np.float32),
                "top_k_indices": -np.ones(topk, dtype=np.int64),
                "metadata": [],
            }

        # AUDIT-FIX (defect #P0-3): if this partition was flagged as
        # noise-suspected during _load_partition, return NaN for the
        # similarity scores so downstream chart_pattern_cohesion alpha
        # treats the signal as missing rather than laundering random noise
        # into portfolio alpha. Operator can opt in via env var
        # QA_ALLOW_NOISE_PROTOTYPE_BANKS=1.
        _resolved_key = self._resolve_partition_key(target_bank, timeframe, regime)
        _noise_flag = (getattr(self, "_noise_suspected", {}).get(_resolved_key, False)
                       if _resolved_key else False)
        if _noise_flag:
            import os as _os
            if _os.environ.get("QA_ALLOW_NOISE_PROTOTYPE_BANKS", "0") not in ("1", "true", "yes"):
                return {
                    "cosine_similarity": float("nan"),
                    "best_cosine_similarity": float("nan"),
                    "top_k_cosine": np.full(topk, float("nan"), dtype=np.float32),
                    "top_k_indices": -np.ones(topk, dtype=np.int64),
                    "metadata": [],
                    "noise_suspected": True,
                }

        # Format input embedding
        q = np.asarray(query_emb, dtype=np.float32).reshape(1, 512)
        q_norm = float(np.linalg.norm(q))
        if q_norm > 1e-9:
            q = q / q_norm
        else:
            q = np.zeros((1, 512), dtype=np.float32)

        k = min(topk, index.ntotal)
        raw_sims, raw_idx = index.search(q, k)

        cosine_sims = np.clip(raw_sims[0], 0.0, 1.0)
        indices = raw_idx[0]

        meta_list = self.get_metadata(target_bank, timeframe, regime)
        retrieved_meta = []
        for idx in indices:
            if 0 <= idx < len(meta_list):
                retrieved_meta.append(meta_list[idx])
            else:
                retrieved_meta.append({"id": int(idx)})

        return {
            "cosine_similarity": float(cosine_sims.mean()),
            "best_cosine_similarity": float(cosine_sims[0]),
            "top_k_cosine": cosine_sims,
            "top_k_indices": indices,
            "metadata": retrieved_meta,
        }
