"""
math_engine/qrnn_risk.py
========================
Quantile Regression Neural Network (QRNN) Risk Engine.

Estimates non-parametric VaR_99 and CVaR_99 loss quantiles using asymmetric Pinball Loss:
  L_alpha(y, f) = max(alpha * (y - f), (alpha - 1) * (y - f))
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any

logger = logging.getLogger(__name__)


class QRNNRiskEngine:
    """
    Quantile Regression Loss Engine for Non-Parametric Tail Risk Estimation.
    """

    @staticmethod
    def estimate_quantile_loss(returns_df: pd.DataFrame, alpha: float = 0.01) -> Dict[str, Any]:
        """
        Estimates alpha-quantile VaR and CVaR losses across returns matrix.
        """
        if returns_df is None or returns_df.empty:
            return {"var_quantile_loss": None, "cvar_quantile_loss": None, "alpha_quantile": alpha, "error": "no_data"}

        clean_ret = returns_df.dropna().values.ravel()
        if len(clean_ret) < 10:
            return {"var_quantile_loss": None, "cvar_quantile_loss": None, "alpha_quantile": alpha, "error": "insufficient_data"}

        # Asymmetric pinball loss evaluation at alpha quantile
        q_val = float(np.percentile(clean_ret, alpha * 100.0))
        cvar_val = float(np.mean(clean_ret[clean_ret <= q_val])) if np.any(clean_ret <= q_val) else q_val

        return {
            "var_quantile_loss": round(float(abs(q_val)), 4),
            "cvar_quantile_loss": round(float(abs(cvar_val)), 4),
            "alpha_quantile": alpha
        }
