"""Real-time risk monitoring — live VaR, drawdown alerts, drift detection.

Streams risk metrics during market hours:
  1. Live VaR (recomputed every 5 minutes)
  2. Drawdown alerts (Telegram alert if DD > threshold)
  3. Model drift detection (PSI, KS test, IC decay)
  4. Automatic refit trigger (when drift exceeds threshold)
"""
from __future__ import annotations

import time
import logging
from typing import Callable, Optional
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class RiskAlert:
    """Risk alert event."""
    timestamp: datetime
    alert_type: str  # "var_breach", "drawdown", "drift", "refit"
    severity: str    # "info", "warning", "critical"
    message: str
    value: float = 0.0
    threshold: float = 0.0


class RealTimeRiskMonitor:
    """Real-time risk monitoring with alerts.

    Runs in a background thread, computing risk metrics every `interval_sec`
    and emitting alerts when thresholds are breached.
    """

    def __init__(
        self,
        weights: dict[str, float],
        var_threshold: float = 0.05,      # 5% daily VaR
        dd_threshold: float = 0.08,        # 8% drawdown alert
        dd_critical: float = 0.15,         # 15% critical drawdown
        interval_sec: int = 300,           # 5 minutes
        callback: Optional[Callable[[RiskAlert], None]] = None,
    ):
        self.weights = weights
        self.var_threshold = var_threshold
        self.dd_threshold = dd_threshold
        self.dd_critical = dd_critical
        self.interval_sec = interval_sec
        self.callback = callback

        self._running = False
        self._thread = None
        self._alerts: list[RiskAlert] = []
        self._peak_value = 1.0
        self._current_value = 1.0
        self._returns_history: list[float] = []  # FIX C5: was never initialized → VaR check was dead code
        # AUDIT-FIX (Round 48 — R48-3): interruptible stop signal. The old
        # loop slept `interval_sec` (default 300 s) in ONE solid time.sleep,
        # so stop()'s join(timeout=5) could never succeed mid-interval:
        # "Stopped" was logged while the thread kept running, and worse, a
        # stop() -> start() cycle flipped the shared _running bool back to
        # True, so the OLD thread never exited — leaving TWO monitor threads
        # emitting duplicate drawdown/VaR alerts and double-appending to the
        # returns history. A per-generation threading.Event makes the wait
        # interruptible (stop takes effect within 0.25 s) and lets the old
        # generation die even if a new one starts immediately.
        import threading as _threading_mod
        self._stop_event = _threading_mod.Event()

    def start(self):
        """Start the risk monitor in a background thread."""
        import threading
        if self._thread is not None and self._thread.is_alive():
            logger.warning("[RiskMonitor] start() ignored — a monitor thread is already running (call stop() first)")
            return
        self._stop_event = threading.Event()  # fresh generation signal
        self._running = True
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        logger.info("[RiskMonitor] Started — interval=%ds, VaR thresh=%.1f%%, DD thresh=%.1f%%",
                    self.interval_sec, self.var_threshold * 100, self.dd_threshold * 100)

    def stop(self):
        """Stop the risk monitor (takes effect within ~0.25 s, not after the full interval)."""
        self._running = False
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=5)
            if self._thread.is_alive():
                logger.warning("[RiskMonitor] Monitor thread did not stop within 5s (a check may be in progress)")
                return
        logger.info("[RiskMonitor] Stopped")

    def _run(self):
        """Main monitoring loop (interruptible wait — see R48-3)."""
        while self._running and not self._stop_event.is_set():
            try:
                self._check_risk()
            except Exception as e:
                logger.warning(f"[RiskMonitor] Check failed: {e}", exc_info=True)
            # R48-3: interruptible wait — returns immediately when the stop
            # event fires instead of blocking the full interval.
            self._stop_event.wait(timeout=self.interval_sec)

    def _check_risk(self):
        """Compute current risk metrics and emit alerts.
        FIX GAP 8.1: Was a stub. Now checks drawdown + VaR.
        """
        if self._current_value <= 0:
            return
        drawdown = (self._peak_value - self._current_value) / max(self._peak_value, 1e-9)
        if drawdown >= self.dd_critical:
            self._emit_alert(RiskAlert(
                timestamp=datetime.now(), alert_type="drawdown", severity="critical",
                message=f"Critical drawdown: {drawdown:.2%}", value=drawdown, threshold=self.dd_critical))
        elif drawdown >= self.dd_threshold:  # FIX C4: was self.dd_warning (undefined) → AttributeError
            self._emit_alert(RiskAlert(
                timestamp=datetime.now(), alert_type="drawdown", severity="warning",
                message=f"Drawdown warning: {drawdown:.2%}", value=drawdown, threshold=self.dd_threshold))  # FIX C4
        if hasattr(self, '_returns_history') and self._returns_history and len(self._returns_history) > 20:
            import numpy as np
            _var_window = int(getattr(self, 'var_window', 252))  # dynamic: default 252, configurable
            returns = np.array(self._returns_history[-_var_window:])
            var_95 = float(np.percentile(returns, 5))
            # ROUND 45 FIX: var_95 is SIGNED (5th percentile of returns). A
            # breach is a LOSS beyond the threshold: var_95 <= -var_threshold.
            # The old `abs(var_95) >= var_threshold` fired on all-POSITIVE
            # windows too — a +10%-every-day portfolio raised a critical
            # "VaR 95% breach" alert.
            if var_95 <= -self.var_threshold:
                self._emit_alert(RiskAlert(
                    timestamp=datetime.now(), alert_type="var", severity="critical",
                    message=f"VaR 95% breach: {var_95:.2%}", value=var_95, threshold=-self.var_threshold))
        logger.debug(f"[RiskMonitor] Check complete — DD={drawdown:.2%}")

    def update_portfolio_value(self, value: float):
        """Update current portfolio value (called externally with live P&L)."""
        # FIX C5: Record return for VaR calculation
        if self._current_value > 0:
            _ret = (value - self._current_value) / self._current_value
            self._returns_history.append(_ret)
            if len(self._returns_history) > 504:  # keep last 2 years
                self._returns_history = self._returns_history[-504:]
        self._current_value = value
        if value > self._peak_value:
            self._peak_value = value

        # Check drawdown
        drawdown = (self._peak_value - value) / self._peak_value
        if drawdown >= self.dd_critical:
            self._emit_alert(RiskAlert(
                timestamp=datetime.now(),
                alert_type="drawdown",
                severity="critical",
                message=f"Critical drawdown: {drawdown:.2%}",
                value=drawdown,
                threshold=self.dd_critical,
            ))
        elif drawdown >= self.dd_threshold:
            self._emit_alert(RiskAlert(
                timestamp=datetime.now(),
                alert_type="drawdown",
                severity="warning",
                message=f"Drawdown alert: {drawdown:.2%}",
                value=drawdown,
                threshold=self.dd_threshold,
            ))

    def check_var(self, portfolio_returns: np.ndarray):
        """Check if VaR exceeds threshold."""
        if len(portfolio_returns) < 30:
            return

        var_95 = float(np.percentile(portfolio_returns, 5))
        # ROUND 45 FIX: signed comparison — see _check_risk. abs() turned a
        # positive 5th-percentile (no downside at all) into a breach.
        if var_95 < -self.var_threshold:
            self._emit_alert(RiskAlert(
                timestamp=datetime.now(),
                alert_type="var_breach",
                severity="critical" if var_95 < -2 * self.var_threshold else "warning",
                message=f"VaR breach: {var_95:.2%} (threshold: -{self.var_threshold:.2%})",
                value=abs(var_95),
                threshold=self.var_threshold,
            ))

    def _emit_alert(self, alert: RiskAlert):
        """Emit a risk alert."""
        self._alerts.append(alert)
        logger.warning(f"[RiskMonitor] {alert.severity.upper()}: {alert.message}")
        if self.callback:
            try:
                self.callback(alert)
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                pass

    @property
    def alerts(self) -> list[RiskAlert]:
        """Get all alerts."""
        return self._alerts.copy()

    def clear_alerts(self):
        """Clear alert history."""
        self._alerts.clear()


# ═══════════════════════════════════════════════════════════════════════════════
# MODEL DRIFT DETECTION
# ═══════════════════════════════════════════════════════════════════════════════

def population_stability_index(
    expected: np.ndarray,
    actual: np.ndarray,
    bins: int = 10,
) -> float:
    """Compute Population Stability Index (PSI).

    PSI measures how much a distribution has shifted.
      PSI < 0.1  = no significant shift
      PSI 0.1-0.25 = moderate shift
      PSI > 0.25 = significant shift (model needs refitting)

    Args:
        expected: Reference distribution (training data).
        actual: Current distribution.
        bins: Number of bins for histogram.

    Returns:
        PSI value.
    """
    if expected is None or actual is None or len(expected) == 0 or len(actual) == 0:
        return 0.0
    min_exp, max_exp = np.min(expected), np.max(expected)
    if min_exp == max_exp:
        return 0.0

    # Bin the expected distribution
    breakpoints = np.linspace(min_exp, max_exp, bins + 1)

    # ROUND 45 FIX: np.histogram DROPS values outside [breakpoints[0], breakpoints[-1]]
    # — i.e. actual observations beyond the expected range were silently
    # discarded, biasing PSI DOWN exactly when drift matters (verified: a
    # 1.5-sigma shift lost ~9.5% of the actual mass and understated PSI ~18%,
    # missing the 0.25 refit trigger at the margin). Canonical treatment:
    # clip actuals into the expected range so out-of-range mass lands in the
    # edge bins.
    expected_arr = np.asarray(expected, dtype=float)
    actual_arr = np.clip(np.asarray(actual, dtype=float), min_exp, max_exp)

    expected_pct = np.histogram(expected_arr, breakpoints)[0] / len(expected_arr)
    actual_pct = np.histogram(actual_arr, breakpoints)[0] / max(len(actual_arr), 1)

    # Avoid division by zero
    expected_pct = np.clip(expected_pct, 0.001, None)
    actual_pct = np.clip(actual_pct, 0.001, None)

    psi = np.sum((actual_pct - expected_pct) * np.log(actual_pct / expected_pct))
    return float(psi)


def kolmogorov_smirnov_test(
    sample1: np.ndarray,
    sample2: np.ndarray,
) -> float:
    """Compute Kolmogorov-Smirnov statistic.

    Measures the maximum distance between two CDFs.
    KS > 0.1 typically indicates significant distribution change.
    """
    try:
        from scipy.stats import ks_2samp
        stat, _ = ks_2samp(sample1, sample2)
        return float(stat)
    except ImportError:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
        return 0.0


def ic_decay_check(
    historical_ics: list[float],
    recent_window: int = 20,
    threshold: float = 0.5,
) -> tuple[bool, float]:
    """Check if Information Coefficient has decayed.

    Compares recent IC (last `recent_window` observations) to historical average.
    If recent IC < threshold × historical IC, signal decay.

    Args:
        historical_ics: List of historical IC values.
        recent_window: Number of recent observations to compare.
        threshold: Decay threshold (recent/historical ratio).

    Returns:
        (has_decayed, decay_ratio)
    """
    if len(historical_ics) < recent_window * 2:
        return False, 1.0

    historical_avg = np.mean(historical_ics[:-recent_window])
    recent_avg = np.mean(historical_ics[-recent_window:])

    if abs(historical_avg) < 1e-9:
        return False, 1.0

    decay_ratio = abs(recent_avg) / abs(historical_avg)
    has_decayed = decay_ratio < threshold

    return has_decayed, float(decay_ratio)


def should_refit_model(
    training_features: np.ndarray,
    current_features: np.ndarray,
    historical_ics: list[float],
    psi_threshold: float = 0.25,
    ks_threshold: float = 0.15,
    ic_decay_threshold: float = 0.5,
) -> tuple[bool, dict]:
    """Determine if the ML model should be refitted.

    Checks three drift indicators:
      1. PSI > 0.25 (feature distribution shift)
      2. KS > 0.15 (label distribution shift)
      3. IC decay > 50% (predictive power loss)

    If any indicator breaches threshold, recommend refit.

    Args:
        training_features: Features from training period.
        current_features: Features from recent period.
        historical_ics: Historical IC values.
        psi_threshold: PSI refit threshold.
        ks_threshold: KS refit threshold.
        ic_decay_threshold: IC decay refit threshold.

    Returns:
        (should_refit, drift_metrics)
    """
    # Compute PSI for each feature, take max
    n_features = training_features.shape[1]
    psi_values = []
    for i in range(n_features):
        try:
            psi = population_stability_index(
                training_features[:, i],
                current_features[:, i]
            )
            psi_values.append(psi)
        except Exception:
            import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
            continue

    max_psi = max(psi_values) if psi_values else 0.0
    avg_psi = np.mean(psi_values) if psi_values else 0.0

    # KS test on first feature (representative)
    try:
        ks_stat = kolmogorov_smirnov_test(
            training_features[:, 0],
            current_features[:, 0]
        )
    except Exception:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
        ks_stat = 0.0

    # IC decay
    ic_decayed, ic_ratio = ic_decay_check(historical_ics, threshold=ic_decay_threshold)

    # Decision
    should_refit = (
        max_psi > psi_threshold or
        ks_stat > ks_threshold or
        ic_decayed
    )

    metrics = {
        "max_psi": max_psi,
        "avg_psi": avg_psi,
        "ks_statistic": ks_stat,
        "ic_decay_ratio": ic_ratio,
        "ic_decayed": ic_decayed,
        "should_refit": should_refit,
    }

    if should_refit:
        logger.warning(f"[DriftDetection] Model refit recommended: {metrics}")

    return should_refit, metrics
