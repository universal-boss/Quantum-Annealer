"""
math_engine/regime_detector.py
===============================
Institutional-grade 3-state Regime-Switching GARCH (RS-GARCH) market regime detector.
Utilizes the Gray (1996) formulation, Hamilton filter, Student-t conditional densities,
and Kullback-Leibler (KL) divergence staleness verification.
"""
from __future__ import annotations

import logging
import json
from pathlib import Path
from typing import Dict, Optional
from datetime import datetime, timezone

import numpy as np
import pandas as pd
from numpy.typing import NDArray
from scipy.optimize import minimize
from scipy.special import gammaln

# ROUND-44 FIX (circular import): this used to be a module-level
# `from data.price_feed import safe_download`. data.price_feed imports
# utils at module level, and utils imports math_engine.indicators
# part-way through ITS module body — so when the import chain entered
# utils first, math_engine/__init__ ran while utils was partially
# initialized, and this module's import chain raised
# "cannot import name '_ACTIVE_STOP_EVENT' from partially initialized
# module 'utils'" — silently degrading the MarketRegimeDetector /
# RegimeDetector exports to None for the whole process (proven by
# importing web_dashboard.app before math_engine). The only use of
# safe_download is inside the macro-overlay branch of detect(), so the
# import is deferred to call time.

logger = logging.getLogger(__name__)


class MarketRegimeDetector:
    """Institutional-grade 3-state Gray-type RS-GARCH(1,1) market regime classifier.

    Mathematical Rationale:
        Instead of a separate volatility estimation and HMM step, this model collapses
        regime switching and volatility dynamics into a single unified framework:

            h_{t,k} = ω_k + α_k · ε_{t-1}² + β_k · h_{t-1}   for regime k ∈ {0, 1, 2}

        where:
            ε_{t-1} = r_{t-1} - E_{t-1}[r_{t-1}]
            h_{t-1} = E_{t-1}[h_{t-1,j} + μ_j²] - (E_{t-1}[r_{t-1}])² (Gray's aggregation)

        Conditional return densities are modeled using Student-t distribution to capture
        the heavy fat-tails of emerging markets (NSE).

        Regimes are sorted by conditional return expectation:
            Regime 0 = Bear     (lowest mean return, highest variance)
            Regime 1 = Sideways (moderate return, moderate variance)
            Regime 2 = Bull     (highest mean return, lowest variance)
    """

    _STATE_LABELS: Dict[int, str] = {0: "Bear", 1: "Sideways", 2: "Bull"}
    _N_STATES: int = 3

    def __init__(
        self,
        n_iter: int = 500,
        tol: float = 1e-4,
        random_state: int = 42,
    ) -> None:
        self._n_iter = n_iter
        self._tol = tol
        self._random_state = random_state
        
        # Model parameters
        self._P_mat: Optional[NDArray[np.float64]] = None
        self._mu: Optional[NDArray[np.float64]] = None
        self._omega: Optional[NDArray[np.float64]] = None
        self._alpha: Optional[NDArray[np.float64]] = None
        self._beta: Optional[NDArray[np.float64]] = None
        self._nu: Optional[NDArray[np.float64]] = None
        self._fitted_params: Optional[list] = None
        self._reference_returns: Optional[list] = None  # to compute KL divergence later
        
        self._is_fitted: bool = False
        self._fit_failed: bool = False

    @classmethod
    def _build_features(cls, df: pd.DataFrame) -> NDArray[np.float64]:
        """Extract univariate return vector from market data."""
        if "return" in df.columns:
            ret: pd.Series = df["return"].astype(np.float64)
        elif "close" in df.columns:
            ret = np.log(df["close"] / df["close"].shift(1)).astype(np.float64)
        else:
            raise KeyError("DataFrame must have a 'close' (prices) or 'return' column.")

        # Scaled log-returns in percent (%)
        ret_pct = ret * 100.0
        obs = ret_pct.dropna().to_numpy()
        
        if len(obs) < 25:
            raise ValueError(f"Only {len(obs)} valid observations; need ≥ 25.")
        return obs

    def fit(self, df: pd.DataFrame, warm_start: bool = True) -> "MarketRegimeDetector":
        """Fit the 3-state Student-t RS-GARCH model using the Hamilton Filter.

        Phase 9: Multi-start ensemble for deterministic, robust fitting.
        Claude found that single-shot SLSQP on the non-convex RS-GARCH likelihood
        surface produces different local optima across runs (75% vs 98% on same data).
        Now: run 3 fits with different seeds, keep the one with lowest NLL.
        """
        try:
            obs = self._build_features(df)
            self._reference_returns = obs.tolist()
            
            warm_start_params = self._fitted_params if (warm_start and self._is_fitted and self._fitted_params) else None

            # Phase 9: Multi-start ensemble — try 3 seeds, keep best (lowest NLL)
            _best_res = None
            _best_nll = float('inf')
            _seeds = [self._random_state, self._random_state + 1, self._random_state + 2]

            for _seed in _seeds:
                try:
                    _res = self._estimate_rsgarch_mle(obs, self._N_STATES, _seed, warm_start_params=warm_start_params)
                    if _res["success"] and _res.get("nll", float('inf')) < _best_nll:
                        _best_nll = _res["nll"]
                        _best_res = _res
                except Exception:
                    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                    continue

            if _best_res is None:
                # All multi-starts failed — fall back to single attempt
                _best_res = self._estimate_rsgarch_mle(obs, self._N_STATES, self._random_state, warm_start_params=warm_start_params)

            fit_res = _best_res
            
            self._P_mat = fit_res["P_mat"]
            self._mu = fit_res["mu"]
            self._omega = fit_res["omega"]
            self._alpha = fit_res["alpha"]
            self._beta = fit_res["beta"]
            self._nu = fit_res["nu"]
            self._fitted_params = fit_res["fitted_params"]
            
            self._fit_failed = not fit_res["success"]
            self._is_fitted = True
            
            logger.info(
                "[RegimeDetector] RS-GARCH fit complete | Success: %s | means: %s | transitions: %s",
                fit_res["success"],
                np.round(self._mu, 4).tolist(),
                np.round(self._P_mat.diagonal(), 4).tolist()
            )
        except Exception as e:
            logger.warning("[RegimeDetector] RS-GARCH fitting failed: %s. Falling back to default parameters.", e, exc_info=True)
            self._fit_failed = True
            self._is_fitted = True
            self._mu = np.array([-0.2, 0.0, 0.2])
            self._P_mat = np.array([
                [0.90, 0.08, 0.02],
                [0.05, 0.90, 0.05],
                [0.02, 0.08, 0.90]
            ])
            self._omega = np.array([0.1, 0.05, 0.02])
            self._alpha = np.array([0.05, 0.05, 0.05])
            self._beta = np.array([0.85, 0.85, 0.85])
            self._nu = np.array([6.0, 6.0, 6.0])
            self._fitted_params = []
            
        return self

    def _estimate_rsgarch_mle(self, r: NDArray[np.float64], K: int = 3, random_state: int = 42, warm_start_params: Optional[list] = None) -> dict:
        """Run Scipy SLSQP optimization for the Hamilton Filter likelihood."""
        n_obs = len(r)
        v_uncond = np.var(r)
        
        init_covs = np.array([v_uncond * 1.5, v_uncond * 0.8, v_uncond * 0.5])
        self._init_covs = init_covs
        if warm_start_params is not None and len(warm_start_params) == (K * (K-1) + 5 * K):
            init_params = np.array(warm_start_params)
        else:
            # Smart initialization using KMeans to find regime clusters.
            # Replaces hmmlearn dependency (BUG-R1 fix) — sklearn is already
            # in requirements.txt and gives equivalent warm-start quality.
            try:
                from sklearn.cluster import KMeans
                obs_2d = r.reshape(-1, 1)
                km = KMeans(n_clusters=K, random_state=random_state, n_init=10, max_iter=300)
                labels = km.fit_predict(obs_2d)

                # Sort clusters by mean return: Bear (lowest) → Sideways → Bull (highest)
                sort_idx = np.argsort(km.cluster_centers_[:, 0])
                init_mu = km.cluster_centers_[sort_idx, 0]

                # Per-cluster variance from data points in each cluster
                init_covs_raw = np.array([
                    np.var(r[labels == i]) if (labels == i).sum() > 1 else v_uncond
                    for i in sort_idx
                ])
                init_covs = np.clip(init_covs_raw, 1e-8, None)

                # Build empirical transition matrix from label sequences
                init_P = np.full((K, K), 0.05 / (K - 1))
                np.fill_diagonal(init_P, 0.0)
                for t in range(len(labels) - 1):
                    si = np.where(sort_idx == labels[t])[0][0]
                    sj = np.where(sort_idx == labels[t + 1])[0][0]
                    init_P[si, sj] += 1
                row_sums = init_P.sum(axis=1, keepdims=True)
                row_sums[row_sums == 0] = 1.0
                init_P = init_P / row_sums

            except Exception:
                # Hard fallback — only reached if sklearn KMeans itself fails
                init_mu    = np.array([-0.2, 0.0, 0.2])
                init_covs  = np.array([v_uncond * 1.5, v_uncond * 0.8, v_uncond * 0.5])
                init_P     = np.array([
                    [0.90, 0.08, 0.02],
                    [0.05, 0.90, 0.05],
                    [0.02, 0.08, 0.90]
                ])
                
            init_logits = []
            for i in range(K):
                row_p = np.clip(init_P[i], 1e-5, 1.0 - 1e-5)
                row_p = row_p / np.sum(row_p)
                logits = np.log(row_p[:-1] / row_p[-1])
                init_logits.extend(logits.tolist())
                
            init_omega = init_covs * 0.08
            init_alpha = np.full(K, 0.06)
            init_beta = np.full(K, 0.84)
            init_nu = np.full(K, 6.0)
            
            init_params = np.concatenate([
                init_logits, init_mu, init_omega, init_alpha, init_beta, init_nu
            ])
        
        bounds = []
        bounds.extend([(-8.0, 8.0)] * (K * (K-1)))  # transition logits
        bounds.extend([(-5.0, 5.0)] * K)            # mu
        bounds.extend([(1e-5, 2.0)] * K)            # omega
        bounds.extend([(0.0, 0.85)] * K)            # alpha
        bounds.extend([(0.0, 0.98)] * K)            # beta
        bounds.extend([(2.1, 40.0)] * K)            # nu (df)
        
        # Stationarity constraints (alpha + beta < 0.999 per state)
        def stationarity_cons(params):
            val = 0.999
            for k in range(K):
                a_idx = K*(K-1) + 2*K + k
                b_idx = K*(K-1) + 3*K + k
                val = min(val, 0.999 - (params[a_idx] + params[b_idx]))
            return val
            
        def hamilton_filter_nll(params):
            p_idx = 0
            P_mat = np.zeros((K, K))
            for i in range(K):
                logits = np.zeros(K)
                for j in range(K-1):
                    logits[j] = params[p_idx]
                    p_idx += 1
                exp_logits = np.exp(logits)
                P_mat[i] = exp_logits / np.sum(exp_logits)
                
            mu_vec = params[p_idx : p_idx + K]
            p_idx += K
            omega_vec = params[p_idx : p_idx + K]
            p_idx += K
            alpha_vec = params[p_idx : p_idx + K]
            p_idx += K
            beta_vec = params[p_idx : p_idx + K]
            p_idx += K
            nu_vec = params[p_idx : p_idx + K]
            
            h_t = init_covs.copy()
            
            # Solve stationary distribution
            try:
                A_eq = (P_mat - np.eye(K)).T
                A_eq = np.vstack([A_eq, np.ones(K)])
                b_eq = np.zeros(K + 1)
                b_eq[-1] = 1.0
                pi = np.linalg.lstsq(A_eq, b_eq, rcond=None)[0]
                if np.any(pi < 0) or np.any(pi > 1):
                    pi = np.ones(K) / K
            except Exception:
                pi = np.ones(K) / K
                
            xi_filter = pi.copy()
            log_lik = 0.0
            
            for t in range(n_obs):
                xi_predict = P_mat.T @ xi_filter
                if t > 0:
                    agg_mu = float(xi_filter @ mu_vec)
                    eps_lag = r[t-1] - agg_mu
                    agg_var = float(xi_filter @ (h_t + mu_vec**2)) - agg_mu**2
                    for k in range(K):
                        h_t[k] = max(1e-6, omega_vec[k] + alpha_vec[k] * (eps_lag**2) + beta_vec[k] * agg_var)
                        
                eta = np.zeros(K)
                for k in range(K):
                    df = nu_vec[k]
                    diff = r[t] - mu_vec[k]
                    scale_sq = h_t[k] * (df - 2.0) / df
                    if scale_sq < 1e-6:
                        scale_sq = 1e-6
                    log_pdf = (gammaln((df + 1.0) / 2.0) - gammaln(df / 2.0)
                               - 0.5 * np.log(np.pi * df * scale_sq)
                               - 0.5 * (df + 1.0) * np.log(1.0 + (diff**2) / (df * scale_sq)))
                    eta[k] = np.exp(log_pdf)
                    
                f_obs = float(xi_predict @ eta)
                if f_obs < 1e-12:
                    f_obs = 1e-12
                log_lik += np.log(f_obs)
                
                xi_filter = (xi_predict * eta) / f_obs
                xi_filter = np.clip(xi_filter, 1e-12, 1.0 - 1e-12)
                xi_filter = xi_filter / np.sum(xi_filter)
                
            return -log_lik

        # Fit
        res = minimize(
            hamilton_filter_nll, init_params, bounds=bounds,
            constraints=[{"type": "ineq", "fun": stationarity_cons}],
            method="SLSQP", options={"maxiter": self._n_iter, "ftol": self._tol}
        )
        
        success = bool(res.success or (res.x is not None and np.isfinite(res.fun)))
        opt_params = res.x if (res.x is not None and len(res.x) == len(init_params)) else init_params
        
        p_idx = 0
        P_mat = np.zeros((K, K))
        for i in range(K):
            logits = np.zeros(K)
            for j in range(K-1):
                logits[j] = opt_params[p_idx]
                p_idx += 1
            exp_logits = np.exp(logits)
            P_mat[i] = exp_logits / np.sum(exp_logits)
            
        mu_vec = opt_params[p_idx : p_idx + K]
        p_idx += K
        omega_vec = opt_params[p_idx : p_idx + K]
        p_idx += K
        alpha_vec = opt_params[p_idx : p_idx + K]
        p_idx += K
        beta_vec = opt_params[p_idx : p_idx + K]
        p_idx += K
        nu_vec = opt_params[p_idx : p_idx + K]
        
        return {
            "success": success,
            "P_mat": P_mat,
            "mu": mu_vec,
            "omega": omega_vec,
            "alpha": alpha_vec,
            "beta": beta_vec,
            "nu": nu_vec,
            "fitted_params": opt_params.tolist(),
            "nll": float(res.fun) if hasattr(res, 'fun') and np.isfinite(res.fun) else float('inf')
        }

    def predict_regime(
        self,
        df: pd.DataFrame,
        last_n_days: int = 252,
        use_macro_overlay: bool = True,
    ) -> Dict[str, object]:
        """Compute the current market regime probabilities via RS-GARCH Hamilton filtering."""
        if not self._is_fitted:
            raise RuntimeError("Model not fitted.")
            
        obs = self._build_features(df)
        
        # Verify staleness info via KL divergence
        kl_divergence = 0.0
        if self._reference_returns is not None and len(self._reference_returns) >= 50:
            # Compare latest last_n_days returns to fitted reference returns
            kl_divergence = self._calculate_kl(obs[-last_n_days:], np.array(self._reference_returns))
            
        # Run Hamilton filter sequentially on the inference observation sequence
        K = self._N_STATES
        if len(obs) > last_n_days:
            obs = obs[-last_n_days:]
        n_obs = len(obs)
        
        h_t = np.full(K, np.var(obs))
        
        # Solve initial stationary probabilities
        try:
            A_eq = (self._P_mat - np.eye(K)).T
            A_eq = np.vstack([A_eq, np.ones(K)])
            b_eq = np.zeros(K + 1)
            b_eq[-1] = 1.0
            pi = np.linalg.lstsq(A_eq, b_eq, rcond=None)[0]
            if np.any(pi < 0) or np.any(pi > 1):
                pi = np.ones(K) / K
        except Exception:
            pi = np.ones(K) / K
            
        xi_filter = pi.copy()
        
        for t in range(n_obs):
            xi_predict = self._P_mat.T @ xi_filter
            if t > 0:
                agg_mu = float(xi_filter @ self._mu)
                eps_lag = obs[t-1] - agg_mu
                agg_var = float(xi_filter @ (h_t + self._mu**2)) - agg_mu**2
                for k in range(K):
                    h_t[k] = max(1e-6, self._omega[k] + self._alpha[k] * (eps_lag**2) + self._beta[k] * agg_var)
                    
            eta = np.zeros(K)
            for k in range(K):
                df_nu = self._nu[k]
                diff = obs[t] - self._mu[k]
                scale_sq = h_t[k] * (df_nu - 2.0) / df_nu
                if scale_sq < 1e-6:
                    scale_sq = 1e-6
                log_pdf = (gammaln((df_nu + 1.0) / 2.0) - gammaln(df_nu / 2.0)
                           - 0.5 * np.log(np.pi * df_nu * scale_sq)
                           - 0.5 * (df_nu + 1.0) * np.log(1.0 + (diff**2) / (df_nu * scale_sq)))
                eta[k] = np.exp(log_pdf)
                
            f_obs = float(xi_predict @ eta)
            if f_obs < 1e-12:
                f_obs = 1e-12
            xi_filter = (xi_predict * eta) / f_obs
            xi_filter = np.clip(xi_filter, 1e-12, 1.0 - 1e-12)
            xi_filter = xi_filter / np.sum(xi_filter)
            
        today_probs = xi_filter.copy()
        raw_probs = today_probs.copy()
        
        macro_shock_applied = False
        macro_shock_factor = 0.0
        
        if use_macro_overlay:
            # Incorporate macro risk adjustments
            try:
                from datetime import datetime as _dt_macro
                _now_ts = _dt_macro.now().timestamp()
                if not hasattr(self, "_macro_cache") or (_now_ts - getattr(self, "_macro_cache_time", 0)) > 300:
                    from data.price_feed import safe_download  # deferred — see ROUND-44 note above
                    self._macro_cache = safe_download(["^GSPC", "^VIX", "^INDIAVIX"], period="2d")
                    self._macro_cache_time = _now_ts
                macro_data = getattr(self, "_macro_cache", pd.DataFrame())
                if macro_data is not None and not macro_data.empty:
                    close_cols = macro_data["Close"]
                    us_ret = 0.0
                    vix_level = 15.0
                    india_vix = 15.0
                    reasons = []
                    
                    if "^GSPC" in close_cols.columns:
                        gspc_close = close_cols["^GSPC"].dropna()
                        if len(gspc_close) >= 2:
                            us_ret = float(np.log(gspc_close.iloc[-1] / gspc_close.iloc[-2]))
                    if "^VIX" in close_cols.columns:
                        vix_close = close_cols["^VIX"].dropna()
                        if not vix_close.empty:
                            vix_level = float(vix_close.iloc[-1])
                    if "^INDIAVIX" in close_cols.columns:
                        india_vix_close = close_cols["^INDIAVIX"].dropna()
                        if not india_vix_close.empty:
                            india_vix = float(india_vix_close.iloc[-1])
                            
                    alpha_sp = 0.0
                    alpha_vix = 0.0
                    alpha_india = 0.0
                    
                    if us_ret < -0.015:
                        alpha_sp = min(0.50, abs(us_ret) * 10.0)
                        reasons.append(f"US Crash ({us_ret:.2%})")
                    if vix_level > 25.0:
                        alpha_vix = min(0.40, (vix_level - 25.0) / 50.0)
                        reasons.append(f"Global VIX ({vix_level:.1f})")
                    if india_vix > 20.0:
                        alpha_india = min(0.40, (india_vix - 20.0) / 40.0)
                        reasons.append(f"India VIX ({india_vix:.1f})")
                        
                    R = max(alpha_sp, alpha_vix, alpha_india)
                    if R > 0.0:
                        macro_shock_applied = True
                        macro_shock_factor = R
                        
                        P_bear = today_probs[0]
                        P_sideways = today_probs[1]
                        P_bull = today_probs[2]
                        
                        P_bear_new = P_bear + R * (1.0 - P_bear)
                        rem = 1.0 - P_bear_new
                        sum_other = P_sideways + P_bull
                        
                        if sum_other > 1e-9:
                            P_sideways_new = P_sideways * rem / sum_other
                            P_bull_new = P_bull * rem / sum_other
                        else:
                            P_sideways_new = rem * 0.5
                            P_bull_new = rem * 0.5
                            
                        today_probs[0] = P_bear_new
                        today_probs[1] = P_sideways_new
                        today_probs[2] = P_bull_new
                        
                        logger.info(
                            "[RegimeDetector] Applied macro overlay: R=%.4f due to %s. "
                            "Adjusted: Bear=%.2f%%, Sideways=%.2f%%, Bull=%.2f%%",
                            R, " + ".join(reasons), P_bear_new * 100.0, P_sideways_new * 100.0, P_bull_new * 100.0
                        )
            except Exception as e:
                logger.warning("[RegimeDetector] Macro overlay failed: %s. Using raw Hamilton filter probabilities.", e, exc_info=True)
                
        # Phase 6.5: Regime hysteresis — prevent flip-flopping in choppy markets.
        # Previously: best_state = argmax(today_probs) flipped regime the instant a
        # different state's probability edged ahead. Now: only switch states when
        # the new state's probability exceeds the current state's by a margin (0.10).
        best_state = int(np.argmax(today_probs))  # compute best state FIRST

        HYSTERESIS_MARGIN = 0.10
        _prev_state = getattr(self, "_last_regime_state", None)
        if _prev_state is not None and _prev_state < len(today_probs) and best_state < len(today_probs):
            _prev_prob = today_probs[_prev_state]
            _best_prob = today_probs[best_state]
            # Only switch if the new state exceeds the previous state by the margin
            if _best_prob < _prev_prob + HYSTERESIS_MARGIN:
                best_state = _prev_state  # hold previous state
        self._last_regime_state = best_state

        # Phase 6.4: KL staleness check — if KL divergence is high, flag for refit.
        # Previously: KL was computed but never triggered a refit. A stale model
        # continued to be used after market regime changes.
        # Now: set refit_required=True in the return dict so callers (RegimeWorker)
        # can trigger an automatic refit.
        STALENESS_THRESHOLD = 0.15
        refit_required = kl_divergence > STALENESS_THRESHOLD

        confidence = float(np.max(today_probs))  # M7 Fix: confidence reflects maximum state probability

        # Bug-fix #4 (HIGH): Fallback regime flag. When the model has _fit_failed=True
        # (load_json loaded a fit_failed model, or fit() fell back to default params
        # due to an exception), predict_regime() still returned the raw Hamilton-filter
        # confidence as if the model was authoritative. Downstream code (live_verify,
        # optimizer, BL estimator) treated this as a high-conviction regime call and
        # sized positions accordingly.
        # Fix: expose is_fallback flag in the return dict, and cap confidence at 0.40
        # when fallback is active so downstream code sees a low-conviction signal.
        is_fallback = bool(getattr(self, "_fit_failed", False))
        if is_fallback:
            # Don't lie about confidence — cap at 0.40 so downstream code sees "weak"
            _original_confidence = confidence
            confidence = min(confidence, 0.40)
            logger.warning(
                "[RegimeDetector] Fallback mode active (model fit failed or loaded a "
                "fit_failed model). Capping confidence from %.2f%% to %.2f%%. "
                "Downstream code should treat this as low-conviction.",
                _original_confidence * 100.0, confidence * 100.0,
            )
        
        return {
            "state": best_state,
            "label": self._STATE_LABELS[best_state],
            "confidence": round(confidence, 6),
            # Bug-fix #4: expose fallback flag so downstream code can react
            "is_fallback": is_fallback,
            "probabilities": {
                "Bear": round(float(today_probs[0]), 6),
                "Sideways": round(float(today_probs[1]), 6),
                "Bull": round(float(today_probs[2]), 6),
            },
            "raw_probabilities": {
                "Bear": round(float(raw_probs[0]), 6),
                "Sideways": round(float(raw_probs[1]), 6),
                "Bull": round(float(raw_probs[2]), 6),
            },
            "signals": {
                # C4-fix: emit the four return/vol signal keys expected by live_verify.py:83-90
                # and other diagnostic dashboards. Previously these were absent, causing the
                # "Today Return / 5d avg / Today Vol / 5d avg" panel to always print "n/a".
                # obs is already scaled to percent by _build_features (×100), so these are
                # directly interpretable as percentage returns / percentage vols.
                "ret_today_pct":   float(obs[-1]) if len(obs) >= 1 else 0.0,
                "ret_5d_avg_pct":  float(np.mean(obs[-5:])) if len(obs) >= 5 else 0.0,
                "vol_today_pct":   float(np.std(obs[-2:])) if len(obs) >= 2 else 0.0,
                "vol_5d_avg_pct":  float(np.std(obs[-5:])) if len(obs) >= 5 else 0.0,
                "macro_shock_applied": float(macro_shock_applied),
                "macro_shock_factor": round(macro_shock_factor, 6),
                "kl_divergence": round(kl_divergence, 6),
                # Bug-fix #4: also expose is_fallback in signals dict for code that
                # reads signals rather than top-level keys.
                "is_fallback": float(is_fallback),
            },
            "transition_matrix": self._P_mat,
            "macro_shock_applied": macro_shock_applied,
            "macro_shock_factor": round(macro_shock_factor, 6),
            "kl_divergence": round(kl_divergence, 6),
            # Phase 6.4: refit_required flag for RegimeWorker to trigger auto-refit
            "refit_required": refit_required,
            # L14-fix: live_verify.py:103 reads pred.get('macro_bull_boost', 0) but
            # predict_regime() never emitted it at the top level. Emit a default 0.0
            # here so consumers don't silently fall back to the missing-key default.
            "macro_bull_boost": 0.0,
        }

    @staticmethod
    def _calculate_kl(p_ret: NDArray[np.float64], q_ret: NDArray[np.float64]) -> float:
        """Compute KL divergence between two return vectors using Gaussian approximation."""
        mu_p, std_p = np.mean(p_ret), np.std(p_ret)
        mu_q, std_q = np.mean(q_ret), np.std(q_ret)
        std_p = max(std_p, 1e-6)
        std_q = max(std_q, 1e-6)
        kl = np.log(std_q / std_p) + (std_p**2 + (mu_p - mu_q)**2) / (2 * std_q**2) - 0.5
        return max(0.0, kl)

    @property
    def transition_matrix(self) -> NDArray[np.float64]:
        if not self._is_fitted or self._P_mat is None:
            raise RuntimeError("Model not fitted.")
        return self._P_mat

    @property
    def emission_means(self) -> NDArray[np.float64]:
        """Means representing state expected returns."""
        if not self._is_fitted or self._mu is None:
            raise RuntimeError("Model not fitted.")
        # Make (3, 2) dummy shape for compatibility with legacy visual components
        # column 0: mu return, column 1: approximate unconditional variance
        # M17-fix: guard against alpha+beta > 1.0 (non-stationary loaded model) producing
        # a negative denominator, which makes np.sqrt return NaN and corrupts downstream UIs.
        vols = np.sqrt(np.maximum(self._omega / (1.0 - self._alpha - self._beta + 1e-9), 0.0))
        return np.column_stack([self._mu, vols])

    @property
    def is_fitted(self) -> bool:
        return self._is_fitted

    def save_json(self, path: str | Path) -> None:
        """Serialize the fitted RS-GARCH parameters to JSON."""
        if not self._is_fitted:
            raise RuntimeError("Model not fitted.")
            
        payload = {
            "metadata": {
                "version": "2.0_rsgarch",
                "timestamp_utc": datetime.now(timezone.utc).isoformat(),
            },
            "detector": {
                "n_iter": int(self._n_iter),
                "tol": float(self._tol),
                "random_state": int(self._random_state),
                "fit_failed": bool(self._fit_failed),
                "reference_returns": self._reference_returns
            },
            "model": {
                "P_mat": self._P_mat.tolist() if self._P_mat is not None else None,
                "mu": self._mu.tolist() if self._mu is not None else None,
                "omega": self._omega.tolist() if self._omega is not None else None,
                "alpha": self._alpha.tolist() if self._alpha is not None else None,
                "beta": self._beta.tolist() if self._beta is not None else None,
                "nu": self._nu.tolist() if self._nu is not None else None,
                "init_covs": self._init_covs.tolist() if getattr(self, "_init_covs", None) is not None else None,
                "fitted_params": self._fitted_params
            }
        }
        
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        # AUDIT-FIX (Round 49 — R49-2): atomic model-artifact write (unique
        # tmp + os.replace). A crash mid-save of the previous plain open(w)+
        # json.dump left a truncated regime_hmm_latest.json; load_json then
        # raised, ensure_fresh_model forced a full retrain (or the dashboard
        # fell back to "Defensive (Stale Model)" mode) instead of simply
        # keeping the last good artifact.
        import os as _os
        import threading as _threading
        _tmp = path.with_suffix(path.suffix + f".{_os.getpid()}.{_threading.get_ident()}.tmp")
        with open(_tmp, "w") as f:
            json.dump(payload, f, indent=2)
        _os.replace(str(_tmp), str(path))
        logger.info("[RegimeDetector] Saved RS-GARCH model -> %s", path)

    @classmethod
    def load_json(cls, path: str | Path) -> "MarketRegimeDetector":
        """Load RS-GARCH model from JSON."""
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Model artifact not found: {path}")
            
        with open(path, "r") as f:
            payload = json.load(f)
            
        inst = cls.__new__(cls)
        detector_data = payload["detector"]
        inst._n_iter = detector_data["n_iter"]
        inst._tol = detector_data["tol"]
        inst._random_state = detector_data["random_state"]
        inst._fit_failed = detector_data.get("fit_failed", False)
        inst._reference_returns = detector_data.get("reference_returns", None)
        inst._is_fitted = True
        
        model_data = payload["model"]
        if model_data is not None and not inst._fit_failed:
            inst._P_mat = np.array(model_data["P_mat"], dtype=np.float64)
            inst._mu = np.array(model_data["mu"], dtype=np.float64)
            inst._omega = np.array(model_data["omega"], dtype=np.float64)
            inst._alpha = np.array(model_data["alpha"], dtype=np.float64)
            inst._beta = np.array(model_data["beta"], dtype=np.float64)
            inst._nu = np.array(model_data["nu"], dtype=np.float64)
            if "init_covs" in model_data and model_data["init_covs"] is not None:
                inst._init_covs = np.array(model_data["init_covs"], dtype=np.float64)
            else:
                inst._init_covs = None
            inst._fitted_params = model_data["fitted_params"]
        else:
            inst._fit_failed = True
            inst._P_mat = np.array([
                [0.90, 0.08, 0.02],
                [0.05, 0.90, 0.05],
                [0.02, 0.08, 0.90]
            ])
            inst._mu = np.array([-0.2, 0.0, 0.2])
            inst._omega = np.array([0.1, 0.05, 0.02])
            inst._alpha = np.array([0.05, 0.05, 0.05])
            inst._beta = np.array([0.85, 0.85, 0.85])
            inst._nu = np.array([6.0, 6.0, 6.0])
            inst._init_covs = None
            inst._fitted_params = []
            
        inst.timestamp_utc = payload.get("metadata", {}).get("timestamp_utc", None)
        logger.info("[RegimeDetector] Loaded RS-GARCH model <- %s", path)
        return inst

    @classmethod
    def ensure_fresh_model(cls, path: str | Path = "models/regime_hmm_latest.json", max_age_hours: float = 48.0, log_fn=None) -> tuple[bool, float]:
        """Checks if the HMM regime model exists and is within max_age_hours.
        If missing or stale, automatically retrains a fresh RS-GARCH HMM on Nifty 50 daily returns and saves it.
        Returns: (was_refreshed: bool, age_hours: float)
        """
        path = Path(path)
        is_stale = True
        age_hours = 999.0

        if path.exists():
            try:
                with open(path, "r") as f:
                    meta = json.load(f).get("metadata", {})
                ts_str = meta.get("timestamp_utc")
                if ts_str:
                    ts = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
                    age_hours = (datetime.now(timezone.utc) - ts).total_seconds() / 3600.0
                    if age_hours <= max_age_hours:
                        is_stale = False
            except Exception as e:
                is_stale = True

        if not is_stale:
            if log_fn:
                log_fn(f"[Regime Pre-Flight] ✓ HMM regime model is fresh (age: {age_hours:.1f}h <= {max_age_hours}h limit).")
            return False, age_hours

        # Retrain on the fly
        if log_fn:
            log_fn(f"[Regime Pre-Flight] ⚠️ HMM model is {age_hours:.1f}h old (> {max_age_hours}h limit) or missing. Auto-retraining fresh RS-GARCH HMM on Nifty 50...")
        try:
            import yfinance as yf
            raw = yf.download("^NSEI", period="3y", interval="1d", auto_adjust=True, progress=False)
            if raw.empty or "Close" not in raw.columns:
                if log_fn: log_fn("[Regime Pre-Flight] ⚠️ Failed to download ^NSEI; keeping existing artifact.")
                return False, age_hours
            prices = raw["Close"].squeeze().dropna()
            returns = prices.pct_change().dropna().squeeze()
            df = pd.DataFrame({"return": returns.values}, index=returns.index)

            detector = cls(n_iter=500, tol=1e-4, random_state=42)
            detector.fit(df)
            detector.save_json(path)
            if log_fn:
                log_fn(f"[Regime Pre-Flight] ✅ Successfully trained fresh RS-GARCH HMM model ({len(returns)} days) -> {path.name}")
            return True, 0.0
        except Exception as e:
            if log_fn:
                log_fn(f"[Regime Pre-Flight] ❌ Retrain error: {e}")
            return False, age_hours

    def save(self, path: str | Path) -> None:
        """Persist model to JSON or pickle based on suffix.

        RegimeWorker historically called save()/load() for non-JSON model paths;
        these wrappers keep that path functional while save_json()/load_json()
        remain the canonical portable format.
        """
        path = Path(path)
        if path.suffix.lower() == ".json":
            self.save_json(path)
            return
        if not self._is_fitted:
            raise RuntimeError("Model not fitted.")
        # SECURITY: pickle/joblib serialization removed — arbitrary code execution risk.
        # Use JSON format only: detector.save_json("models/regime_hmm_latest.json")
        raise ValueError(
            "Pickle serialization disabled for security. Use .json format instead: "
            "detector.save_json(Path('models/regime_hmm_latest.json'))"
        )

    @classmethod
    def load(cls, path: str | Path) -> "MarketRegimeDetector":
        """Load model from JSON only. Pickle/joblib disabled for security.

        SECURITY: pickle.load executes arbitrary code. If an attacker replaces
        the model file, they get full code execution. JSON is safe to deserialize.
        """
        path = Path(path)
        if path.suffix.lower() == ".json":
            return cls.load_json(path)
        raise ValueError(
            f"Pickle/joblib loading disabled for security. "
            f"Got '{path.suffix}' — use .json format only. "
            f"Path: {path}"
        )

    @staticmethod
    def calculate_regime_position_multiplier(
        p_bear: float,
        p_bull: float = 0.0,
        alpha_regime: float = 1.5,
    ) -> float:
        """Dynamically compute position sizing multiplier based on HMM regime state.

        Scales long position weights down as Bear regime probability increases:
            multiplier = (1.0 - p_bear) ** alpha_regime

        In pure Bull regime (p_bear = 0): multiplier = 1.0 (full allocation)
        In 50% Bear regime (p_bear = 0.5): multiplier ≈ 0.35 (risk reduced)
        In 100% Bear regime (p_bear = 1.0): multiplier = 0.0 (all capital to Cash)
        """
        p_bear_clamped = max(0.0, min(1.0, float(p_bear)))
        mult = (1.0 - p_bear_clamped) ** float(alpha_regime)
        return max(0.0, min(1.0, float(mult)))

    def predict_current_state(self, df: Optional[pd.DataFrame] = None) -> str:
        """Convenience method returning the most likely current market regime state string."""
        if not self._is_fitted:
            return "Defensive"
        if df is not None and not df.empty:
            try:
                res = self.predict_regime(df)
                return str(res.get("label", "Defensive"))
            except Exception:
                pass
        # Fallback to reference returns
        if self._reference_returns is not None and len(self._reference_returns) >= 20:
            try:
                ref_df = pd.DataFrame({"Close": np.cumprod(1.0 + np.array(self._reference_returns))})
                res = self.predict_regime(ref_df)
                return str(res.get("label", "Defensive"))
            except Exception:
                pass
        # AUDIT-FIX (Round 6, A2-P3-8): `_state_names` is never defined
        # anywhere (grep-verified) — getattr always fell back to ["Bull"],
        # so this last-resort branch ALWAYS returned the optimistic label.
        # A last-resort default must be conservative.
        return "Defensive"

    def __repr__(self) -> str:
        status = "fitted" if self._is_fitted else "unfitted"
        return f"MarketRegimeDetector(states=3, model=RS-GARCH, status={status})"
