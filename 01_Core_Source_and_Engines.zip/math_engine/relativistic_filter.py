"""
math_engine/relativistic_filter.py
==================================
Backward-compatibility alias. The canonical module is now:
`math_engine.kalman_trend_filter`.
"""
from __future__ import annotations
from math_engine.kalman_trend_filter import KalmanTrendFilter

__all__ = ["KalmanTrendFilter"]
