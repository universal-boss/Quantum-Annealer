"""
math_engine/riemannian_geometry.py
==================================
Volatility Clock & Regime Acceleration Engine.

Measures "volatility clock speed" — how fast the market's internal information
clock is ticking relative to calendar time — by computing:
  1. Rolling realized vol ratio (recent 5-day vs 60-day), the core speed signal.
  2. Poincaré hyperbolic distance between consecutive normalized return states,
     capturing non-linear curvature of sudden regime acceleration.

The hyperbolic distance is geometrically valid (uses correct Poincaré disk formula).
The interpretation: larger hyperbolic distance between consecutive return states
= more structural dissimilarity = faster regime acceleration = higher vol clock speed.

Note: "time dilation factor" is an analogy for regime acceleration speed,
not a physics quantity. Factor range [1.0, 5.0] maps to [normal, extreme crisis].

References:
    - Poincaré disk model: d_H(u,v) = arcosh(1 + 2||u-v||² / ((1-||u||²)(1-||v||²)))
    - Financial volatility clocks: Ané & Geman (2000), "Order Flow, Transaction Clock..."
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any

logger = logging.getLogger(__name__)


class VolatilityClockEngine:
    """
    Volatility Clock Speed & Regime Acceleration Estimator.

    Computes regime acceleration via:
      1. Realized vol ratio (recent / historical) — primary signal.
      2. Poincaré hyperbolic distance between consecutive return states — secondary signal.

    High clock speed (factor >> 1.0) indicates rapid regime shifts requiring
    faster rebalancing and tighter risk limits.
    """

    @staticmethod
    def compute_vol_clock_speed(returns_df: pd.DataFrame, short_window: int = 5) -> Dict[str, Any]:
        """
        Estimates volatility clock acceleration factor.

        Primary metric: realized_vol_ratio = std(recent_returns) / std(full_history)
        Secondary metric: Poincaré hyperbolic distance between consecutive return states.

        Args:
            returns_df: DataFrame of asset returns, shape (T, N).
            short_window: Rolling window for recent vol estimation.

        Returns:
            Dict with vol_clock_speed, hyperbolic_state_distance, and regime_acceleration.
        """
        if returns_df is None or returns_df.empty or returns_df.shape[1] < 2:
            return {"vol_clock_speed": 1.0, "hyperbolic_state_distance": 0.0, "regime_acceleration": "NORMAL"}

        clean_ret = returns_df.dropna(how="all").fillna(0.0).values
        T, N = clean_ret.shape

        if T < short_window + 5:
            return {"vol_clock_speed": 1.0, "hyperbolic_state_distance": 0.0, "regime_acceleration": "NORMAL"}

        # 1. Realized vol ratio (primary, clean financial metric)
        recent_vol = float(np.std(clean_ret[-short_window:]))
        hist_vol = float(np.std(clean_ret)) + 1e-9
        vol_ratio = float(recent_vol / hist_vol)

        # 2. Poincaré hyperbolic distance between consecutive normalized return states
        # Map returns into unit disk via tanh (ensures ||u|| < 1)
        std = np.std(clean_ret, axis=0) + 1e-9
        u = np.tanh(clean_ret[-1] / (3.0 * std))
        v = np.tanh(clean_ret[-2] / (3.0 * std)) if T > 1 else u * 0.9

        u_norm_sq = float(np.clip(np.sum(u ** 2), 0.0, 0.9999))
        v_norm_sq = float(np.clip(np.sum(v ** 2), 0.0, 0.9999))
        diff_norm_sq = float(np.sum((u - v) ** 2))

        # Poincaré disk distance: d_H(u,v) = arcosh(1 + 2||u-v||² / ((1-||u||²)(1-||v||²)))
        arg = 1.0 + (2.0 * diff_norm_sq) / ((1.0 - u_norm_sq) * (1.0 - v_norm_sq) + 1e-9)
        hyperbolic_dist = float(np.arccosh(max(1.0, arg)))

        # Combined vol clock speed: blend both signals
        # Scaling: vol_ratio dominates (linear), hyperbolic dist adds curvature signal
        clock_speed = float(min(max(vol_ratio * (1.0 + 0.2 * hyperbolic_dist), 1.0), 5.0))

        if clock_speed >= 3.0:
            acceleration = "EXTREME_CRISIS"
        elif clock_speed >= 2.0:
            acceleration = "HIGH_STRESS"
        elif clock_speed >= 1.5:
            acceleration = "ELEVATED"
        else:
            acceleration = "NORMAL"

        return {
            "vol_clock_speed": round(clock_speed, 4),
            "realized_vol_ratio": round(vol_ratio, 4),
            "hyperbolic_state_distance": round(hyperbolic_dist, 4),
            "regime_acceleration": acceleration
        }

    @staticmethod
    def compute_absorption_ratio(returns_df: pd.DataFrame, n_components: int = 3) -> Dict[str, Any]:
        """
        Computes Kritzman et al. (2011) Absorption Ratio:
        Ratio of variance explained by the top k principal components.
        Phi = sum_{i=1}^k lambda_i / sum_{i=1}^N lambda_i.
        A high absorption ratio indicates high systemic fragility (assets coupled together).
        """
        if returns_df is None or returns_df.empty or returns_df.shape[1] < 2:
            return {"absorption_ratio": 0.35, "absorption_fragility": "NORMAL", "top_k_components": n_components}
        clean = returns_df.dropna(how="all").fillna(0.0).values
        T, N = clean.shape
        if N < 2:
            return {"absorption_ratio": 0.35, "absorption_fragility": "NORMAL", "top_k_components": n_components}
        k = min(n_components, N)
        try:
            cov = np.cov(clean, rowvar=False)
            evals = np.linalg.eigvalsh(cov)
            evals = np.maximum(evals, 0.0)
            total_var = np.sum(evals)
            if total_var < 1e-12:
                return {"absorption_ratio": 0.35, "absorption_fragility": "NORMAL", "top_k_components": k}
            top_var = np.sum(evals[-k:])
            ar = float(top_var / total_var)
            if ar >= 0.70:
                fragility = "SYSTEMIC_FRAGILITY"
            elif ar >= 0.55:
                fragility = "ELEVATED_COUPLING"
            else:
                fragility = "NORMAL"
            return {
                "absorption_ratio": round(ar, 4),
                "absorption_fragility": fragility,
                "top_k_components": k,
                "variance_explained_pct": f"{ar * 100.0:.2f}%"
            }
        except Exception as _e:
            import logging as _rg_log; _rg_log.getLogger("quantum_annealer").warning(
                f"[VolatilityClockEngine.compute_absorption_ratio] eigen-decomposition failed ({_e}) — returning None"
            )
            return {"absorption_ratio": None, "absorption_fragility": None, "top_k_components": k, "error": "computation_failed"}

    @classmethod
    def compute_riemannian_metric_tensor(cls, returns_df: pd.DataFrame) -> Dict[str, Any]:
        """
        Legacy interface alias — returns vol clock speed metrics.
        Renamed from 'time_dilation_factor' to 'vol_clock_speed' for clarity.
        """
        result = cls.compute_vol_clock_speed(returns_df)
        result["time_dilation_factor"] = result["vol_clock_speed"]
        result["mean_hyperbolic_distance"] = result["hyperbolic_state_distance"]
        return result


# Backward compatibility alias
RiemannianGeometryEngine = VolatilityClockEngine

