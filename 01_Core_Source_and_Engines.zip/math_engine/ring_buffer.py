"""
math_engine/ring_buffer.py
==========================
Thread-safe circular ring buffer register for rolling order execution,
transaction trail logging, and portfolio state snapshot reconciliation.
"""
from __future__ import annotations

import logging
import threading
import hashlib
import json
from typing import Dict, Any, List, Tuple, Optional
from collections import deque
from datetime import datetime

logger = logging.getLogger(__name__)


class RingBufferMemoryRegister:
    """Thread-safe circular ring buffer register for rolling execution & portfolio reconciliation.
    
    Production-grade circular memory structure featuring FIFO eviction,
    O(1) state pushes, historical query windows, and audit hashing.
    """

    def __init__(self, size: int = 1024) -> None:
        self.capacity: int = max(16, int(size))
        self._buffer: deque = deque(maxlen=self.capacity)
        self._lock = threading.RLock()
        self._sequence_counter: int = 0
        self._addr_map: Dict[int, Dict[str, Any]] = {}

    def push(self, data: Dict[str, Any]) -> int:
        """Pushes a new state record into the circular ring buffer.
        
        Evicts oldest record if capacity is reached. Returns unique sequence ID.
        """
        with self._lock:
            self._sequence_counter += 1
            record = {
                "seq": self._sequence_counter,
                "timestamp": datetime.now().isoformat(),
                "data": data
            }
            if len(self._buffer) >= self.capacity:
                oldest = self._buffer[0]
                old_seq = oldest.get("seq")
                if old_seq in self._addr_map:
                    del self._addr_map[old_seq]
            
            self._buffer.append(record)
            address = self._sequence_counter % self.capacity
            self._addr_map[address] = record
            return self._sequence_counter

    def write_state(self, address: int, data: Any) -> bool:
        """Writes or updates state at circular address."""
        with self._lock:
            idx = address % self.capacity
            record = {
                "address": idx,
                "timestamp": datetime.now().isoformat(),
                "data": data
            }
            self._addr_map[idx] = record
            return True

    def read_state(self, address: int) -> Optional[Dict[str, Any]]:
        """Reads state at circular address."""
        with self._lock:
            idx = address % self.capacity
            return self._addr_map.get(idx)

    # Backwards-compatible aliases
    write_baryon_state = write_state
    read_baryon_state = read_state

    def get_recent(self, n: int = 10) -> List[Dict[str, Any]]:
        """Retrieves the n most recent state records."""
        with self._lock:
            items = list(self._buffer)
            return items[-n:] if n <= len(items) else items

    def compute_audit_hash(self) -> str:
        """Computes a SHA-256 integrity hash over all current records in the ring buffer."""
        with self._lock:
            hasher = hashlib.sha256()
            for record in self._buffer:
                hasher.update(json.dumps(record, sort_keys=True, default=str).encode("utf-8"))
            return hasher.hexdigest()

    def clear(self) -> None:
        """Clears all records from the ring buffer."""
        with self._lock:
            self._buffer.clear()
            self._addr_map.clear()
            self._sequence_counter = 0


# Canonical aliases
CircularMemoryRegister = RingBufferMemoryRegister
RingBuffer = RingBufferMemoryRegister
