"""
math_engine/risk_budgeting_solver.py
====================================
Domain IV: Portfolio Construction & Optimization Solvers (Criteria 51-65).
High-performance solvers for QUBO Hamiltonians, Wasserstein DRO, HRP Linkages,
Black-Litterman posterior algebra, Equal Risk Contribution (ERC / Risk Budgeting CCD),
Maximum Diversification (MDP), Fractional Kelly, CVaR, CDaR, EVaR,
SEBI regulatory enforcers, Sector cardinality ceilings, L1 turnover, and Softmax temperature scaling.
"""
from __future__ import annotations

import logging
from typing import Dict, List, Tuple, Optional, Any, Union
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.cluster.hierarchy import linkage, dendrogram

logger = logging.getLogger(__name__)


def _norm_sec(sec_val: Any) -> str:
    if not sec_val or str(sec_val).strip().upper() in ("", "NONE", "UNKNOWN", "N/A", "NAN", "NULL"):
        return "UNKNOWN"
    return str(sec_val).strip()


def qubo_energy_hamiltonian(
    x: np.ndarray,
    mu: np.ndarray,
    cov: np.ndarray,
    k_cardinality: int,
    sectors: Optional[Dict[int, str]] = None,
    sector_caps: Optional[Dict[str, int]] = None,
    alpha: float = 1.8,
    gamma: float = 22.0,
    theta: float = 7.5
) -> float:
    """51. QUBO Energy Hamiltonian: H(x) = -alpha*mu^T x + gamma*(Sum x - K)^2 + theta*x^T Cov x + Sector Penalties."""
    x = np.asarray(x, dtype=float)
    mu = np.asarray(mu, dtype=float)
    cov = np.asarray(cov, dtype=float)
    
    # 1. Alpha return term
    h_alpha = -alpha * float(np.dot(mu, x))
    # 2. Cardinality penalty
    card_diff = float(np.sum(x) - k_cardinality)
    h_card = gamma * (card_diff ** 2)
    # 3. Covariance risk term
    h_risk = theta * float(x @ cov @ x)
    
    # 4. Sector penalty
    h_sector = 0.0
    if sectors is not None and sector_caps is not None:
        sector_counts = {}
        for i, val in enumerate(x):
            if val > 0.5:
                sec = _norm_sec(sectors.get(i, "N/A"))
                sector_counts[sec] = sector_counts.get(sec, 0) + 1
        for sec, cnt in sector_counts.items():
            cap = sector_caps.get(sec, sector_caps.get("UNKNOWN", 999))
            if cnt > cap:
                h_sector += gamma * ((cnt - cap) ** 2)
                
    total_energy = h_alpha + h_card + h_risk + h_sector
    return float(total_energy)


def wasserstein_dro_portfolio(
    returns: Union[pd.DataFrame, np.ndarray],
    epsilon: float = 0.01,
    risk_aversion: float = 2.5
) -> Dict[str, Any]:
    """52. Wasserstein Distributionally Robust Optimization (DRO): min_w max_{P: W1(P, P_hat) <= eps} E_P[f(w, xi)]."""
    X = np.asarray(returns, dtype=float)
    T, N = X.shape
    mu = np.mean(X, axis=0)
    cov = np.cov(X, rowvar=False)
    
    # In Wasserstein DRO with L2 norm, worst-case expected return is mu - eps * ||w||_2
    def obj(w):
        w = np.asarray(w)
        port_ret = float(np.dot(w, mu))
        port_risk = float(w @ cov @ w)
        worst_case_ret = port_ret - epsilon * float(np.linalg.norm(w, 2))
        return -(worst_case_ret - 0.5 * risk_aversion * port_risk)
        
    cons = ({'type': 'eq', 'fun': lambda w: np.sum(w) - 1.0})
    bnds = tuple((0.0, 0.30) for _ in range(N))
    w0 = np.ones(N) / N
    
    res = minimize(obj, w0, method='SLSQP', bounds=bnds, constraints=cons)
    weights = res.x if res.success else w0
    return {
        "weights": weights,
        "worst_case_expected_return": float(np.dot(weights, mu) - epsilon * np.linalg.norm(weights, 2)),
        "portfolio_variance": float(weights @ cov @ weights)
    }


def hierarchical_risk_parity_dendrogram(cov: np.ndarray, linkage_method: str = "single") -> np.ndarray:
    """53. Hierarchical Risk Parity (HRP) Tree Dendrogram Clustering Matrix."""
    c = np.asarray(cov, dtype=float)
    vols = np.sqrt(np.diag(c))
    # AUDIT-FIX (Round 6, A2-P3-9): epsilon on only one factor made the
    # "correlation" asymmetric (corr[i,j] != corr[j,i]) and produced NaN
    # rows for zero-variance assets. Symmetric epsilon as at line 440.
    corr = c / (np.outer(vols, vols) + 1e-9)
    dist = np.sqrt(0.5 * (1.0 - np.clip(corr, -1.0, 1.0)))
    np.fill_diagonal(dist, 0.0)
    
    # Condensed distance matrix
    from scipy.spatial.distance import squareform
    condensed = squareform(dist, checks=False)
    Z = linkage(condensed, method=linkage_method)
    return Z


def black_litterman_posterior_expected_return(
    pi: np.ndarray,
    sigma: np.ndarray,
    p_views: np.ndarray,
    q_views: np.ndarray,
    omega_views: np.ndarray,
    tau: float = 0.05
) -> np.ndarray:
    """54. Black-Litterman Posterior Expected Return: mu_BL = [(tau*Sigma)^-1 + P^T Omega^-1 P]^-1 * [(tau*Sigma)^-1 Pi + P^T Omega^-1 Q]."""
    pi = np.asarray(pi, dtype=float)
    sigma = np.asarray(sigma, dtype=float)
    P = np.asarray(p_views, dtype=float)
    Q = np.asarray(q_views, dtype=float)
    Omega = np.asarray(omega_views, dtype=float)
    
    tau_sigma_inv = np.linalg.pinv(tau * sigma)
    omega_inv = np.linalg.pinv(Omega)
    
    middle_inv = np.linalg.pinv(tau_sigma_inv + P.T @ omega_inv @ P)
    rhs = tau_sigma_inv @ pi + P.T @ omega_inv @ Q
    mu_bl = middle_inv @ rhs
    return mu_bl


def black_litterman_posterior_covariance(
    sigma: np.ndarray,
    p_views: np.ndarray,
    omega_views: np.ndarray,
    tau: float = 0.05
) -> np.ndarray:
    """55. Black-Litterman Posterior Covariance: Sigma_BL = Sigma + [(tau*Sigma)^-1 + P^T Omega^-1 P]^-1."""
    sigma = np.asarray(sigma, dtype=float)
    P = np.asarray(p_views, dtype=float)
    Omega = np.asarray(omega_views, dtype=float)
    
    tau_sigma_inv = np.linalg.pinv(tau * sigma)
    omega_inv = np.linalg.pinv(Omega)
    middle_inv = np.linalg.pinv(tau_sigma_inv + P.T @ omega_inv @ P)
    sigma_bl = sigma + middle_inv
    return 0.5 * (sigma_bl + sigma_bl.T)


def equal_risk_contribution_solver(cov: np.ndarray, max_iter: int = 100, tol: float = 1e-6) -> np.ndarray:
    """56. Equal Risk Contribution (ERC / Risk Budgeting via Cyclical Coordinate Descent CCD)."""
    c = np.asarray(cov, dtype=float)
    N = c.shape[0]
    if N == 0:
        return np.array([])
    # CCD algorithm for ERC: x_i = (sqrt((c_ii * x_i)^2 + 4 * (1/N) * (c x)_i) - (c x)_i) / (2 * c_ii)
    x = np.ones(N) / np.sqrt(np.diag(c))
    for _ in range(max_iter):
        x_prev = x.copy()
        for i in range(N):
            c_i = c[i, :]
            # sigma_xi without i-th component
            c_x_no_i = np.dot(c_i, x) - c[i, i] * x[i]
            # Solve quadratic for x_i
            a = c[i, i]
            b = c_x_no_i
            root = np.sqrt(b**2 + 4.0 * a * (1.0 / N))
            x[i] = (root - b) / (2.0 * a)
        if np.max(np.abs(x - x_prev)) < tol:
            break
    w = x / np.sum(x)
    return w


def maximum_diversification_portfolio(cov: np.ndarray, vols: Optional[np.ndarray] = None) -> np.ndarray:
    """57. Maximum Diversification Portfolio (MDP): max_w (w^T sigma) / sqrt(w^T Cov w)."""
    c = np.asarray(cov, dtype=float)
    N = c.shape[0]
    if vols is None:
        vols = np.sqrt(np.diag(c))
    else:
        vols = np.asarray(vols, dtype=float)
        
    def obj(w):
        w = np.asarray(w)
        port_vol = np.sqrt(max(1e-9, w @ c @ w))
        weighted_vol = np.dot(w, vols)
        return -float(weighted_vol / port_vol)
        
    cons = ({'type': 'eq', 'fun': lambda w: np.sum(w) - 1.0})
    bnds = tuple((0.0, 1.0) for _ in range(N))
    w0 = np.ones(N) / N
    res = minimize(obj, w0, method='SLSQP', bounds=bnds, constraints=cons)
    return res.x if res.success else w0


def fractional_kelly_covariance(
    mu: np.ndarray,
    cov: np.ndarray,
    r_f: float = 0.06 / 252.0,
    kelly_fraction: float = 0.25
) -> np.ndarray:
    """58. Fractional Kelly Criterion with Covariance Uncertainty: w* = f_Kelly * Cov^-1 (mu - r_f).

    Round 16 upgrade: delegates the raw Kelly vector to
    math_engine.institutional.kelly_betting.multi_asset_kelly, which adds
    PD-repair shrinkage for degenerate covariance and an explicit
    long-only gross-leverage cap before the fractional overlay. The
    equal-weight fallback for zero-edge inputs is preserved (identical
    legacy behavior).
    """
    mu = np.asarray(mu, dtype=float)
    c = np.asarray(cov, dtype=float)
    excess_mu = mu - r_f
    if len(mu) == 0:
        return np.zeros(0)
    try:
        from math_engine.institutional.kelly_betting import multi_asset_kelly
        # multi_asset_kelly expects annualized-style inputs; period inputs
        # work identically — the function only uses relative scale.
        raw_kelly = multi_asset_kelly(excess_mu, c, risk_free=0.0, long_only=True)
        # multi_asset_kelly already caps gross leverage at 1.0; re-apply the
        # legacy normalization so the output remains a simplex weight.
    except Exception:
        cov_inv = np.linalg.pinv(c)
        raw_kelly = np.maximum(cov_inv @ excess_mu, 0.0)
    # Apply fractional sizing & long-only clipping
    w_kelly = kelly_fraction * np.maximum(raw_kelly, 0.0)
    sum_w = np.sum(w_kelly)
    if sum_w > 0:
        w_kelly /= sum_w
    else:
        w_kelly = np.ones(len(mu)) / len(mu)
    return w_kelly


def cvar_expected_shortfall_optimization(
    returns: Union[pd.DataFrame, np.ndarray],
    alpha: float = 0.95,
    max_weight: float = 0.30
) -> np.ndarray:
    """59. Conditional Value-at-Risk (CVaR / Expected Shortfall Optimization)."""
    X = np.asarray(returns, dtype=float)
    T, N = X.shape
    if T < 5:
        return np.ones(N) / N
        
    # Variables: w (size N), zeta (VaR threshold)
    def obj(params):
        w = params[:N]
        zeta = params[N]
        losses = -X @ w
        excess_losses = np.maximum(0.0, losses - zeta)
        cvar = zeta + (1.0 / ((1.0 - alpha) * T)) * np.sum(excess_losses)
        return float(cvar)
        
    cons = ({'type': 'eq', 'fun': lambda p: np.sum(p[:N]) - 1.0})
    bnds = [(0.0, max_weight) for _ in range(N)] + [(None, None)]
    p0 = np.append(np.ones(N) / N, 0.02)
    
    res = minimize(obj, p0, method='SLSQP', bounds=bnds, constraints=cons)
    return res.x[:N] if res.success else np.ones(N) / N


def cdar_conditional_drawdown_optimization(
    returns: Union[pd.DataFrame, np.ndarray],
    alpha: float = 0.95
) -> np.ndarray:
    """60. Conditional Drawdown at Risk (CDaR) Penalty Optimization."""
    X = np.asarray(returns, dtype=float)
    T, N = X.shape
    
    def obj(w):
        w = np.asarray(w)
        port_ret = X @ w
        cum_ret = np.cumsum(port_ret)
        peak = np.maximum.accumulate(cum_ret)
        drawdowns = peak - cum_ret
        # Top (1 - alpha) worst drawdowns average
        cutoff = np.percentile(drawdowns, alpha * 100)
        cdar = float(np.mean(drawdowns[drawdowns >= cutoff]))
        return cdar
        
    cons = ({'type': 'eq', 'fun': lambda w: np.sum(w) - 1.0})
    bnds = tuple((0.0, 0.30) for _ in range(N))
    w0 = np.ones(N) / N
    res = minimize(obj, w0, method='SLSQP', bounds=bnds, constraints=cons)
    return res.x if res.success else w0


def entropic_value_at_risk(returns: Union[pd.Series, np.ndarray], alpha: float = 0.95) -> float:
    """61. Entropic Value-at-Risk (EVaR): Tightest upper bound of VaR based on Chernoff bound."""
    r = np.asarray(returns, dtype=float)
    losses = -r
    
    def obj(z):
        # z > 0
        if z <= 1e-4:
            return 1e6
        # log moment generating function
        m = float(np.log(np.mean(np.exp(z * losses))))
        return (m - np.log(1.0 - alpha)) / z
        
    res = minimize(obj, 1.0, method='Nelder-Mead')
    return float(res.fun)


def sebi_category_constraints_enforcer(
    weights: Dict[str, float],
    market_caps: Dict[str, float],
    min_large_cap: float = 0.65,
    max_single: float = 0.10
) -> Dict[str, float]:
    """62. SEBI Regulatory Categorization Constraints: Sum_{LargeCap} w_i >= min_large_cap, w_i <= max_single.

    AUDIT-FIX (Round 6, A2-P2-3): the previous clip-then-renormalize voided
    `max_single` (repro: {A..D: 0.25} with max_single=0.10 → output 0.25
    each) and `market_caps` / `min_large_cap` were dead parameters — the
    documented large-cap floor was never implemented. Now: water-filling
    projection onto the capped simplex for max_single, plus a large-cap
    floor check that promotes the largest large-caps (or flags infeasibility
    by adding a CASH key) when the floor cannot be met."""
    w = dict(weights)
    if not w:
        return w
    # 1) max_single via bounded-simplex water-filling (reuse the compliance
    #    bisection projector for consistency).
    try:
        from optimizer_compliance import _project_weights_to_bounds as _proj
        _keys = list(w.keys())
        _vals = np.array([float(w[k]) for k in _keys])
        _proj_vals = _proj(_vals, lower=0.0, upper=float(max_single))
        w = {k: float(v) for k, v in zip(_keys, _proj_vals)}
    except Exception:
        # Module not importable in this context — local bisection fallback.
        _keys = list(w.keys())
        _vals = np.array([max(0.0, float(w[k])) for k in _keys])
        _lo, _hi = -_vals.max() - 1.0, float(max_single) - _vals.min() + 1.0
        for _ in range(80):
            _mid = 0.5 * (_lo + _hi)
            if float(np.clip(_vals + _mid, 0.0, max_single).sum()) < 1.0:
                _lo = _mid
            else:
                _hi = _mid
        w = {k: float(v) for k, v in zip(_keys, np.clip(_vals + 0.5 * (_lo + _hi), 0.0, max_single))}

    # 2) Large-cap floor: Sum_{LargeCap} w_i >= min_large_cap.
    _large = {k: v for k, v in w.items()
              if str(market_caps.get(k, "")).lower() in ("large", "large cap", "large-cap", "largecap")}
    _large_sum = float(sum(_large.values()))
    _total = float(sum(w.values()))
    if _large and 0.0 < _total and _large_sum / _total < float(min_large_cap) - 1e-9:
        _need = float(min_large_cap) * _total
        _cur = _large_sum
        # Promote the largest large-caps first, up to their max_single cap.
        _room = {k: float(max_single) - v for k, v in _large.items()}
        _deficit = _need - _cur
        for k in sorted(_room, key=_room.get, reverse=True):
            if _deficit <= 0:
                break
            _add = min(_room[k], _deficit)
            w[k] += _add
            _deficit -= _add
        if _deficit > 1e-6:
            # Infeasible with the current universe — park the shortfall in
            # CASH so the floor gap is visible instead of silently ignored.
            w["CASH"] = w.get("CASH", 0.0) + _deficit
    # Final renormalization is a no-op when the projection kept sum == 1.
    _tot = float(sum(w.values()))
    if _tot > 1e-9 and abs(_tot - 1.0) > 1e-9:
        _free = {k: v for k, v in w.items() if v < max_single - 1e-12 and k != "CASH"}
        if _free:
            _fs = sum(_free.values())
            for k in _free:
                w[k] = min(max_single, w[k] + (1.0 - _tot) * (w[k] / _fs))
    return w


def sector_concentration_cardinality_ceiling(
    weights: Dict[str, float],
    sectors: Dict[str, str],
    max_per_sector: int = 2
) -> Dict[str, float]:
    """63. Sector Concentration Cardinality Ceiling: Maximum active stocks allowed per sector."""
    w = dict(weights)
    sec_map = {}
    for s, weight in sorted(w.items(), key=lambda item: item[1], reverse=True):
        if weight > 0:
            sec = _norm_sec(sectors.get(s, "N/A"))
            sec_map.setdefault(sec, []).append(s)
            if len(sec_map[sec]) > max_per_sector:
                w[s] = 0.0
    tot = sum(w.values()) + 1e-9
    return {k: v / tot for k, v in w.items()}


def turnover_regularization_l1(
    weights: Dict[str, float],
    prev_weights: Dict[str, float],
    kappa: float = 0.01
) -> float:
    """64. Turnover Regularization (L1 Transaction Penalty): Penalty = kappa * Sum |w_{i,t} - w_{i,t-1}|."""
    all_keys = set(weights.keys()).union(prev_weights.keys())
    l1_turnover = sum(abs(weights.get(k, 0.0) - prev_weights.get(k, 0.0)) for k in all_keys)
    return float(kappa * l1_turnover)


def softmax_alpha_temperature_scaling(
    alphas: Union[pd.Series, np.ndarray, Dict[str, float]],
    temp_multiplier: float = 0.50
) -> Dict[str, float]:
    """65. Softmax Alpha-Proportional Temperature Scaling: w_i proportional to exp(alpha_i / (T * sigma_alpha))."""
    if isinstance(alphas, dict):
        keys = list(alphas.keys())
        vals = np.array(list(alphas.values()), dtype=float)
    else:
        keys = list(alphas.index) if hasattr(alphas, "index") else [f"A_{i}" for i in range(len(alphas))]
        vals = np.asarray(alphas, dtype=float)
        
    sigma = float(np.std(vals))
    T = max(sigma * temp_multiplier, 0.05)
    exp_vals = np.exp((vals - np.max(vals)) / T)
    weights = exp_vals / (np.sum(exp_vals) + 1e-9)
    return {k: float(w) for k, w in zip(keys, weights)}


class ConvexMeanCVaRSolver:
    """
    Tier-1 Rockafellar-Uryasev Convex Mean-CVaR Optimization Solver.
    Minimizes Expected Shortfall (CVaR at alpha=99%) while targeting pure factor alpha.
    """

    @staticmethod
    def solve(
        returns_matrix: np.ndarray,
        alpha_scores: np.ndarray,
        cvar_alpha: float = 0.99,
        risk_aversion: float = 2.0,
        min_weight: float = 0.04,
        max_weight: float = 0.20
    ) -> np.ndarray:
        """
        Solves: min_{w, gamma} [ gamma + (1/(T*(1-alpha))) sum_t [ -w^T r_t - gamma ]^+ - lambda * w^T alpha ]
        Subject to: sum w_i = 1, min_weight <= w_i <= max_weight.
        """
        R = np.asarray(returns_matrix, dtype=float)
        if R.ndim != 2 or R.shape[0] < 5:
            # Uniform fallback
            n = len(alpha_scores)
            return np.ones(n) / max(n, 1)

        T, N = R.shape
        mu_alpha = np.asarray(alpha_scores, dtype=float)
        
        # Initial guess: w0 = softmax(alpha), gamma0 = VaR estimate
        exp_a = np.exp(mu_alpha - np.max(mu_alpha))
        w0 = exp_a / exp_a.sum()
        # AUDIT-FIX (Round 6, A2-P3-79): keep the equal-clip start point (it
        # only feeds the optimizer start; the OUTPUT projection is bounded).
        
        port_losses = -R @ w0
        gamma0 = float(np.percentile(port_losses, cvar_alpha * 100))
        x0 = np.append(w0, gamma0)

        # Objective function (w in [0:N], gamma = x[-1])
        def cvar_objective(x):
            w = x[:N]
            gamma = x[-1]
            losses = -R @ w
            excess_loss = np.maximum(losses - gamma, 0.0)
            cvar = gamma + (1.0 / (T * (1.0 - cvar_alpha))) * np.sum(excess_loss)
            alpha_term = risk_aversion * np.dot(w, mu_alpha)
            return float(cvar - alpha_term)

        # Constraints & Bounds
        cons = [{'type': 'eq', 'fun': lambda x: np.sum(x[:N]) - 1.0}]
        bounds = [(min_weight, max_weight) for _ in range(N)] + [(None, None)]

        try:
            res = minimize(cvar_objective, x0, method='SLSQP', bounds=bounds, constraints=cons, options={'maxiter': 100})
            if res.success:
                opt_w = res.x[:N]
                # AUDIT-FIX (Round 6, A2-P3-79): bounded-simplex projection
                # (clip-renorm re-inflated weights above max_weight).
                try:
                    from optimizer_compliance import _project_weights_to_bounds as _cvp
                    return _cvp(opt_w, lower=float(min_weight), upper=float(max_weight))
                except Exception:
                    opt_w = np.clip(opt_w, min_weight, max_weight)
                    return opt_w / opt_w.sum()
        except Exception as e:
            logger.debug(f"Convex Mean-CVaR solver SLSQP fallback: {e}", exc_info=True)

        # w0 projection (was clipped then renormalized — same re-inflation)
        try:
            from optimizer_compliance import _project_weights_to_bounds as _cvp
            return _cvp(w0, lower=float(min_weight), upper=float(max_weight))
        except Exception:
            return w0


class HERCRiskAllocator:
    """
    Hierarchical Equal Risk Contribution (HERC) using Machine Learning Dendrogram Clustering.
    Allocates risk recursively across cluster dendrograms to prevent correlation crowding.
    """

    @staticmethod
    def allocate(
        cov_matrix: np.ndarray,
        min_weight: float = 0.04,
        max_weight: float = 0.20
    ) -> np.ndarray:
        N = cov_matrix.shape[0]
        if N <= 1:
            return np.ones(N)

        # 1. Distance matrix from correlation
        vols = np.sqrt(np.diag(cov_matrix))
        corr = cov_matrix / (np.outer(vols, vols) + 1e-8)
        dist = np.sqrt(0.5 * (1.0 - np.clip(corr, -1.0, 1.0)))

        # 2. Hierarchical Linkage Tree
        try:
            from scipy.spatial.distance import squareform
            from scipy.cluster.hierarchy import linkage, leaves_list
            condensed_dist = squareform(dist, checks=False)
            link = linkage(condensed_dist, method='ward')

            # AUDIT-FIX (Round 6, A2-P3-79): the linkage tree was computed and
            # then IGNORED — bisection split `list(range(N))` by raw index,
            # so "clusters" were arbitrary asset ordering (not dendrogram
            # structure). Use the actual leaf order and map positions → asset
            # indices when computing sub-cluster variances (same fix as
            # math_engine/institutional/herc.py A3-P2-3).
            order = list(leaves_list(link))
            
            # 3. Recursive Bisection Risk Budgeting
            weights = np.ones(N)
            clusters = [list(range(N))]  # positions in `order`
            
            while len(clusters) > 0:
                new_clusters = []
                for cl in clusters:
                    if len(cl) > 1:
                        c1 = cl[:len(cl)//2]
                        c2 = cl[len(cl)//2:]
                        
                        # Cluster variance (map positions → asset indices)
                        a1 = [order[i] for i in c1]
                        a2 = [order[i] for i in c2]
                        cov1 = cov_matrix[np.ix_(a1, a1)]
                        cov2 = cov_matrix[np.ix_(a2, a2)]
                        
                        v1 = np.ones(len(c1)) @ cov1 @ np.ones(len(c1)) / (len(c1)**2)
                        v2 = np.ones(len(c2)) @ cov2 @ np.ones(len(c2)) / (len(c2)**2)
                        
                        alpha1 = 1.0 - v1 / (v1 + v2 + 1e-8)
                        alpha2 = 1.0 - alpha1
                        
                        # AUDIT-FIX (Round 6, A2-P3-79): map positions → assets
                        # (previously the raw positions indexed weights, which
                        # coincidentally worked for identity orders only).
                        for i in c1: weights[order[i]] *= alpha1
                        for i in c2: weights[order[i]] *= alpha2
                        
                        if len(c1) > 1: new_clusters.append(c1)
                        if len(c2) > 1: new_clusters.append(c2)
                clusters = new_clusters
                
            # AUDIT-FIX (Round 6, A2-P3-79): clip-then-renormalize re-inflated
            # capped entries above max_weight (repro: N=4 → 0.61 vs cap 0.20).
            # Bounded bisection projection onto the capped simplex instead.
            try:
                from optimizer_compliance import _project_weights_to_bounds as _rbp
                return _rbp(weights, lower=float(min_weight), upper=float(max_weight))
            except Exception:
                _w = np.clip(weights, min_weight, max_weight)
                _lo, _hi = min_weight - 1.0, max_weight + 1.0
                for _ in range(80):
                    _mid = 0.5 * (_lo + _hi)
                    if float(np.clip(_w + _mid, min_weight, max_weight).sum()) < 1.0:
                        _lo = _mid
                    else:
                        _hi = _mid
                return np.clip(_w + 0.5 * (_lo + _hi), min_weight, max_weight)
        except Exception as e:
            logger.debug(f"HERC allocation fallback: {e}", exc_info=True)
            inv_vol = 1.0 / (vols + 1e-8)
            w = inv_vol / inv_vol.sum()
            # bounded projection for the fallback path too
            try:
                from optimizer_compliance import _project_weights_to_bounds as _rbp
                return _rbp(w, lower=float(min_weight), upper=float(max_weight))
            except Exception:
                w = np.clip(w, min_weight, max_weight)
                return w / w.sum()

