"""
math_engine/signal_robust_scaler.py
===================================
Robust Alpha Factor Signal Winsorization & Z-Score Scaling Engine.

Standardizes, winsorizes, and scales cross-sectional alpha factors into 
uniform rank-normalized signal distributions for portfolio optimization input.
"""

from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, Tuple
from scipy.stats import rankdata

logger = logging.getLogger(__name__)


class SignalRobustScaler:
    """
    Robust Factor Signal Normalization Engine.
    Cleans, winsorizes outliers via MAD, and normalizes alpha signals.
    """

    @staticmethod
    def winsorize_zscore_signal(
        series: pd.Series | np.ndarray,
        limits: Tuple[float, float] = (0.02, 0.02),
        z_cap: float = 3.0
    ) -> np.ndarray:
        """
        Winsorizes extreme outliers at percentile limits and computes robust Z-score:
        Z = (X - Median) / (1.4826 * MAD)
        Caps resulting Z-score at +/- z_cap.
        """
        vals = np.asarray(series, dtype=float).copy()
        mask = np.isnan(vals)
        valid = vals[~mask]

        if len(valid) < 5:
            return np.zeros_like(vals)

        # Percentile winsorization
        lower_val = np.percentile(valid, limits[0] * 100)
        upper_val = np.percentile(valid, (1.0 - limits[1]) * 100)
        valid_clipped = np.clip(valid, lower_val, upper_val)

        # Robust Z-score via Median Absolute Deviation (MAD)
        med = np.median(valid_clipped)
        mad = np.median(np.abs(valid_clipped - med))
        scale = 1.4826 * mad if mad > 1e-9 else (np.std(valid_clipped) + 1e-6)

        z_scores = np.clip((valid_clipped - med) / scale, -z_cap, z_cap)
        
        result = np.zeros_like(vals)
        result[~mask] = z_scores
        return result

    @classmethod
    def rank_normalize_factors(
        cls,
        factor_matrix: pd.DataFrame
    ) -> pd.DataFrame:
        """
        Converts raw multi-factor metrics to uniform percentile ranks in [-1, +1].
        """
        df_ranked = factor_matrix.copy()
        for col in df_ranked.columns:
            vals = df_ranked[col].values
            valid_mask = ~np.isnan(vals)
            if np.sum(valid_mask) > 1:
                ranks = rankdata(vals[valid_mask]) / float(np.sum(valid_mask))
                # Map [0, 1] to [-1, 1]
                df_ranked.loc[valid_mask, col] = (ranks - 0.5) * 2.0
        return df_ranked


# Backward-compatible alias
SignalTaxonomyCompiler = SignalRobustScaler
