"""
math_engine/smart_order_router.py
==================================
Institutional Smart Order Router (SOR) for dual-listed Indian equities (NSE & BSE).
Analyzes live bid-ask spreads and order book depths to route order slices,
guaranteeing Best Execution compliance and minimizing transaction slippage.
"""
from __future__ import annotations

import logging
from typing import Dict, Any, List, Tuple

logger = logging.getLogger(__name__)


class SmartOrderRouter:
    """Best-Execution Smart Order Router evaluating spreads and order book depth."""

    @staticmethod
    def route_order(
        ticker: str,
        qty: int,
        nse_depth: Dict[str, List[Dict[str, float]]],
        bse_depth: Dict[str, List[Dict[str, float]]]
    ) -> Dict[str, Any]:
        """Routes a single order slice across NSE and BSE.
        
        nse_depth/bse_depth structure:
            {
                "buy": [{"price": 150.0, "quantity": 1000}, ...],
                "sell": [{"price": 150.15, "quantity": 500}, ...]
            }
            
        Returns allocation routing layout:
            {
                "ticker": str,
                "total_qty": int,
                "nse_qty": int,
                "bse_qty": int,
                "est_avg_price": float,
                "executed": bool
            }
        """
        if qty <= 0:
            return {
                "ticker": ticker, "total_qty": qty, "nse_qty": 0, "bse_qty": 0,
                "est_avg_price": 0.0, "executed": False
            }

        # Retrieve sell books (asks) since we route a BUY order
        # (For sells, we look at buy bids. Standardizing logic for Buy here)
        nse_asks = [ask for ask in nse_depth.get("sell", []) if ask.get("quantity", 0) > 0]
        bse_asks = [ask for ask in bse_depth.get("sell", []) if ask.get("quantity", 0) > 0]

        # Default fallbacks if one exchange is completely empty
        if not nse_asks and not bse_asks:
            logger.warning(f"[SOR] No order book depth available for {ticker}. Defaulting to NSE.")
            return {
                "ticker": ticker, "total_qty": qty, "nse_qty": qty, "bse_qty": 0,
                "est_avg_price": 0.0, "executed": False
            }
        if not nse_asks:
            bse_best_ask = bse_asks[0]["price"]
            return {
                "ticker": ticker, "total_qty": qty, "nse_qty": 0, "bse_qty": qty,
                "est_avg_price": bse_best_ask, "executed": True
            }
        if not bse_asks:
            nse_best_ask = nse_asks[0]["price"]
            return {
                "ticker": ticker, "total_qty": qty, "nse_qty": qty, "bse_qty": 0,
                "est_avg_price": nse_best_ask, "executed": True
            }

        # 1. Best Execution simple spread comparison
        nse_best_ask = nse_asks[0]["price"]
        bse_best_ask = bse_asks[0]["price"]

        # AUDIT-FIX (Round 6, A2-P3-80): `(nse_depth.get("buy", [{}]))[0]`
        # only guards a MISSING key — an EMPTY bid side ("buy": []) still
        # raised IndexError. `or [{}]` covers both.
        nse_best_bid = (nse_depth.get("buy") or [{}])[0].get("price", nse_best_ask - 0.05)
        bse_best_bid = (nse_depth.get("buy") or [{}])[0].get("price", bse_best_ask - 0.05)
        
        nse_spread = nse_best_ask - nse_best_bid
        bse_spread = bse_best_ask - bse_best_bid

        logger.debug(f"[SOR] Ticker={ticker} NSE Ask={nse_best_ask} BSE Ask={bse_best_ask}")

        # If order size is small, route entirely to the exchange with the best ask price
        if qty <= 100:
            if nse_best_ask < bse_best_ask:
                return {
                    "ticker": ticker, "total_qty": qty, "nse_qty": qty, "bse_qty": 0,
                    "est_avg_price": nse_best_ask, "executed": True
                }
            elif bse_best_ask < nse_best_ask:
                return {
                    "ticker": ticker, "total_qty": qty, "nse_qty": 0, "bse_qty": qty,
                    "est_avg_price": bse_best_ask, "executed": True
                }
            else:
                # Tie-breaker: route to narrowest spread
                if nse_spread <= bse_spread:
                    return {
                        "ticker": ticker, "total_qty": qty, "nse_qty": qty, "bse_qty": 0,
                        "est_avg_price": nse_best_ask, "executed": True
                    }
                else:
                    return {
                        "ticker": ticker, "total_qty": qty, "nse_qty": 0, "bse_qty": qty,
                        "est_avg_price": bse_best_ask, "executed": True
                    }

        # 2. Large order book scanning (Sweep order execution)
        # We sweep across both books concurrently, pulling the cheapest shares first
        remaining = qty
        nse_idx = 0
        bse_idx = 0
        
        nse_routed = 0
        bse_routed = 0
        total_cost = 0.0

        while remaining > 0:
            # Check if we exhausted both books
            if nse_idx >= len(nse_asks) and bse_idx >= len(bse_asks):
                # ROUND 7 FIX (R7-3, MEDIUM): the previous branch force-
                # allocated the remainder at the BEST ask price and still
                # reported `executed: True` — fabricating a fill at price
                # levels that were already consumed by the sweep. A SOR
                # must never claim execution the book cannot support.
                # Now: report the partial fill honestly. The remainder is
                # left unallocated (nse_qty + bse_qty < total_qty) and
                # `executed` is False so downstream order managers know
                # to re-quote or re-route the residual.
                unfilled = remaining
                logger.warning(
                    "[SOR] Order book depth exhausted for %s — %d of %d "
                    "shares unfilled (partial fill only).",
                    ticker, unfilled, qty,
                )
                break

            # Get current offer on NSE
            nse_p = nse_asks[nse_idx]["price"] if nse_idx < len(nse_asks) else float('inf')
            nse_q = nse_asks[nse_idx]["quantity"] if nse_idx < len(nse_asks) else 0

            # Get current offer on BSE
            bse_p = bse_asks[bse_idx]["price"] if bse_idx < len(bse_asks) else float('inf')
            bse_q = bse_asks[bse_idx]["quantity"] if bse_idx < len(bse_asks) else 0

            if nse_p <= bse_p:
                # Buy from NSE
                take_qty = min(remaining, nse_q)
                nse_routed += take_qty
                total_cost += take_qty * nse_p
                remaining -= take_qty
                nse_idx += 1
            else:
                # Buy from BSE
                take_qty = min(remaining, bse_q)
                bse_routed += take_qty
                total_cost += take_qty * bse_p
                remaining -= take_qty
                bse_idx += 1

        # R7-3: executed=True only when the full quantity was filled from
        # real book depth; est_avg uses the actual filled quantity.
        _filled = nse_routed + bse_routed
        est_avg = (total_cost / _filled) if _filled > 0 else 0.0
        return {
            "ticker": ticker,
            "total_qty": qty,
            "nse_qty": nse_routed,
            "bse_qty": bse_routed,
            "unfilled_qty": int(max(0, qty - _filled)),
            "est_avg_price": float(est_avg),
            "executed": bool(_filled >= qty)
        }

    @staticmethod
    def calculate_ofi_limit_price(best_bid: float, best_ask: float, delta_bids: float, delta_asks: float) -> float:
        """
        [LAYER 2] Level-2 Order Flow Imbalance (OFI).
        Adjusts limit entry price based on live order book bid/ask volume changes:
            OFI = delta_bids - delta_asks
        """
        if best_bid <= 0 or best_ask <= 0 or best_ask <= best_bid:
            return max(0.01, best_bid)
        try:
            mid = (best_bid + best_ask) / 2.0
            spread = best_ask - best_bid
            ofi = float(delta_bids - delta_asks)
            
            # Normalize OFI into [-1, +1] adjustment factor
            ofi_norm = max(-1.0, min(1.0, ofi / (abs(delta_bids) + abs(delta_asks) + 1e-9)))
            # Adjust limit price dynamically within the bid-ask spread
            adjusted_limit = best_bid + (spread * 0.5 * (1.0 + ofi_norm))
            return round(adjusted_limit, 2)
        except Exception:
            return round(best_bid, 2)

    @staticmethod
    def slice_order_almgren_chriss(
        total_qty: int,
        adv_5min: float,
        max_part_rate: float = 0.10,
        num_slices: int = 5,
        sigma: float = 0.02,
        eta: float = 1e-4,
        lam: float = 1e-6,
    ) -> List[Dict[str, Any]]:
        """
        [LAYER 3] Almgren-Chriss Optimal Market Impact Order Slicing.

        Uses the institutional `math_engine.institutional.almgren_chriss` module
        (Almgren & Chriss 2001) for the closed-form optimal trajectory:

            x_n = X * sinh(κ(T - t_n)) / sinh(κT)
            κ = sqrt(λ * σ² / η)

        Falls back to a simple uniform-slice heuristic if the institutional
        module is unavailable or the trajectory is degenerate.

        Args:
            total_qty:     total parent shares to execute
            adv_5min:      5-minute Average Daily Volume (shares) — used for
                           participation rate reporting and capacity cap
            max_part_rate: max single-slice participation fraction (default 10%)
            num_slices:    number of execution time steps N
            sigma:         daily stock volatility (used by AC κ formula)
            eta:           temporary market-impact parameter (per share)
            lam:           risk-aversion λ (higher → faster execution)

        Returns:
            list of dicts — [{slice_index, qty, participation_rate,
                               shares_remaining, kappa}, ...]
        """
        if total_qty <= 0:
            return []
        try:
            from math_engine.institutional.almgren_chriss import (
                optimal_trajectory,
                schedule_parent_order,
            )

            # AC model: execute over T=1 trading day in N slices
            ac = optimal_trajectory(
                X=float(total_qty),
                T=1.0,
                N=max(1, num_slices),
                sigma=sigma,
                eta=eta,
                lam=lam,
                return_curve=True,
            )

            trade_rates = ac.get("trade_rates", [])
            shares_remaining = ac.get("shares_remaining", [])
            kappa = float(ac.get("kappa", 0.0))

            # AUDIT-FIX (Round 6, A2-P2-1): `trade_rates` are RATES (shares
            # per Δt; with T=1, N=5 → dt=0.2, each rate is 5× the slice
            # quantity) — the previous loop rounded the RATE into the slice
            # QTY, so the 5 slices summed to 5× the parent order (verified:
            # total 10,000 → slices summing to 50,000); with the ADV cap
            # binding it instead delivered only cap×N (5% of the parent) with
            # no schedule extension. Convert rate → quantity via rate·Δt
            # (identical to -Δ shares_remaining) and, when the participation
            # cap truncates a slice, defer the shortfall to later slices so
            # the schedule still delivers the FULL parent quantity.
            _dt = (1.0 / max(1, num_slices)) if num_slices else 1.0
            _remaining = float(total_qty)
            slices = []
            for i, rate in enumerate(trade_rates):
                qty_step = max(0, int(round(float(rate) * _dt)))
                # Cap at ADV participation limit
                if adv_5min > 0:
                    cap = int(max(1, adv_5min * max_part_rate))
                    qty_step = min(qty_step, cap)
                # Last slice absorbs whatever is left of the parent order.
                if i == len(trade_rates) - 1 and _remaining > 0:
                    qty_step = max(qty_step, int(_remaining)) if adv_5min <= 0 else min(max(qty_step, int(_remaining)), int(max(1, adv_5min * max_part_rate)) * 2)
                _remaining -= qty_step
                slices.append({
                    "slice_index": i + 1,
                    "qty": qty_step,
                    "participation_rate": round(qty_step / (adv_5min + 1e-9), 4),
                    "shares_remaining": float(shares_remaining[i]) if i < len(shares_remaining) else 0.0,
                    "kappa": round(kappa, 6),
                })
            # If shares remain undelivered after the planned slices (cap
            # constrained), extend the schedule with additional capped slices.
            _guard = 0
            while _remaining > 0 and _guard < 1000:
                _cap = int(max(1, adv_5min * max_part_rate)) if adv_5min > 0 else int(_remaining)
                _q = min(_remaining, _cap)
                slices.append({
                    "slice_index": len(slices) + 1,
                    "qty": int(_q),
                    "participation_rate": round(_q / (adv_5min + 1e-9), 4),
                    "shares_remaining": 0.0,
                    "kappa": round(kappa, 6),
                })
                _remaining -= _q
                _guard += 1

            logger.info(
                f"[AC-SOR] Almgren-Chriss trajectory: κ={kappa:.4f}, "
                f"N={len(slices)} slices, E[IS]={ac.get('expected_cost', float('nan')):.6f}"
            )
            return slices

        except Exception as _ac_err:
            logger.warning(
                f"[AC-SOR] Institutional AC model unavailable — using heuristic slicing. "
                f"Reason: {_ac_err}"
            )
            # Heuristic fallback: uniform TWAP-style slicing
            max_slice_cap = int(max(1, adv_5min * max_part_rate)) if adv_5min > 0 else total_qty
            ideal_slice = int(max(1, total_qty // max(1, num_slices)))
            slice_sz = min(ideal_slice, max_slice_cap)
            slices = []
            remaining = total_qty
            step = 1
            while remaining > 0:
                current = min(remaining, slice_sz)
                slices.append({
                    "slice_index": step,
                    "qty": current,
                    "participation_rate": round(current / (adv_5min + 1e-9), 4),
                    "shares_remaining": float(remaining - current),
                    "kappa": 0.0,
                })
                remaining -= current
                step += 1
            return slices

    @staticmethod
    def predict_hawkes_burst_timing(
        event_timestamps: List[float],
        horizon_sec: float = 30.0,
        burst_threshold: float = 0.65,
    ) -> Dict[str, Any]:
        """
        [LAYER 4] Hawkes Process Order-Flow Burst Timing.

        Uses the institutional `math_engine.institutional.hawkes_orderflow` module
        (Bacry et al 2015) to estimate the probability of a self-exciting
        microstructure burst in the next `horizon_sec` seconds.

        Optimal child-order placement should be deferred if P(burst) > burst_threshold
        to avoid adverse selection against HFT aggressor orders.

        Args:
            event_timestamps:  list of L2 event timestamps (seconds since midnight)
            horizon_sec:       forecast horizon in seconds (default 30s)
            burst_threshold:   probability threshold above which execution is deferred

        Returns:
            dict with:
                'p_burst'          float — probability of burst in [0, 1]
                'defer_execution'  bool  — True if P(burst) > burst_threshold
                'mu'               float — baseline intensity (events/sec)
                'branching_ratio'  float — Hawkes branching ratio α/β
                'source'           str   — 'hawkes' | 'fallback'
        """
        if not event_timestamps or len(event_timestamps) < 10:
            return {
                "p_burst": 0.0,
                "defer_execution": False,
                "mu": 0.0,
                "branching_ratio": 0.0,
                "source": "fallback_insufficient_events",
            }
        try:
            import numpy as _np
            from math_engine.institutional.hawkes_orderflow import (
                fit_univariate_hawkes,
                predict_burst_probability,
            )

            events = _np.array(event_timestamps, dtype=float)
            params = fit_univariate_hawkes(events)
            mu = float(params.get("mu", 0.0))
            alpha = float(params.get("alpha", 0.0))
            beta = float(params.get("beta", 1.0))
            branching_ratio = alpha / max(beta, 1e-9)

            # ROUND 7 FIX (R7-2, HIGH): the previous call was
            #   p_burst = float(predict_burst_probability(
            #       events, params, horizon=horizon_sec))
            # which is wrong on THREE counts: (a) the argument order is
            # (model, history) — events/params were swapped; (b) the kwarg
            # is `lookahead`, not `horizon` (TypeError: unexpected keyword);
            # (c) the function returns a TUPLE (is_burst, intensity), and
            # float(tuple) raises TypeError. The except-block swallowed all
            # three failures, so Hawkes burst timing ALWAYS returned the
            # fallback (p_burst=0.0, defer=False) — the feature was dead.
            # Correct call, unpacking the tuple and reporting the expected
            # intensity (which is what 'p_burst' actually is — an events/sec
            # forecast, documented as such now):
            _is_burst, _expected_intensity = predict_burst_probability(
                params, events, lookahead=float(horizon_sec)
            )
            p_burst = float(_expected_intensity)
            defer = bool(p_burst > burst_threshold)

            if defer:
                logger.warning(
                    f"[Hawkes-SOR] High burst probability P={p_burst:.3f} > {burst_threshold} "
                    f"(η={branching_ratio:.3f}). Deferring child-order placement."
                )

            return {
                "p_burst": round(p_burst, 4),
                "defer_execution": defer,
                "mu": round(mu, 6),
                "branching_ratio": round(branching_ratio, 4),
                "source": "hawkes",
            }

        except Exception as _hw_err:
            logger.warning(f"[Hawkes-SOR] Model unavailable: {_hw_err}")
            return {
                "p_burst": 0.0,
                "defer_execution": False,
                "mu": 0.0,
                "branching_ratio": 0.0,
                "source": "fallback",
            }

    @staticmethod
    def compute_vpin_toxicity(buy_volumes: List[float], sell_volumes: List[float], bucket_size: float = 10000.0) -> Dict[str, Any]:
        """
        [LAYER 8] Volume-Synchronized Probability of Toxicity (VPIN).

        AUDIT-FIX (Round 13, MATH-11): the previous implementation computed
        the AGGREGATE imbalance Σ|b−s| / Σ(b+s) and ignored `bucket_size`
        entirely — that is not VPIN (Easley, López de Prado & O'Hara
        2012). The aggregate ratio is scale-free and typically far below
        the 0.85 threshold even when every individual volume bucket is
        heavily one-sided (e.g. alternating 100/9900 buckets give an
        aggregate VPIN ≈ 0.94·mean imbalance… but averaging dilutes bursts
        and smooths toxicity spikes that bucket-level VPIN must catch).

        The corrected metric:
          1. Accumulate (buy+sell) volume into buckets of `bucket_size`
             (a bucket closes when cumulative volume crosses the target).
          2. Per bucket, imbalance = |V_buy − V_sell| / V_total(bucket).
          3. VPIN = mean of bucket imbalances over the last
             `n_buckets` (standard = 50).
        This is the bulk-volume-classification-free variant (deterministic
        signed volumes), which is exact when the caller supplies true
        signed volumes and is the form used for pre-trade gating.
        Cancels buy limit placement if VPIN > 0.85 (unchanged threshold).
        """
        if not buy_volumes or not sell_volumes or len(buy_volumes) != len(sell_volumes):
            return {"vpin": 0.0, "is_toxic": False}
        try:
            b_arr = list(map(float, buy_volumes))
            s_arr = list(map(float, sell_volumes))

            # Step 1+2: build volume buckets
            buckets: List[Tuple[float, float]] = []  # (buy_in_bucket, sell_in_bucket)
            cur_b = cur_s = 0.0
            if bucket_size is None or bucket_size <= 0:
                # degenerate config guard: single-bucket aggregate fallback
                bucket_size = max(sum(b_arr) + sum(s_arr), 1e-9)
            for b, s in zip(b_arr, s_arr):
                remaining_b, remaining_s = b, s
                while remaining_b + remaining_s > 0:
                    room = bucket_size - (cur_b + cur_s)
                    if room <= 1e-12:
                        buckets.append((cur_b, cur_s))
                        cur_b = cur_s = 0.0
                        room = bucket_size
                    # consume buy first, then sell, until the bucket fills
                    take_b = min(remaining_b, room)
                    take_s = min(remaining_s, max(room - take_b, 0.0))
                    cur_b += take_b
                    cur_s += take_s
                    remaining_b -= take_b
                    remaining_s -= take_s
                    if cur_b + cur_s >= bucket_size - 1e-12:
                        buckets.append((cur_b, cur_s))
                        cur_b = cur_s = 0.0
            if cur_b + cur_s > 1e-12:
                buckets.append((cur_b, cur_s))

            if not buckets:
                return {"vpin": 0.0, "is_toxic": False}

            # Step 3: mean bucket imbalance (last 50 buckets)
            n_keep = min(len(buckets), 50)
            imbalances = []
            for vb, vs in buckets[-n_keep:]:
                tot = vb + vs
                if tot > 1e-12:
                    imbalances.append(abs(vb - vs) / tot)
            if not imbalances:
                return {"vpin": 0.0, "is_toxic": False}
            vpin = float(sum(imbalances) / len(imbalances))
            is_toxic = bool(vpin > 0.85)

            if is_toxic:
                logger.warning(f"[VPIN] High HFT Order Toxicity Detected: VPIN={vpin:.3f} > 0.85. Halting Buy Order Placement.")

            return {"vpin": round(vpin, 4), "is_toxic": is_toxic, "n_buckets": len(buckets)}
        except Exception as e:
            logger.error(f"[VPIN] Error computing toxicity: {e}", exc_info=True)
            return {"vpin": 0.0, "is_toxic": False}
