"""
math_engine/solver_coordinator.py
==================================
Institutional Solver Coordinator supporting commercial solvers (Gurobi, CPLEX, Mosek).
Structures Mixed-Integer Programming (MIP) cardinality constraints and warm starts
with rank-heuristic fallbacks for open-source convex solvers.
"""
from __future__ import annotations

import logging
from typing import Dict, Any, List, Optional, Tuple
import numpy as np
import pandas as pd
import cvxpy as cp

logger = logging.getLogger(__name__)


class SolverCoordinator:
    """Selects the best available solver and structures MIP cardinality problems."""

    @staticmethod
    def get_best_solver(is_mip: bool = False) -> Tuple[str, bool]:
        """Detect and return the highest priority solver available.
        
        Priorities:
            MIP = True:  GUROBI > CPLEX > MOSEK > GLPK_MI > None (Fallback to heuristic)
            MIP = False: GUROBI > CPLEX > MOSEK > CLARABEL > ECOS > SCS
            
        Returns:
            Tuple[solver_name, supports_mip]
        """
        installed = cp.installed_solvers()
        
        if is_mip:
            if "GUROBI" in installed:
                return "GUROBI", True
            if "CPLEX" in installed:
                return "CPLEX", True
            if "MOSEK" in installed:
                return "MOSEK", True
            if "GLPK_MI" in installed:
                return "GLPK_MI", True
            # No MIP solver available in environment
            return "CLARABEL", False
        else:
            if "GUROBI" in installed:
                return "GUROBI", True
            if "CPLEX" in installed:
                return "CPLEX", True
            if "MOSEK" in installed:
                return "MOSEK", True
            if "CLARABEL" in installed:
                return "CLARABEL", False
            if "ECOS" in installed:
                return "ECOS", False
            return "SCS", False

    @classmethod
    def solve_portfolio_optimization(
        self,
        mu: np.ndarray,
        cov: np.ndarray,
        assets: List[str],
        min_weight: float = 0.0,
        max_weight: float = 0.40,
        max_assets: Optional[int] = None,
        w_prev: Optional[np.ndarray] = None,
        tc_bps: Optional[np.ndarray] = None,
        epsilon: float = 0.0,
        gamma: float = 0.5
    ) -> Dict[str, float]:
        """Formulate and solve portfolio optimization.
        
        Solves Wasserstein Distributionally Robust Optimization (DRO):
            minimize  w^T * cov * w - mu^T * w + epsilon * ||w||_2 + TC_term
            subject to  w >= min_weight
                        w <= max_weight
                        sum(w) == 1
                        cardinality(w) <= max_assets (if set)
        """
        n = len(assets)
        if n == 0:
            return {}

        # 1. Determine Solver & MIP requirements
        use_mip = (max_assets is not None) and (max_assets < n)
        solver_name, supports_mip = self.get_best_solver(is_mip=use_mip)
        
        logger.info(f"[SolverCoordinator] Selected solver: {solver_name} (MIP support: {supports_mip})")

        # 2. Heuristic fallback if cardinality requested but no MIP solver present
        active_mask = np.ones(n, dtype=bool)
        if use_mip and not supports_mip:
            # Rank heuristic fallback: calculate raw asset utility scores
            # Utility = Expected Return - 0.5 * Volatility
            diag_vol = np.sqrt(np.diag(cov))
            scores = mu - 0.5 * diag_vol
            # Select top max_assets
            top_indices = np.argsort(scores)[::-1][:max_assets]
            active_mask = np.zeros(n, dtype=bool)
            active_mask[top_indices] = True
            logger.warning(
                f"[SolverCoordinator] Card limit ({max_assets}) requested but no MIP solver available. "
                f"Activated rank heuristic, restricting optimization to assets: "
                f"{[assets[i] for i in top_indices]}"
            )
            # Disable MIP formulation since we forced non-selected asset weights to 0
            use_mip = False

        # 3. Formulate Optimization variables
        w = cp.Variable(n)
        
        # Constraints list
        constraints = [
            cp.sum(w) == 1.0
        ]

        # Apply bounds (restricting inactive assets to 0 under the rank heuristic)
        for i in range(n):
            if not active_mask[i]:
                constraints.append(w[i] == 0.0)
            else:
                constraints.append(w[i] >= min_weight)
                constraints.append(w[i] <= max_weight)

        # 4. Mixed-Integer formulation (if MIP solver is present)
        if use_mip and supports_mip:
            # Introduce binary selection variables z_i ∈ {0, 1}
            z = cp.Variable(n, boolean=True)
            constraints.append(cp.sum(z) <= max_assets)
            for i in range(n):
                constraints.append(w[i] <= z[i] * max_weight)

        # 5. Objective function
        # Portfolio Variance term: w^T * Cov * w
        risk_term = cp.quad_form(w, cov)
        # Expected Return term: mu^T * w
        return_term = mu @ w
        # Uncertainty robust penalty (Wasserstein DRO radius penalty): epsilon * ||w||_2
        robust_term = epsilon * cp.norm(w, 2)
        
        # Transaction cost term: sum( tc_i * |w_i - w_prev_i| )
        tc_term = 0.0
        if w_prev is not None and tc_bps is not None:
            tc_term = cp.sum(cp.multiply(tc_bps, cp.abs(w - w_prev)))

        objective = cp.Minimize(gamma * risk_term - return_term + robust_term + tc_term)
        # ROUND 45 FIX: `gamma` (risk aversion) was accepted but NEVER used —
        # the objective hard-coded an implicit risk aversion of 1.0, so
        # gamma=0.1 and gamma=10.0 produced byte-identical weights. The
        # parameter now scales the variance term as the signature/docstring
        # ("Solves Wasserstein DRO") imply.
        prob = cp.Problem(objective, constraints)

        # 6. Apply Warm Start (if w_prev supplied)
        if w_prev is not None and not use_mip:
            w.value = w_prev

        # 7. Solve
        try:
            if solver_name == "GUROBI":
                prob.solve(solver=cp.GUROBI, warm_start=True)
            elif solver_name == "CPLEX":
                prob.solve(solver=cp.CPLEX, warm_start=True)
            elif solver_name == "MOSEK":
                prob.solve(solver=cp.MOSEK, warm_start=True)
            elif solver_name == "CLARABEL":
                prob.solve(solver=cp.CLARABEL)
            else:
                prob.solve()
        except Exception as e:
            logger.error(f"[SolverCoordinator] Solver run failed: {e}. Falling back to default Clarabel.", exc_info=True)
            try:
                # Force fallback to Clarabel or ECOS without integer constraints
                # AUDIT-FIX (Round 6, A2-P3-5): every element of `constraints`
                # IS a cp.constraints.Constraint subclass, so the previous
                # filter produced [] and the rebuilt problem kept ONLY the
                # per-asset bounds — the budget constraint sum(w) == 1 was
                # silently DROPPED, making every fallback solution meaningless
                # (arbitrary scale). Rebuild bounds AND the budget (plus the
                # optional cardinality fixed-to-zero rows).
                continuous_constraints = []
                for i in range(n):
                    if not active_mask[i]:
                        continuous_constraints.append(w[i] == 0.0)
                    else:
                        continuous_constraints.append(w[i] >= min_weight)
                        continuous_constraints.append(w[i] <= max_weight)
                continuous_constraints.append(cp.sum(w) == 1.0)
                prob_fallback = cp.Problem(objective, continuous_constraints)
                prob_fallback.solve(solver=cp.CLARABEL)
            except Exception as e_fallback:
                logger.error(f"[SolverCoordinator] Clarabel fallback failed: {e_fallback}", exc_info=True)
                return {}

        # 8. Return results map
        if w.value is None:
            logger.error("[SolverCoordinator] Optimization returned optimal value as None.")
            return {}

        weights_map = {}
        for i, asset in enumerate(assets):
            val = float(w.value[i])
            if abs(val) < 1e-5:
                val = 0.0
            weights_map[asset] = val

        return weights_map
