"""
math_engine/spacetime_foam.py
=============================
Backward-compatibility alias. The canonical module is now:
`math_engine.two_scale_realized_vol`.
"""
from __future__ import annotations
from math_engine.two_scale_realized_vol import TwoScaleRealizedVolatilityEngine

__all__ = ["TwoScaleRealizedVolatilityEngine"]
