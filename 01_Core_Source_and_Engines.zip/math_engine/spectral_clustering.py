"""
math_engine/spectral_clustering.py
===================================
Spectral Graph Laplacian Asset Clustering Engine.

Constructs Normalized Graph Laplacian L = I - D^{-1/2} A D^{-1/2} over asset correlation graph
and performs spectral clustering to partition stocks into orthogonal, uncorrelated risk clusters.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, List

logger = logging.getLogger(__name__)


class SpectralGraphClusteringEngine:
    """
    Normalized Graph Laplacian Spectral Clustering Engine.
    """

    @staticmethod
    def cluster_assets_spectrally(returns_df: pd.DataFrame, n_clusters: int = 3) -> Dict[str, Any]:
        """
        Partitions asset universe into n_clusters orthogonal risk clusters.
        """
        if returns_df is None or returns_df.empty or returns_df.shape[1] < n_clusters:
            return {"asset_clusters": {}, "n_clusters": 0}

        tickers = list(returns_df.columns)
        clean_ret = returns_df.dropna(how="all").fillna(0.0).values
        n_assets = len(tickers)

        # Correlation Adjacency Matrix A (positive weights)
        corr = np.abs(np.corrcoef(clean_ret, rowvar=False))
        np.fill_diagonal(corr, 0.0)

        # Degree matrix D
        d_vals = np.sum(corr, axis=1) + 1e-9
        d_inv_sqrt = np.diag(1.0 / np.sqrt(d_vals))

        # Normalized Graph Laplacian L = I - D^(-1/2) A D^(-1/2)
        laplacian = np.eye(n_assets) - (d_inv_sqrt @ corr @ d_inv_sqrt)

        # Eigen-decomposition of Laplacian
        val, vec = np.linalg.eigh(laplacian)
        idx = val.argsort()
        vec_k = vec[:, idx[:n_clusters]]  # Smallest k eigenvectors

        # Simple k-means assignment proxy based on dominant eigenvector signs
        clusters = {}
        for idx, t in enumerate(tickers):
            cluster_id = int(np.argmax(np.abs(vec_k[idx])))
            clusters[t] = cluster_id

        return {
            "asset_clusters": clusters,
            "n_clusters": n_clusters,
            "n_assets": n_assets
        }
