"""
math_engine/spiking_synapse.py
==============================
Intraday Volume Spike & Order Flow Intensity Pulse Detector.

Applies exponential moving average intensity functions and Z-score volume 
surges to detect institutional order flow execution spikes and volume clusters.
"""

from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, List, Tuple

logger = logging.getLogger(__name__)


class VolumeSpikePulseFilter:
    """
    Real Intraday Volume Spike & Order Intensity Pulse Filter Engine.
    Detects non-linear volume intensity clusters and breakout accumulation pulses.
    """

    @staticmethod
    def compute_volume_intensity_pulse(
        volume_series: pd.Series | np.ndarray,
        short_window: int = 5,
        long_window: int = 20
    ) -> Dict[str, float]:
        """
        Calculates Short-Term Volume Surge Ratio and Exponential Intensity Pulse:
        Volume_Ratio = EMA_short(Volume) / (EMA_long(Volume) + 1e-6)
        
        Returns:
            Dict containing volume_surge_ratio, intensity_z_score, and is_pulse_cluster.
        """
        v_vals = np.asarray(volume_series, dtype=float)
        v_vals = v_vals[~np.isnan(v_vals)]
        n = len(v_vals)

        if n < long_window:
            return {
                "volume_surge_ratio": 1.0,
                "intensity_z_score": 0.0,
                "is_pulse_cluster": False
            }

        s_vol = pd.Series(v_vals)
        ema_short = s_vol.ewm(span=short_window, adjust=False).mean()
        ema_long = s_vol.ewm(span=long_window, adjust=False).mean()

        ratio_series = ema_short / (ema_long + 1e-6)
        last_ratio = float(ratio_series.iloc[-1])

        # Compute Z-score of recent volume relative to trailing median/std
        med_vol = s_vol.iloc[-long_window:].median()
        std_vol = s_vol.iloc[-long_window:].std() + 1e-6
        last_vol = s_vol.iloc[-1]
        z_score = float((last_vol - med_vol) / std_vol)

        is_cluster = (last_ratio > 1.5) and (z_score > 2.0)

        return {
            "volume_surge_ratio": round(last_ratio, 2),
            "intensity_z_score": round(z_score, 2),
            "is_pulse_cluster": bool(is_cluster)
        }

    @classmethod
    def detect_breakout_pulses(cls, df_ohlcv: pd.DataFrame) -> pd.DataFrame:
        """
        Scans OHLCV DataFrame and appends volume intensity pulse indicators.
        """
        if df_ohlcv.empty or "Volume" not in df_ohlcv.columns:
            return df_ohlcv

        df_res = df_ohlcv.copy()
        s_vol = df_res["Volume"]
        ema5 = s_vol.ewm(span=5, adjust=False).mean()
        ema20 = s_vol.ewm(span=20, adjust=False).mean()

        df_res["Volume_Surge_Ratio"] = (ema5 / (ema20 + 1e-6)).round(2)
        df_res["Volume_Pulse_Cluster"] = df_res["Volume_Surge_Ratio"] > 1.5
        return df_res
