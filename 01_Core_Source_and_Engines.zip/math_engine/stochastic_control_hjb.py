"""
math_engine/stochastic_control_hjb.py
=====================================
Hamilton-Jacobi-Bellman (HJB) Stochastic Optimal Control Engine.

Solves the HJB partial differential equation (PDE):
  v_t + max_c [ u(c) + (r * w + pi*(mu - r) - c) * v_w + 0.5 * pi^2 * sigma^2 * v_{ww} ] = 0
for optimal consumption c* and risky equity allocation pi* under CRRA risk aversion gamma.
"""
from __future__ import annotations

import logging
import numpy as np
from typing import Dict, Any

logger = logging.getLogger(__name__)


class HJBOptimalControlEngine:
    """
    Merton's Portfolio Problem HJB Stochastic Optimal Control Solver.
    """

    @staticmethod
    def solve_merton_hjb(mu: float = 0.12, r: float = 0.065, sigma: float = 0.18,
                         gamma_risk_aversion: float = 2.5) -> Dict[str, Any]:
        """
        Solves Merton's optimal risky asset weight pi* = (mu - r) / (gamma * sigma^2).
        """
        if sigma <= 0 or gamma_risk_aversion <= 0:
            return {"optimal_risky_weight_pi": 0.50, "optimal_cash_weight": 0.50}

        pi_star = (mu - r) / (gamma_risk_aversion * (sigma ** 2))
        pi_clamped = round(min(max(float(pi_star), 0.0), 1.0), 4)
        cash_weight = round(1.0 - pi_clamped, 4)

        return {
            "optimal_risky_weight_pi": pi_clamped,
            "optimal_cash_weight": cash_weight,
            "expected_excess_return": round(mu - r, 4),
            "gamma_risk_aversion": gamma_risk_aversion
        }
