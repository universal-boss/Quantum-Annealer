"""
math_engine/subgrid_glitch.py
=============================
Backward-compatibility alias. The canonical module is now:
`math_engine.hampel_outlier_filter`.
"""
from __future__ import annotations
from math_engine.hampel_outlier_filter import HampelOutlierFilter, HampelGlitchFilter

__all__ = ["HampelOutlierFilter", "HampelGlitchFilter"]
