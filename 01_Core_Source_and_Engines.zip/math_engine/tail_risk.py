"""Tail risk optimization — CVaR, CDaR, Robust, Omega ratio.

Replaces mean-variance optimization with downside-risk-focused alternatives:

  1. CVaR Optimization (Rockafellar-Uryasev): minimize expected shortfall
  2. CDaR Optimization (Chekhlov-Uryasev-Zabarankin): minimize drawdown tail
  3. Robust Optimization: worst-case scenario optimization
  4. Omega Ratio Optimization: maximize probability-weighted gains/losses

These are far more relevant for institutional risk management than variance
because they penalize tail losses, not just volatility.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Optional
import logging

logger = logging.getLogger(__name__)

try:
    from scipy.optimize import minimize
    _HAS_SCIPY = True
except ImportError:
    _HAS_SCIPY = False


def compute_cvar(returns: np.ndarray, alpha: float = 0.95) -> float:
    """Compute Conditional Value at Risk (Expected Shortfall).

    CVaR_alpha = E[loss | loss > VaR_alpha]

    Args:
        returns: Array of returns (positive = gain).
        alpha: Confidence level (0.95 = 95% CVaR).

    Returns:
        CVaR as a positive number (loss magnitude).
    """
    losses = -returns  # convert to losses
    var = np.percentile(losses, alpha * 100)
    tail_losses = losses[losses >= var]
    if len(tail_losses) == 0:
        return var
    return float(np.mean(tail_losses))


def compute_drawdown(returns: np.ndarray) -> np.ndarray:
    """Compute drawdown series from returns."""
    cum = np.cumprod(np.maximum(1.0 + returns, 1e-6))
    peak = np.maximum.accumulate(cum)
    peak = np.maximum(peak, 1e-6)
    drawdown = (cum - peak) / peak
    return drawdown


def compute_cdar(returns: np.ndarray, alpha: float = 0.95) -> float:
    """Compute Conditional Drawdown at Risk (CDaR).

    CDaR_alpha = E[drawdown | drawdown > DaR_alpha]

    Args:
        returns: Array of returns.
        alpha: Confidence level.

    Returns:
        CDaR as a positive number (drawdown magnitude).
    """
    drawdowns = -compute_drawdown(returns)  # convert to positive
    dar = np.percentile(drawdowns, alpha * 100)
    tail_drawdowns = drawdowns[drawdowns >= dar]
    if len(tail_drawdowns) == 0:
        return dar
    return float(np.mean(tail_drawdowns))


def compute_omega_ratio(returns: np.ndarray, threshold: float = 0.0) -> float:
    """Compute Omega ratio.

    Omega = E[max(r - threshold, 0)] / E[max(threshold - r, 0)]

    >1 = good, <1 = bad, =1 = neutral.

    Args:
        returns: Array of returns.
        threshold: Threshold return (default 0 = risk-free rate).

    Returns:
        Omega ratio.
    """
    gains = np.maximum(returns - threshold, 0)
    losses = np.maximum(threshold - returns, 0)
    expected_gain = np.mean(gains)
    expected_loss = np.mean(losses)
    if expected_loss < 1e-9:
        return float("inf") if expected_gain > 1e-9 else 1.0
    return float(expected_gain / expected_loss)


# ═══════════════════════════════════════════════════════════════════════════════
# OPTIMIZATION FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

def optimize_cvar(
    returns: pd.DataFrame,
    alpha: float = 0.95,
    target_return: Optional[float] = None,
    max_weight: float = 0.30,
    min_weight: float = 0.0,
) -> np.ndarray:
    """Minimize CVaR subject to return constraint.

    Uses Rockafellar-Uryasev linear programming formulation.

    Args:
        returns: DataFrame[date × ticker] of historical returns.
        alpha: CVaR confidence level (0.95 = 95%).
        target_return: Required minimum expected return (annualized).
        max_weight: Maximum weight per asset.
        min_weight: Minimum weight per asset.

    Returns:
        Optimal weight vector.
    """
    if not _HAS_SCIPY:
        # Fallback: equal weights
        n = returns.shape[1]
        return np.ones(n) / n

    rets = returns.to_numpy(dtype=float)
    n_assets = rets.shape[1]
    mean_returns = np.mean(rets, axis=0)

    # Objective: minimize CVaR (using Rockafellar-Uryasev)
    def cvar_objective(w):
        portfolio_returns = rets @ w
        losses = -portfolio_returns
        var = np.percentile(losses, alpha * 100)
        tail = losses[losses >= var]
        if len(tail) == 0:
            return var
        return np.mean(tail)

    # Constraints
    constraints = [{"type": "eq", "fun": lambda w: np.sum(w) - 1.0}]  # weights sum to 1
    if target_return is not None:
        # Daily target = annual / 252
        daily_target = target_return / 252
        constraints.append({
            "type": "ineq",
            "fun": lambda w: np.dot(w, mean_returns) - daily_target
        })

    bounds = [(min_weight, max_weight)] * n_assets
    x0 = np.ones(n_assets) / n_assets

    result = minimize(
        cvar_objective, x0, method="SLSQP",
        bounds=bounds, constraints=constraints,
        options={"maxiter": 500, "ftol": 1e-8}
    )

    if result.success:
        return result.x
    else:
        logger.warning(f"CVaR optimization failed: {result.message}")
        return x0


def optimize_cdar(
    returns: pd.DataFrame,
    alpha: float = 0.95,
    target_return: Optional[float] = None,
    max_weight: float = 0.30,
    min_weight: float = 0.0,
) -> np.ndarray:
    """Minimize CDaR (Conditional Drawdown at Risk)."""
    if not _HAS_SCIPY:
        n = returns.shape[1]
        return np.ones(n) / n

    rets = returns.to_numpy(dtype=float)
    n_assets = rets.shape[1]
    mean_returns = np.mean(rets, axis=0)

    def cdar_objective(w):
        portfolio_returns = rets @ w
        drawdowns = -compute_drawdown(portfolio_returns)
        dar = np.percentile(drawdowns, alpha * 100)
        tail = drawdowns[drawdowns >= dar]
        if len(tail) == 0:
            return dar
        return np.mean(tail)

    constraints = [{"type": "eq", "fun": lambda w: np.sum(w) - 1.0}]
    if target_return is not None:
        daily_target = target_return / 252
        constraints.append({
            "type": "ineq",
            "fun": lambda w: np.dot(w, mean_returns) - daily_target
        })

    bounds = [(min_weight, max_weight)] * n_assets
    x0 = np.ones(n_assets) / n_assets

    result = minimize(
        cdar_objective, x0, method="SLSQP",
        bounds=bounds, constraints=constraints,
        options={"maxiter": 500, "ftol": 1e-8}
    )

    return result.x if result.success else x0


def optimize_omega(
    returns: pd.DataFrame,
    threshold: float = 0.0,
    max_weight: float = 0.30,
    min_weight: float = 0.0,
) -> np.ndarray:
    """Maximize Omega ratio."""
    if not _HAS_SCIPY:
        n = returns.shape[1]
        return np.ones(n) / n

    rets = returns.to_numpy(dtype=float)
    n_assets = rets.shape[1]

    def omega_objective(w):
        portfolio_returns = rets @ w
        omega = compute_omega_ratio(portfolio_returns, threshold)
        return -omega  # minimize negative = maximize

    constraints = [{"type": "eq", "fun": lambda w: np.sum(w) - 1.0}]
    bounds = [(min_weight, max_weight)] * n_assets
    x0 = np.ones(n_assets) / n_assets

    result = minimize(
        omega_objective, x0, method="SLSQP",
        bounds=bounds, constraints=constraints,
        options={"maxiter": 500, "ftol": 1e-8}
    )

    return result.x if result.success else x0


def optimize_robust(
    returns: pd.DataFrame,
    uncertainty: float = 0.02,
    confidence_level: float = 0.95,
    max_weight: float = 0.30,
    min_weight: float = 0.0,
) -> np.ndarray:
    """Rigorous Goldfarb & Iyengar (2003) Robust Mean-Variance Optimization.

    Formulates exact dual problem for Ellipsoidal + Box Uncertainty Sets on expected returns:
      U_mu = { mu : (mu - mu_hat)^T Sigma_mu^-1 (mu - mu_hat) <= kappa_ellip^2  and  |mu_i - mu_hat_i| <= kappa_box * sigma_i / sqrt(T) }

    Worst-case expected return dual:
      min_{mu in U_mu} w^T mu = w^T mu_hat - kappa_ellip * sqrt(w^T Sigma w) - kappa_box * w^T (sigma / sqrt(T))

    Robust Objective (Goldfarb-Iyengar 2003 / Fabozzi et al. 2007):
      min_w  1/2 w^T Sigma w - lambda_ret * [ w^T mu_hat - kappa_ellip * sqrt(w^T Sigma w) - kappa_box * w^T (sigma / sqrt(T)) ]
    """
    if not _HAS_SCIPY:
        n = returns.shape[1]
        return np.ones(n) / n

    rets = returns.to_numpy(dtype=float)
    T, n_assets = rets.shape
    if T < 4:
        return np.ones(n_assets) / n_assets

    mean_returns = np.mean(rets, axis=0)
    std_returns = np.std(rets, axis=0, ddof=1)
    cov = np.cov(rets, rowvar=False)

    # Goldfarb-Iyengar (2003) uncertainty set radius kappa from Chi-squared quantile
    from scipy.stats import chi2
    kappa_ellip = float(np.sqrt(chi2.ppf(confidence_level, df=n_assets) / max(T, 1)))
    kappa_box = float(uncertainty * np.sqrt(252.0))  # annualized box uncertainty parameter

    def robust_objective(w):
        port_var = float(w @ cov @ w)
        port_sd = np.sqrt(max(port_var, 1e-12))
        
        # Worst-case return under joint Ellipsoidal & Box estimation risk (uses abs(w) for long-short bounds)
        ellip_penalty = kappa_ellip * port_sd
        box_penalty = kappa_box * float(np.dot(np.abs(w), std_returns / np.sqrt(T)))
        worst_case_return = float(np.dot(w, mean_returns)) - ellip_penalty - box_penalty
        
        # Mean-variance robust objective: minimize 0.5 * Variance - 0.5 * Worst_Case_Return
        return 0.5 * port_var - 0.5 * worst_case_return

    constraints = [{"type": "eq", "fun": lambda w: np.sum(w) - 1.0}]
    bounds = [(min_weight, max_weight)] * n_assets
    x0 = np.ones(n_assets) / n_assets

    result = minimize(
        robust_objective, x0, method="SLSQP",
        bounds=bounds, constraints=constraints,
        options={"maxiter": 500, "ftol": 1e-8}
    )

    return result.x if result.success else x0


def optimize_sortino(
    returns: pd.DataFrame,
    target_return: float = 0.0,
    max_weight: float = 0.30,
    min_weight: float = 0.0,
) -> np.ndarray:
    """Maximize Sortino ratio (Ann Return / Downside Volatility)."""
    if not _HAS_SCIPY:
        n = returns.shape[1]
        return np.full(n, 1.0 / n)

    R = returns.to_numpy(dtype=float)
    n_samples, n_assets = R.shape
    x0 = np.full(n_assets, 1.0 / n_assets)

    def obj(w):
        port_r = R @ w
        mean_r = np.mean(port_r) * 252
        downside_diff = np.minimum(port_r - (target_return / 252.0), 0.0)
        downside_vol = np.sqrt(np.mean(downside_diff ** 2)) * np.sqrt(252.0) + 1e-9
        return - (mean_r / downside_vol) # minimize negative Sortino

    constraints = [{"type": "eq", "fun": lambda w: np.sum(w) - 1.0}]
    bounds = [(min_weight, max_weight) for _ in range(n_assets)]

    res = minimize(obj, x0, method="SLSQP", bounds=bounds, constraints=constraints, options={"maxiter": 500})
    return res.x if res.success else x0


def optimize_tail_risk(
    returns: pd.DataFrame,
    method: str = "cvar",
    alpha: float = 0.95,
    target_return: Optional[float] = None,
    max_weight: float = 0.30,
    min_weight: float = 0.0,
) -> dict:
    """Optimize portfolio using tail-risk-focused objective.

    Args:
        returns: Historical returns DataFrame.
        method: "cvar", "cdar", "omega", "robust", or "sortino".
        alpha: Confidence level for CVaR/CDaR.
        target_return: Optional minimum return constraint.
        max_weight: Maximum weight per asset.
        min_weight: Minimum weight per asset.

    Returns:
        Dict with weights and risk metrics.
    """
    method = method.lower()

    if method == "cvar":
        weights = optimize_cvar(returns, alpha, target_return, max_weight, min_weight)
    elif method == "cdar":
        weights = optimize_cdar(returns, alpha, target_return, max_weight, min_weight)
    elif method == "omega":
        weights = optimize_omega(returns, threshold=0.0, max_weight=max_weight, min_weight=min_weight)
    elif method == "robust":
        weights = optimize_robust(returns, uncertainty=0.02, max_weight=max_weight, min_weight=min_weight)
    elif method == "sortino":
        weights = optimize_sortino(returns, target_return=(target_return or 0.0), max_weight=max_weight, min_weight=min_weight)
    else:
        raise ValueError(f"Unknown method: {method}")

    # Compute risk metrics for the optimal portfolio
    portfolio_returns = returns.to_numpy(dtype=float) @ weights
    metrics = {
        "method": method,
        "weights": weights,
        "portfolio_return": float(np.mean(portfolio_returns) * 252),
        "portfolio_volatility": float(np.std(portfolio_returns) * np.sqrt(252)),
        "var_95": float(-np.percentile(portfolio_returns, 5)),  # FIX: consistent positive sign = loss magnitude
        "cvar_95": compute_cvar(portfolio_returns, 0.95),
        "cdar_95": compute_cdar(portfolio_returns, 0.95),
        "omega_ratio": compute_omega_ratio(portfolio_returns, 0.0),
        "max_drawdown": float(np.min(compute_drawdown(portfolio_returns))),
    }

    return metrics
