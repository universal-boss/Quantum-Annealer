"""
math_engine/tax_loss_harvesting.py
==================================
Indian Tax-Loss Harvesting & Lot-Level Cost Basis Optimizer.

Integrates Indian STCG (Short-Term Capital Gains @ 20%) and LTCG (Long-Term Capital Gains @ 12.5%)
share-lot tax rules to harvest unrealized losses and maximize net after-tax portfolio return.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, List, Optional

logger = logging.getLogger(__name__)


class TaxLossHarvestingOptimizer:
    """
    Indian Share-Lot Tax-Loss Harvesting Optimizer.
    """

    # AUDIT-FIX (Round 23 — R23-5): the engine's simplifying assumptions were
    # previously invisible to consumers (only an implied "est." label). They
    # are now a class constant returned in BOTH code paths so every surface
    # (API payload, dashboard panel, reports) can disclose them:
    #   * losses are assumed FULLY offsettable against same-category realized
    #     gains — no modeling of unabsorbed losses, the 8-year carry-forward
    #     limit, or intra-year sequencing;
    #   * the LTCG Rs 1,00,000–1,25,000 annual exemption slab is NOT applied
    #     (gross savings estimate; effective LTCG savings can be lower);
    #   * flat Finance Act 2024 rates (STCG 20% / LTCG 12.5%), no surcharge or
    #     cess, no grandfathering.
    #
    # AUDIT-FIX (Round 24 — R24-5): the first two "assumptions" are now
    # MODELED in `compute_tax_position` below (realized-gains ledger +
    # Sec 70/74 set-off + 8-year carry-forward + the Rs 1.25L LTCG exemption
    # slab). The legacy `identify_harvestable_lots` keeps the gross
    # estimate semantics for backward compatibility; the new method is the
    # honest net-of-set-off figure. The remaining disclosures below are the
    # genuinely unmodeled items (surcharge/cess, settlement adjustments).
    #
    # AUDIT-FIX (Round 25 — R25-5): surcharge + 4% cess, the pre/post
    # Jul-2024 rate regimes (per-tranche 111A/112A rates and exemption
    # slabs), Sec 112A(2) grandfathering (with an FMV feed) and the
    # trade-date holding-period convention (Sec 2(42A)) are now modeled in
    # `compute_tax_position`. The legacy gross estimator's flat-rate
    # semantics are disclosed as such below.
    ENGINE_ASSUMPTIONS: List[str] = [
        "LEGACY GROSS ESTIMATE (identify_harvestable_lots): flat STCG 20% / LTCG 12.5% "
        "Finance Act 2024 rates, gross of set-off/exemption/carry — losses assumed "
        "fully offsettable, no carried-forward-loss tracking, no exemption slab, no "
        "surcharge or cess — use compute_tax_position for the statutory net position",
        "HoldingDays < 365 classifies STCG on the trade-date basis (Sec 2(42A)) — "
        "settlement-date adjustments are never needed for listed-equity holding periods",
        "compute_tax_position models: Sec 70/74 set-off order, 8-year carried-forward "
        "losses, per-tranche Jul-2024 rate regimes, Sec 112A exemption + (with an FMV "
        "feed) grandfathering, and surcharge + 4% Health & Education Cess when "
        "include_surcharge_cess=True — the 15% surcharge cap (Finance Act 2022, "
        "Sec 2(11) proviso) covers the Sec 111A/112/112A tax, and marginal relief "
        "is modeled (exact on the gains-only income basis; conservative-"
        "approximate and disclosed when the caller's total income exceeds the "
        "gains base)",
    ]

    # AUDIT-FIX (Round 24 — R24-5): parameters of the now-MODELED tax rules.
    STCG_RATE: float = 0.20            # Finance (No. 2) Act 2024, Sec 111A
    LTCG_RATE: float = 0.125           # Finance (No. 2) Act 2024, Sec 112A
    LTCG_EXEMPTION_INR: float = 125_000.0  # Sec 112A annual exemption (from FY25-26)
    CARRY_FORWARD_YEARS: int = 8       # Sec 70(3) / 74(1): STCL and LTCL alike

    # ── AUDIT-FIX (Round 25 — R25-5): pre-cutover regime + surcharge/cess ──
    # Transfers BEFORE 23-Jul-2024 (Finance (No. 2) Act 2024 cutover) are
    # taxed under the old Sec 111A/112A regime; on/after it under the new one.
    TAX_REGIME_CUTOFF_DATE: str = "2024-07-23"
    STCG_RATE_PRE_CUTOFF: float = 0.15       # Sec 111A before 23-Jul-2024
    LTCG_RATE_PRE_CUTOFF: float = 0.10       # Sec 112A before 23-Jul-2024
    LTCG_EXEMPTION_PRE_CUTOFF_INR: float = 100_000.0
    # Surcharge slabs (individuals, on total income) + Health & Education
    # Cess. The surcharge RATE is chosen by the income bracket and applied
    # to the capital-gains tax components (each capped at 15% — see
    # LTCG_SURCHARGE_CAP); marginal relief is modeled in compute_tax_position
    # (exact on the gains-only income basis, disclosed otherwise).
    SURCHARGE_SLABS: tuple = (
        (5_000_000.0, 0.10),    # total income > Rs 50L  -> 10%
        (10_000_000.0, 0.15),   # total income > Rs 1Cr  -> 15%
        (20_000_000.0, 0.25),   # total income > Rs 2Cr  -> 25%
        (50_000_000.0, 0.37),   # total income > Rs 5Cr  -> 37%
    )
    # Finance Act 2022 (Sec 2(11) proviso): the surcharge on tax on income
    # under Sec 111A, 112 AND 112A is CAPPED at 15% even when total income
    # falls in the 25%/37% slabs.
    # AUDIT-FIX (Round 26 — R26-1): the cap is applied to the STCG (Sec
    # 111A) component too — the R25 code uncapped it (a statutory error,
    # verified against incometaxindia.gov.in and public effective-rate
    # tables: max effective STCG 23.92% = 20% x 1.15 x 1.04). Constant
    # name kept from R25 for regression-lock continuity; the semantics
    # cover all three capital-gains sections.
    LTCG_SURCHARGE_CAP: float = 0.15
    CESS_RATE: float = 0.04                  # Health & Education Cess on tax + surcharge

    @staticmethod
    def identify_harvestable_lots(holdings_df: pd.DataFrame, current_prices: Dict[str, float]) -> Dict[str, Any]:
        """
        Identifies specific shares/lots with unrealized losses for STCG (20%) and LTCG (12.5%) harvesting.
        """
        if holdings_df is None or holdings_df.empty or "Ticker" not in holdings_df.columns:
            # AUDIT-FIX (Round 22 — R22-4): this early return was missing the
            # 'total_tax_saved_inr' key that the populated path returns —
            # consumers keyed on it saw inconsistent shapes.
            # AUDIT-FIX (Round 23 — R23-5): assumptions key added here too so
            # BOTH return shapes disclose the engine's simplifications.
            return {
                "harvestable_lots_df": pd.DataFrame(),
                "est_stcg_savings_inr": 0.0,
                "est_ltcg_savings_inr": 0.0,
                "total_tax_saved_inr": 0.0,
                "assumptions": TaxLossHarvestingOptimizer.ENGINE_ASSUMPTIONS,
            }

        harvest_rows = []
        stcg_savings = 0.0
        ltcg_savings = 0.0

        for _, row in holdings_df.iterrows():
            ticker = str(row.get("Ticker", "")).upper()
            try:
                raw_buy = row.get("BuyPrice", 0.0)
                buy_price = float(raw_buy) if pd.notna(raw_buy) else 0.0
            except (ValueError, TypeError):
                buy_price = 0.0

            try:
                raw_shares = row.get("Shares", 0)
                shares = int(raw_shares) if pd.notna(raw_shares) and np.isfinite(raw_shares) else 0
            except (ValueError, TypeError):
                shares = 0

            try:
                raw_days = row.get("HoldingDays", 30)
                holding_days = int(raw_days) if pd.notna(raw_days) and np.isfinite(raw_days) else 30
            except (ValueError, TypeError):
                holding_days = 30

            cur_price = current_prices.get(ticker, buy_price)
            if cur_price <= 0 or shares <= 0 or buy_price <= 0:
                continue

            unrealized_pnl = (cur_price - buy_price) * shares
            if unrealized_pnl < 0:
                loss_val = abs(unrealized_pnl)
                is_stcg = holding_days < 365
                tax_rate = 0.20 if is_stcg else 0.125
                saved_tax = loss_val * tax_rate

                if is_stcg:
                    stcg_savings += saved_tax
                else:
                    ltcg_savings += saved_tax

                harvest_rows.append({
                    "Ticker": ticker,
                    "Shares": shares,
                    "BuyPrice": buy_price,
                    "CurrentPrice": cur_price,
                    "UnrealizedLossINR": round(loss_val, 2),
                    "TaxCategory": "STCG" if is_stcg else "LTCG",
                    "EstTaxSavedINR": round(saved_tax, 2)
                })

        return {
            "harvestable_lots_df": pd.DataFrame(harvest_rows),
            "est_stcg_savings_inr": round(stcg_savings, 2),
            "est_ltcg_savings_inr": round(ltcg_savings, 2),
            "total_tax_saved_inr": round(stcg_savings + ltcg_savings, 2),
            # AUDIT-FIX (Round 23 — R23-5): engine-level assumption disclosure
            "assumptions": list(TaxLossHarvestingOptimizer.ENGINE_ASSUMPTIONS),
        }

    # ─────────────────────────────────────────────────────────────────────
    # AUDIT-FIX (Round 24 — R24-5): NET tax position with set-off rules,
    # carry-forward modeling, and the LTCG exemption slab.
    # AUDIT-FIX (Round 25 — R25-5): + pre/post-Jul-2024 per-tranche rate
    # regimes, Sec 112A grandfathering echo, and surcharge + 4% cess.
    # ─────────────────────────────────────────────────────────────────────
    @staticmethod
    def compute_tax_position(
        holdings_df: pd.DataFrame,
        current_prices: Dict[str, float],
        realized_gains: Optional[Dict[str, Any]] = None,
        carried_forward: Optional[Dict[str, Any]] = None,
        assessment_year: Optional[str] = None,
        ltcg_exemption_inr: Optional[float] = None,
        include_surcharge_cess: bool = False,
        total_taxable_income_inr: Optional[float] = None,
        non_cg_tax_inr: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Net-of-set-off Indian capital-gains tax position + harvesting value.

        AUDIT-FIX (Round 24 — R24-5): the legacy identify_harvestable_lots
        estimate assumed every harvested loss offsets same-category gains
        instantly and fully, and ignored the Rs 1.25L LTCG exemption slab.
        This method applies the actual rules on the REALIZED-GAINS LEDGER:

          1. Bucket this assessment year's realized gains/losses (from the
             ledger's net STCG/LTCG) plus today's unrealized harvestable
             losses (the lots that WOULD be harvested).
          2. Sec 70/74 set-off order: STCL first against STCG, then against
             LTCG; LTCL ONLY against LTCG (a long-term loss never reduces
             short-term gains).
          3. Brought-forward unabsorbed losses (`carried_forward` dict, the
             consumer's persisted prior-year remainder) consume gains in the
             same order BEFORE this year's losses.
          4. LTCG exemption: the first Rs 1,25,000 of NET LTCG (after all
             set-offs) is tax-free (Sec 112A).
          5. Tax: 20% of net STCG + 12.5% of net LTCG above the exemption.
             The HARVESTING VALUE is the tax delta between harvesting now
             and not harvesting — losses that cannot be absorbed this year
             are NOT worthless (they carry forward up to 8 years) but are
             discounted by their carry-forward state, disclosed explicitly.

        AUDIT-FIX (Round 25 — R25-5): three more statutory layers:

          6. RATE REGIMES: when the ledger supplies a `regime_split` (by
             exit date vs 23-Jul-2024), the positive net STCG/LTCG are taxed
             PER TRANCHE — pre-cutover: 15% / 10% above Rs 1L; post-cutover:
             20% / 12.5% above Rs 1.25L. A mixed-tranche net is allocated
             pro-rata to the positive gross tranches (disclosed; exact when
             only one tranche is positive — true for every AY from 2025-26
             onward, whose exits are all post-cutover).
          7. GRANDFATHERING: the ledger's Sec 112A(2) deemed-cost adjustment
             (applied when an FMV-31-Jan-2018 feed is supplied) is echoed in
             the payload via `grandfathering` (applied/eligible events +
             total adjustment) — the engine consumes the LEDGER's
             post-adjustment totals, so the adjustment is never double-counted.
          8. SURCHARGE + CESS (`include_surcharge_cess`, default False keeps
             the R24 flat-rate contract): the surcharge bracket is chosen on
             `total_taxable_income_inr` when supplied, else the gains-only
             proxy (disclosed); the surcharge on BOTH the STCG and LTCG tax
             components is capped at 15% (Finance Act 2022, Sec 2(11)
             proviso — covers Sec 111A/112/112A; maximum effective STCG rate
             23.92%, LTCG 14.95%); 4% Health & Education Cess applies on
             tax + net surcharge. MARGINAL RELIEF is modeled (AUDIT-FIX
             Round 26 — R26-2): exact on the gains-only income basis;
             conservative (surcharge limited to the excess income) and
             disclosed when the caller's total income exceeds the gains
             base, because the non-CG tax is not modeled by this engine.

        AUDIT-FIX (Round 27 — R27-2): the mixed-income marginal-relief
        approximation is closed when the caller supplies `non_cg_tax_inr`
        (the slab-rate tax on their non-capital-gains income, BEFORE
        surcharge/cess):

          9. EXACT MIXED-INCOME MARGINAL RELIEF: with the non-CG tax in hand,
             the surcharge covers the total tax (the non-CG portion at the
             UNCAPPED bracket rate — the Sec 2(11) 15% cap only covers Sec
             111A/112/112A tax), and marginal relief is computed exactly at
             the crossed surcharge threshold: the pro-rata reference (the
             engine's pinned pro-rata allocation convention) scales the CG
             and non-CG tax components by threshold/income, applies the
             LOWER-bracket surcharge rate at the threshold income, and caps
             the aggregate at reference + (income - threshold). Without
             `non_cg_tax_inr` the R26 behavior stands (gains-only exact /
             conservative-disclosed fallback).

        All amounts in INR. Degenerate inputs return an honest
        "insufficient data" shape, never fabricated zeros.
        """
        T = TaxLossHarvestingOptimizer
        ltcg_exemption = (float(ltcg_exemption_inr)
                          if ltcg_exemption_inr is not None
                          else T.LTCG_EXEMPTION_INR)
        STCG_R = T.STCG_RATE
        LTCG_R = T.LTCG_RATE
        STCG_R_PRE = T.STCG_RATE_PRE_CUTOFF
        LTCG_R_PRE = T.LTCG_RATE_PRE_CUTOFF
        EXEM_PRE = T.LTCG_EXEMPTION_PRE_CUTOFF_INR
        CESS_R = T.CESS_RATE
        CAP_CG_SR = T.LTCG_SURCHARGE_CAP  # R26-1: caps Sec 111A/112/112A surcharge

        # 1. This year's realized buckets (from the ledger), with the R25-5
        # regime split (by exit date) when the ledger provides it.
        rg = realized_gains or {}
        _regime = rg.get("regime_split") if isinstance(rg.get("regime_split"), dict) else None

        def _tranches(cat: str) -> tuple:
            if _regime is not None:
                d = _regime.get(cat) or {}
                try:
                    pre = float(d.get("pre_cutoff") or 0.0)
                except (TypeError, ValueError):
                    pre = 0.0
                try:
                    post = float(d.get("post_cutoff") or 0.0)
                except (TypeError, ValueError):
                    post = 0.0
                return pre, post
            try:
                tot = float(rg.get(cat) or 0.0)
            except (TypeError, ValueError):
                tot = 0.0
            return 0.0, tot

        stcg_pre_g, stcg_post_g = _tranches("STCG")
        ltcg_pre_g, ltcg_post_g = _tranches("LTCG")
        realized_stcg = stcg_pre_g + stcg_post_g
        realized_ltcg = ltcg_pre_g + ltcg_post_g
        unpriced = int(rg.get("unpriced_events") or 0)
        grandfathering = rg.get("grandfathering") if isinstance(rg.get("grandfathering"), dict) else None
        holding_basis = rg.get("holding_period_basis")

        # 2. Unrealized harvestable lots (gross loss amounts, same logic as
        # identify_harvestable_lots but returning the loss amounts only)
        unreal_stcl = unreal_ltcl = 0.0
        n_harvestable = 0
        if holdings_df is not None and not holdings_df.empty and "Ticker" in holdings_df.columns:
            for _, row in holdings_df.iterrows():
                ticker = str(row.get("Ticker", "")).upper()
                try:
                    buy_price = float(row.get("BuyPrice", 0.0) or 0.0)
                except (ValueError, TypeError):
                    buy_price = 0.0
                try:
                    shares = int(row.get("Shares", 0) or 0)
                except (ValueError, TypeError):
                    shares = 0
                try:
                    holding_days = int(row.get("HoldingDays", 30) or 30)
                except (ValueError, TypeError):
                    holding_days = 30
                cur_price = float(current_prices.get(ticker, 0.0) or 0.0)
                if cur_price <= 0 or shares <= 0 or buy_price <= 0:
                    continue
                unrealized_pnl = (cur_price - buy_price) * shares
                if unrealized_pnl < 0:
                    n_harvestable += 1
                    if holding_days < 365:
                        unreal_stcl += abs(unrealized_pnl)
                    else:
                        unreal_ltcl += abs(unrealized_pnl)

        # 3. Brought-forward unabsorbed losses (prior assessment years)
        cf = carried_forward or {}
        bf_stcl = float(cf.get("unabsorbed_stcl_inr") or 0.0)
        bf_ltcl = float(cf.get("unabsorbed_ltcl_inr") or 0.0)

        base = {
            "assessment_year": assessment_year,
            "stcg_rate": STCG_R,
            "ltcg_rate": LTCG_R,
            "ltcg_exemption_inr": ltcg_exemption,
            "carry_forward_years": T.CARRY_FORWARD_YEARS,
            # AUDIT-FIX (Round 25 — R25-5): the modeled statutory layers
            "include_surcharge_cess": bool(include_surcharge_cess),
            "rate_regimes": {
                "cutoff_date": T.TAX_REGIME_CUTOFF_DATE,
                "pre_cutoff": {"stcg_rate": STCG_R_PRE, "ltcg_rate": LTCG_R_PRE,
                               "ltcg_exemption_inr": EXEM_PRE},
                "post_cutoff": {"stcg_rate": STCG_R, "ltcg_rate": LTCG_R,
                                "ltcg_exemption_inr": ltcg_exemption},
                "allocation_convention": (
                    "positive net-of-set-off gains are allocated pro-rata to the "
                    "positive gross tranches; exact when a single tranche is "
                    "positive (every AY from 2025-26 onward)"),
            },
            "grandfathering": grandfathering,
            "holding_period_basis": holding_basis,
        }

        def _allocate_tranches(net_positive: float, pre_g: float, post_g: float) -> tuple:
            if pre_g <= 0.0 and post_g <= 0.0:
                return 0.0, 0.0
            if pre_g <= 0.0:
                return 0.0, net_positive
            if post_g <= 0.0:
                return net_positive, 0.0
            share = pre_g / (pre_g + post_g)
            return net_positive * share, net_positive * (1.0 - share)

        def _surcharge_rate_for(income_base: float) -> float:
            rate = 0.0
            for threshold, r in T.SURCHARGE_SLABS:
                if income_base > threshold:
                    rate = float(r)
            return rate

        # ── Scenario A: tax WITHOUT harvesting today's unrealized losses ──
        def _tax_after_offsets(stcg_gross: float, ltcg_gross: float,
                               stcl_avail: float, ltcl_avail: float) -> Dict[str, Any]:
            """Apply Sec 70/74 set-off + per-tranche regimes + Sec 112A
            exemptions (+ surcharge/cess when enabled). Returns the tax and
            the unabsorbed (carry-forward) remainders."""
            stcl_left = stcl_avail
            ltcl_left = ltcl_avail
            net_stcg = stcg_gross
            # STCL offsets STCG first, then LTCG
            use = min(stcl_left, max(net_stcg, 0.0))
            net_stcg -= use
            stcl_left -= use
            net_ltcg = ltcg_gross
            use = min(stcl_left, max(net_ltcg, 0.0))
            net_ltcg -= use
            stcl_left -= use
            # LTCL offsets LTCG only
            use = min(ltcl_left, max(net_ltcg, 0.0))
            net_ltcg -= use
            ltcl_left -= use

            # ── R25-5: per-tranche rates on the positive net positions ──
            stcg_pos = max(0.0, net_stcg)
            ltcg_pos = max(0.0, net_ltcg)
            stcg_pre_n, stcg_post_n = _allocate_tranches(stcg_pos, stcg_pre_g, stcg_post_g)
            ltcg_pre_n, ltcg_post_n = _allocate_tranches(ltcg_pos, ltcg_pre_g, ltcg_post_g)
            stcg_tax = STCG_R_PRE * stcg_pre_n + STCG_R * stcg_post_n
            taxable_ltcg_pre = max(0.0, ltcg_pre_n - EXEM_PRE)
            taxable_ltcg_post = max(0.0, ltcg_post_n - ltcg_exemption)
            ltcg_tax = LTCG_R_PRE * taxable_ltcg_pre + LTCG_R * taxable_ltcg_post
            tax_flat = stcg_tax + ltcg_tax

            # ── R25-5: surcharge + Health & Education Cess ──
            try:
                _tti = float(total_taxable_income_inr)
            except (TypeError, ValueError):
                _tti = float("nan")
            # R27-2: the caller's non-CG slab tax (before surcharge/cess).
            # Strictly validated like _tti: non-numeric/negative -> absent.
            _has_noncg = False
            try:
                _ncg = float(non_cg_tax_inr)
                _has_noncg = np.isfinite(_ncg) and _ncg >= 0.0
            except (TypeError, ValueError):
                _ncg = 0.0
            if np.isfinite(_tti) and _tti > 0:
                inc_base = _tti
                sr_basis = ("total_taxable_income_inr (caller-supplied total income — "
                            "the statutory surcharge bracket basis)")
            else:
                inc_base = stcg_pos + taxable_ltcg_pre + taxable_ltcg_post
                sr_basis = ("gains-only proxy (net STCG + taxable LTCG) — pass "
                            "total_taxable_income_inr for the statutory bracket")
            sr_rate = _surcharge_rate_for(inc_base)
            # AUDIT-FIX (Round 26 — R26-1): Finance Act 2022 (Sec 2(11)
            # proviso) caps the surcharge on tax on income under Sec 111A,
            # 112 AND 112A at 15% — the STCG component previously took the
            # UNCAPPED slab rate (37% in the top bracket). Maximum effective
            # STCG rate is therefore 20% x 1.15 x 1.04 = 23.92%; the LTCG
            # path is unchanged (it was already capped).
            sr_stcg = min(sr_rate, CAP_CG_SR) * stcg_tax
            sr_ltcg = min(sr_rate, CAP_CG_SR) * ltcg_tax
            # AUDIT-FIX (Round 27 — R27-2): with the caller's non-CG slab tax
            # supplied, the surcharge is STATUTORY on it too — at the
            # UNCAPPED bracket rate (the Sec 2(11) 15% cap covers only the
            # Sec 111A/112/112A tax components, not the slab tax).
            sr_noncg = (sr_rate * _ncg) if (_has_noncg and _ncg > 0) else 0.0
            surcharge = sr_stcg + sr_ltcg + sr_noncg

            # AUDIT-FIX (Round 26 — R26-2): MARGINAL RELIEF. The aggregate
            # (tax + surcharge) at the actual income must not exceed
            # tax(threshold) + (income - threshold) for the crossed surcharge
            # bracket. Exact when the income basis is the gains-only base
            # (every rupee of income is taxed by THIS engine, so the
            # tax-at-threshold scales proportionally). When the caller's
            # total income exceeds the gains base, the non-CG tax is not
            # modeled, so relief falls back to the conservative shortcut
            # (surcharge limited to the excess income) — disclosed, and the
            # statutory liability can still be LOWER than modeled.
            marginal_relief = 0.0
            mr_basis = "none (no surcharge or no crossed bracket)"
            # R27-2 reference variables (pre-initialized; only set in the
            # exact mixed-income branch)
            _thr = None
            _cg_thr = _noncg_thr = _sur_thr = 0.0
            if surcharge > 0 and np.isfinite(inc_base) and inc_base > 0:
                _thr = None
                for _threshold, _r in T.SURCHARGE_SLABS:
                    if inc_base > _threshold:
                        _thr = float(_threshold)
                if _thr is not None:
                    _gains_base = stcg_pos + taxable_ltcg_pre + taxable_ltcg_post
                    if _has_noncg:
                        # AUDIT-FIX (Round 27 — R27-2): EXACT mixed-income
                        # marginal relief. The caller's non-CG slab tax is in
                        # hand, so the aggregate (CG tax + non-CG tax +
                        # surcharge) is compared against the pro-rata
                        # reference at the crossed threshold: tax components
                        # scaled by threshold/income (the engine's pinned
                        # pro-rata allocation convention), surcharge at the
                        # LOWER-bracket rate of the threshold income (0 at
                        # the first threshold, since surcharge starts only
                        # ABOVE it), CG portions capped at 15% and the
                        # non-CG portion uncapped. cap = reference + excess.
                        _s = _thr / inc_base
                        _cg_thr = tax_flat * _s
                        _noncg_thr = _ncg * _s
                        _rate_thr = _surcharge_rate_for(_thr)
                        _sur_thr = (min(_rate_thr, CAP_CG_SR) * _cg_thr
                                    + _rate_thr * _noncg_thr)
                        _cap_total = (_cg_thr + _noncg_thr + _sur_thr
                                      + (inc_base - _thr))
                        _relief = (tax_flat + _ncg + surcharge) - _cap_total
                        marginal_relief = max(0.0, min(_relief, surcharge))
                        mr_basis = ("exact (mixed-income, R27-2): non-CG slab tax "
                                    "caller-supplied (non_cg_tax_inr); pro-rata "
                                    "reference at the crossed bracket — tax "
                                    "components scaled by threshold/income, "
                                    "lower-bracket surcharge, CG portions capped "
                                    "at 15%, non-CG portion uncapped")
                    elif inc_base <= _gains_base + 1e-9:
                        _tax_at_thr = tax_flat * (_thr / inc_base)
                        _relief = (tax_flat + surcharge) - (_tax_at_thr + (inc_base - _thr))
                        marginal_relief = max(0.0, min(_relief, surcharge))
                        mr_basis = ("exact (gains-only income basis): aggregate tax+surcharge "
                                    "held at or below tax at the crossed bracket plus the "
                                    "excess income")
                    else:
                        _relief = surcharge - (inc_base - _thr)
                        marginal_relief = max(0.0, min(_relief, surcharge))
                        mr_basis = ("approximate-conservative: caller total income exceeds the "
                                    "gains base and the non-CG tax is not supplied — pass "
                                    "non_cg_tax_inr (the slab-rate tax on your non-CG income, "
                                    "before surcharge/cess) for the EXACT mixed-income "
                                    "marginal relief; until then relief is limited to capping "
                                    "the surcharge at the excess income — statutory marginal "
                                    "relief can be larger")
            surcharge_net = max(0.0, surcharge - marginal_relief)
            cess = CESS_R * (tax_flat + surcharge_net)
            tax_total = tax_flat + ((surcharge_net + cess) if include_surcharge_cess else 0.0)
            return {
                "tax_inr": tax_total,
                "tax_before_surcharge_inr": tax_flat,
                "surcharge_inr": (surcharge_net if include_surcharge_cess else 0.0),
                "surcharge_gross_inr": surcharge,
                "marginal_relief_inr": (marginal_relief if include_surcharge_cess else 0.0),
                "marginal_relief_basis": mr_basis,
                "cess_inr": (cess if include_surcharge_cess else 0.0),
                "surcharge_rate": round(sr_rate, 4),
                "surcharge_rate_stcg_capped": round(min(sr_rate, CAP_CG_SR), 4),
                "surcharge_rate_ltcg_capped": round(min(sr_rate, CAP_CG_SR), 4),
                "surcharge_income_basis": sr_basis,
                "non_cg_tax_inr": (_ncg if _has_noncg else 0.0),
                "non_cg_tax_supplied": bool(_has_noncg),
                "marginal_relief_cap_reference_inr": (
                    (_cg_thr + _noncg_thr + _sur_thr + (inc_base - _thr))
                    if (_has_noncg and marginal_relief > 0
                        and np.isfinite(inc_base) and _thr is not None) else 0.0),
                "stcg_tax_component": stcg_tax,
                "ltcg_tax_component": ltcg_tax,
                "net_stcg": net_stcg,
                "net_ltcg": net_ltcg,
                "unabsorbed_stcl": max(0.0, stcl_left),
                "unabsorbed_ltcl": max(0.0, ltcl_left),
            }

        # AUDIT-FIX (Round 26 — R26-3): net-NEGATIVE category buckets are
        # current-year realized losses (the ledger nets STCL into the STCG
        # bucket and LTCL into the LTCG bucket per assessment year). They
        # must enter the Sec 70/74 set-off pools (STCL -> STCG then LTCG;
        # LTCL -> LTCG only) — previously a net-negative bucket sat in
        # net_stcg as a negative gross, was clamped away by
        # stcg_pos = max(0, ...), and VANISHED: it never offset LTCG, never
        # carried forward, and the year's tax was overstated.
        _intra_stcl = max(0.0, -realized_stcg)
        _intra_ltcl = max(0.0, -realized_ltcg)
        _realized_stcg_pos = max(0.0, realized_stcg)
        _realized_ltcg_pos = max(0.0, realized_ltcg)

        # Scenario A: realized gains + brought-forward losses only
        # (R26-3: + the year's own net-negative realized buckets as losses)
        a = _tax_after_offsets(_realized_stcg_pos, _realized_ltcg_pos,
                               bf_stcl + _intra_stcl, bf_ltcl + _intra_ltcl)
        # Scenario B: additionally harvest all unrealized losses now
        b = _tax_after_offsets(_realized_stcg_pos, _realized_ltcg_pos,
                               bf_stcl + _intra_stcl + unreal_stcl,
                               bf_ltcl + _intra_ltcl + unreal_ltcl)
        # R26-4: pool provenance for the per-vintage carry-forward write-back
        # (the endpoint consumes oldest-vintage-first and re-stamps nothing)
        for _sc in (a, b):
            _sc["intra_year_stcl_inr"] = _intra_stcl
            _sc["intra_year_ltcl_inr"] = _intra_ltcl
            _sc["brought_forward_stcl_inr"] = bf_stcl
            _sc["brought_forward_ltcl_inr"] = bf_ltcl

        # Harvesting value: tax saved NOW (A - B), plus the change in
        # carry-forward state. A harvested loss that cannot be absorbed this
        # year still carries forward (8y) — its present value is NOT zero,
        # but the immediate cash saving is what the panel headline shows.
        immediate_saving = a["tax_inr"] - b["tax_inr"]
        stcg_saving_component = STCG_R * min(unreal_stcl, max(realized_stcg - 0.0, 0.0) + max(realized_ltcg, 0.0))
        ltcg_saving_component = LTCG_R * min(unreal_ltcl, max(realized_ltcg, 0.0))

        # Exemption effect disclosure: how much of the LTCG exemption the
        # harvest would shelter/consume
        exemption_effect = (max(0.0, a["net_ltcg"]) - max(0.0, b["net_ltcg"]))

        _surcharge_note = (
            (f"Surcharge + 4% Health & Education Cess MODELED with marginal relief; "
             f"the Finance Act 2022 (Sec 2(11) proviso) 15% surcharge cap covers the "
             f"Sec 111A/112/112A tax (max effective STCG 23.92%, LTCG 14.95%); surcharge "
             f"bracket basis: {a['surcharge_income_basis']}; marginal relief: "
             f"{a['marginal_relief_basis']}")
            if include_surcharge_cess else
            ("Surcharge & cess EXCLUDED (flat-rate view — pass "
             "include_surcharge_cess=True for the statutory view)")
        )
        _regime_note = (
            f"Rate regimes: pre/post {T.TAX_REGIME_CUTOFF_DATE} tranches "
            + ("split by the ledger's exit dates" if _regime is not None else
               "no regime split supplied — all gains taxed at the post-cutoff rates")
        )
        _gf_note = (
            (grandfathering or {}).get("basis")
            or "Sec 112A(2) grandfathering status unknown (no ledger disclosure)"
        )

        if (realized_stcg == 0.0 and realized_ltcg == 0.0
                and unreal_stcl == 0.0 and unreal_ltcl == 0.0
                and bf_stcl == 0.0 and bf_ltcl == 0.0):
            return {
                **base,
                "verdict": "NO TAX POSITION (no realized gains, no harvestable losses, no brought-forward losses)",
                "realized_stcg_inr": round(realized_stcg, 2),
                "realized_ltcg_inr": round(realized_ltcg, 2),
                "harvestable_stcl_inr": round(unreal_stcl, 2),
                "harvestable_ltcl_inr": round(unreal_ltcl, 2),
                "brought_forward_stcl_inr": round(bf_stcl, 2),
                "brought_forward_ltcl_inr": round(bf_ltcl, 2),
                "tax_without_harvest_inr": 0.0,
                "tax_with_harvest_inr": 0.0,
                "immediate_tax_saving_inr": 0.0,
                "assumptions": [
                    _regime_note,
                    _surcharge_note,
                    "Set-off order Sec 70/74: STCL->STCG then LTCG; LTCL->LTCG only",
                    f"LTCG exemption Rs{ltcg_exemption:,.0f} applied to net LTCG after set-offs",
                    f"Unabsorbed losses carry forward {T.CARRY_FORWARD_YEARS} assessment years",
                    _gf_note,
                    f"{unpriced} realized event(s) had no INR P&L (unpriced) — excluded from nets" if unpriced else
                    "All realized ledger events had INR P&L",
                ],
            }

        note_parts = []
        if unreal_stcl > 0 and b["unabsorbed_stcl"] > 0:
            note_parts.append(f"Rs{b['unabsorbed_stcl']:,.0f} of (brought-forward + harvested) STCL "
                              f"remains UNABSORBED this year — carries forward up to "
                              f"{T.CARRY_FORWARD_YEARS} years (Sec 70)")
        if unreal_ltcl > 0 and b["unabsorbed_ltcl"] > 0:
            note_parts.append(f"Rs{b['unabsorbed_ltcl']:,.0f} of (brought-forward + harvested) LTCL "
                              f"remains UNABSORBED (long-term losses can never offset STCG — Sec 70(3))")
        verdict = (
            f"Immediate saving Rs{immediate_saving:,.0f} of tax at today's rates; "
            + ("; ".join(note_parts) if note_parts else "all harvested losses are absorbed this year")
        )

        def _round_scenario(d: Dict[str, Any]) -> Dict[str, Any]:
            return {k: (round(v, 2) if isinstance(v, (int, float)) and not isinstance(v, bool) else v)
                    for k, v in d.items()}

        return {
            **base,
            "verdict": verdict,
            "realized_stcg_inr": round(realized_stcg, 2),
            "realized_ltcg_inr": round(realized_ltcg, 2),
            "harvestable_lots": n_harvestable,
            "harvestable_stcl_inr": round(unreal_stcl, 2),
            "harvestable_ltcl_inr": round(unreal_ltcl, 2),
            "brought_forward_stcl_inr": round(bf_stcl, 2),
            "brought_forward_ltcl_inr": round(bf_ltcl, 2),
            # The set-off walk, both scenarios
            "without_harvest": _round_scenario(a),
            "with_harvest": _round_scenario(b),
            "tax_without_harvest_inr": round(a["tax_inr"], 2),
            "tax_with_harvest_inr": round(b["tax_inr"], 2),
            "immediate_tax_saving_inr": round(immediate_saving, 2),
            "est_stcg_savings_inr": round(stcg_saving_component, 2),
            "est_ltcg_savings_inr": round(ltcg_saving_component, 2),
            "ltcg_exemption_applied_inr": round(exemption_effect, 2),
            "carry_forward_created_stcl_inr": round(b["unabsorbed_stcl"], 2),
            "carry_forward_created_ltcl_inr": round(b["unabsorbed_ltcl"], 2),
            "total_tax_saved_inr": round(immediate_saving, 2),
            # AUDIT-FIX (Round 25 — R25-5): surcharge/cess headline disclosure
            "surcharge_cess_note": _surcharge_note,
            "tax_before_surcharge_without_harvest_inr": round(a["tax_before_surcharge_inr"], 2),
            "surcharge_without_harvest_inr": round(a["surcharge_inr"], 2),
            "cess_without_harvest_inr": round(a["cess_inr"], 2),
            # AUDIT-FIX (Round 26 — R26-1/R26-2): statutory surcharge cap
            # (STCG included) + marginal relief headline disclosure
            "surcharge_gross_without_harvest_inr": round(a["surcharge_gross_inr"], 2),
            "marginal_relief_without_harvest_inr": round(a["marginal_relief_inr"], 2),
            "marginal_relief_basis": a["marginal_relief_basis"],
            "surcharge_rate_stcg_capped": a["surcharge_rate_stcg_capped"],
            "assumptions": [
                _regime_note,
                _surcharge_note,
                "Holding period & AY bucketing on trade dates (Sec 2(42A)); "
                "settlement dates never shift classification",
                "Set-off order Sec 70/74: STCL->STCG then LTCG; LTCL->LTCG only",
                f"LTCG exemption: Rs{ltcg_exemption:,.0f} post-cutoff tranche / "
                f"Rs{EXEM_PRE:,.0f} pre-cutoff tranche, applied to net LTCG after set-offs",
                f"Unabsorbed losses carry forward {T.CARRY_FORWARD_YEARS} assessment years",
                "Immediate saving counts only THIS year's absorbed losses; unabsorbed losses "
                "carry forward (valuable, but not same-year cash)",
                _gf_note,
                f"{unpriced} realized event(s) had no INR P&L (unpriced) — excluded from nets" if unpriced else
                "All realized ledger events had INR P&L",
            ],
        }
