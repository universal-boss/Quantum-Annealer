"""
math_engine/tda_homology.py
===========================
Topological Data Analysis (TDA) Persistent Homology & Betti Number Calculator.

Computes 0-dimensional and 1-dimensional persistent homology metrics (Betti numbers beta_0, beta_1)
on multivariate return correlation manifolds. Detects market topology collapses prior to systemic crashes.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, Tuple

logger = logging.getLogger(__name__)


class TDAHomologyEngine:
    """
    Calculates Topological Persistent Homology (Betti_0 connected components & Betti_1 metric loops)
    on return correlation manifolds.
    """

    @staticmethod
    def compute_persistent_homology_metrics(returns_df: pd.DataFrame,
                                             distance_threshold: float = 0.50) -> Dict[str, Any]:
        """
        Computes Betti_0 (connected component count) and Betti_1 (loop count proxy)
        across distance filtration thresholds.
        """
        if returns_df is None or returns_df.empty or returns_df.shape[1] < 3:
            return {
                "betti_0_components": 1,
                "betti_1_loops": 0,
                "topological_entropy": 0.0,
                "is_manifold_collapse": False
            }

        clean_ret = returns_df.dropna(how="all").fillna(0.0)
        n_assets = clean_ret.shape[1]
        if clean_ret.shape[0] < 10 or n_assets < 3:
            return {
                "betti_0_components": 1,
                "betti_1_loops": 0,
                "topological_entropy": 0.0,
                "is_manifold_collapse": False
            }

        # Correlation distance matrix: D_ij = sqrt( 2 * (1 - C_ij) )
        corr = np.corrcoef(clean_ret.values, rowvar=False)
        corr = np.nan_to_num(corr, nan=0.0)
        np.fill_diagonal(corr, 1.0)
        
        dist = np.sqrt(np.clip(2.0 * (1.0 - corr), 0.0, 4.0))

        # Adjacency graph at distance threshold
        adj = (dist <= distance_threshold).astype(int)
        np.fill_diagonal(adj, 0)

        # Connected components (Betti 0 proxy via graph DFS/BFS)
        visited = set()
        betti_0 = 0
        for i in range(n_assets):
            if i not in visited:
                betti_0 += 1
                queue = [i]
                visited.add(i)
                while queue:
                    curr = queue.pop(0)
                    for neighbor in np.where(adj[curr] == 1)[0]:
                        if neighbor not in visited:
                            visited.add(neighbor)
                            queue.append(neighbor)

        # Betti 1 proxy: Cycle count E - V + C
        n_edges = int(np.sum(adj) // 2)
        betti_1 = max(0, n_edges - n_assets + betti_0)

        # Topological entropy of distance distribution
        triu_dist = dist[np.triu_indices(n_assets, k=1)]
        hist, _ = np.histogram(triu_dist, bins=10, density=True)
        hist = hist[hist > 0]
        topo_entropy = -float(np.sum(hist * np.log(hist + 1e-9)))

        # Market collapse occurs when all assets lockstep into 1 component (betti_0 == 1) and betti_1 drops to 0
        is_collapse = bool(betti_0 == 1 and betti_1 == 0 and corr.mean() > 0.60)

        return {
            "betti_0_components": betti_0,
            "betti_1_loops": betti_1,
            "topological_entropy": round(topo_entropy, 4),
            "mean_correlation": round(float(corr.mean()), 4),
            "is_manifold_collapse": is_collapse
        }
