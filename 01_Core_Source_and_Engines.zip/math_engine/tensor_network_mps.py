"""
math_engine/tensor_network_mps.py
=================================
Sovereign Tier-0+ Quantum-Inspired Matrix Product State (MPS) Tensor Network Engine.

Decomposes large-scale multi-asset covariance and correlation structures into Matrix Product State
(MPS) tensor trains and Matrix Product Operators (MPOs) using sequential Singular Value Decomposition
(SVD) and Schmidt bond-dimension truncation.

Mathematical Foundations:
    1. Matrix Product State (MPS) / Tensor Train Factorization:
       A correlation or high-order risk tensor C_{i_1, ..., i_N} is represented as:
           C_{i_1, ..., i_N} approx A^{[1]}_{i_1} A^{[2]}_{i_2} ... A^{[N]}_{i_N}
       where each A^{[k]} is a 3-way tensor of dimensions (chi_{k-1}, d_k, chi_k).
       
    2. Bond Dimension Truncation (chi <= chi_max):
       Reduces parameter scaling from O(N^3) or O(d^N) down to linear O(N * chi^2),
       enabling instant risk evaluation and contraction across thousands of equities.
       
    3. Quantum Entanglement / von Neumann Entropy:
       Given normalized Schmidt coefficients p_k = lambda_k^2 / sum(lambda_j^2):
           S_vN = - sum_{k=1}^chi p_k * ln(p_k)
       - High S_vN: Systemic market entanglement, non-linear spillover, crisis contagion.
       - Low S_vN: Decoupled sector clusters, high diversification potential.
       
    4. MPS Sequential Contraction:
       w^T C w = sum_{k=1}^chi s_k * (u_k^T w)^2 evaluated in O(N * chi) operations.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Tuple, Union
import numpy as np

logger = logging.getLogger(__name__)


class MatrixProductStateEngine:
    """
    Quantum-Inspired Matrix Product State (MPS) & Tensor Train Engine.
    
    Compresses high-dimensional asset correlation manifolds, denoises trailing noise spectra,
    and quantifies systemic cross-asset market entanglement entropy.
    """

    def __init__(
        self,
        max_bond_dim: int = 16,
        svd_cutoff: float = 1e-5,
    ) -> None:
        self.max_bond_dim = int(max_bond_dim)
        self.svd_cutoff = float(svd_cutoff)

    def decompose_matrix_mps(
        self,
        matrix: np.ndarray,
        max_bond_dim: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Decomposes a symmetric correlation or covariance matrix into a truncated MPS representation
        via Schmidt singular value decomposition:
            M approx U * diag(S) * V^T,  with rank chi <= max_bond_dim.
            
        Returns:
            Dictionary containing:
                - U: Left isometric tensors (N, chi)
                - S: Schmidt singular values (chi,)
                - Vt: Right isometric tensors (chi, N)
                - bond_dim: Retained bond dimension chi
                - entanglement_entropy: von Neumann entropy S_vN
                - reconstruction_error: Frobenius relative error ||M - M_hat||_F / ||M||_F
                - compression_ratio: (N * chi + chi + chi * N) / (N * N)
        """
        mat = np.asarray(matrix, dtype=np.float64)
        n, m = mat.shape
        if n != m:
            raise ValueError(f"Matrix must be square, got ({n}, {m})")
            
        chi_max = int(max_bond_dim or self.max_bond_dim)
        
        # High-performance SVD
        u, s, vt = np.linalg.svd(mat, full_matrices=False)
        
        # Determine cutoff based on relative singular value decay
        total_energy = float(np.sum(s ** 2))
        s_norm = s / (s[0] + 1e-12)
        valid_indices = np.where(s_norm >= self.svd_cutoff)[0]
        
        effective_chi = min(len(valid_indices), chi_max, n)
        effective_chi = max(effective_chi, 1)
        
        u_trunc = u[:, :effective_chi]
        s_trunc = s[:effective_chi]
        vt_trunc = vt[:effective_chi, :]
        
        # 1. von Neumann Entanglement Entropy
        s_sq = s_trunc ** 2
        sum_sq = float(np.sum(s_sq))
        if sum_sq > 0:
            probs = s_sq / sum_sq
            probs = probs[probs > 1e-12]
            entropy = -float(np.sum(probs * np.log(probs)))
        else:
            entropy = 0.0
            
        # 2. Reconstruction error
        reconstructed = (u_trunc * s_trunc) @ vt_trunc
        norm_orig = float(np.linalg.norm(mat, ord="fro"))
        diff_norm = float(np.linalg.norm(mat - reconstructed, ord="fro"))
        rel_error = diff_norm / max(norm_orig, 1e-8)
        
        # 3. Compression ratio
        mps_params = n * effective_chi + effective_chi + effective_chi * n
        full_params = n * n
        compression = float(mps_params / max(full_params, 1))
        
        return {
            "U": u_trunc,
            "S": s_trunc,
            "Vt": vt_trunc,
            "bond_dim": effective_chi,
            "entanglement_entropy": round(entropy, 4),
            "reconstruction_error": round(rel_error, 6),
            "compression_ratio": round(compression, 4),
        }

    def contract_portfolio_risk(
        self,
        weights: np.ndarray,
        mps_dict: Dict[str, Any],
    ) -> float:
        """
        Contracts portfolio variance directly through the MPS tensor cores in O(N * chi) time:
            sigma_p^2 = w^T (U * S * Vt) w = sum_{k=1}^chi S_k * (U_{:, k}^T w) * (Vt_{k, : } w)
        """
        w = np.asarray(weights, dtype=np.float64)
        u = mps_dict["U"]
        s = mps_dict["S"]
        vt = mps_dict["Vt"]
        
        # Project weights onto left and right isometric bases
        w_left = u.T @ w   # (chi,)
        w_right = vt @ w   # (chi,)
        
        # Fast inner contraction with Schmidt weights
        variance = float(np.sum(s * w_left * w_right))
        return max(variance, 0.0)

    def denoise_correlation_matrix(
        self,
        corr_matrix: np.ndarray,
        max_bond_dim: Optional[int] = None,
    ) -> np.ndarray:
        """
        Denoises an empirical correlation matrix using MPS Schmidt rank truncation,
        preserving the trace identity (diag(C) = 1) and positive semi-definiteness.
        """
        decomp = self.decompose_matrix_mps(corr_matrix, max_bond_dim=max_bond_dim)
        u = decomp["U"]
        s = decomp["S"]
        vt = decomp["Vt"]
        
        # Reconstruct filtered matrix
        c_filtered = (u * s) @ vt
        
        # Symmetrize and re-normalize diagonals to 1.0
        c_symm = 0.5 * (c_filtered + c_filtered.T)
        d = np.sqrt(np.maximum(np.diag(c_symm), 1e-8))
        c_denoised = c_symm / np.outer(d, d)
        np.fill_diagonal(c_denoised, 1.0)
        
        return c_denoised

    def compute_market_entanglement(
        self,
        returns_df: Union[np.ndarray, Any],
        max_bond_dim: int = 16,
    ) -> Dict[str, Any]:
        """
        Evaluates real-time systemic market entanglement entropy across an equity universe.
        
        Returns:
            Dictionary with:
                - entanglement_entropy: von Neumann entropy S_vN
                - effective_degrees_of_freedom: exp(S_vN)
                - market_coupling_regime: DECOUPLED, TRANSITIONAL, or SYSTEMIC_CONTAGION
                - dominant_schmidt_ratio: lambda_1^2 / sum(lambda_k^2)
        """
        if hasattr(returns_df, "to_numpy"):
            data = returns_df.dropna(how="all").fillna(0.0).to_numpy(dtype=np.float64)
        else:
            data = np.asarray(returns_df, dtype=np.float64)
            
        t, n = data.shape
        if n < 2:
            return {
                "entanglement_entropy": 0.0,
                "effective_dof": 1.0,
                "market_coupling_regime": "DECOUPLED",
                "dominant_schmidt_ratio": 1.0,
            }
            
        corr = np.corrcoef(data, rowvar=False)
        corr = np.nan_to_num(corr, nan=0.0)
        np.fill_diagonal(corr, 1.0)
        
        decomp = self.decompose_matrix_mps(corr, max_bond_dim=max_bond_dim)
        entropy = decomp["entanglement_entropy"]
        s = decomp["S"]
        
        s_sq = s ** 2
        dom_ratio = float(s_sq[0] / max(np.sum(s_sq), 1e-8))
        eff_dof = float(np.exp(entropy))
        
        # Categorize regime based on entropy vs maximum possible entropy ln(N)
        max_entropy = np.log(max(n, 2))
        normalized_entropy = entropy / max(max_entropy, 1e-4)
        
        if normalized_entropy >= 0.70 or dom_ratio > 0.60:
            regime = "SYSTEMIC_CONTAGION"
        elif normalized_entropy >= 0.40:
            regime = "TRANSITIONAL"
        else:
            regime = "DECOUPLED"
            
        return {
            "entanglement_entropy": round(entropy, 4),
            "normalized_entropy": round(float(normalized_entropy), 4),
            "effective_dof": round(eff_dof, 2),
            "market_coupling_regime": regime,
            "dominant_schmidt_ratio": round(dom_ratio, 4),
            "bond_dim": decomp["bond_dim"],
            "compression_ratio": decomp["compression_ratio"],
        }
