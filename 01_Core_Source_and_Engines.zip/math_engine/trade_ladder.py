"""
math_engine/trade_ladder.py
===========================
Institutional Conformal Trade Exit Ladder & Risk-to-Reward Engine.

Computes exact operational levels for active portfolio allocations:
    1. Entry Price: Validated current market price or limit order level.
    2. Conformal Stop-Loss: Derived from non-parametric 90% conformal drawdown bounds.
    3. Target 1 (1:2 Risk/Reward): Partial profit-taking level (take 50% position off).
    4. Target 2 (1:4 Runner): Multi-week trend extension target.
    5. Chandelier Trailing Stop: Dynamic ATR-ratcheting trail to protect unrealized gains.
"""
from __future__ import annotations

import logging
from typing import Dict, Any, List, Optional
import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


class ConformalTradeLadder:
    """
    Generates institutional trade plan ladders for portfolio holdings.
    """

    @classmethod
    def calculate_stock_ladder(
        cls,
        ticker: str,
        current_price: float,
        price_history: Optional[pd.Series] = None,
        conformal_dd_pct: Optional[float] = None,
        weight_pct: float = 5.0
    ) -> Dict[str, Any]:
        """
        Calculates trade execution ladder for a single stock.
        """
        px = float(current_price) if current_price and current_price > 0 else 100.0

        # 1. Determine Conformal Stop-Loss Percentage
        if conformal_dd_pct is not None and np.isfinite(conformal_dd_pct) and conformal_dd_pct > 0:
            dd_pct = float(conformal_dd_pct)
        elif price_history is not None and len(price_history) >= 20:
            try:
                from math_engine.conformal_risk import ConformalRiskEngine
                bounds = ConformalRiskEngine.calculate_conformal_bounds(price_history, horizon_days=10)
                dd_pct = float(bounds.get("d_max_90_pct", 5.5))
            except Exception:
                dd_pct = 5.5
        else:
            dd_pct = 5.5

        # Bound stop-loss between 3.0% and 8.5% (SEBI institutional guardrails)
        sl_pct = float(np.clip(dd_pct, 3.0, 8.5))
        stop_loss = round(px * (1.0 - sl_pct / 100.0), 2)
        risk_per_share = round(px - stop_loss, 2)

        # 2. Compute 1:2 R:R Target 1 (book 50% position)
        target_1 = round(px + 2.0 * risk_per_share, 2)
        target_1_pct = round(((target_1 - px) / px) * 100.0, 2)

        # 3. Compute 1:4 R:R Target 2 (Runner)
        target_2 = round(px + 4.0 * risk_per_share, 2)
        target_2_pct = round(((target_2 - px) / px) * 100.0, 2)

        # 4. Compute Chandelier Trailing Stop (High - 3*ATR)
        if price_history is not None and len(price_history) >= 14:
            s = price_history.dropna().values
            atr = float(np.mean(np.abs(np.diff(s[-14:])))) if len(s) >= 15 else px * 0.02
            chandelier_trail = round(max(stop_loss, px - 2.5 * atr), 2)
        else:
            chandelier_trail = stop_loss

        return {
            "ticker": ticker,
            "entry_price": round(px, 2),
            "stop_loss": stop_loss,
            "stop_loss_pct": f"-{sl_pct:.2f}%",
            "target_1": target_1,
            "target_1_gain_pct": f"+{target_1_pct:.2f}%",
            "target_2": target_2,
            "target_2_gain_pct": f"+{target_2_pct:.2f}%",
            "chandelier_trail": chandelier_trail,
            "risk_reward_ratio": "1 : 2.0 (Target 1) / 1 : 4.0 (Target 2)",
            "allocation_weight": f"{weight_pct:.2f}%",
            "action_guidance": f"Enter at ₹{px:.2f} | Stop @ ₹{stop_loss:.2f} | Partial Profit @ ₹{target_1:.2f} (+{target_1_pct:.1f}%) | Trail remainder to ₹{target_2:.2f}"
        }

    @classmethod
    def generate_portfolio_trade_ladders(
        cls,
        holdings: List[Dict[str, Any]],
        price_dict: Optional[Dict[str, pd.Series]] = None
    ) -> List[Dict[str, Any]]:
        """
        Generates trade ladders for all active portfolio holdings.
        """
        ladders = []
        for h in holdings:
            sym = h.get("ticker", h.get("Ticker", ""))
            if not sym or sym.upper() == "CASH":
                continue
            px = float(h.get("current_price", h.get("price", h.get("Entry Price", 100.0))) or 100.0)
            w = float(h.get("weight_pct", h.get("weight", h.get("Optimal Weight", 5.0))) or 5.0)
            ph = price_dict.get(sym) if price_dict else None
            ladder = cls.calculate_stock_ladder(sym, px, price_history=ph, weight_pct=w)
            ladders.append(ladder)
        return ladders
