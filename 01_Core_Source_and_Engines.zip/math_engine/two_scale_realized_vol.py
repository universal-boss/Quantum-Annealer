"""
math_engine/two_scale_realized_vol.py
=====================================
Two-Scale Realized Volatility (TSRV) & Microstructure Noise Engine.

Calculates Two-Scale Realized Volatility (TSRV — Zhang, Mykland, Aït-Sahalia 2005)
to eliminate high-frequency microstructure bid-ask bounce noise and extract
unbiased continuous-time asset variance.
"""

from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, Tuple

logger = logging.getLogger(__name__)


class TwoScaleRealizedVolatilityEngine:
    """
    Two-Scale Realized Volatility (TSRV) & Microstructure Noise Estimator.
    Eliminates bid-ask bounce noise in intraday tick series.
    """

    @staticmethod
    def compute_tsrv(
        prices: pd.Series | np.ndarray,
        subsampling_k: int = 5,
        obs_per_day: float = 375.0
    ) -> Dict[str, float]:
        """
        Calculates Two-Scale Realized Volatility (TSRV):
        TSRV = RV_avg - (n_bar / n) * RV_all
        
        Where RV_avg is averaged across K sub-sampled grids, and RV_all is standard high-frequency RV.

        ROUND 45 FIX: `obs_per_day` replaces a hardcoded 375 (1-minute bars) and
        the annualization factor is now sqrt(252 * obs_per_day / n). The old
        formula sqrt(252 * 375 / (n / subsampling_k)) carried an erroneous extra
        factor of subsampling_k (a k=5 run overstated vol by sqrt(5)) and
        forced the intraday assumption on every caller — daily closes were
        annualized ~40x too high (300 daily bars at 1.5% daily vol reported
        ~969% instead of ~24%). Pass obs_per_day=1.0 for daily series.
        """
        p = np.asarray(prices, dtype=float)
        p = p[~np.isnan(p)]
        n = len(p)

        if n < subsampling_k * 2:
            return {
                "tsrv_annualized_vol": 0.20,
                "noise_variance": 0.0,
                "signal_to_noise_ratio": 1.0
            }

        # Log prices for continuous compounding
        log_p = np.log(p)

        # 1. Standard Realized Volatility (all grid)
        rv_all = np.sum(np.diff(log_p) ** 2)

        # 2. Subsampled Realized Volatility averaged across K grids
        rv_sub_sum = 0.0
        n_bar = 0.0

        for m in range(subsampling_k):
            grid_p = log_p[m::subsampling_k]
            if len(grid_p) > 1:
                rv_sub_sum += np.sum(np.diff(grid_p) ** 2)
                n_bar += len(grid_p) - 1

        rv_avg = rv_sub_sum / float(subsampling_k)
        n_bar_avg = n_bar / float(subsampling_k)

        # 3. Two-Scale Correction
        tsrv_var = rv_avg - (n_bar_avg / n) * rv_all
        tsrv_var = max(1e-8, tsrv_var)

        # Microstructure Noise Variance Estimate
        noise_var = (rv_all - tsrv_var) / (2.0 * n)
        noise_var = max(0.0, noise_var)

        # Annualized Volatility: tsrv_var estimates the variance of the efficient
        # price over the WHOLE window. Window length in days = n / obs_per_day, so
        # annualized vol = sqrt(tsrv_var * 252 / (n / obs_per_day)).
        # ROUND 45 FIX: was sqrt(252 * 375 / (n / subsampling_k)) — hardcoded
        # intraday scaling AND an erroneous extra sqrt(subsampling_k) factor.
        n_days = max(n / max(obs_per_day, 1e-9), 1e-9)
        ann_factor = np.sqrt(252.0 / n_days)
        tsrv_ann_vol = round(float(np.sqrt(tsrv_var) * ann_factor), 4)
        snr = round(float(tsrv_var / (rv_all + 1e-9)), 4)

        return {
            "tsrv_annualized_vol": float(tsrv_ann_vol),
            "raw_rv_all": float(round(rv_all, 6)),
            "subsampled_rv_avg": float(round(rv_avg, 6)),
            "noise_variance": float(round(noise_var, 8)),
            "signal_to_noise_ratio": float(snr),
            "is_microstructure_noise_dominant": bool(snr < 0.5)
        }
