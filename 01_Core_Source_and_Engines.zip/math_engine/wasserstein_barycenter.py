"""
math_engine/wasserstein_barycenter.py
======================================
Wasserstein-2 Barycenter Portfolio Fusion Engine.

Merges multiple profile portfolio weight vectors using the Wasserstein-2 barycenter
(Fréchet mean under the 2-Wasserstein metric on the probability simplex).

For discrete 1-D probability distributions (portfolio weight vectors), the
W2 barycenter is solved by the fixed-point iteration of Alvarez-Esteban et al. (2016):
    μ* = argmin Σ_k λ_k * W_2^2(μ, μ_k)
    
Fixed-point update (Wasserstein-2 barycenter on the simplex, 1D case):
    T_k(x) = F_k^{-1}(F_*(x))   (quantile transport map)
    μ*_{n+1} = Σ_k λ_k * T_k # (push-forward mean)

For weight vectors, we use the quantile-based fixed-point solver:
Sort each profile weight vector, compute the weighted mean of sorted quantiles,
and re-assign to tickers based on original ordering (Bonneel et al. 2015).

If `pot` (Python Optimal Transport) library is available, uses the true
`ot.lp.barycenter()` solver. Falls back to the quantile iteration otherwise.

References:
    - Alvarez-Esteban et al. (2016). "A fixed-point approach to barycenters in Wasserstein space."
    - Bonneel et al. (2015). "Sliced and Radon Wasserstein Barycenters of Measures."
    - Peyré & Cuturi (2019). "Computational Optimal Transport."
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, List, Optional

logger = logging.getLogger(__name__)


class WassersteinBarycenterEngine:
    """
    Wasserstein-2 Barycenter Portfolio Weight Fusion Engine.

    Fuses multiple portfolio weight vectors from different screening profiles
    into a single consensus allocation using the Wasserstein-2 Fréchet mean.
    """

    @staticmethod
    def compute_barycenter_weights(
        profile_weights_list: List[Dict[str, float]],
        profile_lambdas: Optional[List[float]] = None
    ) -> Dict[str, float]:
        """
        Computes Wasserstein-2 barycenter mean across multiple profile weight vectors.

        Uses the quantile fixed-point iteration (Wasserstein-2 barycenter on 1D simplex):
            1. Normalize each profile weight vector to a valid probability distribution.
            2. Sort each to its quantile function F_k^{-1}.
            3. Compute the λ-weighted average quantile (the barycenter quantile function).
            4. Re-assign tickers by rank-preserving transport map.

        If the `pot` library is available, uses `ot.lp.barycenter()` as the exact solver.

        Args:
            profile_weights_list: List of weight dicts, one per screening profile.
            profile_lambdas: Optional per-profile importance weights (uniform if None).

        Returns:
            Dict mapping ticker → fused barycenter weight (sums to 1.0).
        """
        if not profile_weights_list:
            return {}

        all_tickers = sorted(list(set(t for pw in profile_weights_list for t in pw.keys())))
        if not all_tickers:
            return {}

        n_profiles = len(profile_weights_list)
        n_assets = len(all_tickers)

        # Profile weights (lambdas): default uniform
        if profile_lambdas is None or len(profile_lambdas) != n_profiles:
            lambdas = np.ones(n_profiles) / n_profiles
        else:
            lambdas = np.asarray(profile_lambdas, dtype=float)
            lambdas = lambdas / (np.sum(lambdas) + 1e-9)

        # Build matrix: (n_profiles × n_assets)
        matrix = np.zeros((n_profiles, n_assets))
        for i, pw in enumerate(profile_weights_list):
            for j, t in enumerate(all_tickers):
                matrix[i, j] = max(0.0, pw.get(t, 0.0))

        # Normalize each profile row to sum to 1 (valid probability vector)
        row_sums = matrix.sum(axis=1, keepdims=True) + 1e-9
        matrix = matrix / row_sums

        # --- Attempt POT exact Wasserstein barycenter ---
        try:
            import ot
            # Each row is a histogram over n_assets support points
            # ot.lp.barycenter requires (n_support, n_histograms)
            A = matrix.T  # shape (n_assets, n_profiles)
            weights_ot = lambdas.astype(float)
            bary = ot.lp.barycenter(A, weights_ot)
            bary = np.maximum(bary, 0.0)
            bary /= (np.sum(bary) + 1e-9)
            logger.info("[WassersteinBarycenter] Used exact POT ot.lp.barycenter solver.")
            return {t: round(float(bary[j]), 4) for j, t in enumerate(all_tickers)}

        except ImportError:
            logger.debug("[WassersteinBarycenter] POT library not found — using quantile fixed-point iteration.")
        except Exception as ex:
            logger.debug(f"[WassersteinBarycenter] POT solver failed: {ex}. Using quantile fallback.", exc_info=True)

        # --- Quantile fixed-point iteration (Wasserstein-2 barycenter, 1D case) ---
        # Step 1: Sort each profile weight vector (ascending quantile function)
        sorted_matrix = np.sort(matrix, axis=1)          # (n_profiles, n_assets)
        sorted_indices = np.argsort(matrix, axis=1)       # (n_profiles, n_assets)

        # Step 2: Weighted mean across sorted quantile positions → barycenter quantile
        # barycenter[q] = Σ_k λ_k * F_k^{-1}(q)
        barycenter_quantile = np.einsum("k,kj->j", lambdas, sorted_matrix)  # (n_assets,)

        # Step 3: Re-assign to tickers via rank-preserving transport map
        # Use the centroid profile (highest lambda) as reference ordering
        ref_profile_idx = int(np.argmax(lambdas))
        ref_order = sorted_indices[ref_profile_idx]   # reference ticker rank ordering

        # Map barycenter quantile values back to ticker positions
        barycenter_weights = np.zeros(n_assets)
        barycenter_weights[ref_order] = np.sort(barycenter_quantile)

        # Normalize to valid probability simplex
        total = np.sum(barycenter_weights)
        if total > 1e-9:
            barycenter_weights /= total
        else:
            barycenter_weights = np.ones(n_assets) / n_assets

        logger.info(
            f"[WassersteinBarycenter] Quantile fixed-point barycenter computed across "
            f"{n_profiles} profiles, {n_assets} assets."
        )

        return {t: round(float(barycenter_weights[j]), 4) for j, t in enumerate(all_tickers)}
