"""
math_engine/wasserstein_calibrator.py
=====================================
Empirical bootstrap calibrator for Wasserstein DRO uncertainty radius.
Replaces static 1/sqrt(T) heuristics with asset-universe-specific sampling variance estimates.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


class WassersteinRadiusCalibrator:
    """Calibrates Wasserstein DRO uncertainty boundary from returns statistics."""

    @staticmethod
    def calibrate_radius(
        returns_df: pd.DataFrame,
        n_bootstrap: int = 100
    ) -> float:
        """Calibrates the uncertainty radius epsilon using subsample bootstrapping.
        
        Calculates the mean absolute difference in sub-sampled return distributions
        to proxy the expected deviation of out-of-sample expected returns.
        """
        if returns_df.empty or len(returns_df) < 10:
            logger.info("[WassersteinCalibrator] Too few return observations. Using default radius of 0.01.")
            return 0.01

        T, N = returns_df.shape
        rets = returns_df.fillna(0.0).to_numpy()

        subsample_size = max(5, T // 2)
        differences = []

        # ROUND 45 FIX: was np.random.seed(42) + global-state draws (this
        # calibrator runs inside the optimizer pipeline and silently reseeded
        # the host process RNG). Local Generator preserves determinism.
        _rng = np.random.default_rng(42)
        for _ in range(n_bootstrap):
            # Sample two distinct halves of the returns timeline
            idx1 = _rng.choice(T, size=subsample_size, replace=True)
            idx2 = _rng.choice(T, size=subsample_size, replace=True)
            
            mean1 = rets[idx1].mean(axis=0)
            mean2 = rets[idx2].mean(axis=0)
            
            # L2 distance between mean vectors represents the variance in return expectations
            dist = float(np.linalg.norm(mean1 - mean2))
            differences.append(dist)

        # Average bootstrap difference scaled by sample size decay
        avg_diff = float(np.mean(differences))
        calibrated_radius = avg_diff / np.sqrt(T)

        # Clamping limits: prevent excessively large or tiny radius boundaries
        clamped_radius = float(np.clip(calibrated_radius, 0.005, 0.08))
        logger.info(
            f"[WassersteinCalibrator] Calibrated empirical Wasserstein radius: "
            f"{calibrated_radius:.6f} -> clamped to {clamped_radius:.6f}"
        )
        return clamped_radius
