"""
math_engine/wasserstein_manifold_dro.py
======================================
Sovereign Tier-0+ Geodesic Sinkhorn Wasserstein Distributionally Robust Optimization (DRO).

Operates on the Riemannian manifold of Symmetric Positive Definite (SPD) covariance matrices S_{++}^N
and the space of probability measures with entropic optimal transport regularization.

Mathematical Foundations:
    1. Affine-Invariant Riemannian Metric (AIRM) on SPD Cone:
       d_{AIRM}(Sigma_1, Sigma_2) = ||log(Sigma_1^{-1/2} Sigma_2 Sigma_1^{-1/2})||_F
                                  = sqrt( sum_{i=1}^N ln^2(lambda_i) )
       where lambda_i are the generalized eigenvalues of (Sigma_2, Sigma_1).
       
    2. Bures-Wasserstein Metric between Gaussians:
       W_2^2(N_1, N_2) = ||mu_1 - mu_2||_2^2 + Tr(Sigma_1 + Sigma_2 - 2 * (Sigma_1^{1/2} Sigma_2 Sigma_1^{1/2})^{1/2})
       
    3. Entropic Sinkhorn-Knopp Regularized Optimal Transport:
       min_{P in U(a, b)} <P, C> + epsilon * H(P)
       solved via scalable log-stabilized matrix-vector scaling.
       
    4. Geodesic Uncertainty Ball & Worst-Case Adversarial Market:
       For ambiguity radius rho > 0 on S_{++}^N and mean uncertainty kappa > 0:
       Sigma^*(w) = Sigma_hat + (exp(rho) - 1) * (Sigma_hat w w^T Sigma_hat) / (w^T Sigma_hat w)
       mu^*(w) = mu_hat - kappa * sqrt(w^T Sigma_hat w) * (Sigma_hat w) / ||Sigma_hat^{1/2} w||_2
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Tuple, Union
import numpy as np
import scipy.linalg as sla

logger = logging.getLogger(__name__)


class SinkhornWassersteinDROEngine:
    """
    Distributionally Robust Portfolio Optimization Engine via Geodesic Sinkhorn Wasserstein Ambiguity.
    
    Protects multi-asset portfolios against worst-case adversarial covariance shifts,
    structural regime changes, and fat-tailed finite-sample estimation errors.
    """

    def __init__(
        self,
        default_rho: float = 0.15,
        default_kappa: float = 0.10,
        sinkhorn_epsilon: float = 0.02,
        sinkhorn_max_iter: int = 300,
        sinkhorn_tol: float = 1e-6,
    ) -> None:
        self.default_rho = float(default_rho)
        self.default_kappa = float(default_kappa)
        self.sinkhorn_epsilon = float(sinkhorn_epsilon)
        self.sinkhorn_max_iter = int(sinkhorn_max_iter)
        self.sinkhorn_tol = float(sinkhorn_tol)

    @staticmethod
    def _matrix_sqrt_spd(mat: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """
        Computes symmetric square root Sigma^{1/2} and inverse square root Sigma^{-1/2}
        via eigenvalue decomposition, ensuring strictly positive eigenvalues.
        """
        evals, evecs = np.linalg.eigh(mat)
        evals_pos = np.maximum(evals, 1e-9)
        sqrt_evals = np.sqrt(evals_pos)
        inv_sqrt_evals = 1.0 / sqrt_evals
        
        sqrt_mat = (evecs * sqrt_evals) @ evecs.T
        inv_sqrt_mat = (evecs * inv_sqrt_evals) @ evecs.T
        return sqrt_mat, inv_sqrt_mat

    def riemannian_distance(self, sigma1: np.ndarray, sigma2: np.ndarray) -> float:
        """
        Computes the Affine-Invariant Riemannian Metric (AIRM) distance between two SPD matrices:
            d_AIRM(Sigma1, Sigma2) = sqrt( sum_{i=1}^N ln^2(lambda_i) )
        where lambda_i are generalized eigenvalues solving Sigma2 v = lambda Sigma1 v.
        """
        n = sigma1.shape[0]
        if sigma2.shape != (n, n):
            raise ValueError(f"Shape mismatch: {sigma1.shape} vs {sigma2.shape}")
            
        # Regularize matrices for numerical stability
        s1 = sigma1 + np.eye(n) * 1e-8
        s2 = sigma2 + np.eye(n) * 1e-8
        
        try:
            # Generalized eigenvalues of pencil (s2, s1)
            gen_evals = sla.eigvals(s2, s1)
            real_evals = np.real(gen_evals)
            pos_evals = np.maximum(real_evals, 1e-12)
            log_evals = np.log(pos_evals)
            dist = float(np.sqrt(np.sum(log_evals ** 2)))
            return dist
        except Exception as e:
            logger.warning("[WassersteinDRO] AIRM computation fallback: %s", e)
            _, inv_sqrt1 = self._matrix_sqrt_spd(s1)
            mid = inv_sqrt1 @ s2 @ inv_sqrt1
            evals = np.maximum(np.linalg.eigvalsh(mid), 1e-12)
            return float(np.sqrt(np.sum(np.log(evals) ** 2)))

    def bures_wasserstein_distance(
        self,
        mu1: np.ndarray,
        sigma1: np.ndarray,
        mu2: np.ndarray,
        sigma2: np.ndarray,
    ) -> float:
        """
        Computes the 2-Wasserstein distance between Gaussian measures N(mu1, Sigma1) and N(mu2, Sigma2):
            W_2^2 = ||mu1 - mu2||_2^2 + Tr(Sigma1 + Sigma2 - 2 * (Sigma1^{1/2} Sigma2 Sigma1^{1/2})^{1/2})
        """
        mean_diff_sq = float(np.sum((mu1 - mu2) ** 2))
        
        n = sigma1.shape[0]
        s1 = sigma1 + np.eye(n) * 1e-8
        s2 = sigma2 + np.eye(n) * 1e-8
        
        sqrt1, _ = self._matrix_sqrt_spd(s1)
        mid = sqrt1 @ s2 @ sqrt1
        mid = 0.5 * (mid + mid.T)
        
        sqrt_mid, _ = self._matrix_sqrt_spd(mid)
        cross_term = float(np.trace(sqrt_mid))
        
        bw_cov_sq = float(np.trace(s1) + np.trace(s2) - 2.0 * cross_term)
        total_w2_sq = max(mean_diff_sq + max(bw_cov_sq, 0.0), 0.0)
        return float(np.sqrt(total_w2_sq))

    def sinkhorn_optimal_transport(
        self,
        a: np.ndarray,
        b: np.ndarray,
        cost_matrix: np.ndarray,
        epsilon: Optional[float] = None,
    ) -> Tuple[np.ndarray, float]:
        """
        Computes entropic regularized optimal transport plan via Sinkhorn-Knopp algorithm:
            min_{P in U(a, b)} <P, C> + eps * H(P)
            
        Returns:
            Tuple of:
                - P: Optimal coupling matrix of shape (n, m)
                - dist: Transport cost <P, C>
        """
        eps = float(epsilon or self.sinkhorn_epsilon)
        a_norm = a / np.sum(a)
        b_norm = b / np.sum(b)
        
        # Gibbs kernel K = exp(-C / eps)
        scaled_c = cost_matrix / max(eps, 1e-6)
        scaled_c -= np.min(scaled_c)  # Prevent numerical underflow
        K = np.exp(-scaled_c)
        
        u = np.ones_like(a_norm)
        v = np.ones_like(b_norm)
        
        for _ in range(self.sinkhorn_max_iter):
            u_prev = u.copy()
            Kv = K @ v
            u = a_norm / (Kv + 1e-14)
            KTu = K.T @ u
            v = b_norm / (KTu + 1e-14)
            
            if np.max(np.abs(u - u_prev)) < self.sinkhorn_tol:
                break
                
        P = np.diag(u) @ K @ np.diag(v)
        P /= np.sum(P)
        ot_cost = float(np.sum(P * cost_matrix))
        return P, ot_cost

    def compute_worst_case_covariance(
        self,
        sigma_hat: np.ndarray,
        weights: np.ndarray,
        rho: Optional[float] = None,
    ) -> np.ndarray:
        """
        Computes the worst-case adversarial covariance matrix Sigma^*(w) within
        the geodesic Riemannian ambiguity ball of radius rho:
            Sigma^*(w) = Sigma_hat + (exp(rho) - 1) * (Sigma_hat w w^T Sigma_hat) / (w^T Sigma_hat w)
            
        Properties:
            1. Sigma^*(w) is guaranteed strictly Symmetric Positive Definite.
            2. Adversarial portfolio variance: w^T Sigma^*(w) w = exp(rho) * (w^T Sigma_hat w).
            3. Affine-invariant Riemannian distance d_AIRM(Sigma^*(w), Sigma_hat) == rho.
        """
        rho_val = float(rho or self.default_rho)
        w = np.asarray(weights, dtype=np.float64)
        w_norm = np.sum(np.abs(w))
        if w_norm > 0:
            w = w / w_norm
            
        nominal_var = float(w @ sigma_hat @ w)
        if nominal_var <= 1e-12:
            return sigma_hat.copy()
            
        # Directional projection vector
        sig_w = sigma_hat @ w
        outer_prod = np.outer(sig_w, sig_w)
        
        inflation_factor = np.exp(rho_val) - 1.0
        worst_case_sigma = sigma_hat + inflation_factor * (outer_prod / nominal_var)
        
        # Enforce exact symmetry
        worst_case_sigma = 0.5 * (worst_case_sigma + worst_case_sigma.T)
        return worst_case_sigma

    def compute_worst_case_return(
        self,
        mu_hat: np.ndarray,
        sigma_hat: np.ndarray,
        weights: np.ndarray,
        kappa: Optional[float] = None,
    ) -> Tuple[np.ndarray, float]:
        """
        Computes worst-case expected return vector and portfolio return under mean uncertainty ball:
            mu^*(w) = mu_hat - kappa * sqrt(w^T Sigma_hat w) * (Sigma_hat w) / ||Sigma_hat^{1/2} w||_2
            r^*(w) = w^T mu_hat - kappa * sqrt(w^T Sigma_hat w)
        """
        kappa_val = float(kappa or self.default_kappa)
        w = np.asarray(weights, dtype=np.float64)
        port_vol = float(np.sqrt(max(w @ sigma_hat @ w, 1e-12)))
        
        sig_w = sigma_hat @ w
        norm_sig_w = float(np.sqrt(max(w @ sig_w, 1e-12)))
        
        haircut_vec = kappa_val * port_vol * (sig_w / (norm_sig_w + 1e-12))
        mu_worst = mu_hat - haircut_vec
        worst_case_port_ret = float(w @ mu_hat - kappa_val * port_vol)
        
        return mu_worst, worst_case_port_ret

    def solve_robust_weights(
        self,
        mu_hat: np.ndarray,
        sigma_hat: np.ndarray,
        risk_aversion: float = 1.0,
        rho: Optional[float] = None,
        kappa: Optional[float] = None,
        max_iter: int = 250,
        step_size: float = 0.05,
    ) -> np.ndarray:
        """
        Solves the Distributionally Robust Portfolio Optimization problem:
            max_{w in Delta} min_{P in B_rho,kappa} E_P[w^T r] - 0.5 * gamma * Var_P(w^T r)
            <=> max_{w in Delta} w^T mu_hat - kappa * ||Sigma_hat^{1/2} w||_2 - 0.5 * gamma * exp(rho) * w^T Sigma_hat w
            
        Solved via Projected Gradient Descent onto the probability simplex Delta.
        """
        gamma = float(risk_aversion)
        rho_val = float(rho or self.default_rho)
        kappa_val = float(kappa or self.default_kappa)
        n = len(mu_hat)
        
        # Initialize uniformly on simplex
        w = np.ones(n, dtype=np.float64) / n
        
        def project_simplex(v: np.ndarray) -> np.ndarray:
            """Exact projection onto the probability simplex sum(w)=1, w>=0 (Duchi et al., 2008)."""
            u = np.sort(v)[::-1]
            cssv = np.cumsum(u)
            rho_idx = np.nonzero(u * np.arange(1, n + 1) > (cssv - 1.0))[0][-1]
            theta = (cssv[rho_idx] - 1.0) / (rho_idx + 1.0)
            return np.maximum(v - theta, 0.0)

        effective_cov = sigma_hat * np.exp(rho_val)
        
        for _ in range(max_iter):
            port_var = float(w @ sigma_hat @ w)
            port_sd = np.sqrt(max(port_var, 1e-12))
            
            # Gradient of objective f(w) with respect to w:
            # grad = mu_hat - kappa * (sigma_hat @ w) / port_sd - gamma * effective_cov @ w
            grad = mu_hat - kappa_val * (sigma_hat @ w) / port_sd - gamma * (effective_cov @ w)
            
            # Gradient ascent step + projection
            w_next = project_simplex(w + step_size * grad)
            
            if np.linalg.norm(w_next - w) < 1e-6:
                w = w_next
                break
            w = w_next
            
        return w

    def calibrate_ambiguity_radius(
        self,
        n_assets: int,
        n_samples: int,
        confidence_level: float = 0.95,
    ) -> float:
        """
        Calibrates the Wasserstein/Geodesic ambiguity radius rho from finite-sample concentration:
            rho = C * sqrt( (n_assets * ln(n_samples)) / n_samples )
        """
        c = 0.75 * np.sqrt(-2.0 * np.log(1.0 - confidence_level))
        radius = c * np.sqrt((n_assets * np.log(max(n_samples, 2))) / max(n_samples, 10))
        return float(np.clip(radius, 0.05, 0.60))
