"""
math_engine/watchlist_exporter.py
=================================
One-Click Broker & Platform Watchlist Exporter.

Formats screened swing trading picks for instant copy-paste or file import into:
1. TradingView: Comma-separated 'NSE:TICKER, NSE:TICKER'
2. Zerodha Kite: Standard symbol newline list
3. DhanHQ: CSV format with Exchange, Symbol, Segment
4. Clean Text / Markdown Summary with Entry, Target, and Stop Loss
"""
from __future__ import annotations

import logging
from typing import List, Dict, Any, Optional
import pandas as pd

logger = logging.getLogger(__name__)


class WatchlistExporter:
    """Formats and exports stock lists for trading platforms and brokers."""

    @staticmethod
    def clean_ticker(ticker: str) -> str:
        """Strips exchange suffixes like .NS or .BO."""
        t = ticker.strip().upper()
        for suffix in [".NS", ".BO", "-EQ", ".BSE", ".NSE"]:
            if t.endswith(suffix):
                t = t[:-len(suffix)]
        return t

    @classmethod
    def to_tradingview_format(cls, tickers: List[str], prefix: str = "NSE:") -> str:
        """
        Formats list of tickers for TradingView watchlist import.
        Example: 'NSE:TCS, NSE:INFY, NSE:HDFCBANK'
        """
        cleaned = [f"{prefix}{cls.clean_ticker(t)}" for t in tickers if t]
        return ", ".join(cleaned)

    @classmethod
    def to_zerodha_kite_format(cls, tickers: List[str]) -> str:
        """
        Formats list of tickers for Zerodha Kite copy-paste (newline delimited).
        """
        cleaned = [cls.clean_ticker(t) for t in tickers if t]
        return "\n".join(cleaned)

    @classmethod
    def to_angelone_csv_format(cls, tickers: List[str]) -> pd.DataFrame:
        """
        Generates Angel One SmartAPI watchlist / basket order CSV DataFrame.
        """
        rows = []
        for t in tickers:
            clean = cls.clean_ticker(t)
            rows.append({
                "Exchange": "NSE",
                "TradingSymbol": clean,
                "Segment": "EQ",
                "ProductType": "DELIVERY",
                "OrderType": "LIMIT"
            })
        return pd.DataFrame(rows)

    @classmethod
    def to_dhan_csv_format(cls, tickers: List[str]) -> pd.DataFrame:
        """Legacy alias: forwards to to_angelone_csv_format."""
        return cls.to_angelone_csv_format(tickers)

    @classmethod
    def generate_trade_sheet_markdown(
        cls,
        basket_data: List[Dict[str, Any]],
        title: str = "🎯 Quantum Annealer Swing Trade Plan"
    ) -> str:
        """
        Generates clean markdown table with Entry, Snell Target, and Stop-Loss.
        """
        lines = [
            f"# {title}",
            "",
            "| Ticker | Entry Price | Snell Target (+18%) | Stop Loss (-5%) | Weight | Classification |",
            "| :--- | :---: | :---: | :---: | :---: | :--- |"
        ]

        for item in basket_data:
            ticker = cls.clean_ticker(item.get("ticker", "N/A"))
            entry = float(item.get("entry_price", item.get("current_price", 100.0)))
            target = float(item.get("snell_target_price", entry * 1.18))
            sl = float(item.get("stop_loss_price", entry * 0.95))
            wt = float(item.get("weight_pct", 5.0))
            cls_name = item.get("classification", "Breakout")

            lines.append(f"| **{ticker}** | ₹{entry:.2f} | **₹{target:.2f}** | ₹{sl:.2f} | {wt:.1f}% | {cls_name} |")

        return "\n".join(lines)
