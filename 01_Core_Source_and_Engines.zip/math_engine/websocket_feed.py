"""
math_engine/websocket_feed.py
=============================
WebSocket feed connectors for real-time price tick streaming.
Provides a live Zerodha Kite Connect ticker wrapper and a mock ticker for offline testing.
"""
import logging
import time
import random
import threading
from typing import Dict, List, Callable, Any, Optional

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────
def _norm_symbol(sym: str) -> str:
    """Normalize tickers to a consistent uppercase broker symbol."""
    return str(sym).strip().upper().replace(".NS", "").replace(".BO", "")

# Try to import kiteconnect, fail gracefully if not installed
try:
    from kiteconnect import KiteTicker, KiteConnect
    KITE_AVAILABLE = True
except ImportError:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    KITE_AVAILABLE = False
    KiteTicker = None
    KiteConnect = None


class WebSocketFeedBase:
    """Base class for websocket price feeds to ensure unified interface."""

    def __init__(self, symbols: List[str]):
        # Normalize symbols (e.g. remove .NS Yahoo Finance suffix if present)
        self.symbols = [_norm_symbol(s) for s in symbols]
        self.callbacks: List[Callable[[Dict[str, Any]], None]] = []
        self.is_connected = False

    def register_callback(self, cb: Callable[[Dict[str, Any]], None]):
        """Register a callback function to receive tick updates."""
        if cb not in self.callbacks:
            self.callbacks.append(cb)

    def unregister_callback(self, cb: Callable[[Dict[str, Any]], None]):
        """Unregister a callback function."""
        if cb in self.callbacks:
            self.callbacks.remove(cb)

    def dispatch_tick(self, symbol: str, price: float, timestamp: float):
        """Dispatch a single price tick to all registered callbacks."""
        tick_data = {
            "symbol": symbol.upper(),
            "last_price": float(price),
            "timestamp": float(timestamp)
        }
        for cb in self.callbacks:
            try:
                cb(tick_data)
            except Exception as e:
                logger.error(f"Error dispatching tick callback: {e}", exc_info=True)


class KiteWebSocketClient(WebSocketFeedBase):
    """Live WebSocket feed client using Zerodha Kite Connect KiteTicker."""

    def __init__(self, api_key: str, access_token: str, symbols: List[str], kite_client: Optional[Any] = None):
        super().__init__(symbols)
        self.api_key = api_key
        self.access_token = access_token
        self.kite_client = kite_client
        self.kws: Optional[Any] = None
        self.symbol_to_token: Dict[str, int] = {}
        self.token_to_symbol: Dict[int, str] = {}

    def connect(self):
        """Connect to Zerodha KiteTicker and subscribe to symbols."""
        if not KITE_AVAILABLE:
            raise ImportError(
                "kiteconnect is not installed. Install it using 'pip install kiteconnect'."
            )

        # ROUND 45 FIX: double-connect guard. KiteWebSocketClient had none
        # (the polling/mock clients do), so a second connect() leaked the
        # previous KiteTicker session and its callbacks (tracked in the repo
        # worklog since Round 39).
        if self.is_connected:
            logger.info("KiteWebSocketClient already connected — connect() ignored.")
            return

        if not self.api_key or not self.access_token:
            raise ValueError("API Key and Access Token must be provided for live Kite ticker.")

        # 1. Fetch instruments mapping (symbols to tokens)
        self._resolve_instrument_tokens()

        if not self.symbol_to_token:
            # Treat as a hard failure so callers (e.g. UI worker threads) can surface a clear error.
            raise RuntimeError(
                "No instrument tokens mapped for requested symbols. "
                "Check that your symbols are valid NSE tradingsymbols and that Kite credentials are correct."
            )

        # 2. Setup KiteTicker
        self.kws = KiteTicker(self.api_key, self.access_token)

        # Phase 6.3: Enable auto-reconnect so a single network blip doesn't
        # permanently kill the live feed. Previously: no reconnect params were
        # set, so any disconnect silently fell back to stale data with no alert.
        # KiteTicker supports: auto_reconnect, reconnect_max_tries, reconnect_max_delay
        try:
            self.kws.auto_reconnect = True
            self.kws.reconnect_max_tries = 10
            self.kws.reconnect_max_delay = 60
        except Exception as _re:
            logger.warning(f"[WebSocket] Could not set auto_reconnect params: {_re}", exc_info=True)

        # Bind callbacks
        self.kws.on_connect = self._on_connect
        self.kws.on_ticks = self._on_ticks
        self.kws.on_close = self._on_close
        self.kws.on_error = self._on_error
        self.kws.on_noreconnect = self._on_noreconnect
        # Phase 6.3: Add on_reconnect callback to re-subscribe after reconnect
        if hasattr(self.kws, "on_reconnect"):
            self.kws.on_reconnect = self._on_reconnect

        # Connect asynchronously in the background
        logger.info("Connecting to KiteTicker...")
        self.kws.connect(threaded=True)

        # Wait briefly for the on_connect callback to flip is_connected.
        # Without this, callers may assume we're connected when we're not.
        t0 = time.time()
        timeout_s = 10.0
        while not self.is_connected and (time.time() - t0) < timeout_s:
            time.sleep(0.1)
        if not self.is_connected:
            if self.kws:
                try:
                    self.kws.close()
                except Exception as ex:
                    logger.error(f"Error closing KiteTicker on connection timeout: {ex}", exc_info=True)
            raise TimeoutError("Timed out waiting for KiteTicker to connect (no on_connect received).")

    def _resolve_instrument_tokens(self):
        """Use KiteConnect client to fetch all NSE instruments and map tokens."""
        try:
            # If no kite_client passed, try initializing one
            kc = self.kite_client
            if kc is None:
                kc = KiteConnect(api_key=self.api_key)
                kc.set_access_token(self.access_token)

            logger.info("Fetching NSE instruments from Kite Connect...")
            instruments = kc.instruments("NSE")
            
            # Map tradingsymbol to instrument_token
            mapped_symbols = set(self.symbols)
            for inst in instruments:
                tsym = inst.get("tradingsymbol", "").upper()
                if tsym in mapped_symbols:
                    token = inst.get("instrument_token")
                    if token:
                        self.symbol_to_token[tsym] = int(token)
                        self.token_to_symbol[int(token)] = tsym
            
            logger.info(f"Mapped {len(self.symbol_to_token)} symbols to instrument tokens.")
            # ROUND 45 FIX: symbols that fail resolution were silently dropped
            # (connect() only hard-fails when ZERO map) — the UI then showed a
            # frozen price with no alert. Surface the unmapped list loudly.
            _unmapped = [s for s in self.symbols if s.upper() not in self.symbol_to_token]
            if _unmapped:
                logger.warning(
                    "KiteWebSocketClient: %d symbol(s) could not be resolved to "
                    "NSE instrument tokens and will NOT be subscribed (no ticks): %s",
                    len(_unmapped), ", ".join(map(str, _unmapped[:10])),
                )
        except Exception as e:
            logger.error(f"Failed to fetch/resolve instrument tokens: {e}", exc_info=True)

    def _on_connect(self, ws, response):
        self.is_connected = True
        logger.info("KiteTicker connected successfully.")
        
        # Subscribe to instrument tokens
        tokens = list(self.symbol_to_token.values())
        if tokens:
            logger.info(f"Subscribing to tokens: {tokens}")
            ws.subscribe(tokens)
            ws.set_mode(ws.modeFull, tokens)

    def _on_ticks(self, ws, ticks):
        for t in ticks:
            token = t.get("instrument_token")
            symbol = self.token_to_symbol.get(token)
            price = t.get("last_price")
            if symbol and price is not None:
                timestamp = t.get("timestamp") or time.time()
                # If timestamp is a datetime object, convert to epoch
                if hasattr(timestamp, "timestamp"):
                    timestamp = timestamp.timestamp()
                self.dispatch_tick(symbol, price, timestamp)

    def _on_close(self, ws, code, reason):
        self.is_connected = False
        logger.info(f"KiteTicker closed. Code: {code}, Reason: {reason}")

    def _on_error(self, ws, code, reason):
        logger.error(f"KiteTicker error. Code: {code}, Reason: {reason}")

    def _on_noreconnect(self, ws):
        # Phase 6.3: Log CRITICAL — auto-reconnect exhausted, feed is dead
        logger.critical("KiteTicker reconnect failed permanently after max retries. "
                        "Live feed is dead — falling back to stale data. "
                        "Manual intervention required.")

    def _on_reconnect(self, ws, attempts_count):
        # Phase 6.3: Log reconnect attempts so operators can monitor feed health
        logger.warning(f"KiteTicker reconnecting (attempt {attempts_count})...")

    def disconnect(self):
        """Stop KiteTicker connection."""
        if self.kws:
            self.kws.close()
            self.is_connected = False
            logger.info("KiteTicker disconnected.")


class AngelOnePollingFeedClient(WebSocketFeedBase):
    """Live Price Polling Feed using AngelOneAdapter."""

    def __init__(self, api_key: str, client_id: str, symbols: List[str], poll_interval: float = 2.0):
        super().__init__(symbols)
        self.api_key = api_key
        self.client_id = client_id
        self.poll_interval = poll_interval
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self.adapter = None

    def connect(self):
        if self.is_connected:
            return
        from math_engine.broker_router import AngelOneAdapter
        self.adapter = AngelOneAdapter(self.api_key, self.client_id)
        self.is_connected = True
        # ROUND 45 FIX: a FRESH stop event per connect cycle. The old code
        # cleared the SHARED event on reconnect, which could resurrect a
        # previous worker thread whose join(2s) had timed out mid-sleep —
        # two polling threads, every tick dispatched twice (verified). The
        # thread now also captures ITS OWN event via the target argument, so
        # replacing self._stop_event can never un-stop a live worker.
        evt = threading.Event()
        self._stop_event = evt
        self._thread = threading.Thread(target=self._run_polling, name="AngelPollFeed", daemon=True, args=(evt,))
        self._thread.start()
        logger.info("AngelOnePollingFeedClient connected (polling thread started).")

    def _run_polling(self, stop_event=None):
        stop = stop_event if stop_event is not None else self._stop_event
        while not stop.is_set():
            timestamp = time.time()
            for sym in self.symbols:
                if self._stop_event.is_set():
                    break
                try:
                    price = self.adapter.get_ltp(sym)
                    if price > 0:
                        self.dispatch_tick(sym, price, timestamp)
                except Exception as e:
                    logger.warning(f"AngelOnePollingFeedClient error fetching LTP for {sym}: {e}", exc_info=True)
                time.sleep(0.2)
            time.sleep(self.poll_interval)

    def disconnect(self):
        if not self.is_connected:
            return
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=2.0)
            if self._thread.is_alive():
                # ROUND 45 FIX: surface the zombie instead of silently letting a
                # future connect() resurrect it (fresh per-connect events make
                # resurrection impossible; this warning explains any lag).
                logger.warning(
                    "AngelOnePollingFeedClient worker did not exit within 2s "
                    "(long poll pass in flight); it will stop at the next loop check."
                )
        self.is_connected = False
        logger.info("AngelOnePollingFeedClient disconnected.")


# Backward-compatibility alias
DhanPollingFeedClient = AngelOnePollingFeedClient


class MockWebSocketClient(WebSocketFeedBase):
    """Simulated WebSocket feed client generating random walk ticks."""

    def __init__(self, symbols: List[str], initial_prices: Optional[Dict[str, float]] = None, tick_interval: float = 1.0):
        super().__init__(symbols)
        self.tick_interval = tick_interval
        self.initial_prices = initial_prices or {}
        
        self.prices: Dict[str, float] = {}
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()

        # Initialize base prices
        for sym in self.symbols:
            # Check direct or stripped symbol
            base_p = (
                self.initial_prices.get(sym)
                or self.initial_prices.get(f"{sym}.NS")
                or self.initial_prices.get(sym.lower())
                or 100.0
            )
            self.prices[sym] = float(base_p)

    def connect(self):
        """Start the background generation thread."""
        if self.is_connected:
            return
        
        self.is_connected = True
        # ROUND 45 FIX: fresh stop event per connect + thread-owned reference
        # (see AngelOnePollingFeedClient.connect) — the shared-event clear
        # resurrected timed-out workers and double-dispatched ticks.
        evt = threading.Event()
        self._stop_event = evt
        self._thread = threading.Thread(target=self._run_simulation, name="MockWSFeed", daemon=True, args=(evt,))
        self._thread.start()
        logger.info("MockWebSocketClient connected (simulation thread started).")

    def _run_simulation(self, stop_event=None):
        """Random walk price tick generator loop."""
        stop = stop_event if stop_event is not None else self._stop_event
        while not stop.is_set():
            # Emit tick for a random symbol (or all of them in a burst)
            # Emit for all symbols to keep state fresh
            timestamp = time.time()
            for sym in self.symbols:
                # Random walk: standard deviation of 0.1% per tick
                change = random.gauss(0.0, 0.001)
                self.prices[sym] *= (1.0 + change)
                
                # Ensure price doesn't go below zero
                if self.prices[sym] < 1.0:
                    self.prices[sym] = 1.0

                self.dispatch_tick(sym, self.prices[sym], timestamp)
            
            time.sleep(self.tick_interval)

    def disconnect(self):
        """Stop the simulation thread."""
        if not self.is_connected:
            return
        
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=2.0)
        self.is_connected = False
        logger.info("MockWebSocketClient disconnected (simulation thread stopped).")
