"""
math_engine/worldquant_operators.py
===================================
WorldQuant 101 Formulaic Alpha Cross-Sectional Operator Algebra.

Implements pure vectorized cross-sectional and time-series primitives:
1. rank(x): Cross-sectional percentile rank in [0, 1].
2. ts_rank(x, d): Time-series percentile rank over lookback window d.
3. indneutralize(x, groups): Group/industry neutralization (demeaned within sector).
4. decay_linear(x, d): Linearly decaying weighted moving average.
5. ts_corr(x, y, d): Rolling cross-sectional correlation between factors x and y.
6. ts_covariance(x, y, d): Rolling cross-sectional covariance.
7. scale(x, a=1.0): Rescales array such that sum(|x|) = a.
"""
from __future__ import annotations

import logging
from typing import Dict, List, Optional, Union
import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


class WorldQuantOperators:
    """Vectorized WorldQuant formulaic alpha operator primitives."""

    @staticmethod
    def rank(series: Union[pd.Series, np.ndarray]) -> np.ndarray:
        """
        Cross-sectional percentile rank across the asset universe in range [0, 1].
        """
        s = np.asarray(series, dtype=float)
        valid_mask = ~np.isnan(s)
        ranked = np.full(s.shape, np.nan)
        if np.sum(valid_mask) > 1:
            vals = s[valid_mask]
            order = np.argsort(vals)
            ranks = np.empty_like(order, dtype=float)
            ranks[order] = np.linspace(0.0, 1.0, len(vals))
            ranked[valid_mask] = ranks
        elif np.sum(valid_mask) == 1:
            ranked[valid_mask] = 0.5
        return ranked

    @staticmethod
    def ts_rank(series: Union[pd.Series, np.ndarray], window: int = 10) -> np.ndarray:
        """
        Time-series percentile rank of current value relative to past d-day history.
        ts_rank(x_t, d) = sum(I(x_t >= x_{t-k})) / d
        """
        s = pd.Series(series).astype(float)
        if len(s) < window:
            return np.full(len(s), 0.5)

        def rolling_rank(arr):
            val = arr[-1]
            return float(np.sum(val >= arr) / len(arr))

        res = s.rolling(window=window, min_periods=max(2, window // 2)).apply(rolling_rank, raw=True)
        return res.bfill().fillna(0.5).values

    @staticmethod
    def indneutralize(
        factor_values: Union[pd.Series, np.ndarray, Dict[str, float]],
        industry_groups: Union[pd.Series, Dict[str, str], List[str]]
    ) -> pd.Series:
        """
        Industry Neutralization:
        demeans factor values within each industry/sector group to eliminate sector-wide bias:
        x_neutral = x_i - (1 / |G_k|) * sum_{j in G_k} x_j
        """
        f_series = pd.Series(factor_values, dtype=float)
        g_series = pd.Series(industry_groups)
        
        df = pd.DataFrame({"factor": f_series, "group": g_series})
        group_means = df.groupby("group")["factor"].transform("mean")
        neutral_factor = df["factor"] - group_means.fillna(df["factor"].mean())
        return neutral_factor

    @staticmethod
    def decay_linear(series: Union[pd.Series, np.ndarray], window: int = 10) -> np.ndarray:
        """
        Weighted moving average with linearly decaying weights:
        decay_linear(x, d) = sum_{k=0}^{d-1} (d - k) x_{t-k} / sum_{k=0}^{d-1} (d - k)
        """
        s = pd.Series(series).astype(float)
        weights = np.arange(1, window + 1, dtype=float)
        weights_sum = weights.sum()

        def apply_decay(arr):
            w = weights[-len(arr):]
            return float(np.sum(arr * w) / np.sum(w))

        res = s.rolling(window=window, min_periods=1).apply(apply_decay, raw=True)
        return res.values

    @staticmethod
    def ts_corr(
        series_x: Union[pd.Series, np.ndarray],
        series_y: Union[pd.Series, np.ndarray],
        window: int = 10
    ) -> np.ndarray:
        """
        Rolling time-series Pearson correlation between factor x and factor y.
        """
        sx = pd.Series(series_x).astype(float)
        sy = pd.Series(series_y).astype(float)
        corr = sx.rolling(window=window, min_periods=max(3, window // 2)).corr(sy)
        return corr.bfill().fillna(0.0).values

    @staticmethod
    def scale(series: Union[pd.Series, np.ndarray], target_sum: float = 1.0) -> np.ndarray:
        """
        Rescales factor array such that sum(|x|) = target_sum while preserving sign.
        """
        s = np.asarray(series, dtype=float)
        abs_sum = np.nansum(np.abs(s))
        if abs_sum > 1e-9:
            return s * (target_sum / abs_sum)
        return np.full_like(s, target_sum / max(len(s), 1))
