"""ML Alpha Engine — institutional-grade factor + ML ensemble for the Quantum Annealer."""
import os
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("VECLIB_MAXIMUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")
try:
    import torch
    torch.set_num_threads(1)
    if hasattr(torch, "set_num_interop_threads"):
        try:
            torch.set_num_interop_threads(1)
        except Exception:
            pass
except ImportError:
    pass

# ── CORE imports (must succeed) ─────────────────────────────────────────────
from .engine import AlphaEngine, FitResult
from .factors import compute_all_factors
from .model import AlphaEnsemble
from .universal_engine import UniversalAlphaEngine, ArchWrap

# ── OPTIONAL imports (degrade gracefully if dependencies missing) ──────────
__all__ = [
    "AlphaEngine",
    "FitResult",
    "compute_all_factors",
    "AlphaEnsemble",
    "UniversalAlphaEngine",
    "ArchWrap",
]

try:
    from .expanded_ensemble import ExpandedAlphaEnsemble
    __all__.append("ExpandedAlphaEnsemble")
except Exception:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    pass

try:
    from .microstructure_factors import compute_100_institutional_factors
    from .stacking_learner import StackingSuperLearner
    __all__.extend(["compute_100_institutional_factors", "StackingSuperLearner"])
except Exception:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    pass

try:
    from .walk_forward import WalkForwardCV, CombinatorialPurgedCV
    __all__.extend(["WalkForwardCV", "CombinatorialPurgedCV"])
except Exception:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    pass

try:
    from .metrics import deflated_sharpe_ratio, spearman_ic
    __all__.extend(["deflated_sharpe_ratio", "spearman_ic"])
except Exception:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    pass

try:
    from .labeling import triple_barrier_labels, compute_daily_volatility
    __all__.extend(["triple_barrier_labels", "compute_daily_volatility"])
except Exception:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    pass

try:
    from .feature_selection import select_factors
    __all__.append("select_factors")
except Exception:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    pass

try:
    from .feature_engineering import engineer_features, fractional_difference
    __all__.extend(["engineer_features", "fractional_difference"])
except Exception:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    pass

try:
    from .feature_store import FeatureStore, ExperimentTracker
    __all__.extend(["FeatureStore", "ExperimentTracker"])
except Exception:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    pass

try:
    from .hyperopt import optimize_all_models
    __all__.append("optimize_all_models")
except Exception:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    pass

try:
    from .alt_factors import ALT_FACTOR_NAMES
    __all__.append("ALT_FACTOR_NAMES")
except Exception:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    pass

try:
    from .advanced_ml import TFTPredictor, StockCorrelationGraph, SimpleRLAgent, granger_causality_test
    __all__.extend(["TFTPredictor", "StockCorrelationGraph", "SimpleRLAgent", "granger_causality_test"])
except Exception:
    pass

try:
    from .prebreakout_model import PreBreakoutInceptionModel, PREBREAKOUT_FACTOR_NAMES
    __all__.extend(["PreBreakoutInceptionModel", "PREBREAKOUT_FACTOR_NAMES"])
except Exception:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)
    pass

__version__ = "3.0.0"
