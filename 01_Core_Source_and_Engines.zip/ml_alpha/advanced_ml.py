"""Advanced ML models — Transformer, GNN, RL, Causal Inference.

Cutting-edge ML approaches beyond the standard ensemble:

  1. Temporal Fusion Transformer (TFT) — state-of-the-art time-series forecasting
  2. Graph Neural Network (GNN) — model stock correlations as a graph
  3. Reinforcement Learning (RL) — learn optimal rebalancing policy
  4. Causal Inference — do-calculus for factor attribution

These are research-grade models that require significant compute and data.
They're included as optional modules — the standard ensemble remains the
primary model.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Optional, List, Dict
import logging

logger = logging.getLogger(__name__)

# Check for optional dependencies
try:
    import torch
    import torch.nn as nn
    _HAS_TORCH = True
except ImportError:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    _HAS_TORCH = False

try:
    import networkx as nx
    _HAS_NETWORKX = True
except ImportError:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    _HAS_NETWORKX = False


# ═══════════════════════════════════════════════════════════════════════════════
# TEMPORAL FUSION TRANSFORMER (TFT)
# ═══════════════════════════════════════════════════════════════════════════════

if _HAS_TORCH:

    class TemporalFusionTransformer(nn.Module):
        """Simplified Temporal Fusion Transformer for time-series prediction.

        TFT combines:
          - LSTM for temporal processing
          - Multi-head attention for long-range dependencies
          - Gating mechanisms to suppress unnecessary components
          - Variable selection network

        This is a simplified version — full TFT has 8+ components.
        """

        def __init__(
            self,
            n_features: int,
            hidden_dim: int = 64,
            n_heads: int = 4,
            n_layers: int = 2,
            dropout: float = 0.1,
        ):
            super().__init__()
            self.n_features = n_features
            self.hidden_dim = hidden_dim

            # Input projection
            self.input_proj = nn.Linear(n_features, hidden_dim)

            # LSTM for temporal processing
            self.lstm = nn.LSTM(
                hidden_dim, hidden_dim,
                num_layers=n_layers,
                batch_first=True,
                dropout=dropout,
            )

            # Multi-head self-attention
            self.attention = nn.MultiheadAttention(
                hidden_dim, n_heads,
                dropout=dropout,
                batch_first=True,
            )

            # Output projection
            self.output_proj = nn.Linear(hidden_dim, 1)

            # Gating mechanism
            self.gate = nn.Sequential(
                nn.Linear(hidden_dim, hidden_dim),
                nn.Sigmoid(),
            )

            self.dropout = nn.Dropout(dropout)
            self.layer_norm = nn.LayerNorm(hidden_dim)

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            """Forward pass.

            Args:
                x: Input tensor of shape (batch, seq_len, n_features).

            Returns:
                Output tensor of shape (batch, 1).
            """
            # Project input
            x = self.input_proj(x)  # (batch, seq, hidden)

            # LSTM
            lstm_out, _ = self.lstm(x)  # (batch, seq, hidden)

            # Self-attention
            attn_out, _ = self.attention(lstm_out, lstm_out, lstm_out)
            attn_out = self.dropout(attn_out)

            # Residual + LayerNorm
            x = self.layer_norm(lstm_out + attn_out)

            # Gating
            gate = self.gate(x)
            x = x * gate

            # Output (use last timestep)
            output = self.output_proj(x[:, -1, :])  # (batch, 1)

            return output.squeeze(-1)


    class TFTPredictor:
        """Wrapper for Temporal Fusion Transformer training and prediction.

        AUDIT-FIX (Round 8, C1 — Part 2B): two integrity defects fixed.

        1. SEQUENCES MIXED TICKERS. The training panel is (date, ticker)-ordered
           rows; _create_sequences sliced X[i:i+seq_len] across consecutive rows,
           blending different tickers into one "sequence" with a target belonging
           to yet another ticker. Sequences are now built WITHIN each ticker's own
           history (groups auto-detected from a MultiIndex level 1, a 'ticker'
           column, or the groups= argument).

        2. PREDICT EMITTED A CONSTANT. predict() took the LAST seq_len rows of
           the whole panel (whatever tickers they happened to be), predicted
           once, and repeated that single number to every row — a rank-inert
           constant blended into every ticker's alpha. predict() now predicts
           per ticker using that ticker's own trailing history within the input,
           and returns NaN for rows/tickers without enough history (the engine
           skips the blend for those rows instead of injecting noise).
        """

        def __init__(
            self,
            n_features: int,
            seq_len: int = 21,
            hidden_dim: int = 64,
            n_heads: int = 4,
            lr: float = 0.001,
            epochs: int = 50,
            batch_size: int = 64,
        ):
            self.seq_len = seq_len
            self.epochs = epochs
            self.batch_size = batch_size

            if torch.cuda.is_available():
                self.device = torch.device("cuda")
            elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
                self.device = torch.device("mps")
            else:
                self.device = torch.device("cpu")

            self.model = TemporalFusionTransformer(
                n_features=n_features,
                hidden_dim=hidden_dim,
                n_heads=n_heads,
            ).to(self.device)

            self.optimizer = torch.optim.Adam(self.model.parameters(), lr=lr)
            self.criterion = nn.MSELoss()

        def __getstate__(self):
            """Serialize model weights strictly on CPU to guarantee Linux/cross-platform unpickling."""
            state = self.__dict__.copy()
            if hasattr(self, "model") and hasattr(self.model, "cpu"):
                state["model"] = self.model.cpu()
            state["device"] = torch.device("cpu")
            return state

        def __setstate__(self, state):
            """Restore model and map to local hardware device (CUDA > MPS > CPU)."""
            self.__dict__.update(state)
            if torch.cuda.is_available():
                self.device = torch.device("cuda")
            elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
                self.device = torch.device("mps")
            else:
                self.device = torch.device("cpu")
            if hasattr(self, "model") and hasattr(self.model, "to"):
                self.model = self.model.to(self.device)

        @staticmethod
        def _extract_groups(X: pd.DataFrame, groups: pd.Series | None = None) -> pd.Series | None:
            """Resolve a per-row ticker label: explicit groups arg > MultiIndex
            level 1 > 'ticker' column > None (single unnamed series)."""
            if groups is not None and len(groups) == len(X):
                return pd.Series(groups.to_numpy() if hasattr(groups, "to_numpy") else groups,
                                 index=X.index)
            if isinstance(X.index, pd.MultiIndex) and X.index.nlevels >= 2:
                return pd.Series(X.index.get_level_values(-1), index=X.index)
            if "ticker" in getattr(X, "columns", []):
                return X["ticker"]
            return None

        def _create_sequences(self, X: np.ndarray, y: np.ndarray, row_groups: pd.Series | None = None) -> tuple:
            """Create (sequence, target) pairs for time-series prediction.

            AUDIT-FIX (Round 8, C1 / Round 17): when row_groups is provided, sequences are
            built strictly WITHIN each group (same ticker) across its chronological history,
            regardless of whether X is sorted by (date, ticker) or (ticker, date).
            Without groups, behaves as a pure single-series splitter.
            """
            sequences = []
            targets = []
            if row_groups is None:
                for i in range(self.seq_len, len(X)):
                    sequences.append(X[i - self.seq_len: i])
                    targets.append(y[i])
            else:
                grp = row_groups.to_numpy()
                unique_groups = pd.unique(grp)
                for g in unique_groups:
                    idx_g = np.where(grp == g)[0]
                    if len(idx_g) > self.seq_len:
                        for k in range(self.seq_len, len(idx_g)):
                            sequences.append(X[idx_g[k - self.seq_len: k]])
                            targets.append(y[idx_g[k]])
            return np.array(sequences), np.array(targets)

        def fit(self, X: pd.DataFrame, y: pd.Series, groups: pd.Series | None = None) -> dict:
            """Train the TFT model using mini-batches for speed and memory efficiency."""
            X_arr = X.fillna(0).to_numpy(dtype=np.float32)
            y_arr = y.to_numpy(dtype=np.float32)
            row_groups = self._extract_groups(X, groups)

            X_seq, y_seq = self._create_sequences(X_arr, y_arr, row_groups)

            if len(X_seq) < self.batch_size:
                logger.warning("Not enough data for TFT training (%d sequences)", len(X_seq))
                return {"trained": False}

            from torch.utils.data import TensorDataset, DataLoader
            X_tensor = torch.FloatTensor(X_seq)
            y_tensor = torch.FloatTensor(y_seq)

            dataset = TensorDataset(X_tensor, y_tensor)
            # AUDIT-FIX (Round 8, C1): `max(self.batch_size, 512)` forced a
            # 512-row batch regardless of the constructor value (probably a
            # min/max typo) — giant batches degrade LSTM-attention training on
            # small datasets. Uses the configured batch size now.
            loader = DataLoader(dataset, batch_size=self.batch_size, shuffle=True)

            self.model.train()
            epoch_loss = 0.0
            for epoch in range(self.epochs):
                epoch_loss = 0.0
                for batch_x, batch_y in loader:
                    batch_x = batch_x.to(self.device)
                    batch_y = batch_y.to(self.device)

                    self.optimizer.zero_grad()
                    pred = self.model(batch_x)
                    loss = self.criterion(pred, batch_y)
                    loss.backward()
                    self.optimizer.step()
                    epoch_loss += loss.item() * len(batch_x)

                epoch_loss /= len(X_seq)
                if (epoch + 1) % 10 == 0 or epoch == 0:
                    logger.info(f"TFT Epoch {epoch+1}/{self.epochs}, Loss: {epoch_loss:.6f}")

            return {"trained": True, "final_loss": float(epoch_loss), "n_sequences": int(len(X_seq))}

        def predict(self, X: pd.DataFrame, groups: pd.Series | None = None) -> pd.Series:
            """Per-ticker prediction using each ticker's own trailing history.

            AUDIT-FIX (Round 8, C1): returns a Series aligned to X.index where
            each row is predicted from the preceding `seq_len` rows OF THE SAME
            ticker inside X. Rows without sufficient same-ticker history get NaN
            (never a repeated constant). If X is a single cross-section (one row
            per ticker — no history), ALL rows are NaN: an honest "cannot
            predict" instead of the previous constant.
            """
            self.model.eval()
            X_arr = X.fillna(0).to_numpy(dtype=np.float32)
            row_groups = self._extract_groups(X, groups)

            out = np.full(len(X), np.nan, dtype=np.float32)

            if row_groups is None:
                if len(X_arr) > self.seq_len:
                    recent = X_arr[-self.seq_len:].reshape(1, self.seq_len, -1)
                    X_tensor = torch.FloatTensor(recent).to(self.device)
                    with torch.no_grad():
                        pred = self.model(X_tensor)
                    out[-1] = float(pred.cpu().numpy().flatten()[0])
                return pd.Series(out, index=X.index, name="tft_pred")

            grp = row_groups.to_numpy()
            unique_groups = pd.unique(grp)
            for g in unique_groups:
                idx_g = np.where(grp == g)[0]
                if len(idx_g) >= self.seq_len:
                    seqs = []
                    tgt_indices = []
                    for k in range(self.seq_len, len(idx_g)):
                        seqs.append(X_arr[idx_g[k - self.seq_len: k]])
                        tgt_indices.append(idx_g[k])
                    if seqs:
                        X_tensor = torch.FloatTensor(np.array(seqs)).to(self.device)
                        with torch.no_grad():
                            preds = self.model(X_tensor).cpu().numpy().flatten()
                        out[tgt_indices] = preds

            if np.all(np.isnan(out)):
                logger.info("TFT predict: no row had %d rows of same-ticker history — "
                            "returning all-NaN (no constant injection)", self.seq_len)
            return pd.Series(out, index=X.index, name="tft_pred")

else:
    # Stub if torch not available
    class TFTPredictor:
        def __init__(self, *args, **kwargs):
            logger.warning("PyTorch not installed — TFT model unavailable")
        def fit(self, *args, **kwargs):
            return {"trained": False}
        def predict(self, X, groups=None):
            # AUDIT-FIX (Round 8, C1 — Part 2B): NaN, not zeros — a zero score
            # is a fabricated prediction; NaN lets the ensemble skip the blend.
            return pd.Series(np.full(len(X), np.nan), index=X.index)


# ═══════════════════════════════════════════════════════════════════════════════
# GRAPH NEURAL NETWORK (GNN) for stock correlations
# ═══════════════════════════════════════════════════════════════════════════════

class StockCorrelationGraph:
    """Model stock correlations as a graph for GNN processing.

    Nodes = stocks, Edges = correlation strength.
    Useful for:
      - Detecting regime-dependent correlation shifts
      - Identifying clusters of correlated stocks
      - Predicting contagion during market stress
    """

    def __init__(self, correlation_threshold: float = 0.5):
        self.threshold = correlation_threshold
        self.graph = None

    def build_graph(self, returns: pd.DataFrame):
        """Build correlation graph from returns.

        Args:
            returns: DataFrame[date × ticker] of stock returns.
        """
        if not _HAS_NETWORKX:
            logger.warning("NetworkX not installed — GNN graph unavailable")
            return

        # Compute correlation matrix
        corr = returns.corr()

        # Build graph
        self.graph = nx.Graph()

        # Add nodes
        for ticker in corr.columns:
            self.graph.add_node(ticker)

        # Add edges for high correlations
        for i, t1 in enumerate(corr.columns):
            for j, t2 in enumerate(corr.columns):
                if i < j and abs(corr.iloc[i, j]) > self.threshold:
                    self.graph.add_edge(t1, t2, weight=corr.iloc[i, j])

        logger.info(f"Built correlation graph: {self.graph.number_of_nodes()} nodes, "
                    f"{self.graph.number_of_edges()} edges")

    def detect_clusters(self) -> Dict[str, List[str]]:
        """Detect clusters of correlated stocks.

        Returns:
            Dict[cluster_id → list of tickers].
        """
        if self.graph is None or not _HAS_NETWORKX:
            return {}

        # Use community detection
        try:
            from networkx.algorithms.community import greedy_modularity_communities
            communities = greedy_modularity_communities(self.graph)

            result = {}
            for i, comm in enumerate(communities):
                result[f"cluster_{i}"] = list(comm)
            return result
        except Exception as e:
            logger.warning(f"Community detection failed: {e}", exc_info=True)
            return {}

    def find_central_stocks(self, top_k: int = 10) -> List[str]:
        """Find most central stocks (highest degree centrality).

        Central stocks are likely to cause contagion if they crash.
        """
        if self.graph is None or not _HAS_NETWORKX:
            return []

        centrality = nx.degree_centrality(self.graph)
        sorted_stocks = sorted(centrality.items(), key=lambda x: -x[1])
        return [s for s, _ in sorted_stocks[:top_k]]


# ═══════════════════════════════════════════════════════════════════════════════
# REINFORCEMENT LEARNING (simplified)
# ═══════════════════════════════════════════════════════════════════════════════

class SimpleRLAgent:
    """Simplified RL agent for portfolio rebalancing.

    Uses Q-learning on a discretized state-action space.
    Full RL would use Deep Q-Networks (DQN) or Proximal Policy Optimization (PPO).

    State: (current_weights, market_features)
    Action: rebalance to new_weights
    Reward: portfolio return - transaction costs
    """

    def __init__(
        self,
        n_assets: int,
        learning_rate: float = 0.01,
        discount: float = 0.95,
        epsilon: float = 0.1,
    ):
        self.n_assets = n_assets
        self.lr = learning_rate
        self.discount = discount
        self.epsilon = epsilon
        self.q_table: Dict[tuple, np.ndarray] = {}

    def _discretize_state(self, weights: np.ndarray, features: np.ndarray) -> tuple:
        """Discretize continuous state for Q-table lookup."""
        # Simplified: discretize weights into 5 bins each
        w_bins = np.digitize(weights, [0.2, 0.4, 0.6, 0.8])
        f_bins = np.digitize(features[:5], np.percentile(features[:5], [20, 40, 60, 80]))
        return tuple(w_bins) + tuple(f_bins)

    def get_action(self, state: tuple) -> np.ndarray:
        """Epsilon-greedy action selection."""
        if np.random.random() < self.epsilon:
            # Random action
            action = np.random.dirichlet(np.ones(self.n_assets))
        else:
            # Greedy: best Q-value action
            if state in self.q_table:
                action_idx = np.argmax(self.q_table[state])
                # Convert action index to weight vector (simplified)
                action = np.zeros(self.n_assets)
                action[action_idx % self.n_assets] = 1.0
            else:
                action = np.ones(self.n_assets) / self.n_assets

        return action

    def update(
        self,
        state: tuple,
        action: np.ndarray,
        reward: float,
        next_state: tuple,
    ):
        """Q-learning update."""
        if state not in self.q_table:
            self.q_table[state] = np.zeros(self.n_assets)

        if next_state not in self.q_table:
            self.q_table[next_state] = np.zeros(self.n_assets)

        action_idx = np.argmax(action)
        best_next = np.max(self.q_table[next_state])

        # Q-learning update rule
        self.q_table[state][action_idx] += self.lr * (
            reward + self.discount * best_next - self.q_table[state][action_idx]
        )


# ═══════════════════════════════════════════════════════════════════════════════
# CAUSAL INFERENCE
# ═══════════════════════════════════════════════════════════════════════════════

def granger_causality_test(
    cause: pd.Series,
    effect: pd.Series,
    max_lag: int = 5,
) -> dict:
    """Granger causality test — does `cause` predict `effect`?

    Unlike correlation, Granger causality tests whether past values of
    `cause` help predict `effect` beyond what `effect`'s own past predicts.

    Args:
        cause: Potential causal series.
        effect: Potential effect series.
        max_lag: Maximum lag to test.

    Returns:
        Dict with test statistics and p-values.
    """
    try:
        from statsmodels.tsa.stattools import grangercausalitytests
        data = pd.DataFrame({"effect": effect, "cause": cause}).dropna()
        results = grangercausalitytests(data[["effect", "cause"]], maxlag=max_lag, verbose=False)

        p_values = {}
        for lag in range(1, max_lag + 1):
            test = results[lag][0]["ssr_ftest"]
            p_values[lag] = test[1]  # p-value

        # Minimum p-value across lags
        min_p = min(p_values.values())
        is_causal = min_p < 0.05

        return {
            "is_causal": is_causal,
            "min_p_value": min_p,
            "p_values_by_lag": p_values,
            "best_lag": min(p_values, key=p_values.get),
        }
    except ImportError:
        logger.warning("statsmodels not installed — Granger test unavailable")
        return {"is_causal": False, "error": "statsmodels not installed"}
    except Exception as e:
        return {"is_causal": False, "error": str(e)}


def do_calculus_attribution(
    returns: pd.DataFrame,
    factors: pd.DataFrame,
    intervention: str = "momentum_12_1",
) -> dict:
    """Do-calculus for factor attribution (causal, not correlational).

    Estimates the causal effect of a factor on returns using:
      1. Granger causality test
      2. Instrumental variable estimation (if instruments available)
      3. Difference-in-differences (if natural experiments available)

    This is research-grade — full causal inference requires domain expertise
    to identify valid instruments and natural experiments.
    """
    results = {}

    if intervention in factors.columns and intervention in returns.columns:
        # Granger test: does factor cause returns?
        gc_result = granger_causality_test(
            factors[intervention],
            returns[intervention],
        )
        results["granger"] = gc_result

    # Simple OLS for comparison (correlational, not causal)
    try:
        from sklearn.linear_model import LinearRegression
        common = factors.index.intersection(returns.index)
        X = factors.loc[common].fillna(0)
        y = returns.loc[common].fillna(0)

        model = LinearRegression()
        model.fit(X, y)
        results["ols_coefficients"] = dict(zip(X.columns, model.coef_))
        results["ols_r2"] = float(model.score(X, y))
    except Exception:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
        pass

    return results
