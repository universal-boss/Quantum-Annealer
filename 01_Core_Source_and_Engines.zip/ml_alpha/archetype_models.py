"""
ml_alpha/archetype_models.py
============================
Dedicated, Purpose-Built Institutional Machine Learning Alpha Models for the 5 Archetypes:

1. 🦄 High-Growth IPO · Multibagger Hunter
   -> IPOMultibaggerModel (ml_alpha/ipo_model.py)
   -> Architecture: Itô Neural SDE + Transformer Attention + Base Formation Geometry

2. 🚀 Momentum & Vol Squeeze · Institutional Alpha
   -> MomentumPatchTSTModel (ml_alpha_momentum.pkl)
   -> Architecture: Patch Time Series Transformer (PatchTSTAlphaEngine) + Microstructure VPIN & VCP Contraction

3. 🏦 Institutional Flow & Smart Money
   -> InstitutionalFlowGATModel (ml_alpha_flow.pkl)
   -> Architecture: Dynamic Graph Attention Network (DynamicGATEngine) + Order-Flow Spillovers & Block Deals

4. 🏛️ Quality Growth & GARP Compounders
   -> QualityCausalGARPModel (ml_alpha_quality.pkl)
   -> Architecture: Pearlian Structural Causal Models (PearlianCausalDiscoveryEngine / DirectLiNGAM) + Do-Calculus

5. 🛡️ All-Weather & Capital Preservation
   -> AllWeatherLiquidODEModel (ml_alpha_defensive.pkl)
   -> Architecture: Continuous-Time Liquid Neural ODE (LiquidNeuralODEEngine) + Dynamic Time-Constant Conductance
"""
from __future__ import annotations

import datetime
import hashlib
import logging
import os
import pickle
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple, Union

import numpy as np
import pandas as pd
from scipy.stats import norm, spearmanr
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.linear_model import Ridge

from math_engine.institutional.deflated_sharpe import deflated_sharpe_ratio
from ml_alpha.causal_structural_discovery import PearlianCausalDiscoveryEngine
from ml_alpha.graph_attention_network import DynamicGATEngine
from ml_alpha.liquid_neural_ode import LiquidNeuralODEEngine
from ml_alpha.patch_tst_engine import PatchTSTAlphaEngine

logger = logging.getLogger("quantum_annealer.archetype_ml")

WORKSPACE = Path(__file__).resolve().parent.parent
MODEL_DIR = WORKSPACE / "models"

# ─────────────────────────────────────────────────────────────────────────────
# Factor Definitions for each Archetype
# ─────────────────────────────────────────────────────────────────────────────

MOMENTUM_FACTOR_NAMES = [
    "z_rs_rating",
    "z_mom_3m",
    "z_mom_6m",
    "z_vcp",
    "z_vpin_toxicity",
    "z_range_contraction",
    "z_vol_surge",
    "z_ma_compression",
    "z_obv_slope",
    "z_ann_vol",
    "z_trend_quality",
    "z_beta",
    "z_downside_vol",
    "z_patch_tst_alpha",
]

FLOW_FACTOR_NAMES = [
    "z_sast_vel",
    "z_bulk_deal_footprint",
    "z_cmf",
    "z_delivery",
    "z_obv_slope",
    "z_updown_vol",
    "z_pead",
    "z_float_squeeze",
    "z_volume_dryup",
    "z_ann_vol",
    "z_downside_vol",
    "z_trend_quality",
    "z_beta",
]

QUALITY_FACTOR_NAMES = [
    "z_roe",
    "z_pe_inv",
    "z_de_inv",
    "z_rev_growth",
    "z_vcp",
    "z_trend_quality",
    "z_ann_vol",
    "z_downside_vol",
    "z_beta",
    "z_drawdown",
]

DEFENSIVE_FACTOR_NAMES = [
    "z_ann_vol",
    "z_downside_vol",
    "z_drawdown",
    "z_beta",
    "z_trend_quality",
    "z_roe",
    "z_delivery",
]


# ─────────────────────────────────────────────────────────────────────────────
# Purged & Embargoed Cross-Validation Engine (CPCV)
# ─────────────────────────────────────────────────────────────────────────────

def compute_purged_embargo_cv_metrics(
    X_mat: np.ndarray,
    y_vec: np.ndarray,
    fit_predict_fn: Callable[[np.ndarray, np.ndarray, np.ndarray], np.ndarray],
    n_splits: int = 5,
    embargo_fraction: float = 0.02,
    n_trials: int = 15,
    as_of_dates: Optional[Sequence] = None,
    embargo_days: Optional[int] = None,
    fold_local_zscore: bool = True,
) -> Dict[str, Any]:
    """
    Computes authentic Purged & Embargoed Cross-Validation (CPCV) out-of-sample metrics.

    ROUND-43 FIX (R6 / AUDIT-06, H-2): when ``as_of_dates`` is supplied, rows
    are first stably sorted date-major so the n_splits contiguous folds are
    genuine TIME blocks (not sets of tickers), and the embargo is applied on
    the as-of time axis in DAYS: every training row whose as-of date lies
    within ``embargo_days`` calendar days of the test block's date range is
    purged — for every ticker — eliminating both same-ticker serial
    correlation and cross-ticker regime/date leakage. When ``as_of_dates`` is
    None the legacy row-position behaviour is kept (backward compatibility),
    which is only sound if the caller guarantees chronological row order.

    ROUND-43 FIX (R8 / AUDIT-19, L-2): ``fold_local_zscore=True`` (default)
    re-normalizes each fold's features with TRAIN-fold statistics only, so
    test-fold feature statistics can no longer leak into training through the
    normalizer. (Re-normalizing an already-globally-normalized matrix is an
    affine composition, mathematically identical to normalizing the raw
    features with train-fold stats.)

    Embargo default in date-aware mode: ``embargo_days`` if given, else
    ``max(5, round(embargo_fraction * calendar_span))`` days.
    """
    n_samples = len(X_mat)
    if n_samples < 40 or len(y_vec) != n_samples:
        return {
            "oos_sharpe": 0.0,
            "oos_ic": 0.0,
            "oos_ir": 0.0,
            "dsr": 0.50,
            "dsr_z": 0.0,
            "dsr_pvalue": 1.0,
            "expected_max_sr": 0.0,
        }

    date_mode = False
    asof = None
    emb_days = 0
    if as_of_dates is not None:
        try:
            _asof = pd.to_datetime(pd.Series(list(as_of_dates)))
            if len(_asof) == n_samples and _asof.notna().sum() == n_samples:
                asof = _asof.to_numpy()
                # Date-major ordering: contiguous folds become genuine time blocks
                order = np.argsort(asof, kind="stable")
                X_mat = np.asarray(X_mat)[order]
                y_vec = np.asarray(y_vec)[order]
                asof = asof[order]
                span_days = max(int((asof.max() - asof.min()) / np.timedelta64(1, "D")), 1)
                emb_days = int(embargo_days) if embargo_days else max(5, int(round(embargo_fraction * span_days)))
                date_mode = True
            else:
                logger.warning(
                    "[CPCV] as_of_dates length/mismatch (%d vs %d rows) — falling back to row-position folds; "
                    "ensure row order is chronological for sound metrics.",
                    len(_asof), n_samples,
                )
        except Exception as _date_err:
            logger.warning(f"[CPCV] Could not parse as_of_dates ({_date_err}) — falling back to row-position folds.")

    fold_size = n_samples // n_splits
    embargo_size = max(2, int(n_samples * embargo_fraction))
    fold_ics = []
    oos_top_returns = []
    dropped_folds = 0

    for k in range(n_splits):
        test_start = k * fold_size
        test_end = (k + 1) * fold_size if k < n_splits - 1 else n_samples
        test_idx = np.arange(test_start, test_end)

        if date_mode:
            # Purge on the TIME axis: drop every train row (any ticker) whose
            # as-of date lies within emb_days of the test block's date range.
            t_lo, t_hi = asof[test_idx[0]], asof[test_idx[-1]]
            train_mask = (asof < t_lo - np.timedelta64(emb_days, "D")) | (
                asof > t_hi + np.timedelta64(emb_days, "D")
            )
            train_idx = np.where(train_mask)[0]
        else:
            # Legacy row-position purge (only sound for chronologically ordered rows)
            train_mask = (np.arange(n_samples) < test_start - embargo_size) | (
                np.arange(n_samples) >= test_end + embargo_size
            )
            train_idx = np.where(train_mask)[0]

        if len(train_idx) < 20 or len(test_idx) < 10:
            dropped_folds += 1
            continue

        X_train, y_train = X_mat[train_idx], y_vec[train_idx]
        X_test, y_test = X_mat[test_idx], y_vec[test_idx]

        if fold_local_zscore and X_train.ndim == 2 and X_train.shape[1] > 0:
            # Train-fold statistics only — no test-fold leakage through scaling
            _mu = np.nanmean(X_train, axis=0)
            _sd = np.nanstd(X_train, axis=0)
            _sd = np.where(_sd < 1e-6, 1.0, _sd)
            X_train = (X_train - _mu) / _sd
            X_test = (X_test - _mu) / _sd

        try:
            y_pred_oos = fit_predict_fn(X_train, y_train, X_test)
            if (
                len(y_pred_oos) == len(y_test)
                and np.std(y_pred_oos) > 1e-7
                and np.std(y_test) > 1e-7
            ):
                ic_val, _ = spearmanr(y_pred_oos, y_test)
                if not np.isnan(ic_val):
                    fold_ics.append(float(ic_val))

                top_cut = np.percentile(y_pred_oos, 70)
                top_rets = y_test[y_pred_oos >= top_cut]
                if len(top_rets) > 0:
                    oos_top_returns.extend(top_rets.tolist())
            else:
                dropped_folds += 1
        except Exception as _fe:
            dropped_folds += 1
            logger.debug(f"[CPCV] Fold {k} failed: {_fe}")
            continue

    oos_ic = float(np.mean(fold_ics)) if fold_ics else 0.0
    oos_ic_std = float(np.std(fold_ics, ddof=1)) if len(fold_ics) > 1 else 1e-4
    oos_ir = float(oos_ic / max(oos_ic_std, 1e-6))

    if not oos_top_returns:
        return {
            "oos_sharpe": 0.0,
            "oos_ic": oos_ic,
            "oos_ir": oos_ir,
            "dsr": 0.50,
            "dsr_z": 0.0,
            "dsr_pvalue": 1.0,
            "expected_max_sr": 0.0,
            "n_folds_used": len(fold_ics),
            "n_folds_dropped": dropped_folds,
        }

    oos_rets_arr = np.array(oos_top_returns)
    dsr_res = deflated_sharpe_ratio(
        returns=oos_rets_arr,
        n_trials=max(1, n_trials),
        freq_per_year=max(1, int(252 / 42)),
    )

    oos_sharpe = float(dsr_res.get("sharpe", 0.0))
    expected_max_sr = float(dsr_res.get("expected_max_SR", 0.0))
    dsr_z = float(dsr_res.get("deflated_sharpe", 0.0))
    dsr_pvalue = float(dsr_res.get("p_value", 1.0))
    dsr = float(np.clip(norm.cdf(dsr_z), 0.0, 1.0))

    return {
        "oos_sharpe": oos_sharpe,
        "oos_ic": oos_ic,
        "oos_ir": oos_ir,
        "dsr": dsr,
        "dsr_z": dsr_z,
        "dsr_pvalue": dsr_pvalue,
        "expected_max_sr": expected_max_sr,
        "n_folds_used": len(fold_ics),
        "n_folds_dropped": dropped_folds,
    }


# ─────────────────────────────────────────────────────────────────────────────
# 1. 🚀 Momentum & Vol Squeeze: PatchTST Transformer Model
# ─────────────────────────────────────────────────────────────────────────────

class MomentumPatchTSTModel:
    """
    Dedicated Machine Learning Model for:
    🚀 Momentum & Vol Squeeze · Institutional Alpha
    
    Integrates Patch Time Series Transformer (PatchTSTAlphaEngine) kernel self-attention
    over multi-scale momentum and volatility contraction patches with regularized
    microstructure VPIN order-flow toxicity and VCP breakout modeling.
    """
    MODEL_FILENAME = "ml_alpha_momentum.pkl"

    def __init__(self, feature_names: Optional[List[str]] = None):
        self.feature_names = list(feature_names or MOMENTUM_FACTOR_NAMES)
        self._linear_weights = None
        self._gbt_model = None
        self._scaler_mean = None
        self._scaler_scale = None
        self.dsr: Optional[float] = None  # None = not yet measured (never fabricate 0.50)
        self.oos_sharpe: float = 0.0
        self.oos_ic: float = 0.0
        self.oos_ir: float = 0.0
        self.expected_max_sr: float = 0.0
        self.dsr_z: float = 0.0
        self.dsr_pvalue: float = 1.0
        self.trained_at: Optional[str] = None
        self.n_samples: int = 0
        self.n_tickers: int = 0

    @classmethod
    def get_model_path(cls) -> Path:
        return MODEL_DIR / cls.MODEL_FILENAME

    def _build_augmented_features(self, X_norm: np.ndarray) -> np.ndarray:
        cols = self.feature_names
        vcp_idx = cols.index("z_vcp") if "z_vcp" in cols else 0
        rs_idx = cols.index("z_rs_rating") if "z_rs_rating" in cols else 0
        ann_vol_idx = cols.index("z_ann_vol") if "z_ann_vol" in cols else 0
        vpin_idx = cols.index("z_vpin_toxicity") if "z_vpin_toxicity" in cols else 0
        beta_idx = cols.index("z_beta") if "z_beta" in cols else None
        range_idx = cols.index("z_range_contraction") if "z_range_contraction" in cols else 0
        # BUGFIX (Round 41): z_patch_tst_alpha is now a genuine per-ticker
        # feature computed upstream (train_archetype_models.extract_features_
        # for_ticker) from that ticker's own real OHLCV history via the
        # actual PatchTSTAlphaEngine — read it directly here instead of the
        # old _compute_patch_attention(), which ran self-attention over a
        # shuffled bag of unrelated cross-sectional factors with no time-
        # series meaning. Falls back to 0.0 (neutral) if an older cached
        # feature set without this column is ever passed in.
        patch_idx = cols.index("z_patch_tst_alpha") if "z_patch_tst_alpha" in cols else None

        vol_scaled_rs = X_norm[:, rs_idx] / (np.maximum(0.1, np.abs(X_norm[:, ann_vol_idx])) + 0.5)
        residual_mom = X_norm[:, rs_idx] - (0.5 * X_norm[:, beta_idx] if beta_idx is not None else 0.0)
        vcp_breakout = np.maximum(0.0, X_norm[:, vcp_idx]) * (1.0 + np.maximum(0.0, X_norm[:, range_idx]))
        vpin_shield = (1.0 - np.clip(X_norm[:, vpin_idx], 0.0, 0.8))
        patch_score = X_norm[:, patch_idx] if patch_idx is not None else np.zeros(len(X_norm))

        return np.column_stack([
            X_norm,
            vol_scaled_rs,
            residual_mom,
            vcp_breakout,
            vpin_shield,
            patch_score,
        ])

    def fit(self, X: pd.DataFrame, y: pd.Series, as_of_dates=None) -> bool:
        # ROUND-43 FIX (R6/AUDIT-06): optional row-aligned as-of dates enable
        # date-major purged CV with a day-based time-axis embargo.

        if X is None or len(X) < 20:
            return False

        cols = [c for c in self.feature_names if c in X.columns]
        if len(cols) < 4:
            return False

        self.feature_names = cols
        X_mat = X[cols].fillna(0.0).to_numpy(dtype=float)
        y_vec = y.reindex(X.index).fillna(0.0).to_numpy(dtype=float)

        self._scaler_mean = np.nanmean(X_mat, axis=0)
        self._scaler_scale = np.nanstd(X_mat, axis=0)
        self._scaler_scale[self._scaler_scale < 1e-6] = 1.0

        X_norm = (X_mat - self._scaler_mean) / self._scaler_scale
        X_norm = np.nan_to_num(X_norm, nan=0.0, posinf=0.0, neginf=0.0)

        # 1. CPCV Out-Of-Sample Evaluation (Purged & Embargoed)
        def _fold_fit_predict(X_tr, y_tr, X_te):
            X_tr_aug = self._build_augmented_features(X_tr)
            X_te_aug = self._build_augmented_features(X_te)
            sw_tr = np.where(y_tr < 0, 1.8, 1.0)
            r_fold = Ridge(alpha=10.0, random_state=42).fit(X_tr_aug, y_tr, sample_weight=sw_tr)
            g_fold = HistGradientBoostingRegressor(
                max_iter=60, max_depth=3, learning_rate=0.04, min_samples_leaf=20, random_state=42
            ).fit(X_tr_aug, y_tr, sample_weight=sw_tr)
            patch_te = X_te_aug[:, -1]
            return 0.40 * r_fold.predict(X_te_aug) + 0.35 * g_fold.predict(X_te_aug) + 0.25 * patch_te

        cv_res = compute_purged_embargo_cv_metrics(
            X_norm, y_vec, _fold_fit_predict, n_splits=5, embargo_fraction=0.02, n_trials=len(self.feature_names),
            as_of_dates=as_of_dates,
        )
        self.oos_sharpe = cv_res["oos_sharpe"]
        self.oos_ic = cv_res["oos_ic"]
        self.oos_ir = cv_res["oos_ir"]
        self.dsr = cv_res["dsr"]
        self.dsr_z = cv_res["dsr_z"]
        self.dsr_pvalue = cv_res["dsr_pvalue"]
        self.expected_max_sr = cv_res["expected_max_sr"]

        # 2. Final Production Model Fit
        X_aug = self._build_augmented_features(X_norm)
        vcp_idx = cols.index("z_vcp") if "z_vcp" in cols else 0
        range_idx = cols.index("z_range_contraction") if "z_range_contraction" in cols else 0
        vcp_breakout = np.maximum(0.0, X_norm[:, vcp_idx]) * (1.0 + np.maximum(0.0, X_norm[:, range_idx]))
        sw = np.where(y_vec < 0, 1.8, 1.0) * (1.0 + 0.4 * np.maximum(0.0, vcp_breakout))

        self._linear_weights = Ridge(alpha=10.0, random_state=42)
        self._linear_weights.fit(X_aug, y_vec, sample_weight=sw)

        self._gbt_model = HistGradientBoostingRegressor(
            max_iter=90,
            max_depth=3,
            learning_rate=0.03,
            min_samples_leaf=30,
            l2_regularization=8.0,
            random_state=42,
        )
        self._gbt_model.fit(X_aug, y_vec, sample_weight=sw)

        self.trained_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
        self.n_samples = len(X)
        self.n_tickers = len(X.index.unique()) if hasattr(X.index, "unique") else len(X)

        logger.info(
            f"[MomentumPatchTSTModel] ✅ Authenticated via Purged CPCV on {self.n_samples} samples | "
            f"OOS IC={self.oos_ic:.3f} | OOS IR={self.oos_ir:.2f} | OOS SR={self.oos_sharpe:.2f} | "
            f"z_DSR={self.dsr_z:.2f} | p={self.dsr_pvalue:.4f} | DSR={self.dsr:.4f}"
        )
        return True

    def predict(self, X: Union[pd.DataFrame, Dict[str, Any]]) -> pd.Series:
        if isinstance(X, dict):
            X_df = pd.DataFrame.from_dict(X, orient="index")
        elif isinstance(X, pd.DataFrame):
            X_df = X
        else:
            return pd.Series(dtype=float)

        if X_df.empty:
            return pd.Series(dtype=float)

        mat_dict = {}
        for c in self.feature_names:
            if c in X_df.columns:
                mat_dict[c] = pd.to_numeric(X_df[c], errors="coerce").fillna(0.0)
            else:
                mat_dict[c] = pd.Series(0.0, index=X_df.index)

        X_aligned = pd.DataFrame(mat_dict, index=X_df.index)
        X_mat = X_aligned.to_numpy(dtype=float)

        if self._scaler_mean is not None and self._scaler_scale is not None:
            X_norm = (X_mat - self._scaler_mean) / self._scaler_scale
            X_norm = np.nan_to_num(X_norm, nan=0.0, posinf=0.0, neginf=0.0)
        else:
            X_norm = X_mat

        if self._linear_weights is not None and self._gbt_model is not None:
            X_aug = self._build_augmented_features(X_norm)
            p_ridge = self._linear_weights.predict(X_aug)
            p_gbt = self._gbt_model.predict(X_aug)
            patch_score = X_aug[:, -1]
            preds = 0.40 * p_ridge + 0.35 * p_gbt + 0.25 * patch_score
        else:
            raise RuntimeError(
                "[MomentumPatchTSTModel] predict() called on an unfitted model. "
                "Call fit() before predict(), or load a saved model via load()."
            )

        return pd.Series(preds, index=X_df.index, name="ml_alpha_momentum")

    def predict_with_attribution(
        self, X: Union[pd.DataFrame, Dict[str, Any]]
    ) -> Tuple[pd.Series, pd.DataFrame]:
        preds = self.predict(X)
        if isinstance(X, dict):
            X_df = pd.DataFrame.from_dict(X, orient="index")
        elif isinstance(X, pd.DataFrame):
            X_df = X
        else:
            return preds, pd.DataFrame()

        mat_dict = {}
        for c in self.feature_names:
            if c in X_df.columns:
                mat_dict[c] = pd.to_numeric(X_df[c], errors="coerce").fillna(0.0)
            else:
                mat_dict[c] = pd.Series(0.0, index=X_df.index)

        X_aligned = pd.DataFrame(mat_dict, index=X_df.index)
        X_mat = X_aligned.to_numpy(dtype=float)

        if self._scaler_mean is not None and self._scaler_scale is not None:
            X_norm = (X_mat - self._scaler_mean) / self._scaler_scale
            X_norm = np.nan_to_num(X_norm, nan=0.0, posinf=0.0, neginf=0.0)
        else:
            X_norm = X_mat

        n_f = X_norm.shape[1]
        ridge_coef = self._linear_weights.coef_[:n_f] if self._linear_weights is not None else np.zeros(n_f)
        ridge_contrib = X_norm * ridge_coef
        fi = self._gbt_model.feature_importances_[:n_f] if (self._gbt_model and hasattr(self._gbt_model, "feature_importances_")) else np.ones(n_f) / n_f
        gbt_contrib = np.sign(X_norm) * (np.abs(X_norm) / (np.abs(X_norm).sum(axis=1, keepdims=True) + 1e-6)) * fi

        total_contrib = 0.40 * ridge_contrib + 0.60 * gbt_contrib
        abs_contrib = np.abs(total_contrib)
        sum_abs = abs_contrib.sum(axis=1, keepdims=True) + 1e-6
        pct_contrib = (abs_contrib / sum_abs) * 100.0

        attr_df = pd.DataFrame(pct_contrib, index=X_df.index, columns=self.feature_names)
        return preds, attr_df

    def save(self, path: Optional[Union[str, Path]] = None) -> Path:
        out_path = Path(path or self.get_model_path())
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with open(out_path, "wb") as f:
            pickle.dump(self, f, protocol=pickle.HIGHEST_PROTOCOL)

        with open(out_path, "rb") as f:
            sha = hashlib.sha256(f.read()).hexdigest()
        manifest = out_path.with_suffix(".pkl.sha256")
        with open(manifest, "w", encoding="utf-8") as f:
            f.write(sha + "\n")

        logger.info(f"[MomentumPatchTSTModel] Saved model to {out_path} (SHA-256: {sha[:16]}...)")
        return out_path

    @classmethod
    def load(cls, path: Optional[Union[str, Path]] = None) -> Optional[MomentumPatchTSTModel]:
        in_path = Path(path or cls.get_model_path())
        if not in_path.exists():
            return None

        manifest = in_path.with_suffix(".pkl.sha256")
        if manifest.exists():
            expected = manifest.read_text(encoding="utf-8").strip().lower()
            with open(in_path, "rb") as f:
                actual = hashlib.sha256(f.read()).hexdigest().lower()
            if expected != actual:
                logger.error(f"[MomentumPatchTSTModel] SHA-256 mismatch for {in_path} — rejecting load")
                return None

        with open(in_path, "rb") as f:
            model = pickle.load(f)
        return model


# ─────────────────────────────────────────────────────────────────────────────
# 2. 🏦 Institutional Flow & Smart Money: Graph Attention Network (GAT) Model
# ─────────────────────────────────────────────────────────────────────────────

class InstitutionalFlowGATModel:
    """
    Dedicated Machine Learning Model for:
    🏦 Institutional Flow & Smart Money
    
    Integrates Dynamic Graph Attention Network (DynamicGATEngine) to model
    cross-asset order-flow spillovers and institutional accumulation networks.
    """
    MODEL_FILENAME = "ml_alpha_flow.pkl"

    def __init__(self, feature_names: Optional[List[str]] = None):
        self.feature_names = list(feature_names or FLOW_FACTOR_NAMES)
        self.gat_engine = DynamicGATEngine(n_heads=4, feature_dim=1, hidden_dim=8)
        self._linear_weights = None
        self._gbt_model = None
        self._scaler_mean = None
        self._scaler_scale = None
        self.dsr: Optional[float] = None  # None = not yet measured (never fabricate 0.50)
        self.oos_sharpe: float = 0.0
        self.oos_ic: float = 0.0
        self.oos_ir: float = 0.0
        self.expected_max_sr: float = 0.0
        self.dsr_z: float = 0.0
        self.dsr_pvalue: float = 1.0
        self.trained_at: Optional[str] = None
        self.n_samples: int = 0
        self.n_tickers: int = 0

    @classmethod
    def get_model_path(cls) -> Path:
        return MODEL_DIR / cls.MODEL_FILENAME

    def _build_augmented_features(self, X_norm: np.ndarray) -> np.ndarray:
        cols = self.feature_names
        sast_idx = cols.index("z_sast_vel") if "z_sast_vel" in cols else 0
        deliv_idx = cols.index("z_delivery") if "z_delivery" in cols else 0
        cmf_idx = cols.index("z_cmf") if "z_cmf" in cols else 0
        bulk_idx = cols.index("z_bulk_deal_footprint") if "z_bulk_deal_footprint" in cols else 0
        float_idx = cols.index("z_float_squeeze") if "z_float_squeeze" in cols else 0
        dryup_idx = cols.index("z_volume_dryup") if "z_volume_dryup" in cols else 0
        ann_vol_idx = cols.index("z_ann_vol") if "z_ann_vol" in cols else 0

        deliv_cmf_synergy = X_norm[:, deliv_idx] * (1.0 + np.maximum(0.0, X_norm[:, cmf_idx]))
        smart_money_footprint = X_norm[:, bulk_idx] * (1.0 + np.maximum(0.0, X_norm[:, sast_idx]))
        float_dryup_compression = np.maximum(0.0, X_norm[:, float_idx]) * (1.0 + np.maximum(0.0, X_norm[:, dryup_idx]))
        risk_adj_delivery = X_norm[:, deliv_idx] / (np.maximum(0.1, np.abs(X_norm[:, ann_vol_idx])) + 0.5)

        return np.column_stack([
            X_norm,
            deliv_cmf_synergy,
            smart_money_footprint,
            float_dryup_compression,
            risk_adj_delivery,
        ])

    def fit(self, X: pd.DataFrame, y: pd.Series, as_of_dates=None) -> bool:
        # ROUND-43 FIX (R6/AUDIT-06): optional row-aligned as-of dates enable
        # date-major purged CV with a day-based time-axis embargo.

        if X is None or len(X) < 20:
            return False

        cols = [c for c in self.feature_names if c in X.columns]
        if len(cols) < 4:
            return False

        self.feature_names = cols
        X_mat = X[cols].fillna(0.0).to_numpy(dtype=float)
        y_vec = y.reindex(X.index).fillna(0.0).to_numpy(dtype=float)

        self._scaler_mean = np.nanmean(X_mat, axis=0)
        self._scaler_scale = np.nanstd(X_mat, axis=0)
        self._scaler_scale[self._scaler_scale < 1e-6] = 1.0

        X_norm = (X_mat - self._scaler_mean) / self._scaler_scale
        X_norm = np.nan_to_num(X_norm, nan=0.0, posinf=0.0, neginf=0.0)

        # 1. CPCV Out-Of-Sample Evaluation
        def _fold_fit_predict(X_tr, y_tr, X_te):
            X_tr_aug = self._build_augmented_features(X_tr)
            X_te_aug = self._build_augmented_features(X_te)
            sw_tr = np.where(y_tr < 0, 1.8, 1.0)
            r_fold = Ridge(alpha=10.0, random_state=42).fit(X_tr_aug, y_tr, sample_weight=sw_tr)
            g_fold = HistGradientBoostingRegressor(
                max_iter=60, max_depth=3, learning_rate=0.04, min_samples_leaf=20, random_state=42
            ).fit(X_tr_aug, y_tr, sample_weight=sw_tr)
            return 0.50 * r_fold.predict(X_te_aug) + 0.50 * g_fold.predict(X_te_aug)

        cv_res = compute_purged_embargo_cv_metrics(
            X_norm, y_vec, _fold_fit_predict, n_splits=5, embargo_fraction=0.02, n_trials=len(self.feature_names),
            as_of_dates=as_of_dates,
        )
        self.oos_sharpe = cv_res["oos_sharpe"]
        self.oos_ic = cv_res["oos_ic"]
        self.oos_ir = cv_res["oos_ir"]
        self.dsr = cv_res["dsr"]
        self.dsr_z = cv_res["dsr_z"]
        self.dsr_pvalue = cv_res["dsr_pvalue"]
        self.expected_max_sr = cv_res["expected_max_sr"]

        # 2. Final Production Models
        X_aug = self._build_augmented_features(X_norm)
        deliv_cmf_synergy = X_aug[:, len(cols)]
        sw = np.where(y_vec < 0, 1.8, 1.0) * (1.0 + 0.4 * np.maximum(0.0, deliv_cmf_synergy))

        self._linear_weights = Ridge(alpha=10.0, random_state=42)
        self._linear_weights.fit(X_aug, y_vec, sample_weight=sw)

        self._gbt_model = HistGradientBoostingRegressor(
            max_iter=90, max_depth=3, learning_rate=0.03, min_samples_leaf=25, l2_regularization=8.0, random_state=42
        )
        self._gbt_model.fit(X_aug, y_vec, sample_weight=sw)

        # 3. Fit Dynamic Graph Attention Network over canonical stock list
        try:
            base_p = 0.5 * self._linear_weights.predict(X_aug) + 0.5 * self._gbt_model.predict(X_aug)
            # BUGFIX (Round 41): two compounding defects here.
            # (a) X.index must actually hold ticker identity — see the fix in
            #     train_archetype_models.py / audit_model_metrics.py, which now
            #     index the training frame by ticker instead of a default
            #     RangeIndex, so X.index.unique() yields real symbols the
            #     graph's supply-chain/sector adjacency lookup can resolve.
            # (b) base_scores=base_p[:len(stock_names)] took a raw positional
            #     slice of the prediction array — the first N rows in the
            #     training-set's row order, NOT one score per unique ticker
            #     (a ticker contributes many rows, one per time window, so
            #     this slice mixed a handful of early tickers' multiple
            #     per-date scores together and silently dropped every other
            #     ticker in the universe). Fixed by aggregating the mean
            #     predicted score per unique ticker, aligned 1:1 with
            #     stock_names, which is what fit_dynamic_attention expects.
            stock_names_raw = X.index.unique() if hasattr(X.index, "unique") else []
            stock_names = [str(t) for t in stock_names_raw] if len(stock_names_raw) > 10 else []
            if stock_names and len(stock_names) <= 200:
                _score_by_ticker = pd.Series(base_p, index=X.index).groupby(level=0).mean()
                _aligned_scores = _score_by_ticker.reindex(stock_names_raw).fillna(0.0).to_numpy()
                self.gat_engine.fit_dynamic_attention(stocks=stock_names, base_scores=_aligned_scores)
        except Exception as _e_gat:
            logger.debug(f"[InstitutionalFlowGATModel] GAT fitting notice: {_e_gat}")

        self.trained_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
        self.n_samples = len(X)
        self.n_tickers = len(X.index.unique()) if hasattr(X.index, "unique") else len(X)

        logger.info(
            f"[InstitutionalFlowGATModel] ✅ Authenticated via Purged CPCV on {self.n_samples} samples | "
            f"OOS IC={self.oos_ic:.3f} | OOS IR={self.oos_ir:.2f} | OOS SR={self.oos_sharpe:.2f} | "
            f"z_DSR={self.dsr_z:.2f} | p={self.dsr_pvalue:.4f} | DSR={self.dsr:.4f}"
        )
        return True

    def predict(self, X: Union[pd.DataFrame, Dict[str, Any]]) -> pd.Series:
        if isinstance(X, dict):
            X_df = pd.DataFrame.from_dict(X, orient="index")
        elif isinstance(X, pd.DataFrame):
            X_df = X
        else:
            return pd.Series(dtype=float)

        if X_df.empty:
            return pd.Series(dtype=float)

        mat_dict = {}
        for c in self.feature_names:
            if c in X_df.columns:
                mat_dict[c] = pd.to_numeric(X_df[c], errors="coerce").fillna(0.0)
            else:
                mat_dict[c] = pd.Series(0.0, index=X_df.index)

        X_aligned = pd.DataFrame(mat_dict, index=X_df.index)
        X_mat = X_aligned.to_numpy(dtype=float)

        if self._scaler_mean is not None and self._scaler_scale is not None:
            X_norm = (X_mat - self._scaler_mean) / self._scaler_scale
            X_norm = np.nan_to_num(X_norm, nan=0.0, posinf=0.0, neginf=0.0)
        else:
            X_norm = X_mat

        if self._linear_weights is not None and self._gbt_model is not None:
            X_aug = self._build_augmented_features(X_norm)
            p_ridge = self._linear_weights.predict(X_aug)
            p_gbt = self._gbt_model.predict(X_aug)
            base_preds = 0.50 * p_ridge + 0.50 * p_gbt

            if getattr(self, "gat_engine", None) is not None and getattr(self.gat_engine, "fitted_", False):
                try:
                    stock_names = [str(t).replace(".NS", "").replace(".BO", "").upper() for t in X_df.index]
                    if (
                        len(stock_names) == len(base_preds)
                        and len(set(stock_names)) == len(stock_names)
                        and len(stock_names) <= 500
                    ):
                        diffused = self.gat_engine.propagate(base_preds, alpha_blend=0.30, names=stock_names)
                        preds = 0.70 * base_preds + 0.30 * diffused
                    else:
                        preds = base_preds
                except Exception:
                    preds = base_preds
            else:
                preds = base_preds
        else:
            raise RuntimeError(
                "[InstitutionalFlowGATModel] predict() called on an unfitted model. "
                "Call fit() before predict(), or load a saved model via load()."
            )

        return pd.Series(preds, index=X_df.index, name="ml_alpha_flow")

    def predict_with_attribution(
        self, X: Union[pd.DataFrame, Dict[str, Any]]
    ) -> Tuple[pd.Series, pd.DataFrame]:
        preds = self.predict(X)
        if isinstance(X, dict):
            X_df = pd.DataFrame.from_dict(X, orient="index")
        elif isinstance(X, pd.DataFrame):
            X_df = X
        else:
            return preds, pd.DataFrame()

        mat_dict = {}
        for c in self.feature_names:
            if c in X_df.columns:
                mat_dict[c] = pd.to_numeric(X_df[c], errors="coerce").fillna(0.0)
            else:
                mat_dict[c] = pd.Series(0.0, index=X_df.index)

        X_aligned = pd.DataFrame(mat_dict, index=X_df.index)
        X_mat = X_aligned.to_numpy(dtype=float)

        if self._scaler_mean is not None and self._scaler_scale is not None:
            X_norm = (X_mat - self._scaler_mean) / self._scaler_scale
            X_norm = np.nan_to_num(X_norm, nan=0.0, posinf=0.0, neginf=0.0)
        else:
            X_norm = X_mat

        n_f = X_norm.shape[1]
        ridge_coef = self._linear_weights.coef_[:n_f] if self._linear_weights is not None else np.zeros(n_f)
        ridge_contrib = X_norm * ridge_coef
        fi = self._gbt_model.feature_importances_[:n_f] if (self._gbt_model and hasattr(self._gbt_model, "feature_importances_")) else np.ones(n_f) / n_f
        gbt_contrib = np.sign(X_norm) * (np.abs(X_norm) / (np.abs(X_norm).sum(axis=1, keepdims=True) + 1e-6)) * fi

        total_contrib = 0.50 * ridge_contrib + 0.50 * gbt_contrib
        abs_contrib = np.abs(total_contrib)
        sum_abs = abs_contrib.sum(axis=1, keepdims=True) + 1e-6
        pct_contrib = (abs_contrib / sum_abs) * 100.0

        attr_df = pd.DataFrame(pct_contrib, index=X_df.index, columns=self.feature_names)
        return preds, attr_df

    def save(self, path: Optional[Union[str, Path]] = None) -> Path:
        out_path = Path(path or self.get_model_path())
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with open(out_path, "wb") as f:
            pickle.dump(self, f, protocol=pickle.HIGHEST_PROTOCOL)

        with open(out_path, "rb") as f:
            sha = hashlib.sha256(f.read()).hexdigest()
        manifest = out_path.with_suffix(".pkl.sha256")
        with open(manifest, "w", encoding="utf-8") as f:
            f.write(sha + "\n")

        logger.info(f"[InstitutionalFlowGATModel] Saved model to {out_path} (SHA-256: {sha[:16]}...)")
        return out_path

    @classmethod
    def load(cls, path: Optional[Union[str, Path]] = None) -> Optional[InstitutionalFlowGATModel]:
        in_path = Path(path or cls.get_model_path())
        if not in_path.exists():
            return None

        manifest = in_path.with_suffix(".pkl.sha256")
        if manifest.exists():
            expected = manifest.read_text(encoding="utf-8").strip().lower()
            with open(in_path, "rb") as f:
                actual = hashlib.sha256(f.read()).hexdigest().lower()
            if expected != actual:
                logger.error(f"[InstitutionalFlowGATModel] SHA-256 mismatch for {in_path} — rejecting load")
                return None

        with open(in_path, "rb") as f:
            model = pickle.load(f)
        return model


# ─────────────────────────────────────────────────────────────────────────────
# 3. 🏛️ Quality Growth & GARP: Structural Causal Model (SCM)
# ─────────────────────────────────────────────────────────────────────────────

class QualityCausalGARPModel:
    """
    Dedicated Machine Learning Model for:
    🏛️ Quality Growth & GARP Compounders
    
    Integrates Pearlian Structural Causal Models (PearlianCausalDiscoveryEngine / DirectLiNGAM)
    and Judea Pearl's Do-Calculus to identify true invariant causal drivers of compounder alpha.
    """
    MODEL_FILENAME = "ml_alpha_quality.pkl"

    def __init__(self, feature_names: Optional[List[str]] = None):
        self.feature_names = list(feature_names or QUALITY_FACTOR_NAMES)
        self.causal_engine = PearlianCausalDiscoveryEngine(random_state=42, prune_threshold=0.03)
        self.causal_parents_: Dict[str, float] = {}
        self.invariant_weights_: Dict[str, float] = {}
        self.causal_stability_ratio_: float = 1.0
        self._linear_weights = None
        self._gbt_model = None
        self._scaler_mean = None
        self._scaler_scale = None
        self.dsr: Optional[float] = None  # None = not yet measured (never fabricate 0.50)
        self.oos_sharpe: float = 0.0
        self.oos_ic: float = 0.0
        self.oos_ir: float = 0.0
        self.expected_max_sr: float = 0.0
        self.dsr_z: float = 0.0
        self.dsr_pvalue: float = 1.0
        self.trained_at: Optional[str] = None
        self.n_samples: int = 0
        self.n_tickers: int = 0

    @classmethod
    def get_model_path(cls) -> Path:
        return MODEL_DIR / cls.MODEL_FILENAME

    def _compute_invariant_causal_projection(self, X_norm: np.ndarray) -> np.ndarray:
        if not self.invariant_weights_:
            return np.zeros(len(X_norm))
        causal_proj = np.zeros(len(X_norm))
        for col_name, w in self.invariant_weights_.items():
            if col_name in self.feature_names:
                idx = self.feature_names.index(col_name)
                causal_proj += float(w) * X_norm[:, idx]
        return causal_proj

    def _build_augmented_features(self, X_norm: np.ndarray) -> np.ndarray:
        cols = self.feature_names
        roe_idx = cols.index("z_roe") if "z_roe" in cols else 0
        pe_idx = cols.index("z_pe_inv") if "z_pe_inv" in cols else 0
        ds_vol_idx = cols.index("z_downside_vol") if "z_downside_vol" in cols else 0
        tq_idx = cols.index("z_trend_quality") if "z_trend_quality" in cols else 0

        quality_sharpe = X_norm[:, roe_idx] / (np.maximum(0.1, np.abs(X_norm[:, ds_vol_idx])) + 0.5)
        trend_garp = X_norm[:, pe_idx] * (1.0 + 0.4 * np.maximum(0.0, X_norm[:, tq_idx]))
        causal_proj = self._compute_invariant_causal_projection(X_norm)

        return np.column_stack([
            X_norm,
            quality_sharpe,
            trend_garp,
            causal_proj,
        ])

    def fit(self, X: pd.DataFrame, y: pd.Series, as_of_dates=None) -> bool:
        # ROUND-43 FIX (R6/AUDIT-06): optional row-aligned as-of dates enable
        # date-major purged CV with a day-based time-axis embargo.

        if X is None or len(X) < 20:
            return False

        cols = [c for c in self.feature_names if c in X.columns]
        if len(cols) < 4:
            return False

        self.feature_names = cols
        X_mat = X[cols].fillna(0.0).to_numpy(dtype=float)
        y_vec = y.reindex(X.index).fillna(0.0).to_numpy(dtype=float)

        self._scaler_mean = np.nanmean(X_mat, axis=0)
        self._scaler_scale = np.nanstd(X_mat, axis=0)
        self._scaler_scale[self._scaler_scale < 1e-6] = 1.0

        X_norm = (X_mat - self._scaler_mean) / self._scaler_scale
        X_norm = np.nan_to_num(X_norm, nan=0.0, posinf=0.0, neginf=0.0)

        # 1. Fit Pearlian Structural Causal Discovery to discover invariant DAG parents of forward return y
        try:
            joint_data = np.column_stack([X_norm[:min(500, len(X_norm))], y_vec[:min(500, len(y_vec))]])
            # BUGFIX (Round 41): sink_variable="target_y" — see
            # PearlianCausalDiscoveryEngine._direct_lingam's docstring.
            # Without this, the forward-return target could land anywhere in
            # the discovered causal order (including ahead of real
            # features), silently producing zero detected causal parents for
            # that fold with no warning.
            self.causal_engine.fit(joint_data, variable_names=cols + ["target_y"], sink_variable="target_y")
            causal_info = self.causal_engine.compute_invariant_causal_alphas(target_index=-1)
            self.invariant_weights_ = causal_info.get("invariant_alpha_weights", {})
            self.causal_parents_ = causal_info.get("direct_causal_parents", {})
            self.causal_stability_ratio_ = float(causal_info.get("causal_stability_ratio", 1.0))
        except Exception as e:
            logger.warning(
                f"[QualityCausalGARPModel] Pearlian Causal Discovery failed ({e}). "
                "Causal projection disabled — model degrades to Ridge+GBT without causal regularization."
            )
            self.invariant_weights_ = {}  # empty = no causal projection; _compute_invariant_causal_projection returns zeros

        # 2. CPCV Out-Of-Sample Evaluation
        def _fold_fit_predict(X_tr, y_tr, X_te):
            X_tr_aug = self._build_augmented_features(X_tr)
            X_te_aug = self._build_augmented_features(X_te)
            sw_tr = np.where(y_tr < 0, 1.8, 1.0)
            r_fold = Ridge(alpha=5.0, random_state=42).fit(X_tr_aug, y_tr, sample_weight=sw_tr)
            g_fold = HistGradientBoostingRegressor(
                max_iter=70, max_depth=3, learning_rate=0.04, min_samples_leaf=15, random_state=42
            ).fit(X_tr_aug, y_tr, sample_weight=sw_tr)
            causal_te = X_te_aug[:, -1]
            return 0.45 * causal_te + 0.30 * r_fold.predict(X_te_aug) + 0.25 * g_fold.predict(X_te_aug)

        cv_res = compute_purged_embargo_cv_metrics(
            X_norm, y_vec, _fold_fit_predict, n_splits=5, embargo_fraction=0.02, n_trials=len(self.feature_names),
            as_of_dates=as_of_dates,
        )
        self.oos_sharpe = cv_res["oos_sharpe"]
        self.oos_ic = cv_res["oos_ic"]
        self.oos_ir = cv_res["oos_ir"]
        self.dsr = cv_res["dsr"]
        self.dsr_z = cv_res["dsr_z"]
        self.dsr_pvalue = cv_res["dsr_pvalue"]
        self.expected_max_sr = cv_res["expected_max_sr"]

        # 3. Final Production Model Fit
        X_aug = self._build_augmented_features(X_norm)
        sw = np.where(y_vec < 0, 1.8, 1.0)
        self._linear_weights = Ridge(alpha=5.0, random_state=42).fit(X_aug, y_vec, sample_weight=sw)
        self._gbt_model = HistGradientBoostingRegressor(
            max_iter=120, max_depth=4, learning_rate=0.04, min_samples_leaf=12, l2_regularization=2.0, random_state=42
        ).fit(X_aug, y_vec, sample_weight=sw)

        self.trained_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
        self.n_samples = len(X)
        self.n_tickers = len(X.index.unique()) if hasattr(X.index, "unique") else len(X)

        logger.info(
            f"[QualityCausalGARPModel] ✅ Authenticated via Purged CPCV on {self.n_samples} samples | "
            f"OOS IC={self.oos_ic:.3f} | OOS IR={self.oos_ir:.2f} | OOS SR={self.oos_sharpe:.2f} | "
            f"z_DSR={self.dsr_z:.2f} | p={self.dsr_pvalue:.4f} | DSR={self.dsr:.4f}"
        )
        return True

    def predict(self, X: Union[pd.DataFrame, Dict[str, Any]]) -> pd.Series:
        if isinstance(X, dict):
            X_df = pd.DataFrame.from_dict(X, orient="index")
        elif isinstance(X, pd.DataFrame):
            X_df = X
        else:
            return pd.Series(dtype=float)

        if X_df.empty:
            return pd.Series(dtype=float)

        mat_dict = {}
        for c in self.feature_names:
            if c in X_df.columns:
                mat_dict[c] = pd.to_numeric(X_df[c], errors="coerce").fillna(0.0)
            else:
                mat_dict[c] = pd.Series(0.0, index=X_df.index)

        X_aligned = pd.DataFrame(mat_dict, index=X_df.index)
        X_mat = X_aligned.to_numpy(dtype=float)

        if self._scaler_mean is not None and self._scaler_scale is not None:
            X_norm = (X_mat - self._scaler_mean) / self._scaler_scale
            X_norm = np.nan_to_num(X_norm, nan=0.0, posinf=0.0, neginf=0.0)
        else:
            X_norm = X_mat

        if self._linear_weights is not None and self._gbt_model is not None:
            X_aug = self._build_augmented_features(X_norm)
            p_ridge = self._linear_weights.predict(X_aug)
            p_gbt = self._gbt_model.predict(X_aug)
            causal_proj = X_aug[:, -1]
            preds = 0.45 * causal_proj + 0.30 * p_ridge + 0.25 * p_gbt
        else:
            raise RuntimeError(
                "[QualityCausalGARPModel] predict() called on an unfitted model. "
                "Call fit() before predict(), or load a saved model via load()."
            )

        return pd.Series(preds, index=X_df.index, name="ml_alpha_quality")

    def predict_with_attribution(
        self, X: Union[pd.DataFrame, Dict[str, Any]]
    ) -> Tuple[pd.Series, pd.DataFrame]:
        preds = self.predict(X)
        if isinstance(X, dict):
            X_df = pd.DataFrame.from_dict(X, orient="index")
        elif isinstance(X, pd.DataFrame):
            X_df = X
        else:
            return preds, pd.DataFrame()

        mat_dict = {}
        for c in self.feature_names:
            if c in X_df.columns:
                mat_dict[c] = pd.to_numeric(X_df[c], errors="coerce").fillna(0.0)
            else:
                mat_dict[c] = pd.Series(0.0, index=X_df.index)

        X_aligned = pd.DataFrame(mat_dict, index=X_df.index)
        X_mat = X_aligned.to_numpy(dtype=float)

        if self._scaler_mean is not None and self._scaler_scale is not None:
            X_norm = (X_mat - self._scaler_mean) / self._scaler_scale
            X_norm = np.nan_to_num(X_norm, nan=0.0, posinf=0.0, neginf=0.0)
        else:
            X_norm = X_mat

        n_f = X_norm.shape[1]
        ridge_coef = self._linear_weights.coef_[:n_f] if self._linear_weights is not None else np.zeros(n_f)
        ridge_contrib = X_norm * ridge_coef
        fi = self._gbt_model.feature_importances_[:n_f] if (self._gbt_model and hasattr(self._gbt_model, "feature_importances_")) else np.ones(n_f) / n_f
        gbt_contrib = np.sign(X_norm) * (np.abs(X_norm) / (np.abs(X_norm).sum(axis=1, keepdims=True) + 1e-6)) * fi

        total_contrib = 0.50 * ridge_contrib + 0.50 * gbt_contrib
        abs_contrib = np.abs(total_contrib)
        sum_abs = abs_contrib.sum(axis=1, keepdims=True) + 1e-6
        pct_contrib = (abs_contrib / sum_abs) * 100.0

        attr_df = pd.DataFrame(pct_contrib, index=X_df.index, columns=self.feature_names)
        return preds, attr_df

    def save(self, path: Optional[Union[str, Path]] = None) -> Path:
        out_path = Path(path or self.get_model_path())
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with open(out_path, "wb") as f:
            pickle.dump(self, f, protocol=pickle.HIGHEST_PROTOCOL)

        with open(out_path, "rb") as f:
            sha = hashlib.sha256(f.read()).hexdigest()
        manifest = out_path.with_suffix(".pkl.sha256")
        with open(manifest, "w", encoding="utf-8") as f:
            f.write(sha + "\n")

        logger.info(f"[QualityCausalGARPModel] Saved model to {out_path} (SHA-256: {sha[:16]}...)")
        return out_path

    @classmethod
    def load(cls, path: Optional[Union[str, Path]] = None) -> Optional[QualityCausalGARPModel]:
        in_path = Path(path or cls.get_model_path())
        if not in_path.exists():
            return None

        manifest = in_path.with_suffix(".pkl.sha256")
        if manifest.exists():
            expected = manifest.read_text(encoding="utf-8").strip().lower()
            with open(in_path, "rb") as f:
                actual = hashlib.sha256(f.read()).hexdigest().lower()
            if expected != actual:
                logger.error(f"[QualityCausalGARPModel] SHA-256 mismatch for {in_path} — rejecting load")
                return None

        with open(in_path, "rb") as f:
            model = pickle.load(f)
        return model


# ─────────────────────────────────────────────────────────────────────────────
# 4. 🛡️ All-Weather & Capital Preservation: Continuous-Time Liquid Neural ODE
# ─────────────────────────────────────────────────────────────────────────────

class AllWeatherLiquidODEModel:
    """
    Dedicated Machine Learning Model for:
    🛡️ All-Weather & Capital Preservation
    
    Integrates Continuous-Time Liquid Time-Constant (LTC) Networks & Neural ODEs
    (LiquidNeuralODEEngine) to adapt dynamic continuous temporal decay tau(x(t))
    under market volatility shocks and drawdown regimes.
    """
    MODEL_FILENAME = "ml_alpha_defensive.pkl"

    def __init__(self, feature_names: Optional[List[str]] = None):
        self.feature_names = list(feature_names or DEFENSIVE_FACTOR_NAMES)
        self.ode_engine = LiquidNeuralODEEngine(input_dim=len(self.feature_names), hidden_dim=16, tau_base=1.5)
        self._linear_weights = None
        self._gbt_model = None
        self._scaler_mean = None
        self._scaler_scale = None
        self.dsr: Optional[float] = None  # None = not yet measured (never fabricate 0.50)
        self.oos_sharpe: float = 0.0
        self.oos_ic: float = 0.0
        self.oos_ir: float = 0.0
        self.expected_max_sr: float = 0.0
        self.dsr_z: float = 0.0
        self.dsr_pvalue: float = 1.0
        self.trained_at: Optional[str] = None
        self.n_samples: int = 0
        self.n_tickers: int = 0

    @classmethod
    def get_model_path(cls) -> Path:
        return MODEL_DIR / cls.MODEL_FILENAME

    def fit(self, X: pd.DataFrame, y: pd.Series, as_of_dates=None) -> bool:
        # ROUND-43 FIX (R6/AUDIT-06): optional row-aligned as-of dates enable
        # date-major purged CV with a day-based time-axis embargo.

        if X is None or len(X) < 20:
            return False

        cols = [c for c in self.feature_names if c in X.columns]
        if len(cols) < 4:
            return False

        self.feature_names = cols
        X_mat = X[cols].fillna(0.0).to_numpy(dtype=float)
        y_vec = y.reindex(X.index).fillna(0.0).to_numpy(dtype=float)

        self._scaler_mean = np.nanmean(X_mat, axis=0)
        self._scaler_scale = np.nanstd(X_mat, axis=0)
        self._scaler_scale[self._scaler_scale < 1e-6] = 1.0

        X_norm = (X_mat - self._scaler_mean) / self._scaler_scale
        X_norm = np.nan_to_num(X_norm, nan=0.0, posinf=0.0, neginf=0.0)

        # 1. Calibrate Continuous-Time Liquid Neural ODE Readout Head via RK4
        self.ode_engine = LiquidNeuralODEEngine(input_dim=len(cols), hidden_dim=16, tau_base=1.5)
        try:
            # BUGFIX (Round 41): X_norm here is a cross-sectional panel (many
            # unrelated tickers' rows), not one asset's own chronological
            # history — calibrate_readout()/integrate_trajectory() chain the
            # hidden state across rows and were making every prediction
            # depend on arbitrary row order (verified: identical feature row
            # produced different predictions purely from array position).
            # calibrate_readout_steady_state() treats each row independently
            # instead — see steady_state_readout()'s docstring in
            # liquid_neural_ode.py for the full explanation. This is also the
            # only option consistent with live inference, where predict()
            # receives exactly one snapshot row per ticker with no history
            # to chain across at all.
            self.ode_engine.calibrate_readout_steady_state(X_norm, y_vec, l2_reg=1e-2)
        except Exception as e:
            logger.warning(f"[AllWeatherLiquidODEModel] ODE calibration notice: {e}")

        # 2. CPCV Out-Of-Sample Evaluation
        def _fold_fit_predict(X_tr, y_tr, X_te):
            fold_ode = LiquidNeuralODEEngine(input_dim=len(cols), hidden_dim=16, tau_base=1.5)
            try:
                # BUGFIX (Round 41): steady-state (row-independent), not
                # sequential-chained — see note above.
                fold_ode.calibrate_readout_steady_state(X_tr, y_tr, l2_reg=1e-2)
                _, _, ode_tr = fold_ode.steady_state_readout(X_tr)
                _, _, ode_te = fold_ode.steady_state_readout(X_te)
                ode_tr_val = np.nan_to_num(ode_tr, nan=0.0).reshape(-1, 1)
                ode_te_val = np.nan_to_num(ode_te, nan=0.0).reshape(-1, 1)
            except Exception:
                ode_tr_val = np.zeros((len(X_tr), 1))
                ode_te_val = np.zeros((len(X_te), 1))

            X_tr_aug = np.hstack([X_tr, ode_tr_val])
            X_te_aug = np.hstack([X_te, ode_te_val])
            r_fold = Ridge(alpha=6.0, random_state=42).fit(X_tr_aug, y_tr)
            g_fold = HistGradientBoostingRegressor(
                max_iter=60, max_depth=3, learning_rate=0.04, min_samples_leaf=15, random_state=42
            ).fit(X_tr_aug, y_tr)
            return 0.45 * ode_te_val.flatten() + 0.30 * r_fold.predict(X_te_aug) + 0.25 * g_fold.predict(X_te_aug)

        cv_res = compute_purged_embargo_cv_metrics(
            X_norm, y_vec, _fold_fit_predict, n_splits=5, embargo_fraction=0.02, n_trials=len(self.feature_names),
            as_of_dates=as_of_dates,
        )
        self.oos_sharpe = cv_res["oos_sharpe"]
        self.oos_ic = cv_res["oos_ic"]
        self.oos_ir = cv_res["oos_ir"]
        self.dsr = cv_res["dsr"]
        self.dsr_z = cv_res["dsr_z"]
        self.dsr_pvalue = cv_res["dsr_pvalue"]
        self.expected_max_sr = cv_res["expected_max_sr"]

        # 3. Final Production Model Fit
        try:
            # BUGFIX (Round 41): steady-state, not sequential-chained.
            _, _, ode_preds = self.ode_engine.steady_state_readout(X_norm)
            ode_conviction = np.nan_to_num(ode_preds, nan=0.0).reshape(-1, 1)
        except Exception:
            ode_conviction = np.zeros((len(X_norm), 1))

        vol_idx = cols.index("z_ann_vol") if "z_ann_vol" in cols else 0
        dd_idx = cols.index("z_drawdown") if "z_drawdown" in cols else 0
        defensive_weights = 1.0 + 0.5 * np.maximum(0.0, -X_norm[:, vol_idx]) + 0.5 * np.maximum(0.0, -X_norm[:, dd_idx])

        X_aug = np.hstack([X_norm, ode_conviction])
        self._linear_weights = Ridge(alpha=6.0, random_state=42).fit(X_aug, y_vec, sample_weight=defensive_weights)
        self._gbt_model = HistGradientBoostingRegressor(
            max_iter=100, max_depth=3, learning_rate=0.04, min_samples_leaf=15, random_state=42
        ).fit(X_aug, y_vec, sample_weight=defensive_weights)

        self.trained_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
        self.n_samples = len(X)
        self.n_tickers = len(X.index.unique()) if hasattr(X.index, "unique") else len(X)

        logger.info(
            f"[AllWeatherLiquidODEModel] ✅ Authenticated via Purged CPCV on {self.n_samples} samples | "
            f"OOS IC={self.oos_ic:.3f} | OOS IR={self.oos_ir:.2f} | OOS SR={self.oos_sharpe:.2f} | "
            f"z_DSR={self.dsr_z:.2f} | p={self.dsr_pvalue:.4f} | DSR={self.dsr:.4f}"
        )
        return True

    def predict(self, X: Union[pd.DataFrame, Dict[str, Any]]) -> pd.Series:
        if isinstance(X, dict):
            X_df = pd.DataFrame.from_dict(X, orient="index")
        elif isinstance(X, pd.DataFrame):
            X_df = X
        else:
            return pd.Series(dtype=float)

        if X_df.empty:
            return pd.Series(dtype=float)

        mat_dict = {}
        for c in self.feature_names:
            if c in X_df.columns:
                mat_dict[c] = pd.to_numeric(X_df[c], errors="coerce").fillna(0.0)
            else:
                mat_dict[c] = pd.Series(0.0, index=X_df.index)

        X_aligned = pd.DataFrame(mat_dict, index=X_df.index)
        X_mat = X_aligned.to_numpy(dtype=float)

        if self._scaler_mean is not None and self._scaler_scale is not None:
            X_norm = (X_mat - self._scaler_mean) / self._scaler_scale
            X_norm = np.nan_to_num(X_norm, nan=0.0, posinf=0.0, neginf=0.0)
        else:
            X_norm = X_mat

        try:
            # BUGFIX (Round 41): steady-state, not sequential-chained — see
            # AllWeatherLiquidODEModel.fit() for the full explanation. This
            # also happens to be the only correct option here: predict() gets
            # exactly one snapshot row per ticker (signal_df), never a
            # per-ticker history, so there is nothing legitimate to "chain"
            # across in the first place.
            _, _, ode_preds = self.ode_engine.steady_state_readout(X_norm)
            ode_conviction = np.nan_to_num(ode_preds, nan=0.0).reshape(-1, 1)
        except Exception:
            ode_conviction = np.zeros((len(X_norm), 1))

        X_aug = np.hstack([X_norm, ode_conviction])

        if self._linear_weights is not None and self._gbt_model is not None:
            p_ridge = self._linear_weights.predict(X_aug)
            p_gbt = self._gbt_model.predict(X_aug)
            ode_score = ode_conviction.flatten()
            preds = 0.45 * ode_score + 0.30 * p_ridge + 0.25 * p_gbt
        else:
            raise RuntimeError(
                "[AllWeatherLiquidODEModel] predict() called on an unfitted model. "
                "Call fit() before predict(), or load a saved model via load()."
            )

        return pd.Series(preds, index=X_df.index, name="ml_alpha_defensive")

    def predict_with_attribution(
        self, X: Union[pd.DataFrame, Dict[str, Any]]
    ) -> Tuple[pd.Series, pd.DataFrame]:
        preds = self.predict(X)
        if isinstance(X, dict):
            X_df = pd.DataFrame.from_dict(X, orient="index")
        elif isinstance(X, pd.DataFrame):
            X_df = X
        else:
            return preds, pd.DataFrame()

        mat_dict = {}
        for c in self.feature_names:
            if c in X_df.columns:
                mat_dict[c] = pd.to_numeric(X_df[c], errors="coerce").fillna(0.0)
            else:
                mat_dict[c] = pd.Series(0.0, index=X_df.index)

        X_aligned = pd.DataFrame(mat_dict, index=X_df.index)
        X_mat = X_aligned.to_numpy(dtype=float)

        if self._scaler_mean is not None and self._scaler_scale is not None:
            X_norm = (X_mat - self._scaler_mean) / self._scaler_scale
            X_norm = np.nan_to_num(X_norm, nan=0.0, posinf=0.0, neginf=0.0)
        else:
            X_norm = X_mat

        n_f = X_norm.shape[1]
        ridge_coef = self._linear_weights.coef_[:n_f] if self._linear_weights is not None else np.zeros(n_f)
        ridge_contrib = X_norm * ridge_coef
        fi = self._gbt_model.feature_importances_[:n_f] if (self._gbt_model and hasattr(self._gbt_model, "feature_importances_")) else np.ones(n_f) / n_f
        gbt_contrib = np.sign(X_norm) * (np.abs(X_norm) / (np.abs(X_norm).sum(axis=1, keepdims=True) + 1e-6)) * fi

        total_contrib = 0.50 * ridge_contrib + 0.50 * gbt_contrib
        abs_contrib = np.abs(total_contrib)
        sum_abs = abs_contrib.sum(axis=1, keepdims=True) + 1e-6
        pct_contrib = (abs_contrib / sum_abs) * 100.0

        attr_df = pd.DataFrame(pct_contrib, index=X_df.index, columns=self.feature_names)
        return preds, attr_df

    def save(self, path: Optional[Union[str, Path]] = None) -> Path:
        out_path = Path(path or self.get_model_path())
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with open(out_path, "wb") as f:
            pickle.dump(self, f, protocol=pickle.HIGHEST_PROTOCOL)

        with open(out_path, "rb") as f:
            sha = hashlib.sha256(f.read()).hexdigest()
        manifest = out_path.with_suffix(".pkl.sha256")
        with open(manifest, "w", encoding="utf-8") as f:
            f.write(sha + "\n")

        logger.info(f"[AllWeatherLiquidODEModel] Saved model to {out_path} (SHA-256: {sha[:16]}...)")
        return out_path

    @classmethod
    def load(cls, path: Optional[Union[str, Path]] = None) -> Optional[AllWeatherLiquidODEModel]:
        in_path = Path(path or cls.get_model_path())
        if not in_path.exists():
            return None

        manifest = in_path.with_suffix(".pkl.sha256")
        if manifest.exists():
            expected = manifest.read_text(encoding="utf-8").strip().lower()
            with open(in_path, "rb") as f:
                actual = hashlib.sha256(f.read()).hexdigest().lower()
            if expected != actual:
                logger.error(f"[AllWeatherLiquidODEModel] SHA-256 mismatch for {in_path} — rejecting load")
                return None

        with open(in_path, "rb") as f:
            model = pickle.load(f)
        return model
