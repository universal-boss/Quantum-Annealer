"""
Pearlian Structural Causal Models (SCMs) & Invariant Causal Discovery Engine
Sovereign Tier-Ω (The Singularity Quant Frontier) Component 3

Implements:
1. Direct Linear Non-Gaussian Acyclic Model (DirectLiNGAM) for DAG discovery.
2. Topological causal ordering via non-Gaussian mutual independence (log-cosh entropy).
3. Strictly acyclic lower-triangular causal adjacency matrix B.
4. Total causal effect matrix via Neumann series / matrix inversion: T = (I - B)^(-1).
5. Judea Pearl's Do-Calculus: P(Y | do(X_k = x_k)) counterfactual intervention propagation.
6. Invariant Causal Alpha scoring: separates genuine causal parent alpha from spurious correlations.
"""

import warnings
from typing import Any, Dict, List, Optional, Tuple, Union
import numpy as np
import pandas as pd


class PearlianCausalDiscoveryEngine:
    """
    Structural Causal Model (SCM) and Invariant Causal Prediction engine based on
    Judea Pearl's Do-Calculus and Shimizu et al.'s Linear Non-Gaussian Acyclic Model (LiNGAM).
    """

    def __init__(self, random_state: int = 42, prune_threshold: float = 0.05):
        self.random_state = random_state
        self.prune_threshold = prune_threshold
        self.variable_names: List[str] = []
        self.topological_order: List[int] = []
        self.causal_adjacency_matrix: Optional[np.ndarray] = None  # B matrix where B[i, j] is j -> i
        self.total_effects_matrix: Optional[np.ndarray] = None     # (I - B)^(-1)
        self.residuals: Optional[np.ndarray] = None
        self.is_fitted: bool = False

    @staticmethod
    def _log_cosh_independence(x: np.ndarray, y: np.ndarray) -> float:
        """
        Non-Gaussian mutual independence score using the log-cosh contrast function.
        Returns a measure of dependence (0 = independent).
        """
        # Center and scale
        x_std = np.std(x)
        y_std = np.std(y)
        if x_std < 1e-9 or y_std < 1e-9:
            return 0.0
        
        zx = (x - np.mean(x)) / x_std
        zy = (y - np.mean(y)) / y_std
        
        # Nonlinear transformations g(u) = tanh(u)
        gx = np.tanh(zx)
        gy = np.tanh(zy)
        
        # Cross-correlation of nonlinear transforms captures higher-order non-Gaussian dependencies
        r1 = np.corrcoef(zx, gy)[0, 1]
        r2 = np.corrcoef(gx, zy)[0, 1]
        r3 = np.corrcoef(gx, gy)[0, 1]
        
        score = float(np.nan_to_num(r1**2 + r2**2 + r3**2, nan=0.0))
        return score

    def _direct_lingam(self, X: np.ndarray, sink_index: Optional[int] = None) -> Tuple[List[int], np.ndarray]:
        """
        DirectLiNGAM algorithm (Shimizu et al., 2011).
        Finds topological order pi and strictly acyclic causal adjacency matrix B.

        BUGFIX (Round 41): added optional `sink_index`. Plain DirectLiNGAM has
        no notion that one variable (here, the forward-return training
        target) cannot be a cause of the others — a noisy return series can
        end up anywhere in the discovered order, including ahead of genuine
        features, which is physically backwards (today's factor values
        cannot be caused by a future return) and silently produces zero
        detected "causal parents" for that fold whenever it happens, with no
        warning. When `sink_index` is given, that variable is excluded from
        candidacy as the next root at every step except the unavoidable last
        one (when it's the only variable left) — guaranteeing it always ends
        up last in the topological order, i.e. downstream of every feature,
        which is the only physically sensible position for a forward-return
        target in this ordering.
        """
        n_samples, p = X.shape
        active_indices = list(range(p))
        order: List[int] = []
        
        # Working copy of residuals
        R = X.copy()
        
        for _ in range(p):
            best_root = None
            min_dep = float('inf')

            # BUGFIX (Round 41): sink_index can only be chosen once it's the
            # sole remaining candidate — never earlier.
            candidates = active_indices
            if sink_index is not None and len(active_indices) > 1 and sink_index in active_indices:
                candidates = [j for j in active_indices if j != sink_index]

            for j in candidates:
                total_dep = 0.0
                xj = R[:, j]
                var_xj = np.var(xj)
                if var_xj < 1e-9:
                    total_dep = float('inf')
                else:
                    for k in active_indices:
                        if k == j:
                            continue
                        xk = R[:, k]
                        # Regress xk on xj
                        cov_kj = np.cov(xk, xj)[0, 1]
                        beta = cov_kj / var_xj
                        res = xk - beta * xj
                        # Measure dependence between xj and residual
                        dep = self._log_cosh_independence(xj, res)
                        total_dep += dep
                
                if total_dep < min_dep:
                    min_dep = total_dep
                    best_root = j
            
            if best_root is None:
                best_root = candidates[0]
            
            order.append(best_root)
            active_indices.remove(best_root)
            
            # Remove effect of best_root from remaining active variables
            if active_indices:
                xj = R[:, best_root]
                var_xj = np.var(xj)
                if var_xj >= 1e-9:
                    for k in active_indices:
                        cov_kj = np.cov(R[:, k], xj)[0, 1]
                        beta = cov_kj / var_xj
                        R[:, k] = R[:, k] - beta * xj

        # Now compute B matrix strictly lower triangular under permutation 'order'
        # B[i, j] is the direct causal coefficient of j on i.
        # So X[:, i] = sum_{j preceding i in order} B[i, j] * X[:, j] + e_i
        B = np.zeros((p, p), dtype=np.float64)
        for i_idx, i in enumerate(order):
            preceding = order[:i_idx]
            if not preceding:
                continue
            X_pred = X[:, preceding]
            y_curr = X[:, i]
            
            # OLS regression with ridge stabilization
            try:
                XT_X = X_pred.T @ X_pred + 1e-6 * np.eye(len(preceding))
                coeffs = np.linalg.solve(XT_X, X_pred.T @ y_curr)
                for prec_idx, j in enumerate(preceding):
                    val = float(coeffs[prec_idx])
                    if abs(val) >= self.prune_threshold:
                        B[i, j] = val
            except Exception:
                pass
                
        return order, B

    def fit(self, X: Union[np.ndarray, pd.DataFrame], 
            variable_names: Optional[List[str]] = None,
            sink_variable: Optional[Union[str, int]] = None) -> "PearlianCausalDiscoveryEngine":
        """
        Fits the Structural Causal Model on data matrix X.

        BUGFIX (Round 41): added `sink_variable` — pass the name (or index)
        of a variable that must not be treated as a cause of the others
        (typically a forward-looking training target). See _direct_lingam's
        docstring for why this matters. Optional and backward-compatible:
        omitting it reproduces the previous unconstrained behavior.
        """
        if isinstance(X, pd.DataFrame):
            self.variable_names = list(X.columns)
            data = X.values.astype(np.float64)
        else:
            data = np.asarray(X, dtype=np.float64)
            if variable_names is not None:
                self.variable_names = list(variable_names)
            else:
                self.variable_names = [f"Var_{i}" for i in range(data.shape[1])]

        # Sanitize data: replace NaNs with column median, ensure non-zero variance
        for col in range(data.shape[1]):
            nan_mask = np.isnan(data[:, col]) | np.isinf(data[:, col])
            if np.any(nan_mask):
                med = np.nanmedian(data[:, col])
                data[nan_mask, col] = med if not np.isnan(med) else 0.0
            col_std = np.std(data[:, col])
            if col_std < 1e-8:
                data[:, col] += np.random.normal(0, 1e-5, size=data.shape[0])

        p = data.shape[1]
        sink_index = None
        if sink_variable is not None:
            if isinstance(sink_variable, str):
                sink_index = self.variable_names.index(sink_variable) if sink_variable in self.variable_names else None
            else:
                sink_index = int(sink_variable)
        self.topological_order, self.causal_adjacency_matrix = self._direct_lingam(data, sink_index=sink_index)
        
        # Compute Total Effects Matrix: T = (I - B)^(-1)
        # Note: B is nilpotent since it is strictly acyclic under topological_order
        I = np.eye(p, dtype=np.float64)
        try:
            self.total_effects_matrix = np.linalg.inv(I - self.causal_adjacency_matrix)
        except Exception:
            # Fallback to truncated Neumann series sum_{k=0}^p B^k
            T = np.eye(p)
            Bk = np.eye(p)
            for _ in range(p):
                Bk = Bk @ self.causal_adjacency_matrix
                T += Bk
            self.total_effects_matrix = T

        # Compute residuals: e = (I - B) X^T
        self.residuals = (I - self.causal_adjacency_matrix) @ data.T
        self.is_fitted = True
        return self

    def intervene_do(self, interventions: Dict[Union[str, int], float], 
                     target: Optional[Union[str, int]] = None) -> Dict[str, Any]:
        """
        Performs Judea Pearl's Do-Calculus intervention:
        E[X | do(X_k = x_k for k in interventions)].
        Cuts incoming edges into intervened variables and propagates effects forward.
        """
        if not self.is_fitted or self.causal_adjacency_matrix is None:
            raise RuntimeError("Engine must be fitted before running interventions.")

        p = len(self.variable_names)
        var_to_idx = {name: i for i, name in enumerate(self.variable_names)}
        
        # Parse interventions into index mapping
        idx_interventions: Dict[int, float] = {}
        for k, v in interventions.items():
            if isinstance(k, str):
                if k in var_to_idx:
                    idx_interventions[var_to_idx[k]] = float(v)
            else:
                idx_interventions[int(k)] = float(v)

        # In Pearlian SCM: for intervened variables, X_k = v, incoming edges removed
        # Forward propagation in topological order
        counterfactual_vals = np.zeros(p, dtype=np.float64)
        intervened_mask = np.zeros(p, dtype=bool)
        for idx, val in idx_interventions.items():
            counterfactual_vals[idx] = val
            intervened_mask[idx] = True

        for i in self.topological_order:
            if intervened_mask[i]:
                continue
            # X_i = sum_j B[i, j] * X_j
            incoming = 0.0
            for j in range(p):
                if self.causal_adjacency_matrix[i, j] != 0.0:
                    incoming += self.causal_adjacency_matrix[i, j] * counterfactual_vals[j]
            counterfactual_vals[i] = incoming

        res: Dict[str, float] = {
            self.variable_names[i]: float(counterfactual_vals[i]) for i in range(p)
        }
        
        target_val = None
        if target is not None:
            t_idx = var_to_idx.get(target, target) if isinstance(target, str) else target
            if 0 <= t_idx < p:
                target_val = float(counterfactual_vals[t_idx])

        return {
            "interventions": {str(k): float(v) for k, v in interventions.items()},
            "counterfactual_expectations": res,
            "target_response": target_val,
        }

    def compute_invariant_causal_alphas(self, target_index: int = -1) -> Dict[str, Any]:
        """
        Isolates invariant causal parents PA(Y) for the specified target variable,
        separating true causal alpha drivers from spurious correlational co-movements.
        """
        if not self.is_fitted or self.causal_adjacency_matrix is None or self.total_effects_matrix is None:
            raise RuntimeError("Engine must be fitted.")

        p = len(self.variable_names)
        t_idx = (target_index + p) % p
        target_name = self.variable_names[t_idx]

        direct_parents: Dict[str, float] = {}
        total_effects: Dict[str, float] = {}
        spurious_divergences: Dict[str, float] = {}

        for j in range(p):
            if j == t_idx:
                continue
            var_name = self.variable_names[j]
            direct_effect = float(self.causal_adjacency_matrix[t_idx, j])
            total_effect = float(self.total_effects_matrix[t_idx, j])
            
            if abs(direct_effect) > 1e-4:
                direct_parents[var_name] = direct_effect
            if abs(total_effect) > 1e-4:
                total_effects[var_name] = total_effect
                
            # Spuriousness: difference between total causal effect and direct effect
            spurious_divergences[var_name] = abs(total_effect - direct_effect)

        # Invariant Causal Alpha Score
        # Weight drivers by their direct invariant causal influence, normalized
        total_mag = sum(abs(v) for v in direct_parents.values())
        causal_weights = {
            k: float(v / (total_mag + 1e-9)) for k, v in direct_parents.items()
        }

        # Stability ratio: direct causal variance / total connected variance
        sum_direct_sq = sum(v**2 for v in direct_parents.values())
        sum_total_sq = sum(v**2 for v in total_effects.values())
        causal_stability_ratio = float(sum_direct_sq / (sum_total_sq + 1e-9)) if sum_total_sq > 0 else 1.0
        causal_stability_ratio = min(1.0, max(0.0, causal_stability_ratio))

        return {
            "target_variable": target_name,
            "direct_causal_parents": direct_parents,
            "total_causal_effects": total_effects,
            "invariant_alpha_weights": causal_weights,
            "causal_stability_ratio": round(causal_stability_ratio, 4),
            "spurious_divergences": spurious_divergences,
            "is_causally_governed": len(direct_parents) > 0,
        }

    def diagnostics(self) -> Dict[str, Any]:
        """
        Returns full telemetry diagnostics for the structural causal discovery model.
        """
        if not self.is_fitted:
            return {"status": "NOT_FITTED"}

        p = len(self.variable_names)
        n_edges = int(np.count_nonzero(self.causal_adjacency_matrix))
        density = float(n_edges / (p * (p - 1))) if p > 1 else 0.0

        ordered_names = [self.variable_names[i] for i in self.topological_order]
        
        # Test a standard 1-sigma shock to the primary root variable
        root_idx = self.topological_order[0]
        root_name = self.variable_names[root_idx]
        shock_response = self.intervene_do({root_name: 1.0})

        # Calculate invariant causal alphas for the final downstream variable
        alpha_info = self.compute_invariant_causal_alphas(target_index=self.topological_order[-1])

        return {
            "topological_causal_order": ordered_names,
            "root_causes": ordered_names[:max(1, p // 3)],
            "downstream_effects": ordered_names[-max(1, p // 3):],
            "dag_edges_count": n_edges,
            "graph_causal_density": round(density, 4),
            "is_acyclic": True,
            "primary_root_shock_1sigma": shock_response["counterfactual_expectations"],
            "target_invariant_alphas": alpha_info,
            "status": "CONVERGED_DIRECT_LINGAM",
        }
