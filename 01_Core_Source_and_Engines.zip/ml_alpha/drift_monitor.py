"""
ml_alpha/drift_monitor.py
=========================
Institutional Model Drift & Factor Distribution Stability Monitor.

Key Capabilities:
1. Population Stability Index (PSI):
   - Quantifies distributional divergence between training/reference factor distributions
     and live inference data.
   - Formula:
       PSI = sum_{b=1}^B (P_b - Q_b) * ln(P_b / Q_b)
   - Benchmarks:
       * PSI < 0.10: Stable (No distribution shift)
       * 0.10 <= PSI < 0.25: Moderate Drift (Monitor closely)
       * PSI >= 0.25: Significant Drift (Trigger automated model retraining)

2. Wasserstein Distance (Earth Mover's Distance):
   - Continuous metric measuring the minimal cost of transforming reference factor
     distribution into live inference factor distribution.

3. Automated Retraining Recommendation:
   - Identifies which specific factors are decaying or drifting out-of-bounds.
   - Emits structured drift telemetry for dashboard and MLOps triggers.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

import numpy as np
import pandas as pd
from scipy import stats

logger = logging.getLogger("quantum_annealer.drift_monitor")

PSI_THRESHOLD_STABLE = 0.10
PSI_THRESHOLD_SIGNIFICANT = 0.25


def compute_psi(
    expected: Union[np.ndarray, Sequence[float], pd.Series],
    actual: Union[np.ndarray, Sequence[float], pd.Series],
    num_buckets: int = 10,
    eps: float = 1e-4,
) -> float:
    """
    Computes the Population Stability Index (PSI) between two distributions.

    Parameters:
        expected: Baseline/reference sample (e.g. training features).
        actual: Live/target sample (e.g. recent market features).
        num_buckets: Number of quantile bins to evaluate.
        eps: Small smoothing constant to prevent division by zero or log(0).

    Returns:
        Scalar PSI value (float).
    """
    e = np.asarray(expected, dtype=float)
    a = np.asarray(actual, dtype=float)

    e = e[~np.isnan(e) & ~np.isinf(e)]
    a = a[~np.isnan(a) & ~np.isinf(a)]

    if len(e) < 10 or len(a) < 10:
        return 0.0

    # Determine quantile bin edges from reference distribution
    percentiles = np.linspace(0, 100, num_buckets + 1)
    bin_edges = np.percentile(e, percentiles)
    # Deduplicate bin edges in case of ties
    bin_edges = np.unique(bin_edges)
    if len(bin_edges) < 2:
        return 0.0

    # Ensure bounds cover full range
    bin_edges[0] = -np.inf
    bin_edges[-1] = np.inf

    # Compute bucket frequencies
    e_counts, _ = np.histogram(e, bins=bin_edges)
    a_counts, _ = np.histogram(a, bins=bin_edges)

    # Convert to proportions with smoothing
    e_pct = (e_counts + eps) / (len(e) + eps * len(e_counts))
    a_pct = (a_counts + eps) / (len(a) + eps * len(a_counts))

    # PSI formula: sum((A - E) * ln(A / E))
    psi_val = np.sum((a_pct - e_pct) * np.log(a_pct / e_pct))
    return float(max(0.0, psi_val))


def compute_wasserstein_drift(
    expected: Union[np.ndarray, Sequence[float], pd.Series],
    actual: Union[np.ndarray, Sequence[float], pd.Series],
) -> float:
    """
    Computes the 1-Wasserstein distance between reference and live factor values.
    """
    e = np.asarray(expected, dtype=float)
    a = np.asarray(actual, dtype=float)
    e = e[~np.isnan(e) & ~np.isinf(e)]
    a = a[~np.isnan(a) & ~np.isinf(a)]

    if len(e) < 5 or len(a) < 5:
        return 0.0

    # Standardize both using reference scale to make distance unitless
    e_std = np.std(e)
    if e_std > 1e-8:
        e_norm = (e - np.mean(e)) / e_std
        a_norm = (a - np.mean(e)) / e_std
    else:
        e_norm, a_norm = e, a

    return float(stats.wasserstein_distance(e_norm, a_norm))


def evaluate_factor_drift(
    baseline_df: pd.DataFrame,
    current_df: pd.DataFrame,
    factor_cols: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Evaluates factor stability across reference baseline and live current data.

    Returns:
        Dict with overall status, per-factor PSI, drifted factors, and retraining trigger.
    """
    if factor_cols is None:
        factor_cols = [
            c for c in baseline_df.columns
            if c in current_df.columns and (c.startswith("z_") or "mom_" in c or "vol_" in c)
        ]

    per_factor_psi: Dict[str, float] = {}
    per_factor_wasserstein: Dict[str, float] = {}
    drifted_factors: List[str] = []
    moderate_drift_factors: List[str] = []

    for col in factor_cols:
        e_vals = baseline_df[col].dropna()
        a_vals = current_df[col].dropna()

        if len(e_vals) >= 10 and len(a_vals) >= 10:
            psi_val = compute_psi(e_vals, a_vals)
            w_dist = compute_wasserstein_drift(e_vals, a_vals)

            per_factor_psi[col] = round(psi_val, 4)
            per_factor_wasserstein[col] = round(w_dist, 4)

            if psi_val >= PSI_THRESHOLD_SIGNIFICANT:
                drifted_factors.append(col)
            elif psi_val >= PSI_THRESHOLD_STABLE:
                moderate_drift_factors.append(col)

    max_psi = max(per_factor_psi.values()) if per_factor_psi else 0.0
    mean_psi = float(np.mean(list(per_factor_psi.values()))) if per_factor_psi else 0.0

    if max_psi >= PSI_THRESHOLD_SIGNIFICANT:
        status = "SIGNIFICANT_DRIFT"
        retrain_recommended = True
    elif max_psi >= PSI_THRESHOLD_STABLE:
        status = "MODERATE_DRIFT"
        retrain_recommended = False
    else:
        status = "STABLE"
        retrain_recommended = False

    telemetry = {
        "status": status,
        "max_psi": round(max_psi, 4),
        "mean_psi": round(mean_psi, 4),
        "factors_evaluated": len(per_factor_psi),
        "drifted_factors": drifted_factors,
        "moderate_drift_factors": moderate_drift_factors,
        "retrain_recommended": retrain_recommended,
        "factor_psi": per_factor_psi,
        "factor_wasserstein": per_factor_wasserstein,
    }

    if retrain_recommended:
        logger.warning(
            f"[DriftMonitor] ⚠️ Significant factor drift detected! "
            f"Max PSI={max_psi:.3f} >= {PSI_THRESHOLD_SIGNIFICANT}. "
            f"Drifted factors: {drifted_factors}. Retraining recommended."
        )
    elif status == "MODERATE_DRIFT":
        logger.info(
            f"[DriftMonitor] Moderate factor drift: Max PSI={max_psi:.3f}. "
            f"Factors: {moderate_drift_factors}. Monitoring closely."
        )
    else:
        logger.info(f"[DriftMonitor] Factor distributions are STABLE (Max PSI={max_psi:.3f} < {PSI_THRESHOLD_STABLE}).")

    return telemetry


def test_drift_monitor():
    """Unit test for drift monitor."""
    rng = np.random.default_rng(42)  # ROUND 45: local rng — was a global np.random.seed
    # Baseline normal distribution
    baseline = pd.DataFrame({
        "z_mom_3m": rng.randn(500),
        "z_vol_surge": rng.randn(500),
        "z_roe": rng.randn(500),
    })

    # Case 1: Same distribution -> STABLE
    stable_sample = pd.DataFrame({
        "z_mom_3m": rng.randn(200),
        "z_vol_surge": rng.randn(200),
        "z_roe": rng.randn(200),
    })
    res_stable = evaluate_factor_drift(baseline, stable_sample)
    assert res_stable["status"] == "STABLE", f"Expected STABLE, got {res_stable['status']}"
    assert res_stable["retrain_recommended"] is False

    # Case 2: Shifted distribution (mean shift + variance expansion) -> SIGNIFICANT_DRIFT
    drifted_sample = pd.DataFrame({
        "z_mom_3m": rng.randn(200) * 2.5 + 1.8,  # heavy shift
        "z_vol_surge": rng.randn(200),
        "z_roe": rng.randn(200),
    })
    res_drift = evaluate_factor_drift(baseline, drifted_sample)
    assert res_drift["status"] == "SIGNIFICANT_DRIFT", f"Expected SIGNIFICANT_DRIFT, got {res_drift['status']}"
    assert "z_mom_3m" in res_drift["drifted_factors"]
    assert res_drift["retrain_recommended"] is True

    print("[DriftMonitor] All unit tests passed!")
    return True
