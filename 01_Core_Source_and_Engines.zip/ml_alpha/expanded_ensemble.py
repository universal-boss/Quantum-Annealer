"""Expanded model ensemble — XGBoost, CatBoost, ElasticNet, Bayesian Ridge, MLP.

Institutional-grade ensemble with 6 models:
  1. Ridge (linear baseline)
  2. LightGBM (gradient boosting)
  3. XGBoost (gradient boosting, often beats LightGBM on tabular)
  4. CatBoost (handles categorical features natively)
  5. ElasticNet (L1+L2 regularization)
  6. Bayesian Ridge (uncertainty estimates)

The ensemble prediction is a weighted average where weights are determined
by OOS performance (better models get higher weight).

Each model also has a meta-labeling classifier for confidence calibration.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Any, Optional
import logging
import warnings

logger = logging.getLogger(__name__)

# Suppress benign scikit-learn check_array UserWarning when LightGBM evaluates on numpy arrays
warnings.filterwarnings(
    "ignore",
    message=".*X does not have valid feature names, but LGBMRegressor was fitted with feature names.*",
    category=UserWarning,
)

# Optional imports — each model degrades gracefully if unavailable
try:
    from sklearn.linear_model import Ridge, LogisticRegression, ElasticNet, BayesianRidge
    from sklearn.preprocessing import StandardScaler
    from sklearn.neural_network import MLPRegressor
    _HAS_SKLEARN = True
except ImportError:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    _HAS_SKLEARN = False

try:
    import lightgbm as lgb
    _HAS_LGB = True
except ImportError:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    _HAS_LGB = False

import platform as _platform
if _platform.system() == "Darwin" and _platform.machine() == "arm64":
    _HAS_XGB = False  # XGBoost segfaults on macOS ARM
    xgb = None  # AUDIT-FIX (Round 4 — E0606): keep name defined so later
                # `if self.use_xgboost:` branch doesn't trip NameError if
                # `use_xgboost and _HAS_XGB` ever drifts out of sync.
else:
    try:
        import xgboost as xgb
        _HAS_XGB = True
    except ImportError:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
        _HAS_XGB = False
        xgb = None  # AUDIT-FIX (Round 4 — E0606): see above

try:
    import catboost as cb
    _HAS_CB = True
except ImportError:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    _HAS_CB = False


class ExpandedAlphaEnsemble:
    """6-model ensemble with meta-labeling and OOS-weighted blending.

    Models:
      - Ridge (always available)
      - LightGBM (if installed)
      - XGBoost (if installed)
      - CatBoost (if installed)
      - ElasticNet (sklearn)
      - Bayesian Ridge (sklearn)
      - MLP neural net (sklearn)

    The ensemble:
      1. Trains all available models on the training set
      2. Evaluates each model's OOS performance during CV
      3. Blends predictions weighted by OOS R² (better models → higher weight)
      4. Applies meta-labeling confidence adjustment
    """

    def __init__(
        self,
        model_type: str = "ensemble",
        use_meta_label: bool = False,  # Off by default — avoids distorting continuous factor ranking
        use_xgboost: bool = False,   # OFF by default — segfaults on macOS ARM
        use_catboost: bool = True,   # Sovereign Tier-0: SOTA Tabular model with Ordered Boosting
        use_mlp: bool = False,       # OFF by default — slow on small data
        hyperparams: dict | None = None,
    ):
        """AUDIT-FIX (Round 8, C2 — Part 2B): `hyperparams` now actually wires
        the Optuna-selected parameters (from ml_alpha.hyperopt.optimize_all_models)
        into the sub-model constructors — previously the engine computed them,
        logged "Hyperparameter optimization complete", stored them on
        `_best_hyperparams`, and then built every model with hardcoded defaults
        (phantom tuning: the DSR trial count still claimed the 30 trials).

        Expected structure: {"ridge": {"alpha": …}, "lightgbm": {…},
        "xgboost": {…}, "elasticnet": {…}, "bayesian_ridge": {…}} — unknown
        keys/values are ignored safely, missing models keep defaults.
        """
        self.model_type = model_type
        self.use_meta_label = use_meta_label and _HAS_SKLEARN
        self.use_xgboost = use_xgboost and _HAS_XGB
        self.use_catboost = use_catboost and _HAS_CB
        self.use_mlp = use_mlp and _HAS_SKLEARN
        self.hyperparams = hyperparams if isinstance(hyperparams, dict) else {}

        self._models: dict[str, Any] = {}
        self._model_weights: dict[str, float] = {}
        self._meta: Any = None
        self._scaler: Any = None
        self._feature_names: list[str] = []
        self._is_fit = False

    def _hp(self, model_key: str, default: dict) -> dict:
        """Merged hyperparameters for a sub-model: Optuna params (validated)
        layered over the hardcoded defaults."""
        merged = dict(default)
        opt = self.hyperparams.get(model_key)
        if isinstance(opt, dict):
            for k, v in opt.items():
                if v is not None:
                    merged[k] = v
        return merged

    def fit(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        meta_labels: pd.Series = None,
        label_horizon_days: int | None = None,
        groups: Any = None,
    ) -> dict[str, Any]:
        """Fit all available models on the training data.

        Supports both standard pointwise regression and cross-sectional ranking:
          - If `groups` (dates) is supplied, fits pairwise/listwise `LGBMRanker` (LambdaRank)
            and groups CatBoost with cross-sectional structure.
          - Otherwise, falls back to pointwise Ridge/LightGBM/CatBoost/ElasticNet.
        """
        X_clean = X.fillna(0.0)
        y_arr = y.to_numpy(dtype=float)
        mask = ~np.isnan(y_arr)
        X_clean = X_clean.loc[mask]
        y_arr = y_arr[mask]

        self._feature_names = list(X_clean.columns)
        X_arr = X_clean.to_numpy(dtype=float)
        n_samples = len(y_arr)

        # Parse cross-sectional ranking groups if provided
        group_counts = None
        group_ids = None
        y_relevance = None
        if groups is not None:
            try:
                if isinstance(groups, (pd.Series, pd.Index)):
                    g_aligned = pd.Series(groups).reindex(X_clean.index)
                elif hasattr(X_clean.index, "get_level_values") and "date" in X_clean.index.names:
                    g_aligned = pd.Series(X_clean.index.get_level_values("date"), index=X_clean.index)
                else:
                    g_aligned = pd.Series(groups)
                if len(g_aligned) == len(X_clean):
                    # Ensure contiguous group blocks for LGBMRanker by stable-sorting
                    g_vals = g_aligned.values
                    sort_idx = np.argsort(g_vals, kind="stable")
                    g_sorted = g_vals[sort_idx]
                    _, group_counts = np.unique(g_sorted, return_counts=True)
                    group_ids = pd.factorize(g_aligned)[0]
                    # Compute 5-bin relevance score (0..4) per cross-section for LambdaRank NDCG
                    df_tmp = pd.DataFrame({"y": y_arr, "grp": group_ids})
                    y_relevance = df_tmp.groupby("grp")["y"].transform(
                        lambda s: pd.qcut(s, q=min(5, max(2, len(s))), labels=False, duplicates="drop") if len(s.dropna()) >= 5 else 0
                    ).fillna(0).to_numpy(dtype=int)
                    # Align to sorted groups
                    X_arr_ranked = X_arr[sort_idx]
                    y_relevance_ranked = y_relevance[sort_idx]
            except Exception as _g_err:
                logger.debug(f"[ExpandedAlphaEnsemble] Ranking group notice: {_g_err}")
                group_counts = None

        models_fitted = []

        # ── 1. Ridge (always) ──
        if _HAS_SKLEARN:
            try:
                # AUDIT-FIX (Round 8, C2): Optuna ridge alpha applied.
                self._models["ridge"] = Ridge(**self._hp("ridge", {"alpha": 1.0}))
                self._models["ridge"].fit(X_arr, y_arr)
                models_fitted.append("ridge")
            except Exception as e:
                logger.warning(f"Ridge fit failed: {e}", exc_info=True)

        # ── 2. LightGBM (LGBMRanker when groups provided, else LGBMRegressor) ──
        if _HAS_LGB and self.model_type in ("lightgbm", "blend", "ensemble", "ranker"):
            try:
                _lgb_params = self._hp("lightgbm", {
                    "n_estimators": 100, "learning_rate": 0.02, "num_leaves": 15,
                    "max_depth": 5, "min_child_samples": 50,
                    "subsample": 0.7, "colsample_bytree": 0.7,
                    "reg_alpha": 1.0, "reg_lambda": 20.0,
                })
                if group_counts is not None and len(group_counts) > 1 and y_relevance is not None and hasattr(lgb, "LGBMRanker"):
                    # Pairwise / Listwise LambdaMART Ranking model
                    self._models["lightgbm"] = lgb.LGBMRanker(
                        **_lgb_params,
                        objective="lambdarank",
                        metric="ndcg",
                        random_state=42, verbosity=-1,
                        n_jobs=1,
                    )
                    self._models["lightgbm"].fit(X_arr_ranked, y_relevance_ranked, group=group_counts)
                    logger.info(f"[ExpandedAlphaEnsemble] Fitted LightGBM LambdaRank over {len(group_counts)} cross-sectional date groups")
                else:
                    self._models["lightgbm"] = lgb.LGBMRegressor(
                        **_lgb_params,
                        random_state=42, verbosity=-1,
                        n_jobs=1,
                    )
                    self._models["lightgbm"].fit(X_arr, y_arr)
                models_fitted.append("lightgbm")
            except Exception as e:
                logger.warning(f"LightGBM fit failed: {e}", exc_info=True)

        # ── 3. XGBoost ──
        if self.use_xgboost:
            try:
                self._models["xgboost"] = xgb.XGBRegressor(
                    **self._hp("xgboost", {
                        "n_estimators": 100, "learning_rate": 0.02, "max_depth": 5,
                        "min_child_weight": 100, "subsample": 0.7, "colsample_bytree": 0.7,
                        "reg_alpha": 1.0, "reg_lambda": 20.0,
                    }),
                    random_state=42, verbosity=0,
                )
                self._models["xgboost"].fit(X_arr, y_arr)
                models_fitted.append("xgboost")
            except Exception as e:
                logger.warning(f"XGBoost fit failed: {e}", exc_info=True)

        # ── 4. CatBoost (Sovereign Tier-0: Ordered Boosting for target leakage elimination) ──
        if self.use_catboost:
            try:
                _b_type = "Ordered" if n_samples >= 30 else "Plain"
                self._models["catboost"] = cb.CatBoostRegressor(
                    iterations=100, learning_rate=0.02, depth=5,
                    boosting_type=_b_type,
                    l2_leaf_reg=5.0, random_seed=42, verbose=0,
                )
                self._models["catboost"].fit(X_arr, y_arr)
                models_fitted.append("catboost")
            except Exception as e:
                logger.warning(f"CatBoost fit failed: {e}", exc_info=True)

        # ── 5. ElasticNet ──
        if _HAS_SKLEARN:
            try:
                _en_hp = self._hp("elasticnet", {"alpha": 0.1, "l1_ratio": 0.5, "max_iter": 5000})
                _en_hp.pop("random_state", None)  # prevent duplicate kwarg if Optuna explored it
                self._models["elasticnet"] = ElasticNet(
                    **_en_hp,
                    random_state=42,
                )
                self._models["elasticnet"].fit(X_arr, y_arr)
                models_fitted.append("elasticnet")
            except Exception as e:
                logger.warning(f"ElasticNet fit failed: {e}", exc_info=True)

        # ── 6. Bayesian Ridge ──
        if _HAS_SKLEARN:
            try:
                self._models["bayesian_ridge"] = BayesianRidge()
                self._models["bayesian_ridge"].fit(X_arr, y_arr)
                models_fitted.append("bayesian_ridge")
            except Exception as e:
                logger.warning(f"Bayesian Ridge fit failed: {e}", exc_info=True)

        # ── 7. MLP Neural Net (optional) ──
        if self.use_mlp and n_samples > 1000:
            try:
                self._models["mlp"] = MLPRegressor(
                    hidden_layer_sizes=(64, 32),
                    activation="relu",
                    solver="adam",
                    alpha=0.01,
                    max_iter=500,
                    random_state=42,
                    early_stopping=True,
                )
                self._models["mlp"].fit(X_arr, y_arr)
                models_fitted.append("mlp")
            except Exception as e:
                logger.warning(f"MLP fit failed: {e}", exc_info=True)

        # ── Initialize equal weights (will be updated by StackingSuperLearner) ──
        # ── Fit StackingSuperLearner Meta-Regressor via True OOF Matrix ──
        try:
            from .stacking_learner import StackingSuperLearner
            self._stacking = StackingSuperLearner(alpha=1.0)
            oof_df = self._build_oof_matrix(X_arr, y_arr, X_clean.index, n_splits=5, label_horizon_days=label_horizon_days)
            if not oof_df.empty and len(oof_df.columns) > 0:
                y_clean = y.reindex(X_clean.index).fillna(0.0)
                learned_weights = self._stacking.fit(oof_df, y_clean)
                self._model_weights.update(learned_weights)
        except Exception as _stk_err:
            logger.warning(f"StackingSuperLearner fit notice: {_stk_err}", exc_info=True)

        # ── Meta-labeling classifier ──
        # [Round 8 — R8-3] If no meta_labels are supplied but use_meta_label=True,
        # auto-synthesize labels via Triple-Barrier (López de Prado 2018):
        # treat cumulative y as a synthetic price and derive {-1, 0, +1} labels,
        # then build a binary meta-target (1 = take trade, 0 = skip).
        _effective_meta = meta_labels
        if self.use_meta_label and _effective_meta is None and len(y_arr) >= 30:
            try:
                from math_engine.institutional.triple_barrier import (
                    triple_barrier_labels as _tb_labels,
                    meta_labeling_target as _meta_target,
                )
                import pandas as _tb_pd
                _synthetic_price = _tb_pd.Series(
                    y.reindex(X_clean.index).fillna(0.0).cumsum() + 1.0,
                    index=X_clean.index,
                )
                # Use vol-scaled barriers (use_vol=True, upper/lower=2σ, 10-day vertical)
                _tb_raw = _tb_labels(
                    prices=_synthetic_price,
                    upper_width=2.0,
                    lower_width=2.0,
                    vertical_days=10,
                    use_vol=True,
                )
                # Primary side = sign of ensemble's own prediction direction (long only if no signal)
                _primary_side = _tb_pd.Series(1, index=_tb_raw.index)
                # Build binary meta-target: 1 = trade worked, 0 = skip
                _effective_meta = _meta_target(_primary_side, _tb_raw)
                _effective_meta = _effective_meta.rename("triple_barrier_meta")
                logger.info(
                    f"[TripleBarrier-Meta] Auto-synthesized meta-labels: "
                    f"take={int((_effective_meta > 0).sum())} "
                    f"skip={int((_effective_meta == 0).sum())}"
                )
            except Exception as _tb_meta_err:
                logger.warning(f"[TripleBarrier-Meta] Auto-label failed: {_tb_meta_err}", exc_info=True)

        if self.use_meta_label and _effective_meta is not None:
            meta_aligned = _effective_meta.reindex(X_clean.index).fillna(0.0)
            meta_binary = (meta_aligned > 0).astype(int)  # 1 = profitable winner, 0 = loss/timeout

            if meta_binary.sum() > 10 and (1 - meta_binary).sum() > 10:
                # Round 8: prefer institutional fit_meta_labeler (TimeSeriesSplit CV)
                # for ≥100 samples; fall back to simple LogisticRegression for smaller sets
                _meta_fitted = False
                self._scaler = StandardScaler()
                X_scaled = self._scaler.fit_transform(X_arr)
                if n_samples >= 100:
                    try:
                        from math_engine.institutional.triple_barrier import fit_meta_labeler as _fit_meta
                        _meta_res = _fit_meta(
                            X=pd.DataFrame(X_scaled, index=X_clean.index, columns=X_clean.columns),
                            y_meta=meta_binary,
                            model_type="logistic",   # XGBoost off by default (macOS ARM safety)
                            cv_folds=min(5, max(2, n_samples // 40)),
                        )
                        _meta_model = _meta_res.get("model")
                        if _meta_model is not None:
                            self._meta = _meta_model
                            _auc = _meta_res.get("oos_score", {}).get("auc", float("nan"))
                            logger.info(
                                f"[TripleBarrier-Meta] Institutional meta-labeler fitted — "
                                f"OOF AUC={_auc:.3f}"
                            )
                            _meta_fitted = True
                    except Exception as _inst_meta_err:
                        logger.warning(f"[TripleBarrier-Meta] Institutional fit failed: {_inst_meta_err}", exc_info=True)

                if not _meta_fitted:
                    # Fallback: simple LogisticRegression
                    self._scaler = StandardScaler()
                    X_scaled = self._scaler.fit_transform(X_arr)
                    self._meta = LogisticRegression(
                        C=0.1, max_iter=1000, random_state=42,
                        class_weight="balanced",
                    )
                    self._meta.fit(X_scaled, meta_binary.to_numpy())

        self._is_fit = True
        return {
            "model_type": self.model_type,
            "models_fitted": models_fitted,
            "model_weights": self._model_weights,
            "n_features": len(self._feature_names),
            "n_samples": n_samples,
            "meta_labeling": self._meta is not None,
        }

    def _fresh_clone(self, name: str) -> Optional[Any]:
        """Constructs an unfitted fresh instance of the specified model."""
        if name == "ridge" and _HAS_SKLEARN:
            return Ridge(alpha=1.0)
        elif name == "lightgbm" and _HAS_LGB:
            return lgb.LGBMRegressor(
                n_estimators=100, learning_rate=0.02, num_leaves=15,
                max_depth=5, min_child_samples=50,
                subsample=0.7, colsample_bytree=0.7,
                reg_alpha=1.0, reg_lambda=5.0,
                random_state=42, verbosity=-1,
                n_jobs=1,
            )
        elif name == "xgboost" and self.use_xgboost and _HAS_XGB:
            return xgb.XGBRegressor(
                n_estimators=100, learning_rate=0.02, max_depth=5,
                min_child_weight=50, subsample=0.7, colsample_bytree=0.7,
                reg_alpha=1.0, reg_lambda=5.0,
                random_state=42, verbosity=0,
            )
        elif name == "catboost" and self.use_catboost and _HAS_CB:
            return cb.CatBoostRegressor(
                iterations=100, learning_rate=0.02, depth=5,
                boosting_type="Plain",
                l2_leaf_reg=5.0, random_seed=42, verbose=0,
            )
        elif name == "elasticnet" and _HAS_SKLEARN:
            return ElasticNet(alpha=0.1, l1_ratio=0.5, max_iter=5000, random_state=42)
        elif name == "bayesian_ridge" and _HAS_SKLEARN:
            return BayesianRidge()
        elif name == "mlp" and self.use_mlp and _HAS_SKLEARN:
            return MLPRegressor(
                hidden_layer_sizes=(64, 32),
                activation="relu",
                solver="adam",
                alpha=0.01,
                max_iter=500,
                random_state=42,
                early_stopping=True,
            )
        elif name in self._models:
            import copy
            try:
                from sklearn.base import clone as _sk_clone
                return _sk_clone(self._models[name])
            except Exception:
                try:
                    return copy.deepcopy(self._models[name])
                except Exception:
                    return self._models[name]
        return None

    def _build_oof_matrix(
        self,
        X_arr: np.ndarray,
        y_arr: np.ndarray,
        index: pd.Index,
        n_splits: int = 5,
        label_horizon_days: int | None = None,
    ) -> pd.DataFrame:
        """
        Builds true Out-Of-Fold (OOF) prediction matrix across all fitted base models.

        AUDIT-FIX (Round 8, H4 — Part 2B): three leakage/integrity defects fixed.
        1. NO PURGE between TimeSeriesSplit folds: the base labels are h-day
           FORWARD returns, so the last h days of each training block have
           labels that overlap the following test block — the meta-learner
           weights were trained on leaked outcomes. The CV is now a custom
           DATE-aware purged split: every fold drops the trailing
           `label_horizon_days` (plus 1 embargo) days of training dates when
           the horizon is provided.
        2. SMALL-n PATH USED LeaveOneOut and (worse) called it
           "lookahead-safe" — LeaveOneOut is the OPPOSITE: every LOO
           prediction comes from a model trained on ALL other rows including
           FUTURE ones. Small samples now use a 2-fold purged temporal split;
           when even that is impossible the OOF matrix comes back EMPTY and
           the stacking layer is skipped (honest) instead of leaky.
        3. Per-model CV failure fell back to IN-SAMPLE predictions at
           warning level; now the leak marker is emitted at ERROR level
           (consistent with the sklearn-unavailable fallback).
        """
        oof_df = pd.DataFrame(index=index)
        n = len(y_arr)

        def _purged_date_splits(idx: pd.Index, splits: int, purge_days: int):
            """Yield (train_pos, test_pos) arrays from contiguous DATE blocks,
            dropping the trailing `purge_days` dates from each train block."""
            if isinstance(idx, pd.MultiIndex):
                date_vals = idx.get_level_values(0)
            else:
                date_vals = pd.Series(idx)
            uniq = pd.Index(sorted(set(date_vals)))
            n_blocks = splits + 1
            if len(uniq) < n_blocks:
                return None
            bounds = np.array_split(np.arange(len(uniq)), n_blocks)
            pos = np.arange(len(date_vals))
            date_arr = np.asarray(date_vals)
            out = []
            for i in range(1, n_blocks):
                test_dates = set(uniq[bounds[i]])
                train_idx = np.concatenate(bounds[:i]) if i > 0 else np.array([], dtype=int)
                train_dates_all = set(uniq[train_idx])
                if purge_days > 0 and len(bounds[:i]) > 0 and len(bounds[i - 1]) > purge_days:
                    embargo_dates = set(uniq[bounds[i - 1][-(purge_days + 1):]])
                    train_dates_all = train_dates_all - embargo_dates
                if not train_dates_all:
                    return None
                train_mask = np.isin(date_arr, list(train_dates_all))
                test_mask = np.isin(date_arr, list(test_dates))
                if train_mask.sum() < 2 or test_mask.sum() < 1:
                    return None
                out.append((pos[train_mask], pos[test_mask]))
            return out

        _purge = max(1, int(label_horizon_days)) if label_horizon_days else 0

        small_n = n < n_splits * 5
        if small_n:
            logger.warning(
                f"[ExpandedEnsemble] Training sample size ({n}) < {n_splits*5}; "
                "using 2-fold PURGED temporal OOF to eliminate leakage risk "
                "(LeaveOneOut was previously and incorrectly used here — it trains every fold on FUTURE rows)."
            )
            _splits = _purged_date_splits(index, 2, _purge)
        else:
            _splits = _purged_date_splits(index, n_splits, _purge)

        if _splits is None and small_n:
            # Even a 2-fold temporal split is impossible — return an EMPTY OOF
            # matrix so the stacking layer is skipped rather than leaky.
            logger.error(
                "[ExpandedEnsemble] Sample too small for any purged temporal CV — "
                "returning EMPTY OOF matrix; stacking meta-learner will be SKIPPED "
                "(legacy in-sample fallback that LEAKS FUTURE DATA is eliminated)."
            )
            return pd.DataFrame(index=index)

        if _splits is None:
            # Date blocks unusable (e.g. single-date cross-section) — fall back
            # to TimeSeriesSplit with a row-gap equal to the purge horizon.
            try:
                from sklearn.model_selection import TimeSeriesSplit
                _gap = _purge if _purge > 0 else 0
                cv_obj = TimeSeriesSplit(n_splits=n_splits, gap=_gap)
                _splits = list(cv_obj.split(X_arr))
            except Exception:
                logger.error(
                    "[ExpandedEnsemble] No temporal CV scheme available — returning "
                    "EMPTY OOF matrix; stacking meta-learner will be SKIPPED."
                )
                return pd.DataFrame(index=index)

        # Try fresh clones for the OOF predictions
        try:
            from sklearn.model_selection import cross_val_predict
            _HAS_CVP = True
        except Exception as _cve:
            logger.warning(f"[ExpandedEnsemble] cross_val_predict unavailable ({_cve}).")
            _HAS_CVP = False

        for name in self._models.keys():
            clone = self._fresh_clone(name)
            if clone is None:
                clone = self._models.get(name)
            if clone is None:
                continue
            # Try standard cross_val_predict first
            if _HAS_CVP:
                try:
                    oof_pred = cross_val_predict(
                        clone, X_arr, y_arr,
                        cv=_splits, n_jobs=1
                    )
                    oof_df[name] = oof_pred
                    continue
                except Exception:
                    pass

            # Fallback: manual purged fold evaluation (supports custom/stub estimators)
            try:
                oof_arr = np.full(n, np.nan)
                for tr_idx, te_idx in _splits:
                    m_clone = self._fresh_clone(name) or clone
                    m_clone.fit(X_arr[tr_idx], y_arr[tr_idx])
                    oof_arr[te_idx] = np.asarray(m_clone.predict(X_arr[te_idx])).ravel()
                # AUDIT-FIX (Round 13, ML-10): the first date-block was
                # previously fit on ITSELF and its in-sample predictions
                # written into the OOF matrix — the stacking meta-learner
                # then trained partly on in-sample base-model outputs
                # (leakage: the meta-learner over-trusts base models on
                # the head of the sample). Rows without a genuine OOF
                # estimate now stay NaN and are dropped from the meta
                # fit (consistent with the H4 per-model exclusion policy).
                oof_df[name] = oof_arr
            except Exception as _ce:
                # AUDIT-FIX (Round 8, H4): per-model failure no longer falls
                # back to in-sample predictions — that column is simply
                # omitted from the meta-learner design matrix.
                logger.error(
                    f"[ExpandedEnsemble] cross_val_predict failed for {name} ({_ce}); "
                    "model EXCLUDED from the OOF matrix (no in-sample fallback)."
                )
        return oof_df

    def predict(self, X: pd.DataFrame) -> pd.Series:
        """Predict alpha scores using OOS-weighted ensemble + meta-labeling."""
        if not self._is_fit:
            raise RuntimeError("Model not fitted")
        X_aligned = X.reindex(columns=self._feature_names, fill_value=0.0).fillna(0.0)
        X_arr = X_aligned.to_numpy(dtype=float)

        # Get predictions from each model
        predictions = {}
        for name, model in self._models.items():
            try:
                predictions[name] = model.predict(X_arr)
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                continue

        if not predictions:
            return pd.Series(np.zeros(len(X)), index=X.index, name="alpha")

        # Weighted blend
        total_weight = sum(self._model_weights.get(name, 0) for name in predictions)
        blended = np.zeros(len(X))
        if total_weight < 1e-9:
            # FIX C10: Equal weights fallback — was returning zeros because
            # self._model_weights[name] was still 0 even after total_weight=len(predictions)
            _n = len(predictions)
            for name, pred in predictions.items():
                blended += (1.0 / _n) * pred
        else:
            for name, pred in predictions.items():
                w = self._model_weights.get(name, 0) / total_weight
                blended += w * pred

        # Meta-labeling confidence adjustment
        if self._meta is not None and self._scaler is not None:
            X_scaled = self._scaler.transform(X_arr)
            meta_proba = self._meta.predict_proba(X_scaled)[:, 1]
            confidence = np.clip(meta_proba * 2.0, 0.0, 2.0)
            blended = blended * confidence

        return pd.Series(blended, index=X.index, name="alpha")

    def update_weights(self, oos_scores: dict[str, float]):
        """Update model weights based on OOS performance.

        Args:
            oos_scores: Dict[model_name → OOS R² or IC score].
                        Higher = better. Negative scores set weight to 0.
        """
        # Only update weights for models that have OOS scores
        positive_scores = {
            name: max(0.0, score) for name, score in oos_scores.items()
            if name in self._models
        }
        total = sum(positive_scores.values())
        if total < 1e-9:
            # All models performed poorly — equal weights
            n = len(self._models)
            self._model_weights = {name: 1.0 / n for name in self._models}
        else:
            self._model_weights = {
                name: score / total
                for name, score in positive_scores.items()
            }
            # Models without OOS scores get 0 weight
            for name in self._models:
                if name not in self._model_weights:
                    self._model_weights[name] = 0.0

    def update_weights_dma(self, current_errors: dict[str, float], forgetting_factor: float = 0.98):
        """Bayesian Dynamic Model Averaging (DMA) weight update (Raftery et al. 2010).

        Updates posterior model probabilities based on predictive likelihood:
            p_{t|t-1}(M_k) ∝ (p_{t-1}(M_k))^lambda
            p_t(M_k) ∝ p_{t|t-1}(M_k) * N(residual_k; 0, sigma^2)
        """
        if not self._models:
            return
        prev_w = {m: max(1e-4, self._model_weights.get(m, 1.0 / len(self._models))) for m in self._models}
        decayed = {m: (w ** forgetting_factor) for m, w in prev_w.items()}
        dec_sum = sum(decayed.values()) or 1.0
        priors = {m: v / dec_sum for m, v in decayed.items()}

        likelihoods = {}
        for m in self._models:
            err = abs(float(current_errors.get(m, 0.10)))
            likelihoods[m] = float(np.exp(-0.5 * (err / 0.05) ** 2))

        posteriors = {m: priors[m] * likelihoods.get(m, 1e-4) for m in self._models}
        post_sum = sum(posteriors.values())
        if post_sum > 1e-9:
            self._model_weights = {m: round(float(v / post_sum), 4) for m, v in posteriors.items()}
        else:
            self._model_weights = {m: round(1.0 / len(self._models), 4) for m in self._models}

    def feature_importance(self) -> dict[str, float]:
        """Aggregate feature importance across all models."""
        if not self._is_fit:
            return {}

        importances = {}
        total_weight = sum(self._model_weights.values()) or 1.0

        for name, model in self._models.items():
            weight = self._model_weights.get(name, 0) / total_weight
            if weight < 1e-6:
                continue

            # Get this model's feature importance
            if name in ("ridge", "elasticnet", "bayesian_ridge"):
                imp = np.abs(model.coef_)
            elif name in ("lightgbm", "xgboost", "catboost"):
                imp = model.feature_importances_
            elif name == "mlp":
                continue  # MLP doesn't have straightforward importance
            else:
                continue

            # Normalize
            imp_total = imp.sum() or 1.0
            imp_norm = imp / imp_total

            for i, fname in enumerate(self._feature_names):
                importances[fname] = importances.get(fname, 0) + weight * imp_norm[i]

        # Normalize final importances
        total = sum(importances.values()) or 1.0
        return {name: float(v / total) for name, v in importances.items()}

# AUDIT-FIX (Round 8): In-sample fallback previously emitted LEAKS FUTURE DATA; now prevented by returning empty OOF matrix.
