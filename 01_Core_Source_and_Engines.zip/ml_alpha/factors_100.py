"""100+ Factor Library — Comprehensive factor set for ML alpha.

Provides 91 base factors across:
  - Momentum (12 factors: 1d, 5d, 21d, 63d, 126d, 252d, skip periods, accelerating)
  - Reversal (6 factors: 1d, 3d, 5d, 10d, 21d, 63d)
  - Volatility (10 factors: 3m, 6m, 12m, vol-of-vol, range-based)
  - Volume (10 factors: surge, trend, relative, turnover, Amihud illiquidity)
  - Trend (10 factors: ADX, Aroon, directional movement, trend strength)
  - Mean Reversion (6 factors: RSI at 7/14/21/28, Bollinger, Keltner)
  - Price Patterns (10 factors: candlestick, support/resistance, breakout)
  - Liquidity (6 factors: turnover, Amihud, bid-ask spread proxy)
  - Higher Moments (6 factors: skew, kurtosis at different windows)
  - MACD / Moving Average Crossovers (6 factors)
  - VWAP / Price-Volume (6 factors)
  - Fractional Differentiation (3 factors)
  = 91 base factors

The 39 new liquidity/microstructure factors (Kyle's lambda, VPIN, Roll spread, etc.)
are embedded directly in kaggle_train_ml_alpha.py and kaggle_e2e_pipeline.py
as a self-contained patch, so they don't need to be in this file.

Let the model find which ones have predictive power via IC+Lasso selection.
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from typing import Optional


# ═══════════════════════════════════════════════════════════════════════════════
# HELPER
# ═══════════════════════════════════════════════════════════════════════════════

def _safe_div(a, b):
    """Safe division — returns NaN when b=0."""
    return a / b.replace(0, np.nan) if hasattr(b, 'replace') else a / (b + 1e-12)


# ═══════════════════════════════════════════════════════════════════════════════
# MOMENTUM (12 factors)
# ═══════════════════════════════════════════════════════════════════════════════

def mom_1d(close): return close.pct_change(1)
def mom_5d(close): return close.pct_change(5)
def mom_21d(close): return close.pct_change(21)
def mom_63d(close): return close.pct_change(63)
def mom_126d(close): return close.pct_change(126)
def mom_252d(close): return close.pct_change(252)
def mom_skip1_21(close): return close.shift(1) / close.shift(22) - 1
def mom_skip5_63(close): return close.shift(5) / close.shift(68) - 1
def mom_skip21_252(close): return close.shift(21) / close.shift(252) - 1
def mom_accel_21(close):
    """Momentum acceleration: 21d return - previous 21d return."""
    return close.pct_change(21) - close.shift(21).pct_change(21)
def mom_accel_63(close):
    return close.pct_change(63) - close.shift(63).pct_change(63)
def mom_decel_21(close):
    """Momentum deceleration: is momentum slowing?"""
    m = close.pct_change(21)
    return m - m.rolling(5).mean()


# ═══════════════════════════════════════════════════════════════════════════════
# REVERSAL (6 factors)
# ═══════════════════════════════════════════════════════════════════════════════

def rev_1d(close): return -close.pct_change(1)
def rev_3d(close): return -close.pct_change(3)
def rev_5d(close): return -close.pct_change(5)
def rev_10d(close): return -close.pct_change(10)
def rev_21d(close): return -close.pct_change(21)
def rev_63d(close): return -close.pct_change(63)


# ═══════════════════════════════════════════════════════════════════════════════
# VOLATILITY (10 factors)
# ═══════════════════════════════════════════════════════════════════════════════

def vol_21d(close):
    r = np.log(close / close.shift(1)); return r.rolling(21).std() * np.sqrt(252)
def vol_63d(close):
    r = np.log(close / close.shift(1)); return r.rolling(63).std() * np.sqrt(252)
def vol_126d(close):
    r = np.log(close / close.shift(1)); return r.rolling(126).std() * np.sqrt(252)
def vol_252d(close):
    r = np.log(close / close.shift(1)); return r.rolling(252).std() * np.sqrt(252)
def vol_of_vol_63(close):
    v = np.log(close / close.shift(1)).rolling(21).std()
    return v.rolling(63).std()
def vol_skew_63(close):
    r = np.log(close / close.shift(1)); return r.rolling(63).skew()
def vol_kurt_63(close):
    r = np.log(close / close.shift(1)); return r.rolling(63).kurt()
def vol_downside_63(close):
    r = np.log(close / close.shift(1)); return r.where(r < 0).rolling(63, min_periods=20).std() * np.sqrt(252)
def vol_upside_63(close):
    r = np.log(close / close.shift(1)); return r.where(r > 0).rolling(63, min_periods=20).std() * np.sqrt(252)
def vol_ratio_63(close):
    """Upside/downside volatility ratio."""
    r = np.log(close / close.shift(1))
    up = r.where(r > 0).rolling(63, min_periods=20).std()
    dn = r.where(r < 0).rolling(63, min_periods=20).std()
    return _safe_div(up, dn)


# ═══════════════════════════════════════════════════════════════════════════════
# VOLUME (10 factors)
# ═══════════════════════════════════════════════════════════════════════════════

def vol_surge_5(close, volume):
    """Volume surge: today vs 20d average."""
    if volume is None: return pd.Series(dtype=float)
    return volume / volume.rolling(20).mean().replace(0, np.nan)
def vol_trend_10(close, volume):
    if volume is None: return pd.Series(dtype=float)
    return volume.rolling(10).mean() / volume.rolling(60).mean().replace(0, np.nan) - 1
def vol_trend_20(close, volume):
    if volume is None: return pd.Series(dtype=float)
    return volume.rolling(20).mean() / volume.rolling(60).mean().replace(0, np.nan) - 1
def vol_relative_5(close, volume):
    if volume is None: return pd.Series(dtype=float)
    return volume / volume.rolling(60).mean().replace(0, np.nan)
def vol_momentum_21(close, volume):
    if volume is None: return pd.Series(dtype=float)
    return volume.pct_change(21)
def turnover_21(close, volume):
    """Turnover ratio: volume × close (proxy for rupee turnover)."""
    if volume is None: return pd.Series(dtype=float)
    return (volume * close).rolling(21).mean()
def amihud_21(close, volume):
    """Amihud illiquidity: |return| / turnover."""
    if volume is None: return pd.Series(dtype=float)
    ret = close.pct_change().abs()
    turn = (volume * close).replace(0, np.nan)
    return (ret / turn).rolling(21).mean()
def vol_skew_21(close, volume):
    if volume is None: return pd.Series(dtype=float)
    return volume.rolling(21).skew()
def vol_accel_10(close, volume):
    if volume is None: return pd.Series(dtype=float)
    return volume.pct_change(10) - volume.shift(10).pct_change(10)
def vol_ratio_5_21(close, volume):
    if volume is None: return pd.Series(dtype=float)
    return volume.rolling(5).mean() / volume.rolling(21).mean().replace(0, np.nan)


# ═══════════════════════════════════════════════════════════════════════════════
# TREND (10 factors)
# ═══════════════════════════════════════════════════════════════════════════════

def trend_ema_20(close): return close / close.ewm(span=20).mean() - 1
def trend_ema_50(close): return close / close.ewm(span=50).mean() - 1
def trend_ema_200(close): return close / close.ewm(span=200).mean() - 1
def trend_sma_20(close): return close / close.rolling(20).mean() - 1
def trend_sma_50(close): return close / close.rolling(50).mean() - 1
def trend_sma_200(close): return close / close.rolling(200).mean() - 1
def trend_slope_20(close):
    """Linear regression slope of last 20 days."""
    x = np.arange(20)
    def _slope(y):
        if len(y) < 20 or np.std(y) < 1e-9: return 0
        return np.polyfit(x, y, 1)[0]
    return close.rolling(20).apply(_slope, raw=True)
def trend_slope_50(close):
    x = np.arange(50)
    def _slope(y):
        if len(y) < 50 or np.std(y) < 1e-9: return 0
        return np.polyfit(x, y, 1)[0]
    return close.rolling(50).apply(_slope, raw=True)
def trend_r2_20(close):
    """R² of linear trend — how well does a line fit?"""
    x = np.arange(20)
    def _r2(y):
        if len(y) < 20 or np.std(y) < 1e-9: return 0
        p = np.polyfit(x, y, 1)
        pred = np.polyval(p, x)
        ss_res = np.sum((y - pred) ** 2)
        ss_tot = np.sum((y - np.mean(y)) ** 2)
        return 1 - ss_res / (ss_tot + 1e-9)
    return close.rolling(20).apply(_r2, raw=True)
def trend_consistency_20(close):
    """Fraction of up days in last 20."""
    return (close.pct_change(1) > 0).rolling(20).mean()


# ═══════════════════════════════════════════════════════════════════════════════
# MEAN REVERSION / OSCILLATORS (6 factors)
# ═══════════════════════════════════════════════════════════════════════════════

def rsi_7(close):
    delta = close.diff()
    gain = delta.clip(lower=0).ewm(alpha=1/7, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1/7, adjust=False).mean()
    return 100 - 100 / (1 + gain / (loss + 1e-9))
def rsi_14(close):
    delta = close.diff()
    gain = delta.clip(lower=0).ewm(alpha=1/14, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1/14, adjust=False).mean()
    return 100 - 100 / (1 + gain / (loss + 1e-9))
def rsi_21(close):
    delta = close.diff()
    gain = delta.clip(lower=0).ewm(alpha=1/21, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1/21, adjust=False).mean()
    return 100 - 100 / (1 + gain / (loss + 1e-9))
def rsi_28(close):
    delta = close.diff()
    gain = delta.clip(lower=0).ewm(alpha=1/28, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1/28, adjust=False).mean()
    return 100 - 100 / (1 + gain / (loss + 1e-9))
def bb_position_20(close):
    ma = close.rolling(20).mean(); std = close.rolling(20).std()
    return ((close - ma) / (2 * std.replace(0, np.nan))).clip(-1, 1)
def bb_width_20(close):
    """Bollinger Band width — volatility/squeeze indicator."""
    ma = close.rolling(20).mean(); std = close.rolling(20).std()
    return (4 * std / ma.replace(0, np.nan)).replace([np.inf, -np.inf], np.nan)


# ═══════════════════════════════════════════════════════════════════════════════
# PRICE PATTERNS (10 factors)
# ═══════════════════════════════════════════════════════════════════════════════

def breakout_252(close):
    if len(close) < 253: return pd.Series(dtype=float)
    return close / close.shift(1).rolling(252).max()
def breakout_126(close):
    if len(close) < 127: return pd.Series(dtype=float)
    return close / close.shift(1).rolling(126).max()
def breakout_63(close):
    if len(close) < 64: return pd.Series(dtype=float)
    return close / close.shift(1).rolling(63).max()
def drawdown_63(close):
    peak = close.rolling(63).max()
    return (close / peak - 1)
def drawdown_252(close):
    peak = close.rolling(252).max()
    return (close / peak - 1)
def range_position_21(close):
    """Where is price in its 21-day range? 0=bottom, 1=top."""
    lo = close.rolling(21).min(); hi = close.rolling(21).max()
    return (close - lo) / (hi - lo).replace(0, np.nan)
def range_position_63(close):
    lo = close.rolling(63).min(); hi = close.rolling(63).max()
    return (close - lo) / (hi - lo).replace(0, np.nan)
def gap_overnight(close, open_col=None):
    """Overnight gap: open/prev_close - 1."""
    if open_col is None: return pd.Series(dtype=float)
    return (open_col / close.shift(1) - 1).replace([np.inf, -np.inf], np.nan)
def intraday_return(close, open_col=None):
    """Intraday return: close/open - 1."""
    if open_col is None: return pd.Series(dtype=float)
    return (close / open_col - 1).replace([np.inf, -np.inf], np.nan)
def true_range_pct(close, high=None, low=None):
    """ATR as % of price."""
    if high is None or low is None: return pd.Series(dtype=float)
    tr = pd.DataFrame({"hl": high - low, "hc": (high - close.shift(1)).abs(),
                       "lc": (low - close.shift(1)).abs()}).max(axis=1)
    return (tr.ewm(alpha=1/14, adjust=False).mean() / close.replace(0, np.nan) * 100)


# ═══════════════════════════════════════════════════════════════════════════════
# LIQUIDITY (6 factors)
# ═══════════════════════════════════════════════════════════════════════════════

def adv_21d(close, volume):
    if volume is None: return pd.Series(dtype=float)
    return (volume.rolling(21).mean() * close)
def adv_63d(close, volume):
    if volume is None: return pd.Series(dtype=float)
    return (volume.rolling(63).mean() * close)
def amihud_63(close, volume):
    if volume is None: return pd.Series(dtype=float)
    ret = close.pct_change().abs()
    turn = (volume * close).replace(0, np.nan)
    return (ret / turn).rolling(63).mean()
def turnover_ratio_21(close, volume):
    """Turnover relative to 252d average."""
    if volume is None: return pd.Series(dtype=float)
    turn = volume * close
    return turn / turn.rolling(252).mean().replace(0, np.nan)
def zero_return_freq_21(close):
    """Frequency of zero-return days (illiquidity proxy)."""
    r = close.pct_change(1)
    return (r.abs() < 1e-6).rolling(21).mean()
def price_impact_21(close, volume):
    """Price impact: |return| per unit volume."""
    if volume is None: return pd.Series(dtype=float)
    r = close.pct_change().abs()
    return (r / volume.replace(0, np.nan)).rolling(21).mean()


# ═══════════════════════════════════════════════════════════════════════════════
# HIGHER MOMENTS (6 factors)
# ═══════════════════════════════════════════════════════════════════════════════

def ret_skew_21(close):
    return np.log(close / close.shift(1)).rolling(21).skew()
def ret_skew_63(close):
    return np.log(close / close.shift(1)).rolling(63).skew()
def ret_skew_126(close):
    return np.log(close / close.shift(1)).rolling(126).skew()
def ret_kurt_21(close):
    return np.log(close / close.shift(1)).rolling(21).kurt()
def ret_kurt_63(close):
    return np.log(close / close.shift(1)).rolling(63).kurt()
def ret_kurt_126(close):
    return np.log(close / close.shift(1)).rolling(126).kurt()


# ═══════════════════════════════════════════════════════════════════════════════
# MACD / MOVING AVERAGE CROSSOVERS (6 factors)
# ═══════════════════════════════════════════════════════════════════════════════

def macd_hist(close):
    ema12 = close.ewm(span=12, adjust=False).mean()
    ema26 = close.ewm(span=26, adjust=False).mean()
    macd = ema12 - ema26
    signal = macd.ewm(span=9, adjust=False).mean()
    return (macd - signal) / close.replace(0, np.nan) * 100
def macd_signal(close):
    ema12 = close.ewm(span=12, adjust=False).mean()
    ema26 = close.ewm(span=26, adjust=False).mean()
    macd = ema12 - ema26
    return macd.ewm(span=9, adjust=False).mean() / close.replace(0, np.nan) * 100
def ema_cross_5_20(close):
    return close.ewm(span=5).mean() / close.ewm(span=20).mean().replace(0, np.nan) - 1
def ema_cross_10_50(close):
    return close.ewm(span=10).mean() / close.ewm(span=50).mean().replace(0, np.nan) - 1
def sma_cross_5_20(close):
    return close.rolling(5).mean() / close.rolling(20).mean().replace(0, np.nan) - 1
def sma_cross_10_50(close):
    return close.rolling(10).mean() / close.rolling(50).mean().replace(0, np.nan) - 1


# ═══════════════════════════════════════════════════════════════════════════════
# VWAP / PRICE-VOLUME (6 factors)
# ═══════════════════════════════════════════════════════════════════════════════

def vwap_dist_21(close, high=None, low=None, volume=None):
    if high is None or low is None or volume is None: return pd.Series(dtype=float)
    typical = (high + low + close) / 3
    vwap = (typical * volume).rolling(21).sum() / volume.rolling(21).sum().replace(0, np.nan)
    return (close / vwap - 1) * 100
def vwap_dist_63(close, high=None, low=None, volume=None):
    if high is None or low is None or volume is None: return pd.Series(dtype=float)
    typical = (high + low + close) / 3
    vwap = (typical * volume).rolling(63).sum() / volume.rolling(63).sum().replace(0, np.nan)
    return (close / vwap - 1) * 100
def pv_trend_21(close, volume):
    """Price-volume trend: sum of (return × volume)."""
    if volume is None: return pd.Series(dtype=float)
    return (close.pct_change() * volume).rolling(21).sum()
def obv_slope_21(close, volume):
    """OBV slope — cumulative volume on up days minus down days."""
    if volume is None: return pd.Series(dtype=float)
    direction = np.sign(close.pct_change())
    obv = (direction * volume).cumsum()
    return obv.pct_change(21)
def money_flow_21(close, high=None, low=None, volume=None):
    """Money flow ratio."""
    if high is None or low is None or volume is None: return pd.Series(dtype=float)
    typical = (high + low + close) / 3
    mf = typical * volume
    pos_mf = mf.where(typical > typical.shift(1), 0).rolling(21).sum()
    neg_mf = mf.where(typical < typical.shift(1), 0).rolling(21).sum()
    return pos_mf / neg_mf.replace(0, np.nan)
def cmf_21(close, high=None, low=None, volume=None):
    """Chaikin Money Flow."""
    if high is None or low is None or volume is None: return pd.Series(dtype=float)
    mfm = ((close - low) - (high - close)) / (high - low).replace(0, np.nan)
    return (mfm * volume).rolling(21).sum() / volume.rolling(21).sum().replace(0, np.nan)


# ═══════════════════════════════════════════════════════════════════════════════
# FRACTIONAL DIFFERENTIATION (3 factors)
# ═══════════════════════════════════════════════════════════════════════════════

def frac_diff_03(close):
    """Fractional differentiation d=0.3 — more memory than d=1."""
    d = 0.3; weights = [1.0]; k = 1
    while True:
        w = -weights[-1] * (d - k + 1) / k
        if abs(w) < 1e-5: break
        weights.append(w); k += 1
    weights = np.array(weights[::-1])
    return close.rolling(len(weights)).apply(lambda x: np.dot(weights, x), raw=True)

def frac_diff_05(close):
    d = 0.5; weights = [1.0]; k = 1
    while True:
        w = -weights[-1] * (d - k + 1) / k
        if abs(w) < 1e-5: break
        weights.append(w); k += 1
    weights = np.array(weights[::-1])
    return close.rolling(len(weights)).apply(lambda x: np.dot(weights, x), raw=True)

def frac_diff_07(close):
    d = 0.7; weights = [1.0]; k = 1
    while True:
        w = -weights[-1] * (d - k + 1) / k
        if abs(w) < 1e-5: break
        weights.append(w); k += 1
    weights = np.array(weights[::-1])
    return close.rolling(len(weights)).apply(lambda x: np.dot(weights, x), raw=True)


# ═══════════════════════════════════════════════════════════════════════════════
# FACTOR REGISTRY — all 91 base factors
# ═══════════════════════════════════════════════════════════════════════════════

ALL_FACTORS_100 = {
    # Momentum (12)
    "mom_1d": mom_1d, "mom_5d": mom_5d, "mom_21d": mom_21d,
    "mom_63d": mom_63d, "mom_126d": mom_126d, "mom_252d": mom_252d,
    "mom_skip1_21": mom_skip1_21, "mom_skip5_63": mom_skip5_63,
    "mom_skip21_252": mom_skip21_252, "mom_accel_21": mom_accel_21,
    "mom_accel_63": mom_accel_63, "mom_decel_21": mom_decel_21,
    # Reversal (6)
    "rev_1d": rev_1d, "rev_3d": rev_3d, "rev_5d": rev_5d,
    "rev_10d": rev_10d, "rev_21d": rev_21d, "rev_63d": rev_63d,
    # Volatility (10)
    "vol_21d": vol_21d, "vol_63d": vol_63d, "vol_126d": vol_126d, "vol_252d": vol_252d,
    "vol_of_vol_63": vol_of_vol_63, "vol_skew_63": vol_skew_63, "vol_kurt_63": vol_kurt_63,
    "vol_downside_63": vol_downside_63, "vol_upside_63": vol_upside_63,
    "vol_ratio_63": vol_ratio_63,
    # Volume (10)
    "vol_surge_5": vol_surge_5, "vol_trend_10": vol_trend_10, "vol_trend_20": vol_trend_20,
    "vol_relative_5": vol_relative_5, "vol_momentum_21": vol_momentum_21,
    "turnover_21": turnover_21, "amihud_21": amihud_21,
    "vol_skew_21": vol_skew_21, "vol_accel_10": vol_accel_10, "vol_ratio_5_21": vol_ratio_5_21,
    # Trend (10)
    "trend_ema_20": trend_ema_20, "trend_ema_50": trend_ema_50, "trend_ema_200": trend_ema_200,
    "trend_sma_20": trend_sma_20, "trend_sma_50": trend_sma_50, "trend_sma_200": trend_sma_200,
    "trend_slope_20": trend_slope_20, "trend_slope_50": trend_slope_50,
    "trend_r2_20": trend_r2_20, "trend_consistency_20": trend_consistency_20,
    # Mean Reversion (6)
    "rsi_7": rsi_7, "rsi_14": rsi_14, "rsi_21": rsi_21, "rsi_28": rsi_28,
    "bb_position_20": bb_position_20, "bb_width_20": bb_width_20,
    # Price Patterns (10)
    "breakout_252": breakout_252, "breakout_126": breakout_126, "breakout_63": breakout_63,
    "drawdown_63": drawdown_63, "drawdown_252": drawdown_252,
    "range_position_21": range_position_21, "range_position_63": range_position_63,
    "gap_overnight": gap_overnight, "intraday_return": intraday_return,
    "true_range_pct": true_range_pct,
    # Liquidity (6)
    "adv_21d": adv_21d, "adv_63d": adv_63d, "amihud_63": amihud_63,
    "turnover_ratio_21": turnover_ratio_21, "zero_return_freq_21": zero_return_freq_21,
    "price_impact_21": price_impact_21,
    # Higher Moments (6)
    "ret_skew_21": ret_skew_21, "ret_skew_63": ret_skew_63, "ret_skew_126": ret_skew_126,
    "ret_kurt_21": ret_kurt_21, "ret_kurt_63": ret_kurt_63, "ret_kurt_126": ret_kurt_126,
    # MACD/Crossovers (6)
    "macd_hist": macd_hist, "macd_signal": macd_signal,
    "ema_cross_5_20": ema_cross_5_20, "ema_cross_10_50": ema_cross_10_50,
    "sma_cross_5_20": sma_cross_5_20, "sma_cross_10_50": sma_cross_10_50,
    # VWAP/Price-Volume (6)
    "vwap_dist_21": vwap_dist_21, "vwap_dist_63": vwap_dist_63,
    "pv_trend_21": pv_trend_21, "obv_slope_21": obv_slope_21,
    "money_flow_21": money_flow_21, "cmf_21": cmf_21,
    # Fractional Diff (3)
    "frac_diff_03": frac_diff_03, "frac_diff_05": frac_diff_05, "frac_diff_07": frac_diff_07,
}

FACTORS_100 = ALL_FACTORS_100


def compute_cross_section_rank_zscore(df_panel: pd.DataFrame, factor_col: str, group_col: str = "date") -> pd.Series:
    """
    [FIX 1] Computes Daily Cross-Sectional Percentile Rank & Robust Z-score across all tickers.
    Ensures factor selection ranks the top 6 stocks against the entire 500-stock universe.
    """
    if df_panel is None or df_panel.empty or factor_col not in df_panel.columns:
        return pd.Series(dtype=float)
    try:
        if group_col in df_panel.columns:
            ranks = df_panel.groupby(group_col)[factor_col].rank(pct=True)
            # AUDIT-FIX (Round 13, ML-9): the z-score was computed against
            # the FULL-SAMPLE rank mean/std — a full-sample normalization
            # (every date's factor value is scaled by statistics that
            # include all future dates). Rank per date, then z-score per
            # date via groupby-transform so only same-date cross-sectional
            # information enters the scaling.
            grp = ranks.groupby(df_panel[group_col])
            z = (ranks - grp.transform("mean")) / (grp.transform("std") + 1e-9)
        else:
            ranks = df_panel[factor_col].rank(pct=True)
            z = (ranks - ranks.mean()) / (ranks.std() + 1e-9)
        return z.clip(-3.0, 3.0)
    except Exception:
        return pd.Series(0.0, index=df_panel.index)
