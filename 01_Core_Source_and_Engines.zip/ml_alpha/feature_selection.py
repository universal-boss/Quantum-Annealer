"""Feature selection — IC-based + Lasso filtering.

Removes noise factors that have no predictive power, keeping only the ones
with statistically significant Information Coefficient (IC).

Two-stage filter:
  1. IC filter: Drop factors with |mean IC| < threshold (default 0.02)
  2. Lasso filter: Drop factors with zero Lasso coefficient (L1 regularization)

This typically reduces 26 factors → 8-12 useful factors, dramatically reducing
overfitting and improving out-of-sample Sharpe.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Optional


def compute_factor_ic(
    factor_panel: pd.DataFrame,
    forward_returns: pd.Series,
    min_periods: int = 30,
) -> pd.Series:
    """Compute Spearman rank IC for a factor panel vs forward returns.

    IC is computed cross-sectionally at each date, then averaged.

    Args:
        factor_panel: DataFrame[date × ticker] of factor values.
        forward_returns: Series indexed by (date, ticker) with forward returns.
        min_periods: Minimum number of valid cross-sectional observations
                     required to compute IC at a given date.

    Returns:
        Series of daily IC values (indexed by date).
    """
    from scipy.stats import spearmanr

    # Stack factor panel to (date, ticker) index
    factor_stacked = factor_panel.stack()
    factor_stacked.name = "factor"

    # Align with forward returns
    df = pd.DataFrame({"factor": factor_stacked, "ret": forward_returns})
    df = df.dropna()

    if len(df) == 0:
        return pd.Series(dtype=float)

    # Group by date (level 0) and compute Spearman IC
    ics = []
    for date, group in df.groupby(level=0):
        if len(group) < min_periods:
            continue
        if group["factor"].std() < 1e-12 or group["ret"].std() < 1e-12:
            continue
        try:
            ic, _ = spearmanr(group["factor"], group["ret"])
            if np.isfinite(ic):
                ics.append((date, ic))
        except Exception:
            import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
            continue

    if not ics:
        return pd.Series(dtype=float)

    return pd.Series(dict(ics))


def select_factors_by_ic(
    factor_panels: dict[str, pd.DataFrame],
    forward_returns: pd.Series,
    ic_threshold: float = 0.02,
    min_periods: int = 30,
) -> list[str]:
    """Select factors with statistically significant mean IC.

    Args:
        factor_panels: Dict[factor_name → DataFrame[date × ticker]].
        forward_returns: Series indexed by (date, ticker).
        ic_threshold: Minimum |mean IC| to keep a factor (default 0.02).
        min_periods: Min observations per date for IC computation.

    Returns:
        List of selected factor names.
    """
    selected = []
    ic_stats = {}

    for fname, panel in factor_panels.items():
        ics = compute_factor_ic(panel, forward_returns, min_periods)
        if len(ics) == 0:
            ic_stats[fname] = {"mean_ic": 0.0, "ic_std": 0.0, "ir": 0.0}
            continue

        mean_ic = float(ics.mean())
        ic_std = float(ics.std())
        # Information Ratio = mean IC / std IC (annualized)
        ir = mean_ic / (ic_std + 1e-9) if ic_std > 1e-9 else 0.0

        ic_stats[fname] = {"mean_ic": mean_ic, "ic_std": ic_std, "ir": ir}

        # Keep factor if |mean IC| exceeds threshold AND has non-negligible Information Ratio (IR >= 0.05)
        # Allows robust momentum, reversal, and trend factors to pass to the Lasso selection stage
        if abs(mean_ic) >= ic_threshold and abs(ir) >= 0.05:
            selected.append(fname)

    # Fallback: if fewer than 12 factors selected, include top factors by |mean IC|
    if len(selected) < 12 and ic_stats:
        ranked = sorted(ic_stats.items(), key=lambda x: -abs(x[1].get("mean_ic", 0.0)))
        for fname, s in ranked:
            if fname not in selected and abs(s.get("mean_ic", 0.0)) >= (ic_threshold * 0.5):
                selected.append(fname)
            if len(selected) >= 15:
                break

    return selected, ic_stats


def select_factors_by_lasso(
    X: pd.DataFrame,
    y: pd.Series,
    n_folds: int = 5,
    min_features: int = 5,
    label_gap: int = 5,
) -> list[str]:
    """Select factors using L1-regularized Lasso CV.

    Lasso drives irrelevant feature coefficients to exactly zero, providing
    a principled feature selection method.

    Args:
        X: Feature matrix (observations × features).
        y: Target variable.
        n_folds: CV folds for Lasso path.
        min_features: Minimum number of features to keep (fallback).
        label_gap: Forward-return horizon (rows) — used as the TimeSeriesSplit
            `gap` so validation windows never overlap the training tail's
            forward-looking labels.

    Returns:
        List of selected feature names.
    """
    try:
        from sklearn.linear_model import LassoCV
        from sklearn.model_selection import TimeSeriesSplit
    except ImportError:
        return list(X.columns)

    # Clean data
    mask = ~np.isnan(y.to_numpy(dtype=float))
    X_clean = X.loc[mask].fillna(0.0)
    y_clean = y.loc[mask]

    if len(X_clean) < 100 or len(X_clean.columns) < 2:
        return list(X.columns)

    try:
        # Fit Lasso with TEMPORAL CV to find optimal alpha.
        # CRITICAL FIX: Use TimeSeriesSplit instead of default K-Fold.
        # K-Fold shuffles/slices data out of order — validation samples end up
        # chronologically *before* some training samples, leaking forward returns
        # from the future into the feature-selection step. This makes Lasso pick
        # "features" that only appear predictive because they correlate with the
        # leaked future. TimeSeriesSplit ensures each validation window is always
        # strictly after its corresponding training window (no time-travel).
        lasso = LassoCV(
            # AUDIT-FIX (Round 13, ML-8): add `gap=label_gap` — the train
            # tail's h-day forward labels overlap the validation head of
            # the NEXT split; without the gap, LassoCV's alpha path is
            # chosen on label overlap (selection leakage).
            cv=TimeSeriesSplit(n_splits=n_folds, gap=max(0, int(label_gap))),
            n_alphas=50,
            max_iter=5000,
            random_state=42,
        )
        lasso.fit(X_clean.to_numpy(dtype=float), y_clean.to_numpy(dtype=float))

        # Select features with non-zero coefficients
        selected = [
            col for col, coef in zip(X_clean.columns, lasso.coef_)
            if abs(coef) > 1e-8
        ]

        # Fallback: if Lasso killed too many features, keep top-K by |coef|
        if len(selected) < min_features:
            coefs = [(col, abs(coef)) for col, coef in zip(X_clean.columns, lasso.coef_)]
            coefs.sort(key=lambda x: -x[1])
            selected = [col for col, _ in coefs[:min_features]]

        return selected if selected else list(X.columns)
    except Exception:
        return list(X.columns)


def select_factors(
    factor_panels: dict[str, pd.DataFrame],
    forward_returns: pd.Series,
    X: pd.DataFrame,
    y: pd.Series,
    ic_threshold: float = 0.02,
    min_features: int = 5,
    label_horizon: int = 5,
) -> tuple[list[str], dict]:
    """Two-stage feature selection: IC filter + Lasso filter.

    Stage 1: Drop factors with |mean IC| < threshold (fast, cross-sectional)
    Stage 2: Drop factors with zero Lasso coefficient (L1 regularization)

    Args:
        factor_panels: Dict[factor_name → DataFrame] for IC computation.
        forward_returns: Series for IC computation.
        X: Feature matrix for Lasso.
        y: Target for Lasso.
        ic_threshold: Min |mean IC| to survive stage 1.
        min_features: Min features to keep (fallback).
        label_horizon: Forward-return horizon in rows — becomes the LassoCV
            TimeSeriesSplit gap (label-overlap purge).

    Returns:
        (selected_factor_names, ic_stats_dict)
    """
    # Stage 1: IC filter
    ic_selected, ic_stats = select_factors_by_ic(
        factor_panels, forward_returns, ic_threshold=ic_threshold
    )

    # If IC filter killed everything (common on first run with noisy data),
    # skip Lasso and use all factors
    if len(ic_selected) < min_features:
        return list(factor_panels.keys()), ic_stats

    # Stage 2: Lasso filter (only on IC-surviving factors)
    X_subset = X[ic_selected] if all(f in X.columns for f in ic_selected) else X
    lasso_selected = select_factors_by_lasso(
        X_subset, y, min_features=min_features, label_gap=label_horizon
    )

    # Intersection of both filters
    final = [f for f in ic_selected if f in lasso_selected]

    # Fallback: if intersection is too small, use IC-selected only
    if len(final) < min_features:
        final = ic_selected

    return final, ic_stats
