"""Feature store — cached factor computation with point-in-time correctness.

Caches computed factors to disk so subsequent ML fits skip the expensive
factor computation step. All cached features are point-in-time correct
(no lookahead bias).

Features:
  1. Disk-based caching (Parquet format for efficiency)
  2. Point-in-time retrieval (no future data leakage)
  3. Incremental updates (only compute new dates)
  4. Versioning (track factor definition changes)
"""
from __future__ import annotations

import hashlib
import json
import logging
from pathlib import Path
from typing import Optional
import pandas as pd
import numpy as np

logger = logging.getLogger(__name__)

CACHE_DIR = Path(__file__).parent.parent / "models" / "feature_cache"


class FeatureStore:
    """Disk-based feature store with point-in-time correctness.

    Usage:
        store = FeatureStore()
        store.save("momentum_12_1", factor_df, version="v2")
        cached = store.load("momentum_12_1", as_of="2024-01-15", version="v2")
    """

    def __init__(self, cache_dir: Optional[Path] = None):
        self.cache_dir = cache_dir or CACHE_DIR
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    # R36-5 NOTE (mechanism decision): the R34-12 "__getstate__ never persists
    # cache_dir" approach is deliberately NOT restored. The Round 36 upload
    # replaced it with a __setstate__-only re-anchor, and that choice is KEPT
    # because it satisfies every behavioral portability contract while also
    # preserving a deliberately-custom cache_dir that still exists locally
    # (locked by test_round36_regressions.py::test_r34_7_unpickled_store_
    # keeps_valid_local_path): a pickled store whose cache_dir is dead on this
    # host re-anchors to THIS repository's models/feature_cache; one whose
    # path is alive is honored verbatim. The original R34-12 incident (a
    # pickled engine whose store pointed at the training machine's absolute
    # path predicting 0 rows everywhere else) remains impossible — the dead
    # path can never survive __setstate__.
    #
    # R34-7 FIX (portability, retained from Round 36): pickled AlphaEngine
    # objects (the lean models/ml_alpha_model.pkl) carry a FeatureStore
    # instance whose cache_dir may be the TRAINING machine's absolute path
    # (e.g. /Users/deepak/Desktop/Quantum Annealer/models/feature_cache). On
    # any other machine — or any other directory on the same machine — every
    # fs.load() silently missed, predict() got zero panels, and the model
    # returned 0 predictions. Re-anchor any unpickled store to THIS
    # repository's models/feature_cache when the pickled path does not exist
    # locally.
    def __setstate__(self, state):
        cache_dir = state.get("cache_dir")
        if cache_dir is None or not Path(cache_dir).exists():
            state["cache_dir"] = Path(CACHE_DIR)
            try:
                Path(CACHE_DIR).mkdir(parents=True, exist_ok=True)
                logger.info(
                    "[FeatureStore] Re-anchored unpickled cache_dir %s → %s "
                    "(original path does not exist on this host)", cache_dir, CACHE_DIR)
            except Exception as e:
                logger.warning("[FeatureStore] Re-anchor mkdir failed: %s", e)
        self.__dict__.update(state)

    def _cache_key(
        self,
        factor_name: str,
        version: str = "v1",
        start: Optional[str] = None,
        end: Optional[str] = None,
    ) -> Path:
        """Generate cache file path for a factor."""
        # Include date range in hash so different ranges are cached separately
        range_str = f"{start or 'all'}_{end or 'all'}"
        key_str = f"{factor_name}_{version}_{range_str}"
        key_hash = hashlib.md5(key_str.encode()).hexdigest()[:12]
        return self.cache_dir / f"{factor_name}_{version}_{key_hash}.parquet"

    def save(
        self,
        factor_name: str,
        data: pd.DataFrame,
        version: str = "v1",
        start: Optional[str] = None,
        end: Optional[str] = None,
    ) -> bool:
        """Save a factor panel to cache.

        Args:
            factor_name: Name of the factor (e.g., "momentum_12_1").
            data: DataFrame[date × ticker] of factor values.
            version: Factor definition version (bump when formula changes).
            start: Start date of the data.
            end: End date of the data.

        Returns:
            True if saved successfully.
        """
        cache_path = self._cache_key(factor_name, version, start, end)
        try:
            data.to_parquet(cache_path)
            # Also save metadata, preserving historical recipe provenance notes
            meta_path = cache_path.with_suffix(".meta.json")
            existing_regen = False
            if meta_path.exists():
                try:
                    old_meta = json.loads(meta_path.read_text(encoding="utf-8"))
                    existing_regen = bool(old_meta.get("regenerated", False))
                except Exception:
                    pass
            meta = {
                "factor_name": factor_name,
                "version": version,
                "start": start,
                "end": end,
                "n_dates": len(data),
                "n_tickers": len(data.columns),
                "saved_at": pd.Timestamp.now().isoformat(),
            }
            if existing_regen:
                meta["regenerated"] = True
                meta["recipe_note"] = "R34-12b regenerated panel (winsorize 1/99 + robust z ±3.5)"
            meta_path.write_text(json.dumps(meta, indent=2))
            logger.debug(f"[FeatureStore] Saved {factor_name} v{version} ({len(data)} dates)")
            return True
        except Exception as e:
            logger.warning(f"[FeatureStore] Save failed for {factor_name}: {e}", exc_info=True)
            return False

    def load(
        self,
        factor_name: str,
        as_of: Optional[str] = None,
        version: str = "v1",
        start: Optional[str] = None,
        end: Optional[str] = None,
    ) -> Optional[pd.DataFrame]:
        """Load a factor panel from cache.

        Args:
            factor_name: Name of the factor.
            as_of: Point-in-time cutoff — only return data up to this date.
            version: Factor version.
            start: Start date of cached data.
            end: End date of cached data.

        Returns:
            DataFrame[date × ticker] or None if not cached.
        """
        cache_path = self._cache_key(factor_name, version, start, end)
        if not cache_path.exists():
            # R34-7 FIX (glob fallback, hardened in R36-5): save() embeds the
            # (start, end) range in the filename hash, but callers frequently
            # load() with no range — computing a different hash and missing
            # files that exist. On an exact-key miss, fall back to the
            # {factor}_{version}_*.parquet files in the cache dir and apply
            # the point-in-time filter. R36-5 hardening: when the caller
            # requested an explicit range, only candidates whose sidecar meta
            # COVERS that range qualify (newest first); a range-blind pick
            # could silently serve a different data window than requested.
            _candidates = sorted(
                self.cache_dir.glob(f"{factor_name}_{version}_*.parquet"),
                key=lambda p: p.stat().st_mtime,
                reverse=True,
            )
            if start is not None or end is not None:
                _rng_ok = []
                for _cand in _candidates:
                    try:
                        _meta = json.loads(
                            _cand.with_suffix(".meta.json").read_text()
                        ) if _cand.with_suffix(".meta.json").exists() else {}
                    except Exception:
                        _meta = {}
                    _ms, _me = _meta.get("start"), _meta.get("end")
                    # A missing sidecar range is treated as unbounded only
                    # when no explicit range can be checked against it.
                    if _ms is None and _me is None:
                        continue
                    if _ms is not None and end is not None and str(_ms) > str(end):
                        continue
                    if _me is not None and start is not None and str(_me) < str(start):
                        continue
                    _rng_ok.append(_cand)
                _candidates = _rng_ok
            if not _candidates:
                return None
            cache_path = _candidates[0]
            if len(_candidates) > 1 or cache_path != self._cache_key(factor_name, version, start, end):
                logger.debug(
                    "[FeatureStore] load(%s v%s): exact range key missed — using "
                    "fallback panel %s (requested range start=%s end=%s)",
                    factor_name, version, cache_path.name, start, end)

        try:
            data = pd.read_parquet(cache_path)
            # Point-in-time filter: only return data up to `as_of`
            if as_of:
                as_of_ts = pd.Timestamp(as_of)
                data = data[data.index <= as_of_ts]
            logger.debug(f"[FeatureStore] Loaded {factor_name} v{version} ({len(data)} dates)")
            return data
        except Exception as e:
            logger.warning(f"[FeatureStore] Load failed for {factor_name}: {e}", exc_info=True)
            return None

    def invalidate(self, factor_name: str, version: str = "v1"):
        """Invalidate cached factor data."""
        for cache_file in self.cache_dir.glob(f"{factor_name}_{version}_*.parquet"):
            cache_file.unlink()
            meta = cache_file.with_suffix(".meta.json")
            if meta.exists():
                meta.unlink()
        logger.info(f"[FeatureStore] Invalidated {factor_name} v{version}")

    def clear_all(self):
        """Clear all cached features."""
        for f in self.cache_dir.glob("*.parquet"):
            f.unlink()
        for f in self.cache_dir.glob("*.meta.json"):
            f.unlink()
        logger.info("[FeatureStore] Cleared all cached features")

    def list_cached(self) -> list[dict]:
        """List all cached factors with metadata."""
        result = []
        for meta_file in self.cache_dir.glob("*.meta.json"):
            try:
                meta = json.loads(meta_file.read_text())
                result.append(meta)
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                continue
        return result


# ═══════════════════════════════════════════════════════════════════════════════
# EXPERIMENT TRACKING
# ═══════════════════════════════════════════════════════════════════════════════

EXPERIMENTS_DIR = Path(__file__).parent.parent / "models" / "experiments"


class ExperimentTracker:
    """Track ML experiments — parameters, metrics, model artifacts.

    Lightweight alternative to MLflow. Stores experiment results as JSON
    files for easy comparison and auditing.
    """

    def __init__(self, experiments_dir: Optional[Path] = None):
        self.experiments_dir = experiments_dir or EXPERIMENTS_DIR
        self.experiments_dir.mkdir(parents=True, exist_ok=True)

    def log_experiment(
        self,
        run_id: str,
        params: dict,
        metrics: dict,
        feature_importance: Optional[dict] = None,
        notes: str = "",
    ) -> bool:
        """Log an experiment run.

        Args:
            run_id: Unique run identifier.
            params: Hyperparameters and configuration.
            metrics: Performance metrics (DSR, OOS Sharpe, etc.).
            feature_importance: Optional feature importance dict.
            notes: Free-text notes.
        """
        exp_path = self.experiments_dir / f"{run_id}.json"
        experiment = {
            "run_id": run_id,
            "timestamp": pd.Timestamp.now().isoformat(),
            "params": params,
            "metrics": metrics,
            "feature_importance": feature_importance or {},
            "notes": notes,
        }
        try:
            exp_path.write_text(json.dumps(experiment, indent=2, default=str))
            logger.info(f"[ExperimentTracker] Logged experiment {run_id}")
            return True
        except Exception as e:
            logger.warning(f"[ExperimentTracker] Log failed: {e}", exc_info=True)
            return False

    def list_experiments(self) -> list[dict]:
        """List all experiments."""
        experiments = []
        for exp_file in self.experiments_dir.glob("*.json"):
            try:
                exp = json.loads(exp_file.read_text())
                experiments.append(exp)
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                continue
        # Sort by timestamp (most recent first)
        experiments.sort(key=lambda x: x.get("timestamp", ""), reverse=True)
        return experiments

    def compare_experiments(self, run_ids: list[str]) -> pd.DataFrame:
        """Compare metrics across multiple experiments.

        Args:
            run_ids: List of run IDs to compare.

        Returns:
            DataFrame with metrics for each run.
        """
        rows = []
        for run_id in run_ids:
            exp_path = self.experiments_dir / f"{run_id}.json"
            if not exp_path.exists():
                continue
            try:
                exp = json.loads(exp_path.read_text())
                row = {"run_id": run_id, "timestamp": exp.get("timestamp", "")}
                row.update(exp.get("metrics", {}))
                row.update(exp.get("params", {}))
                rows.append(row)
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                continue

        if not rows:
            return pd.DataFrame()

        return pd.DataFrame(rows).set_index("run_id")

    def get_best_experiment(
        self,
        metric: str = "deflated_sharpe",
        higher_is_better: bool = True,
    ) -> Optional[dict]:
        """Get the best experiment by a given metric.

        Args:
            metric: Metric name to compare.
            higher_is_better: If True, higher metric = better.

        Returns:
            Best experiment dict, or None if no experiments.
        """
        experiments = self.list_experiments()
        if not experiments:
            return None

        # Filter experiments that have the metric
        with_metric = [
            e for e in experiments
            if metric in e.get("metrics", {})
        ]

        if not with_metric:
            return None

        # Sort by metric
        with_metric.sort(
            key=lambda x: x["metrics"][metric],
            reverse=higher_is_better
        )

        return with_metric[0]
