"""
ml_alpha/gnn_spillover.py
=========================
Graph Neural Network (GCN/GAT) Industry Supply-Chain & Thematic Spillover Engine.

Models structural supply-chain dependencies, customer-supplier links, and cross-stock
lead-lag momentum propagation for Indian Equities (NSE/BSE).
"""
from __future__ import annotations
import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, List, Optional, Tuple

logger = logging.getLogger(__name__)

# Master Canonical Thematic & Supply-Chain Graph for Indian Equities
# Nodes: Upstream Drivers / Macro Megatrends -> Downstream NSE Listed Beneficiaries
CANONICAL_SUPPLY_CHAIN_EDGES = {
    # ── AI Compute & Sovereign Cloud Theme ─────────────────────────────────
    "GLOBAL_AI_SERVERS": [("NETWEB", 0.95), ("OFSS", 0.45)],
    "SEMICONDUCTOR_EQUIP": [("NETWEB", 0.85), ("SBCL", 0.70)],
    
    # ── Defense Indigenization & Aerospace Theme ────────────────────────────
    "DEFENSE_RADAR_MOD": [("ASTRAMICRO", 0.95)],
    "INDIGENOUS_AIRCRAFT": [("ASTRAMICRO", 0.88), ("APARINDS", 0.40)],
    
    # ── EV Battery & Advanced Materials Theme ──────────────────────────────
    "LITHIUM_ION_GIGAFACTORIES": [("HSCL", 0.92), ("SBCL", 0.82)],
    "AUTOMOTIVE_ELECTRIFICATION": [("DIVGIITTS", 0.85), ("SBCL", 0.78), ("HSCL", 0.65)],
    
    # ── Healthcare, GLP-1 & CDMO Supercycle ────────────────────────────────
    "GLP1_OBESITY_DRUGS": [("SHAILY", 0.95)],
    "STERILE_INJECTABLES_RECOVERY": [("GLAND", 0.90)],
    "NOVEL_ANTIBIOTIC_NCE": [("WOCKPHARMA", 0.92), ("AARTIPHARM", 0.70)],
    
    # ── Power Grid Modernization & Data Center Infra ────────────────────────
    "GLOBAL_GRID_CAPEX": [("APARINDS", 0.94), ("KIRLOSENG", 0.60)],
    "DATA_CENTER_BACKUP_POWER": [("KIRLOSENG", 0.90), ("NETWEB", 0.50)],
    
    # ── Clean Energy Transition & Gas Logistics ────────────────────────────
    "CLEAN_FUEL_TRANSIT": [("CONFIPET", 0.90)],
    "DOMESTIC_REFINING_EXPANSION": [("CHENNPETRO", 0.88)],
    
    # ── Capital Markets Financialization ───────────────────────────────────
    "EQUITY_DERIVATIVES_SURGE": [("BSE", 0.92), ("63MOONS", 0.75)],

    # ── Automotive & Commercial Vehicles ───────────────────────────────────
    "COMMERCIAL_VEHICLE_ELECTRIFICATION": [("TMCV", 0.90), ("TATAMOTORS", 0.88), ("M&M", 0.75), ("HSCL", 0.55)],
    "DEFENSE_LOGISTICS_INDIGENISATION": [("TMCV", 0.85), ("TATAMOTORS", 0.82), ("ASTRAMICRO", 0.35)],
    "EV_PASSENGER_LUXURY": [("TMPV", 0.92), ("TATAMOTORS", 0.90), ("MARUTI", 0.80), ("M&M", 0.75)],
    "AUTOMOTIVE_EXPORT_MOMENTUM": [("MARUTI", 0.90), ("M&M", 0.85), ("TMPV", 0.82), ("TMCV", 0.78), ("TATAMOTORS", 0.80)]
}


class GNNIndustrySpilloverEngine:
    """
    Graph Neural Network Engine with Fused Supply-Chain & Empirical Lead-Lag Propagation.
    """

    def __init__(self, correlation_threshold: float = 0.35):
        self.correlation_threshold = correlation_threshold
        self.stock_list: list[str] = []
        self.structural_adj: np.ndarray | None = None
        self.empirical_adj: np.ndarray | None = None

    def build_supply_chain_matrix(self, stocks: list[str]) -> np.ndarray:
        """Constructs an adjacency matrix from canonical supply-chain and thematic linkages with corporate action resolution."""
        n = len(stocks)
        adj = np.zeros((n, n), dtype=float)
        stock_idx = {}
        for i, s in enumerate(stocks):
            raw = s.replace(".NS", "").replace(".BO", "").upper().strip()
            stock_idx[raw] = i

        try:
            from data.corporate_actions_registry import resolve_ticker
        except Exception:
            def resolve_ticker(x): return [x]

        for theme, targets in CANONICAL_SUPPLY_CHAIN_EDGES.items():
            resolved_targets = []
            for sym, w in targets:
                resolved_targets.append((sym, w))
                for r in resolve_ticker(sym):
                    if r != sym:
                        resolved_targets.append((r, w))

            for sym1, w1 in resolved_targets:
                if sym1 in stock_idx:
                    i = stock_idx[sym1]
                    for sym2, w2 in resolved_targets:
                        if sym2 in stock_idx and sym1 != sym2 and i != stock_idx[sym2]:
                            j = stock_idx[sym2]
                            adj[i, j] += w1 * w2 * 0.5

        # Normalize rows
        row_sums = adj.sum(axis=1, keepdims=True)
        row_sums[row_sums == 0] = 1.0
        return adj / row_sums

    def build_empirical_leadlag_matrix(self, returns_df: pd.DataFrame) -> np.ndarray:
        """Constructs adjacency matrix from cross-asset 1-day lagged cross-correlation."""
        if returns_df is None or returns_df.empty:
            return np.eye(max(len(self.stock_list), 1))

        clean_ret = returns_df.dropna(how="all").fillna(0.0)
        n = len(self.stock_list)
        adj = np.zeros((n, n), dtype=float)

        for i, s1 in enumerate(self.stock_list):
            if s1 not in clean_ret.columns:
                continue
            r1 = clean_ret[s1].values
            for j, s2 in enumerate(self.stock_list):
                if i == j or s2 not in clean_ret.columns:
                    continue
                r2 = clean_ret[s2].values
                # 1-day lead-lag correlation: corr(r1_{t-1}, r2_t)
                if len(r1) > 10:
                    c = np.corrcoef(r1[:-1], r2[1:])[0, 1]
                    if not np.isnan(c) and c > self.correlation_threshold:
                        adj[i, j] = c

        row_sums = adj.sum(axis=1, keepdims=True)
        row_sums[row_sums == 0] = 1.0
        return adj / row_sums

    def compute_gnn_spillover_alpha(
        self,
        stocks: list[str],
        returns_df: pd.DataFrame | None = None,
        base_momentum_scores: dict[str, float] | None = None
    ) -> dict[str, dict]:
        """
        Executes graph propagation over the fused Supply-Chain + Empirical graph:
        h^(1) = ReLU( D^-1 A_fused h^(0) · w1 )
        h^(2) = softplus( D^-1 A_fused h^(1) · w2 )

        AUDIT-FIX (Round 8, M10 — Part 2B): honesty note — this is an UNTRAINED
        graph-propagation heuristic, not a trained 2-layer GCN: the "weights"
        are fixed scalars (w1=1.2, w2=0.8, blend 0.50/0.35/0.15), not learned
        matrices, and the supply-chain edges are a hand-curated canonical map.
        The propagation itself is a defensible label-smoothing operator; treat
        the output as a relative screening signal, not a learned spillover
        prediction. Softplus is now overflow-stable (logaddexp).
        """
        self.stock_list = [s.replace(".NS", "").replace(".BO", "").upper() for s in stocks]
        n = len(self.stock_list)
        if n == 0:
            return {}

        # 1. Build Fused Graph Adjacency Matrix
        sc_adj = self.build_supply_chain_matrix(self.stock_list)
        emp_adj = np.eye(n)
        if returns_df is not None and not returns_df.empty:
            emp_adj = self.build_empirical_leadlag_matrix(returns_df)

        fused_adj = 0.65 * sc_adj + 0.35 * emp_adj

        # ROUND 45 FIX — propagation direction:
        # adj[i, j] > 0 means "stock i LEADS stock j" (i's lagged return
        # predicts j's current return; the empirical matrix is built exactly
        # that way, and the supply-chain edges carry the same producer->
        # beneficiary orientation). Spillover semantics require stock i to
        # RECEIVE the momentum of the stocks that LEAD i — i.e. propagate over
        # the TRANSPOSED adjacency (incoming edges), not over i's out-edges.
        # The old code propagated with A @ h0, which aggregated into each stock
        # the momentum of the names IT LEADS (its followers) — for the
        # empirical graph (35% of the fusion) the signal meant the opposite of
        # what was reported (verified: FOLLOWY = 1-day-lagged LEADERX received
        # ZERO boost from LEADERX's 0.95 momentum, identical to an unrelated
        # name).
        fused_adj = fused_adj.T
        np.fill_diagonal(fused_adj, 1.0)  # Self-loops

        # Row-normalize the receiving graph
        d_inv = np.diag(1.0 / (fused_adj.sum(axis=1) + 1e-9))
        norm_adj = np.dot(d_inv, fused_adj)

        # 2. Initial Feature Matrix H^(0)
        h0 = np.zeros((n, 1), dtype=float)
        for i, sym in enumerate(self.stock_list):
            val = base_momentum_scores.get(sym, 0.5) if base_momentum_scores else 0.5
            h0[i, 0] = val

        # 3. Layer 1 Graph Convolution (with non-linear activation)
        w1 = 1.2
        h1 = np.maximum(0.0, np.dot(norm_adj, h0) * w1)  # ReLU

        # 4. Layer 2 Graph Convolution
        w2 = 0.8
        h2 = np.logaddexp(0.0, np.dot(norm_adj, h1) * w2)  # Softplus (stable)

        # Fused GNN Output Signal
        final_alpha = 0.50 * h0.ravel() + 0.35 * h1.ravel() + 0.15 * h2.ravel()
        # Scale to [0.0, 1.0]
        min_v, max_v = final_alpha.min(), final_alpha.max()
        if max_v > min_v:
            normalized = (final_alpha - min_v) / (max_v - min_v)
        else:
            # FIX-Bug3: When all GNN outputs are equal (e.g. uniform h0 input),
            # use the raw h0 values (PatchTST momentum scores) directly as proportional scores
            # instead of collapsing everything to a hardcoded constant.
            h0_min, h0_max = h0.ravel().min(), h0.ravel().max()
            if h0_max > h0_min:
                normalized = (h0.ravel() - h0_min) / (h0_max - h0_min)
            else:
                # Truly uniform: assign equal moderate scores (not 75 — use actual h0 level)
                normalized = h0.ravel().copy()  # e.g. [0.5, 0.5, ...] → scores of 50%

        results = {}
        for i, sym in enumerate(self.stock_list):
            score = float(normalized[i])
            # ROUND 45 FIX: the old "spillover boost" = final_alpha[i] - h0[i]
            # included the softplus floor of h2, so a stock with NO incoming
            # edges still reported ~+10% spillover momentum. Now measured against
            # the self-loop-only baseline — exactly what node i would score with
            # zero external edges — so isolated nodes report 0.0%.
            _self_h1 = max(0.0, float(h0[i, 0]) * w1)
            _self_h2 = float(np.logaddexp(0.0, _self_h1 * w2))
            _self_final = 0.50 * float(h0[i, 0]) + 0.35 * _self_h1 + 0.15 * _self_h2
            spillover_boost = float((final_alpha[i] - _self_final) * 100)

            # Key sector drivers from canonical supply-chain graph
            drivers = []
            for theme, targets in CANONICAL_SUPPLY_CHAIN_EDGES.items():
                for s, weight in targets:
                    if s == sym:
                        drivers.append(f"{theme.replace('_', ' ').title()} ({int(weight*100)}%)")

            # FIX-Bug3: Use actual raw PatchTST h0 value as base when no supply-chain boost
            # so non-graph stocks get scores proportional to their own momentum, not 75.0
            raw_h0_score = float(h0[i, 0]) * 100.0  # convert [0,1] back to [0,100]

            results[sym] = {
                "ticker": f"{sym}.NS",
                "gnn_alpha_score": round(score * 100, 1),
                "spillover_momentum_pct": round(spillover_boost, 2),
                "primary_thematic_driver": drivers[0] if drivers else "Broad Sector Beta",
                "network_centrality": round(float(fused_adj[i].sum()), 2),
                "base_momentum_score": round(raw_h0_score, 1),
                "method": "untrained graph-propagation heuristic (fixed scalar weights, curated edges)",
            }

        return results
