"""
ml_alpha/graph_attention_network.py
====================================
Dynamic Graph Attention Network (GAT) for Indian Equity Supply-Chain & Correlation Graph.

TIER 1 UPGRADE: Replaces fixed canonical adjacency matrix with a trained
multi-head Graph Attention Network (GAT) whose edge weights are dynamically
computed from rolling return correlations fused with supply-chain structural priors.

Reference: Veličković et al. (2018), "Graph Attention Networks", ICLR 2018.
           https://arxiv.org/abs/1710.10903

Architecture:
    e_ij  = LeakyReLU(aᵀ [Wh_i ‖ Wh_j])         # attention logit
    α_ij  = softmax_j(e_ij)                       # normalized per-node
    h_i'  = σ(1/K Σ_k Σ_{j∈N_i} α_ij^(k) W^(k) h_j)  # multi-head aggregation

Implementation: Pure NumPy / SciPy — no PyG, DGL, or C++ extensions.
100% CPU-portable and serializable via standard Python pickle.
"""
from __future__ import annotations

import logging
from typing import Dict, List, Optional
import numpy as np
import pandas as pd
from scipy.special import softmax

logger = logging.getLogger(__name__)


class DynamicGATEngine:
    """
    Dynamic Graph Attention Network Engine.

    Learns attention-weighted adjacency matrices from:
    1. Rolling return correlations (empirical dynamic edges)
    2. Canonical supply-chain prior (structural prior)

    The fused attention weights replace fixed heuristic adjacency matrices,
    enabling adaptive propagation that evolves with market conditions.
    """

    def __init__(
        self,
        n_heads: int = 4,
        feature_dim: int = 1,
        hidden_dim: int = 8,
        alpha_leaky: float = 0.2,
        corr_threshold: float = 0.25,
        supply_chain_weight: float = 0.45,
        corr_weight: float = 0.55,
        n_epochs: int = 30,
        lr: float = 0.01,
    ):
        self.n_heads = n_heads
        self.feature_dim = feature_dim
        self.hidden_dim = hidden_dim
        self.alpha_leaky = alpha_leaky
        self.corr_threshold = corr_threshold
        self.supply_chain_weight = supply_chain_weight
        self.corr_weight = corr_weight
        self.n_epochs = n_epochs
        self.lr = lr

        self.W_: Optional[np.ndarray] = None   # [n_heads, hidden_dim, feature_dim]
        self.a_: Optional[np.ndarray] = None   # [n_heads, 2*hidden_dim]

        self.stock_list_: List[str] = []
        self.supply_chain_adj_: Optional[np.ndarray] = None
        self.corr_adj_: Optional[np.ndarray] = None
        self.fused_adj_: Optional[np.ndarray] = None
        self.attention_adj_: Optional[np.ndarray] = None

        self.fitted_: bool = False

    # ─────────────────────────────────────────────────────────────────────────
    # 1. Dynamic Edge Construction
    # ─────────────────────────────────────────────────────────────────────────

    def build_correlation_adj(self, returns_df: pd.DataFrame, stocks: List[str]) -> np.ndarray:
        """Builds empirical adjacency from rolling 60-day pairwise return correlations.

        R34-3: each pair is aligned on its common dates BEFORE the trailing
        window is taken — the Round 33 version dropna'd each series
        independently and correlated the (possibly date-misaligned) tails,
        which compares returns from different trading days when histories
        diverge.
        """
        n = len(stocks)
        adj = np.zeros((n, n), dtype=float)

        for i, s1 in enumerate(stocks):
            col1 = s1 if s1 in returns_df.columns else s1.replace(".NS", "").replace(".BO", "").upper()
            if col1 not in returns_df.columns:
                continue
            for j, s2 in enumerate(stocks):
                if i == j:
                    continue
                col2 = s2 if s2 in returns_df.columns else s2.replace(".NS", "").replace(".BO", "").upper()
                if col2 not in returns_df.columns:
                    continue
                pair = returns_df[[col1, col2]].dropna().tail(60)
                if len(pair) < 20:
                    continue
                c = float(np.corrcoef(pair[col1].values, pair[col2].values)[0, 1])
                if np.isfinite(c) and c > self.corr_threshold:
                    adj[i, j] = max(0.0, c)

        row_sums = adj.sum(axis=1, keepdims=True)
        row_sums[row_sums < 1e-9] = 1.0
        return adj / row_sums

    def build_supply_chain_adj(self, stocks: List[str]) -> np.ndarray:
        """Builds structural adjacency from canonical supply-chain edges."""
        try:
            from ml_alpha.gnn_spillover import GNNIndustrySpilloverEngine
            engine = GNNIndustrySpilloverEngine()
            return engine.build_supply_chain_matrix(stocks)
        except Exception as e:
            logger.debug("Supply-chain adj fallback: %s", e)
            n = len(stocks)
            return np.eye(n) / max(n, 1)

    # ─────────────────────────────────────────────────────────────────────────
    # 2. Multi-Head Attention (vectorized)
    # ─────────────────────────────────────────────────────────────────────────

    def _leaky_relu(self, x: np.ndarray) -> np.ndarray:
        return np.where(x > 0, x, self.alpha_leaky * x)

    def _fast_attention_adj(self, H: np.ndarray, adj_mask: np.ndarray) -> np.ndarray:
        """
        Vectorized multi-head GAT attention pass.

        e_ij = LeakyReLU(aᵀ [Wh_i ‖ Wh_j])
        α_ij = softmax_{j in N(i)} e_ij
        """
        if self.W_ is None or self.a_ is None:
            return adj_mask

        N = H.shape[0]
        all_head_attn = np.zeros((N, N), dtype=float)
        mask = (adj_mask > 0) | np.eye(N, dtype=bool)

        for k in range(self.n_heads):
            W_k = self.W_[k]   # [hidden_dim, feature_dim]
            a_k = self.a_[k]   # [2 * hidden_dim]
            Wh = (W_k @ H.T).T  # [N, hidden_dim]

            # Vectorized outer product concat: [N, N, 2*hidden_dim]
            Wh_i = Wh[:, np.newaxis, :]   # [N, 1, D]
            Wh_j = Wh[np.newaxis, :, :]   # [1, N, D]
            D = self.hidden_dim
            concat_all = np.concatenate([
                np.broadcast_to(Wh_i, (N, N, D)),
                np.broadcast_to(Wh_j, (N, N, D))
            ], axis=-1)  # [N, N, 2D]

            raw_e = concat_all @ a_k      # [N, N]
            e = self._leaky_relu(raw_e)
            e_masked = np.where(mask, e, -1e9)
            attn_k = softmax(e_masked, axis=1)
            all_head_attn += attn_k

        return all_head_attn / max(self.n_heads, 1)

    # ─────────────────────────────────────────────────────────────────────────
    # 3. Training
    # ─────────────────────────────────────────────────────────────────────────

    def fit_dynamic_attention(
        self,
        stocks: List[str],
        returns_df: Optional[pd.DataFrame] = None,
        base_scores: Optional[np.ndarray] = None,
    ) -> "DynamicGATEngine":
        """
        Learns attention parameters W and a to minimize reconstruction loss
        relative to supply-chain-prior-diffused signals.
        """
        self.stock_list_ = [s.replace(".NS", "").replace(".BO", "").upper() for s in stocks]
        n = len(self.stock_list_)

        if n == 0:
            self.fitted_ = True
            return self

        # Build adjacency matrices
        self.supply_chain_adj_ = self.build_supply_chain_adj(self.stock_list_)
        if returns_df is not None and not returns_df.empty:
            self.corr_adj_ = self.build_correlation_adj(returns_df, self.stock_list_)
        else:
            self.corr_adj_ = np.eye(n) / max(n, 1)

        self.fused_adj_ = (
            self.supply_chain_weight * self.supply_chain_adj_ +
            self.corr_weight * self.corr_adj_
        )
        np.fill_diagonal(self.fused_adj_, 1.0)

        # Initialize learnable parameters
        rng = np.random.default_rng(42)
        self.W_ = rng.normal(0.0, 0.1, (self.n_heads, self.hidden_dim, self.feature_dim))
        self.a_ = rng.normal(0.0, 0.1, (self.n_heads, 2 * self.hidden_dim))

        # Feature matrix H (supports 1-D return or 5-D Multi-Dimensional Flow Tensor)
        if base_scores is not None:
            H_arr = np.asarray(base_scores, dtype=float)
            if H_arr.ndim == 1:
                H = H_arr.reshape(n, -1)
            else:
                H = H_arr
            if H.shape[1] != self.feature_dim:
                self.feature_dim = H.shape[1]
                self.W_ = rng.normal(0.0, 0.1, (self.n_heads, self.hidden_dim, self.feature_dim))
        else:
            H = np.ones((n, self.feature_dim), dtype=float) * 0.5

        target = self.supply_chain_adj_ @ H  # diffusion target
        adj_mask = (self.fused_adj_ > 0.01).astype(float)

        best_loss = float("inf")
        best_W = self.W_.copy()
        best_a = self.a_.copy()

        for epoch in range(self.n_epochs):
            attn_adj = self._fast_attention_adj(H, adj_mask)
            pred = attn_adj @ H
            diff = pred - target
            loss = float(np.mean(diff ** 2))

            if loss < best_loss:
                best_loss = loss
                best_W = self.W_.copy()
                best_a = self.a_.copy()

            # Numerical gradient descent (no autograd required)
            eps = 1e-3
            for k in range(self.n_heads):
                for i in range(min(self.hidden_dim, 4)):
                    for j in range(self.feature_dim):
                        self.W_[k, i, j] += eps
                        lp = float(np.mean((self._fast_attention_adj(H, adj_mask) @ H - target) ** 2))
                        self.W_[k, i, j] -= eps + self.lr * (lp - loss) / eps
                for d in range(min(2 * self.hidden_dim, 8)):
                    self.a_[k, d] += eps
                    lp = float(np.mean((self._fast_attention_adj(H, adj_mask) @ H - target) ** 2))
                    self.a_[k, d] -= eps + self.lr * (lp - loss) / eps

        self.W_ = best_W
        self.a_ = best_a
        self.attention_adj_ = self._fast_attention_adj(H, adj_mask)

        delta = float(np.mean(np.abs(self.attention_adj_ - self.supply_chain_adj_)))
        logger.info("[GAT] %d-head attention fitted on %d stocks. Adj delta vs static: %.4f", self.n_heads, n, delta)
        self.fitted_ = True
        return self

    # ─────────────────────────────────────────────────────────────────────────
    # 4. Inference
    # ─────────────────────────────────────────────────────────────────────────

    def propagate(
        self,
        scores: np.ndarray,
        alpha_blend: float = 0.30,
        names: Optional[List[str]] = None,
    ) -> np.ndarray:
        """
        Propagates alpha scores through dynamic attention adjacency.
        h_diffused = (1 - α) · h + α · (A_attn · h)
        """
        if not self.fitted_:
            return scores

        scores_arr = np.asarray(scores, dtype=float).ravel()
        n = len(scores_arr)
        if n == 0:
            return scores_arr

        # Select adjacency
        adj = self.attention_adj_ if self.attention_adj_ is not None else self.fused_adj_
        if adj is None:
            return scores_arr

        # If names are provided, align them with the fitted stock_list_
        if names is not None and self.stock_list_ is not None:
            clean_names = [str(t).replace(".NS", "").replace(".BO", "").upper() for t in names]
            fitted_name_to_idx = {name: i for i, name in enumerate(self.stock_list_)}
            
            # If names match the full fitted stock list (possibly reordered)
            if set(clean_names).issubset(fitted_name_to_idx.keys()) and len(clean_names) == len(self.stock_list_):
                reorder_idx = [fitted_name_to_idx[name] for name in clean_names]
                # Reorder scores into fitted graph order
                fitted_scores = np.zeros(len(self.stock_list_), dtype=float)
                for src_i, fit_i in enumerate(reorder_idx):
                    fitted_scores[fit_i] = scores_arr[src_i]
                
                h = fitted_scores.reshape(-1, 1)
                diffused_fit = ((1.0 - alpha_blend) * h + alpha_blend * (adj @ h)).ravel()
                
                # Invert back to caller's original order
                out = np.zeros(n, dtype=float)
                for src_i, fit_i in enumerate(reorder_idx):
                    out[src_i] = diffused_fit[fit_i]
                return out

            elif set(clean_names).issubset(fitted_name_to_idx.keys()):
                # Subset of fitted stocks: extract sub-adjacency
                indices = [fitted_name_to_idx[name] for name in clean_names]
                sub_adj = adj[np.ix_(indices, indices)]
                row_sums = sub_adj.sum(axis=1, keepdims=True)
                row_sums[row_sums == 0] = 1.0
                sub_adj = sub_adj / row_sums
                
                h = scores_arr.reshape(n, 1)
                return ((1.0 - alpha_blend) * h + alpha_blend * (sub_adj @ h)).ravel()
            else:
                # Unseen tickers present: cannot diffuse through graph honestly
                return scores_arr

        # Positional fallback only if shapes match
        if adj.shape[0] == n:
            h = scores_arr.reshape(n, 1)
            return ((1.0 - alpha_blend) * h + alpha_blend * (adj @ h)).ravel()

        return scores_arr

    def get_attention_diagnostics(self) -> Dict[str, float]:
        """Returns diagnostic statistics on the learned attention matrix."""
        if not self.fitted_ or self.attention_adj_ is None:
            return {"fitted": 0.0}
        attn = self.attention_adj_
        sc = self.supply_chain_adj_ if self.supply_chain_adj_ is not None else attn
        return {
            "fitted": 1.0,
            "n_stocks": float(len(self.stock_list_)),
            "n_heads": float(self.n_heads),
            "mean_attention_weight": float(np.mean(attn)),
            "max_attention_weight": float(np.max(attn)),
            "attention_vs_static_delta": float(np.mean(np.abs(attn - sc))),
            "attention_sparsity": float(np.mean(attn < 0.01)),
        }


# Backward-compatibility alias
DynamicGraphAttentionEngine = DynamicGATEngine
