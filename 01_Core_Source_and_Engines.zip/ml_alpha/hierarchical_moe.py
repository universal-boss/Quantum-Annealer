"""
ml_alpha/hierarchical_moe.py
============================
Hierarchical Regime-Gated Mixture of Experts (MoE) Architecture:
Pinnacle SOTA Quantitative Machine Learning Model for Institutional Equity Portfolios.

TIER 1 UPGRADE:
  - PeerSpilloverExpert: uses DynamicGATEngine (learned multi-head attention
    adjacency replacing the static canonical supply-chain adjacency matrix).
  - HierarchicalMoEPredictor: accepts use_ppo_gating=True to replace the heuristic
    MacroRegimeGater with a PPOGatingRouter (Proximal Policy Optimization actor-critic
    trained to maximize portfolio Sharpe by routing expert weights).
  - Backward compat: use_ppo_gating=False preserves original MacroRegimeGater.

Architectural Hierarchy:
1. Latent Factor De-Noising Layer (RMT Spectral Shrinkage + Factor-VAE)
2. Macro Regime Detector: PPO RL Router (Tier 1) or MacroRegimeGater (Tier 2 compat)
3. Dynamic GAT Expert Routing (learned attention adjacency)
4. Specialized Quantitative Experts:
   - Expert 1: Trend & Momentum (LightGBM GBDT)
   - Expert 2: Mean Reversion & Squeeze (ElasticNet & Bayesian Ridge)
   - Expert 3: Peer & Supply-Chain Spillover (DynamicGATEngine)
5. Dynamic Synthesis & Quantum Annealer Alpha Scoring
"""
from __future__ import annotations

import logging
from typing import Dict, Any, List, Tuple, Optional, Union
import numpy as np
import pandas as pd
from scipy import stats, linalg
from sklearn.linear_model import Ridge, ElasticNet, BayesianRidge
from sklearn.preprocessing import StandardScaler
import lightgbm as lgb

from .latent_denoiser import LatentFactorDenoiser
from .gnn_spillover import GNNIndustrySpilloverEngine, CANONICAL_SUPPLY_CHAIN_EDGES

# TIER 1: Dynamic GAT Engine (lazy import to avoid circular deps at module load)
try:
    from .graph_attention_network import DynamicGATEngine
    _HAS_GAT = True
except ImportError:
    DynamicGATEngine = None  # type: ignore
    _HAS_GAT = False

# TIER 1: PPO Gating Router (lazy import)
try:
    from .ppo_gating_router import PPOGatingRouter, build_ppo_observation
    _HAS_PPO = True
except ImportError:
    PPOGatingRouter = None  # type: ignore
    build_ppo_observation = None  # type: ignore
    _HAS_PPO = False

logger = logging.getLogger(__name__)

# Macro Market Regimes
REGIME_BULL_TREND = 0
REGIME_CHOP_REVERSION = 1
REGIME_STRESS_CRASH = 2

REGIME_NAMES = {
    REGIME_BULL_TREND: "Bull_Trending",
    REGIME_CHOP_REVERSION: "Chop_MeanReversion",
    REGIME_STRESS_CRASH: "HighVol_CrashStress",
}


class MacroRegimeGater:
    """
    Macro Regime Classification & State Transition Engine:
    Combines trend slope, realized volatility, peak-to-trough drawdown,
    and Hysteresis buffer thresholds to prevent flickering.
    """

    def __init__(
        self,
        vol_high_threshold: float = 0.24,  # Annualized 24% vol triggers stress
        vol_low_threshold: float = 0.14,   # Sub-14% vol indicates quiet bull
        drawdown_stress_threshold: float = -0.10,  # 10% market correction
        hysteresis_buffer: float = 0.15,
    ):
        self.vol_high_threshold = vol_high_threshold
        self.vol_low_threshold = vol_low_threshold
        self.drawdown_stress_threshold = drawdown_stress_threshold
        self.hysteresis_buffer = hysteresis_buffer
        self.current_state: int = REGIME_BULL_TREND

    def classify_market_state(
        self,
        returns_history: Union[pd.Series, np.ndarray],
    ) -> Tuple[int, np.ndarray]:
        """
        Calculates macro regime probabilities [P(Bull), P(Chop), P(Stress)].
        """
        r = np.asarray(returns_history, dtype=float)
        r = r[~np.isnan(r)]
        if len(r) < 20:
            # Uniform Bayesian prior — no regime evidence from fewer than 20 observations
            _p = 1.0 / 3.0
            return REGIME_BULL_TREND, np.array([_p, _p, _p])

        # Trailing 21d realized vol annualized
        trailing_21 = r[-21:] if len(r) >= 21 else r
        realized_vol = float(np.std(trailing_21) * np.sqrt(252.0))

        # Trailing 63d cumulative return and drawdown
        trailing_63 = r[-63:] if len(r) >= 63 else r
        cum_prices = np.cumprod(1.0 + trailing_63)
        running_max = np.maximum.accumulate(cum_prices)
        drawdowns = (cum_prices - running_max) / (running_max + 1e-9)
        max_dd = float(np.min(drawdowns))
        total_ret = float(cum_prices[-1] - 1.0)

        # 1. Stress Score
        stress_score = 0.0
        if realized_vol > self.vol_high_threshold:
            stress_score += (realized_vol - self.vol_high_threshold) / 0.10
        if max_dd < self.drawdown_stress_threshold:
            stress_score += abs(max_dd - self.drawdown_stress_threshold) / 0.10
        stress_score = float(np.clip(stress_score, 0.0, 3.0))

        # 2. Bull Trend Score
        bull_score = 0.0
        if total_ret > 0.02 and realized_vol < self.vol_high_threshold:
            bull_score += (total_ret / 0.10)
        if realized_vol < self.vol_low_threshold:
            bull_score += (self.vol_low_threshold - realized_vol) / 0.05
        bull_score = float(np.clip(bull_score, 0.0, 3.0))

        # 3. Chop Score
        chop_score = 1.0 if (bull_score < 0.8 and stress_score < 0.8) else 0.2

        # Softmax logits
        logits = np.array([bull_score, chop_score, stress_score])
        exp_l = np.exp(logits - np.max(logits))
        probs = exp_l / np.sum(exp_l)

        candidate_state = int(np.argmax(probs))
        # Hysteresis buffer
        if candidate_state != self.current_state:
            if probs[candidate_state] > probs[self.current_state] + self.hysteresis_buffer:
                self.current_state = candidate_state

        return self.current_state, probs


class TrendMomentumExpert:
    """
    Expert 1: Intermediate & Long-Term Momentum Follower:
    Uses LightGBM GBDT with tree-based split interactions on trend & breakout factors.
    """

    FEATURE_KEYWORDS = ["mom_", "breakout_", "trend_", "drawdown_"]

    def __init__(self, n_estimators: int = 40, max_depth: int = 4, learning_rate: float = 0.03):
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.learning_rate = learning_rate
        self.model: Optional[lgb.LGBMRegressor] = None
        self.feature_subset: list[str] = []
        self.scaler = StandardScaler()

    def fit(self, X: pd.DataFrame, y: np.ndarray) -> "TrendMomentumExpert":
        # Select matching feature subset
        cols = [c for c in X.columns if any(kw in c.lower() for kw in self.FEATURE_KEYWORDS)]
        self.feature_subset = cols if cols else list(X.columns)[:8]

        X_sub = X[self.feature_subset].fillna(0.0).values
        X_scaled = self.scaler.fit_transform(X_sub)

        self.model = lgb.LGBMRegressor(
            n_estimators=self.n_estimators,
            max_depth=self.max_depth,
            learning_rate=self.learning_rate,
            num_leaves=15,
            min_child_samples=20,
            n_jobs=1,  # OpenMP safe
            random_state=42,
            verbose=-1,
        )
        self.model.fit(X_scaled, y)
        return self

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        if self.model is None:
            return np.zeros(len(X))
        cols = [c for c in self.feature_subset if c in X.columns]
        if len(cols) != len(self.feature_subset):
            X_mat = np.zeros((len(X), len(self.feature_subset)))
            for i, c in enumerate(self.feature_subset):
                if c in X.columns:
                    X_mat[:, i] = X[c].fillna(0.0).values
        else:
            X_mat = X[self.feature_subset].fillna(0.0).values

        X_scaled = self.scaler.transform(X_mat)
        return self.model.predict(X_scaled)


class MeanReversionSqueezeExpert:
    """
    Expert 2: Short-Term Mean Reversion & Volatility Compression:
    Uses ElasticNet (L1/L2 shrinkage) + Bayesian Ridge on volume exhaustion and fractional memory.
    """

    FEATURE_KEYWORDS = ["vol_", "turnover_", "frac_diff_", "rsi_", "bb_"]

    def __init__(self, alpha: float = 0.1, l1_ratio: float = 0.5):
        self.alpha = alpha
        self.l1_ratio = l1_ratio
        self.model_enet: Optional[ElasticNet] = None
        self.model_bayes: Optional[BayesianRidge] = None
        self.feature_subset: list[str] = []
        self.scaler = StandardScaler()

    def fit(self, X: pd.DataFrame, y: np.ndarray) -> "MeanReversionSqueezeExpert":
        cols = [c for c in X.columns if any(kw in c.lower() for kw in self.FEATURE_KEYWORDS)]
        self.feature_subset = cols if cols else list(X.columns)[:8]

        X_sub = X[self.feature_subset].fillna(0.0).values
        X_scaled = self.scaler.fit_transform(X_sub)

        self.model_enet = ElasticNet(alpha=self.alpha, l1_ratio=self.l1_ratio, random_state=42, max_iter=2000)
        self.model_enet.fit(X_scaled, y)

        self.model_bayes = BayesianRidge(max_iter=1000)
        self.model_bayes.fit(X_scaled, y)
        return self

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        if self.model_enet is None:
            return np.zeros(len(X))
        cols = [c for c in self.feature_subset if c in X.columns]
        if len(cols) != len(self.feature_subset):
            X_mat = np.zeros((len(X), len(self.feature_subset)))
            for i, c in enumerate(self.feature_subset):
                if c in X.columns:
                    X_mat[:, i] = X[c].fillna(0.0).values
        else:
            X_mat = X[self.feature_subset].fillna(0.0).values

        X_scaled = self.scaler.transform(X_mat)
        pred_enet = self.model_enet.predict(X_scaled)
        pred_bayes = self.model_bayes.predict(X_scaled)
        return 0.5 * pred_enet + 0.5 * pred_bayes


class PeerSpilloverExpert:
    """
    Expert 3: Cross-Stock Supply-Chain & Thematic Lead-Lag Diffusion.

    TIER 1 UPGRADE: Now uses DynamicGATEngine with learned multi-head attention
    adjacency (Veličković et al. 2018, ICLR) instead of the fixed canonical
    supply-chain heuristic. Dynamic edges are recomputed from rolling 60-day
    return correlations fused with the supply-chain prior.

    Falls back to static GNNIndustrySpilloverEngine if GAT is unavailable.
    """

    def __init__(self, alpha_decay: float = 0.30, use_gat: bool = True, n_heads: int = 4):
        self.alpha_decay = alpha_decay
        self.use_gat = use_gat and _HAS_GAT
        self.n_heads = n_heads

        # Static fallback engine (original Tier 2 behaviour)
        self.engine = GNNIndustrySpilloverEngine()
        # Dynamic GAT engine (Tier 1 upgrade)
        self.gat_engine_: Optional[Any] = None

        self.linear_base = Ridge(alpha=10.0, random_state=42)
        self.scaler = StandardScaler()
        self._train_tickers: list[str] = []
        self._train_returns: Optional[pd.DataFrame] = None

    def fit(
        self,
        X: pd.DataFrame,
        y: np.ndarray,
        tickers: Optional[list[str]] = None,
        returns_df: Optional[pd.DataFrame] = None,
    ) -> "PeerSpilloverExpert":
        """Fits the linear base predictor and trains the Dynamic GAT adjacency."""
        X_mat = X.fillna(0.0).values
        X_scaled = self.scaler.fit_transform(X_mat)
        self.linear_base.fit(X_scaled, y)

        if tickers:
            self._train_tickers = list(dict.fromkeys(tickers))
        if returns_df is not None:
            self._train_returns = returns_df

        # R34-3: per-ticker mean of the fitted base predictions feeds the GAT's
        # feature matrix H. The Round 33 wiring passed NO base_scores, so H was a
        # constant 0.5 vector: every attention logit e_ij was then identical
        # (Wh_i == Wh_j for all i, j), the softmax collapsed to uniform weights
        # over the edge mask, the reconstruction loss was flat in (W, a), and the
        # 30-epoch "training" executed zero effective gradient — the shipped
        # "trained multi-head attention" was the initial random parameters
        # rendered inert by uniformity. With real cross-sectional scores in H the
        # logits differentiate and the learned attention is meaningful.
        base_scores: Optional[np.ndarray] = None
        if tickers and len(tickers) == len(X):
            try:
                row_preds = np.asarray(self.linear_base.predict(X_scaled), dtype=float)
                per_ticker: dict[str, list[float]] = {}
                for t, p in zip(tickers, row_preds):
                    per_ticker.setdefault(t, []).append(float(p))
                base_scores = np.array(
                    [float(np.mean(per_ticker[t])) for t in self._train_tickers],
                    dtype=float,
                )
            except Exception:
                base_scores = None

        # Fit Dynamic GAT on supply-chain + correlation graph
        if self.use_gat and _HAS_GAT and self._train_tickers:
            try:
                self.gat_engine_ = DynamicGATEngine(n_heads=self.n_heads)
                self.gat_engine_.fit_dynamic_attention(
                    stocks=self._train_tickers,
                    returns_df=self._train_returns,
                    base_scores=base_scores,
                )
                logger.info(
                    "[PeerSpilloverExpert] DynamicGATEngine fitted on %d stocks.",
                    len(self._train_tickers)
                )
            except Exception as e:
                logger.warning("[PeerSpilloverExpert] GAT fitting failed (%s) — using static adj.", e)
                self.gat_engine_ = None

        return self

    def predict(self, X: pd.DataFrame, tickers: Optional[list[str]] = None) -> np.ndarray:
        X_mat = X.fillna(0.0).values
        X_scaled = self.scaler.transform(X_mat)
        base_preds = self.linear_base.predict(X_scaled)

        if not tickers or len(tickers) != len(base_preds):
            return base_preds

        # Case 1: Single cross-section (all unique tickers <= 500)
        unique_tickers = list(dict.fromkeys(tickers))
        if len(unique_tickers) == len(tickers) and len(unique_tickers) <= 500:
            try:
                # TIER 1: Use GAT attention propagation if available
                if self.gat_engine_ is not None and self.gat_engine_.fitted_:
                    if self.gat_engine_.attention_adj_ is not None and \
                       self.gat_engine_.attention_adj_.shape[0] == len(unique_tickers):
                        diffused = self.gat_engine_.propagate(base_preds, alpha_blend=self.alpha_decay)
                        return diffused

                # Fallback to static adjacency
                adj = self.engine.build_supply_chain_matrix(unique_tickers)
                return (1.0 - self.alpha_decay) * base_preds + self.alpha_decay * (adj @ base_preds)
            except Exception as e:
                logger.debug("Graph diffusion fallback due to: %s", e)
                return base_preds

        # Case 2: Multi-date pooled panel (diffuse per date to prevent N^2 memory blowup)
        if isinstance(X.index, pd.MultiIndex) and "date" in X.index.names:
            try:
                diffused = base_preds.copy()
                dates = X.index.get_level_values("date")
                for dt in np.unique(dates):
                    dt_mask = (dates == dt)
                    sub_indices = np.where(dt_mask)[0]
                    sub_tickers = [tickers[idx] for idx in sub_indices]
                    sub_preds = base_preds[dt_mask]
                    if len(sub_tickers) > 1 and len(sub_tickers) == len(set(sub_tickers)) and len(sub_tickers) <= 500:
                        adj = self.engine.build_supply_chain_matrix(sub_tickers)
                        diffused[dt_mask] = (1.0 - self.alpha_decay) * sub_preds + self.alpha_decay * (adj @ sub_preds)
                return diffused
            except Exception as e:
                logger.debug("Pooled graph diffusion fallback due to: %s", e)
                return base_preds

        return base_preds

    def get_gat_diagnostics(self) -> Dict[str, Any]:
        """Returns diagnostic info from the fitted DynamicGATEngine."""
        if self.gat_engine_ is not None and hasattr(self.gat_engine_, 'get_attention_diagnostics'):
            return self.gat_engine_.get_attention_diagnostics()
        return {"gat_available": False, "using": "static_supply_chain_adjacency"}


class HierarchicalMoEPredictor:
    """
    Hierarchical Regime-Gated Mixture of Experts (MoE) Predictor:
    Coordinates Latent De-Noising, Macro Regime Gating, and Specialized Expert Blending.
    """

    def __init__(
        self,
        denoise_method: str = "rmt",
        latent_dim: int = 4,
        kl_weight: float = 0.01,
        use_ppo_gating: bool = True,
        use_gat_spillover: bool = True,
        gat_n_heads: int = 4,
    ):
        """
        Args:
            denoise_method: 'rmt', 'vae', or 'hybrid' for latent de-noising.
            latent_dim: VAE latent space dimension.
            kl_weight: KL divergence weight in ELBO loss.
            use_ppo_gating: TIER 1 — if True, uses PPOGatingRouter (RL trained
                actor-critic) instead of heuristic MacroRegimeGater.
                Set False for Tier 2 backward compat. Default True.
            use_gat_spillover: TIER 1 — if True, PeerSpilloverExpert uses
                DynamicGATEngine (learned multi-head attention adjacency).
                Default True.
            gat_n_heads: Number of attention heads in DynamicGATEngine.
        """
        self.denoise_method = denoise_method
        self.latent_dim = latent_dim
        self.kl_weight = kl_weight
        self.use_ppo_gating = use_ppo_gating and _HAS_PPO
        self.use_gat_spillover = use_gat_spillover and _HAS_GAT
        self.gat_n_heads = gat_n_heads

        # Components
        self.denoiser = LatentFactorDenoiser(method=denoise_method, latent_dim=latent_dim, kl_weight=kl_weight)

        # TIER 1: PPO Gating Router (with heuristic fallback)
        if self.use_ppo_gating and _HAS_PPO:
            self.ppo_router = PPOGatingRouter(use_ppo=True)
            self.regime_gater = MacroRegimeGater()  # kept for regime name reporting
            logger.info("[MoE] TIER 1: PPOGatingRouter activated.")
        else:
            self.ppo_router = None
            self.regime_gater = MacroRegimeGater()

        self.expert_trend = TrendMomentumExpert()
        self.expert_reversion = MeanReversionSqueezeExpert()
        # TIER 1: DynamicGATEngine wired into PeerSpilloverExpert
        self.expert_spillover = PeerSpilloverExpert(
            use_gat=self.use_gat_spillover,
            n_heads=self.gat_n_heads,
        )

        # Calibration & History
        self.feature_names: list[str] = []
        self.train_tickers: list[str] = []
        self.benchmark_returns_: Optional[pd.Series] = None
        self._ic_ewma: float = 0.0
        self.latest_gating_weights_: Dict[str, float] = {
            "trend_momentum": 0.40,
            "mean_reversion": 0.35,
            "peer_spillover": 0.25,
        }
        self.latest_regime_: str = "Bull_Trending"
        self.fitted_: bool = False

    def fit(
        self,
        X: pd.DataFrame,
        y: np.ndarray,
        tickers: list[str],
        dates: Optional[pd.Series] = None,
        benchmark_returns: Optional[pd.Series] = None,
        returns_df: Optional[pd.DataFrame] = None,
        ic_series: Optional[np.ndarray] = None,
    ) -> "HierarchicalMoEPredictor":
        """Fits Latent Denoiser, Experts, GAT, and Gating Network (PPO or heuristic)."""
        self.feature_names = list(X.columns)
        self.train_tickers = list(tickers) if tickers is not None else []
        self.benchmark_returns_ = benchmark_returns

        logger.info("[MoE] Step 1: Fitting Latent Factor Denoiser (%s)...", self.denoise_method)
        self.denoiser.fit(X)
        X_denoised = self.denoiser.denoise(X)

        logger.info("[MoE] Step 2: Fitting Specialized Experts on Denoised Factors...")
        self.expert_trend.fit(X_denoised, y)
        self.expert_reversion.fit(X_denoised, y)
        # TIER 1: Pass the FULL row-aligned ticker list to PeerSpilloverExpert
        # so it can aggregate per-ticker base scores for GAT fitting (R34-3).
        self.expert_spillover.fit(
            X_denoised, y,
            tickers=list(tickers) if tickers is not None else [],
            returns_df=returns_df,
        )

        logger.info("[MoE] Step 3: Calibrating Gating Router...")
        bench_arr = np.asarray(benchmark_returns.values, dtype=float) if benchmark_returns is not None else np.array([])

        # R34-4: per-expert daily cross-sectional IC — the action-dependent reward
        # signal for the PPO router. Without it the router's reward is exogenous
        # to the routing weights and the trained policy degenerates to constant
        # weights. NOTE: these are in-sample ICs of freshly fitted experts (the
        # only per-date expert signal available inside fit()); they tilt the
        # router toward whichever expert fit the training sample best — a
        # disclosed in-sample calibration bias, mirroring the heuristic gater
        # which also calibrates on training-sample statistics.
        expert_ic_matrix: Optional[np.ndarray] = None
        try:
            if (
                isinstance(X.index, pd.MultiIndex)
                and "date" in X.index.names
                and len(y) == len(X)
            ):
                _dates_lvl = pd.Series(X.index.get_level_values("date"))
                _ic_frame = pd.DataFrame({
                    "date": _dates_lvl.values,
                    "y": np.asarray(y, dtype=float),
                    "trend": np.asarray(self.expert_trend.predict(X_denoised), dtype=float),
                    "rev": np.asarray(self.expert_reversion.predict(X_denoised), dtype=float),
                    "spill": np.asarray(
                        self.expert_spillover.predict(X_denoised, tickers=list(tickers)), dtype=float
                    ),
                })
                _ic_rows = []
                for _dt, _g in _ic_frame.groupby("date"):
                    if len(_g) >= 10:
                        _ic_rows.append((
                            _dt,
                            _g["trend"].corr(_g["y"], method="spearman"),
                            _g["rev"].corr(_g["y"], method="spearman"),
                            _g["spill"].corr(_g["y"], method="spearman"),
                        ))
                if len(_ic_rows) >= 30:
                    _ic_df = pd.DataFrame(
                        _ic_rows, columns=["date", "trend", "rev", "spill"]
                    ).set_index("date").dropna()
                    if benchmark_returns is not None and len(_ic_df) > 0:
                        expert_ic_matrix = (
                            _ic_df.reindex(pd.DatetimeIndex(benchmark_returns.index))
                            .fillna(0.0)
                            .values
                        )
                    else:
                        expert_ic_matrix = _ic_df.values
                    logger.info(
                        "[MoE] Per-expert daily IC matrix built (%d dates) for PPO reward.",
                        len(_ic_df),
                    )
        except Exception as _ic_err:
            logger.debug("[MoE] Expert IC matrix unavailable (%s) — PPO falls back.", _ic_err)
            expert_ic_matrix = None

        if self.ppo_router is not None and _HAS_PPO:
            # TIER 1: Train PPO router on benchmark return trajectory
            logger.info("[MoE] TIER 1: Training PPOGatingRouter...")
            self.ppo_router.fit(
                benchmark_returns=bench_arr,
                ic_series=ic_series,
                expert_ic_series=expert_ic_matrix,
                n_episodes=50,
            )
            # Also run heuristic gater for regime name reporting
            if len(bench_arr) >= 20:
                regime_id, probs = self.regime_gater.classify_market_state(bench_arr)
            else:
                regime_id, probs = REGIME_BULL_TREND, np.array([0.50, 0.35, 0.15])
            self.latest_regime_ = REGIME_NAMES.get(regime_id, "Bull_Trending")
            # Get PPO weights
            ppo_w = self.ppo_router.select_weights(bench_arr, ic_ewma=self._ic_ewma)
            self.latest_gating_weights_ = ppo_w
        else:
            # TIER 2 heuristic fallback
            if len(bench_arr) >= 20:
                regime_id, probs = self.regime_gater.classify_market_state(bench_arr)
            else:
                regime_id, probs = REGIME_BULL_TREND, np.array([0.50, 0.35, 0.15])
            self.latest_regime_ = REGIME_NAMES.get(regime_id, "Bull_Trending")
            self._update_gating_weights(probs)

        self.fitted_ = True
        router_type = "PPO" if (self.ppo_router is not None and _HAS_PPO) else "Heuristic"
        gat_type = "DynamicGAT" if self.use_gat_spillover else "StaticGNN"
        logger.info(
            "[MoE] Fitting complete! Router=%s | Spillover=%s | Regime=%s | Weights=%s",
            router_type, gat_type, self.latest_regime_, self.latest_gating_weights_
        )
        return self

    def _update_gating_weights(self, macro_probs: np.ndarray) -> None:
        """
        Heuristic regime-to-weight mapping (Tier 2 backward-compat path).
        Called when use_ppo_gating=False or PPO is unavailable.

        Bull Trending favors Trend Momentum.
        Chop Reversion favors Mean Reversion.
        Stress Crash favors Defensive Peer Spillover.
        """
        p_bull, p_chop, p_stress = macro_probs[0], macro_probs[1], macro_probs[2]

        w_trend = float(0.65 * p_bull + 0.15 * p_chop + 0.10 * p_stress)
        w_rev   = float(0.20 * p_bull + 0.65 * p_chop + 0.25 * p_stress)
        w_spill = float(0.15 * p_bull + 0.20 * p_chop + 0.65 * p_stress)

        total_w = w_trend + w_rev + w_spill + 1e-9
        self.latest_gating_weights_ = {
            "trend_momentum": round(w_trend / total_w, 4),
            "mean_reversion": round(w_rev / total_w, 4),
            "peer_spillover": round(w_spill / total_w, 4),
        }

    def __setstate__(self, state):
        self.__dict__.update(state)
        if not hasattr(self, "ppo_router"):
            self.ppo_router = None
        if not hasattr(self, "use_ppo_gating"):
            self.use_ppo_gating = False
        if not hasattr(self, "use_gat_spillover"):
            self.use_gat_spillover = False
        if not hasattr(self, "gat_n_heads"):
            self.gat_n_heads = 4

    def predict(
        self,
        X: Optional[pd.DataFrame] = None,
        tickers: Optional[list[str]] = None,
        as_of: Optional[Any] = None,
        benchmark_returns: Optional[np.ndarray] = None,
    ) -> Union[np.ndarray, pd.Series, Dict[str, float]]:
        """
        Generates ensemble alpha predictions through the MoE gating network.
        Compatible with AlphaEngine.predict() and optimizer.py auto-loader.

        TIER 1: If PPOGatingRouter is fitted, calls select_weights() to get
        the RL-optimized routing weights before expert blending. Otherwise
        uses cached latest_gating_weights_ from last fit().
        """
        if not self.fitted_:
            raise RuntimeError("HierarchicalMoEPredictor must be fitted before calling predict()")

        if X is None:
            return pd.Series(0.0, index=self.train_tickers)

        # Denoise input features
        X_denoised = self.denoiser.denoise(X) if hasattr(self.denoiser, "denoise") else X

        # Evaluate each expert
        pred_trend = self.expert_trend.predict(X_denoised)
        pred_reversion = self.expert_reversion.predict(X_denoised)
        pred_spillover = self.expert_spillover.predict(X_denoised, tickers=tickers or self.train_tickers)

        # TIER 1: Re-evaluate PPO weights at prediction time if benchmark returns provided
        ppo_router = getattr(self, "ppo_router", None)
        if ppo_router is not None and _HAS_PPO and benchmark_returns is not None:
            bench_arr = np.asarray(benchmark_returns, dtype=float)
            ppo_w = ppo_router.select_weights(bench_arr, ic_ewma=self._ic_ewma)
            self.latest_gating_weights_ = ppo_w
            # Update regime name from heuristic gater for reporting
            if len(bench_arr) >= 20:
                regime_id, _ = self.regime_gater.classify_market_state(bench_arr)
                self.latest_regime_ = REGIME_NAMES.get(regime_id, "Bull_Trending")

        # Expert blending via dynamic routing weights
        w = self.latest_gating_weights_
        final_alpha = (
            w["trend_momentum"] * pred_trend +
            w["mean_reversion"] * pred_reversion +
            w["peer_spillover"] * pred_spillover
        )

        if tickers is not None and len(tickers) == len(final_alpha):
            return pd.Series(final_alpha, index=tickers)
        if isinstance(X, pd.DataFrame) and len(X) == len(final_alpha):
            return pd.Series(final_alpha, index=X.index)
        return final_alpha

    def get_regime_breakdown(self) -> Dict[str, Any]:
        """Returns active macro regime state, routing diagnostics, and expert gating weights."""
        gat_diag = self.expert_spillover.get_gat_diagnostics() if hasattr(self.expert_spillover, "get_gat_diagnostics") else {}
        breakdown: Dict[str, Any] = {
            "current_regime": self.latest_regime_,
            "expert_weights": self.latest_gating_weights_,
            "denoiser_diagnostics": self.denoiser.get_diagnostics() if self.denoiser else {},
            "gat_diagnostics": gat_diag,
        }

        # TIER 1: Include PPO router diagnostics
        ppo_router = getattr(self, "ppo_router", None)
        if ppo_router is not None and _HAS_PPO:
            breakdown["ppo_router"] = ppo_router.get_diagnostics()
        else:
            breakdown["ppo_router"] = {"type": "HeuristicGatingRouter", "fitted": True}

        return breakdown

    def feature_importance(self) -> Dict[str, float]:
        """Calculates aggregated feature importance across experts weighted by gating."""
        fi: Dict[str, float] = {}
        w = getattr(self, "latest_gating_weights_", {})
        w_trend = float(w.get("trend_momentum", 0.40))
        w_rev = float(w.get("mean_reversion", 0.35))
        w_spill = float(w.get("peer_spillover", 0.25))

        # 1. Trend expert (LightGBM)
        if hasattr(self, "expert_trend") and hasattr(self.expert_trend, "model") and self.expert_trend.model is not None:
            lgb_model = self.expert_trend.model
            if hasattr(lgb_model, "feature_importances_"):
                raw_imp = lgb_model.feature_importances_
                total = float(np.sum(raw_imp)) + 1e-9
                for feat, imp in zip(self.expert_trend.feature_subset, raw_imp):
                    fi[feat] = fi.get(feat, 0.0) + w_trend * float(imp / total)

        # 2. Mean reversion expert (ElasticNet)
        if hasattr(self, "expert_reversion") and hasattr(self.expert_reversion, "model_enet") and self.expert_reversion.model_enet is not None:
            enet_coef = np.abs(self.expert_reversion.model_enet.coef_)
            total_enet = float(np.sum(enet_coef)) + 1e-9
            for feat, coef in zip(self.expert_reversion.feature_subset, enet_coef):
                fi[feat] = fi.get(feat, 0.0) + w_rev * float(coef / total_enet)

        # 3. Spillover expert (Ridge base)
        if hasattr(self, "expert_spillover") and hasattr(self.expert_spillover, "linear_base") and self.expert_spillover.linear_base is not None:
            ridge_coef = np.abs(self.expert_spillover.linear_base.coef_)
            total_ridge = float(np.sum(ridge_coef)) + 1e-9
            for feat, coef in zip(self.feature_names[:len(ridge_coef)], ridge_coef):
                fi[feat] = fi.get(feat, 0.0) + w_spill * float(coef / total_ridge)

        # Normalize to sum to 1.0
        total_fi = sum(fi.values())
        if total_fi > 0:
            fi = {k: round(v / total_fi, 4) for k, v in sorted(fi.items(), key=lambda x: -x[1])}
        elif self.feature_names:
            # Equal importance fallback if uninitialized
            eq = round(1.0 / len(self.feature_names), 4)
            fi = {f: eq for f in self.feature_names}

        return fi

