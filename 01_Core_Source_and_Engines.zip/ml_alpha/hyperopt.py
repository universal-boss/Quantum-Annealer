"""Hyperparameter optimization via Optuna with time-series CV.

Uses Bayesian optimization (TPE sampler) to find optimal hyperparameters
for each model in the ensemble. Optimizes for OOS Sharpe ratio (not R²)
because Sharpe is what matters for trading.

Each model gets 50 trials by default. The best hyperparameters are cached
to disk so subsequent runs skip optimization.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Optional
import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)

try:
    import optuna
    optuna.logging.set_verbosity(optuna.logging.WARNING)
    _HAS_OPTUNA = True
except ImportError:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    _HAS_OPTUNA = False

CACHE_PATH = Path(__file__).parent.parent / "models" / "best_hyperparams.json"


def optimize_lightgbm(
    X: pd.DataFrame,
    y: pd.Series,
    cv_splits: list[tuple[pd.DatetimeIndex, pd.DatetimeIndex]],
    n_trials: int = 50,
) -> dict:
    """Optimize LightGBM hyperparameters via Optuna.

    Objective: maximize mean OOS Spearman IC across CV folds.
    """
    if not _HAS_OPTUNA:
        return _default_lightgbm_params()

    def objective(trial):
        params = {
            "n_estimators": trial.suggest_int("n_estimators", 50, 300),
            "learning_rate": trial.suggest_float("learning_rate", 0.005, 0.05, log=True),
            "num_leaves": trial.suggest_int("num_leaves", 7, 31),   # capped at 31: deeper trees → more overfit
            "max_depth": trial.suggest_int("max_depth", 3, 6),       # capped at 6: prevent deep noise-splitting
            # FIX: min_child_samples raised to 500 max. Low values (e.g. 20) allow
            # leaf nodes built on tiny subsets of the data — the classic source of
            # IS Sharpe inflation. Higher values force each split to be supported by
            # enough observations to generalize out-of-sample.
            "min_child_samples": trial.suggest_int("min_child_samples", 50, 500),
            "subsample": trial.suggest_float("subsample", 0.5, 0.85),     # cap at 0.85: full-sample trees memorize
            "colsample_bytree": trial.suggest_float("colsample_bytree", 0.5, 0.85),
            # FIX: reg_lambda raised to 100. With full factor set (26+ features),
            # L2 regularization needs to be strong enough to smooth coefficients
            # across correlated factors without forcing any to exactly zero.
            "reg_alpha": trial.suggest_float("reg_alpha", 0.1, 10.0, log=True),
            "reg_lambda": trial.suggest_float("reg_lambda", 1.0, 100.0, log=True),
        }

        from scipy.stats import spearmanr
        ics = []
        for train_idx, test_idx in cv_splits:
            train_mask = X.index.get_level_values(0).isin(train_idx)
            test_mask = X.index.get_level_values(0).isin(test_idx)
            X_train, y_train = X[train_mask], y[train_mask]
            X_test, y_test = X[test_mask], y[test_mask]

            try:
                import lightgbm as lgb
                model = lgb.LGBMRegressor(**params, random_state=42, verbosity=-1, n_jobs=1)
                model.fit(X_train.fillna(0).to_numpy(), y_train.to_numpy())
                pred = model.predict(X_test.fillna(0).to_numpy())
                ic, _ = spearmanr(pred, y_test.to_numpy())
                if np.isfinite(ic):
                    ics.append(ic)
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                continue

        return np.mean(ics) if ics else 0.0

    study = optuna.create_study(direction="maximize", sampler=optuna.samplers.TPESampler(seed=42))
    study.optimize(objective, n_trials=n_trials, show_progress_bar=False)

    best = study.best_params
    best["n_estimators"] = int(best["n_estimators"])
    logger.info(f"LightGBM optimization: best IC={study.best_value:.4f}")
    return best


def optimize_xgboost(
    X: pd.DataFrame,
    y: pd.Series,
    cv_splits: list[tuple[pd.DatetimeIndex, pd.DatetimeIndex]],
    n_trials: int = 50,
) -> dict:
    """Optimize XGBoost hyperparameters via Optuna."""
    if not _HAS_OPTUNA:
        return _default_xgboost_params()

    def objective(trial):
        params = {
            "n_estimators": trial.suggest_int("n_estimators", 50, 300),
            "learning_rate": trial.suggest_float("learning_rate", 0.005, 0.05, log=True),
            "max_depth": trial.suggest_int("max_depth", 3, 6),
            "min_child_weight": trial.suggest_int("min_child_weight", 50, 500),
            "subsample": trial.suggest_float("subsample", 0.5, 0.85),
            "colsample_bytree": trial.suggest_float("colsample_bytree", 0.5, 0.85),
            "reg_alpha": trial.suggest_float("reg_alpha", 0.1, 10.0, log=True),
            "reg_lambda": trial.suggest_float("reg_lambda", 1.0, 100.0, log=True),
        }

        from scipy.stats import spearmanr
        import platform as _pf
        if _pf.system() == "Darwin" and _pf.machine() == "arm64":
            return 0.0  # XGBoost segfaults on macOS ARM
        try:
            import xgboost as xgb
        except ImportError:
            import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
            return 0.0

        ics = []
        for train_idx, test_idx in cv_splits:
            train_mask = X.index.get_level_values(0).isin(train_idx)
            test_mask = X.index.get_level_values(0).isin(test_idx)
            X_train, y_train = X[train_mask], y[train_mask]
            X_test, y_test = X[test_mask], y[test_mask]

            try:
                model = xgb.XGBRegressor(**params, random_state=42, verbosity=0)
                model.fit(X_train.fillna(0).to_numpy(), y_train.to_numpy())
                pred = model.predict(X_test.fillna(0).to_numpy())
                ic, _ = spearmanr(pred, y_test.to_numpy())
                if np.isfinite(ic):
                    ics.append(ic)
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                continue

        return np.mean(ics) if ics else 0.0

    study = optuna.create_study(direction="maximize", sampler=optuna.samplers.TPESampler(seed=42))
    study.optimize(objective, n_trials=n_trials, show_progress_bar=False)

    best = study.best_params
    best["n_estimators"] = int(best["n_estimators"])
    logger.info(f"XGBoost optimization: best IC={study.best_value:.4f}")
    return best


def optimize_ridge(
    X: pd.DataFrame,
    y: pd.Series,
    cv_splits: list[tuple[pd.DatetimeIndex, pd.DatetimeIndex]],
    n_trials: int = 20,
) -> dict:
    """Optimize Ridge alpha via Optuna."""
    if not _HAS_OPTUNA:
        return {"alpha": 1.0}

    def objective(trial):
        alpha = trial.suggest_float("alpha", 0.001, 100.0, log=True)

        from scipy.stats import spearmanr
        from sklearn.linear_model import Ridge

        ics = []
        for train_idx, test_idx in cv_splits:
            train_mask = X.index.get_level_values(0).isin(train_idx)
            test_mask = X.index.get_level_values(0).isin(test_idx)
            X_train, y_train = X[train_mask], y[train_mask]
            X_test, y_test = X[test_mask], y[test_mask]

            try:
                model = Ridge(alpha=alpha)
                model.fit(X_train.fillna(0).to_numpy(), y_train.to_numpy())
                pred = model.predict(X_test.fillna(0).to_numpy())
                ic, _ = spearmanr(pred, y_test.to_numpy())
                if np.isfinite(ic):
                    ics.append(ic)
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                continue

        return np.mean(ics) if ics else 0.0

    study = optuna.create_study(direction="maximize", sampler=optuna.samplers.TPESampler(seed=42))
    study.optimize(objective, n_trials=n_trials, show_progress_bar=False)

    best = {"alpha": study.best_params["alpha"]}
    logger.info(f"Ridge optimization: best IC={study.best_value:.4f}")
    return best


def optimize_all_models(
    X: pd.DataFrame,
    y: pd.Series,
    cv_splits: list,
    n_trials: int = 50,
    use_cache: bool = True,
) -> dict:
    """Optimize hyperparameters for all models.

    Args:
        X: Feature matrix.
        y: Target series.
        cv_splits: List of (train_idx, test_idx) tuples.
        n_trials: Optuna trials per model.
        use_cache: If True, load/save best params from/to cache.

    Returns:
        Dict[model_name → best_hyperparams].
    """
    # Try to load from cache
    if use_cache and CACHE_PATH.exists():
        try:
            cached = json.loads(CACHE_PATH.read_text())
            logger.info(f"Loaded cached hyperparameters from {CACHE_PATH}")
            return cached
        except Exception:
            import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
            pass

    best_params = {}

    # Optimize each model
    try:
        best_params["ridge"] = optimize_ridge(X, y, cv_splits, n_trials=min(20, n_trials))
    except Exception as e:
        logger.warning(f"Ridge optimization failed: {e}", exc_info=True)
        best_params["ridge"] = _default_ridge_params()

    try:
        best_params["lightgbm"] = optimize_lightgbm(X, y, cv_splits, n_trials=n_trials)
    except Exception as e:
        logger.warning(f"LightGBM optimization failed: {e}", exc_info=True)
        best_params["lightgbm"] = _default_lightgbm_params()

    # XGBoost optimization SKIPPED by default — segfaults on macOS ARM (Apple Silicon)
    # Native C++ crash cannot be caught by try/except. Enable only on Linux/x86.
    import platform
    _is_macos_arm = platform.system() == "Darwin" and platform.machine() == "arm64"
    if not _is_macos_arm:
        try:
            best_params["xgboost"] = optimize_xgboost(X, y, cv_splits, n_trials=n_trials)
        except Exception as e:
            logger.warning(f"XGBoost optimization failed: {e}", exc_info=True)
            best_params["xgboost"] = _default_xgboost_params()
    else:
        logger.info("XGBoost optimization skipped on macOS ARM (known segfault)")
        best_params["xgboost"] = _default_xgboost_params()

    # ElasticNet and Bayesian Ridge use defaults (fewer hyperparams)
    best_params["elasticnet"] = _default_elasticnet_params()
    best_params["bayesian_ridge"] = {}

    # Save to cache
    if use_cache:
        try:
            CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
            CACHE_PATH.write_text(json.dumps(best_params, indent=2))
            logger.info(f"Saved cached hyperparameters to {CACHE_PATH}")
        except Exception as e:
            logger.warning(f"Failed to cache hyperparameters: {e}", exc_info=True)

    return best_params


# ═══════════════════════════════════════════════════════════════════════════════
# DEFAULT PARAMETER VALUES (fallbacks if Optuna not installed)
# ═══════════════════════════════════════════════════════════════════════════════

def _default_ridge_params() -> dict:
    return {"alpha": 1.0}

def _default_lightgbm_params() -> dict:
    # Conservative defaults — higher regularization than before to match
    # the widened search bounds (reg_lambda up to 100) so fallbacks don't
    # suddenly become the least-regularized option.
    return {
        "n_estimators": 100,
        "learning_rate": 0.02,
        "num_leaves": 15,
        "max_depth": 5,
        "min_child_samples": 100,
        "subsample": 0.7,
        "colsample_bytree": 0.7,
        "reg_alpha": 1.0,
        "reg_lambda": 20.0,
    }

def _default_xgboost_params() -> dict:
    return {
        "n_estimators": 100,
        "learning_rate": 0.02,
        "max_depth": 5,
        "min_child_weight": 100,
        "subsample": 0.7,
        "colsample_bytree": 0.7,
        "reg_alpha": 1.0,
        "reg_lambda": 20.0,
    }

def _default_elasticnet_params() -> dict:
    return {"alpha": 0.1, "l1_ratio": 0.5, "max_iter": 5000, "random_state": 42}
