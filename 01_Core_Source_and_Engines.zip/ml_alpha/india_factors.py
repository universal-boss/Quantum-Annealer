"""
India-Specific Alpha Factors — R41 Institutional Upgrade
=========================================================

These factors have documented and empirically-tested predictive power in
Indian equity markets. Unlike generic momentum/vol factors (which are
increasingly arbitraged globally), India-specific factors exploit local
market microstructure, regulatory disclosures, and behavioral patterns.

Factor Catalogue:
  1.  delivery_pct_trend_21     — Rising delivery % = institutional accumulation
  2.  fii_net_flow_zscore        — FII sector net flow (z-scored vs 63d history)
  3.  pead_60d                   — Post-earnings announcement drift (60-day window)
  4.  promoter_pledge_delta_63   — Falling pledge = risk reduction / confidence signal
  5.  short_interest_cover       — F&O OI days-to-cover (short squeeze predictor)
  6.  residual_momentum_6m       — Momentum with sector + beta removed (pure alpha)
  7.  earnings_quality_accrual   — Cash earnings vs reported (Sloan accruals proxy)
  8.  price_to_52w_high_rank_cs  — Cross-sectional rank of proximity to 52W high
  9.  vol_regime_factor          — Volatility regime: recent vs long-term vol ratio
  10. inflow_breadth_20          — Breadth of delivery vs share volume across days

All factors:
  - Fully vectorized (no per-ticker loops inside time-series window)
  - PIT-correct: rolling windows use only backward-looking data
  - Gracefully return empty Series if data is unavailable (no crash)
  - Compatible with compute_all_factors() output format
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import logging

logger = logging.getLogger(__name__)


# ── 1. Delivery % Trend ────────────────────────────────────────────────────────

def delivery_pct_trend_21(
    delivery_pct: pd.Series,
    n: int = 21,
) -> pd.Series:
    """21-day trend in delivery-to-traded volume ratio.

    Rising delivery% signals institutional accumulation — smart money is
    taking delivery, not trading for quick profits. Highly effective in
    India where delivery data is publicly available from NSE bhav copies.

    Args:
        delivery_pct: Daily delivery % series for a ticker (range 0-100).
        n: Lookback window in trading days.

    Returns:
        Rolling z-score of delivery % relative to its own 63-day baseline.
    """
    if delivery_pct is None or len(delivery_pct) < max(n, 63):
        return pd.Series(dtype=float)
    baseline_mean = delivery_pct.rolling(63).mean()
    baseline_std  = delivery_pct.rolling(63).std().replace(0, np.nan)
    zscore = (delivery_pct.rolling(n).mean() - baseline_mean) / baseline_std
    return zscore.replace([np.inf, -np.inf], np.nan).dropna()


# ── 2. FII Net Flow Z-Score ─────────────────────────────────────────────────

def fii_net_flow_zscore(
    fii_net: pd.Series,
    n: int = 5,
    lookback: int = 63,
) -> pd.Series:
    """FII net buying z-score (5-day sum vs 63-day distribution).

    Sustained FII net buying predicts 10-20 day forward returns in NSE.
    The z-score normalizes for changing market cap (prevents currency-size
    bias in the raw INR flow figure).

    Args:
        fii_net: Daily net FII flow in INR crore (positive = buying).
        n: Sum window (trading days).
        lookback: Distribution lookback.

    Returns:
        Rolling z-score of recent FII flow vs historical baseline.
    """
    if fii_net is None or len(fii_net) < lookback:
        return pd.Series(dtype=float)
    rolling_sum = fii_net.rolling(n).sum()
    hist_mean   = rolling_sum.rolling(lookback).mean()
    hist_std    = rolling_sum.rolling(lookback).std().replace(0, np.nan)
    return ((rolling_sum - hist_mean) / hist_std).replace([np.inf, -np.inf], np.nan).dropna()


# ── 3. Post-Earnings Announcement Drift (PEAD) ─────────────────────────────

def pead_60d(
    close: pd.Series,
    earnings_dates: list | pd.DatetimeIndex | None = None,
    drift_window: int = 60,
    min_gap_days: int = 5,
) -> pd.Series:
    """Post-earnings drift momentum: cumulative return starting min_gap_days
    after each earnings announcement, measured over drift_window trading days.

    PEAD is one of the most robust anomalies in Indian markets — earnings
    surprises continue to drift for 40-90 days post-announcement due to
    under-reaction by retail investors. It is particularly strong for
    mid/small cap stocks where analyst coverage is thin.

    Args:
        close: Closing price series.
        earnings_dates: List of earnings announcement dates for this ticker.
        drift_window: Days after announcement to measure drift.
        min_gap_days: Skip this many days post-announcement (avoids bid/ask).

    Returns:
        Drift-return series: for each trading day inside a
        [announcement+min_gap, announcement+drift_window] window, the
        cumulative return since the announcement date (close_t / close_ann - 1);
        NaN outside any window. The drift values themselves are
        point-in-time-safe (no future information).
        (ROUND 45: the docstring previously promised a binary 0/1 signal that
        the implementation never produced — the returned values have always
        been drift returns.)
    """
    if close is None or len(close) < drift_window:
        return pd.Series(dtype=float)
    if not earnings_dates:
        # No earnings calendar — return a synthetic PEAD proxy using quarterly
        # intervals (NSE Q1/Q2/Q3/Q4 cycle: Apr, Jul, Oct, Jan)
        # This captures the broad drift pattern without exact date data
        quarter_ends = pd.DatetimeIndex(
            [d for d in close.index
             if d.month in (4, 7, 10, 1) and d.day <= 7]
        )
        earnings_dates = quarter_ends

    try:
        earnings_dates = pd.DatetimeIndex(earnings_dates)
    except Exception:
        return pd.Series(dtype=float)

    # ROUND 45 FIX: the binary-signal loop below was DEAD CODE — `signal` was
    # built and never read — while the docstring promised a 0/1 gating signal.
    # The function has always returned the drift return since announcement;
    # the docstring now describes the actual (point-in-time-safe) output and
    # the dead loop is removed.
    result = pd.Series(dtype=float, index=close.index)
    for ed in earnings_dates:
        ann_idx = close.index.searchsorted(ed)
        if ann_idx >= len(close):
            continue
        ann_price = close.iloc[ann_idx] if ann_idx < len(close) else np.nan
        if not np.isfinite(ann_price) or ann_price <= 0:
            continue
        start_idx = ann_idx + min_gap_days
        end_idx   = ann_idx + drift_window
        if start_idx >= len(close):
            continue
        for i in range(start_idx, min(end_idx + 1, len(close))):
            drift_ret = (close.iloc[i] / ann_price) - 1.0
            result.iloc[i] = drift_ret

    return result.replace([np.inf, -np.inf], np.nan).dropna()


# ── 4. Promoter Pledge Delta ────────────────────────────────────────────────

def promoter_pledge_delta_63(
    pledge_pct: pd.Series,
    n: int = 63,
) -> pd.Series:
    """Change in promoter pledge percentage over 63 trading days.

    Falling pledge % = promoters are REDUCING their pledge (financial stress
    is easing, or they are prepaying loans). This is a strong positive signal
    in Indian markets where pledging is a major risk factor.

    Positive return → rising pledge (bearish).
    Negative return → falling pledge (bullish — invert for use as alpha).

    We return (−delta) so higher values = more bullish.

    Args:
        pledge_pct: Quarterly/monthly promoter pledge % series.
        n: Lookback window.

    Returns:
        Negative of the 63-day change in pledge % (higher = falling pledge = good).
    """
    if pledge_pct is None or len(pledge_pct) < n:
        return pd.Series(dtype=float)
    delta = pledge_pct - pledge_pct.shift(n)
    return (-delta).replace([np.inf, -np.inf], np.nan).dropna()


# ── 5. Short Interest Days-to-Cover ─────────────────────────────────────────

def short_interest_cover(
    open_interest: pd.Series,
    volume: pd.Series,
    n: int = 5,
) -> pd.Series:
    """F&O open interest days-to-cover: OI / average daily volume.

    High short interest (measured via F&O put OI or short positions) with
    high days-to-cover predicts short squeeze potential in Indian markets.
    Stocks where shorts take >7 days to cover show reversal premium.

    Args:
        open_interest: Daily futures/put open interest in shares.
        volume: Daily trading volume.
        n: Volume averaging window.

    Returns:
        Days-to-cover: OI / avg_volume_n. Higher = more squeeze potential.
    """
    if open_interest is None or volume is None or len(volume) < n:
        return pd.Series(dtype=float)
    common = open_interest.index.intersection(volume.index)
    oi = open_interest.loc[common]
    vol = volume.loc[common]
    avg_vol = vol.rolling(n).mean().replace(0, np.nan)
    dtc = (oi / avg_vol).replace([np.inf, -np.inf], np.nan)
    return dtc.dropna()


# ── 6. Residual Momentum (sector + beta neutral) ────────────────────────────

def residual_momentum_6m(
    close: pd.Series,
    benchmark: pd.Series | None = None,
    sector_return: pd.Series | None = None,
) -> pd.Series:
    """6-month momentum with benchmark beta and sector return removed.

    Pure idiosyncratic alpha: the part of momentum NOT explained by the
    market or the sector. This reduces turnover and improves Sharpe vs
    raw momentum, as sector momentum is mean-reverting at 6-12m horizons
    while residual momentum persists for 3-6 months.

    Args:
        close: Closing price series.
        benchmark: Nifty 500 or broad market index.
        sector_return: Sector index return series.

    Returns:
        Rolling 6-month residual momentum (annualized).
    """
    if close is None or len(close) < 126:
        return pd.Series(dtype=float)

    raw_mom = (close.shift(21) / close.shift(126) - 1.0)

    if benchmark is not None and len(benchmark) >= 126:
        common = close.index.intersection(benchmark.index)
        if len(common) >= 126:
            bm_mom = (benchmark.shift(21) / benchmark.shift(126) - 1.0).reindex(common)
            stk_rets = close.pct_change().reindex(common)
            bm_rets  = benchmark.pct_change().reindex(common)
            # Rolling beta: 63-day
            cov = stk_rets.rolling(63).cov(bm_rets)
            var = bm_rets.rolling(63).var().replace(0, np.nan)
            beta = (cov / var).clip(-3, 3)
            bm_contribution = beta * bm_mom.reindex(close.index)
            raw_mom = raw_mom - bm_contribution

    if sector_return is not None and len(sector_return) >= 63:
        common2 = close.index.intersection(sector_return.index)
        if len(common2) >= 63:
            # ROUND 45 FIX: the sector term used a 63-day window against the
            # 126-day stock momentum (docstring: "6-month momentum with ... sector
            # return removed") — months 3-6 of sector exposure stayed un-hedged.
            # Now the same 21/126 construction as the stock and benchmark terms.
            sec_mom = (sector_return.shift(21) / sector_return.shift(126) - 1.0).reindex(close.index)
            raw_mom = raw_mom - 0.5 * sec_mom

    return raw_mom.replace([np.inf, -np.inf], np.nan).dropna()


# ── 7. Earnings Quality — Accruals (Sloan 1996) ─────────────────────────────

def earnings_quality_accrual(
    net_income: pd.Series,
    operating_cash_flow: pd.Series,
    total_assets: pd.Series,
) -> pd.Series:
    """Cash earnings vs reported earnings (Sloan accruals ratio).

    Sloan (1996): Firms with high accruals (reported earnings >> cash earnings)
    have lower future returns — accruals are mean-reverting and management uses
    them to inflate reported earnings. This is especially powerful in India
    where accounting conservatism varies widely across companies.

    Accrual ratio = (Net Income − Operating Cash Flow) / Total Assets
    Higher accrual → more earnings inflation → lower future returns
    Signal = −accrual_ratio (higher = better cash earnings quality)

    Args:
        net_income: Annual/TTM net income in INR.
        operating_cash_flow: Annual/TTM operating cash flow in INR.
        total_assets: Total assets in INR (normalizer).

    Returns:
        Negative accrual ratio (higher = better earnings quality).
    """
    if any(x is None for x in [net_income, operating_cash_flow, total_assets]):
        return pd.Series(dtype=float)
    common = net_income.index.intersection(operating_cash_flow.index).intersection(total_assets.index)
    if len(common) < 4:
        return pd.Series(dtype=float)
    ni  = net_income.loc[common]
    ocf = operating_cash_flow.loc[common]
    ta  = total_assets.loc[common].replace(0, np.nan)
    accrual = (ni - ocf) / ta
    return (-accrual).replace([np.inf, -np.inf], np.nan).dropna()


# ── 8. Cross-Sectional 52W High Rank ─────────────────────────────────────────

def price_to_52w_high_rank_cs(
    close: pd.Series,
) -> pd.Series:
    """Distance from 52-week high as a cross-sectional alpha factor.

    George & Hwang (2004): The 52-week high is a reference point for investors.
    Stocks close to their 52W high → anchoring prevents buying → subsequent
    outperformance when the anchor is broken. This differs from breakout_252
    which measures being AT the high; this captures the approach to the high.

    Args:
        close: Closing price series.

    Returns:
        1 − (distance from 52W high), i.e. closer to high → higher score.
        Range [0, 1] where 1.0 = AT the 52-week high.
    """
    if close is None or len(close) < 252:
        return pd.Series(dtype=float)
    high_52w = close.rolling(252).max()
    proximity = close / high_52w  # 1.0 = at the high, <1.0 = below
    return proximity.clip(0, 1).dropna()


# ── 9. Volatility Regime Factor ──────────────────────────────────────────────

def vol_regime_factor(
    close: pd.Series,
    short_window: int = 21,
    long_window: int = 126,
) -> pd.Series:
    """Volatility compression ratio: short-term vol / long-term vol.

    Volatility compression (short vol < long vol) precedes breakouts.
    This factor identifies stocks in "coiled spring" setups where realized
    volatility has contracted significantly below its longer-term average.

    Returns:
        short_vol / long_vol. Values < 0.5 = extreme compression (bullish for
        breakout strategies), values > 1.5 = expanding vol (momentum regime).
    """
    if close is None or len(close) < long_window:
        return pd.Series(dtype=float)
    log_rets = np.log(close / close.shift(1))
    short_vol = log_rets.rolling(short_window).std() * np.sqrt(252)
    long_vol  = log_rets.rolling(long_window).std() * np.sqrt(252)
    ratio = (short_vol / long_vol.replace(0, np.nan)).replace([np.inf, -np.inf], np.nan)
    return ratio.dropna()


# ── 10. Delivery Breadth ────────────────────────────────────────────────────

def inflow_breadth_20(
    delivery_pct: pd.Series,
    volume: pd.Series,
    n: int = 20,
) -> pd.Series:
    """Count of days with above-median delivery % in past n days.

    Consistent high-delivery days (not just one spike) signals sustained
    institutional accumulation vs a single large block trade.

    Args:
        delivery_pct: Daily delivery % series.
        volume: Daily volume (for volume-weighting the signal).
        n: Lookback window.

    Returns:
        Fraction of days in n-day window with above-65th-percentile delivery %.
    """
    if delivery_pct is None or len(delivery_pct) < n:
        return pd.Series(dtype=float)
    p65 = delivery_pct.rolling(63).quantile(0.65)
    # ROUND 45 FIX (two defects):
    # (a) For rows where the 63-day p65 baseline does not exist yet,
    #     `delivery_pct > NaN` evaluates to False — a hard 0.0 ("zero
    #     accumulation-breadth days") was fabricated for the first ~43 rows
    #     of every ticker and flowed into the factor panel. Now masked to NaN.
    # (b) The documented volume-weighting was not implemented (the `volume`
    #     parameter was accepted and ignored). Now the breadth fraction is
    #     volume-weighted: sum(volume on above-p65 days) / sum(volume) over
    #     the window.
    above = (delivery_pct > p65).where(p65.notna()).astype(float)
    vol = volume.reindex(above.index) if volume is not None else None
    if vol is None:
        return above.rolling(n).mean().dropna()
    vol = pd.to_numeric(vol, errors="coerce").fillna(0.0)
    weighted = (above * vol).rolling(n).sum()
    total = vol.rolling(n).sum()
    return (weighted / total.replace(0.0, np.nan)).replace([np.inf, -np.inf], np.nan).dropna()


# ═══════════════════════════════════════════════════════════════════════════════
# BULK COMPUTATION — mirrors compute_all_factors() signature in factors.py
# ═══════════════════════════════════════════════════════════════════════════════

INDIA_FACTOR_NAMES = [
    "delivery_pct_trend_21",   # 1. Delivery % accumulation trend
    "residual_momentum_6m",    # 2. Beta/sector-neutral 6m momentum
    "price_to_52w_high_rank",  # 3. Proximity to 52-week high
    "vol_regime_factor",       # 4. Volatility compression (coiled spring)
    "inflow_breadth_20",       # 5. Sustained delivery breadth
    # Below require additional data feeds (earnings, FII, fundamentals):
    # "fii_net_flow_zscore"    # Needs FII flow data by sector/stock
    # "pead_60d"               # Needs earnings calendar
    # "promoter_pledge_delta"  # Needs quarterly pledge disclosures
    # "short_interest_cover"   # Needs F&O OI data
    # "earnings_quality_accrual" # Needs cash flow statements
]


def compute_india_factors(
    panel: dict[str, pd.DataFrame],
    tickers: list[str],
    benchmark: pd.Series | None = None,
    delivery_panel: pd.DataFrame | None = None,
    fii_flow: pd.Series | None = None,
    earnings_dates: dict[str, list] | None = None,
) -> dict[str, pd.DataFrame]:
    """Compute India-specific factors for all tickers.

    Args:
        panel: Standard OHLCV panel dict (same as compute_all_factors).
        tickers: List of ticker symbols.
        benchmark: Broad market index (Nifty 500 or ^CRSLDX).
        delivery_panel: DataFrame[date × ticker] of delivery % from NSE bhav.
        fii_flow: Aggregate daily FII net flow series (market-wide).
        earnings_dates: Dict mapping ticker → list of earnings announcement dates.

    Returns:
        Dict mapping factor_name → DataFrame[date × ticker].
    """
    close_panel = panel.get("Close", panel.get("close", pd.DataFrame())) if isinstance(panel, dict) else panel
    volume_panel = panel.get("Volume", panel.get("volume", pd.DataFrame())) if isinstance(panel, dict) else pd.DataFrame()

    # Master date index = union of all tickers' close dates
    master_idx: pd.DatetimeIndex = pd.DatetimeIndex([])
    if isinstance(close_panel, pd.DataFrame):
        for t in tickers:
            if t in close_panel.columns:
                master_idx = master_idx.union(close_panel[t].dropna().index)
    master_idx = master_idx.sort_values()

    results: dict[str, pd.DataFrame] = {}

    for ticker in tickers:
        # Extract price series
        close = (close_panel[ticker].dropna()
                 if isinstance(close_panel, pd.DataFrame) and ticker in close_panel.columns
                 else pd.Series(dtype=float))
        volume = (volume_panel[ticker].dropna()
                  if isinstance(volume_panel, pd.DataFrame) and ticker in volume_panel.columns
                  else pd.Series(dtype=float))
        delivery = (delivery_panel[ticker].dropna()
                    if delivery_panel is not None and isinstance(delivery_panel, pd.DataFrame)
                    and ticker in delivery_panel.columns
                    else None)

        if len(close) < 20:
            continue

        ticker_factors: dict[str, pd.Series] = {}

        # 1. Delivery trend (requires delivery data)
        if delivery is not None and len(delivery) >= 63:
            _f = delivery_pct_trend_21(delivery)
            if len(_f) > 0:
                ticker_factors["delivery_pct_trend_21"] = _f
            _fb = inflow_breadth_20(delivery, volume if len(volume) > 20 else None)
            if len(_fb) > 0:
                ticker_factors["inflow_breadth_20"] = _fb

        # 2. Residual momentum
        _rm = residual_momentum_6m(close, benchmark)
        if len(_rm) > 0:
            ticker_factors["residual_momentum_6m"] = _rm

        # 3. 52W high rank
        _52 = price_to_52w_high_rank_cs(close)
        if len(_52) > 0:
            ticker_factors["price_to_52w_high_rank"] = _52

        # 4. Vol regime
        _vr = vol_regime_factor(close)
        if len(_vr) > 0:
            ticker_factors["vol_regime_factor"] = _vr

        # 5. PEAD (if earnings calendar available)
        if earnings_dates and ticker in earnings_dates:
            _pe = pead_60d(close, earnings_dates[ticker])
            if len(_pe) > 0:
                ticker_factors["pead_60d"] = _pe

        # Assign to results DataFrames
        for fname, ts in ticker_factors.items():
            if len(ts) == 0:
                continue
            ts_reindexed = ts.reindex(master_idx)
            if fname not in results:
                results[fname] = pd.DataFrame(index=master_idx)
            results[fname][ticker] = ts_reindexed

    logger.info("[IndiaFactors] Computed %d India-specific factor panels for %d tickers",
                len(results), len(tickers))
    return results
