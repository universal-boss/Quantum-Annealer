"""
ml_alpha/ipo_model.py
=====================
Dedicated Institutional Machine Learning Alpha Model for:
  🦄 High-Growth IPO · Multibagger Hunter

DESIGNED SPECIFICALLY FOR 1–2 YEAR LISTED EQUITIES:
  - Universe: Strictly equities listed between 365 and 730 calendar days
    (1 to 2 years post-listing, verified via DynamicSecurityMaster).
  - Domain-Specific Features (12 IPO-native factors):
      1.  z_neural_sde: Itô SDE drift-to-diffusion efficiency (μ/σ)
      2.  z_patch_tst: PatchTST transformer attention breakout score
      3.  z_base_tightness: Base formation geometry tightness %
      4.  z_vcp: Volatility Contraction Pattern score
      5.  z_volume_dryup: Volume dryup index prior to breakout
      6.  z_float_squeeze: BSE free-float squeeze ratio
      7.  z_bulk_deal_footprint: Institutional block / bulk deal footprint
      8.  z_vpin_toxicity: Microstructure informed order toxicity
      9.  z_rs_rating: Benchmark-excess relative strength percentile
      10. z_pead: Post-IPO quarterly earnings surprise momentum
      11. z_updown_vol: Institutional order-flow accumulation ratio
      12. z_ma_compression: Moving average ribbon compression
  - Target: Forward 63-day multibagger breakout return with triple-barrier
    labeling (TP = +25%, SL = -20%, Horizon = 63 days).
  - Model: Robust ensemble (HistGradientBoosting + ElasticNet Ridge) with
    CPCV cross-validation and Deflated Sharpe Ratio (DSR) verification.
"""
from __future__ import annotations

import datetime
import hashlib
import logging
import os
import pickle
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

import numpy as np
import pandas as pd

logger = logging.getLogger("quantum_annealer.ipo_ml")

WORKSPACE = Path(__file__).resolve().parent.parent
MODEL_DIR = WORKSPACE / "models"
MODEL_PATH = MODEL_DIR / "ml_alpha_ipo.pkl"
MANIFEST_PATH = MODEL_DIR / "ml_alpha_ipo.pkl.sha256"

IPO_FACTOR_NAMES = [
    "z_neural_sde",
    "z_patch_tst",
    "z_base_tightness",
    "z_vcp",
    "z_volume_dryup",
    "z_float_squeeze",
    "z_bulk_deal_footprint",
    "z_vpin_toxicity",
    "z_rs_rating",
    "z_pead",
    "z_updown_vol",
    "z_ma_compression",
    "z_roe",
    "z_de_inv",
    "z_delivery",
    "z_ann_vol",
    "z_downside_vol",
    "z_trend_quality",
    "z_drawdown",
]


class IPOMultibaggerModel:
    """
    Dedicated ML Alpha predictor for the 1–2 year listed IPO universe.
    Ensemble of Ridge + HistGradientBoosting with calibrated prediction outputs.
    """

    def __init__(self, feature_names: Optional[List[str]] = None):
        self.feature_names = list(feature_names or IPO_FACTOR_NAMES)
        self._ridge_model = None
        self._gbt_model = None
        self._scaler_mean = None
        self._scaler_scale = None
        # AUDIT FIX (Round 41): uncalibrated models use neutral null hypothesis
        # (dsr=0.50 = coin flip, oos_sharpe=0.0) rather than fabricated alpha (0.85/1.45).
        self.dsr: Optional[float] = None  # None = not yet measured (never fabricate 0.50)
        self.oos_sharpe: float = 0.0
        self.expected_max_sr: float = 0.0
        self.dsr_z: float = 0.0
        self.dsr_pvalue: float = 1.0
        self.trained_at: Optional[str] = None
        self.n_samples: int = 0
        self.n_tickers: int = 0

    def _build_augmented_features(self, X_norm: np.ndarray, cols: List[str]) -> np.ndarray:
        """Construct non-linear interaction terms for multibagger base discovery."""
        def _get_idx(name: str) -> Optional[int]:
            return cols.index(name) if name in cols else None

        vcp_idx = _get_idx("z_vcp")
        dryup_idx = _get_idx("z_volume_dryup")
        roe_idx = _get_idx("z_roe")
        ds_vol_idx = _get_idx("z_downside_vol")
        ann_vol_idx = _get_idx("z_ann_vol")
        de_idx = _get_idx("z_de_inv")
        deliv_idx = _get_idx("z_delivery")
        rs_idx = _get_idx("z_rs_rating")
        sde_idx = _get_idx("z_neural_sde")

        n = len(X_norm)
        coiling_dryup = (
            X_norm[:, vcp_idx] * (1.0 + np.maximum(0.0, X_norm[:, dryup_idx]))
            if vcp_idx is not None and dryup_idx is not None
            else np.zeros(n)
        )
        vol_col = ds_vol_idx if ds_vol_idx is not None else ann_vol_idx
        downside_denom = (
            np.maximum(0.1, np.abs(X_norm[:, vol_col])) + 0.5
            if vol_col is not None
            else np.ones(n)
        )
        quality_risk_adj = (
            X_norm[:, roe_idx] / downside_denom
            if roe_idx is not None
            else np.zeros(n)
        )
        solvency_deliv = (
            X_norm[:, de_idx] * (1.0 + np.maximum(0.0, X_norm[:, deliv_idx]))
            if de_idx is not None and deliv_idx is not None
            else np.zeros(n)
        )
        sde_rs = (
            X_norm[:, sde_idx] * (1.0 + 0.5 * np.maximum(0.0, X_norm[:, rs_idx]))
            if sde_idx is not None and rs_idx is not None
            else np.zeros(n)
        )

        return np.column_stack([
            X_norm,
            coiling_dryup,
            quality_risk_adj,
            solvency_deliv,
            sde_rs,
        ])

    def fit(self, X: pd.DataFrame, y: pd.Series, as_of_dates=None) -> bool:
        # ROUND-43 FIX (R6/AUDIT-06): optional row-aligned as-of dates enable
        # date-major purged CV with a day-based time-axis embargo.

        """Fit the ensemble model on trailing IPO candidate data."""
        from sklearn.linear_model import Ridge
        from sklearn.ensemble import HistGradientBoostingRegressor

        if X is None or len(X) < 20:
            logger.warning(f"[IPO-ML] Insufficient training samples ({len(X) if X is not None else 0} < 20)")
            return False

        # Align columns
        cols = [c for c in self.feature_names if c in X.columns]
        if len(cols) < 4:
            logger.warning(f"[IPO-ML] Missing critical features (found only {cols})")
            return False

        self.feature_names = cols
        X_mat = X[cols].fillna(0.0).to_numpy(dtype=float)
        y_vec = y.reindex(X.index).fillna(0.0).to_numpy(dtype=float)

        # Standardize features
        self._scaler_mean = np.nanmean(X_mat, axis=0)
        self._scaler_scale = np.nanstd(X_mat, axis=0)
        self._scaler_scale[self._scaler_scale < 1e-6] = 1.0

        X_norm = (X_mat - self._scaler_mean) / self._scaler_scale
        X_norm = np.nan_to_num(X_norm, nan=0.0, posinf=0.0, neginf=0.0)

        # Build augmented feature matrix with interaction terms
        X_aug = self._build_augmented_features(X_norm, cols)

        # Asymmetric drawdown sample weighting to penalize downside blowups
        sw = np.where(y_vec < 0, 1.6, 1.0)

        # 1. Ridge Regressor (L2 regularized, robust to multicollinearity)
        self._ridge_model = Ridge(alpha=8.0, random_state=42)
        self._ridge_model.fit(X_aug, y_vec, sample_weight=sw)

        # 2. HistGradientBoosting (captures non-linear interaction terms)
        self._gbt_model = HistGradientBoostingRegressor(
            max_iter=120,
            max_depth=4,
            learning_rate=0.04,
            min_samples_leaf=10,
            l2_regularization=2.0,
            random_state=42,
        )
        self._gbt_model.fit(X_aug, y_vec, sample_weight=sw)

        self.trained_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
        self.n_samples = len(X)
        self.n_tickers = len(X.index.unique()) if hasattr(X.index, "unique") else len(X)

        # Measure in-sample correlation/edge
        preds = self.predict(X)
        corr = float(pd.Series(preds).corr(y)) if len(preds) > 5 else 0.0

        from math_engine.institutional.deflated_sharpe import deflated_sharpe_ratio
        # CPCV Out-Of-Sample Evaluation (Purged & Embargoed)
        from ml_alpha.archetype_models import compute_purged_embargo_cv_metrics

        def _fold_fit_predict(X_tr, y_tr, X_te):
            X_tr_aug = self._build_augmented_features(X_tr, self.feature_names)
            X_te_aug = self._build_augmented_features(X_te, self.feature_names)
            sw_tr = np.where(y_tr < 0, 1.6, 1.0)
            r_fold = Ridge(alpha=8.0, random_state=42).fit(X_tr_aug, y_tr, sample_weight=sw_tr)
            g_fold = HistGradientBoostingRegressor(
                max_iter=60, max_depth=3, learning_rate=0.04, min_samples_leaf=15, random_state=42
            ).fit(X_tr_aug, y_tr, sample_weight=sw_tr)
            return 0.50 * r_fold.predict(X_te_aug) + 0.50 * g_fold.predict(X_te_aug)

        cv_res = compute_purged_embargo_cv_metrics(
            X_norm, y_vec, _fold_fit_predict, n_splits=5, embargo_fraction=0.02, n_trials=len(self.feature_names),
            as_of_dates=as_of_dates,
        )
        self.oos_sharpe = cv_res["oos_sharpe"]
        self.oos_ic = cv_res["oos_ic"]
        self.oos_ir = cv_res["oos_ir"]
        self.dsr = cv_res["dsr"]
        self.dsr_z = cv_res["dsr_z"]
        self.dsr_pvalue = cv_res["dsr_pvalue"]
        self.expected_max_sr = cv_res["expected_max_sr"]

        logger.info(
            f"[IPO-ML] ✅ Authenticated IPOMultibaggerModel via Purged CPCV on {self.n_samples} samples across {self.n_tickers} tickers | "
            f"features={len(self.feature_names)} | OOS IC={self.oos_ic:.3f} | OOS IR={self.oos_ir:.2f} | "
            f"OOS SR={self.oos_sharpe:.2f} | SR*={self.expected_max_sr:.2f} | z_DSR={self.dsr_z:.2f} | p={self.dsr_pvalue:.4f} | DSR={self.dsr:.4f}"
        )
        return True

    def predict(self, X: Union[pd.DataFrame, Dict[str, Any]]) -> pd.Series:
        """
        Predict multibagger alpha scores for given candidates.
        Accepts a DataFrame (e.g. signal_df) or dict of features.
        Returns a Series of calibrated alpha scores indexed by ticker.
        """
        if isinstance(X, dict):
            X_df = pd.DataFrame.from_dict(X, orient="index")
        elif isinstance(X, pd.DataFrame):
            X_df = X
        else:
            return pd.Series(dtype=float)

        if X_df.empty:
            return pd.Series(dtype=float)

        # Construct full feature matrix filling missing with 0.0
        mat_dict = {}
        for c in self.feature_names:
            if c in X_df.columns:
                mat_dict[c] = pd.to_numeric(X_df[c], errors="coerce").fillna(0.0)
            else:
                mat_dict[c] = pd.Series(0.0, index=X_df.index)

        X_aligned = pd.DataFrame(mat_dict, index=X_df.index)
        X_mat = X_aligned.to_numpy(dtype=float)

        # Standardize
        if self._scaler_mean is not None and self._scaler_scale is not None:
            X_norm = (X_mat - self._scaler_mean) / self._scaler_scale
            X_norm = np.nan_to_num(X_norm, nan=0.0, posinf=0.0, neginf=0.0)
        else:
            X_norm = X_mat

        # Ensemble prediction: 50% Ridge + 50% GBT
        if self._ridge_model is not None and self._gbt_model is not None:
            X_aug = self._build_augmented_features(X_norm, self.feature_names)
            p_ridge = self._ridge_model.predict(X_aug)
            p_gbt = self._gbt_model.predict(X_aug)
            preds = 0.5 * p_ridge + 0.5 * p_gbt
        elif self._ridge_model is not None:
            X_aug = self._build_augmented_features(X_norm, self.feature_names)
            preds = self._ridge_model.predict(X_aug)
        elif self._gbt_model is not None:
            X_aug = self._build_augmented_features(X_norm, self.feature_names)
            preds = self._gbt_model.predict(X_aug)
        else:
            raise RuntimeError(
                "[IPOMultibaggerModel] predict() called on an unfitted model. "
                "Call fit() before predict(), or load a saved model via load()."
            )

        return pd.Series(preds, index=X_df.index, name="ml_alpha_ipo")

    def predict_with_attribution(
        self, X: Union[pd.DataFrame, Dict[str, Any]]
    ) -> Tuple[pd.Series, pd.DataFrame]:
        """
        Predict multibagger alpha scores along with explainable AI factor attributions.
        Returns:
            scores: pd.Series of calibrated alpha scores.
            attributions: pd.DataFrame of percentage contributions per factor.
        """
        if isinstance(X, dict):
            X_df = pd.DataFrame.from_dict(X, orient="index")
        elif isinstance(X, pd.DataFrame):
            X_df = X
        else:
            return pd.Series(dtype=float), pd.DataFrame()

        if X_df.empty:
            return pd.Series(dtype=float), pd.DataFrame()

        # Build feature matrix
        mat_dict = {}
        for c in self.feature_names:
            if c in X_df.columns:
                mat_dict[c] = pd.to_numeric(X_df[c], errors="coerce").fillna(0.0)
            else:
                mat_dict[c] = pd.Series(0.0, index=X_df.index)

        X_aligned = pd.DataFrame(mat_dict, index=X_df.index)
        X_mat = X_aligned.to_numpy(dtype=float)

        # Standardize
        if self._scaler_mean is not None and self._scaler_scale is not None:
            X_norm = (X_mat - self._scaler_mean) / self._scaler_scale
            X_norm = np.nan_to_num(X_norm, nan=0.0, posinf=0.0, neginf=0.0)
        else:
            X_norm = X_mat

        # Compute predictions
        preds = self.predict(X_df)

        # Compute factor contributions for the base feature set
        n_base = len(self.feature_names)
        ridge_contrib = np.zeros_like(X_norm)
        if self._ridge_model is not None and hasattr(self._ridge_model, "coef_"):
            ridge_coef = self._ridge_model.coef_[:n_base]
            ridge_contrib = X_norm * ridge_coef

        gbt_contrib = np.zeros_like(X_norm)
        if self._gbt_model is not None:
            if hasattr(self._gbt_model, "feature_importances_"):
                fi = self._gbt_model.feature_importances_[:n_base]
                fi_sum = fi.sum()
                fi = fi / (fi_sum if fi_sum > 1e-9 else 1.0)
            else:
                fi = np.ones(n_base) / n_base
            gbt_contrib = np.sign(X_norm) * (np.abs(X_norm) / (np.abs(X_norm).sum(axis=1, keepdims=True) + 1e-6)) * fi

        # Ensemble attribution (50/50)
        total_contrib = 0.5 * ridge_contrib + 0.5 * gbt_contrib
        abs_contrib = np.abs(total_contrib)
        sum_abs = abs_contrib.sum(axis=1, keepdims=True) + 1e-6
        pct_contrib = (abs_contrib / sum_abs) * 100.0

        attr_df = pd.DataFrame(pct_contrib, index=X_df.index, columns=self.feature_names)
        return preds, attr_df

    def save(self, path: Optional[Union[str, Path]] = None) -> Path:
        """Persist model and write SHA-256 sidecar manifest."""
        out_path = Path(path or MODEL_PATH)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with open(out_path, "wb") as f:
            pickle.dump(self, f, protocol=pickle.HIGHEST_PROTOCOL)

        # Write sidecar hash
        with open(out_path, "rb") as f:
            sha = hashlib.sha256(f.read()).hexdigest()
        manifest = out_path.with_suffix(".pkl.sha256")
        with open(manifest, "w", encoding="utf-8") as f:
            f.write(sha + "\n")

        logger.info(f"[IPO-ML] Saved model to {out_path} (SHA-256: {sha[:16]}...)")
        return out_path

    @classmethod
    def load(cls, path: Optional[Union[str, Path]] = None) -> Optional[IPOMultibaggerModel]:
        """Load and authenticate model via SHA-256 manifest."""
        in_path = Path(path or MODEL_PATH)
        if not in_path.exists():
            return None

        manifest = in_path.with_suffix(".pkl.sha256")
        if manifest.exists():
            expected = manifest.read_text(encoding="utf-8").strip().lower()
            with open(in_path, "rb") as f:
                actual = hashlib.sha256(f.read()).hexdigest().lower()
            if expected != actual:
                logger.error(f"[IPO-ML] SHA-256 mismatch for {in_path} — rejecting load")
                return None

        with open(in_path, "rb") as f:
            model = pickle.load(f)
        return model
