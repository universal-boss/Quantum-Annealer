"""Triple-barrier labeling — López de Prado's institutional standard.

Instead of simple forward returns (P[t+N]/P[t] - 1), triple-barrier labeling
captures path-dependent behavior by placing three barriers around the entry price:

  1. Upper barrier: take-profit (e.g., +2σ)
  2. Lower barrier: stop-loss (e.g., -1σ)
  3. Vertical barrier: time-out (e.g., 10 days)

The label is:
  +1  if price hits upper barrier first  (bullish signal worked)
  -1  if price hits lower barrier first  (bearish signal worked)
   0  if price hits vertical barrier    (no signal — time ran out)

This is FAR more realistic than forward returns because:
  - It captures stop-loss / take-profit behavior (real traders use these)
  - It's robust to end-of-period mean reversion (path matters, not just endpoint)
  - It produces a CLASSIFICATION problem (not regression) → easier to model
  - Meta-labeling can then predict P(correct | features) → position sizing

Reference: López de Prado, "Advances in Financial Machine Learning" (2018), Ch. 3
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Optional


def compute_daily_volatility(
    close: pd.DataFrame,
    span: int = 100,
) -> pd.DataFrame:
    """Compute exponentially-weighted daily volatility for each ticker.

    Args:
        close: DataFrame[date × ticker] of close prices.
        span: EWMA span (default 100 ≈ 5 months of trading days).

    Returns:
        DataFrame[date × ticker] of daily return volatility.
    """
    returns = np.log(close / close.shift(1))
    vol = returns.ewm(span=span).std()
    return vol


def triple_barrier_labels(
    close: pd.DataFrame,
    vol: pd.DataFrame,
    upper_mult: float = 2.0,
    lower_mult: float = 1.0,
    max_holding_days: int = 10,
    min_vol_floor: float = 0.01,
) -> pd.DataFrame:
    """Compute triple-barrier labels for all tickers × dates.

    Args:
        close: DataFrame[date × ticker] of close prices.
        vol: DataFrame[date × ticker] of daily volatility (from compute_daily_volatility).
        upper_mult: Take-profit barrier width in σ units (default 2.0).
        lower_mult: Stop-loss barrier width in σ units (default 1.0).
        max_holding_days: Vertical barrier (time-out) in trading days (default 10).
        min_vol_floor: Minimum volatility floor — prevents zero-vol stocks from
                       producing zero-width barriers (which would instant-label everything).

    Returns:
        DataFrame[date × ticker] with values:
          +1.0 = upper barrier hit (bullish)
          -1.0 = lower barrier hit (bearish)
           0.0 = vertical barrier hit (time-out)
           NaN  = not enough data to compute
    """
    dates = close.index
    tickers = close.columns
    n_dates = len(dates)

    # Pre-compute barrier levels for each date × ticker
    vol_safe = vol.clip(lower=min_vol_floor)

    # Initialize labels as NaN
    labels = pd.DataFrame(
        np.nan, index=dates, columns=tickers, dtype=float
    )

    # Convert to numpy for speed (vectorized over tickers, loop over dates)
    # BUG FIX: .to_numpy() can hand back a READ-ONLY view of pandas' internal
    # storage under Copy-on-Write (permanently enabled since pandas 3.0, and
    # already the default in many 2.x installs). Mutating it in place below
    # raised "ValueError: assignment destination is read-only" on every
    # single call — silently swallowed by engine.py's bare except, which
    # made the whole pipeline fall back to simple forward-return labels
    # instead of the intended triple-barrier labels on every training run.
    # copy=True forces an actual writable array regardless of pandas version/CoW state.
    close_np = close.to_numpy(dtype=float, copy=True)
    vol_np = vol_safe.to_numpy(dtype=float, copy=True)
    labels_np = labels.to_numpy(dtype=float, copy=True)
    ret_np = np.full_like(close_np, np.nan)

    for t in range(n_dates - max_holding_days):
        entry_prices = close_np[t]
        entry_vol = vol_np[t]

        # Skip tickers with NaN entry price or vol
        valid = np.isfinite(entry_prices) & np.isfinite(entry_vol) & (entry_prices > 0)

        if not np.any(valid):
            continue

        # Barrier levels
        upper = entry_prices * (1.0 + upper_mult * entry_vol)
        lower = entry_prices * (1.0 - lower_mult * entry_vol)

        # Check each future day until a barrier is hit
        for h in range(1, max_holding_days + 1):
            future_prices = close_np[t + h]

            # Check upper barrier hit
            hit_upper = valid & (future_prices >= upper) & np.isnan(labels_np[t])
            labels_np[t, hit_upper] = 1.0
            ret_np[t, hit_upper] = (future_prices[hit_upper] - entry_prices[hit_upper]) / entry_prices[hit_upper]

            # Check lower barrier hit
            hit_lower = valid & (future_prices <= lower) & np.isnan(labels_np[t])
            labels_np[t, hit_lower] = -1.0
            ret_np[t, hit_lower] = (future_prices[hit_lower] - entry_prices[hit_lower]) / entry_prices[hit_lower]

            # If vertical barrier (last day) and still NaN, label 0
            if h == max_holding_days:
                still_nan = valid & np.isnan(labels_np[t])
                labels_np[t, still_nan] = 0.0
                ret_np[t, still_nan] = (future_prices[still_nan] - entry_prices[still_nan]) / entry_prices[still_nan]

            # Invalidate tickers where we already have a label
            valid = valid & np.isnan(labels_np[t])

            if not np.any(valid):
                break

    labels_df = pd.DataFrame(labels_np, index=dates, columns=tickers)
    ret_df = pd.DataFrame(ret_np, index=dates, columns=tickers)
    return labels_df, ret_df


def labels_to_forward_returns(
    labels: pd.DataFrame,
    close: pd.DataFrame,
    max_holding_days: int = 10,
    realized_returns: Optional[pd.DataFrame] = None,
) -> tuple[pd.Series, pd.Series]:
    """Convert triple-barrier labels (+1/0/-1) into a continuous target for regression.

    Uses path-preserving actual realized return at the barrier-hit day when available.

    Args:
        labels: Triple-barrier labels from triple_barrier_labels().
        close: Close price DataFrame.
        max_holding_days: Max holding period (for capping returns).
        realized_returns: Exact barrier-hit realized returns (from triple_barrier_labels).

    Returns:
        Tuple of (target_series, label_series).
    """
    labels_stacked = labels.stack()
    labels_stacked.name = "tb_label"

    if realized_returns is not None and not realized_returns.empty:
        fwd_ret_stacked = realized_returns.stack()
    else:
        fwd_ret = close.shift(-max_holding_days) / close - 1.0
        fwd_ret_stacked = fwd_ret.stack()
    fwd_ret_stacked.name = "forward_return"

    df = pd.DataFrame({"label": labels_stacked, "ret": fwd_ret_stacked}).dropna()
    # AUDIT-FIX (Round 8, M1 — Part 2B): `label * |ret|` zeroed EVERY
    # vertical-barrier row (label=0 → target 0.0) — discarding the real
    # partial-horizon return those rows realized and teaching the model that
    # barrier-respecting holds never earn anything. The regression target is
    # now the SIGNED realized return at the barrier: the sign already agrees
    # with the ±1 labels by construction (upper-hit ⇒ +width, lower-hit ⇒
    # −width), and vertical-barrier rows carry their actual time-decayed
    # return instead of a forced 0. The discrete tb_label is unchanged and
    # remains available for meta-labeling.
    df["target"] = df["ret"]

    return df["target"], df["label"]


def get_barrier_widths(
    vol: pd.Series,
    upper_mult: float = 2.0,
    lower_mult: float = 1.0,
) -> tuple[float, float]:
    """Get dynamic barrier widths based on current volatility.

    For high-vol regimes, widen barriers (avoid getting stopped out by noise).
    For low-vol regimes, narrow barriers (capture smaller moves).

    Args:
        vol: Current volatility series (e.g., 63-day realized vol).
        upper_mult: Base upper barrier multiplier.
        lower_mult: Base lower barrier multiplier.

    Returns:
        (upper_width, lower_width) as decimals (e.g., 0.04 = 4%).
    """
    current_vol = float(vol.iloc[-1]) if len(vol) > 0 else 0.02
    # Annualize daily vol
    ann_vol = current_vol * np.sqrt(252) if current_vol < 0.10 else current_vol

    # Scale barriers: wider in high-vol, narrower in low-vol
    vol_scale = max(0.5, min(2.0, ann_vol / 0.20))  # normalize to 20% vol

    upper_width = upper_mult * current_vol * vol_scale
    lower_width = lower_mult * current_vol * vol_scale

    # Floor at 1% to avoid zero-width barriers
    return max(0.01, upper_width), max(0.01, lower_width)
