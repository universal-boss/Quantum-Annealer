"""
ml_alpha/latent_denoiser.py
===========================
Latent Factor De-Noising Engine:
Combines Random Matrix Theory (RMT) / Marchenko-Pastur non-linear spectral clipping
with a PyTorch Variational Factor Autoencoder (Factor-VAE).

Eliminates microstructural noise and unobservable white noise (~85% of market variance)
from cross-sectional factor matrices, isolating true idiosyncratic alpha signals.
"""
from __future__ import annotations

import logging
from typing import Dict, Any, Tuple, Optional, Union
import numpy as np
import pandas as pd
from scipy import linalg

logger = logging.getLogger(__name__)

import os
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("VECLIB_MAXIMUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")

# Optional PyTorch import with CPU-safe fallbacks
try:
    import torch
    import torch.nn as nn
    import torch.optim as optim
    _HAS_TORCH = True
    torch.set_num_threads(1)
    if hasattr(torch, "set_num_interop_threads"):
        try:
            torch.set_num_interop_threads(1)
        except Exception:
            pass
except ImportError:
    _HAS_TORCH = False
    torch = None
    nn = None
    optim = None


class FactorVAEModule:
    """PyTorch Factor-VAE Architecture with ELBO objective."""
    if _HAS_TORCH:
        class _TorchVAE(nn.Module):
            def __init__(self, input_dim: int, latent_dim: int = 4, hidden_dim: int = 32):
                super().__init__()
                self.input_dim = input_dim
                self.latent_dim = latent_dim
                # Encoder (Inputs are already standardized x_std)
                self.encoder = nn.Sequential(
                    nn.Linear(input_dim, hidden_dim),
                    nn.LeakyReLU(0.1),
                    nn.Linear(hidden_dim, hidden_dim // 2),
                    nn.LeakyReLU(0.1),
                )
                self.fc_mu = nn.Linear(hidden_dim // 2, latent_dim)
                self.fc_logvar = nn.Linear(hidden_dim // 2, latent_dim)

                # Decoder (Reconstruction)
                self.decoder = nn.Sequential(
                    nn.Linear(latent_dim, hidden_dim // 2),
                    nn.LeakyReLU(0.1),
                    nn.Linear(hidden_dim // 2, hidden_dim),
                    nn.LeakyReLU(0.1),
                    nn.Linear(hidden_dim, input_dim),
                )

            def encode(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
                h = self.encoder(x)
                mu = self.fc_mu(h)
                logvar = torch.clamp(self.fc_logvar(h), -10.0, 10.0)
                return mu, logvar

            def reparameterize(self, mu: torch.Tensor, logvar: torch.Tensor) -> torch.Tensor:
                std = torch.exp(0.5 * logvar)
                eps = torch.randn_like(std)
                return mu + eps * std

            def decode(self, z: torch.Tensor) -> torch.Tensor:
                return self.decoder(z)

            def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
                mu, logvar = self.encode(x)
                z = self.reparameterize(mu, logvar)
                x_recon = self.decode(z)
                return x_recon, mu, logvar
    else:
        _TorchVAE = None


class LatentFactorDenoiser:
    """
    Dual-Tier Latent Factor De-Noiser:
    1. Tier 1: RMT Marchenko-Pastur Non-Linear Spectral Shrinkage
    2. Tier 2: Factor-VAE (Variational Autoencoder) Latent Projection

    Strips idiosyncratic white noise while preserving cross-sectional rank relationships.
    """

    def __init__(
        self,
        method: str = "hybrid",  # 'rmt', 'vae', or 'hybrid'
        latent_dim: int = 4,
        hidden_dim: int = 32,
        vae_epochs: int = 25,
        learning_rate: float = 0.005,
        kl_weight: float = 0.01,
    ):
        self.method = method
        self.latent_dim = latent_dim
        self.hidden_dim = hidden_dim
        self.vae_epochs = vae_epochs
        self.learning_rate = learning_rate
        self.kl_weight = kl_weight

        self.fitted_ = False
        self.input_dim_: int = 0
        self.feature_names_: list[str] = []
        self.mean_: np.ndarray | None = None
        self.std_: np.ndarray | None = None
        self.denoised_cov_: np.ndarray | None = None
        self.lambda_plus_: float = 0.0
        self.n_clipped_eigenvalues_: int = 0

        # VAE weights stored in pure CPU NumPy arrays for ultra-lean serialization
        self.vae_state_dict_: dict[str, np.ndarray] = {}
        self.last_elbo_loss_: float = 0.0
        self.last_recon_loss_: float = 0.0
        self.last_kl_loss_: float = 0.0

    @staticmethod
    def marchenko_pastur_bounds(var: float, n_assets: int, t_obs: int) -> Tuple[float, float]:
        """Calculates theoretical Marchenko-Pastur spectral boundaries."""
        q = n_assets / max(t_obs, 1)
        lambda_minus = float(var * (1.0 - np.sqrt(q)) ** 2)
        lambda_plus = float(var * (1.0 + np.sqrt(q)) ** 2)
        return lambda_minus, lambda_plus

    def denoise_covariance_rmt(self, cov: np.ndarray, n_assets: int, t_obs: int) -> np.ndarray:
        """
        Applies Random Matrix Theory (RMT) eigenvalue clipping:
        Eigenvalues <= lambda_+ are replaced by their trace-preserving constant mean.
        """
        c = np.asarray(cov, dtype=float)
        if c.shape[0] != c.shape[1] or c.shape[0] < 2:
            return c

        try:
            eigvals, eigvecs = linalg.eigh(c)
            var = float(np.mean(np.diag(c)))
            _, l_plus = self.marchenko_pastur_bounds(var, n_assets, t_obs)
            self.lambda_plus_ = l_plus

            noise_mask = eigvals <= l_plus
            self.n_clipped_eigenvalues_ = int(np.sum(noise_mask))
            if np.any(noise_mask):
                noise_mean = float(np.mean(eigvals[noise_mask]))
                eigvals[noise_mask] = noise_mean

            # Reconstruct symmetric matrix
            denoised = eigvecs @ np.diag(eigvals) @ eigvecs.T
            return 0.5 * (denoised + denoised.T)
        except Exception as e:
            logger.warning("RMT spectral clipping fallback due to %s", e)
            return c

    def fit(self, X: Union[pd.DataFrame, np.ndarray], t_obs: Optional[int] = None) -> "LatentFactorDenoiser":
        """Fits RMT spectral baseline and/or Factor-VAE on factor matrix."""
        if isinstance(X, pd.DataFrame):
            self.feature_names_ = list(X.columns)
            X_mat = X.select_dtypes(include=[np.number]).fillna(0.0).values
        else:
            X_mat = np.asarray(X, dtype=float)
            self.feature_names_ = [f"f_{i}" for i in range(X_mat.shape[1])]

        n_samples, n_features = X_mat.shape
        self.input_dim_ = n_features
        t_effective = t_obs or max(n_samples, 252)

        # Standardize features
        self.mean_ = np.mean(X_mat, axis=0)
        self.std_ = np.std(X_mat, axis=0)
        self.std_[self.std_ < 1e-7] = 1.0
        X_std = (X_mat - self.mean_) / self.std_

        # 1. Fit RMT Denoising on cross-factor correlation matrix
        sample_corr = np.corrcoef(X_std, rowvar=False)
        sample_corr = np.nan_to_num(sample_corr, nan=0.0)
        np.fill_diagonal(sample_corr, 1.0)
        self.denoised_cov_ = self.denoise_covariance_rmt(sample_corr, n_features, t_effective)

        # Precompute stable spectral filter kernel K = C_denoised @ inv(C_raw)
        try:
            inv_raw = linalg.pinv(sample_corr + np.eye(self.input_dim_) * 1e-3)
            self.filter_kernel_ = self.denoised_cov_ @ inv_raw
        except Exception:
            self.filter_kernel_ = np.eye(self.input_dim_)

        # 2. Fit Factor-VAE if requested and PyTorch available
        if self.method in ("vae", "hybrid") and _HAS_TORCH and FactorVAEModule._TorchVAE is not None:
            try:
                self._fit_vae(X_std)
            except Exception as e:
                logger.warning("Factor-VAE fitting fallback (%s) — using RMT spectral denoising", e)

        self.fitted_ = True
        return self

    def _fit_vae(self, X_std: np.ndarray) -> None:
        """Trains PyTorch Factor-VAE and extracts CPU state dict."""
        device = torch.device("cpu")
        vae = FactorVAEModule._TorchVAE(
            input_dim=self.input_dim_,
            latent_dim=min(self.latent_dim, self.input_dim_),
            hidden_dim=self.hidden_dim,
        ).to(device)

        optimizer = optim.AdamW(vae.parameters(), lr=self.learning_rate, weight_decay=1e-4)
        # Ensure C-contiguous float32 array to prevent memory stride faults
        X_contig = np.ascontiguousarray(X_std, dtype=np.float32)
        tensor_x = torch.from_numpy(X_contig)

        n_samples = len(X_contig)
        batch_size = min(128, n_samples)

        vae.train()
        for epoch in range(self.vae_epochs):
            total_recon = 0.0
            total_kl = 0.0
            total_loss = 0.0
            n_batches = 0

            perm = np.random.permutation(n_samples)
            for b in range(0, n_samples, batch_size):
                batch_idx = perm[b : b + batch_size]
                batch_x = tensor_x[batch_idx]

                optimizer.zero_grad()
                x_recon, mu, logvar = vae(batch_x)

                # Reconstruction loss: MSE
                recon_loss = nn.functional.mse_loss(x_recon, batch_x, reduction="mean")
                # KL Divergence: -0.5 * sum(1 + log(sigma^2) - mu^2 - sigma^2)
                kl_loss = -0.5 * torch.mean(torch.sum(1.0 + logvar - mu.pow(2) - logvar.exp(), dim=1))
                loss = recon_loss + self.kl_weight * kl_loss

                loss.backward()
                nn.utils.clip_grad_norm_(vae.parameters(), 1.0)
                optimizer.step()

                total_recon += float(recon_loss.item())
                total_kl += float(kl_loss.item())
                total_loss += float(loss.item())
                n_batches += 1

            self.last_elbo_loss_ = total_loss / max(n_batches, 1)
            self.last_recon_loss_ = total_recon / max(n_batches, 1)
            self.last_kl_loss_ = total_kl / max(n_batches, 1)

        # Serialize VAE parameters to CPU numpy dictionary for lean zero-dependency pickling
        vae.eval()
        self.vae_state_dict_ = {
            k: v.detach().cpu().numpy()
            for k, v in vae.state_dict().items()
        }

    def _reconstruct_via_vae(self, X_std: np.ndarray) -> np.ndarray:
        """Evaluates VAE reconstruction using CPU numpy weights."""
        if not self.vae_state_dict_ or not _HAS_TORCH:
            return X_std

        try:
            vae = FactorVAEModule._TorchVAE(
                input_dim=self.input_dim_,
                latent_dim=min(self.latent_dim, self.input_dim_),
                hidden_dim=self.hidden_dim,
            )
            torch_state = {
                k: torch.tensor(v, dtype=torch.float32)
                for k, v in self.vae_state_dict_.items()
            }
            vae.load_state_dict(torch_state)
            vae.eval()

            X_contig = np.ascontiguousarray(X_std, dtype=np.float32)
            with torch.no_grad():
                tensor_x = torch.from_numpy(X_contig)
                mu, _ = vae.encode(tensor_x)
                x_recon = vae.decode(mu)
                return x_recon.cpu().numpy()
        except Exception as e:
            logger.warning("VAE forward reconstruction fallback due to: %s", e)
            return X_std

    def denoise(self, X: Union[pd.DataFrame, np.ndarray]) -> Union[pd.DataFrame, np.ndarray]:
        """
        Denoises input factor matrix:
        1. Standardizes factors.
        2. Applies RMT spectral projection and/or Factor-VAE reconstruction.
        3. Restores input shape and column names.
        """
        if not self.fitted_:
            raise RuntimeError("LatentFactorDenoiser must be fit before calling denoise()")

        is_df = isinstance(X, pd.DataFrame)
        if is_df:
            cols = list(X.columns)
            X_mat = X.select_dtypes(include=[np.number]).fillna(0.0).values
        else:
            cols = self.feature_names_
            X_mat = np.asarray(X, dtype=float)

        if X_mat.shape[1] != self.input_dim_:
            # Align dimension if needed
            return X

        # Standardize using fitted statistics
        X_std = (X_mat - self.mean_) / self.std_

        if self.method == "rmt":
            X_clean_std = X_std @ getattr(self, "filter_kernel_", np.eye(self.input_dim_))
        elif self.method == "vae":
            X_clean_std = self._reconstruct_via_vae(X_std)
        else:  # hybrid
            vae_out = self._reconstruct_via_vae(X_std)
            rmt_out = X_std @ getattr(self, "filter_kernel_", np.eye(self.input_dim_))
            X_clean_std = 0.5 * vae_out + 0.5 * rmt_out

        # Denormalize back to original factor scale
        X_clean = X_clean_std * self.std_ + self.mean_

        if is_df:
            return pd.DataFrame(X_clean, index=X.index, columns=cols)
        return X_clean

    def get_diagnostics(self) -> Dict[str, Any]:
        """Returns diagnostic metrics for the fitted denoiser."""
        return {
            "method": self.method,
            "input_dim": self.input_dim_,
            "lambda_plus_spectral_bound": round(float(self.lambda_plus_), 4),
            "n_clipped_eigenvalues": self.n_clipped_eigenvalues_,
            "last_elbo_loss": round(float(self.last_elbo_loss_), 4),
            "last_recon_loss": round(float(self.last_recon_loss_), 4),
            "last_kl_loss": round(float(self.last_kl_loss_), 6),
        }
