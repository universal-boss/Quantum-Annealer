"""
ml_alpha/liquid_neural_ode.py
=============================
Sovereign Tier-0+ Liquid Time-Constant (LTC) Networks & Continuous-Time Neural ODE Engine.

Implements Hasani et al. (MIT CSAIL, 2021/2022) "Liquid Time-Constant Networks" 
and Chen et al. (NeurIPS 2018) "Neural Ordinary Differential Equations" for institutional
continuous-time market alpha and high-frequency microstructure dynamics.

Mathematical Formulation:
    Continuous State Transition:
        d h(t) / dt = - [1 / tau_base + f(h(t), x(t); theta)] * h(t) + A * f(h(t), x(t); theta)
    
    where:
        - tau(x(t)) = tau_base / (1 + tau_base * f(h(t), x(t))) is the dynamic input-dependent liquid time constant.
        - Under market stress or volatility bursts, f(.) scales up, driving tau -> 0 (instantaneous regime adaptation).
        - Under quiet consolidation, tau -> tau_base (long-term historical memory preservation).
        - Solved via 4th-Order Runge-Kutta (RK4) and adaptive Dormand-Prince integrators across irregular tick intervals.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Tuple, Union
import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


def _sigmoid(x: np.ndarray) -> np.ndarray:
    """Numerically stable element-wise sigmoid."""
    return np.where(x >= 0, 1.0 / (1.0 + np.exp(-np.clip(x, -50.0, 50.0))), np.exp(np.clip(x, -50.0, 50.0)) / (1.0 + np.exp(np.clip(x, -50.0, 50.0))))


def _softplus(x: np.ndarray) -> np.ndarray:
    """Numerically stable softplus activation."""
    return np.log1p(np.exp(-np.abs(np.clip(x, -50.0, 50.0)))) + np.maximum(x, 0.0)


class LiquidNeuralODEEngine:
    """
    Continuous-Time Liquid Time-Constant (LTC) Neural Differential Equation Engine.
    
    Dynamically adjusts continuous temporal decay constants based on market volatility,
    VPIN order flow toxicity, and microstructure volume spikes.
    """

    def __init__(
        self,
        input_dim: int = 4,
        hidden_dim: int = 16,
        tau_base: float = 1.0,
        resting_potential: float = 1.0,
        random_state: int = 42,
    ) -> None:
        self.input_dim = int(input_dim)
        self.hidden_dim = int(hidden_dim)
        self.tau_base = float(tau_base)
        self.resting_potential = float(resting_potential)
        self.random_state = int(random_state)
        
        # Reproducible parameter initialization
        rng = np.random.RandomState(self.random_state)
        
        # Xavier/Glorot normal initialization for state transitions
        scale_hh = np.sqrt(2.0 / (hidden_dim + hidden_dim))
        scale_xh = np.sqrt(2.0 / (input_dim + hidden_dim))
        
        # Orthogonal/spectral-bounded recurrent weights for ODE Lyapunov stability
        raw_hh = rng.randn(hidden_dim, hidden_dim) * scale_hh
        u, _, vt = np.linalg.svd(raw_hh)
        self.W_hh = u @ vt * 0.95  # Spectral radius strictly < 1.0 for contractive stability
        
        self.W_xh = rng.randn(hidden_dim, input_dim) * scale_xh
        self.bias = np.zeros(hidden_dim, dtype=np.float64)
        
        # Saturation potential vector A (dim = hidden_dim)
        self.A = np.full(hidden_dim, self.resting_potential, dtype=np.float64)
        
        # Linear readout head W_out, b_out
        self.W_out = rng.randn(hidden_dim) * np.sqrt(1.0 / hidden_dim)
        self.b_out = 0.0
        
        self._is_calibrated = False

    def vector_field(self, h: np.ndarray, x: np.ndarray) -> np.ndarray:
        """
        Computes continuous derivative dh/dt at state h and input x:
            dh/dt = - [1/tau_base + f(h, x)] * h + A * f(h, x)
        where f(h, x) = softplus(W_hh @ h + W_xh @ x + bias).
        """
        # Non-linear conductance activation (always >= 0 to ensure stability)
        pre_act = self.W_hh @ h + self.W_xh @ x + self.bias
        f_val = _softplus(pre_act)
        
        # Liquid time-constant conductance
        decay_rate = (1.0 / self.tau_base) + f_val
        dh_dt = -decay_rate * h + self.A * f_val
        return dh_dt

    def effective_tau(self, h: np.ndarray, x: np.ndarray) -> np.ndarray:
        """
        Calculates the instantaneous liquid time-constant vector tau(h, x):
            tau_eff = 1.0 / (1.0/tau_base + f(h, x))
        """
        pre_act = self.W_hh @ h + self.W_xh @ x + self.bias
        f_val = _softplus(pre_act)
        return 1.0 / ((1.0 / self.tau_base) + f_val + 1e-8)

    def rk4_step(
        self,
        h: np.ndarray,
        x0: np.ndarray,
        x1: np.ndarray,
        dt: float,
    ) -> np.ndarray:
        """
        Performs a single 4th-Order Runge-Kutta (RK4) step from t to t + dt:
        Uses linear interpolation for continuous input x(t) over interval [t, t + dt].
        """
        if dt <= 0.0:
            return h.copy()
            
        x_mid = 0.5 * (x0 + x1)
        
        k1 = self.vector_field(h, x0)
        k2 = self.vector_field(h + 0.5 * dt * k1, x_mid)
        k3 = self.vector_field(h + 0.5 * dt * k2, x_mid)
        k4 = self.vector_field(h + dt * k3, x1)
        
        h_next = h + (dt / 6.0) * (k1 + 2.0 * k2 + 2.0 * k3 + k4)
        return h_next

    def integrate_trajectory(
        self,
        X: np.ndarray,
        dt_array: Optional[np.ndarray] = None,
        h0: Optional[np.ndarray] = None,
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Integrates continuous hidden state trajectory over time series X.
        
        Args:
            X: Input sequence of shape (T, input_dim).
            dt_array: Optional interval sequence of shape (T-1,). Defaults to 1.0 (daily/regular).
            h0: Optional initial state of shape (hidden_dim,). Defaults to zeros.
            
        Returns:
            Tuple of:
                - H_traj: Hidden states (T, hidden_dim)
                - tau_traj: Effective liquid time constants (T, hidden_dim)
                - Y_pred: Linear continuous alpha predictions (T,)
        """
        T, d = X.shape
        if d != self.input_dim:
            raise ValueError(f"Expected input_dim={self.input_dim}, got {d}")
            
        if dt_array is None:
            dt_array = np.ones(T - 1, dtype=np.float64)
        else:
            dt_array = np.asarray(dt_array, dtype=np.float64)
            if len(dt_array) != T - 1:
                raise ValueError(f"dt_array length must be T-1={T-1}, got {len(dt_array)}")
                
        H_traj = np.zeros((T, self.hidden_dim), dtype=np.float64)
        tau_traj = np.zeros((T, self.hidden_dim), dtype=np.float64)
        
        if h0 is not None:
            H_traj[0] = np.asarray(h0, dtype=np.float64)
        else:
            H_traj[0] = np.zeros(self.hidden_dim, dtype=np.float64)
            
        tau_traj[0] = self.effective_tau(H_traj[0], X[0])
        
        for t in range(T - 1):
            dt = float(np.clip(dt_array[t], 1e-4, 10.0))
            H_traj[t + 1] = self.rk4_step(H_traj[t], X[t], X[t + 1], dt)
            tau_traj[t + 1] = self.effective_tau(H_traj[t + 1], X[t + 1])
            
        # Continuous Readout Conviction: tanh(W_out @ h + b_out)
        logits = H_traj @ self.W_out + self.b_out
        Y_pred = np.tanh(logits)
        
        return H_traj, tau_traj, Y_pred

    def steady_state_readout(
        self,
        X: np.ndarray,
        n_steps: int = 6,
        dt: float = 1.0,
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        BUGFIX (Round 41): order-independent, per-row alternative to
        integrate_trajectory() for cross-sectional panels.

        integrate_trajectory() is correct when X is a single asset's own
        chronological price/feature history (as used in extract_liquid_features
        below) — each row genuinely follows the previous one in time, so
        chaining the hidden state across rows is the whole point.

        It is NOT correct when X is a cross-sectional panel with one row per
        (ticker, date) spanning many unrelated stocks (as AllWeatherLiquidODEModel
        was doing) — there, "row t+1" is usually a different, unrelated stock,
        so chaining h(t) across rows makes every prediction depend on which
        other stocks happened to precede it in the array, not on that row's
        own features. Verified empirically: the same feature row produced
        different predictions (0.0 vs -0.297) depending purely on row order.

        This method instead treats every row as independent: starting from
        h0=0, it holds that row's own feature vector constant and relaxes
        toward the ODE's fixed point (dh/dt -> 0) for that input alone. The
        result depends only on the row's own features, not on row order or
        neighboring rows — safe for both training (a panel of many samples)
        and live inference (a single snapshot row per ticker, which is
        genuinely all that's available at predict() time — there is no
        per-ticker history for chaining to operate on there).

        Uses an implicit ("IMEX") update for the linear decay term rather than
        explicit RK4: h_{k+1} = (h_k + dt*A*f_val) / (1 + dt*decay_rate). This
        method exists purely to find the equilibrium point, not to trace a
        physically faithful transient trajectory (that's what
        integrate_trajectory is for), so an implicit scheme is the right
        choice here — it is unconditionally stable regardless of how large
        decay_rate/dt get, whereas explicit RK4 diverges to NaN for
        large-magnitude/outlier inputs (a real risk with z-scored market data,
        which routinely has multi-sigma outliers). Inputs are also clipped to
        a generous +/-8 sigma band as a second safety line.

        Vectorized across all rows in X at once (batched matrix ops), not a
        per-row Python loop.
        """
        X = np.clip(np.asarray(X, dtype=np.float64), -8.0, 8.0)
        n = X.shape[0]
        H = np.zeros((n, self.hidden_dim), dtype=np.float64)
        dt = float(max(dt, 1e-4))

        for _ in range(max(1, n_steps)):
            pre_act = H @ self.W_hh.T + X @ self.W_xh.T + self.bias
            f_val = _softplus(pre_act)
            decay_rate = (1.0 / self.tau_base) + f_val
            # Implicit-Euler update of the linear decay term: unconditionally
            # stable for any decay_rate >= 0, unlike explicit RK4.
            H = (H + dt * self.A * f_val) / (1.0 + dt * decay_rate)

        pre_act_final = H @ self.W_hh.T + X @ self.W_xh.T + self.bias
        f_final = _softplus(pre_act_final)
        tau_final = 1.0 / ((1.0 / self.tau_base) + f_final + 1e-8)

        logits = H @ self.W_out + self.b_out
        Y_pred = np.tanh(logits)
        return H, tau_final, Y_pred

    def calibrate_readout_steady_state(
        self,
        X_train: np.ndarray,
        y_train: np.ndarray,
        l2_reg: float = 1e-3,
        n_steps: int = 6,
    ) -> LiquidNeuralODEEngine:
        """Row-independent counterpart to calibrate_readout(), for cross-sectional
        panels — see steady_state_readout() docstring for why this exists."""
        T = len(X_train)
        if T < 5:
            self._is_calibrated = True
            return self

        H_final, _, _ = self.steady_state_readout(X_train, n_steps=n_steps)
        H_aug = np.hstack([H_final, np.ones((T, 1))])
        reg_matrix = l2_reg * np.eye(self.hidden_dim + 1)
        reg_matrix[-1, -1] = 0.0
        cov_h = H_aug.T @ H_aug + reg_matrix
        weights = np.linalg.pinv(cov_h) @ (H_aug.T @ y_train)
        self.W_out = weights[:self.hidden_dim]
        self.b_out = float(weights[-1])
        self._is_calibrated = True
        logger.info(
            "[LiquidNeuralODE] Calibrated steady-state readout head | W_out norm: %.4f | Bias: %.4f",
            float(np.linalg.norm(self.W_out)), self.b_out
        )
        return self

    def calibrate_readout(
        self,
        X_train: np.ndarray,
        y_train: np.ndarray,
        l2_reg: float = 1e-3,
    ) -> LiquidNeuralODEEngine:
        """
        Calibrates the linear readout head (W_out, b_out) against target future returns
        using L2-regularized Ridge regression over the integrated continuous state manifold.
        """
        T = len(X_train)
        if T < 5:
            self._is_calibrated = True
            return self
            
        H_traj, _, _ = self.integrate_trajectory(X_train)
        
        # Build design matrix [H, 1]
        H_aug = np.hstack([H_traj, np.ones((T, 1))])
        
        # Ridge projection: (H^T H + lambda * I)^(-1) H^T y
        reg_matrix = l2_reg * np.eye(self.hidden_dim + 1)
        reg_matrix[-1, -1] = 0.0  # Do not penalize bias
        
        cov_h = H_aug.T @ H_aug + reg_matrix
        weights = np.linalg.pinv(cov_h) @ (H_aug.T @ y_train)
        
        self.W_out = weights[:self.hidden_dim]
        self.b_out = float(weights[-1])
        self._is_calibrated = True
        
        logger.info(
            "[LiquidNeuralODE] Calibrated continuous readout head | W_out norm: %.4f | Bias: %.4f",
            float(np.linalg.norm(self.W_out)), self.b_out
        )
        return self

    def extract_liquid_features(
        self,
        prices: Union[np.ndarray, pd.Series],
        volumes: Optional[Union[np.ndarray, pd.Series]] = None,
        timestamps: Optional[Union[np.ndarray, pd.DatetimeIndex]] = None,
    ) -> Dict[str, float]:
        """
        Extracts high-order continuous dynamical features for an asset price/volume stream.
        
        Returns:
            Dictionary with:
                - liquid_conviction: Directional alpha conviction in [-1, 1]
                - liquid_effective_tau_mean: Mean liquid time constant across hidden neurons
                - liquid_effective_tau_min: Minimum liquid time constant (spike reactivity)
                - liquid_adaptation_velocity: Rate of state transition ||dh/dt||
                - liquid_hidden_energy: Latent manifold state energy ||h||^2
                - liquid_lyapunov_stability: Spectral contraction ratio (< 1.0 = stable)
        """
        px = np.asarray(prices, dtype=np.float64)
        valid = np.isfinite(px) & (px > 0)
        px = px[valid]
        n = len(px)
        
        if n < 8:
            return {
                "liquid_conviction": 0.0,
                "liquid_effective_tau_mean": self.tau_base,
                "liquid_effective_tau_min": self.tau_base,
                "liquid_adaptation_velocity": 0.0,
                "liquid_hidden_energy": 0.0,
                "liquid_lyapunov_stability": 0.95,
            }
            
        # 1. Log Returns
        log_ret = np.diff(np.log(px))
        log_ret = np.pad(log_ret, (1, 0), mode="constant")
        
        # 2. Intra-bar Volatility Proxy (exponential moving absolute deviation)
        vol_proxy = np.abs(log_ret)
        
        # 3. Volume Innovation (if provided, else proxy via squared return)
        if volumes is not None:
            vol_arr = np.asarray(volumes, dtype=np.float64)[valid]
            vol_clean = np.where(np.isfinite(vol_arr) & (vol_arr > 0), vol_arr, 1.0)
            vol_mean = np.mean(vol_clean) if len(vol_clean) > 0 else 1.0
            vol_innov = (vol_clean - vol_mean) / (np.std(vol_clean) + 1e-8)
        else:
            vol_innov = (vol_proxy - np.mean(vol_proxy)) / (np.std(vol_proxy) + 1e-8)
            
        # 4. Momentum / Trend Acceleration
        window = min(5, n // 2)
        roll_mean = pd.Series(log_ret).rolling(window, min_periods=1).mean().to_numpy()
        mom_accel = log_ret - roll_mean
        
        # Construct 4-channel continuous input matrix: (T, 4)
        X = np.column_stack([
            np.clip(log_ret * 10.0, -5.0, 5.0),
            np.clip(vol_proxy * 20.0, -5.0, 5.0),
            np.clip(vol_innov, -5.0, 5.0),
            np.clip(mom_accel * 10.0, -5.0, 5.0),
        ])
        
        # Compute dt from timestamps if available
        dt_array = None
        if timestamps is not None and len(timestamps) == n:
            try:
                ts = pd.to_datetime(timestamps)[valid]
                diffs = (ts[1:] - ts[:-1]).total_seconds() / 86400.0  # in days
                dt_array = np.clip(diffs.to_numpy(dtype=np.float64), 0.1, 5.0)
            except Exception:
                dt_array = None
                
        H_traj, tau_traj, Y_pred = self.integrate_trajectory(X, dt_array=dt_array)
        
        final_h = H_traj[-1]
        final_tau = tau_traj[-1]
        conviction = float(Y_pred[-1])
        
        # Instantaneous adaptation velocity ||dh/dt||
        dh_dt = self.vector_field(final_h, X[-1])
        adapt_vel = float(np.linalg.norm(dh_dt))
        
        # Latent state energy
        energy = float(np.sum(final_h ** 2))
        
        # Spectral Lyapunov stability check
        spectral_radius = float(np.max(np.abs(np.linalg.eigvals(self.W_hh))))
        
        return {
            "liquid_conviction": round(conviction, 5),
            "liquid_effective_tau_mean": round(float(np.mean(final_tau)), 5),
            "liquid_effective_tau_min": round(float(np.min(final_tau)), 5),
            "liquid_adaptation_velocity": round(adapt_vel, 5),
            "liquid_hidden_energy": round(energy, 5),
            "liquid_lyapunov_stability": round(spectral_radius, 5),
        }


# Canonical alias
LiquidNeuralODE = LiquidNeuralODEEngine
