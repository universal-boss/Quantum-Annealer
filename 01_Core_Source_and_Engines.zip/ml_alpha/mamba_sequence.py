"""
ml_alpha/mamba_sequence.py
==========================
Mamba Selective State-Space Sequential Representation Engine for Financial Series.

Implements input-dependent continuous-state sequence modeling with linear O(T) complexity:
    h_t = A_bar * h_{t-1} + B_bar * x_t
    y_t = C * h_t + D * x_t

where:
    A_bar = exp(Delta * A)
    B_bar = (Delta * A)^(-1) * (exp(Delta * A) - I) * Delta * B
    (Delta, B, C) are input-selective functions of x_t.

Captures multi-scale temporal order flow (hourly consolidation -> compression -> breakout)
without the quadratic O(T^2) memory footprint of standard Transformers.

References:
    - Gu, A. & Dao, T. (2023), "Mamba: Linear-Time Sequence Modeling with Selective State Spaces".
"""
from __future__ import annotations

import logging
from typing import Dict, Any, List, Optional, Tuple, Union
import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


class MambaSequenceExtractor:
    """
    Selective State-Space Model for multi-horizon financial return & volume sequences.
    """

    def __init__(self, d_state: int = 16, d_model: int = 4):
        self.d_state = d_state
        self.d_model = d_model
        # Initialize HiPPO-like transition matrix A (decaying continuous memory)
        # Structured diagonal plus low-rank representation
        self.A = -0.5 * np.ones((d_model, d_state), dtype=float)
        for i in range(d_model):
            self.A[i, :] = -np.exp(np.linspace(-2.0, 1.0, d_state))
        self.D = np.ones(d_model, dtype=float)

    def extract_features(
        self,
        prices: Union[np.ndarray, pd.Series],
        volumes: Optional[Union[np.ndarray, pd.Series]] = None
    ) -> Dict[str, float]:
        """
        Runs the selective state-space scan over asset price and volume trajectories.

        Returns:
            Dictionary containing mamba sequence alpha indicators:
            - mamba_trend_drift: Long-horizon latent state momentum
            - mamba_accel_state: Intermediate curvature/acceleration
            - mamba_vol_absorption: Hidden state energy in volume-price interaction
            - mamba_coherence: Ratio of coherent signal to diffusive noise
        """
        px = np.asarray(prices, dtype=float)
        valid = np.isfinite(px) & (px > 0)
        px = px[valid]
        n = len(px)

        if n < 10:
            return {
                "mamba_trend_drift": 0.0,
                "mamba_accel_state": 0.0,
                "mamba_vol_absorption": 0.0,
                "mamba_coherence": 0.5,
            }

        # 1. Construct 4-channel input x_t:
        # Ch 0: Log returns
        # Ch 1: High-Low intra-period proxy (absolute return)
        # Ch 2: Normalized volume innovation
        # Ch 3: Volume-weighted return
        ret = np.diff(np.log(px))
        ret = np.pad(ret, (1, 0), mode="constant")
        abs_ret = np.abs(ret)

        if volumes is not None:
            vol = np.asarray(volumes, dtype=float)[valid] if len(volumes) == len(valid) else np.asarray(volumes, dtype=float)
            vol = np.nan_to_num(vol, nan=1.0)
            log_vol = np.log(np.maximum(vol, 1.0))
            norm_vol = (log_vol - np.mean(log_vol)) / (np.std(log_vol) + 1e-9)
            vw_ret = ret * np.clip(norm_vol, -3.0, 3.0)
        else:
            norm_vol = np.zeros_like(ret)
            vw_ret = ret

        # x has shape (n, d_model = 4)
        x = np.column_stack([ret, abs_ret, norm_vol, vw_ret])
        T, D_in = x.shape

        # 2. Selective Scan: compute input-dependent Delta_t, B_t, C_t
        # Linear projection proxies:
        # Delta controls how much the system pays attention to input vs current state
        # In finance: high volatility -> smaller Delta (faster updating, shorter memory)
        vol_scalar = np.std(ret) + 1e-9
        delta = np.clip(0.1 / (1.0 + 50.0 * np.abs(ret)), 0.01, 0.5)  # Shape (T,)

        # State vector h of shape (d_model, d_state)
        h = np.zeros((self.d_model, self.d_state), dtype=float)
        y_outputs = []

        for t in range(T):
            dt = delta[t]
            x_t = x[t, :]  # Shape (4,)

            # Discretize continuous A: A_bar = exp(dt * A)
            # Element-wise exponential of diagonal transition
            A_bar = np.exp(dt * self.A)  # Shape (4, 16)
            # B_bar approximation: dt * x_t
            # Update state: h = A_bar * h + B_bar * x_t
            B_term = dt * x_t[:, np.newaxis]  # Shape (4, 1) broadcast to (4, 16)
            h = A_bar * h + B_term

            # Readout y_t = mean across state dimensions + D * x_t
            y_t = np.mean(h, axis=1) + self.D * x_t
            y_outputs.append(y_t)

        y_arr = np.array(y_outputs)  # Shape (T, 4)

        # 3. Extract latent alpha metrics from terminal state
        trend_drift = float(np.mean(y_arr[-5:, 0]))
        accel_state = float(y_arr[-1, 0] - y_arr[-5, 0]) if T >= 5 else 0.0
        vol_absorption = float(np.mean(y_arr[-5:, 3]))

        # Coherence: signal energy vs noise energy in state
        sig_energy = float(np.sum(h ** 2))
        coherence = float(np.clip(1.0 / (1.0 + np.exp(-sig_energy * 0.1)), 0.0, 1.0))

        return {
            "mamba_trend_drift": float(np.clip(trend_drift * 10.0, -5.0, 5.0)),
            "mamba_accel_state": float(np.clip(accel_state * 10.0, -5.0, 5.0)),
            "mamba_vol_absorption": float(np.clip(vol_absorption * 10.0, -5.0, 5.0)),
            "mamba_coherence": coherence,
        }
