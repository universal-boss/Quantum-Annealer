"""Statistical metrics — Spearman IC, Deflated Sharpe Ratio, walk-forward efficiency.

All formulas follow López de Prado:
- "The Deflated Sharpe Ratio" (Bailey & López de Prado, 2014)
- "Advances in Financial Machine Learning" (2018)
"""
from __future__ import annotations
from typing import List, Union, Dict, Tuple, Optional

import numpy as np
import pandas as pd
from scipy.stats import spearmanr, norm


def spearman_ic(predictions: np.ndarray, actuals: np.ndarray, dates: np.ndarray | None = None) -> float:
    """Spearman rank IC (industry standard for factor evaluation).

    Masks NaN values before computation. Returns 0.0 for degenerate inputs
    (too few observations or zero variance).

    AUDIT-FIX (Round 13, ML-6): with `dates` supplied, computes the
    PER-DATE cross-sectional Spearman IC and returns its mean — the
    industry definition (a rank correlation within each rebalance
    date's cross-section, then averaged over dates). Without dates the
    pooled correlation mixes time-series and cross-sectional variation
    and can report a high "IC" for a model that is never right within
    any single date but happens to rank early-period rows vs late-period
    rows correctly (a timing artifact, not stock-selection skill).
    Pooled behavior is kept only for callers without dates.
    """
    if len(predictions) != len(actuals):
        return 0.0
    # Mask NaN — robust against missing data
    mask = ~np.isnan(predictions) & ~np.isnan(actuals)
    if dates is not None:
        d = np.asarray(dates)[mask]
        p = np.asarray(predictions)[mask]
        a = np.asarray(actuals)[mask]
        if len(p) < 3:
            return 0.0
        _df = pd.DataFrame({"p": p, "a": a, "d": d})
        ics = []
        for _, _g in _df.groupby("d", sort=False):
            if len(_g) < 3:
                continue
            if _g["p"].nunique() < 2 or _g["a"].nunique() < 2:
                continue
            try:
                _v = float(spearmanr(_g["p"].to_numpy(), _g["a"].to_numpy())[0])
                if np.isfinite(_v):
                    ics.append(_v)
            except Exception:
                continue
        return float(np.mean(ics)) if ics else 0.0
    p = predictions[mask]
    a = actuals[mask]
    if len(p) < 3:
        return 0.0
    if np.std(p) < 1e-12 or np.std(a) < 1e-12:
        return 0.0
    try:
        return float(spearmanr(p, a)[0])
    except Exception:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
        return 0.0


def deflated_sharpe_ratio(
    observed_sharpe: float,
    n_trials: int = 1,
    sample_length: int = 252,
    skewness: float = 0.0,
    kurtosis: float = 3.0,
    holding_days: int = 1,
) -> float:
    """López de Prado's Deflated Sharpe Ratio.

    Returns probability [0, 1] that the true Sharpe is > 0
    after adjusting for multiple testing and non-normality.

    Math follows Bailey & López de Prado (2014):
      1. De-annualize observed Sharpe to per-observation Sharpe:
         SR_per_obs = SR_annual / sqrt(252 / holding_days)
         (annualized Sharpe has units of sqrt(time), so divide by sqrt(periods/year))
      2. Expected max Sharpe under null (n_trials independent tests, each
         with variance 1/(T-1)):
         E[max] = sqrt(2 * ln(n_trials) / (T-1))   for n_trials > 1
      3. Cornish-Fisher adjustment for non-normality:
         Var(SR̂) ≈ (1 - skew*SR + (kurt-1)/4 * SR^2) / (T-1)
      4. DSR = Φ((SR_per_obs - E[max]) / sqrt(Var))

    Args:
        observed_sharpe: ANNUALIZED Sharpe ratio of the long-short portfolio.
        n_trials: Number of INDEPENDENT strategy configurations evaluated.
        sample_length: Number of independent return observations (rebalance dates).
        skewness: Skewness of the return distribution (not predictions).
        kurtosis: Raw kurtosis (3 = normal). Pandas .kurtosis() returns EXCESS
                  kurtosis, so add 3 before passing.
        holding_days: Forward return horizon in trading days. Used to de-annualize
                      the Sharpe ratio. Default 1 (daily).

    Returns:
        Probability [0, 1] that the true Sharpe is > 0 after deflation.
    """
    # Round 8 — R8-2: Prefer the full Bailey & López de Prado (2014) institutional DSR
    # (math_engine.institutional.deflated_sharpe) over the older dsr_calculator wrapper.
    # Builds a synthetic per-holding-period return series from the observed Sharpe so we
    # can call the richer institutional API (which accepts a pd.Series of returns).
    # Falls back to the older dsr_calculator, then to the inline analytical formula.
    try:
        from math_engine.institutional.deflated_sharpe import deflated_sharpe_ratio as _inst_dsr
        # Reconstruct a per-period return series from the observed annualised Sharpe.
        # sr_annual = mean / std * sqrt(252/h) → mean = sr_annual * std / sqrt(252/h)
        # We use a unit-std normal series scaled to match the observed Sharpe.
        if sample_length < 2 or n_trials < 1:
            return 0.0
        _ann_f = float(np.sqrt(max(1.0, 252.0 / holding_days)))
        _sr_per_obs = observed_sharpe / _ann_f
        _std = 1.0
        _mean = _sr_per_obs * _std
        # AUDIT-FIX (Round 13, ML-7): the synthetic series was plain
        # rng.normal(mean, 1, n) — the skewness/kurtosis arguments were
        # ignored AND seeded RNG noise was injected (two runs of the same
        # backtest could straddle the DSR threshold purely from the seed).
        # Rebuild deterministically: Gaussian quantile grid (i+0.5)/n →
        # inverse CDF, then a Cornish-Fisher expansion so the synthetic
        # series carries the ACTUAL skew/kurtosis (the institutional DSR
        # recomputes moments from the series — the non-normality now
        # reaches the deflation instead of being silently dropped).
        _qq = (np.arange(sample_length) + 0.5) / sample_length
        _z = norm.ppf(_qq)
        _s = float(skewness or 0.0)
        _k = float(kurtosis if kurtosis is not None else 3.0)
        _ex_k = _k - 3.0
        _cf = (
            _z
            + (_s / 6.0) * (_z ** 2 - 1.0)
            + (_ex_k / 24.0) * (_z ** 3 - 3.0 * _z)
            - (_s ** 2 / 36.0) * (2.0 * _z ** 3 - 5.0 * _z)
        )
        _cf = (_cf - _cf.mean()) / max(_cf.std(), 1e-12)
        _synth = _mean + _std * _cf
        _ret_series = pd.Series(_synth)
        _res = _inst_dsr(
            returns=_ret_series,
            n_trials=max(1, n_trials),
            freq_per_year=max(1, int(252 / holding_days)),
        )
        _dsr_val = float(_res.get("deflated_sharpe", 0.0))
        # AUDIT-FIX (Round 6, E-P1-2): the institutional function returns a
        # z-STATISTIC, not a probability. The previous cliff conversion
        # (Φ only when |z| > 3) returned raw z-values in (0,1) clipped to
        # 1.0 — DSR was 1.0 for ANY positive z (SR=+0.5 → 1.0) and 0.0 for
        # any negative one, so the DSR-scaled ML weighting in
        # optimizer.py:5915 saw a strong number where there was none (and
        # `or 0.95` re-inflated the 0.0 case). Always map through Φ.
        _dsr_prob = float(norm.cdf(_dsr_val))
        return float(max(0.0, min(1.0, _dsr_prob)))
    except Exception:
        pass  # fall through to legacy chain

    try:
        from math_engine.dsr_calculator import compute_deflated_sharpe_ratio
        res = compute_deflated_sharpe_ratio([observed_sharpe] * max(1, n_trials), np.random.normal(observed_sharpe / np.sqrt(252), 0.01, sample_length))
        return float(res.get("dsr", 0.0))
    except Exception:
        if sample_length < 2 or n_trials < 1:
            return 0.0
        annualization_factor = float(np.sqrt(252.0 / holding_days))
        sr_per_obs = observed_sharpe / annualization_factor
        expected_max = float(np.sqrt(2.0 * np.log(n_trials) / (sample_length - 1))) if n_trials > 1 else 0.0
        cf_term = max(1.0 - skewness * sr_per_obs + ((kurtosis - 1.0) / 4.0) * sr_per_obs ** 2, 1e-10)
        psr_var = cf_term / (sample_length - 1)
        return float(max(0.0, min(1.0, norm.cdf((sr_per_obs - expected_max) / np.sqrt(psr_var)))))


def evaluate_alpha_decay_exit(
    current_ic: float,
    initial_ic: float,
    elapsed_days: float,
    half_life_days: float,
    safety_margin: float = 0.8,
) -> bool:
    """Evaluate whether factor alpha decay warrants an early position exit.

    Returns True if current IC falls below the theoretical exponential decay curve.
    """
    if half_life_days <= 0 or initial_ic <= 0:
        return False
    decay_curve = initial_ic * np.exp(-np.log(2.0) * elapsed_days / half_life_days)
    return bool(current_ic < (decay_curve * safety_margin))


def walk_forward_efficiency(is_sharpes: list[float], oos_sharpes: list[float]) -> float:
    """Ratio of mean OOS Sharpe to mean IS Sharpe.

    > 0.5 good, > 0.7 excellent, < 0.3 overfit.
    Returns 0.0 if IS Sharpe is zero or negative (no signal to degrade).
    """
    if not is_sharpes or not oos_sharpes:
        return 0.0
    is_mean = float(np.mean(is_sharpes))
    oos_mean = float(np.mean(oos_sharpes))
    if is_mean <= 1e-9:
        return 0.0
    eff = oos_mean / is_mean
    if not np.isfinite(eff):
        return 0.0
    return float(eff)


def quantile_sharpe(
    predictions: pd.Series,
    returns: pd.Series,
    holding_days: int = 10,
    n_quantiles: int = 10,
    rebalance_days: int | None = None,
) -> tuple[float, pd.Series]:
    """Top-decile long, bottom-decile short portfolio Sharpe (annualized).

    Returns (sharpe, ls_returns) where ls_returns is the daily long-short
    return series. The return series is needed for DSR skew/kurt computation.

    Args:
        predictions: Series indexed by (date, ticker) — model predictions.
        returns: Series indexed by (date, ticker) — forward returns.
        holding_days: Forward return horizon in trading days (for annualization).
        n_quantiles: Number of quantiles (default 10 = deciles).
        rebalance_days: Observation interval between consecutive L-S entries
            (default None = holding_days → non-overlapping). When the strategy
            observes h-day forward returns every s < h days (e.g. 10-day labels
            sampled every 5 days), adjacent returns overlap and the naive
            mean/std × √(252/h) Sharpe is INFLATED — the denominator now applies
            the Lo (2002) serial-correlation adjustment over K = ⌈h/s⌉−1 lags
            (AUDIT-FIX Round 8, H7 — Part 2B).

    Returns:
        (annualized_sharpe, ls_return_series)
        If degenerate, returns (0.0, empty Series).
    """
    if len(predictions) == 0 or len(returns) == 0:
        return 0.0, pd.Series(dtype=float)

    # Align predictions and returns
    df = pd.DataFrame({"pred": predictions, "ret": returns})
    df = df.dropna(subset=["pred", "ret"])
    if len(df) == 0:
        return 0.0, pd.Series(dtype=float)

    # Must be MultiIndex (date, ticker) for cross-sectional ranking
    if not isinstance(df.index, pd.MultiIndex):
        # Single cross-section — cannot compute time-series Sharpe
        return 0.0, pd.Series(dtype=float)

    # Rank cross-sectionally by prediction, grouping by first index level (date)
    # Use level=0 to be agnostic to the level name (it may be None or "date")
    df["rank"] = df.groupby(level=0)["pred"].rank(pct=True)

    # Top quantile long, bottom quantile short
    top_threshold = 1.0 - 1.0 / n_quantiles
    bottom_threshold = 1.0 / n_quantiles

    long_ret = df[df["rank"] >= top_threshold]["ret"].groupby(level=0).mean()
    short_ret = df[df["rank"] <= bottom_threshold]["ret"].groupby(level=0).mean()

    ls_ret = long_ret - short_ret
    ls_ret = ls_ret.dropna()

    if len(ls_ret) < 5:
        return 0.0, pd.Series(dtype=float)

    std = float(ls_ret.std())
    if not np.isfinite(std) or std < 1e-10:
        return 0.0, pd.Series(dtype=float)

    # Annualize: (252/holding_days) converts per-holding-period returns to annual
    #
    # AUDIT-FIX (Round 8, H7 — Part 2B): Lo (2002) serial-correlation
    # adjustment. When rebalance_days < holding_days the per-observation L-S
    # returns overlap (an h-day return observed every s days shares h−s days
    # with its neighbor), so the naive std understates risk and inflates the
    # Sharpe. The variance is now:
    #   V = σ0 + 2 Σ_{k=1..K} (1 − k/(K+1)) · cov_k,   K = ⌈h/s⌉ − 1
    # and the annualization uses the ACTUAL sampling frequency 252/s:
    #   SR = mean_per_obs · (252/h) / √(V · 252/s)
    # With s = h (non-overlapping) this reduces exactly to the old formula.
    _s = max(1, int(rebalance_days)) if rebalance_days is not None else holding_days
    _h = max(1, int(holding_days))
    _K = max(0, int(np.ceil(_h / _s)) - 1)
    _v0 = float(ls_ret.var(ddof=1)) if len(ls_ret) > 1 else float(std ** 2)
    if _K > 0 and len(ls_ret) > _K + 2:
        _r = ls_ret.to_numpy(dtype=float)
        _r = _r[~np.isnan(_r)]
        _m = _r.mean()
        _d = _r - _m
        _v_adj = float(np.sum(_d ** 2) / len(_d))
        for k in range(1, _K + 1):
            _cov_k = float(np.sum(_d[:-k] * _d[k:]) / len(_d))
            _v_adj += 2.0 * (1.0 - k / (_K + 1)) * _cov_k
        _v_adj = max(_v_adj, 1e-18)
        _annual_mean = float(ls_ret.mean()) * (252.0 / _h)
        _annual_var = _v_adj * (252.0 / _s)
        sharpe = float(_annual_mean / np.sqrt(_annual_var))
    else:
        annualization = float(np.sqrt(252.0 / holding_days))
        sharpe = float(ls_ret.mean() / std * annualization)
    if not np.isfinite(sharpe):
        return 0.0, pd.Series(dtype=float)
    return sharpe, ls_ret


def neutralize_alpha(
    alpha: pd.Series,
    factor_exposures: pd.DataFrame,
    return_r2: bool = False,
) -> pd.Series | tuple[pd.Series, float]:
    """OLS residualization of alpha against factor exposures.

    Removes systematic factor contamination (beta, momentum, size, etc.) from
    raw alpha scores so the residual represents *stock-specific* information.

    Math:
        ε = α - B (B'B)^{-1} B' α
        where B is the (N × K) factor exposure matrix.
        ε is the OLS residual — alpha unexplained by the factors.

    Args:
        alpha: Series[ticker → raw_alpha_score].
        factor_exposures: DataFrame[ticker × factor] of standardized z-scores.
            Typically the z_* columns already present in signal_df.
        return_r2: If True, returns tuple (residual_series, r2_score).

    Returns:
        Residual alpha Series[ticker] (or tuple if return_r2=True).
    """
    if alpha is None or len(alpha) == 0:
        return (alpha, 0.0) if return_r2 else alpha

    # Align: keep only tickers present in both
    common = alpha.index.intersection(factor_exposures.index)
    if len(common) < 5:
        return (alpha, 0.0) if return_r2 else alpha  # not enough data to residualize

    a = alpha.loc[common].to_numpy(dtype=float)
    B = factor_exposures.loc[common].fillna(0.0).to_numpy(dtype=float)

    # Guard: drop near-zero-variance columns (constant factors add no info)
    col_stds = B.std(axis=0)
    B = B[:, col_stds > 1e-6]

    if B.shape[1] == 0 or B.shape[0] <= B.shape[1]:
        return (alpha, 0.0) if return_r2 else alpha  # degenerate: more factors than observations

    try:
        # OLS projection: a_hat = B (B'B)^{-1} B' a
        coef, _, _, _ = np.linalg.lstsq(B, a, rcond=None)
        a_hat = B @ coef
        residual = a - a_hat

        # Calculate true factor R² (explained variance fraction) before rescaling
        var_a = np.var(a)
        var_res = np.var(residual)
        r2 = max(0.0, min(1.0, 1.0 - (var_res / (var_a + 1e-12))))

        # Re-standardize residual to have same scale as input alpha
        if np.std(residual) > 1e-9:
            residual = residual / np.std(residual) * np.std(a)

        result = alpha.copy()
        result.loc[common] = residual
        return (result, r2) if return_r2 else result
    except Exception:
        return (alpha, 0.0) if return_r2 else alpha  # numerical failure — return original unchanged


def ic_half_life(historical_ics: list[float]) -> dict:
    """AR(1)-based IC half-life estimator.

    Fits an AR(1) process to the historical OOS IC series:
        IC_t = μ + φ * IC_{t-1} + ε_t

    The mean-reversion rate φ (between -1 and 1) determines how quickly
    the IC reverts to its mean after a shock. The half-life is:
        τ = -ln(2) / ln(|φ|)   (days, in fold-units)

    A short half-life (< 21 days) means the factor's edge is decaying quickly —
    the model should be refitted or the factor weights should be adjusted.

    Args:
        historical_ics: List of OOS IC values from successive CV folds.
            Typically updated each time the engine runs fit().

    Returns:
        dict with keys:
            - half_life_days: float — mean reversion half-life (fold-units).
                              -1.0 means insufficient data.
            - is_decaying: bool — True if IC trend is negative.
            - current_ic: float — most recent IC value.
            - mean_ic: float — historical mean IC.
            - decay_rate: float — AR(1) coefficient φ (higher = slower decay).
    """
    result = {
        "half_life_days": -1.0,
        "is_decaying": False,
        "current_ic": 0.0,
        "mean_ic": 0.0,
        "decay_rate": 0.0,
    }

    if len(historical_ics) < 6:
        return result  # need at least 6 observations for meaningful AR(1)

    ic_arr = np.array(historical_ics, dtype=float)
    # Remove NaN
    ic_arr = ic_arr[np.isfinite(ic_arr)]
    if len(ic_arr) < 6:
        return result

    result["current_ic"] = float(ic_arr[-1])
    result["mean_ic"] = float(ic_arr.mean())
    result["is_decaying"] = bool(float(ic_arr[-3:].mean()) < float(ic_arr[:-3].mean()))

    try:
        # AR(1): regress IC_t on IC_{t-1}
        y = ic_arr[1:]
        x = ic_arr[:-1].reshape(-1, 1)

        # OLS: φ = (x'x)^{-1} x'y
        x_demean = x - x.mean()
        y_demean = y - y.mean()
        denom = float(np.dot(x_demean.ravel(), x_demean.ravel()))
        if denom < 1e-12:
            return result

        phi = float(np.dot(x_demean.ravel(), y_demean) / denom)
        phi = float(np.clip(phi, -0.9999, 0.9999))  # stability constraint

        result["decay_rate"] = phi

        # Half-life: number of periods for IC to decay halfway to mean
        # τ = -ln(2) / ln(|φ|)
        if abs(phi) > 1e-6:
            half_life = -np.log(2.0) / np.log(abs(phi))
            result["half_life_days"] = float(half_life) if np.isfinite(half_life) else -1.0
    except Exception:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
        pass

    return result


def compute_transfer_coefficient(target_weights: dict, bench_weights: dict, alpha_scores: dict) -> float:
    """
    Computes Grinold-Kahn Transfer Coefficient (TC).
    TC = corr(w_target - w_bench, alpha_scores)
    Measures how unconstrained alpha signals translate into actual active portfolio weights.
    """
    if not target_weights or not alpha_scores:
        return 0.0

    tickers = [t for t in target_weights if t.upper() != "CASH" and t in alpha_scores]
    if len(tickers) < 3:
        return 0.0

    active_w = np.array([target_weights.get(t, 0.0) - bench_weights.get(t, 0.0) for t in tickers], dtype=float)
    alphas = np.array([alpha_scores.get(t, 0.0) for t in tickers], dtype=float)

    if np.std(active_w) < 1e-12 or np.std(alphas) < 1e-12:
        return 0.0

    try:
        tc_val = float(spearmanr(active_w, alphas)[0])
        return round(float(tc_val), 4) if np.isfinite(tc_val) else 0.0
    except Exception:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
        return 0.0


def compute_ic_t_statistic(ic_series: Union[List[float], np.ndarray]) -> float:
    """
    Computes t-statistic of Information Coefficient (IC) time series:
    t_IC = mean(IC) * sqrt(N - 1) / std(IC)
    Prunes factors that fail a 95% 2-tailed Student's t-test (|t_IC| < 2.0).
    """
    ic_arr = np.asarray(ic_series, dtype=float)
    ic_arr = ic_arr[np.isfinite(ic_arr)]
    n = len(ic_arr)
    if n < 3:
        return 0.0

    mean_ic = float(np.mean(ic_arr))
    std_ic = float(np.std(ic_arr, ddof=1)) + 1e-9

    t_stat = (mean_ic * np.sqrt(n - 1.0)) / std_ic
    return round(float(t_stat), 4)
