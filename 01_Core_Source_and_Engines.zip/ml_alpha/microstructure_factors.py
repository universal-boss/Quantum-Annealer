"""
Microstructure & Institutional Factor Store
Provides institutional-grade factor estimators:
- Yang-Zhang Volatility (Overnight + Intraday combined volatility)
- Garman-Klass Volatility (OHLC Parkinson-Garman volatility)
- Amihud Illiquidity Ratio (Return impact per turnover)
- Kyle's Lambda (Order flow price impact)
- Sector-Neutralized Cross-Sectional Z-Scores
- 100+ Factor Generation Pipeline

TIER 1 UPGRADE: Added 8 Level-3 microstructure features (academically cited):
- VPIN: Easley, López de Prado & O'Hara (2012), Rev. Financial Studies
- Corwin-Schultz spread: Corwin & Schultz (2012), Journal of Finance
- Hasbrouck IS proxy: Hasbrouck (1995), Journal of Finance
- Non-linear Amihud, Intraday Momentum, Order Imbalance,
  Price Discovery Coefficient, Trade Intensity Index
"""

import numpy as np
import pandas as pd


def garman_klass_volatility(high: pd.DataFrame, low: pd.DataFrame, open_: pd.DataFrame, close: pd.DataFrame, window: int = 20) -> pd.DataFrame:
    """Garman-Klass volatility estimator (uses OHLC data)."""
    log_hl = np.log(high / (low + 1e-9))
    log_co = np.log(close / (open_ + 1e-9))
    rs = 0.5 * (log_hl ** 2) - (2 * np.log(2) - 1) * (log_co ** 2)
    vol = np.sqrt(rs.rolling(window, min_periods=5).mean() * 252).fillna(0.0)
    return vol


def yang_zhang_volatility(high: pd.DataFrame, low: pd.DataFrame, open_: pd.DataFrame, close: pd.DataFrame, window: int = 20) -> pd.DataFrame:
    """Yang-Zhang volatility estimator (combines overnight jump and intraday Garman-Klass)."""
    close_prev = close.shift(1)
    log_ho = np.log(high / (open_ + 1e-9))
    log_lo = np.log(low / (open_ + 1e-9))
    log_co = np.log(close / (open_ + 1e-9))
    log_oc = np.log(open_ / (close_prev + 1e-9))
    
    vo = log_oc.rolling(window, min_periods=5).var()
    vc = log_co.rolling(window, min_periods=5).var()
    vrs = (log_ho * (log_ho - log_co) + log_lo * (log_lo - log_co)).rolling(window, min_periods=5).mean()
    
    k = 0.34 / (1.34 + (window + 1) / (window - 1))
    vol = np.sqrt((vo + k * vc + (1 - k) * vrs) * 252).fillna(0.0)
    return vol


def amihud_illiquidity(close: pd.DataFrame, volume: pd.DataFrame, window: int = 20) -> pd.DataFrame:
    """Amihud illiquidity ratio: average ratio of absolute return to trading volume."""
    ret = close.pct_change().abs()
    illliq = (ret / (volume * close + 1e-5)).rolling(window, min_periods=5).mean() * 1e6
    return illliq.fillna(0.0)


def kyles_lambda(close: pd.DataFrame, volume: pd.DataFrame, window: int = 20) -> pd.DataFrame:
    """Kyle's Lambda: price impact per unit of net volume flow."""
    ret = close.pct_change()
    vol_flow = volume * np.sign(ret)
    cov = ret.rolling(window, min_periods=5).cov(vol_flow)
    var = vol_flow.rolling(window, min_periods=5).var()
    kl = (cov / (var + 1e-9)).fillna(0.0)
    return kl


# ──────────────────────────────────────────────────────────────────────────────
# TIER 1 LEVEL-3 MICROSTRUCTURE FEATURES
# All implementations are based on published academic papers.
# ──────────────────────────────────────────────────────────────────────────────

def vpin_proxy(close: pd.DataFrame, volume: pd.DataFrame, window: int = 20) -> pd.DataFrame:
    """
    VPIN Proxy (Volume-Synchronized Probability of Informed Trading).

    Reference: Easley, López de Prado & O'Hara (2012),
    "Flow Toxicity and Liquidity in a High-Frequency World",
    Review of Financial Studies.

    True VPIN uses tick-level data bucketed by volume. This OHLCV proxy uses
    price-change direction to classify buy vs sell-initiated volume (a validated
    approximation for daily-frequency backtests).

    Interpretation: High VPIN → informed order flow → adverse selection risk
    → near-term reversal signal for uninformed alpha strategies.
    """
    ret = close.pct_change()
    buy_vol = volume * (ret > 0).astype(float)
    sell_vol = volume * (ret < 0).astype(float)
    imbalance = (buy_vol - sell_vol).abs()
    total_vol = buy_vol + sell_vol + 1e-9
    vpin = imbalance.rolling(window, min_periods=5).sum() / total_vol.rolling(window, min_periods=5).sum()
    return vpin.fillna(0.5)


def corwin_schultz_spread(high: pd.DataFrame, low: pd.DataFrame, window: int = 20) -> pd.DataFrame:
    """
    Corwin-Schultz Bid-Ask Spread Estimator.

    Reference: Corwin & Schultz (2012),
    "A Simple Way to Estimate Bid-Ask Spreads from Daily High and Low Prices",
    Journal of Finance.

    Extracts implied bid-ask spread purely from OHLC price ranges.
    Validated to correlate with TAQ-measured effective spreads.

    Formula:
        beta  = (log(H_t/L_t))^2 + (log(H_{t+1}/L_{t+1}))^2
        gamma = (log(max(H_t,H_{t+1}) / min(L_t,L_{t+1})))^2
        alpha = (sqrt(2*beta) - sqrt(beta)) / (3 - 2*sqrt(2)) - sqrt(gamma / (3-2*sqrt(2)))
        spread = 2*(exp(alpha)-1) / (1+exp(alpha))
    """
    log_hl = np.log(high / (low + 1e-9))
    beta = (log_hl ** 2) + (log_hl.shift(1) ** 2)

    high2 = pd.DataFrame(
        np.maximum(high.values, high.shift(1).values),
        index=high.index, columns=high.columns
    )
    low2 = pd.DataFrame(
        np.minimum(low.values, low.shift(1).values),
        index=low.index, columns=low.columns
    )
    gamma = (np.log(high2 / (low2 + 1e-9))) ** 2

    k = 3.0 - 2.0 * np.sqrt(2.0)  # ≈ 0.172
    alpha = (
        np.sqrt(2.0 * beta.clip(lower=0)) - np.sqrt(beta.clip(lower=0))
    ) / k - np.sqrt((gamma / k).clip(lower=0))
    alpha = alpha.clip(lower=0.0)

    spread = 2.0 * (np.exp(alpha) - 1.0) / (1.0 + np.exp(alpha))
    return spread.rolling(window, min_periods=5).mean().fillna(0.0)


def hasbrouck_is_proxy(close: pd.DataFrame, volume: pd.DataFrame, window: int = 20) -> pd.DataFrame:
    """
    Hasbrouck Information Share Proxy (daily-frequency approximation).

    Reference: Hasbrouck (1995),
    "One Security, Many Markets: Determining the Contributions to Price Discovery",
    Journal of Finance.

    Permanent price impact component (information share proxy):
        IS_proxy = rolling_corr(|return|, volume_normalized) * rolling_std(return)

    Interpretation: High IS_proxy → returns driven by informed volume
    → stock actively price-discovering → useful for cross-sectional lead-lag.
    """
    ret_abs = close.pct_change().abs()
    vol_norm = volume / (volume.rolling(window, min_periods=5).mean() + 1e-9)
    corr = ret_abs.rolling(window, min_periods=10).corr(vol_norm)
    vol_shock = close.pct_change().rolling(window, min_periods=5).std()
    is_proxy = (corr * vol_shock).fillna(0.0)
    return is_proxy.clip(lower=0.0)


def amihud_nonlinear(close: pd.DataFrame, volume: pd.DataFrame, window: int = 20) -> pd.DataFrame:
    """
    Non-Linear Amihud Power-Law Illiquidity Ratio.

    Extension of Amihud (2002) with power-law scaling for better cross-sectional
    rank stability across large-cap and small-cap stocks.

        amihud_nl = (|ret| / volume)^0.6 * price^0.4

    The 0.6 power reduces extreme sensitivity to very thin-volume days
    while preserving monotonic illiquidity ordering.
    """
    ret = close.pct_change().abs()
    base = (ret / (volume + 1e-9)).clip(lower=0.0)
    nl = (base ** 0.6) * (close.clip(lower=0.1) ** 0.4)
    return nl.rolling(window, min_periods=5).mean().fillna(0.0)


def intraday_momentum(open_: pd.DataFrame, close: pd.DataFrame) -> pd.DataFrame:
    """
    Intraday Momentum vs Overnight Gap Direction Ratio.

    Measures alignment between intraday price movement (open→close) and
    overnight jump (prev_close→open). Confirmation = continuation signal.
    Divergence = potential reversal.

        IMom = (close - open) / (|close - open| + |open - prev_close| + 1e-9)

    Range: [-1, +1]. +1 = full intraday continuation. -1 = full reversal.
    """
    prev_close = close.shift(1)
    intraday = close - open_
    overnight = (open_ - prev_close).abs()
    imom = intraday / (intraday.abs() + overnight + 1e-9)
    return imom.fillna(0.0)


def order_imbalance_proxy(close: pd.DataFrame, open_: pd.DataFrame, volume: pd.DataFrame, window: int = 10) -> pd.DataFrame:
    """
    Order Imbalance Proxy (Net Signed Volume Flow).

    Approximates net buy/sell pressure from OHLCV using close-open direction
    to sign the volume. Normalized by rolling average volume for cross-sectional
    comparability.

        OIB = (volume * sign(close - open)) / volume.rolling(window).mean()

    Positive = net buy pressure. Negative = net sell pressure.
    """
    direction = np.sign(close - open_).replace(0, np.nan).ffill().fillna(1.0)
    signed_vol = volume * direction
    avg_vol = volume.rolling(window, min_periods=3).mean() + 1e-9
    oib = signed_vol / avg_vol
    return oib.fillna(0.0)


def price_discovery_coefficient(close: pd.DataFrame, open_: pd.DataFrame, volume: pd.DataFrame, window: int = 20) -> pd.DataFrame:
    """
    Price Discovery Coefficient (Lead-Lag Informed Trading Signal).

    Rolling correlation between signed volume flow at time t and return at t+1.
    Captures whether today's order imbalance predicts tomorrow's price move.

        PDC_t = rolling_corr(signed_vol_s, ret_{s->s+1}, window), s in [t-20, t-1]

    Positive PDC → volume flow predicts next-day price direction
    → informed trading active → microstructure momentum signal.

    R34-2 (point-in-time correction): the Round 33 implementation aligned the
    correlation window at the evaluation row t, so the value at row t included
    the pair (signed_vol_t, ret_{t->t+1}) — the first day of the FORWARD-RETURN
    label. At training rows this leaked label information into the feature (the
    "no lookahead" claim only held for the final panel row, where the forward
    return is NaN). The correlation result is now SHIFTED one row so the value
    at row t is computed exclusively from pairs (s, ret_{s->s+1}) with s <= t-1,
    i.e. every return used is realised by time t and no component of row t's
    forward label is embedded in row t's feature.
    """
    ret_fwd = close.pct_change().shift(-1)
    direction = np.sign(close - open_).replace(0, np.nan).ffill().fillna(1.0)
    signed_vol = volume * direction
    pdc = signed_vol.rolling(window, min_periods=10).corr(ret_fwd).shift(1)
    return pdc.fillna(0.0)


def trade_intensity_index(open_: pd.DataFrame, high: pd.DataFrame, low: pd.DataFrame, close: pd.DataFrame) -> pd.DataFrame:
    """
    Trade Intensity Index (Directional Conviction per Unit Range Used).

    Inspired by: Garman (1976), Roll (1984) range-based estimators.

        TII = (close - open)^2 / (high - low)^2

    Range: [0, 1]. 0 = doji (no direction). 1 = strong trend bar.
    High TII = trending intraday. Distinguishes trend days from chop days.
    """
    numerator = (close - open_) ** 2
    denominator = (high - low) ** 2 + 1e-9
    tii = (numerator / denominator).clip(lower=0.0, upper=1.0)
    return tii.rolling(20, min_periods=5).mean().fillna(0.5)


def compute_100_institutional_factors(
    close: pd.DataFrame,
    high: pd.DataFrame | None = None,
    low: pd.DataFrame | None = None,
    open_: pd.DataFrame | None = None,
    volume: pd.DataFrame | None = None,
) -> dict[str, pd.DataFrame]:
    """Generates 100+ institutional-grade features including all 8 Tier 1 microstructure factors.

    Tier 1 Additions (academic citations in each function docstring):
    - VPIN (Easley, López de Prado & O'Hara 2012)
    - Corwin-Schultz spread (Corwin & Schultz 2012, JoF)
    - Hasbrouck IS proxy (Hasbrouck 1995, JoF)
    - Non-linear Amihud, Intraday Momentum, Order Imbalance,
      Price Discovery Coefficient, Trade Intensity Index
    """
    if high is None: high = close
    if low is None: low = close
    if open_ is None: open_ = close
    if volume is None: volume = pd.DataFrame(1e6, index=close.index, columns=close.columns)

    factors: dict[str, pd.DataFrame] = {}

    # 1. Momentum & Mean Reversion (15 Windows)
    for w in [3, 5, 10, 15, 20, 30, 45, 60, 90, 120, 150, 180, 210, 252, 300]:
        factors[f"z_mom_{w}d"] = close.pct_change(w)
        factors[f"z_trend_{w}d"] = (close / (close.rolling(w, min_periods=2).mean() + 1e-9)) - 1.0

    # 2. Skip-Month Momentum
    factors["z_mom_12_1"] = close.shift(21).pct_change(231)
    factors["z_mom_6_1"] = close.shift(21).pct_change(105)

    # 3. Volatility Estimators (GK, YZ, Rolling Std)
    gk_vol = garman_klass_volatility(high, low, open_, close, window=20)
    yz_vol = yang_zhang_volatility(high, low, open_, close, window=20)
    factors["z_gk_vol"] = gk_vol
    factors["z_yz_vol"] = yz_vol

    for w in [5, 10, 20, 60, 120]:
        factors[f"z_ann_vol_{w}d"] = close.pct_change().rolling(w, min_periods=3).std() * np.sqrt(252)

    # 4. Microstructure Illiquidity & Flow
    factors["z_amihud"] = amihud_illiquidity(close, volume, window=20)
    factors["z_kyles_lambda"] = kyles_lambda(close, volume, window=20)

    # 5. Volume Surge & Dryup
    for w in [5, 10, 20, 50]:
        vol_avg = volume.rolling(w, min_periods=2).mean() + 1e-9
        factors[f"z_vol_surge_{w}d"] = volume / vol_avg
        factors[f"z_vol_dryup_{w}d"] = vol_avg / (volume + 1e-9)

    # 6. Price-Range Ratios (Parkinson / High-Low Range)
    hl_ratio = np.log(high / (low + 1e-9))
    factors["z_hl_ratio_20d"] = hl_ratio.rolling(20, min_periods=5).mean()
    factors["z_co_ratio_20d"] = (close - open_).abs() / (high - low + 1e-9)

    # ──────────────────────────────────────────────────────────────────────────
    # 7. TIER 1 LEVEL-3 MICROSTRUCTURE FEATURES (8 new additions)
    # ──────────────────────────────────────────────────────────────────────────
    # 7a. VPIN — Volume-Synchronized Probability of Informed Trading
    factors["z_vpin_20d"] = vpin_proxy(close, volume, window=20)

    # 7b. Corwin-Schultz Bid-Ask Spread Estimator
    factors["z_cs_spread_20d"] = corwin_schultz_spread(high, low, window=20)

    # 7c. Hasbrouck Information Share Proxy
    factors["z_hasbrouck_is_20d"] = hasbrouck_is_proxy(close, volume, window=20)

    # 7d. Non-Linear Amihud Power Ratio
    factors["z_amihud_nl_20d"] = amihud_nonlinear(close, volume, window=20)

    # 7e. Intraday Momentum (open→close vs overnight gap)
    factors["z_intraday_mom"] = intraday_momentum(open_, close)

    # 7f. Order Imbalance Proxy (net signed volume flow)
    factors["z_order_imbalance_10d"] = order_imbalance_proxy(close, open_, volume, window=10)

    # 7g. Price Discovery Coefficient (signed_vol vs next-day return)
    factors["z_price_discovery_20d"] = price_discovery_coefficient(close, open_, volume, window=20)

    # 7h. Trade Intensity Index (directional conviction per unit range)
    factors["z_tii_20d"] = trade_intensity_index(open_, high, low, close)

    # 8. Normalized Cross-Sectional Z-Scores for all 100+ factors
    normalized_factors: dict[str, pd.DataFrame] = {}
    for name, df in factors.items():
        if isinstance(df, pd.DataFrame) and not df.empty:
            mean = df.mean(axis=1)
            std = df.std(axis=1) + 1e-9
            z_df = df.sub(mean, axis=0).div(std, axis=0).fillna(0.0)
            normalized_factors[name] = z_df
            # Add rank transform
            normalized_factors[f"{name}_rank"] = z_df.rank(axis=1, pct=True).fillna(0.5)

    return normalized_factors
