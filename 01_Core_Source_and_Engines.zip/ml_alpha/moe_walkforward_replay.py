"""
ml_alpha/moe_walkforward_replay.py
==================================
Walk-Forward Out-of-Sample Simulation & Replay Engine for:
1. Baseline Static Model (Single-Archetype)
2. Dynamic Macro Regime Mixture of Experts (MoE) Router
3. Full SOTA: Dynamic MoE Router + Sector-Neutral Cross-Sectional Ranking

Follows Marcos López de Prado's "Advances in Financial Machine Learning":
- Purged and Embargoed Walk-Forward Cross-Validation (WalkForwardCV)
- Annualized CAGR, Volatility, Sharpe, Sortino, Max Drawdown, Calmar Ratio, and Deflated Sharpe Ratio (DSR)
"""
from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ml_alpha.walk_forward import WalkForwardCV
from ml_alpha.regime_ensemble import (
    RegimeEnsembleRouter,
    apply_sector_neutral_ranking,
    detect_macro_regime_state,
)
from math_engine.institutional.deflated_sharpe import deflated_sharpe_ratio

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("moe_walkforward")

ROOT = Path(__file__).resolve().parent.parent


def generate_benchmark_universe(n_assets: int = 40, n_days: int = 1000, seed: int = 42) -> Tuple[pd.DataFrame, pd.DataFrame, Dict[str, str], pd.Series]:
    """
    Generates a realistic multi-year panel of asset prices, factors, sectors, and benchmark returns.
    """
    rng = np.random.default_rng(seed)  # ROUND 45: local rng — was a global np.random.seed
    dates = pd.date_range("2022-01-01", periods=n_days, freq="B")
    tickers = [f"ASSET_{i:03d}.NS" for i in range(n_assets)]
    sectors_list = ["TECH", "FINANCE", "HEALTHCARE", "INDUSTRIALS", "CONSUMER"]
    sectors = {t: sectors_list[i % len(sectors_list)] for i, t in enumerate(tickers)}

    # Benchmark trajectory with bull, chop, and stress regimes
    bench_shocks = rng.randn(n_days) * 0.010
    # Add regime cycles
    bench_shocks[:300] += 0.0008     # Bull
    bench_shocks[300:600] -= 0.0002   # Chop
    bench_shocks[600:750] -= 0.0015   # Stress Drawdown
    bench_shocks[750:] += 0.0010      # Bull Recovery
    bench_returns = pd.Series(bench_shocks, index=dates)

    # Asset prices with sector co-movements and idiosyncratic alpha
    returns_dict = {}
    for i, t in enumerate(tickers):
        sec = sectors[t]
        sec_idx = sectors_list.index(sec)
        sec_factor = np.sin(np.linspace(0, 8 * np.pi, n_days) + sec_idx) * 0.003
        idio = rng.randn(n_days) * 0.015
        beta = 0.8 + 0.4 * (i / n_assets)
        r = beta * bench_returns.values + sec_factor + idio
        returns_dict[t] = r

    returns_df = pd.DataFrame(returns_dict, index=dates)
    prices_df = (1.0 + returns_df).cumprod() * 100.0

    return prices_df, returns_df, sectors, bench_returns


def run_walk_forward_simulation(
    n_splits: int = 4,
    train_days: int = 252,
    test_days: int = 63,
    quick: bool = False,
) -> Dict[str, Any]:
    """
    Executes walk-forward evaluation comparing Baseline vs MoE vs MoE+SectorNeutral.
    """
    n_assets = 20 if quick else 40
    n_days = 600 if quick else 1000
    prices_df, returns_df, sectors, bench_rets = generate_benchmark_universe(n_assets=n_assets, n_days=n_days)

    splitter = WalkForwardCV(
        n_splits=n_splits,
        train_period_days=train_days,
        test_period_days=test_days,
        purge_window_days=14,
        forward_return_days=21,
    )

    dates = prices_df.index
    strategy_returns = {
        "Baseline_Static": [],
        "MoE_Regime_Adaptive": [],
        "MoE_Sector_Neutral_SOTA": [],
        "Benchmark_NIFTY": [],
    }

    fold_count = 0
    for fold in splitter.split(dates):
        fold_count += 1
        test_dates = fold.test_idx
        if len(test_dates) < 10:
            continue

        # In each test period, evaluate factors and rebalance
        sub_returns = returns_df.loc[test_dates]
        bench_sub = bench_rets.loc[test_dates]
        strategy_returns["Benchmark_NIFTY"].extend(bench_sub.values)

        # Generate synthetic factor panel for the test slice
        n_t = len(returns_df.columns)
        all_factors = [
            "z_rs_rating", "z_mom_3m", "z_mom_6m", "z_vcp", "z_vpin_toxicity", "z_range_contraction",
            "z_vol_surge", "z_ma_compression", "z_obv_slope", "z_ann_vol", "z_trend_quality",
            "z_beta", "z_downside_vol", "z_sast_vel", "z_bulk_deal_footprint", "z_cmf", "z_delivery",
            "z_updown_vol", "z_pead", "z_float_squeeze", "z_volume_dryup", "z_roe", "z_pe_inv",
            "z_de_inv", "z_rev_growth", "z_drawdown", "z_neural_sde", "z_patch_tst", "z_base_tightness",
        ]
        # Cross-sectional factors with realistic momentum & quality persistence
        _rng = np.random.default_rng(fold_count * 100)  # ROUND 45: local rng
        signal_data = {f: _rng.randn(n_t) for f in all_factors}
        # Add real momentum persistence
        signal_data["z_mom_3m"] = (returns_df.loc[:test_dates[0]].iloc[-63:].sum().values - 0.05) / 0.10
        signal_df = pd.DataFrame(signal_data, index=returns_df.columns)

        # 1. Baseline Strategy: Pure Momentum
        router_base = RegimeEnsembleRouter(primary_archetype="momentum", use_dynamic_regime_tilt=False)
        alpha_base, _ = router_base.predict_ensemble(signal_df)
        top_base = alpha_base.nlargest(max(4, n_t // 4)).index
        ret_base = sub_returns[top_base].mean(axis=1).values
        strategy_returns["Baseline_Static"].extend(ret_base)

        # 2. MoE Regime Adaptive (without sector neutrality)
        regime_info = {"Regime": "Bull_Trending" if bench_sub.mean() > 0.0005 else ("Turbulent Bear" if bench_sub.mean() < -0.0005 else "Sideways")}
        router_moe = RegimeEnsembleRouter(primary_archetype="momentum", use_dynamic_regime_tilt=True)
        alpha_moe, _ = router_moe.predict_ensemble(signal_df, regime_info=regime_info)
        top_moe = alpha_moe.nlargest(max(4, n_t // 4)).index
        ret_moe = sub_returns[top_moe].mean(axis=1).values
        strategy_returns["MoE_Regime_Adaptive"].extend(ret_moe)

        # 3. MoE + Sector-Neutral Cross-Sectional Ranking (SOTA)
        alpha_sota = apply_sector_neutral_ranking(
            pd.DataFrame({"alpha_score": alpha_moe}, index=signal_df.index),
            sectors=sectors,
            lambda_sector=0.50,
        )
        top_sota = alpha_sota.nlargest(max(4, n_t // 4)).index
        ret_sota = sub_returns[top_sota].mean(axis=1).values
        strategy_returns["MoE_Sector_Neutral_SOTA"].extend(ret_sota)

    # Compute Performance Metrics across strategies
    metrics_summary = {}
    for strat, r_list in strategy_returns.items():
        r = np.asarray(r_list, dtype=float)
        if len(r) < 10:
            continue

        n_days_total = len(r)
        cagr = float((np.prod(1.0 + r) ** (252.0 / n_days_total)) - 1.0)
        ann_vol = float(np.std(r) * np.sqrt(252.0))
        sharpe = float((np.mean(r) / (np.std(r) + 1e-9)) * np.sqrt(252.0))

        downside_r = r[r < 0]
        downside_vol = float(np.std(downside_r) * np.sqrt(252.0)) if len(downside_r) > 2 else ann_vol
        sortino = float((np.mean(r) / (downside_vol + 1e-9)) * np.sqrt(252.0))

        cum = np.cumprod(1.0 + r)
        running_max = np.maximum.accumulate(cum)
        dd = (cum - running_max) / running_max
        max_dd = float(np.min(dd))
        calmar = float(cagr / (abs(max_dd) + 1e-9))

        dsr_res = deflated_sharpe_ratio(
            returns=r,
            n_trials=10,
            freq_per_year=252,
        )

        metrics_summary[strat] = {
            "CAGR_%": round(cagr * 100.0, 2),
            "Annual_Vol_%": round(ann_vol * 100.0, 2),
            "Sharpe": round(sharpe, 2),
            "Sortino": round(sortino, 2),
            "Max_Drawdown_%": round(max_dd * 100.0, 2),
            "Calmar": round(calmar, 2),
            "DSR_z": round(dsr_res.get("deflated_sharpe", 0.0), 2),
            "DSR_p": round(dsr_res.get("p_value", 1.0), 4),
            "DSR_verdict": "PASS" if dsr_res.get("p_value", 1.0) < 0.05 else "FAIL",
        }

    return metrics_summary


def print_walkforward_leaderboard(metrics: Dict[str, Any]) -> None:
    """Prints formatted institutional comparison table."""
    headers = ["Strategy Variant", "CAGR %", "Ann Vol %", "Sharpe", "Sortino", "Max DD %", "Calmar", "DSR z", "Verdict"]
    print("\n" + "=" * 100)
    print("WALK-FORWARD OUT-OF-SAMPLE BENCHMARK LEADERBOARD (4 Folds, Purged & Embargoed)")
    print("=" * 100)
    print(f"{headers[0]:<30} | {headers[1]:<8} | {headers[2]:<9} | {headers[3]:<6} | {headers[4]:<7} | {headers[5]:<8} | {headers[6]:<6} | {headers[7]:<6} | {headers[8]}")
    print("-" * 100)

    for strat, m in metrics.items():
        print(
            f"{strat:<30} | {m['CAGR_%']:>7.2f}% | {m['Annual_Vol_%']:>8.2f}% | {m['Sharpe']:>6.2f} | "
            f"{m['Sortino']:>7.2f} | {m['Max_Drawdown_%']:>7.2f}% | {m['Calmar']:>6.2f} | {m['DSR_z']:>6.2f} | {m['DSR_verdict']}"
        )
    print("=" * 100 + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run Walk-Forward Simulation for MoE & Sector-Neutral Ranking")
    parser.add_argument("--quick", action="store_true", help="Run rapid verification mode")
    args = parser.parse_args()

    results = run_walk_forward_simulation(quick=args.quick)
    print_walkforward_leaderboard(results)
