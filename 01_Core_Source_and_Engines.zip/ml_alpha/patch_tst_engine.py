"""
ml_alpha/patch_tst_engine.py
============================
PatchTST-inspired patch attention heuristic engine.

AUDIT-FIX (Round 8, C5 — Part 2B):
  The previous implementation had three integrity defects:
  1. Degraded-data paths (< 20 rows, < 3 patches) returned HARDCODED
     "model scores" (72.5 / 75.0 / 70.0) presented as computed PatchTST
     outputs. Untrained numbers presented as model scores are fabrication;
     they now return None + an explicit reason.
  2. The "Multi-Head Self-Attention" was computed with UNTRAINED random
     projections (RandomState(42) Q/K/V matrices) — the attention weights
     were deterministic noise. Replaced with a REAL kernel self-attention:
     the softmax attention is computed directly over the patch-similarity
     matrix (patches as their own queries/keys — identity projection, no
     random weights), so the recency-concentration signal is an actual,
     well-defined similarity statistic of the data.
  3. The class claimed to be a "Patch Time Series Transformer"; there is no
     trained transformer here. The docstring and output now say exactly
     what this is: an untrained patch-similarity heuristic whose scores
     are relative accumulation-screening signals, NOT model predictions.

Segments financial OHLCV timeseries into sub-series-level patches and
computes kernel self-attention across temporal scales to detect
institutional accumulation blocks and Stage-2 momentum continuation.
"""
from __future__ import annotations
import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, List, Optional, Tuple

logger = logging.getLogger(__name__)


class PatchTSTAlphaEngine:
    """
    Patch-similarity attention heuristic for temporal alpha screening.

    NOTE (C5 fix): this is an UNTRAINED statistical heuristic, not a trained
    PatchTST transformer. Use its scores only as relative ranking signals
    within a screening pipeline; do not present them as model predictions.
    """

    def __init__(self, patch_len: int = 5, stride: int = 2, d_model: int = 32, n_heads: int = 4):
        self.patch_len = patch_len
        self.stride = stride
        # d_model / n_heads retained for API compatibility; the kernel
        # attention below needs no projection dimension.
        self.d_model = d_model
        self.n_heads = n_heads

    def _extract_patches(self, series: np.ndarray) -> np.ndarray:
        """Slices 1D timeseries into 2D patch matrix (N_patches, patch_len)."""
        n = len(series)
        if n < self.patch_len:
            return np.zeros((0, self.patch_len))
        patches = []
        for i in range(0, n - self.patch_len + 1, self.stride):
            patches.append(series[i : i + self.patch_len])
        return np.array(patches)

    def compute_patch_attention_score(self, ohlcv_df: pd.DataFrame) -> dict[str, Any]:
        """
        Computes kernel self-attention over Close & Volume patches.

        Returns ``patch_tst_alpha`` / ``institutional_accumulation_score`` as
        real computed statistics in [10, 99], or ``None`` (with a reason) when
        there is insufficient data — never a fabricated constant.
        """
        # AUDIT-FIX (Round 8, C5 — Part 2B): no fabricated fallback scores.
        if ohlcv_df is None or len(ohlcv_df) < 20:
            return {
                "patch_tst_alpha": None,
                "institutional_accumulation_score": None,
                "temporal_trend_strength": "NO_DATA",
                "pocket_pivot_detected": False,
                "reason": "insufficient history (< 20 rows) — no score computed",
            }

        closes = ohlcv_df["Close"].values
        volumes = ohlcv_df["Volume"].values if "Volume" in ohlcv_df.columns else np.ones_like(closes)

        # 1. Instance Normalization (RevIN) to eliminate non-stationary drift
        c_mean, c_std = np.mean(closes), np.std(closes) + 1e-8
        v_mean, v_std = np.mean(volumes), np.std(volumes) + 1e-8
        norm_closes = (closes - c_mean) / c_std
        norm_volumes = (volumes - v_mean) / v_std

        # 2. Extract Patches
        c_patches = self._extract_patches(norm_closes)
        v_patches = self._extract_patches(norm_volumes)
        num_patches = len(c_patches)

        if num_patches < 3:
            return {
                "patch_tst_alpha": None,
                "institutional_accumulation_score": None,
                "temporal_trend_strength": "NO_DATA",
                "pocket_pivot_detected": False,
                "reason": f"insufficient patches ({num_patches} < 3) — no score computed",
            }

        # 3. Fused patch representation (close + volume), no random projection.
        fused_patches = np.hstack([c_patches, v_patches])  # (num_patches, 2 * patch_len)
        p_dim = fused_patches.shape[1]

        # AUDIT-FIX (Round 8, C5 — Part 2B): REAL kernel self-attention.
        # Q = K = the patch matrix itself (identity projection): the attention
        # logits are the patch-similarity Gram matrix S = P Pᵀ / sqrt(d).
        # This replaces the previous untrained RandomState(42) Q/K/V
        # projections whose attention was deterministic noise.
        scores = np.dot(fused_patches, fused_patches.T) / np.sqrt(p_dim)
        # Softmax over patches (row-wise) — each patch attends to similar patches.
        exp_scores = np.exp(scores - np.max(scores, axis=-1, keepdims=True))
        attn_weights = exp_scores / (np.sum(exp_scores, axis=-1, keepdims=True) + 1e-9)

        # 4. Attention-based recency signal
        # The last row of the attention matrix is the recency-similarity
        # profile of the most recent patch; its concentration on the trailing
        # patches measures whether the latest behavior matches the recent
        # regime (momentum continuation) — a real statistic of the data.
        recent_attn = attn_weights[-1]
        recent_weight = np.sum(recent_attn[-3:]) / (np.sum(recent_attn) + 1e-9)

        # 10-day volume vs full-history volume accumulation
        vol_ratio = (np.mean(volumes[-10:]) / (np.mean(volumes) + 1e-9))
        price_slope = (closes[-1] - closes[-20]) / (closes[-20] + 1e-9)

        raw_alpha = (0.45 * recent_weight * 100) + (0.35 * min(vol_ratio * 40, 60)) + (0.20 * max(0, price_slope * 200))
        patch_score = float(np.clip(raw_alpha, 10.0, 99.0))

        # Pocket Pivot check: Volume today > highest down-volume in last 10 days
        down_volumes = [volumes[i] for i in range(-11, -1) if closes[i] < closes[i - 1]]  # ROUND 45: prior 10 trading days (was 9 — off-by-one); dropped the always-true `i < len(closes)-1` guard (negative i is always < len-1)
        max_down_vol = max(down_volumes) if down_volumes else 0
        pocket_pivot = bool(volumes[-1] > max_down_vol and closes[-1] > closes[-2])

        trend_strength = "STRONG" if patch_score > 75 else ("MODERATE" if patch_score > 50 else "WEAK")

        return {
            "patch_tst_alpha": round(patch_score, 1),
            "institutional_accumulation_score": round(patch_score, 1),
            "temporal_trend_strength": trend_strength,
            "pocket_pivot_detected": pocket_pivot,
            "method": "kernel self-attention temporal trend and volume confirmation",
        }
