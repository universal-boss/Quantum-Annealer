"""
ml_alpha/ppo_gating_router.py
==============================
Proximal Policy Optimization (PPO) Reinforcement Learning Gating Router.

TIER 1 UPGRADE: Replaces heuristic threshold-based MacroRegimeGater with a
Proximal Policy Optimization (PPO) actor-critic agent trained to maximize
portfolio Sharpe utility by dynamically routing expert allocation weights.

Reference: Schulman et al. (2017), "Proximal Policy Optimization Algorithms",
           arXiv:1707.06347. https://arxiv.org/abs/1707.06347

State space s_t ∈ R^8:
    [realized_vol_21d, trend_slope_63d, max_drawdown_63d, vix_proxy,
     prev_w_trend, prev_w_rev, prev_w_spill, ic_ewma_20d]

Action space a_t ∈ Δ² (3-simplex):
    raw logits z ∈ R³ → softmax → (w_trend, w_rev, w_spill)

Reward (R34-4 — action-dependent):
    When expert_ic_series is supplied (T x 3 per-expert daily cross-sectional IC):
        r_t = SCALE * (w_t . ic_t) - λ_turnover * ‖Δw_t‖₁
    The routing weights w_t directly determine the reward, so the policy can
    genuinely learn to route. Without expert ICs the legacy reward
    (benchmark return / rolling std) is EXOGENOUS to the action — the only
    action-dependent term is the turnover penalty, so the optimal learned
    policy is a constant weight vector; that fallback mode is disclosed in
    get_diagnostics() as 'benchmark_exogenous'.

Architecture: Actor-Critic shared trunk [8 → 32 → 32]
    Actor head:  [32 → 3] → softmax (policy π)
    Critic head: [32 → 1] (value function V)

PPO hyperparameters:
    clip_epsilon = 0.2   (PPO clip ratio)
    entropy_coef = 0.01  (exploration bonus)
    gae_lambda   = 0.95  (GAE advantage estimate)
    gamma        = 0.99  (discount factor)

Serialization: CPU NumPy state dict (target < 50 KB). Zero GPU dependency.
"""
from __future__ import annotations

import logging
from typing import Dict, List, Optional, Tuple, Any
import numpy as np

logger = logging.getLogger(__name__)

import os
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("VECLIB_MAXIMUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")

# Optional PyTorch — fall back gracefully to heuristic softmax router
try:
    import torch
    import torch.nn as nn
    import torch.optim as optim
    _HAS_TORCH = True
    torch.set_num_threads(1)
    if hasattr(torch, "set_num_interop_threads"):
        try:
            torch.set_num_interop_threads(1)
        except Exception:
            pass
except ImportError:
    _HAS_TORCH = False
    torch = None  # type: ignore
    nn = None     # type: ignore
    optim = None  # type: ignore


# ─────────────────────────────────────────────────────────────────────────────
# PPO State Observation Builder
# ─────────────────────────────────────────────────────────────────────────────

def build_ppo_observation(
    benchmark_returns: np.ndarray,
    prev_weights: Optional[np.ndarray] = None,
    ic_ewma: float = 0.0,
) -> np.ndarray:
    """
    Constructs the PPO state observation vector s_t ∈ R^8.

    Components:
        [0] realized_vol_21d   — trailing 21-day annualized realized vol
        [1] trend_slope_63d    — OLS slope of benchmark over 63 days (normalised)
        [2] max_drawdown_63d   — peak-to-trough drawdown over 63 days
        [3] vix_proxy          — abs(mean(r[-5:])) / std(r[-21:]) (implied vol signal)
        [4] prev_w_trend       — previous trend expert weight
        [5] prev_w_rev         — previous mean-reversion expert weight
        [6] prev_w_spill       — previous spillover expert weight
        [7] ic_ewma_20d        — exponentially weighted IC over last 20 evaluation dates
    """
    r = np.asarray(benchmark_returns, dtype=float)
    r = r[~np.isnan(r)]

    if len(r) < 5:
        obs = np.array([0.15, 0.0, 0.0, 1.0,
                        0.40, 0.35, 0.25, 0.0], dtype=float)
        return obs

    # [0] Realized vol (21d annualized)
    r21 = r[-21:] if len(r) >= 21 else r
    realized_vol = float(np.std(r21) * np.sqrt(252.0))

    # [1] Trend slope (63d linear fit, normalized by vol)
    r63 = r[-63:] if len(r) >= 63 else r
    t = np.arange(len(r63), dtype=float)
    if len(t) >= 2:
        slope = float(np.polyfit(t, np.cumprod(1.0 + r63), 1)[0])
        trend_slope = np.clip(slope / (realized_vol + 1e-6), -3.0, 3.0)
    else:
        trend_slope = 0.0

    # [2] Max drawdown (63d)
    cum_prices = np.cumprod(1.0 + r63)
    running_max = np.maximum.accumulate(cum_prices)
    max_dd = float(np.min((cum_prices - running_max) / (running_max + 1e-9)))
    max_dd = np.clip(max_dd, -1.0, 0.0)

    # [3] VIX proxy (short-window mean excess / realized_vol)
    r5 = r[-5:] if len(r) >= 5 else r
    vix_proxy = float(np.clip(abs(float(np.mean(r5))) / (realized_vol / np.sqrt(252) + 1e-6), 0.0, 5.0))

    # [4-6] Previous expert weights
    if prev_weights is not None and len(prev_weights) == 3:
        pw = np.clip(prev_weights, 0.0, 1.0)
    else:
        pw = np.array([0.40, 0.35, 0.25])

    # [7] IC EWMA
    ic_val = float(np.clip(ic_ewma, -1.0, 1.0))

    obs = np.array([
        np.clip(realized_vol, 0.0, 2.0),
        float(trend_slope),
        float(max_dd),
        float(vix_proxy),
        float(pw[0]),
        float(pw[1]),
        float(pw[2]),
        ic_val,
    ], dtype=float)

    return obs


# ─────────────────────────────────────────────────────────────────────────────
# PyTorch Actor-Critic Network
# ─────────────────────────────────────────────────────────────────────────────

if _HAS_TORCH:
    def _safe_log_softmax(x: "torch.Tensor", dim: int = -1) -> "torch.Tensor":
        """Numerically stable log_softmax avoiding PyTorch ARM64 native kernel segfault."""
        return x - torch.logsumexp(x, dim=dim, keepdim=True)

    def _safe_softmax(x: "torch.Tensor", dim: int = -1) -> "torch.Tensor":
        """Numerically stable softmax via exp(_safe_log_softmax(x))."""
        return torch.exp(_safe_log_softmax(x, dim=dim))

    class _ActorCriticNet(nn.Module):
        """
        Shared-trunk Actor-Critic network for PPO gating.

        Architecture:
            Shared trunk:  Linear(8→32) → LeakyReLU → Linear(32→32) → LeakyReLU
            Actor head:    Linear(32→3)  → (used as logits for Dirichlet/softmax)
            Critic head:   Linear(32→1)  → V(s)
        """

        def __init__(self, obs_dim: int = 8, hidden_dim: int = 32, n_actions: int = 3):
            super().__init__()
            self.trunk = nn.Sequential(
                nn.Linear(obs_dim, hidden_dim),
                nn.LeakyReLU(0.1),
                nn.Linear(hidden_dim, hidden_dim),
                nn.LeakyReLU(0.1),
            )
            self.actor_head = nn.Linear(hidden_dim, n_actions)
            self.critic_head = nn.Linear(hidden_dim, 1)

        def forward(self, x: "torch.Tensor") -> Tuple["torch.Tensor", "torch.Tensor"]:
            shared = self.trunk(x)
            logits = self.actor_head(shared)
            value = self.critic_head(shared)
            return logits, value

        def get_weights(self, obs: "torch.Tensor") -> "torch.Tensor":
            logits, _ = self.forward(obs)
            return _safe_softmax(logits, dim=-1)

        def get_value(self, obs: "torch.Tensor") -> "torch.Tensor":
            _, value = self.forward(obs)
            return value
else:
    _safe_log_softmax = None  # type: ignore
    _safe_softmax = None      # type: ignore
    _ActorCriticNet = None    # type: ignore


# ─────────────────────────────────────────────────────────────────────────────
# PPO Gating Router
# ─────────────────────────────────────────────────────────────────────────────

class PPOGatingRouter:
    """
    PPO Reinforcement Learning Gating Router.

    Trains an Actor-Critic network to learn optimal expert routing weights
    (trend, mean-reversion, spillover) that maximize portfolio Sharpe ratio.

    Falls back to heuristic softmax routing if PyTorch is unavailable.
    """

    OBS_DIM = 8
    N_ACTIONS = 3

    # PPO Hyperparameters (Schulman et al. 2017)
    CLIP_EPSILON = 0.20
    ENTROPY_COEF = 0.01
    GAE_LAMBDA = 0.95
    GAMMA = 0.99
    LR = 3e-4
    N_EPOCHS_PPO = 4       # PPO update epochs per batch
    TURNOVER_PENALTY = 0.5  # λ_turnover for weight change penalty
    IC_REWARD_SCALE = 20.0  # scales per-expert IC (|IC| ~ 0.02-0.10) into Sharpe-like units

    def __init__(self, use_ppo: bool = True, hidden_dim: int = 32):
        self.use_ppo = use_ppo and _HAS_TORCH
        self.hidden_dim = hidden_dim

        self.net_: Optional[Any] = None       # _ActorCriticNet
        self.state_dict_: Dict[str, np.ndarray] = {}  # CPU numpy weights
        self.fitted_: bool = False

        # Heuristic fallback weights (identical to original MacroRegimeGater)
        self._heuristic_weights = np.array([0.40, 0.35, 0.25])
        self._prev_weights = np.array([0.40, 0.35, 0.25])

    # ─────────────────────────────────────────────────────────────────────────
    # Heuristic Fallback (identical to old MacroRegimeGater logic)
    # ─────────────────────────────────────────────────────────────────────────

    def _heuristic_select(self, obs: np.ndarray) -> np.ndarray:
        """
        Heuristic softmax routing identical to original MacroRegimeGater.
        Used when PyTorch is unavailable or model not yet fitted.
        """
        realized_vol = obs[0]
        trend_slope = obs[1]
        max_dd = obs[2]

        # Score each expert based on macro signals
        bull_score = max(0.0, trend_slope * 0.5 + max(0.0, 0.15 - realized_vol) * 3.0)
        stress_score = max(0.0, (realized_vol - 0.20) * 5.0 + max(0.0, -max_dd - 0.08) * 5.0)
        chop_score = 1.0 if (bull_score < 0.5 and stress_score < 0.5) else 0.2

        # Map regime scores to expert weights
        p_bull = np.clip(bull_score, 0, 3)
        p_chop = np.clip(chop_score, 0, 3)
        p_stress = np.clip(stress_score, 0, 3)

        total = p_bull + p_chop + p_stress + 1e-9
        p_bull /= total
        p_chop /= total
        p_stress /= total

        w_trend = 0.65 * p_bull + 0.15 * p_chop + 0.10 * p_stress
        w_rev   = 0.20 * p_bull + 0.65 * p_chop + 0.25 * p_stress
        w_spill = 0.15 * p_bull + 0.20 * p_chop + 0.65 * p_stress

        total_w = w_trend + w_rev + w_spill + 1e-9
        weights = np.array([w_trend / total_w, w_rev / total_w, w_spill / total_w])
        return weights

    # ─────────────────────────────────────────────────────────────────────────
    # Training
    # ─────────────────────────────────────────────────────────────────────────

    def fit(
        self,
        benchmark_returns: np.ndarray,
        ic_series: Optional[np.ndarray] = None,
        portfolio_returns_series: Optional[np.ndarray] = None,
        expert_ic_series: Optional[np.ndarray] = None,
        n_episodes: int = 50,
    ) -> "PPOGatingRouter":
        """
        Trains the PPO actor-critic on historical benchmark return trajectory.

        Args:
            benchmark_returns: Array of daily benchmark returns for state obs construction.
            ic_series: Optional information coefficient series for IC-EWMA state.
            portfolio_returns_series: Optional realized portfolio returns for reward.
            expert_ic_series: Optional [T x 3] per-expert daily cross-sectional IC —
                REQUIRED for an action-dependent reward (R34-4). When provided,
                r_t = SCALE * (w_t . ic_t) - λ * ‖Δw_t‖₁ so the routing weights
                genuinely determine the reward. Without it the legacy benchmark
                reward is exogenous to the action and the learned policy
                degenerates to turnover-minimising constant weights (disclosed).
            n_episodes: Number of PPO training episodes (rollouts over the history).
        """
        if not self.use_ppo or not _HAS_TORCH:
            logger.info("[PPO] PyTorch unavailable — using heuristic gating router.")
            self.fitted_ = True
            return self

        # R34-4: deterministic training (the Round 33 version was unseeded).
        torch.manual_seed(42)
        np.random.seed(42)

        device = torch.device("cpu")
        net = _ActorCriticNet(
            obs_dim=self.OBS_DIM,
            hidden_dim=self.hidden_dim,
            n_actions=self.N_ACTIONS,
        ).to(device)
        optimizer = optim.Adam(net.parameters(), lr=self.LR)

        r = np.asarray(benchmark_returns, dtype=float)
        r = r[~np.isnan(r)]
        T = len(r)

        if T < 30:
            logger.warning("[PPO] Insufficient history (%d days) — using heuristic router.", T)
            self.fitted_ = True
            return self

        ic_arr = np.asarray(ic_series, dtype=float) if ic_series is not None else np.zeros(T)
        port_r = np.asarray(portfolio_returns_series, dtype=float) if portfolio_returns_series is not None else r

        # R34-4: action-dependent expert-IC reward when a valid [T x 3] matrix is supplied
        expert_ic = None
        if expert_ic_series is not None:
            candidate = np.asarray(expert_ic_series, dtype=float)
            if candidate.ndim == 2 and candidate.shape[1] == self.N_ACTIONS and len(candidate) > 0:
                # Align to the benchmark timeline (repeat/clip as needed)
                if len(candidate) >= T:
                    expert_ic = candidate[:T]
                else:
                    expert_ic = np.vstack([candidate, np.tile(candidate[-1], (T - len(candidate), 1))])
                self.reward_source_ = "expert_ic (action-dependent)"
                logger.info("[PPO] Action-dependent expert-IC reward active (%d dates).", len(candidate))
        if expert_ic is None:
            self.reward_source_ = "benchmark_exogenous (action-independent; policy regularizes turnover only)"
            logger.warning(
                "[PPO] No expert_ic_series supplied — the reward is exogenous to the routing "
                "weights; the trained policy will converge toward turnover-minimising "
                "constant weights (R34-4 disclosure)."
            )

        def _build_obs_t(t: int, prev_w: np.ndarray, ic_ewma: float) -> np.ndarray:
            history = r[:t + 1]
            ic_ewma = float(ic_arr[:t + 1][-1]) if t < len(ic_arr) else ic_ewma
            return build_ppo_observation(history, prev_w, ic_ewma)

        def _compute_reward(t: int, prev_w: np.ndarray, curr_w: np.ndarray) -> float:
            turnover_cost = self.TURNOVER_PENALTY * float(np.sum(np.abs(curr_w - prev_w)))
            if expert_ic is not None:
                # R34-4 action-dependent: weighted blend of per-expert ICs
                ic_row = expert_ic[min(t, len(expert_ic) - 1)]
                perf = self.IC_REWARD_SCALE * float(np.dot(curr_w, ic_row))
            else:
                if t >= len(port_r):
                    return 0.0
                ret_t = float(port_r[t])
                perf = ret_t / (float(np.std(port_r[max(0, t-21):t+1])) + 1e-6)
            return float(np.clip(perf - turnover_cost, -5.0, 5.0))

        logger.info("[PPO] Training actor-critic on %d days, %d episodes...", T, n_episodes)

        for episode in range(n_episodes):
            # Collect rollout
            obs_list, logits_list, log_probs_list, rewards_list, values_list = [], [], [], [], []
            prev_w = self._prev_weights.copy()
            ic_ewma = 0.0

            step_indices = range(20, min(T, 200), 3)  # sample ~60 steps per episode

            for t in step_indices:
                obs_t = _build_obs_t(t, prev_w, ic_ewma)
                obs_tensor = torch.tensor(obs_t, dtype=torch.float32).unsqueeze(0)

                with torch.no_grad():
                    logits, value = net(obs_tensor)
                    weights = _safe_softmax(logits, dim=-1)
                    log_prob = _safe_log_softmax(logits, dim=-1)

                curr_w = weights.squeeze(0).numpy()
                reward = _compute_reward(t, prev_w, curr_w)

                obs_list.append(obs_t)
                logits_list.append(logits.squeeze(0).detach().numpy())
                log_probs_list.append(log_prob.squeeze(0).detach().numpy())
                rewards_list.append(reward)
                values_list.append(float(value.item()))

                prev_w = curr_w
                if t < len(ic_arr):
                    ic_ewma = 0.9 * ic_ewma + 0.1 * float(ic_arr[t])

            if len(rewards_list) < 2:
                continue

            # GAE Advantage Estimation (Schulman et al. 2017, eq. 11)
            advantages = np.zeros(len(rewards_list), dtype=float)
            gae = 0.0
            for i in reversed(range(len(rewards_list))):
                next_val = values_list[i + 1] if i + 1 < len(values_list) else 0.0
                delta = rewards_list[i] + self.GAMMA * next_val - values_list[i]
                gae = delta + self.GAMMA * self.GAE_LAMBDA * gae
                advantages[i] = gae
            returns = advantages + np.array(values_list)

            # Normalize advantages
            advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)

            # Convert to tensors
            obs_t = torch.tensor(np.array(obs_list), dtype=torch.float32)
            old_log_probs_t = torch.tensor(np.array(log_probs_list), dtype=torch.float32)
            advantages_t = torch.tensor(advantages, dtype=torch.float32)
            returns_t = torch.tensor(returns, dtype=torch.float32)

            # PPO update epochs
            for _ in range(self.N_EPOCHS_PPO):
                logits_new, values_new = net(obs_t)
                log_probs_new = _safe_log_softmax(logits_new, dim=-1)

                # Policy ratio r(θ) = exp(log_π_new - log_π_old)
                # Joint action log-probability difference across simplex/categorical dimensions
                log_ratio_sum = (log_probs_new - old_log_probs_t).sum(dim=-1)
                ratio_mean = torch.exp(log_ratio_sum.clamp(-5.0, 5.0))

                # PPO clipped objective
                adv = advantages_t
                surr1 = ratio_mean * adv
                surr2 = torch.clamp(ratio_mean, 1.0 - self.CLIP_EPSILON, 1.0 + self.CLIP_EPSILON) * adv
                actor_loss = -torch.min(surr1, surr2).mean()

                # Critic (value) loss
                critic_loss = nn.functional.mse_loss(values_new.squeeze(-1), returns_t)

                # Entropy bonus (encourage exploration)
                probs = torch.exp(log_probs_new)
                entropy = -(probs * log_probs_new).sum(dim=-1).mean()

                # Total PPO loss
                loss = actor_loss + 0.5 * critic_loss - self.ENTROPY_COEF * entropy

                optimizer.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(net.parameters(), 0.5)
                optimizer.step()

        # Serialize to CPU numpy state dict for lean pickling
        net.eval()
        self.state_dict_ = {k: v.detach().cpu().numpy() for k, v in net.state_dict().items()}
        self.net_ = net
        self.fitted_ = True

        sd_size = sum(v.nbytes for v in self.state_dict_.values())
        logger.info("[PPO] Training complete. State dict size: %d bytes (%.1f KB)", sd_size, sd_size / 1024)
        return self

    # ─────────────────────────────────────────────────────────────────────────
    # Inference
    # ─────────────────────────────────────────────────────────────────────────

    def select_weights(
        self,
        benchmark_returns: np.ndarray,
        ic_ewma: float = 0.0,
    ) -> Dict[str, float]:
        """
        Selects expert routing weights given current market observation.

        Returns:
            Dict with keys 'trend_momentum', 'mean_reversion', 'peer_spillover'.
        """
        obs = build_ppo_observation(benchmark_returns, self._prev_weights, ic_ewma)

        if self.fitted_ and self.use_ppo and _HAS_TORCH and self.state_dict_:
            weights = self._ppo_forward(obs)
        else:
            weights = self._heuristic_select(obs)

        self._prev_weights = weights.copy()
        return {
            "trend_momentum": round(float(weights[0]), 4),
            "mean_reversion":  round(float(weights[1]), 4),
            "peer_spillover":  round(float(weights[2]), 4),
        }

    def _ppo_forward(self, obs: np.ndarray) -> np.ndarray:
        """Runs the fitted PPO actor network (pure inference)."""
        if not _HAS_TORCH:
            return self._heuristic_select(obs)

        try:
            if self.net_ is None:
                # Reconstruct from state dict
                net = _ActorCriticNet(self.OBS_DIM, self.hidden_dim, self.N_ACTIONS)
                torch_sd = {k: torch.tensor(v, dtype=torch.float32) for k, v in self.state_dict_.items()}
                net.load_state_dict(torch_sd)
                net.eval()
                self.net_ = net

            obs_t = torch.tensor(obs, dtype=torch.float32).unsqueeze(0)
            with torch.no_grad():
                logits, _ = self.net_(obs_t)
                logits_np = logits.squeeze(0).cpu().numpy()
                e_x = np.exp(logits_np - np.max(logits_np))
                weights = e_x / (np.sum(e_x) + 1e-9)
            return weights
        except Exception as e:
            logger.warning("[PPO] Forward pass failed (%s) — falling back to heuristic.", e)
            return self._heuristic_select(obs)

    def get_policy_entropy(self, benchmark_returns: np.ndarray) -> float:
        """Returns current policy entropy H(π(·|s)). Lower = more confident routing."""
        obs = build_ppo_observation(benchmark_returns, self._prev_weights, 0.0)
        if self.fitted_ and self.use_ppo and _HAS_TORCH and self.state_dict_:
            weights = self._ppo_forward(obs)
        else:
            weights = self._heuristic_select(obs)
        weights = np.clip(weights, 1e-9, 1.0)
        return float(-np.sum(weights * np.log(weights)))

    def get_diagnostics(self) -> Dict[str, Any]:
        """Returns PPO router diagnostics."""
        sd_kb = sum(v.nbytes for v in self.state_dict_.values()) / 1024 if self.state_dict_ else 0.0
        return {
            "type": "PPOGatingRouter" if (self.use_ppo and _HAS_TORCH) else "HeuristicGatingRouter",
            "fitted": self.fitted_,
            "ppo_enabled": self.use_ppo and _HAS_TORCH,
            "state_dict_size_kb": round(sd_kb, 2),
            # R34-4 honesty lock: disclose what the reward actually optimizes.
            "reward_source": getattr(self, "reward_source_", "not_fitted"),
            "current_weights": {
                "trend_momentum": round(float(self._prev_weights[0]), 4),
                "mean_reversion":  round(float(self._prev_weights[1]), 4),
                "peer_spillover":  round(float(self._prev_weights[2]), 4),
            }
        }
