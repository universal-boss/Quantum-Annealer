"""
ml_alpha/regime_ensemble.py
===========================
Dynamic Macro Regime Router & Mixture of Experts (MoE) Architecture
for Institutional Alpha Generation.

Key Capabilities:
1. Dynamic Regime Routing:
   - Evaluates Macro Regime (Bull Trending, Chop Mean-Reversion, High-Vol Crash/Stress).
   - Dynamically routes and blends predictions across the 5 SOTA Archetype Models:
       * IPOMultibaggerModel (ml_alpha_ipo.pkl)
       * MomentumPatchTSTModel (ml_alpha_momentum.pkl)
       * InstitutionalFlowGATModel (ml_alpha_flow.pkl)
       * QualityCausalGARPModel (ml_alpha_quality.pkl)
       * AllWeatherLiquidODEModel (ml_alpha_defensive.pkl)
   - Primary archetype serves as anchor (50%-70%), while satellite weights dynamically
     tilt according to market regime conditions (volatility, trend, breadth, drawdown).

2. Sector-Neutral Cross-Sectional Ranking:
   - Neutralizes composite alpha within each sector:
       z_sector = (alpha - mean_sector) / (std_sector + eps)
   - Blends intra-sector relative alpha with cross-sectional global alpha:
       alpha_neutral = (1 - lambda_sec) * z_global + lambda_sec * z_sector
   - Eliminates single-sector factor crowding while preserving cross-sector relative value.

3. Multi-Horizon Ensembling:
   - Blends short-term (10-21d), medium-term (42d), and secular (63-84d) alpha dynamics.

4. Cryptographic Integrity:
   - Strict SHA-256 sidecar verification for all loaded model artifacts.
   - In-memory model caching for sub-millisecond inference across profiles.
"""
from __future__ import annotations

import hashlib
import logging
import os
import pickle
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple, Union

import numpy as np
import pandas as pd

logger = logging.getLogger("quantum_annealer.regime_ensemble")

WORKSPACE = Path(__file__).resolve().parent.parent
MODEL_DIR = WORKSPACE / "models"

# ─────────────────────────────────────────────────────────────────────────────
# Archetype Model Registry
# ─────────────────────────────────────────────────────────────────────────────

ARCHETYPE_MODEL_FILES: Dict[str, str] = {
    "ipo": "ml_alpha_ipo.pkl",
    "momentum": "ml_alpha_momentum.pkl",
    "flow": "ml_alpha_flow.pkl",
    "quality": "ml_alpha_quality.pkl",
    "defensive": "ml_alpha_defensive.pkl",
    "prebreakout": "ml_alpha_prebreakout.pkl",
}

# Base strategic allocation simplex by profile
BASE_STRATEGIC_WEIGHTS: Dict[str, Dict[str, float]] = {
    "prebreakout": {
        "prebreakout": 0.60,
        "momentum": 0.15,
        "flow": 0.10,
        "ipo": 0.10,
        "quality": 0.05,
        "defensive": 0.00,
    },
    "ipo": {
        "ipo": 0.60,
        "prebreakout": 0.15,
        "momentum": 0.15,
        "flow": 0.05,
        "quality": 0.05,
        "defensive": 0.00,
    },
    "momentum": {
        "momentum": 0.60,
        "prebreakout": 0.15,
        "ipo": 0.10,
        "flow": 0.10,
        "quality": 0.05,
        "defensive": 0.00,
    },
    "flow": {
        "flow": 0.60,
        "prebreakout": 0.15,
        "momentum": 0.10,
        "quality": 0.10,
        "ipo": 0.05,
        "defensive": 0.00,
    },
    "quality": {
        "quality": 0.60,
        "flow": 0.15,
        "defensive": 0.10,
        "prebreakout": 0.05,
        "momentum": 0.05,
        "ipo": 0.05,
    },
    "defensive": {
        "defensive": 0.70,
        "quality": 0.15,
        "flow": 0.10,
        "prebreakout": 0.05,
        "momentum": 0.00,
        "ipo": 0.00,
    },
}

# Regime tilts (additive adjustments before simplex projection)
REGIME_WEIGHT_TILTS: Dict[str, Dict[str, float]] = {
    "Bull_Trending": {
        "prebreakout": +0.08,
        "momentum": +0.10,
        "ipo": +0.06,
        "flow": +0.02,
        "quality": -0.12,
        "defensive": -0.14,
    },
    "Chop_MeanReversion": {
        "prebreakout": +0.15,
        "flow": +0.10,
        "quality": +0.05,
        "momentum": -0.10,
        "ipo": -0.05,
        "defensive": -0.05,
    },
    "HighVol_CrashStress": {
        "defensive": +0.25,
        "quality": +0.10,
        "flow": -0.05,
        "prebreakout": -0.10,
        "momentum": -0.10,
        "ipo": -0.10,
    },
}

# In-memory verified model cache
_VERIFIED_MODEL_CACHE: Dict[str, Any] = {}


def resolve_primary_archetype(profile_name: str = "", prescreen_mode: str = "") -> str:
    """
    Resolves the canonical archetype key from profile name or prescreen mode.
    """
    pname = str(profile_name).lower()
    pmode = str(prescreen_mode).lower()

    if pmode == "ipo_multibagger" or "ipo" in pname or "🦄" in pname:
        return "ipo"
    if pmode in ["breakout_early", "prebreakout"] or any(k in pname for k in ["prebreakout", "pre-breakout"]):
        return "prebreakout"
    if any(k in pname for k in ["momentum", "max alpha", "vol squeeze", "🚀"]) or pmode in [
        "institutional_alpha", "vol_squeeze"
    ]:
        return "momentum"
    if any(k in pname for k in ["flow", "smart money", "🏦"]) or pmode in [
        "early_entry", "accumulation"
    ]:
        return "flow"
    if any(k in pname for k in ["quality", "garp", "🏛️"]) or pmode in [
        "quality_compounders", "garp"
    ]:
        return "quality"
    if any(k in pname for k in ["preservation", "all-weather", "defense", "defensive", "🛡️", "⚖️"]) or pmode in [
        "pure_defensive", "balanced"
    ]:
        return "defensive"

    return "momentum"


def load_verified_model(model_key: str, allow_unsigned: bool = False) -> Optional[Any]:
    """
    Loads an archetype model from disk with SHA-256 sidecar validation.
    Caches the verified model in memory for subsequent zero-overhead calls.
    """
    if model_key in _VERIFIED_MODEL_CACHE:
        return _VERIFIED_MODEL_CACHE[model_key]

    filename = ARCHETYPE_MODEL_FILES.get(model_key)
    if not filename:
        logger.warning(f"[RegimeEnsemble] Unknown archetype model key: {model_key}")
        return None

    pkl_path = MODEL_DIR / filename
    if not pkl_path.exists():
        logger.warning(f"[RegimeEnsemble] Model file not found: {pkl_path}")
        return None

    sha_path = pkl_path.with_suffix(pkl_path.suffix + ".sha256")
    load_ok = False

    if sha_path.exists():
        try:
            expected_sha = sha_path.read_text(encoding="utf-8").strip().lower()
            actual_sha = hashlib.sha256(pkl_path.read_bytes()).hexdigest().lower()
            load_ok = (expected_sha == actual_sha)
            if not load_ok:
                logger.error(
                    f"[RegimeEnsemble] ⛔ {filename} SHA-256 MISMATCH! "
                    f"Expected: {expected_sha[:16]}... Actual: {actual_sha[:16]}..."
                )
        except Exception as e:
            logger.error(f"[RegimeEnsemble] SHA-256 verification failed ({e})")
    else:
        logger.warning(f"[RegimeEnsemble] No SHA-256 sidecar for {filename}")

    if not load_ok and not allow_unsigned and os.environ.get("ML_ALLOW_UNSIGNED_PICKLE") != "1":
        logger.error(f"[RegimeEnsemble] Refusing to load unsigned/tampered model: {filename}")
        return None

    try:
        with open(pkl_path, "rb") as f:
            model_obj = pickle.load(f)
        # AUDIT-FIX C-1: refuse artifacts whose class does not match the
        # advertised architecture for this model key.
        _EXPECTED_TYPES = {
            "flow": "InstitutionalFlowGATModel",
            "momentum": "MomentumPatchTSTModel",
            "quality": "QualityCausalGARPModel",
            "defensive": "AllWeatherLiquidODEModel",
            "ipo": "IPOMultibaggerModel",
            "prebreakout": "PreBreakoutInceptionModel",
        }
        _expected = _EXPECTED_TYPES.get(model_key)
        if _expected is not None and type(model_obj).__name__ != _expected and os.environ.get("ML_ALLOW_MISMATCHED_ARCH") != "1":
            logger.error(
                f"[RegimeEnsemble] {filename} contains {type(model_obj).__name__}, "
                f"expected {_expected} — artifact/training-pipeline mismatch. Refusing load."
            )
            return None
        _VERIFIED_MODEL_CACHE[model_key] = model_obj
        logger.info(f"[RegimeEnsemble] Authenticated & cached {filename} (SHA-256 verified)")
        return model_obj
    except Exception as e:
        logger.error(f"[RegimeEnsemble] Failed to unpickle {filename}: {e}")
        return None


def detect_macro_regime_state(
    regime_info: Optional[Dict[str, Any]] = None,
    benchmark_returns: Optional[pd.Series] = None,
    india_vix: Optional[float] = None,
) -> Tuple[str, Dict[str, float]]:
    """
    Synthesizes the Macro Market Regime into one of 3 canonical states:
    - 'Bull_Trending'
    - 'Chop_MeanReversion'
    - 'HighVol_CrashStress'

    Returns:
        (canonical_regime_name, regime_probabilities_dict)
    """
    regime_info = regime_info or {}
    regime_label = str(regime_info.get("Regime", "")).lower()

    # Probability extraction if provided by HMM
    p_bull = float(regime_info.get("P_Bull", 0.0))
    p_bear = float(regime_info.get("P_Bear", 0.0))
    p_side = float(regime_info.get("P_Sideways", 0.0))

    # Realized volatility and drawdown from benchmark returns if available
    realized_vol = 0.16
    drawdown = 0.0
    if benchmark_returns is not None and len(benchmark_returns) >= 20:
        trailing_21 = benchmark_returns.dropna().iloc[-21:]
        if len(trailing_21) >= 10:
            realized_vol = float(trailing_21.std() * np.sqrt(252.0))
        trailing_63 = benchmark_returns.dropna().iloc[-63:]
        if len(trailing_63) >= 10:
            cum = (1.0 + trailing_63).cumprod()
            drawdown = float((cum.iloc[-1] / cum.max()) - 1.0)

    # Fast VIX check
    vix_stress = False
    if india_vix is not None and not np.isnan(india_vix) and india_vix >= 22.0:
        vix_stress = True

    # Rule-based synthesis
    if vix_stress or realized_vol >= 0.24 or drawdown <= -0.08 or any(
        w in regime_label for w in ["bear", "crash", "stress", "turbulent", "defensive", "distribution"]
    ):
        canonical = "HighVol_CrashStress"
        probs = {
            "Bull_Trending": round(max(0.05, p_bull * 0.5), 3),
            "Chop_MeanReversion": round(max(0.15, p_side * 0.8), 3),
            "HighVol_CrashStress": round(max(0.60, p_bear), 3),
        }
    elif realized_vol <= 0.15 and drawdown >= -0.03 and any(
        w in regime_label for w in ["bull", "trend", "risk-on", "strength"]
    ):
        canonical = "Bull_Trending"
        probs = {
            "Bull_Trending": round(max(0.65, p_bull), 3),
            "Chop_MeanReversion": round(max(0.20, p_side), 3),
            "HighVol_CrashStress": round(max(0.05, p_bear * 0.5), 3),
        }
    else:
        canonical = "Chop_MeanReversion"
        probs = {
            "Bull_Trending": round(p_bull if p_bull > 0 else 0.25, 3),
            "Chop_MeanReversion": round(max(0.50, p_side if p_side > 0 else 0.50), 3),
            "HighVol_CrashStress": round(p_bear if p_bear > 0 else 0.25, 3),
        }

    # Normalize probs
    total_p = sum(probs.values())
    if total_p > 0:
        probs = {k: round(v / total_p, 4) for k, v in probs.items()}

    return canonical, probs


class RegimeEnsembleRouter:
    """
    Hierarchical Mixture of Experts (MoE) Router across the 5 SOTA Archetype Models.
    """

    def __init__(
        self,
        primary_archetype: str = "momentum",
        use_dynamic_regime_tilt: bool = True,
        anchor_weight: float = 0.60,
    ):
        self.primary_archetype = primary_archetype
        self.use_dynamic_regime_tilt = use_dynamic_regime_tilt
        self.anchor_weight = anchor_weight
        self.latest_weights: Dict[str, float] = {}
        self.latest_regime: str = "Bull_Trending"
        self.latest_probs: Dict[str, float] = {}

    def compute_routing_weights(
        self,
        regime_info: Optional[Dict[str, Any]] = None,
        benchmark_returns: Optional[pd.Series] = None,
        india_vix: Optional[float] = None,
    ) -> Dict[str, float]:
        """
        Computes the active weight simplex across the 5 models.
        """
        regime, probs = detect_macro_regime_state(
            regime_info=regime_info,
            benchmark_returns=benchmark_returns,
            india_vix=india_vix,
        )
        self.latest_regime = regime
        self.latest_probs = probs

        # Base allocation
        base = dict(BASE_STRATEGIC_WEIGHTS.get(self.primary_archetype, BASE_STRATEGIC_WEIGHTS["momentum"]))

        if not self.use_dynamic_regime_tilt:
            self.latest_weights = base
            return base

        # Apply regime tilts
        tilts = REGIME_WEIGHT_TILTS.get(regime, {})
        adjusted = {}
        for k, w in base.items():
            tilt_val = tilts.get(k, 0.0)
            adjusted[k] = max(0.01, w + tilt_val)

        # Enforce anchor minimum
        if self.primary_archetype in adjusted:
            target_min = self.anchor_weight * 0.85
            non_anchor_sum = sum(v for k, v in adjusted.items() if k != self.primary_archetype)
            curr_anchor = adjusted[self.primary_archetype]
            curr_total = curr_anchor + non_anchor_sum
            if curr_total > 0 and (curr_anchor / curr_total) < target_min and non_anchor_sum > 0:
                scale = (curr_anchor * (1.0 - target_min)) / (target_min * non_anchor_sum)
                for k in adjusted:
                    if k != self.primary_archetype:
                        adjusted[k] *= scale

        # Simplex normalization
        total_w = sum(adjusted.values())
        norm_weights = {k: round(v / total_w, 4) for k, v in adjusted.items()}
        self.latest_weights = norm_weights
        return norm_weights

    def predict_ensemble(
        self,
        signal_df: pd.DataFrame,
        regime_info: Optional[Dict[str, Any]] = None,
        benchmark_returns: Optional[pd.Series] = None,
        india_vix: Optional[float] = None,
        log_cb: Optional[Callable[[str], None]] = None,
    ) -> Tuple[pd.Series, Dict[str, Any]]:
        """
        Generates blended cross-sectional alpha scores across the 5 models.

        Returns:
            (blended_alpha_series, diagnostics_dict)
        """
        weights = self.compute_routing_weights(
            regime_info=regime_info,
            benchmark_returns=benchmark_returns,
            india_vix=india_vix,
        )

        n_assets = len(signal_df)
        if n_assets == 0:
            return pd.Series(dtype=float), {}

        preds_by_model: Dict[str, np.ndarray] = {}
        attributions_by_model: Dict[str, Dict[str, Any]] = {}
        model_dsr: Dict[str, float] = {}
        model_oos: Dict[str, float] = {}

        for m_key, w in weights.items():
            if w <= 0.01:
                continue

            model = load_verified_model(m_key)
            if model is None:
                continue

            # Feature subset selection
            req_feats = getattr(model, "feature_names", None) or [c for c in signal_df.columns if c.startswith("z_")]
            valid_feats = [c for c in req_feats if c in signal_df.columns]

            if not valid_feats:
                continue

            X_mat = signal_df[valid_feats].select_dtypes(include=[np.number]).fillna(0.0)

            try:
                if hasattr(model, "predict_with_attribution"):
                    p_vals, p_attrs = model.predict_with_attribution(X_mat)
                    preds_by_model[m_key] = np.asarray(p_vals, dtype=float)
                    attributions_by_model[m_key] = p_attrs.to_dict(orient="index")
                elif hasattr(model, "predict"):
                    p_vals = model.predict(X_mat)
                    preds_by_model[m_key] = np.asarray(p_vals, dtype=float)
                else:
                    continue

                _d = getattr(model, "dsr", None)
                _o = getattr(model, "oos_sharpe", None)
                if _d is not None:
                    model_dsr[m_key] = float(_d)
                if _o is not None:
                    model_oos[m_key] = float(_o)
            except Exception as e:
                logger.warning(f"[RegimeEnsemble] Prediction failed for {m_key}: {e}")

        if not preds_by_model:
            logger.warning("[RegimeEnsemble] No active models generated predictions.")
            return pd.Series(0.0, index=signal_df.index), {}

        # Standardize each model's predictions cross-sectionally before weighted blend
        z_by_model: Dict[str, np.ndarray] = {}
        active_weights: Dict[str, float] = {}
        for m_key, raw_p in preds_by_model.items():
            w = weights.get(m_key, 0.0)
            if len(raw_p) == n_assets:
                p_std = np.std(raw_p)
                p_mean = np.mean(raw_p)
                z = (raw_p - p_mean) / (p_std + 1e-9) if p_std > 1e-8 else np.zeros_like(raw_p)
                z_by_model[m_key] = z
                active_weights[m_key] = w

        total_act_w = sum(active_weights.values())
        if total_act_w <= 0:
            return pd.Series(0.0, index=signal_df.index), {}

        # Renormalize active weights
        norm_act_weights = {k: v / total_act_w for k, v in active_weights.items()}

        # Weighted blend
        blended_alpha = np.zeros(n_assets, dtype=float)
        for m_key, z in z_by_model.items():
            blended_alpha += norm_act_weights[m_key] * z

        # Compute ensemble DSR and OOS Sharpe from measured models only
        measured_dsr_w = sum(norm_act_weights[k] for k in norm_act_weights if k in model_dsr)
        ens_dsr = (
            sum(norm_act_weights[k] * model_dsr[k] for k in norm_act_weights if k in model_dsr) / measured_dsr_w
            if measured_dsr_w > 0 else None
        )
        measured_oos_w = sum(norm_act_weights[k] for k in norm_act_weights if k in model_oos)
        ens_oos = (
            sum(norm_act_weights[k] * model_oos[k] for k in norm_act_weights if k in model_oos) / measured_oos_w
            if measured_oos_w > 0 else None
        )

        diagnostics = {
            "macro_regime": self.latest_regime,
            "regime_probabilities": self.latest_probs,
            "primary_archetype": self.primary_archetype,
            "active_weights": norm_act_weights,
            "ensemble_dsr": round(ens_dsr, 4) if ens_dsr is not None else None,
            "ensemble_oos_sharpe": round(ens_oos, 2) if ens_oos is not None else None,
            "models_evaluated": list(z_by_model.keys()),
            "attributions": attributions_by_model.get(self.primary_archetype, {}),
        }

        if log_cb:
            weight_str = ", ".join(f"{k}: {w:.1%}" for k, w in norm_act_weights.items())
            oos_str = f"{ens_oos:+.2f}" if ens_oos is not None else "UNMEASURED"
            dsr_str = f"{ens_dsr:.4f}" if ens_dsr is not None else "UNMEASURED"
            log_cb(
                f"[MoE Router] ⚡ Active Regime: {self.latest_regime} | "
                f"Blended Weights: ({weight_str}) | "
                f"Ensemble OOS Sharpe: {oos_str} | DSR: {dsr_str}"
            )

        return pd.Series(blended_alpha, index=signal_df.index), diagnostics


# ─────────────────────────────────────────────────────────────────────────────
# Sector-Neutral Cross-Sectional Ranking
# ─────────────────────────────────────────────────────────────────────────────

def apply_sector_neutral_ranking(
    signal_df: pd.DataFrame,
    alpha_col: str = "alpha_score",
    sectors: Optional[Dict[str, str]] = None,
    lambda_sector: float = 0.50,
    log_cb: Optional[Callable[[str], None]] = None,
) -> pd.Series:
    """
    Applies Sector-Neutral Cross-Sectional Ranking to composite alpha scores.

    Formula:
        z_global = (alpha - mean_universe) / (std_universe + eps)
        z_sector = (alpha - mean_sector) / (std_sector + eps)  [if n_sec >= 2]
        alpha_final = (1 - lambda_sector) * z_global + lambda_sector * z_sector

    Parameters:
        signal_df: DataFrame with asset indices and alpha scores.
        alpha_col: Name of alpha score column.
        sectors: Dict mapping ticker -> sector name.
        lambda_sector: Blend weight between intra-sector alpha and global alpha (0.0 to 1.0).
        log_cb: Optional logger callback.

    Returns:
        pd.Series of neutralized alpha scores indexed by asset.
    """
    if alpha_col not in signal_df.columns:
        return signal_df[alpha_col] if alpha_col in signal_df else pd.Series(0.0, index=signal_df.index)

    raw_alpha = signal_df[alpha_col].fillna(0.0)
    n_assets = len(raw_alpha)
    if n_assets < 3:
        return raw_alpha

    # Global standardization
    g_std = raw_alpha.std()
    g_mean = raw_alpha.mean()
    z_global = (raw_alpha - g_mean) / (g_std + 1e-9) if g_std > 1e-8 else raw_alpha

    if not sectors or lambda_sector <= 0.0:
        return z_global

    # Resolve sectors for assets
    def _norm_sec(s):
        v = sectors.get(s) or sectors.get(f"{s}.NS") or sectors.get(str(s).replace(".NS", ""))
        if not v or str(v).strip().upper() in ("", "NONE", "UNKNOWN", "N/A", "NAN", "NULL"):
            return "UNKNOWN"
        return str(v).strip()

    sec_series = pd.Series(
        [_norm_sec(s) for s in signal_df.index],
        index=signal_df.index,
    )

    z_sector = pd.Series(index=signal_df.index, dtype=float)

    n_neutralized = 0
    unique_secs = sec_series.unique()

    for sec in unique_secs:
        mask = (sec_series == sec)
        sub_alpha = raw_alpha[mask]
        if len(sub_alpha) >= 2:
            s_std = sub_alpha.std()
            s_mean = sub_alpha.mean()
            if s_std > 1e-8:
                z_sector[mask] = (sub_alpha - s_mean) / (s_std + 1e-9)
                n_neutralized += len(sub_alpha)
            else:
                z_sector[mask] = z_global[mask]
        else:
            # Single-asset sector falls back to global z-score
            z_sector[mask] = z_global[mask]

    # Convex blend
    lambda_clamped = float(np.clip(lambda_sector, 0.0, 1.0))
    final_neutral_alpha = (1.0 - lambda_clamped) * z_global + lambda_clamped * z_sector

    if log_cb and n_neutralized > 0:
        log_cb(
            f"[SectorNeutral] Neutralized {n_neutralized}/{n_assets} assets across {len(unique_secs)} sectors "
            f"(intra-sector blend lambda={lambda_clamped:.0%})"
        )

    return final_neutral_alpha
