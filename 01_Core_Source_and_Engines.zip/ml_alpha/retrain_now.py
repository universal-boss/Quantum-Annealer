#!/usr/bin/env python3
"""
retrain_now.py — Institutional ML Alpha Model Retraining Script
================================================================

Retrains the AlphaEngine on the full NSE Liquid 750 universe (Nifty 500 +
Nifty Midcap 250) using the full CPCV pipeline with India-specific factors.

Usage:
    python3 ml_alpha/retrain_now.py                   # Full 750-stock run (~25-40 min)
    python3 ml_alpha/retrain_now.py --fast            # 200-stock run, skip Optuna (~8 min)
    python3 ml_alpha/retrain_now.py --universe nifty500
    python3 ml_alpha/retrain_now.py --years 2 --fast
    python3 ml_alpha/retrain_now.py --dry-run         # Validates pipeline without saving

The script:
  1. Resolves the NSE 750 universe (Nifty 500 ∪ Midcap 250)
  2. Downloads 3y (default) of OHLCV data with 5y warmup
  3. Computes all factors (26 standard + India-specific)
  4. Runs CPCV (6 groups, 2 test) with triple-barrier labeling
  5. Enforces DSR >= 0.3 before saving (rejects weak models)
  6. Writes artifacts/saved_ml_alpha.pkl + .sha256 sidecar
"""
from __future__ import annotations

import os
import sys

# CRASH FIX (macOS EXC_BAD_ACCESS in libomp.dylib __kmp_suspend_initialize_thread):
# Multiple compiled libraries (LightGBM, PyTorch, Scikit-learn, OpenBLAS) each bundle
# their own private copy of libomp.dylib. Setting these BEFORE any C-extension imports
# prevents thread-pool collisions and segfaults on macOS ARM.
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["VECLIB_MAXIMUM_THREADS"] = "1"
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
os.environ["LIGHTGBM_NUM_THREADS"] = "1"

import argparse
import logging
import time
from datetime import date, timedelta
from pathlib import Path
import pandas as pd  # ROUND-43 FIX (R2): pd.read_parquet used in the drift check but was never imported

# Add project root to path
ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("retrain_ml")


def parse_args():
    p = argparse.ArgumentParser(
        description="Retrain the Quantum Annealer ML Alpha model on a large NSE universe."
    )
    p.add_argument(
        "--universe",
        default="nse_liquid_750",
        choices=["nse_liquid_750", "nifty500", "nifty200", "nifty100", "nifty50", "all_nse"],
        help="Training universe (default: nse_liquid_750 = Nifty500 + Midcap250, ~750 stocks)",
    )
    p.add_argument(
        "--years",
        type=int,
        default=3,
        help="Training window in years (default: 3). Warmup adds 5y automatically.",
    )
    p.add_argument(
        "--fast",
        action="store_true",
        help="Fast mode: use nifty200 (if default universe), skip Optuna hyperopt, 4 CPCV groups",
    )
    p.add_argument(
        "--dry-run",
        action="store_true",
        help="Run full pipeline but do NOT save the model (for validation only)",
    )
    p.add_argument(
        "--dsr-gate",
        type=float,
        default=0.3,
        help="Minimum Deflated Sharpe Ratio to save model (default: 0.3)",
    )
    p.add_argument(
        "--force-save",
        action="store_true",
        help="Save model even if DSR < dsr_gate (NOT recommended)",
    )
    p.add_argument(
        "--model-type",
        default="hierarchical_moe",
        choices=["hierarchical_moe", "ensemble", "ridge", "lightgbm", "blend"],
        help="ML Alpha model architecture (default: hierarchical_moe)",
    )
    p.add_argument(
        "--horizon",
        type=int,
        default=5,
        help="Forward return horizon in trading days (default: 5 = 1-week non-overlapping)",
    )
    p.add_argument(
        "--output",
        default=str(ROOT / "artifacts" / "saved_ml_alpha.pkl"),
        help="Output path for the model pickle",
    )
    p.add_argument(
        "--check-drift",
        action="store_true",
        help="Check factor distribution drift (PSI) first; skip retrain if features are STABLE (PSI < 0.25)",
    )
    return p.parse_args()


def main():
    args = parse_args()

    # ── Optional Factor Drift Pre-Check ──────────────────────────────────
    if args.check_drift:
        try:
            from ml_alpha.drift_monitor import evaluate_factor_drift, PSI_THRESHOLD_SIGNIFICANT
            # Attempt to probe feature drift from latest feature cache or synthetic test
            cache_dir = ROOT / "models" / "feature_cache"
            drift_detected = False
            if cache_dir.exists():
                parquets = list(cache_dir.glob("*.parquet"))
                if len(parquets) >= 2:
                    p1 = pd.read_parquet(parquets[0])
                    p2 = pd.read_parquet(parquets[-1])
                    telemetry = evaluate_factor_drift(p1, p2)
                    logger.info("[DriftCheck] Status: %s | Max PSI: %.4f | Retrain recommended: %s",
                                telemetry["status"], telemetry["max_psi"], telemetry["retrain_recommended"])
                    drift_detected = telemetry["retrain_recommended"]
            if not drift_detected and not args.force_save:
                logger.info("[DriftCheck] ✅ Factor distributions are STABLE (PSI < %.2f) — skipping retraining.",
                            PSI_THRESHOLD_SIGNIFICANT)
                return 0
        except Exception as _de:
            logger.warning("[DriftCheck] Drift check notice (%s) — proceeding with retrain.", _de)

    # ── Fast mode adjustments ─────────────────────────────────────────────
    universe = args.universe
    if args.fast and universe == "nse_liquid_750":
        universe = "nifty200"
        logger.info("Fast mode: switching universe to nifty200 (~200 stocks, ~8 min)")

    end_date   = date.today()
    start_date = end_date - timedelta(days=365 * args.years)

    logger.info("=" * 60)
    logger.info("QUANTUM ANNEALER — ML ALPHA RETRAINING")
    logger.info("=" * 60)
    logger.info("Universe  : %s", universe)
    logger.info("Model Type: %s", args.model_type)
    logger.info("Horizon   : %d-day (rebalance: %d-day non-overlapping)", args.horizon, args.horizon)
    logger.info("Training  : %s to %s (%d years)", start_date, end_date, args.years)
    logger.info("Fast mode : %s", args.fast)
    logger.info("Dry run   : %s", args.dry_run)
    logger.info("DSR gate  : %.2f", args.dsr_gate)
    logger.info("Output    : %s", args.output)
    logger.info("=" * 60)

    # ── Import engine ─────────────────────────────────────────────────────
    try:
        from ml_alpha.engine import AlphaEngine
        logger.info("✅ AlphaEngine imported successfully")
    except ImportError as e:
        logger.error("❌ Failed to import AlphaEngine: %s", e)
        logger.error("   Make sure you're running from the project root:")
        logger.error("   cd '/Users/deepak/Desktop/Quantum Annealer'")
        logger.error("   python3 ml_alpha/retrain_now.py")
        sys.exit(1)

    # ── Initialize engine ─────────────────────────────────────────────────
    engine = AlphaEngine(model_type=args.model_type)

    # Fast mode: override Optuna skip via env var
    if args.fast:
        import os
        os.environ["SKIP_OPTUNA"] = "1"
        logger.info("Fast mode: Optuna hyperparameter optimization disabled")

    # ── Progress callback ─────────────────────────────────────────────────
    _start_time = time.time()
    _last_msg = [""]

    def progress_cb(msg: str):
        elapsed = time.time() - _start_time
        prefix = f"[{elapsed:6.0f}s]"
        if msg != _last_msg[0]:
            logger.info("%s %s", prefix, msg)
            _last_msg[0] = msg

    # ── Run fit ───────────────────────────────────────────────────────────
    logger.info("")
    logger.info("⚡ Starting fit pipeline...")
    logger.info("   (CPCV with 6 groups = 15 evaluation paths — this takes time)")
    logger.info("")

    try:
        result = engine.fit(
            start=str(start_date),
            end=str(end_date),
            universe=universe,
            model_type=args.model_type,
            forward_return_days=args.horizon,
            rebalance_freq_days=args.horizon,
            n_splits=4 if args.fast else 6,
            progress_cb=progress_cb,
        )
    except Exception as e:
        logger.error("❌ fit() failed: %s", e, exc_info=True)
        sys.exit(1)

    # ── Print results ─────────────────────────────────────────────────────
    elapsed_total = time.time() - _start_time
    logger.info("")
    logger.info("=" * 60)
    logger.info("TRAINING COMPLETE  (%.1f min)", elapsed_total / 60)
    logger.info("=" * 60)
    logger.info("Tickers trained     : %d", result.n_tickers)
    logger.info("Observations        : %d", result.n_observations)
    logger.info("Features selected   : %d / %s", result.n_features, result.feature_names[:5])
    logger.info("IS Sharpe           : %.2f ± %.2f", result.in_sample_sharpe_mean, result.in_sample_sharpe_std)
    logger.info("OOS Sharpe          : %.2f ± %.2f", result.out_of_sample_sharpe_mean, result.out_of_sample_sharpe_std)
    logger.info("Walk-Forward Eff    : %.1f%%", result.walk_forward_efficiency * 100)
    logger.info("Deflated Sharpe     : %.4f", result.deflated_sharpe)
    logger.info("IC half-life        : %.1f folds", result.ic_half_life_days)
    logger.info("")

    # Per-fold breakdown
    logger.info("Per-fold metrics:")
    for fold in result.per_fold_metrics:
        logger.info(
            "  Path %2d | IS_IC=%+.4f OOS_IC=%+.4f | IS_Sharpe=%+.2f OOS_Sharpe=%+.2f",
            fold.get("fold_id", 0),
            fold.get("is_ic", 0),
            fold.get("oos_ic", 0),
            fold.get("is_sharpe", 0),
            fold.get("oos_sharpe", 0),
        )

    # Top 10 factors by importance
    if result.feature_importance:
        logger.info("")
        logger.info("Top 10 factors by importance:")
        sorted_fi = sorted(result.feature_importance.items(), key=lambda x: -abs(x[1]))
        for fname, imp in sorted_fi[:10]:
            logger.info("  %-35s %.4f", fname, imp)

    # ── DSR quality assessment ────────────────────────────────────────────
    logger.info("")
    dsr = result.deflated_sharpe
    oos_ic_values = [f.get("oos_ic", 0) for f in result.per_fold_metrics]
    mean_oos_ic   = sum(oos_ic_values) / max(1, len(oos_ic_values))
    pct_positive_ic = sum(1 for ic in oos_ic_values if ic > 0) / max(1, len(oos_ic_values))

    logger.info("QUALITY ASSESSMENT:")
    logger.info("  Mean OOS IC      : %+.4f  (target: > 0.02)", mean_oos_ic)
    logger.info("  %% Positive IC  : %.1f%%   (target: > 55%%)", pct_positive_ic * 100)
    logger.info("  DSR              : %.4f   (gate: >= %.2f)", dsr, args.dsr_gate)
    logger.info("  OOS Sharpe       : %.2f    (target: > 0.5)", result.out_of_sample_sharpe_mean)

    quality_ok = (
        dsr >= args.dsr_gate
        and mean_oos_ic > 0.01
        and pct_positive_ic > 0.50
    )

    if quality_ok:
        logger.info("")
        logger.info("✅ MODEL QUALITY: ACCEPTABLE — model has genuine validated edge")
    else:
        logger.info("")
        logger.warning("⚠️  MODEL QUALITY: WEAK — consider rerunning with more data or different universe")
        if dsr < args.dsr_gate:
            logger.warning("   DSR=%.4f below gate %.2f — model will NOT be saved", dsr, args.dsr_gate)

    # ── Save model ────────────────────────────────────────────────────────
    if args.dry_run:
        logger.info("")
        logger.info("DRY RUN — model NOT saved (pass without --dry-run to save)")
        return

    output_path = args.output
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)

    logger.info("")
    logger.info("Saving model to %s ...", output_path)

    saved = engine.save_model(
        path=output_path,
        dsr_gate=args.dsr_gate,
        force=args.force_save,
    )

    if saved:
        import hashlib
        sha = hashlib.sha256(open(output_path, "rb").read()).hexdigest()
        size_mb = Path(output_path).stat().st_size / 1024 / 1024
        logger.info("✅ Model saved: %s (%.1f MB)", output_path, size_mb)
        logger.info("   SHA-256: %s", sha[:32] + "...")
        logger.info("")
        logger.info("The optimizer will load this model automatically on next run.")
        logger.info("Restart the dashboard server if it is currently running.")
    else:
        logger.error("❌ Model NOT saved (DSR gate rejected). See above for details.")
        logger.error("   To bypass: python3 ml_alpha/retrain_now.py --force-save")
        sys.exit(1)


if __name__ == "__main__":
    main()
