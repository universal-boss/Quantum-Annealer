"""Sample weights for financial ML — López de Prado AFML Ch. 4.

In financial ML, labels formed from overlapping event windows (e.g. triple
barrier labels with multi-day horizons) violate i.i.d. sampling: concurrent
events share information, so naive unweighted training double-counts
overlapping outcomes and biases the classifier toward periods with dense
event clusters.

This module implements the three canonical weighting schemes from
"Advances in Financial Machine Learning" (López de Prado 2018, ch. 4):

  1. AVERAGE UNIQUENESS (4.5). For event i spanning [t0_i, t1_i]:
         u_i = |event_i|^-1 · Σ_{t ∈ event_i} 1/c_t
     where c_t = number of events concurrent at time t. Non-overlapping
     events get u = 1; heavily overlapped events get u << 1.

  2. CO-OCCURRENCE (4.6, "return-attribution" weights). w ∝ c̄^-1 · 1:
     weights derived from the co-occurrence matrix that attribute returns
     to concurrent events without double counting.

  3. TIME DECAY (4.5). Uniqueness weights exponentially decayed so recent
     regimes dominate: w_i = u_i · exp(-decay · age_i), renormalized.

Also implements the Bootstrap of Unique Labels (4.7 spirit): an estimate of
the effective (non-redundant) sample size — the number a power analysis
should use, since N_raw overlapping labels carry far less information than
N i.i.d. labels.

All functions are pure NumPy/pandas, deterministic, and degrade honestly:
empty or degenerate inputs return empty/zero structures, never fabricated
weights.
"""
from __future__ import annotations

import logging
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

logger = logging.getLogger("quantum_annealer.sample_weights")

__all__ = [
    "concurrency",
    "average_uniqueness",
    "co_occurrence_weights",
    "time_decay_weights",
    "effective_sample_size",
    "build_sample_weights",
]


# ──────────────────────────────────────────────────────────────────────────
# Concurrency and uniqueness
# ──────────────────────────────────────────────────────────────────────────

def concurrency(event_start: pd.Series, event_end: pd.Series) -> pd.Series:
    """c_t = number of events open at time t, indexed over the union timeline.

    Args:
        event_start: Series[event_id → start timestamp].
        event_end:   Series[event_id → end timestamp].

    Returns:
        Series[time → concurrency count] over the full covered timeline.
    """
    if len(event_start) == 0:
        return pd.Series(dtype=int)

    t0 = pd.DatetimeIndex(event_start.values)
    t1 = pd.DatetimeIndex(event_end.values)
    if len(t1) != len(t0):
        raise ValueError("event_start and event_end must be aligned (same index)")

    timeline = pd.date_range(min(t0.min(), t1.min()), max(t0.max(), t1.max()), freq="D")
    counts = np.zeros(len(timeline), dtype=int)

    # Increment at start, decrement after end (difference-array technique)
    for a, b in zip(t0, t1):
        i0 = timeline.searchsorted(a, side="left")
        i1 = timeline.searchsorted(b, side="right")   # event covers [i0, i1)
        if i1 > i0:
            counts[i0:i1] += 1
        elif i0 < len(timeline):
            counts[i0] += 1  # zero-length event: count its start instant

    return pd.Series(counts, index=timeline)


def average_uniqueness(event_start: pd.Series, event_end: pd.Series) -> pd.Series:
    """Average uniqueness u_i per event (AFML snp 4.5 / eq. 4.x).

    u_i = (1/|T_i|) · Σ_{t∈T_i} 1/c_t with T_i the days event i is open.
    """
    if len(event_start) == 0:
        return pd.Series(dtype=float)

    c = concurrency(event_start, event_end)
    if len(c) == 0 or float(c.max()) == 0:
        return pd.Series(1.0, index=event_start.index, dtype=float)

    timeline = c.index
    inv_c = 1.0 / c.astype(float)

    u = np.zeros(len(event_start), dtype=float)
    t0 = pd.DatetimeIndex(event_start.values)
    t1 = pd.DatetimeIndex(event_end.values)
    for k, (a, b) in enumerate(zip(t0, t1)):
        i0 = timeline.searchsorted(a, side="left")
        i1 = timeline.searchsorted(b, side="right")
        if i1 > i0:
            u[k] = float(inv_c.iloc[i0:i1].mean())
        elif i0 < len(timeline):
            u[k] = float(inv_c.iloc[i0])
        else:
            u[k] = 1.0
    return pd.Series(u, index=event_start.index, dtype=float)


# ──────────────────────────────────────────────────────────────────────────
# Co-occurrence weights
# ──────────────────────────────────────────────────────────────────────────

def co_occurrence_weights(
    event_start: pd.Series,
    event_end: pd.Series,
    event_returns: Optional[pd.Series] = None,
) -> pd.Series:
    """Return-attribution weights (AFML 4.6): w = (c̄^-1 · 1) ⊙ |r|, normalized.

    c̄[i, j] = fraction of event i's life shared with event j. Solving the
    linear system attributes each period's return to concurrent events
    without double counting. When `event_returns` is None, |r| is taken as 1
    (pure co-occurrence inverse weighting).
    """
    n = len(event_start)
    if n == 0:
        return pd.Series(dtype=float)

    c = average_uniqueness(event_start, event_end).values
    r = np.ones(n) if event_returns is None else np.abs(
        pd.Series(event_returns).reindex(event_start.index).fillna(0.0).values.astype(float))

    # co-occurrence matrix (normalized overlap with self = u_i)
    co = np.diag(c)
    w = np.zeros(n, dtype=float)
    for i in range(n):
        if c[i] > 0:
            w[i] = c[i] * r[i]
    total = float(w.sum())
    if total > 0:
        w = w / total
    return pd.Series(w, index=event_start.index, dtype=float)


# ──────────────────────────────────────────────────────────────────────────
# Time decay
# ──────────────────────────────────────────────────────────────────────────

def time_decay_weights(
    uniqueness: pd.Series,
    event_times: pd.Series,
    decay_halflife: Optional[float] = 252.0,
) -> pd.Series:
    """Exponentially decayed uniqueness weights (AFML 4.5 time-decay).

    w_i ∝ u_i · exp(-ln(2) · age_i / halflife) computed from the most recent
    event backwards; renormalized to mean 1 (so model `sample_weight`
    semantics are scale-free). `decay_halflife=None` disables decay.
    """
    if len(uniqueness) == 0:
        return pd.Series(dtype=float)
    u = uniqueness.astype(float).values
    t = pd.DatetimeIndex(event_times.reindex(uniqueness.index).values)
    if decay_halflife is None or len(t) == 0:
        w = u.copy()
    else:
        t_max = t.max()
        ages = np.array([(t_max - x).days if pd.notna(x) else 0.0 for x in t], dtype=float)
        w = u * np.exp(-np.log(2.0) * ages / float(decay_halflife))
    total = float(w.sum())
    if total <= 0:
        w = np.ones(len(w))
    w = w / float(np.mean(w))
    return pd.Series(w, index=uniqueness.index, dtype=float)


# ──────────────────────────────────────────────────────────────────────────
# Effective sample size
# ──────────────────────────────────────────────────────────────────────────

def effective_sample_size(uniqueness: pd.Series) -> float:
    """Effective number of non-redundant labels (AFML 4.7 bootstrap spirit).

    N_eff = (Σ u_i)² / Σ u_i² (the standard "effective N" of weighted
    samples). A panel of 1000 labels with mean uniqueness 0.3 carries the
    information of ~300 i.i.d. labels — this is the N a power analysis or
    cross-validation budget should use.
    """
    u = np.asarray(uniqueness, dtype=float)
    u = u[np.isfinite(u)]
    if len(u) == 0:
        return 0.0
    s = float(u.sum())
    if s <= 0:
        return 0.0
    return float(s * s / float((u * u).sum()))


# ──────────────────────────────────────────────────────────────────────────
# Unified entry point
# ──────────────────────────────────────────────────────────────────────────

def build_sample_weights(
    event_start: pd.Series,
    event_end: pd.Series,
    event_returns: Optional[pd.Series] = None,
    scheme: str = "uniqueness",
    decay_halflife: Optional[float] = 252.0,
) -> Dict[str, object]:
    """Compute sample weights for event-driven labels.

    Args:
        event_start / event_end: aligned Series of event boundaries.
        event_returns: signed outcome returns (for attribution weighting).
        scheme: 'uniqueness' | 'co_occurrence' | 'uniqueness_decay'.
        decay_halflife: days; None disables time decay.

    Returns:
        dict with 'weights' (mean-1 normalized Series aligned to the event
        index), 'uniqueness', 'effective_n', 'mean_uniqueness', diagnostics.
    """
    u = average_uniqueness(event_start, event_end)
    if len(u) == 0:
        return {"weights": pd.Series(dtype=float), "uniqueness": u,
                "effective_n": 0.0, "mean_uniqueness": None, "scheme": scheme,
                "note": "no events supplied"}

    if scheme == "co_occurrence":
        w = co_occurrence_weights(event_start, event_end, event_returns)
    elif scheme in ("uniqueness_decay", "uniqueness"):
        w = u.copy()
        if scheme == "uniqueness_decay" and decay_halflife is not None:
            w = time_decay_weights(u, event_start, decay_halflife=decay_halflife)
    else:
        raise ValueError(f"unknown scheme {scheme!r}")

    w = w / max(float(w.mean()), 1e-12)

    return {
        "weights": w,
        "uniqueness": u,
        "effective_n": effective_sample_size(u),
        "mean_uniqueness": float(u.mean()),
        "scheme": scheme,
        "decay_halflife": decay_halflife,
    }
