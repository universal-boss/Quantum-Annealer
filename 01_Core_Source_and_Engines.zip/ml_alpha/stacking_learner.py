"""
Stacking Super Learner (Meta-Regressor)
Implements non-negative constrained Ridge Meta-Learner for optimal cross-validation blending:
- Generates Out-Of-Fold (OOF) cross-validation predictions for base models.
- Trains a Ridge Meta-Regressor with non-negative constraints (w_i >= 0, sum(w_i) = 1).
- Outperforms simple equal-weighting and rank-averaging across market regimes.
"""

import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge


class StackingSuperLearner:
    """Super Learner Meta-Regressor for dynamic model ensemble weighting."""

    def __init__(self, alpha: float = 1.0):
        self.alpha = alpha
        self.meta_model = Ridge(alpha=alpha, positive=True, fit_intercept=False)
        self.weights_: np.ndarray | None = None
        self.is_fitted: bool = False

    def fit(self, oof_predictions: pd.DataFrame, target: pd.Series) -> dict[str, float]:
        """Fits the meta-learner on out-of-fold predictions matrix."""
        valid_idx = oof_predictions.dropna().index.intersection(target.dropna().index)
        if len(valid_idx) < 20:
            # Fallback to equal weighting if OOF rows are too sparse
            n_models = oof_predictions.shape[1]
            self.weights_ = np.ones(n_models) / max(n_models, 1)
            self.is_fitted = True
            return dict(zip(oof_predictions.columns, self.weights_))

        X_oof = oof_predictions.loc[valid_idx].fillna(0.0).to_numpy()
        y_tgt = target.loc[valid_idx].to_numpy()

        self.meta_model.fit(X_oof, y_tgt)
        raw_weights = self.meta_model.coef_

        if raw_weights.sum() > 0:
            self.weights_ = raw_weights / raw_weights.sum()
        else:
            self.weights_ = np.ones(len(raw_weights)) / len(raw_weights)

        # ROUND 45 FIX: remember the column order the weights were learned in,
        # so predict() can re-align a differently-ordered frame (previously the
        # dot product paired weights with whatever columns arrived — silently
        # wrong blend, no error).
        self._fit_columns = list(oof_predictions.columns)
        self.is_fitted = True
        return dict(zip(oof_predictions.columns, self.weights_))

    def predict(self, base_predictions: pd.DataFrame) -> pd.Series:
        """Combines base model predictions using learned meta-weights."""
        if not self.is_fitted or self.weights_ is None:
            return base_predictions.mean(axis=1)

        # ROUND 45 FIX: re-index to the columns the meta-weights were learned
        # on (wrong-order/superset frames previously blended positionally).
        fit_cols = list(getattr(self, "_fit_columns", []) or base_predictions.columns)
        if fit_cols and list(base_predictions.columns) != fit_cols:
            base_predictions = base_predictions.reindex(columns=fit_cols)
        X_pred = base_predictions.fillna(0.0).to_numpy()
        combined = np.dot(X_pred, self.weights_)
        return pd.Series(combined, index=base_predictions.index)
