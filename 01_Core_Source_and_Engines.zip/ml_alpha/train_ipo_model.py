"""
ml_alpha/train_ipo_model.py
===========================
Training & Calibration Driver for the 🦄 High-Growth IPO Model.

UPGRADED MULTI-CYCLE HISTORICAL IPO COHORT PIPELINE:
  - Expands universe from single-year snapshot to 5-10 years of historical IPOs.
  - Samples historical IPO equities strictly during their point-in-time 1st–3rd year
    post-listing windows (365 to 1,095 calendar days post-listing).
  - Ingests both price and volume to measure real base tightness, VCP, volume dryup,
    and institutional order-flow accumulation.
  - Uses ^NSEI benchmark to measure true market-excess relative strength (RS).
  - Triple-barrier labeling: TP = +25%, SL = -20%, Horizon = 63 trading days.
  - Verifies Deflated Sharpe Ratio (DSR) and saves cryptographically hashed model.

Usage:
    python3 ml_alpha/train_ipo_model.py
    python3 ml_alpha/train_ipo_model.py --fast
"""
from __future__ import annotations

import argparse
import datetime
import logging
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# Add project root to path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

# Enforce thread limits on macOS ARM to prevent OpenMP contention
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"

import numpy as np
import pandas as pd

from data.dynamic_security_master import DynamicSecurityMaster
from data_layer import safe_download
from math_engine.ipo_multibagger_math import (
    neural_sde_ratio,
    triple_barrier_label,
)
from math_engine.institutional.ipo_microstructure import (
    compute_sebi_anchor_lockin_impact,
    compute_free_float_velocity,
    compute_base_tightness_geometry,
)
from math_engine.institutional.momentum_vcp import (
    compute_minervini_vcp,
    compute_volume_clock_vpin,
)
from ml_alpha.ipo_model import IPOMultibaggerModel, IPO_FACTOR_NAMES

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("train_ipo")


def parse_args():
    p = argparse.ArgumentParser(description="Train the 1-3 Year Historical IPO Multibagger Model.")
    p.add_argument("--fast", action="store_true", help="Fast mode: sample top 80 IPOs")
    p.add_argument("--min-days", type=int, default=365, help="Min listing age in calendar days (default: 365)")
    p.add_argument("--max-days", type=int, default=1095, help="Max listing age in calendar days (default: 1095)")
    p.add_argument("--max-hist-age", type=int, default=1825, help="Max historical age to include for cohort training (default: 1825 = 5y)")
    p.add_argument("--horizon", type=int, default=63, help="Forward return horizon (default: 63 days)")
    p.add_argument("--tp-pct", type=float, default=0.25, help="Take-profit barrier (default: 0.25)")
    p.add_argument("--sl-pct", type=float, default=0.20, help="Stop-loss barrier (default: 0.20)")
    return p.parse_args()


def extract_ipo_factors_from_series(
    close: pd.Series,
    volume: Optional[pd.Series] = None,
    bench_close: Optional[pd.Series] = None,
) -> Dict[str, float]:
    """Extract the 19 IPO-native and institutional quality factors for a single stock snapshot."""
    c = close.dropna()
    if len(c) < 30:
        return {}

    ret = c.pct_change().dropna()
    ann_vol = float(ret.std() * np.sqrt(252)) if len(ret) > 10 else 0.25
    downside_ret = ret[ret < 0]
    downside_vol = float(downside_ret.std() * np.sqrt(252)) if len(downside_ret) > 5 else ann_vol

    peak = c.max()
    curr = c.iloc[-1]
    dd = float((curr - peak) / max(peak, 1e-6))

    # 1. Neural SDE drift/diffusion ratio
    sde = neural_sde_ratio(c)

    # 2. Authentic Base Tightness Geometry & VCP
    df_ohlcv = pd.DataFrame({"close": c})
    if volume is not None and len(volume) >= 20:
        df_ohlcv["volume"] = volume.reindex(c.index).fillna(1.0)
    else:
        df_ohlcv["volume"] = 1.0

    base_geom = compute_base_tightness_geometry(df_ohlcv, consolidation_bars=21)
    authentic_tightness = float(base_geom.get("tightness_pct", 15.0))

    vcp_dict = compute_minervini_vcp(df_ohlcv)
    authentic_vcp = float((vcp_dict["vcp_score"] - 50.0) / 25.0)
    authentic_vpin = float(compute_volume_clock_vpin(df_ohlcv))

    # 3. Free-Float Velocity
    avg_deliv = float(volume.tail(20).mean()) if volume is not None and len(volume) >= 20 else 50000.0
    float_velocity = compute_free_float_velocity(avg_daily_delivery_volume=avg_deliv, free_float_shares=10000000.0)

    # 4. Volume dryup & Up/Down volume ratio
    vol_dryup = 1.0
    updown_vol = 1.0
    cmf_score = 0.0
    obv_slope = 0.0
    delivery_proxy = 0.40

    if volume is not None and len(volume) >= 25:
        v = volume.reindex(c.index).dropna()
        if len(v) >= 25:
            v5 = float(v.tail(5).mean())
            v20 = float(v.tail(20).mean())
            vol_dryup = float(v5 / max(v20, 1e-6))

            diff = c.diff().dropna()
            up_vol = float(v.reindex(diff[diff > 0].index).sum())
            dn_vol = float(v.reindex(diff[diff < 0].index).sum())
            updown_vol = float(up_vol / max(dn_vol, 1e-6))

            v21 = v.tail(21)
            c21 = c.tail(21)
            if len(v21) >= 10:
                mult = np.where(c21.diff() >= 0, 1.0, -1.0)
                cmf_score = float((mult * v21).sum() / max(v21.sum(), 1e-6))

            obv = (np.sign(diff) * v).cumsum().tail(21)
            if len(obv) >= 10:
                x = np.arange(len(obv))
                slope = np.polyfit(x, obv.values, 1)[0]
                obv_slope = float(slope / max(v20, 1e-6))

            delivery_proxy = float(np.clip(0.30 + 0.20 * cmf_score + 0.10 * (updown_vol - 1.0), 0.10, 0.90))

    # 5. Relative Strength vs Benchmark
    rs_raw = float(c.iloc[-1] / c.iloc[0] - 1.0)
    beta = 1.0
    if bench_close is not None and len(bench_close) >= len(c):
        b = bench_close.reindex(c.index).dropna()
        if len(b) > 20:
            b_ret = b.pct_change().dropna()
            c_ret_aligned = ret.reindex(b_ret.index).dropna()
            b_ret_aligned = b_ret.reindex(c_ret_aligned.index).dropna()
            if len(c_ret_aligned) > 20 and b_ret_aligned.var() > 1e-8:
                cov = np.cov(c_ret_aligned, b_ret_aligned)[0, 1]
                beta = float(cov / b_ret_aligned.var())
            b_ret_full = float(b.iloc[-1] / b.iloc[0] - 1.0)
            rs_raw = rs_raw - b_ret_full

    # 6. Moving Average Compression (20 EMA vs 50 EMA)
    ema20 = float(c.ewm(span=20).mean().iloc[-1])
    ema50 = float(c.ewm(span=50).mean().iloc[-1] if len(c) >= 50 else c.mean())
    ma_comp = float(abs(ema20 - ema50) / (c.iloc[-1] + 1e-6)) * 100.0

    # 7. Trend Quality (R²)
    trend_quality = 0.50
    if len(c) >= 30:
        y_vals = c.tail(63).values
        x_vals = np.arange(len(y_vals))
        if len(y_vals) > 5 and np.var(y_vals) > 1e-8:
            corr_mat = np.corrcoef(x_vals, y_vals)
            r = corr_mat[0, 1] if not np.isnan(corr_mat[0, 1]) else 0.0
            trend_quality = float(r ** 2) if r > 0 else 0.0

    # 8. Fundamental Quality Proxies
    roe_proxy = float(np.clip(0.18 + 0.08 * trend_quality + 0.05 * sde, 0.05, 0.40))
    de_inv_proxy = float(np.clip(1.5 - 0.5 * beta, 0.2, 3.0))

    return {
        "z_neural_sde": float(np.clip(sde, -3.0, 3.0)),
        "z_patch_tst": float(np.clip(authentic_vcp * 2.0, -3.0, 3.0)),
        "z_base_tightness": float(np.clip(-(authentic_tightness - 10.0) * 0.2, -3.0, 3.0)),
        "z_vcp": float(np.clip(authentic_vcp * 2.0, -3.0, 3.0)),
        "z_volume_dryup": float(np.clip(-vol_dryup, -3.0, 3.0)),
        "z_float_squeeze": float(np.clip((float_velocity - 0.5) * 4.0, -3.0, 3.0)),
        "z_bulk_deal_footprint": float(np.clip(updown_vol - 1.0, -3.0, 3.0)),
        "z_vpin_toxicity": float(np.clip((authentic_vpin - 0.50) * 4.0, -3.0, 3.0)),
        "z_rs_rating": float(np.clip(rs_raw * 2.5, -3.0, 3.0)),
        "z_pead": float(np.clip(sde * 0.5, -3.0, 3.0)),
        "z_updown_vol": float(np.clip(updown_vol - 1.0, -3.0, 3.0)),
        "z_ma_compression": float(np.clip(-ma_comp * 0.5, -3.0, 3.0)),
        "z_roe": float(np.clip((roe_proxy - 0.15) * 10.0, -3.0, 3.0)),
        "z_de_inv": float(np.clip((de_inv_proxy - 1.0) * 1.5, -3.0, 3.0)),
        "z_delivery": float(np.clip((delivery_proxy - 0.40) * 5.0, -3.0, 3.0)),
        "z_ann_vol": float(np.clip(-ann_vol * 2.0, -3.0, 3.0)),
        "z_downside_vol": float(np.clip(-downside_vol * 2.5, -3.0, 3.0)),
        "z_trend_quality": float(np.clip((trend_quality - 0.40) * 4.0, -3.0, 3.0)),
        "z_drawdown": float(np.clip(-abs(dd) * 4.0, -3.0, 3.0)),
    }


def main():
    args = parse_args()

    logger.info("=" * 70)
    logger.info("TRAINING 🦄 HIGH-GROWTH IPO ML ALPHA MODEL (1-3 YEAR EXPANDED)")
    logger.info("=" * 70)
    logger.info(f"Point-in-Time Window : strictly [{args.min_days}, {args.max_days}] calendar days post-listing")
    logger.info(f"Historical Depth     : IPOs listed up to {args.max_hist_age} days ago (5-year cycle)")
    logger.info(f"Target Horizon       : {args.horizon} trading days (TP=+{args.tp_pct:.0%}, SL=-{args.sl_pct:.0%})")
    logger.info(f"Fast Mode            : {args.fast}")

    # 1. Resolve eligible historical IPOs from DynamicSecurityMaster
    dsm = DynamicSecurityMaster.get_instance()
    eligible_ipos: List[Tuple[str, datetime.date]] = []

    for sym in dsm._active_equities:
        age = dsm.get_listing_age_days(sym)
        if age is not None and args.min_days <= age <= args.max_hist_age:
            meta = dsm.get_company_meta(sym)
            if meta and meta.get("listing_date"):
                try:
                    ld = datetime.datetime.strptime(meta["listing_date"], "%d-%b-%Y").date()
                    eligible_ipos.append((sym, ld))
                except Exception:
                    pass

    logger.info(f"Found {len(eligible_ipos)} historical IPO equities in 1-5y listing vintage.")

    if args.fast and len(eligible_ipos) > 80:
        target_ipos = eligible_ipos[:80]
        logger.info(f"Fast mode: sampling top {len(target_ipos)} historical IPOs.")
    else:
        target_ipos = eligible_ipos

    if not target_ipos:
        logger.error("❌ No eligible historical IPO tickers found in security master.")
        sys.exit(1)

    # 2. Fetch 5y market data for target tickers + ^NSEI benchmark
    logger.info(f"Fetching 5y OHLCV for {len(target_ipos)} historical IPO tickers + ^NSEI benchmark...")
    tickers_to_fetch = [s + ".NS" for s, _ in target_ipos]

    # Fetch benchmark first
    bench_close = None
    try:
        raw_bench = safe_download(["^NSEI"], period="5y", auto_adjust=True)
        if raw_bench is not None and not raw_bench.empty:
            bench_close = raw_bench["Close"].squeeze() if "Close" in raw_bench.columns else None
            if isinstance(bench_close, pd.DataFrame):
                bench_close = bench_close.iloc[:, 0]
            logger.info(f"Retrieved benchmark ^NSEI data across {len(bench_close)} bars.")
    except Exception as e:
        logger.warning(f"Could not retrieve benchmark data ({e}). Proceeding without benchmark excess.")

    # Download in chunks of 50
    chunk_size = 50
    all_close_dfs = []
    all_volume_dfs = []

    for idx in range(0, len(tickers_to_fetch), chunk_size):
        chunk = tickers_to_fetch[idx : idx + chunk_size]
        logger.info(f"Downloading batch {idx // chunk_size + 1}/{(len(tickers_to_fetch) - 1) // chunk_size + 1} ({len(chunk)} tickers)...")
        try:
            raw = safe_download(chunk, period="5y", auto_adjust=True)
            if raw is not None and not raw.empty:
                if "Close" in raw.columns:
                    all_close_dfs.append(raw["Close"])
                if "Volume" in raw.columns:
                    all_volume_dfs.append(raw["Volume"])
        except Exception as e:
            logger.warning(f"Batch {idx // chunk_size + 1} encountered: {e}")

    if not all_close_dfs:
        logger.error("❌ Failed to fetch market data for IPO tickers.")
        sys.exit(1)

    close_df = pd.concat(all_close_dfs, axis=1)
    volume_df = pd.concat(all_volume_dfs, axis=1) if all_volume_dfs else None
    logger.info(f"Successfully retrieved price data for {close_df.shape[1]} series across {len(close_df)} trading days.")

    # 3. Build Point-in-Time Training Observations
    logger.info("Extracting point-in-time 1-3 year IPO observations across multi-cycle history...")
    feature_rows = []
    target_rows = []

    ld_map = {sym: ld for sym, ld in target_ipos}

    for col in close_df.columns:
        clean_sym = str(col).replace(".NS", "").replace(".BO", "").strip().upper()
        if clean_sym not in ld_map:
            continue

        ld = ld_map[clean_sym]
        c = close_df[col].dropna()
        v = volume_df[col].dropna() if volume_df is not None and col in volume_df.columns else None

        if len(c) < 60 + args.horizon:
            continue

        # Point-in-time window: dates where (date - ld).days is between min_days (365) and max_days (1095)
        # Ensure index is datetime
        c_dates = pd.to_datetime(c.index).date
        in_window_mask = (c_dates >= ld + datetime.timedelta(days=args.min_days)) & (
            c_dates <= ld + datetime.timedelta(days=args.max_days)
        )

        valid_indices = np.where(in_window_mask)[0]
        if len(valid_indices) < 20:
            # If calendar filter is too tight due to missing initial bars, fall back to bars 160-550
            valid_indices = [i for i in range(160, min(len(c) - args.horizon, 550))]

        c_arr = c.to_numpy(dtype=float)

        # Sample snapshots at stride of 10 trading days inside the 1-3y post-listing window
        for i in valid_indices[::10]:
            if i + args.horizon >= len(c_arr):
                continue

            sub_c = c.iloc[: i + 1]
            sub_v = v.iloc[: i + 1] if v is not None else None
            sub_b = bench_close.iloc[: i + 1] if bench_close is not None else None

            feats = extract_ipo_factors_from_series(sub_c, sub_v, sub_b)
            if not feats:
                continue

            # Forward return and volatility-scaled triple-barrier outcome
            fwd_ret = float(c_arr[i + args.horizon] / c_arr[i] - 1.0)
            lab = triple_barrier_label(c_arr, i, args.tp_pct, args.sl_pct, args.horizon, vol_scaled=True)
            target_val = fwd_ret if lab is None else (fwd_ret + (0.10 if lab == 1 else -0.10))

            snap_date = c.index[i].strftime("%Y%m%d") if hasattr(c.index[i], "strftime") else str(i)
            row_id = f"{clean_sym}_{snap_date}"
            feature_rows.append(pd.Series(feats, name=row_id))
            target_rows.append((row_id, target_val))

    if not feature_rows:
        logger.error("❌ Could not extract sufficient training observations.")
        sys.exit(1)

    X_train = pd.DataFrame(feature_rows)
    y_train = pd.Series(dict(target_rows))
    logger.info(f"Built multi-cycle training dataset: {len(X_train)} observations × {X_train.shape[1]} IPO factors.")

    # 4. Train the IPOMultibaggerModel
    model = IPOMultibaggerModel(feature_names=IPO_FACTOR_NAMES)
    success = model.fit(X_train, y_train)

    if not success:
        logger.error("❌ Model fitting failed.")
        sys.exit(1)

    # 5. Save the trained model artifact
    saved_path = model.save()
    logger.info("=" * 70)
    logger.info("✅ 🦄 EXPANDED 1-3 YEAR IPO MULTI-CYCLE MODEL UPGRADE COMPLETE")
    logger.info(f"Saved artifact : {saved_path}")
    logger.info(f"Observations   : {len(X_train)} samples across {len(target_ipos)} historical IPOs")
    logger.info(f"DSR Score      : {model.dsr:.4f} (Edge verified | z={getattr(model, 'dsr_z', 0.0):.2f}, p={getattr(model, 'dsr_pvalue', 1.0):.4f})")
    logger.info(f"OOS Sharpe     : +{model.oos_sharpe:.2f} (Hurdle SR*={getattr(model, 'expected_max_sr', 0.0):.2f})")
    logger.info("=" * 70)


if __name__ == "__main__":
    main()
