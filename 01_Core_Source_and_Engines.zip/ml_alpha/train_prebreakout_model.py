"""
ml_alpha/train_prebreakout_model.py
===================================
Multi-Cycle Training & Calibration Driver for the Institutional Pre-Breakout Inception Model.

WORKFLOW:
  1. Downloads 5-year multi-cycle historical daily data across a diversified universe of
     liquid, mid-cap, and high-beta multibagger equities on the NSE (including BODALCHEM,
     TRENT, DIXON, POLYCAB, HAL, BEL, CDSL, DEEPAKNTR, RELIANCE, TITAN, etc.).
  2. Extracts point-in-time multi-modal features (quantitative, microstructure, fractal, and
     geometric vision from VisionChartAuditor) across rolling base consolidation periods.
  3. Applies López de Prado Dynamic Volatility-Scaled Triple-Barrier Labeling:
       - Upper barrier (take-profit): +20% (or 2.5 * daily_vol * sqrt(15))
       - Lower barrier (stop-loss):   -5%  (tight stop below base support floor)
       - Holding horizon: 15 trading days (>= 4:1 asymmetric reward-to-risk)
  4. Validates via Combinatorial Purged & Embargoed Cross-Validation (CPCV).
  5. Computes Deflated Sharpe Ratio (DSR > 0.85) to verify statistical significance against data-mining bias.
  6. Persists the trained artifact to models/ml_alpha_prebreakout.pkl with cryptographic SHA-256 sidecar.

Usage:
    python3 ml_alpha/train_prebreakout_model.py
    python3 ml_alpha/train_prebreakout_model.py --fast
"""
from __future__ import annotations

import argparse
import datetime
import logging
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

# Enforce thread limits on macOS ARM
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"

import numpy as np
import pandas as pd

from data_layer import safe_download
from math_engine.ipo_multibagger_math import (
    neural_sde_ratio,
    triple_barrier_label,
)
from math_engine.institutional.momentum_vcp import (
    compute_minervini_vcp,
    compute_volume_clock_vpin,
)
from math_engine.vision_chart_auditor import VisionChartAuditor
from ml_alpha.prebreakout_model import (
    PreBreakoutInceptionModel,
    PREBREAKOUT_FACTOR_NAMES,
    MODEL_PATH,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("train_prebreakout")

PREBREAKOUT_SEED_MULTIBAGGERS = [
    # Historical Benchmark Cohort (Multibagger & High-Alpha Base Builders for Validation)
    "BODALCHEM", "TRENT", "DIXON", "POLYCAB", "HAL", "BEL", "CDSL", "DEEPAKNTR",
    "KALYANKJIL", "SUZLON", "BSE", "MAZDOCK", "COCHINSHIP", "TITAGARH", "RVNL",
    "APOLLOHOSP", "MAXHEALTH", "JUBLFOOD", "DEVYANI", "CUMMINSIND", "ASTRAL",
    "SUPREMEIND", "PERSISTENT", "COFORGE", "LTIM", "HCLTECH", "TATAMOTORS", "M&M",
    "BAJAJ-AUTO", "HEROMOTOCO", "VOLTAS", "HAVELLS", "CROMPTON", "INDHOTEL",
    "VBL", "CHOLAFIN", "SHRIRAMFIN", "MUTHOOTFIN", "PIIND", "SRF", "NAVINFLUOR",
    "AARTIIND", "TATACHEM", "PIDILITIND", "BERGEPAINT", "ASIANPAINT", "SUNPHARMA",
    "CIPLA", "DRREDDY", "DIVISLAB", "RELIANCE", "TCS", "INFY", "HDFCBANK", "ICICIBANK",
]


def parse_args():
    p = argparse.ArgumentParser(description="Train Institutional Pre-Breakout Inception Model.")
    p.add_argument(
        "--universe",
        type=str,
        default="full_nse",
        choices=["full_nse", "nifty500", "multibaggers"],
        help="Training universe: 'full_nse' (all 2,000+ active equities), 'nifty500', or 'multibaggers' (default: full_nse)",
    )
    p.add_argument(
        "--max-symbols",
        type=int,
        default=0,
        help="Max symbols to ingest (0 = all available in chosen universe)",
    )
    p.add_argument("--fast", action="store_true", help="Fast mode: sample top 25 equities")
    p.add_argument("--horizon", type=int, default=15, help="Breakout forward horizon (default: 15 days)")
    p.add_argument("--tp-pct", type=float, default=0.20, help="Take-profit barrier (default: 0.20 = +20%%)")
    p.add_argument("--sl-pct", type=float, default=0.05, help="Stop-loss barrier (default: 0.05 = -5%%)")
    return p.parse_args()


def get_training_universe(mode: str = "full_nse", max_symbols: int = 0) -> List[str]:
    """Retrieve dynamic training universe from DynamicSecurityMaster or official NSE lists."""
    if mode == "full_nse":
        try:
            from data.dynamic_security_master import DynamicSecurityMaster
            master = DynamicSecurityMaster.get_instance()
            active = list(master._active_equities.keys())
            if active:
                active = [s for s in active if not s.startswith(("NIFTY", "BANK", "GOLDBEES", "CPSE"))]
                logger.info(f"Loaded {len(active)} active equities from DynamicSecurityMaster.")
                return active[:max_symbols] if max_symbols > 0 else active
        except Exception as e:
            logger.warning(f"DynamicSecurityMaster load failed: {e}")
        try:
            from data.universe import fetch_nse_tickers
            all_nse = fetch_nse_tickers()
            symbols = [s.replace(".NS", "") for s in all_nse]
            return symbols[:max_symbols] if max_symbols > 0 else symbols
        except Exception as e:
            logger.warning(f"fetch_nse_tickers failed: {e}")

    elif mode == "nifty500":
        try:
            from data.universe import fetch_nifty500_tickers
            n500 = fetch_nifty500_tickers()
            symbols = [s.replace(".NS", "") for s in n500]
            logger.info(f"Loaded {len(symbols)} Nifty 500 index constituents.")
            return symbols[:max_symbols] if max_symbols > 0 else symbols
        except Exception as e:
            logger.warning(f"fetch_nifty500_tickers failed: {e}")

    # Fallback to high-beta multibagger cohort
    if max_symbols > 0:
        return PREBREAKOUT_SEED_MULTIBAGGERS[:max_symbols]
    return PREBREAKOUT_SEED_MULTIBAGGERS


def compute_hurst(series: pd.Series) -> float:
    """18-point Hurst exponent log-log regression with numerical stability safeguards."""
    try:
        vals = series.values
        if len(vals) < 40:
            return 0.50  # Theoretical prior: H=0.50 = pure Brownian motion (no memory detected)
        lags = range(2, 20)
        tau = [max(1e-8, float(np.sqrt(np.std(np.subtract(vals[lag:], vals[:-lag]))))) for lag in lags]
        poly = np.polyfit(np.log(lags), np.log(tau), 1)
        return float(np.clip(poly[0] * 2.0, 0.0, 1.0))
    except Exception as _e:
        logger.warning(f"[compute_hurst] computation failed ({_e}) — returning None")
        return None


def extract_prebreakout_features(
    close: pd.Series,
    volume: Optional[pd.Series],
    bench_close: Optional[pd.Series],
    df_ohlcv: pd.DataFrame,
) -> Dict[str, float]:
    """
    Extracts the 16 institutional factors from point-in-time OHLCV history.
    """
    if len(close) < 60:
        return {}

    c = close.dropna()
    v = volume.reindex(c.index).dropna() if volume is not None else None
    n = len(c)

    ret = np.diff(c.values) / (c.values[:-1] + 1e-9)
    ann_vol = float(np.std(ret) * np.sqrt(252)) if len(ret) > 10 else 0.25

    # 1. Base Tightness: 20-day high-low consolidation spread / midpoint
    tail_20_h = float(c.tail(20).max())
    tail_20_l = float(c.tail(20).min())
    tail_20_mid = float(c.tail(20).mean())
    base_tightness_pct = float(((tail_20_h - tail_20_l) / (tail_20_mid + 1e-9)) * 100)
    # Tighter base = higher pre-breakout score
    z_base_tightness = float(np.clip(3.0 - (base_tightness_pct / 5.0), -3.0, 3.0))

    # 2. VCP Compression: multi-cycle ATR contraction ratio (ATR10 / ATR30)
    vcp_dict = compute_minervini_vcp(df_ohlcv)
    raw_vcp = float(vcp_dict.get("vcp_score", 50.0))
    z_vcp_compression = float(np.clip((raw_vcp - 50.0) / 15.0, -3.0, 3.0))

    # 3. Volume Dryup: 5-day volume / 20-day volume on consolidation pullbacks
    if v is not None and len(v) >= 20:
        v5 = float(v.tail(5).mean())
        v20 = float(v.tail(20).mean())
        dryup_ratio = float(v5 / (v20 + 1e-9))
        # Severe volume dryup (ratio < 0.6) = spring coiling
        z_volume_dryup = float(np.clip((1.0 - dryup_ratio) * 3.0, -3.0, 3.0))
    else:
        z_volume_dryup = 0.0

    # 4. OBV Divergence: 21-day linear regression slope of On-Balance Volume
    if v is not None and len(v) >= 21:
        diff_c = c.diff().tail(21).fillna(0.0)
        v_tail = v.tail(21)
        obv = (np.sign(diff_c) * v_tail).cumsum()
        x_axis = np.arange(len(obv), dtype=float)
        slope = float(np.polyfit(x_axis, obv.values, 1)[0]) if len(obv) >= 10 else 0.0
        avg_v = float(v_tail.mean()) + 1e-9
        z_obv_divergence = float(np.clip((slope / avg_v) * 2.5, -3.0, 3.0))
    else:
        z_obv_divergence = 0.0

    # 5. Delivery Absorption: Up-volume accumulation vs down-volume distribution
    if v is not None and len(v) >= 21:
        diff_c = c.diff().tail(21).dropna()
        v_tail = v.reindex(diff_c.index).dropna()
        up_v = float(v_tail[diff_c > 0].sum())
        dn_v = float(v_tail[diff_c < 0].sum())
        updown_ratio = float(up_v / (dn_v + 1e-9))
        z_updown_vol = float(np.clip((updown_ratio - 1.0) * 1.5, -3.0, 3.0))
        # Synthetic delivery proxy: positive money flow + up/down volume skew
        deliv_proxy = 0.40 + 0.15 * np.tanh(z_updown_vol)
        z_delivery_absorption = float(np.clip((deliv_proxy - 0.40) * 5.0, -3.0, 3.0))
    else:
        z_updown_vol = 0.0
        z_delivery_absorption = 0.0

    # 6. Chaikin Money Flow (CMF 21d)
    if v is not None and len(v) >= 21:
        c21 = c.tail(21)
        v21 = v.tail(21)
        mult = np.where(c21.diff().fillna(0) >= 0, 1.0, -1.0)
        cmf = float((mult * v21).sum() / (v21.sum() + 1e-9))
        z_cmf = float(np.clip(cmf * 5.0, -3.0, 3.0))
    else:
        z_cmf = 0.0

    # 7. Keltner & Bollinger Volatility Squeeze (John Carter Squeeze)
    geo_res = VisionChartAuditor.audit_chart_geometry(df_ohlcv)
    keltner_sqz = bool(geo_res.get("keltner_squeeze", False) or geo_res.get("volume_dryup_confirmed", False))
    z_keltner_bb_squeeze = 1.8 if keltner_sqz else -0.5

    # 8. Pivot Proximity: distance to 20-day high launchpad
    last_price = float(c.iloc[-1])
    dist_pivot = max(0.0, (tail_20_h - last_price) / (tail_20_h + 1e-9) * 100)
    # Closer to pivot = ready to fire
    z_pivot_proximity = float(np.clip(2.5 - (dist_pivot / 3.0), -3.0, 3.0))

    # 9. Vision Conviction: Institutional Base Formation Index (VisionChartAuditor)
    raw_conviction = float(geo_res.get("visual_conviction_score", 75.0))
    z_vision_conviction = float(np.clip((raw_conviction - 60.0) / 12.0, -3.0, 3.0))

    # 10. Neural SDE: Itô drift-to-diffusion efficiency (μ/σ)
    sde = neural_sde_ratio(c)
    z_neural_sde = float(np.clip(sde * 1.5, -3.0, 3.0))

    # 11. Hurst Exponent: Fractal Persistence
    hurst_val = compute_hurst(c)
    z_hurst_exponent = float(np.clip((hurst_val - 0.50) * 6.0, -3.0, 3.0))

    # 12. Kaufman Efficiency Ratio (KER 21d)
    if len(c) >= 25:
        disp = abs(float(c.iloc[-1]) - float(c.iloc[-21]))
        path = float(np.sum(np.abs(np.diff(c.tail(21).values))) + 1e-9)
        ker = disp / path
        z_kaufman_efficiency = float(np.clip((ker - 0.35) * 4.0, -3.0, 3.0))
    else:
        z_kaufman_efficiency = 0.0

    # 13. VPIN Toxicity: Informed order flow accumulation
    vpin = float(compute_volume_clock_vpin(df_ohlcv))
    z_vpin_toxicity = float(np.clip((vpin - 0.30) * 5.0, -3.0, 3.0))

    # 14. Relative Strength Divergence vs Benchmark
    if bench_close is not None and len(bench_close) >= 21:
        bench_ret_21 = float(bench_close.iloc[-1] / (bench_close.iloc[-21] + 1e-9) - 1.0)
        stock_ret_21 = float(c.iloc[-1] / (c.iloc[-21] + 1e-9) - 1.0)
        rs_diff = stock_ret_21 - bench_ret_21
        z_rs_divergence = float(np.clip(rs_diff * 8.0, -3.0, 3.0))
    else:
        z_rs_divergence = 0.0

    # 15. Roll Effective Spread (Serial Covariance Liquidity Footprint)
    d_price = np.diff(c.tail(21).values)
    cov_roll = float(np.cov(d_price[:-1], d_price[1:])[0, 1]) if len(d_price) > 5 else 0.0
    roll_spread = 2.0 * np.sqrt(-cov_roll) if cov_roll < 0 else 0.0
    roll_pct = roll_spread / (last_price + 1e-9)
    z_roll_spread = float(np.clip(-(roll_pct - 0.01) * 20.0, -3.0, 3.0))

    return {
        "z_base_tightness": z_base_tightness,
        "z_vcp_compression": z_vcp_compression,
        "z_volume_dryup": z_volume_dryup,
        "z_obv_divergence": z_obv_divergence,
        "z_delivery_absorption": z_delivery_absorption,
        "z_cmf": z_cmf,
        "z_updown_vol": z_updown_vol,
        "z_keltner_bb_squeeze": z_keltner_bb_squeeze,
        "z_pivot_proximity": z_pivot_proximity,
        "z_vision_conviction": z_vision_conviction,
        "z_neural_sde": z_neural_sde,
        "z_hurst_exponent": z_hurst_exponent,
        "z_kaufman_efficiency": z_kaufman_efficiency,
        "z_vpin_toxicity": z_vpin_toxicity,
        "z_rs_divergence": z_rs_divergence,
        "z_roll_spread": z_roll_spread,
    }


def main():
    args = parse_args()
    if args.fast:
        tickers = get_training_universe(mode="multibaggers", max_symbols=25)
    else:
        tickers = get_training_universe(mode=args.universe, max_symbols=args.max_symbols)
    logger.info("=" * 80)
    logger.info("TRAINING INSTITUTIONAL PRE-BREAKOUT INCEPTION MODEL")
    logger.info("=" * 80)
    logger.info(f"Training Universe : {len(tickers)} equities (Universe: {args.universe}, Max: {args.max_symbols or 'All'})")
    logger.info(f"Target Barriers   : Take-Profit = +{args.tp_pct:.0%}, Stop-Loss = -{args.sl_pct:.0%}, Horizon = {args.horizon}d")
    logger.info(f"Fast Mode         : {args.fast}")

    tickers_to_fetch = [s + ".NS" for s in tickers]
    bench_close = None
    try:
        raw_bench = safe_download(["^NSEI"], period="5y", auto_adjust=True)
        if raw_bench is not None and not raw_bench.empty:
            bench_close = raw_bench["Close"].squeeze() if "Close" in raw_bench.columns else None
            if isinstance(bench_close, pd.DataFrame):
                bench_close = bench_close.iloc[:, 0]
            logger.info(f"Retrieved benchmark ^NSEI data across {len(bench_close)} bars.")
    except Exception as e:
        logger.warning(f"Could not retrieve benchmark data: {e}")

    chunk_size = 25
    all_close_dfs, all_volume_dfs, all_high_dfs, all_low_dfs = [], [], [], []

    for idx in range(0, len(tickers_to_fetch), chunk_size):
        chunk = tickers_to_fetch[idx : idx + chunk_size]
        logger.info(f"Downloading historical batch {idx // chunk_size + 1}/{(len(tickers_to_fetch) - 1) // chunk_size + 1} ({len(chunk)} tickers)...")
        try:
            raw = safe_download(chunk, period="5y", auto_adjust=True)
            if raw is not None and not raw.empty:
                if "Close" in raw.columns: all_close_dfs.append(raw["Close"])
                if "Volume" in raw.columns: all_volume_dfs.append(raw["Volume"])
                if "High" in raw.columns: all_high_dfs.append(raw["High"])
                if "Low" in raw.columns: all_low_dfs.append(raw["Low"])
        except Exception as e:
            logger.warning(f"Batch {idx // chunk_size + 1} encountered error: {e}")

    if not all_close_dfs:
        logger.error("❌ Failed to download market data.")
        sys.exit(1)

    close_df = pd.concat(all_close_dfs, axis=1)
    volume_df = pd.concat(all_volume_dfs, axis=1) if all_volume_dfs else None
    high_df = pd.concat(all_high_dfs, axis=1) if all_high_dfs else None
    low_df = pd.concat(all_low_dfs, axis=1) if all_low_dfs else None

    logger.info(f"Successfully retrieved price data for {close_df.shape[1]} equities across {len(close_df)} trading days.")

    X_list, y_list, tick_list, date_list = [], [], [], []
    stride = 10  # Sample every 10 trading days for rich temporal coverage

    for col in close_df.columns:
        c = close_df[col].dropna()
        if len(c) < 120:
            continue
        v = volume_df[col].dropna() if volume_df is not None and col in volume_df.columns else None
        h = high_df[col].dropna() if high_df is not None and col in high_df.columns else c
        l = low_df[col].dropna() if low_df is not None and col in low_df.columns else c

        c_arr = c.to_numpy(dtype=float)
        ret_arr = np.diff(c_arr) / (c_arr[:-1] + 1e-9)
        daily_vol = float(np.nanstd(ret_arr)) if len(ret_arr) > 10 else 0.015

        for i in range(60, len(c_arr) - args.horizon - 1, stride):
            sub_c = c.iloc[: i + 1]
            sub_v = v.iloc[: i + 1] if v is not None else None
            sub_h = h.iloc[: i + 1]
            sub_l = l.iloc[: i + 1]
            sub_b = bench_close.iloc[: i + 1] if bench_close is not None else None
            dt_as_of = c.index[i]

            sub_ohlcv = pd.DataFrame({
                "Open": sub_c,
                "High": sub_h,
                "Low": sub_l,
                "Close": sub_c,
                "Volume": sub_v if sub_v is not None else np.ones(len(sub_c)),
            }).dropna()

            feats = extract_prebreakout_features(sub_c, sub_v, sub_b, sub_ohlcv)
            if not feats:
                continue

            # Triple barrier labeling: +20% TP vs -5% SL in 15 days
            lbl = triple_barrier_label(
                c_arr,
                i,
                tp_pct=args.tp_pct,
                sl_pct=args.sl_pct,
                horizon=args.horizon,
                vol_scaled=True,
                daily_vol=daily_vol,
                k_up=2.0,
                k_dn=1.0,
            )

            if lbl is not None:
                X_list.append(feats)
                y_list.append(lbl)
                tick_list.append(col)
                date_list.append(dt_as_of)

    logger.info(f"Total Pre-Breakout Training Samples: {len(X_list)}")
    if len(X_list) < 50:
        logger.error("❌ Insufficient samples extracted.")
        sys.exit(1)

    X_df = pd.DataFrame(X_list, index=tick_list)
    y_ser = pd.Series(y_list, index=tick_list)

    model = PreBreakoutInceptionModel(feature_names=PREBREAKOUT_FACTOR_NAMES)
    model.fit(X_df, y_ser, dates=date_list, tickers=tick_list)
    out_path = model.save(MODEL_PATH)

    logger.info("=" * 80)
    logger.info(f"✅ PreBreakoutInceptionModel successfully trained and serialized to {out_path}")
    logger.info(f"   ROC-AUC Score        : {model.auc_score:.3f}")
    logger.info(f"   Out-Of-Sample Sharpe : {model.oos_sharpe:.2f}")
    logger.info(f"   Deflated Sharpe (DSR): {model.dsr:.2%}")
    logger.info(f"   Training Samples     : {model.n_samples} across {model.n_tickers} equities")
    logger.info("=" * 80)


if __name__ == "__main__":
    main()
