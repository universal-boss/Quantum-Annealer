"""Universe Feature Pipeline — 100+ Factor Cross-Sectional Alpha Engine.

Integrates:
  1. combined_universe.csv (792 stocks)
  2. ml_alpha/factors_100.py (91 base factors: momentum, reversal, volatility,
     volume, trend, mean-reversion, patterns, liquidity, higher moments)
  3. ml_alpha/alt_factors.py (12+ India-specific alternative data factors)
  4. Cross-sectional standardization (1%/99% winsorization + robust median/MAD z-score)
  5. Disk-based caching in Parquet FeatureStore with point-in-time integrity.
"""
from __future__ import annotations

import logging
from datetime import date, datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from ml_alpha.alt_factors import (
    accruals_quality_factor,
    bulk_block_footprint_factor,
    debt_to_equity_factor,
    delivery_conviction_factor,
    earnings_surprise_factor,
    fii_dii_flow_factor,
    pb_value_factor,
    pe_value_factor,
    pledge_distress_factor,
    revenue_growth_factor,
    roe_quality_factor,
    sector_momentum_factor,
    short_term_reversal_factor,
)
from ml_alpha.factors_100 import FACTORS_100, compute_cross_section_rank_zscore
from ml_alpha.feature_store import FeatureStore

logger = logging.getLogger(__name__)

UNIVERSE_CSV = Path(__file__).resolve().parent.parent / "combined_universe.csv"


def load_universe_tickers(universe_path: Optional[Path] = None) -> List[str]:
    """Load clean list of symbols from universe CSV."""
    path = universe_path or UNIVERSE_CSV
    if not path.exists():
        logger.warning(f"Universe file {path} not found; using fallback top 50")
        try:
            from data.universe import fetch_nifty50_tickers
            n50 = fetch_nifty50_tickers()
            if n50:
                return [f"{s}.NS" if not s.endswith((".NS", ".BO")) else s for s in n50]
        except Exception:
            pass
        return [
            "RELIANCE.NS", "TCS.NS", "HDFCBANK.NS", "BHARTIARTL.NS", "ICICIBANK.NS",
            "INFY.NS", "ITC.NS", "HINDUNILVR.NS", "LT.NS", "SBIN.NS",
            "BAJFINANCE.NS", "HCLTECH.NS", "KOTAKBANK.NS", "SUNPHARMA.NS", "M&M.NS",
            "MARUTI.NS", "TATAMOTORS.NS", "NTPC.NS", "ONGC.NS", "POWERGRID.NS",
            "TITAN.NS", "ADANIENT.NS", "AXISBANK.NS", "ULTRACEMCO.NS", "COALINDIA.NS",
            "ASIANPAINT.NS", "BAJAJFINSV.NS", "TATASTEEL.NS", "JSWSTEEL.NS", "WIPRO.NS",
            "NESTLEIND.NS", "SIEMENS.NS", "GRASIM.NS", "IOC.NS", "BEL.NS",
            "LTIM.NS", "VEDL.NS", "DLF.NS", "HINDALCO.NS", "INDUSINDBK.NS",
            "TECHM.NS", "ADANIPORTS.NS", "ZOMATO.NS", "PIDILITIND.NS", "DIVISLAB.NS",
            "EICHERMOT.NS", "CIPLA.NS", "BPCL.NS", "HEROMOTOCO.NS", "DRREDDY.NS"
        ]

    df = pd.read_csv(path)
    # Target 'symbol' or 'ticker' column
    sym_col = None
    for col in ("symbol", "ticker", "Symbol", "Ticker"):
        if col in df.columns:
            sym_col = col
            break
    if not sym_col:
        sym_col = df.columns[0]

    tickers = []
    for s in df[sym_col].dropna().astype(str):
        clean = s.strip().upper()
        if not clean:
            continue
        if not clean.endswith(".NS") and not clean.endswith(".BO") and ":" not in clean:
            clean = f"{clean}.NS"
        tickers.append(clean)
    return sorted(list(set(tickers)))


def winsorize_and_standardize_cross_section(
    panel: pd.DataFrame,
    lower_pct: float = 0.01,
    upper_pct: float = 0.99,
) -> pd.DataFrame:
    """Standardize factor panel cross-sectionally per date using robust statistics.

    Args:
        panel: DataFrame[date x ticker] containing raw factor values.
        lower_pct: Lower percentile clip limit (1%).
        upper_pct: Upper percentile clip limit (99%).

    Returns:
        DataFrame[date x ticker] standardized per row (date).
    """
    if panel.empty:
        return panel

    def _standardize_row(row: pd.Series) -> pd.Series:
        valid = row.dropna()
        if len(valid) < 3:
            return row * 0.0

        # Winsorize extremes to prevent single-stock outlier distortion
        lo = valid.quantile(lower_pct)
        hi = valid.quantile(upper_pct)
        clipped = valid.clip(lo, hi)

        # Robust Z-score using Median and Median Absolute Deviation (MAD)
        med = clipped.median()
        mad = (clipped - med).abs().median()
        scale = 1.4826 * mad  # Consistency estimator for normal distribution
        if scale < 1e-8:
            std = clipped.std()
            scale = std if std > 1e-8 else 1.0

        z = (clipped - med) / scale
        res = row.copy()
        res.loc[z.index] = z.clip(-3.5, 3.5)
        return res

    return panel.apply(_standardize_row, axis=1)


def load_sector_map() -> Dict[str, str]:
    """Load canonical ticker -> sector mapping from sector_cache.json or sebi_cap_categories.csv."""
    import json
    sector_map: Dict[str, str] = {}
    cache_path = Path.home() / ".quantum_annealer_pro_v17" / "sector_cache.json"
    if cache_path.exists():
        try:
            with open(cache_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                for k, v in data.items():
                    clean_k = str(k).strip().upper()
                    sector_map[clean_k] = str(v)
                    if not clean_k.endswith(".NS") and not clean_k.endswith(".BO"):
                        sector_map[f"{clean_k}.NS"] = str(v)
                    elif clean_k.endswith(".NS"):
                        sector_map[clean_k[:-3]] = str(v)
        except Exception as e:
            logger.debug(f"Failed loading sector_cache.json: {e}")

    sebi_path = Path(__file__).resolve().parent.parent / "data" / "sebi_cap_categories.csv"
    if sebi_path.exists():
        try:
            df = pd.read_csv(sebi_path)
            for _, row in df.iterrows():
                t = str(row.get("ticker", "") or row.get("symbol", "")).strip().upper()
                sec = str(row.get("sector", "") or row.get("industry", "")).strip()
                if t and sec and t not in sector_map:
                    sector_map[t] = sec
                    if not t.endswith(".NS"):
                        sector_map[f"{t}.NS"] = sec
                    else:
                        sector_map[t[:-3]] = sec
        except Exception as e:
            logger.debug(f"Failed loading sebi_cap_categories.csv: {e}")

    return sector_map


def sector_neutralize_panel(
    panel: pd.DataFrame,
    sector_map: Optional[Dict[str, str]] = None,
) -> pd.DataFrame:
    """Neutralize factor panel cross-sectionally by de-meaning within each sector per date.

    Guarantees the factor represents pure stock-specific alpha within the sector
    rather than systematic sector allocation.
    """
    if panel.empty:
        return panel

    s_map = sector_map or load_sector_map()
    if not s_map:
        return panel

    def _neutralize_row(row: pd.Series) -> pd.Series:
        valid = row.dropna()
        if len(valid) < 3:
            return row

        sectors = pd.Series([s_map.get(t, s_map.get(t.replace(".NS", ""), "Other")) for t in valid.index], index=valid.index)
        grp_means = valid.groupby(sectors).transform("mean")
        neutralized = valid - grp_means
        res = row.copy()
        res.loc[neutralized.index] = neutralized
        return res

    return panel.apply(_neutralize_row, axis=1)


def evaluate_turnover_and_costs(
    predictions: pd.DataFrame,
    returns: pd.DataFrame,
    holding_days: int = 10,
    cost_bps: float = 15.0,
) -> Dict[str, float]:
    """Evaluate Long-Short top vs bottom quintile strategy with realistic transaction costs.

    Calculates:
      - Annualized net return
      - Annualized net volatility
      - Net Sharpe ratio after 15 bps Indian statutory costs
      - Annualized portfolio turnover
    """
    if predictions.empty or returns.empty:
        return {}

    common_dates = sorted(list(predictions.index.intersection(returns.index)))
    if len(common_dates) < 5:
        return {}

    p_df = predictions.loc[common_dates]
    r_df = returns.loc[common_dates]

    daily_net_rets = []
    prev_long_weights = None
    prev_short_weights = None
    turnover_list = []

    for dt in common_dates:
        scores = p_df.loc[dt].dropna()
        rets = r_df.loc[dt].reindex(scores.index).dropna()
        if len(scores) < 10 or len(rets) < 10:
            continue

        valid_tickers = scores.index.intersection(rets.index)
        s = scores.loc[valid_tickers]
        r = rets.loc[valid_tickers]

        q_hi = s.quantile(0.80)
        q_lo = s.quantile(0.20)

        long_names = s[s >= q_hi].index
        short_names = s[s <= q_lo].index

        if len(long_names) == 0 or len(short_names) == 0:
            continue

        curr_long_w = pd.Series(1.0 / len(long_names), index=long_names)
        curr_short_w = pd.Series(-1.0 / len(short_names), index=short_names)

        if prev_long_weights is not None:
            all_w_idx = curr_long_w.index.union(prev_long_weights.index)
            w_diff = (curr_long_w.reindex(all_w_idx).fillna(0.0) - prev_long_weights.reindex(all_w_idx).fillna(0.0)).abs().sum() / 2.0
            turnover_list.append(w_diff)
        prev_long_weights = curr_long_w
        prev_short_weights = curr_short_w

        gross_long = r.loc[long_names].mean()
        gross_short = r.loc[short_names].mean()
        gross_ret = (gross_long - gross_short) / 2.0

        to_pen = (turnover_list[-1] if turnover_list else 0.2) * (cost_bps / 10000.0)
        net_ret = gross_ret - to_pen
        daily_net_rets.append(net_ret)

    if not daily_net_rets:
        return {}

    annual_factor = 252.0 / max(1, holding_days)
    mean_ret = float(np.mean(daily_net_rets)) * annual_factor
    vol = float(np.std(daily_net_rets)) * np.sqrt(annual_factor) + 1e-9
    sharpe = mean_ret / vol
    ann_turnover = float(np.mean(turnover_list)) * annual_factor if turnover_list else 0.0

    return {
        "annualized_net_return": mean_ret,
        "annualized_net_volatility": vol,
        "net_sharpe_ratio": sharpe,
        "annualized_turnover": ann_turnover,
        "cost_bps_applied": cost_bps,
    }


class UniverseFeaturePipeline:
    """Builds, standardizes, and caches 100+ factors across the universe."""

    def __init__(
        self,
        universe_path: Optional[Path] = None,
        feature_store: Optional[FeatureStore] = None,
    ):
        self.universe_path = universe_path or UNIVERSE_CSV
        self.feature_store = feature_store or FeatureStore()
        self.tickers = load_universe_tickers(self.universe_path)

    def extract_technical_factors(
        self,
        prices: Dict[str, pd.DataFrame],
        sector_neutralize: bool = False,
        sector_map: Optional[Dict[str, str]] = None,
    ) -> Dict[str, pd.DataFrame]:
        """Compute all 91 technical factors from FACTORS_100 across available tickers.

        Args:
            prices: Dict of ticker -> DataFrame with columns ['open', 'high', 'low', 'close', 'volume'].
            sector_neutralize: If True, subtract sector mean per date.
            sector_map: Optional ticker -> sector mapping.

        Returns:
            Dict of factor_name -> DataFrame[date x ticker].
        """
        if not prices:
            return {}

        # Align close, high, low, open, volume panels
        dates = None
        for t, df in prices.items():
            if dates is None:
                dates = df.index
            else:
                dates = dates.union(df.index)
        dates = sorted(dates)

        panels: Dict[str, pd.DataFrame] = {}
        close_panel = pd.DataFrame(index=dates)
        high_panel = pd.DataFrame(index=dates)
        low_panel = pd.DataFrame(index=dates)
        open_panel = pd.DataFrame(index=dates)
        volume_panel = pd.DataFrame(index=dates)

        for ticker, df in prices.items():
            if df.empty:
                continue
            if "close" in df:
                close_panel[ticker] = df["close"]
            if "high" in df:
                high_panel[ticker] = df["high"]
            if "low" in df:
                low_panel[ticker] = df["low"]
            if "open" in df:
                open_panel[ticker] = df["open"]
            if "volume" in df:
                volume_panel[ticker] = df["volume"]

        logger.info(f"[UniversePipeline] Extracted price panels for {len(close_panel.columns)} tickers across {len(dates)} dates")

        # Compute each of the 91 factors
        for fname, func in FACTORS_100.items():
            try:
                import inspect
                sig = inspect.signature(func)
                params = list(sig.parameters.keys())
                if len(params) == 1:
                    raw = func(close_panel)
                elif "volume" in params:
                    raw = func(close_panel, volume_panel)
                elif "high" in params and "low" in params:
                    raw = func(high_panel, low_panel, close_panel)
                else:
                    raw = func(close_panel)

                if isinstance(raw, pd.DataFrame) and not raw.empty:
                    # Standardize cross-sectionally per date
                    std_panel = winsorize_and_standardize_cross_section(raw)
                    if sector_neutralize:
                        std_panel = sector_neutralize_panel(std_panel, sector_map=sector_map)
                    panels[fname] = std_panel
            except Exception as e:
                logger.debug(f"[UniversePipeline] Skipping factor {fname}: {e}")

        logger.info(f"[UniversePipeline] Successfully built {len(panels)} standardized factor panels (sector_neutralize={sector_neutralize})")
        return panels

    def extract_pit_fundamental_factors(
        self,
        tickers: List[str],
        dates: List[Any],
        sector_neutralize: bool = False,
        sector_map: Optional[Dict[str, str]] = None,
    ) -> Dict[str, pd.DataFrame]:
        """Extract standardized and sector-neutralized PIT audited fundamental panels."""
        try:
            from data.fundamentals_pit_fetcher import PITFundamentalsFetcher
            fetcher = PITFundamentalsFetcher()
            raw_panels = fetcher.get_pit_panels(tickers, dates)
            processed_panels = {}
            for fname, panel in raw_panels.items():
                std_panel = winsorize_and_standardize_cross_section(panel)
                if sector_neutralize:
                    std_panel = sector_neutralize_panel(std_panel, sector_map=sector_map)
                processed_panels[fname] = std_panel
            logger.info(f"[UniversePipeline] Successfully built {len(processed_panels)} PIT fundamental factor panels (sector_neutralize={sector_neutralize})")
            return processed_panels
        except Exception as e:
            logger.warning(f"[UniversePipeline] Error extracting PIT fundamental factors: {e}")
            return {}

    def save_to_feature_store(
        self,
        panels: Dict[str, pd.DataFrame],
        version: str = "v1",
    ) -> int:
        """Persist computed factor panels into the FeatureStore."""
        saved_count = 0
        for fname, df in panels.items():
            if df is not None and not df.empty:
                if self.feature_store.save(fname, df, version=version):
                    saved_count += 1
        logger.info(f"[UniversePipeline] Persisted {saved_count} factors into FeatureStore")
        return saved_count

    def build_training_dataset(
        self,
        prices: Dict[str, pd.DataFrame],
        panels: Dict[str, pd.DataFrame],
        forward_days: int = 10,
        rebalance_step: int = 5,
        method: str = "forward_return",
    ) -> pd.DataFrame:
        """Construct pooled (date, ticker) cross-sectional training DataFrame with forward returns.

        Args:
            prices: Dict[ticker -> DataFrame(index=date, columns=[close, ...])]
            panels: Dict[factor_name -> DataFrame(index=date, columns=tickers)]
            forward_days: Target prediction horizon in business days.
            rebalance_step: Sample every N days to control autocorrelation.
            method: 'forward_return' or 'triple_barrier'

        Returns:
            DataFrame with MultiIndex (date, ticker), feature columns, and 'forward_return'.
        """
        if not prices or not panels:
            return pd.DataFrame()

        # Build close price panel
        all_dates = sorted(list(panels[list(panels.keys())[0]].index))
        all_tickers = sorted(list(panels[list(panels.keys())[0]].columns))

        close_panel = pd.DataFrame(index=all_dates)
        for t in all_tickers:
            if t in prices and "close" in prices[t]:
                close_panel[t] = prices[t]["close"].reindex(all_dates)

        # Forward return: (Close_{t+H} / Close_t) - 1.0
        fwd_ret = close_panel.shift(-forward_days) / close_panel - 1.0

        # Optional triple-barrier labeling
        tb_df = None
        if method == "triple_barrier":
            try:
                from ml_alpha.labeling import compute_daily_volatility, triple_barrier_labels
                daily_vol = compute_daily_volatility(close_panel)
                tb_res = triple_barrier_labels(
                    close_panel,
                    daily_vol,
                    upper_mult=2.0,
                    lower_mult=1.0,
                    max_holding_days=forward_days,
                )
                tb_df = tb_res[0] if isinstance(tb_res, tuple) else tb_res
            except Exception as e:
                logger.debug(f"[UniversePipeline] Triple barrier fallback: {e}")
                tb_df = None

        # Cross-sectional market-neutral rank label per date
        fwd_label = fwd_ret.apply(lambda row: (row.rank(pct=True) - 0.5) if row.dropna().count() >= 5 else (row * np.nan), axis=1)

        # Sample dates every rebalance_step to prevent severe label overlap
        sample_dates = all_dates[:-forward_days:rebalance_step]
        if not sample_dates:
            sample_dates = all_dates[:-forward_days]

        rows = []
        feature_names = sorted(list(panels.keys()))

        for dt in sample_dates:
            if dt not in fwd_label.index:
                continue
            lbls = fwd_label.loc[dt].dropna()
            if len(lbls) < 5:
                continue

            # Assemble features for all valid tickers on this date
            dt_features = {}
            for fname in feature_names:
                p = panels[fname]
                if dt in p.index:
                    dt_features[fname] = p.loc[dt]

            df_dt = pd.DataFrame(dt_features)
            df_dt["forward_return"] = lbls
            if tb_df is not None and dt in tb_df.index:
                df_dt["tb_label"] = tb_df.loc[dt].reindex(df_dt.index).fillna(0.0)
            df_dt = df_dt.dropna(subset=["forward_return"])
            df_dt["date"] = dt
            df_dt["ticker"] = df_dt.index
            rows.append(df_dt)

        if not rows:
            return pd.DataFrame()

        df_train = pd.concat(rows, ignore_index=True)
        df_train = df_train.set_index(["date", "ticker"]).sort_index()
        # Fill missing features with 0.0 (neutral z-score)
        feat_cols = [c for c in df_train.columns if c not in ("forward_return", "tb_label", "target", "label")]
        df_train[feat_cols] = df_train[feat_cols].fillna(0.0).clip(-3.5, 3.5)

        logger.info(f"[UniversePipeline] Built dataset: {len(df_train)} rows across {len(sample_dates)} dates and {len(feat_cols)} features")
        return df_train

    @staticmethod
    def select_top_ic_factors(
        df_train: pd.DataFrame,
        max_factors: int = 35,
        min_abs_ic: float = 0.010,
    ) -> Tuple[List[str], Dict[str, Dict[str, float]]]:
        """Compute Information Coefficient (IC) per factor and select top-performing alpha factors.

        Evaluates cross-sectional Spearman rank correlation per date to prevent cross-temporal bias.
        """
        if df_train.empty or "forward_return" not in df_train.columns:
            return [], {}

        feature_cols = [c for c in df_train.columns if c not in ("forward_return", "tb_label", "target", "label")]
        dates = df_train.index.get_level_values("date").unique()
        ic_records: Dict[str, List[float]] = {col: [] for col in feature_cols}

        for dt in dates:
            sub = df_train.xs(dt, level="date")
            if len(sub) < 5:
                continue
            y = sub["forward_return"]
            for col in feature_cols:
                x = sub[col]
                # Rank correlation (Spearman)
                if x.std() > 1e-6 and y.std() > 1e-6:
                    corr = float(x.corr(y, method="spearman"))
                    if np.isfinite(corr):
                        ic_records[col].append(corr)

        ic_stats: Dict[str, Dict[str, float]] = {}
        for col, ics in ic_records.items():
            if len(ics) >= 5:
                m_ic = float(np.mean(ics))
                s_ic = float(np.std(ics)) + 1e-9
                ir = m_ic / s_ic
                t_stat = m_ic / (s_ic / np.sqrt(len(ics)))
                ic_stats[col] = {
                    "mean_ic": m_ic,
                    "std_ic": s_ic,
                    "ir": ir,
                    "t_stat": t_stat,
                    "n_dates": len(ics),
                }

        # Filter and rank by absolute mean IC
        qualifying = [
            col for col, s in ic_stats.items()
            if abs(s["mean_ic"]) >= min_abs_ic
        ]
        qualifying.sort(key=lambda col: abs(ic_stats[col]["mean_ic"]), reverse=True)
        selected = qualifying[:max_factors]

        if not selected:
            # Fallback to top factors regardless of threshold
            all_sorted = sorted(ic_stats.keys(), key=lambda col: abs(ic_stats[col]["mean_ic"]), reverse=True)
            selected = all_sorted[:min(max_factors, len(all_sorted))]

        logger.info(f"[UniversePipeline] Evaluated {len(feature_cols)} factors: {len(selected)} selected for production ensemble")
        return selected, ic_stats
