"""ml_alpha/walkforward_replay_scores.py — per-cutoff point-in-time ML scores.

AUDIT-FIX (Round 29 — R29-3): the SWEEP residual "per-cutoff ML predictions"
(INPUT-GATED, standing since R25 §4) is closed at the machinery level. The
R27-1 replay already replays the ML-alpha injection when the caller supplies
``ml_alpha_by_cutoff`` + ``ml_dsr_by_cutoff`` — but the live sweep could never
supply them: the final model's scores are NOT point-in-time (the model was
trained on data after the historical cutoffs). This module is the missing
walk-forward RETRAINING driver:

  at each cutoff t (a date on the replay frame):
    * slice the frame to strictly trailing rows (index <= t);
    * compute the CORE factor set on the trailing slice only
      (ml_alpha.factors.compute_all_factors — backward-looking functions, so
      the slice is point-in-time-safe by construction);
    * preprocess with the PRODUCTION cross-sectional winsorize + z-score
      (ml_alpha.factors.preprocess_factors);
    * build training rows on a rebalance grid with PURGE (label window must
      not cross the cutoff: s + forward + embargo <= t) — the López de Prado
      leakage hygiene the production engine applies;
    * refit the PRODUCTION AlphaEnsemble (ridge path) on those rows;
    * predict at t (features at the cutoff row, cross-sectionally
      standardized exactly like AlphaEngine.predict);
    * compute a per-cutoff DSR with the PRODUCTION deflation formula
      (ml_alpha.metrics.deflated_sharpe_ratio, R8-H7 overlap-adjusted sample
      length, R13-ML-5 trial count, degenerate-stat guards).

FIDELITY DISCLOSURE (carried in the returned provenance and disclosed per
run): this is a core-factor ridge refit. The production engine's per-cutoff
exclusions — triple-barrier labeling, collinearity/IC feature selection,
Optuna tuning, CPCV, TFT blend, and the alt-data factors (delivery %, FII/
DII, bulk/block, pledge, fundamentals — NSE sources are 403-blocked and
now-only from this environment) — are NOT replayed per cutoff. The scores
are honest point-in-time predictions of a SIMPLER model than the live one,
which is exactly what the replay's method_disclosure is for.

Runtime×K: one refit per cutoff — opt-in from the sweep via
``WFO_ML_REPLAY_RETRAIN`` (default False; the disclosed-not-replayed steady
state is unchanged otherwise).
"""
from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from .factors import compute_all_factors, preprocess_factors
from .model import AlphaEnsemble
from .metrics import deflated_sharpe_ratio

_MIN_LS_DATES_FOR_DSR = 15       # too few L-S dates -> DSR None (injection refused)
_MIN_TRAIN_ROWS = 200            # mirrors the engine's minimum training size
_QUANTILE = 0.2                  # top/bottom quintile for the L-S spread
_DEFAULT_MODEL_TYPE = "ridge"    # the production AlphaEnsemble default path


def _cfg_float(cfg: Dict[str, Any], key: str, default: float) -> float:
    try:
        v = float((cfg or {}).get(key, default))
        return v if np.isfinite(v) and v > 0 else float(default)
    except (TypeError, ValueError):
        return float(default)


def _cfg_int(cfg: Dict[str, Any], key: str, default: int) -> int:
    try:
        return max(1, int((cfg or {}).get(key, default)))
    except (TypeError, ValueError):
        return int(default)


def _benchmark_level_series(benchmark_returns: Optional[pd.Series],
                            index: pd.DatetimeIndex) -> Optional[pd.Series]:
    """Benchmark CLOSE level for the beta factor, rebuilt from the sweep's
    benchmark RETURN series (compounded — a level series up to scaling, which
    is all beta_1y needs). Returns None when no benchmark was supplied."""
    if benchmark_returns is None or len(benchmark_returns) == 0:
        return None
    try:
        r = benchmark_returns.reindex(index).fillna(0.0).astype(float)
        if not np.isfinite(r.to_numpy()).all():
            r = r.replace([np.inf, -np.inf], 0.0)
        lvl = (1.0 + r).cumprod()
        return lvl
    except Exception:
        return None


def _training_rows(
    processed: Dict[str, pd.DataFrame],
    close: pd.DataFrame,
    grid_positions: Sequence[int],
    forward_days: int,
    feature_names: List[str],
) -> pd.DataFrame:
    """Build the (date, ticker) × factor training frame with forward-return
    labels on the rebalance grid. PURGE is enforced by the caller (grid
    positions already satisfy s + forward + embargo <= cutoff)."""
    idx = close.index
    records: List[Tuple[pd.Timestamp, str, List[float], float]] = []
    for gp in grid_positions:
        if gp + forward_days >= len(idx):
            continue  # belt-and-braces: label window must close inside the slice
        s = idx[gp]
        fwd = close.iloc[gp + forward_days] / close.iloc[gp] - 1.0
        for t in close.columns:
            try:
                y = float(fwd.get(t, np.nan))
            except (TypeError, ValueError):
                continue
            if not np.isfinite(y):
                continue
            fv: List[float] = []
            has = False
            for f in feature_names:
                panel = processed.get(f)
                v = np.nan
                if panel is not None and t in panel.columns and s in panel.index:
                    try:
                        v = float(panel.at[s, t])
                    except (TypeError, ValueError):
                        v = np.nan
                if np.isfinite(v):
                    has = True
                fv.append(v)
            if has:
                records.append((s, str(t), fv, y))
    if not records:
        return pd.DataFrame()
    mi = pd.MultiIndex.from_tuples([(r[0], r[1]) for r in records],
                                    names=["date", "ticker"])
    X = pd.DataFrame(np.array([r[2] for r in records], dtype=float),
                     index=mi, columns=feature_names)
    df = X.copy()
    df["forward_return"] = np.array([r[3] for r in records], dtype=float)
    return df


def compute_ml_scores_by_cutoff(
    close_df: pd.DataFrame,
    volume_df: Optional[pd.DataFrame] = None,
    cutoff_dates: Optional[Sequence[Any]] = None,
    benchmark_returns: Optional[pd.Series] = None,
    high_df: Optional[pd.DataFrame] = None,
    low_df: Optional[pd.DataFrame] = None,
    cfg: Optional[Dict[str, Any]] = None,
    log_cb: Optional[Callable[[str], None]] = None,
) -> Tuple[Dict[str, Dict[str, float]], Dict[str, Optional[float]], Dict[str, Any]]:
    """Walk-forward per-cutoff ML retraining — see the module docstring.

    Returns (ml_alpha_by_cutoff, ml_dsr_by_cutoff, provenance) in EXACTLY the
    shapes the R27-1 replay consumes: {str(cutoff_date): {ticker: score}} and
    {str(cutoff_date): dsr_or_None}. DSR None -> the replay's Phase-9 gate
    REFUSES the injection at that cutoff (production honest-None semantics).
    """
    cfg = cfg or {}

    def _log(msg: str) -> None:
        if log_cb:
            try:
                log_cb(msg)
            except Exception:
                pass

    if close_df is None or close_df.empty or not cutoff_dates:
        return {}, {}, {"error": "no frame or no cutoffs", "cutoffs_supplied": 0}

    model_type = str(cfg.get("ML_REPLAY_MODEL_TYPE", _DEFAULT_MODEL_TYPE) or _DEFAULT_MODEL_TYPE)
    forward_days = _cfg_int(cfg, "ML_REPLAY_FORWARD_DAYS", 10)
    rebalance_freq = _cfg_int(cfg, "ML_REPLAY_REBALANCE_FREQ", 5)
    embargo_days = _cfg_int(cfg, "ML_REPLAY_EMBARGO_DAYS", 5)
    n_cv_folds = max(1, _cfg_int(cfg, "ML_REPLAY_CV_FOLDS", 3))

    idx = pd.DatetimeIndex(close_df.index)
    tickers = [c for c in close_df.columns]

    ml_alpha_by_cutoff: Dict[str, Dict[str, float]] = {}
    ml_dsr_by_cutoff: Dict[str, Optional[float]] = {}
    per_cutoff: Dict[str, Dict[str, Any]] = {}

    for cd in cutoff_dates:
        ts = pd.Timestamp(cd)
        # locate the cutoff on the frame (nearest position at-or-before)
        pos = int(idx.searchsorted(ts, side="right") - 1)
        if pos < 0 or idx[pos] != ts:
            per_cutoff[str(ts.date())] = {"skipped": "cutoff date not on frame index"}
            continue
        cutoff_key = str(ts.date())

        # ---- strictly trailing slice (point-in-time by construction) ----
        p = pos
        close = close_df.iloc[:p + 1]
        volume = (volume_df.iloc[:p + 1] if volume_df is not None and not volume_df.empty else None)
        high = (high_df.iloc[:p + 1] if high_df is not None and not high_df.empty else None)
        low = (low_df.iloc[:p + 1] if low_df is not None and not low_df.empty else None)

        # ---- factors + production preprocessing on the trailing slice ----
        panel: Dict[str, pd.DataFrame] = {"Close": close}
        if volume is not None:
            panel["Volume"] = volume
        if high is not None:
            panel["High"] = high
        if low is not None:
            panel["Low"] = low
        bench = _benchmark_level_series(benchmark_returns, close.index)
        try:
            factors = compute_all_factors(panel, tickers, bench)
        except Exception as e:
            per_cutoff[cutoff_key] = {"skipped": f"factor computation failed: {e}"}
            continue
        if not factors:
            per_cutoff[cutoff_key] = {"skipped": "no factors computed on the trailing slice"}
            continue
        processed = preprocess_factors(factors)
        feature_names = [f for f in processed.keys()]

        # ---- rebalance grid with PURGE + EMBARGO ----
        # valid grid positions: s + forward + embargo <= p (label window and
        # an embargo buffer must both close strictly before the cutoff)
        last_valid = p - forward_days - embargo_days
        grid = list(range(0, max(0, last_valid) + 1, rebalance_freq))
        if len(grid) < 2:
            per_cutoff[cutoff_key] = {"skipped": "insufficient pre-cutoff history for the rebalance grid"}
            continue

        df = _training_rows(processed, close, grid, forward_days, feature_names)
        if df is None or df.empty or len(df) < _MIN_TRAIN_ROWS:
            per_cutoff[cutoff_key] = {
                "skipped": f"training rows below minimum ({0 if df is None or df.empty else len(df)} < {_MIN_TRAIN_ROWS})"}
            continue
        y = df["forward_return"]
        X = df.drop(columns=["forward_return"])

        # ---- per-cutoff DSR from an internal sequential CV (trailing only) ----
        dsr: Optional[float] = None
        try:
            dsr, dsr_detail = _per_cutoff_dsr(
                X, y, idx, grid, forward_days, rebalance_freq,
                n_cv_folds, len(feature_names))
        except Exception as e:
            dsr, dsr_detail = None, {"error": str(e)}
        if dsr is not None and not np.isfinite(float(dsr)):
            dsr = 0.0  # production guard: NaN/inf DSR must refuse, not inflate

        # ---- refit on ALL purified trailing rows + predict at the cutoff ----
        ens = AlphaEnsemble(model_type=model_type)
        try:
            ens.fit(X, y)
        except Exception as e:
            per_cutoff[cutoff_key] = {"skipped": f"ensemble fit failed: {e}"}
            continue
        X_pred = _predict_matrix(processed, feature_names, close.index, p, tickers)
        if X_pred is None or X_pred.empty:
            per_cutoff[cutoff_key] = {"skipped": "no ticker has feature data at the cutoff row"}
            continue
        try:
            preds = ens.predict(X_pred)
        except Exception as e:
            per_cutoff[cutoff_key] = {"skipped": f"ensemble predict failed: {e}"}
            continue

        scores: Dict[str, float] = {}
        for t, v in preds.items():
            try:
                fv = float(v)
            except (TypeError, ValueError):
                continue
            if np.isfinite(fv):
                scores[str(t)] = fv
        if not scores:
            per_cutoff[cutoff_key] = {"skipped": "no finite predictions at the cutoff"}
            continue

        ml_alpha_by_cutoff[cutoff_key] = scores
        ml_dsr_by_cutoff[cutoff_key] = (None if dsr is None else float(dsr))
        # R29-4: ALSO register the str(Timestamp) key form ("2025-03-12
        # 00:00:00") — the R27 replay contract's native convention — so the
        # dicts drop into either lookup convention without caller massaging.
        ml_alpha_by_cutoff[str(ts)] = dict(scores)
        ml_dsr_by_cutoff[str(ts)] = ml_dsr_by_cutoff[cutoff_key]
        per_cutoff[cutoff_key] = {
            "n_train_rows": int(len(df)),
            "n_grid_dates": int(len(grid)),
            "n_features": int(len(feature_names)),
            "n_scored": int(len(scores)),
            "dsr": (None if dsr is None else round(float(dsr), 6)),
            "dsr_detail": dsr_detail,
            "model_type": model_type,
            "forward_days": int(forward_days),
            "rebalance_freq": int(rebalance_freq),
            "embargo_days": int(embargo_days),
        }
        _log(f"[WFO-ML] {cutoff_key}: refit {len(df)} rows x {len(feature_names)} factors "
             f"-> {len(scores)} scores; DSR={ml_dsr_by_cutoff[cutoff_key]}")

    provenance: Dict[str, Any] = {
        "source": ("walk-forward per-cutoff AlphaEnsemble refit (production ridge path, "
                   "core factor set, production preprocess_factors, purge+embargo, "
                   "per-cutoff DSR via ml_alpha.metrics.deflated_sharpe_ratio)"),
        "fidelity_note": ("core price/volume factors only — the production engine's "
                          "alt-data factors (delivery/FII-DII/bulk/pledge/fundamentals), "
                          "triple-barrier labeling, collinearity/IC feature selection, "
                          "Optuna tuning, CPCV and the TFT blend are NOT replayed per "
                          "cutoff; the scores are point-in-time predictions of a SIMPLER "
                          "model — disclosed per run via the replay method_disclosure"),
        "model_type": model_type,
        "forward_days": int(forward_days),
        "rebalance_freq": int(rebalance_freq),
        "embargo_days": int(embargo_days),
        "purge_rule": "s + forward_days + embargo_days <= cutoff",
        "n_cutoffs_supplied": int(len(list(cutoff_dates or []))),
        "n_cutoffs_scored": int(len(ml_alpha_by_cutoff)),
        "per_cutoff": per_cutoff,
    }
    return ml_alpha_by_cutoff, ml_dsr_by_cutoff, provenance


# ----------------------------------------------------------------------------
# internals
# ----------------------------------------------------------------------------
def _predict_matrix(
    processed: Dict[str, pd.DataFrame],
    feature_names: List[str],
    index: pd.DatetimeIndex,
    p: int,
    tickers: List[str],
) -> Optional[pd.DataFrame]:
    """Ticker × factor matrix at the cutoff row, cross-sectionally standardized
    exactly like AlphaEngine.predict (plain mean/std z per column)."""
    s = index[p]
    cols: Dict[str, List[float]] = {}
    for t in tickers:
        row: List[float] = []
        has = False
        for f in feature_names:
            panel = processed.get(f)
            v = np.nan
            if panel is not None and t in panel.columns and s in panel.index:
                v = float(panel.at[s, t])
            row.append(v)
            if np.isfinite(v):
                has = True
        if has:
            cols[str(t)] = row
    if not cols:
        return None
    X = pd.DataFrame(cols, index=feature_names).T
    try:
        for c in X.columns:
            _std = float(X[c].std())
            if _std > 1e-9:
                X[c] = (X[c] - float(X[c].mean())) / _std
            else:
                X[c] = 0.0
    except Exception:
        pass
    return X


def _per_cutoff_dsr(
    X: pd.DataFrame,
    y: pd.Series,
    idx: pd.DatetimeIndex,
    grid: Sequence[int],
    forward_days: int,
    rebalance_freq: int,
    n_cv_folds: int,
    n_features: int,
) -> Tuple[Optional[float], Dict[str, Any]]:
    """Per-cutoff DSR from an internal SEQUENTIAL CV on the purified trailing
    rows: per fold, refit on earlier folds, predict the fold, build the
    per-date top-minus-bottom-quintile forward-return spread, then deflate the
    annualized L-S Sharpe with the PRODUCTION formula (R8-H7 effective sample
    size, R13-ML-5 trial count, degenerate-stat guards)."""
    dates = X.index.get_level_values(0)
    unique_dates = sorted(set(dates))
    if len(unique_dates) < _MIN_LS_DATES_FOR_DSR:
        return None, {"reason": f"fewer than {_MIN_LS_DATES_FOR_DSR} L-S dates — DSR not measured"}

    fold_bounds = np.array_split(np.arange(len(unique_dates)), max(1, n_cv_folds))
    ls_rows: List[Tuple[pd.Timestamp, float]] = []
    for fold in fold_bounds:
        if len(fold) == 0:
            continue
        fold_dates = {unique_dates[i] for i in fold}
        train_mask = np.array([d not in fold_dates for d in dates])
        test_mask = ~train_mask
        if train_mask.sum() < 50 or test_mask.sum() < 10:
            continue
        try:
            ens = AlphaEnsemble(model_type=_DEFAULT_MODEL_TYPE)
            ens.fit(X.loc[train_mask], y.loc[train_mask])
            preds = ens.predict(X.loc[test_mask])
        except Exception:
            continue
        df_test = X.loc[test_mask]
        for d, grp in df_test.groupby(level=0):
            tickers_fold = list(grp.index.get_level_values(1))
            pv = pd.Series({t: float(preds.loc[(d, t)]) if (d, t) in preds.index else np.nan
                            for t in tickers_fold}).dropna()
            if len(pv) < 10:
                continue
            yv = pd.Series({t: float(y.loc[(d, t)]) for t in pv.index if (d, t) in y.index}).reindex(pv.index)
            valid = yv.dropna()
            if len(valid) < 10:
                continue
            pv = pv.reindex(valid.index)
            q_hi = pv.quantile(1.0 - _QUANTILE)
            q_lo = pv.quantile(_QUANTILE)
            top = yv[pv >= q_hi]
            bot = yv[pv <= q_lo]
            if len(top) == 0 or len(bot) == 0:
                continue
            ls_rows.append((d, float(top.mean() - bot.mean())))

    if len(ls_rows) < _MIN_LS_DATES_FOR_DSR:
        return None, {"reason": f"insufficient L-S observations ({len(ls_rows)}) — DSR not measured"}

    ls = pd.Series({d: v for d, v in ls_rows}).sort_index()
    per_obs_sr = float(ls.mean() / ls.std()) if float(ls.std()) > 1e-12 else 0.0
    observed_sharpe_ann = per_obs_sr * float(np.sqrt(252.0 / max(1, forward_days)))

    # R8-H7: overlap-adjusted effective n (h-day labels sampled every r days)
    overlap_factor = max(1.0, float(forward_days) / max(1, int(rebalance_freq)))
    sample_length = max(10, int(len(ls) / overlap_factor))

    # degenerate-stat guards (production engine block)
    skew, kurt = 0.0, 3.0
    if len(ls) > 10 and float(ls.std()) > 1e-9:
        _sk = float(ls.skew())
        _kt = float(ls.kurtosis()) + 3.0
        skew = float(np.clip(_sk if np.isfinite(_sk) else 0.0, -1.5, 1.5))
        kurt = float(np.clip(_kt if np.isfinite(_kt) else 3.0, 2.5, 8.0))

    # R13-ML-5 production trial count (no-Optuna branch): 1 + feature screen + 6
    n_trials = 1 + max(0, int(n_features)) + 6
    dsr = deflated_sharpe_ratio(
        observed_sharpe=observed_sharpe_ann,
        n_trials=n_trials,
        sample_length=sample_length,
        skewness=skew,
        kurtosis=kurt,
        holding_days=forward_days,
    )
    if dsr is None or not np.isfinite(float(dsr)):
        dsr = 0.0
    detail = {
        "n_ls_dates": int(len(ls)),
        "ls_mean": float(ls.mean()),
        "ls_std": float(ls.std()),
        "per_obs_sharpe": per_obs_sr,
        "observed_sharpe_ann": observed_sharpe_ann,
        "sample_length_eff": int(sample_length),
        "n_trials": int(n_trials),
        "skew": skew,
        "kurt": kurt,
    }
    return float(dsr), detail
