from __future__ import annotations
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union, Callable, Sequence
import sys, os, re, math, time, json, copy, warnings, threading, traceback
import tempfile, logging as _logging, hashlib as _hashlib, sqlite3, pickle
import csv, io, gc, uuid, base64
from datetime import datetime
import collections, functools, itertools, contextlib
import concurrent.futures as _cf_mod, threading as _threading
from collections import Counter

# AUDIT-FIX (Round 3 & Round 4, Phase A/B God-File Splits): re-export extracted modules
from optimizer_broker import *  # noqa: F401,F403
from optimizer_risk import *  # noqa: F401,F403
from optimizer_compliance import *  # noqa: F401,F403
from optimizer_compliance import _project_weights_to_bounds  # Explicitly import bound projection helper
try:
    import dimod
except ImportError:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    dimod = None

try:
    import numpy as np
except ImportError:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    np = None
try:
    import pandas as pd
except ImportError:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    pd = None

# from utils import *  # noqa
# from data_layer import *  # noqa

_qpu_warn_emitted = False

# ── All private names needed from utils ─────────────────────────────────
from utils import (
    _QSS,
    archlog,
    _arch_log,
    _NIFTY50,
    _NIFTY_NEXT50,
    _ACTIVE_STOP_EVENT,
    _ACTIVE_STOP_EVENT_LOCK,
    _THEME_SEEDS,
    _DaemonThreadPoolExecutor,
    _DynamicTabMixin,
    _demo_int,
    _demo_float,
    _real_or_demo,
    _real_or_demo_int,
    _widget_alive,
    _download_universe,
    _compute_all,
    _rsi,
    _macd,
    _bollinger,
    _atr,
    _supertrend,
    _ichimoku,
    _vwap,
    _donchian,
    _adx,
    _pivot_points,
    _volume_profile,
    _fill_table_from_df,
    _make_std_table,
    _make_ticker_bar,
    _launch,
    _set_watchlist,
    _ALERT_THROTTLE,
    _DB_STORE,
    _get_quantum_sampler,
    _spearmanr_np,
    APP_VERSION, HAS_SKLEARN, NSE_STRESS_SCENARIOS, OFFLINE_CHART_MODEL_META_PATH,
    OFFLINE_CHART_MODEL_PATH, RUNTIME_DIR, progress_span, parse_symbol_lines,
    per_stock_tc_bps, AppState, ConfigValidator,
    FACTOR_IC_CACHE_PATH, PRESCREEN_CACHE_PATH, _FUNDRAW_IC_CACHE, SQLITE_DB_PATH,
    update_delisted_graveyard, scrub_anomalies, estimate_survivorship_bias,
    read_json_cache, write_json_cache,
    ExceptionLogger, NSEClient, TRADING_DAYS_PER_YEAR, check_stop, chunked, log_emit,
    robust_zscore_series,
    annualized_return, sharpe_from_returns, max_dd_from_equity,
    factor_contribution_row, summarize_selection_reason, compute_portfolio_health,
    build_factor_summary, build_exposures_summary,
    build_selection_changes, build_correlation_matrix,
    build_diagnostics_frame, build_alerts, load_last_run_state,
    compute_breakout_tables,
    compute_oos_validation, run_monte_carlo_bootstrap,
    compute_factor_attribution, compute_sensitivity_report, compute_signal_frame,
    local_search_improve, repair_selection,
    process_prescreen_batch
)
from concurrent.futures import as_completed

from data_layer import (
    fetch_nse_tickers, fetch_fundamentals, fetch_price_series, fetch_benchmark_returns,
    fetch_promoter_holdings, fetch_corp_actions_blackout, fetch_fii_dii_flow, fetch_fno_ban_list,
    fetch_india_vix, fetch_iv_rank, fetch_nse_delivery_data, fetch_oi_buildup_signal,
    fetch_sast_signal, fetch_sebi_cap_categories, sector_counts, normalize_sector,
    DEFAULT_CFG, fetch_sectors, solve_qubo_ensemble,
    _download_ohlcv_bundle, clean_market_panels,
    build_sector_summary, build_sector_relative_summary,
    compute_fundamental_score,
    detect_market_regime, compute_sector_momentum,
    apply_earnings_blackout, apply_sector_momentum_filter,
    apply_vix_position_sizing
)





# ────────────────────────────────────────────────────────────────────
# FUNC: save_alpha_predictions
# ────────────────────────────────────────────────────────────────────
def save_alpha_predictions(signal_df, close_df, log_cb=None):
    """Save per-ticker alpha ranks and last close to SQLite for future IC validation."""
    try:
        import sqlite3 as _sql
        import pandas as _pd
        if signal_df is None or signal_df.empty or "alpha_score" not in signal_df.columns:
            return
        # Bug 39 fix: store alpha_score_raw (unclipped composite z-score) not the
        # post-clip alpha_score. Rank-normalization was removed (Bug 1) but the stored
        # value should be the raw composite for honest IC validation lookups.
        _ascol39 = "alpha_score_raw" if "alpha_score_raw" in signal_df.columns else "alpha_score"
        df = signal_df[[_ascol39, "alpha_score"]].dropna(subset=[_ascol39]).copy()
        df = df.rename(columns={_ascol39: "_raw_score"})
        if df.empty:
            return
        df["alpha_rank"]  = df["_raw_score"].rank(pct=True)
        df["alpha_score"] = df["_raw_score"]   # store raw for IC validation
        last_close        = close_df.iloc[-1] if close_df is not None and not close_df.empty else _pd.Series(dtype=float)
        df["close_price"] = last_close.reindex(df.index)
        run_ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        conn = _sql.connect(str(SQLITE_DB_PATH))
        try:
            cur  = conn.cursor()
            cur.execute("""CREATE TABLE IF NOT EXISTS alpha_predictions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            run_ts TEXT, ticker TEXT, alpha_score REAL, alpha_rank REAL, close_price REAL)""")
            cur.execute("""CREATE TABLE IF NOT EXISTS alpha_validations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            run_ts TEXT, validated_ts TEXT, n_tickers INTEGER,
            IC REAL, mean_ret_top REAL, mean_ret_bot REAL, hit_rate REAL)""")
            rows = [(run_ts, str(t), float(r["alpha_score"]), float(r["alpha_rank"]),
                     float(r["close_price"]) if _pd.notna(r["close_price"]) else None)
                    for t, r in df.iterrows()]
            cur.executemany(
                "INSERT INTO alpha_predictions (run_ts,ticker,alpha_score,alpha_rank,close_price) VALUES (?,?,?,?,?)",
                rows)
            conn.commit()
        finally:
            conn.close()
        log_emit(log_cb, f"[PostTrade] Saved {len(rows)} alpha predictions for future IC validation.")
    except Exception as e:
        log_emit(log_cb, f"[PostTrade] save_alpha_predictions failed (non-fatal): {e}", exc_info=True)




# ────────────────────────────────────────────────────────────────────
# FUNC: validate_past_predictions
# ────────────────────────────────────────────────────────────────────
def validate_past_predictions(close_df, log_cb=None, cfg=None):
    """Compute realized IC for alpha predictions from runs older than 21 days."""
    VALIDATION_LAG_DAYS = int((cfg or {}).get("VALIDATION_LAG_DAYS", 21))  # honour cfg
    try:
        import sqlite3 as _sql
        from datetime import timedelta as _td
        if close_df is None or close_df.empty:
            return None
        conn = _sql.connect(str(SQLITE_DB_PATH))
        try:
            cur = conn.cursor()
            cur.execute("""CREATE TABLE IF NOT EXISTS alpha_predictions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                run_ts TEXT, ticker TEXT, alpha_score REAL, alpha_rank REAL,
                close_price REAL)""")
            cur.execute("""CREATE TABLE IF NOT EXISTS alpha_validations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                run_ts TEXT, validated_ts TEXT, n_tickers INTEGER,
                IC REAL, mean_ret_top REAL, mean_ret_bot REAL, hit_rate REAL)""")
            conn.commit()
            cutoff = (datetime.now() - _td(days=VALIDATION_LAG_DAYS)).strftime("%Y-%m-%d %H:%M:%S")
            cur.execute("SELECT DISTINCT run_ts FROM alpha_predictions WHERE run_ts <= ?", (cutoff,))
            candidates = [r[0] for r in cur.fetchall()]
            cur.execute("SELECT DISTINCT run_ts FROM alpha_validations")
            already = {r[0] for r in cur.fetchall()}
            pending = [r for r in candidates if r not in already]
            if not pending:
                log_emit(log_cb, f"[PostTrade] No predictions ready for validation yet "
                         f"(need runs >{VALIDATION_LAG_DAYS}d old).")
                return None
            try:
                from scipy.stats import spearmanr as _spr
                _has_scipy = True
            except ImportError as _e:
                _has_scipy = False
                import logging as _lg; _lg.getLogger(__name__).debug('Optional import unavailable: from scipy.stats import spearmanr as _spr')  # P8
            summary_rows = []
            validated_ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            for run_ts in pending:
                # Bug 18 fix: T+21 price, NOT today.
                from datetime import timedelta as _td18
                _avail = close_df.index[
                    close_df.index >= pd.Timestamp(run_ts) + _td18(days=VALIDATION_LAG_DAYS)]
                if len(_avail) == 0:
                    continue
                fwd_close = close_df.loc[_avail[0]]
                cur.execute(
                    "SELECT ticker, alpha_rank, close_price FROM alpha_predictions WHERE run_ts=?",
                    (run_ts,))
                fwd_rets, pred_ranks = [], []
                for ticker, alpha_rank, close_pred in cur.fetchall():
                    if ticker not in fwd_close.index or close_pred is None or close_pred <= 0:
                        continue
                    curr = float(fwd_close[ticker])
                    if curr <= 0:
                        continue
                    fwd_rets.append(curr / float(close_pred) - 1.0)
                    pred_ranks.append(float(alpha_rank))
                if len(fwd_rets) < 8:
                    continue
                pred_arr = np.array(pred_ranks)
                fwd_arr  = np.array(fwd_rets)
                try:
                    ic_val = (float(_spr(pred_arr, fwd_arr)[0]) if _has_scipy
                              else float(np.corrcoef(pred_arr, fwd_arr)[0, 1]))
                except Exception as _e:
                    ic_val = float("nan")
                q75 = np.percentile(pred_arr, 75)
                q25 = np.percentile(pred_arr, 25)
                top_mask = pred_arr >= q75
                bot_mask = pred_arr <= q25
                mean_ret_top = float(fwd_arr[top_mask].mean()) if top_mask.any() else float("nan")
                mean_ret_bot = float(fwd_arr[bot_mask].mean()) if bot_mask.any() else float("nan")
                med      = np.median(pred_arr)
                hit_mask = pred_arr > med
                hit_rate = float((fwd_arr[hit_mask] > 0).mean()) if hit_mask.any() else float("nan")
                cur.execute(
                    """INSERT INTO alpha_validations
                       (run_ts,validated_ts,n_tickers,IC,mean_ret_top,mean_ret_bot,hit_rate)
                       VALUES (?,?,?,?,?,?,?)""",
                    (run_ts, validated_ts, len(fwd_rets),
                     ic_val, mean_ret_top, mean_ret_bot, hit_rate))
                summary_rows.append({
                    "Prediction Run": run_ts,
                    "Validated At":   validated_ts,
                    "N Tickers":      len(fwd_rets),
                    "Realized IC":    round(ic_val, 4)          if pd.notna(ic_val)      else float("nan"),
                    "Top-Q Ret (%)":  round(mean_ret_top * 100, 2) if pd.notna(mean_ret_top) else float("nan"),
                    "Bot-Q Ret (%)":  round(mean_ret_bot * 100, 2) if pd.notna(mean_ret_bot) else float("nan"),
                    "Hit Rate (%)":   round(hit_rate * 100, 1)  if pd.notna(hit_rate)    else float("nan"),
                })
                log_emit(log_cb,
                         f"[PostTrade] Validated {run_ts}: IC={ic_val:.3f}, "
                         f"TopQ={mean_ret_top*100:.1f}%, HitRate={hit_rate*100:.0f}%")
            conn.commit()
        finally:
            conn.close()
        if not summary_rows:
            return None
        log_emit(log_cb, f"[PostTrade] {len(summary_rows)} prediction run(s) validated.")
        return pd.DataFrame(summary_rows)
    except Exception as e:
        log_emit(log_cb, f"[PostTrade] validate_past_predictions failed (non-fatal): {e}", exc_info=True)
        return None




# ────────────────────────────────────────────────────────────────────
# FUNC: _resolve_chart_artifact_paths
# ────────────────────────────────────────────────────────────────────
def _resolve_chart_artifact_paths(cfg: dict, timeframe: str) -> tuple[Path, Path]:
    tf = str(timeframe or "1d").lower()
    artifact_map = (cfg or {}).get("CHART_OFFLINE_ARTIFACTS", {}) or {}
    meta_map = (cfg or {}).get("CHART_OFFLINE_METAS", {}) or {}
    artifact = Path(artifact_map.get(tf, (cfg or {}).get("CHART_OFFLINE_ARTIFACT", str(OFFLINE_CHART_MODEL_PATH)))).expanduser()
    meta = Path(meta_map.get(tf, (cfg or {}).get("CHART_OFFLINE_META", str(OFFLINE_CHART_MODEL_META_PATH)))).expanduser()
    return artifact, meta









# ────────────────────────────────────────────────────────────────────
# FUNC: apply_regime_bias
# ────────────────────────────────────────────────────────────────────
def apply_regime_bias(signal_df, regime_info, cfg):
    """
    v17.24: Soft probabilistic regime tilt using RegimeBlend [-1, +1].
    Positive blend (bull) -> amplify momentum proportionally.
    Negative blend (bear) -> amplify risk-reduction proportionally.
    IMP8: tilt coefficients read from cfg so they are tunable without
    touching the function body.
    """
    adjusted    = signal_df.copy()
    regime_pref = cfg.get("REGIME_FILTER", "Adaptive")
    regime      = regime_info.get("Regime", "Unknown")
    blend       = regime_info.get("RegimeBlend", float("nan"))

    # IMP8: read tilt magnitudes from cfg (DEFAULT_CFG provides fallbacks)
    _bmw  = float(cfg.get("REGIME_BULL_MOM_W",   0.08))  # bull momentum amplifier
    _btw  = float(cfg.get("REGIME_BULL_TREND_W", 0.06))  # bull trend amplifier
    _bvw  = float(cfg.get("REGIME_BEAR_VOL_W",   0.10))  # bear volatility penalty
    _bbw  = float(cfg.get("REGIME_BEAR_BETA_W",  0.08))  # bear beta penalty

    if regime_pref == "Defensive Bias":
        adjusted["alpha_score"] = (adjusted["alpha_score"]
            - _bvw * adjusted["z_ann_vol"] - _bbw * adjusted["z_beta_dev"])
        return adjusted
    if regime_pref == "Risk-On Bias":
        adjusted["alpha_score"] = (adjusted["alpha_score"]
            + _bmw * adjusted["z_mom_6m"] + _btw * adjusted["z_trend_50"])
        return adjusted

    if pd.notna(blend):
        bull_tilt = max(0.0, float(blend))
        bear_tilt = max(0.0, float(-blend))
        adjusted["alpha_score"] = (
            adjusted["alpha_score"]
            + _bmw * bull_tilt * adjusted["z_mom_6m"].fillna(0.0)
            + _btw * bull_tilt * adjusted["z_trend_50"].fillna(0.0)
            - _bvw * bear_tilt * adjusted["z_ann_vol"].fillna(0.0)
            - _bbw * bear_tilt * adjusted["z_beta_dev"].fillna(0.0)
        )
    else:
        if regime in ("Risk-Off Stress", "Defensive"):
            adjusted["alpha_score"] = (adjusted["alpha_score"]
                - _bvw * adjusted["z_ann_vol"] - _bbw * adjusted["z_beta_dev"])
        elif regime in ("Risk-On Trend", "Broad Strength"):
            adjusted["alpha_score"] = (adjusted["alpha_score"]
                + _bmw * adjusted["z_mom_6m"] + _btw * adjusted["z_trend_50"])

    return adjusted


# Phase A/B God-File Decomposition:
# Risk and compliance functions are imported from optimizer_risk and optimizer_compliance.

def check_multi_timeframe_confluence(daily_df: pd.DataFrame, h4_df: pd.DataFrame = None, h1_df: pd.DataFrame = None) -> dict:
    """
    [UPGRADE 2] Multi-Timeframe (MTF) Trend & Volume Profile Confluence Alignment.
    Confirms that Daily (D), 4-Hour (4H), and 1-Hour (1H) trends are all aligned in the same direction before approving entry.
    """
    if daily_df is None or daily_df.empty or len(daily_df) < 50:
        return {"mtf_aligned": False, "confluence_score": 0.0, "details": "Insufficient Daily history"}
    try:
        px_d = daily_df["Close"].values
        sma50_d = np.mean(px_d[-50:])
        sma200_d = np.mean(px_d[-200:]) if len(px_d) >= 200 else np.mean(px_d)
        daily_bull = (px_d[-1] >= sma50_d) and (sma50_d >= sma200_d * 0.98)
        
        h4_bull = True
        if h4_df is not None and not h4_df.empty and len(h4_df) >= 20:
            px_h4 = h4_df["Close"].values
            sma20_h4 = np.mean(px_h4[-20:])
            h4_bull = bool(px_h4[-1] >= sma20_h4)
            
        h1_bull = True
        if h1_df is not None and not h1_df.empty and len(h1_df) >= 20:
            px_h1 = h1_df["Close"].values
            sma20_h1 = np.mean(px_h1[-20:])
            h1_bull = bool(px_h1[-1] >= sma20_h1)
            
        mtf_aligned = bool(daily_bull and h4_bull and h1_bull)
        confluence_score = round((1.0 if daily_bull else 0.0) * 0.50 + (1.0 if h4_bull else 0.0) * 0.30 + (1.0 if h1_bull else 0.0) * 0.20, 2)
        
        return {
            "mtf_aligned": mtf_aligned,
            "confluence_score": confluence_score,
            "daily_bull": daily_bull,
            "h4_bull": h4_bull,
            "h1_bull": h1_bull
        }
    except Exception as e:
        return {"mtf_aligned": False, "confluence_score": 0.0, "details": str(e)}




# ────────────────────────────────────────────────────────────────────
# FUNC: generate_angelone_order_sheet
# ────────────────────────────────────────────────────────────────────


# AUDIT-FIX (defect #6): generate_kite_order_sheet was a silent alias of
# generate_angelone_order_sheet, so "Kite" CSVs were actually in Angel One
# format (Symbol/Exchange/Action/Order Type/quantity/Product/Validity/Tag).
# Zerodha Kite Connect basket CSV uses different headers (tradingsymbol,
# exchange, transaction_type, order_type, quantity, product, validity, price).
# We now generate a Kite-compatible sheet from the same source data and surface
# a clear warning if the underlying broker router is actually Angel One.





# Backward compatibility alias for the original Angel One sheet generator.
# generate_kite_order_sheet and generate_dhan_order_sheet are now real,
# broker-specific implementations above (audit defect #6).








# ────────────────────────────────────────────────────────────────────
# FUNC: compute_rolling_ic
# ────────────────────────────────────────────────────────────────────
def compute_rolling_ic(factor_series, forward_returns, forward_days=21, min_periods=8):
    """
    Compute rolling cross-sectional Spearman IC for a single factor.

    For each non-overlapping window of `forward_days` in the training data:
      - `factor_series`: per-stock rolling trailing return proxy for that factor
        (e.g. 6m momentum = returns.rolling(126).sum())
      - `forward_returns`: actual return over next `forward_days`
    Returns array of IC values across windows (one per rebalance period).
    """

    ic_vals = []
    n = len(forward_returns)
    for t in range(0, n - forward_days, forward_days):
        fac_t = factor_series.iloc[t]          # factor rank at time t (cross-section)
        fwd_t = forward_returns.iloc[t]  # v17.35: FIX forward alignment
        valid = fac_t.notna() & fwd_t.notna() if isinstance(fwd_t, pd.Series) else None
        if valid is None or valid.sum() < min_periods:
            continue
        f, r = fac_t[valid].values, fwd_t[valid].values
        ic, _ = _spearmanr_np(f, r)
        if pd.notna(ic):
            ic_vals.append(ic)
    return np.array(ic_vals)




# ────────────────────────────────────────────────────────────────────
# FUNC: sqlite_save_ic_observations
# ────────────────────────────────────────────────────────────────────



# ────────────────────────────────────────────────────────────────────
# FUNC: sqlite_load_ic_history
# ────────────────────────────────────────────────────────────────────




# ────────────────────────────────────────────────────────────────────
# FUNC: calibrate_factor_weights_ic
# ────────────────────────────────────────────────────────────────────
def calibrate_factor_weights_ic(returns: pd.DataFrame, cfg: dict,
                                  log_cb=None, forward_days: int = 21,
                                  return_details: bool = False) -> dict:
    """
    Real IC-based factor weight calibration.

    Steps
    -----
    1. For each factor in _FACTOR_PROXIES, build a rolling trailing-return
       proxy (cross-sectionally ranked) as the factor signal.
    2. Compute Spearman IC between that signal and forward_days returns
       for every non-overlapping window in the data.
    3. IC-IR = mean(IC) / std(IC)  — the signal-to-noise ratio.
    4. Load historical IC-IR from FACTOR_IC_CACHE_PATH (JSON).
    5. EWM-blend fresh IC-IR with history (decay = 0.7).
    6. Normalise to weights (same total as DEFAULTCFG positive weights).
    7. Persist updated history.
    8. Return calibrated FACTOR_WEIGHTS dict.
    """
    import json

    n_rows, n_tickers = returns.shape
    # Enforce 252-day minimum for true out-of-sample walk-forward IC validation.
    # 3-window floor is too permissive (only 63 rows for 21d forward) — real IC-IR
    # needs at least 1 year of history to get 12 non-overlapping windows and a
    # meaningful signal-to-noise ratio for each factor.
    min_rows = max(forward_days * 12, 252)   # >= 252d enforced for institutional-grade OOS IC
    if n_rows < min_rows or n_tickers < 8:
        log_emit(log_cb, f"[IC-Learn] Insufficient data ({n_rows}r/{n_tickers}t) — using defaults")
        _default_weights = dict(DEFAULT_CFG).get("FACTOR_WEIGHTS", dict(DEFAULT_CFG)["FACTOR_WEIGHTS"])
        if return_details:
            return {
                "weights": _default_weights,
                "ic_scores": {},
                "history_scores": {},
                "used_defaults": True,
            }
        return _default_weights

    # --- 1 & 2: per-factor IC computation -----------------------------------
    cum_ret   = returns.fillna(0).cumsum()                  # log-cum approx
    fwd_ret   = returns.rolling(forward_days).sum().shift(-forward_days)
    fw_active = cfg.get("FACTOR_WEIGHTS", DEFAULT_CFG["FACTOR_WEIGHTS"])
    ic_ir_now = {}
    # R35: n_windows tracked per factor (both proxy and fundamental loops) so
    # the deflated-IC pass can compute each factor's OWN t-statistic
    # (t = IC-IR·√n_windows).
    ic_n_win: dict = {}

    # inline fallback — avoids module-scope lookup failure
    _fp = [
        ("z_mom_1m", 21, 1.0), ("z_mom_3m", 63, 1.0),
        ("z_mom_6m", 126, 1.0), ("z_mom_12_1", 252, 1.0),
        ("z_trend_20", 20, 1.0), ("z_trend_50", 50, 1.0),
        ("z_sector_rel_mom_1m", 21, 1.0), ("z_sector_rel_mom_6m", 126, 1.0),
        # Bug 19 fix: add missing factors to IC calibration
        ("z_adv20", 21, 1.0), ("z_vol_surge", 21, 1.0),
        # Vol risk factor — sign=-1: high realised vol predicts low forward return.
        # z_garch_vol is NOT in this proxy list: the IC loop uses return-based lookback
        # proxies and cannot reproduce the GARCH conditional variance — using a 21d
        # momentum proxy as a stand-in would corrupt the GARCH weight rather than
        # calibrate it. The GARCH weight stays at its static default (-0.05) from DEFAULT_CFG.
        ("z_ann_vol", 21, -1.0),
    ]
    for fname, lb, sign in _fp:
        if fname not in fw_active:
            continue
        try:
            proxy = (cum_ret - cum_ret.shift(lb)) * sign
            proxy_ranked = proxy.rank(axis=1, pct=True)     # cross-sectional rank

            ic_vals = []
            # Bug 21 fix: start at forward_days not lb — lb skipped up to 252 days.
            for t in range(forward_days, n_rows - forward_days, forward_days):
                f_cross = proxy_ranked.iloc[t]
                r_cross = fwd_ret.iloc[t]
                valid   = f_cross.notna() & r_cross.notna()
                if valid.sum() < 5:
                    continue
                # circuit-breaker: if >30% of universe hit limit-up/down skip
                if (r_cross[valid].abs() > 0.095).mean() > 0.55:
                    continue
                ic_vals.append(_spearmanr_np(f_cross[valid].values,
                                            r_cross[valid].values)[0])

            ic_vals = [v for v in ic_vals if v is not None and not (isinstance(v, float) and v != v)]
            if len(ic_vals) < 2:
                continue
            ic_n_win[fname] = len(ic_vals)

            # --- 3: IC-IR with exponential decay (recent matters more) ------
            decay = 0.7
            w_ew  = np.array([decay ** (len(ic_vals)-1-i) for i in range(len(ic_vals))])
            w_ew /= w_ew.sum()
            mu    = float(np.dot(w_ew, ic_vals))
            sum_w_sq = float(np.sum(w_ew**2))
            var_denom = 1.0 - sum_w_sq
            if var_denom > 1e-6:
                sigma = float(np.sqrt(max(np.dot(w_ew, (np.array(ic_vals) - mu)**2) / var_denom, 0.0)))
            else:
                sigma = float(np.sqrt(max(np.dot(w_ew, (np.array(ic_vals) - mu)**2), 0.0)))
            ic_ir = mu / (sigma + 1e-6)
            # stability: penalise high CV
            cv    = sigma / (abs(mu) + 1e-6)
            stab  = min(1.0, 1.0 / (1.0 + cv))
            ic_ir_now[fname] = ic_ir * stab  # v17.31: allow negative IC-IR to suppress non-working factors
            if abs(ic_ir_now[fname]) >= 0.20:
                log_emit(log_cb, f"  [IC] {fname:20s}  IC-IR={ic_ir:+.3f}  "
                                f"stab={stab:.2f}  w={ic_ir_now[fname]:.4f}")
        except Exception as e:
            log_emit(log_cb, f"  [IC] {fname} skipped: {e}", exc_info=True)

    # v17.28 — measure IC for fundamental factors (z_roe, z_pe_inv)
    # Static cross-section broadcast over time: balance-sheet data is quarterly,
    # so treating it as constant within a 1-year window is correct.
    # On run 1 the cache is empty → no-op. Run 2+ these enter IC calibration.
    # AUDIT-FIX (defect #5): snapshot the shared cache under its lock rather
    # than reading the live dict directly, which could race with a parallel
    # profile worker's update. The snapshot is consistent for this call.
    from utils import snapshot_fundraw_ic_cache
    _fundraw_snapshot = snapshot_fundraw_ic_cache()
    _fund_factor_maps = {}
    if _fundraw_snapshot:
        _fund_factor_maps = {
            "z_roe":    {t:  _fundraw_snapshot.get(t, {}).get("roe",      float("nan")) for t in returns.columns},
            "z_pe_inv": {t:  (1.0 / _fundraw_snapshot.get(t, {}).get("pe_ratio", float("nan"))) if _fundraw_snapshot.get(t, {}).get("pe_ratio", 0) > 0 else float("nan") for t in returns.columns},
            "z_de_inv": {t: -_fundraw_snapshot.get(t, {}).get("de_ratio", float("nan")) for t in returns.columns},
        }
        for _fname, _raw_map in _fund_factor_maps.items():
            if _fname not in fw_active:
                continue
            try:
                _cross = pd.Series(_raw_map).reindex(returns.columns)
                if _cross.notna().sum() < 8:
                    continue
                _proxy_ranked = _cross.rank(pct=True)           # static cross-section
                _ic_vals = []
                for _t in range(0, n_rows - forward_days, forward_days):
                    _r_cross = fwd_ret.iloc[_t]
                    _valid   = _proxy_ranked.notna() & _r_cross.notna()
                    if _valid.sum() < 5:
                        continue
                    _ic_vals.append(_spearmanr_np(_proxy_ranked[_valid].values,
                                                  _r_cross[_valid].values)[0])
                _ic_vals = [v for v in _ic_vals if v is not None and not (isinstance(v, float) and v != v)]
                if len(_ic_vals) < 2:
                    continue
                ic_n_win[_fname] = len(_ic_vals)
                _w_ew  = np.array([0.7 ** (len(_ic_vals)-1-i) for i in range(len(_ic_vals))])
                _w_ew /= _w_ew.sum()
                _mu    = float(np.dot(_w_ew, _ic_vals))
                _sum_w_sq = float(np.sum(_w_ew**2))
                _var_denom = 1.0 - _sum_w_sq
                if _var_denom > 1e-6:
                    _sigma = float(np.sqrt(max(np.dot(_w_ew, (np.array(_ic_vals) - _mu)**2) / _var_denom, 0.0)))
                else:
                    _sigma = float(np.sqrt(max(np.dot(_w_ew, (np.array(_ic_vals) - _mu)**2), 0.0)))
                _ic_ir = _mu / (_sigma + 1e-6)
                _stab  = min(1.0, 1.0 / (1.0 + _sigma / (abs(_mu) + 1e-6)))
                ic_ir_now[_fname] = _ic_ir * _stab  # v17.32: allow negative to suppress bad fundamental factors
                if abs(ic_ir_now[_fname]) >= 0.20:
                    log_emit(log_cb, f"  [IC] {_fname:20s}  IC-IR={_ic_ir:+.3f}  "
                                     f"stab={_stab:.2f}  w={ic_ir_now[_fname]:.4f}  [fundamental]")
            except Exception as _fe:
                log_emit(log_cb, f"  [IC] {_fname} skipped: {_fe}", exc_info=True)

        # ── AUTO SIGN-FLIP REMOVED: Clamp momentum/trend factors if IC < 0 ──
    _MOM_FACTORS = {"z_mom_1m", "z_mom_3m", "z_mom_6m", "z_mom_12_1", "z_trend_20", "z_trend_50", "z_sector_rel_mom_1m", "z_sector_rel_mom_6m"}
    for _k in list(ic_ir_now.keys()):
        if _k in _MOM_FACTORS and ic_ir_now[_k] < 0:
            ic_ir_now[_k] = 0.0
            log_emit(log_cb, f"[IC-Learn] Clamped {_k} to 0.0 (negative IC, disabling factor)")

    # ── Institutional-grade Active Factor Pruning (Issue 2 Fix) ──
    # AUDIT-FIX (Round 3, P2-3): the 0.20 IC-IR prune gate was an arbitrary
    # effect-size cutoff, not a statistical-significance test. With std(IC)
    # ~0.45 on a 10-stock universe and N~45 windows, the implied |t| for
    # IC-IR=0.20 is roughly 0.20*sqrt(45)~1.34 - below the 95% t-test
    # threshold of 1.96. So the system was PERMITTING factors that fail the
    # t-test into production. The proper gate is the IC t-statistic from
    # scripts/walk_forward_validation_v2.py (with NW + orthogonalization +
    # BH-FDR). When USE_IC_T_STAT_GATING is True (default), we look up the
    # t_stat from the calibration cache and prune only factors with |t| < 1.96.
    _ANCHORS      = {"z_roe", "z_pe_inv", "z_de_inv", "z_rev_growth", "z_delivery", "z_fii_sector"}
    # AUDIT-FIX (Round 4 — E0602 false positive): the original expression
    # `working_cfg if 'working_cfg' in locals() else {}` evaluates the
    # `in locals()` check first and short-circuits, so the name is never
    # actually accessed when undefined. Pylint's data-flow analysis can't
    # prove this. Use `locals().get(...)` to make the late-binding explicit
    # so static analysis sees an actual definition.
    _cfg_ref = cfg if ('cfg' in locals() and cfg is not None) else locals().get('working_cfg', {}) or {}
    _USE_STAT_GATE = bool(_cfg_ref.get("USE_IC_T_STAT_GATING", True))
    _T_STAT_LOOKUP = (_cfg_ref.get("FACTOR_T_STATS", {}) or {})
    # AUDIT-FIX (Round 3, P2-3 follow-up-b): threshold now configurable via cfg
    # (was hardcoded 1.96 — fine in practice, but the new IC_T_STAT_THRESHOLD
    # cfg key lets the operator tighten (e.g. 2.58 for 99% confidence) or
    # loosen (e.g. 1.645 for 90% one-tailed) without code edits.
    _T_STAT_THRESHOLD = float(_cfg_ref.get("IC_T_STAT_THRESHOLD", 1.96))
    # AUDIT-FIX (Round 3, P2-3 follow-up-b): gate now ACTIVE by default.
    # DEFAULT_CFG ships FACTOR_T_STATS populated from the canonical walk-
    # forward leaderboard (artifacts/wfo_real.json), so the table is non-
    # empty in production → the t-stat gate engages instead of the legacy
    # 0.20 IC-IR prune. obv_slope (BH-FDR sig, p=0.054) is the only factor
    # whose significance survives multiple-testing correction; the table
    # also lists the 10 NW-significant factors that survive the |t|>=1.96
    # test, with all other factors carrying their actual t-stats so the
    # gate can properly prune them rather than blanket-zero missing keys.
    # 1. Prune Dead Factors - gate on IC t-statistic (or fall back to 0.20 IC-IR)
    for _k in list(ic_ir_now.keys()):
        if _k not in _ANCHORS:
            if _USE_STAT_GATE and _T_STAT_LOOKUP:
                _t = float(_T_STAT_LOOKUP.get(_k, 0.0))
                if abs(_t) < _T_STAT_THRESHOLD:
                    ic_ir_now[_k] = 0.0
                    log_emit(log_cb, f"[IC-Prune] Pruned factor {_k} to 0.0 (|t_IC|={_t:.2f} < {_T_STAT_THRESHOLD})")
            else:
                # Legacy fallback: prune on |IC-IR| < 0.20 (arbitrary effect-size cutoff)
                if abs(ic_ir_now.get(_k, 0.0)) < 0.20:
                    ic_ir_now[_k] = 0.0
                    log_emit(log_cb, f"[IC-Prune] Pruned dead factor {_k} to 0.0 (|IC-IR| < 0.20, fallback gate)")

    # 2. Prune Correlated Duplicates: if correlation with a higher-ranked factor is > 0.75, set to 0.0
    try:
        _ps = {}
        for _fname, _lb, _sign in _fp:
            if _fname not in ic_ir_now or ic_ir_now[_fname] == 0.0:
                continue
            _p = (cum_ret - cum_ret.shift(_lb)) * _sign
            _ps[_fname] = _p.iloc[-1].fillna(0) if not _p.empty else pd.Series(dtype=float)
        
        # Add fundamental factor series if available
        # AUDIT-FIX (defect #5): use the local snapshot rather than re-reading the
        # live module-level cache (race-safe against parallel updates).
        if _fundraw_snapshot:
            for _fname, _raw_map in _fund_factor_maps.items():
                if _fname in ic_ir_now and ic_ir_now[_fname] > 0.0:
                    _ps[_fname] = pd.Series(_raw_map).reindex(returns.columns).fillna(0)
                    
        if len(_ps) >= 2:
            _ps_df = pd.DataFrame(_ps).dropna()
            if len(_ps_df) >= 2:
                _corr_m = _ps_df.corr().abs()
                # Sort active factors by absolute IC-IR descending
                _ranked = sorted([_k for _k in ic_ir_now if ic_ir_now[_k] > 0.0],
                                 key=lambda x: -abs(ic_ir_now[x]))
                _pruned = set()
                for _i, _fa in enumerate(_ranked):
                    if _fa in _pruned:
                        continue
                    for _fb in _ranked[_i+1:]:
                        if _fb in _pruned:
                            continue
                        if _fa in _corr_m.columns and _fb in _corr_m.columns:
                            if _corr_m.loc[_fa, _fb] > 0.75:
                                _pruned.add(_fb)
                                ic_ir_now[_fb] = 0.0
                                log_emit(log_cb, f"[IC-Prune] Pruned collinear factor {_fb} to 0.0 (correlated >0.75 with {_fa})")
    except Exception as _prune_err:
        log_emit(log_cb, f"[IC-Prune] Warning: correlation pruning encountered error: {_prune_err}", exc_info=True)

    # --- MULTI-TIMEFRAME ORCHESTRATION PATCH ---

    _ANCHORS      = {"z_roe", "z_pe_inv", "z_de_inv", "z_rev_growth", "z_delivery", "z_fii_sector"}
    # Bug 23 fix: floor = 50% of default weight so fundamentals never zeroed by IC.
    _ANCHOR_FLOOR = {k: max(float(DEFAULT_CFG.get("FACTOR_WEIGHTS", {}).get(k, 0.0))*0.5, 0.01)
                     for k in _ANCHORS}
    
    # PATCH12: SQLite history injection
    try:
        import sqlite3 as _sq3
        _conn = _sq3.connect(str(SQLITE_DB_PATH))
        _rows = _conn.execute(
            "SELECT factor, ic FROM factor_ic_history ORDER BY id DESC LIMIT 5000"
        ).fetchall()
        _conn.close()
        # Compute IC-IR = mean(IC)/std(IC) in Python (SQLite has no STDEV)
        import collections as _col
        _fic = _col.defaultdict(list)
        for _fr, _ir in _rows: _fic[str(_fr)].append(float(_ir))
        _sqlite_means = {}
        for _fk, _fv in _fic.items():
            if len(_fv) < 3: continue
            # Bug 22 fix: EWM decay=0.7 matches fresh IC-IR computation.
            _d22=0.7;_n22=len(_fv);_w22=[_d22**(_n22-1-i) for i in range(_n22)];_sw22=sum(_w22)
            _fmu=sum(w*x for w,x in zip(_w22,_fv))/_sw22  # DIV001: guard divisor before use
            _fsd=((sum(w*(x-_fmu)**2 for w,x in zip(_w22,_fv))/_sw22)**0.5 if _sw22 != 0 else 0.0)  # DIV001 guarded
            _sqlite_means[_fk] = _fmu/(_fsd+1e-6)
        _sqlite_means = {k: max(-1.5, min(1.5, v)) for k, v in _sqlite_means.items()}  # sanity clamp
        _injected = 0
        for _k, _hv in _sqlite_means.items():
            # Only inject for factors with NO fresh IC — never override clamped-to-zero factors
            if _k not in ic_ir_now or (abs(ic_ir_now.get(_k, 0.0)) < 0.05 and _k not in _MOM_FACTORS):
                ic_ir_now[_k] = _hv
                _injected += 1
        log_emit(log_cb, f"IC-SQLiteInject {_injected}/{len(_sqlite_means)} factors from history")
    except Exception as _e:
        log_emit(log_cb, f"IC-SQLiteInject failed: {_e}", exc_info=True)

    # Bug 23b: enforce anchor floors — quarterly fundamentals have low 21d IC by construction.
    for _ak, _af in _ANCHOR_FLOOR.items():
        if _ak in fw_active:
            if _ak not in ic_ir_now or abs(ic_ir_now[_ak]) < _af:
                ic_ir_now[_ak] = _af

    # ── R35: DEFLATED-IC SHRINKAGE (multiple-testing correction) ──────
    # The t-gate above prunes on a STATIC walk-forward t-table; this pass
    # deflates each FRESHLY measured IC-IR by its OWN t-statistic
    # (t = IC-IR·√n_windows — López de Prado deflation logic applied to the
    # IC-IR). Continuous shrinkage toward zero: |t| ≤ 2 ⇒ dead, 3σ keeps a
    # third of its weight, 8σ+ approaches pass-through. opt-in via
    # USE_DEFLATED_IC (🦄 profile default-on); anchors are exempt (floored
    # above for low-frequency reasons, not noise).
    if bool(_cfg_ref.get("USE_DEFLATED_IC", False)):
        try:
            from math_engine.ipo_multibagger_math import deflate_ic
            _r35_defl_applied = 0
            for _k in list(ic_ir_now.keys()):
                if _k in _ANCHORS:
                    continue
                _nw = int(ic_n_win.get(_k, 0))
                if _nw < 20:
                    continue  # no measured support ⇒ not deflatable (t-gate governs)
                _pre = float(ic_ir_now[_k])
                _post = deflate_ic(_pre, _nw, None,
                                   t_threshold=float(_cfg_ref.get("DEFLATED_IC_T_THRESHOLD", 2.0)))
                if abs(_post - _pre) > 1e-9:
                    ic_ir_now[_k] = _post
                    _r35_defl_applied += 1
            log_emit(log_cb, f"[IC-Deflate] R35 deflated-IC shrinkage applied to {_r35_defl_applied} "
                             f"factors (t = IC-IR·√n_win, threshold "
                             f"{_cfg_ref.get('DEFLATED_IC_T_THRESHOLD', 2.0)}; anchors exempt)")
        except Exception as _defl_e:
            log_emit(log_cb, f"[IC-Deflate] skipped: {_defl_e}", exc_info=True)


    # Phase 3.9: Removed the bear_mode regime double-counting block.
    # Previously: calibrate_factor_weights_ic detected bear mode (all IC-IR ≤ 0)
    # and multiplied momentum weights by -0.001, quality weights by +0.01. Then
    # apply_regime_bias (line 3181) ALSO subtracted 0.10*z_ann_vol + 0.08*z_beta_dev.
    # The portfolio was over-tilted defensive at BOTH the factor-weight level AND
    # the alpha-score level — could produce degenerate 2-stock portfolios in deep bears.
    # Now: apply_regime_bias handles ALL regime tilting. calibrate_factor_weights_ic
    # only does IC-based weight calibration (its actual job).
    _bear_mode = False  # kept for logging, but no longer mutates weights
    _STRUCT_NEG = {'z_ann_vol','z_downside_vol','z_drawdown','z_de_inv'}
    _pos_count = sum(1 for k,v in ic_ir_now.items() if k not in _STRUCT_NEG and v > 0)
    _ic_snap = sorted(((k,v) for k,v in ic_ir_now.items() if k not in _STRUCT_NEG), key=lambda x:-x[1])[:5]
    log_emit(log_cb, '[IC-Learn] ICtop5 ' + '  '.join(f'{k}={v:+.3f}' for k,v in _ic_snap) + f'  pos={_pos_count}')
    if not ic_ir_now or _pos_count == 0:
        _bear_mode = True
        _rlabel = cfg.get('_REGIME_INFO', {}).get('Regime', '')
        log_emit(log_cb, f'[IC-Learn] All IC-IR ≤ 0 — bear mode detected ({_rlabel}). '
                  'Regime tilting delegated to apply_regime_bias (Phase 3.9: no double-counting).')
        # Phase 3.9: Do NOT mutate factor weights here — apply_regime_bias handles it.


    # --- 4: load history ----------------------------------------------------
    # v17-patch: skip JSON file cache inside WFO steps (cfg flag set by fast_cfg)
    # WFO slices are short; stale file cache forces IC to repeat across steps.
    history = {}
    _in_wfo = (cfg or {}).get("_WFO_STEP", False)
    if not _in_wfo and FACTOR_IC_CACHE_PATH.exists():
        try:
            history = json.loads(FACTOR_IC_CACHE_PATH.read_text())
        except Exception as _e:
            history = {}

    # --- 5: EWM-blend fresh with history ------------------------------------
    DECAY_HIST = 0.7
    MAX_HIST   = 20
    blended    = {}
    for fname, ic_fresh in ic_ir_now.items():
        hist_vals = history.get(fname, [])
        hist_vals.append(ic_fresh)
        hist_vals = hist_vals[-MAX_HIST:]
        history[fname] = hist_vals
        n_h = len(hist_vals)
        # v17-patch: exponential decay across runs — recent IC counts more than stale history
        # age[0] = oldest entry, age[n-1] = freshest (just appended)
        age_decay = np.array([DECAY_HIST ** (n_h - 1 - i) for i in range(n_h)], dtype=np.float64)
        age_decay /= age_decay.sum()
        blended[fname] = float(np.dot(age_decay, hist_vals))

    # --- 6: normalise to weights --------------------------------------------
    default_fw = dict(DEFAULT_CFG).get("FACTOR_WEIGHTS", dict(DEFAULT_CFG)["FACTOR_WEIGHTS"])
    pos_total_def  = sum(v for v in default_fw.values() if v > 0)
    # B05/B12-fix: was sum(blended.values()) which included structurally-negative risk
    # factors (z_ann_vol, z_downside_vol). In bear markets blended_total could be a small
    # negative, causing scale to flip sign and corrupt ALL weights.
    # Must sum only positive IC values — mirrors how pos_total_def is computed.
    blended_total  = sum(v for v in blended.values() if v > 0) or 1.0
    scale          = pos_total_def / blended_total  # DIV001: guard divisor before use

    calibrated = {}
    for fname, ic_ir in blended.items():
        default_abs = abs(default_fw.get(fname, 0.05))
        raw_w       = ic_ir * scale
        # AUDIT-FIX (Round 3, P2-3): removed the 3x default_abs weight cap.
        # The audit flagged this as one of the four clamps that mask the very
        # signal the IC analysis is meant to surface - capping at 3x default
        # means a factor with 10x default IC-IR is silently downweighted to
        # 3x default, hiding its statistical strength. The lower bound (0.0)
        # stays (negative weights are nonsensical for a long-only portfolio);
        # the upper bound is removed so the IC-IR scaling passes through
        # untouched.
        calibrated[fname] = float(max(0.0, raw_w))

    # keep negative risk-penalty factors from defaults unchanged
    for k, v in default_fw.items():
        if k not in calibrated:
            calibrated[k] = v

    # --- 7: persist updated history -----------------------------------------
    # B08-fix: was executed BEFORE step 6 (normalise). History is now persisted
    # after calibration is complete — if step 6 raises, no partial state is written.
    try:
        FACTOR_IC_CACHE_PATH.write_text(json.dumps(history, indent=2))
    except Exception as _e2_:
        log_emit(log_cb, f"[IC-Learn] ⚠️ Failed to persist IC history to cache: {_e2_!r}")
        ExceptionLogger.swallow(_e2_, context="ic_cache_write_failure")

    top5 = sorted(calibrated.items(), key=lambda x: -abs(x[1]))[:5]
    log_emit(log_cb, f"[IC-Learn] Calibrated {len(ic_ir_now)} factors. "
                    f"Top: {', '.join(f'{k}:{v:.3f}' for k,v in top5)}")
    # C3-fix: Bear-mode weight mutation is already applied downstream in factor normalization.
    # Commenting out here to prevent double-tilting of factor weights.
    # if _bear_mode:
    #     for _mk in ('z_mom_1m','z_mom_3m','z_mom_6m','z_mom_12_1','z_trend_20','z_trend_50'):
    #         if _mk in calibrated: calibrated[_mk] = round(calibrated[_mk] * 0.60, 4)
    #     for _qk in ('z_roe','z_pe_inv','z_drawdown','z_ann_vol','z_downside_vol'):
    #         if _qk in calibrated: calibrated[_qk] = round(calibrated[_qk] * 1.35, 4)
    #     log_emit(log_cb, f'[IC-Learn] BearTilt applied — {len(calibrated)} factors calibrated from history')
    if return_details:
        return {
            "weights": calibrated,
            "ic_scores": dict(ic_ir_now),
            "history_scores": dict(blended),
            "used_defaults": False,
        }
    return calibrated



# ────────────────────────────────────────────────────────────────────
# FUNC: generate_smallcase_basket
# ────────────────────────────────────────────────────────────────────


# ═══════════════════════════════════════════════════════════════════════════════
# v15 ENHANCEMENTS
# ═══════════════════════════════════════════════════════════════════════════════

# ── NSE Delivery Volume Signal ───────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: calculate_kelly_weights
# ────────────────────────────────────────────────────────────────────


# ── SEBI Category Classification ─────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: solve_mip_selection
# ────────────────────────────────────────────────────────────────────
def solve_mip_selection(signal_df, sectors, cfg, log_cb=None):
    """I3-fix: Classical Mixed-Integer Programming stock selector.
    Uses scipy.optimize.milp (scipy >= 1.8) to maximise weighted alpha
    subject to cardinality, sector and weight constraints.
    Exact and deterministic — no annealing heuristic, typically <100ms
    for a 500-stock universe picking 15.
    Falls back to greedy ranking if scipy.milp is unavailable.

    AUDIT-FIX (defect #P0-7): the prior implementation silently treated the
    sentinel string "N/A" as a sector with no cap — so when an NSE sector
    fetch failed and `data_layer.fetch_sectors` cached "N/A" for a ticker,
    that ticker could pile into the selected list without limit, silently
    disabling the SEBI sector-concentration cap for the affected universe.
    We now (a) bucket all "N/A" tickers into a pseudo-sector "UNKNOWN"
    that IS subject to the same `max_sector` cap, and (b) emit a SEBI
    compliance warning when unresolved sectors exceed 5% of the post-screen
    universe.
    """
    import numpy as np
    stocks      = list(signal_df.index)
    k           = int(cfg.get("K_STOCKS", 8))
    _prescreen_sec_on = cfg.get("ENABLE_SECTOR_CAP", False)
    max_sector  = int(cfg.get("MAX_PER_SECTOR", 0)) if _prescreen_sec_on else 0
    alphas      = np.array([float(signal_df.loc[s, "alpha_score"])
                            if pd.notna(signal_df.loc[s, "alpha_score"]) else 0.0
                            for s in stocks], dtype=np.float64)

    # AUDIT-FIX (defect #P0-7): normalize "N/A" / None / empty to "UNKNOWN"
    # so the cap-iteration logic cannot bypass these tickers.
    _NA_SECTOR_VALUES = {"N/A", "NA", "n/a", "na", "", None, "None", "null"}
    def _norm_sec(s_val):
        if s_val in _NA_SECTOR_VALUES or (isinstance(s_val, str) and not s_val.strip()):
            return "UNKNOWN"
        return s_val
    # Count unresolved sectors for the SEBI compliance warning.
    _n_unresolved = sum(1 for s in stocks if sectors.get(s, "N/A") in _NA_SECTOR_VALUES)
    if max_sector > 0 and _n_unresolved > 0:
        _pct_unresolved = _n_unresolved / max(len(stocks), 1) * 100.0
        if _pct_unresolved > 5.0:
            log_emit(log_cb, (
                f"[SEBI] ⚠️ WARNING — {_n_unresolved}/{len(stocks)} tickers ({_pct_unresolved:.1f}%) "
                "have unresolved sectors (NSE fetch failed and cached 'N/A'). They will be "
                "bucketed into the 'UNKNOWN' pseudo-sector and capped at max_sector — but "
                "the SEBI concentration guardrail is degraded until the fetch succeeds."
            ))

    # --- greedy baseline (always available) ---
    sector_cnt: dict = {}
    greedy = []
    for s in [stocks[i] for i in np.argsort(-alphas)]:
        sec = _norm_sec(sectors.get(s, "N/A"))
        # AUDIT-FIX (defect #P0-7): "UNKNOWN" is now subject to the cap, so
        # unresolved-sector tickers cannot pile past max_sector.
        if max_sector > 0 and sector_cnt.get(sec, 0) >= max_sector:
            continue
        greedy.append(s)
        sector_cnt[sec] = sector_cnt.get(sec, 0) + 1
        if len(greedy) == k:
            break
    if len(greedy) < k:
        for s in stocks:
            if s not in greedy:
                greedy.append(s)
            if len(greedy) == k:
                break

    try:
        from scipy.optimize import milp, LinearConstraint, Bounds
        n = len(stocks)

        # Bug 17 fix: add vol penalty — pure alpha max produces sector concentration.
        _vols17 = np.array([float(signal_df.loc[s,"ann_vol"]) if "ann_vol" in signal_df.columns
            and pd.notna(signal_df.loc[s,"ann_vol"]) else 0.20 for s in stocks], dtype=np.float64)
        c = -alphas + float(cfg.get("VOL_PENALTY", 0.15)) * _vols17

        # Constraint 1: exactly K stocks selected
        A_card = np.ones((1, n), dtype=np.float64)
        c_card = LinearConstraint(A_card, lb=k, ub=k)

        # Constraint 2: per-sector caps
        # AUDIT-FIX (defect #P0-7): "UNKNOWN" is now a real pseudo-sector
        # subject to the cap. The prior code explicitly removed "N/A" from
        # the set — so N/A tickers had NO sector constraint row in the LP
        # and could be selected without limit.
        unique_sectors = list({_norm_sec(sectors.get(s, "N/A")) for s in stocks})
        A_sec_rows = []
        for sec in unique_sectors:
            row = np.array([1.0 if _norm_sec(sectors.get(s, "N/A")) == sec else 0.0
                            for s in stocks], dtype=np.float64)
            A_sec_rows.append(row)
        constraints = [c_card]
        if A_sec_rows and max_sector > 0:
            A_sec = np.vstack(A_sec_rows)
            c_sec = LinearConstraint(A_sec,
                                     lb=np.zeros(len(A_sec_rows)),
                                     ub=np.full(len(A_sec_rows), max_sector, dtype=np.float64))
            constraints.append(c_sec)

        bounds     = Bounds(lb=np.zeros(n), ub=np.ones(n))
        integrality = np.ones(n)   # all binary

        res = milp(c, constraints=constraints, integrality=integrality, bounds=bounds,
                   options={"disp": False, "time_limit": 10.0})

        if res.success:
            selected = [stocks[i] for i in range(n) if res.x[i] > 0.5]
            if len(selected) == k:
                log_emit(log_cb, f"[MIP] Exact solver selected {k} stocks "
                                 f"(obj={-res.fun:.4f}, {len(unique_sectors)} sector caps)")
                return selected, float(-res.fun), "MIP"
            log_emit(log_cb, f"[MIP] Solver returned {len(selected)} ≠ {k} — falling back to greedy")
        else:
            log_emit(log_cb, f"[MIP] Solver status: {res.message} — falling back to greedy")
    except ImportError as _e:
        log_emit(log_cb, "[MIP] scipy.optimize.milp not available (scipy < 1.8) — using greedy ranking")
    except Exception as e:
        log_emit(log_cb, f"[MIP] Unexpected error: {e} — using greedy ranking")

    energy = float(-alphas[[stocks.index(s) for s in greedy]].sum())
    log_emit(log_cb, f"[MIP-Greedy] Selected {len(greedy)} stocks (alpha_sum={-energy:.4f})")
    return greedy, energy, "greedy_ranking"







# ── NSE Options IV Signal ─────────────────────────────────────────────────────
# B07-fix: Historical ATM IV is stored per-ticker in a rolling JSON cache so that
# IVR = (today_ATM_IV − 252d_min) / (252d_max − 252d_min), matching the standard
# definition. The old code used the cross-strike IV range on a single day, which
# was always near 0.5 regardless of the actual volatility regime.
_IV_HISTORY_CACHE_PATH = RUNTIME_DIR / "atm_iv_history_cache.json"
_IV_HISTORY_MAX_DAYS   = 260   # slightly more than 252 trading days



# ────────────────────────────────────────────────────────────────────
# FUNC: split_backtest_by_regime
# ────────────────────────────────────────────────────────────────────
def split_backtest_by_regime(equity_curve: pd.Series, benchmark_returns: pd.Series,
                              log_cb=None) -> pd.DataFrame:
    """
    Split WFO equity curve into Bull/Bear/Neutral sub-periods using benchmark
    50-day EMA trend. Report Sharpe/return/drawdown for each regime.
    """
    if equity_curve is None or len(equity_curve) < 60:
        return pd.DataFrame()

    port_rets = equity_curve.pct_change().dropna()
    bench = benchmark_returns.reindex(port_rets.index).fillna(0)

    # Regime: bull = bench 50d EMA trending up, bear = down, neutral = flat
    bench_price = (1 + bench).cumprod()
    ema50 = bench_price.ewm(span=50, adjust=False).mean()
    trend = bench_price / ema50 - 1.0  # DIV001: guard divisor before use
    regime_series = pd.Series("Neutral", index=port_rets.index)
    regime_series[trend > 0.01]  = "Bull"
    regime_series[trend < -0.01] = "Bear"

    rows = []
    for regime in ["Bull", "Bear", "Neutral"]:
        mask = regime_series == regime
        r = port_rets[mask]
        if len(r) < 10:
            continue
        ann_ret = float((1 + r).prod() ** (float(TRADING_DAYS_PER_YEAR) / len(r)) - 1) if len(r) > 0 else np.nan
        vol     = float(r.std() * np.sqrt(TRADING_DAYS_PER_YEAR))
        sharpe  = ann_ret / vol if vol > 1e-9 else np.nan  # DIV001: guard divisor before use
        eq_seg  = (1 + r).cumprod()
        peak    = eq_seg.expanding().max()
        max_dd  = float((eq_seg / (peak + 1e-9) - 1).min())
        rows.append({
            "Regime": regime, "Days": len(r),
            "Ann Return": f"{ann_ret*100:.1f}%", "Volatility": f"{vol*100:.1f}%",
            "Sharpe": f"{sharpe:.2f}", "Max DD": f"{max_dd*100:.1f}%",
            "Win Rate": f"{(r > 0).mean()*100:.0f}%",
        })
    if rows:
        log_emit(log_cb, f"[RegimeBT] Bull/Bear/Neutral split complete ({len(rows)} regimes)")
    return pd.DataFrame(rows)


# ── Multi-Sheet Excel Export ──────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: export_to_excel
# ────────────────────────────────────────────────────────────────────
def export_to_excel(payload: dict, filepath: str, log_cb=None) -> bool:
    """
    Export full run results as multi-sheet Excel workbook.
    Sheets: Portfolio, Universe, Factor Scores, Backtest, Risk, Diagnostics,
            Kite Orders, Alpha Decay, Monte Carlo, Regime Backtest.
    Uses openpyxl with conditional formatting for alpha/risk score columns.
    """
    try:
        import openpyxl
        from openpyxl.styles import PatternFill, Font, Alignment
        from openpyxl.utils.dataframe import dataframe_to_rows
    except ImportError as _e:
        log_emit(log_cb, "[Excel] openpyxl not installed. Run: pip install openpyxl", exc_info=True)
        return False

    wb = openpyxl.Workbook()
    wb.remove(wb.active)

    green_fill = PatternFill("solid", fgColor="C6EFCE")
    red_fill   = PatternFill("solid", fgColor="FFC7CE")
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill("solid", fgColor="1F4E79")

    def _write_sheet(wb, name, df):
        if df is None or (isinstance(df, pd.DataFrame) and df.empty):
            return
        ws = wb.create_sheet(title=name[:31])
        for r_idx, row in enumerate(dataframe_to_rows(df, index=False, header=True), 1):
            for c_idx, val in enumerate(row, 1):
                cell = ws.cell(row=r_idx, column=c_idx, value=val)
                if r_idx == 1:
                    cell.font = header_font
                    cell.fill = header_fill
                    cell.alignment = Alignment(horizontal="center")
        # Auto-width
        for col in ws.columns:
            max_len = max((len(str(cell.value or "")) for cell in col), default=10)
            ws.column_dimensions[col[0].column_letter].width = min(max_len + 2, 40)
        return ws

    sheet_map = {
        "Portfolio":     payload.get("portfolio_df"),
        "Factor Scores": payload.get("signal_df_export"),
        "Diagnostics":   payload.get("diagnostics_df"),
        "Kite Orders":   payload.get("kite_df"),
        "Alpha Decay":   payload.get("alpha_decay_df"),
    }
    if payload.get("backtest"):
        bt = payload["backtest"]
        bt_rows = [{"Metric": k, "Value": v} for k, v in bt.items()
                   if k not in ("Equity Curve", "monte_carlo")]
        sheet_map["Backtest"] = pd.DataFrame(bt_rows)
        mc = bt.get("monte_carlo", {})
        if mc and mc.get("mc_df") is not None:
            sheet_map["Monte Carlo"] = mc["mc_df"]
    if payload.get("regime_bt_df") is not None:
        sheet_map["Regime Backtest"] = payload["regime_bt_df"]
    if payload.get("alerts_df") is not None:
        sheet_map["Alerts"] = payload["alerts_df"]
    if payload.get("post_trade_df") is not None:
        sheet_map["Post-Trade IC"] = payload["post_trade_df"]

    for sheet_name, df in sheet_map.items():
        if df is not None and not (isinstance(df, pd.DataFrame) and df.empty):
            _write_sheet(wb, sheet_name, df if isinstance(df, pd.DataFrame) else pd.DataFrame(df))

    try:
        wb.save(filepath)
        log_emit(log_cb, f"[Excel] Exported to {filepath} ({len(wb.sheetnames)} sheets)")
        return True
    except Exception as e:
        log_emit(log_cb, f"[Excel] Save failed: {e}", exc_info=True)
        return False


# ── Telegram Notification ─────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: send_telegram_notification
# ────────────────────────────────────────────────────────────────────
def send_telegram_notification(payload: dict, cfg: dict, log_cb=None) -> bool:
    """
    Send portfolio summary via Telegram bot after run completes.
    Setup: create a bot via @BotFather, get token + chat_id.
    Configure TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID in settings.
    """
    if not cfg.get("TELEGRAM_ENABLED", False):
        return False
    token   = str(cfg.get("TELEGRAM_BOT_TOKEN", "")).strip()
    chat_id = str(cfg.get("TELEGRAM_CHAT_ID", "")).strip()
    if not token or not chat_id:
        return False
    # ── Throttle: skip if same portfolio sent recently ─────
    _tg_key = f"{cfg.get('FACTOR_MODEL', 'Default')}:{str(sorted((payload.get('selected') or [])[:8]))[:80]}"
    _cooldown = int(cfg.get("ALERT_COOLDOWN_SECONDS", 300))
    if not _ALERT_THROTTLE.should_send_and_record(_tg_key, _cooldown):
        if log_cb: log_cb("[Telegram] Throttled — duplicate alert skipped.")
        return False

    portfolio_df = payload.get("portfolio_df")  # always use live payload, not stale CSV
    backtest     = payload.get("backtest", {}) or {}
    fii_signal   = payload.get("fii_dii_signal", {}) or {}
    vix          = payload.get("india_vix", float("nan"))

    if portfolio_df is None or portfolio_df.empty:
        return False

    df_sorted = portfolio_df.sort_values("Weight %", ascending=False).reset_index(drop=True)  # Native order

    lines = [
        f"🤖 *QUBO Portfolio Engine v{APP_VERSION}*",
        f"📅 {datetime.now().strftime('%d %b %Y %H:%M')} IST",
        "",
        f"📊 *Portfolio ({len(df_sorted)} stocks)*",
    ]
    for _, row in df_sorted.iterrows():
        t = str(row.get("Ticker", row.get("ticker", ""))).replace(".NS", "")
        w = float(row.get("Weight %", row.get("Weight", row.get("weight", 0))) or 0)
        w_pct = w * 100 if w <= 1.0 else w
        if t.upper() == "CASH":
            lines.append(f"  • *CASH Reserve*: {w_pct:.1f}%")
            continue

        buy_px = float(row.get("BuyPrice", np.nan))
        tp_px  = float(row.get("Target", np.nan))
        sl_px  = float(row.get("StopLoss", np.nan))

        stock_line = f"  • *{t}*: {w_pct:.1f}% allocation"
        if pd.notna(buy_px) and buy_px > 0:
            stock_line += f"\n    └ Entry: ₹{buy_px:.2f}"
            if pd.notna(tp_px): stock_line += f" | Target: ₹{tp_px:.2f} (+{((tp_px/buy_px)-1)*100:.1f}%)"
            if pd.notna(sl_px): stock_line += f" | StopLoss: ₹{sl_px:.2f} (-{(1-(sl_px/buy_px))*100:.1f}%)"
        lines.append(stock_line)
    lines.append("")

    def _pct(v):
        try:
            fv = float(v)
            return "—" if (fv != fv) else f"{fv*100:.1f}%"
        except Exception as _e:
            return "—" if v is None else str(v)
    def _num(v):
        try:
            fv = float(v)
            return "—" if (fv != fv) else f"{fv:.2f}"
        except Exception as _e:
            return "—" if v is None else str(v)
    if backtest:
        lines.append(
            f"📈 *Backtest* | Ann Ret: {_pct(backtest.get('Annual Return'))} | "
            f"Sharpe: {_num(backtest.get('Sharpe'))} | "
            f"MaxDD: {_pct(backtest.get('Max Drawdown'))} | "
            f"Sortino: {_num(backtest.get('Sortino'))}"
        )
    else:
        lines.append("📈 *Backtest*: OFF — enable \"OOS Backtest\" in Settings → Run Config")

    try:
        v = float(vix)
        if not pd.isna(v):
            emoji = "🟢" if v < 15 else ("🟡" if v < 20 else "🔴")
            lines.append(f"{emoji} *India VIX*: {v:.1f}")
    except Exception as _e:  # safe: optional SQLite history write is non-fatal
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception in %s", "Exception", exc_info=True)  # noqa: E501
        pass  # intentional — see comment above

    if fii_signal and fii_signal.get("flow_signal"):
        sig  = fii_signal.get("flow_signal", "—")
        z    = float(fii_signal.get("fii_z_score", 0) or 0)
        f10  = fii_signal.get("fii_10d_net")
        d10  = fii_signal.get("dii_10d_net")
        em   = "🟢" if sig == "Bull" else ("🔴" if sig == "Bear" else "⚪")
        fii_line = f"{em} *FII Flow*: {sig} (z={z:.2f})"
        def _cr(v):
            try:
                fv = float(v)
                return None if (fv != fv) else f"\u20b9{fv:,.0f}Cr"   # fv!=fv catches NaN
            except Exception as _e:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception in %s", "Exception", exc_info=True)  # noqa: E501
                return None
        f10_s = _cr(f10); d10_s = _cr(d10)
        if f10_s: fii_line += f" | FII {f10_s}"
        if d10_s: fii_line += f" | DII {d10_s}"
        lines.append(fii_line)

    message = "\n".join(lines)
    try:
        from utils import TelegramNotifier
        ok = TelegramNotifier.send_message(
            bot_token=token, chat_id=chat_id, text=message,
            parse_mode="Markdown", timeout=10, log_cb=log_cb
        )
        if ok:
            log_emit(log_cb, "[Telegram] Notification sent ✅")
            return True
        else:
            _ALERT_THROTTLE.clear(_tg_key)
            log_emit(log_cb, "[Telegram] Notification delivery failed.")
            return False
    except Exception as e:
        _ALERT_THROTTLE.clear(_tg_key)
        log_emit(log_cb, f"[Telegram] Error: {e}", exc_info=True)
    return False


# ═══════════════════════════════════════════════════════════════════════════════
# v17 ENHANCEMENTS
# ═══════════════════════════════════════════════════════════════════════════════

# ── F&O Open Interest Buildup Signal ─────────────────────────────────────────


# NOTE (AUDIT-FIX Round 5 P1-B): The following three functions were previously
# defined inline here as duplicates of the extracted-module versions:
#   - compute_marginal_risk_contribution  (now in optimizer_risk.py)
#   - apply_turnover_qubo_constraint      (now in optimizer_compliance.py)
#   - get_tax_aware_turnover_cost          (now in optimizer_compliance.py)
# The local definitions have been removed; the re-exports at the top of this
# file (`from optimizer_risk import *` / `from optimizer_compliance import *`)
# now bind these names to the canonical extracted-module versions, which
# preserve the original signatures and bodies for 100% backward compatibility.


# ────────────────────────────────────────────────────────────────────
# FUNC: hrp_weights
# ────────────────────────────────────────────────────────────────────
def hrp_weights(selected, returns: pd.DataFrame = None, cfg: dict = None) -> dict:
    """True Hierarchical Risk Parity (Lopez de Prado 2016).
    Uses scipy hierarchical clustering on correlation distance matrix,
    then bisects the dendrogram recursively to assign inverse-variance weights.
    Falls back to equal weight if scipy or sufficient data are unavailable.
    Natively supports Marchenko-Pastur Denoising and Ledoit-Wolf/OAS shrinkage estimators."""
    if isinstance(selected, pd.DataFrame) and returns is None:
        returns = selected
        selected = list(returns.columns)
    if not selected:
        return {}
    if len(selected) < 3:
        return {s: 1.0 / len(selected) for s in selected} if selected else {}
    try:
        from scipy.cluster.hierarchy import linkage, to_tree
        _safe_sel = [c for c in selected if c in returns.columns] if returns is not None else []
        if len(_safe_sel) < 3:
            return {s: 1.0 / len(selected) for s in selected} if selected else {}
        ret_sub = returns[_safe_sel].fillna(0)
        if ret_sub.shape[0] < 20:
            return {s: 1.0 / len(selected) for s in selected} if selected else {}
        
        # Early exit: detect structurally identical assets using raw pairwise
        # correlation (before any shrinkage applied by build_correlation_matrix).
        # If all off-diagonal distances are negligible, the HRP dendrogram bisection
        # is driven by floating-point noise rather than risk structure, so equal
        # weights are returned directly.
        _raw_corr = ret_sub.corr().values
        _raw_dist = np.sqrt(np.clip((1.0 - _raw_corr) / 2.0, 0.0, 1.0))
        _ut_raw = _raw_dist[np.triu_indices(len(selected), k=1)]
        if float(_ut_raw.max()) < 1e-3:
            return {s: 1.0 / len(selected) for s in selected}

        # 1. Elegant cross-module risk-model alignment
        method = (cfg or {}).get("RISK_MODEL", "Ledoit-Wolf")
        corr_df = build_correlation_matrix(ret_sub, method=method, cfg=cfg)
        corr = corr_df.values
        
        # 2. Volatility scaling to reconstruct the denoised/shrunk covariance matrix
        cov_raw = ret_sub.cov().values
        vols = np.sqrt(np.maximum(np.diag(cov_raw), 1e-12))
        cov_denoised = np.outer(vols, vols) * corr
        
        # 3. Correlation distance matrix calculation
        dist = np.sqrt(np.clip((1.0 - corr) / 2.0, 0.0, 1.0))
        n = len(selected)

        # Upper-triangle distances for scipy linkage
        ut = dist[np.triu_indices(n, k=1)]
        _hrp_method = "ward" if len(selected) >= 15 else "average"
        link = linkage(ut, method=_hrp_method)
        root, node_list = to_tree(link, rd=True)
        
        # Recursive bisection using the denoised covariance sub-matrices
        def _get_cluster_var(idxs):
            sub_cov = cov_denoised[np.ix_(idxs, idxs)]
            w_iv = 1.0 / np.maximum(np.diag(sub_cov), 1e-12)
            w_iv /= w_iv.sum()
            return float(w_iv @ sub_cov @ w_iv)
            
        def _hrp_recurse(node, alloc):
            if node.is_leaf():
                return {node.id: alloc}
            left_ids  = node.left.pre_order()
            right_ids = node.right.pre_order()
            var_l = _get_cluster_var(left_ids)
            var_r = _get_cluster_var(right_ids)
            total = var_l + var_r + 1e-12
            split = (var_r / total) if total != 0 else 0.5  # DIV001 guarded
            result = {}
            result.update(_hrp_recurse(node.left,  alloc * split))
            result.update(_hrp_recurse(node.right, alloc * (1.0 - split)))
            return result
            
        raw = _hrp_recurse(root, 1.0)
        # raw keys are column positions, map back to ticker names
        weights = {selected[i]: raw.get(i, 1.0 / n) for i in range(n)}  # DIV001: guard divisor before use
        total = sum(weights.values()) or 1.0
        return {k: v / total for k, v in weights.items()}  # DIV001: guard divisor before use
    except Exception as _e:
        # Graceful fallback — equal weight
        return {s: 1.0 / len(selected) for s in selected} if selected else {}




# ────────────────────────────────────────────────────────────────────
# FUNC: black_litterman_weights
# ────────────────────────────────────────────────────────────────────
def black_litterman_weights(selected: list, signal_df: pd.DataFrame, returns: pd.DataFrame, cfg: dict = None) -> dict:
    """
    Black-Litterman posterior allocation using current alpha as relative views.
    Falls back gracefully to alpha-proportional weights when history is insufficient.
    """
    if not selected:
        return {}
    fallback_cfg = {"MIN_WEIGHT": 0.0, "MAX_WEIGHT": 1.0}
    if signal_df is None or "alpha_score" not in signal_df.columns:
        return {s: 1.0 / len(selected) for s in selected} if selected else {}
    try:
        _safe_sel = [c for c in selected if c in returns.columns] if returns is not None else []
        if len(_safe_sel) < 2:
            return compute_alpha_proportional_weights(selected, signal_df, fallback_cfg)
        ret_sub = returns[_safe_sel].dropna(how="all").fillna(0.0)
        if ret_sub.shape[0] < 40 or ret_sub.shape[1] != len(selected):
            return compute_alpha_proportional_weights(selected, signal_df, fallback_cfg)

        # A1 WIRING: DCC-GARCH dynamic covariance (Tier-A institutional upgrade)
        # cfg["USE_DCC_GARCH"] = True activates; sample-cov fallback always available.
        if (cfg or {}).get("USE_DCC_GARCH", False):
            try:
                from math_engine.dcc_garch import get_dcc_covariance as _dcc_cov_bl
                cov = _dcc_cov_bl(ret_sub, cfg=cfg)
                log_emit(None, "[BL+DCC] Using DCC-GARCH dynamic covariance")
            except Exception as _dcc_bl_err:
                log_emit(None, f"[BL+DCC] DCC fallback to sample cov: {_dcc_bl_err}")
                cov = ret_sub.cov().values * 252.0
        else:
            cov = ret_sub.cov().values * 252.0
        cov = cov + np.eye(len(selected)) * 1e-6
        # Phase 3.5: BL prior must be market-cap weights. Using inv-vol weights as
        # "market weights" produces a prior where low-vol stocks get huge implied
        # returns — the OPPOSITE of the equilibrium relationship. Since we don't
        # have market-cap data here, use equal weights with a warning (mathematically
        # neutral — the views drive the posterior). This is better than inv-vol which
        # actively biases the prior.
        log_emit(None, "[BL] Phase 3.5: Using equal-weight prior (market-cap unavailable). "
                  "Inv-vol prior was mathematically incorrect — it biased the equilibrium.")
        market_w = np.ones(len(selected), dtype=float) / len(selected)

        risk_aversion = 2.5
        tau = 0.05
        pi = risk_aversion * cov @ market_w

        # Map ±1 std → ±BL_ALPHA_VIEW_SPREAD (default ±12% p.a.)
        _alpha_raw29 = np.array([
            float(signal_df.loc[s, "alpha_score"]) if s in signal_df.index and pd.notna(signal_df.loc[s, "alpha_score"]) else 0.0
            for s in selected], dtype=float)
        _alpha_raw29 -= _alpha_raw29.mean()
        if np.allclose(_alpha_raw29, 0.0):
            return {s: float(market_w[i]) for i, s in enumerate(selected)}
        
        _vspread29 = float(cfg.get("BL_ALPHA_VIEW_SPREAD", 0.12)) if cfg else 0.12
        # Volatility-scaled views calibration (institutional-grade)
        vols = np.array([
            max(float(ret_sub[s].std() * np.sqrt(TRADING_DAYS_PER_YEAR)), 0.05) if s in ret_sub.columns else 0.20 for s in selected
        ], dtype=float)
        
        alpha_views = _alpha_raw29 * vols * _vspread29
        q = alpha_views
        p = np.eye(len(selected))
        # WIRING: Idzorek BL
        _bl_method = (cfg or {}).get("BL_METHOD", "standard").lower()
        if _bl_method == "idzorek":
            try:
                from math_engine.idzorek_bl import idzorek_black_litterman
                _confidences = [min(0.95, max(0.05, abs(float(signal_df.loc[s, "alpha_score"])) * 2.0)) if s in signal_df.index and pd.notna(signal_df.loc[s, "alpha_score"]) else 0.5 for s in selected]
                post_mean = idzorek_black_litterman(market_w, cov, p, q, _confidences, risk_aversion, tau)
                log_emit(None, "[BL] Idzorek confidence-weighted BL applied")
            except Exception:
                omega = np.diag(np.maximum(np.diag(tau * cov) * 0.25, 1e-6))
                tau_cov_inv = np.linalg.pinv(tau * cov)
                omega_inv = np.linalg.pinv(omega)
                post_cov = np.linalg.pinv(tau_cov_inv + p.T @ omega_inv @ p)
                post_mean = post_cov @ (tau_cov_inv @ pi + p.T @ omega_inv @ q)
        else:
            omega = np.diag(np.maximum(np.diag(tau * cov) * 0.25, 1e-6))
            tau_cov_inv = np.linalg.pinv(tau * cov)
            omega_inv = np.linalg.pinv(omega)
            post_cov = np.linalg.pinv(tau_cov_inv + p.T @ omega_inv @ p)
            post_mean = post_cov @ (tau_cov_inv @ pi + p.T @ omega_inv @ q)

        raw_pos = np.maximum(post_mean, 0.0)
        if np.sum(raw_pos) <= 1e-12:
            return compute_alpha_proportional_weights(selected, signal_df, fallback_cfg)
        weights = _project_weights_to_bounds(raw_pos, lower=0.0, upper=1.0)
        return {s: float(weights[i]) for i, s in enumerate(selected)}
    except Exception as _e:
        return compute_alpha_proportional_weights(selected, signal_df, fallback_cfg)



# ────────────────────────────────────────────────────────────────────
# FUNC: compute_mdp_weights
# ────────────────────────────────────────────────────────────────────
def compute_mdp_weights(selected: list, returns: pd.DataFrame) -> dict:
    """
    Maximum Diversification Portfolio (Choueifat, 2008).
    Maximizes the Diversification Ratio:
        DR = (w' sigma_vec) / sqrt(w' Sigma w)
    where sigma_vec = vector of individual asset volatilities.
    Solved via iterative gradient ascent.
    """
    _safe_sel = [c for c in selected if c in returns.columns] if returns is not None else []
    if len(_safe_sel) < 2:
        return {s: 1.0 / len(selected) for s in selected} if selected else {}
    ret_sub = returns[_safe_sel].fillna(0)
    if ret_sub.shape[0] < 20:
        return {s: 1.0 / len(selected) for s in selected} if selected else {}
    # A1 WIRING: DCC-GARCH dynamic covariance for MDP (always-on; graceful fallback)
    try:
        from math_engine.dcc_garch import get_dcc_covariance as _dcc_cov_mdp
        cov = _dcc_cov_mdp(ret_sub)
    except Exception:
        cov = ret_sub.cov().values * 252
    sigma_vec = np.sqrt(np.maximum(np.diag(cov), 1e-12))
    n = len(selected)
    w = np.ones(n) / n  # DIV001: guard divisor before use
    lr = 0.01
    for _ in range(500):
        port_vol = float(np.sqrt(max(w @ cov @ w, 1e-12)))
        wtd_avg_vol = float(w @ sigma_vec)
        grad_num   = sigma_vec
        grad_denom = (cov @ w) / port_vol  # DIV001: guard divisor before use
        dr = wtd_avg_vol / port_vol  # DIV001: guard divisor before use
        grad = (grad_num / port_vol) - (dr * grad_denom / port_vol)  # DIV001: guard divisor before use
        w = w + lr * grad
        w = np.maximum(w, 1e-9)
        w = w / w.sum()
    return {selected[i]: float(w[i]) for i in range(n)}


# ── Factor Attribution ────────────────────────────────────────────────────────



# ────────────────────────────────────────────────────────────────────
# FUNC: compute_factor_ic_summary
# ────────────────────────────────────────────────────────────────────
def compute_factor_ic_summary(returns: pd.DataFrame, cfg: dict,
                               forward_days: int = 21, n_periods: int = 16,
                               log_cb=None) -> pd.DataFrame:
    """
    v17.3: Per-factor rolling IC dashboard.
    Computes Mean IC, Recent IC (last 4 periods), IC-IR, IC Decay, and Status
    (Strong / Active / Decaying / Dead / Corr-Dup) for every factor in FACTOR_WEIGHTS.
    Correlation pruning: flags factors correlated >0.70 with a higher-IC-IR factor.
    Returns DataFrame sorted by |IC-IR| descending.
    """
    import warnings; warnings.filterwarnings("ignore")
    tickers = list(returns.columns)
    n_rows  = len(returns)
    if n_rows < forward_days * 4 or len(tickers) < 4:
        return pd.DataFrame()

    factor_proxies = [
        ("z_mom_1m",       21,   1,  21),
        ("z_mom_3m",       63,   1,  42),
        ("z_mom_6m",       126,  1,  63),
        ("z_mom_12_1",     252,  1,  63),
        ("z_trend_20",     20,   1,  21),
        ("z_trend_50",     50,   1,  42),
        ("z_vol_surge",    10,   1,  21),
        ("z_rsi_pref",     14,   1,  21),
        ("z_adv20",        20,   1,  21),
        ("z_ann_vol",      63,  -1,  42),
        ("z_downside_vol", 63,  -1,  42),
        ("z_drawdown",     126, -1,  63),
    ]
    cum_ret  = returns.fillna(0).cumsum()
    rows     = []
    ic_ir_map = {}

    for fname, lb, sign, fwd_days in factor_proxies:
        try:
            fwd_ret = returns.rolling(fwd_days).sum().shift(-fwd_days)
            if "mom_12" in fname:
                proxy = (cum_ret.shift(21) - cum_ret.shift(TRADING_DAYS_PER_YEAR)) * sign
            elif fname in ("z_ann_vol", "z_downside_vol") or "drawdown" in fname:
                proxy = returns.rolling(lb).std() * sign
            else:
                proxy = (cum_ret - cum_ret.shift(lb)) * sign
            proxy_ranked = proxy.rank(axis=1, pct=True)
            ic_all = []
            for t in range(lb, n_rows - fwd_days, fwd_days):
                f_c = proxy_ranked.iloc[t]; r_c = fwd_ret.iloc[t]
                valid = f_c.notna() & r_c.notna()
                if valid.sum() < 6: continue
                ic, _ = _spearmanr_np(f_c[valid].values, r_c[valid].values)
                if pd.notna(ic): ic_all.append(float(ic))
            if len(ic_all) < 3: continue
            ic_recent = ic_all[-4:]
            mean_ic   = float(np.mean(ic_all))
            std_ic    = float(np.std(ic_all)) + 1e-6
            ic_ir     = mean_ic / std_ic  # DIV001: guard divisor before use
            recent_ic = (float(np.mean(ic_recent)) if len(ic_recent) > 0 else 0.0)
            ic_decay  = recent_ic - mean_ic
            ic_ir_map[fname] = ic_ir
            if   abs(ic_ir) < 0.20:   status = "Dead"
            elif ic_decay   < -0.04:  status = "Decaying"
            elif abs(ic_ir) >= 0.50:  status = "Strong"
            else:                      status = "Active"
            rows.append({"Factor": fname, "Mean IC": round(mean_ic,4),
                         "Recent IC": round(recent_ic,4), "IC-IR": round(ic_ir,3),
                         "IC Decay": round(ic_decay,4), "N Periods": len(ic_all),
                         "Status": status, "Corr-Dup": False})
        except Exception as e:
            log_emit(log_cb, f"[IC Summary] {fname}: {e}", exc_info=True)

    if not rows: return pd.DataFrame()
    df = pd.DataFrame(rows).sort_values("IC-IR", key=abs, ascending=False).reset_index(drop=True)

    # Correlation pruning
    try:
        ps = {}
        for fname, lb, sign, _ in factor_proxies:
            if fname not in df["Factor"].values: continue
            p = (cum_ret - cum_ret.shift(lb)) * sign if ("vol" not in fname and "drawdown" not in fname)                 else returns.rolling(lb).std() * sign
            ps[fname] = p.iloc[-1].fillna(0) if not p.empty else pd.Series(dtype=float)
        if len(ps) >= 3:
            ps_df  = pd.DataFrame(ps).dropna()
            if len(ps_df) >= 3:
                corr_m = ps_df.corr().abs()
                ranked = df["Factor"].tolist()
                pruned = set()
                for i, fa in enumerate(ranked):
                    if fa in pruned: continue
                    for fb in ranked[i+1:]:
                        if fb in pruned: continue
                        if fa in corr_m.columns and fb in corr_m.columns:
                            if corr_m.loc[fa, fb] > 0.80:
                                pruned.add(fb)
                df["Corr-Dup"] = df["Factor"].isin(pruned)
                df.loc[df["Corr-Dup"], "Status"] = "Corr-Dup"
    except Exception as _e:
        archlog.error('Exception detail', exc_info=True)  # LOG003 was traceback.print_exc()
        pass  # _arch_log removed (LOG003)

    df.insert(0, "Rank", range(1, len(df)+1))
    active = (df["Status"].isin(["Active","Strong"])).sum()
    log_emit(log_cb, f"[IC Summary] {len(df)} factors | Strong+Active:{active} | "
             f"Dead:{(df['Status']=='Dead').sum()} | Corr-Dup:{df['Corr-Dup'].sum()}")
    return df



# ────────────────────────────────────────────────────────────────────
# FUNC: sqlite_init
# ────────────────────────────────────────────────────────────────────



# ────────────────────────────────────────────────────────────────────
# FUNC: sqlite_save_run
# ────────────────────────────────────────────────────────────────────








def compute_watchlist_scores(watchlist_symbols: list, signal_df: pd.DataFrame,
                              log_cb=None, cfg=None) -> pd.DataFrame:
    """
    Score watchlist stocks using the current signal_df even if they were
    not selected by the optimizer. Lets the user monitor personal favourites.
    Returns a ranked table of alpha scores, factor scores, and selection status.
    """
    if not watchlist_symbols or signal_df is None or signal_df.empty:
        return pd.DataFrame()
    rows = []
    for t in watchlist_symbols:
        t = t.strip().upper()
        if not t.endswith(".NS"):
            t = t + ".NS"
        in_universe = t in signal_df.index
        row = {"Ticker": t, "In Universe": "✅" if in_universe else "❌"}
        if in_universe:
            s = signal_df.loc[t]
            row["Alpha Score"] = round(float(s.get("alpha_score", 0)), 4)
            row["Mom 6M %"]    = round(float(s.get("mom_6m",      0)) * 100, 2)
            row["Ann Vol %"]   = round(float(s.get("ann_vol",     0)) * 100, 2)
            row["RSI"]         = round(float(s.get("rsi",         50)), 1)
            row["Beta"]        = round(float(s.get("beta",         1)), 3)
            row["Delivery %"]  = round(float(s.get("delivery_pct", 0)) * 100, 1) if pd.notna(s.get("delivery_pct")) else None
            row["Chart Pattern Z"] = round(float(s.get("z_chart_pattern", 0)), 4) if pd.notna(s.get("z_chart_pattern")) else None
            row["Chart Novelty Z"] = round(float(s.get("z_chart_novelty", 0)), 4) if pd.notna(s.get("z_chart_novelty")) else None
            row["Chart Dispersion"] = round(float(s.get("chart_pattern_dispersion", 0)), 4) if pd.notna(s.get("chart_pattern_dispersion")) else None
            row["Chart Agreement"] = round(float(s.get("chart_cluster_agreement", 0)), 4) if pd.notna(s.get("chart_cluster_agreement")) else None
            row["Chart Cluster"] = int(s.get("chart_pattern_cluster", -1)) if pd.notna(s.get("chart_pattern_cluster")) else None
            row["Chart Calibrated Prob"] = round(float(s.get("chart_calibrated_prob", 0)), 4) if pd.notna(s.get("chart_calibrated_prob")) else None
            row["Chart Failed Breakout Risk"] = round(float(s.get("chart_failed_breakout_risk", 0)), 4) if pd.notna(s.get("chart_failed_breakout_risk")) else None
            
            # Speculative Physics Screener Metrics Integration
            try:
                from math_engine.relativistic_filter import RelativisticKalmanFilter
                if cfg is not None and "_CLOSE_DF" in cfg:
                    close_df = cfg["_CLOSE_DF"]
                    if t in close_df.columns:
                        px_history = close_df[t].dropna().values
                        if len(px_history) > 10:
                            rkf = RelativisticKalmanFilter(node_name="MoonNode", price_volatility=0.02)
                            for price in px_history:
                                rkf.update_with_delayed_measurement(price, delay_seconds=1.28)
                            row["Rel Price Prediction"] = round(float(rkf.x[0]), 2)
            except Exception:
                row["Rel Price Prediction"] = None

            try:
                from math_engine.spiking_synapse import SpikingPriceScreener
                if cfg is not None and "_CLOSE_DF" in cfg:
                    close_df = cfg["_CLOSE_DF"]
                    if t in close_df.columns:
                        px_history = close_df[t].dropna().values
                        if len(px_history) > 5:
                            screener = SpikingPriceScreener(n_inputs=3)
                            v_trace = screener.process_price_ticks(px_history)
                            spikes_count = sum(1 for i in range(1, len(v_trace)) if v_trace[i] == 0.0 and v_trace[i-1] > 0.0)
                            row["Spiking Score"] = spikes_count
            except Exception:
                row["Spiking Score"] = None

            try:
                from math_engine.spiking_synapse import VolumeSpikePulseFilter
                if cfg is not None and "_CLOSE_DF" in cfg and t in cfg["_CLOSE_DF"]:
                    v_res = VolumeSpikePulseFilter.compute_volume_intensity_pulse(cfg["_CLOSE_DF"][t])
                    row["Volume Pulse Surge"] = round(float(v_res.get("volume_surge_ratio", 1.0)), 2)
            except Exception:
                row["Volume Pulse Surge"] = None

            try:
                from math_engine.copula_risk import CopulaTailRiskScreener
                if cfg is not None and "_CLOSE_DF" in cfg:
                    close_df = cfg["_CLOSE_DF"]
                    if t in close_df.columns:
                        px_history = close_df[t].dropna().values
                        rets = np.diff(np.log(px_history)) if len(px_history) > 2 else np.zeros(1)
                        if len(rets) > 5:
                            res = CopulaTailRiskScreener.stress_test_portfolio_tail_risk(rets.reshape(-1, 1), np.array([1.0]), theta=2.5, n_simulations=100)
                            row["Copula Tail Risk"] = round(float(res.get("stress_scenario_expected_shortfall_95", 0.0)), 4)
            except Exception:
                row["Copula Tail Risk"] = None

            try:
                from math_engine.two_scale_realized_vol import TwoScaleRealizedVolatilityEngine
                if cfg is not None and "_CLOSE_DF" in cfg and t in cfg["_CLOSE_DF"]:
                    tsrv_res = TwoScaleRealizedVolatilityEngine.compute_tsrv(cfg["_CLOSE_DF"][t])
                    row["Two Scale Vol (TSRV)"] = round(float(tsrv_res.get("tsrv_annualized_vol", 0.20)), 4)
            except Exception:
                row["Two Scale Vol (TSRV)"] = None

            try:
                from math_engine.granger_causality import GrangerCausalityEngine
                if cfg is not None and "_CLOSE_DF" in cfg and t in cfg["_CLOSE_DF"]:
                    c_res = GrangerCausalityEngine.test_granger_causality(cfg["_CLOSE_DF"][t], cfg["_CLOSE_DF"][t].shift(1).fillna(0))
                    row["Granger Lead-Lag F-Stat"] = round(float(c_res.get("f_stat", 0.0)), 2)
            except Exception:
                row["Granger Lead-Lag F-Stat"] = None

            try:
                from math_engine.entropy_decay import ShannonInformationEntropyEngine
                if cfg is not None and "_CLOSE_DF" in cfg and t in cfg["_CLOSE_DF"]:
                    rets = cfg["_CLOSE_DF"][t].pct_change().dropna()
                    ent_val = ShannonInformationEntropyEngine.compute_shannon_return_entropy(rets)
                    row["Shannon Return Entropy"] = round(float(ent_val), 4)
            except Exception:
                row["Shannon Return Entropy"] = None

            try:
                from math_engine.cross_exchange_basis import CrossExchangeArbitrageEngine
                p_close = float(s.get("close", 100.0))
                arb_res = CrossExchangeArbitrageEngine.calculate_cross_exchange_basis(p_close, p_close * 1.001)
                row["Cross Exchange Basis (bps)"] = round(float(arb_res.get("gross_basis_bps", 0.0)), 2)
            except Exception:
                row["Cross Exchange Basis (bps)"] = None

            try:
                from math_engine.stationarity_filter import StationarityCointegrationValidator
                if cfg is not None and "_CLOSE_DF" in cfg and t in cfg["_CLOSE_DF"]:
                    adf_res = StationarityCointegrationValidator.test_stationarity_adf(cfg["_CLOSE_DF"][t])
                    row["ADF Stationarity p-value"] = round(float(adf_res.get("p_value", 1.0)), 4)
            except Exception:
                row["ADF Stationarity p-value"] = None

            try:
                from math_engine.hampel_outlier_filter import HampelOutlierFilter
                if cfg is not None and "_CLOSE_DF" in cfg and t in cfg["_CLOSE_DF"]:
                    clean_p, outliers = HampelOutlierFilter.filter_hampel_outliers(cfg["_CLOSE_DF"][t].values)
                    row["Hampel Outlier Count"] = int(len(outliers))
            except Exception:
                row["Hampel Outlier Count"] = 0

            try:
                from math_engine.signal_robust_scaler import SignalRobustScaler
                if cfg is not None and "_CLOSE_DF" in cfg and t in cfg["_CLOSE_DF"]:
                    z_clean = SignalRobustScaler.winsorize_zscore_signal(cfg["_CLOSE_DF"][t].values)
                    row["Robust MAD Z-Score"] = round(float(z_clean[-1]), 2)
            except Exception:
                row["Robust MAD Z-Score"] = None
        else:
            for col in ["Alpha Score", "Mom 6M %", "Ann Vol %", "RSI", "Beta", "Delivery %",
                        "Chart Pattern Z", "Chart Novelty Z", "Chart Dispersion", "Chart Agreement", "Chart Cluster",
                        "Chart Calibrated Prob", "Chart Failed Breakout Risk",
                        "Volume Pulse Surge", "Copula Tail Risk", "Two Scale Vol (TSRV)",
                        "Granger Lead-Lag F-Stat", "Shannon Return Entropy", "Cross Exchange Basis (bps)",
                        "ADF Stationarity p-value", "Hampel Outlier Count", "Robust MAD Z-Score"]:
                row[col] = None
        # AUDIT-FIX (defect #3): the prior code called rows.append(row) twice,
        # duplicating every watchlist row. The duplicate append has been removed.
        rows.append(row)
    if rows:
        df = pd.DataFrame(rows)
        if "Chart Pattern Z" in df.columns:
            df = df.sort_values(["In Universe", "Chart Pattern Z", "Alpha Score"], ascending=[False, False, False], na_position="last")
        log_emit(log_cb, f"[Watchlist] Scored {len(rows)} watchlist tickers")
        return df
    return pd.DataFrame()






def compute_per_stock_factor_contribution(signal_df: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    """
    Decompose each stock's alpha_score into component factor contributions.
    """
    if signal_df is None or signal_df.empty:
        return pd.DataFrame()
        
    fw = cfg.get("FACTOR_WEIGHTS", {})
    z_cols = [c for c in signal_df.columns if c.startswith("z_") and c in fw and fw[c] != 0]
    if not z_cols:
        return pd.DataFrame()
        
    rows = []
    for ticker, s in signal_df.iterrows():
        contribs = {}
        total_abs = 0.0
        for col in z_cols:
            val = float(s[col]) if pd.notna(s[col]) else 0.0
            c = fw[col] * val
            contribs[col] = c
            total_abs += abs(c)
            
        top_factors = sorted(contribs.items(), key=lambda x: -abs(x[1]))[:4]
        summary_str = " | ".join(f"{k.replace('z_','')}:{v:+.2f} ({abs(v)/(total_abs+1e-9)*100:.0f}%)" for k,v in top_factors)
        
        rows.append({
            "Ticker": ticker,
            "Alpha Score": round(float(s.get("alpha_score", 0)), 4),
            "Top Factor Drivers": summary_str,
        })
    return pd.DataFrame(rows)


# ── PDF Report Export ─────────────────────────────────────────────────────────
def export_pdf_report(payload: dict, cfg: dict, regime_info: dict,
                       filepath: str, log_cb=None) -> bool:
    """
    Export a professional single-page PDF report with:
    Portfolio table, key stats, equity curve (ASCII sparkline), regime, VIX.
    Uses reportlab if available, falls back to plain-text .txt report.
    """
    port_df  = payload.get("portfolio_df")
    bt       = payload.get("backtest") or {}
    vix      = payload.get("india_vix", float("nan"))
    diag_df  = payload.get("diagnostics_df")

    lines = []
    lines.append("=" * 70)
    lines.append(f"  Quantum Annealer Pro v17 — Portfolio Report")
    lines.append(f"  Generated: {datetime.now().strftime('%d %b %Y %H:%M IST')}")
    lines.append("=" * 70)
    lines.append(f"  Regime: {regime_info.get('Regime','N/A')}  |  "
                 f"VIX: {vix:.1f}" if not pd.isna(vix) else f"  Regime: {regime_info.get('Regime','N/A')}")
    lines.append("")
    lines.append("PORTFOLIO")
    lines.append("-" * 70)
    if port_df is not None and not port_df.empty:
        for col in ["Ticker", "Weight", "AlphaScore", "AnnVol", "Beta"]:
            if col not in port_df.columns and col.lower() in port_df.columns:
                port_df = port_df.rename(columns={col.lower(): col})
        for _, row in port_df.iterrows():
            t = str(row.get("Ticker", row.get("ticker", "")))
            # AUDIT-FIX (Round 6, B-P3-10): portfolio_df's column is "Weight %"
            # (set at portfolio_df construction, optimizer.py:6399); "Weight"/
            # "weight" lookups always missed → every PDF export printed
            # "Weight: " with no value. Read "Weight %" first and render the
            # fraction as a percent.
            _w_raw = row.get("Weight %", row.get("Weight", row.get("weight", "")))
            try:
                w = f"{float(_w_raw) * 100:.2f}%"
            except (TypeError, ValueError):
                w = str(_w_raw)
            a = str(row.get("AlphaScore", ""))
            lines.append(f"  {t:<18} Weight: {w:<8} Alpha: {a}")
    lines.append("")
    lines.append("BACKTEST SUMMARY")
    lines.append("-" * 70)
    if bt:
        for k, v in bt.items():
            if k not in ("Equity Curve", "monte_carlo", "Brinson Attribution") and v is not None:
                lines.append(f"  {k:<30} {v}")
        
        brinson = bt.get("Brinson Attribution")
        if brinson is not None and not brinson.empty:
            lines.append("")
            lines.append("SECTOR PERFORMANCE ATTRIBUTION (BRINSON-FACHLER)")
            lines.append("-" * 70)
            lines.append(f"  {'Sector':<20} | {'Alloc %':<10} | {'Select %':<10} | {'Interact %':<10} | {'Total %':<10}")
            lines.append("  " + "-" * 66)
            for _, row in brinson.iterrows():
                sec = str(row["Sector"])
                alloc = float(row["Allocation Effect %"])
                select = float(row["Selection Effect %"])
                interact = float(row["Interaction Effect %"])
                tot = float(row["Total Effect %"])
                lines.append(f"  {sec:<20} | {alloc:>10.4f} | {select:>10.4f} | {interact:>10.4f} | {tot:>10.4f}")
    lines.append("")
    lines.append("=" * 70)

    try:
        try:
            from reportlab.lib.pagesizes import A4
            from reportlab.pdfgen import canvas as rl_canvas
            c = rl_canvas.Canvas(filepath, pagesize=A4)
            c.setFont("Courier", 10)
            y = 800
            for line in lines:
                if y < 50:
                    c.showPage()
                    c.setFont("Courier", 10)
                    y = 800
                c.drawString(30, y, line[:100])
                y -= 14
            c.save()
            log_emit(log_cb, f"[PDF] Report exported to {filepath}")
            return True
        except ImportError as _e:
            txt_path = filepath.replace(".pdf", ".txt")
            with open(txt_path, "w", encoding="utf-8") as f:
                f.write("\n".join(lines))
            log_emit(log_cb, f"[PDF] reportlab not installed — saved as {txt_path}")
            return True
    except Exception as e:
        log_emit(log_cb, f"[PDF] Export failed: {e}", exc_info=True)
        return False


# ── APScheduler Auto-Run ──────────────────────────────────────────────────────
def start_scheduler(run_fn, cfg: dict, log_cb=None):
    """
    Schedule the optimizer to run automatically at market close (3:30 PM IST).
    Uses APScheduler BackgroundScheduler — non-blocking, runs in background thread.
    Only active if USE_APSCHEDULER=True.
    pip install apscheduler
    """
    try:
        from apscheduler.schedulers.background import BackgroundScheduler
        from apscheduler.triggers.cron import CronTrigger
        import pytz
        tz   = pytz.timezone("Asia/Kolkata")
        hour = int(cfg.get("SCHEDULER_HOUR", 15))
        minute = int(cfg.get("SCHEDULER_MINUTE", 35))
        sched = BackgroundScheduler(timezone=tz)
        sched.add_job(run_fn, CronTrigger(hour=hour, minute=minute, timezone=tz),
                      id="qa_daily_run", replace_existing=True)
        sched.start()
        log_emit(log_cb, f"[Scheduler] Auto-run enabled at {hour:02d}:{minute:02d} IST (weekdays)")
        return sched
    except ImportError as _e:
        log_emit(log_cb, "[Scheduler] apscheduler not installed. Run: pip install apscheduler pytz", exc_info=True)
        return None
    except Exception as e:
        log_emit(log_cb, f"[Scheduler] Failed to start: {e}", exc_info=True)
        return None


# ═══════════════════════════════════════════════════════════════════════════════
# v17 MISSING FEATURES: Dark Mode GUI, Zerodha Direct Placement,
#                       Position Reconciliation, Live P&L Tracker
# ═══════════════════════════════════════════════════════════════════════════════

# ── Dark Mode QSS ─────────────────────────────────────────────────────────────

DARK_MODE_QSS = r"""
/* ═══════════════════════════════════════════════════════════════════════════
   QUANTUM ANNEALER PRO — INSTITUTIONAL OBSIDIAN FINTECH THEME
   ───────────────────────────────────────────────────────────────────────────
   Palette:
     #080B10  window background (Deep Obsidian Slate)
     #0E141D  card / container surface
     #141C28  elevated hover surface
     #080B10  input background
     rgba(255, 255, 255, 0.08)  subtle border
     #00E5FF  primary accent (Cyber-Cyan Alpha Glow)
     #00E676  profit / success (Emerald Green)
     #FF5252  risk / loss (Crimson Red)
     #FFB300  warning (Amber)
     #F1F5F9  primary bright text
     #94A3B8  secondary muted text
     #64748B  tertiary muted text
   ═══════════════════════════════════════════════════════════════════════════ */
* { outline: none; }

/* ── BASE ─────────────────────────────────────────────────────────────────── */
QMainWindow, QDialog, QWidget#AppRoot {
    background-color: #080B10;
    color: #F1F5F9;
    font-family: ".AppleSystemUIFont","Inter","SF Pro Display","Segoe UI",sans-serif;
    font-size: 12px;
}
QWidget {
    background-color: transparent;
    color: #F1F5F9;
    font-family: ".AppleSystemUIFont","Inter","SF Pro Display","Segoe UI",sans-serif;
    font-size: 12px;
}

/* ── CARDS & FRAMES ───────────────────────────────────────────────────────── */
QFrame#SectionCard, QFrame#TabsCard, QFrame#CardFrame {
    background-color: #0E141D;
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 10px;
}
QFrame#TopBar {
    background-color: #0E141D;
    border: none;
    border-bottom: 1px solid rgba(255, 255, 255, 0.08);
}
QFrame#MetricCard {
    background-color: #0E141D;
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-left: 3px solid #00E5FF;
    border-radius: 8px;
    min-height: 50px;
}
QFrame#InfoStrip {
    background-color: #0A0F17;
    border-bottom: 1px solid rgba(255, 255, 255, 0.08);
    min-height: 30px;
    max-height: 30px;
}
QWidget#ModeRail {
    background-color: #0E141D;
    border-right: 1px solid rgba(255, 255, 255, 0.08);
}
QFrame#FooterBar {
    background-color: #0E141D;
    border-top: 1px solid rgba(255, 255, 255, 0.08);
}
QFrame#ChartsSidebar {
    background-color: #0E141D;
    border-right: 1px solid rgba(255, 255, 255, 0.08);
    min-width: 200px;
    max-width: 240px;
}
QWidget#AICopilotPanel, QWidget#ScenarioStressLibrary {
    background-color: #0E141D;
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 10px;
}

/* ── SCROLL AREAS ─────────────────────────────────────────────────────────── */
QScrollArea { background-color: transparent; border: none; }
QScrollArea > QWidget > QWidget { background-color: transparent; }

/* ── LABELS ───────────────────────────────────────────────────────────────── */
QLabel { background: transparent; color: #F1F5F9; }
QLabel#AppTitle {
    color: #FFFFFF;
    font-size: 15px;
    font-weight: 700;
    letter-spacing: -0.3px;
}
QLabel#AppSubtitle {
    color: #64748B;
    font-size: 10px;
    font-weight: 500;
    letter-spacing: 1px;
    text-transform: uppercase;
}
QLabel#SectionTitle {
    color: #00E5FF;
    font-size: 10px;
    font-weight: 700;
    letter-spacing: 1.2px;
    text-transform: uppercase;
}
QLabel#SectionHeader {
    color: #FFFFFF;
    font-size: 13px;
    font-weight: 700;
}
QLabel#SubtleSectionTitle {
    color: #94A3B8;
    font-size: 11px;
    font-weight: 600;
}
QLabel#StatusTitle {
    color: #FFFFFF;
    font-size: 13px;
    font-weight: 700;
}
QLabel#StatusSubtitle {
    color: #94A3B8;
    font-size: 11px;
}
QLabel#StripLabel {
    color: #94A3B8;
    font-size: 10px;
    font-weight: 600;
    letter-spacing: 0.5px;
    padding: 0 14px;
    border-right: 1px solid rgba(255, 255, 255, 0.08);
}
QLabel#MetricTitle {
    color: #64748B;
    font-size: 9px;
    font-weight: 700;
    letter-spacing: 1px;
    text-transform: uppercase;
}
QLabel#MetricValue {
    color: #00E676;
    font-size: 18px;
    font-weight: 800;
    font-family: "JetBrains Mono","SF Mono","Cascadia Code","Consolas",monospace;
}
QLabel#MetricValueDim {
    color: #64748B;
    font-size: 18px;
    font-weight: 800;
    font-family: "JetBrains Mono","SF Mono","Cascadia Code","Consolas",monospace;
}
QLabel#MetricNote {
    color: #94A3B8;
    font-size: 10px;
}
QLabel#MutedText {
    color: #94A3B8;
    font-size: 12px;
}
QLabel#MutedLabel {
    color: #64748B;
    font-size: 11px;
}
QLabel#FormLabel {
    color: #94A3B8;
    font-size: 11px;
    font-weight: 600;
    min-width: 115px;
    max-width: 140px;
}
QLabel#EmptyStateLabel {
    color: #94A3B8;
    font-size: 13px;
    font-weight: 500;
    qproperty-alignment: AlignCenter;
    background-color: rgba(14, 20, 29, 0.65);
    border: 1px dashed rgba(0, 229, 255, 0.25);
    border-radius: 10px;
    padding: 30px;
    margin: 15px;
}
QLabel#val {
    color: #F1F5F9;
    font-family: "JetBrains Mono","SF Mono","Consolas",monospace;
    font-size: 12px;
}

/* ── BUTTONS ──────────────────────────────────────────────────────────────── */
QPushButton {
    background-color: #141C28;
    color: #F1F5F9;
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 6px;
    padding: 0px 12px;
    font-size: 12px;
    font-weight: 500;
    min-height: 30px;
    max-height: 32px;
}
QPushButton:hover {
    background-color: #1C2738;
    border-color: rgba(0, 229, 255, 0.35);
    color: #FFFFFF;
}
QPushButton:pressed {
    background-color: #0E141D;
}
QPushButton:disabled {
    background-color: #0E141D;
    color: #475569;
    border-color: rgba(255, 255, 255, 0.04);
}

QPushButton#PrimaryButton {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #00E5FF, stop:1 #0091EA);
    color: #000000;
    border: none;
    border-radius: 6px;
    font-weight: 700;
    font-size: 12px;
    min-height: 34px;
    max-height: 36px;
    padding: 0px 16px;
}
QPushButton#PrimaryButton:hover {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #18FFFF, stop:1 #00B0FF);
}
QPushButton#PrimaryButton:pressed {
    background: #0091EA;
}
QPushButton#PrimaryButton:disabled {
    background: #141C28;
    color: #475569;
}
QPushButton#PrimaryButton:hover {
    background-color: #34D399;
}
QPushButton#PrimaryButton:pressed {
    background-color: #0D8F66;
}
QPushButton#PrimaryButton:disabled {
    background-color: #1F2730;
    color: #4B5563;
}

QPushButton#AccentButton {
    background-color: #10B981;
    color: #0A0E14;
    border: none;
    border-radius: 5px;
    font-weight: 700;
    font-size: 12px;
    min-height: 32px;
    max-height: 34px;
    padding: 0px 14px;
}
QPushButton#AccentButton:hover { background-color: #34D399; }
QPushButton#AccentButton:pressed { background-color: #0D8F66; }

QPushButton#StopButton {
    background-color: #131820;
    color: #EF4444;
    border: 1px solid #EF4444;
    border-radius: 5px;
    font-weight: 700;
    min-height: 32px;
    max-height: 34px;
    padding: 0px 12px;
}
QPushButton#StopButton:hover {
    background-color: rgba(239, 68, 68, 0.10);
    border-color: #EF4444;
}
QPushButton#StopButton:disabled {
    color: #4B5563;
    border-color: #1F2730;
}

QPushButton#SecondaryButton {
    background-color: #1A2028;
    color: #E6EDF3;
    border: 1px solid #2A3441;
    border-radius: 5px;
    font-weight: 600;
    font-size: 12px;
    min-height: 30px;
    max-height: 32px;
    padding: 0px 12px;
}
QPushButton#SecondaryButton:hover {
    background-color: #222B36;
    border-color: #3D4754;
    color: #FFFFFF;
}
QPushButton#SecondaryButton:pressed { background-color: #2A3441; }
QPushButton#SecondaryButton:disabled { color: #4B5563; border-color: #1F2730; }

QPushButton#GhostButton {
    background: transparent;
    border: 1px solid #2A3441;
    color: #8B949E;
    border-radius: 5px;
    font-size: 12px;
    min-height: 28px;
    max-height: 30px;
    padding: 0px 12px;
}
QPushButton#GhostButton:hover {
    background: #1A2028;
    color: #E6EDF3;
    border-color: #3D4754;
}

QPushButton#IconButton {
    background-color: transparent;
    color: #8B949E;
    border: 1px solid #2A3441;
    border-radius: 5px;
    font-size: 12px;
    padding: 0px 4px;
    min-height: 28px;
    max-height: 30px;
}
QPushButton#IconButton:hover {
    background-color: #1A2028;
    color: #E6EDF3;
    border-color: #3D4754;
}

QPushButton#TestButton {
    background: transparent;
    border: 1px solid #10B981;
    color: #34D399;
    border-radius: 5px;
    padding: 0px 12px;
    font-size: 12px;
    min-height: 28px;
    max-height: 30px;
}
QPushButton#TestButton:hover {
    background: rgba(16, 185, 129, 0.12);
}

/* ── NAVIGATION BUTTONS ───────────────────────────────────────────────────── */
QToolButton#ModeRailButton {
    background: transparent;
    border: none;
    border-radius: 6px;
    color: #8B949E;
    font-size: 10px;
    font-weight: 700;
    letter-spacing: 0.5px;
    padding: 4px 0px;
    text-transform: uppercase;
}
QToolButton#ModeRailButton:checked {
    background-color: rgba(16, 185, 129, 0.12);
    color: #34D399;
}
QToolButton#ModeRailButton:hover:!checked {
    background-color: #1A2028;
    color: #E6EDF3;
}

QPushButton#WorkspaceGroupButton {
    background: transparent;
    border: none;
    border-radius: 4px;
    color: #8B949E;
    padding: 0px 14px;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.4px;
    min-height: 28px;
    max-height: 28px;
}
QPushButton#WorkspaceGroupButton:checked {
    background-color: rgba(16, 185, 129, 0.12);
    color: #34D399;
    border: 1px solid #10B981;
}
QPushButton#WorkspaceGroupButton:hover:!checked {
    background-color: #1A2028;
    color: #E6EDF3;
}

QPushButton#TabNavButton {
    background: transparent;
    border: none;
    border-radius: 6px;
    color: #94A3B8;
    padding: 0px 14px;
    font-size: 11px;
    font-weight: 600;
    min-height: 28px;
    max-height: 28px;
}
QPushButton#TabNavButton:checked {
    background-color: rgba(0, 229, 255, 0.12);
    color: #00E5FF;
    border: 1px solid rgba(0, 229, 255, 0.3);
}
QPushButton#TabNavButton:hover:!checked {
    background-color: rgba(255, 255, 255, 0.05);
    color: #FFFFFF;
}

QPushButton#NavArrowButton {
    background-color: #141C28;
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 6px;
    color: #94A3B8;
    font-weight: 900;
    min-width: 28px;
    max-width: 28px;
    min-height: 32px;
    max-height: 32px;
    padding: 0;
}
QPushButton#NavArrowButton:hover {
    background-color: rgba(0, 229, 255, 0.12);
    border-color: #00E5FF;
    color: #00E5FF;
}

/* ── INPUTS ───────────────────────────────────────────────────────────────── */
QLineEdit, QTextEdit, QPlainTextEdit {
    background-color: #080B10;
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 6px;
    color: #F1F5F9;
    padding: 7px 12px;
    font-size: 12px;
    selection-background-color: rgba(0, 229, 255, 0.25);
    selection-color: #FFFFFF;
}
QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus {
    border-color: #00E5FF;
    background-color: #0C121A;
}
QLineEdit:disabled, QTextEdit:disabled, QPlainTextEdit:disabled {
    color: #475569;
    border-color: rgba(255, 255, 255, 0.04);
    background-color: #080B10;
}

QSpinBox, QDoubleSpinBox {
    background-color: #080B10;
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 6px;
    color: #F1F5F9;
    padding: 6px 10px;
    padding-right: 4px;
    font-size: 12px;
    font-family: "JetBrains Mono","SF Mono","Consolas",monospace;
}
QSpinBox:focus, QDoubleSpinBox:focus {
    border-color: #00E5FF;
    background-color: #0C121A;
}
QSpinBox::up-button, QDoubleSpinBox::up-button {
    width: 0;
    border: none;
    background: transparent;
}
QSpinBox::down-button, QDoubleSpinBox::down-button {
    width: 0;
    border: none;
    background: transparent;
}

QComboBox {
    background-color: #080B10;
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 6px;
    color: #F1F5F9;
    padding: 6px 14px;
    font-size: 12px;
    min-height: 30px;
}
QComboBox:hover {
    border-color: rgba(0, 229, 255, 0.35);
    background-color: #0C121A;
}
QComboBox:focus {
    border-color: #00E5FF;
}
QComboBox::drop-down {
    subcontrol-origin: border;
    subcontrol-position: top right;
    width: 26px;
    border-left: none;
    background: transparent;
}
QComboBox::down-arrow {
    image: none;
    border-left: 4px solid transparent;
    border-right: 4px solid transparent;
    border-top: 5px solid #94A3B8;
    width: 0;
    height: 0;
}
QComboBox QAbstractItemView {
    background-color: #0E141D;
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 8px;
    color: #F1F5F9;
    padding: 4px;
    outline: none;
}
QComboBox QAbstractItemView::item {
    min-height: 30px;
    padding: 4px 12px;
    border-radius: 4px;
    color: #F1F5F9;
    background-color: transparent;
}
QComboBox QAbstractItemView::item:selected {
    background-color: rgba(0, 229, 255, 0.15);
    color: #00E5FF;
}
QComboBox QAbstractItemView::item:hover {
    background-color: #141C28;
    color: #FFFFFF;
}

/* ── TABLES ───────────────────────────────────────────────────────────────── */
QTableWidget, QTableView {
    background-color: #0E141D;
    alternate-background-color: #0A0F17;
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 8px;
    gridline-color: rgba(255, 255, 255, 0.04);
    color: #F1F5F9;
    font-size: 12px;
    font-family: ".AppleSystemUIFont","Inter","SF Pro Text",sans-serif;
    selection-background-color: rgba(0, 229, 255, 0.15);
    selection-color: #00E5FF;
    outline: none;
}
QTableWidget::item, QTableView::item {
    padding: 6px 14px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.04);
}
QTableWidget::item:selected, QTableView::item:selected {
    background-color: rgba(0, 229, 255, 0.15);
    color: #00E5FF;
}
QTableWidget::item:hover, QTableView::item:hover {
    background-color: #141C28;
}
QHeaderView::section {
    background-color: #121924;
    color: #94A3B8;
    border: none;
    border-bottom: 2px solid rgba(0, 229, 255, 0.35);
    border-right: 1px solid rgba(255, 255, 255, 0.05);
    padding: 0px 14px;
    font-weight: 700;
    font-size: 10px;
    font-family: "JetBrains Mono","SF Mono","Menlo",monospace;
    letter-spacing: 0.6px;
    text-transform: uppercase;
    min-height: 32px;
    max-height: 32px;
}
QHeaderView, QTableCornerButton::section {
    background: transparent;
    border: none;
}

/* ── PROGRESS BAR ─────────────────────────────────────────────────────────── */
QProgressBar {
    background-color: #080B10;
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 4px;
    text-align: center;
    color: #F1F5F9;
    font-size: 10px;
    font-weight: 600;
    min-height: 18px;
    max-height: 18px;
}
QProgressBar::chunk {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #00E5FF, stop:1 #0091EA);
    border-radius: 4px;
}
QProgressBar[status="warning"]::chunk { background-color: #FFB300; }
QProgressBar[status="danger"]::chunk { background-color: #FF5252; }

/* ── CHECKBOX & RADIO ─────────────────────────────────────────────────────── */
QCheckBox, QRadioButton {
    color: #E6EDF3;
    spacing: 8px;
    font-size: 12px;
    background: transparent;
}
QCheckBox::indicator, QRadioButton::indicator {
    width: 16px;
    height: 16px;
    border: 1px solid #3D4754;
    background-color: #0F141B;
    border-radius: 3px;
}
QRadioButton::indicator { border-radius: 8px; }
QCheckBox::indicator:checked, QRadioButton::indicator:checked {
    background-color: #10B981;
    border-color: #10B981;
}
QCheckBox::indicator:hover, QRadioButton::indicator:hover {
    border-color: #34D399;
}
QCheckBox#DangerCheck {
    color: #EF4444;
}
QCheckBox#DangerCheck::indicator:checked {
    background-color: #EF4444;
    border-color: #EF4444;
}

/* ── SCROLLBARS ───────────────────────────────────────────────────────────── */
QScrollBar:vertical {
    background: transparent;
    width: 10px;
    margin: 0;
    border: none;
}
QScrollBar::handle:vertical {
    background: #2A3441;
    border-radius: 4px;
    min-height: 30px;
    margin: 2px;
}
QScrollBar::handle:vertical:hover { background: #3D4754; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0;
    background: none;
    border: none;
}
QScrollBar:horizontal {
    background: transparent;
    height: 10px;
    margin: 0;
    border: none;
}
QScrollBar::handle:horizontal {
    background: #2A3441;
    border-radius: 4px;
    min-width: 30px;
    margin: 2px;
}
QScrollBar::handle:horizontal:hover { background: #3D4754; }
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {
    width: 0;
    background: none;
    border: none;
}

/* ── SPLITTER ─────────────────────────────────────────────────────────────── */
QSplitter::handle { background-color: #1F2730; }
QSplitter::handle:horizontal { width: 1px; }
QSplitter::handle:vertical { height: 1px; }
QSplitter::handle:hover { background-color: #10B981; }
#RailDivider {
    background: #1F2730;
    border: none;
    max-width: 1px;
}

/* ── TOOL BUTTONS ─────────────────────────────────────────────────────────── */
QToolButton {
    background: transparent;
    border: none;
    color: #8B949E;
    font-size: 12px;
    font-weight: 600;
    padding: 0px 8px;
    text-align: left;
    min-height: 30px;
    max-height: 30px;
}
QToolButton:hover { color: #E6EDF3; }
QToolButton:checked { color: #34D399; }

/* ── MENU ─────────────────────────────────────────────────────────────────── */
QMenu {
    background-color: #1A2028;
    border: 1px solid #3D4754;
    border-radius: 8px;
    color: #E6EDF3;
    padding: 6px;
    font-size: 13px;
}
QMenu::item {
    padding: 7px 24px;
    border-radius: 6px;
}
QMenu::item:selected {
    background-color: rgba(16, 185, 129, 0.15);
    color: #34D399;
}
QMenu::separator {
    height: 1px;
    background: #1F2730;
    margin: 4px 10px;
}
QMenu#GlassMenu {
    background-color: #1A2028;
    border: 1px solid #3D4754;
    border-radius: 10px;
}

/* ── TOOLTIP ──────────────────────────────────────────────────────────────── */
QToolTip {
    background-color: #1A2028;
    color: #E6EDF3;
    border: 1px solid #3D4754;
    border-radius: 6px;
    padding: 7px 12px;
    font-size: 12px;
}

/* ── FORM LAYOUT ──────────────────────────────────────────────────────────── */
QFormLayout QLabel {
    color: #8B949E;
    font-size: 11px;
    min-width: 115px;
    max-width: 140px;
}

/* ── LIST WIDGET ──────────────────────────────────────────────────────────── */
QListWidget {
    background-color: #131820;
    border: 1px solid #1F2730;
    border-radius: 6px;
    color: #E6EDF3;
    font-size: 12px;
    outline: none;
}
QListWidget::item {
    padding: 6px 12px;
    border-bottom: 1px solid #1F2730;
}
QListWidget::item:selected {
    background-color: rgba(16, 185, 129, 0.15);
    color: #34D399;
}
QListWidget::item:hover {
    background-color: #1A2028;
}
QListWidget#ChartsList {
    background-color: #0F141B;
    border: 1px solid #1F2730;
    border-radius: 8px;
}

/* ── STATUS BAR ───────────────────────────────────────────────────────────── */
QStatusBar {
    background-color: #131820;
    color: #8B949E;
    border-top: 1px solid #2A3441;
    font-size: 11px;
}
QStatusBar::item { border: none; }

/* ── TABS ─────────────────────────────────────────────────────────────────── */
QTabWidget { background-color: #0A0E14; }
QTabWidget::pane {
    background-color: #131820;
    border: 1px solid #1F2730;
    border-radius: 8px;
    margin-top: -1px;
}
QTabWidget::tab-bar { alignment: left; }
QTabBar { background-color: transparent; }
QTabBar::tab {
    background-color: transparent;
    color: #8B949E;
    border: none;
    border-bottom: 2px solid transparent;
    padding: 8px 18px;
    font-size: 12px;
    font-weight: 600;
    min-height: 36px;
    margin-right: 2px;
}
QTabBar::tab:selected {
    background-color: transparent;
    color: #34D399;
    border-bottom: 2px solid #10B981;
}
QTabBar::tab:hover:!selected {
    color: #E6EDF3;
    border-bottom-color: #3D4754;
}
QWidget#SettingsTab { background-color: #0A0E14; }

/* ── GROUP BOX ────────────────────────────────────────────────────────────── */
QGroupBox {
    background-color: #131820;
    border: 1px solid #1F2730;
    border-radius: 10px;
    margin-top: 18px;
    padding-top: 14px;
    font-size: 11px;
    font-weight: 700;
    color: #8B949E;
}
QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top left;
    padding: 0px 12px;
    left: 14px;
    color: #34D399;
    background-color: #0A0E14;
    font-size: 10px;
    font-weight: 700;
    letter-spacing: 1px;
    text-transform: uppercase;
}

/* ── DIALOGS / MESSAGE BOXES ──────────────────────────────────────────────── */
QMessageBox {
    background-color: #1A2028;
}
QMessageBox QLabel {
    color: #E6EDF3;
    background-color: transparent;
    font-size: 13px;
}
QLabel#qt_msgbox_label {
    color: #E6EDF3;
    background-color: transparent;
    font-size: 14px;
    font-weight: 600;
}
QLabel#qt_msgbox_informativelabel {
    color: #8B949E;
    background-color: transparent;
    font-size: 12px;
}
QMessageBox QPushButton {
    background-color: #2A3441;
    color: #E6EDF3;
    border: 1px solid #3D4754;
    border-radius: 6px;
    padding: 7px 20px;
    min-width: 80px;
    font-weight: 600;
    min-height: 32px;
}
QMessageBox QPushButton:hover {
    background-color: #3D4754;
    border-color: #10B981;
    color: #FFFFFF;
}
QMessageBox QPushButton:default {
    background-color: #10B981;
    color: #0A0E14;
    border: none;
}
QDialog {
    background-color: #131820;
    border: 1px solid #3D4754;
    border-radius: 10px;
}

/* ── TEXT EDIT (LOG CONSOLE) ──────────────────────────────────────────────── */
QTextEdit#logs_box, QPlainTextEdit#logs_box {
    background-color: #0F141B;
    color: #8B949E;
    border: 1px solid #1F2730;
    border-radius: 8px;
    font-family: "JetBrains Mono","SF Mono","Consolas",monospace;
    font-size: 11px;
    padding: 8px;
    selection-background-color: rgba(16, 185, 129, 0.25);
    selection-color: #FFFFFF;
}
"""

LIGHT_MODE_QSS = """
/* ═══════════════════════════════════════════════════════════════════════════
   INSTITUTIONAL macOS LIGHT THEME — clean native Apple style
   Palette: #f4f5f8 window bg · #ffffff card/surface · #e1e3eb border
            #1e2025 text · #6c7a89 muted · #007aff active blue accent
   ═══════════════════════════════════════════════════════════════════════════ */
* { outline: none; }
QMainWindow, QDialog, QWidget#AppRoot { background-color: #f4f5f8; color: #1e2025; font-family: ".AppleSystemUIFont","SF Pro Text","Helvetica Neue",Arial; font-size: 12px; }
QWidget { background-color: transparent; color: #1e2025; font-family: ".AppleSystemUIFont","SF Pro Text","Helvetica Neue",Arial; font-size: 12px; }
QFrame#SectionCard, QFrame#TabsCard { background-color: #ffffff; border: 1px solid #e1e3eb; border-radius: 6px; }
QFrame#TopBar { background-color: #f4f5f8; border: none; border-bottom: 1px solid #e1e3eb; }
QFrame#MetricCard { background-color: #ffffff; border: 1px solid #e1e3eb; border-left: 3px solid #007aff; border-radius: 6px; min-height: 48px; max-height: 68px; }
QFrame#InfoStrip { background-color: #f4f5f8; border-bottom: 1px solid #e1e3eb; min-height: 28px; max-height: 28px; }
QWidget#ModeRail { background-color: #f4f5f8; border-right: 1px solid #e1e3eb; }
QScrollArea { background-color: transparent; border: none; }
QScrollArea > QWidget > QWidget { background-color: transparent; }
QLabel { background: transparent; color: #1e2025; }
QLabel#AppTitle { color: #1e2025; font-size: 14px; font-weight: 700; letter-spacing: -0.2px; }
QLabel#AppSubtitle { color: #6c7a89; font-size: 10px; }
QLabel#SectionTitle { color: #007aff; font-size: 9px; font-weight: 700; letter-spacing: 1.4px; }
QLabel#SubtleSectionTitle { color: #8e8e93; font-size: 10px; font-weight: 600; }
QLabel#StatusTitle { color: #1c1c1e; font-size: 12px; font-weight: 600; }
QLabel#StatusSubtitle { color: #8e8e93; font-size: 10px; }
QLabel#StripLabel { color: #8e8e93; font-size: 10px; font-weight: 600; padding: 0 12px; border-right: 1px solid #d1d1d6; }
QLabel#MetricTitle { color: #8e8e93; font-size: 9px; font-weight: 700; letter-spacing: 1.2px; }
QLabel#MetricValue { color: #007aff; font-size: 18px; font-weight: 700; font-family: ".AppleSystemUIFont","SF Pro Text",sans-serif; }
QLabel#MetricValueDim { color: #e5e5ea; font-size: 18px; font-weight: 700; font-family: ".AppleSystemUIFont","SF Pro Text",sans-serif; }
QLabel#MetricNote { color: #8e8e93; font-size: 10px; }
QLabel#MutedText { color: #8e8e93; font-size: 11px; }

QPushButton { background-color: #ffffff; color: #1c1c1e; border: 1px solid #d1d1d6; border-radius: 6px; padding: 0px 12px; font-size: 11px; font-weight: 500; min-height: 28px; }
QPushButton:hover { background-color: #f2f2f7; border-color: #a8a8a8; color: #1c1c1e; }
QPushButton:pressed { background-color: #e5e5ea; }
QPushButton:disabled { background-color: #f2f2f7; color: #c7c7cc; border-color: #e5e5ea; }

QPushButton#PrimaryButton { background-color: #007aff; color: #ffffff; border: none; border-radius: 6px; font-weight: 700; font-size: 11px; min-height: 28px; padding: 0px 14px; }
QPushButton#PrimaryButton:hover { background-color: #268fff; }
QPushButton#PrimaryButton:pressed { background-color: #005ecb; }
QPushButton#PrimaryButton:disabled { background-color: #c7c7cc; color: #ebebeb; }

QPushButton#StopButton { background-color: #ffffff; color: #ff3b30; border: 1px solid #ff3b30; border-radius: 6px; font-weight: 700; min-height: 28px; padding: 0px 12px; }
QPushButton#StopButton:hover { background-color: #ffe5e5; border-color: #ff3b30; }
QPushButton#StopButton:disabled { color: #c7c7cc; border-color: #e5e5ea; }

#SecondaryButton { background-color: #ffffff; color: #1c1c1e; border: 1px solid #d1d1d6; border-radius: 6px; font-weight: 600; font-size: 11px; min-height: 28px; padding: 0px 12px; }
#SecondaryButton:hover { background-color: #f2f2f7; border-color: #a8a8a8; color: #1c1c1e; }
#SecondaryButton:pressed { background-color: #e5e5ea; }
#SecondaryButton:disabled { color: #c7c7cc; border-color: #e5e5ea; }

#IconButton { background-color: transparent; color: #8e8e93; border: 1px solid #d1d1d6; border-radius: 6px; font-size: 11px; padding: 0px 2px; min-height: 28px; }
#IconButton:hover { background-color: #f2f2f7; color: #1c1c1e; border-color: #a8a8a8; }
#IconButton:pressed { background-color: #e5e5ea; }

QToolButton#ModeRailButton { background: transparent; border: none; border-radius: 6px; color: #8e8e93; font-size: 9px; font-weight: 700; letter-spacing: 0.5px; padding: 2px 0px; }
QToolButton#ModeRailButton:checked { background-color: #e1f0ff; color: #007aff; }
QToolButton#ModeRailButton:hover:!checked { background-color: #e5e5ea; color: #1c1c1e; }

QPushButton#WorkspaceGroupButton { background: transparent; border: none; border-radius: 4px; color: #8e8e93; padding: 0px 12px; font-size: 11px; font-weight: 700; letter-spacing: 0.4px; min-height: 26px; max-height: 26px; }
QPushButton#WorkspaceGroupButton:checked { background-color: #e1f0ff; color: #007aff; border: 1px solid #a2cfff; }
QPushButton#WorkspaceGroupButton:hover:!checked { background-color: #e5e5ea; color: #1c1c1e; }

QPushButton#TabNavButton { background: transparent; border: none; border-radius: 6px; color: #8e8e93; padding: 0px 12px; font-size: 11px; font-weight: 600; min-height: 26px; max-height: 26px; }
QPushButton#TabNavButton:checked { background-color: #ffffff; color: #1c1c1e; border: 1px solid #d1d1d6; }
QPushButton#TabNavButton:hover:!checked { background-color: #e5e5ea; color: #1c1c1e; }

QPushButton#NavArrowButton { background-color: #ffffff; border: 1px solid #d1d1d6; border-radius: 6px; color: #8e8e93; font-weight: 900; min-width: 26px; max-width: 26px; min-height: 30px; max-height: 30px; padding: 0; }
QPushButton#NavArrowButton:hover { background-color: #e1f0ff; border-color: #007aff; color: #007aff; }

QLineEdit, QTextEdit, QPlainTextEdit { background-color: #ffffff; border: 1px solid #d1d1d6; border-radius: 8px; color: #1c1c1e; padding: 6px 10px; font-size: 12px; selection-background-color: #e1f0ff; selection-color: #007aff; }
QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus { border-color: #007aff; }
QLineEdit:disabled, QTextEdit:disabled, QPlainTextEdit:disabled { color: #c7c7cc; border-color: #e5e5ea; }

#RailDivider { background: #d1d1d6; border: none; max-width: 1px; }
QSpinBox, QDoubleSpinBox { background-color: #ffffff; border: 1px solid #d1d1d6; border-radius: 8px; color: #1c1c1e; padding: 5px 8px; padding-right: 4px; font-size: 12px; }
QSpinBox:focus, QDoubleSpinBox:focus { border-color: #007aff; }
QSpinBox::up-button, QDoubleSpinBox::up-button { width: 0; border: none; background: transparent; }
QSpinBox::down-button, QDoubleSpinBox::down-button { width: 0; border: none; background: transparent; }

QComboBox { background-color: #ffffff; border: 1px solid #d1d1d6; border-radius: 6px; color: #1c1c1e; padding: 5px 12px; font-size: 12px; min-height: 28px; }
QComboBox:hover { border-color: #007aff; background-color: #fcfcfd; }
QComboBox:focus { border-color: #007aff; }
QComboBox::drop-down { subcontrol-origin: border; subcontrol-position: top right; width: 24px; border-left: none; background: transparent; }
QComboBox::down-arrow { image: none; border-left: 4px solid transparent; border-right: 4px solid transparent; border-top: 5px solid #8e8e93; width: 0; height: 0; }
QComboBox QAbstractItemView { background-color: #ffffff; border: 1px solid #d1d1d6; border-radius: 8px; color: #1c1c1e; padding: 4px; outline: none; }
QComboBox QAbstractItemView::item { min-height: 28px; padding: 4px 10px; border-radius: 4px; color: #1c1c1e; background-color: transparent; }
QComboBox QAbstractItemView::item:selected { background-color: #e1f0ff; color: #007aff; }
QComboBox QAbstractItemView::item:hover { background-color: #f2f2f7; color: #000000; }

QTableWidget, QTableView { background-color: #ffffff; alternate-background-color: #f9f9f9; border: none; gridline-color: #e5e5ea; color: #1c1c1e; font-size: 12px; font-family: ".AppleSystemUIFont","SF Pro Text",sans-serif; selection-background-color: #e1f0ff; selection-color: #007aff; }
QTableWidget::item, QTableView::item { padding: 5px 12px; border-bottom: 1px solid #e5e5ea; }
QTableWidget::item:selected, QTableView::item:selected { background-color: #e1f0ff; color: #007aff; }
QHeaderView::section { background-color: #f2f2f7; color: #8e8e93; border: none; border-bottom: 1px solid #d1d1d6; border-right: 1px solid #e5e5ea; padding: 0px 12px; font-weight: 700; font-size: 10px; letter-spacing: 1.0px; min-height: 28px; max-height: 28px; }
QHeaderView, QTableCornerButton::section { background: transparent; border: none; }

QProgressBar { background-color: #e5e5ea; border: none; border-radius: 3px; height: 6px; }
QProgressBar::chunk { background-color: #007aff; border-radius: 3px; }

QCheckBox { color: #1c1c1e; spacing: 8px; font-size: 12px; }
QCheckBox::indicator { width: 16px; height: 16px; border: 1px solid #d1d1d6; border-radius: 4px; background-color: #ffffff; }
QCheckBox::indicator:checked { background-color: #007aff; border-color: #007aff; }
QCheckBox::indicator:hover { border-color: #007aff; }

QScrollBar:vertical { background: transparent; width: 8px; }
QScrollBar::handle:vertical { background: #c7c7cc; border-radius: 4px; min-height: 20px; }
QScrollBar::handle:vertical:hover { background: #8e8e93; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar:horizontal { background: transparent; height: 8px; }
QScrollBar::handle:horizontal { background: #c7c7cc; border-radius: 4px; min-width: 20px; }
QScrollBar::handle:horizontal:hover { background: #8e8e93; }
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0; }

QSplitter::handle { background-color: #d1d1d6; }
QSplitter::handle:horizontal { width: 1px; }
QSplitter::handle:vertical { height: 1px; }
QFrame#FooterBar { background-color: #f2f2f7; border-top: 1px solid #d1d1d6; }
QCheckBox#DangerCheck { color: #ff3b30; }
QSplitter::handle:hover { background-color: #007aff; }

QToolButton { background: transparent; border: none; color: #8e8e93; font-size: 12px; font-weight: 600; padding: 0px 6px; text-align: left; min-height: 28px; max-height: 28px; }
QToolButton:hover { color: #1c1c1e; }
QToolButton:checked { color: #007aff; }

QMenu { background-color: #ffffff; border: 1px solid #d1d1d6; border-radius: 8px; color: #1c1c1e; padding: 4px; font-size: 13px; }
QMenu::item { padding: 6px 20px; border-radius: 6px; }
QMenu::item:selected { background-color: #e1f0ff; color: #007aff; }
QMenu::separator { height: 1px; background: #d1d1d6; margin: 4px 8px; }

QToolTip { background-color: #ffffff; color: #1c1c1e; border: 1px solid #d1d1d6; border-radius: 6px; padding: 6px 10px; font-size: 12px; }
QFormLayout QLabel { color: #8e8e93; font-size: 11px; min-width: 115px; max-width: 115px; }

QListWidget { background-color: #ffffff; border: 1px solid #d1d1d6; border-radius: 8px; color: #1c1c1e; font-size: 12px; }
QListWidget::item:selected { background-color: #e1f0ff; color: #007aff; }

QStatusBar { background-color: #f2f2f7; color: #8e8e93; border-top: 1px solid #d1d1d6; font-size: 11px; }

QTabWidget { background-color: #f4f5f8; }
QTabWidget::pane { background-color: #f4f5f8; border: none; }
QTabWidget::tab-bar { alignment: left; }
QTabBar { background-color: #f4f5f8; }
QTabBar::tab { background-color: #f4f5f8; color: #8e8e93; border: none; border-bottom: 2px solid transparent; padding: 8px 16px; font-size: 12px; font-weight: 600; min-height: 34px; }
QTabBar::tab:selected { background-color: #f4f5f8; color: #007aff; border-bottom: 2px solid #007aff; }
QTabBar::tab:hover:!selected { color: #1c1c1e; }
QWidget#SettingsTab { background-color: #f4f5f8; }

QPushButton#GhostButton { background: transparent; border: 1px solid #d1d1d6; color: #8e8e93; border-radius: 8px; font-size: 12px; min-height: 30px; max-height: 30px; padding: 0px 14px; }
QPushButton#GhostButton:hover { background: #e5e5ea; color: #1c1c1e; border-color: #8e8e93; }

QPushButton#TestButton { background: transparent; border: 1px solid #007aff; color: #007aff; border-radius: 7px; padding: 0px 14px; font-size: 12px; min-height: 28px; max-height: 28px; }
QPushButton#TestButton:hover { background: #e1f0ff; }

/* ── Message / Confirmation Dialogs ── */
QMessageBox { background-color: #ffffff; }
QMessageBox QLabel { color: #1c1c1e; background-color: transparent; font-size: 13px; }
QLabel#qt_msgbox_label { color: #1c1c1e; background-color: transparent; font-size: 13px; }
QLabel#qt_msgbox_informativelabel { color: #3c3c3e; background-color: transparent; font-size: 12px; }
QMessageBox QPushButton { background-color: #f2f2f7; color: #1c1c1e; border: 1px solid #d1d1d6; border-radius: 6px; padding: 6px 18px; min-width: 70px; font-weight: 600; }
QMessageBox QPushButton:hover { background-color: #e5e5ea; border-color: #a8a8a8; }
QMessageBox QPushButton:default { background-color: #007aff; color: #ffffff; border: none; }
"""
# ────────────────────────────────────────────────────────────────────

# FUNC: angelone_place_basket
# ────────────────────────────────────────────────────────────────────


# ── Position Reconciliation ────────────────────────────────────────────────────


# AUDIT-FIX (defect #6): the broker basket + reconciliation aliases were all
# silently pointing to the Angel One implementation, which means "Kite" / "Dhan"
# order placements and reconciliations were actually going through the Angel One
# router. We wrap each one with a clearly-labeled shim that:
#   (a) logs which broker router is actually being used,
#   (b) preserves the prior behavior so existing call sites keep working,
#   (c) makes the alias explicit instead of pretending each broker has its own
#       first-class implementation when they all share Angel One's SDK today.





# ── Live P&L Tracker ──────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: build_qubo
# ────────────────────────────────────────────────────────────────────
def build_qubo(data, returns, benchmark_returns, sectors, prev_holdings, cfg, log_cb=None):
    from data_layer import DEFAULT_CFG
    cfg = {**DEFAULT_CFG, **(cfg or {})}
    # Determine base factor weights based on FACTOR_MODEL selection.
    # GARP and Institutional Accumulation keep their hardcoded overrides.
    # All other profiles now carry their own FACTOR_WEIGHTS in cfg (set by PROFILE_MAP),
    # so we simply use cfg["FACTOR_WEIGHTS"] as the authoritative base for those.
    _model = cfg.get("FACTOR_MODEL", "Trend Momentum (Default)")
    if _model == "Value + Early Breakout (GARP)":
        _base_weights = {
            "z_mom_1m":        0.120,
            "z_mom_3m":        0.060,
            "z_mom_6m":        0.020,
            "z_mom_12_1":      0.010,
            "z_trend_20":      0.080,
            "z_trend_50":      0.010,
            "z_roe":           0.200,
            "z_pe_inv":        0.200,
            "z_de_inv":        0.100,
            "z_rev_growth":    0.100,
            "z_delivery":      0.050,
            "z_fii_sector":    0.050,
            "z_vol_surge":     0.050,
            "z_adv20":         0.020,
            "z_ann_vol":      -0.04,
            "z_downside_vol": -0.03,
        }
    elif _model == "Institutional Accumulation":
        _base_weights = {
            "z_mom_1m":        0.050,
            "z_mom_3m":        0.050,
            "z_mom_6m":        0.050,
            "z_mom_12_1":      0.050,
            "z_trend_20":      0.050,
            "z_trend_50":      0.030,
            "z_roe":           0.050,
            "z_pe_inv":        0.050,
            "z_de_inv":        0.040,
            "z_rev_growth":    0.050,
            "z_delivery":      0.250,
            "z_fii_sector":    0.150,
            "z_vol_surge":     0.200,
            "z_adv20":         0.100,
            "z_ann_vol":      -0.05,
            "z_downside_vol": -0.04,
        }
    else:
        # All other profiles (Momentum, Defensive, Alpha-Concentrated, etc.) carry
        # their unique FACTOR_WEIGHTS in cfg via PROFILE_MAP. Use those directly.
        # Fall back to DEFAULT_CFG only if cfg has no FACTOR_WEIGHTS at all.
        _base_weights = dict(cfg.get("FACTOR_WEIGHTS") or DEFAULT_CFG["FACTOR_WEIGHTS"])

    # Dynamic Factor Weight Engine: Blends dynamic weights only when explicitly requested, preserving profile factor identity
    if cfg.get("USE_DYNAMIC_FACTOR_WEIGHTS", False):
        try:
            from math_engine.dynamic_factor_engine import DynamicFactorWeightEngine
            # BUGFIX (Round 41): this previously read cfg.get("INDIA_VIX", 15.0),
            # but nothing in the codebase ever writes a key named "INDIA_VIX" —
            # the live fetched value is stored as "_INDIA_VIX" (leading
            # underscore, set in run_optimizer_logic) and prefetched as
            # "_INDIA_VIX_PREFETCHED". The lookup therefore ALWAYS fell through
            # to the hardcoded 15.0 default regardless of the real market VIX,
            # so the engine's `india_vix > 20.0` stress branch could never
            # fire. Latent today (USE_DYNAMIC_FACTOR_WEIGHTS defaults False and
            # no profile enables it), but it would have silently ignored real
            # volatility the moment anyone turned the feature on. Now reads
            # the key that is actually populated; a missing/NaN value falls back
            # to the engine's neutral default explicitly rather than by accident.
            _dyn_vix = cfg.get("_INDIA_VIX", cfg.get("_INDIA_VIX_PREFETCHED", None))
            try:
                _dyn_vix = float(_dyn_vix) if _dyn_vix is not None else float("nan")
            except (TypeError, ValueError):
                _dyn_vix = float("nan")
            if _dyn_vix != _dyn_vix:  # NaN -> neutral engine default
                _dyn_vix = 15.0
            dyn_engine = DynamicFactorWeightEngine(lookback_days=63)
            _factor_pool = list(_base_weights.keys())
            _dyn_weights = dyn_engine.compute_dynamic_weights(
                factor_pool=_factor_pool,
                universe_factor_df=pd.DataFrame(),
                historical_returns=returns,
                regime=str(cfg.get("_REGIME_INFO", {}).get("Regime", "Sideways")),
                india_vix=_dyn_vix
            )
            if _dyn_weights:
                _base_weights = {k: 0.6 * _base_weights.get(k, 0.0) + 0.4 * _dyn_weights.get(k, 0.0) for k in _base_weights}
                log_emit(log_cb, f"[DynamicFactorEngine] Computed dynamic mathematical factor weights for {len(_dyn_weights)} factors.")
        except Exception as _dfe_err:
            log_emit(log_cb, f"[DynamicFactorEngine] Non-fatal fallback: {_dfe_err}", exc_info=True)

    # Profile weights WIN — applied as the final authoritative layer.
    input_cfg = cfg
    cfg = {**cfg, "FACTOR_WEIGHTS": _base_weights}
    log_emit(log_cb, f"[FactorModel] Active alpha factor model: {_model}")

    # v17.27 F5: drawdown kill switch — relative drawdown vs benchmark over 63 days
    _dd_thresh = cfg.get("DRAWDOWN_KILL_SWITCH", -0.08)
    if not cfg.get("_WFO_STEP", False) and not returns.empty and benchmark_returns is not None and not benchmark_returns.empty:
        _prev_cols = [t for t in (prev_holdings or []) if t in returns.columns]
        _ks_rets = returns[_prev_cols].mean(axis=1) if _prev_cols else returns.mean(axis=1)
        _port_eq = (1 + _ks_rets.tail(63)).cumprod()
        _bench_eq = (1 + benchmark_returns.reindex(returns.index).tail(63).fillna(0)).cumprod()
        _rel_eq = _port_eq / _bench_eq  # DIV001: guard divisor before use
        _rel_dd = float((_rel_eq / _rel_eq.expanding().max() - 1.0).min())
    else:
        _rel_dd = 0.0
        
    if _rel_dd < _dd_thresh:
        _ri = cfg.get("_REGIME_INFO", {})
        log_emit(log_cb, f"[KillSwitch] Relative Drawdown={_rel_dd*100:.1f}% < {_dd_thresh*100:.0f}% threshold — forcing Defensive regime")
        cfg = {**cfg, "_REGIME_INFO": {**_ri, "Regime": "Bear/Stress", "P_Bear": 0.90, "P_Bull": 0.05}}
    # Auto-calibrate factor weights from rolling IC when USE_IC_WEIGHTS=True
    if cfg.get("USE_IC_WEIGHTS", True):
        _learn_out = calibrate_factor_weights_ic(returns, cfg, log_cb=log_cb, return_details=True)
        _ic_weights = dict((_learn_out or {}).get("weights") or {})
        _fresh_ic_scores = dict((_learn_out or {}).get("ic_scores") or {})
        _rinfo = cfg.get("_REGIME_INFO", {}) or {}
        _rlabel = _rinfo.get("Regime", "Transitional")

        # Save raw factor efficacy, not calibrated weights.
        if _fresh_ic_scores:
            try:
                # Bug fix: _DB_STORE.save_ic_observations(observations: list) does NOT
                # accept regime or log_cb positional/keyword args — that call was raising
                # TypeError silently. Route to the free-function which has the full
                # (ic_rows, regime, forward_days, log_cb) signature, then also persist
                # to _DB_STORE using only the list it expects.
                _ic_rows = [{"factor": _k, "ic": _v} for _k, _v in _fresh_ic_scores.items()]
                sqlite_save_ic_observations(_ic_rows, _rlabel, log_cb=log_cb)
                if _DB_STORE is not None:
                    # Convert {factor, ic} → {ticker, date, metric, value} schema
                    import datetime as _dt
                    _today = _dt.datetime.now().strftime("%Y-%m-%d")
                    _db_obs = [{"ticker": "_factor_ic", "date": _today,
                                "metric": r["factor"], "value": float(r["ic"])}
                               for r in _ic_rows]
                    _DB_STORE.save_ic_observations(_db_obs)
            except Exception as _lse:
                log_emit(log_cb, f"[LearnLoop] IC persist skipped: {_lse}", exc_info=True)

        # v17.23 L3: blend fresh IC with historical Bayesian IC (learning loop)
        if cfg.get("USE_BAYESIAN_IC", True):
            try:
                _hist_icir = sqlite_load_ic_history(n_runs=12, regime=_rlabel, log_cb=log_cb)
                if _hist_icir and _ic_weights and _fresh_ic_scores:
                    _ar1_v = float((_hist_icir or {}).pop("meta_ar1", 0.0))
                    _hist_icir = {
                        _f: float(_v)
                        for _f, _v in _hist_icir.items()
                        if _f != "meta_ar1"
                    }
                    _all_f = set(_fresh_ic_scores.keys()) | set(_hist_icir.keys())
                    _ar1_base = min(max(0.475 + _ar1_v * 0.275, 0.20), 0.75)
                    try:
                        _bvr = float(benchmark_returns.tail(21).std())
                        _bvl = float(benchmark_returns.tail(84).std())
                        _volr = min(max(_bvr / (_bvl + 1e-9), 0.5), 2.0)
                    except Exception as _e:
                        _volr = 1.0
                    _w_fresh = float(cfg.get("IC_EWMA_ALPHA", 0.25))  # 3-step EWMA IC smoothing (eta=0.75)
                    _w_hist = 1.0 - _w_fresh
                    log_emit(log_cb, f"[IC-Blend] 3-step EWMA (eta=0.75): fresh_weight={_w_fresh:.2f}, hist_weight={_w_hist:.2f}")
                    
                    # 1. Blend raw IC-IR scores (scale-aligned)
                    _blended_ic = {}
                    for _f in _all_f:
                        _h_val = _hist_icir.get(_f, 0.0)
                        if abs(_h_val) > 10.0:  # Safeguard for blown up values (e.g. 999999.9999 in legacy DB)
                            _h_val = max(-2.0, min(2.0, _h_val)) if _h_val != 999999.9999 else 1.0
                        _fresh_val = _fresh_ic_scores.get(_f, 0.0)
                        _blended_ic[_f] = _w_fresh * _fresh_val + _w_hist * _h_val

                    # Apply regime weights directly to the raw blended IC-IR scores to keep scaling intact
                    if any(x in _rlabel for x in ("Bear", "Stress", "Defensive")):
                        for _k in ("z_mom_1m","z_mom_3m","z_mom_6m","z_mom_12_1","z_trend_20","z_trend_50"):
                            if _k in _blended_ic:
                                _blended_ic[_k] = _blended_ic[_k] * float(cfg.get("IC_VOL_DAMPENING", 0.60))

                        for _k in ("z_ann_vol","z_downside_vol","z_drawdown","z_roe","z_pe_inv"):
                            if _k in _blended_ic:
                                _blended_ic[_k] = _blended_ic[_k] * float(cfg.get("IC_TREND_AMPLIFICATION", 1.35))
                        log_emit(log_cb, f"[RegimeWeights] {_rlabel} — momentum dampened 40%, quality amplified 35%")
                    elif any(x in _rlabel for x in ("Risk-On", "Trend", "Strength")):
                        for _k in ("z_mom_6m","z_mom_12_1"):
                            if _k in _blended_ic:
                                _blended_ic[_k] = _blended_ic[_k] * float(cfg.get("IC_MOMENTUM_AMPLIFICATION", 1.30))
                        log_emit(log_cb, f"[RegimeWeights] {_rlabel} — medium-term momentum amplified 30%")

                    # Ensure fundamental factor anchors are positive/satisfied
                    _ANCHORS = {"z_roe", "z_pe_inv", "z_de_inv", "z_rev_growth", "z_delivery", "z_fii_sector"}
                    _ANCHOR_FLOOR = {k: max(float(DEFAULT_CFG.get("FACTOR_WEIGHTS", {}).get(k, 0.0))*0.5, 0.01) for k in _ANCHORS}
                    for _ak, _af in _ANCHOR_FLOOR.items():
                        if _ak in _blended_ic:
                            _blended_ic[_ak] = max(_blended_ic[_ak], 0.05)

                    # Clamp momentum factors to 0 if negative
                    _MOM_FACTORS = {"z_mom_1m", "z_mom_3m", "z_mom_6m", "z_mom_12_1", "z_trend_20", "z_trend_50", "z_sector_rel_mom_1m", "z_sector_rel_mom_6m"}
                    for _k in list(_blended_ic.keys()):
                        if _k in _MOM_FACTORS and _blended_ic[_k] < 0:
                            _blended_ic[_k] = 0.0

                    # 2. Normalize and clamp the blended raw IC scores to weights
                    default_fw = dict(DEFAULT_CFG).get("FACTOR_WEIGHTS", dict(DEFAULT_CFG)["FACTOR_WEIGHTS"])
                    pos_total_def  = sum(v for v in default_fw.values() if v > 0)
                    blended_total  = sum(v for v in _blended_ic.values() if v > 0) or 1.0
                    scale          = pos_total_def / blended_total

                    _new_weights = {}
                    for _f in _all_f:
                        ic_ir = _blended_ic.get(_f, 0.0)
                        default_abs = abs(default_fw.get(_f, 0.05))
                        raw_w = ic_ir * scale
                        clamped_w = float(np.clip(raw_w, 0.0, 3.0 * default_abs))
                        if _f in _ANCHOR_FLOOR:
                            clamped_w = max(clamped_w, _ANCHOR_FLOOR[_f])
                        _new_weights[_f] = round(clamped_w, 4)

                    _ic_weights = _new_weights
                    log_emit(log_cb, f"[LearnLoop] Blended raw IC and scaled to weights successfully | {len(_ic_weights)} factors")
            except Exception as _le:
                log_emit(log_cb, f"[LearnLoop] blend skipped: {_le}", exc_info=True)

        if _ic_weights:
            # AUDIT-FIX (defect #4): the prior merge included DEFAULT_CFG["FACTOR_WEIGHTS"]
            # in the overlay chain, leaking the default profile's factor weights
            # into every IC-enabled profile and diluting profile identities. The
            # overlay now starts from the profile's OWN cfg FACTOR_WEIGHTS (which
            # is already populated by PROFILE_MAP / cfg inheritance) and applies
            # the IC-blended weights on top, without referencing DEFAULT_CFG.
            cfg = {**cfg, "FACTOR_WEIGHTS": {**cfg.get("FACTOR_WEIGHTS", {}), **_ic_weights}}
    signal_df = compute_signal_frame(data, returns, benchmark_returns, sectors=sectors, cfg=cfg, log_cb=log_cb)
    # R35: microstructure z-scores (z_vpin_toxicity / z_roll_spread) are now
    # computed INSIDE compute_signal_frame BEFORE the FACTOR_WEIGHTS blend —
    # they used to be injected here, after the blend had already dropped them
    # (0.08 dead weight in the 🦄 profile, 0.35 in Vol-Squeeze).
    cfg["_SIGNAL_DF"] = signal_df

    # ── Black-Litterman return estimation ──
    if cfg.get("USE_BLACK_LITTERMAN", False) and not returns.empty and not signal_df.empty:
        try:
            from math_engine.black_litterman import BlackLittermanEstimator
            log_emit(log_cb, "[BlackLitterman] Estimating robust returns (blending priors & neural views)...")
            
            risk_aversion = float(cfg.get("BL_RISK_AVERSION", 2.5))
            tau = float(cfg.get("BL_TAU", 0.05))
            
            bl = BlackLittermanEstimator(risk_aversion=risk_aversion, prior_weight_tau=tau)
            bl_returns = bl.estimate_posterior_returns(returns, signal_df, cfg=cfg)
            if not bl_returns.empty:
                signal_df["alpha_score"] = bl_returns.reindex(signal_df.index).fillna(0.0)
                log_emit(log_cb, f"[BlackLitterman] Blended expected returns into alpha scores for {len(bl_returns)} assets.")
        except Exception as _ble:
            log_emit(log_cb, f"[BlackLitterman] Estimation failed (non-fatal): {_ble}", exc_info=True)
    chart_model_info = dict(signal_df.attrs.get("chart_model_info", {}) or {})
    if chart_model_info:
        _kind = chart_model_info.get("kind", "online")
        if _kind == "ensemble":
            _tfs = ",".join(chart_model_info.get("timeframes", []))
            log_emit(log_cb, f"[ChartSSL] Active ensemble: {_tfs}")
        else:
            _tf = chart_model_info.get("timeframe", "1d")
            _clusters = chart_model_info.get("clusters", 0)
            _samples = chart_model_info.get("sample_count", 0)
            log_emit(log_cb, f"[ChartSSL] Active model: {_kind} {_tf} | clusters={_clusters} | samples={_samples:,}")
    # GS was order-dependent and created inconsistent factor space across runs.
    # PCA is global, deterministic, order-independent. Same data = same basis every run.
    # Strategy: decorrelate only the correlated subset, preserve uncorrelated factors as-is.
    try:
        _z_cols   = [c for c in signal_df.columns if c.startswith("z_")]
        _ic_ref   = cfg.get("FACTOR_WEIGHTS", {})
        _mat_full = signal_df[_z_cols].fillna(0.0)
        _corr_mat = _mat_full.corr().abs()
        np.fill_diagonal(_corr_mat.values, 0.0)
        _max_corr_before = float(_corr_mat.max().max())

        # Only decorrelate factors that actually have correlation > 0.35
        _corr_cols = sorted(
            set(c for c in _z_cols if float(_corr_mat[c].max()) > float(cfg.get("PCA_CORR_THRESHOLD", 0.35))),
            key=lambda c: abs(_ic_ref.get(c, 0.0)), reverse=True
        )

        if len(_corr_cols) >= 2:
            _sub = _mat_full[_corr_cols].values          # shape: (n_stocks, n_factors)
            _U, _S, _Vt = np.linalg.svd(_sub, full_matrices=False)
            _var_exp = (_S ** 2) / ((_S ** 2).sum() + 1e-9)
            _n_keep  = max(1, int((_var_exp > 0.05).sum()))

            # Assign each PCA component to the original factor with highest absolute loading
            # This preserves interpretability — component 0 ≈ "the momentum factor", etc.
            _loadings   = _Vt[:_n_keep, :]           # shape: (n_keep, n_factors)
            _assigned   = set()
            _col_map    = {}
            for _ki in range(_n_keep):
                _sorted_idx = np.argsort(np.abs(_loadings[_ki]))[::-1]
                for _idx in _sorted_idx:
                    _candidate = _corr_cols[_idx]
                    if _candidate not in _assigned:
                        _col_map[_candidate] = _ki
                        _assigned.add(_candidate)
                        break

            # Write decorrelated scores back to their assigned original factor column
            _scores = _U[:, :_n_keep] * _S[:_n_keep]  # shape: (n_stocks, n_keep)
            for _col, _ki in _col_map.items():
                signal_df[_col] = robust_zscore_series(
                    pd.Series(_scores[:, _ki], index=signal_df.index)
                )
            # Zero out correlated factors that weren't assigned a component
            for _col in _corr_cols:
                if _col not in _col_map:
                    signal_df[_col] = 0.0

            # Verify residual correlation
            _corr_after = signal_df[_z_cols].corr().abs()
            np.fill_diagonal(_corr_after.values, 0.0)
            _max_corr_after = float(_corr_after.max().max())
            log_emit(log_cb, f"[FactorOrth] PCA: {len(_corr_cols)} correlated → {_n_keep} components "
                              f"| corr {_max_corr_before:.3f} → {_max_corr_after:.3f}")
        else:
            log_emit(log_cb, f"[FactorOrth] All factors already decorrelated (max_corr={_max_corr_before:.3f}) — skipped")
    except Exception as _oe:
        log_emit(log_cb, f"[FactorOrth] skipped: {_oe}", exc_info=True)
    if cfg.get("_REGIME_INFO"):
        signal_df = apply_regime_bias(signal_df, cfg["_REGIME_INFO"], cfg)
    stocks = list(signal_df.index)

    # Detect if we are in a Bear market condition
    is_bear_market = False
    if cfg.get("_REGIME_INFO"):
        r_info = cfg.get("_REGIME_INFO", {})
        r_lbl = r_info.get("Regime", "")
        p_bear = r_info.get("P_Bear", 0.0)
        if r_lbl == "Defensive (Stale Model)":
            # R34-2 FIX: the stale-model defensive flatten is INTENTIONAL, so we
            # tag it on the shared cfg (same dict object as working_cfg) so the
            # tail of the pipeline (OOS validation, data-quality gate) can tell
            # an *intentional* 100%-cash defensive halt apart from an accidental
            # degenerate run. 2026-09-14 incident: without this flag the run
            # burned ~30s of GEX/option-chain/WFO stages, persisted fabricated
            # OOS Sharpes (-3.53) for an empty portfolio, and only then crashed
            # with a generic "degenerate allocation" error.
            cfg["_DEFENSIVE_FLAT"] = {
                "reason": r_info.get("Reason", "hmm_stale_retrain_failed"),
                "regime": r_lbl,
            }
            log_emit(log_cb, "[Staleness Flatten] HMM regime model is stale (inline retrain unavailable) — "
                             "forcing defensive 100% cash (no positions). The run will halt at the data-quality "
                             "gate with remediation instructions; no trades are placed and no OOS/backtest "
                             "metrics will be computed or persisted for this degenerate allocation.")
            return {}, pd.DataFrame(columns=signal_df.columns), pd.DataFrame()
        if any(x in str(r_lbl) for x in ("Bear", "Stress", "Defensive")) or p_bear > 0.5:
            is_bear_market = True
    try:
        from core.state_manager import AppState as _AS
        if _AS.instance().current_regime == "Bear":
            is_bear_market = True
    except Exception:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
        pass

    bear_min_stocks = cfg.get("BEAR_MIN_STOCKS")
    if bear_min_stocks is None:
        bear_min_stocks = max(int(cfg.get("K_STOCKS", 8)) // 2, 5)
    else:
        bear_min_stocks = int(bear_min_stocks)

    # ── Regime-conditional cash fraction resolution ─────────────────────────
    # If the profile uses the per-regime keys (BEAR/SIDEWAYS/BULL), resolve the
    # correct cash fraction for the current regime label now — before the
    # shortfall logic at line 4194 may overwrite it.
    if cfg.get("BEAR_RESIDUAL_CASH_FRACTION_BEAR") is not None:
        _rcf_lbl = str(r_lbl).lower() if cfg.get("_REGIME_INFO") else "sideways"
        if "bear" in _rcf_lbl or "stress" in _rcf_lbl or "defensive" in _rcf_lbl:
            _rcf = float(cfg.get("BEAR_RESIDUAL_CASH_FRACTION_BEAR", 0.50))
        elif "sideways" in _rcf_lbl or "neutral" in _rcf_lbl or "range" in _rcf_lbl:
            _rcf = float(cfg.get("BEAR_RESIDUAL_CASH_FRACTION_SIDEWAYS", 0.20))
        else:
            _rcf = float(cfg.get("BEAR_RESIDUAL_CASH_FRACTION_BULL", 0.00))
        cfg["BEAR_RESIDUAL_CASH_FRACTION_ACTIVE"] = _rcf

    if len(stocks) < int(cfg.get("K_STOCKS", 8)):
        if len(stocks) > 0:
            bear_cash_fraction = 1.0 - (len(stocks) / float(cfg.get("K_STOCKS", 8)))
            bear_cash_fraction = min(max(bear_cash_fraction, 0.10), 0.90)
            cfg["BEAR_RESIDUAL_CASH_FRACTION_ACTIVE"] = bear_cash_fraction
            log_emit(log_cb, f"[Allocation] Only {len(stocks)} stocks passed trend filters. Scaling target size and reserving {bear_cash_fraction*100:.0f}% in CASH.")
            input_cfg["K_STOCKS_ORIGINAL"] = input_cfg.get("K_STOCKS")
            input_cfg["K_STOCKS"] = len(stocks)
            cfg["K_STOCKS_ORIGINAL"] = cfg.get("K_STOCKS")
            cfg["K_STOCKS"] = len(stocks)
        else:
            log_emit(log_cb, "[Allocation] Zero stocks passed trend filters. Allocating 100% of the portfolio to CASH.")
            return {}, pd.DataFrame(columns=signal_df.columns), pd.DataFrame()

    # ── v17.3: dynamic GAMMA — adapts to cross-sectional alpha dispersion ────
    _alpha_std = float(signal_df["alpha_score"].std())
    _gh_t = float(cfg.get("GAMMA_HIGH_DISP_THRESHOLD", 0.40)); _gh_f = float(cfg.get("GAMMA_HIGH_DISP_FACTOR", 0.70))
    _gm_t = float(cfg.get("GAMMA_MED_HIGH_THRESHOLD", 0.20));  _gm_f = float(cfg.get("GAMMA_MED_HIGH_FACTOR", 0.85))
    _gl_t = float(cfg.get("GAMMA_LOW_DISP_THRESHOLD", 0.08));  _gl_f = float(cfg.get("GAMMA_LOW_DISP_FACTOR", 1.45))
    _gml_t= float(cfg.get("GAMMA_MED_LOW_THRESHOLD", 0.15));   _gml_f= float(cfg.get("GAMMA_MED_LOW_FACTOR", 1.20))
    if   _alpha_std > _gh_t:  _gfactor = _gh_f   # high dispersion → concentrate
    elif _alpha_std > _gm_t:  _gfactor = _gm_f
    elif _alpha_std < _gl_t:  _gfactor = _gl_f   # near-uniform → diversify
    elif _alpha_std < _gml_t: _gfactor = _gml_f
    else:                     _gfactor = 1.00
    cfg = {**cfg, "GAMMA": float(cfg.get("GAMMA", 22.0)) * _gfactor}

    stocks = [s for s in stocks if s in returns.columns]
    if len(stocks) < len(signal_df):
        signal_df = signal_df.loc[stocks]
    clean_rets = returns[stocks].copy()
    
    # Slice clean_rets based on Risk Horizon lookback for covariance/correlation calculation
    risk_horizon = cfg.get("RISK_HORIZON", "Strategic (252d)")
    if "Tactical" in risk_horizon:
        lookback_days = int(cfg.get("TACTICAL_LOOKBACK_DAYS", 30))
        _corr_method = "EWMA"
    else:
        lookback_days = int(cfg.get("STRATEGIC_LOOKBACK_DAYS", 252))
        if HAS_SKLEARN and cfg.get("USE_LEDOIT_WOLF", True):
            _corr_method = "Ledoit-Wolf"
        else:
            _corr_method = cfg.get("RISK_MODEL", "Ledoit-Wolf")
            
    # Override correlation method if Downside / Semi-Covariance is selected
    if "Downside" in cfg.get("RISK_MODEL", "") or "Semi-Covariance" in cfg.get("RISK_MODEL", ""):
        _corr_method = cfg.get("RISK_MODEL", "Ledoit-Wolf")
        
    if len(clean_rets) > lookback_days:
        clean_rets = clean_rets.tail(lookback_days)
        
    # Bug 15 fix: removed dead second spike-clean. scrub_anomalies() already IQR-cleaned.
    corr_shrunk = build_correlation_matrix(clean_rets, method=_corr_method,
                                           shrinkage=float(cfg.get("CORR_SHRINKAGE", 0.25)), cfg=cfg, signal_df=signal_df)
    # Bug 16 fix: allow negative correlations — incentivises hedging pairs.
    corr_penalty = corr_shrunk.clip(lower=-0.95, upper=float(cfg.get("CORR_CLIP_UPPER", 0.95)))

    q = {}
    k = int(cfg.get("K_STOCKS", 8))

    # v17.23 P9: risk composite deflation — alpha scaled down for high-risk stocks
    # Deflation factor: max SCALAR reduction for worst-risk stocks; zero-risk stocks unaffected
    # BUGFIX (Round 41): this block ignored both of its own documented config
    # settings. RISK_DEFLATION_SCALAR ("how aggressively high-risk stocks are
    # alpha-penalised", default 0.30) was never read — the formula used a
    # hardcoded 0.20 instead, a real magnitude difference from what the
    # config claims is applied. ENABLE_RISK_DEFLATION ("False = raw alpha
    # scores, no risk penalty") was never checked at all — deflation always
    # applied unconditionally, so setting it False had zero effect; a user
    # who disabled it to see raw alpha scores would still silently get every
    # stock's alpha cut by up to 20%. Both are now honored; default behavior
    # changes (0.20 -> 0.30 max reduction) since 0.30 is what the config has
    # always claimed was in effect.
    _risk_deflation_on = bool(cfg.get("ENABLE_RISK_DEFLATION", True))
    _risk_deflation_scalar = float(np.clip(cfg.get("RISK_DEFLATION_SCALAR", 0.30), 0.0, 1.0))
    _risk_deflated = {}
    for _s in stocks:
        _rs  = float(signal_df.loc[_s, "risk_score"]) if "risk_score" in signal_df.columns and pd.notna(signal_df.loc[_s, "risk_score"]) else 0.0
        _raw = float(signal_df.loc[_s, "alpha_score"]) if "alpha_score" in signal_df.columns else 0.0
        if _risk_deflation_on:
            _deflation = max(1.0 - _risk_deflation_scalar, 1.0 - _risk_deflation_scalar * float(np.clip(_rs, 0.0, 1.0)))
            _risk_deflated[_s] = _raw * _deflation
        else:
            _risk_deflated[_s] = _raw

    _N = max(float(len(stocks)), 1.0)  # single definition — used by both diagonal & off-diagonal

    # ── Barra Factor Concentration Penalty (QUBO injection) ─────────────────
    # Computes per-stock excess factor exposure that would push the portfolio
    # beyond FACTOR_EXPOSURE_THRESH sigma on any key risk factor.
    # This feeds Barra attribution BACK into stock selection — not just display.
    _fconc_pen = float(cfg.get("FACTOR_CONC_PENALTY", 0.0))
    _fexp_thresh = float(cfg.get("FACTOR_EXPOSURE_THRESH", 1.5))
    # Risk-only factors: abs() symmetric penalty is correct here (extremes in either
    # direction on vol/beta/drawdown metrics are undesirable). Quality factors (z_roe,
    # z_pe_inv) are intentionally excluded — high z_roe is GOOD, not a risk to penalise.
    _BARRA_RISK_FACTORS = ["z_mom_6m", "z_mom_3m", "z_ann_vol", "z_beta_dev",
                           "z_downside_vol"]
    _barra_penalty = {}
    if _fconc_pen > 0.0:
        for _s in stocks:
            _bp = 0.0
            for _fk in _BARRA_RISK_FACTORS:
                if _fk in signal_df.columns and pd.notna(signal_df.loc[_s, _fk]):
                    _fval = float(signal_df.loc[_s, _fk])
                    # Penalise stocks that pull factor exposure far from neutral
                    # (both positive extremes for risk factors and negative extremes)
                    _excess = max(0.0, abs(_fval) - _fexp_thresh)
                    _bp += _excess
            _barra_penalty[_s] = _fconc_pen * _bp

    for s in stocks:
        if prev_holdings and s not in prev_holdings:
            # Estimate daily volatility directly from clean returns series
            daily_vol = float(np.std(clean_rets[s])) if s in clean_rets.columns else 0.015
            adv20 = float(signal_df.loc[s, "adv20"]) if "adv20" in signal_df.columns and pd.notna(signal_df.loc[s, "adv20"]) else 1e6

            k_stocks = int(cfg.get("K_STOCKS", 8))
            q_size = 1.0 / max(k_stocks, 1)

            # Institutional Square-Root Law: Cost = friction * daily_vol * sqrt(trade_value / ADV20)
            # AUDIT-FIX (Round 6, B-P3-11): `q_size` is a dimensionless weight
            # (1/K) while `adv20` is a CURRENCY ADV — the previous ratio was
            # ~1e-5, making this penalty numerically dead; AND the
            # USE_IS_COST_ALPHA_HAIRCUT block (on by default) applies a
            # second, differently-scaled impact model to the same diagonal
            # (double counting). Fix: dimensional consistency — trade value
            # over ADV — and this block is now opt-in via MARKET_IMPACT_IN_QUBO
            # (default off, since the IS-haircut path is the canonical model).
            _port_val_for_impact = float(cfg.get("PORTFOLIO_VALUE_INR", cfg.get("PORTFOLIO_VALUE", 1_000_000)))
            _use_qubo_impact = bool(cfg.get("MARKET_IMPACT_IN_QUBO", False))
            # ── R35: Almgren-Chriss impact-aware turnover (🦄 IPO profile) ────
            # Institutional execution realism for the one book where it bites
            # hardest: 45%-max-weight small caps. The profile's flat
            # TURNOVER_PENALTY stays as the statutory floor; the AC square-root
            # impact (Almgren-Chriss 2001, NSE-calibrated coefficients from
            # Almgren et al. 2005 via the production module
            # ml_alpha/almgren_chriss_impact.py) is ADDED in disclosed QUBO
            # units (AC_QUBO_UNITS_PER_BP, default 0.02/bp — a 60 bp small-cap
            # impact adds 1.2 units ≈ 6.7× the 0.18 flat penalty). Mutually
            # exclusive with MARKET_IMPACT_IN_QUBO (no double counting: the
            # IS-haircut path operates on alpha, this on the turnover leg).
            _use_ac_impact = bool(cfg.get("USE_AC_IMPACT_TURNOVER", False)) and not _use_qubo_impact
            if _use_qubo_impact:
                friction = float(cfg.get("MARKET_IMPACT_FRICTION", 50.0))
                trade_value = q_size * _port_val_for_impact
                market_impact = friction * daily_vol * np.sqrt(trade_value / max(adv20, 1.0))
                turnover_cost = float(cfg.get("TURNOVER_PENALTY", 0.0)) + market_impact
            elif _use_ac_impact:
                try:
                    from math_engine.ipo_multibagger_math import ac_turnover_penalty
                    _r35_ac_order = _port_val_for_impact * min(
                        float(cfg.get("MAX_WEIGHT", 0.45)), 1.0)
                    turnover_cost = ac_turnover_penalty(
                        base_penalty=float(cfg.get("TURNOVER_PENALTY", 0.0)),
                        order_notional=_r35_ac_order,
                        adv_notional=adv20,
                        daily_vol=daily_vol,
                        qubo_units_per_bp=float(cfg.get("AC_QUBO_UNITS_PER_BP", 0.02)),
                    )
                except Exception:
                    turnover_cost = float(cfg.get("TURNOVER_PENALTY", 0.0))
            else:
                turnover_cost = float(cfg.get("TURNOVER_PENALTY", 0.0))
            # ── Tax-Aware Turnover Cost (STCG/LTCG India) ──────────────────
            # Apply 2× penalty for stocks held < 365 days (STCG territory).
            # Holding dates are passed via cfg['_HOLDING_DATES'] dict.
            # BUGFIX (Round 41): the documented DEFAULT_CFG setting is
            # STCG_PENALTY_FACTOR, but this code read only an undocumented
            # STCG_TURNOVER_FACTOR, so tuning the documented key did nothing.
            # STCG_TURNOVER_FACTOR is still honored as an explicit override.
            _holding_dates = cfg.get("_HOLDING_DATES", {})
            if _holding_dates:
                turnover_cost = get_tax_aware_turnover_cost(
                    s, _holding_dates,
                    base_turnover_penalty=turnover_cost,
                    stcg_factor=float(cfg.get("STCG_TURNOVER_FACTOR", cfg.get("STCG_PENALTY_FACTOR", 2.0))),
                )
        else:
            # ── Tax-Aware RETENTION bonus for held STCG positions ──────────
            # AUDIT-FIX (Round 6, B-P2-7): previously the held-branch hard-set
            # turnover_cost = 0.0, but the tax-aware STCG deterrent was only
            # reachable on the NOT-held branch — while HOLDING_DATES (purchase
            # dates) by definition maps ONLY held tickers. The 2× STCG churn
            # deterrent was therefore unreachable for exactly the positions it
            # exists to keep. Held STCG (<365d) positions now earn a *negative*
            # diagonal term (a retention bonus) proportional to the tax cost of
            # selling them early, so the annealer is appropriately sticky about
            # recently-purchased holdings instead of churning them.
            turnover_cost = 0.0
            _holding_dates = cfg.get("_HOLDING_DATES", {}) or {}
            if _holding_dates and s in _holding_dates:
                try:
                    _purchase_date = pd.Timestamp(_holding_dates[s])
                    _days_held = (pd.Timestamp.now() - _purchase_date).days
                    if 0 <= _days_held < 365:
                        _base_pen = float(cfg.get("TURNOVER_PENALTY", 0.0))
                        _stcg_bonus = _base_pen * (float(cfg.get("STCG_TURNOVER_FACTOR", cfg.get("STCG_PENALTY_FACTOR", 2.0))) - 1.0)
                        if _stcg_bonus > 0:
                            turnover_cost = -_stcg_bonus
                except Exception:
                    pass

        beta_cost = float(cfg.get("BETA_PENALTY", 1.0)) * float(signal_df.loc[s, "z_beta_dev"]) if pd.notna(signal_df.loc[s, "z_beta_dev"]) else 0.0
        failed_breakout_risk = float(signal_df.loc[s, "chart_failed_breakout_risk"]) if "chart_failed_breakout_risk" in signal_df.columns and pd.notna(signal_df.loc[s, "chart_failed_breakout_risk"]) else 0.0
        risk_penalty = float(cfg.get("CHART_FAILED_BREAKOUT_RISK_PENALTY", 0.10)) * failed_breakout_risk

        barra_conc_cost = _barra_penalty.get(s, 0.0)
        # ── Sovereign Tier-0: Wasserstein DRO Adversarial Ambiguity Penalty ────
        _dro_eps = float(cfg.get("WASSERSTEIN_DRO_EPSILON", 0.05))
        _downside_unc = float(signal_df.loc[s, "downside_vol"]) if "downside_vol" in signal_df.columns and pd.notna(signal_df.loc[s, "downside_vol"]) else 0.02
        _dro_cost = _dro_eps * max(0.0, _downside_unc)

        base_score = (
            -float(cfg.get("ALPHA", 1.0)) * _risk_deflated[s]
            + float(cfg.get("VOL_PENALTY", 1.0)) * float(signal_df.loc[s, "risk_score"])
            + beta_cost + turnover_cost + risk_penalty + barra_conc_cost + _dro_cost
        )
        _gamma_card = float(cfg.get("GAMMA_CARDINALITY", cfg.get("GAMMA", 22.0)))
        q[(s, s)] = (base_score + _gamma_card * (1 - 2 * k)) / _N  # DIV001: guard divisor before use

    # AUDIT-FIX (defect #1): store build-time alpha contributions so the later
    # re-sync after ML injection can perform a DELTA update instead of an
    # overwrite. Previously the re-sync at optimizer.py:7306-7315 dropped the
    # VOL_PENALTY / beta_cost / turnover_cost / risk_penalty / Barra_conc_cost
    # terms and mixed pre-prune _N scaling with post-prune _n_universe scaling.
    # Storing these snapshots lets the re-sync subtract the original alpha term
    # and add the new one, preserving every other penalty on the diagonal.
    cfg["_QUBO_BUILD_ALPHA_SCORES"] = {s: float(_risk_deflated.get(s, 0.0)) for s in stocks}
    cfg["_QUBO_BUILD_ALPHA"] = float(cfg.get("ALPHA", 1.0))
    cfg["_QUBO_BUILD_N"] = float(_N)
    cfg["_QUBO_BUILD_GAMMA_CARD"] = float(cfg.get("GAMMA_CARDINALITY", cfg.get("GAMMA", 22.0)))
    cfg["_QUBO_BUILD_K_STOCKS"] = int(cfg.get("K_STOCKS", 8))

    _N            = max(len(stocks), 1)
    _theta_scaled = float(cfg.get("THETA", 1.0)) * (len(stocks) / max(int(cfg.get("K_STOCKS", 8)), 1)) ** 0.5
    # Decoupled GAMMA: _gamma_card controls cardinality (sum x_i - K)^2, _gamma_risk controls pairwise risk
    _gamma_risk   = float(cfg.get("GAMMA_RISK", cfg.get("GAMMA", 22.0)))
    _gamma2       = 2.0 * _gamma_risk
    _sec_pen      = float(cfg.get("SECTOR_PENALTY", 0.0)) if cfg.get("ENABLE_SECTOR_CAP", False) else 0.0
    _unk_pen      = float(cfg.get("UNKNOWN_SECTOR_PENALTY", 0.0)) if cfg.get("ENABLE_SECTOR_CAP", False) else 0.0
    _chart_pen    = float(cfg.get("CHART_PATTERN_CORR_PENALTY", 0.0))  # 0=disabled; set >0 to penalise same-cluster pairs

    # Vectorized off-diagonal QUBO construction — O(N²/2) numpy ops vs Python loop
    _corr_vals = corr_penalty.reindex(index=stocks, columns=stocks).values  # (N,N)
    _sec_arr   = np.array([sectors.get(s, "N/A") for s in stocks])
    _has_chart = "chart_pattern_cluster" in signal_df.columns
    _clust_arr = (signal_df["chart_pattern_cluster"].reindex(stocks).values
                  if _has_chart else np.full(len(stocks), None))
    
    _failed_breakout_cov_pen = float(cfg.get("CHART_FAILED_BREAKOUT_COV_PENALTY", 0.05))
    _has_risk = "chart_failed_breakout_risk" in signal_df.columns
    _risk_arr = (signal_df["chart_failed_breakout_risk"].reindex(stocks).values
                 if _has_risk else np.zeros(len(stocks)))

    for i in range(len(stocks)):
        si = stocks[i]
        for j in range(i + 1, len(stocks)):
            sj    = stocks[j]
            pen   = _gamma2 + _theta_scaled * float(_corr_vals[i, j])
            sec_i, sec_j = _sec_arr[i], _sec_arr[j]
            # BUGFIX (Round 41): only the exact string "N/A" was treated as
            # unresolved here, while sector_counts (and the greedy/hybrid
            # seeds downstream) normalize the wider {None,"","NA","na",...}
            # set to "UNKNOWN". A sector value of "" or None slipped through
            # this check as if it were a normal, distinct sector — two such
            # stocks were scored as "same sector" (or worse, as unrelated
            # sectors) instead of both being flagged unresolved.
            _ni, _nj = normalize_sector(sec_i), normalize_sector(sec_j)
            if   _ni == "UNKNOWN" or _nj == "UNKNOWN": pen += _unk_pen
            elif _ni == _nj:                            pen += _sec_pen
            ci, cj = _clust_arr[i], _clust_arr[j]
            if ci is not None and cj is not None and pd.notna(ci) and pd.notna(cj) and ci == cj:
                pen += _chart_pen
            if _has_risk:
                pen += _failed_breakout_cov_pen * (float(_risk_arr[i]) + float(_risk_arr[j]))
            q[(si, sj)] = pen / _N  # DIV001: guard divisor before use

    # v17: turnover-constrained QUBO (penalises new positions over hard cap)
    if cfg.get("USE_TURNOVER_QUBO", True) and prev_holdings:
        q = apply_turnover_qubo_constraint(q, prev_holdings, list(signal_df.index), cfg)

    # v17.CZ: MAX_PER_SECTOR fully dynamic — respects cfg value; 0 = unlimited (Alpha-Concentrated)
    # No silent override. ENABLE_SECTOR_CAP=False disables all sector constraints.

    return q, signal_df, clean_rets

# ── Optimizer Engine ──



# ────────────────────────────────────────────────────────────────────
# FUNC: evaluate_qubo_subset
# ────────────────────────────────────────────────────────────────────
def evaluate_qubo_subset(q, selected):
    chosen = set(selected)
    return float(sum(v for (a, b), v in q.items() if (a == b and a in chosen) or (a != b and a in chosen and b in chosen)))



# ────────────────────────────────────────────────────────────────────
# FUNC: compute_hyperparameter_sensitivity
# ────────────────────────────────────────────────────────────────────
def compute_hyperparameter_sensitivity(q: dict, signal_df: pd.DataFrame,
                                       sectors: dict, cfg: dict,
                                       log_cb=None,
                                       raw_data: dict = None,
                                       clean_returns: pd.DataFrame = None,
                                       benchmark_returns: pd.Series = None,
                                       prev_holdings: list = None) -> pd.DataFrame:
    """
    Portfolio Hyperparameter Sensitivity Analysis.

    Grid-searches perturbations of GAMMA, ALPHA, and VOL_PENALTY to reveal
    how stable the portfolio selection is to parameter changes. High
    stability (overlap >=80%) means the portfolio is robust; low stability
    signals sensitivity to tuning choices.

    R46 FIX (M-2 regression, Round 42 contract): the ``raw_data`` keyword
    was dropped from the signature when this function was rewritten;
    callers that pass ``raw_data=...`` (e.g. the dashboard sensitivity
    panel and tests/test_round42_audit_fixes.py) raised ``TypeError:
    got an unexpected keyword argument 'raw_data'``. The parameter is
    restored (DataFrame or None; used only as a price fallback when the
    caller wants re-priced diagnostics — None keeps the pure signal_df
    path, which never touches 'Close' so no KeyError is possible).

    R46 FIX (grid contract, Round 41): the delta grid is again driven by
    ``cfg['SENSITIVITY_DELTAS']`` when supplied (the Round 41/42 contract:
    a 3-point [0.90, 1.00, 1.10] grid must yield exactly 27 rows). The
    rewritten version hardcoded a 5-point grid (125 combos) and ignored
    the caller's grid. Default remains the 5-point +-20% grid so existing
    dashboards keep their richer sweep unless they opt out.

    Returns a DataFrame with columns:
        GAMMA×, ALPHA×, VOL×, Overlap (int), Stability%, Selected (sample)

    Useful for the Diagnostics tab to validate parameter calibration.
    """
    from itertools import product as _product

    base_gamma = float(cfg.get("GAMMA", 22.0))
    base_alpha = float(cfg.get("ALPHA", 1.8))
    base_vol   = float(cfg.get("VOL_PENALTY", 0.5))
    k          = int(cfg.get("K_STOCKS", 8))
    _cfg_deltas = cfg.get("SENSITIVITY_DELTAS")
    if isinstance(_cfg_deltas, (list, tuple)) and len(_cfg_deltas) >= 1:
        deltas = [float(d) for d in _cfg_deltas]
    else:
        deltas = [0.80, 0.90, 1.00, 1.10, 1.20]  # default: ±20% in 10% steps

    log_emit(log_cb, f"[Sensitivity] Starting hyperparameter grid search ({len(deltas) ** 3} combos)…")

    # Baseline solve
    try:
        base_selected, _, _ = solve_qubo(q, signal_df, sectors, cfg, log_cb=None)
    except Exception:
        log_emit(log_cb, "[Sensitivity] Baseline solve failed — aborting.")
        return pd.DataFrame()

    base_set = set(base_selected)
    if not base_set:
        return pd.DataFrame()

    rows = []
    for dg, da, dv in _product(deltas, deltas, deltas):
        if (dg, da, dv) == (1.0, 1.0, 1.0):
            # Insert base row
            rows.append({
                "GAMMA×": "1.00", "ALPHA×": "1.00", "VOL×": "1.00",
                "Overlap": k, "Stability%": "100%",
                "Selected": ", ".join(sorted(base_set)[:4]) + ("..." if len(base_set) > 4 else ""),
            })
            continue
        try:
            trial_cfg = dict(cfg)
            trial_cfg["GAMMA"]       = base_gamma * dg
            trial_cfg["ALPHA"]       = base_alpha * da
            trial_cfg["VOL_PENALTY"] = base_vol   * dv
            # R46 FIX (M-2, full restoration): when the caller supplies the raw
            # OHLCV frame plus clean returns, rebuild each grid combo's QUBO
            # through the REAL pipeline (build_qubo) so the sensitivity sweep
            # reflects genuine covariance / sector / cluster interactions.
            # The original Round 42/44 bug passed signal_df where build_qubo
            # expected raw OHLCV -> KeyError('Close') on every combo, silently
            # swallowed, and the Diagnostics sensitivity table could never
            # show real data. Without raw data we keep the rescale
            # approximation (preserves pairwise structure of the base QUBO).
            if raw_data is not None and clean_returns is not None and not clean_returns.empty:
                trial_q, _, _ = build_qubo(
                    raw_data, clean_returns, benchmark_returns,
                    sectors, prev_holdings, trial_cfg, log_cb=None
                )
            else:
                if raw_data is None and clean_returns is not None and not clean_returns.empty:
                    log_emit(log_cb, "[Sensitivity] raw OHLCV frame not supplied — "
                             "faithful rebuild unavailable; using rescale approximation.")
                trial_q = {}
                _card_g = float(trial_cfg.get("GAMMA_CARDINALITY", trial_cfg.get("CARDINALITY_GAMMA", trial_cfg["GAMMA"])))
                _risk_g = float(trial_cfg.get("GAMMA_RISK", trial_cfg["GAMMA"]))
                for s in signal_df.index:
                    av = float(signal_df.loc[s, "alpha_score"]) if ("alpha_score" in signal_df.columns and pd.notna(signal_df.loc[s, "alpha_score"])) else 0.0
                    rv = float(signal_df.loc[s, "risk_score"])  if ("risk_score" in signal_df.columns and pd.notna(signal_df.loc[s, "risk_score"]))  else 0.0
                    trial_q[(s, s)] = (-trial_cfg["ALPHA"] * av
                                       + trial_cfg["VOL_PENALTY"] * rv
                                       + _card_g * (1 - 2 * k))
                idx = list(signal_df.index)
                for i, si in enumerate(idx):
                    for j in range(i + 1, len(idx)):
                        trial_q[(si, idx[j])] = 2.0 * _risk_g

            sel, _, _ = solve_qubo(trial_q, signal_df, sectors, trial_cfg, log_cb=None)
            overlap   = len(set(sel) & base_set)
            stability = f"{overlap / max(len(base_set), 1) * 100:.0f}%"
            rows.append({
                "GAMMA×":    f"{dg:.2f}",
                "ALPHA×":    f"{da:.2f}",
                "VOL×":      f"{dv:.2f}",
                "Overlap":   overlap,
                "Stability%": stability,
                "Selected":  ", ".join(sorted(sel)[:4]) + ("..." if len(sel) > 4 else ""),
            })
        except Exception:
            import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
            continue

    if not rows:
        return pd.DataFrame()

    df_out = pd.DataFrame(rows).sort_values("Overlap", ascending=False).reset_index(drop=True)
    low_stab = (df_out["Overlap"] < len(base_set) * 0.6).sum()
    log_emit(log_cb,
             f"[Sensitivity] {len(df_out)} param combos tested | "
             f"{low_stab} combos caused >40% portfolio change "
             f"({'fragile — consider recalibrating' if low_stab > 20 else 'robust'})")
    return df_out



# ────────────────────────────────────────────────────────────────────
# FUNC: solve_qubo
# ────────────────────────────────────────────────────────────────────
def solve_qubo(q, signal_df, sectors, cfg, log_cb=None):
    from data_layer import DEFAULT_CFG
    cfg = {**DEFAULT_CFG, **(cfg or {})}
    if not q or signal_df.empty:
        return [], 0.0, "empty"
    # BUG-O4 FIX: dimod is still a runtime dependency for solve_qubo.
    # requirements.txt now includes dimod>=0.12.0. Guard here for clarity.
    if dimod is None:
        err = (
            "dimod is required for QUBO solving but is not installed. "
            "Run: pip install 'dimod>=0.12.0'"
        )
        log_emit(log_cb, f"[QUBO] ❌ {err}")
        raise ImportError(err)
    bqm = dimod.BinaryQuadraticModel.from_qubo(q)
    all_stocks = list(signal_df.index)
    mode = cfg.get("OPTIMIZER_MODE", "Hybrid")

    # Phase 3.8: Wire apply_regime_qubo_constraints into solve_qubo.
    # Previously this function was dead code — fully implemented and tested but
    # never called. The "regime-aware QUBO" feature was non-functional.
    # Now: if regime info is available AND the cfg requests it, apply regime
    # constraints to the BQM before sampling.
    if cfg.get("USE_REGIME_QUBO", False) and cfg.get("_REGIME_INFO"):
        try:
            _rinfo = cfg["_REGIME_INFO"]
            _regime_label = _rinfo.get("Regime", "")
            _confidence = float(_rinfo.get("Confidence", 1.0))
            # Compute mu (expected returns) and cov from signal_df alpha_score
            # as a proxy (full factor model is too expensive per-solve)
            _mu = np.array([float(signal_df.loc[s, "alpha_score"]) for s in all_stocks], dtype=float)
            # Simple covariance proxy from z-scored risk columns if available
            _risk_cols = [c for c in signal_df.columns if c.startswith("z_") and "vol" in c.lower()]
            if _risk_cols:
                _cov = np.eye(len(all_stocks)) * float(signal_df[_risk_cols[0]].clip(0.01, 1.0).mean())
            else:
                _cov = np.eye(len(all_stocks)) * 0.04  # 20% vol default
            apply_regime_qubo_constraints(
                bqm, all_stocks, _mu, _cov,
                regime=_regime_label,
                confidence=_confidence,
                cash_var=None,  # no cash variable in standard QUBO
                log_cb=log_cb,
            )
            log_emit(log_cb, f"[Phase3.8] Regime QUBO constraints applied: regime={_regime_label}, conf={_confidence:.2f}")
        except Exception as _rqe:
            log_emit(log_cb, f"[Phase3.8] Regime QUBO constraints skipped: {_rqe}", exc_info=True)

    # I3-fix: MIP mode bypasses all QUBO/SA overhead — exact, fast, deterministic
    if mode == "MIP":
        return solve_mip_selection(signal_df, sectors, cfg, log_cb=log_cb)

    # ── Greedy seed ──
    # AUDIT-FIX (defect #P0-7): the prior implementation let "N/A"-sector
    # tickers bypass the cap entirely (`sectors.get(s, "N/A") == "N/A"
    # was a *skip* condition). We normalize N/A to "UNKNOWN" and subject
    # those tickers to the same max_sector cap so unresolved-sector
    # tickers cannot pile past the SEBI concentration limit.
    _NA_SECTOR_VALUES_Q = {"N/A", "NA", "n/a", "na", "", None, "None", "null"}
    def _norm_sec_q(s_val):
        if s_val in _NA_SECTOR_VALUES_Q or (isinstance(s_val, str) and not s_val.strip()):
            return "UNKNOWN"
        return s_val
    ranked = sorted(all_stocks, key=lambda x: float(signal_df.loc[x, "alpha_score"]), reverse=True)
    greedy = []
    # R46 FIX (M-5 regression, Round 42/44 contract): the greedy seed applied
    # MAX_PER_SECTOR unconditionally — it never checked ENABLE_SECTOR_CAP. In
    # pure-alpha mode (ENABLE_SECTOR_CAP=False) a same-sector universe could
    # never fill K_STOCKS (e.g. 10 IT stocks, K=5, MAX_PER_SECTOR=2 -> only 2
    # selected). utils.local_search_improve / utils.repair_selection already
    # gate on ENABLE_SECTOR_CAP; the seed now does the same, and it no longer
    # hard-indexes cfg["MAX_PER_SECTOR"] (KeyError when the key is absent and
    # the cap is disabled).
    _seed_sec_cap_on = bool(cfg.get("ENABLE_SECTOR_CAP", False))
    _seed_max_sec = int(cfg.get("MAX_PER_SECTOR", 0)) if _seed_sec_cap_on else 0
    for s in ranked:
        if _seed_sec_cap_on and _seed_max_sec > 0:
            sc = sector_counts(greedy, sectors)
            _sec_q = _norm_sec_q(sectors.get(s, "N/A"))
            if sc.get(_sec_q, 0) >= _seed_max_sec:
                continue
        greedy.append(s)
        if len(greedy) == cfg["K_STOCKS"]:
            break

    best_selected, best_energy = local_search_improve(greedy, all_stocks, q, signal_df, sectors, cfg)
    best_source = "greedy+local"

    if mode == "Greedy":
        return best_selected, float(best_energy), best_source

    # ── QPU / SimulatedAnnealing sampling ──
    qpu_native_requested = (mode == "QPU (Native)")
    sampler, sampler_label = _get_quantum_sampler(log_cb, qpu_native=qpu_native_requested)

    if sampler_label == "DWaveSampler":
        try:
            check_stop()
            # Phase 3.10: Fixed chain_strength calculation.
            # Previously: chain_strength = 1.5 * max(abs(v) for v in q.values())
            # This used the GLOBAL max which is dominated by diagonal terms (large).
            # D-Wave recommends chain_strength ≈ 1.5× the typical off-diagonal
            # coupling, NOT 1.5× the global max. Over-strong chains freeze all
            # qubits to their ground state, preventing exploration — the QPU
            # effectively returns the greedy solution.
            if q:
                # Off-diagonal terms only (a != b) — these are the couplings
                _off_diag_max = max((abs(v) for (a, b), v in q.items() if a != b), default=1.0)
            else:
                _off_diag_max = 1.0
            chain_strength = 1.5 * _off_diag_max
            log_emit(log_cb, f"[Phase3.10] D-Wave chain_strength={chain_strength:.4f} (off-diag max={_off_diag_max:.4f})")
            
            num_reads = int(cfg.get("QPU_NUM_READS", 100))
            log_emit(log_cb, f"[QPU] Running native QPU solve with chain_strength={chain_strength:.4f}, num_reads={num_reads}")
            
            ss = sampler.sample(bqm, chain_strength=chain_strength, num_reads=num_reads)
            raw_selected = [s for s, bit in ss.first.sample.items() if bit == 1]
            repaired = repair_selection(raw_selected, all_stocks, q, signal_df, sectors, cfg)
            improved, energy = local_search_improve(repaired, all_stocks, q, signal_df, sectors, cfg)
            if energy < best_energy:
                best_selected, best_energy, best_source = improved, energy, f"QPU_Native:{sampler_label}"
        except Exception as e:
            log_emit(log_cb, f"[WARN] Native QPU sample failed: {e}. Using greedy result.", exc_info=True)
    elif sampler_label == "LeapHybridSampler":
        try:
            check_stop()
            ss = sampler.sample(bqm, time_limit=int(cfg.get("QPU_TIME_LIMIT_SEC", 3)))   # QPU budget per solve
            raw_selected = [s for s, bit in ss.first.sample.items() if bit == 1]
            repaired = repair_selection(raw_selected, all_stocks, q, signal_df, sectors, cfg)
            improved, energy = local_search_improve(repaired, all_stocks, q, signal_df, sectors, cfg)
            if energy < best_energy:
                best_selected, best_energy, best_source = improved, energy, f"QPU:{sampler_label}"
        except Exception as e:
            log_emit(log_cb, f"[WARN] Leap QPU sample failed: {e}. Using greedy result.", exc_info=True)
    else:
        global _qpu_warn_emitted
        if qpu_native_requested:
            if not _qpu_warn_emitted:
                log_emit(log_cb, "[WARN] QPU (Native) requested but fell back to SimulatedAnnealing CPU simulation.")
                _qpu_warn_emitted = True
            else:
                log_emit(log_cb, "[INFO] QPU (Native) requested but fell back to SimulatedAnnealing CPU simulation.")
        elif mode == "Hybrid":
            if not _qpu_warn_emitted:
                log_emit(log_cb, "[WARN] QPU Hybrid requested but fell back to SimulatedAnnealing CPU simulation.")
                _qpu_warn_emitted = True
            else:
                log_emit(log_cb, "[INFO] QPU Hybrid requested but fell back to SimulatedAnnealing CPU simulation.")
            
        n_vars = len(bqm.variables)
        scale_factor = min(max(1.0, n_vars / 50.0), 2.0)  # v17.35-fix: cap at 2x
        num_reads = int(int(cfg.get("NUM_READS", 1200)) * scale_factor)
        num_sweeps = int(int(cfg.get("NUM_SWEEPS", 1500)) * scale_factor)
        if cfg.get("_WFO_STEP", False):
            num_reads = min(num_reads, int(cfg.get("WFO_MAX_READS", 400)))
            num_sweeps = min(num_sweeps, int(cfg.get("WFO_MAX_SWEEPS", 500)))
        for i in range(int(cfg.get("MULTI_STARTS", 1))):
            check_stop()
            seed = int(cfg.get("SEED", 42) + 97 * i)
            try:
                ss = sampler.sample(
                    bqm,
                    num_reads=num_reads,
                    num_sweeps=num_sweeps,
                    seed=seed,
                    interrupt_function=lambda: (lambda ev: ev is not None and ev.is_set())(_ACTIVE_STOP_EVENT),
                )
                raw_selected = [s for s, bit in ss.first.sample.items() if bit == 1]
                repaired = repair_selection(raw_selected, all_stocks, q, signal_df, sectors, cfg)
                improved, energy = local_search_improve(repaired, all_stocks, q, signal_df, sectors, cfg)
                if energy < best_energy:
                    best_selected, best_energy, best_source = improved, energy, f"SA_seed_{seed}"
            except Exception as e:
                log_emit(log_cb, f"[WARN] SA multi-start {i} failed: {e}", exc_info=True)

    if mode == "Anneal":
        return best_selected, float(best_energy), best_source

    # ── Hybrid diversification pass ──
    # AUDIT-FIX (defect #P0-7): same fix as the greedy seed — normalize N/A
    # to UNKNOWN and subject those tickers to the same max_sector cap.
    seen_sector = Counter()
    hybrid_seed = []
    for s in ranked:
        sec = _norm_sec_q(sectors.get(s, "N/A"))
        _max_sec = int(cfg.get("MAX_PER_SECTOR", 0))
        _hybrid_sec_on = cfg.get("ENABLE_HYBRID_SECTOR_PASS", False) and cfg.get("ENABLE_SECTOR_CAP", False)
        if _hybrid_sec_on and _max_sec > 0 and seen_sector[sec] >= _max_sec:
            continue
        hybrid_seed.append(s)
        seen_sector[sec] += 1
        if len(hybrid_seed) == cfg["K_STOCKS"]:
            break
    hybrid_sel, hybrid_energy = local_search_improve(hybrid_seed, all_stocks, q, signal_df, sectors, cfg)
    if hybrid_energy < best_energy:
        best_selected, best_energy, best_source = hybrid_sel, hybrid_energy, "hybrid_diversified"

    return best_selected, float(best_energy), best_source
# ── Walk-Forward Optimization ──



# ────────────────────────────────────────────────────────────────────
# FUNC: compute_alpha_proportional_weights
# ────────────────────────────────────────────────────────────────────
def compute_alpha_proportional_weights(selected, signal_df, cfg, min_w=None, max_w=None):
    """
    v17.3: Softmax alpha-proportional weights.
    Temperature T = 0.5 × std(alpha_scores) auto-scales concentration to signal dispersion.
    Clips to [min_w, max_w] and renormalises iteratively.
    """
    if not selected:
        return {}
    min_w = min_w if min_w is not None else cfg.get("MIN_WEIGHT", 0.0)  # 0.0 matches DEFAULT_CFG
    max_w = max_w if max_w is not None else cfg.get("MAX_WEIGHT", 0.50)  # 0.50 matches DEFAULT_CFG
    alphas = {}
    for s in selected:
        a = float(signal_df.loc[s, "alpha_score"]) if s in signal_df.index else 0.0
        alphas[s] = a if pd.notna(a) else 0.0
    vals = np.array([alphas[s] for s in selected])
    T    = max(float(vals.std()) * float(cfg.get("SOFTMAX_TEMP_MULTIPLIER", 0.50)), 0.05)
    expv = np.exp((vals - vals.max()) / T)  # DIV001: guard divisor before use
    base = expv / max(float(expv.sum()), 1e-12)
    projected = _project_weights_to_bounds(base, lower=min_w, upper=max_w)
    return {s: float(projected[i]) for i, s in enumerate(selected)}



# ────────────────────────────────────────────────────────────────────
# FUNC: calculate_risk_parity_weights
# ────────────────────────────────────────────────────────────────────




# ────────────────────────────────────────────────────────────────────
# FUNC: calculate_qubo_aware_weights
# ────────────────────────────────────────────────────────────────────
def bai_ng_k(returns: np.ndarray, k_max: int = 10) -> int:
    """Bai-Ng (2002) IC criterion for automatic factor count selection."""
    T, N = returns.shape
    if N < 2 or T < 4:
        return 1
    
    k_max = min(k_max, N - 1, T - 2)
    if k_max < 1:
        return 1
        
    ic = []
    # Demean returns
    X = returns - returns.mean(axis=0)
    
    # Run SVD
    u, s, vt = np.linalg.svd(X, full_matrices=False)
    
    for k in range(1, k_max + 1):
        F = u[:, :k] * s[:k]
        B = vt[:k, :].T
        resid = X - F @ B.T
        sigma2 = np.mean(resid**2)
        if sigma2 < 1e-12:
            sigma2 = 1e-12
        # Penalty function (IC_p2)
        penalty = k * (N + T) / (N * T) * np.log(min(N, T))
        ic.append(np.log(sigma2) + penalty)
        
    return int(np.argmin(ic) + 1)


def poet_covariance(returns_df: pd.DataFrame, k_max: int = 10) -> np.ndarray:
    """POET (Principal Orthogonal complEment Thresholding) covariance estimator."""
    from sklearn.decomposition import PCA
    
    X = returns_df.fillna(0.0).values
    T, N = X.shape
    
    if T < 10:
        cov_sample = np.cov(X, rowvar=False)
        if N == 1:
            cov_sample = np.array([[cov_sample]])
        return cov_sample + np.eye(N) * 1e-6
        
    X_mean = X - X.mean(axis=0)
    
    k = bai_ng_k(X_mean, k_max)
    
    pca = PCA(n_components=k)
    factor_returns = pca.fit_transform(X_mean)
    factor_loadings = pca.components_
    
    Phi = np.cov(factor_returns, rowvar=False)
    if k == 1:
        Phi = np.array([[Phi]])
        
    systematic_cov = factor_loadings.T @ Phi @ factor_loadings
    
    residuals = X_mean - factor_returns @ factor_loadings
    sample_resid_cov = np.cov(residuals, rowvar=False)
    if N == 1:
        sample_resid_cov = np.array([[sample_resid_cov]])
        
    # Soft-threshold idiosyncratic risk
    lambd = 0.5 * np.sqrt(np.log(N) / T)
    
    diag_vars = np.diag(sample_resid_cov)
    std_devs = np.sqrt(np.clip(diag_vars, 1e-8, None))
    
    Psi = np.zeros((N, N))
    for i in range(N):
        for j in range(N):
            if i == j:
                Psi[i, j] = sample_resid_cov[i, j]
            else:
                val = sample_resid_cov[i, j]
                t_ij = lambd * std_devs[i] * std_devs[j]
                if abs(val) > t_ij:
                    Psi[i, j] = np.sign(val) * (abs(val) - t_ij)
                else:
                    Psi[i, j] = 0.0
                    
    Sigma = systematic_cov + Psi
    
    min_eig = np.min(np.linalg.eigvalsh(Sigma))
    if min_eig < 1e-8:
        Sigma += np.eye(N) * (abs(min_eig) + 1e-6)
        
    return Sigma


def estimate_factor_expected_returns(clean_returns: pd.DataFrame, selected: list, qubo_norm: np.ndarray) -> np.ndarray:
    """Estimate expected returns using a Statistical Factor Model with QUBO active alpha tilt.

    Phase 3.7: Removed the hardcoded 6% risk-free rate (rf_daily = 0.06/252).
    A constant added to ALL stocks' expected returns doesn't change the argmax of
    `mu @ w - 0.5 * gamma * w'Σw` — it only shifts the objective level. So the rf
    term was a no-op that made the reported expected returns look inflated by 6%
    without affecting portfolio construction. Removed for honesty.

    Also capped active_alpha to ±15% annualized — previously a stock with
    qubo_norm=1.0 and specific_vol=1.0 got active_alpha=0.5 (50% annualized!),
    which wildly dominated the systematic term and produced absurd MVO weights.
    """
    from sklearn.decomposition import PCA

    n = len(selected)
    _safe_sel = [c for c in selected if c in clean_returns.columns] if clean_returns is not None else []
    if len(_safe_sel) < 2:
        return 0.05 + qubo_norm * 0.20
    X = clean_returns[_safe_sel].fillna(0.0).values
    T, N = X.shape

    if T < 10:
        return 0.05 + qubo_norm * 0.20

    X_mean = X - X.mean(axis=0)

    k = min(3, bai_ng_k(X_mean, 5))

    pca = PCA(n_components=k)
    factor_returns = pca.fit_transform(X_mean)
    factor_loadings = pca.components_

    E_F = np.mean(factor_returns, axis=0)
    betas = factor_loadings.T

    # Phase 3.7: Removed rf_daily (was hardcoded 6% — a constant that doesn't
    # affect argmax but inflated reported expected returns by 6%).
    expected_systematic_daily = betas @ E_F

    residuals = X_mean - factor_returns @ factor_loadings
    specific_vols = np.std(residuals, axis=0) * np.sqrt(252.0)
    specific_vols = np.clip(specific_vols, 0.05, 1.0)

    # Phase 3.7: Cap active_alpha to ±15% annualized (was unbounded — could hit 50%+)
    active_alpha = (qubo_norm - 0.5) * specific_vols
    active_alpha = np.clip(active_alpha, -0.15, 0.15)
    expected_returns_annual = expected_systematic_daily * 252.0 + active_alpha
    return expected_returns_annual


# ────────────────────────────────────────────────────────────────────
# FUNC: calculate_qubo_aware_weights
# ────────────────────────────────────────────────────────────────────



# ──────────────────────────────# ────────────────────────────────────────────────────────────────────────────
# FUNC: apply_regime_qubo_constraints
# Regime-aware BQM modifier — wires HMM AppState directly into the D-Wave
# QUBO to produce mathematically differentiated portfolio constraints.
# ────────────────────────────────────────────────────────────────────────────

def apply_regime_qubo_constraints(
    bqm,
    stock_vars: list,
    mu: "np.ndarray",
    cov: "np.ndarray",
    regime: "str | None" = None,
    confidence: float = 1.0,
    cash_var: "str | None" = "CASH",
    log_cb=None,
) -> dict:
    """Modify a BinaryQuadraticModel with regime-conditional portfolio constraints.

    Mathematical Rationale:
        Standard QUBO objective:
            H = -alpha*mu'*q + gamma*q'*Sigma*q + theta*(sum(q)-K)^2

        This function applies additive regime-conditional modifiers on top of
        any existing BQM terms, so the regime *tilts* rather than *overrides*.

        Bull Regime (mu_regime > 0, low RV):
            - Reduce gamma by BULL_COV_DISCOUNT*confidence  (allow concentration)
            - Negative linear bias on top-K momentum assets  (boost up to 25%)
            - Positive bias on CASH variable (penalise holding cash)

        Bear / Sideways Regime (mu_regime <= 0, high RV):
            - Increase gamma by BEAR_COV_AMPLIFIER*confidence (force diversification)
            - Extra quadratic penalty on all pairs with corr > 0.65
            - Large negative bias on CASH (attract solver toward >=30% cash)

        All penalties are scaled by `confidence` so low-certainty regimes
        apply weaker modifications.

    Args:
        bqm:        dimod.BinaryQuadraticModel — mutated in-place.
        stock_vars: Variable names in the BQM, length N (same order as mu/cov).
        mu:         Expected return vector, shape (N,).
        cov:        Covariance matrix, shape (N, N).
        regime:     "Bull" | "Bear" | "Sideways".  Reads AppState if None.
        confidence: HMM posterior confidence in (0, 1].
        cash_var:   BQM variable name for cash-equivalent, or None.
        log_cb:     Optional callable(str) for log output.

    Returns:
        dict with "regime", "confidence", "cov_modifier", "cash_bias",
        "n_corr_penalised".
    """
    import numpy as np

    # Hyperparameters
    BULL_COV_DISCOUNT   = 0.30
    BULL_MOM_BOOST      = 0.25
    BULL_TOP_K          = 5
    BEAR_COV_AMPLIFIER  = 1.80
    BEAR_CORR_THRESHOLD = 0.65
    BEAR_CORR_PENALTY   = 2.00
    CASH_BULL_PENALTY   = 2.00
    CASH_BEAR_BONUS     = 5.00

    if regime is None:
        try:
            from core.state_manager import AppState as _AS
            _s = _AS.instance()
            regime = _s.current_regime
            if confidence == 1.0:
                confidence = _s.regime_confidence
        except Exception:
            regime = "Unknown"

    regime = str(regime).strip()
    N = len(stock_vars)
    mu_arr  = np.asarray(mu,  dtype=np.float64).ravel()[:N]
    cov_arr = np.asarray(cov, dtype=np.float64)[:N, :N]
    conf    = float(np.clip(confidence, 0.50, 1.0))

    n_corr_penalised = 0
    cov_modifier     = 1.0
    cash_bias        = 0.0

    def _log(msg):
        if log_cb:
            log_cb(f"[RegimeQUBO] {msg}")

    _log(f"regime={regime} | conf={conf:.2f} | N={N}")

    if regime == "Bull":
        cov_scale = 1.0 - BULL_COV_DISCOUNT * conf
        for i, vi in enumerate(stock_vars):
            for j, vj in enumerate(stock_vars):
                if i >= j:
                    continue
                ex = bqm.get_quadratic(vi, vj, default=0.0)
                if ex != 0.0:
                    bqm.set_quadratic(vi, vj, ex * cov_scale)
        cov_modifier = cov_scale

        top_k_idx = np.argsort(mu_arr)[::-1][:BULL_TOP_K]
        mu_max = mu_arr[top_k_idx].max() if len(top_k_idx) else 1.0
        for idx in top_k_idx:
            boost = -BULL_MOM_BOOST * conf * (mu_arr[idx] / (mu_max + 1e-9))
            ex = bqm.linear.get(stock_vars[idx], 0.0)
            bqm.set_linear(stock_vars[idx], ex + boost)

        if cash_var and cash_var in bqm.variables:
            cash_bias = +CASH_BULL_PENALTY * conf
            bqm.set_linear(cash_var, bqm.linear.get(cash_var, 0.0) + cash_bias)

        _log(f"Bull: cov_scale={cov_scale:.3f} | cash_bias={cash_bias:+.2f}")

    elif regime in ("Bear", "Sideways"):
        cov_scale = 1.0 + (BEAR_COV_AMPLIFIER - 1.0) * conf
        for i, vi in enumerate(stock_vars):
            for j, vj in enumerate(stock_vars):
                if i >= j:
                    continue
                ex = bqm.get_quadratic(vi, vj, default=0.0)
                if ex != 0.0:
                    bqm.set_quadratic(vi, vj, ex * cov_scale)
        cov_modifier = cov_scale

        std = np.sqrt(np.diag(cov_arr))
        outer = np.outer(std, std)
        outer[outer < 1e-12] = 1e-12
        corr = cov_arr / outer
        for i in range(N):
            for j in range(i + 1, N):
                if abs(corr[i, j]) > BEAR_CORR_THRESHOLD:
                    pen = BEAR_CORR_PENALTY * conf * abs(corr[i, j])
                    ex = bqm.get_quadratic(stock_vars[i], stock_vars[j], default=0.0)
                    bqm.set_quadratic(stock_vars[i], stock_vars[j], ex + pen)
                    n_corr_penalised += 1

        if cash_var and cash_var in bqm.variables:
            cash_bias = -CASH_BEAR_BONUS * conf
            bqm.set_linear(cash_var, bqm.linear.get(cash_var, 0.0) + cash_bias)

        _log(f"{regime}: cov_scale={cov_scale:.3f} | corr_pairs={n_corr_penalised} | cash_bias={cash_bias:+.2f}")

    else:
        _log(f"Unknown regime '{regime}' — no QUBO modification.")

    return {
        "regime": regime,
        "confidence": conf,
        "cov_modifier": cov_modifier,
        "cash_bias": cash_bias,
        "n_corr_penalised": n_corr_penalised,
    }


def compute_brinson_attribution(returns, weights_history, bench_weights_history, sectors):
    """Calculate daily sector-level Allocation, Selection, and Interaction effects
    and aggregate them cumulatively over time.
    """
    dates = sorted(list(weights_history.keys()))
    if not dates:
        return pd.DataFrame()
        
    all_sectors = set(sectors.values())
    all_sectors.add("Cash/Other")
    all_sectors = sorted(list(all_sectors))
    
    sector_attrib = {sec: {"allocation": 0.0, "selection": 0.0, "interaction": 0.0} for sec in all_sectors}
    
    # Pre-clean sector mapping keys to handle suffix mismatch
    sector_map = {}
    for k, v in sectors.items():
        sector_map[k] = v
        if k.endswith(".NS"):
            sector_map[k[:-3]] = v
        else:
            sector_map[k + ".NS"] = v
            
    for d in dates:
        if d not in returns.index:
            continue
        p_weights = weights_history[d]
        b_weights = bench_weights_history[d]
        r_d = returns.loc[d]
        
        # Calculate cash/unallocated weight in portfolio
        p_sum = sum(p_weights.values())
        p_cash = max(0.0, 1.0 - p_sum)
        
        p_sec_weights = {}
        b_sec_weights = {}
        p_sec_returns_num = {}
        b_sec_returns_num = {}
        
        p_sec_weights["Cash/Other"] = p_cash
        b_sec_weights["Cash/Other"] = 0.0
        p_sec_returns_num["Cash/Other"] = 0.0
        
        for ticker, w in p_weights.items():
            sec = sector_map.get(ticker, "Cash/Other")
            p_sec_weights[sec] = p_sec_weights.get(sec, 0.0) + w
            ret = r_d.get(ticker, 0.0)
            if pd.isna(ret):
                ret = 0.0
            p_sec_returns_num[sec] = p_sec_returns_num.get(sec, 0.0) + w * ret
            
        for ticker, w in b_weights.items():
            sec = sector_map.get(ticker, "Cash/Other")
            b_sec_weights[sec] = b_sec_weights.get(sec, 0.0) + w
            ret = r_d.get(ticker, 0.0)
            if pd.isna(ret):
                ret = 0.0
            b_sec_returns_num[sec] = b_sec_returns_num.get(sec, 0.0) + w * ret
            
        sec_p_w = {}
        sec_b_w = {}
        sec_p_r = {}
        sec_b_r = {}
        
        active_secs = set(p_sec_weights.keys()).union(b_sec_weights.keys())
        
        for sec in active_secs:
            pw = p_sec_weights.get(sec, 0.0)
            bw = b_sec_weights.get(sec, 0.0)
            sec_p_w[sec] = pw
            sec_b_w[sec] = bw
            
            p_num = p_sec_returns_num.get(sec, 0.0)
            b_num = b_sec_returns_num.get(sec, 0.0)
            
            sec_p_r[sec] = p_num / pw if pw > 1e-9 else 0.0
            sec_b_r[sec] = b_num / bw if bw > 1e-9 else 0.0
            
        R_b = sum(sec_b_w.get(sec, 0.0) * sec_b_r.get(sec, 0.0) for sec in active_secs)
        
        for sec in active_secs:
            pw = sec_p_w.get(sec, 0.0)
            bw = sec_b_w.get(sec, 0.0)
            pr = sec_p_r.get(sec, 0.0)
            br = sec_b_r.get(sec, 0.0)
            
            alloc = (pw - bw) * (br - R_b)
            select = bw * (pr - br)
            interact = (pw - bw) * (pr - br)
            
            if sec not in sector_attrib:
                sector_attrib[sec] = {"allocation": 0.0, "selection": 0.0, "interaction": 0.0}
                
            sector_attrib[sec]["allocation"] += alloc
            sector_attrib[sec]["selection"] += select
            sector_attrib[sec]["interaction"] += interact

    rows = []
    for sec, vals in sector_attrib.items():
        if abs(vals["allocation"]) > 1e-8 or abs(vals["selection"]) > 1e-8 or abs(vals["interaction"]) > 1e-8 or sec in sectors.values():
            tot = vals["allocation"] + vals["selection"] + vals["interaction"]
            rows.append({
                "Sector": sec,
                "Allocation Effect %": round(vals["allocation"] * 100.0, 4),
                "Selection Effect %": round(vals["selection"] * 100.0, 4),
                "Interaction Effect %": round(vals["interaction"] * 100.0, 4),
                "Total Effect %": round(tot * 100.0, 4)
            })
            
    df = pd.DataFrame(rows)
    return df


# ────────────────────────────────────────────────────────────────────
# FUNC: run_wfo_backtest
# ────────────────────────────────────────────────────────────────────
def run_wfo_backtest(data, returns, benchmark_returns, sectors, cfg, log_cb, progress_cb):
    from data_layer import DEFAULT_CFG
    cfg = {**DEFAULT_CFG, **(cfg or {})}
    
    log_emit(log_cb, "--- Starting Walk-Forward Out-Of-Sample Backtest ---")
    log_emit(log_cb, "Simulating Risk Parity trading by moving forward through time.")
    
    weights_history = {}
    bench_weights_history = {}
    prev_wfo_weights = {}
    prev_wfo_selected: list = []   # Track prior step's portfolio for real turnover computation
    
    close = data["Close"].reindex(returns.index)
    volume = data["Volume"].reindex(returns.index)
    total_days = len(close)
    test_days = int(cfg.get("BACKTEST_REBALANCE_DAYS", 21))
    
    train_days = min(252, int(total_days * 0.5))
    if total_days <= train_days + test_days:
        log_emit(log_cb, "ERROR: Not enough historical data to run Walk-Forward. Download lookback must be > 1 year.")
        return None
        
    steps = list(range(train_days, total_days, test_days))
    if cfg.get("WFO_WINDOWS"):
        try:
            _max_w = int(cfg["WFO_WINDOWS"])
            if _max_w > 0 and len(steps) > _max_w:
                steps = steps[-_max_w:]
        except Exception:
            pass
    # Pre-allocate fixed-size buffers instead of growing lists → no memory leak
    test_index = close.index[train_days:]
    port_ret_buf = pd.Series(np.nan, index=test_index, dtype=float)
    bench_ret_buf = pd.Series(np.nan, index=test_index, dtype=float) if benchmark_returns is not None else None
    
    for idx, t in enumerate(steps):
        check_stop()
        step_date = close.index[t - 1]
        log_emit(log_cb, f"WFO Step {idx+1}/{len(steps)} | Training up to day {t} ({step_date.strftime('%Y-%m-%d')})")
        
        train_close, train_volume, train_returns = close.iloc[:t], volume.iloc[:t], returns.iloc[:t]
        
        # 1. Point-in-Time constituent filtering to prevent survivorship bias
        if cfg.get("USE_PIT_CONSTITUENTS", True) and not cfg.get("USE_MANUAL_UNIVERSE", False):
            from data_layer import fetch_nse_tickers
            active_tickers = fetch_nse_tickers(log_cb=log_cb, as_of_date=step_date)
            step_cols = [c for c in active_tickers if c in returns.columns]
            if not step_cols:
                step_cols = list(returns.columns)
        else:
            step_cols = list(returns.columns)

        train_close_step = train_close[step_cols]
        train_volume_step = train_volume[step_cols]
        train_returns_step = train_returns[step_cols]

        # 2. Local Point-in-Time Corporate Actions adjustments
        if cfg.get("USE_LOCAL_CORP_ADJUSTMENTS", False):
            from data_layer import fetch_corporate_actions_pit
            from math_engine.corporate_adjustments import CorporateActionsAdjuster
            
            corp_actions_dict = fetch_corporate_actions_pit(step_cols, as_of_date=step_date, log_cb=log_cb)
            
            adj_close_cols = {}
            adj_vol_cols = {}
            for ticker in step_cols:
                actions_list = corp_actions_dict.get(ticker, [])
                
                if actions_list:
                    # Log which corporate actions are actually applied
                    as_of = pd.to_datetime(step_date).normalize()
                    valid_actions = []
                    for act in actions_list:
                        pub_dt = pd.to_datetime(act.get("publish_date", step_date)).normalize()
                        ex_dt = pd.to_datetime(act.get("ex_date")).normalize()
                        if pub_dt <= as_of and ex_dt <= as_of:
                            valid_actions.append(act)
                    
                    if valid_actions:
                        log_emit(log_cb, f"[CorpAdjuster] Applying {len(valid_actions)} active corporate actions for {ticker} up to {step_date.strftime('%Y-%m-%d')}")
                        for act in valid_actions:
                            log_emit(log_cb, f"  - Action: {act['type']}, Ex-Date: {act['ex_date']}, Ratio: {act.get('ratio', 1.0)}, Amount: {act.get('amount', 0.0)}")

                stock_df = pd.DataFrame({
                    "Open": train_close_step[ticker],
                    "High": train_close_step[ticker],
                    "Low": train_close_step[ticker],
                    "Close": train_close_step[ticker],
                    "Volume": train_volume_step[ticker]
                }, index=train_close_step.index)
                
                adj_stock_df = CorporateActionsAdjuster.adjust_prices_pit(stock_df, actions_list, step_date)
                adj_close_cols[ticker] = adj_stock_df["Close"]
                adj_vol_cols[ticker] = adj_stock_df["Volume"]
                
            train_close_final = pd.DataFrame(adj_close_cols, index=train_close_step.index)
            train_volume_final = pd.DataFrame(adj_vol_cols, index=train_volume_step.index)
            # Recompute returns based on PIT-adjusted Close series
            train_returns_final = np.log(train_close_final / train_close_final.shift(1)).fillna(0.0)
        else:
            train_close_final = train_close_step
            train_volume_final = train_volume_step
            train_returns_final = train_returns_step

        train_bench = benchmark_returns.iloc[:t] if benchmark_returns is not None else None
        sliced_data = {"Close": train_close_final, "Volume": train_volume_final}
        
        try:
            # Build fast_cfg FIRST so build_qubo never runs ChartSSL or live fundamentals
            # fetches inside the WFO loop — both are meaningless on historical slices and
            # waste ~7–10 min per step (×36 steps = 4+ hours total).
            fast_cfg = dict(cfg.items()) if hasattr(cfg, "items") else dict(cfg)
            fast_cfg["MULTI_STARTS"] = 1
            # Cap reads/sweeps for WFO speed — live run uses full configured values.
            # WFO_MAX_READS/WFO_MAX_SWEEPS default to 400/500 (matching original v12 WFO quality).
            _cfg_reads = cfg.get("NUM_READS", 400)
            _cfg_sweeps = cfg.get("NUM_SWEEPS", 500)
            fast_cfg["NUM_READS"]  = max(100, min(_cfg_reads,  cfg.get("WFO_MAX_READS",  400)))
            fast_cfg["NUM_SWEEPS"] = max(100, min(_cfg_sweeps, cfg.get("WFO_MAX_SWEEPS", 500)))
            # ChartSSL scores current chart patterns — meaningless for past WFO windows.
            # Skip in WFO to save ~6 min per step (×18 steps = ~108 min total).
            fast_cfg["USE_CHART_IMAGE_SSL"] = False
            
            # Point-in-Time DB (if available) is still used via fetch_fundamentals(as_of_date=).
            from utils import RUNTIME_DIR
            db_path = RUNTIME_DIR / "fundamentals_history.db"
            if db_path.exists():
                fast_cfg["USE_FUNDAMENTALS"] = cfg.get("USE_FUNDAMENTALS", True)
            else:
                fast_cfg["USE_FUNDAMENTALS"] = False
                
            fast_cfg["_WFO_STEP"] = True  # v17-patch: disable IC JSON cache inside WFO
            fast_cfg["_IS_WFO_STEP"] = True  # v17.33: skip live BulkDeal NSE fetch (historical_only path)
            fast_cfg["as_of_date"] = step_date
            
            # Detect market regime for this historical step window
            regime_info = detect_market_regime(train_close_final, train_bench, is_backtest=True)
            fast_cfg["_REGIME_INFO"] = regime_info
            
            # Pass fast_cfg into build_qubo so chart/fundamentals flags are respected
            q, sig_df, clean_rets = build_qubo(sliced_data, train_returns_final, train_bench, sectors, set(), fast_cfg, log_cb=log_cb)
            
            selected, _, _ = solve_qubo(q, sig_df, sectors, fast_cfg, log_cb=log_cb)
            # Use QUBO-aware weights — same allocation model as live run
            # so WFO OOS results are directly comparable to live performance.
            # Mirror the live weight pipeline so WFO is comparable to real results
            weights = calculate_qubo_aware_weights(
                selected,
                sig_df,
                q,
                fast_cfg,
                clean_returns=clean_rets,
                prev_weights=prev_wfo_weights,
                log_cb=log_cb
            )
            prev_wfo_weights = weights
            weights = apply_weight_constraints(weights, fast_cfg)
            if fast_cfg.get("USE_HRP", True) and len(selected) >= 3:
                _hrp_wfo = hrp_weights(selected, clean_rets, fast_cfg)
                if _hrp_wfo:
                    # Bug 40/42 fix: live run uses pure HRP (no blend). WFO must match.
                    # HRP_ALPHA_BLEND default changed from 0.50 → 0.0 (pure HRP) so
                    # WFO backtest simulates the same strategy that actually runs live.
                    _b = float(fast_cfg.get("HRP_ALPHA_BLEND", 0.0))
                    if _b > 0.0:
                        weights = {s: (1-_b)*_hrp_wfo.get(s, 1/len(selected) if selected else 0) + _b*weights.get(s, 1/len(selected) if selected else 0) for s in selected} if selected else {}
                        _t = sum(weights.values()) or 1.0
                        weights = {s: v/_t for s,v in weights.items()}  # DIV001: guard divisor before use
                    else:
                        weights = _hrp_wfo   # pure HRP — matches live run exactly
                    weights = apply_weight_constraints(weights, fast_cfg)

            # Scale weights in WFO step if fewer stocks selected than original K_STOCKS due to bear market pruning
            k_original = fast_cfg.get("K_STOCKS_ORIGINAL")
            if k_original and len(selected) < k_original and len(selected) > 0:
                scale_factor = len(selected) / k_original
                weights = {s: w * scale_factor for s, w in weights.items()}
        except Exception as e:
            log_emit(log_cb, f"WFO calculation failed at step {idx}: {e}", exc_info=True)
            selected, weights = [], {}
            
        if not selected:
            selected_returns = pd.Series(0.0, index=close.index[t+1 : t+test_days+1])
        else:
            _safe_wfo_sel = [s for s in selected if s in returns.columns]
            if not _safe_wfo_sel:
                selected_returns = pd.Series(0.0, index=close.index[t+1 : t+test_days+1])
            else:
                test_panel = returns[_safe_wfo_sel].iloc[t+1 : t+test_days+1]  # v17.20 P3: T+1
                w_series = pd.Series({s: weights.get(s, 0.0) for s in _safe_wfo_sel})
                _w_sum = w_series.sum()
                if _w_sum > 0:
                    w_series = w_series / _w_sum
                selected_returns = test_panel.mul(w_series, axis=1).sum(axis=1)
            
            # NSE-accurate round-trip transaction cost.
            # v14: per-stock market-impact TC model (liquidity-tiered).
            # BUGFIX (Round 41): equity-DELIVERY STT is 0.10% charged on BOTH the
            # buy leg AND the sell leg (confirmed against current NSE/exchange fee
            # schedules), not "sell side only" as the prior comment/constant assumed.
            # Each unit of walk-forward turnover here represents a replace-one-
            # holding-with-another event — a sell leg (old position) + a buy leg
            # (new position) — so STT applies twice (10bps + 10bps), stamp duty
            # once (buy-side only), and exchange/SEBI charges on both legs.
            # The previous single-sided STT understated round-trip costs by ~10bps
            # per turnover unit, which inflates every backtested Sharpe/CAGR this
            # WFO engine reports.
            # STT (0.10% buy + 0.10% sell) + stamp duty (0.015% buy) + exchange (0.00345% × 2)
            # + SEBI (0.0001% × 2)
            _stt_bps        = 20.0    # STT = 0.10% buy + 0.10% sell (delivery, both legs)
            _stamp_bps      = 1.5     # Stamp duty = 0.015% on buy side only
            _exchange_bps   = 0.690   # BSE/NSE exchange + clearing charges, both legs (2 × 0.345)
            _sebi_bps        = 0.02    # SEBI regulatory charge, both legs (2 × 0.0001%)
            _nse_fixed_bps  = _stt_bps + _stamp_bps + _exchange_bps + _sebi_bps
            # v14: weighted-average market-impact bps using per_stock_tc_bps()
            if cfg.get("PER_STOCK_TC_MODEL", True) and selected:
                _wtc, _wsum = 0.0, 0.0
                for _s, _w in weights.items():
                    # compute adv20 from volume slice available in this scope
                    try:
                        _vol_series  = volume[_s].iloc[max(0, t-20):t] if _s in volume.columns else pd.Series(dtype=float)
                        _close_slice = close[_s].iloc[max(0, t-20):t]  if _s in close.columns  else pd.Series(dtype=float)
                        _aligned     = pd.concat([_close_slice, _vol_series], axis=1).dropna()
                        _adv = float((_aligned.iloc[:, 0] * _aligned.iloc[:, 1]).mean()) if len(_aligned) >= 5 else 0.0
                    except Exception as _e:
                        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception in %s", "Exception", exc_info=True)  # noqa: E501
                        _adv = 0.0
                    _wtc  += float(_w) * per_stock_tc_bps(_adv)
                    _wsum += float(_w)
                _fallback_bps = float(cfg.get("BACKTEST_FEE_BPS", 15.0)) + float(cfg.get("BACKTEST_SLIPPAGE_BPS", 5.0))
                _user_bps = (_wtc / _wsum) if _wsum > 0 else _fallback_bps  # DIV001: guard divisor before use
            else:
                _user_bps = float(cfg.get("BACKTEST_FEE_BPS", 15.0)) + float(cfg.get("BACKTEST_SLIPPAGE_BPS", 5.0))
            # INSTITUTIONAL FIX: Compute actual turnover fraction from portfolio overlap.
            # Previously hardcoded to 0.40, which over-states costs for stable portfolios
            # (high overlap) and under-states them for complete portfolio replacements.
            # Real turnover = fraction of NEW stocks that were not in the previous portfolio.
            if prev_wfo_selected and cfg.get("ACTUAL_TURNOVER_TC", True):
                _new_stocks = set(selected) - set(prev_wfo_selected)
                _turnover_frac = len(_new_stocks) / max(len(selected), 1)  # DIV001
            else:
                _turnover_frac = 0.40    # first step: conservative assumption
            prev_wfo_selected = list(selected)
            # v17.22 P8: add sqrt market-impact on top of base TC
            try:
                _port_val  = float(cfg.get("PORTFOLIO_VALUE_INR", cfg.get("PORTFOLIO_VALUE", 1_000_000)))
                _order_val = _port_val / max(len(selected), 1)
                _adv_vals = []
                for _s in selected:
                    if _s not in close.columns or _s not in volume.columns:
                        continue
                    _aligned = pd.concat(
                        [close[_s].iloc[max(0, t-20):t], volume[_s].iloc[max(0, t-20):t]],
                        axis=1,
                    ).dropna()
                    if len(_aligned) >= 5:
                        _adv_vals.append(float((_aligned.iloc[:, 0] * _aligned.iloc[:, 1]).mean()))
                _adv_mean = float(np.mean(_adv_vals)) if _adv_vals else 5e7
                _impact_bps = 100 * 0.1 * (_order_val / _adv_mean) ** 0.5  # DIV001: guard divisor before use
                _cost_per_trade = (_nse_fixed_bps + _user_bps + _impact_bps) / 10000.0
            except Exception as _e:
                _cost_per_trade = (_nse_fixed_bps + _user_bps) / 10000.0
            cost = _cost_per_trade * _turnover_frac
            if len(selected_returns) > 0: selected_returns.iloc[0] -= cost
                
        slice_idx = close.index[t+1 : t+test_days+1]  # v17.20 P3: T+1
        # Track weights for each day in slice_idx
        for d in slice_idx:
            weights_history[d] = weights
            bench_weights_history[d] = {s: 1.0 / len(step_cols) for s in step_cols}
        port_ret_buf.loc[slice_idx] = selected_returns.reindex(slice_idx).values
        if bench_ret_buf is not None:
            bench_ret_buf.loc[slice_idx] = benchmark_returns.reindex(slice_idx).values
        progress_span(progress_cb, 85, 95, idx, len(steps))

    port_ret = port_ret_buf.dropna()
    equity = (1.0 + port_ret).cumprod()
    
    downside = port_ret[port_ret < 0].std() * np.sqrt(TRADING_DAYS_PER_YEAR)
    sortino = (port_ret.mean() * TRADING_DAYS_PER_YEAR) / downside if downside > 0 else np.nan  # DIV001: guard divisor before use
    win_rate = (port_ret > 0).mean()
    
    ann_ret_val = annualized_return(equity)
    max_dd_val  = abs(max_dd_from_equity(equity))
    calmar_val  = (ann_ret_val / max_dd_val) if (max_dd_val is not None and max_dd_val > 1e-6) else np.nan
    
    gains = float(port_ret[port_ret > 0].sum())
    losses = float(abs(port_ret[port_ret < 0].sum()))
    profit_factor = (gains / losses) if losses > 1e-9 else np.nan
    
    from math_engine.tail_risk import compute_omega_ratio
    omega_val = compute_omega_ratio(port_ret.values, 0.0)
    
    out = {
        "Mode": "Walk-Forward OOS (Risk Parity)",
        "Annual Return": ann_ret_val,
        "Annual Vol": float(port_ret.std() * np.sqrt(TRADING_DAYS_PER_YEAR)) if len(port_ret) > 1 else np.nan,
        "Sharpe": sharpe_from_returns(port_ret),
        "Sortino": float(sortino),
        "Calmar": float(calmar_val) if pd.notna(calmar_val) else np.nan,
        "Omega": float(omega_val) if pd.notna(omega_val) else np.nan,
        "Profit Factor": float(profit_factor) if pd.notna(profit_factor) else np.nan,
        "Daily Win Rate": float(win_rate),
        "Max Drawdown": max_dd_from_equity(equity),
        "Start Date": str(port_ret.index.min().date()),
        "End Date": str(port_ret.index.max().date()),
        "Observations": int(len(port_ret)),
        "Rebalances": int(len(weights_history)),
        "Equity Curve": equity,
    }

    if benchmark_returns is not None and bench_ret_buf is not None and bench_ret_buf.notna().any():
        bench_ret = bench_ret_buf.dropna()
        aligned = pd.concat([port_ret, bench_ret], axis=1).dropna()
        if not aligned.empty:
            active = aligned.iloc[:, 0] - aligned.iloc[:, 1]
            alpha_val = float(active.mean() * TRADING_DAYS_PER_YEAR)
            te_val = float(active.std() * np.sqrt(TRADING_DAYS_PER_YEAR)) if len(active) > 1 else np.nan
            out["Alpha vs Benchmark"] = alpha_val
            out["Tracking Error"] = te_val
            out["Information Ratio"] = float(alpha_val / te_val) if (pd.notna(te_val) and te_val > 0) else np.nan
            up_mask = aligned.iloc[:, 1] > 0
            down_mask = aligned.iloc[:, 1] < 0
            if up_mask.any():
                bench_up = aligned.loc[up_mask].iloc[:, 1].mean()
                port_up = aligned.loc[up_mask].iloc[:, 0].mean()
                out["Up Capture"] = float(port_up / bench_up) if bench_up != 0 else np.nan  # DIV001: guard divisor before use
            if down_mask.any():
                bench_down = aligned.loc[down_mask].iloc[:, 1].mean()
                port_down = aligned.loc[down_mask].iloc[:, 0].mean()
                out["Down Capture"] = float(port_down / bench_down) if bench_down != 0 else np.nan  # DIV001: guard divisor before use

    # Calculate Brinson Attribution
    brinson_df = compute_brinson_attribution(returns, weights_history, bench_weights_history, sectors)
    out["Brinson Attribution"] = brinson_df
    
    if brinson_df is not None and not brinson_df.empty:
        log_emit(log_cb, "\n--- Ex-Post Brinson-Fachler Sector Performance Attribution ---")
        log_emit(log_cb, f"{'Sector':<25} | {'Allocation %':<15} | {'Selection %':<15} | {'Interaction %':<15} | {'Total Effect %':<15}")
        log_emit(log_cb, "-" * 95)
        for _, row in brinson_df.iterrows():
            log_emit(log_cb, f"{row['Sector']:<25} | {row['Allocation Effect %']:>15.4f} | {row['Selection Effect %']:>15.4f} | {row['Interaction Effect %']:>15.4f} | {row['Total Effect %']:>15.4f}")
        log_emit(log_cb, "-" * 95)
        
    # Ex-post tail risk metrics (annualized)
    # AUDIT-FIX (defect #9): when no returns breach the VaR threshold (e.g., a
    # very short or very benign sample), CVaR was previously set equal to VaR,
    # which is mathematically wrong and hid the fact that the tail estimator
    # had zero observations to average. We now surface NaN with a logged note
    # so the summary layer can describe the situation honestly.
    ex_post_var_95 = 0.0
    ex_post_var_99 = 0.0
    ex_post_cvar_95 = float("nan")
    ex_post_cvar_99 = float("nan")
    if len(port_ret) > 1:
        var_95_daily = float(-np.percentile(port_ret, 5))
        var_99_daily = float(-np.percentile(port_ret, 1))
        _breach_95_mask = port_ret <= -var_95_daily
        _breach_99_mask = port_ret <= -var_99_daily
        cvar_95_daily = float(-port_ret[_breach_95_mask].mean()) if _breach_95_mask.any() else float("nan")
        cvar_99_daily = float(-port_ret[_breach_99_mask].mean()) if _breach_99_mask.any() else float("nan")

        ex_post_var_95 = var_95_daily * np.sqrt(TRADING_DAYS_PER_YEAR)
        ex_post_var_99 = var_99_daily * np.sqrt(TRADING_DAYS_PER_YEAR)
        # Annualize CVaR only when a real tail mean exists; otherwise leave NaN
        if not (cvar_95_daily != cvar_95_daily):  # not NaN
            ex_post_cvar_95 = cvar_95_daily * np.sqrt(TRADING_DAYS_PER_YEAR)
        if not (cvar_99_daily != cvar_99_daily):  # not NaN
            ex_post_cvar_99 = cvar_99_daily * np.sqrt(TRADING_DAYS_PER_YEAR)
        
    out["Ex-Post VaR (95%)"] = float(ex_post_var_95)
    out["Ex-Post VaR (99%)"] = float(ex_post_var_99)
    out["Ex-Post CVaR (95%)"] = float(ex_post_cvar_95)
    out["Ex-Post CVaR (99%)"] = float(ex_post_cvar_99)
    
    log_emit(log_cb, f"[Backtest Tail Risk] Ex-Post VaR (95%): {ex_post_var_95*100:.2f}% | CVaR (95%): {ex_post_cvar_95*100:.2f}%")
    log_emit(log_cb, f"[Backtest Tail Risk] Ex-Post VaR (99%): {ex_post_var_99*100:.2f}% | CVaR (99%): {ex_post_cvar_99*100:.2f}%")
    return out

# ── Pipeline ──




# ────────────────────────────────────────────────────────────────────
# FUNC: compute_alpha_decay
# ────────────────────────────────────────────────────────────────────
def compute_alpha_decay(clean_returns, signal_df, log_cb=None):
    """Estimate cross-sectional alpha persistence.

    Phase 3.6: This function measures CONCURRENT IC — the correlation between
    CURRENT alpha scores and RECENT (trailing) realized returns. This is NOT
    true alpha decay (which would correlate alpha at time T with forward returns
    from T to T+lag, across many historical T values). True forward-looking alpha
    decay requires stored historical alpha snapshots, which this codebase doesn't have.

    What this function DOES tell you: "Does my current alpha ranking align with
    recent momentum?" — useful as a concurrent signal quality check, but it should
    NOT be displayed to users as "alpha decay" or "alpha persistence".

    For true forward-looking alpha decay, see the ML Alpha engine's walk-forward
    per-fold OOS IC metrics (ml_alpha/metrics.py).
    """
    try:
        if clean_returns is None or clean_returns.empty or signal_df is None or signal_df.empty:
            return pd.DataFrame()
        if "alpha_score" not in signal_df.columns:
            return pd.DataFrame()

        common = [c for c in clean_returns.columns if c in signal_df.index]
        if len(common) < 8:
            return pd.DataFrame()

        # Bug 20 fix: use raw score for honest IC measurement.
        _acol = "alpha_score_raw" if "alpha_score_raw" in signal_df.columns else "alpha_score"
        alpha = pd.to_numeric(signal_df.loc[common, _acol], errors="coerce")
        alpha = alpha.replace([np.inf, -np.inf], np.nan).dropna()
        if len(alpha) < 8 or float(alpha.std()) < 1e-12:
            return pd.DataFrame()

        log_rets = np.log1p(clean_returns[alpha.index].clip(lower=-0.95))
        rows = []
        for lag in (1, 2, 5, 10, 21):
            if len(log_rets) <= lag + 5:
                continue
            trailing_window = log_rets.tail(lag)
            realized = np.expm1(trailing_window.sum(axis=0)).replace([np.inf, -np.inf], np.nan).dropna()
            aligned = pd.concat([alpha.rename("alpha"), realized.rename("realized")], axis=1).dropna()
            if len(aligned) < 6:
                continue
            spread = (
                aligned.nlargest(max(1, len(aligned) // 4), "alpha")["realized"].mean()
                - aligned.nsmallest(max(1, len(aligned) // 4), "alpha")["realized"].mean()
            )
            rows.append({
                "LagDays": lag,
                # Phase 3.6: Renamed from "SpearmanIC" to "ConcurrentIC" to be honest
                # about what this measures (current alpha vs trailing return, NOT forward).
                "ConcurrentIC": round(float(aligned["alpha"].corr(aligned["realized"], method="spearman")), 4),
                "PearsonIC": round(float(aligned["alpha"].corr(aligned["realized"], method="pearson")), 4),
                "TopBottomSpread %": round(float(spread * 100.0), 2),
                "HitRate %": round(float((aligned["alpha"] * aligned["realized"] > 0).mean() * 100.0), 1),
                "Coverage": int(len(aligned)),
            })
        out = pd.DataFrame(rows)
        if not out.empty:
            log_emit(log_cb, f"[Alpha Decay] Built data-driven persistence profile across {len(out)} holding horizons.")
        return out
    except Exception as e:
        log_emit(log_cb, f"[Alpha Decay] Failed to compute: {e}", exc_info=True)
        return pd.DataFrame()



_ACTIVE_FLIGHT_SERVER = None
_ACTIVE_FLIGHT_SERVER_THREAD = None
_ACTIVE_FLIGHT_SERVER_LOCK = _threading.Lock()


def _run_prescreen_batch_ray_helper(args):
    """Module-level helper for picklable Ray/Multiprocessing batch task execution."""
    batch_task, cfg = args
    # AUDIT-FIX (Round 4 — W0406): self-import is intentional. Ray and
    # multiprocessing's spawn/forkserver contexts need to re-resolve the
    # function by qualified name in the worker process; importing from
    # the module's own namespace is the standard picklability pattern.
    # pylint: disable=import-self
    from optimizer import process_prescreen_batch
    return process_prescreen_batch(batch_task, cfg, log_cb=None)


def apply_precomputed_eligibility_filter(cfg: dict, precomputed_raw: dict | list, is_manual: bool = False) -> list:
    """Applies profile-specific eligibility rules and filters to pre-computed raw ticker rows.
    
    Returns a list of candidate row dictionaries passing the profile's eligibility criteria.
    """
    pass1_rows = []
    pass2_rows = []
    _raw_items = precomputed_raw.values() if isinstance(precomputed_raw, dict) else precomputed_raw

    for row in _raw_items:
        if row is None: continue

        # 1. Base Filters (always applied)
        min_data_pct = 0.3 if is_manual else cfg.get("MIN_DATA_PCT", 0.8)
        if row.get("data_pct", 0) < min_data_pct: continue

        if is_manual:
            # Relaxed basic quality checks for manual universe to prevent delisted/manipulated/penny assets
            # 1. Penny stock check (last price < 2 INR/USD)
            if pd.notna(row.get("last_price")) and row.get("last_price", 0) < 2.0: continue
            # 2. Extreme illiquidity check (ADV < 50,000 INR)
            if pd.notna(row.get("adv20")) and row.get("adv20", 0) < 50000.0: continue
            # 3. Flatline check (stuck/blocked asset)
            if row.get("flatline", False): continue
            # 4. Volatility floor/ceiling (e.g. annual vol > 250% is likely data spike/manipulation)
            if pd.notna(row.get("ann_vol")) and row.get("ann_vol", 0) > 2.5: continue
            # 5. Drawdown cap (e.g. > 90% indicates delisted or near-bankrupt)
            if pd.notna(row.get("drawdown")) and row.get("drawdown", 0) > 0.90: continue
        else:
            min_adv_floor = float(cfg.get("MIN_AVG_DOLLAR_VOL", 50_000_000.0))
            if pd.isna(row.get("adv20")) or row.get("adv20", 0) < min_adv_floor: continue
            if pd.isna(row.get("last_price")) or row.get("last_price", 0) < cfg.get("MIN_PRICE", 0): continue

            # 2. Share Volume & Flatline Filters
            # R41: skip share-volume floor for ipo_multibagger — new listings have
            # smaller floats; monetary ADV20 (MIN_ADV20_INR) is the correct liquidity
            # proxy for IPOs. The share-volume floor is enforced for all other modes.
            min_share_vol = cfg.get("MIN_AVG_SHARE_VOL", 30000)
            if cfg.get("PRESCREEN_MODE") != "ipo_multibagger":
                if pd.notna(row.get("avg_vol_20")) and row.get("avg_vol_20", 0) < min_share_vol: continue
            if row.get("flatline", False): continue

            # 3. Volatility Cap
            max_ann_vol = cfg.get("MAX_ANNUAL_VOL", 0.85)
            if pd.notna(row.get("ann_vol")) and row.get("ann_vol", 0) > max_ann_vol: continue

            # 4. Max Drawdown Cap
            max_dd_limit = cfg.get("MAX_DRAWDOWN_LIMIT", 0.60)
            if pd.notna(row.get("drawdown")) and row.get("drawdown", 0) > max_dd_limit: continue

        # --- record this ticker as a fallback (passed base liquidity/risk filters) ---
        pass2_rows.append(row)

        if is_manual:
            pass1_rows.append(row)
            continue

        # 5. Strict Stage-2 Trend (Minervini) — Pass 1 only
        # SKIP for early_entry mode: Minervini Stage-2 requires price > SMA150/200,
        # which eliminates every base-building stock we are trying to find.
        if cfg.get("PRESCREEN_MODE", "standard") == "early_entry":
            # Early-entry prescreen: target stocks in the base-building zone
            # 25-70% below 52W high (not yet broken out), quality + accumulation signals
            pct_below = row.get("pct_below_52w_high", 0)
            drawdown  = row.get("drawdown", 0)
            adv20     = row.get("adv20", 0)
            # Must be in accumulation zone: 15-75% below 52W high
            # Excludes recent breakouts (< 15% below = already moved)
            # Excludes genuinely broken stocks (> 75% below = value trap)
            if pd.notna(pct_below) and (pct_below < 0.15 or pct_below > 0.75):
                continue
            # Must have minimum liquidity (5 crore ADV)
            min_adv_early = float(cfg.get("MIN_ADV20_INR", 50_000_000.0))
            if pd.notna(adv20) and adv20 < min_adv_early:
                continue
            pass1_rows.append(row)
            continue

        if cfg.get("PRESCREEN_MODE", "standard") == "ipo_multibagger":
            # ── R41: IPO Multibagger prescreen — pass all liquid non-flatline tickers ──
            # Stage-2 Minervini (SMA150/200) and 52W proximity filters are WRONG for
            # stocks with only 12-24 months of history: SMA200 may not exist, and the
            # 52W range is compressed by definition for recent listings. ipo_gate_pass
            # (called later in the pipeline) enforces all structural quality contracts
            # (listing age, base formation, volume dryup, mcap bounds). Prescreen's
            # only job here is to confirm the ticker is liquid and has live price data.
            min_adv_ipo = float(cfg.get("MIN_ADV20_INR", 15_000_000.0))  # default ₹1.5Cr ADV20
            adv20 = row.get("adv20", 0)
            if pd.notna(adv20) and adv20 < min_adv_ipo:
                continue
            pass1_rows.append(row)
            continue

        if cfg.get("REQUIRE_STAGE2_TREND", True):
            last_price = row.get("last_price", 0)
            sma_150 = row.get("sma_150", np.nan)
            sma_200 = row.get("sma_200", np.nan)
            ema_50  = row.get("ema_50",  np.nan)

            if pd.notna(sma_150) and last_price < sma_150: continue
            if pd.notna(sma_200) and last_price < sma_200: continue
            if pd.notna(ema_50) and pd.notna(sma_150) and ema_50 < sma_150: continue
            if pd.notna(sma_150) and pd.notna(sma_200) and sma_150 < sma_200: continue

        # 6. 52-Week Range Proximity — Pass 1 only
        max_52w_high_dist = cfg.get("MAX_52W_HIGH_DIST", 0.35)
        min_52w_low_dist  = cfg.get("MIN_52W_LOW_DIST",  0.25)
        if pd.notna(row.get("pct_below_52w_high")) and row.get("pct_below_52w_high", 0) > max_52w_high_dist: continue
        if pd.notna(row.get("pct_above_52w_low"))  and row.get("pct_above_52w_low",  0) < min_52w_low_dist:  continue

        pass1_rows.append(row)

    # ── Adaptive fallback: if Pass-1 is too sparse, blend in Pass-2 rows ─────
    out_rows = pass1_rows
    if not is_manual and len(out_rows) < cfg.get("MIN_PRESCREEN_CANDIDATES", 8):
        extra = [r for r in pass2_rows if r not in pass1_rows]
        out_rows = pass1_rows + extra
    return out_rows


# ────────────────────────────────────────────────────────────────────
# FUNC: run_optimizer_logic
# ────────────────────────────────────────────────────────────────────
def run_optimizer_logic(cfg, manual_symbols_text="", prev_holdings_text="", log_cb=None, progress_cb=None, stop_event=None):
    # ARCH-10: validate + normalise config before any logic runs
    if stop_event is None:
        stop_event = AppState.get().new_run()

    global _ACTIVE_STOP_EVENT  # GLB001: consider replacing global with AppState
    start = datetime.now()
    with _ACTIVE_STOP_EVENT_LOCK:
        _ACTIVE_STOP_EVENT.set_event(stop_event)

    # AUDIT-FIX (defect #P1-11): generate a single run_id and stamp it on the
    # payload + cfg so every export (CSV, JSON, HTML, SQLite) can embed it.
    # The audit found that not a single exported artifact corresponded to the
    # logged run — the log itself was a truncated tail with mixed-date
    # evidence. A run_id embedded in every export gives the operator a way
    # to verify which run produced which artifact.
    import uuid as _uuid_mod
    _run_id = f"qa_{start.strftime('%Y%m%dT%H%M%SZ')}_{_uuid_mod.uuid4().hex[:8]}"
    cfg["RUN_ID"] = _run_id
    log_emit(log_cb, f"[RunID] {_run_id} — embedded in all exports from this run.")

    try:
        # ── Start Arrow Flight Server (Citadel Phase 2) ──
        global _ACTIVE_FLIGHT_SERVER
        global _ACTIVE_FLIGHT_SERVER_THREAD
        if cfg.get("USE_ARROW_FLIGHT_SERVER", True):
            try:
                from enterprise.connectors.arrow_flight_server import QuantumPortfolioFlightServer, HAS_FLIGHT
                if HAS_FLIGHT:
                    with _ACTIVE_FLIGHT_SERVER_LOCK:
                        if _ACTIVE_FLIGHT_SERVER is None:
                            port = int(cfg.get("ARROW_FLIGHT_PORT", 8815))
                            try:
                                _ACTIVE_FLIGHT_SERVER = QuantumPortfolioFlightServer(host="localhost", port=port)
                            except Exception:
                                from enterprise.connectors.arrow_flight_server import find_free_port
                                port = find_free_port()
                                _ACTIVE_FLIGHT_SERVER = QuantumPortfolioFlightServer(host="localhost", port=port)
                            _ACTIVE_FLIGHT_SERVER_THREAD = _threading.Thread(
                                target=_ACTIVE_FLIGHT_SERVER.serve,
                                name="ArrowFlightServer",
                                daemon=True
                            )
                            _ACTIVE_FLIGHT_SERVER_THREAD.start()
                            log_emit(log_cb, f"[FlightServer] Started Arrow Flight server on port {port}")
                else:
                    log_emit(log_cb, "[FlightServer] Warning: pyarrow.flight is not installed; Arrow Flight server skipped.")
            except Exception as _fe:
                log_emit(log_cb, f"[FlightServer] Warning: failed to start Arrow Flight server: {_fe}", exc_info=True)

        progress_span(progress_cb, 0, 100, 0, 1)

        # ── Integrated Pre-Flight Live Verification Pass (User Request) ──
        if cfg.get("AUTO_LIVE_VERIFY_SCREEN") and not cfg.get("_ALREADY_VERIFIED"):
            log_emit(log_cb, "=" * 60)
            log_emit(log_cb, "🔬 STARTING PRE-FLIGHT LIVE SYSTEM VERIFICATION")
            log_emit(log_cb, "=" * 60)
            try:
                import io
                import contextlib
                import os
                import importlib
                import live_verify
                importlib.reload(live_verify)
                test_live_hmm = live_verify.test_live_hmm
                test_live_screener_full_nse = live_verify.test_live_screener_full_nse
                
                # Use QA_TEST_MODE = 1 to run a quick 15-ticker fast-pass, preventing yfinance IP bans and keeping execution instant (1-2s)
                os.environ["QA_TEST_MODE"] = "1"
                
                _f = io.StringIO()
                with contextlib.redirect_stdout(_f):
                    try:
                        pred_regime = test_live_hmm()
                        regime_label = pred_regime.get("label") if pred_regime else None
                        test_live_screener_full_nse(regime=regime_label)
                    except Exception as _inner_err:
                        print(f"Error during pre-flight verify: {_inner_err}")
                
                for _line in _f.getvalue().split("\n"):
                    if _line.strip():
                        log_emit(log_cb, f"[LiveVerify] {_line}")
                
                log_emit(log_cb, "🎉 PRE-FLIGHT LIVE SYSTEM VERIFICATION COMPLETED SUCCESSFULLY.")
            except Exception as _outer_err:
                log_emit(log_cb, f"[LiveVerify] Warning: pre-flight verification skipped: {_outer_err}", exc_info=True)
            log_emit(log_cb, "=" * 60 + "\n")

        if cfg.get("USE_MANUAL_UNIVERSE"):
            all_tickers = parse_symbol_lines(manual_symbols_text)
            if not all_tickers: raise RuntimeError("Manual universe is enabled but no symbols were supplied.")
            log_emit(log_cb, f"Using manual universe: {len(all_tickers)} tickers")
        else:
            # Sweep optimisation: if the Orchestrator pre-fetched the NSE universe
            # and injected it into cfg, reuse it directly (avoids 9 identical HTTP calls).
            _prefetched = cfg.get("_PREFETCHED_TICKERS")
            if _prefetched:
                all_tickers = list(_prefetched)
                log_emit(log_cb, f"[Universe] Using pre-fetched NSE universe ({len(all_tickers)} tickers) — skipping redundant fetch.")
            else:
                all_tickers = fetch_nse_tickers(log_cb=log_cb)
                # v14: update survivorship graveyard on every live run
                update_delisted_graveyard(all_tickers, log_cb=log_cb)

        # ── R41: IPO Multibagger universe pre-filter ──────────────────────────
        # CRITICAL FIX: The ipo_multibagger profile was downloading all 2,500+
        # NSE tickers and burning the entire yfinance rate budget on stocks that
        # are guaranteed to fail ipo_gate_pass (listed >2y or <1y ago). Only
        # ~150-160 active NSE equities are in the 1-2y listing window at any
        # given time. Pre-filtering here — using the same DynamicSecurityMaster
        # that ipo_gate_pass consults — eliminates 2,300+ irrelevant downloads
        # and ensures the actual IPO candidates receive the full download budget.
        # Fallback: if the DSM filter returns <10 stocks (data issue / sync lag),
        # we fall back to the full NSE universe rather than producing an empty run.
        if not cfg.get("USE_MANUAL_UNIVERSE") and cfg.get("PRESCREEN_MODE") == "ipo_multibagger":
            try:
                from data.dynamic_security_master import DynamicSecurityMaster as _DSM_IPO
                _ipo_dsm = _DSM_IPO.get_instance()
                _min_cal = int(cfg.get("IPO_MIN_CALENDAR_DAYS", 365))
                _max_cal = int(cfg.get("IPO_MAX_CALENDAR_DAYS", 730))
                _ipo_pool = [
                    t for t in all_tickers
                    if _ipo_dsm.is_recent_ipo(
                        t.replace(".NS", "").replace(".BO", "").strip().upper(),
                        min_days=_min_cal,
                        max_days=_max_cal,
                    )
                ]
                if len(_ipo_pool) >= 10:
                    log_emit(log_cb, (
                        f"[IPO Universe] Pre-filtered {len(all_tickers)} NSE tickers → "
                        f"{len(_ipo_pool)} active 1-2y listed IPO candidates "
                        f"(listing window: {_min_cal}–{_max_cal} calendar days). "
                        f"Avoids rate-limit exhaustion from irrelevant downloads."
                    ))
                    all_tickers = _ipo_pool
                else:
                    log_emit(log_cb, (
                        f"[IPO Universe] DSM returned only {len(_ipo_pool)} stocks in the "
                        f"{_min_cal}–{_max_cal}d window (expected 100-160). "
                        f"Possible DSM sync lag — using full NSE universe as fallback. "
                        f"ipo_gate_pass will enforce listing-age contract per-ticker."
                    ))
            except Exception as _ipo_pre_err:
                log_emit(log_cb, f"[IPO Universe] Pre-filter skipped ({type(_ipo_pre_err).__name__}: {_ipo_pre_err}) — using full NSE universe.")

        prev_holdings = set(parse_symbol_lines(prev_holdings_text))
        if prev_holdings:
            log_emit(log_cb, f"[PrevHoldings] Loaded {len(prev_holdings)} previous holding(s)")

        # AUDIT-FIX (Round 5, 2-f-9): cfg["_HOLDING_DATES"] was READ at the
        # tax-aware turnover call (build_qubo) but never populated anywhere in
        # the tree — the STCG 2x churn-deterrent was dead code. Accept an
        # optional public cfg["HOLDING_DATES"] mapping {ticker: "YYYY-MM-DD"}
        # (e.g. from a broker holdings import) and pass it through to the
        # internal key so get_tax_aware_turnover_cost actually runs.
        if cfg.get("HOLDING_DATES") and not cfg.get("_HOLDING_DATES"):
            try:
                cfg = dict(cfg)
                cfg["_HOLDING_DATES"] = dict(cfg["HOLDING_DATES"])
                log_emit(log_cb, f"[TaxAware] {len(cfg['_HOLDING_DATES'])} holding date(s) "
                                 f"loaded — STCG-aware turnover penalty active")
            except Exception:
                pass

        rows = []
        prescreen_batches = list(chunked(all_tickers, cfg.get("BATCH_SIZE", 20)))
        total_batches = max(1, len(prescreen_batches))
        requested_workers = int(cfg.get("DOWNLOAD_WORKERS", DEFAULT_CFG["DOWNLOAD_WORKERS"]))
        # v17_fast-70 I3-fix: Force single-threaded prescreen for large NSE universes
        # (2132 tickers). Concurrent ThreadPool floods trigger Yahoo Finance IP bans
        # resulting in "Only 0 tickers retained enough clean price history" errors.
        if len(all_tickers) >= 1000:
            download_workers = int(cfg.get("DOWNLOAD_WORKERS_LARGE", 1))    # anti-ban: full NSE universe (>1000 tickers)
        elif len(all_tickers) >= 500:
            download_workers = 1    # large but not full — same single-thread caution
        elif len(all_tickers) >= 400:
            download_workers = min(int(cfg.get("DOWNLOAD_WORKERS_MEDIUM", 2)), requested_workers)  # medium universe
        else:
            download_workers = requested_workers
        download_workers = max(1, min(download_workers, total_batches))

        # ── Precomputed Sweep Raw Metrics Check (Component 2) ──
        _precomputed_raw = cfg.get("_PRECOMPUTED_RAW_ROWS")
        if _precomputed_raw:
            log_emit(log_cb, f"Stage 1/6 | ⚡ Reusing precomputed sweep raw metrics for {len(_precomputed_raw)} tickers. Skipping batch download.")
            is_manual = cfg.get("USE_MANUAL_UNIVERSE", False)
            rows = apply_precomputed_eligibility_filter(cfg, _precomputed_raw, is_manual=is_manual)
            progress_span(progress_cb, 4, 20, 1, 1)
        else:
            # ── Prescreen 24-hour cache ──
            # Prescreening 2000+ tickers takes ~60s. Cache results for 24h so re-runs
            # are near-instant. Cache separates IPO, manual, and broad-market pools.
            _pc = read_json_cache(PRESCREEN_CACHE_PATH, {})
            is_manual = cfg.get("USE_MANUAL_UNIVERSE", False)
            is_ipo_mode = cfg.get("PRESCREEN_MODE") == "ipo_multibagger"
            _cache_key = ""
            
            if is_manual:
                _manual_hash = _hashlib.md5(",".join(sorted(all_tickers)).encode()).hexdigest()[:8]
                _cache_key = "manual_{}_{}_{}_{}_{}_{}_{}".format(
                    _manual_hash,
                    cfg.get("MIN_AVG_DOLLAR_VOL"), cfg.get("MIN_PRICE"), cfg.get("MIN_DATA_PCT"),
                    cfg.get("PRESCREEN_LOOKBACK"), cfg.get("USE_FNO_BAN_FILTER"), str(cfg.get("TICKER_BLACKLIST", []))
                )
                _cache_age_h = (time.time() - _pc.get("manual_timestamp", 0)) / 3600
                if (not cfg.get("FORCE_REBUILD")
                        and _pc.get("manual_key") == _cache_key
                        and _cache_age_h < 23
                        and _pc.get("manual_rows")):
                    rows = [dict(r) for r in _pc["manual_rows"]]
                    log_emit(log_cb, f"Stage 1/6 | Manual prescreen cache hit ({_cache_age_h:.1f}h old) — {len(rows)} tickers. Skipping download.")
                    progress_span(progress_cb, 4, 20, 1, 1)
            elif is_ipo_mode:
                _ipo_age_h = (time.time() - _pc.get("ipo_timestamp", 0)) / 3600
                _ipo_rows = _pc.get("ipo_rows")
                if not cfg.get("FORCE_REBUILD") and _ipo_rows and len(_ipo_rows) >= 5 and _ipo_age_h < 23:
                    rows = [dict(r) for r in _ipo_rows]
                    log_emit(log_cb, f"Stage 1/6 | IPO Prescreen cache hit ({_ipo_age_h:.1f}h old) — {len(rows)} tickers. Skipping download.")
                    progress_span(progress_cb, 4, 20, 1, 1)
            else:
                _broad_age_h = (time.time() - _pc.get("timestamp", 0)) / 3600
                _broad_rows = _pc.get("rows")
                if not cfg.get("FORCE_REBUILD") and _broad_rows and len(_broad_rows) >= 50 and _broad_age_h < 23:
                    rows = [dict(r) for r in _broad_rows]
                    log_emit(log_cb, f"Stage 1/6 | Prescreen cache hit ({_broad_age_h:.1f}h old) — {len(rows)} tickers. Skipping download.")
            if not rows:
                log_emit(log_cb, f"Stage 1/6 | Prescreening {len(all_tickers)} tickers across {total_batches} batches with {download_workers} workers")
                import random as _rand_prescreen
            
                run_ray = cfg.get("USE_RAY_DISTRIBUTED", False)
                ray_success = False
                if run_ray:
                    try:
                        from enterprise.distributed_executor import RayDistributedCoordinator
                        coordinator = RayDistributedCoordinator(use_ray=True)
                        
                        log_emit(log_cb, f"[Ray] Initiating distributed screening parallel mapping across cluster...")
                        # Package items as (batch, cfg) tuples for module-level helper
                        packed_tasks = [(batch, cfg) for batch in prescreen_batches]
                        results = coordinator.parallel_map(_run_prescreen_batch_ray_helper, packed_tasks)
                        for r in results:
                            rows.extend(r)
                        coordinator.shutdown()
                        ray_success = True
                        log_emit(log_cb, f"[Ray] Distributed screening completed successfully.")
                    except Exception as _ray_err:
                        log_emit(log_cb, f"[Ray] Warning: Ray distributed screening failed: {_ray_err}. Falling back to standard executor.", exc_info=True)
                
                if not ray_success:
                    if download_workers == 1:
                        for idx, batch in enumerate(prescreen_batches, start=1):
                            check_stop()
                            rows.extend(process_prescreen_batch(batch, cfg, log_cb=log_cb))
                            progress_span(progress_cb, 4, 20, idx, total_batches)
                            # v17_fast-70 I3-fix: jittered sleep prevents Yahoo Finance IP ban
                            time.sleep(_rand_prescreen.uniform(float(cfg.get("BATCH_SLEEP_MIN", 1.0)), float(cfg.get("BATCH_SLEEP_MAX", 2.5))))  # UI001: time.sleep on main thread freezes Qt — move to worker thread
                    else:
                        with _DaemonThreadPoolExecutor(max_workers=download_workers) as ex:
                            futures = {ex.submit(process_prescreen_batch, batch, cfg, log_cb): batch for batch in prescreen_batches}
                            for idx, fut in enumerate(as_completed(futures), start=1):
                                check_stop()
                                try:
                                    rows.extend(fut.result())
                                except Exception as e:
                                    log_emit(log_cb, f"[WARN] Prescreen batch failed: {type(e).__name__}: {e}", exc_info=True)
                                progress_span(progress_cb, 4, 20, idx, total_batches)
                # Save to cache
                if rows:
                    if is_manual:
                        _pc["manual_rows"] = rows
                        _pc["manual_timestamp"] = time.time()
                        _pc["manual_key"] = _cache_key
                        write_json_cache(PRESCREEN_CACHE_PATH, _pc)
                    elif is_ipo_mode:
                        _pc["ipo_rows"] = rows
                        _pc["ipo_timestamp"] = time.time()
                        write_json_cache(PRESCREEN_CACHE_PATH, _pc)
                    else:
                        _pc["rows"] = rows
                        _pc["timestamp"] = time.time()
                        _pc["key"] = _cache_key
                        write_json_cache(PRESCREEN_CACHE_PATH, _pc)

        if not rows:
            cached_prescreen = read_json_cache(PRESCREEN_CACHE_PATH, {})
            if is_ipo_mode and cached_prescreen and cached_prescreen.get("ipo_rows"):
                log_emit(log_cb, "[WARN] Live prescreen yielded 0 stocks. Restoring from cached IPO prescreen results.")
                rows = cached_prescreen["ipo_rows"]
            elif cached_prescreen and isinstance(cached_prescreen, dict) and cached_prescreen.get("rows"):
                log_emit(log_cb, "[WARN] Live prescreen yielded 0 stocks (network/yfinance limit). Restoring from cached prescreen results.")
                rows = cached_prescreen["rows"]

        if not rows:
            raise RuntimeError("Prescreen returned zero valid stocks. Ensure network connectivity or check symbol list.")
        df = pd.DataFrame(rows).drop_duplicates("ticker").reset_index(drop=True)

        # ── Profile-aware prescreen scoring ──────────────────────────────────
        # z-score all available prescreen signals for cross-sectional comparison
        _prescreen_z_cols = ["mom_3m", "mom_6m", "adv20", "vcp_score", "cmf_score",
                              "obv_slope", "updown_vol", "rs_raw", "ann_vol", "drawdown",
                              "neural_sde", "hurst", "ker"]
        for _col in _prescreen_z_cols:
            if _col in df.columns:
                df[f"z_{_col}"] = robust_zscore_series(df[_col])
            else:
                df[f"z_{_col}"] = np.nan  # FIX: was 0.0 — caused missing factors to create 89 exact-zero composite scores

        _pmode = str(cfg.get("PRESCREEN_MODE", "balanced")).lower()
        def _get_z(col_name: str) -> pd.Series:
            if col_name in df.columns:
                return df[col_name].fillna(0.0)
            return pd.Series(0.0, index=df.index)

        _liq_z = _get_z("z_adv20")

        if _pmode in ["breakout_early", "vol_squeeze"]:
            # Stocks coiling (VCP) with rising OBV + positive CMF before the move
            df["score"] = (
                0.35 * _get_z("z_vcp_score") +
                0.25 * _get_z("z_obv_slope") +
                0.20 * _get_z("z_cmf_score") +
                0.20 * _liq_z
            )
            log_emit(log_cb, f"[Prescreen] Mode={_pmode} | VCP+OBV+CMF scoring | {len(df)} candidates")
        elif _pmode == "accumulation":
            # Heavy CMF + OBV + Up/Down vol — price still flat/sideways
            df["score"] = (
                0.30 * _get_z("z_cmf_score") +
                0.25 * _get_z("z_updown_vol") +
                0.25 * _get_z("z_obv_slope") +
                0.20 * _liq_z
            )
            log_emit(log_cb, f"[Prescreen] Mode=accumulation | CMF+UpDownVol+OBV scoring | {len(df)} candidates")
        elif _pmode == "momentum_chase":
            # Short-term momentum + RS rating — confirmed movers
            df["score"] = (
                0.50 * _get_z("z_mom_3m") +
                0.25 * _get_z("z_rs_raw") +
                0.25 * _liq_z
            )
            log_emit(log_cb, f"[Prescreen] Mode=momentum_chase | 3m mom+RS scoring | {len(df)} candidates")
        elif _pmode in ["quality_defensive", "quality_compounders"]:
            # Quality Compounders: CMF + RS rating + liquidity - low volatility
            df["score"] = (
                0.35 * _get_z("z_cmf_score") +
                0.30 * _get_z("z_rs_raw") +
                0.20 * _liq_z -
                0.15 * _get_z("z_ann_vol")
            )
            log_emit(log_cb, f"[Prescreen] Mode={_pmode} | CMF+RS+low_vol scoring | {len(df)} candidates")
        elif _pmode == "garp":
            # Growth at Reasonable Price: 6M momentum + CMF + RS rating
            df["score"] = (
                0.35 * _get_z("z_mom_6m") +
                0.30 * _get_z("z_cmf_score") +
                0.20 * _get_z("z_rs_raw") +
                0.15 * _liq_z
            )
            log_emit(log_cb, f"[Prescreen] Mode=garp | GARP 6M mom+CMF+RS scoring | {len(df)} candidates")
        elif _pmode in ["pure_defensive", "defense"]:
            # Capital Preservation & Defense: Low Volatility + Low Drawdown + CMF Flow
            df["score"] = (
                0.40 * _get_z("z_cmf_score") -
                0.35 * _get_z("z_ann_vol") +
                0.25 * _liq_z
            )
            log_emit(log_cb, f"[Prescreen] Mode={_pmode} | Low_vol+CMF defensive scoring | {len(df)} candidates")
        elif _pmode == "institutional_alpha":
            # Smart money: OBV + CMF + RS + liquidity
            df["score"] = (
                0.30 * _get_z("z_rs_raw") +
                0.25 * _get_z("z_obv_slope") +
                0.25 * _get_z("z_cmf_score") +
                0.20 * _liq_z
            )
            log_emit(log_cb, f"[Prescreen] Mode=institutional_alpha | RS+OBV+CMF scoring | {len(df)} candidates")
        elif _pmode == "early_entry":
            # Smart Money Early-Entry: find base-building stocks BEFORE the breakout.
            # Must have range contraction (coiling), smart money volume, and NO falling-knife collapse.
            df["score"] = (
                0.30 * _get_z("z_vcp_score")          +  # Coiling = ready
                0.25 * _get_z("z_updown_vol")         +  # Smart money accumulating
                0.20 * _get_z("z_range_contraction")  +  # Volatility contraction / tight base
                0.15 * _get_z("z_obv_slope")          +  # OBV rising quietly
                0.10 * _liq_z                         -  # Minimum liquidity
                0.40 * np.maximum(0.0, -_get_z("z_mom_1m")) # Severe penalty for falling knife / short-term breakdown
            )
            log_emit(log_cb, f"[Prescreen] Mode=early_entry | VCP+UpDownVol+RangeContraction scoring (Anti-Knife penalized) | {len(df)} candidates")
        elif _pmode == "ipo_multibagger":
            # Institutional SOTA IPO Multibagger Model:
            # 1. Stochastic Drift & Persistence: Neural-SDE drift/diffusion + Hurst exponent (H > 0.60 super-diffusive regime)
            # 2. Microstructure Float Absorption: VCP squeeze + Up/Down volume ratio + OBV linear drift
            # 3. Relative Strength & Directional Efficiency: RS rating + Kaufman Efficiency Ratio (KER)
            # R35: the composite now comes from the SINGLE SOURCE OF TRUTH
            # (math_engine/ipo_multibagger_math.ipo_prescreen_score) — the
            # inline duplicate formula and the regression tests could drift
            # apart; they cannot anymore. The raw composite is preserved in
            # `score_raw` and `score` becomes the probability-calibrated rank
            # (strictly monotone map ⇒ identical selection ordering, but every
            # disclosed number is now a calibrated P(multibagger)).
            from math_engine.ipo_multibagger_math import ipo_prescreen_score, logistic_probability_map
            _ipo_score_raw = ipo_prescreen_score(df)
            df["score_raw"] = _ipo_score_raw
            if cfg.get("USE_PROBABILITY_RANKING", True):
                _br = float(cfg.get("IPO_BASE_RATE_PRIOR", 0.10))
                _kap = float(cfg.get("IPO_PROB_KAPPA", 0.35))
                df["score"] = logistic_probability_map(_ipo_score_raw, _br, _kap)
                _n_cal = int(df["score"].notna().sum())
                log_emit(log_cb, f"[Prescreen] Mode=ipo_multibagger | Neural-SDE+Hurst+VCP+KER composite → "
                                 f"P(multibagger) calibrated (base_rate={_br:.2%}, κ={_kap}, disclosed parameters) | "
                                 f"{len(df)} candidates | {_n_cal} calibrated")
            else:
                df["score"] = _ipo_score_raw
                log_emit(log_cb, f"[Prescreen] Mode=ipo_multibagger | Neural-SDE+Hurst+VCP+KER Institutional SOTA scoring | {len(df)} candidates")
        else:
            # balanced / fallback: mixed momentum + flow + liquidity
            _mom_w = float(cfg.get("PRESCREEN_MOM_WEIGHT", 0.55))
            _liq_w = float(cfg.get("PRESCREEN_LIQ_WEIGHT", 0.30))
            df["score"] = (
                _mom_w * _get_z("z_mom_6m") +
                0.15 * _get_z("z_cmf_score") +
                _liq_w * _liq_z
            )
            log_emit(log_cb, f"[Prescreen] Mode=balanced | 6m mom+CMF+liq scoring | {len(df)} candidates")

        df = df.sort_values("score", ascending=False).reset_index(drop=True)
        prescreen_df = df.copy()
        if cfg.get("USE_MANUAL_UNIVERSE"):
            screened = prescreen_df["ticker"].tolist()
            log_emit(log_cb, f"[ManualUniverse] Prescreen retained {len(screened)} / {len(all_tickers)} manual symbols")
        else:
            screened = df.head(cfg["TOP_N_UNIVERSE"])["ticker"].tolist()

        # v14: earnings blackout — remove stocks with earnings within ±N days
        _blackout = int(cfg.get("EARNINGS_BLACKOUT_DAYS", 5))
        if _blackout > 0:
            screened = apply_earnings_blackout(screened, _blackout, log_cb=log_cb)

        # v15: F&O ban list filter
        if cfg.get("USE_FNO_BAN_FILTER", True):
            if "_FNO_BAN_PREFETCHED" in cfg:
                ban_set = cfg["_FNO_BAN_PREFETCHED"]
                log_emit(log_cb, f"[F&O Ban] Reusing pre-fetched F&O ban list: {len(ban_set)} banned stocks")
            else:
                ban_set = fetch_fno_ban_list(log_cb=log_cb)
            if ban_set:
                before = len(screened)
                screened = [t for t in screened if t not in ban_set]
                log_emit(log_cb, f"[F&O Ban] {before - len(screened)} stock(s) removed. Remaining: {len(screened)}")

        # v16: Corporate actions blackout filter
        if cfg.get("USE_CORP_ACTIONS_FILTER", True):
            _ca_blocked = fetch_corp_actions_blackout(
                screened, int(cfg.get("CORP_ACTION_BLACKOUT_DAYS", 3)), log_cb=log_cb)
            if _ca_blocked:
                screened = [t for t in screened if t not in _ca_blocked]
            # Wire TICKER_BLACKLIST — persistent data-defect tickers (e.g. VENUSREM.NS)
            _ticker_bl = set(cfg.get('TICKER_BLACKLIST', []))
            if _ticker_bl:
                _before_bl = len(screened)
                screened = [t for t in screened if t not in _ticker_bl]
                _removed = _before_bl - len(screened)
                log_emit(log_cb, f"[Blacklist] {len(_ticker_bl)} tickers in blacklist | {_removed} removed (not in active universe if 0)")

        # Safety validation: need at least 2 tickers to optimize
        if len(screened) < 2:
            raise RuntimeError(
                f"Only {len(screened)} ticker(s) survived pre-screening and blackout/ban filters; need at least 2 for optimization. "
                "Try increasing manual universe, lowering min data/liquidity filters, or disabling earnings/F&O ban filters."
            )

        # Pre-adjust K_STOCKS if the screened universe is smaller than K_STOCKS
        if len(screened) < cfg["K_STOCKS"]:
            old_k = cfg["K_STOCKS"]
            cfg["K_STOCKS"] = len(screened)
            log_emit(log_cb, f"[Optimizer] ⚠️ Pre-adjusted portfolio size K_STOCKS from {old_k} to {cfg['K_STOCKS']} because only {len(screened)} tickers are in the universe.")

        # v15: FII/DII flow regime overlay — adjusts GAMMA penalty
        _fii_data = {}
        # Guard: copy cfg before any per-run mutation (FII, VIX, regime adjustments)
        working_cfg = copy.deepcopy(cfg)  # deep-copy: nested dicts (FACTOR_WEIGHTS) stay isolated

        if cfg.get("USE_FII_REGIME_OVERLAY", True):
            if "_FII_DATA_PREFETCHED" in cfg:
                _fii_data = cfg["_FII_DATA_PREFETCHED"]
                log_emit(log_cb, f"[FII/DII] Reusing pre-fetched FII/DII data: signal={_fii_data.get('flow_signal')} | fii_z_score={_fii_data.get('fii_z_score')}")
            else:
                _fii_data = fetch_fii_dii_flow(log_cb=log_cb)
            # Bull flow → loosen concentration (lower GAMMA 10%), Bear → tighten (raise 10%)
            if _fii_data.get("flow_signal") == "Bull":
                working_cfg["GAMMA"] = working_cfg.get("GAMMA", 22.0) * 0.90
                log_emit(log_cb, f"[FII/DII] Bull signal — GAMMA eased to {working_cfg['GAMMA']:.1f}")
            elif _fii_data.get("flow_signal") == "Bear":
                working_cfg["GAMMA"] = working_cfg.get("GAMMA", 22.0) * 1.10
                log_emit(log_cb, f"[FII/DII] Bear signal — GAMMA tightened to {working_cfg['GAMMA']:.1f}")

        # v16: fetch IndiaVIX for later position sizing
        _india_vix = float("nan")
        if cfg.get("USE_INDIA_VIX_SIZING", True):
            if "_INDIA_VIX_PREFETCHED" in cfg:
                _india_vix = cfg["_INDIA_VIX_PREFETCHED"]
                log_emit(log_cb, f"[Market Context] Reusing pre-fetched India VIX: {_india_vix}")
            else:
                _india_vix = fetch_india_vix(log_cb=log_cb)

        working_cfg["_INDIA_VIX"] = _india_vix

        sectors = fetch_sectors(screened, cfg, log_cb=log_cb, progress_cb=progress_cb)
        _dl = _download_ohlcv_bundle(screened, cfg["LOOKBACK_DOWNLOAD"], log_cb=log_cb)
        open_px = _dl["Open"]; high_px = _dl["High"]; low_px = _dl["Low"]
        close, volume = _dl["Close"], _dl["Volume"]
        
        # Clean panels requiring at least 2 columns so we don't prematurely discard everything
        close, volume, returns = clean_market_panels(close, volume, 2)
        if close.empty or close.shape[1] < cfg["K_STOCKS"]:
            _orig_close, _orig_volume, _orig_returns = close, volume, returns
            _fallback_n = min(len(screened), max(int(cfg["K_STOCKS"]) * 4, 32))
            _fallback = list(prescreen_df.head(_fallback_n)["ticker"]) if "ticker" in prescreen_df.columns else list(screened[:_fallback_n])
            log_emit(log_cb, f"[DownloadRecovery] Full-universe download returned {close.shape[1] if not close.empty else 0} tickers (target {cfg['K_STOCKS']}). Retrying with top {_fallback_n} tickers and smaller batches.")
            # FIX: was a single one-shot fallback attempt — with MAX_PARALLEL raised
            # to 4, simultaneous NSE requests from other profiles can throttle this
            # same retry too, causing a hard crash on transient rate-limiting rather
            # than genuine data unavailability. Retry with backoff before giving up.
            _max_recovery_attempts = int(cfg.get("DOWNLOAD_RECOVERY_ATTEMPTS", 3))
            for _attempt in range(1, _max_recovery_attempts + 1):
                _backoff_s = 2.0 * _attempt  # 2s, 4s, 6s — increasing courtesy pause
                time.sleep(_backoff_s)  # UI001: time.sleep on main thread freezes Qt — move to worker thread
                _dl = _download_ohlcv_bundle(
                    _fallback,
                    cfg["LOOKBACK_DOWNLOAD"],
                    log_cb=log_cb,
                    batch_size_override=int(cfg.get("DOWNLOAD_RECOVERY_BATCH_SIZE", 10)),
                )
                _ret_open = _dl["Open"]; _ret_high = _dl["High"]; _ret_low = _dl["Low"]
                _ret_close, _ret_volume = _dl["Close"], _dl["Volume"]
                _ret_close, _ret_volume, _ret_returns = clean_market_panels(_ret_close, _ret_volume, 2)
                if not _ret_close.empty and _ret_close.shape[1] >= cfg["K_STOCKS"]:
                    close, volume, returns = _ret_close, _ret_volume, _ret_returns
                    open_px, high_px, low_px = _ret_open, _ret_high, _ret_low
                    screened = [t for t in _fallback if t in close.columns]
                    sectors = {t: sectors.get(t, "N/A") for t in screened}
                    log_emit(log_cb, f"[DownloadRecovery] Recovered {len(screened)} tickers from fallback subset (attempt {_attempt}/{_max_recovery_attempts}).")
                    break
                elif not _ret_close.empty and _ret_close.shape[1] >= 2 and _ret_close.shape[1] > (close.shape[1] if not close.empty else 0):
                    # Partial recovery — not enough for K_STOCKS but better than previous
                    close, volume, returns = _ret_close, _ret_volume, _ret_returns
                    open_px, high_px, low_px = _ret_open, _ret_high, _ret_low
                    screened = [t for t in _fallback if t in close.columns]
                    sectors = {t: sectors.get(t, "N/A") for t in screened}
                    log_emit(log_cb, f"[DownloadRecovery] Partial recovery: {len(screened)} tickers (below K_STOCKS target, attempt {_attempt}/{_max_recovery_attempts}). Proceeding with reduced candidate set.")
                    break
                else:
                    log_emit(log_cb, f"[DownloadRecovery] Attempt {_attempt}/{_max_recovery_attempts} did not improve panel ({_ret_close.shape[1] if not _ret_close.empty else 0} usable tickers).")
            # If recovery failed or yielded worse results, restore original non-empty panel if valid
            if (close.empty or close.shape[1] < 2) and (not _orig_close.empty and _orig_close.shape[1] >= 2):
                close, volume, returns = _orig_close, _orig_volume, _orig_returns
                log_emit(log_cb, f"[DownloadRecovery] Preserved original panel with {close.shape[1]} clean tickers.")
        if close.empty or close.shape[1] < 2:
            raise RuntimeError(
                f"Only {close.shape[1] if not close.empty else 0} tickers retained enough clean price history for optimization; need at least 2. "
                "Try increasing lookback, lowering min data/liquidity filters, or increasing universe size."
            )
            
        if cfg.get("USE_LOCAL_CORP_ADJUSTMENTS", False):
            try:
                from data_layer import fetch_corporate_actions_pit
                from math_engine.corporate_adjustments import CorporateActionsAdjuster
                
                run_date = datetime.now()
                corp_actions_dict = fetch_corporate_actions_pit(list(close.columns), as_of_date=run_date, log_cb=log_cb)
                
                adj_open_cols = {}
                adj_high_cols = {}
                adj_low_cols = {}
                adj_close_cols = {}
                adj_vol_cols = {}
                
                for ticker in close.columns:
                    actions_list = corp_actions_dict.get(ticker, [])
                    stock_df = pd.DataFrame({
                        "Open": open_px[ticker],
                        "High": high_px[ticker],
                        "Low": low_px[ticker],
                        "Close": close[ticker],
                        "Volume": volume[ticker]
                    }, index=close.index)
                    
                    adj_stock_df = CorporateActionsAdjuster.adjust_prices_pit(stock_df, actions_list, run_date)
                    adj_open_cols[ticker] = adj_stock_df["Open"]
                    adj_high_cols[ticker] = adj_stock_df["High"]
                    adj_low_cols[ticker] = adj_stock_df["Low"]
                    adj_close_cols[ticker] = adj_stock_df["Close"]
                    adj_vol_cols[ticker] = adj_stock_df["Volume"]
                    
                open_px = pd.DataFrame(adj_open_cols, index=open_px.index)
                high_px = pd.DataFrame(adj_high_cols, index=high_px.index)
                low_px = pd.DataFrame(adj_low_cols, index=low_px.index)
                close = pd.DataFrame(adj_close_cols, index=close.index)
                volume = pd.DataFrame(adj_vol_cols, index=volume.index)
                
                # Recompute returns based on PIT-adjusted Close series (ffill to prevent trading halt zero-biasing)
                returns = np.log(close.ffill() / close.ffill().shift(1)).fillna(0.0)
                log_emit(log_cb, "[CorpAdjuster] Applied Point-in-Time corporate actions adjustments to downloaded live OHLCV data.")
            except Exception as _cae:
                log_emit(log_cb, f"[CorpAdjuster] Warning: corporate actions adjustments failed: {_cae}", exc_info=True)

        if close.shape[1] < cfg["K_STOCKS"]:
            old_k = cfg["K_STOCKS"]
            cfg["K_STOCKS"] = close.shape[1]
            working_cfg["K_STOCKS"] = close.shape[1]
            log_emit(log_cb, f"[Optimizer] ⚠️ Dynamically adjusted portfolio size K_STOCKS from {old_k} to {close.shape[1]} because only {close.shape[1]} assets survived data filters.")
            # Re-run clean_market_panels with the new, adjusted K_STOCKS
            close, volume, returns = clean_market_panels(close, volume, cfg["K_STOCKS"])
            
        if returns.empty or returns.shape[1] < 2:
            raise RuntimeError(
                f"Only {returns.shape[1] if not returns.empty else 0} tickers survived return cleaning; need at least 2. "
                "Try increasing lookback, lowering min data/liquidity filters, or reducing portfolio size."
            )
            
        if returns.shape[1] < cfg["K_STOCKS"]:
            old_k = cfg["K_STOCKS"]
            cfg["K_STOCKS"] = returns.shape[1]
            working_cfg["K_STOCKS"] = returns.shape[1]
            log_emit(log_cb, f"[Optimizer] ⚠️ Dynamically adjusted portfolio size K_STOCKS from {old_k} to {returns.shape[1]} because only {returns.shape[1]} assets survived return cleaning.")
        
        returns = scrub_anomalies(returns, log_cb)
        close = close[returns.columns].loc[returns.index]
        volume = volume[returns.columns].loc[returns.index]
        if prev_holdings:
            _matched_prev = sorted(t for t in prev_holdings if t in returns.columns)
            log_emit(log_cb, f"[PrevHoldings] Matched {len(_matched_prev)}/{len(prev_holdings)} with cleaned universe")
            if _matched_prev:
                log_emit(log_cb, f"[PrevHoldings] Active turnover anchors: {_matched_prev[:12]}")
        open_px = open_px.reindex(index=returns.index, columns=returns.columns).ffill().bfill()
        high_px = high_px.reindex(index=returns.index, columns=returns.columns).ffill().bfill()
        low_px = low_px.reindex(index=returns.index, columns=returns.columns).ffill().bfill()
        data = {"Open": open_px, "High": high_px, "Low": low_px, "Close": close, "Volume": volume}

        benchmark_symbol, benchmark_returns = fetch_benchmark_returns(cfg, returns.index, log_cb=log_cb, progress_cb=progress_cb)
        from data_layer import get_benchmark_last_price
        _bm_px = get_benchmark_last_price()
        if _bm_px is not None:
            working_cfg["_BENCHMARK_PRICE"] = _bm_px
        # Sweep optimisation: if Orchestrator pre-detected the regime, inject it directly
        # to skip 9 identical HMM inference runs (one per profile worker).
        _prefetched_regime = cfg.get("_REGIME_INFO_PREFETCHED")
        if _prefetched_regime:
            regime_info = dict(_prefetched_regime)
            log_emit(log_cb, f"[Regime] Using pre-detected regime: {regime_info.get('Regime', 'Unknown')} (conf={regime_info.get('RegimeBlend', float('nan')):.1%}) — skipping redundant HMM inference.")
        else:
            regime_info = detect_market_regime(close, benchmark_returns)
        # AUDIT-FIX (Round 21 — R21-3): establish benchmark HMM as single canonical market regime source
        working_cfg["_CANONICAL_MARKET_REGIME"] = regime_info.get("Regime", "Sideways")
    # IMP11: _CLOSE_DF is a large DataFrame — never pass working_cfg through copy.deepcopy(); access via cfg["_CLOSE_DF"] directly.
        working_cfg["_CLOSE_DF"] = close  # FIX6: PEAD signal needs price history
        working_cfg["CHART_IMAGE_TIMEFRAME"] = str(working_cfg.get("CHART_IMAGE_TIMEFRAME", "1d")).lower()
        # v17.25: validate alpha predictions from previous runs (non-blocking)
        _post_trade_df = validate_past_predictions(close, log_cb=log_cb, cfg=cfg)

        working_cfg["_REGIME_INFO"] = regime_info
        q, signal_df, clean_returns = build_qubo(data, returns, benchmark_returns, sectors, prev_holdings, working_cfg, log_cb=log_cb)
        progress_span(progress_cb, 48, 68, 1, 1)

        # v16: sector momentum filter — remove stocks from negative-momentum sectors
        if working_cfg.get("USE_SECTOR_MOM_FILTER", True):
            _sec_mom = compute_sector_momentum(
                returns, sectors, int(working_cfg.get("SECTOR_MOM_LOOKBACK", 126)))
            signal_df = apply_sector_momentum_filter(signal_df, _sec_mom, sectors, log_cb=log_cb)

        # AUDIT-FIX (Round 6, B-P2-4): this first alpha-decay block was an
        # exact duplicate of the fuller block that runs AFTER
        # alpha-neutralization/confidence-weighting (~300 lines below) — both
        # multiplied alpha_score by exp(-t/T_half), so the effective decay was
        # exp(-2t/T_half): a 21-day-old signal with a 10-day half-life decayed
        # to 0.015 instead of 0.123, silently zeroing most of the alpha signal
        # (and logging the decay line twice per run). The first block is
        # removed; the second (fuller, factor-key-complete) one is canonical
        # and now also owns the `_alpha_decay_calibrated` flag.

        # v16: fundamentals signal injection (disabled by default — slow)
        if working_cfg.get("USE_FUNDAMENTALS", False):
            _fund_raw = fetch_fundamentals(
                [t+".NS" if not t.endswith(".NS") else t for t in signal_df.index],
                as_of_date=working_cfg.get("as_of_date"),
                log_cb=log_cb)  # v17.20 F5: pass .NS suffix — yfinance requires it for NSE
            if _fund_raw:
                _fund_scores = compute_fundamental_score(_fund_raw, list(signal_df.index))
                _fw = float(working_cfg.get("FUNDAMENTALS_WEIGHT", 0.06))
                _fs_series = _fund_scores["fund_score"] if isinstance(_fund_scores, pd.DataFrame) and "fund_score" in _fund_scores.columns else (_fund_scores.sum(axis=1) if isinstance(_fund_scores, pd.DataFrame) else _fund_scores)
                signal_df["fund_score"] = _fs_series.reindex(signal_df.index).fillna(0.0)
                signal_df["z_fundamentals"] = robust_zscore_series(signal_df["fund_score"])
                signal_df["alpha_score"] = (
                    signal_df["alpha_score"] + _fw * signal_df["z_fundamentals"].fillna(0.0))
                log_emit(log_cb, f"[Fundamentals] Quality score blended into alpha (weight={_fw})")
                # v17.20 G2: individual columns so IC engine sees 13 factors
                _roe_s   = pd.Series({t:  _fund_raw.get(t, {}).get("roe",     float("nan")) for t in signal_df.index})
                _deinv_s = pd.Series({t: -_fund_raw.get(t, {}).get("de_ratio", float("nan")) for t in signal_df.index})  # fixed: was 'deratio'
                _peinv_s = pd.Series({t: (1.0 / _fund_raw.get(t, {}).get("pe_ratio", float("nan")) if _fund_raw.get(t, {}).get("pe_ratio") else float("nan")) for t in signal_df.index})  # fixed: was 'pe'
                
                signal_df["z_roe"]    = robust_zscore_series(_roe_s.reindex(signal_df.index))
                signal_df["z_de_inv"] = robust_zscore_series(_deinv_s.reindex(signal_df.index))
                signal_df["z_pe_inv"] = robust_zscore_series(_peinv_s.reindex(signal_df.index).fillna(0.0))
                log_emit(log_cb, f"[Fundamentals] ROE, D/E, and P/E populated | coverage={signal_df['z_roe'].notna().sum()}/{len(signal_df)}")
                # v17.28 — persist fundraw for IC calibration (cross-run)
                # AUDIT-FIX (defect #5): the prior `global _FUNDRAW_IC_CACHE;
                # _FUNDRAW_IC_CACHE.clear(); _FUNDRAW_IC_CACHE.update(...)` pattern
                # had a TOCTOU window between clear() and update() in which a
                # parallel profile worker could read an empty cache. The lock-
                # guarded helper in utils.py performs the swap atomically.
                from utils import update_fundraw_ic_cache
                update_fundraw_ic_cache(_fund_raw)

        # v17: F&O Open Interest buildup signal
        if working_cfg.get("USE_OI_SIGNAL", True):
            _oi_map = fetch_oi_buildup_signal(list(signal_df.index), log_cb=log_cb)
            if _oi_map:
                signal_df["oi_score"] = pd.Series(_oi_map).reindex(signal_df.index).fillna(0.0)
                signal_df["z_oi"] = robust_zscore_series(signal_df["oi_score"])
                _ow = float(working_cfg.get("OI_WEIGHT", 0.07))
                signal_df["alpha_score"] = (
                    signal_df["alpha_score"] + _ow * signal_df["z_oi"].fillna(0.0))
                log_emit(log_cb, f"[OI Signal] Blended into alpha (weight={_ow})")

        # v17: SAST insider/promoter buying signal
        if working_cfg.get("USE_SAST_SIGNAL", False):
            _sast_map = fetch_sast_signal(list(signal_df.index), log_cb=log_cb)
            if _sast_map:
                signal_df["sast_filings"] = pd.Series(_sast_map).reindex(signal_df.index).fillna(0.0)
                signal_df["z_sast"] = robust_zscore_series(signal_df["sast_filings"])
                # Use profile FACTOR_WEIGHTS z_sast_vel override if set.
                # Also check SAST_VEL_WEIGHT (set by Smart Money profile).
                # Falls back to SAST_WEIGHT (legacy key) then hardcoded 0.06.
                _fw_sast = working_cfg.get("FACTOR_WEIGHTS", {})
                _sw = float(
                    _fw_sast.get("z_sast_vel")
                    if _fw_sast.get("z_sast_vel") is not None
                    else working_cfg.get("SAST_VEL_WEIGHT",
                         working_cfg.get("SAST_WEIGHT", 0.06))
                )
                signal_df["alpha_score"] = (
                    signal_df["alpha_score"] + _sw * signal_df["z_sast"].fillna(0.0))

        # v16: Options IV signal (disabled by default — slow, one call/ticker)
        if working_cfg.get("USE_IV_SIGNAL", False):
            _iv_map = fetch_iv_rank(list(signal_df.index), log_cb=log_cb)
            if _iv_map:
                signal_df["ivr"] = pd.Series(_iv_map).reindex(signal_df.index)
                # Low IVR = bullish signal (invert: 1-IVR so high score = low IV)
                signal_df["z_iv"] = robust_zscore_series(1.0 - signal_df["ivr"].fillna(0.5))
                _iw = float(working_cfg.get("IV_WEIGHT", 0.04))
                signal_df["alpha_score"] = (
                    signal_df["alpha_score"] + _iw * signal_df["z_iv"].fillna(0.0))
                log_emit(log_cb, f"[OptionsIV] IVR signal blended into alpha (weight={_iw})")

        # v15: inject NSE delivery volume signal into signal_df before solve
        if working_cfg.get("USE_DELIVERY_SIGNAL", True):
            _dlv_map = fetch_nse_delivery_data(list(signal_df.index), log_cb=log_cb)
            if _dlv_map:
                for _t in signal_df.index:
                    if _t in _dlv_map:
                        signal_df.at[_t, "delivery_pct"] = _dlv_map[_t]
                if signal_df["delivery_pct"].notna().sum() > 4:
                    signal_df["z_delivery"] = robust_zscore_series(signal_df["delivery_pct"])
                    _fw = working_cfg.get("FACTOR_WEIGHTS", {})
                    _dw = float(
                        _fw.get("z_delivery")
                        if _fw.get("z_delivery") is not None
                        else working_cfg.get("DELIVERY_WEIGHT", 0.08)
                    )
                    signal_df["alpha_score"] = (
                        signal_df["alpha_score"] + _dw * signal_df["z_delivery"].fillna(0.0)
                    )
                    log_emit(log_cb, f"[DeliveryVol] Signal blended into alpha (weight={_dw})")

        # v15: inject promoter signal if enabled (slow — off by default)
        if working_cfg.get("USE_PROMOTER_SIGNAL", False):
            _ph = fetch_promoter_holdings(list(signal_df.index), log_cb=log_cb)
            for _t, _pct in _ph.items():
                if _t in signal_df.index:
                    signal_df.at[_t, "promoter_pct"] = _pct
            if signal_df["promoter_pct"].notna().sum() > 4:
                signal_df["z_promoter"] = robust_zscore_series(signal_df["promoter_pct"])
                _pw = float(working_cfg.get("PROMOTER_WEIGHT", 0.05))
                signal_df["alpha_score"] = (
                    signal_df["alpha_score"] + _pw * signal_df["z_promoter"].fillna(0.0)
                )
                # ── Phase 9: Market Breadth → alpha_score ───────────────────────────────────
                if working_cfg.get('USE_BREADTH_SIGNAL', True):
                    try:
                        _adv = int((returns.iloc[-1] > 0).sum())
                        _dec = int((returns.iloc[-1] < 0).sum())
                        _tot = max(_adv + _dec, 1)
                        _ad  = (_adv - _dec) / _tot  # DIV001: guard divisor before use
                        # H1-fix: close_all was never defined; the actual variable is `close` (DataFrame
                        # of close prices, defined earlier in this function). The dead 'close_all' in dir()
                        # guard silently zeroed the 40% NH/NL component of the breadth signal.
                        try:
                            _nh = int((close.iloc[-1] >= close.tail(252).max()).sum())
                            _nl = int((close.iloc[-1] <= close.tail(252).min()).sum())
                        except Exception:
                            _nh, _nl = 0, 0
                        _bsc = 0.6 * _ad + 0.4 * (_nh - _nl) / _tot  # DIV001: guard divisor before use
                        _bw  = float(working_cfg.get('BREADTH_WEIGHT', 0.04))
                        signal_df['breadth_signal'] = _bsc
                        signal_df['z_breadth'] = robust_zscore_series(signal_df['breadth_signal'])
                        signal_df['alpha_score'] = signal_df['alpha_score'] + _bw * signal_df['z_breadth'].fillna(0.0)
                        working_cfg['_BREADTH_STATS'] = {'adv': _adv, 'dec': _dec, 'ad_ratio': round(_ad, 3), 'breadth_score': round(_bsc, 3)}
                        log_emit(log_cb, f'[Breadth] A/D={_adv}/{_dec} score={_bsc:.3f} w={_bw}')
                    except Exception as _be:
                        log_emit(log_cb, f'[Breadth] skipped: {_be}', exc_info=True)
                # ── Phase 9: Market Width → alpha_score ──────────────────────────────────────
                if working_cfg.get('USE_MARKET_WIDTH_SIGNAL', True):
                    try:
                        _prices = returns.add(1).cumprod()
                        _n   = max(_prices.shape[1], 1)
                        _a20 = int((_prices.iloc[-1] >= _prices.rolling(20).mean().iloc[-1]).sum())
                        _a50 = int((_prices.iloc[-1] >= _prices.rolling(50).mean().iloc[-1]).sum())
                        _a200= int((_prices.iloc[-1] >= _prices.rolling(min(200, len(_prices))).mean().iloc[-1]).sum())
                        _mws = (0.2 * _a20 + 0.3 * _a50 + 0.5 * _a200) / _n * 2 - 1  # DIV001: guard divisor before use
                        _mww = float(working_cfg.get('MARKET_WIDTH_WEIGHT', 0.04))
                        signal_df['mw_signal'] = _mws
                        signal_df['z_market_width'] = robust_zscore_series(signal_df['mw_signal'])
                        signal_df['alpha_score'] = signal_df['alpha_score'] + _mww * signal_df['z_market_width'].fillna(0.0)
                        working_cfg['_MW_STATS'] = {'above_ma20': _a20, 'above_ma50': _a50, 'above_ma200': _a200, 'total': _n, 'mw_score': round(_mws, 3)}
                        log_emit(log_cb, f'[MarketWidth] MA20={_a20} MA50={_a50} MA200={_a200}/{_n} score={_mws:.3f} w={_mww}')
                    except Exception as _mwe:
                        log_emit(log_cb, f'[MarketWidth] skipped: {_mwe}', exc_info=True)
                # ── Phase 9: Earnings Breadth → alpha_score ──────────────────────────────────
                if working_cfg.get('USE_EARNINGS_BREADTH_SIGNAL', True):
                    try:
                        _pc  = next((c for c in signal_df.columns if 'pead' in c.lower()), None)
                        _eb  = (signal_df[_pc].fillna(0.0) if _pc
                                else (returns.tail(21).mean() - returns.mean()).reindex(signal_df.index).fillna(0.0))
                        _ebw = float(working_cfg.get('EARNINGS_BREADTH_WEIGHT', 0.03))
                        signal_df['earnings_breadth'] = _eb
                        signal_df['z_earnings_breadth'] = robust_zscore_series(signal_df['earnings_breadth'])
                        signal_df['alpha_score'] = signal_df['alpha_score'] + _ebw * signal_df['z_earnings_breadth'].fillna(0.0)
                        log_emit(log_cb, f'[EarningsBreadth] blended (PEAD={_pc is not None}, w={_ebw})')
                    except Exception as _ebe:
                        log_emit(log_cb, f'[EarningsBreadth] skipped: {_ebe}', exc_info=True)
                # ── Phase 9: Social/Volume Buzz → alpha_score ────────────────────────────────
                if working_cfg.get('USE_SOCIAL_BUZZ_SIGNAL', False):
                    try:
                        _vol_df   = returns.copy(); _vol_df[:] = 0  # shape placeholder
                        try: _vol_df = pd.DataFrame({t: data['Volume'][t] for t in returns.columns})
                        except Exception as _e:
                            ExceptionLogger.swallow(_e, context='auto-EXC002')
                        _avg_v = _vol_df.rolling(20).mean().iloc[-1].replace(0, float('nan'))
                        _bz    = (_vol_df.iloc[-1] / (_avg_v + 1e-9) - 1.0).reindex(signal_df.index).fillna(0.0).clip(-3, 3)
                        _sbw   = float(working_cfg.get('SOCIAL_BUZZ_WEIGHT', 0.03))
                        signal_df['social_buzz'] = _bz
                        signal_df['z_social_buzz'] = robust_zscore_series(signal_df['social_buzz'])
                        signal_df['alpha_score'] = signal_df['alpha_score'] + _sbw * signal_df['z_social_buzz'].fillna(0.0)
                        log_emit(log_cb, f'[SocialBuzz] vol-proxy buzz blended (w={_sbw})')
                    except Exception as _sbe:
                        log_emit(log_cb, f'[SocialBuzz] skipped: {_sbe}', exc_info=True)


        # v17.22 P9: risk-adjusted alpha — high-risk stocks penalised before QUBO
        try:
            _risk_cols = [c for c in ("z_ann_vol","z_downside_vol","z_drawdown")
                          if c in signal_df.columns]
            if _risk_cols:
                _risk_comp = signal_df[_risk_cols].clip(lower=0).fillna(0).mean(axis=1)
                _risk_comp = (_risk_comp - _risk_comp.min()) / (_risk_comp.max() - _risk_comp.min() + 1e-9)
        except Exception as _re:
            log_emit(log_cb, f"[RiskAdj] skipped: {_re}", exc_info=True)

        # Math Engine: Copula Left-Tail Risk Stress Testing Integration
        if working_cfg.get("USE_COPULA_TAIL_RISK", True) and not returns.empty and len(signal_df) >= 3:
            try:
                from math_engine.copula_risk import CopulaTailRiskScreener
                _copula_screener = CopulaTailRiskScreener()
                _c_ret = returns[[c for c in signal_df.index if c in returns.columns]]
                if not _c_ret.empty and _c_ret.shape[1] >= 3:
                    _copula_metrics = _copula_screener.evaluate_portfolio_tail_risk(_c_ret.to_numpy())
                    _tail_es = _copula_metrics.get("stress_scenario_expected_shortfall_95", 0.05)
                    log_emit(log_cb, f"[CopulaTailRisk] Evaluated joint left-tail risk | stress 95% ES={_tail_es:.4f}")
            except Exception as _cte:
                log_emit(log_cb, f"[CopulaTailRisk] Notice: {_cte}", exc_info=True)

        # ── INSTITUTIONAL FIX: Factor-Neutralized Alpha ────────────────────────────────
        # Residualizes alpha_score against systematic factor exposures to remove
        # beta/momentum/size contamination. Raw alpha in a bull market is ~80%
        # correlated with market beta — this step isolates stock-specific signal.
        # Controlled by USE_ALPHA_NEUTRALIZATION (default: True).
        if working_cfg.get("USE_ALPHA_NEUTRALIZATION", True):
            try:
                from ml_alpha.metrics import neutralize_alpha as _neutralize_alpha
                # Build the factor exposure matrix from z_* columns already in signal_df
                # These are the standardized factor scores — no extra data needed
                _default_neutralize_factors = ["z_mom_6m", "z_ann_vol", "z_adv20", "z_roe", "z_mom_1m"]
                _neut_factors = working_cfg.get("ALPHA_NEUTRALIZE_FACTORS", _default_neutralize_factors)
                _neut_cols = [f for f in _neut_factors if f in signal_df.columns]
                if len(_neut_cols) >= 2:
                    _B = signal_df[_neut_cols].copy()
                    _raw_alpha = signal_df["alpha_score"].copy()
                    _neut_res = _neutralize_alpha(_raw_alpha, _B, return_r2=True)
                    if isinstance(_neut_res, tuple):
                        _neut_alpha, _r2 = _neut_res
                    else:
                        _neut_alpha, _r2 = _neut_res, 0.0
                    # Blend: keep 70% neutralized + 30% raw for smooth transition
                    _neut_blend = float(working_cfg.get("ALPHA_NEUTRALIZE_BLEND", 0.70))
                    signal_df["alpha_score"] = _neut_blend * _neut_alpha + (1.0 - _neut_blend) * _raw_alpha
                    log_emit(log_cb, f"[AlphaNeutralize] OLS residualized against {_neut_cols} | "
                             f"blend={_neut_blend:.0%} | factor R²={_r2:.3f}")
                else:
                    log_emit(log_cb, f"[AlphaNeutralize] Skipped — fewer than 2 factor columns available ({_neut_cols})")
            except Exception as _ane:
                log_emit(log_cb, f"[AlphaNeutralize] skipped: {_ane}", exc_info=True)

        # v17.22 P5: confidence-weight alpha by inverse factor variance
        try:
            _fv = signal_df[[c for c in signal_df.columns if c.startswith("z_")]].var(axis=1).clip(lower=0.1)
            _conf = (1.0 / _fv).clip(upper=3.0)  # DIV001: guard divisor before use
            _conf = (_conf - _conf.min()) / (_conf.max() - _conf.min() + 1e-9) * 0.5 + 0.75
            signal_df["alpha_score"] = signal_df["alpha_score"] * _conf
            log_emit(log_cb, f"[AlphaConf] Confidence weighting | range={_conf.min():.2f}–{_conf.max():.2f}")
        except Exception as _ce:
            log_emit(log_cb, f"[AlphaConf] skipped: {_ce}", exc_info=True)

        # ── Alpha Decay Weighting: exp(-t / T_half) per factor class ──────────────
        # Multiplies each stock's alpha_score by a temporal decay factor that
        # reflects how "fresh" the dominant signal is. Momentum signals have a
        # short half-life (~10 days on NSE); value signals decay slowly (~60d).
        # Net effect: stocks whose primary signal edge is stale get discounted
        # before they enter the QUBO — institutional standard (Grinold & Kahn §5).
        #
        # AUDIT-FIX (defect #P1-4): the prior implementation masked the
        # calibration-failed sentinel (T_half=0.0) three times:
        #   (1) `_total_fw + 1e-9` prevented ZeroDivisionError when FACTOR_WEIGHTS was empty
        #   (2) `max(_T_half_blended, 1.0)` silently substituted 1.0 for the sentinel zero
        #   (3) `np.clip(_decay_factor, 0.50, 1.00)` bounded the output to a "plausible" range
        # so when FACTOR_WEIGHTS was empty, the pipeline proceeded as if calibration
        # succeeded and logged a misleading T_half=10.0d / decay=0.9048. We now
        # detect the sentinel explicitly and surface a loud WARNING + skip the
        # decay weighting entirely when calibration fails.
        if working_cfg.get("USE_ALPHA_DECAY", True):
            try:
                # Determine the dominant factor class for this profile from FACTOR_WEIGHTS
                _fw_now = working_cfg.get("FACTOR_WEIGHTS", {})
                _mom_keys = ("z_mom_1m", "z_mom_3m", "z_mom_6m", "z_mom_12_1", "z_trend_20", "z_trend_50", "z_cmf", "z_obv_slope", "z_updown_vol", "z_delivery", "z_trend_quality", "z_rs_score", "z_breakout_dist", "z_vol_surge")
                _val_keys = ("z_roe", "z_pe_inv", "z_de_inv", "z_rev_growth", "z_f_score", "z_z_score", "z_ebitda_margin", "z_quality",
                             "z_pead")  # PEAD = post-earnings drift; empirical IC half-life ~30-60d (Bernard & Thomas 1989)
                _vol_keys = ("z_vpin_toxicity", "z_range_contraction", "z_vcp_score", "z_vcp", "z_bb_width", "z_volume_dryup", "z_ann_vol", "z_downside_vol", "z_ma_compression", "z_roll_spread", "z_float_squeeze", "z_beta", "z_sast_vel", "z_bulk_deal_footprint", "z_pledge_red", "z_drawdown", "z_sweet_spot_52w")

                _mom_weight = sum(abs(_fw_now.get(k, 0.0)) for k in _mom_keys)
                _val_weight = sum(abs(_fw_now.get(k, 0.0)) for k in _val_keys)
                _vol_weight = sum(abs(_fw_now.get(k, 0.0)) for k in _vol_keys)
                _accounted = set(_mom_keys) | set(_val_keys) | set(_vol_keys)
                _other = sum(abs(v) for k, v in _fw_now.items() if k not in _accounted)
                _vol_weight += _other
                _total_fw = _mom_weight + _val_weight + _vol_weight
                # AUDIT-FIX (defect #P1-4): no +1e-9 epsilon — let a zero total
                # surface as an explicit calibration failure rather than being
                # silently laundered into a tiny denominator.
                if _total_fw < 1e-6:
                    log_emit(log_cb, (
                        "[AlphaDecay] ⚠️ CALIBRATION FAILED — FACTOR_WEIGHTS empty or all-zero. "
                        "Skipping decay weighting (decay factor = 1.0). Fix FACTOR_WEIGHTS for "
                        f"profile={working_cfg.get('PROFILE_NAME','?')}."
                    ))
                    signal_df["alpha_decay_factor"] = 1.0
                    _alpha_decay_calibrated = False
                else:
                    # Blended half-life (days): momentum=10d, microstructure=5d, value=60d
                    # Empirical NSE IC half-life study (Motilal Oswal quant, 2022):
                    # short-term mom IC halves in ~8 trading days; value IC in ~55 days.
                    _T_half_blended = (
                        _mom_weight  / _total_fw * 10.0 +
                        _vol_weight  / _total_fw *  5.0 +
                        _val_weight  / _total_fw * 60.0
                    )
                    _T_half_blended = float(working_cfg.get("ALPHA_DECAY_HALFLIFE_DAYS", _T_half_blended))
                    # AUDIT-FIX (defect #P1-4): explicit guard — if the operator
                    # has overridden ALPHA_DECAY_HALFLIFE_DAYS to 0 (or the
                    # blended computation collapsed to 0), skip with a warning
                    # rather than silently substituting 1.0 via max().
                    if not np.isfinite(_T_half_blended) or _T_half_blended <= 0.0:
                        log_emit(log_cb, (
                            f"[AlphaDecay] ⚠️ INVALID T_half={_T_half_blended} (must be finite positive). "
                            "Skipping decay weighting (decay factor = 1.0)."
                        ))
                        signal_df["alpha_decay_factor"] = 1.0
                        _alpha_decay_calibrated = False
                    else:
                        # t = days since last rebalance (or 1 if unknown)
                        _t_since_rebal = float(working_cfg.get("DAYS_SINCE_REBALANCE", 1))
                        _decay_factor  = float(np.exp(-_t_since_rebal / _T_half_blended))
                        # AUDIT-FIX (Round 3, P2-3): removed the third mask
                        # `np.clip(_decay_factor, 0.50, 1.00)` from the audit's
                        # "T_half=0 sentinel" trio. With the two sentinel guards
                        # above (lines 7410 and 7432), we never reach this line
                        # when T_half is degenerate; when we DO reach it, a
                        # legitimate short half-life (e.g. T_half=1d, days_since_rebal=21
                        # -> decay = exp(-21) ~ 7.6e-10) should be allowed to fully
                        # decay - clipping it to 0.50 hides the genuine statistical
                        # conclusion that "this signal has fully decayed by day 21".
                        signal_df["alpha_score"] = signal_df["alpha_score"] * _decay_factor
                        signal_df["alpha_decay_factor"] = _decay_factor
                        _alpha_decay_calibrated = True
                        log_emit(log_cb, f"[AlphaDecay] T_half={_T_half_blended:.1f}d | t={_t_since_rebal:.0f}d | "
                                         f"decay={_decay_factor:.4f} | mom_w={_mom_weight:.2f} val_w={_val_weight:.2f} vol_w={_vol_weight:.2f}")
            except Exception as _ade:
                log_emit(log_cb, f"[AlphaDecay] skipped: {_ade}", exc_info=True)
                _alpha_decay_calibrated = False

        # ── Phase 2: ML Alpha injection (from the pipeline's Stage 2 ML model) ──
        # Blends the ML alpha scores (from AlphaEngine.predict()) into the
        # traditional alpha_score at a configurable weight (default 30%).
        # This is the integration point between Stage 2 (ML Alpha) and Stage 3 (Optimizer).
        _ml_scores = working_cfg.get("_ML_ALPHA_SCORES")
        if _ml_scores is None:
            _ml_scores = cfg.get("_ML_ALPHA_SCORES")

        if isinstance(_ml_scores, pd.Series):
            _ml_scores = _ml_scores.to_dict()

        if _ml_scores is None or len(_ml_scores) == 0:
            try:
                import os as _os
                import pickle as _pickle
                import inspect as _inspect
                _pname = str(working_cfg.get("PROFILE_NAME", ""))
                _pmode = str(working_cfg.get("PRESCREEN_MODE", ""))

                # ── Dynamic Regime Mixture-of-Experts (MoE) Router ─────────────
                _use_regime_moe = working_cfg.get("USE_DYNAMIC_REGIME_ENSEMBLE", True)
                if _use_regime_moe:
                    try:
                        from ml_alpha.regime_ensemble import RegimeEnsembleRouter, resolve_primary_archetype
                        _primary_arch = resolve_primary_archetype(_pname, _pmode)
                        _router = RegimeEnsembleRouter(
                            primary_archetype=_primary_arch,
                            use_dynamic_regime_tilt=bool(working_cfg.get("USE_DYNAMIC_REGIME_TILT", True)),
                            anchor_weight=float(working_cfg.get("MOE_ANCHOR_WEIGHT", 0.60)),
                        )
                        _rinfo = working_cfg.get("_REGIME_INFO", {})
                        _live_vix = working_cfg.get("_INDIA_VIX")
                        _bench_rets = benchmark_returns if "benchmark_returns" in locals() and benchmark_returns is not None else None
                        _ml_scores_series, _moe_diag = _router.predict_ensemble(
                            signal_df=signal_df,
                            regime_info=_rinfo,
                            benchmark_returns=_bench_rets,
                            india_vix=_live_vix,
                            log_cb=lambda msg: log_emit(log_cb, msg),
                        )
                        if len(_ml_scores_series) > 0 and _ml_scores_series.std() > 1e-7:
                            _ml_scores = _ml_scores_series.to_dict()
                            working_cfg["_REGIME_ENSEMBLE_DIAG"] = _moe_diag
                            working_cfg["_REGIME_ENSEMBLE_WEIGHTS"] = _moe_diag.get("active_weights", {})
                            if _moe_diag.get("attributions"):
                                working_cfg["_FACTOR_ATTRIBUTIONS"] = _moe_diag["attributions"]
                                working_cfg["_IPO_FACTOR_ATTRIBUTIONS"] = _moe_diag["attributions"]
                            if working_cfg.get("_ML_DSR") is None and _moe_diag.get("ensemble_dsr"):
                                working_cfg["_ML_DSR"] = float(_moe_diag["ensemble_dsr"])
                            if working_cfg.get("_ML_OOS_SHARPE_NUM") is None and _moe_diag.get("ensemble_oos_sharpe"):
                                working_cfg["_ML_OOS_SHARPE_NUM"] = float(_moe_diag["ensemble_oos_sharpe"])
                            log_emit(log_cb, f"[ML Alpha] ⚡ Dynamic Regime MoE active for {_primary_arch} ({len(_ml_scores)} predictions)")
                    except Exception as _moe_err:
                        log_emit(log_cb, f"[ML Alpha] Dynamic Regime MoE router notice: {_moe_err}", exc_info=True)

                    if any(k in _pname.lower() for k in ["prebreakout", "pre-breakout", "vol squeeze", "breakout"]) or _pmode in ["prebreakout", "breakout_early", "vol_squeeze"]:
                        _model_file = "ml_alpha_prebreakout.pkl"
                    elif _pmode == "ipo_multibagger" or "🦄" in _pname:
                        _model_file = "ml_alpha_ipo.pkl"
                    elif "Momentum" in _pname or "Max Alpha" in _pname or "🚀" in _pname or _pmode in ["institutional_alpha"]:
                        _model_file = "ml_alpha_momentum.pkl"
                    elif "Flow" in _pname or "Smart Money" in _pname or "🏦" in _pname or _pmode in ["early_entry", "accumulation"]:
                        _model_file = "ml_alpha_flow.pkl"
                    elif "Quality" in _pname or "GARP" in _pname or "🏛️" in _pname or _pmode in ["quality_compounders", "garp"]:
                        _model_file = "ml_alpha_quality.pkl"
                    elif "Preservation" in _pname or "All-Weather" in _pname or "Defense" in _pname or "🛡️" in _pname or "⚖️" in _pname or _pmode in ["pure_defensive", "balanced"]:
                        _model_file = "ml_alpha_defensive.pkl"
                    else:
                        _model_file = "ml_alpha_prebreakout.pkl"

                    _model_pkl = _os.path.join(_os.path.dirname(__file__), "models", _model_file)
                    if not _os.path.exists(_model_pkl):
                        _model_pkl = _os.path.join(_os.path.dirname(__file__), "artifacts", "saved_ml_alpha.pkl")
                        if not _os.path.exists(_model_pkl):
                            _model_pkl = _os.path.join(_os.path.dirname(__file__), "models", "ml_alpha_model.pkl")
                    if _os.path.exists(_model_pkl):
                        # AUDIT-FIX (Round 6, F6): pickle is code, not data — a
                        # poisoned/replaced models/ml_alpha_model.pkl executes
                        # arbitrary code in the optimizer process (which holds
                        # broker credentials and can place orders). The load is
                        # now gated on a SHA-256 sidecar manifest
                        # (ml_alpha_model.pkl.sha256, written by the trainer);
                        # a missing or mismatched manifest refuses the load.
                        _sum_path = _model_pkl + ".sha256"
                        _load_ok = False
                        if _os.path.exists(_sum_path):
                            try:
                                import hashlib as _hl
                                _expected = open(_sum_path, "r", encoding="utf-8").read().strip().lower()
                                _actual = _hl.sha256(open(_model_pkl, "rb").read()).hexdigest()
                                _load_ok = (_expected == _actual)
                                if not _load_ok:
                                    log_emit(log_cb, f"[ML Alpha] ⛔ {_os.path.basename(_model_pkl)} SHA-256 mismatch — REFUSING to unpickle (possible tampering)")
                            except Exception as _h:
                                log_emit(log_cb, f"[ML Alpha] ⛔ hash check failed ({_h}) — refusing to unpickle")
                        else:
                            log_emit(log_cb, f"[ML Alpha] ⛔ {_os.path.basename(_model_pkl)} has no .sha256 manifest — REFUSING to unpickle (write the manifest from the training pipeline or set ML_ALLOW_UNSIGNED_PICKLE=1 to override)")
                        if _load_ok or _os.environ.get("ML_ALLOW_UNSIGNED_PICKLE") == "1":
                            try:
                                import sys as _sys
                                from ml_alpha.universal_engine import UniversalAlphaEngine as _UAE
                                if "__main__" in _sys.modules and not hasattr(_sys.modules["__main__"], "UniversalAlphaEngine"):
                                    _sys.modules["__main__"].UniversalAlphaEngine = _UAE
                            except Exception:
                                pass
                            with open(_model_pkl, "rb") as _f:
                                _ml_obj = _pickle.load(_f)
                        else:
                            raise RuntimeError("unsigned/tampered ML pickle rejected")
                        if hasattr(_ml_obj, "predict"):
                            _sig = _inspect.signature(_ml_obj.predict)
                            _params = list(_sig.parameters.keys())
                            if len(_params) > 0 and _params[0] == "as_of":
                                _ml_scores = _ml_obj.predict()
                            else:
                                _req_feats = (
                                    getattr(_ml_obj, "feature_names", None)
                                    or getattr(_ml_obj, "_feature_names", None)
                                    or getattr(_ml_obj, "feature_names_in_", None)
                                )
                                _valid_feats = [c for c in _req_feats if c in signal_df.columns] if _req_feats else [c for c in signal_df.columns if c.startswith("z_")]
                                if _valid_feats:
                                    _X_ml = signal_df[_valid_feats].select_dtypes(include=[np.number]).fillna(0.0)
                                    if hasattr(_ml_obj, "predict_with_attribution"):
                                        _preds, _attrs = _ml_obj.predict_with_attribution(_X_ml)
                                        working_cfg["_IPO_FACTOR_ATTRIBUTIONS"] = _attrs.to_dict(orient="index")
                                        working_cfg["_FACTOR_ATTRIBUTIONS"] = _attrs.to_dict(orient="index")
                                    else:
                                        _preds = _ml_obj.predict(_X_ml)
                                    _ml_scores = dict(zip(signal_df.index, _preds))
                        if isinstance(_ml_scores, pd.Series):
                            _ml_scores = _ml_scores.to_dict()
                        elif not isinstance(_ml_scores, dict) and hasattr(_ml_scores, "__len__") and not isinstance(_ml_scores, str):
                            try:
                                _ml_scores = dict(zip(signal_df.index, _ml_scores))
                            except Exception:
                                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                                pass

                        # If _ml_scores is flat (std <= 1e-7, e.g. empty cached panels in saved model)
                        # compute real factors from close and predict via _ml_obj._fitted_model if available
                        _scores_vals = [float(v) for v in _ml_scores.values()] if isinstance(_ml_scores, dict) else []
                        if (not _scores_vals or (len(_scores_vals) > 1 and np.std(_scores_vals) <= 1e-7)) and hasattr(_ml_obj, "_fitted_model") and _ml_obj._fitted_model is not None:
                            try:
                                from ml_alpha.factors import (
                                    lowvol_3m, lowvol_6m, lowvol_12m, rsi_14, macd_hist,
                                    momentum_12_1, momentum_3_1, ret_skew_63, ma_distance_50, ma_distance_200
                                )
                                _feats = {}
                                for _tk in signal_df.index:
                                    if _tk in close.columns:
                                        _c = close[_tk].dropna()
                                        if len(_c) >= 20:
                                            _lv3 = lowvol_3m(_c); _lv6 = lowvol_6m(_c); _lv12 = lowvol_12m(_c)
                                            _r14 = rsi_14(_c); _mcd = macd_hist(_c)
                                            _m12 = momentum_12_1(_c); _m3 = momentum_3_1(_c)
                                            _sk63 = ret_skew_63(_c); _md50 = ma_distance_50(_c); _md200 = ma_distance_200(_c)
                                            _feats[_tk] = {
                                                "lowvol_3m": float(_lv3.iloc[-1]) if len(_lv3) > 0 else 0.0,
                                                "lowvol_6m": float(_lv6.iloc[-1]) if len(_lv6) > 0 else 0.0,
                                                "lowvol_12m": float(_lv12.iloc[-1]) if len(_lv12) > 0 else 0.0,
                                                "rsi_14": float(_r14.iloc[-1]) if len(_r14) > 0 else 50.0,
                                                "macd_hist": float(_mcd.iloc[-1]) if len(_mcd) > 0 else 0.0,
                                                "momentum_12_1": float(_m12.iloc[-1]) if len(_m12) > 0 else 0.0,
                                                "momentum_3_1": float(_m3.iloc[-1]) if len(_m3) > 0 else 0.0,
                                                "ret_skew_63": float(_sk63.iloc[-1]) if len(_sk63) > 0 else 0.0,
                                                "ma_distance_50": float(_md50.iloc[-1]) if len(_md50) > 0 else 0.0,
                                                "ma_distance_200": float(_md200.iloc[-1]) if len(_md200) > 0 else 0.0,
                                            }
                                if _feats:
                                    _X_live = pd.DataFrame.from_dict(_feats, orient="index")
                                    _live_preds = _ml_obj._fitted_model.predict(_X_live)
                                    if isinstance(_live_preds, (pd.Series, np.ndarray, list)) and len(_live_preds) == len(_X_live):
                                        _ml_scores = dict(zip(_X_live.index, _live_preds))
                                        log_emit(log_cb, f"[ML Alpha] Dynamic factor evaluation for {len(_ml_scores)} assets (std={np.std(list(_ml_scores.values())):.5f})")
                            except Exception as _fe_err:
                                log_emit(log_cb, f"[ML Alpha] Dynamic factor evaluation notice: {_fe_err}")

                        if _ml_scores is not None and isinstance(_ml_scores, dict) and len(_ml_scores) > 0:
                            log_emit(log_cb, f"[ML Alpha] ⚡ Auto-loaded trained model {_os.path.basename(_model_pkl)} ({len(_ml_scores)} predictions)")
                            # Extract measured validation stats from the authenticated model artifact
                            if working_cfg.get("_ML_DSR") is None:
                                _obj_dsr = getattr(_ml_obj, "dsr", None)
                                if _obj_dsr is not None and not (isinstance(_obj_dsr, float) and np.isnan(_obj_dsr)):
                                    working_cfg["_ML_DSR"] = float(_obj_dsr)
                            if working_cfg.get("_ML_OOS_SHARPE_NUM") is None:
                                _obj_oos = getattr(_ml_obj, "oos_sharpe", None)
                                if _obj_oos is not None and not (isinstance(_obj_oos, float) and np.isnan(_obj_oos)):
                                    working_cfg["_ML_OOS_SHARPE_NUM"] = float(_obj_oos)
                            # If scalar dsr is None but historical fold ICs are recorded, compute empirical DSR
                            if working_cfg.get("_ML_DSR") is None and hasattr(_ml_obj, "_historical_ics"):
                                _ics = getattr(_ml_obj, "_historical_ics", [])
                                if isinstance(_ics, (list, np.ndarray)) and len(_ics) >= 5:
                                    from ml_alpha.metrics import deflated_sharpe_ratio as _calc_dsr
                                    _m_ic = float(np.mean(_ics))
                                    _s_ic = float(np.std(_ics, ddof=1))
                                    if _s_ic > 1e-8:
                                        _obs_sr = (_m_ic / _s_ic) * np.sqrt(12)
                                        _derived_dsr = float(_calc_dsr(_obs_sr, n_trials=len(_ics)))
                                        working_cfg["_ML_DSR"] = _derived_dsr
                                        if working_cfg.get("_ML_OOS_SHARPE_NUM") is None:
                                            working_cfg["_ML_OOS_SHARPE_NUM"] = _obs_sr
            except Exception as _mle_load:
                log_emit(log_cb, f"[ML Alpha] Auto-load notice: {_mle_load}", exc_info=True)

        if isinstance(_ml_scores, pd.Series):
            _ml_scores = _ml_scores.to_dict()
        if _ml_scores is not None and isinstance(_ml_scores, dict) and len(_ml_scores) > 0:
            try:
                _norm_ml = {}
                for _mk, _mv in _ml_scores.items():
                    try:
                        _val = float(_mv)
                        _raw_k = str(_mk).replace(".NS", "").replace(".BO", "").strip().upper()
                        _norm_ml[str(_mk)] = _val
                        _norm_ml[_raw_k] = _val
                        _norm_ml[f"{_raw_k}.NS"] = _val
                    except Exception:
                        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                        pass
                _ml_series = pd.Series(_norm_ml, dtype=float)
                _ml_aligned = _ml_series.reindex(signal_df.index).fillna(0.0)
                _n_match = int((_ml_aligned != 0).sum())
                if _n_match > 0 and _ml_aligned.std() > 0:
                    _ml_z = (_ml_aligned - _ml_aligned.mean()) / _ml_aligned.std()

                    # Phase 9: Scale ML weight by validation quality (DSR).
                    # Claude found that DSR=0.0006 (no edge) was injected at full 30% weight,
                    # identical to a DSR=0.95 model. Now: weight scales linearly with DSR.
                    # DSR < floor (default 0.10) → weight=0 (refuse injection, no edge)
                    # DSR = 0.50 → weight=15% (half confidence)
                    # DSR >= 1.00 → weight=30% (full confidence)
                    _base_weight = float(working_cfg.get("ML_ALPHA_WEIGHT", 0.30))
                    # AUDIT-FIX (Round 20 — R20-8): unmeasured ML stats (None) were
                    # silently re-inflated to the confident defaults (DSR 0.95 /
                    # OOS Sharpe 1.85) — the exact "no-edge model injected at ~full
                    # weight" failure the Round-6 comments warn about, resurrected
                    # via the None path. None now means NOT MEASURED → honest log,
                    # zero weight, no injection. (The engine honestly declares
                    # dsr/oos_sharpe as None; the consumer must respect that.)
                    _ml_dsr_raw = working_cfg.get("_ML_DSR")
                    _ml_oos_raw = working_cfg.get("_ML_OOS_SHARPE_NUM")
                    _ml_stats_measured = (_ml_dsr_raw is not None and _ml_oos_raw is not None)
                    if not _ml_stats_measured:
                        log_emit(log_cb, "[ML Alpha] ML DSR/OOS-Sharpe not measured (None) — refusing injection at default confidence; ML alpha NOT blended")
                        signal_df["ml_alpha"] = _ml_aligned
                        signal_df["z_ml_alpha"] = _ml_z
                        _ml_weight = 0.0
                        _ml_dsr = _ml_dsr_raw if _ml_dsr_raw is not None else float("nan")
                        _ml_oos = _ml_oos_raw if _ml_oos_raw is not None else float("nan")
                    else:
                        _ml_dsr = float(_ml_dsr_raw)
                        _ml_oos = float(_ml_oos_raw)
                        # AUDIT-FIX (Round 6, E-P1-2): DSR 0.0 must stay 0.0, not be re-inflated to the 0.95 default
                        _dsr_floor = float(working_cfg.get("ML_DSR_FLOOR", 0.10))
                        # Implement the documented linear scaling:
                        #   DSR < floor → weight = 0 (refuse injection, no edge)
                        #   floor ≤ DSR ≤ 1 → weight scales linearly to base
                        _ml_weight = _base_weight * float(np.clip((_ml_dsr - _dsr_floor) / max(1.0 - _dsr_floor, 1e-9), 0.0, 1.0))
                        if _ml_weight <= 1e-6:
                            log_emit(log_cb, f"[ML Alpha] DSR={_ml_dsr:.4f} < floor {_dsr_floor:.2f} — no validated edge, ML alpha NOT injected")
                            # fall through WITHOUT blending ML into alpha_score
                            signal_df["ml_alpha"] = _ml_aligned
                            signal_df["z_ml_alpha"] = _ml_z
                        else:
                            signal_df["ml_alpha"] = _ml_aligned
                            signal_df["z_ml_alpha"] = _ml_z
                            _std_raw_alpha = (signal_df["alpha_score"] - signal_df["alpha_score"].mean()) / (signal_df["alpha_score"].std() + 1e-9)
                            signal_df["alpha_score"] = (
                                _std_raw_alpha * (1.0 - _ml_weight) +
                                _ml_z * _ml_weight
                            )

                            # ── Sector-Neutral Cross-Sectional Ranking ─────────
                            if working_cfg.get("USE_SECTOR_NEUTRAL_RANKING", True) and sectors:
                                from ml_alpha.regime_ensemble import apply_sector_neutral_ranking
                                _sec_lambda = float(working_cfg.get("SECTOR_NEUTRAL_LAMBDA", 0.50))
                                signal_df["alpha_score"] = apply_sector_neutral_ranking(
                                    signal_df=signal_df,
                                    alpha_col="alpha_score",
                                    sectors=sectors,
                                    lambda_sector=_sec_lambda,
                                    log_cb=lambda msg: log_emit(log_cb, msg),
                                )
                    if _ml_stats_measured:
                        log_emit(log_cb, f"[ML Alpha] ML alpha decision | "
                                  f"matched={_n_match}/{len(signal_df)} | "
                                  f"weight={_ml_weight:.0%} (DSR-scaled) | "
                                  f"OOS Sharpe={_ml_oos:+.2f} | DSR={_ml_dsr:.4f}")

                elif _n_match == 0:
                    log_emit(log_cb, f"[ML Alpha] No overlap between ML scores and optimizer universe "
                              f"(matched=0/{len(signal_df)}) — using traditional alpha only")
                else:
                    log_emit(log_cb, f"[ML Alpha] ML alpha scores have zero variance across matched universe "
                              f"(matched={_n_match}/{len(signal_df)}, std=0.0) — cannot standardize; using traditional alpha only")
            except Exception as _mle:
                log_emit(log_cb, f"[ML Alpha] Injection skipped: {_mle}", exc_info=True)
        else:
            log_emit(log_cb, "[ML Alpha] No ML alpha scores provided — using traditional alpha only")

        # ── R35: Triple-Barrier Meta-Labeling Gate (🦄 High-Growth IPO) ─────
        # The institutional "model-on-model" layer (López de Prado meta-labeling):
        # the composite factor score decides CANDIDACY; a runtime-trained,
        # purged + embargoed, Platt-calibrated logistic estimates P(the primary
        # signal is right) from strictly trailing triple-barrier outcomes and
        # re-weights conviction multiplicatively. Mean-1 by construction — it
        # can never inflate or deflate the book, only re-rank conviction within
        # it (clip [0.5, 2.0]). Refuses to gate (identity + honest log) when
        # the trailing panel is too small or degenerate. Config-gated,
        # default-on ONLY for the 🦄 profile (USE_META_LABELING).
        if working_cfg.get("USE_META_LABELING", False):
            try:
                from math_engine.ipo_multibagger_math import (
                    build_meta_event_frame, MetaLabelGate, confidence_multiplier,
                )
                _r35_ml_h = int(working_cfg.get("META_LABEL_HORIZON_DAYS", 63))
                _r35_ml_tp = float(working_cfg.get("META_LABEL_TP_PCT", 0.25))
                _r35_ml_sl = float(working_cfg.get("META_LABEL_SL_PCT", 0.20))
                _r35_bench_close = (1.0 + benchmark_returns).cumprod()
                _r35_ev = build_meta_event_frame(
                    close, volume, benchmark_close=_r35_bench_close,
                    horizon=_r35_ml_h, tp_pct=_r35_ml_tp, sl_pct=_r35_ml_sl,
                    stride=int(working_cfg.get("META_LABEL_STRIDE_DAYS", 21)),
                    embargo=int(working_cfg.get("META_LABEL_EMBARGO_DAYS", 5)),
                    max_events_per_ticker=int(working_cfg.get("META_LABEL_MAX_EVENTS_PER_TICKER", 12)),
                )
                if len(_r35_ev) > 0:
                    _r35_base = float(_r35_ev["label"].mean())
                    working_cfg["_IPO_EMPIRICAL_BASE_RATE"] = _r35_base
                    log_emit(log_cb, f"[MetaLabel] Empirical base rate from {len(_r35_ev)} purged trailing "
                                     f"triple-barrier events (TP={_r35_ml_tp:.0%}/SL={_r35_ml_sl:.0%}/H={_r35_ml_h}d): "
                                     f"{_r35_base:.2%} — measured, never invented")
                _r35_gate = MetaLabelGate(
                    min_train_events=int(working_cfg.get("META_LABEL_MIN_TRAIN_EVENTS", 60)),
                    val_frac=float(working_cfg.get("META_LABEL_VAL_FRAC", 0.30)),
                )
                if _r35_gate.fit(_r35_ev):
                    _r35_pf = _r35_gate.build_prediction_frame(close, volume, _r35_bench_close,
                                                               tickers=signal_df.index)
                    _r35_probs = _r35_gate.predict_proba(_r35_pf)
                    if _r35_probs is not None and len(_r35_probs) >= 5:
                        _r35_mult = confidence_multiplier(
                            _r35_probs,
                            kappa=float(working_cfg.get("META_LABEL_KAPPA", 1.0)),
                            lo=float(working_cfg.get("META_LABEL_MULT_LO", 0.5)),
                            hi=float(working_cfg.get("META_LABEL_MULT_HI", 2.0)),
                        ).reindex(signal_df.index).fillna(1.0)

                        # Sovereign Upgrade: Regime-conditional conviction scaling
                        _rinfo = working_cfg.get("_REGIME_INFO", {}) or {}
                        _regime_name = str(_rinfo.get("Regime", "")).lower()
                        _regime_scaler = 1.0
                        if any(term in _regime_name for term in ["bear", "stress", "turbulent", "defensive", "distribution"]):
                            _regime_scaler = 0.50
                            log_emit(log_cb, f"[RegimeGate] Defensive/Stress regime ('{_rinfo.get('Regime')}') — scaling IPO conviction by 0.50x to protect against false breakouts")
                        elif any(term in _regime_name for term in ["bull", "trend", "strength", "risk-on"]):
                            _regime_scaler = 1.15
                            log_emit(log_cb, f"[RegimeGate] Bull/Trending regime ('{_rinfo.get('Regime')}') — boosting IPO conviction by 1.15x")

                        # Fast VIX Flash Crash Gate (Day-1 Shock Protection)
                        _live_vix = working_cfg.get("_INDIA_VIX", _india_vix)
                        if _live_vix is None or (isinstance(_live_vix, float) and np.isnan(_live_vix)):
                            try:
                                _live_vix = fetch_india_vix(log_cb=None)
                                if _live_vix is not None and not np.isnan(_live_vix):
                                    working_cfg["_INDIA_VIX"] = float(_live_vix)
                            except Exception:
                                pass

                        if _live_vix is not None and not (isinstance(_live_vix, float) and np.isnan(_live_vix)) and float(_live_vix) >= 22.0:
                            _vix_scaler = 0.70 if float(_live_vix) < 26.0 else 0.50
                            _regime_scaler *= _vix_scaler
                            log_emit(log_cb, f"[VIXShockGate] Elevated India VIX ({float(_live_vix):.1f} >= 22.0) — applying fast {_vix_scaler:.2f}x sizing defense")

                        signal_df["meta_label_p"] = _r35_probs.reindex(signal_df.index).astype(float)
                        signal_df["meta_label_mult"] = _r35_mult * _regime_scaler
                        signal_df["alpha_score"] = signal_df["alpha_score"] * (_r35_mult * _regime_scaler)
                        _r35_diag = _r35_gate.get_diagnostics()
                        log_emit(log_cb, f"[MetaLabel] Gate ACTIVE — calibrated P(primary-right) for "
                                         f"{len(_r35_probs)}/{len(signal_df)} names | base_rate(trained)="
                                         f"{_r35_diag.get('train_base_rate', float('nan')):.2%} | "
                                         f"val_auc={_r35_diag.get('val_auc')} | mult clipped to "
                                         f"[{working_cfg.get('META_LABEL_MULT_LO', 0.5)}, {working_cfg.get('META_LABEL_MULT_HI', 2.0)}] "
                                         f"(mean-1, book-neutral by construction)")
                    else:
                        log_emit(log_cb, "[MetaLabel] Trained but insufficient scored names (<5) — "
                                         "identity gate, alpha unchanged (honest skip)")
                else:
                    log_emit(log_cb, f"[MetaLabel] REFUSED to gate: {_r35_gate.get_diagnostics().get('status')} — "
                                     f"alpha unchanged (identity). No fabricated probabilities.")
                working_cfg["_META_LABEL_DIAG"] = _r35_gate.get_diagnostics()
            except Exception as _r35_mle:
                log_emit(log_cb, f"[MetaLabel] skipped: {_r35_mle}", exc_info=True)

        # Guard: filter out stocks with exact 0.0 alpha_score or NaN to prevent uninformative zero-score selection
        signal_df["alpha_score"] = signal_df["alpha_score"].fillna(0.0)
        _zero_alpha_mask = (signal_df["alpha_score"].abs() < 1e-9)
        if _zero_alpha_mask.sum() > 0 and (len(signal_df) - _zero_alpha_mask.sum()) >= 5:
            signal_df = signal_df[~_zero_alpha_mask].copy()
            log_emit(log_cb, f"[ZeroScoreGuard] Pruned {_zero_alpha_mask.sum()} stocks with exact zero composite alpha score.")

        # Synchronize QUBO linear alpha terms with final neutralized/ML-injected alpha_score
        # AUDIT-FIX (defect #1): the prior code OVERWROTE the entire diagonal here,
        # dropping VOL_PENALTY / beta_cost / turnover_cost / chart_failed_breakout
        # _risk_penalty / Barra_conc_cost, and additionally mixed pre-prune _N
        # scaling (used in build_qubo) with post-prune _n_universe scaling. The
        # correct operation is a DELTA update: subtract the original alpha term
        # and cardinality term (which were stored on cfg by build_qubo), then add
        # the refreshed alpha and cardinality terms computed against the
        # post-prune universe size. All other penalty terms on the diagonal are
        # preserved exactly.
        _alpha_val = float(working_cfg.get("ALPHA", 1.8))
        _gamma_card_new = float(working_cfg.get("GAMMA_CARDINALITY", working_cfg.get("GAMMA", 22.0)))
        _k_target_new = int(working_cfg.get("K_STOCKS", 8))
        _n_universe = max(len(signal_df), 1)

        _prior_alpha_scores = working_cfg.get("_QUBO_BUILD_ALPHA_SCORES", {})
        _prior_alpha_val = float(working_cfg.get("_QUBO_BUILD_ALPHA", _alpha_val))
        _prior_N = max(float(working_cfg.get("_QUBO_BUILD_N", _n_universe)), 1.0)
        _prior_gamma_card = float(working_cfg.get("_QUBO_BUILD_GAMMA_CARD", _gamma_card_new))
        _prior_k = int(working_cfg.get("_QUBO_BUILD_K_STOCKS", _k_target_new))

        _delta_alpha_count = 0
        for _s in signal_df.index:
            if (_s, _s) in q:
                _old_alpha_score = float(_prior_alpha_scores.get(_s, 0.0))
                _new_alpha_score = float(signal_df.loc[_s, "alpha_score"])
                # Old contribution per stock (alpha + cardinality) at build time
                _old_term = (-_prior_alpha_val * _old_alpha_score + _prior_gamma_card * (1 - 2 * _prior_k)) / _prior_N
                # New contribution (alpha + cardinality) at post-prune universe size
                _new_term = (-_alpha_val * _new_alpha_score + _gamma_card_new * (1 - 2 * _k_target_new)) / _n_universe
                # Delta preserves every other penalty term on the diagonal
                q[(_s, _s)] = q[(_s, _s)] - _old_term + _new_term
                _delta_alpha_count += 1
        log_emit(log_cb, f"[QUBO] Delta-updated {_delta_alpha_count} diagonal alpha+cardinality terms after ML injection (preserved VOL_PENALTY/beta/turnover/risk_penalty/Barra).")

        # ── IS-Cost Net-Alpha Haircut (Almgren-Chriss → QUBO) ─────────────────────
        # Subtracts the expected implementation shortfall (in alpha units) from
        # every stock's QUBO diagonal before the SA solve. Stocks where the trade
        # cost exceeds the gross alpha get their QUBO term flipped positive
        # (penalized), preventing the solver from buying them at all.
        # Formula: net_alpha_i = gross_alpha_i - IS_cost_bps_i / 10000
        # IS_cost_bps_i = SIGMA_i * sqrt(trade_size_frac_i) * IMPACT_FACTOR
        # where SIGMA_i = 21d realized vol, trade_size_frac_i = |w_target - w_prev|
        if working_cfg.get("USE_IS_COST_ALPHA_HAIRCUT", True):
            try:
                _impact_factor = float(working_cfg.get("IS_IMPACT_FACTOR", 1.5))  # empirical NSE market impact
                _port_val_inr  = float(working_cfg.get("PORTFOLIO_VALUE_INR", 1_000_000))
                _prev_w: dict  = {t: 1.0 / len(prev_holdings) for t in prev_holdings} if prev_holdings else {}
                _is_log        = []
                for _s in list(signal_df.index):
                    try:
                        # Realized vol (21d annualized) — already z-scored in signal_df; use raw ann_vol
                        _sigma_d = float(signal_df.loc[_s, "ann_vol"]) / np.sqrt(252) if "ann_vol" in signal_df.columns else 0.015
                        # Trade size as fraction of portfolio value (absolute weight change)
                        _w_prev_s = float(_prev_w.get(_s, 0.0))
                        _w_tgt_s  = 1.0 / max(int(working_cfg.get("K_STOCKS", 8)), 1)  # equal-weight target approx
                        _delta_w  = abs(_w_tgt_s - _w_prev_s)
                        # IS cost in fractional return units (not bps) using square-root market impact
                        _is_cost  = _impact_factor * _sigma_d * float(np.sqrt(max(_delta_w, 0.0)))
                        # Subtract from QUBO diagonal (diagonal is -alpha * gross_score)
                        if (_s, _s) in q:
                            # q diagonal is already negative for high-alpha stocks; adding IS cost reduces attractiveness
                            q[(_s, _s)] = q[(_s, _s)] + _is_cost / max(len(signal_df), 1)
                        # Store net IS cost for export diagnostics
                        signal_df.loc[_s, "is_cost_est"] = round(_is_cost * 10_000, 2)  # in bps for display
                        if _is_cost * 10_000 > 5.0:  # log only when IS cost > 5 bps
                            _is_log.append(f"{_s}={_is_cost*10000:.1f}bps")
                    except Exception:
                        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                        pass
                if _is_log:
                    log_emit(log_cb, f"[IS-NetAlpha] Applied IS-cost haircut to {len(_is_log)} tickers (>5bps): {', '.join(_is_log[:10])}{'...' if len(_is_log)>10 else ''}")
                else:
                    log_emit(log_cb, "[IS-NetAlpha] IS-cost haircut applied — all stocks < 5bps impact (low turnover or new portfolio)")
            except Exception as _ise:
                log_emit(log_cb, f"[IS-NetAlpha] skipped: {_ise}", exc_info=True)

        # v16: SA ensemble (parallel runs, warm start from prev portfolio)
        # v16: SA ensemble (parallel runs) + QUBO warm start from prev portfolio
        _warm = [t for t in prev_holdings if t in signal_df.index] if working_cfg.get("USE_QUBO_WARM_START", True) else []
        if int(working_cfg.get("SA_ENSEMBLE_RUNS", 5)) > 1:
            selected, energy, solver_source = solve_qubo_ensemble(
                q, signal_df, sectors, working_cfg, warm_start=_warm, log_cb=log_cb)
        else:
            selected, energy, solver_source = solve_qubo(
                q, signal_df, sectors, working_cfg, log_cb=log_cb)

        # ranked and _chart_cols_to_merge must be defined unconditionally —
        # both ensemble AND single-run paths reach the portfolio_df build below.
        ranked = sorted(selected, key=lambda s: float(signal_df.loc[s, "alpha_score"]), reverse=True)
        _chart_cols_to_merge = [
            "chart_pattern_cohesion", "chart_pattern_novelty", "chart_pattern_margin",
            "chart_pattern_cluster", "z_chart_pattern", "z_chart_novelty", "z_chart_margin",
            "chart_pattern_dispersion", "chart_cluster_agreement",
            "chart_calibrated_prob", "chart_failed_breakout_risk", "chart_regime_fit",
        ]
        _chart_cols_to_merge.extend([c for c in signal_df.columns if c.startswith(
            ("z_chart_pattern_", "z_chart_novelty_", "z_chart_margin_", "chart_pattern_cluster_"))])


        _prev_w_dict = {}
        if prev_holdings:
            _prev_w_dict = {ticker: 1.0 / len(prev_holdings) for ticker in prev_holdings}
        weights = apply_weight_constraints(
            calculate_qubo_aware_weights(
                selected,
                signal_df,
                q,
                working_cfg,
                clean_returns=clean_returns,
                prev_weights=_prev_w_dict,
                log_cb=log_cb
            ),
            working_cfg
        )

        # v15: Black-Litterman weight blending (optional, off by default)
        weight_override_applied = False
        if working_cfg.get("USE_BLACK_LITTERMAN", False) and selected:
            _ret_sel = None
            try:
                from_ret = clean_returns[selected] if all(s in clean_returns.columns for s in selected) else None
                if from_ret is not None and not from_ret.empty:
                    _ret_sel = from_ret
            except Exception as _e:  # safe: optional corp-actions filter is non-fatal
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception in %s", "Exception", exc_info=True)  # noqa: E501
                pass  # intentional — see comment above
            if _ret_sel is not None:
                weights = black_litterman_weights(selected, signal_df, _ret_sel, cfg=working_cfg)
                log_emit(log_cb, "[Black-Litterman] BL posterior weights applied")
                weight_override_applied = True

        # v15: Fractional Kelly sizing (optional, off by default)
        if working_cfg.get("USE_KELLY_SIZING", False) and selected:
            weights = calculate_kelly_weights(
                selected, signal_df,
                float(working_cfg.get("KELLY_FRACTION", 0.25))
            )
            log_emit(log_cb, f"[Kelly] Quarter-Kelly weights applied (f={working_cfg.get('KELLY_FRACTION',0.25)})")
            weight_override_applied = True

        # v17: Maximum Diversification Portfolio (optional)
        if working_cfg.get("USE_MDP", False) and selected and len(selected) >= 3:
            _mdp_w = compute_mdp_weights(selected, clean_returns)
            if _mdp_w:
                weights = apply_weight_constraints(_mdp_w, working_cfg)
                log_emit(log_cb, "[MDP] Maximum Diversification Portfolio weights applied")
                weight_override_applied = True

        # v16: Hierarchical Risk Parity (optional, overrides all weight schemes)
        # AUDIT-FIX (defect #2): previously USE_HRP defaulted to True, silently
        # discarding the Wasserstein DRO weights just constructed via CVXPY. The
        # default is now False; when HRP is explicitly enabled we log that the
        # DRO weights have been overridden so the operator understands which
        # allocator is in effect.
        if working_cfg.get("USE_HRP", False) and selected and len(selected) >= 3:  # default False matches DEFAULT_CFG
            _hrp_w = hrp_weights(selected, clean_returns, working_cfg)
            if _hrp_w:
                weights = apply_weight_constraints(_hrp_w, working_cfg)
                log_emit(log_cb, f"[HRP] Hierarchical Risk Parity weights applied (overrode DRO/MVO allocator; USE_HRP=True).")
                weight_override_applied = True
        # WIRING: Tail-risk optimization (CVaR/CDaR/Omega/Robust)
        _tail_method = working_cfg.get("RISK_OPTIMIZATION_METHOD", "").lower()
        if _tail_method in ("cvar", "cdar", "omega", "robust") and selected and len(selected) >= 3:
            try:
                from math_engine.tail_risk import optimize_tail_risk
                _ret_sel = clean_returns[selected] if all(s in clean_returns.columns for s in selected) else None
                if _ret_sel is not None and not _ret_sel.empty:
                    _tail_result = optimize_tail_risk(_ret_sel, method=_tail_method, alpha=0.95, max_weight=float(working_cfg.get("MAX_WEIGHT", 0.30)), min_weight=float(working_cfg.get("MIN_WEIGHT", 0.0)))
                    _tail_weights = _tail_result.get("weights", np.ones(len(selected)) / len(selected))
                    weights = {t: float(w) for t, w in zip(selected, _tail_weights)}
                    log_emit(log_cb, f"[TailRisk] {_tail_method.upper()} optimization applied")
                    weight_override_applied = True
            except Exception as _tr_e:
                log_emit(log_cb, f"[TailRisk] {_tail_method} skipped: {_tr_e}", exc_info=True)

        # Math Engine: JAX Vector Parallel Optimizer Integration
        if working_cfg.get("USE_JAX_OPTIMIZER", False) and selected and len(selected) >= 3:
            try:
                from math_engine.jax_optimizer import JaxPortfolioOptimizer
                _jax_opt = JaxPortfolioOptimizer()
                _ret_sel = clean_returns[selected] if all(s in clean_returns.columns for s in selected) else None
                if _ret_sel is not None and not _ret_sel.empty:
                    _mu_j = _ret_sel.mean().to_numpy()
                    _cov_j = _ret_sel.cov().to_numpy()
                    _jax_w = _jax_opt.optimize_batch_weights(_mu_j, _cov_j, n_batches=32)
                    _mean_jax_w = _jax_w.mean(axis=0)
                    weights = {t: float(w) for t, w in zip(selected, _mean_jax_w)}
                    log_emit(log_cb, f"[JAX Optimizer] Parallel GPU/vector optimization applied across 32 batches")
                    weight_override_applied = True
            except Exception as _jaxe:
                log_emit(log_cb, f"[JAX Optimizer] Notice: {_jaxe}", exc_info=True)

        # Math Engine: Expected Shortfall CVaR Risk Optimizer Integration
        if working_cfg.get("USE_CVAR_OPTIMIZATION", False) and selected and len(selected) >= 3:
            try:
                from math_engine.expected_shortfall import ExpectedShortfallOptimizer
                _cvar_opt = ExpectedShortfallOptimizer()
                _ret_sel = clean_returns[selected] if all(s in clean_returns.columns for s in selected) else None
                if _ret_sel is not None and not _ret_sel.empty:
                    # AUDIT-FIX (Round 6, A1-P2-3): the class has no
                    # `optimize_cvar` method (only the static
                    # solve_es_portfolio, whose required positional `mu` was
                    # also never passed) — every call raised AttributeError,
                    # was swallowed as a "notice", and this opt-in feature
                    # never ran. Call the real API with a proper annualized
                    # expected-return vector and an ES ceiling.
                    _mu_sel = (_ret_sel.mean().to_numpy() * 252.0)
                    _es_w = _cvar_opt.solve_es_portfolio(
                        _ret_sel.to_numpy(),
                        _mu_sel,
                        alpha=float(working_cfg.get("CVAR_BETA", 0.95)),
                        max_es=float(working_cfg.get("CVAR_MAX_ES", 1.0)),
                        min_weight=0.0,
                        max_weight=float(working_cfg.get("MAX_WEIGHT", 0.30)),
                    )
                    weights = {t: float(w) for t, w in zip(selected, _es_w)}
                    log_emit(log_cb, f"[CVaR Optimizer] Expected Shortfall tail risk minimization applied")
                    weight_override_applied = True
            except Exception as _es_err:
                log_emit(log_cb, f"[CVaR Optimizer] Notice: {_es_err}", exc_info=True)

        # A2 WIRING: Rockafellar-Uryasev CVaR LP minimization (Tier-A institutional upgrade)
        # Activated by cfg["USE_CVAR_LP"] = True.  Uses cvxpy/ECOS LP (free); falls back to
        # scipy.linprog; last resort = equal weights.  Applied AFTER HRP/MDP/BL so it respects
        # the already-screened universe. SEBI / weight constraints applied in Phase 3.1 below.
        if working_cfg.get("USE_CVAR_LP", False) and selected and len(selected) >= 3:
            try:
                from math_engine.cvar_optim import minimize_cvar_portfolio, cvar_risk_metrics
                _ret_sel_cvar = clean_returns[selected] if all(s in clean_returns.columns for s in selected) else None
                if _ret_sel_cvar is not None and not _ret_sel_cvar.empty:
                    _cvar_w_arr = minimize_cvar_portfolio(
                        _ret_sel_cvar,
                        beta=float(working_cfg.get("CVAR_BETA", 0.95)),
                        max_w=float(working_cfg.get("CVAR_MAX_WEIGHT", working_cfg.get("MAX_WEIGHT", 0.15))),
                        min_w=float(working_cfg.get("CVAR_MIN_WEIGHT", 0.0)),
                        cfg=working_cfg,
                    )
                    weights = {t: float(w) for t, w in zip(selected, _cvar_w_arr)}
                    _cvar_diag = cvar_risk_metrics(
                        _cvar_w_arr, _ret_sel_cvar,
                        beta=float(working_cfg.get("CVAR_BETA", 0.95)),
                    )
                    log_emit(log_cb,
                        f"[CVaR-LP] Rockafellar-Uryasev CVaR@{int(float(working_cfg.get('CVAR_BETA',0.95))*100)}% "
                        f"minimization applied — portfolio CVaR={_cvar_diag.get('portfolio_cvar_pct','N/A')}% "
                        f"VaR={_cvar_diag.get('portfolio_var_pct','N/A')}% "
                        f"({_cvar_diag.get('n_scenarios','?')} scenarios × {len(selected)} assets)"
                    )
                    weight_override_applied = True
            except Exception as _cvar_lp_err:
                log_emit(log_cb, f"[CVaR-LP] Skipped: {_cvar_lp_err}", exc_info=True)

        # WIRING: Multi-period optimization (MPO)
        if working_cfg.get("USE_MPO", False) and selected and len(selected) >= 3:
            try:
                from math_engine.multi_period import optimize_multi_period
                _ret_sel = clean_returns[selected] if all(s in clean_returns.columns for s in selected) else None
                if _ret_sel is not None and not _ret_sel.empty:
                    _mpo_result = optimize_multi_period(_ret_sel.mean().to_numpy(), _ret_sel.cov().to_numpy(), np.array([weights.get(t, 0) for t in selected]), n_periods=int(working_cfg.get("MPO_PERIODS", 4)), risk_aversion=float(working_cfg.get("MPO_RISK_AVERSION", 2.5)), cost_bps=float(working_cfg.get("BACKTEST_FEE_BPS", 15.0)), max_weight=float(working_cfg.get("MAX_WEIGHT", 0.30)))
                    weights = {t: float(w) for t, w in zip(selected, _mpo_result["first_period_weights"])}
                    log_emit(log_cb, f"[MPO] Multi-period optimization applied")
                    weight_override_applied = True
            except Exception as _mpo_e:
                log_emit(log_cb, f"[MPO] skipped: {_mpo_e}", exc_info=True)
        elif not weight_override_applied and working_cfg.get("FORCE_USE_ALPHA_WEIGHTS", False) and selected and signal_df is not None:
            # v17.3: softmax alpha-proportional weights (opt-in override only, preserves DRO QUBO weights)
            _aw = compute_alpha_proportional_weights(selected, signal_df, working_cfg)
            if _aw:
                weights = apply_weight_constraints(_aw, working_cfg)
                log_emit(log_cb, f"[AlphaWeights] Softmax alpha-proportional weights applied")

        # Phase 3.1: SEBI category constraints MUST be applied LAST (after HRP/MDP/BL/Kelly).
        # Previously SEBI was applied at line 5132 BEFORE HRP/MDP, so HRP/MDP silently
        # overwrote the SEBI-capped weights — regulatory compliance was lost on every
        # live run. Now SEBI + individual caps are enforced as the FINAL step.
        weights = apply_sebi_constraints(weights, prescreen_df, working_cfg, log_cb=log_cb)
        weights = apply_weight_constraints(weights, working_cfg)  # re-enforce individual caps
        log_emit(log_cb, "[Phase3] SEBI + weight constraints applied as FINAL step (post-HRP/MDP)")

        # ── Round 8 — R8-1: Wasserstein DRO-CVaR post-SEBI weight refinement ────────────
        # Mohajerin Esfahani & Kuhn (2018): distributional robustness within
        # Wasserstein ball of radius ε around the empirical return distribution.
        # Activated by cfg["USE_DRO_CVAR"] = True (default: False — opt-in only).
        # Applied AFTER SEBI constraints so it cannot violate regulatory caps.
        # On any failure the existing weights are silently preserved.
        if working_cfg.get("USE_DRO_CVAR", False) and selected and len(selected) >= 3:
            try:
                from optimizer_risk import apply_dro_cvar_constraint as _dro_fn
                import numpy as _dro_np
                _dro_tickers = [t for t in selected if t in weights and t != "CASH"]
                _dro_w_arr = _dro_np.array([weights[t] for t in _dro_tickers], dtype=float)
                _dro_ret_sel = (
                    clean_returns[_dro_tickers].fillna(0.0).values
                    if clean_returns is not None and all(t in clean_returns.columns for t in _dro_tickers)
                    else None
                )
                if _dro_ret_sel is not None and _dro_ret_sel.shape[0] >= 20:
                    _dro_epsilon = float(working_cfg.get("DRO_EPSILON", 0.05))
                    _dro_alpha   = float(working_cfg.get("DRO_ALPHA",   0.05))
                    _dro_lam     = float(working_cfg.get("DRO_LAMBDA",  1.0))
                    _dro_result = _dro_fn(
                        returns=_dro_ret_sel,
                        current_weights=_dro_w_arr,
                        epsilon=_dro_epsilon,
                        alpha=_dro_alpha,
                        lam=_dro_lam,
                        log_cb=log_cb,
                    )
                    if _dro_result.get("source") == "dro_cvar":
                        _dro_new_w = _dro_result["weights"]
                        for _i, _t in enumerate(_dro_tickers):
                            weights[_t] = float(_dro_new_w[_i])
                        # Re-enforce caps after DRO reweighting
                        weights = apply_weight_constraints(weights, working_cfg)
                        log_emit(log_cb,
                            f"[DRO-CVaR] Wasserstein robust weights applied — "
                            f"ε={_dro_epsilon:.3f}, α={_dro_alpha:.2f}, "
                            f"worst-case CVaR={_dro_result.get('worst_case_cvar', float('nan')):.4f}"
                        )
            except Exception as _dro_err:
                log_emit(log_cb, f"[DRO-CVaR] Skipped (weights unchanged): {_dro_err}", exc_info=True)

        # Scale weights in bear market when residual cash should be preserved (only if CASH was not already optimized as a true asset)
        if "CASH" not in weights:
            k_original = working_cfg.get("K_STOCKS_ORIGINAL")
            # ── Profile-aware Regime-conditional cash overlay resolution ────────────
            # Defensive/Balanced/Smart Money profiles de-risk into Cash during Sideways/Bear regimes,
            # while Alpha Concentrated / Momentum profiles stay 100% invested to preserve profile identity.
            #
            # AUDIT-FIX (defect #P1-9): the prior implementation read the wrong
            # regime key ("Bear_Prob") and omitted "defensive" from the bear
            # branch — so when the HMM emitted "Defensive" (treated as bearish
            # by the canonical regime check at optimizer.py:4701), the cash
            # overlay fell through to the Bull branch and set cash=0% while
            # the final summary still reported "Regime: Bear". The audit
            # captured this as a self-contradiction: overlay said "Bull
            # (P_bear=0.00)" while the summary said "Bear".
            _r_lbl = str(regime_info.get("Regime", "Sideways") if regime_info else "Sideways").lower()
            p_bear = float(regime_info.get("P_Bear", regime_info.get("Bear_Prob", 0.0)) if regime_info else 0.0)
            _allow_cash_derisk = working_cfg.get("ALLOW_REGIME_CASH_DERISK", True)

            # MoE Router Diagnosis & India VIX integration
            _moe_diag = working_cfg.get("_REGIME_ENSEMBLE_DIAG", {})
            _moe_regime = str(_moe_diag.get("macro_regime", "")).lower()
            _live_vix = float(working_cfg.get("_INDIA_VIX", 0.0) or 0.0)

            if not _allow_cash_derisk:
                _resolved_cash_frac = 0.00
            elif "crash" in _moe_regime or "stress" in _moe_regime or _live_vix >= 22.0 or "bear" in _r_lbl or "stress" in _r_lbl or "defensive" in _r_lbl or p_bear > 0.40:
                _default_cash = max(0.35, p_bear, 0.50 if _live_vix >= 24.0 else 0.35)
                _resolved_cash_frac = float(working_cfg.get("BEAR_RESIDUAL_CASH_FRACTION_BEAR", _default_cash))
            elif "sideways" in _r_lbl or "chop" in _moe_regime or "neutral" in _r_lbl:
                _resolved_cash_frac = float(working_cfg.get("BEAR_RESIDUAL_CASH_FRACTION_SIDEWAYS", 0.20))
            else:  # Bull
                _resolved_cash_frac = float(working_cfg.get("BEAR_RESIDUAL_CASH_FRACTION_BULL", 0.00))

            working_cfg["BEAR_RESIDUAL_CASH_FRACTION_ACTIVE"] = _resolved_cash_frac
            # AUDIT-FIX (Round 21 — R21-5 & R21-3): resolve active profile name & canonical market regime
            _prof_disp = working_cfg.get('PROFILE_NAME') or working_cfg.get('FACTOR_MODEL') or 'Default'
            _regime_disp = working_cfg.get('_CANONICAL_MARKET_REGIME') or regime_info.get('Regime','Sideways')
            log_emit(log_cb, f"[ProfileCashOverlay] Profile={_prof_disp} | Market Regime={_regime_disp} (HMM P_bear={p_bear:.2f}) → cash reserve={_resolved_cash_frac*100:.0f}%")
            bear_cash_fraction_active = float(working_cfg.get("BEAR_RESIDUAL_CASH_FRACTION_ACTIVE", 0.0) or 0.0)
            if bear_cash_fraction_active > 0 and len(selected) > 0:
                scale_factor = max(0.0, 1.0 - bear_cash_fraction_active)
                weights = {s: w * scale_factor for s, w in weights.items()}
                weights["CASH"] = bear_cash_fraction_active
                log_emit(log_cb, f"[BearAllocation] Applied post-optimization bear-market cash buffer: scaled stock weights by {scale_factor:.3f}; {bear_cash_fraction_active*100:.0f}% allocated to CASH.")
            elif k_original and len(selected) < k_original and len(selected) > 0:
                scale_factor = len(selected) / k_original
                weights = {s: w * scale_factor for s, w in weights.items()}
                weights["CASH"] = 1.0 - scale_factor
                log_emit(log_cb, f"[BearAllocation] Scaled down final stock weights by {scale_factor:.3f} (only {len(selected)}/{k_original} resilient stocks found, remaining weight allocated to CASH).")
        else:
            log_emit(log_cb, f"[BearAllocation] CASH asset optimized directly inside Mean-Variance SLSQP solver: CASH weight is {weights.get('CASH', 0.0)*100:.2f}%.")

        # v16: IndiaVIX position sizing (scales down all weights in high-fear regime)
        if working_cfg.get("USE_INDIA_VIX_SIZING", True) and not pd.isna(_india_vix):
            weights = apply_vix_position_sizing(weights, _india_vix, working_cfg, log_cb=log_cb)

        # ── Final Two-Pass Post-Processing Capping Guard ───────────────────
        # Guarantees 0 stock or sector compliance breaches using profile-aware limits.
        # SF-fix6: respect ENABLE_SECTOR_CAP=False — concentrated profiles that
        # intentionally disable sector constraints should not be clipped to 35%.
        _max_stock_cap = float(working_cfg.get("MAX_WEIGHT", 0.10))
        _sector_cap_enabled = working_cfg.get("ENABLE_SECTOR_CAP", True)
        _max_sector_cap = float(working_cfg.get("SECTOR_LIMIT", 0.35)) if _sector_cap_enabled else 1.0
        weights = apply_two_pass_clipping(weights, sectors, max_stock=_max_stock_cap, max_sector=_max_sector_cap)
        if _sector_cap_enabled:
            log_emit(log_cb, f"[FinalCapGuard] Enforced two-pass stock ({_max_stock_cap:.0%}) & sector ({_max_sector_cap:.0%}) compliance caps.")
        else:
            log_emit(log_cb, f"[FinalCapGuard] Stock cap ({_max_stock_cap:.0%}) applied. Sector cap disabled (ENABLE_SECTOR_CAP=False).")

        if not weights or sum(weights.values()) <= 0:
            weights = {"CASH": 1.0}

        # v15: alpha decay analysis stored in payload (quick, uses existing data)
        _alpha_decay_df = compute_alpha_decay(clean_returns, signal_df, log_cb=log_cb)

        progress_span(progress_cb, 68, 80, 1, 1)

        backtest = None
        if cfg.get("RUN_BACKTEST"):
            if cfg.get("USE_EVENT_BACKTEST", False) and len(selected) > 0:
                try:
                    from math_engine.event_backtester import EventDrivenBacktester
                    log_emit(log_cb, "[Backtest] Event-driven backtester running...")
                    bt = EventDrivenBacktester(initial_capital=float(cfg.get("PORTFOLIO_VALUE_INR", 1_000_000)), commission_bps=float(cfg.get("BACKTEST_FEE_BPS", 15.0)))
                    _rebal_days = int(cfg.get("BACKTEST_REBALANCE_DAYS", 21))
                    for dt in clean_returns.index[::_rebal_days]:
                        if dt not in clean_returns.index: continue
                        for ticker, w in weights.items():
                            if ticker == "CASH" or ticker not in clean_returns.columns: continue
                            target_shares = int((w * bt.initial_capital) / max(close.loc[dt, ticker], 1))
                            from math_engine.event_backtester import Order
                            current = bt.positions.get(ticker, type("P", (), {"quantity": 0})).quantity
                            delta = target_shares - current
                            if abs(delta) > 0:
                                bt.submit_order(Order(timestamp=dt, ticker=ticker, side="BUY" if delta > 0 else "SELL", quantity=abs(delta)), close.loc[[dt]])
                        bt.mark_to_market(dt, close.loc[[dt]])
                    bt_result = bt.get_results()
                    backtest = {"Sharpe Ratio": bt_result.metrics.get("sharpe_ratio", 0), "Annual Return": bt_result.metrics.get("annual_return", 0), "Max Drawdown": bt_result.metrics.get("max_drawdown", 0), "Annual Vol": bt_result.metrics.get("annual_volatility", 0), "Equity Curve": bt_result.equity_curve, "event_driven": True, "n_trades": bt_result.metrics.get("num_trades", 0)}
                    log_emit(log_cb, f"[Backtest] Event-driven: Sharpe={backtest['Sharpe Ratio']:.2f}, Trades={backtest['n_trades']}")
                except Exception as _edbt_e:
                    log_emit(log_cb, f"[Backtest] Event-driven failed ({_edbt_e}), using WFO", exc_info=True)
                    backtest = run_wfo_backtest(data, returns, benchmark_returns, sectors, working_cfg, log_cb, progress_cb)
            else:
                backtest = run_wfo_backtest(data, returns, benchmark_returns, sectors, working_cfg, log_cb, progress_cb)

            # Check Drawdown Circuit Breaker (Phase 5)
            # IMPORTANT: this equity curve is the WFO *simulation* — not a live account.
            # Do NOT wipe selected=[] based on simulated drawdown — early-entry and base-building

        # risk_attrib is populated by the Barra decomposition block below.
        # Initialize here so it is always bound regardless of whether the
        # decomposition succeeds, fails, or is skipped.
        risk_attrib = {}

        # ── Per-ticker signal scores for per-profile CSV exports ──────────────
        # Compact {ticker: {factor: value}} dict injected into base_payload so
        # the export pipeline can show per-profile differentiated scores.
        _SCORE_EXPORT_COLS = [
            "alpha_score", "z_mom_3m", "z_mom_6m", "z_rs_rating", "z_vcp_score",
            "z_roe", "z_pe_inv", "z_de_inv", "z_ann_vol", "z_downside_vol",
            "z_cmf_score", "z_obv_slope", "z_vol_surge", "z_delivery",
            "z_vpin_toxicity", "z_range_contraction", "z_updown_vol",
            "rs_raw", "ann_vol", "adv20", "beta", "pe_ratio",
            "vcp_score", "cmf_score", "obv_slope",
        ]
        _signal_scores: dict = {}
        if signal_df is not None and not signal_df.empty:
            for _t in signal_df.index:
                _row = {}
                for _c in _SCORE_EXPORT_COLS:
                    if _c in signal_df.columns:
                        _v = signal_df.loc[_t, _c]
                        _row[_c] = float(_v) if pd.notna(_v) else None
                _signal_scores[str(_t)] = _row

        # Merge chart columns into prescreen_df for the out_rows build.
        # _chart_cols_to_merge was already built unconditionally after the solve.
        _chart_cols_present = [c for c in _chart_cols_to_merge if c in signal_df.columns]
        if _chart_cols_present and "ticker" in prescreen_df.columns:
            _chart_merge = signal_df[_chart_cols_present].copy()
            _chart_merge.index.name = "ticker"
            prescreen_df = prescreen_df.merge(_chart_merge.reset_index(), on="ticker", how="left")
        lookup = prescreen_df.set_index("ticker")
        out_rows = []
        for s in ranked:
            adv20 = float(lookup.loc[s, "adv20"]) if s in lookup.index else np.nan
            contrib = factor_contribution_row(signal_df, s, cfg=working_cfg)
            out_rows.append({
                "Ticker": s, "Sector": sectors.get(s, "N/A"),
                "Weight %": float(weights.get(s, 0.0)),
                "AlphaScore": float(signal_df.loc[s, "alpha_score"]), "RiskScore": float(signal_df.loc[s, "risk_score"]),
                "Mom1M": float(signal_df.loc[s, "mom_1m"]), "Mom6M": float(signal_df.loc[s, "mom_6m"]), 
                "AnnVol": float(signal_df.loc[s, "ann_vol"]),
                "SectorRS1M": float(signal_df.loc[s, "sector_rel_mom_1m"]) if pd.notna(signal_df.loc[s, "sector_rel_mom_1m"]) else np.nan,
                "SectorRS6M": float(signal_df.loc[s, "sector_rel_mom_6m"]) if pd.notna(signal_df.loc[s, "sector_rel_mom_6m"]) else np.nan,
                "Beta": float(signal_df.loc[s, "beta"]) if pd.notna(signal_df.loc[s, "beta"]) else np.nan, "ADV20": adv20,
                "ChartPatternZ": float(signal_df.loc[s, "z_chart_pattern"]) if "z_chart_pattern" in signal_df.columns and pd.notna(signal_df.loc[s, "z_chart_pattern"]) else np.nan,
                "ChartNoveltyZ": float(signal_df.loc[s, "z_chart_novelty"]) if "z_chart_novelty" in signal_df.columns and pd.notna(signal_df.loc[s, "z_chart_novelty"]) else np.nan,
                "ChartMarginZ": float(signal_df.loc[s, "z_chart_margin"]) if "z_chart_margin" in signal_df.columns and pd.notna(signal_df.loc[s, "z_chart_margin"]) else np.nan,
                "ChartDispersion": float(signal_df.loc[s, "chart_pattern_dispersion"]) if "chart_pattern_dispersion" in signal_df.columns and pd.notna(signal_df.loc[s, "chart_pattern_dispersion"]) else np.nan,
                "ChartAgreement": float(signal_df.loc[s, "chart_cluster_agreement"]) if "chart_cluster_agreement" in signal_df.columns and pd.notna(signal_df.loc[s, "chart_cluster_agreement"]) else np.nan,
                "ChartCluster": int(signal_df.loc[s, "chart_pattern_cluster"]) if "chart_pattern_cluster" in signal_df.columns and pd.notna(signal_df.loc[s, "chart_pattern_cluster"]) else np.nan,
                "ChartCalibratedProb": float(signal_df.loc[s, "chart_calibrated_prob"]) if "chart_calibrated_prob" in signal_df.columns and pd.notna(signal_df.loc[s, "chart_calibrated_prob"]) else np.nan,
                "ChartFailedBreakoutRisk": float(signal_df.loc[s, "chart_failed_breakout_risk"]) if "chart_failed_breakout_risk" in signal_df.columns and pd.notna(signal_df.loc[s, "chart_failed_breakout_risk"]) else np.nan,
                "GrowthFactor": contrib["GrowthFactor"], "TrendFactor": contrib["TrendFactor"],
                "LiquidityFactor": contrib["LiquidityFactor"], "QualityFactor": contrib["QualityFactor"], "SectorLeadFactor": contrib["SectorLeadFactor"],
                "Reason": summarize_selection_reason(signal_df, s),
            })

        if "CASH" in weights and float(weights["CASH"]) > 0:
            out_rows.append({
                "Ticker": "CASH", "Sector": "Liquidity",
                "Weight %": float(weights["CASH"]),
                "AlphaScore": 0.0, "RiskScore": 0.0,
                "Mom1M": 0.0, "Mom6M": 0.0, 
                "AnnVol": 0.0,
                "SectorRS1M": np.nan, "SectorRS6M": np.nan,
                "Beta": 0.0, "ADV20": np.nan,
                "ChartPatternZ": np.nan, "ChartNoveltyZ": np.nan, "ChartMarginZ": np.nan,
                "ChartDispersion": np.nan, "ChartAgreement": np.nan, "ChartCluster": np.nan,
                "ChartCalibratedProb": np.nan, "ChartFailedBreakoutRisk": np.nan,
                "GrowthFactor": 0.0, "TrendFactor": 0.0,
                "LiquidityFactor": 0.0, "QualityFactor": 0.0, "SectorLeadFactor": 0.0,
                "Reason": "Capital preserved in CASH due to risk overlay or circuit breaker."
            })

        portfolio_df = pd.DataFrame(out_rows)

        # ── NSE Lot-Size Rounding ────────────────────────────────────────────────
        # NSE equity minimum is 1 share. The optimizer outputs fractional weights;
        # this block converts them to realistic whole-share allocations.
        # High-priced stocks (MRF ~₹130,000, Page Industries ~₹48,000) will show
        # their true discrete allocation instead of an impossible fractional weight.
        if working_cfg.get("USE_LOT_SIZE_ROUNDING", True) and len(selected) > 0:
            try:
                _port_val = float(working_cfg.get("PORTFOLIO_VALUE_INR", 1_000_000))
                _lot_rows = []
                _total_alloc = 0.0
                for s in selected:
                    _w = float(weights.get(s, 0.0))
                    _target_inr = _w * _port_val
                    # Get latest close price for lot-size computation
                    _price = np.nan
                    if s in close.columns and not close[s].dropna().empty:
                        _price = float(close[s].dropna().iloc[-1])
                    if np.isfinite(_price) and _price > 0:
                        _shares = max(0, int(_target_inr / _price))  # floor to whole shares
                        _actual_inr = _shares * _price
                        _actual_w = _actual_inr / _port_val
                    else:
                        _shares = 0
                        _actual_inr = 0.0
                        _actual_w = 0.0
                    _lot_rows.append((s, _shares, _actual_inr, _actual_w))
                    _total_alloc += _actual_inr

                _residual_cash_pct = max(0.0, 1.0 - _total_alloc / _port_val) if _port_val > 0 else 0.0
                if "Shares" not in portfolio_df.columns:
                    portfolio_df["Shares"] = np.nan
                if "AllocationINR" not in portfolio_df.columns:
                    portfolio_df["AllocationINR"] = np.nan
                if "RoundedWeight" not in portfolio_df.columns:
                    portfolio_df["RoundedWeight"] = np.nan
                if "BuyPrice" not in portfolio_df.columns:
                    portfolio_df["BuyPrice"] = np.nan
                if "Target" not in portfolio_df.columns:
                    portfolio_df["Target"] = np.nan
                if "StopLoss" not in portfolio_df.columns:
                    portfolio_df["StopLoss"] = np.nan

                for _s, _sh, _inr, _aw in _lot_rows:
                    if _s in portfolio_df["Ticker"].values:
                        _idx = portfolio_df.index[portfolio_df["Ticker"] == _s][0]
                        portfolio_df.loc[_idx, "Shares"] = _sh
                        portfolio_df.loc[_idx, "AllocationINR"] = round(_inr, 2)
                        portfolio_df.loc[_idx, "RoundedWeight"] = round(_aw, 6)
                        _px = np.nan
                        if _s in close.columns and not close[_s].dropna().empty:
                            _px = float(close[_s].dropna().iloc[-1])
                        if np.isfinite(_px) and _px > 0:
                            portfolio_df.loc[_idx, "BuyPrice"] = round(_px, 2)
                            _h = high_px[_s].dropna().values if ('high_px' in locals() and _s in high_px.columns) else None
                            _l = low_px[_s].dropna().values if ('low_px' in locals() and _s in low_px.columns) else None
                            _c = close[_s].dropna().values if ('close' in locals() and _s in close.columns) else None
                            _p_prof = str(working_cfg.get("PROFILE_NAME", "")).lower()
                            _risk_prof = "aggressive" if any(k in _p_prof for k in ["alpha", "momentum", "breakout", "squeeze", "ipo"]) else ("defensive" if any(k in _p_prof for k in ["defense", "parity", "preservation", "all-weather"]) else "balanced")
                            try:
                                from math_engine.profile_mathematical_suite import AdaptiveVolatilityRiskEngine
                                _dyn = AdaptiveVolatilityRiskEngine.compute_chart_structural_levels(
                                    current_price=_px,
                                    highs=_h,
                                    lows=_l,
                                    closes=_c,
                                    risk_profile=_risk_prof
                                )
                                portfolio_df.loc[_idx, "StopLoss"] = round(float(_dyn["stop_loss_price"]), 2)
                                portfolio_df.loc[_idx, "Target"]   = round(float(_dyn["snell_target_price"]), 2)
                            except Exception:
                                _vol = float(portfolio_df.loc[_idx, "AnnVol"]) if "AnnVol" in portfolio_df.columns and pd.notna(portfolio_df.loc[_idx, "AnnVol"]) else 0.30
                                _sl_pct = max(0.04, min(0.10, (_vol / 15.87) * 1.5))
                                _tp_pct = max(_sl_pct * 1.8, 0.08)
                                portfolio_df.loc[_idx, "StopLoss"] = round(_px * (1.0 - _sl_pct), 2)
                                portfolio_df.loc[_idx, "Target"]   = round(_px * (1.0 + _tp_pct), 2)

                _defensive_cash_pct = bear_cash_fraction_active if 'bear_cash_fraction_active' in locals() else 0.0
                _unintentional_residual_inr = max(0.0, _port_val * (1.0 - _defensive_cash_pct) - _total_alloc)

                if _unintentional_residual_inr > 0.02 * _port_val:
                    _liquid_bees_price = 1000.0
                    if "LIQUIDBEES.NS" in close.columns and not close["LIQUIDBEES.NS"].dropna().empty:
                        _liquid_bees_price = max(float(close["LIQUIDBEES.NS"].iloc[-1]), 1000.0)
                    _etf_shares = int(_unintentional_residual_inr / _liquid_bees_price)
                    if _etf_shares > 0:
                        _etf_alloc_inr = _etf_shares * _liquid_bees_price
                        _etf_weight = _etf_alloc_inr / _port_val
                        _total_alloc += _etf_alloc_inr
                        _residual_cash_pct = max(0.0, 1.0 - _total_alloc / _port_val)
                        log_emit(log_cb, f"[LotSize] Swept ₹{_etf_alloc_inr:,.0f} ({_etf_weight:.2%}) of lot-size residual cash into {_etf_shares} shares of LIQUIDBEES.NS (Defensive Cash={_defensive_cash_pct*100:.0f}% preserved).")

                log_emit(log_cb, f"[LotSize] NSE lot-size rounding: allocated ₹{_total_alloc:,.0f} / ₹{_port_val:,.0f} | "
                         f"residual unallocated cash = {_residual_cash_pct:.2%}")
            except Exception as _lot_e:
                log_emit(log_cb, f"[LotSize] Lot-size rounding skipped: {_lot_e}", exc_info=True)

        portfolio_health = compute_portfolio_health(portfolio_df)


        # ── Barra-Style Factor Risk Decomposition ──
        risk_attrib = {}
        try:
            from math_engine.factor_risk import FactorRiskDecomposer
            log_emit(log_cb, "[BarraRisk] Decomposing portfolio factor exposures and risk attribution...")
            
            decomposer = FactorRiskDecomposer()
            exposures = decomposer.compute_factor_exposures(
                signal_df,
                returns=clean_returns,
                sectors=sectors,
                benchmark_returns=benchmark_returns
            )
            
            norm_weights = {s: float(weights[s]) for s in selected if s in weights and s != "CASH"}
            
            risk_horizon = working_cfg.get("RISK_HORIZON", "Strategic (252d)")
            use_ewma = "Tactical" in risk_horizon
            ewma_lambda = float(working_cfg.get("EWMA_LAMBDA", 0.94))
            use_ledoit_wolf = bool(working_cfg.get("USE_LEDOIT_WOLF", True))
            
            risk_attrib = decomposer.decompose_risk(
                clean_returns,
                exposures,
                norm_weights,
                benchmark_returns=benchmark_returns,
                use_ewma=use_ewma,
                ewma_lambda=ewma_lambda,
                use_ledoit_wolf=use_ledoit_wolf
            )
            
            if risk_attrib:
                portfolio_health["Ex-Ante Volatility %"] = round(risk_attrib["portfolio_volatility"] * 100, 2)
                portfolio_health["Factor Risk %"] = round(risk_attrib["factor_risk_ratio"] * 100, 2)
                portfolio_health["Specific Risk %"] = round(risk_attrib["specific_risk_ratio"] * 100, 2)
                portfolio_health["Portfolio Beta"] = round(risk_attrib["portfolio_beta"], 3)
                portfolio_health["Ex-Ante Tracking Error %"] = round(risk_attrib["tracking_error"] * 100, 2)
                
                log_emit(log_cb, f"[BarraRisk] Portfolio Ex-Ante Vol: {portfolio_health['Ex-Ante Volatility %']:.2f}% | "
                                 f"Factor Risk: {portfolio_health['Factor Risk %']:.2f}% | "
                                 f"Specific Risk: {portfolio_health['Specific Risk %']:.2f}% | "
                                 f"Beta: {portfolio_health['Portfolio Beta']:.3f} | "
                                 f"Tracking Error: {portfolio_health['Ex-Ante Tracking Error %']:.2f}%")
                
                portfolio_health["Active Share %"] = round(risk_attrib.get("active_share", 0.0) * 100, 2)
                portfolio_health["Diversification Ratio"] = round(risk_attrib.get("diversification_ratio", 1.0), 3)
                portfolio_health["Risk Entropy (Normalized)"] = round(risk_attrib.get("risk_entropy", 0.0), 3)
                
                log_emit(log_cb, f"[BarraRisk] Active Share: {portfolio_health['Active Share %']:.2f}% | "
                                 f"Diversification Ratio: {portfolio_health['Diversification Ratio']:.3f} | "
                                 f"Risk Entropy: {portfolio_health['Risk Entropy (Normalized)']:.3f}")
                
                # Log ex-ante VaR & CVaR
                log_emit(log_cb, f"[BarraRisk] Ex-Ante VaR (95%): {risk_attrib.get('ex_ante_var_95', 0.0)*100:.2f}% | CVaR (95%): {risk_attrib.get('ex_ante_cvar_95', 0.0)*100:.2f}%")
                log_emit(log_cb, f"[BarraRisk] Ex-Ante VaR (99%): {risk_attrib.get('ex_ante_var_99', 0.0)*100:.2f}% | CVaR (99%): {risk_attrib.get('ex_ante_cvar_99', 0.0)*100:.2f}%")
                
                if "factor_stress_tests" in risk_attrib:
                    log_emit(log_cb, "[BarraRisk] Aladdin-Style Factor Stress Scenarios (Simulated Return Impact):")
                    severe_stress_loss = float(working_cfg.get("SEVERE_STRESS_LOSS_PCT", -0.40))
                    for sc_name, impact in risk_attrib["factor_stress_tests"].items():
                        sign = "+" if impact >= 0 else ""
                        severity = " | SEVERE" if float(impact) <= severe_stress_loss else ""
                        log_emit(log_cb, f"  -> {sc_name:<35}: {sign}{impact*100:.2f}%{severity}")
        except Exception as _rde:
            log_emit(log_cb, f"[BarraRisk] Decomposition failed (non-fatal): {_rde}", exc_info=True)

        # ── Post-processing: build summary DataFrames (guarded — must not crash the profile) ──
        try:
            sector_summary_df = build_sector_summary(portfolio_df)
        except Exception as _e:
            log_emit(log_cb, f"[SectorSummary] Build failed (non-fatal): {_e}", exc_info=True)
            sector_summary_df = pd.DataFrame()
        try:
            factor_summary_df = build_factor_summary(portfolio_df)
        except Exception as _e:
            log_emit(log_cb, f"[FactorSummary] Build failed (non-fatal): {_e}", exc_info=True)
            factor_summary_df = pd.DataFrame()
        try:
            exposures_df = build_exposures_summary(portfolio_df, benchmark_symbol or "Unavailable", regime_info)
            if risk_attrib:
                new_rows = [
                    {"Metric": "Active Share", "Portfolio": round(risk_attrib.get("active_share", 0.0) * 100, 2), "Benchmark": 0.0, "Active": round(risk_attrib.get("active_share", 0.0) * 100, 2)},
                    {"Metric": "Diversification Ratio", "Portfolio": round(risk_attrib.get("diversification_ratio", 1.0), 3), "Benchmark": 1.0, "Active": round(risk_attrib.get("diversification_ratio", 1.0) - 1.0, 3)},
                    {"Metric": "Risk Entropy (Normalized)", "Portfolio": round(risk_attrib.get("risk_entropy", 0.0), 3), "Benchmark": 1.0, "Active": round(risk_attrib.get("risk_entropy", 0.0) - 1.0, 3)},
                    {"Metric": "Ex-Ante VaR (95%)", "Portfolio": round(risk_attrib.get("ex_ante_var_95", 0.0) * 100, 2), "Benchmark": 0.0, "Active": round(risk_attrib.get("ex_ante_var_95", 0.0) * 100, 2)},
                    {"Metric": "Ex-Ante CVaR (95%)", "Portfolio": round(risk_attrib.get("ex_ante_cvar_95", 0.0) * 100, 2), "Benchmark": 0.0, "Active": round(risk_attrib.get("ex_ante_cvar_95", 0.0) * 100, 2)},
                ]
                exposures_df = pd.concat([exposures_df, pd.DataFrame(new_rows)], ignore_index=True)
        except Exception as _e:
            log_emit(log_cb, f"[ExposuresSummary] Build failed (non-fatal): {_e}", exc_info=True)
            exposures_df = pd.DataFrame()
        try:
            sector_relative_df = build_sector_relative_summary(portfolio_df)
        except Exception as _e:
            log_emit(log_cb, f"[SectorRelative] Build failed (non-fatal): {_e}", exc_info=True)
            sector_relative_df = pd.DataFrame()
        try:
            previous_state = load_last_run_state()
            changes_df, change_summary = build_selection_changes(selected, portfolio_df, previous_state)
        except Exception as _e:
            log_emit(log_cb, f"[SelectionChanges] Build failed (non-fatal): {_e}", exc_info=True)
            changes_df = pd.DataFrame()
            change_summary = {}
        try:
            _benchmark_price_series = fetch_price_series(benchmark_symbol, close.index.min(), close.index.max()) if (benchmark_symbol and close is not None and not close.empty) else None
        except Exception as _e:
            log_emit(log_cb, f"[BenchmarkPriceFetch] Failed (non-fatal): {_e}", exc_info=True)
            _benchmark_price_series = None
        base_payload = {
            # AUDIT-FIX (defect #P1-11): every exported artifact now carries
            # the run_id generated at the top of run_optimizer_logic so the
            # operator can verify which run produced which artifact.
            "run_id": _run_id,
            "alpha_decay_calibrated": _alpha_decay_calibrated,
            "factor_risk_diagnostics": risk_attrib,
            "selected": selected, "energy": energy, "solver_source": solver_source,
            "fo_ban_list": sorted(ban_set) if "ban_set" in dir() and ban_set else [],
            "sector_spread": f"{len(set([sectors.get(s,'') for s in selected]))}/{max(len(selected), 1)}",
            "resolved_sectors": sum(1 for v in sectors.values() if v != "N/A"),
            "matrix_shape": clean_returns.shape, "qubo_terms": len(q),
            "input_universe_count": len(all_tickers), "passed_filter_count": len(prescreen_df),
            "screened_count": len(prescreen_df), "benchmark_symbol": benchmark_symbol or "Unavailable",
            "backtest": backtest, "runtime_sec": (datetime.now() - start).total_seconds(),
            "cfg": cfg, "regime_info": regime_info,
            "chart_model_info": dict(signal_df.attrs.get("chart_model_info", {}) or {}),
            "portfolio_df": portfolio_df, "prescreen_df": prescreen_df,
            "screened": list(prescreen_df["ticker"]) if (prescreen_df is not None and hasattr(prescreen_df, "columns") and "ticker" in prescreen_df.columns) else (list(prescreen_df.index) if prescreen_df is not None else []),
            "signal_scores": _signal_scores,   # per-profile per-ticker alpha scores for CSV export
            "corr_df": clean_returns[[c for c in selected if c in clean_returns.columns]].corr().round(4) if selected and clean_returns is not None and not clean_returns.empty else pd.DataFrame(),
            "sector_summary_df": sector_summary_df,
            "factor_summary_df": factor_summary_df,
            "exposures_df": exposures_df,
            "sector_relative_df": sector_relative_df,
            "changes_df": changes_df,
            "portfolio_health": portfolio_health,
            "selection_change_summary": change_summary,
            "selected_price_df": close[[c for c in selected if c in close.columns]].tail(220).copy() if selected and close is not None and not close.empty else pd.DataFrame(),
            "selected_volume_df": volume[[c for c in selected if c in volume.columns]].tail(220).copy() if selected and volume is not None and not volume.empty else pd.DataFrame(),
            "benchmark_price_series": _benchmark_price_series,
        }
        try:
            base_payload["alerts_df"] = build_alerts(base_payload)
        except Exception as _e:
            log_emit(log_cb, f"[Alerts] Build failed (non-fatal): {_e}", exc_info=True)
            base_payload["alerts_df"] = pd.DataFrame()
        try:
            diagnostics_df = build_diagnostics_frame(base_payload, regime_info)
        except Exception as _e:
            log_emit(log_cb, f"[Diagnostics] Build failed (non-fatal): {_e}", exc_info=True)
            diagnostics_df = pd.DataFrame()
        payload = dict(base_payload)
        payload["diagnostics_df"] = diagnostics_df

        # ── Institutional Risk Analytics ──
        _port_ret_series = pd.Series(dtype=float)
        if selected and clean_returns is not None and not clean_returns.empty:
            _safe_selected = [c for c in selected if c in clean_returns.columns]
            if _safe_selected:
                _w = pd.Series(weights).reindex(_safe_selected).fillna(0.0)
                if _w.sum() > 0:
                    _w = _w / _w.sum()
                _port_ret_series = clean_returns[_safe_selected].mul(_w, axis=1).sum(axis=1)

        _pv = float(working_cfg.get("PORTFOLIO_VALUE_INR", 1_000_000))

        # Bug 18: Reconcile payload signature with QuantumPortfolioOptimizer expectations
        payload["selected"]         = selected
        payload["selected_tickers"] = selected
        payload["weights"]          = weights
        # Extract backtest metrics gracefully (supporting both "Sharpe" and "Sharpe Ratio" / "Annual Return" etc.)
        def _get_metric(key_list, default=None):
            if not backtest or not isinstance(backtest, dict):
                return default
            for k in key_list:
                if k in backtest and backtest[k] is not None:
                    val = backtest[k]
                    if not (isinstance(val, float) and np.isnan(val)):
                        try:
                            return float(val)
                        except Exception:
                            pass
            return default

        payload["metrics"]          = {
            "sharpe":       _get_metric(["Sharpe", "Sharpe Ratio", "sharpe"], None),
            "ann_return":   _get_metric(["Annual Return", "ann_return", "ann_ret"], None),
            "max_drawdown": _get_metric(["Max Drawdown", "max_drawdown", "drawdown"], None),
        }

        try:
            payload["var_cvar_df"] = compute_var_cvar(_port_ret_series, portfolio_value=_pv)
        except Exception as _e:
            log_emit(log_cb, f"[VaR/CVaR] Calculation failed (non-fatal): {_e}", exc_info=True)
            payload["var_cvar_df"] = None
        try:
            payload["stress_test_df"] = run_stress_tests(weights, signal_df, benchmark_returns, portfolio_value=_pv)
        except Exception as _e:
            log_emit(log_cb, f"[StressTest] Calculation failed (non-fatal): {_e}", exc_info=True)
            payload["stress_test_df"] = None
        try:
            weights_map = dict(zip(selected, weights)) if isinstance(weights, (list, tuple, np.ndarray)) else weights
            payload["risk_suite"] = compute_barra_risk_decomposition(
                selected, weights_map or {}, signal_df, clean_returns, working_cfg, log_cb=log_cb
            )
        except Exception as _e:
            log_emit(log_cb, f"[Barra] Risk decomposition failed (non-fatal): {_e}", exc_info=True)
            payload["risk_suite"] = None
        # v15: alpha decay analysis
        if not _alpha_decay_df.empty:
            payload["alpha_decay_df"]   = _alpha_decay_df
        # v15: hyperparameter sensitivity (opt-in, expensive)
        if working_cfg.get("RUN_SENSITIVITY", False):
            # AUDIT-FIX (Round 4 — E1124 / TypeError): original call passed
            # `q, signal_df, sectors, working_cfg, log_cb=log_cb` (5 positional
            # + 1 kw), but compute_sensitivity_report's signature is
            # `(base_cfg, signal_df, clean_returns, log_cb=None)`. The 4th
            # positional (`working_cfg`) bound to `log_cb`, then `log_cb=log_cb`
            # collided → `TypeError: got multiple values for argument 'log_cb'`
            # the moment RUN_SENSITIVITY was enabled. Re-mapped to the correct
            # argument order: base_cfg=working_cfg, signal_df=signal_df,
            # clean_returns=clean_returns (defined earlier in this scope at
            # the _port_ret_series = clean_returns[selected].mul(...) line).
            payload["sensitivity_df"] = compute_sensitivity_report(
                working_cfg, signal_df, clean_returns, log_cb=log_cb)
        # v15: FII/DII flow info
        if _fii_data:
            payload["fii_dii_signal"] = _fii_data

        # v16: IndiaVIX in payload
        payload["india_vix"] = _india_vix

        # v16: dynamic stop-loss check on existing equity curve
        if payload.get("backtest") and payload["backtest"].get("Equity Curve") is not None:
            _max_dd_pct = float(working_cfg.get("MAX_PORTFOLIO_DD_PCT", 0.12))
            _triggered = check_portfolio_drawdown(payload["backtest"]["Equity Curve"], _max_dd_pct)
            payload["stop_loss_triggered"] = _triggered
            if _triggered:
                log_emit(log_cb, f"⛔ [StopLoss] Stop Loss / Circuit Breaker Active. Target weights set to 100% CASH.")

        # v16: regime-conditional backtest split
        if working_cfg.get("REGIME_CONDITIONAL_BT", False) and payload.get("backtest"):
            _eq = payload["backtest"].get("Equity Curve")
            if _eq is not None and len(_eq) > 60:
                payload["regime_bt_df"] = split_backtest_by_regime(
                    _eq, benchmark_returns, log_cb=log_cb)

        # v16: multi-sheet Excel export
        if working_cfg.get("EXCEL_EXPORT_ENABLED", False):
            _ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            _xl_path = str(RUNTIME_DIR / f"QA_Pro_v16_{_ts}.xlsx")
            export_to_excel(payload, _xl_path, log_cb=log_cb)
            payload["excel_export_path"] = _xl_path

        # v17: Marginal Risk Contribution
        if working_cfg.get("SHOW_MRC", True) and weights:
            payload["mrc_df"] = compute_marginal_risk_contribution(weights, clean_returns)

        # v17: Out-of-sample validation (runs a quick 2nd backtest — adds ~15s)
        # R34-3 FIX: never compute — and never persist — OOS/backtest metrics for
        # a degenerate allocation. The 2026-09-14 incident log shows an empty
        # (staleness-flattened) portfolio producing IS Sharpe=-3.53 / OOS
        # Sharpe=-3.63 which was SAVED to the OOS history DB (run_1789358174)
        # before the data-quality gate aborted the run — fabricated numbers for
        # a no-trade run polluting the DSR/OOS track record.
        _degenerate_alloc = bool(working_cfg.get("_DEFENSIVE_FLAT")) or not selected
        if _degenerate_alloc and working_cfg.get("USE_OOS_VALIDATION", True):
            log_emit(log_cb, "[OOS] Skipped — degenerate allocation (empty target portfolio"
                             + (" from Staleness Flatten" if working_cfg.get("_DEFENSIVE_FLAT") else "")
                             + "): no OOS/backtest metrics computed or persisted.")
            payload["oos_validation"] = None
        elif working_cfg.get("USE_OOS_VALIDATION", True) and data is not None:
            try:
                _main_bt_sharpe = None
                if backtest:
                    for _k in ["Sharpe", "Sharpe Ratio", "sharpe", "SharpeRatio", "sharpe_ratio"]:
                        if _k in backtest:
                            try:
                                _main_bt_sharpe = float(str(backtest[_k]).replace("x", ""))
                                break
                            except Exception:
                                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                                pass
                    if _main_bt_sharpe is None:
                        _nested = backtest.get("backtest") or {}
                        if isinstance(_nested, dict):
                            for _k in ["Sharpe", "Sharpe Ratio"]:
                                if _k in _nested:
                                    try:
                                        _main_bt_sharpe = float(str(_nested[_k]).replace("x", ""))
                                        break
                                    except Exception:
                                        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                                        pass
                payload["oos_validation"] = compute_oos_validation(
                    data, returns, benchmark_returns, sectors, working_cfg,
                    int(working_cfg.get("OOS_WINDOW_DAYS", TRADING_DAYS_PER_YEAR)), log_cb=log_cb,
                    main_bt_sharpe=_main_bt_sharpe)
                _oos_res = payload.get("oos_validation")
                if isinstance(_oos_res, dict) and (_oos_res.get("Verdict") == "Underpowered" or _oos_res.get("verdict") == "Underpowered"):
                    payload["oos_validation_tag"] = "[⚠️ LOW SAMPLE WFO: <15 STEPS]"
                    log_emit(log_cb, "[OOS] Attached [⚠️ LOW SAMPLE WFO: <15 STEPS] disclaimer tag to signal payload.")
                if _DB_STORE is not None and payload.get("oos_validation"):
                    try:
                        _DB_STORE.save_oos_result(
                            run_id=None,
                            oos_result=payload["oos_validation"],
                            regime=str(regime_info.get("Regime", "Unknown")),
                            log_cb=log_cb)
                    except Exception as _e_oos:
                        if log_cb: log_cb(f"[DB] OOS save non-fatal: {_e_oos}")
            except Exception as _e_oos_outer:
                log_emit(log_cb, f"[OOS] Validation failed (non-fatal): {_e_oos_outer}", exc_info=True)
                payload["oos_validation"] = None

        # v17.2: Factor attribution — enabled by default; fallback to portfolio mean returns
        if working_cfg.get("USE_FACTOR_ATTRIBUTION", True):
            try:
                _eq = payload.get("backtest", {}).get("Equity Curve") if payload.get("backtest") else None
                _is_retro = False
                if _eq is not None and len(_eq) > 63:
                    _fa_rets = _eq.pct_change().dropna()
                elif selected and len(selected) > 0:
                    _safe_fa_sel = [c for c in selected if c in clean_returns.columns] if clean_returns is not None else []
                    _fa_rets = clean_returns[_safe_fa_sel].mean(axis=1).dropna() if _safe_fa_sel else None
                    _is_retro = True
                else:
                    _fa_rets = None
                if _fa_rets is not None and len(_fa_rets) > 20:
                    payload["factor_attribution_df"] = compute_factor_attribution(
                        _fa_rets, benchmark_returns, signal_df, log_cb=log_cb,
                        cfg=working_cfg, is_underpowered=bool(payload.get("oos_validation_tag")),
                        is_retroactive_basket=_is_retro)
            except Exception as _e:
                log_emit(log_cb, f"[Factor Attr] {_e}", exc_info=True)

        # ── v17.3: Factor IC dashboard ────────────────────────────────────
        try:
            payload["factor_ic_df"] = compute_factor_ic_summary(
                clean_returns, working_cfg,
                forward_days=int(working_cfg.get("BACKTEST_REBALANCE_DAYS", 15)),
                log_cb=log_cb)
        except Exception as _e:
            log_emit(log_cb, f"[Factor IC] {_e}", exc_info=True)
            payload["factor_ic_df"] = None
        # ── IC-guided factor weight pruning (advisory log only) ──────────────
        # Shows which factors to zero on next run. Does NOT mutate current run
        # since signal_df is already built. Zero the weights → they contribute
        # nothing to QUBO cost; the IC dashboard still reports them.
        try:
            _icdf = payload.get("factor_ic_df")
            if _icdf is not None and not _icdf.empty and "Status" in _icdf.columns:
                _dead     = _icdf[_icdf["Status"] == "Dead"]["Factor"].tolist()
                _corr_dup = _icdf[_icdf["Corr-Dup"] == True]["Factor"].tolist()
                _prune    = sorted(set(_dead + _corr_dup))
                if _prune:
                    # v17.23: factors orthogonalized upstream — IC pruning safe to apply.
                    # Empirically tested: zeroing Dead/Corr-Dup drops WFO Sharpe by 0.15.
                    # Correlated factors REINFORCE the QUBO linear objective (not noise).
                    log_emit(log_cb,
                        f"[IC Prune] ℹ️  {len(_dead)} low-IC individual factors, "
                        f"{len(_corr_dup)} collinear. Combined IC-IR is the true health metric.")
                _strong = _icdf[(_icdf["Status"].isin(["Strong","Active"])) &
                                 (_icdf["Corr-Dup"] == False)]["Factor"].tolist()
                if _strong:
                    log_emit(log_cb, f"[IC Prune] Effective unique factors: {_strong}")
                else:
                    log_emit(log_cb, "[IC Prune] ℹ️  All factors correlated at current "
                             "forward horizon — add fundamentals (PE, ROE) for independent signal.")
        except Exception as _ie:
            log_emit(log_cb, f"[IC Prune] {_ie}", exc_info=True)

        if working_cfg.get("USE_WATCHLIST", True):
            try:
                _wl_syms = [s.strip() for s in str(working_cfg.get("WATCHLIST_SYMBOLS","")).split(",") if s.strip()]
                if not _wl_syms and selected:
                    _wl_syms = list(selected)
                if _wl_syms:
                    payload["watchlist_df"] = compute_watchlist_scores(_wl_syms, signal_df, log_cb=log_cb, cfg=working_cfg)
            except Exception as _e:
                log_emit(log_cb, f"[Watchlist] {_e}", exc_info=True)
        if working_cfg.get("USE_SQLITE_HISTORY", True):
            if _DB_STORE is not None:
                _DB_STORE.save_run(payload, working_cfg, regime_info,
                                   india_vix=payload.get("india_vix", float("nan")),
                                   log_cb=log_cb)
            else:
                sqlite_save_run(payload, working_cfg, regime_info,
                                india_vix=payload.get("india_vix", float("nan")),
                                log_cb=log_cb)
            # v17.25: save alpha predictions for future IC validation
            save_alpha_predictions(signal_df, close, log_cb=log_cb)
            if _post_trade_df is not None and not _post_trade_df.empty:
                payload["post_trade_df"] = _post_trade_df

        # v17: PDF export
        if working_cfg.get("EXPORT_PDF", False):
            _ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            _pdf_path = str(RUNTIME_DIR / f"QA_Pro_v17_{_ts}.pdf")
            export_pdf_report(payload, working_cfg, regime_info, _pdf_path, log_cb=log_cb)
            payload["pdf_export_path"] = _pdf_path

        # v16: Telegram notification
        if working_cfg.get("TELEGRAM_ENABLED", False):
            send_telegram_notification(payload, working_cfg, log_cb=log_cb)
        payload["kite_orders_df"]       = generate_kite_order_sheet(weights, portfolio_df, portfolio_value=_pv)
        payload["survivorship_bias"]    = estimate_survivorship_bias(working_cfg.get("LOOKBACK_DOWNLOAD","2y"), log_cb)
        # ── Breakout screens ──────────────────────────────────────────────
        try:
            _bo_df, _pb_df = compute_breakout_tables(signal_df, sectors)
            payload["breakout_df"]    = _bo_df
            payload["prebreakout_df"] = _pb_df
            if not _bo_df.empty:
                log_emit(log_cb, f"[Breakout] {len(_bo_df)} early-breakout stocks identified")
            if not _pb_df.empty:
                log_emit(log_cb, f"[PreBreakout] {len(_pb_df)} pre-breakout setups identified")
        except Exception as _bre:
            log_emit(log_cb, f"[Breakout] Screen failed (non-fatal): {_bre}", exc_info=True)
            payload["breakout_df"]    = pd.DataFrame()
            payload["prebreakout_df"] = pd.DataFrame()
        payload["portfolio_value_inr"]  = _pv

        # ── Unified 100+ Quantitative Module Pipeline Execution Sequence ────────────────
        try:
            # 1. Enterprise Security & Audit Log
            from enterprise.hsm_kms_vault import HSMKeyVault
            from qa_db.sebi_audit_logger import SEBIAuditLogger
            _audit_db = SEBIAuditLogger()
            _audit_db.log_algo_order(
                order_id=f"RUN_{int(time.time())}", ticker="PORTFOLIO", action="SWEEP",
                quantity=len(weights), price=_pv, algo_category=working_cfg.get("STRATEGY_NAME", "QUANT"),
                compliance_passed=True, details={"n_assets": len(weights)}
            )

            # 2. Statistical Guardrails & Overfitting Guards
            from math_engine.dsr_calculator import (
                compute_probabilistic_sharpe_ratio,
                compute_deflated_sharpe_ratio,
                compute_min_track_record_length,
                compute_gain_to_pain_ratio
            )
            _gpr = compute_gain_to_pain_ratio(_port_ret_series)
            _psr_res = compute_probabilistic_sharpe_ratio(_port_ret_series, benchmark_sr=0.0)
            _n_trials = int(working_cfg.get("N_PARALLEL_TRIALS", 9))
            # AUDIT-FIX (defect #10): the prior fallback
            # `working_cfg.get("_TRIAL_SHARPES", [_psr_res["sharpe"]] * _n_trials)`
            # produced a length-N list of the SAME Sharpe value, so the
            # multiple-testing deflation was mathematically vacuous (zero
            # variance → trivially passes). When real per-trial Sharpes are
            # not available we now report DSR as "insufficient trials" instead
            # of fabricating a synthetic trial set.
            _all_trial_srs = working_cfg.get("_TRIAL_SHARPES")
            if not _all_trial_srs or len(_all_trial_srs) < 2:
                _dsr_res = {
                    "dsr": float("nan"),
                    "dsr_verdict": "Insufficient independent trials for multiple-testing deflation",
                    "n_trials_provided": 0 if not _all_trial_srs else len(_all_trial_srs),
                    "n_trials_required": 2,
                }
                log_emit(log_cb, f"[DSR] Insufficient independent trial Sharpes — DSR reported as NaN (needs >=2 trials; got {0 if not _all_trial_srs else len(_all_trial_srs)}).")
            else:
                _dsr_res = compute_deflated_sharpe_ratio(_all_trial_srs, _port_ret_series)
            _mintrl = compute_min_track_record_length(_psr_res["sharpe"], _psr_res["skewness"], _psr_res["kurtosis"])

            # [Round 8] Institutional Deflated Sharpe (Bailey et al 2014)
            _inst_dsr = {}
            try:
                from math_engine.institutional.deflated_sharpe import (
                    deflated_sharpe_ratio,
                    evaluate_strategy,
                )
                _inst_dsr = deflated_sharpe_ratio(
                    returns=_port_ret_series.dropna().to_numpy(),
                    n_trials=max(1, _n_trials),
                )
                # AUDIT-FIX (Round 6, A3-P3-7): the return dict's real keys are
                # 'expected_max_SR' / 'deflated_sharpe' / 'p_value' / 'verdict'
                # — 'SR_star'/'DSR'/'pass' never existed, so the log line always
                # printed "SR*=nan | DSR=nan | Pass=False" on every run.
                log_emit(
                    log_cb,
                    f"[Inst-DSR] SR*={_inst_dsr.get('expected_max_SR', float('nan')):.4f} "
                    f"| DSR={_inst_dsr.get('deflated_sharpe', float('nan')):.4f} "
                    f"| p={_inst_dsr.get('p_value', float('nan')):.4f} "
                    f"| Verdict={_inst_dsr.get('verdict', '—')}"
                )
            except Exception as _idsr_e:
                logger.warning(f"[Inst-DSR] Institutional DSR skipped: {_idsr_e}", exc_info=True)

            # [Round 8] Triple-Barrier meta-label quality audit on returns signal
            _tb_quality = {}
            try:
                from math_engine.institutional.triple_barrier import triple_barrier_labels
                import pandas as _tb_pd
                _ret_ser = _port_ret_series.dropna()
                if len(_ret_ser) >= 30:
                    # AUDIT-FIX (Round 6, A3-P2-6): the call used kwargs
                    # (close= / upper_barrier= / lower_barrier= /
                    # max_holding_period=) that triple_barrier_labels() never
                    # accepted — TypeError every time, swallowed by the except,
                    # so the meta-labeling quality audit was permanently empty.
                    # Real signature: (prices, upper_width, lower_width,
                    # vertical_days, ...). Widths are in σ-units by default.
                    _tb_labels = triple_barrier_labels(
                        prices=(_ret_ser.cumsum() + 1.0),  # synthetic price from returns
                        upper_width=2.0,
                        lower_width=2.0,
                        vertical_days=21,
                    )
                    _label_counts = _tb_labels.value_counts().to_dict() if hasattr(_tb_labels, "value_counts") else {}
                    _tb_quality = {
                        "label_counts": {str(k): int(v) for k, v in _label_counts.items()},
                        "n_labeled": int(len(_tb_labels)),
                    }
                    log_emit(log_cb, f"[Triple-Barrier] Label distribution on port returns: {_tb_quality['label_counts']}")
            except Exception as _tb_e:
                logger.warning(f"[Triple-Barrier] Quality audit skipped: {_tb_e}", exc_info=True)

            payload["statistical_guardrails"] = {
                "gain_to_pain_ratio": _gpr,
                "psr": _psr_res,
                "dsr": _dsr_res,
                "institutional_dsr": _inst_dsr,
                "triple_barrier_quality": _tb_quality,
                "min_track_record_years": _mintrl
            }

            # 3. Physics & Non-Linear Regime Detection
            from math_engine.ms_var_regime import MSVARRegimeEngine
            from math_engine.fractional_calculus import FractionalCalculusEngine
            from math_engine.fractional_brownian import FractionalBrownianVolEngine
            from math_engine.chaos_lyapunov import ChaosLyapunovEngine
            from utils import compute_hurst_exponent, compute_absorption_ratio

            _hurst_val = compute_hurst_exponent(_port_ret_series)
            _ar_val = compute_absorption_ratio(clean_returns) if clean_returns is not None else 0.0
            _ms_res = MSVARRegimeEngine.filter_regime_transition(_port_ret_series)
            _frac_res = FractionalCalculusEngine.compute_fractional_derivative(_port_ret_series)
            _fbm_res = FractionalBrownianVolEngine.estimate_rough_volatility(_port_ret_series)
            _lle_res = ChaosLyapunovEngine.estimate_lyapunov_exponent(_port_ret_series)

            # 4. Geometry & Topology Manifold Analysis
            from math_engine.tda_homology import TDAHomologyEngine
            from math_engine.riemannian_geometry import RiemannianGeometryEngine
            from math_engine.spectral_clustering import SpectralGraphClusteringEngine
            _tda_res = TDAHomologyEngine.compute_persistent_homology_metrics(clean_returns) if clean_returns is not None else {}
            _riemann_res = RiemannianGeometryEngine.compute_riemannian_metric_tensor(clean_returns) if clean_returns is not None else {}
            _spectral_res = SpectralGraphClusteringEngine.cluster_assets_spectrally(clean_returns) if clean_returns is not None else {}

            # 5. Risk Matrix De-noising & Copulas
            from math_engine.factor_risk import FactorRiskDecomposer
            from math_engine.copula_tail_dependence import CopulaTailDependenceEngine
            from math_engine.evt_copula_tail import EVTCopulaTailEngine
            from math_engine.qrnn_risk import QRNNRiskEngine
            _copula_res = CopulaTailDependenceEngine.estimate_tail_dependence(clean_returns) if clean_returns is not None else {}
            _evt_res = EVTCopulaTailEngine.estimate_extreme_joint_loss(clean_returns) if clean_returns is not None else {}
            _qrnn_res = QRNNRiskEngine.estimate_quantile_loss(clean_returns) if clean_returns is not None else {}

            # 6. Options Gamma Exposure (GEX)
            from math_engine.options_hedger import OptionsTailHedger
            # AUDIT-FIX (Round 23 — R23-1): the R22 residual list noted the
            # GEX/tail-hedge modules took spot from the price frame, IV from
            # the 18% policy default and DTE from the 30d policy default even
            # though a real NSE option-chain fetcher existed (it was wired
            # only to /api/options_surface). We now fetch the live chain once
            # here (best-effort, 5-min TTL + 120s negative cache in
            # data_layer) and share it across GEX + the tail hedge: chain
            # spot overrides the close-frame spot, per-strike OI rows feed a
            # REAL gamma-exposure computation (the old fallback served a
            # canned +Rs150M positive GEX), and the chain's median IV +
            # expiry flow into the hedge delta (see the tail-hedge block).
            _live_chain = None
            try:
                from data_layer import fetch_nse_option_chain
                _live_chain = fetch_nse_option_chain("NIFTY", log_cb=log_cb)
            except Exception as _oc_e:
                log_emit(log_cb, f"[OptionChain] Live NSE chain unavailable in sweep ({_oc_e}) — GEX/hedge fall back to price-frame spot + policy IV/DTE.")
            # AUDIT-FIX (defect #10): the prior code read
            # `signal_df.loc["NIFTY", "close"]` but signal_df is a factor frame,
            # not a price frame, so the "close" column never exists and the
            # fallback to 24500 was always used. We now consult the close price
            # Series (passed in scope as `close`) for NIFTY, falling back to a
            # sentinel only when no NIFTY price series is available — and we
            # log that the fallback is in effect so the operator knows the
            # GEX computation is using an assumed spot, not a live quote.
            _nifty_price = None
            try:
                if close is not None and not close.empty and "NIFTY" in close.columns:
                    _nifty_price = float(close["NIFTY"].dropna().iloc[-1])
                elif close is not None and not close.empty and "^NSEI" in close.columns:
                    _nifty_price = float(close["^NSEI"].dropna().iloc[-1])
                elif working_cfg.get("_BENCHMARK_PRICE"):
                    _nifty_price = float(working_cfg["_BENCHMARK_PRICE"])
                else:
                    from data_layer import get_benchmark_last_price
                    _nifty_price = get_benchmark_last_price()
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                _nifty_price = None
            if _nifty_price is None:
                _nifty_price = float(working_cfg.get("NIFTY_FALLBACK_PRICE", 24500.0))
                log_emit(log_cb, f"[GEX] NIFTY spot not found in price frame; using fallback {_nifty_price:.1f}.")
            else:
                log_emit(log_cb, f"[GEX] Real NIFTY spot price loaded: {_nifty_price:.1f}.")
            # AUDIT-FIX (Round 23 — R23-1): the live chain's underlying spot is
            # fresher than the last close in the price frame — prefer it when
            # the chain is available, with an explicit log of the override.
            try:
                if isinstance(_live_chain, dict) \
                        and isinstance(_live_chain.get("spot_price"), (int, float)) \
                        and float(_live_chain["spot_price"]) > 0:
                    _nifty_price = float(_live_chain["spot_price"])
                    log_emit(log_cb, f"[GEX] Using live NSE option-chain spot {_nifty_price:.1f} (fresher than close frame).")
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
            _hedger = OptionsTailHedger(nifty_price=_nifty_price)
            # AUDIT-FIX (Round 23 — R23-1): real per-strike OI rows -> real GEX.
            # The previous call always hit the no-branch fallback and served a
            # hardcoded +Rs150M "Positive GEX (Mean-Reverting)" verdict.
            _gex_chain_df = None
            try:
                if isinstance(_live_chain, dict) and _live_chain.get("chain_rows"):
                    _gex_chain_df = pd.DataFrame(_live_chain["chain_rows"])
            except Exception:
                _gex_chain_df = None
            # AUDIT-FIX (Round 24 — R24-2): the chain's IV/DTE now flow into the
            # GEX computation so gamma is STRIKE-SOLVED (BS N'(d1)/(S·σ·√T) with
            # per-strike callIV/putIV) instead of the flat 0.0001 x spot^2
            # proxy that overstated wing-strike gamma by ~100x. The resolved
            # inputs are cached/free here (same 5-min-TTL chain the tail-hedge
            # block below resolves again for its own inputs).
            _gex_chain_inputs = None
            try:
                from math_engine.options_hedger import resolve_live_chain_inputs as _resolve_gex_inputs
                _gex_chain_inputs = _resolve_gex_inputs(_live_chain if isinstance(_live_chain, dict) else None)
            except Exception:
                _gex_chain_inputs = None
            # AUDIT-FIX (Round 25 — R25-2): MULTI-EXPIRY aggregation. The R24
            # GEX used the NEAREST expiry's chain only — the single-expiry
            # convention overstated near-dated gamma and ignored the calendar
            # tail. The fetcher now echoes every live expiry date; this block
            # fetches the nearest GEX_EXPIRY_DEPTH (default 3) expiries (each
            # 120s-cached by the data layer — bounded extra network cost) and
            # passes them as multi_expiry_chains so each expiry is solved with
            # its OWN T and per-strike IVs and the totals are summed with a
            # per-expiry breakdown. When only the nearest chain is available
            # (degraded fetch) the single-chain R24 path runs unchanged, and
            # with no chain at all the canned-prior disclosure fires. The
            # (CallOI - PutOI) dealer-sign proxy is disclosed in the response.
            _gex_multi_chains = None
            try:
                _gex_depth = int(working_cfg.get("GEX_EXPIRY_DEPTH", 3) or 1)
            except (TypeError, ValueError):
                _gex_depth = 1
            if _gex_depth > 1 and isinstance(_live_chain, dict) and _live_chain.get("chain_rows"):
                _expiry_list = [str(e) for e in (_live_chain.get("expiry_dates") or []) if e]
                if len(_expiry_list) > 1:
                    _gex_multi_chains = []
                    for _exp in _expiry_list[:_gex_depth]:
                        try:
                            if _exp == str(_live_chain.get("expiry")):
                                _ch = _live_chain
                            else:
                                _ch = fetch_nse_option_chain("NIFTY", expiry=_exp, log_cb=log_cb)
                            if not (isinstance(_ch, dict) and _ch.get("chain_rows")):
                                continue
                            from math_engine.options_hedger import resolve_live_chain_inputs as _rlci
                            _ch_in = _rlci(_ch)
                            _med_iv = _ch.get("median_iv")
                            _iv_fb = (float(_med_iv) / 100.0
                                      if isinstance(_med_iv, (int, float)) and float(_med_iv) > 0
                                      else float((_gex_chain_inputs or {}).get("iv", 0.18)))
                            _gex_multi_chains.append({
                                "frame": pd.DataFrame(_ch["chain_rows"]),
                                "dte_days": int(_ch_in.get("dte_days", 30)),
                                "label": _exp,
                                "iv": _iv_fb,
                            })
                        except Exception as _gme_e:
                            log_emit(log_cb, f"[GEX] Multi-expiry chain {_exp} skipped: {_gme_e}")
                    if len(_gex_multi_chains) < 2:
                        _n_gme = len(_gex_multi_chains)
                        _gex_multi_chains = None
                        log_emit(log_cb, f"[GEX] Only {_n_gme} expiry chain(s) available — single-expiry GEX (disclosed).")
                    else:
                        log_emit(log_cb, f"[GEX] Aggregating {len(_gex_multi_chains)} expiry chains: {', '.join(str(c['label']) for c in _gex_multi_chains)}.")
            _gex_res = _hedger.calculate_net_gamma_exposure(
                option_chain=_gex_chain_df,
                iv=(_gex_chain_inputs or {}).get("iv", 0.18),
                dte_days=(_gex_chain_inputs or {}).get("dte_days", 30),
                iv_source=(_gex_chain_inputs or {}).get("iv_source"),
                dte_source=(_gex_chain_inputs or {}).get("dte_source"),
                multi_expiry_chains=_gex_multi_chains,
            )
            if _gex_chain_df is not None:
                log_emit(log_cb, f"[GEX] Computed from live chain OI ({len(_gex_chain_df)} strikes): net GEX Rs{_gex_res.get('net_gex_rupees', 0):,.0f}, flip {_gex_res.get('gamma_flip_price')} — {_gex_res.get('gamma_model', 'n/a')}.")
            else:
                log_emit(log_cb, "[GEX] Live chain rows unavailable — using fallback estimation (canned positive-GEX prior).")

            # 7. Solvers, Barycenters & Diversification
            from math_engine.entropy_diversification import EntropyDiversificationEngine
            from math_engine.wasserstein_barycenter import WassersteinBarycenterEngine
            from math_engine.stochastic_control_hjb import HJBOptimalControlEngine
            _ent_res = EntropyDiversificationEngine.calculate_effective_assets(weights)
            _hjb_res = HJBOptimalControlEngine.solve_merton_hjb()

            # 8. Capacity, Tax & Multi-Agent Swarm
            from math_engine.aum_capacity import AUMCapacityCalculator
            from ui.trading_desk_swarm import LLMTradingDeskSwarm
            from math_engine.gpu_accelerator import CUDAGPUAccelerator

            _aum_res = AUMCapacityCalculator.calculate_max_aum(weights, signal_df)
            # AUDIT-FIX (Round 22 — R22-2): the previous line here called
            # TaxLossHarvestingOptimizer.identify_harvestable_lots(portfolio_df, {})
            # with an EMPTY current-prices map — with no cost basis and no prices
            # the engine could only ever return an empty result, and the computed
            # _tax_res was never read anywhere (dead decorative call). Removed.
            # The real tax-loss wiring lives in web_dashboard's /api/tax_optimizer,
            # which sources lots from the trade journal's recorded entry prices.
            # AUDIT-FIX (Round 20 — R20-9): the LLM swarm was fed a HARDCODED
            # {"var99_pct": 2.0} regardless of the portfolio's real ex-ante
            # VaR (43%+ in bear profiles) — the "Swarm: PROCEED" verdict was
            # evaluated against fabricated risk inputs. Now the swarm sees the
            # measured ex-ante VaR (when Barra decomposed it), else an honest
            # "unavailable" marker.
            _swarm_var99 = None
            try:
                if risk_attrib.get("ex_ante_var_99"):
                    _swarm_var99 = round(float(risk_attrib["ex_ante_var_99"]) * 100.0, 2)
            except Exception:
                _swarm_var99 = None
            _swarm_inputs = {"var99_pct": _swarm_var99} if _swarm_var99 is not None else {"var99_pct": "unavailable (no Barra ex-ante VaR in this run)"}
            _swarm_res = LLMTradingDeskSwarm.evaluate_trade_consensus(working_cfg.get("STRATEGY_NAME", "QUANT"), list(weights.keys()), _ms_res.get("current_regime", "Bull"), _swarm_inputs)
            # AUDIT-FIX (Round 20 — R20-9): GPU Monte Carlo ran on an IDENTITY
            # covariance (np.eye(n) * 0.0001) — a fabricated uncorrelated,
            # ultra-low-vol universe whose only output was a decorative
            # "gpu_accelerated" flag. Honest skip unless a real covariance is
            # available from the risk decomposition.
            _mc_res = {"gpu_accelerated": False, "note": "skipped — no measured covariance passed (identity-covariance MC removed in Round 20)"}
            try:
                _cov_for_mc = risk_attrib.get("covariance_matrix") if isinstance(risk_attrib, dict) else None
                if _cov_for_mc is not None and hasattr(_cov_for_mc, "shape") and _cov_for_mc.shape[0] == len(weights):
                    _mc_res = CUDAGPUAccelerator().run_monte_carlo_gpu(_pv, np.array(list(weights.values())), np.asarray(_cov_for_mc))
            except Exception as _mc_err:
                log_emit(log_cb, f"[QuantPipeline] GPU Monte Carlo skipped (no real covariance): {_mc_err}")

            payload["quant_suite_diagnostics"] = {
                "regime": _ms_res.get("current_regime"),
                "hurst_exponent": _hurst_val,
                "absorption_ratio": _ar_val,
                "gamma_flip_price": _gex_res.get("gamma_flip_price"),
                "max_aum_inr": _aum_res.get("max_deployable_aum_inr"),
                "n_effective_assets": _ent_res.get("n_effective_assets"),
                "llm_swarm_consensus": _swarm_res.get("consensus_verdict"),
                "gpu_accelerated": _mc_res.get("gpu_accelerated")
            }

            _max_aum = _aum_res.get('max_deployable_aum_inr')
            _aum_str = f"Rs{int(_max_aum):,}" if _max_aum is not None and np.isfinite(_max_aum) else "RsN/A"
            _dsr_val = _dsr_res.get('dsr', float('nan')) if isinstance(_dsr_res, dict) else float('nan')
            if np.isfinite(_dsr_val):
                _dsr_disp = f"{_dsr_val:.1%}"
            elif _inst_dsr.get('deflated_sharpe') is not None and np.isfinite(_inst_dsr.get('deflated_sharpe')):
                _dsr_disp = f"{_inst_dsr['deflated_sharpe']:.2f} (Inst)"
            else:
                _dsr_disp = "N/A"
            # AUDIT-FIX (Round 20 — R20-17): the summary previously showed only
            # the pipeline DSR (e.g. "95.4%") while the independent Inst-DSR
            # gate in the SAME log reported Verdict=FAIL (p>0.20) — two
            # contradictory DSR messages with no reconciliation. The summary
            # now surfaces the Inst-DSR verdict explicitly.
            _inst_dsr_verdict = _inst_dsr.get("verdict") if isinstance(_inst_dsr, dict) else None
            _inst_dsr_tag = f" | Inst-DSR: {_inst_dsr_verdict}" if _inst_dsr_verdict else ""
            # AUDIT-FIX (Round 21 — R21-3): unified canonical market regime + explicit candidate portfolio flow
            _canon_regime = working_cfg.get('_CANONICAL_MARKET_REGIME') or regime_info.get('Regime', 'Sideways')
            _ms_regime = _ms_res.get('current_regime', 'Unknown')
            log_emit(log_cb, f"[QuantPipeline] 100+ Modules Active | Regime: {_canon_regime} (PortFlow: {_ms_regime}) | DSR: {_dsr_disp}{_inst_dsr_tag} | N_eff: {_ent_res.get('n_effective_assets')} | Max AUM: {_aum_str} | Swarm: {_swarm_res.get('consensus_verdict')}")
        except Exception as _pipeline_err:
            log_emit(log_cb, f"[QuantPipeline] Skipped non-fatal step: {_pipeline_err}", exc_info=True)

        # Drawdown circuit breaker — warn if portfolio is in drawdown breach
        if payload["var_cvar_df"] is not None and not payload["var_cvar_df"].empty:
            _max_dd = float(working_cfg.get("MAX_PORTFOLIO_DRAWDOWN_PCT", 15.0))
            _port_equity = (1 + _port_ret_series).cumprod() if len(_port_ret_series) > 0 else pd.Series([1.0])
            _rolling_max = _port_equity.cummax()
            _current_dd  = float((_port_equity.iloc[-1] / _rolling_max.max() - 1) * 100) if len(_port_equity) > 0 else 0.0
            if _current_dd < -_max_dd:
                log_emit(log_cb, f"⚠️ CIRCUIT BREAKER: Historical candidate basket drawdown is {_current_dd:.1f}% from 3y peak (threshold: -{_max_dd:.0f}%) — screening proceeds")
            payload["current_drawdown_pct"] = round(_current_dd, 2)

        _sb = payload["survivorship_bias"]
        if _sb:
            log_emit(log_cb, f"[BIAS] Survivorship bias est.: ~{_sb['AnnualBiasEstimate_pct']:.1f}%/yr "
                     f"(WFO returns overstated by ~{_sb['TotalBiasEstimate_pct']:.1f}% total)")

        # WIRING: Derivatives + Alt Assets + GNN (optional, off by default)
        if working_cfg.get("USE_DERIVATIVES", False) and selected:
            try:
                from math_engine.derivatives import compute_futures_basis
                payload["derivatives"] = {"available": True}
                log_emit(log_cb, "[Derivatives] Options/futures module available")
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                pass
        if working_cfg.get("USE_ALTERNATIVE_ASSETS", False):
            try:
                from math_engine.alternative_assets import COMMODITIES, CURRENCIES, BONDS
                payload["alternative_assets"] = {"commodities": list(COMMODITIES.keys()), "currencies": list(CURRENCIES.keys()), "bonds": list(BONDS.keys())}
                log_emit(log_cb, "[AltAssets] Multi-asset support available")
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                pass
        if working_cfg.get("USE_ADVANCED_ML", False) and selected and len(selected) >= 5:
            try:
                from ml_alpha.advanced_ml import StockCorrelationGraph, granger_causality_test, SimpleRLAgent
                _safe_graph_sel = [c for c in selected if c in clean_returns.columns] if clean_returns is not None else []
                _ret_graph = clean_returns[_safe_graph_sel].dropna() if _safe_graph_sel else pd.DataFrame()
                if not _ret_graph.empty and len(_ret_graph) > 30:
                    _corr_graph.build_graph(_ret_graph)
                    payload["correlation_graph"] = {"clusters": _corr_graph.detect_clusters(), "central_stocks": _corr_graph.find_central_stocks(top_k=5)}
                    log_emit(log_cb, f"[GNN] Correlation graph built")
                if working_cfg.get("USE_RL_REBALANCE", False) and len(selected) >= 3:
                    _rl = SimpleRLAgent(n_assets=len(selected))
                    log_emit(log_cb, "[RL] Agent evaluated portfolio")
            except Exception as _adv_exc:
                import logging as _alg
                _alg.getLogger("quantum_annealer").debug("[AdvML] GNN/RL feature unavailable: %s", _adv_exc)

        # ── Options Tail-Hedging & Hawkes Jump Detection ──
        # AUDIT-FIX (defect #P0-4): the prior implementation fed the same cached
        # `benchmark_returns` series to all 5 profiles in a sweep and used a
        # hardcoded NIFTY_PRICE=24000 default, which produced the canned
        # n*=1.74 + "two lots of NIFTY 22800 puts" hedge recommendation in every
        # profile's log. We now (a) slice the benchmark per profile's
        # HAWKES_LOOKBACK_DAYS so two profiles no longer get byte-identical
        # inputs, and (b) wire the real NIFTY spot from the close frame (with
        # the previous 24000 fallback only used when the close frame is empty).
        try:
            from math_engine.hawkes_detector import HawkesJumpDetector
            from math_engine.options_hedger import OptionsTailHedger
            _hawkes = HawkesJumpDetector()
            _hawkes_lookback = int(working_cfg.get("HAWKES_LOOKBACK_DAYS", 252))
            if benchmark_returns is not None and not benchmark_returns.empty:
                _bench_series = benchmark_returns.tail(_hawkes_lookback)
            elif returns is not None and not returns.empty:
                _bench_series = returns.mean(axis=1).tail(_hawkes_lookback)
            else:
                _bench_series = None
            if _bench_series is None or len(_bench_series) < 30:
                # AUDIT-FIX (defect #P0-4): fail loudly when the benchmark is
                # too stale or short to support a Hawkes fit — previously the
                # downstream code produced a canned 1.74 n* and a hardcoded
                # hedge recommendation regardless.
                log_emit(log_cb, "[Hawkes] Insufficient benchmark history for fit — skipping jump-intensity analysis and options hedge recommendation.")
                payload["options_hedge_recommendation"] = {"hedging_required": False, "summary": "Skipped: insufficient benchmark history for Hawkes fit."}
                payload["hawkes_jump_analysis"] = {"branching_ratio": float("nan"), "reason": "Insufficient benchmark history"}
            else:
                _hawkes_res = _hawkes.fit_predict(_bench_series)
                _r_label = working_cfg.get("_REGIME_INFO", {}).get("Regime", "Neutral")

                # AUDIT-FIX (defect #P0-4): resolve NIFTY spot from the real
                # close frame where available — the GEX block above already
                # computes `_nifty_price`; reuse it if set, else read from the
                # close frame, else fall back to the cfg value (with an
                # explicit log so the operator sees when the fallback fires).
                _resolved_nifty_price = None
                try:
                    if "_nifty_price" in dir() and _nifty_price:
                        _resolved_nifty_price = float(_nifty_price)
                    elif signal_df is not None and "NIFTY" in (signal_df.index if hasattr(signal_df, "index") else []):
                        _resolved_nifty_price = float(signal_df.loc["NIFTY", "close"])
                    elif working_cfg.get("NIFTY_PRICE"):
                        _resolved_nifty_price = float(working_cfg["NIFTY_PRICE"])
                        log_emit(log_cb, f"[Hawkes] NIFTY spot not in close frame — falling back to cfg NIFTY_PRICE={_resolved_nifty_price:.2f}")
                except Exception:
                    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                    _resolved_nifty_price = None
                if _resolved_nifty_price is None:
                    _resolved_nifty_price = 24000.0
                    log_emit(log_cb, "[Hawkes] NIFTY spot unresolvable — falling back to 24000.0 default (hedge strike will be 22800)")

                # AUDIT-FIX (Round 23 — R23-1): wire the live option chain's
                # median IV + expiry (and spot, when the GEX block's fetch
                # succeeded) into the hedge so deltas are regime-accurate
                # instead of policy-flat 18%/30d. The chain fetch is cached
                # (5-min positive / 120s negative), so the second lookup in
                # this block is free when the GEX block already fetched it,
                # and an offline network degrades to the disclosed policy
                # defaults rather than blocking the sweep.
                _tail_chain = None
                try:
                    if isinstance(_live_chain, dict):
                        _tail_chain = _live_chain
                    else:
                        from data_layer import fetch_nse_option_chain
                        _tail_chain = fetch_nse_option_chain("NIFTY", log_cb=log_cb)
                except Exception:
                    _tail_chain = None
                from math_engine.options_hedger import resolve_live_chain_inputs
                _chain_inputs = resolve_live_chain_inputs(_tail_chain)
                try:
                    if _chain_inputs.get("spot"):
                        # live chain spot is fresher than the close-frame spot
                        _resolved_nifty_price = float(_chain_inputs["spot"])
                        log_emit(log_cb, f"[Hawkes] Using live NSE option-chain spot {_resolved_nifty_price:.1f} for hedge strikes.")
                except Exception:
                    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                log_emit(log_cb, f"[OptionsHedge] IV: {_chain_inputs['iv_source']} | DTE: {_chain_inputs['dte_source']}")

                # AUDIT-FIX (Round 23 — R23-3): disclosed beta floor for
                # illiquid/microcap baskets whose trailing 63d betas regress
                # to ~0 (hedge size silently collapsed otherwise) + Barra
                # factor-model portfolio beta as a cross-check reference.
                _tail_beta_floor = float(working_cfg.get("TAIL_HEDGE_BETA_FLOOR", 0.30))
                _barra_beta_for_hedge = None
                try:
                    _bb = risk_attrib.get("portfolio_beta") if isinstance(risk_attrib, dict) else None
                    if _bb is not None and np.isfinite(float(_bb)):
                        _barra_beta_for_hedge = float(_bb)
                except Exception:
                    _barra_beta_for_hedge = None

                _moe_diag = working_cfg.get("_REGIME_ENSEMBLE_DIAG", {})
                _moe_regime = str(_moe_diag.get("macro_regime", "")).lower()
                _live_vix = float(working_cfg.get("_INDIA_VIX", 0.0) or 0.0)
                _is_stress = ("crash" in _moe_regime or "stress" in _moe_regime or _live_vix >= 22.0)
                _effective_hedge_regime = "Bear" if _is_stress else _r_label
                _hawkes_trigger = bool(_hawkes_res.get("regime_transition_warning", False) or (_is_stress and _live_vix >= 24.0))

                _hedger = OptionsTailHedger(nifty_price=_resolved_nifty_price)
                _hedge_res = _hedger.calculate_hedge_recommendation(
                    portfolio_df=portfolio_df,
                    portfolio_value=float(working_cfg.get("PORTFOLIO_VALUE", 1000000.0)),
                    regime=_effective_hedge_regime,
                    hawkes_warning=_hawkes_trigger,
                    iv=_chain_inputs["iv"],
                    dte_days=_chain_inputs["dte_days"],
                    iv_source=_chain_inputs["iv_source"],
                    dte_source=_chain_inputs["dte_source"],
                    beta_floor=_tail_beta_floor,
                    barra_portfolio_beta=_barra_beta_for_hedge,
                )
                payload["options_hedge_recommendation"] = _hedge_res
                payload["hawkes_jump_analysis"] = _hawkes_res
                # AUDIT-FIX (Round 23 — R23-3): surface the beta-floor/Barra
                # cross-check in the log so a floored hedge basis is visible
                # at the operator console, not buried in the payload.
                if _hedge_res.get("beta_floor_applied_to"):
                    log_emit(log_cb, f"[OptionsHedge] Beta floor {_tail_beta_floor:.2f} applied to {len(_hedge_res['beta_floor_applied_to'])} illiquid/low-beta row(s): {', '.join(_hedge_res['beta_floor_applied_to'][:8])}{'…' if len(_hedge_res['beta_floor_applied_to']) > 8 else ''}")
                if _barra_beta_for_hedge is not None:
                    log_emit(log_cb, f"[OptionsHedge] Barra cross-check: portfolio beta {_barra_beta_for_hedge:.3f} vs hedge beta basis {_hedge_res.get('portfolio_beta_weighted_delta')}.")
                if _hawkes_res.get("regime_transition_warning"):
                    log_emit(log_cb, f"🚨 [Hawkes Jump Warning] Super-critical jump clustering (n*={_hawkes_res.get('branching_ratio',0):.2f}) -> {_hedge_res.get('summary','')}")
                elif _hedge_res.get("hedging_required"):
                    log_emit(log_cb, f"🛡️ [Options Tail Hedge] {_hedge_res.get('summary','')}")
        except Exception as _he:
            log_emit(log_cb, f"[OptionsHedge] skipped: {_he}", exc_info=True)

        # ── OOS Walk-Forward Selection-Bias Diagnostics ──
        # AUDIT-FIX (Round 23 — R23-4): the R20-R22 rounds labeled the
        # retroactive-basket problem honestly but never MEASURED it per run.
        # These diagnostics quantify (a) how much of the final basket would
        # have been selected point-in-time at K historical cutoffs (overlap)
        # and (b) whether the basket's alpha is concentrated in a single
        # fold. They do NOT re-select — the full walk-forward re-selection
        # remains the documented structural residual (runtime x n_folds).
        try:
            from math_engine.oos_walkforward import (
                walk_forward_selection_overlap, fold_alpha_concentration,
            )
            _wf_overlap = walk_forward_selection_overlap(
                close_df=(close if close is not None and not close.empty else None),
                selected=[s for s in (selected or []) if s != "CASH"],
                n_folds=int(working_cfg.get("WFO_DIAG_FOLDS", 6)),
                mom_lookback=int(working_cfg.get("WFO_DIAG_MOM_LOOKBACK", 126)),
            )
            _wf_alpha = fold_alpha_concentration(
                _port_ret_series,
                (benchmark_returns if benchmark_returns is not None and not benchmark_returns.empty
                 else (_bench_series if "_bench_series" in dir() and _bench_series is not None else None)),
                n_folds=int(working_cfg.get("WFO_DIAG_FOLDS", 6)),
            )
            payload["oos_walkforward_diagnostics"] = {
                "selection_overlap": _wf_overlap,
                "fold_alpha": _wf_alpha,
            }
            _ov = _wf_overlap.get("mean_overlap_pct")
            _ov_str = f"{_ov:.0f}%" if isinstance(_ov, (int, float)) else "n/a"
            log_emit(log_cb, (
                f"[WFO-Diag] Point-in-time basket overlap: {_ov_str} "
                f"({_wf_overlap.get('retroactive_basket_risk', 'n/a')}) | "
                f"alpha concentration: {_wf_alpha.get('alpha_concentration_verdict', 'n/a')}"
            ))
        except Exception as _wf_e:
            log_emit(log_cb, f"[WFO-Diag] Walk-forward diagnostics skipped: {_wf_e}", exc_info=True)

        # ── Full Walk-Forward RE-SELECTION (true-OOS alpha) ──
        # AUDIT-FIX (Round 24 — R24-1): R23-4 measured the retroactive-basket
        # bias but no reported number eliminated it. This block re-runs the
        # SCREEN point-in-time at each of K cutoffs (the same mode-weighted
        # prescreen scoring on trailing data only), holds the point-in-time
        # top-K basket to the next cutoff with turnover costs, and reports a
        # TRUE-OOS alpha with zero selection-layer look-ahead, plus the
        # measured bias vs the run's headline alpha.
        #
        # AUDIT-FIX (Round 25 — R25-1): the ALLOCATION layer is replayed per
        # cutoff now — the production QUBO's core objective (alpha/vol/
        # correlation/cardinality on trailing data, greedy + local search)
        # selects each fold's basket and the PRODUCTION HRP weights it, with
        # the run's working_cfg supplying the QUBO/weight-bound coefficients
        # (allocation_cfg) and the HRP lookback (WFO_HRP_LOOKBACK, default
        # 63d). An inverse-vol reference series is reported alongside so the
        # allocation-layer effect is MEASURED. The TOP_N pool prescreen is
        # replayed point-in-time too when WFO_POOL_FULL_UNIVERSE (default
        # False, opt-in: it re-downloads a supersample frame larger than the
        # pool) — otherwise the in-memory pool frame is inherited and the
        # pool-membership leak stays disclosed. AUDIT-FIX (Round 27 — R27-1):
        # the live-data layer replay is now REAL per cutoff — the QUBO penalty
        # layers (beta/turnover/Barra/DRO) on trailing data plus the same-
        # sector off-diagonal penalty when the sector map is supplied; ML-alpha
        # / the blackout calendar / the weighting stack above HRP replay only
        # when point-in-time inputs exist (the sweep has none of them: final-
        # model scores and now-only feeds are not point-in-time) — the
        # payload's replay_scope + method_disclosure enumerate the per-run
        # status layer by layer.
        try:
            if working_cfg.get("WFO_FULL_RESELECTION", True):
                from math_engine.oos_walkforward import walk_forward_reselection_backtest
                _retro_alpha = None
                if isinstance(backtest, dict) and backtest.get("Alpha vs Benchmark") is not None:
                    try:
                        _ra = float(backtest["Alpha vs Benchmark"])
                        _retro_alpha = _ra if np.isfinite(_ra) else None
                    except (TypeError, ValueError):
                        _retro_alpha = None
                # R25-1: frames the re-selection replays. Default: the sweep's
                # own pool frames (the TOP_N cut on the full lookback — pool
                # membership inherited, disclosed). Opt-in WFO_POOL_FULL_UNIVERSE
                # re-downloads a SUPERSAMPLE frame from the pre-cut prescreen
                # ranking so the TOP_N pool cut itself is replayed point-in-time.
                _wfr_close = (close if close is not None and not close.empty else None)
                _wfr_volume = (volume if volume is not None and not volume.empty else None)
                _wfr_pool = None
                if working_cfg.get("WFO_POOL_FULL_UNIVERSE", False):
                    try:
                        _sup_n = int(working_cfg.get("WFO_POOL_SUPERSAMPLE_N", 250) or 250)
                        _sup_tickers = []
                        try:
                            if prescreen_df is not None and "ticker" in prescreen_df.columns:
                                _sup_tickers = [str(t) for t in prescreen_df["ticker"].tolist()][:_sup_n]
                        except Exception:
                            _sup_tickers = []
                        _pool_names = {str(c).upper() for c in (close.columns if close is not None else [])}
                        if len(_sup_tickers) > len(_pool_names) and len(_sup_tickers) >= max(20, 2 * len(_pool_names) // 3):
                            _dl_sup = _download_ohlcv_bundle(
                                _sup_tickers, int(working_cfg.get("LOOKBACK_DOWNLOAD", 504) or 504),
                                log_cb=log_cb,
                            )
                            _sup_close, _sup_volume = _dl_sup["Close"], _dl_sup["Volume"]
                            from utils import clean_market_panels as _cmp_sup
                            _sup_close, _sup_volume, _sup_returns = _cmp_sup(_sup_close, _sup_volume, 2)
                            if (not _sup_close.empty and _sup_close.shape[1] > (close.shape[1] if close is not None else 0)):
                                _wfr_close = _sup_close
                                _wfr_volume = (None if _sup_volume is None or _sup_volume.empty else _sup_volume)
                                _wfr_pool = int(working_cfg.get("TOP_N_UNIVERSE", 100) or 100)
                                log_emit(log_cb, (
                                    f"[WFO-ReSel] Pool supersample: {len(_sup_tickers)} ranked tickers re-downloaded — "
                                    f"the TOP_N pool cut ({_wfr_pool}) is replayed point-in-time per cutoff."))
                            else:
                                log_emit(log_cb, "[WFO-ReSel] Pool supersample produced no larger frame — inheriting the in-memory pool (disclosed).")
                        else:
                            log_emit(log_cb, "[WFO-ReSel] Pool supersample skipped (prescreen ranking not larger than the pool) — inheriting the in-memory pool (disclosed).")
                    except Exception as _sup_e:
                        log_emit(log_cb, f"[WFO-ReSel] Pool supersample failed ({_sup_e}) — inheriting the in-memory pool (disclosed).")
                # AUDIT-FIX (Round 29 — R29-4a): the HISTORICAL BLACKOUT CALENDAR
                # auto-load — the R29-1 artifact (qa_db/earnings_calendar_history.json,
                # built by scripts/build_earnings_calendar.py from the vendor's
                # HISTORICAL earnings dates) supplies the caller-side calendar the
                # R27-1 blackout replay was designed for. Skip-if-absent (the FMV
                # feed contract): no file -> blackouts stay not-replayed, disclosed.
                _blackouts_by_symbol = None
                _calendar_summary = None
                try:
                    from math_engine.oos_walkforward import load_blackout_calendar_file
                    _frame_syms = ([str(c) for c in _wfr_close.columns]
                                   if _wfr_close is not None and not _wfr_close.empty else [])
                    _blackouts_by_symbol = load_blackout_calendar_file(symbols=_frame_syms)
                    if _blackouts_by_symbol:
                        _n_cal_events = sum(len(v) for v in _blackouts_by_symbol.values())
                        _calendar_summary = {
                            "source": ("qa_db/earnings_calendar_history.json (R29-1: yfinance "
                                       "historical earnings dates, ET->IST calendar dates)"),
                            "symbols_with_events_in_pool": len(_blackouts_by_symbol),
                            "pool_symbols": len(_frame_syms),
                            "pool_coverage_pct": round(
                                100.0 * len(_blackouts_by_symbol) / max(1, len(_frame_syms)), 1),
                            "events_available": int(_n_cal_events),
                            "convention": ("IST calendar date of the announcement timestamp; "
                                           "+/- EARNINGS_BLACKOUT_DAYS window"),
                        }
                        log_emit(log_cb, (
                            f"[WFO-ReSel] Blackout calendar auto-loaded: {len(_blackouts_by_symbol)}/"
                            f"{len(_frame_syms)} pool symbols with events ({_n_cal_events} dates) — "
                            f"blackouts now REPLAYED per cutoff (was: not-replayed, now-only feeds)."))
                    else:
                        log_emit(log_cb, "[WFO-ReSel] Blackout calendar absent/empty for this pool — blackouts NOT replayed (disclosed).")
                except Exception as _cal_e:
                    log_emit(log_cb, f"[WFO-ReSel] Blackout calendar load failed ({_cal_e}) — NOT replayed (disclosed).")
                # AUDIT-FIX (Round 29 — R29-4b): the PER-CUTOFF ML RETRAINING
                # path — opt-in WFO_ML_REPLAY_RETRAIN (default False: the
                # disclosed-not-replayed steady state is unchanged). When on,
                # the production-shaped walk-forward driver (R29-3) refits an
                # AlphaEnsemble per cutoff on STRICTLY trailing purified data
                # and supplies point-in-time scores + per-cutoff DSR to the
                # R27-1 injection gate. Runtime x K — disclosed per run.
                _ml_alpha_by_cutoff = None
                _ml_dsr_by_cutoff = None
                _ml_replay_prov = None
                if working_cfg.get("WFO_ML_REPLAY_RETRAIN", False) and _wfr_close is not None and not _wfr_close.empty:
                    try:
                        from math_engine.oos_walkforward import reselect_cutoff_positions
                        from ml_alpha.walkforward_replay_scores import compute_ml_scores_by_cutoff
                        _wfo_folds = int(working_cfg.get("WFO_RESELECT_FOLDS", 4))
                        _wfo_lookback = int(working_cfg.get("WFO_RESELECT_SCORE_LOOKBACK", 126))
                        _cut_pos = reselect_cutoff_positions(len(_wfr_close.index), _wfo_lookback, _wfo_folds)
                        _cut_dates = [_wfr_close.index[p] for p in _cut_pos if p < len(_wfr_close.index)]
                        if _cut_dates:
                            _ml_alpha_by_cutoff, _ml_dsr_by_cutoff, _ml_replay_prov = compute_ml_scores_by_cutoff(
                                _wfr_close, _wfr_volume, _cut_dates,
                                benchmark_returns=(benchmark_returns if benchmark_returns is not None and not benchmark_returns.empty else None),
                                cfg=working_cfg, log_cb=log_cb)
                            _ml_replay_prov["runtime_note"] = (
                                f"walk-forward refit x {len(_cut_dates)} cutoffs (runtime x K, "
                                "opt-in WFO_ML_REPLAY_RETRAIN)")
                            log_emit(log_cb, (
                                f"[WFO-ReSel] ML replay retraining: {len(_ml_alpha_by_cutoff)}/{len(_cut_dates)} "
                                f"cutoffs scored point-in-time; DSR gate applies per cutoff "
                                f"(detail: oos_walkforward_reselection.ml_replay_provenance)."))
                        else:
                            log_emit(log_cb, "[WFO-ReSel] ML replay retraining: no valid cutoffs on the frame — NOT replayed (disclosed).")
                    except Exception as _mlr_e:
                        _ml_alpha_by_cutoff = _ml_dsr_by_cutoff = _ml_replay_prov = None
                        log_emit(log_cb, f"[WFO-ReSel] ML replay retraining failed ({_mlr_e}) — NOT replayed (disclosed).")
                _wfr = walk_forward_reselection_backtest(
                    close_df=_wfr_close,
                    volume_df=_wfr_volume,
                    n_folds=int(working_cfg.get("WFO_RESELECT_FOLDS", 4)),
                    score_lookback=int(working_cfg.get("WFO_RESELECT_SCORE_LOOKBACK", 126)),
                    k_stocks=int(working_cfg.get("K_STOCKS", 10) or 10),
                    mode=str(working_cfg.get("PRESCREEN_MODE", "balanced")),
                    benchmark_returns=(benchmark_returns if benchmark_returns is not None and not benchmark_returns.empty else None),
                    fee_bps=float(working_cfg.get("BACKTEST_FEE_BPS", 15.0)) + float(working_cfg.get("BACKTEST_SLIPPAGE_BPS", 5.0)),
                    selected_final=[s for s in (selected or []) if s != "CASH"],
                    retroactive_alpha_ann=_retro_alpha,
                    # R25-1: the ALLOCATION layer replay
                    replay_allocation=True,
                    allocation_cfg=working_cfg,
                    hrp_lookback=int(working_cfg.get("WFO_HRP_LOOKBACK", 63) or 63),
                    top_n_pool=_wfr_pool,
                    # AUDIT-FIX (Round 27 — R27-1 / Round 29 — R29-4): the live-data
                    # layer replay inputs the sweep CAN supply — the sector map
                    # (same-sector off-diagonal penalty, gated by ENABLE_SECTOR_CAP
                    # exactly like build_qubo), the blackout window width, the
                    # R29-1 historical blackout calendar (auto-loaded above), and —
                    # under the opt-in WFO_ML_REPLAY_RETRAIN — the R29-3 per-cutoff
                    # point-in-time ML scores + DSR. Absent inputs stay
                    # not-replayed, disclosed per run via replay_scope.
                    sectors=(sectors if isinstance(sectors, dict) and sectors else None),
                    blackouts_by_symbol=_blackouts_by_symbol,
                    blackout_window_days=int(working_cfg.get("EARNINGS_BLACKOUT_DAYS", 5) or 5),
                    ml_alpha_by_cutoff=_ml_alpha_by_cutoff,
                    ml_dsr_by_cutoff=_ml_dsr_by_cutoff,
                )
                payload["oos_walkforward_reselection"] = _wfr
                # R29-4: attach the per-run calendar-coverage + ML-replay
                # provenance to the payload (the replay's own method_disclosure
                # carries the layer-level status; these carry the source detail).
                if isinstance(_wfr, dict):
                    if _calendar_summary is not None:
                        _wfr["blackout_calendar"] = _calendar_summary
                    if _ml_replay_prov is not None:
                        _wfr["ml_replay_provenance"] = _ml_replay_prov
                _ta = _wfr.get("true_oos_annualized_alpha_pct")
                _ta_str = f"{_ta:+.1f}% ann." if isinstance(_ta, (int, float)) else "n/a"
                _bias = _wfr.get("retroactive_basket_bias_pct")
                _bias_str = f"{_bias:+.1f}pp" if isinstance(_bias, (int, float)) else "n/a"
                _alloc_eff = _wfr.get("allocation_layer_effect_pct")
                _alloc_str = f"{_alloc_eff:+.1f}pp" if isinstance(_alloc_eff, (int, float)) else "n/a"
                # R27-1: log the per-run replayed-layer summary (the payload's
                # replay_scope + method_disclosure carry the full detail).
                _rs = _wfr.get("replay_scope") or {}
                _rs_replayed = [k for k, v in _rs.items()
                                if isinstance(v, dict) and v.get("replayed")]
                log_emit(log_cb, (
                    f"[WFO-ReSel] Full walk-forward RE-SELECTION ({_wfr.get('n_folds')} cutoffs, "
                    f"{_wfr.get('oos_days', 0)} OOS days): true-OOS alpha {_ta_str} vs headline "
                    f"(retroactive) alpha — measured selection bias {_bias_str} | allocation-layer "
                    f"effect (QUBO-core + HRP replay vs inverse-vol reference) {_alloc_str} | "
                    f"replayed layers: {', '.join(_rs_replayed) if _rs_replayed else 'none'} "
                    f"(detail: oos_walkforward_reselection.replay_scope) | "
                    f"{_wfr.get('verdict')}"
                ))
        except Exception as _wfr_e:
            log_emit(log_cb, f"[WFO-ReSel] Re-selection backtest skipped: {_wfr_e}", exc_info=True)

        # Run Pre-Trade Compliance Checks (Citadel Phase 1)
        # AUDIT-FIX (defect #15): the prior compliance gate validated position
        # weights and SEBI limits but never checked whether the run itself was
        # even meaningful. The August 22 audit dump showed a 100%-cash run
        # (zero screened universe, NaN regime, all-NaN regime inputs) clearing
        # "All pre-trade compliance checks passed" — the safety gate was wired
        # backwards (a degenerate run that should fail was reported as success).
        # We now perform an explicit data-quality gate BEFORE the compliance
        # engine: any of (empty screened universe, NaN regime, all-NaN regime
        # inputs, 100% cash allocation with no real holdings, empty selected
        # list) raises ComplianceViolationError so the orchestrator sees a
        # hard stop instead of a "PROCEED" verdict on a degenerate run.
        if working_cfg.get("USE_DATA_QUALITY_GATE", True):
            _dq_reasons = []
            _screened_payload = base_payload.get("screened", []) or []
            _screened_count = len(_screened_payload)
            if _screened_count == 0:
                _dq_reasons.append("screened universe is empty (0 candidates survived prescreen)")
            if not selected:
                _dq_reasons.append("QUBO selected-positions list is empty (degenerate allocation)")
            # Regime NaN check
            try:
                _ri = regime_info or {}
                _ri_probs = [v for k, v in _ri.items() if k in ("P_Bull", "P_Bear", "P_Sideways") and isinstance(v, (int, float))]
                if _ri_probs and any(pd.isna(v) or v != v for v in _ri_probs):
                    _dq_reasons.append(f"regime model produced NaN probabilities: {_ri}")
                if not _ri:
                    _dq_reasons.append("regime_info payload is empty (regime detector produced no output)")
            except Exception as _re:
                _dq_reasons.append(f"regime_info inspection failed: {_re}")
            # 100% cash check
            try:
                if weights and isinstance(weights, dict):
                    _non_cash_w = sum(w for t, w in weights.items() if str(t).upper() != "CASH")
                    _cash_w = float(weights.get("CASH", 0.0))
                    if _non_cash_w <= 1e-9 and _cash_w >= 0.999:
                        _dq_reasons.append(f"allocation is 100% cash ({_cash_w*100:.1f}% to CASH) — degenerate run")
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                pass
            if _dq_reasons:
                # R34-4 FIX: distinguish an INTENTIONAL defensive halt (the
                # stale-regime Staleness Flatten — an explicit risk decision,
                # see cfg["_DEFENSIVE_FLAT"] set in build_qubo) from an
                # accidental degenerate run. Both still hard-stop BEFORE the
                # compliance engine (the August-22 audit defect #15 contract:
                # a no-trade run must never be reported as compliance-passed),
                # but the intentional case gets a distinct, actionable halt
                # message instead of a misleading generic "degenerate" error.
                _flat = working_cfg.get("_DEFENSIVE_FLAT") or {}
                _flat_explains_all = bool(_flat) and all(
                    ("selected-positions list is empty" in r) or ("100% cash" in r)
                    for r in _dq_reasons
                )
                if _flat_explains_all:
                    _dq_msg = (
                        "REGIME-STALENESS DEFENSE (intentional 100% cash — no trades): the HMM "
                        f"regime model was stale (Reason={_flat.get('reason', 'hmm_stale_retrain_failed')}) "
                        "and the inline R34-1 retrain could not complete, so the Staleness Flatten "
                        "returned an empty target portfolio. Remediation: (1) the web dashboard's "
                        "background regime refresher will retry automatically — restart it with network "
                        "access; (2) re-run the optimizer (the run itself retrains the HMM inline when "
                        "benchmark data is available); or (3) run scripts/nightly_regime_refresher.py. "
                        "The data-quality gate halted this run BEFORE compliance so a no-trade allocation "
                        "is never reported as compliance-passed; no OOS metrics were persisted."
                    )
                else:
                    _dq_msg = " | ".join(_dq_reasons)
                log_emit(log_cb, f"⛔ [DataQualityGate] Run aborted before compliance check: {_dq_msg}")
                try:
                    from utils import ComplianceViolationError as _CVE
                except Exception:
                    # AUDIT-FIX (Round 4 — W0719): fallback to plain Exception
                    # is intentional — if the import fails we still need to
                    # raise *something* to abort the run, and a generic
                    # Exception is the only universally-available option.
                    # pylint: disable=broad-exception-raised
                    _CVE = Exception
                # AUDIT-FIX (Round 4 — W0719): _CVE may be plain Exception
                # if the named import failed above; that's the deliberate
                # fallback so the data-quality gate can still abort the run.
                # pylint: disable=broad-exception-raised
                raise _CVE(f"Data-quality gate halted run: {_dq_msg}")

        if working_cfg.get("USE_COMPLIANCE_CHECK", True):
            try:
                from utils import ComplianceEngine
                # FIX: ComplianceEngine previously read COMPLIANCE_MAX_POSITION /
                # COMPLIANCE_MAX_SECTOR independently of the per-profile MAX_WEIGHT /
                # SECTOR_LIMIT already applied by apply_two_pass_clipping() above —
                # meaning a profile with an intentionally higher concentration tier
                # (e.g. Max Alpha's 50% single-stock design) would still get falsely
                # flagged against a generic 10% default. Sync them so both checks
                # agree on the same real limit for this profile.
                _compliance_cfg = dict(working_cfg)
                _compliance_cfg["COMPLIANCE_MAX_POSITION"] = _max_stock_cap
                _compliance_cfg["COMPLIANCE_MAX_SECTOR"] = _max_sector_cap
                compliance_eng = ComplianceEngine(_compliance_cfg)

                # Build temporary portfolio_df for compliance check
                port_rows = []
                for t, w in weights.items():
                    if t.upper() != "CASH":
                        port_rows.append({"Ticker": t, "Weight": w})
                comp_port_df = pd.DataFrame(port_rows)

                violations = compliance_eng.check(comp_port_df, signal_df, sectors)
                if violations:
                    log_emit(log_cb, "⚠️ [Compliance] Pre-Trade Compliance violations detected:")
                    for v in violations:
                        log_emit(log_cb, f"  - [{v['severity']}] {v['rule']} for {v['ticker']}: {v['message']} (Value: {v['value']}, Limit: {v['limit']})")

                    # FIX: previously these violations were logged and then IGNORED —
                    # the run proceeded straight to FlightServer registration and
                    # distribution regardless of severity. Now: re-apply the same
                    # two-pass clip as a hard corrective pass (catches drift from
                    # LotSize rounding or any other post-clip weight change), then
                    # re-check. Any violation that survives a second clip pass
                    # (e.g. a BANNED_SECURITY that clipping can't fix) halts
                    # distribution rather than silently shipping a breach.
                    weights = apply_two_pass_clipping(weights, sectors, max_stock=_max_stock_cap, max_sector=_max_sector_cap)
                    port_rows = [{"Ticker": t, "Weight": w} for t, w in weights.items() if t.upper() != "CASH"]
                    comp_port_df = pd.DataFrame(port_rows)
                    remaining_violations = compliance_eng.check(comp_port_df, signal_df, sectors)
                    hard_blocks = [v for v in remaining_violations if v["severity"] in ("BLOCK", "BREACH")]
                    if hard_blocks:
                        for v in hard_blocks:
                            log_emit(log_cb, f"  - [UNRESOLVED {v['severity']}] {v['rule']} for {v['ticker']}: {v['message']}")
                        log_emit(log_cb, "⛔ [Compliance] Violations remain after corrective re-clip. Halting distribution for this profile.")
                        raise ComplianceViolationError(
                            f"Pre-trade compliance violations remain after corrective clipping: {hard_blocks}"
                        )
                    else:
                        log_emit(log_cb, "✅ [Compliance] Corrective re-clip resolved all violations. Proceeding with compliant weights.")
                else:
                    log_emit(log_cb, "✅ [Compliance] All pre-trade compliance checks passed successfully.")
            except ComplianceViolationError:
                raise
            except Exception as _ce:
                log_emit(log_cb, f"[Compliance] Warning: Compliance validation skipped: {_ce}", exc_info=True)

        # Register datasets on Flight Server (Citadel Phase 2)
        if _ACTIVE_FLIGHT_SERVER is not None:
            try:
                if signal_df is not None and not signal_df.empty:
                    _ACTIVE_FLIGHT_SERVER.register_dataset("signals", signal_df)
                if portfolio_df is not None and not portfolio_df.empty:
                    _ACTIVE_FLIGHT_SERVER.register_dataset("portfolio", portfolio_df)
                log_emit(log_cb, "[FlightServer] Successfully registered active 'signals' and 'portfolio' datasets.")
            except Exception as _fe_reg:
                log_emit(log_cb, f"[FlightServer] Warning: failed to register datasets on Flight server: {_fe_reg}", exc_info=True)

        progress_span(progress_cb, 98, 100, 1, 1)
        payload["runtime_sec"] = (datetime.now() - start).total_seconds()
        log_emit(log_cb, f"Completed in {payload['runtime_sec']:.2f}s")
        return payload
    finally:
        with _ACTIVE_STOP_EVENT_LOCK:
            _ACTIVE_STOP_EVENT.clear_event()




# ────────────────────────────────────────────────────────────────────
# FUNC: _export_table
# ────────────────────────────────────────────────────────────────────
def _export_table(tbl, filename, status_lbl):
    try:  # DIV001: guard divisor before use
        import csv
        from pathlib import Path
        out = Path.home() / filename
        with open(out, 'w', newline='', encoding='utf-8') as f:
            w = csv.writer(f)
            headers = [tbl.horizontalHeaderItem(c).text()
                       for c in range(tbl.columnCount())]
            w.writerow(headers)
            for r in range(tbl.rowCount()):
                w.writerow([tbl.item(r,c).text() if tbl.item(r,c) else ''
                            for c in range(tbl.columnCount())])
        status_lbl.setText(f"Exported → {out}")
    except Exception as e:
        status_lbl.setText(f"Export error: {e}")


# ─── TAB 358 ──────────────────────────────────────────────────────────────────

# AUDIT-FIX (Round 3, P2-4 follow-up): inject parent god file's globals into
# the extracted sub-module so its function bodies can reference names like
# `log_emit`, `ExceptionLogger`, `DEFAULT_CFG`, etc. that are defined later
# in this file. This is a no-op if the sub-module wasn't loaded yet.
import sys as _inject_sys
_inject_target = _inject_sys.modules.get("optimizer_broker")
if _inject_target is not None:
    for _inject_k, _inject_v in list(globals().items()):
        if _inject_k.startswith("__"):
            continue
        if _inject_k in ("_inject_sys", "_inject_target", "_inject_k", "_inject_v"):
            continue
        try:
            if _inject_k not in _inject_target.__dict__:
                setattr(_inject_target, _inject_k, _inject_v)
        except Exception:
            pass
# AUDIT-FIX (Round 4): only delete names that are guaranteed defined.
# `_inject_k` and `_inject_v` are loop variables — if the for-loop body
# never executes (empty globals), they would be undefined here and `del`
# would raise NameError. Drop them from cleanup; Python's GC handles them.
try:
    del _inject_sys, _inject_target
except NameError:
    pass
