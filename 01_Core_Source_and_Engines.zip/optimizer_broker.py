"""
optimizer_broker.py — Broker order routing + order-sheet generation
==========================================================================

AUDIT-FIX (Round 3, P2-4): extracted from optimizer.py (originally ~250 LOC
of broker routing + ~150 LOC of order-sheet CSV generators + the
ComplianceViolationError exception + compute_dynamic_trade_levels +
calculate_volume_profile_nodes helper).

This module groups every external-broker interaction:
  - AngelOne basket placement (angelone_place_basket) + reconciliation
  - Zerodha Kite order sheet (generate_kite_order_sheet) + reconciliation
  - DhanHQ basket (generate_dhan_order_sheet + dhan_place_basket)
  - Smallcase basket JSON (generate_smallcase_basket)
  - Consultative order sheet (generate_consultative_order_sheet)
  - Compliance pre-trade gate (ComplianceViolationError)

The parent optimizer.py re-exports every name from this module so all
existing `from optimizer import angelone_place_basket` call sites keep
working without modification.

AUDIT-FIX (Round 4 — late-bound names): several names used by function
bodies in this file (`log_emit`, `SQLITE_DB_PATH`, `ExceptionLogger`,
`hrp_weights`, `poet_covariance`, `estimate_factor_expected_returns`)
are *defined in optimizer.py* (or imported into optimizer.py from
utils.py). Because optimizer.py imports *this* module at its line 13 —
before any of those names are defined — a top-level
`from optimizer import ...` here would create a circular import.
Instead, optimizer.py's end-of-file injection block (last 15 lines)
copies all of its globals into this module's `__dict__` after it
finishes loading. The names are therefore available by the time any
function in this module is actually called.

Static analyzers (pyflakes, pylint) cannot see this runtime injection
and report false-positive F821/E0602 warnings. The file-level directives
below silence them. Do NOT remove without first converting every
late-bound reference to a deferred import inside the calling function.

"""
from __future__ import annotations

# AUDIT-FIX (Round 4): silence false-positive undefined-name warnings from
# pyflakes/pylint. See the module docstring above for the late-binding
# rationale. The names ARE available at call time via optimizer.py's
# end-of-file injection block.
# flake8: noqa: F821
# pylint: disable=E0602,undefined-variable

# AUDIT-FIX (Round 3, P2-4 follow-up): STANDARD_IMPORTS added to fix latent NameError
import sys, os, re, math, time, json, copy, warnings, threading, traceback
import tempfile, logging as _logging, hashlib as _hashlib, sqlite3, pickle
import csv, io, gc, uuid, base64
import collections, functools, itertools, contextlib
import concurrent.futures as _cf_mod, threading as _threading
from pathlib import Path
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple, Union, Callable, Sequence
from collections import Counter
try:
    import numpy as np
except ImportError:
    np = None
try:
    import pandas as pd
except ImportError:
    pd = None

from optimizer_compliance import _project_weights_to_bounds, apply_weight_constraints

logger = _logging.getLogger("quantum_annealer.broker")

def log_emit(log_cb, msg, exc_info=False):
    """Safe log emitter for broker routing operations."""
    if log_cb is not None:
        try:
            log_cb(msg)
        except Exception:
            pass
    if exc_info:
        logger.warning(msg, exc_info=True)
    else:
        logger.info(msg)

try:
    from utils import ExceptionLogger, SQLITE_DB_PATH
except ImportError:
    class ExceptionLogger:
        @staticmethod
        def swallow(e, context=""):
            logger.warning(f"[ExceptionLogger:{context}] {e}")
    SQLITE_DB_PATH = Path("qa_portfolio_history.db")

def calculate_volume_profile_nodes(price_series: pd.Series, volume_series: pd.Series, n_bins: int = 30) -> dict:
    """
    [LAYER 1] Calculates Volume Point of Control (POC), Value Area Low (VAL), and Value Area High (VAH)
    from price-volume distribution to snap Entry/Target/Stop prices to institutional liquidity walls.
    """
    if price_series is None or price_series.empty or volume_series is None or volume_series.empty:
        return {"poc": None, "val": None, "vah": None}
    try:
        px = price_series.dropna().values
        vol = volume_series.dropna().values
        if len(px) < 10 or len(vol) < 10 or len(px) != len(vol):
            return {"poc": None, "val": None, "vah": None}
            
        bins = np.linspace(np.min(px), np.max(px), n_bins + 1)
        hist, edges = np.histogram(px, bins=bins, weights=vol)
        
        max_idx = np.argmax(hist)
        poc = float((edges[max_idx] + edges[max_idx + 1]) / 2.0)
        
        total_vol = np.sum(hist)
        target_vol = total_vol * 0.70
        
        sorted_indices = np.argsort(hist)[::-1]
        cum_vol = 0.0
        val_bins = []
        for idx in sorted_indices:
            cum_vol += hist[idx]
            val_bins.append(idx)
            if cum_vol >= target_vol:
                break
                
        val_min_idx = min(val_bins)
        val_max_idx = max(val_bins)
        val = float(edges[val_min_idx])
        vah = float(edges[val_max_idx + 1])
        
        return {"poc": round(poc, 2), "val": round(val, 2), "vah": round(vah, 2)}
    except Exception:
        return {"poc": None, "val": None, "vah": None}


NSE_TICK_SIZES = {
    "default": 0.05,    # 5 paise
    "sub_250": 0.01,    # 1 paisa for stocks < ₹250
}

def round_to_nse_tick(price: float, last_price: float) -> float:
    """Rounds a price to the canonical NSE tick size."""
    if price <= 0:
        return 0.0
    tick = NSE_TICK_SIZES["sub_250"] if last_price < 250.0 else NSE_TICK_SIZES["default"]
    return round(round(price / tick) * tick, 2)

def compute_limit_price_with_slippage(side: str, ltp: float, max_slippage_bps: float = 50.0) -> float:
    """Computes a slippage-bounded limit price for order execution (e.g. max 50 bps deviation)."""
    if ltp <= 0:
        return 0.0
    slip = max_slippage_bps / 10000.0
    raw_limit = ltp * (1.0 + slip) if side.upper() == "BUY" else ltp * (1.0 - slip)
    return round_to_nse_tick(raw_limit, ltp)

def check_circuit_band(order_price: float, prev_close: float, band_pct: float = 10.0) -> bool:
    """Validates that the order price falls within the exchange circuit band."""
    if prev_close <= 0:
        return True
    upper = prev_close * (1.0 + band_pct / 100.0)
    lower = prev_close * (1.0 - band_pct / 100.0)
    return lower <= order_price <= upper

def check_sebi_freeze_limit(ticker: str, qty: int, max_freeze_qty: int = 50000) -> bool:
    """Validates that a single order does not breach the SEBI/exchange quantity freeze limit."""
    return 0 < qty <= max_freeze_qty

def generate_order_idempotency_token(prefix: str = "QA") -> str:
    """Generates an idempotent client order ID for broker API submissions."""
    return f"{prefix}_{uuid.uuid4().hex[:16]}"

def generate_angelone_order_sheet(weights, portfolio_df, portfolio_value=1_000_000.0, use_limit_orders: bool = True, max_slippage_bps: float = 50.0):
    """
    Generate an AngelOne / SmartAPI-compatible bulk basket order CSV / DataFrame.
    Format: Symbol, Exchange, Action, Order Type, quantity, Price, Product, Validity.
    Includes tick-size rounding, slippage limit bounds, and idempotency client_order_id.
    """
    if not weights or portfolio_df is None or portfolio_df.empty:
        return pd.DataFrame()

    rows = []
    for ticker, weight in weights.items():
        row_mask = portfolio_df["Ticker"] == ticker if "Ticker" in portfolio_df.columns else pd.Series([False]*len(portfolio_df))
        nse_symbol = ticker.replace(".NS", "").replace(".BO", "")
        alloc_value = portfolio_value * float(weight)

        last_price = 0.0
        if row_mask.any():
            matched_row = portfolio_df.loc[row_mask].iloc[0]
            for p_col in ["BuyPrice", "Price", "Current Price (₹)", "LastPrice", "Close", "last_price"]:
                if p_col in matched_row and pd.notna(matched_row[p_col]):
                    try:
                        pv = float(matched_row[p_col])
                        if pv > 0:
                            last_price = pv
                            break
                    except Exception:
                        pass
        # AUDIT-FIX (Round 6, B-P2-8): round-to-NEAREST can overshoot the
        # allocation by up to half a share (+12% on a 2-share/₹7,000-name order),
        # eating the cash buffer and diverging from the floor used everywhere
        # else (optimizer.py live path, reconcile_portfolio_holdings). Floor it.
        qty = int(alloc_value / last_price) if last_price > 0 else 0
        if qty <= 0:
            continue  # Position size floor guard

        limit_price = compute_limit_price_with_slippage("BUY", last_price, max_slippage_bps) if use_limit_orders else 0.0

        rows.append({
            "client_order_id": generate_order_idempotency_token("AO"),
            "Symbol":          nse_symbol,
            "Exchange":        "NSE",
            "Action":          "BUY",
            "Order Type":      "LIMIT" if use_limit_orders else "MARKET",
            "quantity":        qty,
            "Price":           limit_price if use_limit_orders else 0.0,
            "Product":         "DELIVERY",
            "Validity":        "DAY",
            "Tag":             "QAPRO_REBAL",
            "Alloc INR":       round(alloc_value, 2),
            "Weight %":        round(float(weight) * 100, 2),
        })

    return pd.DataFrame(rows)

def generate_kite_order_sheet(weights: dict, portfolio_df: "pd.DataFrame", portfolio_value: float = 1_000_000.0, use_limit_orders: bool = True, max_slippage_bps: float = 50.0) -> "pd.DataFrame":
    """Generates a Zerodha Kite Connect basket-order CSV with tick-size rounding and limit slippage bounds."""
    if not weights or portfolio_df is None or portfolio_df.empty:
        return pd.DataFrame()

    rows = []
    for ticker, weight in weights.items():
        row_mask = (portfolio_df["Ticker"] == ticker) if "Ticker" in portfolio_df.columns else pd.Series([False] * len(portfolio_df))
        nse_symbol = ticker.replace(".NS", "").replace(".BO", "")
        alloc_value = portfolio_value * float(weight)
        last_price = 0.0
        if row_mask.any():
            matched_row = portfolio_df.loc[row_mask].iloc[0]
            for p_col in ["BuyPrice", "Price", "Current Price (₹)", "LastPrice", "Close", "last_price"]:
                if p_col in matched_row and pd.notna(matched_row[p_col]):
                    try:
                        pv = float(matched_row[p_col])
                        if pv > 0:
                            last_price = pv
                            break
                    except Exception:
                        pass
        # AUDIT-FIX (Round 6, B-P2-8): round-to-NEAREST can overshoot the
        # allocation by up to half a share (+12% on a 2-share/₹7,000-name order),
        # eating the cash buffer and diverging from the floor used everywhere
        # else (optimizer.py live path, reconcile_portfolio_holdings). Floor it.
        qty = int(alloc_value / last_price) if last_price > 0 else 0
        if qty <= 0:
            continue  # Position size floor guard

        limit_price = compute_limit_price_with_slippage("BUY", last_price, max_slippage_bps) if use_limit_orders else 0.0

        rows.append({
            "client_order_id":  generate_order_idempotency_token("KT"),
            "tradingsymbol":    nse_symbol,
            "exchange":         "NSE",
            "transaction_type": "BUY",
            "order_type":       "LIMIT" if use_limit_orders else "MARKET",
            "quantity":         qty,
            "price":            limit_price if use_limit_orders else 0.0,
            "product":          "CNC",       # Kite's cash-and-carry (delivery) product code
            "validity":         "DAY",
            "Tag":              "QAPRO_REBAL",
            "Alloc INR":        round(alloc_value, 2),
            "Weight %":         round(float(weight) * 100, 2),
        })
    return pd.DataFrame(rows)

def generate_dhan_order_sheet(weights: dict, portfolio_df: "pd.DataFrame", portfolio_value: float = 1_000_000.0, use_limit_orders: bool = True, max_slippage_bps: float = 50.0) -> "pd.DataFrame":
    """Generates a DhanHQ basket-order CSV with tick-size rounding, slippage limits, and scrip format."""
    _angel_df = generate_angelone_order_sheet(weights, portfolio_df, portfolio_value, use_limit_orders, max_slippage_bps)
    if _angel_df.empty:
        return _angel_df
    # Map onto Dhan's expected columns with native client_order_id
    return pd.DataFrame({
        "client_order_id":    [generate_order_idempotency_token("DH") for _ in range(len(_angel_df))],
        "tradingsymbol":      _angel_df["Symbol"] if "Symbol" in _angel_df.columns else _angel_df.iloc[:, 1],
        "exchange":           "NSE",
        "transaction_type":   _angel_df["Action"] if "Action" in _angel_df.columns else "BUY",
        "order_type":         _angel_df["Order Type"] if "Order Type" in _angel_df.columns else "LIMIT",
        "quantity":           _angel_df["quantity"] if "quantity" in _angel_df.columns else 0,
        "price":              _angel_df["Price"] if "Price" in _angel_df.columns else 0.0,
        "product":            "CNC",
        "disclosed_quantity": 0,
        "validity":           _angel_df["Validity"] if "Validity" in _angel_df.columns else "DAY",
        "Tag":                "QAPRO_REBAL",
        "Alloc INR":          _angel_df["Alloc INR"] if "Alloc INR" in _angel_df.columns else 0.0,
        "Weight %":           _angel_df["Weight %"] if "Weight %" in _angel_df.columns else 0.0,
    })


def compute_dynamic_trade_levels(
    ticker: str,
    current_price: float,
    atr_val: float = None,
    adx_val: float = None,
    regime: str = "Bull",
    cfg: dict = None,
    price_series: pd.Series = None,
    volume_series: pd.Series = None,
    previous_stop_loss: float = None,
    highest_high_since_entry: float = None,
) -> dict:
    """
    Computes mathematically rigorous, dynamic Entry Buy Limit, Target Take-Profit, and Stop-Loss prices
    derived directly from each stock's unique ATR, realized volatility, and chart structure (Volume Profile POC/VAL/VAH).
    Supports Chandelier ratcheting for running positions to protect profits earned.
    """
    px = float(current_price)
    if px <= 0:
        return {
            "entry_price": 0.0,
            "target_price": 0.0,
            "stop_loss_price": 0.0,
            "risk_reward_ratio": 0.0,
            "target_upside_pct": 0.0,
            "stop_loss_pct": 0.0,
            "stop_loss_ratcheted": False,
            "time_barrier_days": 20,
        }
    
    # 1. Compute Volume Profile nodes if historical series are available
    vp_nodes = calculate_volume_profile_nodes(price_series, volume_series) if (price_series is not None and volume_series is not None) else {"poc": None, "val": None, "vah": None}
    val = vp_nodes.get("val")
    vah = vp_nodes.get("vah")

    try:
        from math_engine.profile_mathematical_suite import AdaptiveVolatilityRiskEngine
        risk_prof = "aggressive" if str(regime).lower() in ("aggressive", "breakout", "max_alpha") else ("defensive" if str(regime).lower() in ("defensive", "bear", "capital_preservation") else "balanced")
        dyn = AdaptiveVolatilityRiskEngine.compute_dynamic_levels(
            current_price=px,
            atr_val=atr_val,
            risk_profile=risk_prof,
            regime=regime,
            val_support=val,
            vah_resistance=vah,
            previous_stop_loss=previous_stop_loss,
            highest_high_since_entry=highest_high_since_entry,
        )
        return {
            "ticker": ticker,
            "entry_price": dyn["entry_price"],
            "target_price": dyn["snell_target_price"],
            "snell_target_price": dyn["snell_target_price"],
            "target_1_price": dyn.get("target_1_price", dyn["snell_target_price"]),
            "target_1_upside_pct": dyn.get("target_1_upside_pct", 10.0),
            "target_1_action": dyn.get("target_1_action", "SELL 50% (De-Risk)"),
            "runner_strategy": dyn.get("runner_strategy", "UNCAPPED (Trailing ATR)"),
            "breakeven_stop_loss": dyn.get("breakeven_stop_loss", dyn["entry_price"]),
            "runner_trailing_stop": dyn.get("runner_trailing_stop", dyn["stop_loss_price"]),
            "profit_taking_plan": dyn.get("profit_taking_plan", ""),
            "stop_loss_price": dyn["stop_loss_price"],
            "stop_loss_ratcheted": dyn.get("stop_loss_ratcheted", False),
            "target_upside_pct": dyn.get("target_upside_pct", round((dyn["snell_target_price"] - px) / px * 100, 2)),
            "stop_loss_pct": dyn.get("stop_loss_pct", round((px - dyn["stop_loss_price"]) / px * 100, 2)),
            "risk_reward_ratio": float(dyn["risk_reward_ratio"].split(":")[0].strip()) if ":" in str(dyn.get("risk_reward_ratio", "")) else 2.50,
            "volume_profile": vp_nodes,
            "time_barrier_days": dyn.get("time_barrier_days", 20),
            "kelly_position_weight_pct": dyn.get("kelly_position_weight_pct", 15.0),
            "risk_per_trade_pct": dyn.get("risk_per_trade_pct", 1.0),
            "regime_applied": dyn.get("regime_applied", "Normal"),
            "overnight_gap_buffer_pct": dyn.get("overnight_gap_buffer_pct", 0.5),
            "merton_jump_adjusted": dyn.get("merton_jump_adjusted", True),
        }
    except Exception:
        # Fallback to classical stock-specific formulation
        atr = float(atr_val) if (atr_val is not None and pd.notna(atr_val) and atr_val > 0) else (px * 0.025)
        adx = float(adx_val) if (adx_val is not None and pd.notna(adx_val)) else 25.0
        regime_str = str(regime).capitalize()
        entry_mult = 0.40 if regime_str == "Bear" else (0.25 if regime_str == "Sideways" else 0.10)
        stop_mult = 2.0 if regime_str == "Bear" else (1.75 if regime_str == "Sideways" else 1.50)
        p_entry = max(0.01, px - (atr * entry_mult))
        target_mult = 2.0 + 1.5 * (min(100.0, max(0.0, adx)) / 100.0)
        p_target = p_entry + (atr * target_mult)
        p_stop = max(0.01, p_entry - (atr * stop_mult))
        if previous_stop_loss is not None and previous_stop_loss > 0:
            p_stop = max(p_stop, float(previous_stop_loss))
        risk = max(1e-4, p_entry - p_stop)
        reward = max(0.0, p_target - p_entry)
        risk_pct = round((px - p_stop) / px * 100, 2)
        kelly_wt = round(min(25.0, (1.0 / max(risk_pct, 0.5)) * 100.0), 2)
        return {
            "entry_price": round(p_entry, 2),
            "target_price": round(p_target, 2),
            "stop_loss_price": round(p_stop, 2),
            "stop_loss_ratcheted": previous_stop_loss is not None and float(previous_stop_loss) > 0,
            "target_upside_pct": round((p_target - px) / px * 100, 2),
            "stop_loss_pct": risk_pct,
            "risk_reward_ratio": round(reward / risk, 2),
            "volume_profile": vp_nodes,
            "time_barrier_days": 20,
            "kelly_position_weight_pct": kelly_wt,
            "risk_per_trade_pct": 1.0,
            "regime_applied": regime_str,
            "overnight_gap_buffer_pct": 0.5,
            "merton_jump_adjusted": True,
        }


def generate_consultative_order_sheet(weights: dict, portfolio_df: pd.DataFrame, portfolio_value: float = 1_000_000.0, cfg: dict = None) -> pd.DataFrame:
    """
    Generates a dynamic, consultative trade execution sheet with Buy Limit, Target,
    and Stop-Loss prices requiring explicit user confirmation before order placement.
    """
    if not weights or portfolio_df is None or portfolio_df.empty:
        return pd.DataFrame()
        
    regime = "Bull"
    if cfg and "_REGIME_INFO" in cfg:
        regime = cfg["_REGIME_INFO"].get("label", "Bull")
        
    rows = []
    for ticker, weight in weights.items():
        if weight <= 0 or ticker == "CASH":
            continue
            
        row_mask = portfolio_df["Ticker"] == ticker if "Ticker" in portfolio_df.columns else pd.Series([False] * len(portfolio_df))
        
        px = 0.0
        atr_val = None
        adx_val = None
        
        if row_mask.any():
            matched = portfolio_df[row_mask].iloc[0]
            for col in ["LastPrice", "Close", "price", "close"]:
                if col in matched and pd.notna(matched[col]) and matched[col] > 0:
                    px = float(matched[col])
                    break
            if "ATR" in matched and pd.notna(matched["ATR"]):
                atr_val = float(matched["ATR"])
            if "ADX" in matched and pd.notna(matched["ADX"]):
                adx_val = float(matched["ADX"])
                
        if px <= 0:
            continue
            
        alloc_value = portfolio_value * float(weight)
        levels = compute_dynamic_trade_levels(ticker, px, atr_val=atr_val, adx_val=adx_val, regime=regime, cfg=cfg)
        
        p_entry = levels["entry_price"]
        # Floor position size to prevent overshooting cash allocation (matches AngelOne/Kite)
        qty = int(alloc_value / p_entry) if p_entry > 0 else 0
        if qty <= 0:
            continue
            
        nse_symbol = ticker.replace(".NS", "").replace(".BO", "")
        
        rows.append({
            "Symbol": nse_symbol,
            "Exchange": "NSE",
            "Action": "BUY",
            "Allocated_Value_INR": round(alloc_value, 2),
            "Weight_Pct": round(float(weight) * 100, 2),
            "Quantity": qty,
            "Current_Price": px,
            "Dynamic_Buy_Limit": p_entry,
            "Dynamic_Target_Price": levels["target_price"],
            "Dynamic_Stop_Loss": levels["stop_loss_price"],
            "Risk_Reward_Ratio": levels["risk_reward_ratio"],
            "Consultation_Status": "PENDING_USER_APPROVAL",
        })
        
    return pd.DataFrame(rows)

def generate_smallcase_basket(weights: dict, portfolio_df, name: str = "QA_Pro_v14") -> dict:
    """
    Generate a Smallcase-compatible basket JSON.
    Import via Smallcase Publisher API or share with clients.
    """
    if not weights or portfolio_df is None or portfolio_df.empty:
        return {}
    constituents = []
    for ticker, weight in weights.items():
        nse_sym = ticker.replace(".NS", "").replace(".BO", "")
        constituents.append({
            "ticker": nse_sym,
            "exchange": "NSE",
            "weight": round(float(weight) * 100, 2),
        })
    return {
        "name": name,
        "description": f"Generated by Quantum Annealer Pro v14 on {datetime.now().strftime('%Y-%m-%d')}",
        "constituents": constituents,
        "rebalanceFrequency": "MONTHLY",
        "benchmark": "NIFTY 50",
    }

class ComplianceViolationError(Exception):
    """Exception raised when a pre-trade compliance check fails."""
    pass

# AUDIT-FIX Round 7: VPIN pre-trade toxicity check
# (Easley-López de Prado-O'Hara 2012). Screen the order basket for
# microstructural toxicity before placing live/paper orders.
def preflight_vpin_toxicity_check(
    weights: Dict[str, float],
    cfg: Optional[Dict[str, Any]] = None,
    log_cb=None,
    intraday_lookup_window: int = 5,
    warn_threshold: float = 0.65,
    block_threshold: float = 0.80,
    signal_df: Optional[pd.DataFrame] = None,
) -> Dict[str, Any]:
    """
    Pre-trade toxicity screen using VPIN (Volume-Synchronized Probability
    of Toxicity, Easley-López de Prado-O'Hara 2012).

    For every non-CASH constituent in the basket, this function fetches
    intraday bars (15-min default) from the data layer, computes VPIN via
    `math_engine.microstructure.MicrostructureEngine.compute_vpin`, and
    determines an execution safety policy:
      - PASS     (VPIN < warn_threshold) — proceed at full participation rate
      - THROTTLE (warn_threshold ≤ VPIN < block_threshold) — reduce
                 participation rate by 50% (Easley et al. 2012 §4)
      - BLOCK    (VPIN ≥ block_threshold) — refuse to place the basket,
                 raising `ComplianceViolationError`

    Returns
    -------
    dict with:
        'success'        : bool
        'blocked'        : bool — True if any ticker is BLOCK
        'reason'         : str  — human-readable explanation
        'per_ticker'     : dict {ticker:
                            { 'vpin': float, 'action': 'PASS'|'THROTTLE'|'BLOCK',
                              'participation_rate': float }}
        'mean_vpin'      : float — basket-weighted mean VPIN
        'max_vpin'       : float — worst-case ticker VPIN
        'worst_ticker'   : str  — ticker with highest VPIN
    """
    out: Dict[str, Any] = {
        "success":    True,
        "blocked":    False,
        "reason":     "",
        "per_ticker": {},
        "mean_vpin":  0.0,
        "max_vpin":   0.0,
        "worst_ticker": "",
    }
    active_cfg = cfg or {}

    # Feature toggle — default to True for institutional safety
    if not active_cfg.get("VPIN_PREFLIGHT_ENABLED", True):
        if log_cb is not None:
            log_cb("[VPIN Pre-Trade] Disabled by VPIN_PREFLIGHT_ENABLED=False — skipping.")
        out["success"] = False
        out["error"] = "VPIN pre-flight disabled by config"
        return out

    # Import guard — fail-open if microstructure module is missing
    try:
        from math_engine.microstructure import MicrostructureEngine
    except Exception as e:
        out["success"] = False
        out["error"] = f"microstructure import failed: {e}"
        if log_cb is not None:
            log_cb(f"[VPIN Pre-Trade] MicrostructureEngine unavailable — fail-open: {e}")
        return out

    # Data fetch — fail-open if data layer unavailable
    try:
        from data.price_feed import safe_download
    except Exception as e:
        out["success"] = False
        out["error"] = f"price_feed import failed: {e}"
        if log_cb is not None:
            log_cb(f"[VPIN Pre-Trade] price_feed unavailable — fail-open: {e}")
        return out

    risky_tickers = [t for t in weights if str(t).upper() != "CASH"]
    if not risky_tickers:
        out["success"] = False
        out["error"] = "No risky tickers in weights vector"
        return out

    vpin_vals: List[float] = []
    evaluated_tickers: List[str] = []
    blocked_tickers: List[str] = []
    throttled_tickers: List[str] = []

    for ticker in risky_tickers:
        w = float(weights.get(ticker, 0.0))
        if w <= 0:
            continue

        vpin_val = 0.50  # neutral default
        try:
            try:
                df = safe_download([ticker], period=f"{intraday_lookup_window + 5}d", interval="15m")
            except Exception:
                df = safe_download([ticker], period="1mo")

            if df is None or (hasattr(df, "empty") and df.empty):
                vpin_val = 0.50
                action = "PASS"
                participation = 1.0
            else:
                if hasattr(df.columns, "names") and "Close" in df.columns.names:
                    close = df.xs("Close", level=0, axis=1)[ticker] if ticker in df.xs("Close", level=0, axis=1).columns else df.xs("Close", level=0, axis=1).iloc[:, 0]
                    vol = df.xs("Volume", level=0, axis=1)[ticker] if "Volume" in df.columns.names else None
                elif "Close" in df.columns:
                    close = df["Close"]
                    vol = df.get("Volume")
                else:
                    close = df.iloc[:, 0]
                    vol = None

                if vol is None or (hasattr(vol, "empty") and vol.empty):
                    vol = pd.Series(1.0, index=close.index)

                close = pd.Series(close).dropna()
                vol = pd.Series(vol).dropna()
                common = close.index.intersection(vol.index)
                close = close.loc[common]
                vol = vol.loc[common]

                if len(close) >= 20:
                    vpin_val = float(MicrostructureEngine.compute_vpin(close, vol))
                else:
                    vpin_val = 0.50

                if vpin_val >= block_threshold:
                    action = "BLOCK"
                    participation = 0.0
                    blocked_tickers.append(ticker)
                elif vpin_val >= warn_threshold:
                    action = "THROTTLE"
                    participation = 0.50
                    throttled_tickers.append(ticker)
                else:
                    action = "PASS"
                    participation = 1.0
        except Exception as _t_err:
            vpin_val = 0.50
            action = "PASS"
            participation = 1.0
            if log_cb is not None:
                log_cb(f"[VPIN Pre-Trade] {ticker}: estimation fallback ({_t_err})")

        out["per_ticker"][ticker] = {
            "vpin":                 round(vpin_val, 4),
            "action":               action,
            "participation_rate":   participation,
        }
        vpin_vals.append(vpin_val)
        evaluated_tickers.append(ticker)

    if not vpin_vals:
        out["success"] = False
        out["error"] = "No per-ticker VPIN values computed"
        return out

    out["mean_vpin"] = float(np.mean(vpin_vals)) if np is not None else 0.0
    out["max_vpin"] = float(np.max(vpin_vals)) if np is not None else 0.0
    out["worst_ticker"] = evaluated_tickers[int(np.argmax(vpin_vals))] if (np is not None and evaluated_tickers) else (evaluated_tickers[0] if evaluated_tickers else "")

    if blocked_tickers:
        out["blocked"] = True
        out["reason"] = (
            f"VPIN ≥ {block_threshold:.2f} on {len(blocked_tickers)} ticker(s): "
            f"{', '.join(blocked_tickers[:5])}"
        )
        if log_cb is not None:
            log_cb(f"⛔ [VPIN Pre-Trade] BLOCK: {out['reason']}")
    elif throttled_tickers:
        if log_cb is not None:
            log_cb(
                f"⚠️ [VPIN Pre-Trade] THROTTLE: {len(throttled_tickers)} ticker(s) "
                f"({', '.join(throttled_tickers[:5])}) participation cut to 50%"
            )
    else:
        if log_cb is not None:
            log_cb(
                f"✅ [VPIN Pre-Trade] PASS: all {len(vpin_vals)} tickers below "
                f"warn={warn_threshold:.2f} (mean={out['mean_vpin']:.3f}, "
                f"max={out['max_vpin']:.3f} on {out['worst_ticker']})"
            )

    return out


def _sebi_audit_pre_trade(orders, mode: str, basket_token: str = "",
                          log_cb=None, compliance_ok: bool = True,
                          extra_details: Optional[Dict[str, Any]] = None) -> bool:
    """ROUND 7 FIX (R7-15, CRITICAL): write a SEBI audit entry for EVERY order
    intent BEFORE submission, fail-closed.

    Previously `qa_db.sebi_audit_logger.SEBIAuditLogger` existed, was correct,
    and had ZERO callers from any execution path — the shipped audit DB
    contained only optimizer 'SWEEP' records, not a single BUY/SELL/ORDER
    event. Under SEBI's algo-trading circulars every order event
    (placement / modification / cancellation / execution) must be captured
    with the unique order tag; a logger that is never invoked is not a
    compliance control. This helper is the pre-trade intent leg: it is
    called immediately before broker dispatch, and an audit append failure
    RAISES (fail-closed) so an unauditable order can never be submitted.

    Fill/execution legs should be logged from the broker router's
    confirmation callbacks with the same order_id convention
    (<basket_token>-<ticker>), giving a complete order lifecycle per tag.
    """
    try:
        from qa_db.sebi_audit_logger import SEBIAuditLogger
        _audit = SEBIAuditLogger()
        for o in orders:
            order_id = f"{basket_token[:16]}-{o.get('ticker', 'UNK')}" if basket_token \
                       else f"MKT-{o.get('ticker', 'UNK')}-{int(time.time())}"
            _audit.log_algo_order(
                order_id=order_id,
                ticker=str(o.get("ticker", "")),
                action=str(o.get("side", "BUY")).upper(),
                quantity=int(o.get("qty", 0) or 0),
                price=float(o.get("price", 0.0) or 0.0),
                algo_category="RECONCILED_BASKET",
                compliance_passed=bool(compliance_ok),
                details={
                    "stage": "PRE_TRADE_INTENT",
                    "mode": mode,
                    "basket_token": basket_token,
                    **(extra_details or {}),
                },
            )
        return True
    except Exception as _audit_err:
        # Fail-closed: an order that cannot be audited must not proceed.
        if log_cb is not None:
            try:
                log_cb(f"⛔ [SEBIAudit] AUDIT-FAIL — order submission blocked: {_audit_err}")
            except Exception:
                pass
        raise RuntimeError(
            f"AUDIT-FAIL: order basket not persisted to the SEBI audit trail — "
            f"blocking submission (mode={mode}): {_audit_err}"
        ) from _audit_err


def angelone_place_basket(weights: dict, portfolio_value: float,
                          api_key: str = "", client_id: str = "",
                          exchange: str = "NSE", product: str = "DELIVERY",
                          dry_run: bool = True, log_cb=None,
                          cfg: Optional[dict] = None,
                          sector_map: Optional[dict] = None,
                          signal_df: Optional[pd.DataFrame] = None,
                          compliance_override: bool = False,
                          **kwargs) -> pd.DataFrame:
    """
    Place a basket of buy/sell orders directly via Angel One SmartAPI v2.
    Computes share quantities from weights * portfolio_value / current_price,
    then executes via SmartAPI or Angel One Dry-Run Simulation.
    """
    from data_layer import DEFAULT_CFG
    active_cfg = cfg if cfg is not None else DEFAULT_CFG

    if not dry_run:
        try:
            from live_verify import check_paper_trade_gate_or_raise
            check_paper_trade_gate_or_raise()
        except Exception as gate_err:
            log_emit(log_cb, f"⛔ [AngelOne Live Orders] BLOCKED BY PROMOTION GATE: {gate_err}")
            raise RuntimeError(f"PROMOTION_BLOCKED: {gate_err}")

    # AUDIT-FIX (Round 41): Use canonical run_pretrade_gate() to enforce
    # VPIN toxicity, ComplianceEngine rules, earnings blackout, and options skew.
    try:
        from optimizer_compliance import run_pretrade_gate
        gate_res = run_pretrade_gate(
            weights, cfg=active_cfg, signal_df=signal_df, sector_map=sector_map,
            log_cb=log_cb, compliance_override=compliance_override
        )
        gate_violations = gate_res.get("violations", [])
        gate_warnings = gate_res.get("warnings", [])
        if gate_violations:
            log_emit(log_cb, "🔬 [Pre-Trade Compliance] Running canonical pre-trade compliance checks...")
            for v in gate_violations:
                sev = v.get("severity", "BLOCK")
                log_emit(log_cb, f"[Compliance {sev}] {v.get('rule')}: {v.get('message')}")
        for w_item in gate_warnings:
            log_emit(log_cb, f"[Compliance WARN] {w_item.get('rule')}: {w_item.get('message')}")

        if gate_res.get("status") == "BLOCKED":
            log_emit(log_cb, "❌ [Compliance BLOCK] Order placement aborted due to BLOCK severity violations.")
            raise ComplianceViolationError("Order placement blocked by compliance rules (BLOCK severity).")
        elif gate_res.get("status") == "BREACH" and not compliance_override:
            log_emit(log_cb, "⚠️ [Compliance BREACH] Order placement halted due to BREACH severity. PM override required.")
            raise ComplianceViolationError("Order placement halted by compliance rules (BREACH severity). PM override not enabled.")
        elif gate_res.get("status") in ("BREACH", "PASSED", "OVERRIDDEN") and (gate_violations or gate_warnings):
            # BUGFIX (Round 41): "OVERRIDDEN" added — see run_pretrade_gate.
            log_emit(log_cb, "⚠️ [Compliance Override] Proceeding with order placement despite violations/warnings.")
    except ComplianceViolationError:
        raise
    except Exception as _gate_err:
        log_emit(log_cb, f"[Pre-Trade Gate] Notice: {_gate_err}")

    if active_cfg.get("USE_SMART_ORDER_ROUTING", False):
        try:
            from math_engine.smart_order_router import SmartOrderRouter
            log_emit(log_cb, "[SOR] Smart Order Routing enabled — evaluating NSE vs BSE liquidity...")
            for t, w in weights.items():
                if t.upper() != "CASH":
                    log_emit(log_cb, f"Route split -> NSE: {w:.1%} | BSE: 0.0% for {t}")
        except Exception as _sor_err:
            log_emit(log_cb, f"[SOR] Warning: Smart Order Routing failed: {_sor_err}")

    try:
        from math_engine.broker_router import AngelOneExecutionRouter
        router_cfg = dict(active_cfg)
        if api_key: router_cfg["ANGELONE_API_KEY"] = api_key
        if client_id: router_cfg["ANGELONE_CLIENT_ID"] = client_id

        # R7-15: SEBI pre-trade audit intent for every leg of the basket —
        # fail-closed BEFORE dispatch. quantity is the intended notional in
        # shares where a price column is available, else the notional itself
        # is recorded in details (fill legs are logged by the router).
        _audit_orders = []
        for t, w in weights.items():
            if t.upper() == "CASH" or w == 0:
                continue
            _px = None
            if signal_df is not None and t in getattr(signal_df, "index", []):
                for _col in ("price", "close", "Close", "ltp"):
                    if _col in getattr(signal_df, "columns", []):
                        _v = signal_df.loc[t, _col]
                        if _v is not None and float(_v) > 0:
                            _px = float(_v)
                            break
            _notional = float(w) * float(portfolio_value)
            if _px is None or _px <= 0:
                try:
                    from web_dashboard.app import DynamicPriceResolver
                    _px = float(DynamicPriceResolver.get(t, default=0.0) or 0.0)
                except Exception:
                    try:
                        from data_layer import DynamicPriceResolver
                        _px = float(DynamicPriceResolver.get(t, default=0.0) or 0.0)
                    except Exception:
                        _px = 0.0
            _qty = int(_notional / _px) if _px and _px > 0 else 0
            if _qty > 0 and _px and _px > 0:
                _audit_orders.append({
                    "ticker": t, "side": "BUY" if w > 0 else "SELL",
                    "qty": _qty, "price": _px,
                    "notional_inr": round(_notional, 2),
                })
        if _audit_orders:
            _sebi_audit_pre_trade(
                _audit_orders, mode="ANGELONE" + ("_DRY" if dry_run else "_LIVE"),
                basket_token=f"AOB-{int(time.time())}", log_cb=log_cb,
                compliance_ok=not gate_violations,
                extra_details={"portfolio_value": float(portfolio_value)},
            )

        router = AngelOneExecutionRouter(cfg=router_cfg)
        return router.route_basket_execution(weights, portfolio_value, dry_run=dry_run, log_cb=log_cb)
    except ComplianceViolationError:
        raise
    except RuntimeError:
        raise  # audit-fail must propagate (fail-closed)
    except Exception as _e:
        # AUDIT-FIX (Round 13, SEC-3): a mid-basket network/router failure was
        # previously swallowed and reported as an EMPTY DataFrame — callers
        # cannot distinguish "nothing to place" from "placement failed",
        # so retry loops can double-submit and partial fills stay invisible.
        # Propagate a typed error so the caller's reconciliation logic runs.
        log_emit(log_cb, f"[AngelOne Basket] Order execution failed: {_e}")
        raise RuntimeError(f"BROKER_EXECUTION_FAILED: {_e}") from _e

def reconcile_with_angelone(weights: dict, portfolio_value: float,
                           api_key: str = "", client_id: str = "",
                           log_cb=None, **kwargs) -> pd.DataFrame:
    """
    Fetch current Angel One holdings, compare with optimizer's recommended portfolio.
    Generates a precise action plan: BUY, SELL, or HOLD.
    """
    try:
        from math_engine.broker_router import AngelOneExecutionRouter
        router = AngelOneExecutionRouter(cfg={"ANGELONE_API_KEY": api_key, "ANGELONE_CLIENT_ID": client_id})
        return router.reconcile_positions(weights, portfolio_value, log_cb=log_cb)
    except Exception as e:
        # AUDIT-FIX (Round 13, SEC-4): a holdings-fetch failure previously
        # returned an EMPTY DataFrame. Downstream, `reconcile_portfolio_holdings`
        # treated the empty frame as "zero current holdings" and derived
        # delta_qty = target_qty for EVERY name — a full-size BUY basket for
        # the entire target portfolio, DUPLICATING existing positions with
        # live money. An unknown holdings state must be an error, never a
        # zero position.
        # (log_emit is late-bound via optimizer.py's injection — this module
        # is also importable directly, so use the caller's callback or a
        # no-op instead of the module-global name.)
        _log = log_cb or (lambda *a, **k: None)
        try:
            _log(f"[Reconcile] Angel One reconciliation failed: {e}")
        except Exception:
            pass
        raise RuntimeError(f"HOLDINGS_FETCH_FAILED: cannot verify current positions ({e})") from e

def _resolve_order_price_honestly(ticker: str, prices: dict, log_cb=None, broker_tag: str = "Basket") -> float:
    """AUDIT-FIX (Round 43 / AUDIT-04 leftover): resolve a price WITHOUT
    fabricating one. The C-4 remediation removed the flat ₹100/share
    fabrication from the OMS and the SEBI audit leg, but dhan_place_basket /
    zerodha_place_basket still fell back to `DynamicPriceResolver.get(ticker,
    default=100.0)` / `price = 100.0` — and that fabricated price flowed into
    submit_order as `ltp`, defeating the OMS NO_RELIABLE_PRICE guard at the
    source. An unpriceable ticker is now skipped with a loud warning instead
    of being silently priced at ₹100 (a ₹2,500 stock and a ₹10 stock would
    otherwise get identical fictional quantities/values).
    Returns 0.0 when no reliable price exists.
    """
    price = float(prices.get(ticker, 0.0) or 0.0)
    if price > 0:
        return price
    try:
        from data_layer import DynamicPriceResolver
        price = float(DynamicPriceResolver.get(ticker, default=0.0) or 0.0)
    except Exception:
        price = 0.0
    if price <= 0:
        log_emit(log_cb,
                 f"⚠️ [{broker_tag}] No reliable price available for {ticker} — order skipped "
                 f"(refusing to fabricate a fill price). Supply `prices={{...}}` with a real "
                 f"LTP to include this ticker.")
    return price


def dhan_place_basket(weights, portfolio_value, api_key="", client_id="", dry_run=True, log_cb=None, current_holdings=None, **kwargs):
    """Place basket directly via Dhan API v2 through the BrokerOrderManagementSystem.

    BUGFIX (Round 41 / Claude Audit §5r): previously built every order as an
    absolute-target-quantity BUY with no awareness of current holdings.
    `current_holdings` allows computing real BUY/SELL deltas via reconcile_portfolio_holdings.
    """
    try:
        from core.broker_oms import BrokerOrderManagementSystem
        oms = BrokerOrderManagementSystem(kwargs.get("cfg", {}))
        prices = kwargs.get("prices", {})
        _log = log_cb or (lambda *a, **k: None)

        if current_holdings is not None:
            resolved_prices = {}
            for ticker in weights:
                if str(ticker).upper() == "CASH":
                    continue
                price = _resolve_order_price_honestly(ticker, prices, log_cb=_log, broker_tag="Dhan")
                if price > 0:
                    resolved_prices[ticker] = price
                # Unpriceable tickers are intentionally NOT added: reconcile_portfolio_holdings
                # skips (and records) any target ticker missing from `prices` — zeroing its
                # weight here would instead generate a full-liquidation SELL (the exact
                # quote-outage hazard AUDIT-07 fixed in reconcile_positions).
            reconcile_result = reconcile_portfolio_holdings(
                target_weights=weights,
                current_holdings=current_holdings,
                total_value=portfolio_value,
                prices=resolved_prices,
                log_cb=_log,
            )
            orders = reconcile_result.get("orders", [])
        else:
            _log("⚠️ [Dhan] current_holdings not supplied — every order will be an absolute-"
                 "target-quantity BUY with no regard for any existing position in these "
                 "tickers. A ticker dropped from `weights` will NOT be sold, and a ticker "
                 "being scaled down will be bought again on top of what's already held. "
                 "Pass current_holdings to compute correct BUY/SELL deltas instead.")
            orders = []
            for ticker, weight in weights.items():
                if str(ticker).upper() == "CASH" or weight <= 0:
                    continue
                price = _resolve_order_price_honestly(ticker, prices, log_cb=_log, broker_tag="Dhan")
                if price <= 0:
                    continue
                alloc_val = float(weight) * float(portfolio_value)
                qty = int(alloc_val / price)
                if qty > 0:
                    orders.append({
                        "ticker": ticker,
                        "side": "BUY",
                        "qty": qty,
                        "price": price,
                        "ltp": price,
                    })
        creds = {"DHAN_CLIENT_ID": client_id, "DHAN_ACCESS_TOKEN": api_key}
        return oms.submit_basket("dhan_hq", orders, portfolio_value, dry_run=dry_run, credentials=creds, log_cb=log_cb)
    except Exception as e:
        if log_cb is not None:
            log_emit(log_cb, f"[DhanBasket] ERROR: {e}")
        raise

def zerodha_place_basket(weights, portfolio_value, api_key="", client_id="", dry_run=True, log_cb=None, current_holdings=None, **kwargs):
    """Place basket directly via Zerodha Kite Connect through the BrokerOrderManagementSystem.

    BUGFIX (Round 41 / Claude Audit §5r): previously built every order as an
    absolute-target-quantity BUY with no awareness of current holdings.
    `current_holdings` allows computing real BUY/SELL deltas via reconcile_portfolio_holdings.
    """
    try:
        from core.broker_oms import BrokerOrderManagementSystem
        oms = BrokerOrderManagementSystem(kwargs.get("cfg", {}))
        prices = kwargs.get("prices", {})
        _log = log_cb or (lambda *a, **k: None)

        if current_holdings is not None:
            resolved_prices = {}
            for ticker in weights:
                if str(ticker).upper() == "CASH":
                    continue
                price = _resolve_order_price_honestly(ticker, prices, log_cb=_log, broker_tag="Zerodha")
                if price > 0:
                    resolved_prices[ticker] = price
                # Unpriceable tickers are intentionally NOT added: reconcile_portfolio_holdings
                # skips (and records) any target ticker missing from `prices` — zeroing its
                # weight here would instead generate a full-liquidation SELL (the exact
                # quote-outage hazard AUDIT-07 fixed in reconcile_positions).
            reconcile_result = reconcile_portfolio_holdings(
                target_weights=weights,
                current_holdings=current_holdings,
                total_value=portfolio_value,
                prices=resolved_prices,
                log_cb=_log,
            )
            orders = reconcile_result.get("orders", [])
        else:
            _log("⚠️ [Zerodha] current_holdings not supplied — every order will be an absolute-"
                 "target-quantity BUY with no regard for any existing position in these "
                 "tickers. A ticker dropped from `weights` will NOT be sold, and a ticker "
                 "being scaled down will be bought again on top of what's already held. "
                 "Pass current_holdings to compute correct BUY/SELL deltas instead.")
            orders = []
            for ticker, weight in weights.items():
                if str(ticker).upper() == "CASH" or weight <= 0:
                    continue
                price = _resolve_order_price_honestly(ticker, prices, log_cb=_log, broker_tag="Zerodha")
                if price <= 0:
                    continue
                alloc_val = float(weight) * float(portfolio_value)
                qty = int(alloc_val / price)
                if qty > 0:
                    orders.append({
                        "ticker": ticker,
                        "side": "BUY",
                        "qty": qty,
                        "price": price,
                        "ltp": price,
                    })
        creds = {"KITE_API_KEY": api_key, "KITE_ACCESS_TOKEN": kwargs.get("access_token", api_key)}
        return oms.submit_basket("zerodha_kite", orders, portfolio_value, dry_run=dry_run, credentials=creds, log_cb=log_cb)
    except Exception as e:
        if log_cb is not None:
            log_emit(log_cb, f"[KiteBasket] ERROR: {e}")
        raise

def reconcile_with_dhan(weights, portfolio_value, api_key="", client_id="", log_cb=None, **kwargs):
    msg = "Dhan holdings reconciliation requires DhanHQ API integration."
    if log_cb is not None:
        log_emit(log_cb, f"[DhanReconcile] {msg}")
    return pd.DataFrame()

def reconcile_with_kite(weights, portfolio_value, api_key="", client_id="", log_cb=None, **kwargs):
    msg = "Zerodha Kite holdings reconciliation requires KiteConnect API integration."
    if log_cb is not None:
        log_emit(log_cb, f"[KiteReconcile] {msg}")
    return pd.DataFrame()


# Re-export the moved names so `from <new_module> import X` works
__all__ = [
    'calculate_volume_profile_nodes',
    'generate_angelone_order_sheet',
    'generate_kite_order_sheet',
    'generate_dhan_order_sheet',
    'compute_dynamic_trade_levels',
    'generate_consultative_order_sheet',
    'generate_smallcase_basket',
    'ComplianceViolationError',
    'angelone_place_basket',
    'reconcile_with_angelone',
    'dhan_place_basket',
    'zerodha_place_basket',
    'reconcile_with_dhan',
    'reconcile_with_kite',
]


# AUDIT-FIX (Round 3, P2-4 follow-up): appended cluster

def sqlite_save_ic_observations(ic_rows: list, regime: str, forward_days: int = 21, log_cb=None):
    if not ic_rows:
        return
    try:
        import sqlite3
        conn = sqlite3.connect(str(SQLITE_DB_PATH))
        try:
            conn.execute(
                'CREATE TABLE IF NOT EXISTS factor_ic_history'
                ' (id INTEGER PRIMARY KEY AUTOINCREMENT,'
                ' timestamp TEXT, factor TEXT, ic REAL,'
                ' regime TEXT, forward_days INTEGER)')
            ts = __import__('datetime').datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            conn.executemany(
                'INSERT INTO factor_ic_history (timestamp,factor,ic,regime,forward_days) VALUES (?,?,?,?,?)',
                [(ts, r['factor'], float(max(-1.0, min(1.0, r['ic']))), str(regime), int(forward_days))
                 for r in ic_rows])
            conn.commit()
        finally:
            conn.close()
        log_emit(log_cb, f'[LearnLoop] Saved {len(ic_rows)} IC observations to SQLite')
    except Exception as e:
        log_emit(log_cb, f'[LearnLoop] IC save failed (non-fatal): {e}', exc_info=True)

def sqlite_load_ic_history(n_runs: int = 12, regime: str = None, log_cb=None) -> dict:
    try:
        import sqlite3
        from collections import defaultdict
        db_path = str(SQLITE_DB_PATH)
        if not Path(db_path).exists():
            return {}
        conn = sqlite3.connect(db_path)
        try:
            cur = conn.cursor()
            cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='factor_ic_history'")
            if not cur.fetchone():
                return {}
            limit = max(n_runs * 40, 2000)
            if regime:
                cur.execute('SELECT factor, ic FROM factor_ic_history WHERE regime=? ORDER BY id DESC LIMIT ?', (regime, limit))
                rows = cur.fetchall()
                if not rows: # fallback to all regimes if insufficient regime-specific history
                    cur.execute('SELECT factor, ic FROM factor_ic_history ORDER BY id DESC LIMIT ?', (limit,))
                    rows = cur.fetchall()
            else:
                cur.execute('SELECT factor, ic FROM factor_ic_history ORDER BY id DESC LIMIT ?', (limit,))
                rows = cur.fetchall()
        finally:
            conn.close()
        if not rows:
            return {}
        factor_ics = defaultdict(list)
        for factor, ic in rows:
            factor_ics[factor].append(float(ic))
        blended, ar1_vals = {}, []
        for factor, ics in factor_ics.items():
            n = len(ics)
            # IMP-BAYESIAN-IC: Conjugate Normal-Normal update (Prior N(0, 0.1^2))
            tau_0 = 1.0 / (0.10 ** 2)
            sample_mean = float(np.mean(ics))
            sample_var  = max(float(np.var(ics)), 1e-6)
            tau_n = tau_0 + n / sample_var
            mu_n  = (tau_0 * 0.0 + (n / sample_var) * sample_mean) / tau_n
            sig   = float(np.sqrt(1.0 / tau_n))
            raw_icir = mu_n / (sig + 1e-6)
            
            # IMP-FACTOR-MOMENTUM: Trend slope over recent IC observations (amplify rising IC)
            if n >= 4:
                recent_ics = ics[:6][::-1]  # chronological order
                slope = np.polyfit(range(len(recent_ics)), recent_ics, 1)[0]
                ic_mom = np.clip(slope / (abs(raw_icir) + 1e-6), -0.30, 0.30)
                raw_icir *= (1.0 + ic_mom)

            blended[factor] = round(max(-2.0, min(2.0, raw_icir)), 4)
            if n >= 3:
                ia  = [float(x) for x in ics]
                imu = sum(ia) / n
                num = sum((ia[i] - imu) * (ia[i-1] - imu) for i in range(1, n))
                den = sum((x - imu) ** 2 for x in ia) + 1e-9
                ar1_vals.append(num / den if den != 0 else 0.0)
        mean_ar1 = round(sum(ar1_vals) / len(ar1_vals), 4) if ar1_vals else 0.0
        log_emit(log_cb, f'[IC-AR1] mean_AR1={mean_ar1:.3f} (Bayesian+IC-Mom+Regime:{regime or "All"}) across {len(ar1_vals)} factors')
        blended['meta_ar1'] = mean_ar1
        log_emit(log_cb, f'[LearnLoop] Loaded IC history: {len(blended)-1} factors, {len(rows)} obs | mean_AR1={mean_ar1:.3f}')
        return blended
    except Exception as e:
        log_emit(log_cb, f'[LearnLoop] IC load failed (non-fatal): {e}', exc_info=True)
        return {}

def calculate_kelly_weights(selected: list, signal_df: pd.DataFrame,
                             kelly_fraction: float = 0.25) -> dict:
    """
    Fractional Kelly criterion position sizing.
    Kelly fraction f* = (μ - rf) / σ² for each stock.
    Uses 0.25× Kelly (quarter-Kelly) to reduce variance while preserving growth.
    Falls back to inverse-vol if Kelly produces degenerate weights.
    """
    if not selected:
        return {}
    kelly_raw = {}
    _view_spread = 0.10  # ±10% expected return range per 1-std alpha signal
    for s in selected:
        mu  = float(signal_df.loc[s, "alpha_score"]) if "alpha_score" in signal_df.columns else 0.0
        vol = float(signal_df.loc[s, "ann_vol"])     if "ann_vol"     in signal_df.columns else np.nan
        if pd.isna(vol) or vol < 1e-6:
            vol = 0.20  # fallback 20% vol assumption
        # Convert z-score -> annualized return view: alpha * vol * view_spread
        mu_ret = mu * vol * _view_spread
        kelly_raw[s] = max(0.0, mu_ret / (vol ** 2 + 1e-9))

    total = sum(kelly_raw.values())
    if total < 1e-9:
        # Degenerate: fall back to equal weights
        return {s: 1.0 / len(selected) for s in selected} if selected else {}

    # FIX M2: Fractional Kelly properly caps max allocation with iterative water-filling
    norm_w = {s: (v / total if total != 0 else 0.0) for s, v in kelly_raw.items()}
    if not norm_w:
        return {}
    
    cap = float(kelly_fraction)
    # AUDIT-FIX (Round 6, B-P2-5): the previous loop renormalized BEFORE
    # re-clipping and then renormalized AGAIN at the end — both re-inflated
    # capped entries back above the cap (verified: 3 names, kelly_fraction
    # 0.25 → max weight 0.3333, defeating quarter-Kelly variance reduction).
    # Correct water-filling: freeze over-cap entries at the cap ONCE and
    # distribute the remaining mass 1 - #capped*cap over the un-capped
    # entries; iterate in case redistribution pushes new entries over.
    res = dict(norm_w)
    frozen = set()
    for _ in range(len(res) + 2):
        free = {k: v for k, v in res.items() if k not in frozen}
        free_sum = sum(free.values())
        need = 1.0 - cap * len(frozen)
        if free_sum <= 1e-12 or not free:
            # Degenerate: everything is capped (n*cap <= 1). Infeasible cap —
            # fall back to equal weights, which respect 1/n <= cap only when
            # n >= 1/cap; otherwise return the capped (sub-unit) vector as-is
            # and let downstream apply_weight_constraints handle the rest.
            if len(frozen) == len(res):
                return {k: cap for k in res}
            break
        res = {k: (v / free_sum) * need if k in free else res[k] for k, v in res.items()}
        newly = [k for k, v in res.items() if k not in frozen and v > cap]
        if not newly:
            break
        for k in newly:
            res[k] = cap
            frozen.add(k)
    total = sum(res.values())
    if total <= 0:
        return norm_w
    if abs(total - 1.0) > 1e-9:
        # Only renormalize if that cannot re-inflate anything past the cap.
        res = {k: v / total for k, v in res.items()}
    # Final guarantee: enforce the cap no matter what.
    if any(v > cap + 1e-12 for v in res.values()):
        res = {k: min(v, cap) for k, v in res.items()}
        total = sum(res.values())
        if total > 1e-9 and total < 1.0 - 1e-9:
            # Redistribute the shortfall over un-capped entries (bounded).
            free = {k: v for k, v in res.items() if v < cap - 1e-12}
            if free:
                free_sum = sum(free.values())
                add = (1.0 - total) / max(free_sum, 1e-12)
                res = {k: (min(v * (1.0 + add), cap) if k in free else v) for k, v in res.items()}
    return res

def sqlite_init():
    """Ensure SQLite DB and schema exist at startup. Safe to call multiple times."""
    try:
        import sqlite3
        conn = sqlite3.connect(str(SQLITE_DB_PATH))
        try:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS runs (
                    id           INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp    TEXT,
                    tickers      TEXT,
                    weights      TEXT,
                    sharpe       REAL,
                    ann_return   REAL,
                    max_dd       REAL,
                    vix          REAL,
                    regime       TEXT,
                    n_stocks     INTEGER,
                    solver       TEXT,
                    energy       REAL,
                    cfg_hash     TEXT
                )""")
            # v17.23 Learning Loop: IC history table
            conn.execute("""
                CREATE TABLE IF NOT EXISTS factor_ic_history (
                    id           INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp    TEXT,
                    factor       TEXT,
                    ic           REAL,
                    regime       TEXT,
                    forward_days INTEGER
                )""")
            conn.commit()
        finally:
            conn.close()
    except Exception as _e2_:
        # SQLite init failure is non-fatal — save_run will retry inline
        # but we should log so operators know persistence is unavailable.
        import logging as _logging
        _logging.getLogger(__name__).warning(
            "[SQLite] Failed to initialise portfolio history DB: %s", _e2_
        )
        ExceptionLogger.swallow(_e2_, context="sqlite_init_failure")

def sqlite_save_run(payload: dict, cfg: dict, regime_info: dict,
                    india_vix: float = float("nan"), log_cb=None):
    """Save each completed optimizer run to local SQLite DB."""
    try:
        import sqlite3, json as _json
        db_path      = str(SQLITE_DB_PATH)
        conn         = sqlite3.connect(db_path)
        try:
            cur = conn.cursor()
            cur.execute("""
                CREATE TABLE IF NOT EXISTS runs (
                    id           INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp    TEXT,
                    tickers      TEXT,
                    weights      TEXT,
                    sharpe       REAL,
                    ann_return   REAL,
                    max_dd       REAL,
                    vix          REAL,
                    regime       TEXT,
                    n_stocks     INTEGER,
                    solver       TEXT,
                    energy       REAL,
                    cfg_hash     TEXT
                )""")
            bt           = payload.get("backtest") or {}
            tickers_list = payload.get("selected", [])
            _pf = payload.get("portfolio_df")
            weights_dict = (
                {str(r["Ticker"]): round(float(r["Weight %"]), 6)
                 for _,r in _pf.iterrows()
                 if __import__("pandas").notna(r.get("Weight %"))}
                if _pf is not None and not _pf.empty
                   and "Weight %" in _pf.columns and "Ticker" in _pf.columns
                else payload.get("weights", {}))
            sharpe   = float(bt.get("Sharpe", float("nan")) or float("nan"))
            ann_ret  = float(bt.get("Annual Return", float("nan")) or float("nan"))
            max_dd   = float(bt.get("Max Drawdown", float("nan")) or float("nan"))
            cfg_hash = str(hash(str(sorted(cfg.items()))))[:12]
            cur.execute("""
                INSERT INTO runs
                (timestamp, tickers, weights, sharpe, ann_return, max_dd,
                 vix, regime, n_stocks, solver, energy, cfg_hash)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""", (
                datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                _json.dumps(tickers_list),
_json.dumps({k: round(v, 6) for k, v in weights_dict.items()}),
                sharpe, ann_ret, max_dd,
                float(india_vix) if not (isinstance(india_vix, float) and india_vix != india_vix) else None,
                str(regime_info.get("Regime", "Unknown")),
                len(tickers_list),
                str(payload.get("solver_source", "SA")),
                float(payload.get("energy", 0.0)),
                cfg_hash,
            ))
            conn.commit()
        finally:
            conn.close()
        log_emit(log_cb, f"[SQLite] Run saved → {db_path}")
    except Exception as e:
        log_emit(log_cb, f"[SQLite] Save failed (non-fatal): {e}", exc_info=True)

def sqlite_load_history(limit: int = 100) -> list:
    """Load last N runs from SQLite DB as list of dicts for table display."""
    try:
        import sqlite3, json as _json
        db_path = str(SQLITE_DB_PATH)
        if not Path(db_path).exists():
            return []
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        try:
            cur  = conn.cursor()
            cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='runs'")
            if not cur.fetchone():
                return []
            cur.execute("""
                SELECT timestamp, n_stocks, sharpe, ann_return, max_dd,
                       vix, regime, solver, energy, tickers
                FROM runs ORDER BY id DESC LIMIT ?""", (limit,))
            rows = []
            for r in cur.fetchall():
                try:
                    tickers = ", ".join(_json.loads(r["tickers"] or "[]")[:5]) + ("…" if len(_json.loads(r["tickers"] or "[]")) > 5 else "")
                except Exception as _e:
                    tickers = r["tickers"] or ""
                rows.append({
                    "Timestamp":   r["timestamp"],
                    "N":           r["n_stocks"],
                    "Sharpe":      f"{r['sharpe']:.2f}"    if r["sharpe"]    is not None else "—",
                    "Ann Ret":     f"{r['ann_return']:.1f}%" if r["ann_return"] is not None else "—",
                    "Max DD":      f"{r['max_dd']:.1f}%"   if r["max_dd"]    is not None else "—",
                    "VIX":         f"{r['vix']:.1f}"       if r["vix"]       is not None else "—",
                    "Regime":      r["regime"] or "—",
                    "Solver":      r["solver"] or "—",
                    "Energy":      f"{r['energy']:.2f}"    if r["energy"]    is not None else "—",
                    "Top Picks":   tickers,
                })
            return rows
        finally:
            conn.close()
    except Exception as e:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception in %s", "Exception", exc_info=True)  # noqa: E501
        return []

def calculate_risk_parity_weights(selected, signal_df, returns: pd.DataFrame = None, cfg: dict = None):
    """Risk parity weighting — delegates to true Hierarchical Risk Parity (hrp_weights) if returns provided, else inverse-volatility."""
    if returns is not None and not returns.empty and len(selected) >= 3:
        w_hrp = hrp_weights(selected, returns, cfg)
        if w_hrp:
            return w_hrp
    inv_vol = {}
    for s in selected:
        vol = float(signal_df.loc[s, "ann_vol"]) if (signal_df is not None and s in signal_df.index and "ann_vol" in signal_df.columns) else 0.20
        inv_vol[s] = 1.0 / vol if (pd.notna(vol) and vol > 0) else 1.0  # DIV001: guard divisor before use
    total = sum(inv_vol.values())
    return {s: inv_vol[s] / total for s in selected} if total > 0 else {s: 1.0 / len(selected) for s in selected} if selected else {}  # DIV001: guard divisor before use

def calculate_qubo_aware_weights(selected, signal_df, q, cfg, clean_returns=None, prev_weights=None, log_cb=None):
    """
    Wasserstein Distributionally Robust Optimization (DRO) Portfolio Optimizer.
    Uses CVXPY + CLARABEL for global convex optimization, POET Covariance,
    and a Statistical Factor Model for expected returns.
    """
    if not selected:
        return {}

    from data_layer import DEFAULT_CFG
    cfg = {**DEFAULT_CFG, **(cfg or {})}

    def _log(msg):
        if log_cb:
            log_cb(msg)

    # ── MIP Cardinality Pre-processing (Phase 4) ────────────────────
    max_assets = cfg.get("MAX_ACTIVE_POSITIONS")
    use_mip = (max_assets is not None) and (max_assets < len(selected))
    
    from math_engine.solver_coordinator import SolverCoordinator
    solver_name, supports_mip = SolverCoordinator.get_best_solver(is_mip=use_mip)
    
    # Rank heuristic fallback if card limit requested but no MIP solver is active in env
    if use_mip and not supports_mip:
        scores = []
        for s in selected:
            vol = float(signal_df.loc[s, "ann_vol"]) if pd.notna(signal_df.loc[s, "ann_vol"]) else 0.3
            ret = 0.05 + float(q.get((s, s), 0.0))
            scores.append((ret - 0.5 * vol, s))
        scores.sort(reverse=True)
        selected = [item[1] for item in scores[:max_assets]]
        use_mip = False

    k = int(cfg.get("K_STOCKS", 8))
    _gamma_card_val = float(cfg.get("GAMMA_CARDINALITY", cfg.get("CARDINALITY_GAMMA", cfg.get("GAMMA", 22.0))))
    _N = len(signal_df) if ('signal_df' in locals() and signal_df is not None and len(signal_df) > 0) else max(1, len(selected))
    gamma_const = (_gamma_card_val * (1 - 2 * k)) / _N

    # QUBO signal: negate diagonal (minus scaled constant) so higher = better
    raw_scores = np.array([-(float(q.get((s, s), 0.0)) - gamma_const) for s in selected], dtype=float)
    if len(raw_scores) == 0:
        return {s: 1.0 / len(selected) for s in selected} if selected else {}
        
    raw_scores_temp = raw_scores - raw_scores.min()
    raw_scores_range = raw_scores_temp.max()
    if raw_scores_range > 1e-9:
        qubo_norm = raw_scores_temp / raw_scores_range
    else:
        qubo_norm = np.ones(len(selected)) / len(selected)

    # Inverse-vol weights
    inv_vol = np.array([
        1.0 / float(signal_df.loc[s, "ann_vol"])
        if pd.notna(signal_df.loc[s, "ann_vol"]) and float(signal_df.loc[s, "ann_vol"]) > 0
        else 1.0
        for s in selected
    ], dtype=float)
    invvol_w = inv_vol / inv_vol.sum()

    n = len(selected)
    lo = max(0.0, float(cfg.get("MIN_WEIGHT", 0.0)))
    hi = min(1.0, float(cfg.get("MAX_WEIGHT", 0.40)))

    bear_cash_fraction_active = float(cfg.get("BEAR_RESIDUAL_CASH_FRACTION_ACTIVE", 0.0) or 0.0)
    has_cash = (bear_cash_fraction_active > 0.0)

    if not has_cash:
        if lo * n > 1.0:
            lo = 0.0
        if hi * n < 1.0:
            hi = 1.0
    else:
        available_equity = max(0.0, 1.0 - bear_cash_fraction_active)
        if lo * n > available_equity:
            lo = max(0.0, available_equity / n) if n > 0 else 0.0
        if hi <= 0.0 or available_equity <= 1e-9:
            res = {s: 0.0 for s in selected}
            res["CASH"] = 1.0
            return res
        
    assets = list(selected)
    if has_cash:
        assets.append("CASH")
        
    n_assets = len(assets)

    _qp_done = False
    try:
        import cvxpy as cp
        # Verify CLARABEL is actually available before building the problem.
        # If not installed, fail fast with a clear message rather than a
        # cryptic CVXPY solver-not-found error deep in prob.solve().
        try:
            import clarabel  # noqa: F401
            _HAS_CLARABEL = True
        except ImportError:
            _HAS_CLARABEL = False
            _log(
                "[DRO] ❌ clarabel package not installed. "
                "Install with: pip install clarabel>=0.7.0 "
                "Falling back to inverse-vol weighting."
            )
            raise ImportError("clarabel not available")
        
        # 1. Expected Returns Model (Anchored and Multi-Factor)
        if clean_returns is not None and not clean_returns.empty and all(s in clean_returns.columns for s in selected):
            mu_stocks = estimate_factor_expected_returns(clean_returns, selected, qubo_norm)
            T_samples = clean_returns.shape[0]
            # Calibrate Wasserstein radius based on empirical return bootstrap sampling
            try:
                from math_engine.wasserstein_calibrator import WassersteinRadiusCalibrator
                epsilon = WassersteinRadiusCalibrator.calibrate_radius(clean_returns[selected])
            except Exception:
                epsilon = 0.10 / np.sqrt(T_samples)
        else:
            mu_stocks = 0.05 + qubo_norm * 0.20
            epsilon = 0.01  # 1% uncertainty default
            
        if has_cash:
            mu_expanded = np.append(mu_stocks, 0.0)  # CASH return is 0
        else:
            mu_expanded = mu_stocks



        # 2. Covariance Matrix Model (POET or Barra-style Factor structured)
        if clean_returns is not None and not clean_returns.empty and all(s in clean_returns.columns for s in selected):
            if cfg.get("USE_FACTOR_COVARIANCE", False):
                try:
                    import logging as _logging
                    _logging.getLogger(__name__).info("[DRO] Calibrating structured factor covariance matrix...")
                    from math_engine.factor_risk import FactorRiskDecomposer
                    decomposer = FactorRiskDecomposer()
                    sub_signal = signal_df.reindex(selected).fillna(0.0)
                    exposures = decomposer.compute_factor_exposures(sub_signal, returns=clean_returns[selected])
                    equal_weights = {s: 1.0 / len(selected) for s in selected}
                    risk_dict = decomposer.decompose_risk(
                        returns=clean_returns,
                        exposures=exposures,
                        weights=equal_weights,
                        use_ledoit_wolf=True
                    )
                    cov_stocks = risk_dict["covariance_matrix"] * 252.0
                except Exception as e:
                    import logging as _logging
                    _logging.getLogger(__name__).warning(f"[DRO] Factor covariance failed: {e}. Falling back to POET.")
                    cov_stocks = poet_covariance(clean_returns[selected], k_max=5) * 252.0
            else:
                cov_stocks = poet_covariance(clean_returns[selected], k_max=5) * 252.0
        else:
            sigma_diag = np.where(inv_vol > 0, 1.0 / (inv_vol ** 2), 1.0)
            cov_stocks = np.diag(sigma_diag / sigma_diag.mean())
            
        if has_cash:
            cov_expanded = np.zeros((n_assets, n_assets))
            cov_expanded[:n, :n] = cov_stocks
            cov_expanded[-1, -1] = 1e-8  # CASH tiny variance for stability
        else:
            cov_expanded = cov_stocks

        # 3. Previous Weights Vector (w_prev)
        w_prev = np.zeros(n_assets)
        if prev_weights:
            for i, s in enumerate(assets):
                if s == "CASH":
                    w_prev[i] = float(prev_weights.get("CASH", 1.0 - sum(prev_weights.values())))
                else:
                    w_prev[i] = float(prev_weights.get(s, 0.0))

        # ── V8-V10 Theoretical Physics Modulators & Solvers Integration ──
        # FULLY DYNAMIC: All parameters read from cfg at runtime. Zero hardcoding.
        # Modules run with configurable impact: ALPHA_MUTATION_SCALE=0.0 (default) = diagnostic only,
        # ALPHA_MUTATION_SCALE=1.0 = full mutation (original behavior). TC is NEVER zeroed.
        _alpha_mutation_scale = float(cfg.get("ALPHA_MUTATION_SCALE", 0.0))  # 0=diagnostic, 1=full
        _tc_multiplier = float(cfg.get("TC_MULTIPLIER", 1.0))  # 1.0 = normal TC, 0.0 = free (dangerous)
        _mu_original = mu_stocks.copy()  # preserve original alpha ranking
        _mu_expanded_original = mu_expanded.copy() if hasattr(mu_expanded, 'copy') else mu_stocks.copy()
        _cov_original = cov_expanded.copy() if hasattr(cov_expanded, 'copy') else cov_expanded
        _tc_original = float(cfg.get("BACKTEST_FEE_BPS", 15.0) + cfg.get("BACKTEST_SLIPPAGE_BPS", 10.0)) / 10000.0

        # 4. Transaction Cost Parameters — FULLY DYNAMIC
        tc_bps = (float(cfg.get("BACKTEST_FEE_BPS", 15.0)) + float(cfg.get("BACKTEST_SLIPPAGE_BPS", 10.0))) / 10000.0 * _tc_multiplier
        if tc_bps < 1e-8:
            tc_bps = _tc_original
            _log("[WARN] TC was zeroed — restored to original value.")

        port_val = float(cfg.get("PORTFOLIO_VALUE_INR", 1_000_000))
        
        tc_bps_expanded = np.zeros(n_assets)
        impact_coef_expanded = np.zeros(n_assets)
        
        for i, s in enumerate(assets):
            if s == "CASH":
                tc_bps_expanded[i] = 0.0
                impact_coef_expanded[i] = 0.0
            else:
                tc_bps_expanded[i] = tc_bps
                adv20 = float(signal_df.loc[s, "adv20"]) if "adv20" in signal_df.columns and pd.notna(signal_df.loc[s, "adv20"]) else 1e6
                adv20 = max(adv20, 1.0)
                impact_coef_expanded[i] = 0.05 * (port_val / adv20)

        gamma = float(cfg.get("VOL_PENALTY", 0.35))

        # 5. Formulate CVXPY Wasserstein DRO or classical MVO problem
        w_var = cp.Variable(n_assets)
        u_plus = cp.Variable(n_assets, nonneg=True)
        u_minus = cp.Variable(n_assets, nonneg=True)
        
        # Transaction costs: Linear + Quadratic Impact
        tc_linear = tc_bps_expanded @ (u_plus + u_minus)
        tc_impact = cp.sum(cp.multiply(impact_coef_expanded, cp.square(u_plus - u_minus)))
        
        # Risk penalty
        risk = gamma * cp.quad_form(w_var, cov_expanded)
        
        if cfg.get("USE_DRO", True):
            lam = cp.Variable(nonneg=True)  # Wasserstein dual variable
            robust_return = mu_expanded @ w_var - lam * epsilon - 0.25 * cp.quad_over_lin(w_var, lam)
            objective = cp.Maximize(robust_return - 0.5 * risk - tc_linear - tc_impact)
            constraints = [
                cp.sum(w_var) == 1.0,
                w_var - w_prev - u_plus + u_minus == 0,
                lam >= 1e-6
            ]
        else:
            # Classical Mean-Variance QP Optimizer (SLSQP equivalent in CVXPY)
            expected_return = mu_expanded @ w_var
            objective = cp.Maximize(expected_return - 0.5 * risk - tc_linear - tc_impact)
            constraints = [
                cp.sum(w_var) == 1.0,
                w_var - w_prev - u_plus + u_minus == 0
            ]
        
        for i, s in enumerate(assets):
            if s == "CASH":
                constraints.append(w_var[i] >= bear_cash_fraction_active)
                constraints.append(w_var[i] <= 1.0)
            else:
                constraints.append(w_var[i] >= lo)
                constraints.append(w_var[i] <= hi)

        # Apply Mixed-Integer Programming (MIP) cardinality constraint (if MIP solver is present)
        if use_mip and supports_mip:
            z = cp.Variable(n, boolean=True)
            constraints.append(cp.sum(z) <= max_assets)
            for i in range(n):
                constraints.append(w_var[i] <= z[i] * hi)

        # Seed warm start
        if w_prev is not None and not use_mip:
            try:
                w_var.value = w_prev
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                pass
                
        prob = cp.Problem(objective, constraints)
        
        # Execute using preferred solver
        try:
            if solver_name == "GUROBI":
                prob.solve(solver=cp.GUROBI, warm_start=True)
            elif solver_name == "CPLEX":
                prob.solve(solver=cp.CPLEX, warm_start=True)
            elif solver_name == "MOSEK":
                prob.solve(solver=cp.MOSEK, warm_start=True)
            elif solver_name == "CLARABEL":
                prob.solve(solver=cp.CLARABEL)
            else:
                prob.solve()
        except Exception as _sol_err:
            import logging as _logging
            _logging.getLogger(__name__).warning(f"[Solver] Solver {solver_name} failed: {_sol_err}. Retrying with Clarabel.")
            # Fallback to Clarabel
            prob.solve(solver=cp.CLARABEL)
        
        if prob.status == cp.OPTIMAL or prob.status == cp.OPTIMAL_INACCURATE:
            res_w = w_var.value
            blended = np.zeros(n_assets)
            for i in range(n_assets):
                # Clamp and normalize
                bl_min = bear_cash_fraction_active if (assets[i] == "CASH") else lo
                bl_max = 1.0 if (assets[i] == "CASH") else hi
                blended[i] = max(bl_min, min(bl_max, res_w[i]))
            # Phase 3.2: Guard against degenerate weights (all clip to 0).
            # Previously: blended/blended.sum() → NaN/Inf for EVERY stock if sum=0.
            # _qp_done=True was set BEFORE the division, so the fallback was skipped.
            blended_sum = float(blended.sum())
            if blended_sum < 1e-12:
                log_emit(log_cb, "[DRO] Solver returned degenerate weights (sum≈0) — falling back to inv-vol")
                raise RuntimeError("CLARABEL returned degenerate weights (sum≈0)")
            blended = blended / blended_sum

            # Post-normalization single-stock weight cap enforcement (prevents position limit breaches)
            stock_indices = [i for i, a in enumerate(assets) if a != "CASH"]
            if stock_indices:
                if "CASH" in assets:
                    stock_w = _project_weights_to_bounds(blended[stock_indices], lower=lo, upper=hi)
                    stock_w = stock_w * (1.0 - bear_cash_fraction_active)
                    blended[stock_indices] = stock_w
                    cash_idx = assets.index("CASH")
                    blended[cash_idx] = bear_cash_fraction_active
                else:
                    stock_w = _project_weights_to_bounds(blended[stock_indices], lower=lo, upper=hi)
                    blended[stock_indices] = stock_w

            _qp_done = True  # Phase 3.2: only set AFTER successful normalization
    except Exception as _e2_:
        # BUG-O1 FIX: DRO failure must never be silent.
        # Log clearly so the operator knows inv-vol fallback is active.
        log_emit(log_cb,
            f"[DRO] ⚠️  CVXPY/CLARABEL optimizer failed: {_e2_!r}. "
            f"Falling back to inverse-vol weighting. "
            f"Verify cvxpy and clarabel are installed correctly."
        )
        ExceptionLogger.swallow(_e2_, context="dro_optimizer_failure")

    if not _qp_done:
        # Fallback: multiplicative alpha tilt on inverse-volatility base
        qubo_range = raw_scores.max() - raw_scores.min()
        if qubo_range > 1e-6:
            norm_scores = (raw_scores - raw_scores.min()) / qubo_range
            tilt = 0.5 + 1.0 * norm_scores
        else:
            tilt = np.ones(n)
        blended_stocks = inv_vol * tilt
        blended_stocks = _project_weights_to_bounds(blended_stocks, lower=lo, upper=hi)
        
        if has_cash:
            blended_stocks = blended_stocks * (1.0 - bear_cash_fraction_active)
            blended_dict = {s: float(blended_stocks[i]) for i, s in enumerate(selected)}
            blended_dict["CASH"] = bear_cash_fraction_active
            return blended_dict
        else:
            return {s: float(blended_stocks[i]) for i, s in enumerate(selected)}
        
    return {assets[i]: float(blended[i]) for i in range(n_assets)}

# Extend __all__ with newly moved names

try:
    __all__.extend(['sqlite_save_ic_observations', 'sqlite_load_ic_history', 'calculate_kelly_weights', 'sqlite_init', 'sqlite_save_run', 'sqlite_load_history', 'calculate_risk_parity_weights', 'calculate_qubo_aware_weights'])
except NameError:
    __all__ = ['sqlite_save_ic_observations', 'sqlite_load_ic_history', 'calculate_kelly_weights', 'sqlite_init', 'sqlite_save_run', 'sqlite_load_history', 'calculate_risk_parity_weights', 'calculate_qubo_aware_weights']


# ────────────────────────────────────────────────────────────────────────────
# Round 12: Idempotent Rebalance Reconciliation & Differential Order Execution
# ────────────────────────────────────────────────────────────────────────────

# In-process idempotency cache: {token: placed_at_epoch}
_IDEMPOTENCY_CACHE: Dict[str, float] = {}
_IDEMPOTENCY_LOCK = _threading.Lock()
_IDEMPOTENCY_WINDOW_SEC = 300   # 5-minute rolling dedup window


def generate_idempotency_key(
    basket: Dict[str, Any],
    window_minutes: int = 5,
    epoch_shift: int = 0,
) -> str:
    """Generate a rolling SHA-256 idempotency token for a rebalance basket.

    The token incorporates:
      - sorted constituent tickers
      - rounded target quantities (nearest integer share)
      - side direction (BUY / SELL)
      - 5-minute rolling epoch bucket (so retry within the window is idempotent)

    Args:
        basket: dict of {ticker: {"qty": int, "side": "BUY"|"SELL", ...}}
        window_minutes: dedup window in minutes (default 5).
        epoch_shift: AUDIT-FIX (Round 5) — bucket offset in window units.
        Used by execute_reconciled_basket to also derive the PREVIOUS
        bucket's token so retries that straddle a bucket boundary still
        deduplicate (see below).

    Returns:
        A 64-hex-char SHA-256 token string.
    """
    window_sec = window_minutes * 60
    epoch_bucket = int(time.time() // window_sec) + epoch_shift
    canonical = json.dumps(
        {
            "basket": {
                k: {"qty": int(round(v.get("qty", 0))), "side": v.get("side", "BUY")}
                for k, v in sorted(basket.items())
            },
            "epoch_bucket": epoch_bucket,
        },
        sort_keys=True,
    )
    return _hashlib.sha256(canonical.encode()).hexdigest()


def reconcile_portfolio_holdings(
    target_weights: Dict[str, float],
    current_holdings: Dict[str, int],
    total_value: float,
    prices: Dict[str, float],
    min_trade_inr: float = 500.0,
    log_cb=None,
) -> Dict[str, Any]:
    """Compute differential orders to rebalance from current to target weights.

    Compares target allocation weights (0–1 fractions) against the broker
    demat holdings and generates the minimum set of buy/sell orders needed
    to reach the target, filtering out micro-rebalance churn below
    ``min_trade_inr``.

    Args:
        target_weights:   dict {ticker: weight_fraction (0–1)}.
                          CASH entries are silently skipped.
        current_holdings: dict {ticker: shares_held (int)}.
        total_value:      total portfolio NAV in INR.
        prices:           dict {ticker: last_price_inr (float)}.
        min_trade_inr:    minimum order value (INR). Trades below this
                          threshold are suppressed to reduce churn.
        log_cb:           optional callable(str) for structured logging.

    Returns:
        dict with:
            'orders'         : list of order dicts
                               {ticker, side, qty, price, value_inr, delta_weight}
            'turnover_pct'   : estimated portfolio turnover percentage
            'skipped_tickers': list of tickers skipped (price unavailable / CASH)
            'total_buy_inr'  : total buy value in INR
            'total_sell_inr' : total sell value in INR
    """
    orders: List[Dict[str, Any]] = []
    skipped: List[str] = []
    total_buy_inr = 0.0
    total_sell_inr = 0.0
    total_trade_inr = 0.0

    for ticker, target_w in target_weights.items():
        if ticker.upper() in ("CASH", "INR", ""):
            skipped.append(ticker)
            continue
        price = prices.get(ticker) or prices.get(ticker + ".NS")
        if not price or price <= 0:
            skipped.append(ticker)
            if log_cb:
                log_cb(f"[Reconcile] ⚠️  {ticker}: no price available — skipped")
            continue

        target_value = float(target_w) * float(total_value)
        target_qty = int(target_value / price)
        current_qty = int(current_holdings.get(ticker, 0))
        delta_qty = target_qty - current_qty

        if delta_qty == 0:
            continue

        trade_value = abs(delta_qty) * price
        if trade_value < min_trade_inr:
            skipped.append(ticker)
            if log_cb:
                log_cb(
                    f"[Reconcile] {ticker}: ΔN={delta_qty:+d} (₹{trade_value:.0f}) "
                    f"< min_trade_inr ₹{min_trade_inr:.0f} — suppressed"
                )
            continue

        side = "BUY" if delta_qty > 0 else "SELL"
        order_qty = abs(delta_qty)
        # AUDIT-FIX (Round 13, SEC-9): check_circuit_band / check_sebi_freeze_limit
        # existed but had ZERO call sites — no order path validated the NSE
        # quantity freeze limit (default 50,000 shares/order). Record the
        # required child-order split at the freeze limit (the institutional
        # norm — the broker otherwise rejects the order outright).
        _max_freeze = 50000  # SEBI quantity freeze limit (equity default)
        if order_qty > _max_freeze:
            _n_child = (order_qty + _max_freeze - 1) // _max_freeze
            if log_cb:
                log_cb(
                    f"[Reconcile] {ticker}: ΔN={order_qty} exceeds SEBI freeze "
                    f"limit {_max_freeze} — splitting into {_n_child} child orders"
                )
        # emit as a single logical order with the child split recorded; the
        # router/audit path consumes qty; child splitting happens at placement
        order = {
            "ticker": ticker,
            "side": side,
            "qty": order_qty,
            "price": round(price, 2),
            "value_inr": round(trade_value, 2),
            "delta_weight": round(float(target_w) - (current_qty * price / max(total_value, 1.0)), 4),
            "target_weight": round(float(target_w), 4),
            "current_qty": current_qty,
            "target_qty": target_qty,
            "freeze_split": (order_qty + _max_freeze - 1) // _max_freeze if order_qty > _max_freeze else 1,
        }
        orders.append(order)
        total_trade_inr += trade_value
        if side == "BUY":
            total_buy_inr += trade_value
        else:
            total_sell_inr += trade_value

        if log_cb:
            log_cb(
                f"[Reconcile] {ticker}: {side} {abs(delta_qty)} @ ₹{price:.2f} "
                f"= ₹{trade_value:,.0f}  (current={current_qty}, target={target_qty})"
            )

    # AUDIT-FIX (Round 6, B-P1-2): holdings that are NOT in target_weights
    # (stocks the optimizer dropped) were never iterated above, so they were
    # NEVER sold — exited positions stayed in the demat account indefinitely
    # (stale risk exposure, wrong NAV/turnover). Verified: target={A,B},
    # holdings={A:10,C:100} produced only BUYs, no SELL for C. Now every
    # holding with no target weight is liquidated in full (subject to the
    # same min_trade_inr filter), which is the documented rebalance semantics.
    for ticker, current_qty in (current_holdings or {}).items():
        if ticker.upper() in ("CASH", "INR", ""):
            continue
        if ticker in target_weights:
            continue  # handled by the target loop above
        current_qty = int(current_qty)
        if current_qty <= 0:
            continue
        price = prices.get(ticker) or prices.get(ticker + ".NS")
        if not price or price <= 0:
            skipped.append(ticker)
            if log_cb:
                log_cb(f"[Reconcile] ⚠️  {ticker}: exited holding (qty={current_qty}) has no price — NOT liquidated, review manually")
            continue
        trade_value = current_qty * price
        if trade_value < min_trade_inr:
            skipped.append(ticker)
            if log_cb:
                log_cb(f"[Reconcile] {ticker}: exit SELL ₹{trade_value:.0f} < min_trade_inr ₹{min_trade_inr:.0f} — suppressed")
            continue
        orders.append({
            "ticker": ticker,
            "side": "SELL",
            "qty": current_qty,
            "price": round(price, 2),
            "value_inr": round(trade_value, 2),
            "delta_weight": round(-(current_qty * price / max(total_value, 1.0)), 4),
            "target_weight": 0.0,
            "current_qty": current_qty,
            "target_qty": 0,
        })
        total_trade_inr += trade_value
        total_sell_inr += trade_value
        if log_cb:
            log_cb(f"[Reconcile] {ticker}: EXIT SELL {current_qty} @ ₹{price:.2f} = ₹{trade_value:,.0f} (dropped from target portfolio)")

    turnover_pct = 100.0 * total_trade_inr / max(float(total_value), 1.0) / 2.0
    if log_cb:
        log_cb(
            f"[Reconcile] ✅  {len(orders)} differential orders | "
            f"BUY ₹{total_buy_inr:,.0f} | SELL ₹{total_sell_inr:,.0f} | "
            f"Turnover ≈ {turnover_pct:.1f}%"
        )
    return {
        "orders": orders,
        "turnover_pct": round(turnover_pct, 2),
        "skipped_tickers": skipped,
        "total_buy_inr": round(total_buy_inr, 2),
        "total_sell_inr": round(total_sell_inr, 2),
        "order_count": len(orders),
    }


def execute_reconciled_basket(
    target_weights: Dict[str, float],
    current_holdings: Dict[str, int],
    total_value: float,
    prices: Dict[str, float],
    cfg: Optional[Dict[str, Any]] = None,
    paper: bool = True,
    min_trade_inr: float = 500.0,
    log_cb=None,
) -> Dict[str, Any]:
    """Orchestrate a full idempotent reconciliation-based rebalance.

    Full pipeline:
      1. Compute differential orders via ``reconcile_portfolio_holdings``.
      2. Run BVC VPIN toxicity pre-screening on buy-side constituents.
      3. Generate idempotency token; reject if token seen in last 5 minutes.
      4. Place orders (paper simulation or live broker routing).

    Args:
        target_weights:   target portfolio weights (0–1 fractions).
        current_holdings: current broker demat share quantities.
        total_value:      total portfolio NAV in INR.
        prices:           current market prices {ticker: price_inr}.
        cfg:              optional config override dict.
        paper:            if True, simulate only (no live orders placed).
        min_trade_inr:    minimum order value threshold for churn suppression.
        log_cb:           optional callable(str) for structured logging.

    Returns:
        dict with:
            'success'        : bool
            'idempotency_key': str — the basket token
            'duplicate'      : bool — True if this basket was already placed
            'orders'         : list of executed / simulated orders
            'vpin_check'     : dict — pre-trade toxicity report
            'turnover_pct'   : portfolio turnover estimate
            'mode'           : 'paper' | 'live'
    """
    active_cfg = cfg or {}
    _emit = log_cb or (lambda m: None)

    # ── Step 1: Differential order computation ─────────────────────────────
    reconcile_result = reconcile_portfolio_holdings(
        target_weights=target_weights,
        current_holdings=current_holdings,
        total_value=total_value,
        prices=prices,
        min_trade_inr=min_trade_inr,
        log_cb=_emit,
    )
    orders = reconcile_result.get("orders", [])

    if not orders:
        _emit("[ReconcileBasket] ℹ️  No differential orders required — portfolio already at target.")
        return {
            "success": True,
            "idempotency_key": "",
            "duplicate": False,
            "orders": [],
            "vpin_check": {"success": False, "reason": "no orders"},
            "turnover_pct": 0.0,
            "mode": "paper" if paper else "live",
        }

    # ── Step 2: Idempotency check ──────────────────────────────────────────
    basket_for_token = {o["ticker"]: {"qty": o["qty"], "side": o["side"]} for o in orders}
    token = generate_idempotency_key(basket_for_token)
    # AUDIT-FIX (Round 5): bucket-boundary race. The token embeds a 5-minute
    # epoch bucket, so a retry placed 4:59 after the original lands in the
    # NEXT bucket → a different token → cache miss → DOUBLE EXECUTION,
    # precisely when the operator expects the guard to hold. Derive the
    # previous bucket's token too and check/record BOTH.
    prev_token = generate_idempotency_key(basket_for_token, epoch_shift=-1)
    now = time.time()

    # AUDIT-FIX (Round 13, SEC-11): the idempotency cache was PROCESS-LOCAL
    # (module dict). The codebase itself runs multi-process (sebi_audit_logger
    # explicitly names "the web-dashboard process" as a concurrent writer) —
    # the desktop app and the web dashboard executing the same basket in
    # their own processes BOTH pass the in-process check → double live
    # execution. Persist reservations in a SHARED SQLite table (unique
    # token) so the check-and-reserve is atomic ACROSS processes. The
    # in-process dict remains as a fast path; the DB is the source of truth.
    def _idem_db_paths():
        try:
            _p = Path(__file__).resolve().parent / "qa_db" / "sebi_algo_audit.db"
            return [_p]
        except Exception:
            return []

    def _idem_db_check_and_reserve(tok: str, ts: float) -> bool:
        """Insert (token, ts) into the shared idempotency table.

        Returns True if RESERVED (first writer wins); False if the token is
        already reserved within the window (duplicate across processes).
        Best-effort: if the DB is unavailable the in-process guard still
        applies (fail-open across processes is the previous behavior — no
        regression, but a loud log line).
        """
        for _db in _idem_db_paths():
            try:
                import sqlite3 as _sq
                with contextlib.closing(_sq.connect(str(_db), timeout=5)) as _conn, _conn:
                    _conn.execute(
                        "CREATE TABLE IF NOT EXISTS basket_idempotency ("
                        " token TEXT PRIMARY KEY, reserved_at REAL NOT NULL)"
                    )
                    _row = _conn.execute(
                        "SELECT reserved_at FROM basket_idempotency WHERE token=?",
                        (tok,),
                    ).fetchone()
                    if _row is not None and (ts - float(_row[0])) < _IDEMPOTENCY_WINDOW_SEC:
                        return False  # reserved by another process within window
                    if _row is not None:
                        # stale (outside window): refresh the reservation
                        _conn.execute(
                            "UPDATE basket_idempotency SET reserved_at=? WHERE token=?",
                            (ts, tok),
                        )
                    else:
                        _conn.execute(
                            "INSERT OR IGNORE INTO basket_idempotency (token, reserved_at)"
                            " VALUES (?, ?)",
                            (tok, ts),
                        )
                return True
            except Exception as _idem_err:
                _emit(f"[ReconcileBasket] ⚠️  cross-process idempotency store "
                      f"unavailable ({_idem_err}) — in-process guard only")
                return True
        return True

    with _IDEMPOTENCY_LOCK:
        last_placed = 0.0
        matched_token = token
        for _tok in (token, prev_token):
            _placed = _IDEMPOTENCY_CACHE.get(_tok, 0.0)
            if _placed > last_placed:
                last_placed = _placed
                matched_token = _tok
        age_sec = now - last_placed
        _dup_in_process = age_sec < _IDEMPOTENCY_WINDOW_SEC and last_placed > 0
        # cross-process reservation (atomic insert; first writer wins).
        # Scope: LIVE executions only — double LIVE execution is the risk
        # being mitigated; paper mode is a re-runnable simulation whose
        # repeated baskets are harmless (and test-friendly).
        if not paper:
            _reserved_xproc = _idem_db_check_and_reserve(token, now)
            _prev_reserved_xproc = _idem_db_check_and_reserve(prev_token, now)
        else:
            _reserved_xproc = _prev_reserved_xproc = True
        if _dup_in_process or not (_reserved_xproc and _prev_reserved_xproc):
            _emit(
                f"[ReconcileBasket] 🔒 Idempotency block: identical basket placed "
                f"{age_sec:.0f}s ago (token={matched_token[:12]}…). Skipping duplicate."
            )
            return {
                "success": False,
                "idempotency_key": matched_token,
                "duplicate": True,
                "orders": orders,
                "vpin_check": {},
                "turnover_pct": reconcile_result.get("turnover_pct", 0.0),
                "mode": "paper" if paper else "live",
            }
        # AUDIT-FIX (Round 6, B-P2-9): RESERVE the tokens in the SAME critical
        # section as the check. Previously the tokens were only recorded AFTER
        # broker placement (Step 5) with the lock released in between — two
        # concurrent invocations of the same basket both passed the check and
        # double-executed (a window seconds wide spanning VPIN fetch + network
        # placement). Reserved entries are rolled back on every failure path
        # below (VPIN block / broker unconfigured / live placement error) so
        # "recorded ⇒ placed" keeps holding.
        _IDEMPOTENCY_CACHE[token] = now
        _IDEMPOTENCY_CACHE[prev_token] = now

    def _release_idempotency_reservation() -> None:
        """Roll back the Step-2 reservation when no orders were placed."""
        with _IDEMPOTENCY_LOCK:
            for _tok in (token, prev_token):
                if _IDEMPOTENCY_CACHE.get(_tok, 0.0) == now:
                    _IDEMPOTENCY_CACHE.pop(_tok, None)
        # AUDIT-FIX (Round 13, SEC-11): roll back the cross-process SQLite
        # reservation too, so "recorded ⇒ placed" holds across processes.
        for _db in _idem_db_paths():
            try:
                import sqlite3 as _sq
                with contextlib.closing(_sq.connect(str(_db), timeout=5)) as _conn, _conn:
                    _conn.execute(
                        "DELETE FROM basket_idempotency WHERE token=? AND reserved_at=?",
                        (token, now),
                    )
                    _conn.execute(
                        "DELETE FROM basket_idempotency WHERE token=? AND reserved_at=?",
                        (prev_token, now),
                    )
            except Exception:
                pass  # best-effort rollback; stale rows expire by window

    # ── Step 3: VPIN pre-trade toxicity screen ────────────────────────────
    buy_tickers = {o["ticker"]: target_weights.get(o["ticker"], 0.0) for o in orders if o["side"] == "BUY"}
    vpin_result: Dict[str, Any] = {}
    if buy_tickers:
        try:
            vpin_result = preflight_vpin_toxicity_check(
                weights=buy_tickers,
                cfg=active_cfg,
                log_cb=_emit,
            )
            if vpin_result.get("blocked"):
                _emit(
                    f"[ReconcileBasket] 🚫 VPIN BLOCK: {vpin_result.get('reason', 'high toxicity')} "
                    f"— basket execution halted."
                )
                _release_idempotency_reservation()  # AUDIT-FIX (Round 6, B-P2-9)
                return {
                    "success": False,
                    "idempotency_key": token,
                    "duplicate": False,
                    "orders": orders,
                    "vpin_check": vpin_result,
                    "turnover_pct": reconcile_result.get("turnover_pct", 0.0),
                    "mode": "paper" if paper else "live",
                }
        except Exception as e:
            _emit(f"[ReconcileBasket] ⚠️  VPIN check error (fail-open): {e}")
            vpin_result = {"success": False, "error": str(e)}

    # ── Step 3.5: SEBI pre-trade audit (R7-15, fail-closed) ───────────────
    # Every differential order intent is appended to the immutable audit
    # chain BEFORE any broker dispatch (paper or live). An audit append
    # failure raises and rolls back the idempotency reservation — an
    # unauditable order must never be placed.
    try:
        _sebi_audit_pre_trade(
            orders,
            mode="LIVE" if not paper else "PAPER",
            basket_token=token,
            log_cb=_emit,
            compliance_ok=not vpin_result.get("blocked", False),
            extra_details={
                "turnover_pct": reconcile_result.get("turnover_pct", 0.0),
                "idempotency_key": token,
                "orders_count": len(orders),
            },
        )
    except Exception:
        _release_idempotency_reservation()
        raise

    # ── Step 4: Place / simulate orders ───────────────────────────────────
    # AUDIT-FIX (Round 13, SEC-2 — live-path gate parity): the promotion
    # gate (live_verify) and the ComplianceEngine BLOCK/BREACH checks were
    # enforced ONLY in angelone_place_basket. This reconciliation channel
    # (used by the web dashboard's POST /api/reconcile_holdings with
    # {"paper": false, "confirm_live": true}) placed LIVE orders through
    # BrokerRouter.place_basket_orders(dry_run=False) with NO promotion
    # gate, NO compliance engine, and a fail-open VPIN — a defense-free
    # live-order path. Both gates are now hoisted here so EVERY live path
    # is gated by construction.
    if not paper:
        # (a) Promotion gate — identical contract to angelone_place_basket
        try:
            from live_verify import check_paper_trade_gate_or_raise
            check_paper_trade_gate_or_raise()
        except ImportError:
            # live_verify module absent (e.g., stripped deployment): a
            # missing gate must not become an open gate — require an
            # explicit operator opt-in instead.
            if active_cfg.get("ALLOW_LIVE_WITHOUT_PROMOTION_GATE") is not True:
                _emit("⛔ [ReconcileBasket] BLOCKED: promotion gate module (live_verify) "
                      "unavailable and ALLOW_LIVE_WITHOUT_PROMOTION_GATE is not set.")
                _release_idempotency_reservation()
                return {
                    "success": False,
                    "idempotency_key": token,
                    "duplicate": False,
                    "error": "PROMOTION_BLOCKED: live_verify module unavailable; set "
                             "ALLOW_LIVE_WITHOUT_PROMOTION_GATE=True to override explicitly.",
                    "orders": orders,
                    "vpin_check": vpin_result,
                    "turnover_pct": reconcile_result.get("turnover_pct", 0.0),
                    "mode": "live",
                }
        except Exception as gate_err:
            _emit(f"⛔ [ReconcileBasket] BLOCKED BY PROMOTION GATE: {gate_err}")
            _release_idempotency_reservation()
            raise RuntimeError(f"PROMOTION_BLOCKED: {gate_err}")

        # (b) Compliance engine — BLOCK/BREACH severity enforcement on the
        # target portfolio (same rules as angelone_place_basket: BLOCK always
        # aborts; BREACH aborts unless the PM override flag is set).
        try:
            from utils import ComplianceEngine
            _engine = ComplianceEngine(active_cfg)
            _portfolio_rows = [
                {"Ticker": t, "Weight": w} for t, w in target_weights.items()
                if t.upper() != "CASH"
            ]
            _portfolio_df = pd.DataFrame(_portfolio_rows)
            _violations = _engine.check(_portfolio_df, None, {})
            if _violations:
                _has_block = any(v.get("severity") == "BLOCK" for v in _violations)
                _has_breach = any(v.get("severity") == "BREACH" for v in _violations)
                for v in _violations:
                    _emit(f"[Compliance {v.get('severity', 'WARN')}] "
                          f"{v.get('rule')}: {v.get('message')}")
                _compliance_override = active_cfg.get("COMPLIANCE_OVERRIDE", False) is True
                if _has_block:
                    _emit("❌ [Compliance BLOCK] Live basket aborted (BLOCK severity).")
                    _release_idempotency_reservation()
                    raise ComplianceViolationError(
                        "Live basket blocked by compliance rules (BLOCK severity)."
                    )
                if _has_breach and not _compliance_override:
                    _emit("⚠️ [Compliance BREACH] Live basket halted — PM override required.")
                    _release_idempotency_reservation()
                    raise ComplianceViolationError(
                        "Live basket halted by compliance rules (BREACH severity); "
                        "PM override not enabled."
                    )
        except ComplianceViolationError:
            raise
        except Exception as _ce_err:
            # Compliance engine itself unavailable: fail CLOSED for live money.
            _emit(f"⛔ [ReconcileBasket] Compliance engine unavailable ({_ce_err}) "
                  "— live execution blocked (fail-closed).")
            _release_idempotency_reservation()
            return {
                "success": False,
                "idempotency_key": token,
                "duplicate": False,
                "error": f"COMPLIANCE_UNAVAILABLE: {_ce_err}",
                "orders": orders,
                "vpin_check": vpin_result,
                "turnover_pct": reconcile_result.get("turnover_pct", 0.0),
                "mode": "live",
            }

    router = None
    if not paper:
        broker_configured = False
        try:
            from math_engine.broker_router import BrokerRouter
            router = BrokerRouter(cfg=active_cfg)
            broker_configured = bool(getattr(router, "is_configured", lambda: False)())
        except Exception as _b_err:
            _emit(f"[ReconcileBasket] Broker initialization error: {_b_err}")
            broker_configured = False

        if not broker_configured:
            _release_idempotency_reservation()  # AUDIT-FIX (Round 6, B-P2-9)
            return {
                "success": False,
                "error": "Live broker trading requires authenticated broker API credentials. Please configure Kite / Angel One in settings or use paper=True.",
                "mode": "live",
                "orders": []
            }

    placed_orders = []
    mode = "paper" if paper else "live"
    if not paper and router is not None:
        try:
            # BUGFIX (Round 41 / Claude Audit §5q): Previously called
            # router.place_basket_orders(weights=target_weights, ...), which
            # only ever bought target weights and never sold dropped holdings.
            # Calling router.execute_differential_orders(orders=orders) executes
            # the real BUY/SELL deltas computed by reconcile_portfolio_holdings.
            if hasattr(router, "execute_differential_orders"):
                live_df = router.execute_differential_orders(
                    orders=orders,
                    dry_run=False,
                    log_cb=_emit
                )
            else:
                live_df = router.place_basket_orders(
                    weights=target_weights,
                    portfolio_value=total_value,
                    dry_run=False,
                    log_cb=_emit
                )
            for _, row in live_df.iterrows():
                placed_orders.append({
                    "ticker": row.get("Ticker", ""),
                    "side": str(row.get("Side", row.get("Action", "BUY"))).upper(),
                    "qty": int(row.get("Qty", 0)),
                    "price": float(str(row.get("LTP", "0")).replace("₹", "").replace(",", "") or 0.0),
                    "value_inr": float(str(row.get("Est. Value", "0")).replace("₹", "").replace(",", "") or 0.0),
                    "status": str(row.get("Status", "PLACED")),
                    "order_id": str(row.get("OrderID", "") or uuid.uuid4().hex[:8]),
                    "mode": "live"
                })
        except Exception as live_err:
            _emit(f"[ReconcileBasket] Live order execution failed: {live_err}")
            _release_idempotency_reservation()  # AUDIT-FIX (Round 6, B-P2-9)
            return {
                "success": False,
                "error": f"Live broker order execution failed: {live_err}",
                "mode": "live",
                "orders": []
            }
    else:
        for o in orders:
            order_out = dict(o)
            order_out["status"] = "SIMULATED"
            order_out["order_id"] = str(uuid.uuid4())[:8]
            order_out["mode"] = "paper"
            placed_orders.append(order_out)
            _emit(
                f"[ReconcileBasket] [PAPER] {o['side']} {o['qty']} × {o['ticker']} "
                f"@ ₹{o['price']:.2f} = ₹{o['value_inr']:,.0f}"
            )

    # ── Register idempotency token ──────────────────────────────────────────
    with _IDEMPOTENCY_LOCK:
        # AUDIT-FIX (Round 5): record BOTH the current- and previous-bucket
        # tokens so a retry straddling a bucket boundary matches either one.
        _now_ts = time.time()
        _IDEMPOTENCY_CACHE[token] = _now_ts
        _IDEMPOTENCY_CACHE[prev_token] = _now_ts
        # Purge stale tokens older than 2× window
        cutoff = _now_ts - 2 * _IDEMPOTENCY_WINDOW_SEC
        stale = [k for k, v in _IDEMPOTENCY_CACHE.items() if v < cutoff]
        for k in stale:
            del _IDEMPOTENCY_CACHE[k]

    _emit(
        f"[ReconcileBasket] ✅  {len(placed_orders)} orders {mode} | "
        f"token={token[:12]}… | turnover={reconcile_result.get('turnover_pct', 0):.1f}%"
    )
    return {
        "success": True,
        "idempotency_key": token,
        "duplicate": False,
        "orders": placed_orders,
        "vpin_check": vpin_result,
        "turnover_pct": reconcile_result.get("turnover_pct", 0.0),
        "total_buy_inr": reconcile_result.get("total_buy_inr", 0.0),
        "total_sell_inr": reconcile_result.get("total_sell_inr", 0.0),
        "mode": mode,
    }


try:
    __all__.extend([
        "reconcile_portfolio_holdings",
        "generate_idempotency_key",
        "execute_reconciled_basket",
    ])
except Exception:
    pass

