"""
optimizer_compliance.py — Regulatory Compliance, Bounds & Circuit Enforcement Suite
===================================================================================

AUDIT-FIX (Phase B God-File Decomposition):
Extracted 8 regulatory compliance and weight-mutation functions from optimizer.py,
and added the mandatory apply_all_compliance() orchestrator to preserve ordered execution:
  - apply_sebi_constraints
  - _project_weights_to_bounds
  - apply_weight_constraints
  - apply_two_pass_clipping
  - check_earnings_blackout
  - evaluate_options_skew_warning
  - apply_turnover_qubo_constraint
  - get_tax_aware_turnover_cost
  - apply_all_compliance (ORCHESTRATOR)

Re-exported by optimizer.py for 100% backward compatibility.
"""
from __future__ import annotations

import logging as _logging
import numpy as np
import pandas as pd
from typing import Any, Dict, List, Optional, Tuple, Union

logger = _logging.getLogger("quantum_annealer.compliance")


__all__ = [
    "apply_sebi_constraints",
    "_project_weights_to_bounds",
    "apply_weight_constraints",
    "apply_two_pass_clipping",
    "check_earnings_blackout",
    "evaluate_options_skew_warning",
    "apply_turnover_qubo_constraint",
    "get_tax_aware_turnover_cost",
    "apply_all_compliance",
    "run_pretrade_gate",
]


def apply_sebi_constraints(weights: dict, prescreen_df: pd.DataFrame = None, cfg: dict = None, log_cb=None) -> dict:
    """Enforce SEBI category exposure limits (Large, Mid, Small caps) with iterative redistribution."""
    if not weights:
        return weights
    try:
        # AUDIT-FIX (Round 5 P1-A): the SEBI category map helper lives in
        # data_layer (not utils, as the previous version mistakenly assumed).
        # The earlier wrong-module import raised ImportError, was silently
        # caught, and returned weights UNCHANGED — disabling SEBI compliance.
        from data_layer import fetch_sebi_cap_categories
        category_map = fetch_sebi_cap_categories(log_cb) if callable(fetch_sebi_cap_categories) else {}
        if not category_map:
            import logging as _b7_log
            _b7_log.getLogger("quantum_annealer").error(
                "[AUDIT-FIX B7] SEBI category-cap map unavailable — gate FAILED "
                "CLOSED: returning all-CASH weights (caps cannot be verified).")
            if log_cb:
                log_cb("[SEBI-Caps] Category map unavailable — fail-closed to CASH.")
            return {"CASH": 1.0}

        w_series = pd.Series(weights)
        _LIQUID_CASH_TICKERS = {
            "CASH", "LIQUIDBEES.NS", "LIQUIDETF.NS", "GOLDBEES.NS",
            "LIQUIDCASE.NS", "NIFTYBEES.NS", "BANKBEES.NS",
            "LIQUIDBEES", "LIQUIDETF", "GOLDBEES", "LIQUIDCASE"
        }
        cats = pd.Series({
            t: ("cash" if t.upper() in _LIQUID_CASH_TICKERS or "LIQUID" in t.upper() or t == "CASH"
                else category_map.get(t, "small"))
            for t in w_series.index
        })

        max_small = float((cfg or {}).get("MAX_SMALL_CAP_PCT", 0.30))
        max_mid = float((cfg or {}).get("MAX_MID_CAP_PCT", 0.50))
        max_w = float((cfg or {}).get("MAX_WEIGHT", 0.50))

        excess = 0.0
        small_exp = w_series[cats == "small"].sum() if sum(cats == "small") > 0 else 0
        mid_exp = w_series[cats == "mid"].sum() if sum(cats == "mid") > 0 else 0

        if small_exp > max_small and small_exp > 0:
            trim_factor = max_small / small_exp
            excess += float(w_series[cats == "small"].sum() * (1 - trim_factor))
            w_series[cats == "small"] *= trim_factor
        if mid_exp > max_mid and mid_exp > 0:
            trim_factor = max_mid / mid_exp
            excess += float(w_series[cats == "mid"].sum() * (1 - trim_factor))
            w_series[cats == "mid"] *= trim_factor

        if excess > 1e-6:
            large_mask = cats == "large"
            if large_mask.any():
                large_total = float(w_series[large_mask].sum())
                if large_total > 1e-9:
                    w_series[large_mask] += excess * (w_series[large_mask] / large_total)
                else:
                    w_series[large_mask] = excess / large_mask.sum()
            elif (cats == "cash").any():
                cash_mask = cats == "cash"
                w_series[cash_mask] += excess / cash_mask.sum()
            else:
                # AUDIT-FIX (Round 6, B-P1-1): when the portfolio has NEITHER a
                # large-cap NOR a cash sleeve (all small/mid names), the trimmed
                # excess used to silently VANISH — the final renormalization then
                # re-inflated the trimmed sleeves right back above the SEBI caps
                # (verified: 4×0.25 all-small with 0.30 cap → output unchanged,
                # small exposure 100%). Park the excess in a CASH sleeve exactly
                # like the clip loop below, so the renormalization is a no-op
                # and the category caps hold.
                w_series["CASH"] = float(w_series.get("CASH", 0.0)) + excess
                cats["CASH"] = "cash"
                if log_cb:
                    log_cb(f"[SEBI] Category-cap trim routed {excess:.4f} to CASH sleeve (no large-cap/cash available).")

        for _ in range(10):
            # Clip only equity sleeves to max_w; do NOT clip CASH / cash equivalents
            non_cash_mask = cats != "cash"
            clipped = w_series[non_cash_mask].clip(upper=max_w)
            # AUDIT-FIX (Round 5, 2-f-1): the clipped-off mass used to be
            # silently DELETED here; the unconditional renormalization at the
            # end then re-inflated every remaining weight by 1/w_sum — pushing
            # small-cap exposure and single-name weights BACK ABOVE both the
            # SEBI category caps and MAX_WEIGHT (verified: {S1:.5,S2:.2,L1:.2,
            # L2:.1} with cap 0.20 → output max weight 0.2917, small-cap 0.417
            # vs 0.30 cap). Conserve the mass in the CASH sleeve instead so
            # the final renormalization is a no-op and every cap holds.
            _lost = float((w_series[non_cash_mask] - clipped).sum())
            w_series[non_cash_mask] = clipped
            if _lost > 1e-12:
                if "CASH" in w_series.index:
                    w_series["CASH"] = float(w_series["CASH"]) + _lost
                else:
                    w_series["CASH"] = _lost
                    cats["CASH"] = "cash"
            small_exp_new = float(w_series[cats == "small"].sum())
            mid_exp_new = float(w_series[cats == "mid"].sum())
            _re_excess = 0.0
            if small_exp_new > max_small + 1e-6:
                _tf = max_small / small_exp_new
                _re_excess += float(w_series[cats == "small"].sum() * (1 - _tf))
                w_series[cats == "small"] *= _tf
            if mid_exp_new > max_mid + 1e-6:
                _tf = max_mid / mid_exp_new
                _re_excess += float(w_series[cats == "mid"].sum() * (1 - _tf))
                w_series[cats == "mid"] *= _tf
            if _re_excess > 1e-6:
                large_mask = cats == "large"
                if large_mask.any():
                    large_total = float(w_series[large_mask].sum())
                    if large_total > 1e-9:
                        w_series[large_mask] += _re_excess * (w_series[large_mask] / large_total)
                    else:
                        w_series[large_mask] = _re_excess / large_mask.sum()
                elif (cats == "cash").any():
                    cash_mask = cats == "cash"
                    w_series[cash_mask] += _re_excess / cash_mask.sum()
                else:
                    # AUDIT-FIX (Round 6, B-P1-1): same mass-conservation fix as
                    # the first trim — never let trimmed category mass vanish.
                    w_series["CASH"] = float(w_series.get("CASH", 0.0)) + _re_excess
                    cats["CASH"] = "cash"
            else:
                break

        w_sum = w_series.sum()
        if w_sum > 1e-9:
            w_series = w_series / w_sum
        return w_series.to_dict()
    except Exception as e:
        # AUDIT-FIX (Round 13, SEC-1): the outer exception handler previously
        # returned the ORIGINAL, UNCONSTRAINED weights with only a "Notice"
        # log — a fail-OPEN compliance gate. Any failure in the import, the
        # cap-category feed, or the redistribution math silently disabled
        # SEBI large/mid/small-cap exposure limits for the entire downstream
        # pipeline (per-stock/sector caps in apply_weight_constraints do NOT
        # enforce category limits). The B7 path above already fails closed
        # (empty category map → all-CASH); the outer path must fail the SAME
        # way. Caps cannot be verified ⇒ capital cannot be deployed.
        import logging as _sec1_log
        _sec1_log.getLogger("quantum_annealer").error(
            "[AUDIT-FIX SEC-1] SEBI constraint enforcement FAILED (%s) — "
            "gate FAILED CLOSED: returning all-CASH weights.", e)
        if log_cb:
            log_cb(f"[SEBI-Caps] Constraint enforcement error ({e}) — fail-closed to CASH.")
        return {"CASH": 1.0}


def _project_weights_to_bounds(values, lower: float = 0.0, upper: float = 1.0) -> np.ndarray:
    """Project weight vector onto the capped simplex: sum(v) == 1 with
    lower <= v_i <= upper for every entry.

    AUDIT-FIX (Round 6, B-P2-6): the previous clip-then-renormalize pushed
    clipped weights right back ABOVE `upper` (verified: [0.5,0.3,0.2] with
    upper=0.2 → [1/3,1/3,1/3]). Replaced with the standard bisection on the
    shift λ: sum(clip(v_i + λ, lower, upper)) == 1, which is monotone in λ and
    provably respects the box; infeasible caps (n·upper < 1) fall back to
    all-upper. Consumed by compute_alpha_proportional_weights and the
    QUBO-aware post-normalization re-projection."""
    v = np.asarray(values, dtype=float)
    n = len(v)
    if n == 0:
        return v
    if np.all(v <= 0):
        return np.ones(n) / n
    target = 1.0
    upper = min(upper, 1.0)
    if n * upper < target - 1e-12:
        # Infeasible: even all-capped cannot reach the target.
        return np.full(n, upper)
    if n * lower > target + 1e-12:
        return np.full(n, target / n)

    def total(shift: float) -> float:
        return float(np.clip(v + shift, lower, upper).sum())

    lo, hi = lower - float(v.max()) - 1.0, upper - float(v.min()) + 1.0
    # total(lo) <= n*lower < target and total(hi) >= n*upper > target
    for _ in range(100):
        mid = 0.5 * (lo + hi)
        if total(mid) < target:
            lo = mid
        else:
            hi = mid
        if hi - lo < 1e-12:
            break
    shift = 0.5 * (lo + hi)
    out = np.clip(v + shift, lower, upper)
    # Tiny residual dust spread over un-capped entries (keeps sum == 1).
    resid = target - float(out.sum())
    if abs(resid) > 1e-12:
        free = out < upper - 1e-12
        if free.any():
            out[free] = np.clip(out[free] + resid * (out[free] / out[free].sum()), lower, upper)
    return out


def apply_weight_constraints(weights: dict, cfg: dict = None) -> dict:
    """Applies single-stock minimum and maximum position allocation constraints.
    Ensures active equity positions satisfy lower and upper bounds without
    leaving phantom 0.00% positions in the portfolio. Diverts clipped excess to CASH."""
    if not weights:
        return weights
    min_w = float((cfg or {}).get("MIN_WEIGHT", 0.01))
    max_w = float((cfg or {}).get("MAX_WEIGHT", 0.20))
    cash_w = float(weights.get("CASH", 0.0))

    eq_weights = {k: float(v) for k, v in weights.items() if k != "CASH" and float(v) > 0.0}
    if not eq_weights:
        return {"CASH": 1.0}

    available_equity = max(0.0, 1.0 - cash_w)
    if available_equity <= 1e-6:
        return {"CASH": 1.0}

    n_stocks = len(eq_weights)
    if n_stocks * min_w <= available_equity + 1e-9:
        stock_tickers = list(eq_weights.keys())
        raw_vals = np.array([eq_weights[t] for t in stock_tickers], dtype=float)

        eff_lower = min(min_w / available_equity, 1.0 / n_stocks)
        eff_upper = min(max_w / available_equity, 1.0)
        proj_vals = _project_weights_to_bounds(raw_vals, lower=eff_lower, upper=eff_upper)

        res = {stock_tickers[i]: float(proj_vals[i] * available_equity) for i in range(n_stocks)}
        actual_eq_sum = sum(res.values())
        rem_cash = max(cash_w, 1.0 - actual_eq_sum)
        if rem_cash > 1e-12:
            res["CASH"] = rem_cash
        return res
    else:
        max_feasible = max(1, int(available_equity / min_w))
        sorted_stocks = sorted(eq_weights.items(), key=lambda x: x[1], reverse=True)[:max_feasible]
        stock_tickers = [x[0] for x in sorted_stocks]
        raw_vals = np.array([x[1] for x in sorted_stocks], dtype=float)

        n_kept = len(stock_tickers)
        eff_lower = min(min_w / available_equity, 1.0 / n_kept)
        eff_upper = min(max_w / available_equity, 1.0)
        proj_vals = _project_weights_to_bounds(raw_vals, lower=eff_lower, upper=eff_upper)

        res = {stock_tickers[i]: float(proj_vals[i] * available_equity) for i in range(n_kept)}
        actual_eq_sum = sum(res.values())
        rem_cash = max(cash_w, 1.0 - actual_eq_sum)
        if rem_cash > 1e-12:
            res["CASH"] = rem_cash
        return res


def apply_two_pass_clipping(weights: dict, sector_map: dict, max_stock: float = 0.15, max_sector: float = 0.35) -> dict:
    """Two-pass regularizer: clips stock weights first, then sector weights, diverting excess to CASH."""
    if not weights:
        return weights
    w_out = dict(weights)

    # Pass 1: stock clipping
    for s in list(w_out.keys()):
        if s != "CASH" and w_out[s] > max_stock:
            excess = w_out[s] - max_stock
            w_out[s] = max_stock
            w_out["CASH"] = w_out.get("CASH", 0.0) + excess

    # Pass 2: sector clipping
    try:
        from utils import normalize_sector
    except ImportError:
        def normalize_sector(x):
            return "UNKNOWN" if not x or str(x).strip().upper() in ("", "NONE", "UNKNOWN", "N/A", "NAN", "NULL") else str(x)

    sectors = sector_map or {}
    sec_totals: dict[str, float] = {}
    for s, w in w_out.items():
        if s != "CASH":
            sec = normalize_sector(sectors.get(s, "UNKNOWN"))
            sec_totals[sec] = sec_totals.get(sec, 0.0) + w

    for sec, tot in sec_totals.items():
        if tot > max_sector and tot > 1e-9:
            ratio = max_sector / tot
            for s in list(w_out.keys()):
                if s != "CASH" and normalize_sector(sectors.get(s, "UNKNOWN")) == sec:
                    freed = w_out[s] * (1.0 - ratio)
                    w_out[s] *= ratio
                    w_out["CASH"] = w_out.get("CASH", 0.0) + freed

    return w_out


def check_earnings_blackout(ticker: str, blackout_days: int = 2) -> bool:
    """Returns True if the ticker has earnings/results within blackout_days.

    AUDIT-FIX (Round 8, B7 — Part 2B): two defects fixed.
    (1) The caller previously passed `[]` for tickers to
        fetch_corp_actions_blackout([], blackout_days=blackout_days) —
        so the feed was never queried for the ticker at all.
    (2) On ANY exception this gate returned False (FAIL-OPEN), allowing
        trading during an unverified blackout window. Worse, on network
        failure data_layer returns an EMPTY set, which previously fell
        through to `ticker in set()` == False (also fail-open).
        When the corporate-actions feed fails or returns empty (which is
        unrealistic for market-wide NSE disclosures), we FAIL CLOSED
        (return True = treat as blacked-out / block trading) and log at
        ERROR level.
    """
    try:
        from data_layer import fetch_corp_actions_blackout
        # Pass the single ticker in a list so the provider can optimize.
        blackout_set = fetch_corp_actions_blackout([ticker], blackout_days=blackout_days)
        if not blackout_set:
            # If the market-wide fetcher returned nothing at all, treat as
            # feed failure (fail closed).
            import logging as _b7_log
            _b7_log.getLogger("quantum_annealer").error(
                "[AUDIT-FIX B7] corporate-actions feed returned an empty window set "
                "for %s — failing CLOSED (treated as blacked out).", ticker)
            return True
        return ticker in blackout_set
    except Exception as e:
        import logging as _b7_log
        _b7_log.getLogger("quantum_annealer").error(
            "[AUDIT-FIX B7] earnings-blackout gate FAILED CLOSED for %s: %s — "
            "blocking position as unverified.", ticker, e)
        return True


def evaluate_options_skew_warning(ticker: str, threshold: float = 1.25,
                                  option_chain: dict = None,
                                  cfg: dict = None, log_cb=None) -> bool:
    """Check if OTM-put skew signals imminent downside tail risk.

    AUDIT-FIX (Round 5 P2-1 & Round 7 P2-3):
    1. If option_chain dict is supplied, fits an SVI surface (Gatheral & Jacquier 2012)
       and detects skew anomalies.
    2. If options chain is fetched via data_layer, builds vol surface via
       math_engine.derivatives and computes 25-delta put-call IV skew.

    Returns True when the skew slope / IV skew exceeds threshold.
    Fail-open: returns False on any missing data / import failure.
    """
    # 1. Try derivatives module with cfg/data_layer
    active_cfg = cfg or {}
    try:
        from math_engine import derivatives as deriv_mod
        # AUDIT-FIX (Round 5, 2-f-5): fetch the chain only when the caller did
        # NOT supply one — the old unconditional `from data_layer import
        # fetch_options_chain` made path 1 raise ImportError even for supplied
        # chains, so a provided chain could never be processed by this path.
        chain = option_chain
        if chain is None:
            from data_layer import fetch_options_chain
            chain = fetch_options_chain(ticker, **active_cfg.get("OPTIONS_CHAIN_PARAMS", {}))
        if chain is not None:
            if isinstance(chain, dict) and "chain_rows" in chain:
                import pandas as _pd
                chain_df = _pd.DataFrame(chain["chain_rows"])
            elif hasattr(chain, "iterrows"):
                chain_df = chain
            else:
                chain_df = None

            if chain_df is not None and not chain_df.empty:
                spot = float(active_cfg.get("SPOT_PRICE", 0.0)) or None
                rf = float(active_cfg.get("RISK_FREE_RATE", 0.07))
                vol_surface = deriv_mod.build_vol_surface(chain_df, spot_price=spot, risk_free_rate=rf)
                skew_data = deriv_mod.compute_vol_skew(vol_surface)
                skew_val = float(skew_data.get("skew", 0.0))
            if skew_val >= threshold:
                if log_cb is not None:
                    log_cb(
                        f"⚠️ [SkewWarning] {ticker} 25Δ put skew = {skew_val*100:.1f}bps "
                        f"(>= threshold {threshold*100:.0f}bps) — downside tail risk elevated"
                    )
                return True
            return False
    except Exception as _d_err:
        # AUDIT-FIX (Round 5, 2-g-26): a dead compliance gate must be visible
        # above DEBUG — this function fail-opens to False, so a silent debug
        # log left the options-skew tail-risk warning permanently disabled with
        # no operator-visible trace (violating the suite's own P2-5 spec).
        logger.warning(f"[SkewWarn-DEGRADED] {ticker} derivatives path unavailable: {_d_err}")

    # 2. Fall back to institutional SVI surface
    try:
        from math_engine.institutional.svi_surface import (
            build_surface_from_chain, detect_skew_anomaly,
        )
        chain = option_chain
        if chain is None:
            from data_layer import fetch_nse_option_chain
            chain = fetch_nse_option_chain(ticker)
        if not chain:
            return False
        surface = build_surface_from_chain(chain)
        # AUDIT-FIX (Round 5, 2-f-2): `detect_skew_anomaly(surface, threshold=…)`
        # raised TypeError when the callee's real parameter is `slope_threshold`
        # — swallowed by the fail-open except, so the OTM-put tail-risk warning
        # could NEVER fire. Inspect the signature and pass whichever parameter
        # name the installed math_engine actually accepts.
        import inspect as _inspect
        try:
            _params = _inspect.signature(detect_skew_anomaly).parameters
        except (TypeError, ValueError):
            _params = {}
        if "threshold" in _params or not _params:
            is_warning, slope = detect_skew_anomaly(surface, threshold=threshold)
        elif "slope_threshold" in _params:
            is_warning, slope = detect_skew_anomaly(surface, slope_threshold=threshold)
        else:
            is_warning, slope = detect_skew_anomaly(surface, threshold=threshold)
        if not is_warning and chain and isinstance(chain, dict):
            try:
                for exp, quotes in chain.items():
                    if quotes:
                        spot_val = float(quotes[0].get("spot", 100.0))
                        atm_ivs = [float(q.get("imp_vol", 0)) for q in quotes if abs(float(q.get("strike", 0)) - spot_val) < 1.0]
                        atm_iv = float(np.mean(atm_ivs)) if atm_ivs else 0.15
                        otm_put_ivs = [float(q.get("imp_vol", 0)) for q in quotes if float(q.get("strike", 0)) < spot_val and q.get("type", "") in ("put", "PE")]
                        if otm_put_ivs and atm_iv > 0:
                            max_put_iv = max(otm_put_ivs)
                            if (max_put_iv / atm_iv) >= threshold:
                                is_warning = True
                                slope = max_put_iv / atm_iv
                                break
            except Exception:
                pass

        if is_warning:
            if log_cb is not None:
                log_cb(f"⚠️ [SkewWarning] {ticker} OTM-put skew slope={slope:.3f} >= threshold={threshold:.3f}")
            logger.warning(
                f"[SkewWarn] {ticker} OTM-put skew slope={slope:.3f} "
                f"> threshold={threshold:.3f} — tail-risk signal fired"
            )
        return bool(is_warning)
    except Exception as _e:
        # AUDIT-FIX (Round 5, 2-g-26): see note above — degraded gate must be
        # visible, not buried at DEBUG level.
        logger.warning(f"[SkewWarn-DEGRADED] {ticker} SVI path unavailable: {_e}")
        return False


def apply_turnover_qubo_constraint(q: dict, prev_holdings: list,
                                    all_stocks: list, cfg: dict) -> dict:
    """
    Penalise selection of stocks NOT in previous holdings when turnover
    would exceed TURNOVER_HARD_CAP * K. Encourages reuse of existing positions.

    AUDIT-FIX (Round 5 P1-B): Replaced the previous `return qubo_matrix` no-op stub
    with the real body previously defined inline in optimizer.py:1331. The signature
    is preserved (q, prev_holdings, all_stocks, cfg) for 100% backward compatibility.
    The local def in optimizer.py has been removed; this is now the single source of truth.
    """
    if not prev_holdings:
        return q
    hard_cap         = float(cfg.get("TURNOVER_HARD_CAP", 0.60))
    k_stocks         = int(cfg.get("K_STOCKS", 8))
    max_new          = max(1, int(hard_cap * k_stocks))
    prev_set         = set(p.replace(".NS","").upper() for p in prev_holdings)
    all_clean        = [s.replace(".NS","").upper() for s in all_stocks]
    new_stocks       = [s for s in all_stocks if s.replace(".NS","").upper() not in prev_set]
    # penalty scales with how many new stocks are beyond the cap
    gamma            = float(cfg.get("GAMMA", 22.0))
    _N_universe      = max(float(len(all_stocks)), 1.0)
    # Bug 12 fix: /N so turnover_pen matches scale of all other QUBO diagonals.
    turnover_pen     = (gamma * 0.12 / max(max_new, 1)) / _N_universe  # DIV001: guard divisor before use
    q_new = dict(q)
    for si in new_stocks:
        # Diagonal penalty (cost of selecting each new stock)
        diag_key = (si, si)
        q_new[diag_key] = q_new.get(diag_key, 0.0) + turnover_pen
        # Off-diagonal pair penalty between new stocks (discourages selecting many new)
        for sj in new_stocks:
            if sj <= si:
                continue
            key = (si, sj)
            q_new[key] = q_new.get(key, 0.0) + turnover_pen * 0.15
    return q_new


def get_tax_aware_turnover_cost(ticker: str, prev_holdings_dates: dict,
                                 base_turnover_penalty: float,
                                 stcg_factor: float = 2.0) -> float:
    """
    Amplify the QUBO turnover penalty for positions held < 365 days (STCG territory).

    Indian tax regime:
      - STCG tax = 15% (equity held < 1 year)
      - LTCG tax = 10% over ₹1L threshold (equity held ≥ 1 year)
    Selling a short-term holding costs ~5% more in tax, so we apply a 2× penalty
    on the QUBO diagonal to deter premature churn.

    AUDIT-FIX (Round 5 P1-B): Replaced the previous STT-tax stub (which had a
    different signature: old_weights/new_weights/portfolio_val/stt_bps and a
    different formula) with the real STCG-aware body previously defined inline
    in optimizer.py:1368. The local def in optimizer.py has been removed;
    this is now the single source of truth.

    Args:
        ticker: NSE ticker symbol
        prev_holdings_dates: {ticker: purchase_date_str (YYYY-MM-DD)}
        base_turnover_penalty: standard penalty from cfg["TURNOVER_PENALTY"]
        stcg_factor: multiplier for short-term positions (default 2.0)

    Returns:
        float: effective turnover penalty (amplified for STCG positions)
    """
    if not prev_holdings_dates or ticker not in prev_holdings_dates:
        return base_turnover_penalty
    try:
        purchase_date = pd.Timestamp(prev_holdings_dates[ticker])
        days_held = (pd.Timestamp.now() - purchase_date).days
        if days_held < 365:
            return base_turnover_penalty * stcg_factor  # STCG: amplify penalty
        return base_turnover_penalty                    # LTCG: normal penalty
    except Exception:
        return base_turnover_penalty


def apply_all_compliance(weights: dict, prescreen_df: pd.DataFrame = None, cfg: dict = None, sector_map: dict = None, log_cb=None) -> dict:
    """
    Mandatory Orchestrator: Applies all regulatory, exposure, and clipping constraints
    in the strict invariant execution sequence:
        1. SEBI Category Exposure (Large/Mid/Small)
        2. Single-Stock Bounds (Min/Max Weight)
        3. Two-Pass Stock & Sector Regularization (Diverting excess to CASH)
        4. (Optional) Wasserstein DRO-CVaR re-scaling (Round 6 institutional upgrade)

    AUDIT-FIX (Round 6): When cfg["DRO_CVAR_ENABLED"] is True and
    cfg["DRO_CVAR_RETURNS"] is supplied (an (N, M) returns DataFrame),
    we rescale the weights via the Wasserstein DRO-CVaR optimizer
    (Mohajerin Esfahani & Kuhn 2018) as a post-step. This is a soft
    correction — the constraint sequence above is still applied first.
    The DRO-CVaR rescaling is bounded to ±10% of each weight to avoid
    wild swings vs the SEBI-compliant baseline.

    Args:
        weights:      dict of {ticker: weight}
        prescreen_df: optional pre-screening DataFrame
        cfg:          optional config dict (DRO_CVAR_* keys recognized)
        sector_map:   optional {ticker: sector} mapping
        log_cb:       optional log callback

    Returns:
        dict of {ticker: weight} post-compliance.
    """
    if not weights:
        return weights

    w = dict(weights)
    w = apply_sebi_constraints(w, prescreen_df=prescreen_df, cfg=cfg, log_cb=log_cb)
    w = apply_weight_constraints(w, cfg=cfg)
    max_stock = float((cfg or {}).get("MAX_STOCK_PCT", (cfg or {}).get("MAX_WEIGHT", 0.15)))
    _sector_cap_enabled = (cfg or {}).get("ENABLE_SECTOR_CAP", True)
    max_sector = float((cfg or {}).get("SECTOR_LIMIT", (cfg or {}).get("MAX_SECTOR_PCT", 0.35))) if _sector_cap_enabled else 1.0
    w = apply_two_pass_clipping(w, sector_map or {}, max_stock=max_stock, max_sector=max_sector)

    # Round 6 institutional upgrade: optional DRO-CVaR re-scaling
    try:
        if (cfg or {}).get("DRO_CVAR_ENABLED", False):
            from math_engine.institutional.wasserstein_dro_cvar import (
                dr_cvar_optimal_w, calibrate_epsilon,
            )
            returns_df = cfg.get("DRO_CVAR_RETURNS")
            if returns_df is not None and len(returns_df) >= 50:
                tickers = [t for t in w if t != "CASH" and t in returns_df.columns]
                if len(tickers) >= 3:
                    R = returns_df[tickers].dropna().values
                    if len(R) >= 50:
                        alpha = float(cfg.get("DRO_CVAR_ALPHA", 0.95))
                        eps = cfg.get("DRO_CVAR_EPSILON")
                        w_long_only = np.array([w.get(t, 0.0) for t in tickers])
                        original_non_cash_total = float(w_long_only.sum())
                        if original_non_cash_total > 1e-6:
                            # Solve DRO-CVaR on the normalized weights
                            w_dro = dr_cvar_optimal_w(
                                R, alpha=alpha,
                                epsilon=eps,
                                long_only=True,
                                max_weight=max_stock,
                            )
                            # Normalize both to sum to 1, blend, then rescale to
                            # original non-CASH total (so CASH is preserved)
                            blend_factor = float(cfg.get("DRO_CVAR_BLEND", 0.30))
                            w_baseline_norm = w_long_only / original_non_cash_total
                            w_blended = (1 - blend_factor) * w_baseline_norm + \
                                        blend_factor * w_dro
                            # AUDIT-FIX (Round 5, 2-f-8): the docstring promises
                            # "bounded to ±10% of each weight to avoid wild
                            # swings vs the SEBI-compliant baseline" — the code
                            # had no bound at all, so DRO_CVAR_BLEND=1.0 fully
                            # replaced the compliant weights. Enforce the
                            # documented per-weight movement limit.
                            _lo_bound = 0.90 * w_baseline_norm
                            _hi_bound = 1.10 * w_baseline_norm
                            w_blended = np.clip(w_blended, _lo_bound, _hi_bound)
                            w_blended = w_blended / max(w_blended.sum(), 1e-6)
                            # Scale back to original non-CASH budget
                            w_final = w_blended * original_non_cash_total
                            for i, t in enumerate(tickers):
                                w[t] = float(w_final[i])
                            # AUDIT-FIX (Round 8, B19 — Part 2B): the blend's
                            # renormalization could push weights back OVER the
                            # caps — the ±10% movement clip sits ABOVE the cap
                            # when the cap binds, and the sum-to-1 renormalization
                            # rescales every weight upward when mass was clipped
                            # away. The FULL SEBI constraint sequence is
                            # re-applied after the DRO blend so the returned
                            # portfolio is compliant by construction.
                            w = apply_sebi_constraints(w, prescreen_df=prescreen_df, cfg=cfg, log_cb=log_cb)
                            w = apply_weight_constraints(w, cfg=cfg)
                            w = apply_two_pass_clipping(w, sector_map or {}, max_stock=max_stock, max_sector=max_sector)
                            if log_cb:
                                log_cb(f"[DRO-CVaR] Re-scaled {len(tickers)} weights "
                                       f"with α={alpha:.2f}, ε={eps}, blend={blend_factor:.2f}, "
                                       f"non_cash_total={original_non_cash_total:.3f} "
                                       f"(+ full SEBI re-clip post-blend per B19)")
    except Exception as e:
        if log_cb:
            log_cb(f"[DRO-CVaR] Skipped (non-fatal): {e}")

    return w


def run_pretrade_gate(weights: dict, cfg: dict = None,
                      signal_df: pd.DataFrame = None,
                      sector_map: dict = None,
                      log_cb=None,
                      compliance_override: bool = False) -> dict:
    """Canonical pre-trade compliance and risk gate.

    Consolidates all execution safeguards into one reusable checkpoint:
      0. Portfolio-level circuit breaker (CircuitBreaker.check_history)
      1. VPIN preflight toxicity screen (Easley-López de Prado-O'Hara 2012)
      2. ComplianceEngine checks (banned securities, position limit, sector limit, liquidity ADV20, beta)
      3. Earnings blackout screen (check_earnings_blackout)
      4. Options skew tail risk warning (evaluate_options_skew_warning)

    Returns:
      {
        "status": "PASSED" | "BLOCKED" | "BREACH" | "OVERRIDDEN",
        "violations": list of violation dicts,
        "warnings": list of warning dicts,
        "vpin_results": dict,
      }

    "OVERRIDDEN" (Round 41) means a BREACH-severity violation occurred but
    compliance_override=True bypassed it — distinct from "PASSED" (zero
    violations) so callers cannot mistake an explicitly-overridden breach
    for a genuinely clean check. Callers MUST handle this status explicitly
    (log it, surface the violations) rather than letting it fall through to
    whatever code path handles "PASSED".
    """
    active_cfg = cfg or {}
    violations = []
    warnings = []

    # 0a. Global Master Kill Switch Check
    try:
        from core.kill_switch import MasterKillSwitch
        if MasterKillSwitch.is_active():
            violations.append({
                "severity": "BLOCK",
                "rule": "GLOBAL_KILL_SWITCH",
                "ticker": "ALL",
                "message": "Global emergency kill switch is ACTIVE — all execution blocked"
            })
            return {
                "status": "BLOCKED",
                "violations": violations,
                "warnings": warnings,
                "vpin_results": {},
            }
    except Exception:
        pass

    # 0b. Portfolio-level circuit breaker (Round 41)
    # BUGFIX: CircuitBreaker (utils.py) is documented as "Auto-halt
    # automation when any of three trip conditions are met" (single-day
    # loss, peak-to-trough drawdown, N consecutive losing runs), but before
    # this fix its check_history() result was consulted in exactly one
    # place in the entire codebase: a UI status label
    # (ui/main_window.py, "self.circuit_status_lbl.setText(...)") that
    # displays "TRIPPED" in red text and writes an audit log entry — it was
    # never actually checked by run_pretrade_gate, angelone_place_basket,
    # reconcile_holdings, or any other order-placement code path. An
    # operator could see "Status: TRIPPED" in the UI while every other tab/
    # button continued placing live orders completely unaffected, because
    # nothing in the execution path ever consulted it. This is the same
    # "documented as an auto-halt, implemented as decorative" gap already
    # found in this codebase's other safety mechanisms this session — now
    # wired into the actual gate as a BLOCK-severity check, so a tripped
    # circuit breaker genuinely halts new order submission rather than only
    # updating a label.
    try:
        from utils import CircuitBreaker
        cb = CircuitBreaker(active_cfg)
        cb_tripped, cb_reason = cb.check_history()
        if cb_tripped:
            violations.append({
                "severity": "BLOCK",
                "rule": "CIRCUIT_BREAKER",
                "ticker": "PORTFOLIO",
                "message": f"Circuit breaker tripped: {cb_reason}",
            })
    except Exception as _cbe:
        if log_cb:
            log_cb(f"[CircuitBreaker Pre-Trade] Notice: {_cbe}")

    # 1. VPIN preflight toxicity check
    vpin_results = {}
    try:
        from optimizer_broker import preflight_vpin_toxicity_check
        vpin_results = preflight_vpin_toxicity_check(
            weights, cfg=active_cfg, log_cb=log_cb, signal_df=signal_df
        )
        if vpin_results.get("blocked"):
            violations.append({
                "severity": "BLOCK",
                "rule": "VPIN_TOXICITY",
                "ticker": "BASKET",
                "message": f"VPIN pre-trade toxicity BLOCK: {vpin_results.get('reason')}"
            })
    except Exception as _ve:
        if log_cb:
            log_cb(f"[VPIN Pre-Trade] Notice: {_ve}")

    # 2. ComplianceEngine rule checks
    try:
        from utils import ComplianceEngine
        engine = ComplianceEngine(active_cfg)
        portfolio_rows = []
        for t, w in weights.items():
            if str(t).upper() != "CASH":
                portfolio_rows.append({"Ticker": t, "Weight": w})
        if portfolio_rows:
            p_df = pd.DataFrame(portfolio_rows)
            c_violations = engine.check(p_df, signal_df, sector_map or {})
            if c_violations:
                for v in c_violations:
                    if v.get("severity") in ("BLOCK", "BREACH"):
                        violations.append(v)
                    else:
                        warnings.append(v)
    except Exception as _ce:
        if log_cb:
            log_cb(f"[ComplianceEngine] Check notice: {_ce}")

    # 3. Earnings blackout gate (when enabled)
    if active_cfg.get("CHECK_EARNINGS_BLACKOUT", False):
        blackout_days = int(active_cfg.get("EARNINGS_BLACKOUT_DAYS", 2))
        for t in weights:
            if str(t).upper() != "CASH":
                try:
                    if check_earnings_blackout(str(t), blackout_days=blackout_days):
                        violations.append({
                            "severity": "BLOCK",
                            "rule": "EARNINGS_BLACKOUT",
                            "ticker": str(t),
                            "message": f"{t} is within earnings/results blackout window ({blackout_days}d)"
                        })
                except Exception as _eb_err:
                    if log_cb:
                        log_cb(f"[EarningsBlackout] {t}: {_eb_err}")

    # 4. Options skew tail risk warning (when enabled)
    if active_cfg.get("CHECK_OPTIONS_SKEW", False):
        skew_thresh = float(active_cfg.get("OPTIONS_SKEW_THRESHOLD", 1.25))
        for t in weights:
            if str(t).upper() != "CASH":
                try:
                    if evaluate_options_skew_warning(str(t), threshold=skew_thresh, cfg=active_cfg, log_cb=log_cb):
                        warnings.append({
                            "severity": "WARN",
                            "rule": "OPTIONS_SKEW_TAIL_RISK",
                            "ticker": str(t),
                            "message": f"{t} exhibits extreme OTM put skew (>= {skew_thresh})"
                        })
                except Exception as _sk_err:
                    if log_cb:
                        log_cb(f"[OptionsSkew] {t}: {_sk_err}")

    has_block = any(v.get("severity") == "BLOCK" for v in violations)
    has_breach = any(v.get("severity") == "BREACH" for v in violations)

    # BUGFIX (Round 41): a BREACH bypassed via compliance_override must NOT
    # collapse into the same "PASSED" status as a genuinely clean check —
    # they are not the same thing, and a caller that only branches on
    # `status` (rather than separately re-inspecting `violations`) would
    # treat an overridden BREACH as if zero violations occurred at all, with
    # no log line and no audit trail. Confirmed this is exactly what
    # enterprise/connectors/unified_broker_gateway.py's route_rebalanced_basket
    # did: it only checked `status in ("BLOCKED", "BREACH")`, so an overridden
    # BREACH fell through to the success path silently — no log message, and
    # the returned dict didn't even carry the violations list. "OVERRIDDEN"
    # is a distinct status so every caller must explicitly decide how to
    # handle it, rather than accidentally inheriting an "everything's fine"
    # code path meant for a real pass.
    if has_block:
        status = "BLOCKED"
    elif has_breach and not compliance_override:
        status = "BREACH"
    elif has_breach and compliance_override:
        status = "OVERRIDDEN"
    else:
        status = "PASSED"

    return {
        "status": status,
        "violations": violations,
        "warnings": warnings,
        "vpin_results": vpin_results,
    }
