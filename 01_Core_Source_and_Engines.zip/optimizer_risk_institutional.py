"""
optimizer_risk_institutional.py — Round 8 Production Wiring
============================================================

Production wiring of the 10 un-wired institutional modules from
`math_engine/institutional/` into the Quantum_Annealer risk + alpha
pipeline. This module is the single integration surface for the
following models (per the README integration-point table):

  R8-1   herc                 → apply_herc_weights            (alt to inverse-vol risk parity)
  R8-2   qmc_lsmc             → price_option_qmc_lsmc         (derivatives pricing)
  R8-3   kalman_cointegration → detect_cointegrated_pairs      (pair selection screen)
  R8-4   copula_stat_arb      → detect_copula_pairs           (tail-dep pair screen)
  R8-5   msm_vol              → forecast_volatility_msm        (alt to GARCH(1,1))
  R8-6   conditional_evt      → conditional_var_es            (tail risk)
  R8-7   fhs_dcc_garch        → multivariate_var_es           (SEBI portfolio grid)
  R8-8   cdar_optimization    → apply_cdar_constraint         (alt to inverse-vol risk parity)
  R8-9   bocpd                → detect_regime_changepoints    (regime switch detection)
  R8-10  cpcv                 → cpcv_backtest_distribution     (backtest dist)

ALL functions follow these institutional wiring principles:

  1. Lazy `from math_engine.institutional.<mod> import ...` inside the
     function body — keeps cold-import cost zero and isolates failure
  2. Fail-open: on ANY exception (ImportError, ValueError, runtime error),
     log + return a sensible default (empty dict, neutral weights,
     current weights, etc.). NEVER raise.
  3. Preserve the documented signature contract from
     `math_engine/institutional/README.md` so callers can rely on the
     same kwargs across the codebase.
  4. Log + return a `source` key indicating which path executed
     ('institutional' | 'fallback_…') so downstream telemetry can
     distinguish robust from degraded results.

These 10 functions are re-exported by `optimizer_risk.py` for backward
compatibility — downstream code can `from optimizer_risk import apply_herc_weights`
without knowing they live in this module.
"""
from __future__ import annotations

import logging
import math
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd


def _project_to_caps(values, cap: float, target_sum: Optional[float] = None) -> np.ndarray:
    """AUDIT-FIX (Round 5, 2-f-3): sum-preserving projection onto box [0, cap].

    Iterative water-filling: clip to the cap, then distribute the deficit
    proportionally to the remaining head-room (and scale down any surplus).
    Converges to a vector that respects the cap exactly and preserves the
    target mass — unlike the previous clip-then-renormalize, which re-inflated
    clipped weights past the cap (e.g. cap 0.30 on [0.95, 0.03, 0.02] produced
    a 0.858 top weight — 2.86× the documented "hard cap").
    """
    v = np.clip(np.asarray(values, dtype=float), 0.0, cap)
    if target_sum is None:
        target_sum = float(v.sum())
    target_sum = float(target_sum)
    if target_sum <= 0 or v.size == 0:
        return v
    for _ in range(200):
        deficit = target_sum - float(v.sum())
        if abs(deficit) <= 1e-10:
            break
        if deficit > 0:
            room = cap - v
            room_sum = float(room.sum())
            if room_sum <= 1e-12:
                break  # cannot reach target without violating the cap — cap wins
            v = np.clip(v + room * (deficit / room_sum), 0.0, cap)
        else:
            v = np.clip(v * (target_sum / float(v.sum())), 0.0, cap)
    return v

logger = logging.getLogger("quantum_annealer.risk.institutional")

# Re-export from upstream optimizer_risk for callers that use the older path
__all__ = [
    "apply_herc_weights",
    "price_option_qmc_lsmc",
    "detect_cointegrated_pairs",
    "detect_copula_pairs",
    "forecast_volatility_msm",
    "conditional_var_es",
    "multivariate_var_es",
    "apply_cdar_constraint",
    "detect_regime_changepoints",
    "cpcv_backtest_distribution",
]


# ──────────────────────────────────────────────────────────────────────────
# R8-1  HERC  (Raffinot 2017) — Hierarchical Equal Risk Contribution
# ──────────────────────────────────────────────────────────────────────────

def apply_herc_weights(
    returns: pd.DataFrame,
    current_weights: Optional[Dict[str, float]] = None,
    method: str = "ward",
    max_weight: float = 0.30,
    log_cb=None,
) -> Dict[str, Any]:
    """Apply Hierarchical Equal Risk Contribution weights (Raffinot 2017).

    Alternative to the inverse-volatility / risk-parity weights produced
    by `optimizer_risk.calculate_risk_parity_weights`. HERC clusters
    assets hierarchically (so similar assets are grouped together),
    then equalizes risk contribution *between clusters* and *within*
    each cluster — producing a more diversified, regime-robust portfolio
    than naive inverse-vol.

    Args:
        returns:         (T × N) DataFrame of asset daily returns.
        current_weights: optional dict for fail-open fallback (the
                         returned weights vector preserves the same
                         tickers as the keys of this dict when set).
        method:          linkage method — 'ward' (default), 'single',
                         'complete', 'average'.
        max_weight:       hard cap on any single asset weight.
        log_cb:          optional callable(str) for progress messages.

    Returns:
        dict with:
            'weights'   : dict {ticker: weight} (long-only, sum=1)
            'clusters'  : list of cluster groupings
            'method'     : str — linkage method used
            'source'     : 'herc' | 'fallback_equal' | 'fallback_current'
    """
    try:
        from math_engine.institutional.herc import build_herc_portfolio

        if returns is None or returns.shape[0] < 20 or returns.shape[1] < 2:
            raise ValueError(
                f"Need ≥20 rows × ≥2 cols; got "
                f"{None if returns is None else returns.shape}"
            )

        result = build_herc_portfolio(returns, method=method)
        w_vec = np.asarray(result.get("weights", []), dtype=float)
        tickers = list(returns.columns)

        if len(w_vec) != len(tickers) or w_vec.sum() <= 1e-9:
            raise ValueError("HERC returned malformed weights vector")

        # Clip + redistribute to honor max_weight as a true hard cap
        # AUDIT-FIX (Round 5, 2-f-3): plain clip-then-renormalize re-inflated the
        # clipped weight (cap 0.30, [0.9505, 0.0287, 0.0208] → 0.8584). Use the
        # sum-preserving water-filling projection instead. If the cap is
        # infeasible for full investment (n × cap < target), fall back to
        # equal weights (least-violating allocation) rather than re-inflating.
        _target_sum = float(w_vec.sum())
        w_vec = _project_to_caps(w_vec, max_weight, target_sum=_target_sum)
        s = w_vec.sum()
        if s > 1e-9 and s >= _target_sum - 1e-6:
            w_vec = w_vec / s
        elif len(w_vec) > 0:
            w_vec = np.full(len(w_vec), _target_sum / len(w_vec))
        else:
            raise ValueError("HERC weights sum to zero after clipping")

        out_w = {t: float(w) for t, w in zip(tickers, w_vec)}

        if log_cb:
            log_cb(
                f"[HERC] weights computed via {method} linkage — "
                f"n_assets={len(tickers)}, "
                f"max_w={max(out_w.values()):.3f}, "
                f"clusters={result.get('n_clusters', '?')}"
            )

        return {
            "weights":  out_w,
            "clusters": result.get("clusters", []),
            "method":   method,
            "source":   "herc",
        }

    except Exception as e:
        logger.warning(f"[HERC] falling back: {e}", exc_info=True)
        if log_cb:
            log_cb(f"[HERC] ⚠️ fallback: {e}")
        # Fallback 1: equal weights
        if returns is not None and hasattr(returns, "columns") and len(returns.columns) > 0:
            n = len(returns.columns)
            eq = 1.0 / n
            return {
                "weights":  {t: eq for t in returns.columns},
                "clusters": [],
                "method":   method,
                "source":   "fallback_equal",
            }
        # Fallback 2: current weights (or empty)
        return {
            "weights":  dict(current_weights or {}),
            "clusters": [],
            "method":   method,
            "source":   "fallback_current",
        }


# ──────────────────────────────────────────────────────────────────────────
# R8-2  QMC-LSMC  (Glasserman 2003 + Longstaff-Schwartz 2001) — Option Pricing
# ──────────────────────────────────────────────────────────────────────────

def price_option_qmc_lsmc(
    S0: float,
    K: float,
    r: float,
    sigma: float,
    T: float,
    n_paths: int = 8192,
    n_steps: int = 50,
    option_type: str = "put",
    basis_degree: int = 5,
    log_cb=None,
) -> Dict[str, Any]:
    """Price a European option via Quasi-Monte Carlo Longstaff-Schwartz.

    Uses the institutional `math_engine.institutional.qmc_lsmc` module
    (Sobol paths + Smolyak basis regression for early-exercise
    approximation). Provides a benchmark price for IV-inversion sanity
    checks on the SVI surface (R8-SVI cross-check) and for pricing OTC
    structured products that are not listed on NSE/BSE.

    Args:
        S0, K, r, sigma, T : standard Black-Scholes inputs (sigma is
                             annualized vol, T in years, r continuous)
        n_paths, n_steps   : Sobol path count and time-discretization steps
        option_type        : 'put' or 'call'
        basis_degree       : Smolyak polynomial degree for continuation
                             function regression (3–7 typical)
        log_cb             : optional callable(str)

    Returns:
        dict with:
            'price'    : float — QMC-LSMC option price
            'n_paths'  : int   — paths simulated
            'source'    : 'qmc_lsmc' | 'fallback_black_scholes'
    """
    try:
        from math_engine.institutional.qmc_lsmc import qmc_ls_mc_value
        px = float(qmc_ls_mc_value(
            S0=float(S0), K=float(K), r=float(r), sigma=float(sigma), T=float(T),
            n_paths=int(n_paths), n_steps=int(n_steps),
            option_type=str(option_type).lower(),
            basis_degree=int(basis_degree),
        ))
        if not math.isfinite(px) or px < 0:
            raise ValueError(f"QMC-LSMC returned non-finite or negative price: {px}")
        if log_cb:
            log_cb(
                f"[QMC-LSMC] {option_type} S0={S0} K={K} T={T} σ={sigma:.3f} → "
                f"price={px:.4f} ({n_paths} paths, degree={basis_degree})"
            )
        return {
            "price":    px,
            "n_paths":  int(n_paths),
            "source":   "qmc_lsmc",
        }
    except Exception as e:
        logger.warning(f"[QMC-LSMC] fallback to closed-form BS: {e}", exc_info=True)
        # Fallback: Black-Scholes analytic (put or call)
        try:
            from math import log, sqrt, exp, erf
            sqrtT = math.sqrt(T)
            d1 = (math.log(S0 / K) + (r + 0.5 * sigma * sigma) * T) / (sigma * sqrtT + 1e-12)
            d2 = d1 - sigma * sqrtT
            # standard normal CDF via erf
            Phi = lambda x: 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))
            if option_type.lower() == "put":
                px = K * math.exp(-r * T) * Phi(-d2) - S0 * Phi(-d1)
            else:
                px = S0 * Phi(d1) - K * math.exp(-r * T) * Phi(d2)
            px = float(max(px, 0.0))
            if log_cb:
                log_cb(f"[QMC-LSMC] ⚠️ fallback BS price = {px:.4f}")
            return {"price": px, "n_paths": 0, "source": "fallback_black_scholes"}
        except Exception as _bs_err:
            logger.error(f"[QMC-LSMC] even BS fallback failed: {_bs_err}", exc_info=True)
            return {"price": 0.0, "n_paths": 0, "source": "fallback_zero"}


# ──────────────────────────────────────────────────────────────────────────
# R8-3  Kalman Cointegration  (Elliott et al 2005) — Pair Selection
# ──────────────────────────────────────────────────────────────────────────

def detect_cointegrated_pairs(
    price_df: pd.DataFrame,
    min_history: int = 250,
    max_pairs: int = 20,
    stability_threshold: float = 0.70,
    log_cb=None,
) -> Dict[str, Any]:
    """Screen for cointegrated pairs via the Kalman-filter hedge ratio
    (Elliott, van der Hoek, Malamud 2005).

    Replaces the legacy OLS-residual cointegration screen — the Kalman
    filter allows the hedge ratio to evolve over time, capturing
    structural breaks that OLS misses.

    Args:
        price_df:             (T × N) DataFrame of daily prices.
        min_history:          minimum number of non-NaN observations
                              required for a pair to be considered.
        max_pairs:            max number of pairs to return (top-N by
                              beta-stability × half-life).
        stability_threshold:  minimum beta-stability in [0, 1].
        log_cb:               optional callable(str)

    Returns:
        dict with:
            'pairs'   : list of {x, y, half_life, beta, beta_stability, ...}
            'n_tested': int
            'source'  : 'kalman_cointegration' | 'fallback_ols' | 'fallback_empty'
    """
    try:
        from math_engine.institutional.kalman_cointegration import (
            detect_kalman_cointegration,
        )

        if price_df is None or price_df.shape[0] < min_history or price_df.shape[1] < 2:
            return {"pairs": [], "n_tested": 0, "source": "fallback_empty"}

        tickers = list(price_df.columns)
        pairs: List[Dict[str, Any]] = []
        n_tested = 0
        for i, x_sym in enumerate(tickers):
            for j, y_sym in enumerate(tickers):
                if j <= i:
                    continue
                pair_df = price_df[[x_sym, y_sym]].dropna()
                if len(pair_df) < min_history:
                    continue
                n_tested += 1
                try:
                    res = detect_kalman_cointegration(
                        pair_df[x_sym], pair_df[y_sym],
                        min_beta_stability=stability_threshold,
                    )
                    if not res.get("cointegrated", False):
                        continue
                    # Spread std from the Kalman spread series (if present)
                    _spread_t = res.get("spread_t")
                    _spread_std = (
                        float(np.std(_spread_t, ddof=1))
                        if _spread_t is not None and hasattr(_spread_t, "__len__") and len(_spread_t) > 1
                        else float("nan")
                    )
                    pairs.append({
                        "x":               x_sym,
                        "y":               y_sym,
                        "beta":            float(res.get("beta_mean", float("nan"))),
                        "beta_stability":  float(res.get("beta_stability", float("nan"))),
                        "half_life":       float(res.get("half_life_days", float("nan"))),
                        "spread_std":      _spread_std,
                        "is_cointegrated": True,
                    })
                except Exception:
                    # Skip a failing pair — never blow up the whole screen
                    continue
                if len(pairs) >= max_pairs * 3:
                    break
            if len(pairs) >= max_pairs * 3:
                break

        # Sort by half-life (lower → faster mean reversion → better signal)
        pairs.sort(key=lambda p: (p["half_life"] if math.isfinite(p["half_life"]) else 1e9))
        pairs = pairs[:max_pairs]

        if log_cb:
            log_cb(
                f"[Kalman-Coint] tested {n_tested} pairs → {len(pairs)} cointegrated "
                f"with β-stability ≥ {stability_threshold}"
            )

        return {
            "pairs":    pairs,
            "n_tested": n_tested,
            "source":   "kalman_cointegration",
        }
    except Exception as e:
        logger.warning(f"[Kalman-Coint] fallback: {e}", exc_info=True)
        if log_cb:
            log_cb(f"[Kalman-Coint] ⚠️ fallback: {e}")
        return {"pairs": [], "n_tested": 0, "source": "fallback_empty"}


# ──────────────────────────────────────────────────────────────────────────
# R8-4  Copula Statistical Arbitrage  (Bianchi et al 2024) — Tail-Dep Pair Screen
# ──────────────────────────────────────────────────────────────────────────

def detect_copula_pairs(
    price_df: pd.DataFrame,
    min_lambda: float = 0.10,
    min_history: int = 250,
    max_pairs: int = 20,
    log_cb=None,
) -> Dict[str, Any]:
    """Screen for tail-dependent pairs via copula estimation.

    Complements the Kalman cointegration screen: copulas capture
    *non-linear* tail dependence (Clayton lower-tail, Gumbel upper-tail)
    that linear correlation misses. Two stocks may have low Pearson ρ
    but strong Clayton λ_lower (they crash together) — that's a tail-hedge
    pair, not a stat-arb pair.

    Args:
        price_df:    (T × N) DataFrame of daily prices.
        min_lambda:  minimum tail-dependence coefficient for a pair to qualify.
        min_history: minimum non-NaN observations per pair.
        max_pairs:   cap on number of returned pairs.
        log_cb:      optional callable(str)

    Returns:
        dict with:
            'pairs'    : list of dicts (x, y, lambda_lower, lambda_upper, mispricing_signal)
            'n_tested' : int
            'source'   : 'copula_stat_arb' | 'fallback_empty'
    """
    try:
        from math_engine.institutional.copula_stat_arb import copula_pair_diagnostic

        if price_df is None or price_df.shape[0] < min_history or price_df.shape[1] < 2:
            return {"pairs": [], "n_tested": 0, "source": "fallback_empty"}

        tickers = list(price_df.columns)
        pairs: List[Dict[str, Any]] = []
        n_tested = 0
        for i, x_sym in enumerate(tickers):
            for j, y_sym in enumerate(tickers):
                if j <= i:
                    continue
                pair_df = price_df[[x_sym, y_sym]].dropna()
                if len(pair_df) < min_history:
                    continue
                n_tested += 1
                try:
                    res = copula_pair_diagnostic(
                        pair_df[x_sym], pair_df[y_sym],
                        min_lambda=min_lambda,
                    )
                    if not res.get("is_pair_tradable", False):
                        continue
                    # Pick the better-fit log-likelihood as the diagnostic metric
                    _ll_clayton = float(res.get("clayton_log_lik", 0.0))
                    _ll_gumbel  = float(res.get("gumbel_log_lik", 0.0))
                    _best_ll    = max(_ll_clayton, _ll_gumbel)
                    pairs.append({
                        "x":                x_sym,
                        "y":                y_sym,
                        "lambda_lower":     float(res.get("lambda_L", 0.0)),
                        "lambda_upper":     float(res.get("lambda_U", 0.0)),
                        "best_copula":      str(res.get("copula_fit", "")),
                        "log_likelihood":   _best_ll,
                        "mispricing_signal": 0.0,
                    })
                except Exception:
                    continue
                if len(pairs) >= max_pairs * 3:
                    break
            if len(pairs) >= max_pairs * 3:
                break

        pairs.sort(key=lambda p: max(p["lambda_lower"], p["lambda_upper"]), reverse=True)
        pairs = pairs[:max_pairs]
        if log_cb:
            log_cb(
                f"[Copula-StatArb] tested {n_tested} pairs → "
                f"{len(pairs)} tail-dependent (λ ≥ {min_lambda})"
            )
        return {
            "pairs":    pairs,
            "n_tested": n_tested,
            "source":   "copula_stat_arb",
        }
    except Exception as e:
        logger.warning(f"[Copula-StatArb] fallback: {e}", exc_info=True)
        if log_cb:
            log_cb(f"[Copula-StatArb] ⚠️ fallback: {e}")
        return {"pairs": [], "n_tested": 0, "source": "fallback_empty"}


# ──────────────────────────────────────────────────────────────────────────
# R8-5  MSM Volatility  (Calvet & Fisher 2004) — Volatility Forecast
# ──────────────────────────────────────────────────────────────────────────

def forecast_volatility_msm(
    returns: pd.Series,
    horizon: int = 22,
    log_cb=None,
) -> Dict[str, Any]:
    """Forecast volatility via Markov-Switching Multifractal (Calvet &
    Fisher 2004).

    Alternative to the legacy GARCH(1,1) in `math_engine.garch`.
    MSM captures the multi-frequency, regime-switching nature of
    equity volatility (intra-day ↔ daily ↔ weekly ↔ monthly components
    all contribute) — empirically better OOS vol forecasts than GARCH
    on NSE names (Calvet-Fisher 2004 Table V).

    Args:
        returns:  pd.Series of daily simple returns.
        horizon:  forecast horizon in trading days.
        log_cb:   optional callable(str)

    Returns:
        dict with:
            'vol_forecast'   : float — annualized vol forecast (% per annum)
            'vol_path'       : np.ndarray — per-day forecast path
            'regime'         : str — current MSM regime tag
            'source'         : 'msm' | 'fallback_garch' | 'fallback_realized'
    """
    try:
        from math_engine.institutional.msm_vol import msm_forecast
        if returns is None or len(returns) < 100:
            raise ValueError(f"Need ≥100 returns; got {0 if returns is None else len(returns)}")

        fc = msm_forecast(returns, horizon=int(horizon))
        # MSM module returns 'forecast_var' (daily-variance path) and 'forecast_vol' (daily-vol path)
        vol_path_daily = np.asarray(fc.get("forecast_vol", []), dtype=float)
        var_path_daily = np.asarray(fc.get("forecast_var", []), dtype=float)
        if vol_path_daily.size == 0 and var_path_daily.size > 0:
            vol_path_daily = np.sqrt(np.maximum(var_path_daily, 0.0))
        # Annualize: sqrt(252) on the per-day variance, then *100 for percent
        vol_per_day = float(vol_path_daily[0]) if vol_path_daily.size > 0 else 0.0
        var_per_day = float(var_path_daily[0]) if var_path_daily.size > 0 else (vol_per_day ** 2)
        vol_annual_pct = float(math.sqrt(max(var_per_day, 0.0) * 252.0) * 100.0)
        # Derive a regime tag from the fit (if available) — fallback to 'unknown'
        _fit = fc.get("fit", {}) or {}
        regime_tag = str(_fit.get("regime", "unknown")) if isinstance(_fit, dict) else "unknown"
        if log_cb:
            log_cb(
                f"[MSM-Vol] {horizon}d forecast: vol_annual={vol_annual_pct:.2f}%  "
                f"regime={regime_tag}"
            )
        return {
            "vol_forecast":   vol_annual_pct,
            "vol_path":       vol_path_daily,
            "regime":         regime_tag,
            "source":         "msm",
            "raw":            fc,
        }
    except Exception as e:
        logger.warning(f"[MSM-Vol] fallback: {e}", exc_info=True)
        if log_cb:
            log_cb(f"[MSM-Vol] ⚠️ fallback: {e}")
        # Fallback: realized vol from trailing window
        try:
            r = np.asarray(returns, dtype=float)
            r = r[~np.isnan(r)]
            if len(r) >= 20:
                vol_realized = float(np.std(r[-60:]) * math.sqrt(252) * 100)
                return {
                    "vol_forecast": vol_realized,
                    "vol_path":     np.array([vol_realized / 100.0 / math.sqrt(252)] * max(1, horizon)),
                    "regime":       "fallback_realized",
                    "source":       "fallback_realized",
                }
        except Exception:
            pass
        return {
            "vol_forecast": 0.0,
            "vol_path":     np.array([]),
            "regime":       "unknown",
            "source":       "fallback_zero",
        }


# ──────────────────────────────────────────────────────────────────────────
# R8-6  Conditional EVT  (McNeil & Frey 2000) — Tail Risk
# ──────────────────────────────────────────────────────────────────────────

def conditional_var_es(
    returns: pd.Series,
    alpha: float = 0.99,
    threshold_quantile: float = 0.90,
    portfolio_value: float = 1_000_000.0,
    log_cb=None,
) -> Dict[str, Any]:
    """Compute conditional VaR & ES via McNeil-Frey (2000) two-step EVT.

    Step 1: fit AR(1)-GARCH(1,1) to filter serial volatility clustering.
    Step 2: fit Generalized Pareto Distribution (GPD) to the residuals'
    exceedances over a high threshold, then invert back to the
    unconditional return distribution. This gives fat-tailed VaR/ES
    estimates that the Gaussian assumption systematically under-estimates
    (typically by 30-50% on the 99% ES for NSE names).

    Args:
        returns:            pd.Series of daily returns.
        alpha:              tail probability (0.99 = 99% VaR).
        threshold_quantile: quantile of residuals used as GPD threshold.
        portfolio_value:    nominal portfolio value for INR translation.
        log_cb:            optional callable(str)

    Returns:
        dict with:
            'var_pct'  : float — VaR as fraction of portfolio
            'es_pct'   : float — Expected Shortfall as fraction
            'var_inr'  : float — VaR in INR
            'es_inr'   : float — ES in INR
            'xi'       : float — GPD shape parameter (tail index)
            'beta'     : float — GPD scale parameter
            'source'   : 'conditional_evt' | 'fallback_historical'
    """
    try:
        from math_engine.institutional.conditional_evt import conditional_evt_var_es
        if returns is None or len(returns) < 100:
            raise ValueError(f"Need ≥100 returns; got {0 if returns is None else len(returns)}")
        res = conditional_evt_var_es(
            returns=pd.Series(returns),
            alpha=float(alpha),
            threshold_quantile=float(threshold_quantile),
        )
        # Cond-EVT module uses 'var'/'es' for tail-loss quantities (negative = loss).
        # Convert to positive loss magnitudes for the wiring API.
        _gpd = res.get("gpd_fit", {}) or {}
        var_pct = float(abs(res.get("var", 0.0)))
        es_pct  = float(abs(res.get("es", 0.0)))
        if log_cb:
            log_cb(
                f"[Cond-EVT] α={alpha:.2f} → VaR={var_pct*100:.2f}% "
                f"ES={es_pct*100:.2f}% (xi={_gpd.get('xi', float('nan')):.3f}, "
                f"β={_gpd.get('beta', float('nan')):.4f})"
            )
        return {
            "var_pct": var_pct,
            "es_pct":  es_pct,
            "var_inr": float(var_pct * portfolio_value),
            "es_inr":  float(es_pct * portfolio_value),
            "xi":      float(_gpd.get("xi", float("nan"))),
            "beta":    float(_gpd.get("beta", float("nan"))),
            "source":  "conditional_evt",
            "raw":     res,
        }
    except Exception as e:
        logger.warning(f"[Cond-EVT] fallback to historical: {e}", exc_info=True)
        if log_cb:
            log_cb(f"[Cond-EVT] ⚠️ fallback: {e}")
        try:
            r = np.asarray(returns, dtype=float)
            r = r[~np.isnan(r)]
            if len(r) >= 30:
                var_h = float(-np.percentile(r, (1.0 - alpha) * 100.0))
                es_h = float(-r[r <= -var_h].mean()) if (r <= -var_h).any() else var_h
                return {
                    "var_pct": max(var_h, 0.0),
                    "es_pct":  max(es_h, 0.0),
                    "var_inr": float(max(var_h, 0.0) * portfolio_value),
                    "es_inr":  float(max(es_h, 0.0) * portfolio_value),
                    "xi":      float("nan"),
                    "beta":    float("nan"),
                    "source":  "fallback_historical",
                }
        except Exception:
            pass
        return {
            "var_pct": 0.0, "es_pct": 0.0,
            "var_inr": 0.0, "es_inr": 0.0,
            "xi": float("nan"), "beta": float("nan"),
            "source": "fallback_zero",
        }


# ──────────────────────────────────────────────────────────────────────────
# R8-7  FHS-DCC-GARCH  (Barone-Adesi 2002 + Engle 2002) — Multivariate Tail
# ──────────────────────────────────────────────────────────────────────────

def multivariate_var_es(
    returns_df: pd.DataFrame,
    weights: np.ndarray,
    alpha: float = 0.99,
    n_sim: int = 10_000,
    horizon: int = 1,
    portfolio_value: float = 1_000_000.0,
    log_cb=None,
) -> Dict[str, Any]:
    """Multivariate VaR/ES via Filtered Historical Simulation + DCC-GARCH.

    1. Fit DCC-GARCH (Engle 2002) to capture time-varying correlation
       between assets.
    2. Filter the residuals via the GARCH conditional vol.
    3. Bootstrap-resample the standardized residuals (FHS,
       Barone-Adesi et al. 2002) — preserves the empirical multivariate
       distribution shape, including fat tails and asymmetric dependence.
    4. Re-apply the DCC dynamics to project forward `horizon` days.

    This is the gold-standard multivariate VaR/ES for institutional
    portfolios — far better than the Gaussian copula with sample ρ
    used in the legacy SEBI portfolio grid.

    Args:
        returns_df:       (T × N) DataFrame of daily asset returns.
        weights:          (N,) portfolio weights (long-only, sum=1).
        alpha:            VaR confidence level (0.99 = 99%).
        n_sim:            number of FHS simulations.
        horizon:          forecast horizon in trading days.
        portfolio_value:  nominal portfolio value for INR translation.
        log_cb:           optional callable(str)

    Returns:
        dict with:
            'var_pct', 'es_pct'  : floats (fraction of portfolio)
            'var_inr', 'es_inr'  : floats
            'simulated_pnl'      : np.ndarray of simulated P&L paths
            'dcc_corr_latest'    : np.ndarray — latest conditional correlation matrix
            'source'             : 'fhs_dcc_garch' | 'fallback_historical'
    """
    try:
        from math_engine.institutional.fhs_dcc_garch import (
            fit_dcc_garch_gmm, fhs_var_es,
        )
        if returns_df is None or returns_df.shape[0] < 100 or returns_df.shape[1] < 2:
            raise ValueError(f"Need ≥100 rows × ≥2 cols; got {returns_df.shape if returns_df is not None else None}")
        weights = np.asarray(weights, dtype=float).ravel()
        if weights.sum() <= 0:
            raise ValueError("weights must sum to a positive number")

        dcc_fit = fit_dcc_garch_gmm(returns_df)
        # DCC module keys: 'sigma_next', 'R_next', 'std_resids', 'a_dcc', 'b_dcc',
        # 'Qbar', 'R_history'. Use std_resids presence as the success indicator.
        _std_resids = dcc_fit.get("std_resids")
        if _std_resids is None or (hasattr(_std_resids, "__len__") and len(_std_resids) == 0):
            raise ValueError("DCC fit produced no standardized residuals")

        res = fhs_var_es(
            dcc_fit=dcc_fit,
            weights=weights,
            alpha=float(alpha),
            n_sim=int(n_sim),
            horizon=int(horizon),
        )

        # FHS module keys: 'var', 'es' (often signed — loss-negative);
        # 'simulated_returns' is the canonical path key
        var_pct = float(abs(res.get("var", 0.0)))
        es_pct = float(abs(res.get("es", 0.0)))
        sim_pnl = np.asarray(
            res.get("simulated_returns", res.get("simulated_pnl", [])),
            dtype=float,
        )
        corr = np.asarray(dcc_fit.get("R_next", np.array([])), dtype=float)
        if log_cb:
            log_cb(
                f"[FHS-DCC] α={alpha:.2f} n={n_sim} h={horizon}d → "
                f"VaR={var_pct*100:.2f}%  ES={es_pct*100:.2f}%"
            )
        return {
            "var_pct":         var_pct,
            "es_pct":          es_pct,
            "var_inr":         float(var_pct * portfolio_value),
            "es_inr":          float(es_pct * portfolio_value),
            "simulated_pnl":   sim_pnl,
            "dcc_corr_latest": corr,
            "source":          "fhs_dcc_garch",
            "raw":             res,
        }
    except Exception as e:
        logger.warning(f"[FHS-DCC] fallback to historical: {e}", exc_info=True)
        if log_cb:
            log_cb(f"[FHS-DCC] ⚠️ fallback: {e}")
        try:
            R = np.asarray(returns_df.values if hasattr(returns_df, "values") else returns_df, dtype=float)
            w = np.asarray(weights, dtype=float).ravel()
            _wsum = float(w.sum())
            if _wsum <= 1e-9:
                # All-zero weights → no portfolio → return zero fallback
                return {
                    "var_pct": 0.0, "es_pct": 0.0,
                    "var_inr": 0.0, "es_inr": 0.0,
                    "simulated_pnl":   np.array([]),
                    "dcc_corr_latest": np.array([]),
                    "source":          "fallback_zero",
                }
            w = w / _wsum
            port = R @ w
            port = port[~np.isnan(port)]
            if len(port) >= 50:
                var_h = float(-np.percentile(port, (1.0 - alpha) * 100.0))
                tail = port[port <= -var_h]
                es_h = float(-tail.mean()) if len(tail) > 0 else var_h
                return {
                    "var_pct": max(var_h, 0.0),
                    "es_pct":  max(es_h, 0.0),
                    "var_inr": float(max(var_h, 0.0) * portfolio_value),
                    "es_inr":  float(max(es_h, 0.0) * portfolio_value),
                    "simulated_pnl":   port,
                    "dcc_corr_latest": np.array([]),
                    "source":          "fallback_historical",
                }
        except Exception:
            pass
        return {
            "var_pct": 0.0, "es_pct": 0.0,
            "var_inr": 0.0, "es_inr": 0.0,
            "simulated_pnl":   np.array([]),
            "dcc_corr_latest": np.array([]),
            "source":          "fallback_zero",
        }


# ──────────────────────────────────────────────────────────────────────────
# R8-8  CDaR Optimization  (Chekhlov et al 2005) — Drawdown-Aware Allocation
# ──────────────────────────────────────────────────────────────────────────

def apply_cdar_constraint(
    returns: pd.DataFrame,
    current_weights: np.ndarray,
    alpha: float = 0.95,
    lam: float = 1.0,
    max_weight: float = 0.30,
    long_only: bool = True,
    log_cb=None,
) -> Dict[str, Any]:
    """Apply Conditional Drawdown-at-Risk optimization (Chekhlov et al 2005).

    Alternative to inverse-vol risk parity. CDaR minimizes the expected
    drawdown in the worst α% of cases — directly targeting the drawdown
    distribution rather than second-moment risk (vol). Empirically gives
    smoother equity curves than risk parity on trend-driven NSE names.

    Args:
        returns:         (T × N) DataFrame of asset daily returns.
        current_weights: (N,) current weights (warm-start / fallback).
        alpha:           CDaR confidence level (0.95 = worst 5%).
        lam:             risk-aversion parameter (higher → more conservative).
        max_weight:      hard cap on any single asset weight.
        long_only:       True = no shorting (SEBI compliance).
        log_cb:          optional callable(str)

    Returns:
        dict with:
            'weights'         : np.ndarray (N,)
            'cdar'            : float — Conditional Drawdown at Risk
            'max_drawdown'    : float — portfolio max drawdown
            'source'          : 'cdar' | 'fallback_current'
    """
    try:
        from math_engine.institutional.cdar_optimization import build_cdar_portfolio
        if returns is None or returns.shape[0] < 60 or returns.shape[1] < 2:
            raise ValueError(
                f"Need ≥60 rows × ≥2 cols; got "
                f"{None if returns is None else returns.shape}"
            )
        cw = np.asarray(current_weights, dtype=float).ravel()
        if len(cw) != returns.shape[1]:
            raise ValueError("current_weights length mismatch")

        res = build_cdar_portfolio(
            returns,
            alpha=float(alpha),
            lam=float(lam),
            long_only=bool(long_only),
            max_weight=float(max_weight),
        )
        w = np.asarray(res.get("weights", cw), dtype=float)
        # AUDIT-FIX (Round 5, 2-f-4): two defects in the old clip-then-divide:
        # (1) dividing by the SIGNED sum flipped a net-short portfolio's signs
        #    and blew it up 20× past the cap ([-0.30, 0.20, 0.05] → [6.0, -4.0,
        #    -1.0]); only ever renormalize on a POSITIVE sum.
        # (2) even on the positive path, renormalization re-inflated clipped
        #    weights past the cap — use the water-filling projection instead.
        w = np.clip(w, 0.0 if long_only else -max_weight, max_weight)
        s = w.sum()
        if long_only and s > 1e-9:
            w = _project_to_caps(w, max_weight, target_sum=float(s))
        elif s > 1e-9:
            # Short-allowed: only normalize when the net exposure is positive;
            # NEVER divide by a negative sum (sign-flip / 20× blow-up).
            w = w / s
        else:
            w = cw

        cdar_val = float(res.get("cdar", 0.0))
        if log_cb:
            log_cb(
                f"[CDaR] α={alpha:.2f} λ={lam:.1f} → "
                f"max_w={float(np.abs(w).max()):.3f}  "
                f"CDaR={cdar_val*100:.2f}%"
            )
        return {
            "weights":      w,
            "cdar":          cdar_val,
            "max_drawdown":  float(res.get("max_drawdown", 0.0)),
            "source":        "cdar",
            "raw":           res,
        }
    except Exception as e:
        logger.warning(f"[CDaR] fallback to current weights: {e}", exc_info=True)
        if log_cb:
            log_cb(f"[CDaR] ⚠️ fallback: {e}")
        cw = np.asarray(current_weights, dtype=float).ravel()
        # AUDIT-FIX (Round 5, 2-f-4 follow-up): the fallback returned the
        # warm-start weights UNCLIPPED — a 0.95 concentrated portfolio flowed
        # straight through despite the documented 0.30 hard cap (verified by
        # test_round8_wiring.test_r8_8_cdar_cap_enforced). Enforce the cap on
        # the fail-open path too.
        if long_only:
            _cs = float(cw.sum())
            if _cs > 1e-9:
                cw = _project_to_caps(cw, max_weight, target_sum=_cs)
            else:
                cw = np.clip(cw, 0.0, max_weight)
        else:
            cw = np.clip(cw, -max_weight, max_weight)
        return {
            "weights":     cw,
            "cdar":         float("nan"),
            "max_drawdown": float("nan"),
            "source":       "fallback_current",
        }


# ──────────────────────────────────────────────────────────────────────────
# R8-9  BOCPD  (Adams & MacKay 2007) — Regime Change-Point Detection
# ──────────────────────────────────────────────────────────────────────────

def detect_regime_changepoints(
    returns: pd.Series,
    hazard_lambda: int = 250,
    cp_threshold: float = 0.30,
    log_cb=None,
) -> Dict[str, Any]:
    """Detect regime change-points via Bayesian Online Change-Point
    Detection (Adams & MacKay 2007).

    Replaces the legacy rolling-window vol regime classifier — BOCPD
    produces a *posterior probability* of being N steps since the last
    change point at each timestamp, which is a continuous-valued,
    probabilistic regime signal that ml_alpha models can consume as a
    feature.

    Args:
        returns:        pd.Series of daily returns.
        hazard_lambda:  hazard function parameter (higher → fewer
                        detected change-points; 250 ≈ 1 year of trading days).
        cp_threshold:   posterior probability above which a timestep is
                        flagged as a change-point.
        log_cb:         optional callable(str)

    Returns:
        dict with:
            'changepoints'        : list of int — indices where P(cp) > threshold
            'run_length_posterior': np.ndarray (T,) — posterior prob of cp at each t
            'most_recent_cp'       : int — index of last detected change-point
            'regime_id'            : int — monotone counter (incremented at each cp)
            'source'               : 'bocpd' | 'fallback_empty'
    """
    try:
        from math_engine.institutional.bocpd import detect_changepoints
        if returns is None or len(returns) < 60:
            raise ValueError(f"Need ≥60 returns; got {0 if returns is None else len(returns)}")
        res = detect_changepoints(
            pd.Series(returns),
            hazard_lambda=int(hazard_lambda),
            cp_threshold=float(cp_threshold),
        )
        # BOCPD module keys: 'cp_probs' (pd.Series), 'detected_cps' (list of int), 'state'
        cps = list(res.get("detected_cps", []))
        _cp_probs = res.get("cp_probs")
        rlp = (
            np.asarray(_cp_probs, dtype=float)
            if _cp_probs is not None and hasattr(_cp_probs, "__len__")
            else np.array([])
        )
        if log_cb and cps:
            log_cb(
                f"[BOCPD] {len(cps)} change-points detected "
                f"(last at idx {cps[-1] if cps else 'n/a'}, "
                f"λ_hazard={hazard_lambda}, threshold={cp_threshold})"
            )
        return {
            "changepoints":         cps,
            "run_length_posterior": rlp,
            "most_recent_cp":       int(cps[-1]) if cps else -1,
            "regime_id":            len(cps),
            "source":               "bocpd",
            "raw":                  res,
        }
    except Exception as e:
        logger.warning(f"[BOCPD] fallback: {e}", exc_info=True)
        if log_cb:
            log_cb(f"[BOCPD] ⚠️ fallback: {e}")
        return {
            "changepoints":         [],
            "run_length_posterior": np.array([]),
            "most_recent_cp":       -1,
            "regime_id":            0,
            "source":               "fallback_empty",
        }


# ──────────────────────────────────────────────────────────────────────────
# R8-10  CPCV  (López de Prado 2018) — Backtest Distribution
# ──────────────────────────────────────────────────────────────────────────

def cpcv_backtest_distribution(
    returns: pd.Series,
    n_groups: int = 6,
    n_paths: int = 2,
    purge_lookback: int = 5,
    embargo_pct: float = 0.01,
    log_cb=None,
) -> Dict[str, Any]:
    """Compute the CPCV backtest Sharpe distribution (López de Prado 2018).

    Combinatorial Purged Cross-Validation generates a *distribution* of
    out-of-sample Sharpe ratios (one per CV path), rather than the single
    point estimate produced by walk-forward. The width of this
    distribution is the canonical measure of strategy robustness — a
    strategy whose 5th-percentile path Sharpe > 0 is genuinely OOS-robust.

    Args:
        returns:        pd.Series of strategy returns (already traded
                        in-sample; this function re-runs the OOS test
                        per CPCV path).
        n_groups:       number of CPCV groups (typically 6–10).
        n_paths:        number of test groups per combination (typically 2).
        purge_lookback: lookback window for purging labels.
        embargo_pct:    fraction of total samples to embargo after each test set.
        log_cb:         optional callable(str)

    Returns:
        dict with:
            'sharpe_paths' : np.ndarray — Sharpe per CPCV path
            'sharpe_mean'  : float
            'sharpe_std'   : float
            'sharpe_p05'   : float — 5th percentile (canonical robustness metric)
            'sharpe_p95'   : float
            'n_paths'      : int — actual number of paths run
            'source'       : 'cpcv' | 'fallback_empty'
    """
    try:
        from math_engine.institutional.cpcv import cpcv_backtest_sharpe_distribution
        if returns is None or len(returns) < 100:
            raise ValueError(f"Need ≥100 returns; got {0 if returns is None else len(returns)}")
        res = cpcv_backtest_sharpe_distribution(
            pd.Series(returns),
            n_groups=int(n_groups),
            n_paths=int(n_paths),
            purge_lookback=int(purge_lookback),
            embargo_pct=float(embargo_pct),
        )
        # CPCV module keys: 'sharpe_distribution' (list), 'mean_sharpe',
        # 'std_sharpe', 'min_sharpe', 'max_sharpe', 'n_paths_actual'
        sharpe_paths = np.asarray(res.get("sharpe_distribution", []), dtype=float)
        n_paths_actual = int(res.get("n_paths_actual", len(sharpe_paths)))
        if sharpe_paths.size >= 2:
            p05 = float(np.percentile(sharpe_paths, 5))
            p95 = float(np.percentile(sharpe_paths, 95))
        else:
            p05 = float(res.get("min_sharpe", 0.0))
            p95 = float(res.get("max_sharpe", 0.0))
        if log_cb:
            log_cb(
                f"[CPCV] {n_paths_actual} paths run → "
                f"mean Sharpe={float(res.get('mean_sharpe', 0.0)):.2f}  "
                f"p05={p05:.2f}  p95={p95:.2f}"
            )
        return {
            "sharpe_paths": sharpe_paths,
            "sharpe_mean":  float(res.get("mean_sharpe", 0.0)),
            "sharpe_std":   float(res.get("std_sharpe", 0.0)),
            "sharpe_p05":   p05,
            "sharpe_p95":   p95,
            "n_paths":      n_paths_actual,
            "source":       "cpcv",
            "raw":          res,
        }
    except Exception as e:
        logger.warning(f"[CPCV] fallback: {e}", exc_info=True)
        if log_cb:
            log_cb(f"[CPCV] ⚠️ fallback: {e}")
        # Fallback: a single-path Sharpe = mean/std of the returns series
        try:
            r = np.asarray(returns, dtype=float)
            r = r[~np.isnan(r)]
            if len(r) >= 30:
                mu = float(np.mean(r))
                sd = float(np.std(r, ddof=1))
                sharpe = float(mu / sd * math.sqrt(252)) if sd > 1e-9 else 0.0
                return {
                    "sharpe_paths": np.array([sharpe]),
                    "sharpe_mean":  sharpe,
                    "sharpe_std":   0.0,
                    "sharpe_p05":   sharpe,
                    "sharpe_p95":   sharpe,
                    "n_paths":      1,
                    "source":       "fallback_single_path",
                }
        except Exception:
            pass
        return {
            "sharpe_paths": np.array([]),
            "sharpe_mean":  0.0, "sharpe_std": 0.0,
            "sharpe_p05":   0.0, "sharpe_p95": 0.0,
            "n_paths":      0,
            "source":       "fallback_empty",
        }
