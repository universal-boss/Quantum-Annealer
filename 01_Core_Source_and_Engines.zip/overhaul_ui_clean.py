with open("web_dashboard/index.html", "r") as f:
    content = f.read()

# 1. Clean Header Row Buttons
hdr_target = """          <span class="header-title">Quantum Annealer — Pinnacle SOTA Edition</span>
          <span class="badge-real-money">REAL-MONEY SYSTEM ACTIVE</span>
          <span class="badge-regime" id="gatekeeperBadge">🟢 BULLISH REGIME (100% SIZING)</span>
          <button class="btn-settings-header" onclick="downloadExecutiveFactsheet()" style="background:rgba(0,230,118,0.15); color:#00e676; border-color:rgba(0,230,118,0.3);">📄 Factsheet PDF</button>
          <button class="btn-settings-header" onclick="openPopoutWindow('charts')" style="background:rgba(56,189,248,0.15); color:#38bdf8; border-color:rgba(56,189,248,0.3);">🪟 Popout</button>
          <button class="btn-settings-header" onclick="openSettingsModal()">Settings</button>"""

hdr_replace = """          <span class="header-title">Quantum Annealer — Pinnacle SOTA Edition</span>
          <span class="badge-real-money">REAL-MONEY SYSTEM ACTIVE</span>
          <span class="badge-regime" id="gatekeeperBadge">🟢 BULLISH REGIME (100% SIZING)</span>
          <div style="display:inline-flex; gap:6px; margin-left:auto; align-items:center;">
            <button class="btn-settings-header" onclick="downloadExecutiveFactsheet()" style="background:rgba(0,230,118,0.12); color:#00e676; border:1px solid rgba(0,230,118,0.3); font-size:11px; padding:3px 10px; border-radius:4px;">📄 Factsheet PDF</button>
            <button class="btn-settings-header" onclick="openPopoutWindow('charts')" style="background:rgba(56,189,248,0.12); color:#38bdf8; border:1px solid rgba(56,189,248,0.3); font-size:11px; padding:3px 10px; border-radius:4px;">🪟 Popout</button>
            <button class="btn-settings-header" onclick="openSettingsModal()" style="background:rgba(255,255,255,0.06); color:#e2e8f0; border:1px solid rgba(255,255,255,0.15); font-size:11px; padding:3px 10px; border-radius:4px;">⚙️ Settings</button>
          </div>"""

content = content.replace(hdr_target, hdr_replace)

# 2. Clean tab-all-profiles stacked buttons and status badges
all_prof_target = """            <!-- Top Profile Status Badges Row (Exact Desktop Replica) -->
            <div
              style="display:flex; justify-content:space-between; align-items:center; background:var(--bg-card); border:1px solid var(--border-color); border-radius:4px; padding:6px 10px; margin-bottom:8px; gap:8px;">
              <div style="display:flex; gap:6px; flex-wrap:wrap; align-items:center; flex:1;">
                <span class="badge-profile-status" id="badgeProf0">✓ 🔍 Smart Money</span>
                <span class="badge-profile-status" id="badgeProf1">✓ 🚀 Max Alpha</span>
                <span class="badge-profile-status" id="badgeProf2">✓ 📈 Trend Momentum</span>
                <span class="badge-profile-status" id="badgeProf3">✓ 💰 GARP</span>
                <span class="badge-profile-status" id="badgeProf4">✓ 🏦 Inst. Accumulation</span>
                <span class="badge-profile-status" id="badgeProf5">✓ 🏛️ Quality Comp.</span>
                <span class="badge-profile-status" id="badgeProf6">✓ ⚡ Vol Squeeze</span>
                <span class="badge-profile-status" id="badgeProf7">✓ ⚖️ Risk Parity</span>
                <span class="badge-profile-status" id="badgeProf8">✓ 🛡️ Capital Preserv.</span>
              </div>
              <button class="btn-stop-compact" onclick="stopExecution()">🔴 Stop All</button>
            </div>

            <!-- Sub-Profile Navigation Buttons -->
            <div
              style="display:flex; gap:4px; margin-bottom:8px; overflow-x:auto; border-bottom:1px solid var(--border-color); padding-bottom:6px;">
              <button class="tab-btn active" id="subTabCompare" onclick="switchAllProfilesSubTab('compare', this)">📊
                Compare All</button>
              <button class="tab-btn" onclick="switchAllProfilesSubTab('🔍 Smart Money · Early Entry', this)">🔍 Smart
                Money</button>
              <button class="tab-btn" onclick="switchAllProfilesSubTab('🚀 Max Alpha · Institutional', this)">🚀 Max
                Alpha</button>
              <button class="tab-btn" onclick="switchAllProfilesSubTab('📈 Trend Momentum · Core', this)">📈 Trend
                Momentum</button>
              <button class="tab-btn" onclick="switchAllProfilesSubTab('💰 GARP · Value + Breakout', this)">💰
                GARP</button>
              <button class="tab-btn" onclick="switchAllProfilesSubTab('🏦 Inst. Accumulation · Flow', this)">🏦 Inst.
                Accumulation</button>
              <button class="tab-btn" onclick="switchAllProfilesSubTab('🏛️ Quality Compounders', this)">🏛️ Quality
                Compounders</button>
              <button class="tab-btn"
                onclick="switchAllProfilesSubTab('⚡ Vol Squeeze · Microstructure Breakout', this)">⚡ Vol
                Squeeze</button>
              <button class="tab-btn" onclick="switchAllProfilesSubTab('⚖️ Risk Parity · All-Weather', this)">⚖️ Risk
                Parity</button>
              <button class="tab-btn" onclick="switchAllProfilesSubTab('🛡️ Capital Preservation · Defense', this)">🛡️
                Capital Defense</button>
            </div>"""

all_prof_replace = """            <!-- Streamlined Single-Line Profile Switcher -->
            <div style="display:flex; justify-content:space-between; align-items:center; background:var(--bg-card); border:1px solid var(--border-color); border-radius:4px; padding:6px 12px; margin-bottom:8px;">
              <div style="display:flex; align-items:center; gap:10px;">
                <span style="font-size:11px; font-weight:700; color:var(--cyan-accent);">⚡ Profile View:</span>
                <select id="subProfileSelect" onchange="switchAllProfilesSubTab(this.value, null)" style="background:var(--bg-secondary); border:1px solid var(--border-color); color:var(--text-primary); padding:4px 10px; border-radius:4px; font-size:11px; font-weight:600;">
                  <option value="compare">📊 Master Comparison Matrix (All 9 Profiles)</option>
                  <option value="🔍 Smart Money · Early Entry">🔍 Smart Money · Early Entry</option>
                  <option value="🚀 Max Alpha · Institutional">🚀 Max Alpha · Institutional</option>
                  <option value="📈 Trend Momentum · Core">📈 Trend Momentum · Core</option>
                  <option value="💰 GARP · Value + Breakout">💰 GARP · Value + Breakout</option>
                  <option value="🏦 Inst. Accumulation · Flow">🏦 Inst. Accumulation · Flow</option>
                  <option value="🏛️ Quality Compounders">🏛️ Quality Compounders</option>
                  <option value="⚡ Vol Squeeze · Microstructure Breakout">⚡ Vol Squeeze · Microstructure Breakout</option>
                  <option value="⚖️ Risk Parity · All-Weather">⚖️ Risk Parity · All-Weather</option>
                  <option value="🛡️ Capital Preservation · Defense">🛡️ Capital Preservation · Defense</option>
                </select>
              </div>
              <button class="btn-stop-compact" onclick="stopExecution()" style="padding:4px 10px; font-size:10px;">🔴 Stop All Runs</button>
            </div>"""

content = content.replace(all_prof_target, all_prof_replace)

with open("web_dashboard/index.html", "w") as f:
    f.write(content)
