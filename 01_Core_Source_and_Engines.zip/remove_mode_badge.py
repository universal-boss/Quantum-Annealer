"""AUDIT-FIX (Round 5, 2-f-10): one-shot repo-maintenance patch script.

Previously opened the CWD-relative "web_dashboard/index.html" — run from any
other directory it crashed with FileNotFoundError, and its regex lacked
re.DOTALL so a multi-line span would silently not match. Anchor the path to
this file's directory, guard existence, and match across newlines.
"""
import os
import re

_HERE = os.path.dirname(os.path.abspath(__file__))
_TARGET = os.path.join(_HERE, "web_dashboard", "index.html")

if not os.path.exists(_TARGET):
    print(f"[remove_mode_badge] target not found (nothing to do): {_TARGET}")
else:
    with open(_TARGET, "r", encoding="utf-8") as f:
        html = f.read()

    # Remove the badge-real-money span entirely (DOTALL: span may span lines)
    html = re.sub(
        r"\s*<span class=\"badge-real-money\"[^>]*>.*?</span>",
        "",
        html,
        flags=re.DOTALL,
    )

    with open(_TARGET, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"[remove_mode_badge] processed: {_TARGET}")
