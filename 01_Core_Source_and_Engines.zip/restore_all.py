#!/usr/bin/env python3
"""
restore_all.py
==============
Reconstitutes the complete Quantum Annealer repository from the partitioned ZIP files.
Usage:
  python3 restore_all.py [target_directory]
"""
import sys
import glob
import zipfile
from pathlib import Path

target_dir = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("./Quantum_Annealer_Restored")
target_dir.mkdir(parents=True, exist_ok=True)
current_dir = Path(__file__).parent

zip_files = sorted(glob.glob(str(current_dir / "Quantum_Annealer_*.zip")))
print(f"📦 Found {len(zip_files)} partition archives. Extracting to {target_dir}...")

for zf_path in zip_files:
    print(f"  -> Extracting {Path(zf_path).name}...")
    with zipfile.ZipFile(zf_path, "r") as zf:
        zf.extractall(target_dir)

# Recombine deep alpha model chunks if present
models_dir = target_dir / "models"
part_files = sorted(models_dir.glob("ml_alpha_model.pkl.part*"))
if part_files:
    print(f"  -> Recombining {len(part_files)} chunks into models/ml_alpha_model.pkl...")
    master_model = models_dir / "ml_alpha_model.pkl"
    with open(master_model, "wb") as f_out:
        for p in part_files:
            with open(p, "rb") as f_in:
                f_out.write(f_in.read())
            p.unlink()
    print("  ✅ ml_alpha_model.pkl successfully reconstituted!")

print(f"🎉 Complete Quantum Annealer project restored to: {target_dir.resolve()}")
