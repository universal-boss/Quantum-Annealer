with open("web_dashboard/styles.css", "r") as f:
    css = f.read()

root_target = """:root {
  --bg-app: #131722;             /* TradingView Official Canvas Dark */
  --bg-sidebar: #1e222d;         /* TradingView Official Surface Panel Dark */
  --bg-card: #1e222d;            /* TradingView Card Surface */
  --bg-card-elevated: #2a2e39;   /* TradingView Hover Surface */
  --bg-input: #131722;           /* TradingView Input Deep Dark */
  --bg-input-focus: #2a2e39;     /* TradingView Input Active */
  --bg-secondary: #1e222d;
  --bg-dark: #131722;
  
  --border-color: #2a2e39;       /* TradingView Official Panel Border */
  --border-subtle: #262933;      /* TradingView Subtle Divider */
  --border-focus: #2962ff;       /* TradingView Royal Blue Focus */
  
  --text-primary: #d1d4dc;       /* TradingView Primary Text */
  --text-secondary: #787b86;     /* TradingView Secondary Grey */
  --text-muted: #5d606b;         /* TradingView Muted Grey */
  
  --cyan-accent: #2962ff;        /* TradingView Royal Blue Accent */
  --cyan-hover: #1e53e5;        
  --emerald-profit: #089981;     /* TradingView Official Candle Green */
  --crimson-risk: #f23645;       /* TradingView Official Candle Red */
  --amber-warn: #ff9800;        
  --amber-border: #f57c00;      
  --purple-regime: #9c27b0;      
  
  --font-main: -apple-system, BlinkMacSystemFont, "Trebuchet MS", Roboto, Ubuntu, sans-serif;
  --font-mono: "Courier New", Courier, monospace;
}"""

root_restore = """:root {
  --bg-app: #070b12;
  --bg-sidebar: #0b111c;
  --bg-card: #0f172a;
  --bg-card-elevated: #1e293b;
  --bg-input: #0b111c;
  --bg-input-focus: #1e293b;
  --bg-secondary: #0f172a;
  --bg-dark: #070b12;
  
  --border-color: #1e293b;
  --border-subtle: #172033;
  --border-focus: #00f2fe;
  
  --text-primary: #f8fafc;
  --text-secondary: #94a3b8;
  --text-muted: #64748b;
  
  --cyan-accent: #00f2fe;
  --cyan-hover: #38bdf8;
  --emerald-profit: #00e676;
  --crimson-risk: #ef4444;
  --amber-warn: #f59e0b;
  --amber-border: #d97706;
  --purple-regime: #a855f7;
  
  --font-main: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  --font-mono: "JetBrains Mono", "SF Mono", Menlo, Consolas, monospace;
}"""

css = css.replace(root_target, root_restore)
css = css.replace("#2a2e39", "#1e293b").replace("#363a45", "#334155")

with open("web_dashboard/styles.css", "w") as f:
    f.write(css)
