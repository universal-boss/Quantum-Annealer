with open("web_dashboard/styles.css", "r") as f:
    css = f.read()

root_target = """:root {
  --bg-app: #131722;             /* Exact TradingView Dark #131722 (19,23,34) */
  --bg-sidebar: #131722;         /* Seamless Sidebar #131722 */
  --bg-card: #1e222d;            /* TradingView Card Surface #1e222d */
  --bg-card-elevated: #2a2e39;   /* TradingView Hover Surface #2a2e39 */
  --bg-input: #131722;           /* Deep Input #131722 */
  --bg-input-focus: #2a2e39;     /* Input Active Focus */
  --bg-secondary: #131722;
  --bg-dark: #131722;
  
  --border-color: #2a2e39;       /* TradingView Panel Border #2a2e39 */
  --border-subtle: #262933;      /* Subtle Divider */
  --border-focus: #00f2fe;       /* Electric Neon Cyan Focus */
  
  --text-primary: #f8fafc;       /* Crisp High-Contrast White */
  --text-secondary: #94a3b8;     /* Clean Slate Grey */
  --text-muted: #64748b;         /* Muted Slate Grey */
  
  --cyan-accent: #00f2fe;        /* Electric Neon Cyan */
  --cyan-hover: #38bdf8;        
  --emerald-profit: #00e676;     /* Electric Emerald Green */
  --crimson-risk: #ef4444;       /* Electric Crimson Red */
  --amber-warn: #f59e0b;        
  --amber-border: #d97706;      
  --purple-regime: #a855f7;      
  
  --font-main: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  --font-mono: "JetBrains Mono", "SF Mono", Menlo, Consolas, monospace;
}"""

root_pure_black = """:root {
  --bg-app: #000000;             /* Pure 100% True OLED Black */
  --bg-sidebar: #000000;         /* Pure 100% True OLED Black Sidebar */
  --bg-card: #000000;            /* Pure 100% True OLED Black Card */
  --bg-card-elevated: #0a0a0a;   /* Subtle OLED Elevated Surface */
  --bg-input: #000000;           /* Pure Black Input */
  --bg-input-focus: #141414;     /* Input Focus Surface */
  --bg-secondary: #000000;
  --bg-dark: #000000;
  
  --border-color: #1f1f1f;       /* Crisp Pure Black Border */
  --border-subtle: #141414;      /* Subtle Black Divider */
  --border-focus: #00f2fe;       /* Electric Neon Cyan Focus */
  
  --text-primary: #ffffff;       /* Pure High-Contrast White */
  --text-secondary: #a1a1aa;     /* Clean Neutral Grey */
  --text-muted: #52525b;         /* Muted Zinc Grey */
  
  --cyan-accent: #00f2fe;        /* Electric Neon Cyan */
  --cyan-hover: #38bdf8;        
  --emerald-profit: #00e676;     /* Electric Emerald Green */
  --crimson-risk: #ef4444;       /* Electric Crimson Red */
  --amber-warn: #f59e0b;        
  --amber-border: #d97706;      
  --purple-regime: #a855f7;      
  
  --font-main: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  --font-mono: "JetBrains Mono", "SF Mono", Menlo, Consolas, monospace;
}"""

css = css.replace(root_target, root_pure_black)
css = css.replace("#2a2e39", "#1f1f1f").replace("#262933", "#141414")

with open("web_dashboard/styles.css", "w") as f:
    f.write(css)
