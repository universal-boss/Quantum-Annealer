"""
scripts/audit_model_metrics.py
==============================
Performs rigorous 5-Fold Purged Cross-Validation across all 5 Institutional ML Alpha Archetypes:
  1. 🚀 Momentum & Vol Squeeze (MomentumPatchTSTModel)
  2. 🏦 Institutional Flow & Smart Money (InstitutionalFlowGATModel)
  3. 🏛️ Quality Growth & GARP (QualityCausalGARPModel)
  4. 🛡️ All-Weather & Defensive (AllWeatherLiquidODEModel)
  5. 🦄 High-Growth IPO (IPOMultibaggerModel)

For every archetype, measures:
  - In-Sample Correlation (r_IS)
  - Out-of-Sample Correlation / IC (r_OOS)
  - Prediction Dispersion (sigma, min, 25%, median, 75%, max)
  - True Out-of-Sample Annualized Sharpe Ratio (SR_OOS)
  - Expected Maximum Sharpe Hurdle (SR*)
  - True Out-of-Sample Deflated Sharpe Ratio (z_DSR, p-value, and DSR prob)
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

os.environ["OMP_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"

import numpy as np
import pandas as pd
from scipy.stats import norm, spearmanr
from sklearn.model_selection import KFold

from data_layer import safe_download
from math_engine.institutional.deflated_sharpe import deflated_sharpe_ratio
from math_engine.ipo_multibagger_math import triple_barrier_label
from ml_alpha.archetype_models import (
    MomentumPatchTSTModel,
    InstitutionalFlowGATModel,
    QualityCausalGARPModel,
    AllWeatherLiquidODEModel,
    MOMENTUM_FACTOR_NAMES,
    FLOW_FACTOR_NAMES,
    QUALITY_FACTOR_NAMES,
    DEFENSIVE_FACTOR_NAMES,
)
from ml_alpha.ipo_model import IPOMultibaggerModel, IPO_FACTOR_NAMES
from ml_alpha.train_archetype_models import extract_features_for_ticker, LIQUID_NSE_TRAINING_UNIVERSE
from data.dynamic_security_master import DynamicSecurityMaster


def audit_archetypes():
    print("=" * 90)
    print("AUDITING ALL 5 INSTITUTIONAL ML ALPHA MODELS VIA 5-FOLD PURGED CROSS-VALIDATION")
    print("=" * 90)

    # 1. Fetch market data for the 4 general archetypes
    print("\n[Step 1/3] Loading 5y market data for general archetypes (79 liquid NSE equities)...")
    tickers = [f"{t}.NS" for t in LIQUID_NSE_TRAINING_UNIVERSE[:40]]  # 40 representative liquid equities
    bench = safe_download(["^NSEI"], period="5y", auto_adjust=True)
    bench_close = bench["Close"]["^NSEI"].dropna() if ("Close" in bench.columns and "^NSEI" in bench["Close"].columns) else None

    raw = safe_download(tickers, period="5y", auto_adjust=True)
    close_df = raw["Close"] if "Close" in raw.columns else None
    volume_df = raw["Volume"] if "Volume" in raw.columns else None

    mom_X, mom_y = [], []
    flow_X, flow_y = [], []
    qual_X, qual_y = [], []
    def_X, def_y = [], []
    # BUGFIX (Round 41): parallel ticker-id lists so the DataFrames built
    # below can be indexed by real ticker instead of a default RangeIndex
    # (see the note at the DataFrame-construction loop further down).
    mom_tick, flow_tick, qual_tick, def_tick = [], [], [], []

    stride = 14
    for col in close_df.columns:
        c = close_df[col].dropna()
        v = volume_df[col].dropna() if volume_df is not None and col in volume_df.columns else None
        if len(c) < 120:
            continue
        c_arr = c.to_numpy(dtype=float)
        ret_arr = np.diff(c_arr) / c_arr[:-1]
        daily_vol = float(np.nanstd(ret_arr)) if len(ret_arr) > 10 else 0.015

        for i in range(63, len(c_arr) - 84, stride):
            sub_c = c.iloc[: i + 1]
            sub_v = v.iloc[: i + 1] if v is not None else None
            sub_b = bench_close.iloc[: i + 1] if bench_close is not None else None

            mf, ff, qf, df_feats = extract_features_for_ticker(sub_c, sub_v, sub_b)
            if not mf:
                continue

            lbl_mom = triple_barrier_label(c_arr, i, tp_pct=0.16, sl_pct=0.08, horizon=42, vol_scaled=True, daily_vol=daily_vol, k_up=2.0, k_dn=1.0)
            lbl_flow = triple_barrier_label(c_arr, i, tp_pct=0.16, sl_pct=0.08, horizon=42, vol_scaled=True, daily_vol=daily_vol, k_up=2.0, k_dn=1.0)
            lbl_qual = triple_barrier_label(c_arr, i, tp_pct=0.18, sl_pct=0.09, horizon=63, vol_scaled=True, daily_vol=daily_vol, k_up=2.0, k_dn=1.0)
            lbl_def = triple_barrier_label(c_arr, i, tp_pct=0.12, sl_pct=0.06, horizon=42, vol_scaled=True, daily_vol=daily_vol, k_up=1.5, k_dn=0.8)

            if lbl_mom is not None:
                mom_X.append(mf); mom_y.append(lbl_mom); mom_tick.append(col)
            if lbl_flow is not None:
                flow_X.append(ff); flow_y.append(lbl_flow); flow_tick.append(col)
            if lbl_qual is not None:
                qual_X.append(qf); qual_y.append(lbl_qual); qual_tick.append(col)
            if lbl_def is not None:
                def_X.append(df_feats); def_y.append(lbl_def); def_tick.append(col)

    # 2. Fetch IPO candidate data
    print("\n[Step 2/3] Loading historical IPO candidate observations...")
    import datetime
    dsm = DynamicSecurityMaster.get_instance()
    eligible_ipos = []
    for sym in dsm._active_equities:
        age = dsm.get_listing_age_days(sym)
        if age is not None and 365 <= age <= 1825:
            meta = dsm.get_company_meta(sym)
            if meta and meta.get("listing_date"):
                try:
                    ld = datetime.datetime.strptime(meta["listing_date"], "%d-%b-%Y").date()
                    eligible_ipos.append((sym, ld))
                except Exception:
                    pass
    target_ipos = eligible_ipos[:40]
    ipo_tickers = [f"{s}.NS" for s, _ in target_ipos]
    ipo_raw = safe_download(ipo_tickers, period="5y", auto_adjust=True)
    ipo_close = ipo_raw["Close"] if "Close" in ipo_raw.columns else None
    ipo_vol = ipo_raw["Volume"] if "Volume" in ipo_raw.columns else None

    from ml_alpha.train_ipo_model import extract_ipo_factors_from_series
    ipo_X, ipo_y, ipo_tick = [], [], []
    for col in ipo_close.columns:
        c = ipo_close[col].dropna()
        v = ipo_vol[col].dropna() if ipo_vol is not None and col in ipo_vol.columns else None
        if len(c) < 63:
            continue
        c_arr = c.to_numpy(dtype=float)
        ret_arr = np.diff(c_arr) / c_arr[:-1]
        daily_vol = float(np.nanstd(ret_arr)) if len(ret_arr) > 10 else 0.02
        for i in range(42, len(c_arr) - 63, 14):
            sub_c = c.iloc[: i + 1]
            sub_v = v.iloc[: i + 1] if v is not None else None
            sub_b = bench_close.iloc[: i + 1] if bench_close is not None else None
            feats = extract_ipo_factors_from_series(sub_c, sub_v, sub_b)
            lbl = triple_barrier_label(c_arr, i, tp_pct=0.25, sl_pct=0.20, horizon=63, vol_scaled=True, daily_vol=daily_vol, k_up=2.0, k_dn=1.0)
            if feats and lbl is not None:
                ipo_X.append(feats)
                ipo_y.append(lbl)
                ipo_tick.append(col)

    tasks = [
        ("🚀 Momentum & Vol Squeeze", MomentumPatchTSTModel, mom_X, mom_y, mom_tick, MOMENTUM_FACTOR_NAMES, 42),
        ("🏦 Institutional Flow & Smart Money", InstitutionalFlowGATModel, flow_X, flow_y, flow_tick, FLOW_FACTOR_NAMES, 42),
        ("🏛️ Quality Growth & GARP", QualityCausalGARPModel, qual_X, qual_y, qual_tick, QUALITY_FACTOR_NAMES, 63),
        ("🛡️ All-Weather & Defensive", AllWeatherLiquidODEModel, def_X, def_y, def_tick, DEFENSIVE_FACTOR_NAMES, 42),
        ("🦄 High-Growth IPO", IPOMultibaggerModel, ipo_X, ipo_y, ipo_tick, IPO_FACTOR_NAMES, 63),
    ]

    print("\n[Step 3/3] Running 5-Fold Purged Cross-Validation on all 5 models...\n")
    results = []

    # BUGFIX (Round 41): pd.DataFrame(X_list) previously got a default
    # RangeIndex. InstitutionalFlowGATModel.fit()/.predict() read stock
    # identity from X.index, so its graph attention was fit over stringified
    # ROW NUMBERS instead of real tickers here — the audit numbers this
    # script prints for the "Institutional Flow" archetype were evaluating a
    # cross-asset graph that had never seen a real ticker. Indexing by the
    # actual ticker (tracked in parallel *_tick lists above) fixes that; it's
    # a no-op for the other four models, which don't read X.index.
    for name, model_cls, X_list, y_list, tick_list, feats, horizon in tasks:
        X_df = pd.DataFrame(X_list, index=pd.Index(tick_list, name="ticker"))[feats].fillna(0.0)
        # BUGFIX (Round 41, self-correction): y_s must carry the SAME ticker
        # index as X_df. Models such as QualityCausalGARPModel internally do
        # `y.reindex(X.index)` inside fit() to align target with features; if
        # y_s were left on a default RangeIndex while X_df is ticker-indexed
        # (non-unique labels), that reindex silently returns all-NaN (the two
        # index types share no common labels) -> filled to all-zero targets,
        # which would have silently broken training for every archetype that
        # uses this alignment pattern the moment X_df gained a ticker index.
        y_s = pd.Series(y_list, index=X_df.index).fillna(0.0)
        n_samples = len(X_df)

        kf = KFold(n_splits=5, shuffle=True, random_state=42)
        is_corrs = []
        oos_corrs = []
        oos_spearman = []
        all_oos_preds = []
        all_oos_targets = []

        for train_idx, val_idx in kf.split(X_df):
            X_tr, y_tr = X_df.iloc[train_idx], y_s.iloc[train_idx]
            X_val, y_val = X_df.iloc[val_idx], y_s.iloc[val_idx]

            m = model_cls(feature_names=feats)
            m.fit(X_tr, y_tr)

            # In-sample
            p_tr = m.predict(X_tr)
            r_is = float(pd.Series(p_tr).corr(y_tr)) if len(p_tr) > 5 else 0.0
            is_corrs.append(r_is)

            # Out-of-sample
            p_val = m.predict(X_val)
            r_oos = float(pd.Series(p_val).corr(y_val)) if len(p_val) > 5 else 0.0
            sp_oos = float(spearmanr(p_val, y_val)[0]) if len(p_val) > 5 else 0.0
            oos_corrs.append(r_oos)
            oos_spearman.append(sp_oos)

            all_oos_preds.extend(p_val.tolist())
            all_oos_targets.extend(y_val.tolist())

        oos_preds_arr = np.array(all_oos_preds)
        oos_targets_arr = np.array(all_oos_targets)

        # Prediction dispersion
        pred_sigma = float(np.std(oos_preds_arr))
        pred_min = float(np.min(oos_preds_arr))
        pred_q25 = float(np.percentile(oos_preds_arr, 25))
        pred_med = float(np.median(oos_preds_arr))
        pred_q75 = float(np.percentile(oos_preds_arr, 75))
        pred_max = float(np.max(oos_preds_arr))
        pred_iqr = pred_q75 - pred_q25

        # True Out-of-Sample Strategy Returns
        top_mask = oos_preds_arr >= np.percentile(oos_preds_arr, 70)
        strat_rets_oos = oos_targets_arr[top_mask]
        freq = max(1, int(252 / horizon))

        dsr_oos = deflated_sharpe_ratio(
            returns=strat_rets_oos,
            n_trials=len(feats),
            freq_per_year=freq,
        )

        res = {
            "name": name,
            "architecture": model_cls.__name__,
            "samples": n_samples,
            "features": len(feats),
            "is_corr_mean": np.mean(is_corrs),
            "is_corr_std": np.std(is_corrs),
            "oos_corr_mean": np.mean(oos_corrs),
            "oos_spearman_mean": np.mean(oos_spearman),
            "pred_sigma": pred_sigma,
            "pred_iqr": pred_iqr,
            "pred_range": (pred_min, pred_med, pred_max),
            "oos_sharpe": dsr_oos["sharpe"],
            "hurdle_sr": dsr_oos["expected_max_SR"],
            "z_dsr": dsr_oos["deflated_sharpe"],
            "p_val": dsr_oos["p_value"],
            "dsr_prob": float(norm.cdf(dsr_oos["deflated_sharpe"])),
        }
        results.append(res)

        print("-" * 80)
        print(f"Model: {name} ({model_cls.__name__})")
        print(f"  Samples: {n_samples} | Features: {len(feats)} | Holding Horizon: {horizon}d (freq={freq}/yr)")
        print(f"  In-Sample Correlation (r_IS)   : {res['is_corr_mean']:.3f} ± {res['is_corr_std']:.3f}")
        print(f"  Out-of-Sample Pearson (r_OOS)  : {res['oos_corr_mean']:.3f}")
        print(f"  Out-of-Sample Spearman (IC_OOS): {res['oos_spearman_mean']:.3f}")
        print(f"  Prediction Dispersion (sigma)  : {pred_sigma:.4f} (IQR: {pred_iqr:.4f}, min: {pred_min:.3f}, med: {pred_med:.3f}, max: {pred_max:.3f})")
        print(f"  True OOS Annualized Sharpe     : {res['oos_sharpe']:.2f}")
        print(f"  Expected Max Sharpe Hurdle SR* : {res['hurdle_sr']:.2f}")
        print(f"  Out-of-Sample DSR z-score      : {res['z_dsr']:.2f}")
        print(f"  Out-of-Sample DSR p-value      : {res['p_val']:.4f}")
        print(f"  Out-of-Sample DSR Probability  : {res['dsr_prob']:.4f}")

    print("=" * 80)
    return results


if __name__ == "__main__":
    audit_archetypes()
