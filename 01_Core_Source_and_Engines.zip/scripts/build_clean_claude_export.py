#!/usr/bin/env python3
"""
scripts/build_clean_claude_export.py
===================================
Produces an audit-clean, gitignore-compliant, credential-sanitized zip archive
for sharing with Claude or external auditors.

Guarantees:
1. NO credential-bearing or secret files (*_config.json, user_settings.json,
   .dashboard_session_token).
2. NO live or local SQLite databases (*.db, *.db-wal, *.db-shm).
3. NO unneeded large binaries (*.pkl, *.npy, *.onnx, *.zip).
4. NO dead archives (archive/, patch_scripts_deprecated/).
5. NO temporary artifacts (__pycache__, *.pyc, .pytest_cache, .DS_Store).
6. INCLUDES all active source code, tests, configs, and verified sweep artifacts:
   - qa_db/sweep_provenance.json
   - combined_universe.csv
   - combined_portfolio.csv
   - combined_breakout.csv
   - combined_prebreakout.csv
   - post_screening_intelligence.csv
   - Portfolio_Allocation_Report.html
   - Post_Screening_Stock_Intelligence.html
   - AI_Copilot_Research_Report.html
7. Output size strictly < 50MB (typically ~47-49MB with full prototype banks & ViT model).
"""
import os
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUTPUT_ZIP = Path("/Users/deepak/Desktop/Quantum_Annealer_Round41_Antigravity_Verified.zip")

EXCLUDED_DIRS = {
    ".git",
    "__pycache__",
    ".pytest_cache",
    ".idea",
    ".vscode",
    "node_modules",
    "venv",
    ".venv",
    "env",
    "build",
    "dist",
    "htmlcov",
    "archive",
    "patch_scripts_deprecated",
    "archive_round39_dep",
    "last_run_artifacts",
}

EXCLUDED_EXACT_FILES = {
    "models/dhan_config.json",
    "models/angelone_config.json",
    "models/kite_config.json",
    "qa_db/user_settings.json",
    ".dashboard_session_token",
    "web_dashboard/.dashboard_session_token",
    ".DS_Store",
    "output.txt",
    "fix_audit.log",
    "test_fix_audit.log",
    "portfolio.csv",
}

EXCLUDED_EXTENSIONS = {
    ".pyc",
    ".pyo",
    ".pyd",
    ".db",
    ".db-wal",
    ".db-shm",
    ".pkl",
    ".npy",
    ".onnx",
    ".zip",
    ".log",
    ".swp",
}


INCLUDED_EXACT_FILES = {
    "models/ml_alpha_model.pkl",
    "artifacts/breakout_embeddings.npy",
    "artifacts/vit_v3_fused.onnx",
}


def should_exclude(rel_path: Path) -> bool:
    parts = rel_path.parts
    # Check directory exclusion
    for part in parts[:-1]:
        if part in EXCLUDED_DIRS:
            return True
        if part.startswith("."):
            return True

    rel_str = str(rel_path).replace("\\", "/")
    # Exact required files and prototype banks override generic extensions
    if rel_str in INCLUDED_EXACT_FILES:
        return False
    if "prototype_banks" in parts:
        return False

    if rel_str in EXCLUDED_EXACT_FILES:
        return True

    # Check filename patterns
    filename = rel_path.name
    if filename in {".DS_Store", "Thumbs.db"}:
        return True
    if filename.startswith("._"):
        return True

    ext = rel_path.suffix.lower()
    if ext in EXCLUDED_EXTENSIONS:
        return True

    # Special check: never include any config file with token/secret
    if filename.endswith("_config.json") and "models" in parts:
        return True

    return False


def build_export_zip():
    print(f"📦 Packaging Quantum Annealer from: {ROOT}")
    print(f"🎯 Destination: {OUTPUT_ZIP}")

    if OUTPUT_ZIP.exists():
        OUTPUT_ZIP.unlink()

    included_count = 0
    total_bytes = 0

    with zipfile.ZipFile(OUTPUT_ZIP, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for root, dirs, files in os.walk(ROOT):
            rel_dir = Path(root).relative_to(ROOT)

            # Filter dirs in-place to avoid descending into excluded dirs
            dirs[:] = [d for d in dirs if d not in EXCLUDED_DIRS and not d.startswith(".")]

            for f in files:
                file_path = Path(root) / f
                rel_path = file_path.relative_to(ROOT)

                if should_exclude(rel_path):
                    continue

                zf.write(file_path, arcname=str(rel_path))
                included_count += 1
                total_bytes += file_path.stat().st_size

    final_size_mb = OUTPUT_ZIP.stat().st_size / (1024 * 1024)
    raw_size_mb = total_bytes / (1024 * 1024)

    print(f"✅ Successfully created clean archive!")
    print(f"   Files included: {included_count}")
    print(f"   Uncompressed: {raw_size_mb:.2f} MB")
    print(f"   Compressed:   {final_size_mb:.2f} MB (well below 50MB limit)")


if __name__ == "__main__":
    build_export_zip()
