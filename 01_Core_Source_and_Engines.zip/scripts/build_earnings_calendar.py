#!/usr/bin/env python
"""scripts/build_earnings_calendar.py — historical earnings-calendar builder.

AUDIT-FIX (Round 29 — R29-1): the SWEEP residual "per-cutoff ML predictions /
historical blackout calendar" is INPUT-GATED: the R27-1 replay machinery
exists and replays blackouts on a CALLER-SUPPLIED historical calendar, but no
such calendar existed (the live NSE / yfinance feeds are NOW-ONLY — they
answer "what is the next earnings date", never the historical record). This
builder closes the data half of that gate: it pulls each ticker's HISTORICAL
quarterly earnings dates from Yahoo (.NS `earnings_dates` — a dated historical
record, not a now-only projection), converts the vendor's America/New_York
timestamps to IST calendar dates, and writes the artifact the sweep
AUTO-LOADS:

  * --out (default qa_db/earnings_calendar_history.json):
      {"meta": {...coverage, convention, failures...},
       "calendar": {"RELIANCE.NS": ["2020-10-30", ...], ...},
       "failures": {"TICKER.NS": "error text", ...}}

Convention (disclosed in meta): event_date = the IST calendar date of the
vendor's announcement timestamp (no roll). The live filter's ±blackout_days
window absorbs the same-day/next-trading-day reaction ambiguity.

Never-invent discipline (the R27-3/R28-1 house rule): a ticker whose fetch
fails or returns nothing is recorded in `failures` / counted as empty — it
NEVER contributes a fabricated event.

Runtime discipline: resumable (--resume) and time-budgeted
(--max-runtime-sec) so the pull can be driven in bounded foreground passes
(the R28 pattern — the session reaps background runs).

Usage:
  python scripts/build_earnings_calendar.py --universe-csv combined_universe.csv
  python scripts/build_earnings_calendar.py --tickers RELIANCE.NS,TCS.NS
  python scripts/build_earnings_calendar.py --resume --max-runtime-sec 90
  python scripts/build_earnings_calendar.py --selfcheck        # no network
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import pandas as pd  # noqa: E402  (offline-safe core dep)

DEFAULT_OUT = ROOT / "qa_db" / "earnings_calendar_history.json"
_PROGRESS = ROOT / "qa_db" / "earnings_calendar_progress.json"
DEFAULT_UNIVERSE_CSV = ROOT / "combined_universe.csv"
_IST = "Asia/Kolkata"
_SOURCE_LABEL = ("yfinance earnings_dates (Yahoo .NS historical quarterly "
                 "earnings dates; America/New_York timestamps converted to IST "
                 "calendar dates)")
_CONVENTION = ("event_date = IST calendar date of the vendor announcement "
               "timestamp (no roll); the +/- EARNINGS_BLACKOUT_DAYS window "
               "absorbs the same-day/next-trading-day reaction ambiguity")


# ----------------------------------------------------------------------------
# core helpers (pure, offline — locked by --selfcheck)
# ----------------------------------------------------------------------------
def to_ist_date(ts) -> str:
    """Vendor timestamp (tz-aware ET, naive UTC, or ISO string) -> IST date.

    Yahoo returns earnings timestamps localized to America/New_York; the IST
    calendar date is the honest event date for an Indian blackout calendar
    (06:00 EDT = 15:30 IST same day; 22:00 EST = 08:30 IST NEXT day).
    """
    t = pd.Timestamp(ts)
    if t.tzinfo is not None:
        t = t.tz_convert(_IST)
    else:
        t = t.tz_localize("UTC").tz_convert(_IST)
    return t.date().isoformat()


def normalize_events(raw_index) -> list:
    """Iterable of vendor timestamps -> sorted, deduped IST ISO date list."""
    out: set = set()
    for ts in list(raw_index):
        try:
            out.add(to_ist_date(ts))
        except Exception:
            continue
    return sorted(out)


def _load_tickers(args) -> list:
    tickers: list = []
    if getattr(args, "tickers", None):
        tickers = [t.strip() for t in str(args.tickers).split(",") if t.strip()]
    if getattr(args, "tickers_file", None):
        p = Path(args.tickers_file)
        if p.exists():
            for line in p.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line and not line.startswith("#"):
                    tickers.append(line)
    if getattr(args, "universe_csv", None) and not tickers:
        p = Path(args.universe_csv)
        if p.exists():
            df = pd.read_csv(p)
            col = "Ticker" if "Ticker" in df.columns else df.columns[0]
            tickers = [str(t).strip() for t in df[col].dropna().tolist()]
    out, seen = [], set()
    for t in tickers:
        t = t if "." in t else f"{t}.NS"
        if t not in seen:
            seen.add(t)
            out.append(t)
    return out


def fetch_earnings_dates(ticker: str, retries: int = 2, log=print) -> list:
    """Best-effort historical earnings dates for one ticker (never invented).

    Returns [] on empty or failure — the caller records the distinction
    (empty vs failure) for the honest-coverage meta. An empty first answer
    is RE-VERIFIED once after backoff before being believed (the vendor
    throttling signature is an empty frame, not an exception).
    """
    try:
        import yfinance as yf
    except Exception as e:  # pragma: no cover - env-dependent
        log(f"[CAL] {ticker}: yfinance unavailable: {e}")
        return []
    last_err = None
    for attempt in range(int(retries) + 1):
        try:
            ed = yf.Ticker(ticker).earnings_dates
            if ed is None or len(ed) == 0:
                # empty != verified-absent: re-verify once after backoff so a
                # throttled response cannot masquerade as "no earnings data"
                if attempt < int(retries):
                    time.sleep(1.5)
                    continue
                return []
            return normalize_events(ed.index)
        except Exception as e:
            last_err = e
            if attempt < int(retries):
                time.sleep(3.0 * (attempt + 1))
    log(f"[CAL] {ticker}: earnings_dates failed: {last_err}")
    raise RuntimeError(str(last_err))


# ----------------------------------------------------------------------------
# artifact I/O (atomic, resumable)
# ----------------------------------------------------------------------------
def _atomic_write_json(path: Path, obj: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=1, sort_keys=True)
    os.replace(tmp, path)


def build_meta(requested: list, calendar: dict, failures: dict,
               completed: bool, budget_exhausted: bool) -> dict:
    n_req = len(requested)
    with_events = len([t for t, v in calendar.items() if v])
    n_failed = len(failures)
    # empty = fetched OK but the vendor holds no earnings record for the name
    # (distinct from failed — the honest-coverage split is exhaustive:
    # with_events + failed + empty = n_requested).
    n_empty = max(0, n_req - with_events - n_failed)
    all_dates = [d for v in calendar.values() for d in v]
    return {
        "built_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "source": _SOURCE_LABEL,
        "event_date_convention": _CONVENTION,
        "completed": bool(completed),
        "time_budget_exhausted": bool(budget_exhausted),
        "n_requested": n_req,
        "n_with_events": with_events,
        "n_empty": n_empty,
        "n_failed": n_failed,
        "coverage_pct": round(100.0 * with_events / n_req, 2) if n_req else 0.0,
        "earliest_event": min(all_dates) if all_dates else None,
        "latest_event": max(all_dates) if all_dates else None,
        "failures_reported_never_invented": True,
    }


def write_artifact(out_path: Path, calendar: dict, failures: dict,
                   meta: dict) -> None:
    _atomic_write_json(out_path, {
        "meta": meta,
        "calendar": {t: list(v) for t, v in sorted(calendar.items())},
        "failures": {t: str(e) for t, e in sorted(failures.items())},
    })


def _final_artifact_complete(out_path: Path) -> bool:
    """True when the final artifact exists and its meta says completed —
    the idempotent re-invocation guard (a second call after COMPLETE must
    never re-fetch over a good artifact; --rebaseline is the explicit path)."""
    try:
        obj = json.loads(out_path.read_text(encoding="utf-8"))
        return bool((obj.get("meta") or {}).get("completed"))
    except Exception:
        return False


# ----------------------------------------------------------------------------
# driver
# ----------------------------------------------------------------------------
def run(args) -> int:
    log = print
    out_path = Path(args.out)
    if not getattr(args, "rebaseline", False) and _final_artifact_complete(out_path):
        log(f"[CAL] final artifact already COMPLETE at {out_path} — nothing to do "
            f"(pass --rebaseline to rebuild)")
        return 0
    requested = _load_tickers(args)
    if not requested:
        log("[CAL] no tickers resolved — pass --universe-csv / --tickers-file / --tickers")
        return 2

    calendar: dict = {}
    failures: dict = {}
    prior_events: dict = {}
    done: set = set()
    if args.resume and _PROGRESS.exists():
        try:
            st = json.loads(_PROGRESS.read_text(encoding="utf-8"))
            calendar = {t: list(v) for t, v in st.get("calendar", {}).items()}
            failures = {t: str(e) for t, e in st.get("failures", {}).items()}
            done = set(st.get("done", []))
            prior_events = {t: list(v) for t, v in calendar.items() if v}
            log(f"[CAL] resume: {len(done)} already resolved")
        except Exception:
            pass

    budget = float(args.max_runtime_sec or 0.0)
    t0 = time.time()
    exhausted = False
    checkpoint_every = max(1, int(args.checkpoint_every or 10))

    for i, t in enumerate(requested):
        if t in done:
            continue
        if budget > 0 and (time.time() - t0) > budget:
            exhausted = True
            break
        try:
            events = fetch_earnings_dates(t, retries=int(args.retries or 2), log=log)
            if not events and t in prior_events and prior_events[t]:
                # prior events exist and the re-fetch came back empty — treat
                # as a vendor refusal (never discard verified data on a blank)
                events = list(prior_events[t])
                failures[t] = "re-fetch empty (possible vendor throttle) — prior events kept"
            calendar[t] = events
        except RuntimeError as e:
            failures[t] = str(e)
            calendar[t] = list(prior_events.get(t, []))
        done.add(t)
        if args.sleep_sec and args.sleep_sec > 0:
            time.sleep(float(args.sleep_sec))
        if (len(done) % checkpoint_every) == 0:
            _atomic_write_json(_PROGRESS, {
                "done": sorted(done), "calendar": calendar, "failures": failures})
        if (i + 1) % 50 == 0:
            log(f"[CAL] progress: {len(done)}/{len(requested)} resolved "
                f"({len(failures)} failures)")

    completed = (not exhausted) and len(done) >= len(requested)
    meta = build_meta(requested, calendar, failures, completed, exhausted)
    if completed:
        # ATOMIC PROMOTION: only a completed run may write the final path; a
        # time-budgeted partial goes to the .partial.json sidecar so it can
        # never clobber a good artifact (idempotency discipline).
        write_artifact(out_path, calendar, failures, meta)
        for stale in (out_path.with_name(out_path.name + ".partial.json"), _PROGRESS):
            try:
                stale.unlink()
            except FileNotFoundError:
                pass
    else:
        write_artifact(out_path.with_name(out_path.name + ".partial.json"),
                       calendar, failures, meta)
    log(f"[CAL] STATUS: {'COMPLETE' if completed else 'TIME_BUDGET'} — "
        f"{meta['n_with_events']}/{meta['n_requested']} with events, "
        f"{meta['n_failed']} failed, coverage {meta['coverage_pct']}% "
        f"-> {out_path if completed else str(out_path) + '.partial.json'}")
    return 0


# ----------------------------------------------------------------------------
# selfcheck (offline, no network) — the pinned-builder contract
# ----------------------------------------------------------------------------
def selfcheck() -> int:
    checks: list = []

    def check(name, ok):
        checks.append((name, bool(ok)))

    # 1. ET -> IST same-day (06:00 EDT = 15:30 IST)
    check("ET->IST same-day",
          to_ist_date(pd.Timestamp("2026-01-16 08:00", tz="America/New_York"))
          == "2026-01-16")
    # 2. late ET -> IST NEXT day (22:00 EST = 08:30 IST +1d)
    check("ET->IST next-day",
          to_ist_date(pd.Timestamp("2026-01-16 22:00", tz="America/New_York"))
          == "2026-01-17")
    # 3. naive timestamp treated as UTC
    check("naive=UTC", to_ist_date(pd.Timestamp("2026-01-16 20:00"))
          == "2026-01-17")  # 20:00 UTC = 01:30 IST next day
    # 4. normalize: dedupe + sort + tz mix
    idx = pd.DatetimeIndex([
        pd.Timestamp("2026-03-01 09:00", tz="America/New_York"),
        pd.Timestamp("2025-12-01 09:00", tz="America/New_York"),
        pd.Timestamp("2026-03-01 09:00", tz="America/New_York"),
    ])
    ev = normalize_events(idx)
    check("dedupe+sort", ev == ["2025-12-01", "2026-03-01"])
    # 5. empty index -> no events (never invented)
    check("empty->none", normalize_events(pd.DatetimeIndex([])) == [])
    # 6. meta counting honors the never-invent split (exhaustive:
    #    with_events + failed + empty = requested)
    meta = build_meta(["A.NS", "B.NS"], {"A.NS": ["2026-01-01"]},
                      {"B.NS": "HTTPError"}, completed=True, budget_exhausted=False)
    check("meta counts (failed != empty)", meta["n_with_events"] == 1
          and meta["n_failed"] == 1 and meta["n_empty"] == 0
          and meta["coverage_pct"] == 50.0
          and meta["failures_reported_never_invented"] is True)
    meta2 = build_meta(["A.NS", "B.NS", "C.NS"], {"A.NS": ["2026-01-01"], "C.NS": []},
                       {"B.NS": "HTTPError"}, completed=True, budget_exhausted=False)
    check("meta counts (empty counted)", meta2["n_empty"] == 1
          and meta2["n_with_events"] + meta2["n_failed"] + meta2["n_empty"] == 3)
    # 7. artifact round-trip + atomic write
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / "cal.json"
        write_artifact(p, {"A.NS": ["2026-01-01"]}, {}, meta)
        obj = json.loads(p.read_text(encoding="utf-8"))
        check("artifact contract",
              set(obj.keys()) == {"meta", "calendar", "failures"}
              and obj["calendar"] == {"A.NS": ["2026-01-01"]}
              and obj["meta"]["source"].startswith("yfinance earnings_dates"))
    # 8. universe loader: bare symbol -> .NS, dedupe
    class _A:
        tickers = "RELIANCE,TCS.NS,RELIANCE"
        tickers_file = None
        universe_csv = None
    check("loader normalize+dedupe",
          _load_tickers(_A) == ["RELIANCE.NS", "TCS.NS"])

    n_pass = sum(1 for _, ok in checks if ok)
    for name, ok in checks:
        print(f"  [{'PASS' if ok else 'FAIL'}] {name}")
    print(f"selfcheck: {n_pass}/{len(checks)} PASS")
    return 0 if n_pass == len(checks) else 1


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--tickers", default=None)
    ap.add_argument("--tickers-file", default=None)
    ap.add_argument("--universe-csv", default=str(DEFAULT_UNIVERSE_CSV))
    ap.add_argument("--out", default=str(DEFAULT_OUT))
    ap.add_argument("--retries", type=int, default=2)
    ap.add_argument("--sleep-sec", type=float, default=0.35)
    ap.add_argument("--max-runtime-sec", type=float, default=0.0,
                    help="0 = unlimited; >0 = exit cleanly at the budget "
                         "(resumable via --resume)")
    ap.add_argument("--checkpoint-every", type=int, default=10)
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--rebaseline", action="store_true",
                    help="rebuild even when the final artifact is COMPLETE")
    ap.add_argument("--selfcheck", action="store_true")
    args = ap.parse_args()
    if args.selfcheck:
        return selfcheck()
    return run(args)


if __name__ == "__main__":
    raise SystemExit(main())
