#!/usr/bin/env python
"""scripts/build_tax_fmv_feed.py — Sec 112A(2) FMV-31-Jan-2018 feed builder.

AUDIT-FIX (Round 27 — R27-3): the grandfathering residual ("needs the
TAX_FMV_31JAN2018 feed") is closed operationally. The statute's valuation
input for pre-01-Feb-2018 acquisitions is the HIGHEST QUOTED PRICE on
31-Jan-2018; this script builds that record from Yahoo Finance .NS daily
history (best-effort — per-ticker failures are reported, never invented)
using the PURE resolver core/realized_gains_ledger.resolve_fmv_31jan2018:

  * exact-date High when 31-Jan-2018 has a row;
  * else the nearest trading day ON OR BEFORE it within --max-lookback days
    (weekends / exchange holidays);
  * nothing within the window -> ticker goes to the `missing` list.

Outputs:
  * --out (default qa_db/tax_fmv_31jan2018.json): {TICKER: fmv} — the exact
    shape the /api/tax_optimizer endpoint AUTO-LOADS when the cfg does not
    carry TAX_FMV_31JAN2018 (R27-3 auto-load path).
  * a sibling .meta.json with per-ticker as_of_date / source / missing list.

Usage:
  python scripts/build_tax_fmv_feed.py --tickers RELIANCE.NS,TCS.NS
  python scripts/build_tax_fmv_feed.py --tickers-file universe.txt
  python scripts/build_tax_fmv_feed.py --selfcheck      # no network

Network notes: NSE's site is 403-blocked from this environment (documented
since R23); Yahoo .NS is the working source (verified live in R25). A failed
download is recorded and skipped — the feed never contains a fabricated mark.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from core.realized_gains_ledger import resolve_fmv_31jan2018, FMV_VALUATION_DATE  # noqa: E402

DEFAULT_OUT = ROOT / "qa_db" / "tax_fmv_31jan2018.json"
_DOWNLOAD_START = "2018-01-10"
_DOWNLOAD_END = "2018-02-06"


def _load_tickers(args) -> list:
    tickers: list = []
    if args.tickers:
        tickers = [t.strip() for t in str(args.tickers).split(",") if t.strip()]
    if args.tickers_file:
        p = Path(args.tickers_file)
        if p.exists():
            for line in p.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line and not line.startswith("#"):
                    tickers.append(line)
    # normalize: bare symbols -> .NS
    out = []
    for t in tickers:
        out.append(t if "." in t else f"{t}.NS")
    return out


def _download_highs(ticker: str, log) -> dict:
    """Best-effort Yahoo .NS daily High around 31-Jan-2018 -> {date: high}."""
    try:
        import yfinance as yf
    except Exception as e:  # pragma: no cover - env-dependent
        log(f"[FMV] yfinance unavailable: {e}")
        return {}
    try:
        df = yf.download(ticker, start=_DOWNLOAD_START, end=_DOWNLOAD_END,
                         interval="1d", progress=False, auto_adjust=False)
    except Exception as e:
        log(f"[FMV] {ticker}: download failed: {e}")
        return {}
    if df is None or df.empty:
        return {}
    try:
        high_col = df["High"]
        if hasattr(high_col, "columns"):  # yfinance returns a frame on newer versions
            high_col = high_col.iloc[:, 0]
        highs = {}
        for ts, v in high_col.dropna().items():
            try:
                d = str(getattr(ts, "date", lambda: ts)())[:10]
            except Exception:
                d = str(ts)[:10]
            try:
                fv = float(v)
            except (TypeError, ValueError):
                continue
            if fv > 0:
                highs[d] = fv
        return highs
    except Exception as e:
        log(f"[FMV] {ticker}: High column parse failed: {e}")
        return {}


def build_feed(tickers, max_lookback_days: int = 7, log=print) -> dict:
    """Build {ticker: fmv} + meta. Pure orchestration over the resolver."""
    feed: dict = {}
    meta: dict = {"valuation_date": FMV_VALUATION_DATE,
                  "max_lookback_days": int(max_lookback_days),
                  "source": "Yahoo Finance .NS daily High",
                  "resolved": {}, "missing": [], "note": None}
    for t in tickers:
        highs = _download_highs(t, log)
        if not highs:
            meta["missing"].append(t)
            continue
        fmv, as_of = resolve_fmv_31jan2018(highs, max_lookback_days=max_lookback_days)
        if fmv is None:
            meta["missing"].append(t)
        else:
            feed[t] = round(float(fmv), 2)
            meta["resolved"][t] = {"fmv": feed[t], "as_of_date": as_of}
    if meta["missing"]:
        meta["note"] = ("tickers in `missing` had no usable 31-Jan-2018 row within the "
                        "lookback window — NO value was invented for them; grandfathering "
                        "falls back to actual cost (conservative, disclosed)")
    return {"feed": feed, "meta": meta}


def _selfcheck() -> int:
    """Offline resolver vectors (no network) — mirrors the regression locks."""
    cases = [
        ({"2018-01-31": 150.0}, (150.0, "2018-01-31"), "exact date"),
        ({"2018-01-30": 148.0, "2018-01-29": 145.0}, (148.0, "2018-01-30"), "nearest-before"),
        ({"2018-01-20": 140.0}, (None, None), "outside window"),
        ({}, (None, None), "empty"),
        ({"2018-01-31": -1.0}, (None, None), "non-positive skipped"),
    ]
    ok = True
    for highs, expected, label in cases:
        got = resolve_fmv_31jan2018(highs)
        status = "PASS" if got == expected else "FAIL"
        if got != expected:
            ok = False
        print(f"[selfcheck] {label}: {got} (expected {expected}) -> {status}")
    print("[selfcheck] " + ("ALL PASS" if ok else "FAILURES PRESENT"))
    return 0 if ok else 1


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--tickers", default=None, help="comma-separated tickers (bare names get .NS)")
    ap.add_argument("--tickers-file", default=None, help="file with one ticker per line")
    ap.add_argument("--out", default=str(DEFAULT_OUT), help="output feed path")
    ap.add_argument("--max-lookback", type=int, default=7,
                    help="calendar days to look back from 31-Jan-2018 for the nearest trading day")
    ap.add_argument("--selfcheck", action="store_true",
                    help="run the offline resolver vectors (no network) and exit")
    args = ap.parse_args()

    if args.selfcheck:
        return _selfcheck()

    tickers = _load_tickers(args)
    if not tickers:
        # default: the workspace's combined universe if present
        uni = ROOT / "combined_universe.csv"
        if uni.exists():
            try:
                import csv
                with uni.open(encoding="utf-8") as f:
                    rows = list(csv.DictReader(f))
                tickers = []
                for r in rows:
                    for key in ("ticker", "symbol", "Ticker", "Symbol"):
                        if key in r and r[key]:
                            t = str(r[key]).strip()
                            if t:
                                tickers.append(t if "." in t else f"{t}.NS")
                            break
            except Exception:
                tickers = []
        if not tickers:
            print("No tickers supplied (use --tickers / --tickers-file) and no "
                  "combined_universe.csv found. Nothing to do.")
            return 1

    print(f"[FMV] building Sec 112A(2) FMV feed for {len(tickers)} ticker(s) "
          f"(valuation date {FMV_VALUATION_DATE}, max lookback {args.max_lookback}d)")
    result = build_feed(tickers, max_lookback_days=args.max_lookback)
    feed, meta = result["feed"], result["meta"]
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    # atomic write (mirror the ledger discipline: mkstemp + rename)
    import tempfile, os
    fd, tmp = tempfile.mkstemp(dir=str(out_path.parent), suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(feed, f, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, out_path)
    except Exception:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise
    meta_path = out_path.with_suffix(".meta.json")
    meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")
    print(f"[FMV] wrote {len(feed)} resolved value(s) -> {out_path}")
    print(f"[FMV] meta -> {meta_path}")
    if meta["missing"]:
        print(f"[FMV] WARNING: {len(meta['missing'])} ticker(s) unresolved (no value "
              f"invented): {', '.join(meta['missing'][:20])}"
              + (" ..." if len(meta["missing"]) > 20 else ""))
    print("[FMV] the /api/tax_optimizer endpoint auto-loads this file when the cfg "
          "does not carry TAX_FMV_31JAN2018 (payload key: fmv_feed_source).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
