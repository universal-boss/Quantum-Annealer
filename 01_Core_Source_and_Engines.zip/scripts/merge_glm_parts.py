#!/usr/bin/env python3
"""
scripts/merge_glm_parts.py
==========================
Merges and verifies multi-part GLM export archives.

When working with GLM or external systems with strict 50 MB upload limits,
the Quantum Annealer repository is provided in two parts:
  - Part 1: Quantum_Annealer_GLM_Part1.zip (~35 MB) -> Full codebase, dashboard, tests, CSVs, reports, and core factors.
  - Part 2: Quantum_Annealer_GLM_Part2.zip (~35 MB) -> Extended factor store panels.

Usage:
  # If Part 2 is in current dir or Desktop:
  python3 scripts/merge_glm_parts.py

  # Or specify explicit path to Part 2:
  python3 scripts/merge_glm_parts.py /path/to/Quantum_Annealer_GLM_Part2.zip
"""
import sys
import os
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def find_part2_zip(user_arg: str | None = None) -> Path | None:
    if user_arg:
        p = Path(user_arg).resolve()
        if p.exists() and p.is_file():
            return p

    candidates = [
        ROOT / "Quantum_Annealer_GLM_Part2.zip",
        Path.home() / "Desktop" / "Quantum_Annealer_GLM_Part2.zip",
        Path.home() / "Downloads" / "Quantum_Annealer_GLM_Part2.zip",
        Path("/Users/deepak/Desktop/Quantum_Annealer_GLM_Part2.zip"),
    ]
    for c in candidates:
        if c.exists() and c.is_file():
            return c
    return None


def merge_part2(part2_path: Path):
    print(f"📦 Extracting Part 2 from: {part2_path}")
    extracted = 0
    with zipfile.ZipFile(part2_path, "r") as zf:
        for info in zf.infolist():
            zf.extract(info, ROOT)
            extracted += 1
    print(f"✅ Successfully extracted {extracted} files into {ROOT}")


def verify_feature_cache():
    cache_dir = ROOT / "models" / "feature_cache"
    if not cache_dir.exists():
        print(f"⚠️  models/feature_cache does not exist yet at {cache_dir}")
        return False

    parquets = list(cache_dir.glob("*.parquet"))
    metas = list(cache_dir.glob("*.meta.json"))
    print(f"🔍 Feature Cache Status:")
    print(f"   - Parquet panels: {len(parquets)}")
    print(f"   - Metadata sidecars: {len(metas)}")

    missing_metas = [p.name for p in parquets if not p.with_suffix(".meta.json").exists()]
    if missing_metas:
        print(f"   ⚠️  Warning: {len(missing_metas)} parquets missing metadata sidecars: {missing_metas[:5]}")
        return False
    else:
        print(f"   ✅ 100% of parquets have valid provenance metadata sidecars.")

    regens = [p for p in metas if '"regenerated": true' in p.read_text(encoding="utf-8")]
    print(f"   ✅ R34-12b regenerated disclosure panels present: {len(regens)}")
    return True


def main():
    print("=" * 65)
    print("  Quantum Annealer — GLM Build Part Merger & Validator")
    print("=" * 65)

    arg = sys.argv[1] if len(sys.argv) > 1 else None
    part2 = find_part2_zip(arg)

    if part2:
        merge_part2(part2)
    else:
        print("ℹ️  Part 2 zip file not specified or found automatically.")
        print("   If you have already extracted Part 2 manually, checking repository integrity now...")

    valid = verify_feature_cache()
    if valid:
        print("\n🎉 Repository is fully assembled, intact, and ready for execution!")
    else:
        print("\n⚠️  Some feature panels may still be missing. Provide Part 2 to complete.")


if __name__ == "__main__":
    main()
