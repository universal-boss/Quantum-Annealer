"""
scripts/nightly_regime_refresher.py
===================================
Automated maintenance job to keep models/regime_hmm_latest.json fresh.
Can be executed via launchd, cron, or manual trigger.
"""
import sys
import logging
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)
logger = logging.getLogger("RegimeRefresher")

from math_engine.regime_detector import MarketRegimeDetector

def main():
    model_path = ROOT / "models" / "regime_hmm_latest.json"
    logger.info("Checking HMM regime model freshness at %s...", model_path)
    refreshed, age_h = MarketRegimeDetector.ensure_fresh_model(
        model_path,
        max_age_hours=24.0, # Keep model within 24h freshness window
        log_fn=logger.info
    )
    if refreshed:
        logger.info("✅ HMM regime model successfully updated on disk.")
    else:
        logger.info("✓ Model is already fresh (age: %.1f hours). No action required.", age_h)

if __name__ == "__main__":
    main()
