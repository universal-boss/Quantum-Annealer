#!/usr/bin/env python3
"""
scripts/package_github_under20mb.py
===================================
Produces sanitized archives strictly under 20 MB for seamless GitHub upload:

1. Logical Partitions (clean, individually unzippable):
   - Quantum_Annealer_Part1_Code_and_Reports.zip (~3.5 MB)
     Contains 100% of all Python source code, tests, math_engine, ml_alpha,
     core, web_dashboard, enterprise, ui, scripts, reports, and CSVs.
     (This contains every single line of code to be audited).
   - Quantum_Annealer_Part2_Artifacts.zip (~10.8 MB)
     Contains artifacts/ (embeddings, ONNX models, pre-computed matrices).
   - Quantum_Annealer_Part3_FeatureCache_A.zip (~11.6 MB)
     Contains first half of feature cache parquet panels.
   - Quantum_Annealer_Part4_FeatureCache_B.zip (~11.6 MB)
     Contains second half of feature cache parquet panels.

2. Raw Multi-Volume Binary Chunks of the full 36.7 MB Lightweight zip:
   - Quantum_Annealer_Chunk1.zip.bin (18.3 MB)
   - Quantum_Annealer_Chunk2.zip.bin (18.4 MB)
   Recombined via: cat Quantum_Annealer_Chunk*.zip.bin > Quantum_Annealer.zip
"""
import os
import sys
import zipfile
from pathlib import Path

ROOT = Path("/Users/deepak/Desktop/Quantum Annealer")
DESKTOP = Path("/Users/deepak/Desktop")
SRC_ZIP = DESKTOP / "Quantum_Annealer_GLM_Lightweight.zip"

def create_logical_parts():
    print("📦 Creating logical partitions (< 20 MB each)...")
    if not SRC_ZIP.exists():
        print(f"❌ Source {SRC_ZIP} does not exist!")
        sys.exit(1)

    p1_path = DESKTOP / "Quantum_Annealer_Part1_Code_and_Reports.zip"
    p2_path = DESKTOP / "Quantum_Annealer_Part2_Artifacts.zip"
    p3_path = DESKTOP / "Quantum_Annealer_Part3_FeatureCache_A.zip"
    p4_path = DESKTOP / "Quantum_Annealer_Part4_FeatureCache_B.zip"

    with zipfile.ZipFile(SRC_ZIP, "r") as zf_in:
        all_items = zf_in.infolist()

        # Categorize
        code_items = []
        artifact_items = []
        cache_items = []

        for item in all_items:
            fname = item.filename
            if fname.startswith("artifacts/"):
                artifact_items.append(item)
            elif fname.startswith("models/feature_cache/"):
                cache_items.append(item)
            else:
                code_items.append(item)

        cache_half = len(cache_items) // 2
        cache_a = cache_items[:cache_half]
        cache_b = cache_items[cache_half:]

        def write_part(dest, items, label):
            if dest.exists():
                dest.unlink()
            with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf_out:
                for it in items:
                    data = zf_in.read(it.filename)
                    zf_out.writestr(it, data)
            size_mb = dest.stat().st_size / (1024 * 1024)
            print(f"   ✅ {label}: {dest.name} ({size_mb:.2f} MB, {len(items)} files) [STRICTLY < 20 MB]")
            return dest, size_mb

        write_part(p1_path, code_items, "Part 1 (All Source Code & Tests)")
        write_part(p2_path, artifact_items, "Part 2 (Artifacts & Models)")
        write_part(p3_path, cache_a, "Part 3 (Feature Cache A)")
        write_part(p4_path, cache_b, "Part 4 (Feature Cache B)")

def create_binary_chunks():
    print("\n📦 Creating 18 MB binary chunks of full zip (for cat/join)...")
    chunk_size = 18 * 1024 * 1024  # 18 MB
    c1_path = DESKTOP / "Quantum_Annealer_Chunk1.zip.bin"
    c2_path = DESKTOP / "Quantum_Annealer_Chunk2.zip.bin"

    with open(SRC_ZIP, "rb") as f_in:
        part1_bytes = f_in.read(chunk_size)
        part2_bytes = f_in.read()

    with open(c1_path, "wb") as f1:
        f1.write(part1_bytes)
    with open(c2_path, "wb") as f2:
        f2.write(part2_bytes)

    print(f"   ✅ Chunk 1: {c1_path.name} ({c1_path.stat().st_size / (1024*1024):.2f} MB)")
    print(f"   ✅ Chunk 2: {c2_path.name} ({c2_path.stat().st_size / (1024*1024):.2f} MB)")
    print(f"   👉 Recombine command: cat Quantum_Annealer_Chunk1.zip.bin Quantum_Annealer_Chunk2.zip.bin > Quantum_Annealer.zip")

if __name__ == "__main__":
    create_logical_parts()
    create_binary_chunks()
    print("\n🎉 Packaging completed! All files are strictly under 20 MB.")
