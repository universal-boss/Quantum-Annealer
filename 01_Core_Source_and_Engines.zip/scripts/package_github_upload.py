#!/usr/bin/env python3
"""
Quantum Annealer — GitHub Multi-Part Upload Packager
Splits the entire project into clean, logical zip packages strictly < 20 MB each.
Designed for GitHub web uploads and GLM independent auditing.
"""

import os
import sys
import glob
import zipfile
import shutil
from pathlib import Path

ROOT = Path("/Users/deepak/Desktop/Quantum Annealer")
OUT_DIR = Path("/Users/deepak/Desktop/Quantum_Annealer_GitHub_Upload")

EXCLUDE_NAMES = {
    ".DS_Store", ".localized", "thumbs.db",
    ".dashboard_session_token", ".qa_session_token"
}
EXCLUDE_EXTS = {".zip", ".pyc", ".orig", ".rej", ".tmp"}
EXCLUDE_DIRS = {"__pycache__", "github_export", ".git", ".pytest_cache", ".venv", "scratch"}


def should_skip(rel_path: str) -> bool:
    parts = Path(rel_path).parts
    if any(p in EXCLUDE_DIRS for p in parts):
        return True
    fname = os.path.basename(rel_path)
    if fname in EXCLUDE_NAMES:
        return True
    if any(fname.endswith(ext) for ext in EXCLUDE_EXTS):
        return True
    return False


import json

def add_to_zip(zf: zipfile.ZipFile, rel_path: str, arcname: str = None):
    full_path = ROOT / rel_path
    if not full_path.exists():
        return
    if arcname is None:
        arcname = rel_path
    # Redact / mask any personal credentials or chat IDs from user_settings.json
    if "user_settings.json" in rel_path:
        sanitized_settings = json.dumps({
            "telegram_chat_id": "",
            "telegram_enabled": False,
            "angel_client_code": "",
            "gemini_model": ""
        }, indent=2)
        zf.writestr(arcname, sanitized_settings)
        return
    zf.write(full_path, arcname=arcname, compress_type=zipfile.ZIP_DEFLATED)


def package_all():
    print(f"Packaging Quantum Annealer from: {ROOT}")
    print(f"Target Output Directory: {OUT_DIR}")
    
    # Ensure clean output directory
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    # Clear existing zip/bin files in target
    for old_f in OUT_DIR.glob("*.zip*"):
        old_f.unlink()

    # 1. CORE SOURCE AND ENGINES
    print("\n[1/15] Packaging 01_Core_Source_and_Engines.zip...")
    core_zip = OUT_DIR / "01_Core_Source_and_Engines.zip"
    core_dirs = ["core", "math_engine", "data", "ml_alpha", "ui", "workers", "enterprise", "scripts", "catboost_info"]
    with zipfile.ZipFile(core_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        # Add root python files & configs
        for f in os.listdir(ROOT):
            fp = ROOT / f
            if fp.is_file() and not should_skip(f):
                if f.endswith((".py", ".txt", ".json", ".md", ".sh", ".yaml", ".yml", ".toml", ".ini", ".cfg", ".anchor")):
                    add_to_zip(zf, f)
        # Add core subdirectories
        for d in core_dirs:
            dp = ROOT / d
            if dp.exists():
                for root, _, files in os.walk(dp):
                    for f in files:
                        rel = os.path.relpath(os.path.join(root, f), ROOT)
                        if not should_skip(rel):
                            add_to_zip(zf, rel)
    print(f"  -> {core_zip.name}: {core_zip.stat().st_size / (1024*1024):.2f} MB")

    # 2. WEB DASHBOARD AND WORKSTATION
    print("\n[2/15] Packaging 02_Web_Dashboard_and_Workstation.zip...")
    dash_zip = OUT_DIR / "02_Web_Dashboard_and_Workstation.zip"
    with zipfile.ZipFile(dash_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, _, files in os.walk(ROOT / "web_dashboard"):
            for f in files:
                rel = os.path.relpath(os.path.join(root, f), ROOT)
                if not should_skip(rel):
                    add_to_zip(zf, rel)
    print(f"  -> {dash_zip.name}: {dash_zip.stat().st_size / (1024*1024):.2f} MB")

    # 3. AUDIT DELIVERY AND TESTS
    print("\n[3/15] Packaging 03_Audit_Delivery_and_Tests.zip...")
    audit_zip = OUT_DIR / "03_Audit_Delivery_and_Tests.zip"
    with zipfile.ZipFile(audit_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        for target in ["_AUDIT_DELIVERY", "tests"]:
            tp = ROOT / target
            if tp.exists():
                for root, _, files in os.walk(tp):
                    for f in files:
                        rel = os.path.relpath(os.path.join(root, f), ROOT)
                        if not should_skip(rel):
                            add_to_zip(zf, rel)
    print(f"  -> {audit_zip.name}: {audit_zip.stat().st_size / (1024*1024):.2f} MB")

    # 4. CSVS, DATABASES, AND HTML REPORTS
    print("\n[4/15] Packaging 04_CSVs_Databases_and_HTML_Reports.zip...")
    data_zip = OUT_DIR / "04_CSVs_Databases_and_HTML_Reports.zip"
    with zipfile.ZipFile(data_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        # Root CSVs & HTML reports
        for f in os.listdir(ROOT):
            fp = ROOT / f
            if fp.is_file() and not should_skip(f):
                if f.endswith((".csv", ".html")):
                    add_to_zip(zf, f)
        # qa_db & archive
        for target in ["qa_db", "archive"]:
            tp = ROOT / target
            if tp.exists():
                for root, _, files in os.walk(tp):
                    for f in files:
                        rel = os.path.relpath(os.path.join(root, f), ROOT)
                        if not should_skip(rel):
                            add_to_zip(zf, rel)
    print(f"  -> {data_zip.name}: {data_zip.stat().st_size / (1024*1024):.2f} MB")

    # 0. CODE-ONLY SINGLE ZIP (< 4 MB)
    print("\n[0/15] Packaging 00_Complete_Source_Code_and_Reports_NO_MODELS.zip...")
    no_models_zip = OUT_DIR / "00_Complete_Source_Code_and_Reports_NO_MODELS.zip"
    with zipfile.ZipFile(no_models_zip, "w", zipfile.ZIP_DEFLATED) as out_zf:
        for p in [core_zip, dash_zip, audit_zip, data_zip]:
            with zipfile.ZipFile(p, "r") as in_zf:
                for item in in_zf.infolist():
                    out_zf.writestr(item, in_zf.read(item.filename))
    print(f"  -> {no_models_zip.name}: {no_models_zip.stat().st_size / (1024*1024):.2f} MB")

    # 5. VISION ARTIFACTS AND EMBEDDINGS
    print("\n[5/15] Packaging 05_Vision_Artifacts_and_Embeddings.zip...")
    art_zip = OUT_DIR / "05_Vision_Artifacts_and_Embeddings.zip"
    with zipfile.ZipFile(art_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, _, files in os.walk(ROOT / "artifacts"):
            for f in files:
                rel = os.path.relpath(os.path.join(root, f), ROOT)
                if not should_skip(rel):
                    add_to_zip(zf, rel)
    print(f"  -> {art_zip.name}: {art_zip.stat().st_size / (1024*1024):.2f} MB")

    # 6-10. ARCHETYPE ALPHA MODELS
    archetypes = [
        ("06_Archetype_Momentum.zip", ["models/ml_alpha_momentum.pkl", "models/ml_alpha_momentum.pkl.sha256"]),
        ("07_Archetype_Quality.zip", ["models/ml_alpha_quality.pkl", "models/ml_alpha_quality.pkl.sha256"]),
        ("08_Archetype_Defensive.zip", ["models/ml_alpha_defensive.pkl", "models/ml_alpha_defensive.pkl.sha256"]),
        ("09_Archetype_Flow.zip", ["models/ml_alpha_flow.pkl", "models/ml_alpha_flow.pkl.sha256"]),
        ("10_Archetype_IPO_and_Prebreakout.zip", [
            "models/ml_alpha_ipo.pkl",
            "models/ml_alpha_ipo.pkl.sha256",
            "models/ml_alpha_prebreakout.pkl",
            "models/ml_alpha_prebreakout.pkl.sha256",
            "models/regime_hmm_latest.json"
        ]),
    ]
    for idx, (arch_name, paths) in enumerate(archetypes, start=6):
        print(f"\n[{idx}/15] Packaging {arch_name}...")
        arch_zip = OUT_DIR / arch_name
        with zipfile.ZipFile(arch_zip, "w", zipfile.ZIP_DEFLATED) as zf:
            for p in paths:
                if (ROOT / p).exists():
                    add_to_zip(zf, p)
        print(f"  -> {arch_zip.name}: {arch_zip.stat().st_size / (1024*1024):.2f} MB")

    # 11-14. FEATURE CACHE PARQUETS & METADATA SIDECARS (Split across 4 parts)
    fc_dir = ROOT / "models" / "feature_cache"
    all_parquets = sorted([
        os.path.relpath(os.path.join(root, f), ROOT)
        for root, _, files in os.walk(fc_dir)
        for f in files if f.endswith(".parquet") and not should_skip(f)
    ])
    print(f"\nFound {len(all_parquets)} parquet files in models/feature_cache/")
    chunk_size = (len(all_parquets) + 3) // 4
    for p_idx in range(4):
        subset = all_parquets[p_idx * chunk_size : (p_idx + 1) * chunk_size]
        zip_name = f"{11 + p_idx}_Feature_Cache_Part{p_idx + 1}.zip"
        fc_zip = OUT_DIR / zip_name
        print(f"[{11 + p_idx}/15] Packaging {zip_name} ({len(subset)} parquets + sidecars)...")
        with zipfile.ZipFile(fc_zip, "w", zipfile.ZIP_DEFLATED) as zf:
            for rel in subset:
                add_to_zip(zf, rel)
                meta_rel = os.path.splitext(rel)[0] + ".meta.json"
                if (ROOT / meta_rel).exists():
                    add_to_zip(zf, meta_rel)
        print(f"  -> {fc_zip.name}: {fc_zip.stat().st_size / (1024*1024):.2f} MB")

    # 15. DEEP ALPHA MASTER MODEL (models/ml_alpha_model.pkl -> ~112 MB split into 9 chunks <= 14 MB each)
    master_pkl = ROOT / "models" / "ml_alpha_model.pkl"
    if master_pkl.exists():
        print(f"\n[15/15] Packaging DeepAlpha Master Model ({master_pkl.stat().st_size / (1024*1024):.2f} MB)...")
        CHUNK_SIZE = 14 * 1024 * 1024  # 14 MB uncompressed chunks
        total_chunks = (master_pkl.stat().st_size + CHUNK_SIZE - 1) // CHUNK_SIZE
        
        # Temp dir for chunks
        tmp_chunks_dir = OUT_DIR / ".tmp_model_chunks"
        tmp_chunks_dir.mkdir(parents=True, exist_ok=True)
        
        with open(master_pkl, "rb") as mf:
            c_num = 1
            while True:
                data = mf.read(CHUNK_SIZE)
                if not data:
                    break
                chunk_fname = f"ml_alpha_model.pkl.part{c_num:02d}"
                chunk_file = tmp_chunks_dir / chunk_fname
                chunk_file.write_bytes(data)
                
                # Zip this chunk
                part_zip_name = f"15_DeepAlpha_Model_Part{c_num:02d}_of_{total_chunks:02d}.zip"
                part_zip = OUT_DIR / part_zip_name
                with zipfile.ZipFile(part_zip, "w", zipfile.ZIP_DEFLATED) as zf:
                    zf.write(chunk_file, arcname=f"models/{chunk_fname}", compress_type=zipfile.ZIP_DEFLATED)
                    if c_num == 1 and (ROOT / "models" / "ml_alpha_model.pkl.sha256").exists():
                        add_to_zip(zf, "models/ml_alpha_model.pkl.sha256")
                print(f"  -> {part_zip_name}: {part_zip.stat().st_size / (1024*1024):.2f} MB")
                c_num += 1
                
        shutil.rmtree(tmp_chunks_dir, ignore_errors=True)

    # GENERATE COMPREHENSIVE README_GITHUB_UPLOAD.md
    readme_path = OUT_DIR / "README_GITHUB_UPLOAD.md"
    readme_content = f"""# Quantum Annealer — GitHub Multi-Part Upload Manifest

**Round 50 Audited Baseline**  
All files in this folder are **strictly < 18.00 MB** each and 100% compliant with GitHub's file upload limits. Includes all models, provenance sidecars (.sha256, .meta.json), and tests.

---

## 📦 Package Inventory & Logical Structure

| Part # | Package Name | Size | Contents & Purpose |
|:---:|---|:---:|---|
| **00** | `00_Complete_Source_Code_and_Reports_NO_MODELS.zip` | ~3.8 MB | Complete Python source code, tests, HTML reports, and web dashboard (< 4 MB) |
| **01** | `01_Core_Source_and_Engines.zip` | ~1.8 MB | Complete Python source code (`optimizer.py`, `data_layer.py`, `portfolio_engine.py`, `math_engine/`, `core/`, `data/`, `ml_alpha/`, `workers/`, configs) |
| **02** | `02_Web_Dashboard_and_Workstation.zip` | ~0.3 MB | Web dashboard, TradingView direct workstation engine, full drawing tools, proxy server, and single-CSV export |
| **03** | `03_Audit_Delivery_and_Tests.zip` | ~0.4 MB | Complete test suites (`tests/`), verification scripts (`verify_fixes_r*.py`), and audit reports (`_AUDIT_DELIVERY/`) |
| **04** | `04_CSVs_Databases_and_HTML_Reports.zip` | ~1.4 MB | Universe CSVs, database tables (`qa_db/`), and HTML research reports |
| **05** | `05_Vision_Artifacts_and_Embeddings.zip` | ~10.7 MB | Vision Transformer ONNX model (`vit_v3_fused.onnx`), embeddings, and prototype banks |
| **06** | `06_Archetype_Momentum.zip` | ~11.4 MB | Momentum ML Alpha model + .sha256 sidecar (`models/ml_alpha_momentum.pkl`) |
| **07** | `07_Archetype_Quality.zip` | ~11.4 MB | Quality ML Alpha model + .sha256 sidecar (`models/ml_alpha_quality.pkl`) |
| **08** | `08_Archetype_Defensive.zip` | ~11.4 MB | Defensive ML Alpha model + .sha256 sidecar (`models/ml_alpha_defensive.pkl`) |
| **09** | `09_Archetype_Flow.zip` | ~11.4 MB | Institutional Flow GAT model + .sha256 sidecar (`models/ml_alpha_flow.pkl`) |
| **10** | `10_Archetype_IPO_and_Prebreakout.zip` | ~11.8 MB | IPO model, Pre-breakout model + .sha256 sidecars, and Regime HMM artifact |
| **11** | `11_Feature_Cache_Part1.zip` | ~13.4 MB | Feature Cache Parquets + .meta.json sidecars (Subset 1/4) |
| **12** | `12_Feature_Cache_Part2.zip` | ~14.0 MB | Feature Cache Parquets + .meta.json sidecars (Subset 2/4) |
| **13** | `13_Feature_Cache_Part3.zip` | ~16.9 MB | Feature Cache Parquets + .meta.json sidecars (Subset 3/4) |
| **14** | `14_Feature_Cache_Part4.zip` | ~13.9 MB | Feature Cache Parquets + .meta.json sidecars (Subset 4/4) |
| **15** | `15_DeepAlpha_Model_Part01_of_09.zip` .. `Part09_of_09.zip` | ~13 MB each | DeepAlpha Master Model (`models/ml_alpha_model.pkl`) + .sha256 split across 9 parts |

---

## 🚀 How to Restore the Complete Tree (for GLM or Local Deployment)

To unpack and reconstruct the complete, identical repository:

```bash
# 1. Create target folder and enter it
mkdir -p quantum_annealer && cd quantum_annealer

# 2. Unzip all packages
for f in /path/to/Quantum_Annealer_GitHub_Upload/*.zip; do
    unzip -o "$f"
done

# 3. Reassemble the DeepAlpha Master Model
cat models/ml_alpha_model.pkl.part* > models/ml_alpha_model.pkl
rm -f models/ml_alpha_model.pkl.part*

# 4. Verify integrity
python3 _AUDIT_DELIVERY/verify_fixes_r50.py
python3 _AUDIT_DELIVERY/verify_fixes_r49.py
python3 _AUDIT_DELIVERY/verify_fixes.py
python3 -m pytest tests/test_round50_regressions.py -q 2>/dev/null || true
```
"""
    readme_path.write_text(readme_content, encoding="utf-8")
    print(f"\nGenerated: {readme_path}")
    print("\n✅ ALL PACKAGES SUCCESSFULLY CREATED!")

    # Verify all generated zip files are strictly < 20 MB
    print("\nVerifying file size limits (< 20.00 MB):")
    all_ok = True
    for z in sorted(OUT_DIR.glob("*.zip")):
        sz_mb = z.stat().st_size / (1024*1024)
        status = "OK (<20MB)" if sz_mb < 20.0 else "EXCEEDS LIMIT!"
        print(f"  {z.name:50s}: {sz_mb:6.2f} MB  [{status}]")
        if sz_mb >= 20.0:
            all_ok = False
            
    if all_ok:
        print("\n🎉 PERFECT: 100% of zip packages are strictly under 20 MB and ready for GitHub upload.")
    else:
        print("\n⚠️ Some packages exceeded 20 MB!")


if __name__ == "__main__":
    package_all()
