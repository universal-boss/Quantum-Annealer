#!/usr/bin/env python3
"""R50-1: regenerate the provenance/sha256 sidecars the GitHub split-zip
packaging dropped.

- models/*.pkl.sha256       -> bare sha256 hex digest of the shipped .pkl
- models/feature_cache/*.meta.json -> FeatureStore.save() schema, rebuilt
  from panel CONTENT (factor name/version from the canonical filename,
  start/end from the panel's own DatetimeIndex, n_dates/n_tickers from its
  shape), with an explicit sidecar_rebuilt disclosure + note.

Honesty rules (repo doctrine "telemetry/provenance reports only what it
measures"):
- No value is invented: the sha256 IS the hash of the shipped bytes; every
  meta field is measured from the parquet itself.
- All-NaN panels get an explicit all_nan disclosure instead of a silent
  normal-looking sidecar.
- The historical R34-12b "regenerated: true" notes belong to the retired
  factors_100 generation; they are NOT fabricated onto this generation.
"""
import hashlib
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
MODELS = ROOT / "models"
CACHE = MODELS / "feature_cache"
NOW = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

FNAME_RE = re.compile(r"^(?P<factor>.+)_(?P<version>v\d+)_(?P<hash>[0-9a-f]{12})$")


def make_model_sidecars() -> int:
    n = 0
    for pkl in sorted(MODELS.glob("*.pkl")):
        sha = hashlib.sha256(pkl.read_bytes()).hexdigest()
        side = pkl.with_suffix(pkl.suffix + ".sha256")
        side.write_text(sha + "\n", encoding="utf-8")
        print(f"  {side.name}  {sha}")
        n += 1
    return n


def make_cache_sidecars() -> int:
    n = 0
    for pq in sorted(CACHE.glob("*.parquet")):
        m = FNAME_RE.match(pq.stem)
        if not m:
            print(f"  !! non-canonical panel name, skipping: {pq.name}", file=sys.stderr)
            continue
        factor, version = m.group("factor"), m.group("version")
        df = pd.read_parquet(pq)
        idx = df.index
        if isinstance(idx, pd.DatetimeIndex) and len(idx):
            start, end = str(idx.min().date()), str(idx.max().date())
        else:
            start = end = None
        import numpy as np
        v = df.select_dtypes("number").to_numpy().ravel()
        all_nan = bool(v.size == 0 or bool(pd.isna(v).all()))
        meta = {
            "factor_name": factor,
            "version": version,
            "start": start,
            "end": end,
            "n_dates": int(df.shape[0]),
            "n_tickers": int(df.shape[1]),
            "saved_at": NOW,
            # R50 disclosure: this sidecar itself is a reconstruction (the
            # original was lost in the GitHub packaging step), while the
            # PANEL bytes are exactly as shipped.
            "sidecar_rebuilt": True,
            "rebuild_note": (
                "R50 upload audit: original .meta.json was dropped by the "
                "GitHub split-zip packaging; sidecar rebuilt from the panel's "
                "own content (name/version parsed from the canonical filename, "
                "range measured from the panel index, shape measured from the "
                "frame). Panel bytes untouched."
            ),
        }
        if all_nan:
            meta["all_nan"] = True
            meta["data_note"] = (
                "R50 disclosure: every value in this panel is NaN in the "
                "shipped generation — the feature failed to compute; consumers "
                "zero-fill it. Regenerate via the live pipeline."
            )
        side = pq.with_suffix(".meta.json")
        side.write_text(json.dumps(meta, indent=2), encoding="utf-8")
        n += 1
    return n


if __name__ == "__main__":
    print("== model sha256 sidecars ==")
    a = make_model_sidecars()
    print("== feature-cache provenance sidecars ==")
    b = make_cache_sidecars()
    print(f"done: {a} model sidecars, {b} cache sidecars")
