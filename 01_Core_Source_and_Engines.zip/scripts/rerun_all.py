#!/usr/bin/env python3
"""Re-apply all Round 3 patches in the right order.

Order:
  1. God-file split (split_god_files.py)
  2. optimizer.py alpha-decay + IC prune + weight cap fixes
  3. data_layer.py NSE consolidation fixes
  4. Except-handler sweep (sweep_except_handlers.py)
  5. Verify all files compile
"""
import os, sys, subprocess
APP = "/home/z/my-project/upload/extracted_app"
SCRIPTS = "/home/z/my-project/scripts/p3_round"

print("=== Step 1: god-file split ===")
r = subprocess.run(["python3", f"{SCRIPTS}/split_god_files.py"], capture_output=True, text=True, check=False)  # AUDIT-FIX (Round 4 — W1510): explicit check=False
print(r.stdout[-500:]); print(r.stderr[-500:])

print("\n=== Step 2: optimizer.py patches ===")
# Apply patches directly via Python
opt_path = f"{APP}/optimizer.py"
src = open(opt_path, encoding='utf-8').read()

# Patch 1: remove the np.clip(_decay_factor, 0.50, 1.00) third mask
old1 = '''                        _t_since_rebal = float(working_cfg.get("DAYS_SINCE_REBALANCE", 1))
                        _decay_factor  = float(np.exp(-_t_since_rebal / _T_half_blended))
                        # Clip to [0.50, 1.00] so decay never kills more than half the alpha
                        _decay_factor  = float(np.clip(_decay_factor, 0.50, 1.00))
                        signal_df["alpha_score"] = signal_df["alpha_score"] * _decay_factor
                        # Store per-ticker decay factor for diagnostic export
                        signal_df["alpha_decay_factor"] = _decay_factor
                        payload["alpha_decay_calibrated"] = True'''
new1 = '''                        _t_since_rebal = float(working_cfg.get("DAYS_SINCE_REBALANCE", 1))
                        _decay_factor  = float(np.exp(-_t_since_rebal / _T_half_blended))
                        # AUDIT-FIX (Round 3, P2-3): removed the third mask
                        # `np.clip(_decay_factor, 0.50, 1.00)` from the audit's
                        # "T_half=0 sentinel" trio. With the two sentinel guards
                        # above (lines 7410 and 7432), we never reach this line
                        # when T_half is degenerate; when we DO reach it, a
                        # legitimate short half-life (e.g. T_half=1d, days_since_rebal=21
                        # -> decay = exp(-21) ~ 7.6e-10) should be allowed to fully
                        # decay - clipping it to 0.50 hides the genuine statistical
                        # conclusion that "this signal has fully decayed by day 21".
                        signal_df["alpha_score"] = signal_df["alpha_score"] * _decay_factor
                        signal_df["alpha_decay_factor"] = _decay_factor
                        payload["alpha_decay_calibrated"] = True'''
assert old1 in src, "optimizer patch 1 (decay clip) not found"
src = src.replace(old1, new1, 1)
print("  patch 1 (decay clip removal) applied")

# Patch 2: IC prune gate (0.20 IC-IR -> 1.96 t-stat)
old2 = '''    # ── Institutional-grade Active Factor Pruning (Issue 2 Fix) ──
    _ANCHORS      = {"z_roe", "z_pe_inv", "z_de_inv", "z_rev_growth", "z_delivery", "z_fii_sector"}
    # 1. Prune Dead Factors: if absolute IC-IR is below 0.20 and not a fundamental anchor, set to 0.0
    for _k in list(ic_ir_now.keys()):
        if _k not in _ANCHORS and abs(ic_ir_now.get(_k, 0.0)) < 0.20:
            ic_ir_now[_k] = 0.0
            log_emit(log_cb, f"[IC-Prune] Pruned dead factor {_k} to 0.0 (|IC-IR| < 0.20)")'''
new2 = '''    # ── Institutional-grade Active Factor Pruning (Issue 2 Fix) ──
    # AUDIT-FIX (Round 3, P2-3): the 0.20 IC-IR prune gate was an arbitrary
    # effect-size cutoff, not a statistical-significance test. With std(IC)
    # ~0.45 on a 10-stock universe and N~45 windows, the implied |t| for
    # IC-IR=0.20 is roughly 0.20*sqrt(45)~1.34 - below the 95% t-test
    # threshold of 1.96. So the system was PERMITTING factors that fail the
    # t-test into production. The proper gate is the IC t-statistic from
    # scripts/walk_forward_validation_v2.py (with NW + orthogonalization +
    # BH-FDR). When USE_IC_T_STAT_GATING is True (default), we look up the
    # t_stat from the calibration cache and prune only factors with |t| < 1.96.
    _ANCHORS      = {"z_roe", "z_pe_inv", "z_de_inv", "z_rev_growth", "z_delivery", "z_fii_sector"}
    _USE_STAT_GATE = bool(working_cfg.get("USE_IC_T_STAT_GATING", True)) if 'working_cfg' in dir() else True
    _T_STAT_LOOKUP = (working_cfg.get("FACTOR_T_STATS", {}) if 'working_cfg' in dir() else {})
    _T_STAT_THRESHOLD = 1.96  # 95% two-tailed
    # 1. Prune Dead Factors - gate on IC t-statistic (or fall back to 0.20 IC-IR)
    for _k in list(ic_ir_now.keys()):
        if _k not in _ANCHORS:
            if _USE_STAT_GATE and _T_STAT_LOOKUP:
                _t = float(_T_STAT_LOOKUP.get(_k, 0.0))
                if abs(_t) < _T_STAT_THRESHOLD:
                    ic_ir_now[_k] = 0.0
                    log_emit(log_cb, f"[IC-Prune] Pruned factor {_k} to 0.0 (|t_IC|={_t:.2f} < {_T_STAT_THRESHOLD})")
            else:
                # Legacy fallback: prune on |IC-IR| < 0.20 (arbitrary effect-size cutoff)
                if abs(ic_ir_now.get(_k, 0.0)) < 0.20:
                    ic_ir_now[_k] = 0.0
                    log_emit(log_cb, f"[IC-Prune] Pruned dead factor {_k} to 0.0 (|IC-IR| < 0.20, fallback gate)")'''
assert old2 in src, "optimizer patch 2 (IC prune) not found"
src = src.replace(old2, new2, 1)
print("  patch 2 (IC prune gate) applied")

# Patch 3: weight cap removal (3x default_abs -> no upper bound)
old3 = '''    calibrated = {}
    for fname, ic_ir in blended.items():
        default_abs = abs(default_fw.get(fname, 0.05))
        raw_w       = ic_ir * scale
        # clamp: no factor gets more than 3× its default
        calibrated[fname] = float(np.clip(raw_w, 0.0, 3.0 * default_abs))'''
new3 = '''    calibrated = {}
    for fname, ic_ir in blended.items():
        default_abs = abs(default_fw.get(fname, 0.05))
        raw_w       = ic_ir * scale
        # AUDIT-FIX (Round 3, P2-3): removed the 3x default_abs weight cap.
        # The audit flagged this as one of the four clamps that mask the very
        # signal the IC analysis is meant to surface - capping at 3x default
        # means a factor with 10x default IC-IR is silently downweighted to
        # 3x default, hiding its statistical strength. The lower bound (0.0)
        # stays (negative weights are nonsensical for a long-only portfolio);
        # the upper bound is removed so the IC-IR scaling passes through
        # untouched.
        calibrated[fname] = float(max(0.0, raw_w))'''
assert old3 in src, "optimizer patch 3 (weight cap) not found"
src = src.replace(old3, new3, 1)
print("  patch 3 (weight cap removal) applied")

open(opt_path, 'w', encoding='utf-8').write(src)

print("\n=== Step 3: data_layer.py NSE patches ===")
dl_path = f"{APP}/data_layer.py"
src = open(dl_path, encoding='utf-8').read()

# I'll just import the helper from the existing scripts/p3_round module
# Actually, let me copy patches directly. Use a marker comment for the patches
# that have already been written to data_layer.py and re-apply them.

# This is the FULL MultiEdit list from the previous Edit call. We do it inline.
import re as _re

patches = [
    # Patch 1: fetch_pcr_skew
    (
'''def fetch_pcr_skew(tickers: list, log_cb=None) -> dict:
    """S4: Options PCR + IV Skew divergence from 20d average.
    Uses NSE option-chain API. High PCR divergence = bearish positioning.
    Inverse used as signal: low PCR vs history = bullish informed flow."""
    today_str = datetime.now().strftime("%Y-%m-%d")
    cache = read_json_cache(PCR_CACHE_PATH, {})
    if cache.get("date") == today_str and cache.get("data"):
        return cache["data"]
    result = {}
    try:
        session = requests.Session()
        session.get("https://www.nseindia.com", headers={"User-Agent": "Mozilla/5.0"}, timeout=10)
        headers = {
            "User-Agent": "Mozilla/5.0", "Accept": "application/json",
            "Referer": "https://www.nseindia.com"
        }
        # Bug 26 fix: removed top-40 cap — created feedback loop where only first
        # 40 tickers ever received PCR signals, artificially boosting them.
        for t in tickers:
            sym = t.replace(".NS","").upper()
            try:
                url = f"https://www.nseindia.com/api/option-chain-equities?symbol={sym}"
                resp = session.get(url, headers=headers, timeout=10)
                if resp.status_code != 200: continue
                data = resp.json()
                records = data.get("records", {}).get("data", [])
                total_put_oi  = sum(r.get("PE", {}).get("openInterest", 0) for r in records if r.get("PE"))
                total_call_oi = sum(r.get("CE", {}).get("openInterest", 0) for r in records if r.get("CE"))
                if total_call_oi > 0:
                    result[t] = round(1.0 / (1.0 + total_put_oi / total_call_oi), 4)  # DIV001: guard divisor before use
            except Exception as _exc_p2a_:
                ExceptionLogger.swallow(_exc_p2a_, context='L4311')
        write_json_cache(PCR_CACHE_PATH, {"date": today_str, "data": result})
        log_emit(log_cb, f"[PCR] {len(result)} tickers with PCR skew scores")
    except Exception as e:
        log_emit(log_cb, f"[PCR] fetch failed (non-fatal): {e}")
    return result''',
'''def fetch_pcr_skew(tickers: list, log_cb=None) -> dict:
    """S4: Options PCR + IV Skew divergence from 20d average.
    Uses NSE option-chain API. High PCR divergence = bearish positioning.
    Inverse used as signal: low PCR vs history = bullish informed flow.

    AUDIT-FIX (Round 3, P2-2): migrated onto NSEClient + NSEPerTickerPool.
    """
    from utils_nse import NSEPerTickerPool, nse_parsers
    from utils import NSEClient

    today_str = datetime.now().strftime("%Y-%m-%d")
    cache = read_json_cache(PCR_CACHE_PATH, {})
    if cache.get("date") == today_str and cache.get("data"):
        return cache["data"]

    result = {}

    def _fetch_one(t: str):
        sym = t.replace(".NS","").upper()
        url = f"https://www.nseindia.com/api/option-chain-equities?symbol={sym}"
        resp = NSEClient.get(url, timeout=10)
        if resp.status_code != 200:
            return None
        data = nse_parsers.decode_nse_json(resp)
        records = data.get("records", {}).get("data", [])
        total_put_oi  = sum(r.get("PE", {}).get("openInterest", 0) for r in records if r.get("PE"))
        total_call_oi = sum(r.get("CE", {}).get("openInterest", 0) for r in records if r.get("CE"))
        if total_call_oi > 0:
            return round(1.0 / (1.0 + total_put_oi / total_call_oi), 4)
        return None

    try:
        per_ticker_results = NSEPerTickerPool.map_per_ticker(_fetch_one, tickers)
        for t, v in per_ticker_results.items():
            if v is not None:
                result[t] = v
        if result:
            write_json_cache(PCR_CACHE_PATH, {"date": today_str, "data": result})
        log_emit(log_cb, f"[PCR] {len(result)} tickers with PCR skew scores")
    except Exception as e:
        log_emit(log_cb, f"[PCR] fetch failed (non-fatal): {e}")
    return result''',
    ),
    # Patch 2: fetch_fii_sector_flow
    (
'''def fetch_fii_sector_flow(log_cb=None) -> dict:
    """S5: FII sector-level flow disaggregation.
    NSE publishes sector-wise FII buy/sell. Returns sector→zscore dict."""
    today_str = datetime.now().strftime("%Y-%m-%d")
    cache = read_json_cache(FII_SECTOR_CACHE_PATH, {})
    if cache.get("date") == today_str and cache.get("data"):
        return cache["data"]
    result = {}
    try:
        session = requests.Session()
        session.get("https://www.nseindia.com",
                    headers={"User-Agent": "Mozilla/5.0"}, timeout=10)
        headers = {"User-Agent": "Mozilla/5.0", "Accept": "application/json",
                   "Referer": "https://www.nseindia.com"}
        # NSE sector indices FII data
        resp = session.get(
            "https://www.nseindia.com/api/fiidiiTradeReact",
            headers=headers, timeout=15
        )
        if resp.status_code == 200:
            data = resp.json()
            flows = {}
            for rec in (data if isinstance(data, list) else data.get("data", [])):
                cat = str(rec.get("category", "")).strip()
                try:
                    net = float(str(rec.get("netBuySell", "0")).replace(",", "") or 0)
                    if cat:
                        flows[cat] = flows.get(cat, 0) + net
                except Exception as _exc_p2a_:
                    ExceptionLogger.swallow(_exc_p2a_, context='L4348')
            if flows:
                vals = list(flows.values())
                mu   = (float(np.mean(vals)) if len(vals) > 0 else 0.0)
                sig  = (float(np.std(vals)) if len(vals) > 0 else 0.0) + 1e-6
                result = {k: round((v - mu) / sig, 3) for k, v in flows.items()}  # DIV001: guard divisor before use
        write_json_cache(FII_SECTOR_CACHE_PATH, {"date": today_str, "data": result})
        log_emit(log_cb, f"[FII-Sector] {len(result)} sector flow z-scores")
    except Exception as e:
        log_emit(log_cb, f"[FII-Sector] fetch failed (non-fatal): {e}")
    return result''',
'''def fetch_fii_sector_flow(log_cb=None) -> dict:
    """S5: FII sector-level flow disaggregation.
    NSE publishes sector-wise FII buy/sell. Returns sector->zscore dict.

    AUDIT-FIX (Round 3, P2-2): migrated onto NSEClient.fetch_json.
    """
    from utils import NSEClient
    from utils_nse import nse_parsers

    today_str = datetime.now().strftime("%Y-%m-%d")
    cache = read_json_cache(FII_SECTOR_CACHE_PATH, {})
    if cache.get("date") == today_str and cache.get("data"):
        return cache["data"]
    result = {}
    try:
        parsed = NSEClient.fetch_json(
            "https://www.nseindia.com/api/fiidiiTradeReact",
            timeout=15,
        )
        records = nse_parsers.extract_records(parsed)
        flows = {}
        for rec in records:
            cat = str(rec.get("category", "")).strip()
            try:
                net = float(str(rec.get("netBuySell", "0")).replace(",", "") or 0)
                if cat:
                    flows[cat] = flows.get(cat, 0) + net
            except Exception as _exc_p2a_:
                ExceptionLogger.swallow(_exc_p2a_, context='L4348')
        if flows:
            vals = list(flows.values())
            mu   = (float(np.mean(vals)) if len(vals) > 0 else 0.0)
            sig  = (float(np.std(vals)) if len(vals) > 0 else 0.0) + 1e-6
            result = {k: round((v - mu) / sig, 3) for k, v in flows.items()}
        if result:
            write_json_cache(FII_SECTOR_CACHE_PATH, {"date": today_str, "data": result})
        log_emit(log_cb, f"[FII-Sector] {len(result)} sector flow z-scores")
    except Exception as e:
        log_emit(log_cb, f"[FII-Sector] fetch failed (non-fatal): {e}")
    return result''',
    ),
    # Patch 3: fetch_mtf_reversal
    (
'''def fetch_mtf_reversal(tickers: list, log_cb=None) -> dict:
    """S7: Margin Trading Facility (MTF) forced-unwind reversal signal.
    NSE publishes daily MTF outstanding. High MTF + recent price drop = forced
    unwind risk. We use inverse: low MTF + stable price = clean positioning."""
    today_str = datetime.now().strftime("%Y-%m-%d")
    cache = read_json_cache(MTF_CACHE_PATH, {})
    if cache.get("date") == today_str and cache.get("data"):
        return cache["data"]
    result = {}
    try:
        session = requests.Session()
        session.get("https://www.nseindia.com",
                    headers={"User-Agent": "Mozilla/5.0"}, timeout=10)
        headers = {
            "User-Agent": "Mozilla/5.0", "Accept": "application/json",
            "Referer": "https://www.nseindia.com",
            "X-Requested-With": "XMLHttpRequest"
        }
        resp = session.get(
            "https://www.nseindia.com/api/mtf",
            headers=headers, timeout=15
        )
        if resp.status_code == 200:
            data = resp.json()
            records = data if isinstance(data, list) else data.get("data", [])
            ticker_set = set(t.replace(".NS","").upper() for t in tickers)
            mtf_vals = {}
            for rec in records:
                sym = str(rec.get("symbol", "")).strip().upper()
                if sym in ticker_set:
                    try:
                        mtf_outstanding = float(str(rec.get("mtfOutstanding", 0)).replace(",","") or 0)
                        mtf_vals[f"{sym}.NS"] = mtf_outstanding
                    except Exception as _exc_p2a_:
                        ExceptionLogger.swallow(_exc_p2a_, context='L4434')
            if mtf_vals:
                arr = np.array(list(mtf_vals.values()))
                mu, sig = arr.mean(), arr.std() + 1e-6
                # Inverse signal: low MTF exposure = cleaner, safer positioning
                for k, v in mtf_vals.items():
                    result[k] = (round(-1.0 * (v - mu) / sig, 3) if sig != 0 else 0.0)  # DIV001 guarded
        write_json_cache(MTF_CACHE_PATH, {"date": today_str, "data": result})
        log_emit(log_cb, f"[MTF] {len(result)} tickers with MTF reversal scores")
    except Exception as e:
        log_emit(log_cb, f"[MTF] fetch failed (non-fatal): {e}")
    return result''',
'''def fetch_mtf_reversal(tickers: list, log_cb=None) -> dict:
    """S7: Margin Trading Facility (MTF) forced-unwind reversal signal.
    NSE publishes daily MTF outstanding. High MTF + recent price drop = forced
    unwind risk. We use inverse: low MTF + stable price = clean positioning.

    AUDIT-FIX (Round 3, P2-2): migrated onto NSEClient.fetch_json.
    """
    from utils import NSEClient
    from utils_nse import nse_parsers

    today_str = datetime.now().strftime("%Y-%m-%d")
    cache = read_json_cache(MTF_CACHE_PATH, {})
    if cache.get("date") == today_str and cache.get("data"):
        return cache["data"]
    result = {}
    try:
        parsed = NSEClient.fetch_json(
            "https://www.nseindia.com/api/mtf",
            headers={"X-Requested-With": "XMLHttpRequest"},
            timeout=15,
        )
        records = nse_parsers.extract_records(parsed)
        ticker_set = set(t.replace(".NS","").upper() for t in tickers)
        mtf_vals = {}
        for rec in records:
            sym = str(rec.get("symbol", "")).strip().upper()
            if sym in ticker_set:
                try:
                    mtf_outstanding = float(str(rec.get("mtfOutstanding", 0)).replace(",","") or 0)
                    mtf_vals[f"{sym}.NS"] = mtf_outstanding
                except Exception as _exc_p2a_:
                    ExceptionLogger.swallow(_exc_p2a_, context='L4434')
        if mtf_vals:
            arr = np.array(list(mtf_vals.values()))
            mu, sig = arr.mean(), arr.std() + 1e-6
            for k, v in mtf_vals.items():
                result[k] = (round(-1.0 * (v - mu) / sig, 3) if sig != 0 else 0.0)
        if result:
            write_json_cache(MTF_CACHE_PATH, {"date": today_str, "data": result})
        log_emit(log_cb, f"[MTF] {len(result)} tickers with MTF reversal scores")
    except Exception as e:
        log_emit(log_cb, f"[MTF] fetch failed (non-fatal): {e}")
    return result''',
    ),
    # Patch 4: fetch_fno_ban_list (constant fallback fix)
    (
'''    banned = set()
    headers = {"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"}
    try:
        # Primary: Official NSE Archives fo_secban.csv
        resp = requests.get("https://archives.nseindia.com/content/fo/fo_secban.csv", headers=headers, timeout=10)
        if resp.status_code == 200 and resp.text:
            lines = resp.text.strip().splitlines()
            for line in lines:
                parts = [p.strip().upper() for p in line.split(",") if p.strip()]
                for p in parts:
                    if p and p != "NIL" and len(p) >= 3 and p.isalnum() and not p.isdigit() and "SECURITIES IN BAN" not in p:
                        banned.add(f"{p}.NS")
    except Exception as e:
        log_emit(log_cb, f"[F&O Ban] NSE Archives CSV fetch notice: {e}")

    write_json_cache(FNO_BAN_CACHE_PATH, {"date": today, "banned": list(banned)})
    log_emit(log_cb, f"[F&O Ban] {len(banned)} stocks in ban period — excluded from universe")
    return banned''',
'''    # AUDIT-FIX (Round 3, P2-2): use NSEClient + sentinel-guarded cache write
    from utils import NSEClient
    banned = set()
    fetch_ok = False
    try:
        resp = NSEClient.get("https://archives.nseindia.com/content/fo/fo_secban.csv", timeout=10)
        if resp.status_code == 200 and resp.text:
            fetch_ok = True
            lines = resp.text.strip().splitlines()
            for line in lines:
                parts = [p.strip().upper() for p in line.split(",") if p.strip()]
                for p in parts:
                    if p and p != "NIL" and len(p) >= 3 and p.isalnum() and not p.isdigit() and "SECURITIES IN BAN" not in p:
                        banned.add(f"{p}.NS")
    except Exception as e:
        log_emit(log_cb, f"[F&O Ban] NSE Archives CSV fetch notice: {e}")
    if fetch_ok:
        write_json_cache(FNO_BAN_CACHE_PATH, {"date": today, "banned": list(banned)})
    else:
        log_emit(log_cb, "[F&O Ban] HTTP fetch failed - not caching empty set; will retry next run")
    log_emit(log_cb, f"[F&O Ban] {len(banned)} stocks in ban period - excluded from universe")
    return banned''',
    ),
    # Patch 5: fetch_india_vix (15.0 -> NaN)
    (
'''        vix_val = _extract_last_float(raw_vix)
        if vix_val is not None and pd.notna(vix_val) and vix_val > 0.0:
            log_emit(log_cb, f"[Market Context] India VIX = {vix_val:.2f}")
            return vix_val
    except Exception as e:
        log_emit(log_cb, f"[Market Context] Failed to fetch VIX: {e}")
    
    log_emit(log_cb, "[Market Context] ⚠️ All India VIX fetches failed — defaulting VIX to neutral baseline 15.0 for position sizing.")
    return 15.0''',
'''        vix_val = _extract_last_float(raw_vix)
        if vix_val is not None and pd.notna(vix_val) and vix_val > 0.0:
            log_emit(log_cb, f"[Market Context] India VIX = {vix_val:.2f}")
            return vix_val
    except Exception as e:
        log_emit(log_cb, f"[Market Context] Failed to fetch VIX: {e}")
    # AUDIT-FIX (Round 3, P2-2): replace silent constant 15.0 fallback with NaN
    log_emit(log_cb, "[Market Context] All India VIX fetches failed - returning NaN.")
    return float('nan')''',
    ),
    # Patch 6: fetch_fii_dii_flow (Neutral sentinel -> NaN)
    (
'''    last_valid_result = cache.get("result")
    result = {"fii_10d_net": np.nan, "dii_10d_net": np.nan,
              "fii_z_score": 0.0, "flow_signal": "Neutral"}
    fetch_ok = False
    headers = {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "application/json, text/plain, */*",
        "Referer": "https://www.nseindia.com/reports/fii-dii",
        "X-Requested-With": "XMLHttpRequest"
    }
    # Session warmup: visit /reports/fii-dii to acquire valid Akamai session cookies
    _warmup_urls = [
        "https://www.nseindia.com/reports/fii-dii",
        "https://www.nseindia.com/market-data/fii-dii-activity"
    ]
    for _wu in _warmup_urls:
        try:
            NSEClient.get(_wu, headers={"User-Agent": headers["User-Agent"], "Accept": "text/html,*/*"}, timeout=8)
        except Exception:
            pass

    try:
        resp = NSEClient.get(NSE_FII_DII_URL, headers=headers, timeout=15)
        if resp.status_code == 200:''',
'''    # AUDIT-FIX (Round 3, P2-2): replace silent constant fallback
    last_valid_result = cache.get("result")
    result = {"fii_10d_net": np.nan, "dii_10d_net": np.nan,
              "fii_z_score": float('nan'), "flow_signal": None}
    fetch_ok = False
    headers = {"X-Requested-With": "XMLHttpRequest"}

    try:
        resp = NSEClient.get(NSE_FII_DII_URL, headers=headers, timeout=15)
        if resp.status_code == 200:''',
    ),
    # Patch 7: fetch_fii_dii_flow tail
    (
'''    if fetch_ok:
        write_json_cache(FII_DII_CACHE_PATH, {"date": today, "result": result})
    elif last_valid_result:
        log_emit(log_cb, f"[FII/DII] Live fetch throttled — reusing last valid cached flow: signal={last_valid_result.get('flow_signal')}")
        result = last_valid_result
    else:
        log_emit(log_cb, "[FII/DII] Skipping cache write — using neutral fallback")

    return result''',
'''    if fetch_ok:
        write_json_cache(FII_DII_CACHE_PATH, {"date": today, "result": result})
    elif last_valid_result:
        log_emit(log_cb, f"[FII/DII] Live fetch throttled - reusing last valid cached flow: signal={last_valid_result.get('flow_signal')}")
        result = last_valid_result
    else:
        # AUDIT-FIX (Round 3, P2-2): return NaN/None sentinel, do not cache
        log_emit(log_cb, "[FII/DII] Live fetch failed - returning NaN/None sentinel (no cache write).")

    return result''',
    ),
    # Patch 8: fetch_iv_rank (full rewrite)
    (
'''    headers = {"User-Agent": "Mozilla/5.0", "Referer": "https://www.nseindia.com",
               "Accept": "application/json"}
    result = {}
    session = requests.Session()
    try:
        session.get("https://www.nseindia.com", headers=headers, timeout=8)
    except Exception as _e:
        return result

    # Load existing ATM IV history for all tickers
    iv_history = _load_iv_history()
    history_updated = False

    for t in tickers[:30]:  # limit to top 30 to avoid throttling
        sym = t.replace(".NS", "").replace(".BO", "").upper()
        try:
            url = NSE_OPTIONS_URL.format(symbol=sym)
            resp = session.get(url, headers=headers, timeout=10)
            if resp.status_code != 200:
                continue
            data = resp.json()
            records = data.get("records", {}).get("data", [])

            # Find ATM IV: use near-the-money strikes (median of all valid IVs)
            ivs = []
            for rec in records:
                for opt_type in ["CE", "PE"]:
                    opt = rec.get(opt_type, {})
                    iv_val = opt.get("impliedVolatility")
                    if iv_val and float(iv_val) > 0:
                        ivs.append(float(iv_val))
            if not ivs:
                continue

            atm_iv = float(np.median(ivs))

            # B07-fix: append today's ATM IV to this ticker's rolling history
            ticker_hist = iv_history.get(t, [])
            ticker_hist.append([today, atm_iv])
            # Keep only the last 260 observations (≈ 252 trading days + buffer)
            ticker_hist = ticker_hist[-_IV_HISTORY_MAX_DAYS:]
            iv_history[t] = ticker_hist
            history_updated = True

            # Compute true IVR from the rolling history
            hist_ivs = [entry[1] for entry in ticker_hist if isinstance(entry, list) and len(entry) == 2]
            if len(hist_ivs) < 5:
                # Insufficient history — fall back to neutral value
                result[t] = 0.5
                continue

            iv_lo  = float(min(hist_ivs))
            iv_hi  = float(max(hist_ivs))
            iv_rng = iv_hi - iv_lo
            if iv_rng < 1e-6:
                result[t] = 0.5
                continue

            # True IV Rank: where is today's IV in the historical range?
            ivr = ((atm_iv - iv_lo) / iv_rng) if iv_rng != 0 else 0.5  # DIV001 guarded
            result[t] = float(np.clip(ivr, 0.0, 1.0))

        except Exception as _eloop:
            pass  # _arch_log removed (LOG003)
            continue''',
'''    # AUDIT-FIX (Round 3, P2-2): migrated onto NSEClient + NSEPerTickerPool.
    # Replaces '0.5 neutral IV rank' silent fallback with NaN.
    from utils import NSEClient
    from utils_nse import NSEPerTickerPool, nse_parsers

    result = {}

    iv_history = _load_iv_history()
    history_updated = False

    def _fetch_one_iv(t: str):
        sym = t.replace(".NS", "").replace(".BO", "").upper()
        url = NSE_OPTIONS_URL.format(symbol=sym)
        resp = NSEClient.get(url, timeout=10)
        if resp.status_code != 200:
            return None
        data = nse_parsers.decode_nse_json(resp)
        records = data.get("records", {}).get("data", [])
        ivs = []
        for rec in records:
            for opt_type in ["CE", "PE"]:
                opt = rec.get(opt_type, {})
                iv_val = opt.get("impliedVolatility")
                if iv_val and float(iv_val) > 0:
                    ivs.append(float(iv_val))
        if not ivs:
            return None
        return float(np.median(ivs))

    per_ticker_results = NSEPerTickerPool.map_per_ticker(_fetch_one_iv, tickers)

    for t, atm_iv in per_ticker_results.items():
        if atm_iv is None:
            continue
        try:
            ticker_hist = iv_history.get(t, [])
            ticker_hist.append([today, atm_iv])
            ticker_hist = ticker_hist[-_IV_HISTORY_MAX_DAYS:]
            iv_history[t] = ticker_hist
            history_updated = True
            hist_ivs = [entry[1] for entry in ticker_hist if isinstance(entry, list) and len(entry) == 2]
            if len(hist_ivs) < 5:
                result[t] = float('nan')  # AUDIT-FIX (Round 3): NaN, not 0.5
                continue
            iv_lo  = float(min(hist_ivs))
            iv_hi  = float(max(hist_ivs))
            iv_rng = iv_hi - iv_lo
            if iv_rng < 1e-6:
                result[t] = float('nan')
                continue
            ivr = ((atm_iv - iv_lo) / iv_rng) if iv_rng != 0 else float('nan')
            result[t] = float(np.clip(ivr, 0.0, 1.0))
        except Exception as _eloop:
            import logging as _logging_mod
            _logging_mod.getLogger("quantum_annealer").debug(
                "[IV Rank] per-ticker loop failed for %s: %s", t, _eloop, exc_info=True,
            )
            continue''',
    ),
    # Patch 9: fetch_oi_buildup_signal
    (
'''    headers = {
        "User-Agent":      "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
        "Referer":         "https://www.nseindia.com",
        "Accept":          "application/json, text/plain, */*",
        "Accept-Language": "en-US,en;q=0.9",
        "Connection":      "keep-alive",
    }
    session = requests.Session()
    try:
        import threading as _threading
        if _threading.current_thread() is not _threading.main_thread():
            time.sleep(NSE_SESSION_SLEEP)  # UI001: only sleep if running in background worker thread
    except Exception as _e:  # safe: optional APScheduler job — non-fatal if scheduler not ready
        pass  # intentional — see comment above

    fo_syms = [t.replace(".NS", "").replace(".BO", "").upper() for t in tickers]
    result  = {}

    def _fetch_one(sym):
        try:
            url  = f"https://www.nseindia.com/api/quote-derivative?symbol={sym}"
            resp = session.get(url, headers=headers, timeout=12)
            if resp.status_code != 200:
                return sym, None
            jd      = resp.json()
            stocks  = jd.get("stocks", []) or []
            # Nearest-expiry stock futures
            futures = [s for s in stocks
                       if s.get("metadata", {}).get("instrumentType", "") == "Stock Futures"]
            if not futures:
                return sym, None
            futures.sort(key=lambda x: str(x.get("metadata", {}).get("expiryDate", "")))
            meta   = futures[0].get("metadata", {})
            oi_chg = float(meta.get("changeinOpenInterest", 0) or 0)
            p_chg  = float(meta.get("change", 0) or meta.get("pChange", 0) or 0)
            if   oi_chg > 0 and p_chg > 0: score = +1.0   # long buildup
            elif oi_chg > 0 and p_chg < 0: score = -1.0   # short buildup
            elif oi_chg < 0 and p_chg > 0: score = +0.3   # short covering
            elif oi_chg < 0 and p_chg < 0: score = -0.5   # long unwinding
            else:                           score =  0.0
            return sym, score
        except Exception as _e:
            return sym, None

    # Sample top 60 to stay within NSE rate limits (~6 concurrent)
    with _DaemonThreadPoolExecutor(max_workers=ConcurrencyPolicy.workers('io')) as pool:  # P2-D
        for sym, score in pool.map(_fetch_one, fo_syms[:60]):
            if score is not None:
                result[f"{sym}.NS"] = score

    if result:''',
'''    # AUDIT-FIX (Round 3, P2-2): migrated onto NSEClient + NSEPerTickerPool.
    from utils import NSEClient
    from utils_nse import NSEPerTickerPool, nse_parsers

    fo_syms = [t.replace(".NS", "").replace(".BO", "").upper() for t in tickers]
    result  = {}

    def _fetch_one(sym):
        url  = f"https://www.nseindia.com/api/quote-derivative?symbol={sym}"
        resp = NSEClient.get(url, timeout=12)
        if resp.status_code != 200:
            return sym, None
        jd      = nse_parsers.decode_nse_json(resp)
        stocks  = jd.get("stocks", []) or []
        futures = [s for s in stocks
                   if s.get("metadata", {}).get("instrumentType", "") == "Stock Futures"]
        if not futures:
            return sym, None
        futures.sort(key=lambda x: str(x.get("metadata", {}).get("expiryDate", "")))
        meta   = futures[0].get("metadata", {})
        oi_chg = float(meta.get("changeinOpenInterest", 0) or 0)
        p_chg  = float(meta.get("change", 0) or meta.get("pChange", 0) or 0)
        if   oi_chg > 0 and p_chg > 0: score = +1.0
        elif oi_chg > 0 and p_chg < 0: score = -1.0
        elif oi_chg < 0 and p_chg > 0: score = +0.3
        elif oi_chg < 0 and p_chg < 0: score = -0.5
        else:                           score =  0.0
        return sym, score

    per_sym = NSEPerTickerPool.map_per_ticker(lambda s: _fetch_one(s)[1], fo_syms)
    for sym, score in per_sym.items():
        if score is not None:
            result[f"{sym}.NS"] = score

    if result:''',
    ),
    # Patch 10: _fetch_fundamentals_live tail (0.0 -> NaN)
    (
'''        if _last_exc is not None:
            log_emit(log_cb, f"[Fundamentals] Gave up on {t} after 3 retries: {_last_exc}")
            result[t] = {"roe": 0.0, "de_ratio": 0.0, "rev_growth": 0.0, "pe_ratio": 0.0}
    return result''',
'''        if _last_exc is not None:
            log_emit(log_cb, f"[Fundamentals] Gave up on {t} after 3 retries: {_last_exc}")
            # AUDIT-FIX (Round 3, P2-2): return NaN sentinels, not 0.0
            result[t] = {"roe": float('nan'), "de_ratio": float('nan'),
                         "rev_growth": float('nan'), "pe_ratio": float('nan')}
    return result''',
    ),
    # Patch 11: _neutral_fundamentals (0.0 -> NaN)
    (
'''    def _neutral_fundamentals() -> dict:
        return {"roe": 0.0, "de_ratio": 0.0, "rev_growth": 0.0, "pe_ratio": 0.0}''',
'''    def _neutral_fundamentals() -> dict:
        # AUDIT-FIX (Round 3, P2-2): NaN sentinels instead of 0.0
        return {"roe": float('nan'), "de_ratio": float('nan'),
                "rev_growth": float('nan'), "pe_ratio": float('nan')}''',
    ),
]

for i, (old, new) in enumerate(patches, start=1):
    if old in src:
        src = src.replace(old, new, 1)
        print(f"  data_layer patch {i} applied")
    else:
        print(f"  WARNING: data_layer patch {i} not found (already applied or moved)")

open(dl_path, 'w', encoding='utf-8').write(src)

print("\n=== Step 4: except-handler sweep ===")
r = subprocess.run(["python3", f"{SCRIPTS}/sweep_except_handlers.py"], capture_output=True, text=True, check=False)  # AUDIT-FIX (Round 4 — W1510): explicit check=False
print(r.stdout[-500:])

print("\n=== Step 5: verify compile ===")
r = subprocess.run(["python3", "-m", "py_compile",
                    f"{APP}/optimizer.py", f"{APP}/utils.py", f"{APP}/data_layer.py",
                    f"{APP}/utils_nse.py", f"{APP}/optimizer_broker.py", f"{APP}/utils_chart_pipeline.py",
                    f"{APP}/web_dashboard/app.py",
                    f"{APP}/math_engine/post_screening_intelligence.py",
                    f"{APP}/ml_alpha/engine.py",
                    f"{APP}/workers/worker_threads.py",
                    f"{APP}/math_engine/prototype_bank.py",
                    ], capture_output=True, text=True, check=False)  # AUDIT-FIX (Round 4 — W1510): explicit check=False (returncode inspected below)
if r.returncode == 0:
    print("ALL FILES COMPILE CLEAN ✓")
else:
    print("COMPILE ERROR:")
    print(r.stderr)
    sys.exit(1)
