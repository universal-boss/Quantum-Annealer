#!/usr/bin/env scripts/python
"""scripts/restate_fmv_feed.py — Sec 112A(2) FMV feed restatement overlay
(R28-2) + exchange-record rebase (R31).

WHY THIS EXISTS (Round 28): the one-time Yahoo .NS pull (R28-1, chunked over
combined_universe.csv) delivered raw daily Highs for 31-Jan-2018 — but the
vendor back-adjusts historical bars for SOME post-31-Jan-2018 splits/bonuses,
and its split metadata is DEMONSTRABLY unreliable in BOTH directions
(HDFCBANK 2025 bonus really back-applied to bars; BRITANNIA's real 2021
bonus absent from metadata entirely).

R28 DISCIPLINE (kept verbatim as the fallback layer): only anchor-verified
factors applied (web-verified corporate action + clean price-band
reconciliation); every other candidate factor DISCLOSED but NOT applied —
under-restating FMV overstates tax (the accepted, disclosed error
direction); over-restating would UNDERSTATE tax (never the default);
NOTHING is invented.

R31 PROMOTION — EXECUTED (the record was delivered): the NSE 31-Jan-2018
closing-rate record (full 13-column bhavcopy capture, published Apr 2022 by
sajagonline, relayed via r.jina.ai server-side PDF extraction because every
direct egress route to the exchange archives is blocked from this
environment) now lives at qa_db/tax_fmv_31jan2018.record.json. The
promotion protocol this script implements:
  * join every feed ticker to the record (direct symbol / ISIN /
    symbol-change / verified manual rename);
  * measure the vendor divisor across THREE independent fields (record
    High/vendor High, record Close/vendor Close, record PrevClose/vendor
    30-Jan Close) — a UNIFORM divisor (spread <= 0.6%) proves the vendor
    series is a scaled version of the as-traded series, whatever the
    divisor's numeric form (clean split product or compound like RELIANCE's
    2.18739 = 2023 Jio demerger x 2024 1:1 bonus);
  * adopt the record High as the FMV for every uniform entry (the statutory
    'highest price' for Sec 112A(2) — the record IS the authority, so this
    is measurement, not invention); the divisor is disclosed for audit;
  * NON-uniform or record-uncovered tickers keep the RAW vendor High with
    the discrepancy disclosed (the conservative direction, unchanged).
Two R28 anchor verdicts were CORRECTED by the record (baked into
qa_db/tax_fmv_31jan2018.record_overlay.json):
  * RELIANCE  x2.0 -> record High 964.50 (compound divisor 2.18739);
  * HDFCBANK  x2.0 -> record High 2013.50 (divisor 3.9998 = 2019 1:2 split
    AND 2025-08-26 1:1 bonus both back-applied; the R28 '2025 never applied'
    claim was mistaken).
The record overlay also independently confirms the 228 missing tickers are
post-31-Jan-2018 IPOs / BSE-only listings / suspended names (0 ISIN hits).

R32 PROMOTION — EXECUTED (the BSE-only-listing sub-path closed): the BSE
31-Jan-2018 record was DELIVERED (finlib.in 'Fair Market Value of stocks on
31 Jan 2018 for LTCG' — a server-rendered, ISIN-tagged table of 3,527 rows
with BOTH exchange Highs + the published FMV = max(Highs), fetched DIRECT,
no relay needed; its NSE-High column was validated against the R31 sajag
NSE record: 1,657/1,657 rows EXACT — two independent captures agreeing;
scribd 433201744 independently corroborates the ACRYCIL row) and lives at
qa_db/tax_fmv_31jan2018.record_bse.json. Protocol implemented here:
  * BSE_PROMOTIONS_VERIFIED names which feed-MISSING universe ticker maps to
    which record row; the VALUE always comes from the record FILE at load
    time and the loader FAILS CLOSED on any disagreement — the registry can
    never invent or override a value;
  * CARYSIL.NS (BSE-only on 31-Jan-2018, ISIN INE482D01016 pre-split)
    promoted to the BSE record High 575.95 — the statutory Sec 112A(2)
    value. Vendor CARYSIL.BO bars are back-adjusted (575.95 / 115.19 =
    4.9996 ~= the 1:5 Rs10->Rs2 sub-division, record date 09-Jan-2019,
    which also allotted the new ISIN INE482D01024) — divisor disclosed;
  * POWERINDIA.NS RECLASSIFIED (not blocked): Hitachi Energy India Ltd
    (formerly ABB Power Products and Systems India) listed on NSE+BSE on
    30-Mar-2020 — a post-valuation-date listing; no 31-Jan-2018 quotation
    can exist, so its absence is the correct steady state (the R28/R31
    'BSE-only listing' classification was imprecise — corrected).

Files:
  qa_db/tax_fmv_31jan2018.json               final feed {ticker: fmv} (endpoint auto-load)
  qa_db/tax_fmv_31jan2018.raw.json           pristine raw pull (idempotency source)
  qa_db/tax_fmv_31jan2018.meta.json          audit: raw / restated / factor / events /
                                              candidates / missing (+ legacy notes)
  qa_db/tax_fmv_31jan2018.record.json        the delivered exchange record (R31, NSE)
  qa_db/tax_fmv_31jan2018.record_overlay.json deterministic R31 rebase decisions
  qa_db/tax_fmv_31jan2018.record_bse.json     the delivered BSE record (R32, ISIN-tagged)
  qa_db/tax_fmv_31jan2018.splits_evidence.json  (when --sweep given: the
    vendor split-event evidence + continuity classes = the promotion worklist)

Usage:
  python scripts/restate_fmv_feed.py                     # restatize in place
  python scripts/restate_fmv_feed.py --sweep <file.json> # embed candidates
  python scripts/restate_fmv_feed.py --selfcheck         # offline vectors
  python scripts/restate_fmv_feed.py --rebaseline        # raw backup := current
                                                         # feed (fresh pull)
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
import tempfile
from pathlib import Path
from typing import Dict, Optional, Tuple

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

FEED = ROOT / "qa_db" / "tax_fmv_31jan2018.json"
RAW = ROOT / "qa_db" / "tax_fmv_31jan2018.raw.json"
META = ROOT / "qa_db" / "tax_fmv_31jan2018.meta.json"
EVIDENCE = ROOT / "qa_db" / "tax_fmv_31jan2018.splits_evidence.json"
RECORD = ROOT / "qa_db" / "tax_fmv_31jan2018.record.json"
RECORD_OVERLAY = ROOT / "qa_db" / "tax_fmv_31jan2018.record_overlay.json"
BSE_RECORD = ROOT / "qa_db" / "tax_fmv_31jan2018.record_bse.json"

# Anchor-verified restatement factors (R28, 2026-09-12) — LEGACY LAYER.
# Each factor was the VENDOR DIVISOR measured against the then-believed
# real-world 31-Jan-2018 as-traded High band, corroborated by a web-verified
# corporate action. The R31 exchange record SUPERSEDES this layer wherever
# it covers the ticker (see qa_db/tax_fmv_31jan2018.record_overlay.json):
# it confirmed TCS/INFY/BPCL/TORNTPHARM/HCLTECH (x2 exact) and ITC (raw,
# modulo a uniform 1.0385 vendor scaling), and CORRECTED RELIANCE and
# HDFCBANK (record Highs 964.50 / 2013.50 — compound divisors 2.18739 and
# 3.9998). This registry remains the fallback for record-uncovered tickers.
VERIFIED_FACTORS: Dict[str, dict] = {
    "RELIANCE.NS": {
        "factor": 2.0,
        "events": [("2024-10-28", 2.0)],
        "provenance": ("RIL 1:1 bonus ex 2024-10-28 (web-confirmed); R28 raw "
                       "440.94 x 2 = 881.88 — SUPERSEDED by the R31 record "
                       "rebase (record High 964.50, compound divisor 2.18739 "
                       "= 2023 Jio demerger x 2024 bonus); kept as the "
                       "record-uncovered fallback only"),
    },
    "TCS.NS": {
        "factor": 2.0,
        "events": [("2018-05-31", 2.0)],
        "provenance": ("TCS 1:1 bonus ex 2018-05-31 (web-confirmed); raw "
                       "1575.0 x 2 = 3150.0 — record-CONFIRMED exact (R31: "
                       "record High 3150.0, divisor 2.0 uniform)"),
    },
    "INFY.NS": {
        "factor": 2.0,
        "events": [("2018-09-04", 2.0)],
        "provenance": ("Infosys 1:1 bonus ex 2018-09-04 (web-confirmed); raw "
                       "583.30 x 2 = 1166.60 — record-CONFIRMED exact (R31: "
                       "record High 1166.6, divisor 2.0 uniform)"),
    },
    "HDFCBANK.NS": {
        "factor": 2.0,
        "events": [("2019-09-19", 2.0)],
        "excluded_events": [
            ("2025-08-26", 2.0,
             "1:1 bonus REAL (web-confirmed). R28 believed it was never "
             "applied to historical bars and excluded it fearing it would "
             "UNDERSTATE tax; the R31 exchange record PROVES the vendor DID "
             "back-apply it (divisor 3.9998 = 2019 split x 2025 bonus; "
             "record High 2013.50) — the exclusion was mistaken and is "
             "superseded by the record rebase"),
        ],
        "provenance": ("1:2 split ex 2019-09-19 (web-confirmed); raw 503.38 "
                       "x 2 = 1006.76 — SUPERSEDED by the R31 record rebase "
                       "(record High 2013.50, divisor 3.9998)"),
    },
    "ITC.NS": {
        "factor": 1.0,
        "events": [],
        "provenance": ("no post-31-Jan-2018 split/bonus (web + vendor "
                       "metadata agree); raw 265.76 as-traded — R31 record: "
                       "High 276.0 (uniform vendor scaling 1.0385; record "
                       "High adopted as the statutory value)"),
    },
    "BPCL.NS": {
        "factor": 2.0,
        "events": [("2024-06-21", 2.0)],
        "provenance": ("BPCL 1:1 bonus ex 2024-06-21 (web-confirmed); raw "
                       "246.80 x 2 = 493.60 — record-CONFIRMED exact (R31: "
                       "record High 493.6, divisor 2.0 uniform)"),
    },
    "TORNTPHARM.NS": {
        "factor": 2.0,
        "events": [("2022-07-08", 2.0)],
        "provenance": ("Torrent Pharma face-value split 10->5 ex 2022-07-08 "
                       "(web-confirmed); raw 684.97 x 2 = 1369.94 — record-"
                       "CONFIRMED exact (R31: record High 1369.95, divisor "
                       "2.0 uniform)"),
    },
    "HCLTECH.NS": {
        "factor": 2.0,
        "events": [("2019-12-05", 2.0)],
        "provenance": ("HCL Technologies 1:1 bonus ex 2019-12-05 "
                       "(web-confirmed); raw 508.95 x 2 = 1017.90 — record-"
                       "CONFIRMED exact (R31: record High 1017.9, divisor "
                       "2.0 uniform)"),
    },
}

# Legacy symbols tried during the R28 pull and DROPPED by the vendor (no
# pre-rename history exists) — recorded so the missing list is explained.
# R32 notes: CARYSIL.NS is RESOLVED (promoted from the delivered BSE record);
# POWERINDIA.NS is RECLASSIFIED (a 2020 listing, dual NSE+BSE — nothing to
# capture: no 31-Jan-2018 quotation can exist).
LEGACY_RETIRED: Dict[str, str] = {
    "CARYSIL.NS": ("renamed from ACRYSIL; legacy symbol ACRYSIL.NS tried "
                   "in the R28 pull — vendor returns no data (retired). "
                   "BSE-only listing on 31-Jan-2018 — RESOLVED in R32: "
                   "promoted from the BSE 31-Jan-2018 record (finlib "
                   "capture, ISIN INE482D01016, ACRYCIL LTD., High 575.95; "
                   "scribd-corroborated; vendor divisor 4.9996 = the 2019 "
                   "1:5 Rs10->Rs2 sub-division back-applied to CARYSIL.BO "
                   "bars — record value adopted, divisor disclosed)"),
    "POWERINDIA.NS": ("Hitachi Energy India Ltd (formerly ABB Power "
                      "Products and Systems India Ltd). Legacy symbols "
                      "ABBPPS.NS / HITACHIENERGY.NS tried in the R28 pull — "
                      "vendor returns no data. RECLASSIFIED in R32: the "
                      "company listed on NSE+BSE on 30-Mar-2020 (demerger "
                      "listing; first vendor bar 2020-03-30) — a POST-"
                      "valuation-date listing, dual-listed, not BSE-only and "
                      "not egress-blocked: no 31-Jan-2018 quotation can "
                      "exist. Correct steady state (same class as the "
                      "post-2018 IPOs)"),
}

# R32 — BSE-record promotions (the BSE-only-listing sub-path closure). The
# delivered BSE record (finlib capture: 3,527 ISIN-tagged rows; NSE column
# verified 1,657/1,657 EXACT vs the R31 sajag NSE record — two independent
# captures agreeing; scribd 433201744 independently corroborates the
# ACRYCIL row) is the AUTHORITY. This registry only names which feed-missing
# universe ticker maps to which record row; the VALUE always comes from the
# record file at load time and the loader fails closed on any disagreement
# — the registry can never invent or override a value.
BSE_PROMOTIONS_VERIFIED: Dict[str, dict] = {
    "CARYSIL.NS": {
        "record_isin": "INE482D01016",   # the 2018 pre-split security (Acrysil India Ltd)
        "bse_name": "ACRYCIL LTD.",
        "expect_fmv": 575.95,            # scribd 433201744: 'ACRYCIL LTD. 31/1/2018 BSE 575.95'
        "current_isin": "INE482D01024",  # post-2019 sub-division ISIN (Carysil Ltd)
        "note": ("BSE-only listing on 31-Jan-2018 (no NSE symbol; absent "
                 "from the R31 NSE record by construction). BSE High "
                 "575.95 = the statutory Sec 112A(2) highest price. Vendor "
                 "CARYSIL.BO bars are back-adjusted: 575.95 / 115.19 = "
                 "4.9996 ~= the 1:5 sub-division (Rs10 -> Rs2, record date "
                 "09-Jan-2019, ex 10-Jan-2019; a new ISIN was allotted) — "
                 "divisor disclosed, record value adopted"),
    },
}


def apply_restatement(
    raw_feed: Dict[str, float],
    verified: Optional[Dict[str, dict]] = None,
    sweep: Optional[dict] = None,
    record_overlay: Optional[dict] = None,
    bse_promotions: Optional[Dict[str, dict]] = None,
) -> Tuple[Dict[str, float], Dict[str, dict]]:
    """PURE: (final_feed, per_ticker_meta).

    R31 precedence: record_overlay (exchange-record High — the statutory
    value) > verified factor (R28 anchor layer) > raw. Unverified candidate
    factors remain DISCLOSED ONLY (never applied by default — the
    conservative direction).

    R32 addition: `bse_promotions` (loaded+gated from the BSE record via
    _load_bse_promotions) ADDS feed-MISSING tickers (BSE-only listings)
    at their record High — a promotion, never an override: tickers that
    exist in raw_feed stay under the precedence chain above.
    """
    verified = verified if verified is not None else VERIFIED_FACTORS
    final: Dict[str, float] = {}
    meta: Dict[str, dict] = {}
    for tk, raw in raw_feed.items():
        if not isinstance(raw, (int, float)) or not (float(raw) > 0):
            # never touch non-numeric / non-positive rows
            final[tk] = raw
            meta[tk] = {"raw": raw, "restated": None, "factor": None,
                        "provenance": "non-numeric/non-positive row kept as-is"}
            continue
        rec: dict = {"raw": raw}
        ro = (record_overlay or {}).get(tk)
        v = (verified or {}).get(tk)
        if ro and isinstance(ro.get("fmv"), (int, float)) and float(ro["fmv"]) > 0:
            fmv = round(float(ro["fmv"]), 2)
            final[tk] = fmv
            rec.update({"restated": fmv, "factor": ro.get("divisor"),
                        "record_rebased": True,
                        "record_symbol": ro.get("record_symbol"),
                        "record_series": ro.get("record_series"),
                        "record_isin": ro.get("record_isin"),
                        "record_join": ro.get("join"),
                        "uniformity_spread_pct": ro.get("uniformity_spread_pct"),
                        "provenance": (ro.get("reason") or "") +
                                      " [record: " + str(ro.get("record_symbol")) +
                                      " High " + str(fmv) + ", source " +
                                      "qa_db/tax_fmv_31jan2018.record.json]"})
        elif v and isinstance(v.get("factor"), (int, float)) and float(v["factor"]) > 0:
            f = float(v["factor"])
            restated = round(float(raw) * f, 2)
            final[tk] = restated
            rec.update({"restated": restated, "factor": f,
                        "provenance": v.get("provenance", ""),
                        "events": [list(e) if isinstance(e, tuple) else e
                                   for e in v.get("events", [])],
                        "excluded_events": [list(e) if isinstance(e, tuple) else e
                                            for e in v.get("excluded_events", [])]})
        else:
            final[tk] = raw
            rec.update({"restated": None, "factor": None,
                        "provenance": ("raw Yahoo .NS High (no anchor-verified "
                                       "factor; candidate disclosed, NOT applied — "
                                       "conservative direction)")})
        if sweep and tk in sweep:
            s = sweep[tk] or {}
            rec["candidate_evidence"] = {
                "post_valuation_events": s.get("post_valuation_events", []),
                "candidate_factor": s.get("candidate_factor"),
                "note": ("vendor split-metadata candidate; metadata is "
                         "demonstrably unreliable (see report) — verify "
                         "against the exchange record before promoting"),
            }
        meta[tk] = rec

    # R32: BSE-record promotions — ADD feed-missing tickers (BSE-only
    # listings) at their record High. Promotion only, never an override:
    # anything already in raw_feed stays under the precedence chain above.
    for tk, pr in (bse_promotions or {}).items():
        if tk in raw_feed:
            continue
        fmv = round(float(pr["fmv"]), 2)
        final[tk] = fmv
        meta[tk] = {
            "raw": None,
            "restated": fmv,
            "factor": None,
            "bse_record_promoted": True,
            "record_isin": pr.get("record_isin"),
            "bse_name": pr.get("bse_name"),
            "record_date": pr.get("record_date"),
            "bse_high": pr.get("bse_high"),
            "provenance": ("BSE-record promotion (R32): feed-missing BSE-only "
                           "listing resolved from the delivered BSE 31-Jan-2018 "
                           "record (qa_db/tax_fmv_31jan2018.record_bse.json; "
                           "ISIN " + str(pr.get("record_isin")) + ", High "
                           + str(fmv) + " — the statutory Sec 112A(2) value; "
                           "NSE column cross-validated 1,657/1,657 exact vs "
                           "the R31 sajag NSE record; scribd-corroborated). "
                           + str(pr.get("note") or "")),
        }
    return final, meta


def _atomic_write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(obj, f, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except Exception:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


def _load_record_overlay() -> Optional[dict]:
    if not RECORD_OVERLAY.exists():
        return None
    try:
        doc = json.loads(RECORD_OVERLAY.read_text(encoding="utf-8"))
    except Exception:
        return None
    ov = doc.get("overlay")
    return ov if isinstance(ov, dict) and ov else None


def _load_bse_promotions() -> Tuple[Dict[str, dict], dict]:
    """Load + GATE the BSE-record promotions (R32, fail-closed).

    Returns (promotions, audit). promotions is {} unless EVERY gate passes:
      * the record file exists and its own validation gates passed
        (G1: the finlib NSE-High column vs the R31 sajag NSE record —
        exact-match rate >= 0.99 on >= 1000 joined rows — two independent
        captures agreeing is what makes the BSE column trustworthy);
      * every registry entry matches a record row EXACTLY (ISIN, BSE name,
        FMV, BSE-only: no NSE symbol, applicable date 31/01/18).
    The registry names the mapping; the FILE supplies the value — nothing
    can be invented or overridden through this path.
    """
    audit: dict = {"record_file": "qa_db/tax_fmv_31jan2018.record_bse.json",
                   "loaded": False, "gates": {}}
    if not BSE_RECORD.exists():
        audit["gates"] = {"file_exists": False}
        return {}, audit
    try:
        doc = json.loads(BSE_RECORD.read_text(encoding="utf-8"))
    except Exception as e:
        audit["gates"] = {"file_exists": True, "parse_error": str(e)[:200]}
        return {}, audit
    gates = (doc.get("validation") or {}).get("gates") or {}
    audit["gates"] = {
        "file_exists": True,
        "rows": (doc.get("stats") or {}).get("rows"),
        "G1_nse_vs_record_exact_rate": gates.get("G1_nse_vs_record_exact_rate"),
        "G1_joined": gates.get("G1_joined"),
        "G1_exact": gates.get("G1_exact"),
        "G5_powerindia_rows": gates.get("G5_powerindia_rows"),
    }
    if not (gates.get("passed") is True
            and (gates.get("G1_nse_vs_record_exact_rate") or 0.0) >= 0.99
            and (gates.get("G1_joined") or 0) >= 1000):
        return {}, audit
    rows = {(r.get("isin") or ""): r for r in doc.get("rows") or []}
    promos: Dict[str, dict] = {}
    for tk, reg in BSE_PROMOTIONS_VERIFIED.items():
        r = rows.get(reg.get("record_isin") or "")
        if not r:
            audit["gates"][f"row_missing:{tk}"] = reg.get("record_isin")
            continue
        if (r.get("bse_name") != reg.get("bse_name")
                or r.get("nse_symbol")
                or r.get("date") != "31/01/18"
                or abs(float(r.get("fmv") or 0.0)
                       - float(reg["expect_fmv"])) > 0.005):
            audit["gates"][f"row_mismatch:{tk}"] = {
                "file_row": {k: r.get(k) for k in
                             ("bse_name", "fmv", "nse_symbol", "date")}}
            continue
        promos[tk] = {
            "fmv": round(float(r["fmv"]), 2),
            "record_isin": r.get("isin"),
            "bse_name": r.get("bse_name"),
            "record_date": "2018-01-31",
            "bse_high": r.get("bse_high"),
            "note": reg.get("note"),
        }
    audit["loaded"] = bool(promos)
    audit["promoted_tickers"] = sorted(promos)
    return promos, audit


def _selfcheck() -> int:
    ok = True

    def check(label, got, want):
        nonlocal ok
        status = "PASS" if got == want else "FAIL"
        if got != want:
            ok = False
        print(f"[selfcheck] {label}: {got} (expected {want}) -> {status}")

    # 1. verified factor applies (R28 legacy layer, unchanged)
    final, meta = apply_restatement(
        {"AAA.NS": 100.0}, verified={"AAA.NS": {"factor": 2.0,
                                                "provenance": "x"}})
    check("verified x2", (final["AAA.NS"], meta["AAA.NS"]["restated"]),
          (200.0, 200.0))
    # 2. unverified stays raw (conservative; candidate disclosed only)
    final, meta = apply_restatement({"BBB.NS": 100.0})
    check("unverified raw", final["BBB.NS"], 100.0)
    check("unverified no-factor", meta["BBB.NS"]["factor"], None)
    # 3. PHANTOM EXCLUSION (the HDFCBANK discipline): metadata candidate x4
    #    (two continuous events) but verified x2 -> final is raw x 2, NOT x 4
    final, meta = apply_restatement(
        {"HDFCBANK.NS": 503.38},
        verified={"HDFCBANK.NS": {"factor": 2.0, "provenance": "x"}},
        sweep={"HDFCBANK.NS": {"post_valuation_events": [
            {"date": "2019-09-19", "ratio": 2.0,
             "class": "continuous(restamped-or-phantom)"},
            {"date": "2025-08-26", "ratio": 2.0,
             "class": "continuous(restamped-or-phantom)"}],
            "candidate_factor": 4.0}})
    check("phantom-excluded restated", final["HDFCBANK.NS"], 1006.76)
    check("candidate disclosed not applied",
          meta["HDFCBANK.NS"]["candidate_evidence"]["candidate_factor"], 4.0)
    # 4. non-positive guard
    final, _ = apply_restatement({"CCC.NS": -1.0})
    check("non-positive untouched", final["CCC.NS"], -1.0)
    # 5. idempotency by construction: re-applying on RAW gives the same final
    f1, _ = apply_restatement({"AAA.NS": 100.0},
                              verified={"AAA.NS": {"factor": 2.0}})
    f2, _ = apply_restatement({"AAA.NS": 100.0},
                              verified={"AAA.NS": {"factor": 2.0}})
    check("idempotent (from raw)", f1 == f2, True)
    # 6. R31 record overlay PRECEDENCE: the record High wins over the legacy
    #    verified factor AND over raw (the HDFCBANK correction)
    final, meta = apply_restatement(
        {"HDFCBANK.NS": 503.38},
        verified={"HDFCBANK.NS": {"factor": 2.0, "provenance": "x"}},
        record_overlay={"HDFCBANK.NS": {"fmv": 2013.5, "divisor": 3.9998,
                                        "record_symbol": "HDFCBANK",
                                        "reason": "record uniform"}})
    check("record-rebased HDFCBANK", final["HDFCBANK.NS"], 2013.5)
    check("record-rebased flag", meta["HDFCBANK.NS"]["record_rebased"], True)
    check("record divisor disclosed", meta["HDFCBANK.NS"]["factor"], 3.9998)
    # 7. record overlay only applies to covered tickers; others fall through
    final, _ = apply_restatement(
        {"AAA.NS": 100.0, "BBB.NS": 100.0},
        verified={"AAA.NS": {"factor": 2.0}},
        record_overlay={"BBB.NS": {"fmv": 276.0, "divisor": 1.03851}})
    check("covered-rebased", final["BBB.NS"], 276.0)
    check("uncovered-legacy-path", final["AAA.NS"], 200.0)
    # 8. R32: a BSE-record promotion ADDS a feed-missing ticker at its
    #    record High with full provenance (the CARYSIL sub-path closure)
    final, meta = apply_restatement(
        {"AAA.NS": 100.0},
        bse_promotions={"CARYSIL.NS": {"fmv": 575.95,
                                        "record_isin": "INE482D01016",
                                        "bse_name": "ACRYCIL LTD.",
                                        "record_date": "2018-01-31",
                                        "bse_high": 575.95, "note": "x"}})
    check("bse-promoted missing added", final.get("CARYSIL.NS"), 575.95)
    check("bse-promoted flag", meta["CARYSIL.NS"]["bse_record_promoted"], True)
    check("bse-promoted raw is None", meta["CARYSIL.NS"]["raw"], None)
    check("bse-promoted isin disclosed", meta["CARYSIL.NS"]["record_isin"],
          "INE482D01016")
    # 9. R32: a promotion NEVER overrides an already-pulled ticker (the
    #    precedence chain governs anything present in raw)
    final, _ = apply_restatement(
        {"CARYSIL.NS": 111.22},
        bse_promotions={"CARYSIL.NS": {"fmv": 575.95}})
    check("bse-promotion no-override", final["CARYSIL.NS"], 111.22)
    # 10. R32: promotions are deterministic/idempotent (registry+file driven)
    promo = {"ZZZ.NS": {"fmv": 575.95}}
    f1, _ = apply_restatement({}, bse_promotions=promo)
    f2, _ = apply_restatement({}, bse_promotions=promo)
    check("bse-promotion idempotent", f1 == f2 and f1["ZZZ.NS"] == 575.95, True)
    print("[selfcheck] " + ("ALL PASS" if ok else "FAILURES PRESENT"))
    return 0 if ok else 1


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--sweep", default=None,
                    help="fmv_splits_sweep.json (vendor event evidence) to embed "
                         "as candidate factors + copy into qa_db")
    ap.add_argument("--selfcheck", action="store_true")
    ap.add_argument("--rebaseline", action="store_true",
                    help="raw backup := current feed (use after a fresh pull)")
    args = ap.parse_args()
    if args.selfcheck:
        return _selfcheck()

    if not FEED.exists():
        print(f"[FMV-restate] no feed at {FEED} — run scripts/build_tax_fmv_feed.py "
              f"first (or the R28 chunked pull). Nothing to do.")
        return 1

    # idempotency: derive from the pristine raw backup
    if args.rebaseline or not RAW.exists():
        shutil.copyfile(FEED, RAW)
        print(f"[FMV-restate] raw baseline written -> {RAW}")
    raw_feed = json.loads(RAW.read_text(encoding="utf-8"))

    sweep = None
    if args.sweep:
        sweep = json.loads(Path(args.sweep).read_text(encoding="utf-8"))

    record_overlay = _load_record_overlay()
    if record_overlay is None:
        print("[FMV-restate] no record overlay at "
              f"{RECORD_OVERLAY} — R28 legacy layer only")

    # R32: load + gate the BSE-record promotions (fail-closed: {} unless the
    # finlib capture's validation gates passed AND every registry entry
    # matches its record row exactly — see _load_bse_promotions)
    bse_promotions, bse_audit = _load_bse_promotions()
    if not bse_promotions:
        print("[FMV-restate] BSE-record promotions NOT loaded — R32 layer "
              f"inactive (gates: {json.dumps(bse_audit.get('gates'))[:300]})")

    final, per_ticker = apply_restatement(raw_feed, VERIFIED_FACTORS, sweep,
                                          record_overlay, bse_promotions)

    # carry the pull meta's shape (valuation_date / resolved / missing ...)
    pull_meta = {}
    if META.exists():
        try:
            pull_meta = json.loads(META.read_text(encoding="utf-8"))
        except Exception:
            pull_meta = {}
    missing = pull_meta.get("missing", [])
    resolved = {}
    for tk, rec in per_ticker.items():
        as_of = ((pull_meta.get("resolved") or {}).get(tk) or {}).get("as_of_date")
        if as_of is None and rec.get("bse_record_promoted"):
            as_of = rec.get("record_date")  # the BSE record's own applicable date
        resolved[tk] = {"fmv": final[tk], "as_of_date": as_of, **rec}
    n_rebased = sum(1 for r in per_ticker.values() if r.get("record_rebased"))
    n_legacy = sum(1 for r in per_ticker.values()
                   if r.get("restated") is not None and not r.get("record_rebased"))
    n_cand = sum(1 for r in per_ticker.values()
                 if (r.get("candidate_evidence") or {}).get("candidate_factor"))
    n_bse = sum(1 for r in per_ticker.values() if r.get("bse_record_promoted"))
    missing_after = [m for m in missing if str(m) not in final]

    record_block = {}
    if RECORD_OVERLAY.exists():
        try:
            ro_doc = json.loads(RECORD_OVERLAY.read_text(encoding="utf-8"))
            record_block = {
                "record_file": "qa_db/tax_fmv_31jan2018.record.json",
                "source": ro_doc.get("provenance"),
                "rebased_tickers": n_rebased,
                "keep_raw_disclosed": ro_doc.get("keep_raw_disclosed"),
                "anchor_corrections": ro_doc.get("anchor_corrections"),
                "missing_228_confirmation": ro_doc.get("missing_228_confirmation"),
                "method": ro_doc.get("method"),
            }
        except Exception:
            record_block = {}

    meta_out = {
        "valuation_date": "2018-01-31",
        "max_lookback_days": pull_meta.get("max_lookback_days", 7),
        "source": ("Yahoo Finance .NS daily High (R28 one-time pull) + "
                   "anchor-verified restatement overlay (R28-2) + exchange-"
                   "record rebase (R31: NSE 31-Jan-2018 closing-rate capture, "
                   "qa_db/tax_fmv_31jan2018.record.json) + BSE-record "
                   "promotion (R32: finlib ISIN-tagged capture, "
                   "qa_db/tax_fmv_31jan2018.record_bse.json — feed-MISSING "
                   "BSE-only listings added at their record High); see "
                   "scripts/restate_fmv_feed.py"),
        "resolved": resolved,
        "missing": missing_after,
        "missing_before_r32": len(missing),
        "bse_record_promoted_removed_from_missing": sorted(
            str(m) for m in missing if str(m) not in missing_after),
        "missing_notes": LEGACY_RETIRED,
        "universe_size": pull_meta.get("universe_size"),
        "restatement": {
            "verified_tickers": n_rebased + n_legacy,
            "candidate_disclosed_tickers": n_cand,
            "discipline": ("only record-rebased or anchor-verified factors "
                           "applied (exchange-record High / web-verified event + "
                           "clean price-band reconciliation); all other "
                           "candidate factors DISCLOSED but NOT applied — "
                           "under-restating FMV overstates tax (conservative, "
                           "disclosed); over-restating would UNDERSTATE tax "
                           "(never the default); NOTHING is invented"),
            "vendor_unreliability_evidence": (
                "HDFCBANK 2025-08-26 bonus really back-applied to bars "
                "(R31 record: divisor 3.9998 — R28's exclusion was mistaken); "
                "BRITANNIA 2021-04-25 bonus real (web) but absent from vendor "
                "metadata; GLAXO/BRITANNIA raw values do not reconcile to clean "
                "divisors — the R31 record resolves these by direct measurement "
                "(record High adopted wherever the divisor is uniform)"),
            "promotion_path": ("EXECUTED in R31 — the NSE/BSE 31-Jan-2018 "
                               "record was delivered (sajag secondary capture "
                               "relayed via r.jina.ai; local egress to the "
                               "exchange archives remains 403/TCP-blocked). "
                               "qa_db/tax_fmv_31jan2018.record_overlay.json "
                               "drives the rebase; re-running this script is "
                               "idempotent from the raw backup"),
        },
        "record_restatement": record_block,
        "bse_record_restatement": {
            "record_file": "qa_db/tax_fmv_31jan2018.record_bse.json",
            "source": ("finlib.in 'Fair Market Value of stocks on 31 Jan "
                       "2018 for LTCG' (https://finlib.in/fair-market-value-"
                       "31-jan-2018/), server-rendered WordPress table, "
                       "DIRECT fetch (R32); columns: ISIN, BSE Name, NSE "
                       "Symbol, Applicable date, High BSE, High NSE, FMV"),
            "validation": ("NSE-High column joined to the R31 sajag NSE "
                           "record by ISIN/symbol: 1,657/1,657 EXACT — two "
                           "independent captures agreeing; FMV == max("
                           "available Highs) on 3,527/3,527 rows; all ISIN "
                           "check-digits valid; POWERINDIA/HITACHI absent "
                           "(listed 2020-03-30 — no 31-Jan-2018 quotation "
                           "can exist); ACRYCIL row corroborated "
                           "independently by scribd 433201744"),
            "promoted_tickers": sorted(bse_promotions),
            "promoted": n_bse,
            "gates_audit": bse_audit,
            "powerindia_reclassification": (
                "POWERINDIA.NS = Hitachi Energy India Ltd (formerly ABB "
                "Power Products and Systems India Ltd), listed NSE+BSE "
                "2020-03-30 — POST-valuation-date listing, dual-listed: no "
                "31-Jan-2018 quotation can exist. Its feed absence is the "
                "correct steady state (same class as the post-2018 IPOs); "
                "the earlier 'BSE-only listing, egress-blocked' class was "
                "imprecise and is corrected here."),
        },
        "note": pull_meta.get("note"),
    }
    _atomic_write_json(FEED, final)
    _atomic_write_json(META, meta_out)
    if sweep is not None:
        _atomic_write_json(EVIDENCE, sweep)
        print(f"[FMV-restate] evidence copied -> {EVIDENCE}")
    print(f"[FMV-restate] feed: {len(final)} tickers "
          f"({n_rebased} record-rebased [R31], {n_legacy} legacy-verified, "
          f"{n_bse} BSE-record-promoted [R32], "
          f"{n_cand} candidates disclosed-not-applied) -> {FEED}")
    print(f"[FMV-restate] meta -> {META}")
    print(f"[FMV-restate] raw backup -> {RAW}")
    print(f"[FMV-restate] missing: {len(missing)} -> {len(missing_after)} "
          f"(BSE-record promotions removed: "
          f"{sorted(str(m) for m in missing if str(m) not in missing_after)})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
