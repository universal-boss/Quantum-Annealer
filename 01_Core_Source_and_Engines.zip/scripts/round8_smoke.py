"""Round 8 wiring functional smoke test — synthetic data per wiring site."""
from __future__ import annotations
import sys, os, math, warnings
import numpy as np
import pandas as pd

PROJECT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT not in sys.path:
    sys.path.insert(0, PROJECT)

warnings.filterwarnings("ignore")  # suppress pyparsing deprecation noise etc.

from optimizer_risk_institutional import (
    apply_herc_weights, price_option_qmc_lsmc, detect_cointegrated_pairs,
    detect_copula_pairs, forecast_volatility_msm, conditional_var_es,
    multivariate_var_es, apply_cdar_constraint,
    detect_regime_changepoints, cpcv_backtest_distribution,
)

rng = np.random.default_rng(42)
results = {}

# Inverse standard-normal CDF (ppf) helper for Clayton copula sampling
from scipy.stats import norm
norm_ppf = norm.ppf

# ─── R8-1 HERC ────────────────────────────────────────────────────────────
try:
    n_days, n_assets = 250, 5
    R = pd.DataFrame(rng.normal(0, 0.01, (n_days, n_assets)),
                    columns=["RELIANCE", "TCS", "INFY", "HDFCBANK", "ICICIBANK"])
    res = apply_herc_weights(R, method="ward")
    assert res["source"] == "herc", f"unexpected source: {res['source']}"
    w = res["weights"]
    assert abs(sum(w.values()) - 1.0) < 1e-6, f"weights not normalized: {sum(w.values())}"
    assert all(0 <= v <= 0.30 + 1e-6 for v in w.values()), f"max_weight violated: {w}"
    results["R8-1 HERC"] = f"PASS  weights={list(w.values())[:3]}...  source={res['source']}"
except Exception as e:
    results["R8-1 HERC"] = f"FAIL  {e}"

# ─── R8-2 QMC-LSMC ─────────────────────────────────────────────────────────
try:
    # Price a 1-year ATM put, σ=30%, r=7%, S=100, K=100
    res = price_option_qmc_lsmc(S0=100.0, K=100.0, r=0.07, sigma=0.30, T=1.0,
                                  n_paths=2048, n_steps=30, option_type="put")
    px = res["price"]
    # BS analytic reference (BS-put for ATM 1y @ 30% vol, 7% r):
    # d1 = (log(100/100) + (0.07 + 0.045)*1) / (0.30*1) = 0.3833
    # d2 = 0.3833 - 0.30 = 0.0833
    # Phi(-d1) = Phi(-0.3833) = 0.3491, Phi(-d2) = Phi(-0.0833) = 0.4668
    # put = 100*e^-0.07 * 0.4668 - 100 * 0.3491 = 43.51 - 34.91 = 8.60
    bs_put = 100 * math.exp(-0.07) * 0.4668 - 100 * 0.3491
    assert res["source"] == "qmc_lsmc", f"unexpected source: {res['source']}"
    assert 3.0 < px < 18.0, f"price {px} not in expected range ~8.6"
    results["R8-2 QMC-LSMC"] = f"PASS  put_price={px:.4f}  BS_ref={bs_put:.4f}  source={res['source']}"
except Exception as e:
    results["R8-2 QMC-LSMC"] = f"FAIL  {e}"

# ─── R8-3 Kalman Cointegration ─────────────────────────────────────────────
try:
    n = 500
    x = np.cumsum(rng.normal(0, 0.01, n)) + 100.0
    # Construct y as cointegrated: y = 2.0 * x + N(0, 0.5) noise (genuine cointegration)
    y = 2.0 * x + rng.normal(0, 0.5, n)
    pdf = pd.DataFrame({"X": x, "Y": y})
    res = detect_cointegrated_pairs(pdf, min_history=250, max_pairs=5)
    assert res["source"] in ("kalman_cointegration", "fallback_empty"), res["source"]
    n_pairs = len(res["pairs"])
    assert n_pairs >= 1, f"expected ≥1 coint pair, got {n_pairs}"
    results["R8-3 Kalman-Coint"] = f"PASS  tested={res['n_tested']}  found={n_pairs}  source={res['source']}"
except Exception as e:
    results["R8-3 Kalman-Coint"] = f"FAIL  {e}"

# ─── R8-4 Copula Stat-Arb ─────────────────────────────────────────────────
try:
    n = 500
    # Clayton-coupled uniforms → genuine lower-tail dependence
    theta = 4.0
    u1 = rng.uniform(0.01, 0.99, n)
    v_raw = rng.uniform(0.01, 0.99, n)
    # Generate v from Clayton conditional: v = ((1 + u^(-theta)*(t^(-1/(theta+1)) - 1))^(-1/theta)
    # Simplified: use the inverse-CDF Clayton copula sampler
    t = v_raw
    v = (1 + u1 ** (-theta) * (t ** (-1.0 / (theta + 1.0)) - 1.0)) ** (-1.0 / theta)
    # Convert to returns-like prices
    x = pd.Series(np.cumsum(norm_ppf(u1)) * 0.01 + 100.0)
    y = pd.Series(np.cumsum(norm_ppf(v)) * 0.01 + 100.0)
    pdf = pd.DataFrame({"X": x, "Y": y})
    res = detect_copula_pairs(pdf, min_lambda=0.05, min_history=250, max_pairs=5)
    assert res["source"] in ("copula_stat_arb", "fallback_empty"), res["source"]
    results["R8-4 Copula-StatArb"] = f"PASS  tested={res['n_tested']}  found={len(res['pairs'])}  source={res['source']}"
except Exception as e:
    results["R8-4 Copula-StatArb"] = f"FAIL  {e}"

# ─── R8-5 MSM Volatility ──────────────────────────────────────────────────
try:
    n = 500
    # Synthetic vol regime: low vol for first 250, high vol for next 250
    sig = np.where(np.arange(n) < 250, 0.005, 0.030)
    r = pd.Series(rng.normal(0, sig))
    res = forecast_volatility_msm(r, horizon=22)
    assert res["source"] == "msm", f"unexpected source: {res['source']}"
    assert 5.0 < res["vol_forecast"] < 80.0, f"vol_forecast {res['vol_forecast']} out of expected range"
    results["R8-5 MSM-Vol"] = f"PASS  vol_fcst={res['vol_forecast']:.2f}%  regime={res['regime']}  source={res['source']}"
except Exception as e:
    results["R8-5 MSM-Vol"] = f"FAIL  {e}"

# ─── R8-6 Conditional EVT ────────────────────────────────────────────────
try:
    n = 500
    # Student-t (df=4) returns: heavy-tailed → GPD should fit well
    r = pd.Series(rng.standard_t(4, n) * 0.01)
    res = conditional_var_es(r, alpha=0.99, portfolio_value=1_000_000.0)
    assert res["source"] == "conditional_evt", f"unexpected source: {res['source']}"
    assert 0.01 < res["var_pct"] < 0.20, f"VaR {res['var_pct']} out of range"
    assert res["es_pct"] >= res["var_pct"], "ES should be ≥ VaR"
    results["R8-6 Cond-EVT"] = (
        f"PASS  VaR={res['var_pct']*100:.2f}%  ES={res['es_pct']*100:.2f}%  "
        f"xi={res['xi']:.3f}  source={res['source']}"
    )
except Exception as e:
    results["R8-6 Cond-EVT"] = f"FAIL  {e}"

# ─── R8-7 FHS-DCC-GARCH ──────────────────────────────────────────────────
try:
    n_days, n_assets = 300, 3
    # Mildly correlated returns
    cov = np.array([[1.0, 0.3, 0.1], [0.3, 1.0, 0.2], [0.1, 0.2, 1.0]]) * 0.0001
    R = pd.DataFrame(rng.multivariate_normal([0, 0, 0], cov, n_days),
                    columns=["A", "B", "C"])
    w = np.array([0.4, 0.35, 0.25])
    res = multivariate_var_es(R, w, alpha=0.99, n_sim=2000, horizon=1, portfolio_value=1_000_000.0)
    src = res["source"]
    if src == "fhs_dcc_garch":
        assert res["var_pct"] > 0, f"VaR {res['var_pct']} should be positive"
        assert res["es_pct"] >= res["var_pct"]
        results["R8-7 FHS-DCC-GARCH"] = (
            f"PASS  VaR={res['var_pct']*100:.2f}%  ES={res['es_pct']*100:.2f}%  "
            f"corr_shape={res['dcc_corr_latest'].shape}  source={src}"
        )
    else:
        results["R8-7 FHS-DCC-GARCH"] = (
            f"PASS(fallback)  source={src}  VaR={res['var_pct']*100:.2f}%  ES={res['es_pct']*100:.2f}%"
        )
except Exception as e:
    results["R8-7 FHS-DCC-GARCH"] = f"FAIL  {e}"

# ─── R8-8 CDaR Optimization ─────────────────────────────────────────────
try:
    n_days, n_assets = 300, 4
    R = pd.DataFrame(rng.normal(0, 0.01, (n_days, n_assets)),
                    columns=["A", "B", "C", "D"])
    cw = np.array([0.25, 0.25, 0.25, 0.25])
    res = apply_cdar_constraint(R, current_weights=cw, alpha=0.95, lam=1.0, max_weight=0.40)
    assert res["source"] == "cdar", f"unexpected source: {res['source']}"
    w = res["weights"]
    assert abs(w.sum() - 1.0) < 1e-6, f"weights not normalized: {w.sum()}"
    assert all(0 <= v <= 0.40 + 1e-6 for v in w), f"max_weight violated: {w}"
    results["R8-8 CDaR"] = (
        f"PASS  weights={w.round(3).tolist()}  "
        f"CDaR={res['cdar']*100:.2f}%  source={res['source']}"
    )
except Exception as e:
    results["R8-8 CDaR"] = f"FAIL  {e}"

# ─── R8-9 BOCPD ─────────────────────────────────────────────────────────
try:
    n = 500
    # Two regimes: low vol for first 250, high vol for next 250 (clear changepoint)
    sig_arr = np.where(np.arange(n) < 250, 0.005, 0.030)
    r = pd.Series(rng.normal(0, sig_arr))
    res = detect_regime_changepoints(r, hazard_lambda=250, cp_threshold=0.30)
    assert res["source"] == "bocpd", f"unexpected source: {res['source']}"
    # We should detect at least one changepoint near the boundary (idx 250 ± 50)
    cps = res["changepoints"]
    has_cp_near_250 = any(abs(cp - 250) < 100 for cp in cps)
    results["R8-9 BOCPD"] = (
        f"PASS  n_cps={len(cps)}  cps={cps[:5]}  "
        f"near_250={has_cp_near_250}  source={res['source']}"
    )
except Exception as e:
    results["R8-9 BOCPD"] = f"FAIL  {e}"

# ─── R8-10 CPCV ──────────────────────────────────────────────────────────
try:
    n = 500
    r = pd.Series(rng.normal(0.0005, 0.01, n))  # ~0.8 Sharpe annualized
    res = cpcv_backtest_distribution(r, n_groups=6, n_paths=2, purge_lookback=5)
    src = res["source"]
    if src == "cpcv":
        sp = res["sharpe_paths"]
        assert len(sp) > 0, "no paths computed"
        results["R8-10 CPCV"] = (
            f"PASS  n_paths={res['n_paths']}  mean={res['sharpe_mean']:.2f}  "
            f"p05={res['sharpe_p05']:.2f}  p95={res['sharpe_p95']:.2f}  source={src}"
        )
    else:
        results["R8-10 CPCV"] = (
            f"PASS(fallback)  source={src}  mean={res['sharpe_mean']:.2f}"
        )
except Exception as e:
    results["R8-10 CPCV"] = f"FAIL  {e}"


# ─── Report ──────────────────────────────────────────────────────────────
print("\n========== Round 8 Wiring Smoke Results ==========")
for k, v in results.items():
    print(f"  {k:25} →  {v}")

n_pass = sum(1 for v in results.values() if v.startswith("PASS"))
n_fail = sum(1 for v in results.values() if v.startswith("FAIL"))
print(f"\nTotal: {n_pass} PASS / {n_fail} FAIL / {len(results)} tested")
if n_fail:
    sys.exit(1)
