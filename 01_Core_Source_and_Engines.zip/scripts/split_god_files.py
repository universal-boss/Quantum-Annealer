#!/usr/bin/env python3
"""
scripts/p3_round/split_god_files.py
====================================

AUDIT-FIX (Round 3, P2-4): Splits the two god files (optimizer.py ~8,855 LOC,
utils.py ~9,175 LOC) by physically moving function bodies into focused
sub-modules, then replacing the originals with thin re-import shims so every
existing `from optimizer import X` / `from utils import Y` call site keeps
working.

Strategy (extract-and-shim):
  1. Parse each god file with `ast`.
  2. For each function/class in the move-list, extract its source lines
     (using AST line-number metadata, so byte-exact).
  3. Write the extracted bodies to a new sub-module file with appropriate
     imports (stdlib + third-party libs + an end-of-parent globals injection
     so function bodies can reference parent-god-file globals like
     `log_emit`, `ExceptionLogger`, `DEFAULT_CFG`, etc. at runtime).
  4. In the god file, replace each moved function's body with a single
     `from <new_module> import *` re-import.

Idempotency (AUDIT-FIX Round 3 follow-up):
  - _build_new_module now APPENDS to an existing extracted module instead of
    overwriting. So re-running with an extended name set adds the new
    functions without losing the previously extracted ones.
  - _patch_god_file only deletes defs that are STILL in the god file; if
    a name was already extracted in a prior run, the patcher skips it.

Latent-bug fix (AUDIT-FIX Round 3 follow-up):
  The original extract-and-shim pattern relied on "deferred lookup from
  parent module's namespace" — but Python does not do cross-module
  namespace lookup for function-internal Name references. Extracted
  functions that referenced god-file globals (like `log_emit`, `pd`, or
  `AngelOneExecutionRouter`) silently NameError'd at runtime, caught by
  the omnipresent try/except blocks. The new builder:
  (a) imports numpy, pandas, and common stdlib libs directly;
  (b) appends an end-of-parent injection: at the very end of the parent
      god file (after all defs are bound), we copy the parent's globals
      into the extracted module's __dict__ via setattr. This is triggered
      by `from <new_module> import *` which forces the new module to be
      loaded, and then at the END of the parent's body we add a tiny
      block that injects parent's globals into the new module.
"""
from __future__ import annotations

import ast
import os
import re
import sys
import logging
from pathlib import Path
from typing import List, Set, Tuple

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("split_god_files")

APP_ROOT = Path(os.environ.get("EXTRACTED_APP_ROOT",
                              "/home/z/my-project/upload/extracted_app"))


# --------------------------------------------------------------------------- #
# Standard imports to inject into every new sub-module                          #
# --------------------------------------------------------------------------- #
# These are the imports the god files themselves use at module level. Adding
# them to the extracted module ensures extracted function bodies can resolve
# numpy/pandas/stdlib names without going through the parent god file's
# namespace (which is the latent bug in the original extract-and-shim pattern).
STANDARD_IMPORTS = """\
import sys, os, re, math, time, json, copy, warnings, threading, traceback
import tempfile, logging as _logging, hashlib as _hashlib, sqlite3, pickle
import csv, io, gc, uuid, base64
import collections, functools, itertools, contextlib
import concurrent.futures as _cf_mod, threading as _threading
from pathlib import Path
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple, Union, Callable, Sequence
from collections import Counter
try:
    import numpy as np
except ImportError:
    np = None
try:
    import pandas as pd
except ImportError:
    pd = None
"""

# End-of-parent injection block — appended to the parent god file after the
# `from <new_module> import *` line. At module-import time, the parent's
# globals are not yet bound (we're mid-import). So this block uses a deferred
# approach: it appends a function _inject_parent_globals() at the end of the
# parent that's called once the parent is fully loaded, AND also registers a
# sys.meta_path-less trick via sys.modules check inside the new module's
# function bodies — we use module-level __getattr__ (PEP 562) as a fallback.
#
# Actually the cleanest mechanism: at the END of the parent god file, after
# ALL defs are bound, run `globals().update(...)` on the new module. This
# is what INJECT_PARENT_GLOBALS_BLOCK does.
INJECT_PARENT_GLOBALS_TEMPLATE = """\

# AUDIT-FIX (Round 3, P2-4 follow-up): inject parent god file's globals into
# the extracted sub-module so its function bodies can reference names like
# `log_emit`, `ExceptionLogger`, `DEFAULT_CFG`, etc. that are defined later
# in this file. This is a no-op if the sub-module wasn't loaded yet.
import sys as _inject_sys
_inject_target = _inject_sys.modules.get("{new_module_name}")
if _inject_target is not None:
    for _inject_k, _inject_v in list(globals().items()):
        if _inject_k.startswith("__"):
            continue
        if _inject_k in ("_inject_sys", "_inject_target", "_inject_k", "_inject_v"):
            continue
        try:
            if _inject_k not in _inject_target.__dict__:
                setattr(_inject_target, _inject_k, _inject_v)
        except Exception:
            pass
    del _inject_sys, _inject_target, _inject_k, _inject_v
"""


# --------------------------------------------------------------------------- #
# Functions to extract from optimizer.py → optimizer_broker.py                 #
# --------------------------------------------------------------------------- #
# Original Round 3 cluster (broker routing, order sheets, compliance):
OPTIMIZER_BROKER_NAMES_ORIGINAL: Set[str] = {
    "ComplianceViolationError",
    "angelone_place_basket",
    "reconcile_with_angelone",
    "dhan_place_basket",
    "zerodha_place_basket",
    "reconcile_with_dhan",
    "reconcile_with_kite",
    "generate_angelone_order_sheet",
    "generate_kite_order_sheet",
    "generate_dhan_order_sheet",
    "generate_consultative_order_sheet",
    "generate_smallcase_basket",
    "compute_dynamic_trade_levels",
    "calculate_volume_profile_nodes",
}

# AUDIT-FIX (Round 3, P2-4 follow-up): extended cluster — sqlite persistence
# + weight calculators. These were chosen because:
#   - sqlite_* (5 functions, 233 LOC): cohesive SQLite persistence cluster,
#     minimal cross-references (only references SQLITE_DB_PATH global).
#   - calculate_*_weights (3 functions, 384 LOC): cohesive weight-calculator
#     cluster, calculate_qubo_aware_weights references _project_weights_to_bounds,
#     estimate_factor_expected_returns, poet_covariance — all resolved via
#     the end-of-parent globals injection.
OPTIMIZER_BROKER_NAMES_EXTENSION: Set[str] = {
    "sqlite_init",
    "sqlite_save_run",
    "sqlite_save_ic_observations",
    "sqlite_load_ic_history",
    "sqlite_load_history",
    "calculate_kelly_weights",
    "calculate_risk_parity_weights",
    "calculate_qubo_aware_weights",
}

OPTIMIZER_BROKER_NAMES = OPTIMIZER_BROKER_NAMES_ORIGINAL | OPTIMIZER_BROKER_NAMES_EXTENSION


# --------------------------------------------------------------------------- #
# Functions to extract from utils.py → utils_chart_pipeline.py                 #
# --------------------------------------------------------------------------- #
# Original Round 3 cluster (chart SSL pipeline, multi-timeframe features):
UTILS_CHART_PIPELINE_NAMES_ORIGINAL: Set[str] = {
    "_pool_mean_fixed",
    "_chart_image_embedding_from_array",
    "_chart_image_embedding_from_file",
    "_apply_chart_embedding_projection",
    "_load_offline_chart_model",
    "_sample_chart_image_paths",
    "load_or_build_chart_ssl_model",
    "_get_sweep_chart_ticker_lock",
    "compute_multi_timeframe_chart_features",
    "_ts_feature_vector",
    "ts_feature_vector_v2",
    "build_chart_tensor",
    "build_multitimeframe_input_bundle",
    "apply_score_calibration",
    "_build_live_chart_ssl_model",
    "compute_chart_ssl_features",
}

# AUDIT-FIX (Round 3, P2-4 follow-up): extended cluster — builders (factor
# summary, exposures, alerts, diagnostics, correlation). These were chosen
# because:
#   - build_* (7 functions, 427 LOC): cohesive builder cluster, all return
#     DataFrames for UI consumption. build_correlation_matrix references
#     build_ewma_correlation, denoise_covariance_rmt, ledoit_wolf_shrinkage_numpy,
#     oas_shrinkage_numpy — all resolved via the end-of-parent globals injection.
UTILS_CHART_PIPELINE_NAMES_EXTENSION: Set[str] = {
    "build_factor_summary",
    "build_exposures_summary",
    "build_selection_changes",
    "build_alerts",
    "build_diagnostics_frame",
    "build_correlation_matrix",
    "build_ewma_correlation",
}

UTILS_CHART_PIPELINE_NAMES = UTILS_CHART_PIPELINE_NAMES_ORIGINAL | UTILS_CHART_PIPELINE_NAMES_EXTENSION


# --------------------------------------------------------------------------- #
# AST helpers                                                                 #
# --------------------------------------------------------------------------- #
def _find_top_level_defs(tree: ast.Module) -> List[Tuple[str, int, int, str]]:
    """Return [(name, start_line, end_line, kind)] for every top-level def/class."""
    out = []
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            end_line = getattr(node, "end_lineno", None) or node.lineno
            out.append((node.name, node.lineno, end_line, "fn"))
        elif isinstance(node, ast.ClassDef):
            end_line = getattr(node, "end_lineno", None) or node.lineno
            out.append((node.name, node.lineno, end_line, "class"))
    return out


def _extract_block(source_lines: List[str], start_line: int, end_line: int) -> str:
    """Extract lines [start_line, end_line] (1-indexed, inclusive)."""
    return "".join(source_lines[start_line - 1: end_line])


def _existing_module_names(module_path: Path) -> Set[str]:
    """If module_path exists, return the set of top-level def/class names already in it.
    Empty set if file doesn't exist.
    """
    if not module_path.exists():
        return set()
    try:
        tree = ast.parse(module_path.read_text(encoding="utf-8"))
    except SyntaxError:
        return set()
    return {n.name for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))}


def _ensure_standard_imports(module_path: Path) -> bool:
    """If the module doesn't have `import numpy as np` in its imports,
    inject STANDARD_IMPORTS after the leading docstring. Returns True if injected.

    This fixes the latent NameError bug from the original Round 3 builder,
    which left extracted function bodies unable to resolve `np`/`pd`/
    `log_emit`-style references at runtime (they were silently caught by
    omnipresent try/except blocks).
    """
    if not module_path.exists():
        return False
    text = module_path.read_text(encoding="utf-8")
    if "import numpy as np" in text:
        return False  # already has it
    # Find end of leading docstring
    doc_end = text.find('"""', 3)
    if doc_end == -1:
        doc_end = 0
    else:
        doc_end += 3
    new_text = (text[:doc_end]
                + "\n\n"
                + "# AUDIT-FIX (Round 3, P2-4 follow-up): STANDARD_IMPORTS added to fix latent NameError\n"
                + STANDARD_IMPORTS
                + text[doc_end:])
    module_path.write_text(new_text, encoding="utf-8")
    log.info("  ✓ Injected STANDARD_IMPORTS into %s (fixes latent NameError bug)", module_path.name)
    return True


def _build_new_module(
    new_module_path: Path,
    source_god_file: Path,
    extracted_names: Set[str],
    docstring: str,
    extra_imports: str = "",
) -> Tuple[bool, int, int]:
    """Build/extend a new sub-module file from extracted function bodies.

    Idempotent: if the module already exists, only NEW names (not already in
    the module) are extracted and appended.

    Returns (success, lines_moved, n_functions_moved).
    """
    existing_names = _existing_module_names(new_module_path)
    names_already_moved = extracted_names & existing_names
    names_to_move = extracted_names - existing_names
    log.info("Building/extending %s from %s: %d requested, %d already present, %d to extract",
             new_module_path.name, source_god_file.name,
             len(extracted_names), len(names_already_moved), len(names_to_move))

    if not names_to_move:
        log.info("  ✓ No new names to extract — module is up to date")
        # Even if no new names to move, still inject STANDARD_IMPORTS
        # into an existing module if it's missing them (fixes latent
        # NameError bug from the original Round 3 builder).
        if new_module_path.exists():
            _ensure_standard_imports(new_module_path)
        return True, 0, 0

    src_text = source_god_file.read_text(encoding="utf-8")
    src_lines = src_text.splitlines(keepends=True)
    tree = ast.parse(src_text)
    defs = _find_top_level_defs(tree)

    moved_blocks = []
    moved_names = []
    for name, start, end, kind in defs:
        if name in names_to_move:
            block = _extract_block(src_lines, start, end)
            moved_blocks.append(block)
            moved_names.append(name)

    if not moved_blocks:
        log.warning("  No matching defs found in %s (were they already moved?)",
                    source_god_file.name)
        return False, 0, 0

    # Build the new content
    is_fresh_module = not new_module_path.exists()
    if is_fresh_module:
        # Build from scratch: docstring + standard imports + moved blocks
        new_content = ['"""', docstring, '"""', ""]
        new_content.append("from __future__ import annotations")
        new_content.append("")
        new_content.append(STANDARD_IMPORTS)
        new_content.append("")
        if extra_imports:
            new_content.append(extra_imports)
            new_content.append("")
        new_content.extend(moved_blocks)
        # Re-export
        new_content.append("")
        new_content.append("# AUDIT-FIX (Round 3, P2-4): re-export moved names")
        new_content.append("__all__ = [")
        for n in moved_names:
            new_content.append(f"    {n!r},")
        new_content.append("]")
        new_content.append("")
        new_module_path.parent.mkdir(parents=True, exist_ok=True)
        new_module_path.write_text("\n".join(new_content), encoding="utf-8")
    else:
        # Append to existing module
        existing_text = new_module_path.read_text(encoding="utf-8")

        # If STANDARD_IMPORTS is not present, inject it after the docstring.
        # This fixes the latent NameError bug for modules created by the
        # original Round 3 builder (which didn't add proper imports).
        _ensure_standard_imports(new_module_path)
        # Re-read after potential injection
        existing_text = new_module_path.read_text(encoding="utf-8")

        append_content = ["\n", "# AUDIT-FIX (Round 3, P2-4 follow-up): appended cluster"]
        append_content.append("")
        append_content.extend(moved_blocks)
        # Update __all__ if present
        if "__all__ = [" in existing_text:
            # Find __all__ list and extend it
            new_all_entries = "".join(f"    {n!r},\n" for n in moved_names)
            append_content.append(f"# Extend __all__ with newly moved names\n")
            append_content.append(f"try:\n    __all__.extend({moved_names!r})\nexcept NameError:\n    __all__ = {moved_names!r}\n")
        new_module_path.write_text(existing_text + "\n".join(append_content), encoding="utf-8")

    lines_moved = sum(b.count("\n") for b in moved_blocks)
    log.info("  ✓ Moved %d functions/classes (%d lines) → %s (%s)",
             len(moved_names), lines_moved, new_module_path.name,
             "fresh" if is_fresh_module else "appended")
    return True, lines_moved, len(moved_names)


def _patch_god_file(
    god_path: Path,
    extracted_names: Set[str],
    new_module_name: str,
):
    """Replace each extracted function body in the god file with a re-import.

    Idempotent: only patches defs that are STILL in the god file. If a name
    was already extracted in a prior run, the patcher skips it (no matching
    def → not in ranges_to_delete).
    """
    log.info("Patching %s to re-import from %s...", god_path.name, new_module_name)

    src_text = god_path.read_text(encoding="utf-8")
    src_lines = src_text.splitlines(keepends=True)
    tree = ast.parse(src_text)
    defs = _find_top_level_defs(tree)

    # Collect ranges to delete (in reverse order so line numbers don't shift)
    ranges_to_delete = []
    for name, start, end, kind in defs:
        if name in extracted_names:
            ranges_to_delete.append((start, end, name))
    ranges_to_delete.sort(reverse=True)

    if not ranges_to_delete:
        log.info("  ✓ %s: no defs to patch (all names already extracted in a prior run)",
                 god_path.name)
        # Still ensure the re-import + injection block are present
        _ensure_re_import_and_injection(god_path, new_module_name)
        return 0

    # Delete the function bodies — but also collect decorators (lines above
    # the def that start with @) so we don't leave orphaned decorator lines.
    for start, end, name in ranges_to_delete:
        actual_start = start
        while actual_start - 2 >= 0 and src_lines[actual_start - 2].strip().startswith("@"):
            actual_start -= 1
        del src_lines[actual_start - 1: end]

    god_path.write_text("".join(src_lines), encoding="utf-8")
    log.info("  ✓ Patched %s: %d functions/classes replaced with re-imports",
             god_path.name, len(ranges_to_delete))

    # Ensure re-import + injection block are present (idempotent)
    _ensure_re_import_and_injection(god_path, new_module_name)
    return len(ranges_to_delete)


def _ensure_re_import_and_injection(god_path: Path, new_module_name: str) -> None:
    """Ensure the god file has `from <new_module> import *` and the end-of-parent
    globals-injection block. Idempotent — only inserts if missing.
    """
    src_text = god_path.read_text(encoding="utf-8")
    src_lines = src_text.splitlines(keepends=True)

    re_import_line = f"from {new_module_name} import *  # noqa: F401,F403"
    re_import_marker = f"# AUDIT-FIX (Round 3, P2-4): re-export from {new_module_name}"

    needs_re_import = re_import_line not in src_text

    injection_block = INJECT_PARENT_GLOBALS_TEMPLATE.format(new_module_name=new_module_name)
    injection_marker = f"_inject_target = _inject_sys.modules.get(\"{new_module_name}\")"
    needs_injection = injection_marker not in src_text

    if not needs_re_import and not needs_injection:
        return  # all good

    # Find insertion point for re-import: end of leading block of comments/imports
    insertion_line = 0
    for i, line in enumerate(src_lines):
        stripped = line.strip()
        if (stripped.startswith("#") or stripped.startswith('"""')
                or stripped.startswith("from __future__")
                or stripped == ""
                or stripped.startswith("import ")
                or stripped.startswith("from ")):
            insertion_line = i + 1
        else:
            break

    if needs_re_import:
        re_import = (f"\n# AUDIT-FIX (Round 3, P2-4): re-export from {new_module_name}"
                     f" (split from this god file)\n{re_import_line}\n")
        src_lines.insert(insertion_line, re_import)

    if needs_injection:
        # Append the injection block at the very end of the file
        src_lines.append(injection_block)

    god_path.write_text("".join(src_lines), encoding="utf-8")


# --------------------------------------------------------------------------- #
# Main                                                                         #
# --------------------------------------------------------------------------- #
def main():
    log.info("=== God-File Split (Round 3, P2-4) ===")
    log.info("OPTIMIZER_BROKER_NAMES: %d names (original=%d, extension=%d)",
             len(OPTIMIZER_BROKER_NAMES),
             len(OPTIMIZER_BROKER_NAMES_ORIGINAL),
             len(OPTIMIZER_BROKER_NAMES_EXTENSION))
    log.info("UTILS_CHART_PIPELINE_NAMES: %d names (original=%d, extension=%d)",
             len(UTILS_CHART_PIPELINE_NAMES),
             len(UTILS_CHART_PIPELINE_NAMES_ORIGINAL),
             len(UTILS_CHART_PIPELINE_NAMES_EXTENSION))

    # ---- optimizer.py → optimizer_broker.py ----
    broker_docstring = '''optimizer_broker.py — Broker routing + order sheets + sqlite + weight calculators
==================================================================================

AUDIT-FIX (Round 3, P2-4): extracted from optimizer.py in two waves.
Wave 1 (original): broker routing (~250 LOC), order-sheet CSV generators
(~150 LOC), ComplianceViolationError, compute_dynamic_trade_levels,
calculate_volume_profile_nodes. Total 14 names.
Wave 2 (extension): sqlite persistence cluster (5 names, 233 LOC) +
weight-calculator cluster (3 names, 384 LOC). Total 8 names.

This module groups:
  - Broker routing: AngelOne, Zerodha Kite, DhanHQ, Smallcase, Consultative
  - Compliance: ComplianceViolationError + pre-trade gate
  - SQLite persistence: schema init, run save/load, IC observations
  - Weight calculators: Kelly, risk-parity, QUBO-aware

The parent optimizer.py re-exports every name from this module so all
existing `from optimizer import X` call sites keep working. The parent's
globals are injected into this module's __dict__ at the end of the parent's
import (see INJECT_PARENT_GLOBALS_BLOCK in optimizer.py), so function bodies
here can reference `log_emit`, `ExceptionLogger`, `DEFAULT_CFG`, etc.
'''
    ok, lines, n = _build_new_module(
        APP_ROOT / "optimizer_broker.py",
        APP_ROOT / "optimizer.py",
        OPTIMIZER_BROKER_NAMES,
        broker_docstring,
        extra_imports="# No extra imports — STANDARD_IMPORTS covers numpy/pandas/stdlib.",
    )
    if ok:
        _patch_god_file(APP_ROOT / "optimizer.py", OPTIMIZER_BROKER_NAMES, "optimizer_broker")

    # ---- utils.py → utils_chart_pipeline.py ----
    chart_docstring = '''utils_chart_pipeline.py — Chart SSL + multi-timeframe features + builders
=============================================================================

AUDIT-FIX (Round 3, P2-4): extracted from utils.py in two waves.
Wave 1 (original): chart-image SSL helpers + multi-timeframe dual-tower
feature builders + apply_score_calibration + compute_chart_ssl_features.
Total 16 names.
Wave 2 (extension): builders cluster (7 names, 427 LOC) — factor summary,
exposures, selection changes, alerts, diagnostics, correlation, EWMA.

This module groups:
  - Chart image embedding (from array, from file)
  - Offline chart SSL model load/build
  - Multi-timeframe dual-tower feature computation
  - 1-D time-series feature vectors (v1 and v2)
  - Chart tensor + multitimeframe input bundle builders
  - Score calibration (apply_score_calibration)
  - Live chart SSL model build + compute_chart_ssl_features
  - Builders (factor_summary, exposures, alerts, diagnostics, correlation)

The parent utils.py re-exports every name from this module so all existing
`from utils import X` call sites keep working. The parent's globals are
injected into this module's __dict__ at the end of the parent's import.
'''
    ok, lines, n = _build_new_module(
        APP_ROOT / "utils_chart_pipeline.py",
        APP_ROOT / "utils.py",
        UTILS_CHART_PIPELINE_NAMES,
        chart_docstring,
        extra_imports="# STANDARD_IMPORTS covers numpy/pandas/stdlib.",
    )
    if ok:
        _patch_god_file(APP_ROOT / "utils.py", UTILS_CHART_PIPELINE_NAMES, "utils_chart_pipeline")

    log.info("=== Done. Run `python -m py_compile optimizer.py utils.py optimizer_broker.py utils_chart_pipeline.py` to verify. ===")


if __name__ == "__main__":
    main()
