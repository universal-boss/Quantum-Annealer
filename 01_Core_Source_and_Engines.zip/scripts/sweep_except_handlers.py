#!/usr/bin/env python3
"""
scripts/p3_round/sweep_except_handlers.py
==========================================

AUDIT-FIX (Round 3, P2-5): Broad except-handler sweep.

The audit's AST scan found 823 problematic patterns across 65 files:
  - 0   bare `except:` clauses (already clean)
  - 272 `except Exception as e:` that logs message WITHOUT exc_info=True
        (logger.warning(f"... {e}") — traceback is lost)
  - 551 swallowing `except Exception:` that recover silently (pass /
        continue / return None / set to NaN, etc.)

Strategy:
  1. For the 272 LOG_NO_EXC cases: programmatically add `, exc_info=True`
     to every logger call inside the except block. This is a search-and-
     replace that's safe (Python's logging accepts exc_info kwarg on every
     level method) and high-leverage (every traceback is now captured).
  2. For the 551 SWALLOW cases: leave the recovery logic intact (most are
     legitimate defensive fallbacks in factor pipelines where one bad
     factor must not crash the frame), but add a `logger.debug(...,
     exc_info=True)` call so the failure is at least recorded at DEBUG
     level. We focus on the top 5 worst-offending files:
       - optimizer.py (60 swallows)
       - utils.py    (94 swallows)
       - data_layer.py (68 swallows)
       - ui/main_window.py (97 swallows — UI thread swallows; will not
         modify since UI worker thread swallows emit Qt signals with the
         traceback already, not logger calls)
       - web_dashboard/app.py (26 swallows)

Files modified: optimizer.py, utils.py, data_layer.py, web_dashboard/app.py
Estimated transformations:
  - ~150 LOG_NO_EXC → LOG_WITH_EXC_INFO patches
  - ~50 SWALLOW → SWALLOW + DEBUG LOG patches (limited to factor-pipeline
    paths where the silent fallback masks real bugs per the audit's
    "Recommended Next Actions" §1)
"""
from __future__ import annotations

import ast
import os
import re
import sys
import logging
from pathlib import Path
from typing import List, Set, Tuple, Optional

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("sweep_except")

APP_ROOT = Path(os.environ.get("EXTRACTED_APP_ROOT",
                              "/home/z/my-project/upload/extracted_app"))

# Files in priority order
TARGET_FILES = [
    "optimizer.py",
    "utils.py",
    "data_layer.py",
    "web_dashboard/app.py",
    "math_engine/post_screening_intelligence.py",
    "ml_alpha/engine.py",
    "workers/worker_threads.py",
    # AUDIT-FIX (Round 3, P2-5 follow-up): expand to ui/tabs/, math_engine/,
    # ml_alpha/ — AST scan found 48 additional files with broad except
    # handlers (excluding the 2 already in TARGET_FILES). The patcher is
    # idempotent so re-running on already-patched files is safe.
    "math_engine/__init__.py",
    "math_engine/advanced_regimes.py",
    "math_engine/alternative_assets.py",
    "math_engine/black_litterman.py",
    "math_engine/broker_router.py",
    "math_engine/cqm_formulator.py",
    "math_engine/ctc_causality.py",
    "math_engine/derivatives.py",
    "math_engine/dynamic_factor_engine.py",
    "math_engine/event_backtester.py",
    "math_engine/expected_shortfall.py",
    "math_engine/factor_orthogonalizer.py",
    "math_engine/factor_risk.py",
    "math_engine/godelian_oracle.py",
    "math_engine/gpu_accelerator.py",
    "math_engine/html_report_generator.py",
    "math_engine/indicators.py",
    "math_engine/institutional_operators.py",
    "math_engine/institutional_research_registry.py",
    "math_engine/matrix_denoising.py",
    "math_engine/onnx_inference.py",
    "math_engine/ontological_erasure.py",
    "math_engine/options_hedger.py",
    "math_engine/profile_mathematical_suite.py",
    "math_engine/prototype_bank.py",
    "math_engine/realtime_risk.py",
    "math_engine/regime_detector.py",
    "math_engine/risk_budgeting_solver.py",
    "math_engine/smart_order_router.py",
    "math_engine/solver_coordinator.py",
    "math_engine/stress_tester.py",
    "math_engine/wasserstein_barycenter.py",
    "math_engine/websocket_feed.py",
    "ml_alpha/__init__.py",
    "ml_alpha/advanced_ml.py",
    "ml_alpha/expanded_ensemble.py",
    "ml_alpha/factors_100.py",
    "ml_alpha/feature_engineering.py",
    "ml_alpha/feature_extractor.py",
    "ml_alpha/feature_selection.py",
    "ml_alpha/feature_store.py",
    "ml_alpha/gnn_spillover.py",
    "ml_alpha/hyperopt.py",
    "ml_alpha/metrics.py",
    "ui/tabs/ai_copilot.py",
    "ui/tabs/corporate.py",
    "ui/tabs/risk_stress.py",
]

# Logger-call patterns we'll patch (LOG_NO_EXC → LOG_WITH_EXC_INFO)
LOGGER_CALL_PATTERN = re.compile(
    r'(?P<indent>^\s*)'
    r'(?P<logger>(?:self\.)?(?:log_emit|logger|archlog|_arch_log|log)\b[\.\(]?)'
    # The above is permissive — actual fixup happens per-call
    ,
    re.MULTILINE,
)


def _is_logger_call(node: ast.AST) -> bool:
    """True if `node` is a logger call like `logger.warning(...)` or `log_emit(..., ...)`."""
    if isinstance(node, ast.Expr) and isinstance(node.value, ast.Call):
        return _is_logger_call(node.value)
    if isinstance(node, ast.Call):
        f = node.func
        # logger.warning(...) / archlog.error(...) / self.log.debug(...)
        if isinstance(f, ast.Attribute):
            obj = f.value
            if isinstance(obj, ast.Name) and obj.id in ("logger", "archlog", "_arch_log", "log"):
                return True
            if isinstance(obj, ast.Attribute) and isinstance(obj.attr, str) and obj.attr in ("log",):
                return True
        # log_emit(...) / log(...) calls
        if isinstance(f, ast.Name) and f.id in ("log_emit", "log"):
            return True
    return False


def _has_exc_info(call: ast.Call) -> bool:
    """True if the call already has exc_info kwarg."""
    for kw in call.keywords:
        if kw.arg == "exc_info":
            return True
    return False


def _patch_except_block(source: str, handler: ast.ExceptHandler) -> Tuple[str, bool, int]:
    """Patch the body of an except handler to add exc_info=True to logger calls.

    Returns (new_source, was_patched, n_loggers_patched).

    AUDIT-FIX (Round 3, P2-5): Conservative — only patches SINGLE-LINE logger
    calls (where the entire call fits on one line). Multi-line calls (where
    the call's closing `)` is on its own line) are skipped to avoid
    mangled-syntax bugs. Still patches ~80% of the LOG_NO_EXC cases.
    """
    n_patched = 0
    was_modified = False
    new_source = source

    # Walk the handler's body looking for logger calls
    for stmt in handler.body:
        # Find logger calls inside this statement
        for node in ast.walk(stmt):
            if isinstance(node, ast.Call) and _is_logger_call(node):
                if _has_exc_info(node):
                    continue  # already has exc_info
                # Check if this is a SINGLE-LINE call (start_lineno == end_lineno)
                start_line = getattr(node, "lineno", None)
                end_line = getattr(node, "end_lineno", None)
                end_col = getattr(node, "end_col_offset", None)
                if start_line is None or end_line is None or end_col is None:
                    continue
                # Skip multi-line calls (start_line != end_line)
                if start_line != end_line:
                    continue

                lines = new_source.split("\n")
                if end_line - 1 >= len(lines):
                    continue
                line = lines[end_line - 1]
                close_paren_idx = end_col - 1  # 0-indexed
                if close_paren_idx < 0 or close_paren_idx >= len(line):
                    continue
                if line[close_paren_idx] != ')':
                    continue
                # Only patch if the call has at least one positional arg
                # (so we don't write `logger.warning(exc_info=True)` with no message)
                has_args = bool(node.args) or bool(node.keywords)
                if not has_args:
                    continue
                # AUDIT-FIX (Round 3, P2-5): additionally, check that the char
                # immediately before `close_paren_idx` is NOT a comma — if it
                # is, the call is `logger.warning(arg1,)` (trailing-comma form)
                # and we should add `exc_info=True` (no leading comma) instead
                # of `, exc_info=True`.
                if close_paren_idx > 0 and line[close_paren_idx - 1] == ',':
                    insertion = " exc_info=True"  # no leading comma
                else:
                    insertion = ", exc_info=True"
                new_line = line[:close_paren_idx] + insertion + line[close_paren_idx:]
                lines[end_line - 1] = new_line
                new_source = "\n".join(lines)
                n_patched += 1
                was_modified = True

    return new_source, was_modified, n_patched


def _patch_swallow_with_debug(source: str, handler: ast.ExceptHandler) -> Tuple[str, bool]:
    """For swallowing except blocks (pass / continue / return None / single
    var assignment), insert a `logger.debug("...", exc_info=True)` line at
    the top of the handler body so the failure is at least captured at DEBUG level.

    Conservative: only patches handlers where:
      - body is 1-3 simple statements
      - body is on its own line(s), NOT a single-line `try:/except:` combo
        (where the body statement shares the line with `try:`)
      - body consists only of `pass`, `continue`, `return None/0/{}/[]/False`,
        or `<var> = np.nan`/`<var> = float('nan')`/`<var> = 0.0`
    """
    body = handler.body
    if not body:
        return source, False

    # Heuristic: only patch if body is 1-2 simple statements
    if len(body) > 3:
        return source, False

    # AUDIT-FIX (Round 3, P2-5): SAFETY CHECK — skip single-line try:/except:
    # blocks (where the body's first statement starts on the same line as the
    # `try:` keyword). Inserting a debug log line in such cases produces a
    # syntax error because the try block has no proper body before `except`.
    first_stmt = body[0]
    try_block_lineno = None
    # Walk up to find the enclosing Try node — we don't have it directly,
    # but we can check: if the first body stmt's lineno equals the except
    # handler's lineno, it's almost certainly a single-line combo.
    if first_stmt.lineno == handler.lineno:
        return source, False

    # Also skip if any body statement is on the same line as the except
    # handler itself
    for s in body:
        if s.lineno == handler.lineno:
            return source, False

    # Classify the body
    is_pass_like = all(
        isinstance(s, ast.Pass) or
        isinstance(s, ast.Continue) or
        (isinstance(s, ast.Return) and (
            s.value is None or
            (isinstance(s.value, ast.Constant) and s.value.value in (None, 0, 0.0, False, "", [])) or
            (isinstance(s.value, ast.List) and not s.value.elts) or
            (isinstance(s.value, ast.Dict) and not s.value.keys) or
            (isinstance(s.value, ast.Name) and s.value.id == 'None')
        ))
        for s in body
    )

    # "var = nan/0.0/None" assignments
    is_recover_assignment = all(
        isinstance(s, ast.Assign) and
        len(s.targets) == 1 and
        isinstance(s.targets[0], ast.Name) and
        isinstance(s.value, ast.Constant) and
        (s.value.value in (None, 0, 0.0, False, "")
         or (isinstance(s.value.value, float) and s.value.value != s.value.value))
        for s in body
    )

    if not (is_pass_like or is_recover_assignment):
        return source, False

    # Don't patch if there's already a logger call in the body
    for stmt in body:
        for node in ast.walk(stmt):
            if isinstance(node, ast.Call) and _is_logger_call(node):
                return source, False

    # Get the exception variable name (if `as e:` form)
    exc_name = ""
    if handler.name:
        exc_name = handler.name

    # Build the debug log line
    indent_unit = "    "  # 4-space indent; we'll match the handler body's indent below
    lines = source.split("\n")
    if not body:
        return source, False
    first_stmt = body[0]
    start_line = first_stmt.lineno  # 1-indexed
    if start_line - 1 >= len(lines):
        return source, False
    first_line = lines[start_line - 1]
    actual_indent = first_line[:len(first_line) - len(first_line.lstrip())]
    if not actual_indent:
        actual_indent = indent_unit

    # The handler body is at the indent of `actual_indent`; the `except` line
    # is at one indent level less. But we're inserting INSIDE the body, so
    # use `actual_indent` as the indent for our new debug log line.
    if exc_name:
        # ROUND-44 FIX: the emitted logging call used a `{}` placeholder, but
        # logging performs %-style (printf) formatting — `msg % args` raised
        # "TypeError: not all arguments converted during string formatting"
        # inside the logging framework on EVERY call, so the swallowed-
        # exception instrumentation never actually logged its message. Emit
        # `%s` instead.
        debug_line = f'{actual_indent}import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception in %s", "{handler.type.id if handler.type and isinstance(handler.type, ast.Name) else "Exception"}", exc_info=True)  # noqa: E501'
    else:
        debug_line = f'{actual_indent}import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501'

    # Insert BEFORE the first body statement
    new_lines = lines[:start_line - 1] + [debug_line] + lines[start_line - 1:]
    return "\n".join(new_lines), True


def sweep_file(filepath: Path, max_swallow_patches: int = 30) -> Tuple[int, int]:
    """Patch all LOG_NO_EXC + selected SWALLOW patterns in `filepath`.

    Returns (n_exc_info_added, n_swallow_debug_added).
    """
    if not filepath.exists():
        return 0, 0
    source = filepath.read_text(encoding="utf-8")
    try:
        tree = ast.parse(source)
    except SyntaxError as e:
        log.error("  %s: syntax error %s — skipping", filepath.name, e)
        return 0, 0

    n_exc = 0
    n_swallow = 0
    swallow_patches = 0

    # Iterate over every ExceptHandler in the file
    # We need to patch from the bottom up so line numbers don't shift
    handlers = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ExceptHandler):
            handlers.append(node)
    # Sort by start line descending
    handlers.sort(key=lambda h: h.lineno, reverse=True)

    for handler in handlers:
        # First try LOG_NO_EXC patch: find logger calls without exc_info
        # and add it.
        new_source, was_modified, n_patched = _patch_except_block(source, handler)
        if was_modified:
            source = new_source
            n_exc += n_patched

        # Then try SWALLOW patch: insert a debug log line at the top
        # of the handler body if it's a pass-like/recover-assignment block.
        # Cap at max_swallow_patches per file to avoid runaway scope.
        if swallow_patches < max_swallow_patches:
            new_source, was_patched = _patch_swallow_with_debug(source, handler)
            if was_patched:
                source = new_source
                n_swallow += 1
                swallow_patches += 1

    if n_exc > 0 or n_swallow > 0:
        filepath.write_text(source, encoding="utf-8")
        log.info("  %s: +%d exc_info / +%d swallow-debug", filepath.name, n_exc, n_swallow)

    return n_exc, n_swallow


def main():
    log.info("=== Broad except-handler sweep (Round 3, P2-5) ===")
    total_exc = 0
    total_swallow = 0
    for relpath in TARGET_FILES:
        fpath = APP_ROOT / relpath
        log.info("Scanning %s...", relpath)
        n_exc, n_swallow = sweep_file(fpath)
        total_exc += n_exc
        total_swallow += n_swallow

    log.info("=== Done. Total: +%d exc_info added, +%d swallow-debug logs added ===", total_exc, total_swallow)
    log.info("Run `python -m py_compile` on the patched files to verify.")


if __name__ == "__main__":
    main()
