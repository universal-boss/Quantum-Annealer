"""
scripts/train_hierarchical_moe.py
=================================
Hierarchical Regime-Gated Mixture of Experts (MoE) with Latent Denoising Driver.

Executes the pinnacle quantitative training pipeline:
  1. Universe: 150 liquid Indian equities from data/combined_universe.csv.
  2. Features: Top 25 sector-neutralized multi-factor panels from Parquet FeatureStore.
  3. Latent De-Noising: Random Matrix Theory (RMT) + Factor-VAE ELBO reconstruction.
  4. Dynamic Regime Gating: Macro trend/vol/drawdown classifier routing to:
     - Expert 1: Trend & Momentum (LightGBM GBDT)
     - Expert 2: Mean Reversion & Squeeze (ElasticNet & Bayesian Ridge)
     - Expert 3: Peer & Supply-Chain Spillover (GNN Diffusion Engine)
  5. Validation: Purged Walk-Forward Optimization (WFO with 10d embargo).
  6. Transaction Costs: 15 bps Indian statutory & execution costs backtest.
  7. Production Packaging: models/ml_alpha_model.pkl (< 1.0 MB) + SHA-256 sidecar.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import pickle
import sys
import time
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("train_hierarchical_moe")

from data.price_feed import safe_download
from ml_alpha.engine import AlphaEngine
from ml_alpha.feature_store import FeatureStore
from ml_alpha.hierarchical_moe import HierarchicalMoEPredictor
from ml_alpha.universe_pipeline import (
    UniverseFeaturePipeline,
    load_universe_tickers,
    load_sector_map,
    sector_neutralize_panel,
    evaluate_turnover_and_costs,
)


def fetch_universe_prices(
    tickers: List[str],
    period: str = "2y",
    max_tickers: int = 150,
) -> Dict[str, pd.DataFrame]:
    """Fetch 2-year OHLCV for top liquid universe tickers."""
    target_tickers = tickers[:max_tickers]
    logger.info(f"Downloading historical OHLCV for {len(target_tickers)} universe tickers (period={period})...")

    chunk_size = 50
    price_dict: Dict[str, pd.DataFrame] = {}
    for i in range(0, len(target_tickers), chunk_size):
        chunk = target_tickers[i : i + chunk_size]
        logger.info(f"  Fetching batch {i // chunk_size + 1}/{(len(target_tickers) + chunk_size - 1) // chunk_size} ({len(chunk)} tickers)...")
        raw = safe_download(chunk, period=period, auto_adjust=True)
        if raw.empty:
            continue
        for ticker in chunk:
            try:
                if isinstance(raw.columns, pd.MultiIndex):
                    if ticker in raw.columns.get_level_values(1):
                        sub = raw.xs(ticker, axis=1, level=1)
                    elif ticker in raw.columns.get_level_values(0):
                        sub = raw.xs(ticker, axis=1, level=0)
                    else:
                        continue
                else:
                    sub = raw
                cols = {c.lower(): c for c in sub.columns}
                if "close" in cols:
                    df = pd.DataFrame(index=sub.index)
                    for f in ("open", "high", "low", "close", "volume"):
                        if f in cols:
                            df[f] = sub[cols[f]].astype(float)
                        elif "close" in cols:
                            df[f] = sub[cols["close"]].astype(float)
                    df = df.dropna(subset=["close"])
                    if len(df) >= 120:
                        price_dict[ticker] = df
            except Exception:
                pass
    return price_dict


def run_purged_wfo_moe(
    df_train: pd.DataFrame,
    feature_cols: List[str],
    benchmark_series: pd.Series,
    n_splits: int = 4,
    forward_days: int = 10,
) -> Tuple[List[float], Dict[str, float]]:
    """Runs Purged Walk-Forward Cross-Validation for the Hierarchical MoE."""
    dates = pd.DatetimeIndex(sorted(df_train.index.get_level_values("date").unique()))
    n_dates = len(dates)
    fold_size = n_dates // (n_splits + 1)

    fold_ics: List[float] = []
    logger.info(f"Starting MoE Purged Walk-Forward CV ({n_splits} folds, {n_dates} total dates)...")

    for k in range(n_splits):
        train_end_idx = fold_size * (k + 1)
        test_start_idx = train_end_idx
        test_end_idx = min(train_end_idx + fold_size, n_dates)

        purge_end_idx = max(20, train_end_idx - forward_days)
        train_dates = dates[:purge_end_idx]
        test_dates = dates[test_start_idx:test_end_idx]

        train_mask = df_train.index.get_level_values("date").isin(train_dates)
        test_mask = df_train.index.get_level_values("date").isin(test_dates)

        X_train = df_train.loc[train_mask, feature_cols]
        y_train = df_train.loc[train_mask, "forward_return"]
        X_test = df_train.loc[test_mask, feature_cols]
        y_test = df_train.loc[test_mask, "forward_return"]

        if len(X_train) < 100 or len(X_test) < 20:
            continue

        train_tickers = list(df_train.loc[train_mask].index.get_level_values("ticker"))
        test_tickers = list(df_train.loc[test_mask].index.get_level_values("ticker"))

        # Fit Hierarchical MoE on fold
        moe = HierarchicalMoEPredictor(denoise_method="rmt", latent_dim=3)
        bench_fold = benchmark_series[benchmark_series.index.isin(train_dates)]
        moe.fit(X_train, y_train.values, tickers=train_tickers, benchmark_returns=bench_fold)

        # Predict out-of-sample
        preds = moe.predict(X_test, tickers=test_tickers)
        if isinstance(preds, pd.Series):
            pred_vals = preds.values
        else:
            pred_vals = np.asarray(preds, dtype=float)

        df_test_res = pd.DataFrame({
            "pred": pred_vals,
            "actual": y_test.values,
        }, index=X_test.index)

        # Calculate daily cross-sectional Spearman IC
        daily_ics = []
        for dt, grp in df_test_res.groupby(level="date"):
            if len(grp) >= 5 and grp["pred"].std() > 1e-6 and grp["actual"].std() > 1e-6:
                ic = float(grp["pred"].corr(grp["actual"], method="spearman"))
                if np.isfinite(ic):
                    daily_ics.append(ic)

        fold_mean_ic = float(np.mean(daily_ics)) if daily_ics else 0.0
        fold_ics.append(fold_mean_ic)
        logger.info(f"  Fold {k + 1}/{n_splits}: {len(train_dates)} train dates → {len(test_dates)} test dates | MoE OOS IC = {fold_mean_ic:+.4f} ({len(daily_ics)} test dates)")

    mean_ic = float(np.mean(fold_ics)) if fold_ics else 0.0
    std_ic = float(np.std(fold_ics)) if len(fold_ics) > 1 else 0.01
    icir = mean_ic / (std_ic + 1e-9)
    t_stat = mean_ic / (std_ic / np.sqrt(len(fold_ics))) if fold_ics else 0.0

    stats = {
        "mean_ic": mean_ic,
        "std_ic": std_ic,
        "icir": icir,
        "t_stat": t_stat,
        "n_folds": len(fold_ics),
    }
    return fold_ics, stats


def main():
    logger.info("=" * 78)
    logger.info("  HIERARCHICAL REGIME-GATED MOE WITH LATENT DENOISING TRAINING")
    logger.info("=" * 78)

    fs = FeatureStore(PROJECT_ROOT / "models" / "feature_cache")
    universe = load_universe_tickers()
    logger.info(f"Loaded {len(universe)} universe tickers from combined_universe.csv.")

    # 1. Fetch Prices (150 liquid names)
    price_dict = fetch_universe_prices(universe, period="2y", max_tickers=150)
    if len(price_dict) < 20:
        logger.error(f"Too few tickers downloaded ({len(price_dict)}). Aborting.")
        return 1

    # 2. Extract Sector-Neutralized Factor Panels
    pipeline = UniverseFeaturePipeline(feature_store=fs)
    logger.info("Extracting, standardizing, and sector-neutralizing factor panels from cache...")
    neutralized_panels = pipeline.extract_technical_factors(price_dict, sector_neutralize=True)
    logger.info(f"Active panels: {len(neutralized_panels)} factors across {len(price_dict)} valid equity series.")

    # 3. Build Training Frame with Triple-Barrier Labels
    logger.info("Building multi-factor training panel with path-dependent triple-barrier labeling...")
    df_train = pipeline.build_training_dataset(price_dict, neutralized_panels, forward_days=10, rebalance_step=5, method="triple_barrier")
    logger.info(f"Training dataset: {df_train.shape[0]:,} observations × {df_train.shape[1]} columns.")

    # 4. Select Top IC Features (Strict Target Leakage Shield)
    logger.info("Selecting Top 25 factors via cross-sectional Information Coefficient...")
    selected_features, ic_stats = pipeline.select_top_ic_factors(df_train, max_factors=25, min_abs_ic=0.012)
    logger.info(f"Selected {len(selected_features)} top factors: {selected_features[:5]} ...")

    # 5. Build Benchmark Series for Macro Gating
    all_dates = sorted(df_train.index.get_level_values("date").unique())
    # Equal-weighted cross-sectional return as market proxy
    close_df = pd.DataFrame({s: df["close"] for s, df in price_dict.items() if "close" in df.columns})
    bench_returns = close_df.pct_change().mean(axis=1).dropna()

    # 6. Run Purged WFO Cross-Validation
    fold_ics, wfo_stats = run_purged_wfo_moe(
        df_train=df_train,
        feature_cols=selected_features,
        benchmark_series=bench_returns,
        n_splits=4,
        forward_days=10,
    )
    logger.info("Purged WFO Cross-Validation Results:")
    logger.info(f"  Mean OOS IC: {wfo_stats['mean_ic']:+.4f}")
    logger.info(f"  ICIR:        {wfo_stats['icir']:.2f}")
    logger.info(f"  t-statistic: {wfo_stats['t_stat']:.2f}")

    # 7. Fit Final Hierarchical MoE on Full Sample
    logger.info("Fitting production HierarchicalMoEPredictor on full sample...")
    X_full = df_train[selected_features]
    y_full = df_train["forward_return"]
    tickers_full = list(df_train.index.get_level_values("ticker"))

    moe = HierarchicalMoEPredictor(denoise_method="rmt", latent_dim=4)
    moe.fit(X_full, y_full.values, tickers=tickers_full, benchmark_returns=bench_returns)

    # 8. Score Dispersion & Predictions
    preds_full = moe.predict(X_full, tickers=tickers_full)
    if isinstance(preds_full, pd.Series):
        pred_arr = preds_full.values
    else:
        pred_arr = np.asarray(preds_full, dtype=float)

    p_min, p_max = float(np.min(pred_arr)), float(np.max(pred_arr))
    p_mean, p_std = float(np.mean(pred_arr)), float(np.std(pred_arr))
    logger.info(f"Production Score Distribution: Min={p_min:+.4f} | Max={p_max:+.4f} | Mean={p_mean:+.4f} | Std={p_std:.4f}")

    # 9. Cost-Aware Turnover & Net Sharpe Evaluation (15 bps Indian costs)
    df_eval = pd.DataFrame({"pred": pred_arr, "ret": y_full.values}, index=X_full.index)
    p_matrix = df_eval["pred"].unstack(level="ticker")
    r_matrix = df_eval["ret"].unstack(level="ticker")
    cost_res = evaluate_turnover_and_costs(p_matrix, r_matrix, holding_days=10, cost_bps=15.0)
    logger.info("Cost-Aware Strategy Evaluation (15 bps Indian Costs):")
    if cost_res:
        logger.info(f"  Annualized Net Return:     {cost_res.get('annualized_net_return', 0.0)*100:+.2f}%")
        logger.info(f"  Annualized Net Volatility: {cost_res.get('annualized_net_volatility', 0.0)*100:.2f}%")
        logger.info(f"  Net Sharpe Ratio:          {cost_res.get('net_sharpe_ratio', 0.0):.2f}")
        logger.info(f"  Annualized Turnover:       {cost_res.get('annualized_turnover', 0.0):.1f}x")
        logger.info(f"  Statutory Cost Applied:    {cost_res.get('cost_bps_applied', 15.0):.1f} bps")

    # 10. Wrap in AlphaEngine-Compatible Structure & Serialize
    engine = AlphaEngine(model_type="hierarchical_moe")
    engine._fitted_model = moe
    engine._feature_names = selected_features
    engine._train_tickers = list(price_dict.keys())
    engine._processed_panels = {f: neutralized_panels[f] for f in selected_features if f in neutralized_panels}
    engine._benchmark = bench_returns

    model_dir = PROJECT_ROOT / "models"
    model_dir.mkdir(parents=True, exist_ok=True)
    model_path = model_dir / "ml_alpha_model.pkl"

    logger.info(f"Serializing production model to {model_path}...")
    with open(model_path, "wb") as f:
        pickle.dump(engine, f, protocol=pickle.HIGHEST_PROTOCOL)

    file_size = os.path.getsize(model_path)
    file_size_mb = file_size / (1024 * 1024)
    logger.info(f"Model serialized successfully! File size: {file_size:,} bytes ({file_size_mb:.2f} MB)")

    # 11. Generate SHA-256 Manifest
    sha256_hash = hashlib.sha256(open(model_path, "rb").read()).hexdigest()
    sha_path = model_dir / "ml_alpha_model.pkl.sha256"
    with open(sha_path, "w", encoding="utf-8") as f:
        f.write(sha256_hash + "\n")
    logger.info(f"SHA-256 manifest written: {sha256_hash}")

    # 12. Verification Load
    logger.info("Verifying model unpickling and CPU safety...")
    with open(model_path, "rb") as f:
        loaded = pickle.load(f)
    test_preds = loaded.predict()
    logger.info(f"Verification load SUCCESS! Produced {len(test_preds)} active alpha predictions.")
    logger.info("=" * 78)
    logger.info("  HIERARCHICAL MOE PRODUCTION UPGRADE COMPLETE")
    logger.info("=" * 78)


if __name__ == "__main__":
    main()
