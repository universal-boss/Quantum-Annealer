"""scripts/train_institutional_alpha.py
======================================
Institutional Alpha Model Training & Cross-Validation Driver.

Graduates the active ML model from an 8-feature toy to a production-grade
cross-sectional alpha engine:
  1. Universe: 150+ liquid equities from combined_universe.csv.
  2. Features: 100+ factors (factors_100.py + alt_factors.py).
  3. Standardization: Daily 1%/99% winsorization + robust Median/MAD z-score.
  4. Feature Selection: Cross-sectional Information Coefficient (IC) ranking.
  5. Validation: Purged Walk-Forward Cross-Validation (WFO with embargo).
  6. Model Ensemble: ExpandedAlphaEnsemble (Ridge, LightGBM, CatBoost,
     ElasticNet, BayesianRidge, StackingSuperLearner).
  7. Artifact Hygiene: Weights saved to models/ml_alpha_model.pkl (< 1.5 MB),
     factor panels saved to Parquet FeatureStore, SHA-256 sidecar updated.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import pickle
import sys
import time
from datetime import date, datetime
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd

# Set up project root on sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("train_institutional_alpha")

from data.price_feed import safe_download
from ml_alpha.engine import AlphaEngine
from ml_alpha.expanded_ensemble import ExpandedAlphaEnsemble
from ml_alpha.feature_store import FeatureStore
from ml_alpha.universe_pipeline import (
    UniverseFeaturePipeline,
    load_universe_tickers,
    winsorize_and_standardize_cross_section,
)


def fetch_universe_prices(
    tickers: List[str],
    period: str = "2y",
    max_tickers: int = 150,
) -> Dict[str, pd.DataFrame]:
    """Fetch 2-year OHLCV for the top liquid universe tickers."""
    target_tickers = tickers[:max_tickers]
    logger.info(f"Downloading historical OHLCV for {len(target_tickers)} universe tickers (period={period})...")
    t0 = time.time()

    # Batch download in chunks of 50 to maximize throughput and avoid timeouts
    chunk_size = 50
    price_dict: Dict[str, pd.DataFrame] = {}

    for i in range(0, len(target_tickers), chunk_size):
        chunk = target_tickers[i : i + chunk_size]
        logger.info(f"  Fetching batch {i // chunk_size + 1}/{(len(target_tickers) + chunk_size - 1) // chunk_size} ({len(chunk)} tickers)...")
        raw = safe_download(chunk, period=period, auto_adjust=True)
        if raw.empty:
            continue

        for ticker in chunk:
            try:
                if isinstance(raw.columns, pd.MultiIndex):
                    # MultiIndex: (field, ticker) or (ticker, field)
                    if ticker in raw.columns.get_level_values(1):
                        sub = raw.xs(ticker, axis=1, level=1)
                    elif ticker in raw.columns.get_level_values(0):
                        sub = raw.xs(ticker, axis=1, level=0)
                    else:
                        continue
                else:
                    sub = raw

                cols = {c.lower(): c for c in sub.columns}
                if "close" in cols:
                    df = pd.DataFrame(index=sub.index)
                    for f in ("open", "high", "low", "close", "volume"):
                        if f in cols:
                            df[f] = sub[cols[f]].astype(float)
                        elif "close" in cols:
                            df[f] = sub[cols["close"]].astype(float)
                    df = df.dropna(subset=["close"])
                    if len(df) >= 120:  # Minimum 6 months of data
                        price_dict[ticker] = df
            except Exception as e:
                logger.debug(f"Error parsing {ticker}: {e}")

    elapsed = round(time.time() - t0, 2)
    logger.info(f"Downloaded valid prices for {len(price_dict)}/{len(target_tickers)} tickers in {elapsed}s")
    return price_dict


def run_purged_walk_forward_cv(
    df_train: pd.DataFrame,
    feature_cols: List[str],
    n_splits: int = 4,
    forward_days: int = 10,
) -> Tuple[List[float], Dict[str, float]]:
    """Run Purged Walk-Forward Cross-Validation across distinct temporal folds."""
    dates = pd.DatetimeIndex(sorted(df_train.index.get_level_values("date").unique()))
    n_dates = len(dates)
    fold_size = n_dates // (n_splits + 1)

    fold_ics: List[float] = []
    logger.info(f"Starting Purged Walk-Forward Cross-Validation ({n_splits} folds, {n_dates} total dates)...")

    for k in range(n_splits):
        train_end_idx = fold_size * (k + 1)
        test_start_idx = train_end_idx
        test_end_idx = min(train_end_idx + fold_size, n_dates)

        # PURGE: Drop trailing forward_days from train to eliminate label overlap leakage
        purge_end_idx = max(20, train_end_idx - forward_days)
        train_dates = dates[:purge_end_idx]
        test_dates = dates[test_start_idx:test_end_idx]

        train_mask = df_train.index.get_level_values("date").isin(train_dates)
        test_mask = df_train.index.get_level_values("date").isin(test_dates)

        X_train = df_train.loc[train_mask, feature_cols]
        y_train = df_train.loc[train_mask, "forward_return"]
        X_test = df_train.loc[test_mask, feature_cols]
        y_test = df_train.loc[test_mask, "forward_return"]

        if len(X_train) < 100 or len(X_test) < 20:
            continue

        # Fit model on train
        model = ExpandedAlphaEnsemble(
            model_type="ensemble",
            use_meta_label=False,
            use_xgboost=False,
            use_catboost=True,
            use_mlp=False,
        )
        model.fit(
            X_train,
            y_train,
            label_horizon_days=forward_days,
            groups=X_train.index.get_level_values("date"),
        )

        # Predict on test
        preds = model.predict(X_test)
        df_test_res = pd.DataFrame({
            "pred": preds,
            "actual": y_test.values,
        }, index=X_test.index)

        # Calculate daily cross-sectional Spearman IC
        daily_ics = []
        for dt, grp in df_test_res.groupby(level="date"):
            if len(grp) >= 5 and grp["pred"].std() > 1e-6 and grp["actual"].std() > 1e-6:
                ic = float(grp["pred"].corr(grp["actual"], method="spearman"))
                if np.isfinite(ic):
                    daily_ics.append(ic)

        fold_mean_ic = float(np.mean(daily_ics)) if daily_ics else 0.0
        fold_ics.append(fold_mean_ic)
        logger.info(f"  Fold {k + 1}/{n_splits}: {len(train_dates)} train dates → {len(test_dates)} test dates | OOS IC = {fold_mean_ic:+.4f} (over {len(daily_ics)} dates)")

    mean_ic = float(np.mean(fold_ics)) if fold_ics else 0.0
    std_ic = float(np.std(fold_ics)) if len(fold_ics) > 1 else 0.01
    icir = mean_ic / (std_ic + 1e-9)
    t_stat = mean_ic / (std_ic / np.sqrt(len(fold_ics))) if fold_ics else 0.0

    stats = {
        "mean_ic": mean_ic,
        "std_ic": std_ic,
        "icir": icir,
        "t_stat": t_stat,
        "n_folds": len(fold_ics),
    }
    logger.info(f"WFO Results: Mean OOS IC = {mean_ic:+.4f} | ICIR = {icir:.2f} | t-stat = {t_stat:.2f}")
    return fold_ics, stats


def main():
    logger.info("=" * 70)
    logger.info("INSTITUTIONAL ML ALPHA RETRAINING PIPELINE")
    logger.info("=" * 70)

    # 1. Universe
    tickers = load_universe_tickers()
    logger.info(f"Loaded {len(tickers)} tickers from combined_universe.csv")

    # 2. Fetch Prices (150 liquid names)
    prices = fetch_universe_prices(tickers, period="2y", max_tickers=150)
    if len(prices) < 20:
        logger.error(f"Too few tickers downloaded ({len(prices)}). Aborting.")
        return 1

    # 3. Compute 100+ Factors with Sector Neutralization
    feature_store = FeatureStore(PROJECT_ROOT / "models" / "feature_cache")
    pipeline = UniverseFeaturePipeline(feature_store=feature_store)
    logger.info("Extracting, standardizing, and sector-neutralizing 100+ factor panels...")
    panels = pipeline.extract_technical_factors(prices, sector_neutralize=True)
    logger.info(f"Extracted {len(panels)} sector-neutralized factor panels across {len(prices)} tickers")

    # 3.5 Extract PIT Audited Fundamental Panels (Zero-Lookahead)
    logger.info("Extracting Point-in-Time audited fundamental panels (Sloan, Piotroski, Novy-Marx, ROE, D/E)...")
    dates_list = sorted(list(next(iter(panels.values())).index)) if panels else []
    pit_panels = pipeline.extract_pit_fundamental_factors(list(prices.keys()), dates_list, sector_neutralize=True)
    if pit_panels:
        logger.info(f"Extracted and merged {len(pit_panels)} PIT fundamental factor panels: {list(pit_panels.keys())}")
        panels.update(pit_panels)

    # 4. Build Training Dataset with Triple-Barrier Path-Dependent Labels
    logger.info("Building pooled cross-sectional training dataset with triple-barrier labels...")
    df_train = pipeline.build_training_dataset(prices, panels, forward_days=10, rebalance_step=5, method="triple_barrier")
    logger.info(f"Training dataset: {len(df_train):,} rows × {len(df_train.columns) - 1} features")

    # 5. Feature Selection via IC
    logger.info("Selecting top-IC alpha factors...")
    selected_features, ic_stats = pipeline.select_top_ic_factors(df_train, max_factors=25, min_abs_ic=0.012)
    logger.info(f"Selected {len(selected_features)} top factors for production ensemble:")
    for f in selected_features[:10]:
        st = ic_stats.get(f, {})
        logger.info(f"  {f:25s} | Mean IC: {st.get('mean_ic', 0):+.4f} | IR: {st.get('ir', 0):.2f} | t-stat: {st.get('t_stat', 0):.2f}")

    # 6. Purged Walk-Forward Cross-Validation
    fold_ics, wfo_stats = run_purged_walk_forward_cv(
        df_train,
        selected_features,
        n_splits=4,
        forward_days=10,
    )

    # 7. Final Model Training on All Observations
    logger.info(f"Training final production ExpandedAlphaEnsemble on all {len(df_train):,} observations...")
    X_all = df_train[selected_features]
    y_all = df_train["forward_return"]

    final_model = ExpandedAlphaEnsemble(
        model_type="ensemble",
        use_meta_label=True,
        use_xgboost=False,
        use_catboost=True,
        use_mlp=False,
    )
    meta_lbls = df_train.get("tb_label")
    final_model.fit(
        X_all,
        y_all,
        meta_labels=meta_lbls,
        label_horizon_days=10,
        groups=df_train.index.get_level_values("date"),
    )

    # 7.5 Turnover and Realistic Transaction Cost Evaluation (15 bps round-trip)
    logger.info("Evaluating Long-Short top quintile turnover and net Sharpe after 15 bps Indian costs...")
    try:
        from ml_alpha.universe_pipeline import evaluate_turnover_and_costs
        close_matrix = pd.DataFrame({t: df["close"] for t, df in prices.items()}).dropna(how="all")
        fwd_matrix = close_matrix.shift(-10) / close_matrix - 1.0
        # Build date-by-ticker predictions across recent dates
        pred_matrix = pd.DataFrame(index=close_matrix.index, columns=close_matrix.columns)
        for dt in df_train.index.get_level_values("date").unique()[-40:]:
            if dt in df_train.index:
                sub_X = df_train.xs(dt, level="date")[selected_features]
                if len(sub_X) > 10:
                    pred_matrix.loc[dt, sub_X.index] = final_model.predict(sub_X)
        cost_eval = evaluate_turnover_and_costs(pred_matrix.dropna(how="all"), fwd_matrix, holding_days=10, cost_bps=15.0)
        if cost_eval:
            logger.info(f"  Annualized Net Return (after costs): {cost_eval['annualized_net_return']*100:.2f}%")
            logger.info(f"  Annualized Turnover:                {cost_eval['annualized_turnover']:.2f}x")
            logger.info(f"  Net Sharpe Ratio (post 15 bps):     {cost_eval['net_sharpe_ratio']:.2f}")
    except Exception as e:
        logger.warning(f"Turnover evaluation notice: {e}")

    # 8. Save Panels to FeatureStore (Parquet)
    saved_panels = pipeline.save_to_feature_store(panels, version="v1")
    logger.info(f"Saved {saved_panels} factor panels into Parquet FeatureStore")

    # 9. Package into AlphaEngine
    logger.info("Packaging final AlphaEngine...")
    engine = AlphaEngine(model_type="blend")
    engine._fitted_model = final_model
    engine._feature_names = selected_features
    engine._train_tickers = sorted(list(prices.keys()))
    engine._historical_ics = fold_ics
    engine._best_hyperparams = {}
    engine._feature_store = feature_store
    # Critical artifact hygiene: omit heavy dataframes from pickle
    engine._factor_panels = {}
    engine._processed_panels = {f: panels[f] for f in selected_features if f in panels}
    engine._prices_df = None

    # Check Feature Drift
    drift_res = engine.detect_drift()
    logger.info(f"Feature Drift Detection: drift_detected={drift_res.get('drift_detected')} (drift_ratio={drift_res.get('drift_ratio', 0)*100:.1f}%)")

    # Verify predict() works
    logger.info(f"Verifying AlphaEngine.predict() across {len(engine._train_tickers)} universe stocks...")
    preds = engine.predict()
    logger.info(f"Generated {len(preds)} predictions. Summary:")
    if isinstance(preds, pd.Series):
        scores = preds.values.tolist()
    elif isinstance(preds, dict):
        scores = list(preds.values())
    else:
        scores = list(preds)
    logger.info(f"  Min: {np.min(scores):.4f} | Max: {np.max(scores):.4f} | Mean: {np.mean(scores):.4f} | Std: {np.std(scores):.4f}")

    # 10. Persist Model and SHA-256 Manifest
    pkl_path = PROJECT_ROOT / "models" / "ml_alpha_model.pkl"
    sha_path = PROJECT_ROOT / "models" / "ml_alpha_model.pkl.sha256"

    with open(pkl_path, "wb") as f:
        pickle.dump(engine, f, protocol=pickle.HIGHEST_PROTOCOL)

    raw_bytes = pkl_path.read_bytes()
    new_sha256 = hashlib.sha256(raw_bytes).hexdigest().lower()
    sha_path.write_text(new_sha256 + "\n", encoding="utf-8")

    size_mb = len(raw_bytes) / (1024 * 1024)
    logger.info("=" * 70)
    logger.info("TRAINING COMPLETE & MODEL PERSISTED")
    logger.info(f"  Artifact Path:     {pkl_path} ({size_mb:.2f} MB)")
    logger.info(f"  SHA-256 Manifest:  {new_sha256}")
    logger.info(f"  Universe Coverage: {len(engine._train_tickers)} stocks")
    logger.info(f"  Features Count:    {len(selected_features)} institutional factors")
    logger.info(f"  WFO Mean OOS IC:   {wfo_stats['mean_ic']:+.4f} (vs baseline +0.0042)")
    logger.info(f"  WFO ICIR:          {wfo_stats['icir']:.2f}")
    logger.info("=" * 70)
    return 0


if __name__ == "__main__":
    sys.exit(main())
