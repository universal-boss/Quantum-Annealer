"""
verify_round7.py — Quantum_Annealer Round 7 verification script.

Runs all Round 7 smoke tests in one shot:
  1. HAR-RV module self-smoke (math_engine.har_rv)
  2. HAR-RV → optimizer_risk end-to-end wiring
  3. VPIN preflight pre-trade helper dispatch logic
  4. BVC VPIN monotonicity fix
  5. Bollinger ddof=1 P2-2 fix
  6. Skew warning P2-3 wiring
  7. yfinance lazy import P2-4 fix (data_layer + data.price_feed)
  8. P2 assertRaises/pytest.warns regression suite (tests/test_p2_audit_fixes.py)

Exits 0 if everything passes; non-zero on any failure.
"""
from __future__ import annotations

import sys
import os
import subprocess

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(PROJECT_ROOT)
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)


def banner(msg: str) -> None:
    line = "=" * 72
    print(f"\n{line}\n{msg}\n{line}")


def run_check(name: str, fn) -> bool:
    banner(f"CHECK: {name}")
    try:
        fn()
        print(f"  ✓ PASS: {name}")
        return True
    except Exception as e:
        print(f"  ✗ FAIL: {name}: {e}")
        import traceback
        traceback.print_exc()
        return False


def check_har_rv_module_smoke():
    """HAR-RV self-smoke test (intraday-RV + daily-RV paths)."""
    from math_engine import har_rv
    har_rv._smoke_test()


def check_har_rv_optimizer_wiring():
    """HAR-RV → optimizer_risk end-to-end."""
    import numpy as np
    import pandas as pd
    from optimizer_risk import compute_har_rv_volatility, apply_har_rv_size_adjustment

    rng = np.random.default_rng(7)
    n = 200
    close = pd.Series(100 * np.exp(np.cumsum(rng.normal(0, 0.012, n))))
    close.index = pd.date_range("2024-01-01", periods=n, freq="B")

    # 1) Direct compute call
    r = compute_har_rv_volatility(close)
    assert r["success"], f"HAR-RV compute should succeed: {r.get('error')}"
    assert r["regime"] in {"LOW", "NORMAL", "ELEVATED", "STRESS"}
    assert r["vol_d1_pct"] > 0

    # 2) Size adjustment preserves cash sleeve + renormalizes
    base = {"A": 0.30, "B": 0.25, "C": 0.20, "D": 0.05, "CASH": 0.20}
    scaled, report = apply_har_rv_size_adjustment(base, close)
    assert abs(scaled["CASH"] - 0.20) < 1e-6, f"Cash sleeve must be preserved: {scaled['CASH']}"
    assert abs(sum(scaled.values()) - 1.0) < 1e-6, f"Total must be 1.0: {sum(scaled.values())}"
    risky_sum = sum(v for k, v in scaled.items() if k != "CASH")
    assert abs(risky_sum - 0.80) < 1e-4, f"Risky sleeve must sum to 0.80: {risky_sum}"


def check_vpin_preflight_dispatch():
    """VPIN preflight PASS/THROTTLE/BLOCK dispatch via synthetic data."""
    import sys
    import types
    import numpy as np
    import pandas as pd

    # Stub data.price_feed
    pf_mod = types.ModuleType("data.price_feed")
    def _make_mock(trend_strength=0.0):
        rng = np.random.default_rng(99)
        n = 50
        idx = pd.date_range("2024-01-01", periods=n, freq="15min")
        rets = rng.normal(trend_strength, 0.0008, n)
        close = pd.Series(100 * np.exp(np.cumsum(rets)), index=idx)
        vol = pd.Series(rng.integers(10000, 50000, n).astype(float), index=idx)
        def _mock(tickers, period="1mo", interval=None):
            out = {}
            for t in tickers:
                out[t] = pd.DataFrame({"Close": close, "Volume": vol,
                                        "Open": close, "High": close*1.001, "Low": close*0.999})
            if len(out) == 1:
                return list(out.values())[0]
            return pd.concat(out, axis=1)
        return _mock

    saved_pf = sys.modules.get("data.price_feed")
    try:
        sys.modules["data.price_feed"] = pf_mod
        from optimizer_broker import preflight_vpin_toxicity_check

        # PASS path: balanced random walk
        pf_mod.safe_download = _make_mock(trend_strength=0.0)
        weights = {"A": 0.50, "B": 0.30, "CASH": 0.20}
        r = preflight_vpin_toxicity_check(weights, cfg={"VPIN_PREFLIGHT_ENABLED": True})
        assert r["success"]
        assert not r["blocked"], f"Balanced data should PASS, got blocked=True with max_vpin={r['max_vpin']}"

        # BLOCK path: strong trend
        pf_mod.safe_download = _make_mock(trend_strength=0.005)
        r = preflight_vpin_toxicity_check(weights, cfg={"VPIN_PREFLIGHT_ENABLED": True})
        assert r["success"]
        assert r["blocked"], f"Strong trend should BLOCK, got blocked=False with max_vpin={r['max_vpin']}"

        # Disabled path
        r = preflight_vpin_toxicity_check(weights, cfg={"VPIN_PREFLIGHT_ENABLED": False})
        assert not r["success"]
        assert not r["blocked"]
    finally:
        if saved_pf is not None:
            sys.modules["data.price_feed"] = saved_pf
        else:
            sys.modules.pop("data.price_feed", None)


def check_bvc_vpin_monotonicity():
    """BVC VPIN must be monotone in trend strength."""
    import numpy as np
    import pandas as pd
    from math_engine.microstructure import MicrostructureEngine

    rng = np.random.default_rng(42)
    n = 100
    vol = pd.Series(rng.integers(1000, 5000, n).astype(float))
    close_flat = pd.Series(np.full(n, 100.0))
    close_random = pd.Series(100 * np.exp(np.cumsum(rng.normal(0, 0.001, n))))
    close_trend = pd.Series(100 * np.exp(np.cumsum(rng.normal(0.003, 0.0001, n))))

    vpin_flat = MicrostructureEngine.compute_vpin(close_flat, vol)
    vpin_random = MicrostructureEngine.compute_vpin(close_random, vol)
    vpin_trend = MicrostructureEngine.compute_vpin(close_trend, vol)

    assert vpin_flat < vpin_random, f"flat({vpin_flat}) should be < random({vpin_random})"
    assert vpin_random < vpin_trend, f"random({vpin_random}) should be < trend({vpin_trend})"


def check_bollinger_ddof1():
    """P2-2: Bollinger must use ddof=1 (sample std)."""
    import numpy as np
    from math_engine.indicators import _calc_bollinger

    rng = np.random.default_rng(7)
    close = rng.normal(100, 2, 25).astype(np.float64)
    _, _, _, _, _, std_returned = _calc_bollinger(close, period=20, num_std=2.0)
    expected = float(np.std(close[-20:], ddof=1))
    assert abs(std_returned - expected) < 1e-6, f"Bollinger std should be {expected}, got {std_returned}"


def check_skew_warning_wired():
    """P2-3: skew warning must not be a `return False` stub."""
    import sys
    import types
    import pandas as pd

    # Stub data_layer
    stub_dl = types.ModuleType("data_layer")
    stub_dl.fetch_options_chain = lambda *a, **kw: pd.DataFrame([
        {"option_type": "put", "delta": -0.25, "implied_vol": 0.18}
    ])
    saved_dl = sys.modules.get("data_layer")
    sys.modules["data_layer"] = stub_dl
    try:
        from optimizer_compliance import evaluate_options_skew_warning
        from math_engine import derivatives as deriv_mod
        from unittest import mock

        with mock.patch.object(deriv_mod, "build_vol_surface",
                               return_value=pd.DataFrame({"option_type": ["put"], "delta": [-0.25], "implied_vol": [0.18]})), \
             mock.patch.object(deriv_mod, "compute_vol_skew",
                               return_value={"skew": 0.02, "atm_vol": 0.12, "call_25d_iv": 0.10, "put_25d_iv": 0.12}):
            r = evaluate_options_skew_warning("RELIANCE.NS", threshold=0.01, cfg={"SPOT_PRICE": 100.0})
        assert r is True, "Skew warning should return True when skew (2%) >= threshold (1%)"
    finally:
        if saved_dl is not None:
            sys.modules["data_layer"] = saved_dl
        else:
            sys.modules.pop("data_layer", None)


def check_yfinance_lazy_import():
    """P2-4: data_layer AND data.price_feed must survive missing yfinance."""
    import sys
    saved_yf = sys.modules.pop("yfinance", None)
    saved_pf = sys.modules.pop("data.price_feed", None)
    saved_dl = sys.modules.pop("data_layer", None)
    sys.modules["yfinance"] = None  # forces ImportError
    try:
        try:
            import data_layer  # noqa: F401
            # If we got here, the lazy import guard worked
            assert hasattr(data_layer, "yf"), "data_layer must expose yf attribute"
        except ImportError as ie:
            assert "yfinance" not in str(ie).lower(), \
                f"data_layer import blocked by yfinance: {ie} — P2-4 regression"
    finally:
        sys.modules.pop("yfinance", None)
        if saved_yf is not None:
            sys.modules["yfinance"] = saved_yf
        if saved_pf is not None:
            sys.modules["data.price_feed"] = saved_pf
        if saved_dl is not None:
            sys.modules["data_layer"] = saved_dl
        sys.modules.pop("data_layer", None)
        sys.modules.pop("data.price_feed", None)
        sys.modules.pop("data.universe", None)


def check_p2_test_suite():
    """Run the full tests/test_p2_audit_fixes.py unittest suite."""
    result = subprocess.run(
        [sys.executable, "-m", "unittest", "tests.test_p2_audit_fixes", "-v"],
        cwd=PROJECT_ROOT,
        capture_output=True,
        text=True,
        check=False,  # AUDIT-FIX (Round 4 — W1510): explicit check=False (returncode inspected below)
    )
    print(result.stdout[-3000:])
    if result.returncode != 0:
        print("STDERR (tail):")
        print(result.stderr[-1500:])
        raise RuntimeError(f"tests.test_p2_audit_fixes failed with exit code {result.returncode}")


def main() -> int:
    banner("Quantum_Annealer Round 7 — Smoke Verification")
    checks = [
        ("HAR-RV module self-smoke",                check_har_rv_module_smoke),
        ("HAR-RV → optimizer_risk end-to-end",      check_har_rv_optimizer_wiring),
        ("VPIN preflight PASS/BLOCK dispatch",     check_vpin_preflight_dispatch),
        ("BVC VPIN monotonicity",                  check_bvc_vpin_monotonicity),
        ("Bollinger ddof=1 (P2-2)",                 check_bollinger_ddof1),
        ("Skew warning wired (P2-3)",               check_skew_warning_wired),
        ("yfinance lazy import (P2-4)",             check_yfinance_lazy_import),
        ("P2 regression suite (26 tests)",          check_p2_test_suite),
    ]
    passes = 0
    failures = 0
    for name, fn in checks:
        if run_check(name, fn):
            passes += 1
        else:
            failures += 1

    banner(f"ROUND 7 SUMMARY: {passes}/{len(checks)} checks PASS, {failures} FAIL")
    return 0 if failures == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
