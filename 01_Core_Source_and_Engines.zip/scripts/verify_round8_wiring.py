"""verify_round8_wiring.py — Round 8 integration smoke tests.

Tests that R8-1, R8-2, and R8-3 are correctly wired:
  R8-1: DRO-CVaR wiring in optimizer.py (checks code presence + functional)
  R8-2: Institutional DSR upgrade in ml_alpha/metrics.py
  R8-3: Triple-barrier meta-labeling fix in expanded_ensemble.py

Run from the project root:
    cd "/Users/deepak/Desktop/Quantum Annealer"
    python scripts/verify_round8_wiring.py
"""
import sys, os, traceback, re
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

import numpy as np
import pandas as pd

_PASS = "✅ PASS"
_FAIL = "❌ FAIL"
_results = []

def check(name, condition, detail=""):
    icon = _PASS if condition else _FAIL
    print(f"  {icon}  {name}" + (f" — {detail}" if detail else ""))
    _results.append((name, condition))

# ── R8-1: DRO-CVaR ───────────────────────────────────────────────────────────
print("\n── R8-1: Wasserstein DRO-CVaR wiring (optimizer.py) ──────────────────")
try:
    with open(os.path.join(_PROJECT_ROOT, "optimizer.py"), "r", encoding="utf-8") as _f:
        _opt_src = _f.read()
    check("R8-1a: USE_DRO_CVAR guard present", 'working_cfg.get("USE_DRO_CVAR"' in _opt_src)
    check("R8-1b: apply_dro_cvar_constraint imported", "apply_dro_cvar_constraint as _dro_fn" in _opt_src)
    _sebi_pos = _opt_src.index("apply_sebi_constraints")
    _dro_pos  = _opt_src.index("USE_DRO_CVAR")
    check("R8-1c: DRO applied AFTER SEBI constraints", _dro_pos > _sebi_pos)
    # Find the DRO block and verify apply_weight_constraints appears WITHIN it
    _dro_block_match = re.search(
        r'USE_DRO_CVAR.*?(?=Scale weights in bear market)',
        _opt_src, re.DOTALL
    )
    _dro_block = _dro_block_match.group(0) if _dro_block_match else ""
    check("R8-1d: weight_constraints re-applied post-DRO",
          "apply_weight_constraints(weights, working_cfg)" in _dro_block)
except Exception as e:
    check("R8-1: optimizer.py source audit", False, str(e))

try:
    from optimizer_risk import apply_dro_cvar_constraint
    rng = np.random.default_rng(42)
    _rets = rng.normal(0, 0.01, (60, 5))
    _w0 = np.ones(5) / 5.0
    _res = apply_dro_cvar_constraint(_rets, _w0, epsilon=0.05, alpha=0.05)
    check("R8-1e: returns dict", isinstance(_res, dict))
    _w_out = np.array(_res.get("weights", []))
    check("R8-1f: weights present", len(_w_out) == 5)
    check("R8-1g: weights sum ≈ 1", abs(_w_out.sum() - 1.0) < 0.02, f"sum={_w_out.sum():.4f}")
    check("R8-1h: all weights ≥ 0", bool((_w_out >= -1e-9).all()), f"min={_w_out.min():.6f}")
    check("R8-1i: source field present", "source" in _res)
except Exception as e:
    check("R8-1: apply_dro_cvar_constraint functional", False, traceback.format_exc()[-200:])

# ── R8-2: Institutional DSR ────────────────────────────────────────────────
print("\n── R8-2: Institutional DSR upgrade (ml_alpha/metrics.py) ─────────────")
try:
    _met_path = os.path.join(_PROJECT_ROOT, "ml_alpha", "metrics.py")
    with open(_met_path, "r", encoding="utf-8") as _f:
        _met_src = _f.read()
    check("R8-2a: institutional DSR import present", "math_engine.institutional.deflated_sharpe" in _met_src)
    check("R8-2b: R8-2 comment present", "R8-2" in _met_src)
    check("R8-2c: three-tier fallback (institutional→dsr_calc→inline)",
          _met_src.count("except Exception:") >= 2 and "dsr_calculator" in _met_src and "norm.cdf" in _met_src)
except Exception as e:
    check("R8-2: metrics.py source audit", False, str(e))

try:
    from ml_alpha.metrics import deflated_sharpe_ratio as _dsr_fn
    from scipy.stats import norm as _norm_dist
    _d1 = _dsr_fn(observed_sharpe=2.5, n_trials=10, sample_length=252)
    check("R8-2d: positive Sharpe → DSR in [0,1]", isinstance(_d1, float) and 0.0 <= _d1 <= 1.0, f"got={_d1:.4f}")
    _d2 = _dsr_fn(observed_sharpe=-1.0, n_trials=1, sample_length=252)
    check("R8-2e: negative Sharpe → DSR in [0,1]", isinstance(_d2, float) and 0.0 <= _d2 <= 1.0, f"got={_d2:.4f}")
    _d3 = _dsr_fn(observed_sharpe=1.0, n_trials=100, sample_length=252)
    _d4 = _dsr_fn(observed_sharpe=1.0, n_trials=1,   sample_length=252)
    check("R8-2f: more trials → lower DSR (SR=1.0)", _d3 < _d4, f"100trials={_d3:.4f} 1trial={_d4:.4f}")
    check("R8-2g: not NaN/inf", np.isfinite(_d1) and np.isfinite(_d2))
except Exception as e:
    check("R8-2: deflated_sharpe_ratio functional", False, traceback.format_exc()[-300:])

# ── R8-3: Triple-barrier meta-labeling ────────────────────────────────────
print("\n── R8-3: Triple-barrier meta-labeling (expanded_ensemble.py) ──────────")
try:
    _ee_path = os.path.join(_PROJECT_ROOT, "ml_alpha", "expanded_ensemble.py")
    with open(_ee_path, "r", encoding="utf-8") as _f:
        _ee_src = _f.read()
    check("R8-3a: R8-3 comment present", "R8-3" in _ee_src)
    check("R8-3b: correct param 'prices='", "prices=_synthetic_price" in _ee_src)
    check("R8-3c: correct param 'upper_width='", "upper_width=2.0" in _ee_src)
    check("R8-3d: correct param 'vertical_days='", "vertical_days=10" in _ee_src)
    check("R8-3e: meta_labeling_target imported", "meta_labeling_target as _meta_target" in _ee_src)
    check("R8-3f: fit_meta_labeler imported", "fit_meta_labeler as _fit_meta" in _ee_src)
    check("R8-3g: ≥100 sample path exists", "n_samples >= 100" in _ee_src)
    check("R8-3h: LogisticRegression fallback present", "not _meta_fitted" in _ee_src)
except Exception as e:
    check("R8-3: expanded_ensemble.py source audit", False, str(e))

try:
    from ml_alpha.expanded_ensemble import ExpandedAlphaEnsemble
    rng2 = np.random.default_rng(99)
    _n, _k = 80, 10
    _X = pd.DataFrame(rng2.normal(0, 1, (_n, _k)), columns=[f"f{i}" for i in range(_k)])
    _y = pd.Series(rng2.normal(0, 0.01, _n))
    ee = ExpandedAlphaEnsemble(use_meta_label=True)
    _fit_res = ee.fit(_X, _y, meta_labels=None)
    check("R8-3i: fit() completes without error", True)
    check("R8-3j: meta_labeling in fit result", "meta_labeling" in _fit_res)
    _X_test = pd.DataFrame(rng2.normal(0, 1, (5, _k)), columns=[f"f{i}" for i in range(_k)])
    _preds = ee.predict(_X_test)
    check("R8-3k: predict returns Series of len 5", isinstance(_preds, pd.Series) and len(_preds) == 5)
    check("R8-3l: predictions all finite", bool(np.isfinite(_preds.values).all()))
except Exception as e:
    check("R8-3: ExpandedAlphaEnsemble functional", False, traceback.format_exc()[-300:])

# ── Regression: institutional modules importable ───────────────────────────
print("\n── Regression: institutional imports ───────────────────────────────────")
for _mod in ["math_engine.institutional.wasserstein_dro_cvar",
             "math_engine.institutional.deflated_sharpe",
             "math_engine.institutional.triple_barrier",
             "math_engine.institutional.almgren_chriss",
             "math_engine.institutional.hawkes_orderflow"]:
    try:
        import importlib; importlib.import_module(_mod)
        check(f"import {_mod.split('.')[-1]}", True)
    except Exception as _ie:
        check(f"import {_mod.split('.')[-1]}", False, str(_ie)[:80])

# ── Summary ──────────────────────────────────────────────────────────────────
print()
n_pass = sum(1 for _, ok in _results if ok)
n_fail = sum(1 for _, ok in _results if not ok)
print("=" * 60)
print(f"RESULT: {n_pass}/{len(_results)} checks passed, {n_fail} failed")
if n_fail == 0:
    print("RESULT: PASS — all Round 8 wiring verified ✅")
else:
    print("RESULT: FAIL — see failed checks above ❌")
    for n, ok in _results:
        if not ok:
            print(f"  - {n}")
    sys.exit(1)
