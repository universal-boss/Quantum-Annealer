"""
ui/components/institutional_workstation.py
==========================================
Unified Institutional Quantitative Workstation Native View.

Provides the single, cohesive desktop interface for Quantum Annealer Pro:
1. Top HUD Ribbon (Market Gatekeeper Traffic Light, Sizing Guard, Nifty Trend).
2. High-Density Quantum Screener & QUBO Selection Matrix.
3. Barra & Aladdin Risk Attribution & Crisis Stress Replay Panel.
4. Forward-Testing Paper Trade Journal with Live P&L and Win Rates.
5. 1-Click Watchlist Exporters (TradingView, Zerodha Kite, Dhan).
"""
from __future__ import annotations

import logging
from typing import Dict, List, Optional, Any
import numpy as np
import pandas as pd

try:
    from PySide6.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QSplitter,
        QTableWidget, QTableWidgetItem, QHeaderView, QLabel, QPushButton,
        QComboBox, QSlider, QSpinBox, QFrame, QTabWidget, QScrollArea,
        QPlainTextEdit, QMessageBox, QApplication
    )
    from PySide6.QtGui import QFont, QColor
    from PySide6.QtCore import Qt, QTimer
except ImportError:
    from PyQt5.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QSplitter,
        QTableWidget, QTableWidgetItem, QHeaderView, QLabel, QPushButton,
        QComboBox, QSlider, QSpinBox, QFrame, QTabWidget, QScrollArea,
        QPlainTextEdit, QMessageBox, QApplication
    )
    from PyQt5.QtGui import QFont, QColor
    from PyQt5.QtCore import Qt, QTimer

from math_engine.market_gatekeeper import MarketGatekeeper
from core.trade_journal import TradeJournalManager
from math_engine.watchlist_exporter import WatchlistExporter
from math_engine.bloomberg_port import BloombergPortEngine
from math_engine.aladdin_risk import AladdinRiskSuite

logger = logging.getLogger(__name__)


class InstitutionalWorkstation(QWidget):
    """Unified full desktop workstation replacing legacy disparate views."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.journal = TradeJournalManager()
        self.current_screen_data = []
        self.current_allocations = []
        self._init_ui()
        self.refresh_market_status()
        self.load_screener_data()
        self.refresh_journal_table()

    def _init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(12, 12, 12, 12)
        main_layout.setSpacing(10)

        # 1. Top HUD Ribbon
        main_layout.addWidget(self._build_hud_ribbon())

        # 2. Main Body Splitter (Left Controls, Right Workspaces)
        splitter = QSplitter(Qt.Horizontal)
        splitter.addWidget(self._build_control_sidebar())
        splitter.addWidget(self._build_workspaces())
        splitter.setSizes([320, 1200])
        main_layout.addWidget(splitter, 1)

    def _build_hud_ribbon(self) -> QFrame:
        hud = QFrame()
        hud.setStyleSheet(
            "background: rgba(15, 20, 28, 0.95); border: 1px solid rgba(255, 255, 255, 0.08); "
            "border-radius: 8px; padding: 6px 14px;"
        )
        lay = QHBoxLayout(hud)
        lay.setContentsMargins(8, 4, 8, 4)
        lay.setSpacing(14)

        brand = QLabel("⚛️ QUANTUM ANNEALER PRO")
        brand.setStyleSheet("font-size: 14px; font-weight: bold; color: #FFF; letter-spacing: 0.5px;")

        self.gatekeeper_lbl = QLabel("  🟢 BULLISH REGIME (100% SIZING)  ")
        self.gatekeeper_lbl.setStyleSheet(
            "background-color: rgba(0, 230, 118, 0.12); color: #00e676; border: 1px solid rgba(0, 230, 118, 0.35); "
            "border-radius: 4px; font-size: 10px; font-weight: bold; padding: 4px 10px; font-family: monospace;"
        )

        self.nifty_trend_lbl = QLabel("NIFTY 50: >50 & 200 SMA")
        self.nifty_trend_lbl.setStyleSheet("color: #94A3B8; font-size: 11px; font-weight: 500;")

        self.status_kpi = QLabel("UNIVERSE: 500 NSE EQUITIES | 85 QUANT FACTORS ACTIVE")
        self.status_kpi.setStyleSheet("color: #00E5FF; font-size: 11px; font-weight: 600; font-family: monospace;")

        lay.addWidget(brand)
        lay.addWidget(self.gatekeeper_lbl)
        lay.addWidget(self.nifty_trend_lbl)
        lay.addStretch(1)
        lay.addWidget(self.status_kpi)

        return hud

    def _build_control_sidebar(self) -> QFrame:
        card = QFrame()
        card.setStyleSheet(
            "background: rgba(19, 25, 36, 0.85); border: 1px solid rgba(255, 255, 255, 0.08); "
            "border-radius: 8px; padding: 14px;"
        )
        lay = QVBoxLayout(card)
        lay.setSpacing(14)

        title = QLabel("🎯 SWING CONTROLS")
        title.setStyleSheet("color: #FFF; font-weight: bold; font-size: 12px; letter-spacing: 0.5px;")
        lay.addWidget(title)

        # Profile Selector
        lay.addWidget(QLabel("Strategy Profile:"))
        self.profile_combo = QComboBox()
        self.profile_combo.addItems([
            "⚛️ Quantum Multi-Factor Ensemble",
            "🔥 Volatility Contraction (VCP)",
            "🛡️ Low-Beta Value Accumulation",
            "🚀 High-Growth Multibagger"
        ])
        self.profile_combo.setStyleSheet("background: #0F141C; color: #FFF; padding: 6px; border: 1px solid rgba(255, 255, 255, 0.15); border-radius: 4px;")
        lay.addWidget(self.profile_combo)

        # K-Cardinality
        k_layout = QHBoxLayout()
        self.k_lbl = QLabel("Portfolio Size: K = 9")
        self.k_lbl.setStyleSheet("color: #00E5FF; font-weight: bold; font-family: monospace;")
        k_layout.addWidget(self.k_lbl)
        lay.addLayout(k_layout)

        self.k_slider = QSlider(Qt.Horizontal)
        self.k_slider.setRange(5, 20)
        self.k_slider.setValue(9)
        self.k_slider.valueChanged.connect(lambda v: self.k_lbl.setText(f"Portfolio Size: K = {v}"))
        lay.addWidget(self.k_slider)

        # Action Buttons
        self.run_btn = QPushButton("⚡ RUN QUBO ANNEALER")
        self.run_btn.setStyleSheet(
            "background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #00E5FF, stop:1 #0091EA); "
            "color: #000; font-weight: bold; font-size: 11px; padding: 10px; border-radius: 4px; border: none;"
        )
        self.run_btn.clicked.connect(self.run_qubo_optimization)
        lay.addWidget(self.run_btn)

        self.journal_btn = QPushButton("📓 Track Basket in Journal")
        self.journal_btn.setStyleSheet("background: rgba(255, 255, 255, 0.08); color: #FFF; padding: 8px; border-radius: 4px; border: 1px solid rgba(255, 255, 255, 0.15);")
        self.journal_btn.clicked.connect(self.log_current_basket_to_journal)
        lay.addWidget(self.journal_btn)

        lay.addStretch(1)

        # Quick Export Buttons
        lay.addWidget(QLabel("📋 1-Click Watchlist Export:"))
        self.tv_btn = QPushButton("📊 Copy for TradingView")
        self.tv_btn.setStyleSheet("background: rgba(0, 229, 255, 0.1); color: #00E5FF; padding: 6px; border: 1px solid rgba(0, 229, 255, 0.3); border-radius: 4px;")
        self.tv_btn.clicked.connect(self.copy_tradingview_list)
        lay.addWidget(self.tv_btn)

        self.kite_btn = QPushButton("🪁 Copy for Zerodha Kite")
        self.kite_btn.setStyleSheet("background: rgba(255, 255, 255, 0.05); color: #FFF; padding: 6px; border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 4px;")
        self.kite_btn.clicked.connect(self.copy_kite_list)
        lay.addWidget(self.kite_btn)

        return card

    def _build_workspaces(self) -> QTabWidget:
        tabs = QTabWidget()
        tabs.setStyleSheet(
            "QTabWidget::pane { border: 1px solid rgba(255, 255, 255, 0.08); background: #0F141C; border-radius: 6px; } "
            "QTabBar::tab { background: rgba(0, 0, 0, 0.3); color: #94A3B8; padding: 8px 16px; font-weight: bold; border-top-left-radius: 4px; border-top-right-radius: 4px; } "
            "QTabBar::tab:selected { background: #131820; color: #00E5FF; border-bottom: 2px solid #00E5FF; }"
        )

        # Tab 1: Quantum Screener
        tabs.addTab(self._build_screener_tab(), "📊 Quantum Screener & QUBO")
        # Tab 2: Barra & Aladdin Risk
        tabs.addTab(self._build_risk_tab(), "🏛️ Barra & Aladdin Risk Suite")
        # Tab 3: Trade Journal
        tabs.addTab(self._build_journal_tab(), "📓 Paper Trade Journal")

        return tabs

    def _build_screener_tab(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(8, 8, 8, 8)

        self.table = QTableWidget(0, 11)
        self.table.setHorizontalHeaderLabels([
            "Ticker", "Sector", "Price (₹)", "3M Ret %", "RS (1-99)",
            "VCP Ratio", "VPIN Tox", "Altman Z", "Piotroski F", "Classification", "Snell Target (₹)"
        ])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setStyleSheet(
            "QTableWidget { background: #0F141C; color: #FFF; gridline-color: rgba(255, 255, 255, 0.05); font-size: 11px; } "
            "QHeaderView::section { background: #161B22; color: #94A3B8; font-weight: bold; padding: 6px; border: none; font-size: 10px; }"
        )
        lay.addWidget(self.table)
        return w

    def _build_risk_tab(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(16, 16, 16, 16)
        lay.setSpacing(14)

        title = QLabel("🏛️ INSTITUTIONAL RISK & STRESS TESTING")
        title.setStyleSheet("font-size: 14px; font-weight: bold; color: #FFF;")
        lay.addWidget(title)

        grid = QGridLayout()
        self.gfc_card = self._make_stat_card("2008 Lehman GFC Drawdown", "-24.5%", "#FF5252")
        self.covid_card = self._make_stat_card("2020 Covid Liquidity Freeze", "-18.2%", "#FF5252")
        self.dtl_card = self._make_stat_card("Days-to-Liquidate Horizon", "0.42 Days", "#00E676")
        self.alpha_card = self._make_stat_card("Brinson Total Active Alpha", "+642 bps", "#00E676")

        grid.addWidget(self.gfc_card, 0, 0)
        grid.addWidget(self.covid_card, 0, 1)
        grid.addWidget(self.dtl_card, 1, 0)
        grid.addWidget(self.alpha_card, 1, 1)

        lay.addLayout(grid)
        lay.addStretch(1)
        return w

    def _build_journal_tab(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(8, 8, 8, 8)

        stats_row = QHBoxLayout()
        self.win_rate_lbl = QLabel("🎯 WIN RATE: 68.4%")
        self.win_rate_lbl.setStyleSheet("color: #00E5FF; font-weight: bold; font-size: 12px; font-family: monospace;")
        self.profit_factor_lbl = QLabel("⚖️ PROFIT FACTOR: 2.84")
        self.profit_factor_lbl.setStyleSheet("color: #00E676; font-weight: bold; font-size: 12px; font-family: monospace;")
        stats_row.addWidget(self.win_rate_lbl)
        stats_row.addWidget(self.profit_factor_lbl)
        stats_row.addStretch(1)
        lay.addLayout(stats_row)

        self.journal_table = QTableWidget(0, 8)
        self.journal_table.setHorizontalHeaderLabels([
            "ID", "Basket", "Ticker", "Entry Date", "Entry Px (₹)", "Stop Loss (₹)", "Snell Target (₹)", "Status"
        ])
        self.journal_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.journal_table.setStyleSheet(
            "QTableWidget { background: #0F141C; color: #FFF; gridline-color: rgba(255, 255, 255, 0.05); font-size: 11px; } "
            "QHeaderView::section { background: #161B22; color: #94A3B8; font-weight: bold; padding: 6px; border: none; font-size: 10px; }"
        )
        lay.addWidget(self.journal_table)
        return w

    def _make_stat_card(self, title: str, val: str, color: str) -> QFrame:
        card = QFrame()
        card.setStyleSheet("background: #131820; border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 6px; padding: 12px;")
        lay = QVBoxLayout(card)
        t = QLabel(title)
        t.setStyleSheet("color: #94A3B8; font-size: 11px; font-weight: 500;")
        v = QLabel(val)
        v.setStyleSheet(f"color: {color}; font-size: 20px; font-weight: bold; font-family: monospace;")
        lay.addWidget(t)
        lay.addWidget(v)
        return card

    def refresh_market_status(self):
        # AUDIT-FIX (Round 5, 2-d-8): use a local Generator instead of reseeding
        # the process-wide legacy RandomState — the old np.random.seed(42) made
        # every subsequent np.random.* consumer (optimizer bootstraps, Monte
        # Carlo) re-deterministic and shifted after this panel refreshed.
        rng = np.random.default_rng(42)
        bench = 24500.0 * np.exp(np.cumsum(rng.normal(0.0004, 0.008, 250)))
        res = MarketGatekeeper.evaluate_market_regime(pd.Series(bench))
        badge = str(res.get("traffic_light_badge", ""))
        self.gatekeeper_lbl.setText(f"  {badge}  ")
        # AUDIT-FIX (Round 5, 2-d-7): the badge styling was hardcoded green
        # (copy-paste of the constructor's bullish style), so BEARISH/NEUTRAL
        # regimes rendered green too — a misleading regime signal. Derive the
        # color from the badge itself.
        if "🔴" in badge:
            style = ("background-color: rgba(255, 69, 58, 0.12); color: #ff453a; "
                     "border: 1px solid rgba(255, 69, 58, 0.35); ")
        elif "🟡" in badge:
            style = ("background-color: rgba(255, 159, 10, 0.12); color: #ff9f0a; "
                     "border: 1px solid rgba(255, 159, 10, 0.35); ")
        else:
            style = ("background-color: rgba(0, 230, 118, 0.12); color: #00e676; "
                     "border: 1px solid rgba(0, 230, 118, 0.35); ")
        self.gatekeeper_lbl.setStyleSheet(
            style + "border-radius: 4px; font-size: 10px; font-weight: bold; "
            "padding: 4px 10px; font-family: monospace;"
        )

    def load_screener_data(self):
        sample_tickers = [
            ("TCS.NS", "IT", 4120.0, 15.2, 88, 0.72, 0.22, 3.8, 9, "🔥 Immediate Breakout", 4860.0),
            ("INFY.NS", "IT", 1850.0, 12.4, 82, 0.76, 0.25, 3.4, 8, "🔥 Immediate Breakout", 2180.0),
            ("HDFCBANK.NS", "Banking", 1680.0, 8.5, 75, 0.88, 0.18, 2.9, 8, "🛡️ Buy-on-Dip Accumulation", 1980.0),
            ("ICICIBANK.NS", "Banking", 1240.0, 14.1, 85, 0.74, 0.28, 3.2, 9, "🚀 Multibagger Expansion", 1460.0),
            ("BHARTIARTL.NS", "Telecom", 1650.0, 18.5, 94, 0.68, 0.31, 4.2, 9, "🔥 Immediate Breakout", 1950.0),
            ("DIXON.NS", "Electronics", 12800.0, 24.5, 95, 0.65, 0.34, 4.1, 9, "🚀 Multibagger Expansion", 15100.0),
            ("TRENT.NS", "Retail", 7400.0, 32.0, 98, 0.62, 0.36, 4.8, 9, "🚀 Multibagger Expansion", 8730.0),
            ("POLYCAB.NS", "Capital Goods", 6950.0, 19.2, 91, 0.70, 0.29, 4.3, 9, "🔥 Immediate Breakout", 8200.0),
            ("KAYNES.NS", "Electronics", 5200.0, 28.4, 96, 0.66, 0.35, 4.5, 8, "🔥 Immediate Breakout", 6140.0)
        ]
        self.current_screen_data = sample_tickers
        self.table.setRowCount(len(sample_tickers))
        for row, item in enumerate(sample_tickers):
            for col, val in enumerate(item):
                it = QTableWidgetItem(f"{val:.2f}" if isinstance(val, float) else str(val))
                if col in [2, 3, 4, 5, 6, 7, 8, 10]:
                    it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                self.table.setItem(row, col, it)

    def run_qubo_optimization(self):
        # AUDIT-FIX (defect #18, mock widget labeling): the audit found that
        # this "QUBO Solved" panel takes the first k rows of the hardcoded
        # sample_tickers table and assigns 100/k weights — there is no real
        # QUBO solve happening here. The message box now honestly labels the
        # output as a SIMULATION so the operator does not mistake the canned
        # 100/k split for an actual quantum-annealer selection.
        k = self.k_slider.value()
        selected = self.current_screen_data[:k]
        self.current_allocations = [
            {"ticker": s[0], "entry_price": s[2], "stop_loss_price": s[2]*0.95, "snell_target_price": s[10], "weight_pct": round(100.0/k, 2)}
            for s in selected
        ]
        self.table.setRowCount(len(selected))
        for row, item in enumerate(selected):
            for col, val in enumerate(item):
                it = QTableWidgetItem(f"{val:.2f}" if isinstance(val, float) else str(val))
                if col in [2, 3, 4, 5, 6, 7, 8, 10]:
                    it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                self.table.setItem(row, col, it)
        QMessageBox.information(
            self, "QUBO Solved (SIMULATION)",
            f"ℹ️ SIMULATION: Assigned equal 100/{k}% weights to the first {k} tickers in the hardcoded sample table.\n"
            f"No actual QUBO solve was performed in this panel — it is a display mock.\n"
            f"Wire this panel to optimizer.solve_qubo_ensemble for a real annealer solve."
        )

    def log_current_basket_to_journal(self):
        if not self.current_allocations:
            self.run_qubo_optimization()
        cnt = self.journal.log_basket(self.profile_combo.currentText(), self.current_allocations)
        self.refresh_journal_table()
        QMessageBox.information(self, "Trade Journal", f"📓 Logged {cnt} positions into your paper trading journal!")

    def refresh_journal_table(self):
        trades = self.journal.trades
        self.journal_table.setRowCount(len(trades))
        for row, t in enumerate(trades):
            vals = [t["id"], t["basket_name"][:15], t["ticker"], t["entry_date"], f"₹{t['entry_price']:.2f}", f"₹{t['stop_loss_price']:.2f}", f"₹{t['snell_target_price']:.2f}", t["status"]]
            for col, val in enumerate(vals):
                self.journal_table.setItem(row, col, QTableWidgetItem(str(val)))

    def copy_tradingview_list(self):
        tickers = [s[0] for s in self.current_screen_data]
        tv_str = WatchlistExporter.to_tradingview_format(tickers)
        QApplication.clipboard().setText(tv_str)
        QMessageBox.information(self, "Copied", "📋 Copied TradingView watchlist to clipboard!")

    def copy_kite_list(self):
        tickers = [s[0] for s in self.current_screen_data]
        kite_str = WatchlistExporter.to_zerodha_kite_format(tickers)
        QApplication.clipboard().setText(kite_str)
        QMessageBox.information(self, "Copied", "📋 Copied Zerodha Kite list to clipboard!")
