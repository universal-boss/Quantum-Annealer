"""
ui/components/interactive_chart.py
===================================
Institutional-grade high-performance interactive charting canvas using QPainter.
Supports pan, zoom, crosshair, volume panels, and technical indicator overlays.
"""
from __future__ import annotations

import math
from datetime import datetime
import pandas as pd
import numpy as np

try:
    from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QSizePolicy
    from PySide6.QtGui import QPainter, QColor, QPen, QBrush, QFont, QMouseEvent, QWheelEvent, QCursor
    from PySide6.QtCore import Qt, QPoint, QRect, QSize, QTimer
except ImportError:
    try:
        from PyQt6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QSizePolicy
        from PyQt6.QtGui import QPainter, QColor, QPen, QBrush, QFont, QMouseEvent, QWheelEvent, QCursor
        from PyQt6.QtCore import Qt, QPoint, QRect, QSize, QTimer
    except ImportError:
        from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QSizePolicy
        from PyQt5.QtGui import QPainter, QColor, QPen, QBrush, QFont, QCursor
        from PyQt5.QtCore import Qt, QPoint, QRect, QSize, QTimer

def _qt_enum(namespace, attr: str, fallback):
    return getattr(namespace, attr, fallback)

_RenderHint = getattr(QPainter, "RenderHint", QPainter)
_AlignmentFlag = getattr(Qt, "AlignmentFlag", Qt)
_PenStyle = getattr(Qt, "PenStyle", Qt)
_MouseButton = getattr(Qt, "MouseButton", Qt)
_CursorShape = getattr(Qt, "CursorShape", Qt)

QT_ANTIALIASING = _qt_enum(_RenderHint, "Antialiasing", getattr(QPainter, "Antialiasing", None))
QT_ALIGN_CENTER = _qt_enum(_AlignmentFlag, "AlignCenter", getattr(Qt, "AlignCenter", None))
QT_DASH_LINE = _qt_enum(_PenStyle, "DashLine", getattr(Qt, "DashLine", None))
QT_SOLID_LINE = _qt_enum(_PenStyle, "SolidLine", getattr(Qt, "SolidLine", None))
QT_NO_PEN = _qt_enum(_PenStyle, "NoPen", getattr(Qt, "NoPen", None))
QT_DOT_LINE = _qt_enum(_PenStyle, "DotLine", getattr(Qt, "DotLine", None))
QT_LEFT_BUTTON = _qt_enum(_MouseButton, "LeftButton", getattr(Qt, "LeftButton", None))
QT_CLOSED_HAND_CURSOR = _qt_enum(_CursorShape, "ClosedHandCursor", getattr(Qt, "ClosedHandCursor", None))
QT_CROSS_CURSOR = _qt_enum(_CursorShape, "CrossCursor", getattr(Qt, "CrossCursor", None))

class InteractivePortfolioChart(QWidget):
    """
    A premium, high-performance interactive chart using native QPainter.
    No pyqtgraph or matplotlib dependency required.
    Features:
      - Smooth mouse wheel zoom (centered on cursor)
      - Left-click drag panning
      - Dynamic crosshair overlay with price and date hover labels
      - Custom dark mode styling (neon green and coral red)
      - Dynamic gridlines mapping price and dates
      - Volume sub-pane at the bottom
      - Technical indicators (e.g. 20-day Simple Moving Average overlay)
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMouseTracking(True)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMinimumHeight(300)

        # Chart Data
        self.df: pd.DataFrame | None = None
        self.dates: list = []
        self.closes: np.ndarray = np.array([])
        self.opens: np.ndarray = np.array([])
        self.highs: np.ndarray = np.array([])
        self.lows: np.ndarray = np.array([])
        self.volumes: np.ndarray = np.array([])
        self.indicator: np.ndarray = np.array([])  # 20-day SMA or similar

        # Viewport Range (Indices into the DataFrame)
        self.start_idx = 0
        self.end_idx = 0
        self.min_visible_bars = 15
        
        # Interaction States
        self.is_panning = False
        self.pan_start_x = 0
        self.pan_start_idx = 0
        self.crosshair_pos = QPoint(-1, -1)
        self.hovered_bar_idx = -1

        # Aesthetics / Palette
        self.color_bg = QColor(24, 24, 27)         # Slate 900
        self.color_grid = QColor(39, 39, 42, 100)   # Slate 800 with transparency
        self.color_bull = QColor(16, 185, 129)     # Emerald 500
        self.color_bear = QColor(239, 68, 68)       # Red 500
        self.color_text = QColor(212, 212, 216)     # Zinc 300
        self.color_muted = QColor(113, 113, 122)    # Zinc 500
        self.color_crosshair = QColor(161, 161, 170, 150) # Gray 400
        self.color_indicator = QColor(59, 130, 246) # Blue 500

    def set_data(self, df: pd.DataFrame):
        """Loads and prepares DataFrame for visualization."""
        if df is None or df.empty:
            self.df = None
            self.dates = []
            self.closes = np.array([])
            self.update()
            return

        # Handle MultiIndex if present
        import pandas as _pd
        if isinstance(df.columns, _pd.MultiIndex):
            # Extract first level/symbol
            cols = df.columns.get_level_values(0).unique()
            tickers = df.columns.get_level_values(1).unique()
            if tickers.size > 0:
                ticker = tickers[0]
                df = df.xs(ticker, axis=1, level=1)
        
        # Standardize columns
        df_clean = df.copy()
        df_clean.columns = [c.lower() for c in df_clean.columns]
        
        # Verify required columns exist
        required = ["open", "high", "low", "close"]
        if not all(col in df_clean.columns for col in required):
            # Attempt to use first four columns
            if df_clean.shape[1] >= 4:
                df_clean.columns = ["open", "high", "low", "close"][:df_clean.shape[1]] + list(df_clean.columns[4:])
            else:
                self.df = None
                self.update()
                return

        # AUDIT-FIX (Round 5, 2-d-4): drop NaN on ALL OHLC columns, not just
        # close — a row with valid close but NaN open/high/low survived and
        # int(NaN-derived floats) in paintEvent raised ValueError, wedging the
        # widget ("QPaintDevice: Cannot destroy paint device that is being
        # painted").
        self.df = df_clean.dropna(subset=["open", "high", "low", "close"])
        if self.df.empty:
            self.df = None
            self.update()
            return

        self.dates = [pd.to_datetime(d) for d in self.df.index]
        self.opens = self.df["open"].values.astype(float)
        self.highs = self.df["high"].values.astype(float)
        self.lows = self.df["low"].values.astype(float)
        self.closes = self.df["close"].values.astype(float)
        
        if "volume" in self.df.columns:
            # AUDIT-FIX (Round 5, 2-d-4): NaN volumes crashed the volume-bar
            # int() cast in paintEvent; sanitize to 0.
            self.volumes = np.nan_to_num(self.df["volume"].values.astype(float))
        else:
            self.volumes = np.zeros(len(self.df))

        # Calculate a 20-period simple moving average overlay
        self.indicator = self.df["close"].rolling(window=20).mean().values

        # Reset visible range to show the last 80 bars by default
        n_bars = len(self.df)
        self.end_idx = n_bars
        self.start_idx = max(0, n_bars - 80)

        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QT_ANTIALIASING)

        # 1. Background Fill
        painter.fillRect(self.rect(), self.color_bg)

        if self.df is None or len(self.closes) == 0:
            painter.setPen(self.color_muted)
            painter.setFont(QFont(".AppleSystemUIFont", 12))
            painter.drawText(self.rect(), QT_ALIGN_CENTER, "No Chart Data Loaded")
            # L27-fix: explicitly end the QPainter before this early return. Without this,
            # the painter is left active on a widget that's about to be destroyed by Qt,
            # which can produce "QPainter::begin: A paint device can only be painted by one
            # painter at a time." warnings on the next paint cycle.
            painter.end()
            return

        # 2. Geometry Setup
        margin_left = 12
        margin_right = 75
        margin_top = 25
        margin_bottom = 35
        
        w_chart = self.width() - margin_left - margin_right
        h_total = self.height() - margin_top - margin_bottom
        
        # Sub-pane layout: 80% Main Price, 20% Volume bars
        h_price = int(h_total * 0.82)
        h_vol = h_total - h_price - 10
        
        rect_price = QRect(margin_left, margin_top, w_chart, h_price)
        rect_vol = QRect(margin_left, margin_top + h_price + 10, w_chart, h_vol)

        # Visible bars slice
        sub_opens = self.opens[self.start_idx:self.end_idx]
        sub_highs = self.highs[self.start_idx:self.end_idx]
        sub_lows = self.lows[self.start_idx:self.end_idx]
        sub_closes = self.closes[self.start_idx:self.end_idx]
        sub_vols = self.volumes[self.start_idx:self.end_idx]
        sub_ind = self.indicator[self.start_idx:self.end_idx]
        n_visible = len(sub_closes)

        if n_visible == 0:
            # L27-fix: explicitly end the painter before this early return to avoid leaving
            # an active painter on the widget (same rationale as the empty-data branch above).
            painter.end()
            return

        # Bounds for scaling
        min_p = float(np.nanmin(sub_lows))
        max_p = float(np.nanmax(sub_highs))
        
        # Include indicator in scaling if present
        valid_ind = sub_ind[~np.isnan(sub_ind)]
        if len(valid_ind) > 0:
            min_p = min(min_p, float(np.nanmin(valid_ind)))
            max_p = max(max_p, float(np.nanmax(valid_ind)))

        # Add 5% padding to top/bottom of price pane
        price_diff = max_p - min_p if max_p != min_p else 1.0
        min_p -= price_diff * 0.05
        max_p += price_diff * 0.05
        price_range = max_p - min_p

        max_v = float(np.max(sub_vols)) if len(sub_vols) > 0 and np.max(sub_vols) > 0 else 1.0

        # Bar Width
        bar_w = w_chart / n_visible
        bar_gap = max(1.0, bar_w * 0.15)
        candle_w = max(1.0, bar_w - bar_gap)

        # Helper lambda to convert price to Y coordinate
        def get_y_price(price):
            if price_range == 0:
                return rect_price.bottom() - rect_price.height() // 2
            return int(rect_price.bottom() - ((price - min_p) / price_range) * rect_price.height())

        # 3. Draw Gridlines & Axes Labels
        grid_pen = QPen(self.color_grid, 1, QT_DASH_LINE)
        painter.setPen(grid_pen)
        painter.setFont(QFont(".AppleSystemUIFont", 8))

        # Horizontal Gridlines (Price)
        n_grid_lines = 5
        for i in range(n_grid_lines):
            val = min_p + (price_range / (n_grid_lines - 1)) * i
            y = get_y_price(val)
            # Draw line
            painter.setPen(grid_pen)
            painter.drawLine(rect_price.left(), y, rect_price.right(), y)
            # Draw label
            painter.setPen(self.color_muted)
            painter.drawText(rect_price.right() + 6, y + 4, f"{val:.2f}")

        # Vertical Gridlines (Time / Dates)
        date_step = max(1, n_visible // 5)
        for i in range(0, n_visible, date_step):
            idx = self.start_idx + i
            if idx >= len(self.dates):
                break
            x = int(rect_price.left() + i * bar_w + bar_w / 2)
            
            painter.setPen(grid_pen)
            painter.drawLine(x, rect_price.top(), x, rect_vol.bottom())
            
            painter.setPen(self.color_muted)
            date_str = self.dates[idx].strftime("%b %d")
            painter.drawText(x - 20, rect_vol.bottom() + 15, date_str)

        # 4. Draw Indicator Overlay (20 SMA)
        ind_points = []
        for i in range(n_visible):
            idx = self.start_idx + i
            val = self.indicator[idx]
            if not np.isnan(val):
                x = int(rect_price.left() + i * bar_w + bar_w / 2)
                y = get_y_price(val)
                ind_points.append(QPoint(x, y))

        if len(ind_points) > 1:
            painter.setPen(QPen(self.color_indicator, 2, QT_SOLID_LINE))
            for k in range(len(ind_points) - 1):
                painter.drawLine(ind_points[k], ind_points[k+1])

        # 5. Draw Candlesticks & Volume
        for i in range(n_visible):
            idx = self.start_idx + i
            
            op = sub_opens[i]
            hi = sub_highs[i]
            lo = sub_lows[i]
            cl = sub_closes[i]
            vl = sub_vols[i]

            x_center = rect_price.left() + i * bar_w + bar_w / 2
            x_left = x_center - candle_w / 2

            # Color Selection
            is_bull = cl >= op
            color = self.color_bull if is_bull else self.color_bear
            
            y_open = get_y_price(op)
            y_close = get_y_price(cl)
            y_high = get_y_price(hi)
            y_low = get_y_price(lo)

            # Draw Wick
            painter.setPen(QPen(color, 1.2))
            painter.drawLine(int(x_center), int(y_high), int(x_center), int(y_low))

            # Draw Body
            body_h = abs(y_close - y_open)
            body_y = min(y_open, y_close)
            if body_h < 1.0:
                body_h = 1.0  # Ensure dot/flat candle is visible
            
            painter.setBrush(QBrush(color))
            painter.setPen(QPen(color, 1))
            painter.drawRect(int(x_left), int(body_y), int(candle_w), int(body_h))

            # Draw Volume Bar
            vol_h = int((vl / max_v) * rect_vol.height()) if max_v > 0 else 0
            vol_y = rect_vol.bottom() - vol_h
            
            vol_color = QColor(color.red(), color.green(), color.blue(), 100) # Transparent
            painter.setBrush(QBrush(vol_color))
            painter.setPen(QT_NO_PEN)
            painter.drawRect(int(x_left), int(vol_y), int(candle_w), int(vol_h))

        # 6. Draw Crosshair & Hover Tooltip Details
        mouse_in_chart = rect_price.contains(self.crosshair_pos) or rect_vol.contains(self.crosshair_pos)
        if mouse_in_chart and self.hovered_bar_idx >= 0 and self.hovered_bar_idx < len(self.closes):
            h_idx = self.hovered_bar_idx
            x_cross = int(rect_price.left() + (h_idx - self.start_idx) * bar_w + bar_w / 2)
            y_cross = self.crosshair_pos.y()

            # Crosshair Lines
            cross_pen = QPen(self.color_crosshair, 1, QT_DOT_LINE)
            painter.setPen(cross_pen)
            painter.drawLine(x_cross, rect_price.top(), x_cross, rect_vol.bottom())
            painter.drawLine(rect_price.left(), y_cross, rect_price.right(), y_cross)

            # Label calculations
            # AUDIT-FIX (Round 5, 2-d-10): QFont.Weight.Bold is PySide6/PyQt6-
            # only and breaks this file's own PyQt5 fallback — construct the
            # font and setBold() instead (works on all three bindings).
            _f_bold = QFont(".AppleSystemUIFont", 8); _f_bold.setBold(True)
            painter.setFont(_f_bold)
            
            # Hovered Price label
            hover_price = min_p + ((rect_price.bottom() - y_cross) / rect_price.height()) * price_range
            price_str = f" {hover_price:.2f} "
            fm = painter.fontMetrics()
            lbl_w = fm.horizontalAdvance(price_str)
            lbl_h = fm.height() + 4
            
            # Background block for price label
            painter.setPen(QT_NO_PEN)
            painter.setBrush(QBrush(QColor(63, 63, 70)))
            painter.drawRect(rect_price.right() + 4, y_cross - lbl_h // 2, lbl_w, lbl_h)
            
            # Text drawing
            painter.setPen(self.color_text)
            painter.drawText(rect_price.right() + 6, y_cross + lbl_h // 4, price_str)

            # Hovered Date label
            hover_date = self.dates[h_idx].strftime("%Y-%m-%d")
            date_str = f" {hover_date} "
            lbl_w_dt = fm.horizontalAdvance(date_str)
            lbl_h_dt = fm.height() + 4
            
            painter.setPen(QT_NO_PEN)
            painter.setBrush(QBrush(QColor(63, 63, 70)))
            painter.drawRect(x_cross - lbl_w_dt // 2, rect_vol.bottom() + 4, lbl_w_dt, lbl_h_dt)
            
            painter.setPen(self.color_text)
            painter.drawText(x_cross - lbl_w_dt // 2 + 2, rect_vol.bottom() + 14, date_str)

            # Tooltip details at the top margin (O H L C V)
            op_v = self.opens[h_idx]
            hi_v = self.highs[h_idx]
            lo_v = self.lows[h_idx]
            cl_v = self.closes[h_idx]
            vl_v = self.volumes[h_idx]
            
            info_str = f"O: {op_v:.2f}  |  H: {hi_v:.2f}  |  L: {lo_v:.2f}  |  C: {cl_v:.2f}  |  V: {vl_v:,.0f}"
            # AUDIT-FIX (Round 5, 2-d-10): same PyQt5-compat fix as above.
            _f_mono = QFont("Courier New", 9); _f_mono.setBold(True)
            painter.setFont(_f_mono)
            painter.setPen(self.color_text)
            painter.drawText(rect_price.left() + 4, rect_price.top() - 8, info_str)
        else:
            # Default showing last visible price metrics at the top
            idx_last = self.end_idx - 1
            if 0 <= idx_last < len(self.closes):
                op_v = self.opens[idx_last]
                hi_v = self.highs[idx_last]
                lo_v = self.lows[idx_last]
                cl_v = self.closes[idx_last]
                vl_v = self.volumes[idx_last]
                info_str = f"Last Bar -> O: {op_v:.2f}  |  H: {hi_v:.2f}  |  L: {lo_v:.2f}  |  C: {cl_v:.2f}  |  V: {vl_v:,.0f}"
                # AUDIT-FIX (Round 5, 2-d-10): same PyQt5-compat fix as above.
                _f_mono = QFont("Courier New", 9); _f_mono.setBold(True)
                painter.setFont(_f_mono)
                painter.setPen(self.color_muted)
                painter.drawText(rect_price.left() + 4, rect_price.top() - 8, info_str)

    # ── Interaction Events ──────────────────────────────────────────────────
    def mousePressEvent(self, event: QMouseEvent):
        if event.button() == QT_LEFT_BUTTON:
            self.is_panning = True
            self.pan_start_x = event.pos().x()
            self.pan_start_idx = self.start_idx
            self.setCursor(QCursor(QT_CLOSED_HAND_CURSOR))
        self.update()

    def mouseReleaseEvent(self, event: QMouseEvent):
        if event.button() == QT_LEFT_BUTTON:
            self.is_panning = False
            self.setCursor(QCursor(QT_CROSS_CURSOR))
        self.update()

    def mouseMoveEvent(self, event: QMouseEvent):
        self.crosshair_pos = event.pos()
        
        # Calculate hovered index
        margin_left = 12
        margin_right = 75
        w_chart = self.width() - margin_left - margin_right
        
        n_visible = self.end_idx - self.start_idx
        if n_visible > 0 and w_chart > 0:
            bar_w = w_chart / n_visible
            relative_x = event.pos().x() - margin_left
            relative_bar = int(relative_x / bar_w)
            
            # Clip
            relative_bar = max(0, min(n_visible - 1, relative_bar))
            self.hovered_bar_idx = self.start_idx + relative_bar
        
        if self.is_panning and len(self.closes) > 0 and w_chart > 0 and n_visible > 0:
            delta_x = event.pos().x() - self.pan_start_x
            # L26-fix: guard w_chart > 0 and n_visible > 0 above to avoid ZeroDivisionError
            # in `w_chart / n_visible` when the chart has zero width or no visible bars.
            bars_shifted = int(delta_x / (w_chart / n_visible))
            
            new_start = self.pan_start_idx - bars_shifted
            new_end = new_start + n_visible
            
            # Constrain range
            if new_start >= 0 and new_end <= len(self.closes):
                self.start_idx = new_start
                self.end_idx = new_end
                
        self.update()

    def leaveEvent(self, event):
        self.crosshair_pos = QPoint(-1, -1)
        self.hovered_bar_idx = -1
        self.update()

    def wheelEvent(self, event: QWheelEvent):
        # Zoom centered around mouse hovered bar if valid
        n_visible = self.end_idx - self.start_idx
        if n_visible == 0:
            return

        # Zoom magnitude
        steps = event.angleDelta().y() / 120
        # AUDIT-FIX (Round 5, 2-d-5): a horizontal trackpad swipe / tilt-wheel
        # event has y()==0 — the old `1 if steps > 0 else -1` fallback then
        # picked −1 and zoomed OUT on every horizontal event. Ignore pure
        # horizontal deltas instead.
        if steps == 0:
            return
        zoom_bars = int(n_visible * 0.12 * steps)
        if zoom_bars == 0:
            zoom_bars = 1 if steps > 0 else -1

        # Center bar
        center_idx = self.hovered_bar_idx if (self.hovered_bar_idx >= 0) else (self.start_idx + n_visible // 2)

        # AUDIT-FIX (Round 5, 2-d-6): actually anchor the zoom at the cursor
        # bar. The docstring promises "zoom centered on cursor" but the anchor
        # was dead code — symmetric zoom let the bar under the cursor drift.
        # Keep the hovered bar's relative position fixed instead.
        anchor_frac = (center_idx - self.start_idx) / float(n_visible)
        new_n = n_visible - 2 * zoom_bars
        if new_n < self.min_visible_bars:
            new_n = self.min_visible_bars
        new_start = int(round(center_idx - anchor_frac * new_n))
        new_start = max(0, min(new_start, len(self.closes) - new_n))
        new_end = new_start + new_n

        self.start_idx = new_start
        self.end_idx = new_end
        self.update()
