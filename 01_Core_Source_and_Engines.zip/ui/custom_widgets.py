import os
import sys
import time
from pathlib import Path
try:
    from PySide6.QtWidgets import (
        QWidget, QLabel, QVBoxLayout, QHBoxLayout, QFrame, QPushButton,
        QComboBox, QSpinBox, QDoubleSpinBox, QCheckBox, QLineEdit, QFormLayout,
        QDialog, QTabWidget, QTableWidget, QTableWidgetItem, QHeaderView,
        QAbstractItemView, QToolButton, QSizePolicy, QMessageBox,
        QListWidget, QListWidgetItem, QPlainTextEdit, QGroupBox, QRadioButton, QMenu,
        QStyledItemDelegate
    )
    from PySide6.QtGui import (
        QPainter, QColor, QLinearGradient, QRadialGradient, QPen, QFont
    )
    from PySide6.QtCore import Qt, QPointF, QRectF, QTimer, Signal as pyqtSignal
except ImportError:
    from PyQt5.QtWidgets import (
        QWidget, QLabel, QVBoxLayout, QHBoxLayout, QFrame, QPushButton,
        QComboBox, QSpinBox, QDoubleSpinBox, QCheckBox, QLineEdit, QFormLayout,
        QDialog, QTabWidget, QTableWidget, QTableWidgetItem, QHeaderView,
        QAbstractItemView, QToolButton, QSizePolicy, QMessageBox,
        QListWidget, QListWidgetItem, QPlainTextEdit, QGroupBox, QRadioButton, QMenu,
        QStyledItemDelegate
    )
    from PyQt5.QtGui import (
        QPainter, QColor, QLinearGradient, QRadialGradient, QPen, QFont
    )
    from PyQt5.QtCore import Qt, QPointF, QRectF, QTimer, pyqtSignal

from ui.styling import _QSS
from utils import (
    _WATCHLIST, load_credentials, save_credentials,
    NSEClient, archlog, show_styled_message_box
)
from data_layer import get_active_universe

def _qmessagebox_enum_value(enum_name: str, value_name: str, fallback: int = 0):
    enum_obj = getattr(QMessageBox, enum_name, None)
    if enum_obj is not None and hasattr(enum_obj, value_name):
        return getattr(enum_obj, value_name)
    if hasattr(QMessageBox, value_name):
        return getattr(QMessageBox, value_name)
    return fallback

class _QMessageBoxIconCompat:
    Information = _qmessagebox_enum_value("Icon", "Information", 1)
    Warning = _qmessagebox_enum_value("Icon", "Warning", 2)
    Critical = _qmessagebox_enum_value("Icon", "Critical", 3)

_QMESSAGEBOX_ICON = _QMessageBoxIconCompat

class _DynamicTabMixin:
    """Adds universe badge + Refresh button to any analytical tab."""
    def _add_refresh_toolbar(self, parent_layout, refresh_fn):
        self._refresh_fn = refresh_fn
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 4)
        self._universe_badge = QLabel()
        self._update_universe_badge()
        self._universe_badge.setStyleSheet(
            "color:#7a9eb5;font-size:11px;padding:2px 6px;"
            "border:1px solid #2a3a42;border-radius:4px;")
        refresh_btn = QPushButton("🔄 Refresh")
        refresh_btn.setFixedHeight(26)
        refresh_btn.setStyleSheet(
            "QPushButton{background:#1e2a2e;color:#d0d0d0;border:1px solid #2a3a42;"
            "border-radius:4px;padding:0 10px;font-size:11px;}"
            "QPushButton:hover{background:#243540;}")
        refresh_btn.clicked.connect(lambda: (self._update_universe_badge(), self._refresh_fn()))
        row.addWidget(self._universe_badge)
        row.addStretch()
        row.addWidget(refresh_btn)
        parent_layout.insertLayout(0, row)

    def _update_universe_badge(self):
        u = get_active_universe()
        src_label = "Watchlist" if _WATCHLIST else "Nifty 50"
        if hasattr(self, "_universe_badge"):
            self._universe_badge.setText(
                f"📊 Universe: {len(u)} tickers  [{src_label}]")


class PlainBackground(QWidget):
    """Sleek Apple Silicon native window background."""
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # If in light mode, paint unified light gray workspace background (#f2f2f7)
        if CardFrame._FILL_TOP.red() > 100:
            painter.fillRect(self.rect(), QColor("#f2f2f7"))
        else:
            # Unified ultra-premium true deep black window background (#000000)
            painter.fillRect(self.rect(), QColor("#000000"))

# Alias
GlassBackground = PlainBackground


class CardFrame(QFrame):
    """Refined Apple Silicon native panel card with subtle border and 8px rounded corners."""
    _FILL_TOP = QColor(0, 0, 0, 255)  # True deep black uniform panel
    _FILL_MID = QColor(0, 0, 0, 255)
    _FILL_BOT = QColor(0, 0, 0, 255)

    def __init__(self, name: str = "Card"):
        super().__init__()
        self.setObjectName(name)
        self.setAttribute(Qt.WA_StyledBackground, False)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        rect = QRectF(self.rect())
        
        # If in light mode, paint standard clean light card background
        if self._FILL_TOP.red() > 100:
            grad = QLinearGradient(rect.topLeft(), rect.bottomLeft())
            grad.setColorAt(0.0, QColor(255, 255, 255, 255))
            grad.setColorAt(1.0, QColor(255, 255, 255, 255))
            painter.setBrush(grad)
            pen = QPen(QColor(209, 209, 214, 255), 1)  # Apple System Gray 4 border
            painter.setPen(pen)
            painter.drawRoundedRect(rect.adjusted(0.5, 0.5, -0.5, -0.5), 8, 8)
            return

        # Frosted card background
        grad = QLinearGradient(rect.topLeft(), rect.bottomLeft())
        grad.setColorAt(0.0, self._FILL_TOP)
        grad.setColorAt(0.5, self._FILL_MID)
        grad.setColorAt(1.0, self._FILL_BOT)
        
        painter.setBrush(grad)
        
        # Soft transparent Apple border line
        pen = QPen(QColor(255, 255, 255, 20), 1)
        painter.setPen(pen)
        
        # Draw the card with 8px rounded corners
        painter.drawRoundedRect(rect.adjusted(0.5, 0.5, -0.5, -0.5), 8, 8)

# Alias
GlassPanel = CardFrame


class MetricCard(QFrame):
    """KPI metric tile — layout + objectNames; QSS handles all rendering."""
    def __init__(self, title: str):
        super().__init__()
        self.setObjectName("MetricCard")
        self.setMinimumHeight(48)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(10, 6, 10, 6)
        lay.setSpacing(1)
        self.title_lbl = QLabel(title.upper())
        self.title_lbl.setObjectName("MetricTitle")
        self.value_lbl = QLabel("—")
        self.value_lbl.setObjectName("MetricValueDim")
        self.note_lbl  = QLabel("Waiting")
        self.note_lbl.setObjectName("MetricNote")
        lay.addWidget(self.title_lbl)
        lay.addWidget(self.value_lbl)
        lay.addWidget(self.note_lbl)

    def set_data(self, value, note=""):
        self.value_lbl.setObjectName("MetricValue")
        self.value_lbl.setText(str(value))
        self.note_lbl.setText(str(note) if note else "")
        self.value_lbl.style().unpolish(self.value_lbl)
        self.value_lbl.style().polish(self.value_lbl)

    def reset(self):
        self.value_lbl.setObjectName("MetricValueDim")
        self.value_lbl.setText("—")
        self.note_lbl.setText("Waiting")
        self.value_lbl.style().unpolish(self.value_lbl)
        self.value_lbl.style().polish(self.value_lbl)


class CollapsibleGroup(QFrame):
    def __init__(self, title, expanded=False):
        super().__init__()
        self.setObjectName("SectionCard")
        self.toggle = QToolButton()
        self.toggle.setCheckable(True)
        self.toggle.setChecked(expanded)
        self.toggle.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self.toggle.setArrowType(Qt.NoArrow)
        self.toggle.setText(("▼  " if expanded else "▶  ") + title)
        self.toggle.clicked.connect(self._on_toggle)
        self.body = QWidget()
        self.body.setVisible(expanded)
        self.body_layout = QVBoxLayout(self.body)
        self.body_layout.setContentsMargins(0, 8, 0, 0)
        self.body_layout.setSpacing(8)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(10, 10, 10, 10)
        outer.setSpacing(0)
        outer.addWidget(self.toggle)
        outer.addWidget(self.body)

    def _on_toggle(self):
        expanded = self.toggle.isChecked()
        self.toggle.setArrowType(Qt.DownArrow if expanded else Qt.RightArrow)
        self.body.setVisible(expanded)


class SettingsDialog(QDialog):
    """Polished Settings dialog matching the app's dark theme."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setWindowTitle("Settings")
        self.setMinimumSize(560, 500)
        self.setModal(True)
        self._creds = load_credentials()
        self._build()

    def _build(self):
        root = QVBoxLayout(self)
        root.setSpacing(0)
        root.setContentsMargins(0, 0, 0, 0)

        tabs = QTabWidget()
        tabs.setDocumentMode(True)
        tabs.addTab(self._tab_telegram(),   "  📨  Telegram  ")
        tabs.addTab(self._tab_angelone(),   "  😇  Angel One API  ")
        tabs.addTab(self._tab_automation(), "  ⚙   Automation  ")
        tabs.addTab(self._tab_copilot(),    "  🤖  AI Copilot  ")
        root.addWidget(tabs, 1)

        footer = QFrame()
        footer.setObjectName("FooterBar")
        fl = QHBoxLayout(footer); fl.setContentsMargins(20, 12, 20, 12); fl.setSpacing(10)
        cancel_btn = QPushButton("Cancel")
        cancel_btn.setObjectName("GhostButton")
        save_btn   = QPushButton("  💾  Save  ")
        save_btn.setObjectName("PrimaryButton")
        save_btn.setMinimumHeight(36); cancel_btn.setMinimumHeight(36)
        cancel_btn.setFixedWidth(90);  save_btn.setFixedWidth(120)
        save_btn.clicked.connect(self._on_save)
        cancel_btn.clicked.connect(self.reject)
        cache_btn = QPushButton("🗂  Cache Manager")
        cache_btn.setObjectName("SecondaryButton")
        cache_btn.setMinimumHeight(36)
        cache_btn.clicked.connect(lambda: CacheManagerDialog(self).exec())
        fl.addWidget(cache_btn); fl.addStretch(1)
        fl.addWidget(cancel_btn); fl.addWidget(save_btn)
        root.addWidget(footer)

    @staticmethod
    def _section(title):
        lbl = QLabel(title)
        lbl.setStyleSheet("color:currentColor; font-size:11px; font-weight:700; "
                          "letter-spacing:1px; text-transform:uppercase; "
                          "padding-bottom:4px; border-bottom:1px solid currentColor;")
        return lbl

    def _tab_telegram(self):
        w = QWidget()
        w.setObjectName("SettingsTab")
        lay = QVBoxLayout(w); lay.setContentsMargins(24, 20, 24, 20); lay.setSpacing(16)
        lay.addWidget(self._section("Telegram Notifications"))

        form = QFormLayout()
        form.setVerticalSpacing(8)
        form.setHorizontalSpacing(12)
        form.setLabelAlignment(Qt.AlignRight | Qt.AlignVCenter)
        form.setFieldGrowthPolicy(QFormLayout.ExpandingFieldsGrow)

        self.tg_enabled = QCheckBox("Send notification after every run")
        self.tg_enabled.setChecked(self._creds.get("TELEGRAM_ENABLED", False))

        self.tg_token = QLineEdit(self._creds.get("TELEGRAM_BOT_TOKEN", ""))
        self.tg_token.setPlaceholderText("Token from @BotFather  e.g. 7412356789:AAF_xKz…")
        self.tg_token.setEchoMode(QLineEdit.Password)
        self.tg_token.setMinimumHeight(34)

        self.tg_chatid = QLineEdit(self._creds.get("TELEGRAM_CHAT_ID", ""))
        self.tg_chatid.setPlaceholderText("Numeric Chat ID  e.g. 123456789")
        self.tg_chatid.setMinimumHeight(34)

        show_tok = QPushButton("👁"); show_tok.setFixedSize(34, 34); show_tok.setCheckable(True)
        show_tok.setStyleSheet(
            "QPushButton{background:transparent;border:1px solid %s;"
            "border-radius:5px;padding:0;font-size:14px;}"
            "QPushButton:checked{border-color:currentColor;}" % _QSS.BORDER_DARK)
        show_tok.toggled.connect(lambda on: self.tg_token.setEchoMode(
            QLineEdit.Normal if on else QLineEdit.Password))

        tok_row = QHBoxLayout(); tok_row.setSpacing(6)
        tok_row.addWidget(self.tg_token, 1); tok_row.addWidget(show_tok)

        test_btn = QPushButton("🧪  Test"); test_btn.setObjectName("TestButton")
        test_btn.clicked.connect(self._test_telegram)
        self._tg_test_btn = test_btn  # AUDIT-FIX (Round 6, D-P2-1): referenced by the threaded test handlers

        form.addRow("", self.tg_enabled)
        form.addRow("Bot Token", tok_row)
        form.addRow("Chat ID", self.tg_chatid)
        lay.addLayout(form)

        act_row = QHBoxLayout()
        note = QLabel("💡 Token & Chat ID are saved to disk — no re-entry on next launch")
        note.setStyleSheet("color:inherit; font-size:11px;")
        act_row.addWidget(note, 1); act_row.addWidget(test_btn)
        lay.addLayout(act_row)
        lay.addStretch(1)
        return w

    def _tab_angelone(self):
        w = QWidget()
        w.setObjectName("SettingsTab")
        lay = QVBoxLayout(w); lay.setContentsMargins(24, 20, 24, 20); lay.setSpacing(16)
        lay.addWidget(self._section("Angel One SmartAPI v2 Credentials"))

        form = QFormLayout()
        form.setVerticalSpacing(8)
        form.setHorizontalSpacing(12)
        form.setLabelAlignment(Qt.AlignRight | Qt.AlignVCenter)
        form.setFieldGrowthPolicy(QFormLayout.ExpandingFieldsGrow)

        self.angel_key = QLineEdit(self._creds.get("ANGELONE_API_KEY", self._creds.get("DHAN_CLIENT_ID", "")))
        self.angel_key.setPlaceholderText("API Key — e.g. SmartAPI Key from smartapi.angelone.in")
        self.angel_key.setMinimumHeight(34)
        self.dhan_key = self.angel_key  # Backward compatibility alias
        self.kite_key = self.angel_key

        self.angel_clientid = QLineEdit(self._creds.get("ANGELONE_CLIENT_ID", ""))
        self.angel_clientid.setPlaceholderText("Client Code — e.g. A123456")
        self.angel_clientid.setMinimumHeight(34)
        self.dhan_token = self.angel_clientid
        self.kite_token = self.angel_clientid

        self.angel_password = QLineEdit(self._creds.get("ANGELONE_PASSWORD", ""))
        self.angel_password.setPlaceholderText("Account Password / PIN")
        self.angel_password.setEchoMode(QLineEdit.Password)
        self.angel_password.setMinimumHeight(34)

        self.angel_totp = QLineEdit(self._creds.get("ANGELONE_TOTP_SECRET", ""))
        self.angel_totp.setPlaceholderText("TOTP Secret Key (from 2FA setup)")
        self.angel_totp.setEchoMode(QLineEdit.Password)
        self.angel_totp.setMinimumHeight(34)

        show_k = QPushButton("👁"); show_k.setFixedSize(34, 34); show_k.setCheckable(True)
        show_k.setStyleSheet(
            "QPushButton{background:transparent;border:1px solid %s;"
            "border-radius:5px;padding:0;font-size:14px;}"
            "QPushButton:checked{border-color:currentColor;}" % _QSS.BORDER_DARK)
        show_k.toggled.connect(lambda on: (
            self.angel_password.setEchoMode(QLineEdit.Normal if on else QLineEdit.Password),
            self.angel_totp.setEchoMode(QLineEdit.Normal if on else QLineEdit.Password)))

        pwd_row = QHBoxLayout(); pwd_row.setSpacing(6)
        pwd_row.addWidget(self.angel_password, 1); pwd_row.addWidget(show_k)

        self.angel_live = QCheckBox("⚠️  Live orders — sends REAL orders via Angel One SmartAPI (disables dry-run)")
        self.angel_live.setChecked(self._creds.get("ANGELONE_LIVE_ORDERS", self._creds.get("DHAN_LIVE_ORDERS", False)))
        self.angel_live.setObjectName("DangerCheck")
        self.dhan_live = self.angel_live
        self.kite_live = self.angel_live

        form.addRow("API Key", self.angel_key)
        form.addRow("Client Code", self.angel_clientid)
        form.addRow("Password / PIN", pwd_row)
        form.addRow("TOTP Secret", self.angel_totp)
        form.addRow("", self.angel_live)
        lay.addLayout(form)

        note = QLabel("💡 Angel One SmartAPI credentials are saved securely to your local disk.")
        note.setStyleSheet("color:inherit; font-size:11px;")
        lay.addWidget(note)
        lay.addStretch(1)
        return w

    def _tab_dhan(self):
        return self._tab_angelone()

    def _tab_kite(self):
        return self._tab_angelone()

    def _tab_automation(self):
        w = QWidget()
        w.setObjectName("SettingsTab")
        lay = QVBoxLayout(w); lay.setContentsMargins(24, 20, 24, 20); lay.setSpacing(16)
        lay.addWidget(self._section("Scheduled Auto-Run"))

        form = QFormLayout()
        form.setVerticalSpacing(8)
        form.setHorizontalSpacing(12)
        form.setLabelAlignment(Qt.AlignRight | Qt.AlignVCenter)
        form.setFieldGrowthPolicy(QFormLayout.ExpandingFieldsGrow)

        self.auto_enabled = QCheckBox("Enable scheduled auto-run")
        self.auto_enabled.setChecked(self._creds.get("AUTO_RUN_ENABLED", False))

        self.auto_interval = QSpinBox(); self.auto_interval.setRange(15, 1440)
        self.auto_interval.setSuffix("  min"); self.auto_interval.setMinimumHeight(34)
        self.auto_interval.setValue(int(self._creds.get("AUTO_RUN_INTERVAL_MIN", 60)))

        form.addRow("", self.auto_enabled)
        form.addRow("Interval", self.auto_interval)
        lay.addLayout(form)

        lay.addWidget(self._section("Export & Notifications"))

        form2 = QFormLayout()
        form2.setVerticalSpacing(8)
        form2.setHorizontalSpacing(12)
        form2.setLabelAlignment(Qt.AlignRight | Qt.AlignVCenter)
        form2.setFieldGrowthPolicy(QFormLayout.ExpandingFieldsGrow)
        self.auto_excel = QCheckBox("Auto-export Excel after every run")
        self.auto_excel.setChecked(self._creds.get("EXCEL_EXPORT_ENABLED", False))
        self.auto_memo  = QCheckBox("Auto-export Investment Memo (Markdown)")
        self.auto_memo.setChecked(self._creds.get("AUTO_EXPORT_MEMO", False))
        self.auto_tg    = QCheckBox("Send Telegram notification after run")
        self.auto_tg.setChecked(self._creds.get("TELEGRAM_ENABLED", False))
        form2.addRow("", self.auto_excel)
        form2.addRow("", self.auto_memo)
        form2.addRow("", self.auto_tg)
        lay.addLayout(form2)
        lay.addStretch(1)
        return w

    def _tab_copilot(self):
        w = QWidget()
        w.setObjectName("SettingsTab")
        lay = QVBoxLayout(w); lay.setContentsMargins(24, 20, 24, 20); lay.setSpacing(16)
        lay.addWidget(self._section("Gemini AI Configuration"))

        form = QFormLayout()
        form.setVerticalSpacing(8)
        form.setHorizontalSpacing(12)
        form.setLabelAlignment(Qt.AlignRight | Qt.AlignVCenter)
        form.setFieldGrowthPolicy(QFormLayout.ExpandingFieldsGrow)

        self.gemini_key = QLineEdit(self._creds.get("GEMINI_API_KEY", ""))
        self.gemini_key.setPlaceholderText("Enter your Gemini API key (e.g. AIzaSy...)")
        self.gemini_key.setEchoMode(QLineEdit.Password)
        self.gemini_key.setMinimumHeight(34)

        show_gemini = QPushButton("👁"); show_gemini.setFixedSize(34, 34); show_gemini.setCheckable(True)
        show_gemini.setStyleSheet(
            "QPushButton{background:transparent;border:1px solid %s;"
            "border-radius:5px;padding:0;font-size:14px;}"
            "QPushButton:checked{border-color:currentColor;}" % _QSS.BORDER_DARK)
        show_gemini.toggled.connect(lambda on: self.gemini_key.setEchoMode(
            QLineEdit.Normal if on else QLineEdit.Password))

        key_row = QHBoxLayout(); key_row.setSpacing(6)
        key_row.addWidget(self.gemini_key, 1); key_row.addWidget(show_gemini)

        form.addRow("API Key", key_row)

        self.gemini_model = GlassComboBox()
        self.gemini_model.setEditable(True)
        self.gemini_model.setMinimumHeight(34)
        models = [
            "gemini-2.0-flash",
            "gemini-3.5-flash",
            "gemini-1.5-flash",
            "gemini-1.5-pro",
            "gemini-2.5-flash",
            "gemini-2.0-pro-exp-02-05"
        ]
        self.gemini_model.addItems(models)
        saved_model = self._creds.get("GEMINI_MODEL", "gemini-2.0-flash")
        if saved_model not in models:
            self.gemini_model.insertItem(0, saved_model)
            self.gemini_model.setCurrentIndex(0)
        else:
            self.gemini_model.setCurrentText(saved_model)

        form.addRow("AI Model", self.gemini_model)
        lay.addLayout(form)

        note = QLabel("💡 A Gemini API key is needed to run interactive copilot queries and custom audits.\n"
                      "If empty, a rule-based portfolio audit builder will be used as a local fallback.")
        note.setWordWrap(True)
        note.setStyleSheet("color:inherit; font-size:11px;")
        lay.addWidget(note)
        lay.addStretch(1)
        return w

    def _on_save(self):
        creds = {
            "TELEGRAM_ENABLED":      self.tg_enabled.isChecked() or self.auto_tg.isChecked(),
            "TELEGRAM_BOT_TOKEN":    self.tg_token.text().strip(),
            "TELEGRAM_CHAT_ID":      self.tg_chatid.text().strip(),
            "ANGELONE_API_KEY":      self.angel_key.text().strip(),
            "ANGELONE_CLIENT_ID":    self.angel_clientid.text().strip(),
            "ANGELONE_PASSWORD":     self.angel_password.text().strip(),
            "ANGELONE_TOTP_SECRET":  self.angel_totp.text().strip(),
            "ANGELONE_LIVE_ORDERS":  self.angel_live.isChecked(),
            "DHAN_CLIENT_ID":        self.angel_clientid.text().strip(),
            "DHAN_ACCESS_TOKEN":     self.angel_key.text().strip(),
            "DHAN_LIVE_ORDERS":      self.angel_live.isChecked(),
            "KITE_API_KEY":          self.angel_key.text().strip(),
            "KITE_ACCESS_TOKEN":     self.angel_clientid.text().strip(),
            "KITE_LIVE_ORDERS":      self.angel_live.isChecked(),
            "AUTO_RUN_ENABLED":      self.auto_enabled.isChecked(),
            "AUTO_RUN_INTERVAL_MIN": self.auto_interval.value(),
            "EXCEL_EXPORT_ENABLED":  self.auto_excel.isChecked(),
            "AUTO_EXPORT_MEMO":      self.auto_memo.isChecked(),
            "GEMINI_API_KEY":        self.gemini_key.text().strip(),
            "GEMINI_MODEL":          self.gemini_model.currentText().strip(),
        }
        if save_credentials(creds):
            self.accept()
        else:
            show_styled_message_box(self, "Error", "❌  Could not write credentials file.", _QMESSAGEBOX_ICON.Warning)

    def _test_telegram(self):
        token, chat_id = self.tg_token.text().strip(), self.tg_chatid.text().strip()
        if not token or not chat_id:
            show_styled_message_box(self, "Missing Fields", "Enter Bot Token and Chat ID first.", _QMESSAGEBOX_ICON.Warning)
            return
        # AUDIT-FIX (Round 6, D-P2-11): NSEClient.post retries 3× with
        # timeout=8 + backoff + session renewals — called directly in the
        # button slot this froze the whole dialog for up to ~30 s on a bad
        # key/network (the main-window sibling _test_telegram already runs
        # threaded). Run the POST on a worker thread; marshal the outcome
        # back to the GUI thread via signals.
        from workers.worker_threads import _GenericNetworkWorker

        def _do_post():
            return NSEClient.post(
                f"https://api.telegram.org/bot{token}/sendMessage",
                json={"chat_id": chat_id, "text": "🤖 *QUBO* — test ✅", "parse_mode": "Markdown"},
                timeout=8)

        self._tg_test_btn.setEnabled(False)
        _worker = _GenericNetworkWorker(_do_post)
        self._tg_test_worker = _worker  # keep a reference alive

        def _on_ok(r):
            self._tg_test_btn.setEnabled(True)
            if getattr(r, "status_code", 0) == 200:
                show_styled_message_box(self, "Success", "✅  Test message sent!", _QMESSAGEBOX_ICON.Information)
            else:
                show_styled_message_box(self, "Failed", f"❌  Telegram error: {getattr(r, 'status_code', '?')}\n{getattr(r, 'text', '')}", _QMESSAGEBOX_ICON.Warning)

        def _on_err(e):
            self._tg_test_btn.setEnabled(True)
            show_styled_message_box(self, "Error", f"❌  Network / SSL error: {e}", _QMESSAGEBOX_ICON.Critical)

        _worker.result.connect(_on_ok)
        _worker.error.connect(_on_err)
        _worker.start()


class CacheManagerDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setWindowTitle("Cache Manager")
        self.setMinimumSize(500, 340)
        self._build_ui(); self._refresh()

    def _build_ui(self):
        lo = QVBoxLayout(self)
        lo.setSpacing(10); lo.setContentsMargins(18, 16, 18, 14)
        self._stats = QLabel(); self._stats.setObjectName("MutedText")
        lo.addWidget(self._stats)
        self._tbl = QTableWidget(0, 3)
        self._tbl.setHorizontalHeaderLabels(["File", "Size KB", "Age (s)"])
        self._tbl.setEditTriggers(QTableWidget.NoEditTriggers)
        self._tbl.setSelectionBehavior(QTableWidget.SelectRows)
        self._tbl.horizontalHeader().setStretchLastSection(True)
        self._tbl.verticalHeader().setVisible(False)
        lo.addWidget(self._tbl)
        row = QHBoxLayout()
        for lbl, obj, fn in [("Refresh", "SecondaryButton", self._refresh),
                              ("Clear Selected", "SecondaryButton", self._clear_sel)]:
            b = QPushButton(lbl); b.setObjectName(obj)
            b.setFixedHeight(28); b.clicked.connect(fn); row.addWidget(b)
        row.addStretch()
        ca = QPushButton("Clear All"); ca.setObjectName("PrimaryButton")
        ca.setFixedHeight(28); ca.clicked.connect(self._clear_all); row.addWidget(ca)
        row.addSpacing(6)
        cl = QPushButton("Close"); cl.setObjectName("GhostButton")
        cl.setFixedHeight(28); cl.clicked.connect(self.accept); row.addWidget(cl)
        lo.addLayout(row)

    def _cache(self):
        try:
            from qa_data.cache import DiskCache; return DiskCache()
        except ImportError as _e:
            return None

    def _refresh(self):
        c = self._cache()
        if c is None:
            self._stats.setText("qa_data not installed."); return
        s = c.stats()
        self._stats.setText(
            f"Entries: {s['entries']}   •   Size: {s['size_kb']} KB   •   Dir: {s['dir']}")
        files = sorted(Path(s['dir']).glob("*.pkl"),
                       key=lambda f: f.stat().st_mtime, reverse=True)
        self._tbl.setRowCount(len(files))
        now = time.time()
        for i, f in enumerate(files):
            st = f.stat()
            self._tbl.setItem(i, 0, QTableWidgetItem(f.name))
            self._tbl.setItem(i, 1, QTableWidgetItem(f"{st.st_size/1024:.1f}"))
            self._tbl.setItem(i, 2, QTableWidgetItem(f"{now - st.st_mtime:.0f}"))

    def _clear_sel(self):
        c = self._cache()
        if c is None: return
        s = c.stats()
        files = sorted(Path(s['dir']).glob("*.pkl"),
                       key=lambda f: f.stat().st_mtime, reverse=True)
        for idx in self._tbl.selectionModel().selectedRows():
            try: files[idx.row()].unlink(missing_ok=True)
            except Exception as _e:
                archlog.error('Exception detail', exc_info=True)
                pass
        self._refresh()

    def _clear_all(self):
        c = self._cache()
        if c is None: return
        n = c.clear()
        self._tbl.setSortingEnabled(False)
        self._stats.setText(f"Cleared {n} entries."); self._tbl.setRowCount(0)


class ApprovalDialog(QDialog):
    """Pre-trade approval gate. Writes immutable audit record to DatabaseStore."""

    approval_result = pyqtSignal(str, bool)

    def __init__(self, weights: dict, portfolio_value: float,
                 dry_run: bool = True, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_StyledBackground, True)
        self._weights         = weights
        self._portfolio_value = portfolio_value
        self._dry_run         = dry_run
        import uuid as _uuid
        self._order_ref = f"ORD-{_uuid.uuid4().hex[:12].upper()}"
        self._approved  = False
        self._build_ui()
        self.setWindowTitle("Order Approval" if not dry_run else "Dry-Run Review")
        self.setMinimumWidth(520)

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(12)
        layout.setContentsMargins(20, 20, 20, 16)
        # Header
        mode_color = "#f85149" if not self._dry_run else "#388bfd"
        mode_label = "⚠  LIVE ORDER" if not self._dry_run else "🔵  DRY-RUN SIMULATION"
        hdr = QLabel(mode_label)
        hdr.setStyleSheet(
            f"color:{mode_color};font-size:13px;font-weight:700;"
            f"padding:8px 12px;border-radius:6px;background:{mode_color}22;"
        )
        hdr.setAlignment(Qt.AlignCenter)
        layout.addWidget(hdr)
        # Order ref
        ref_lbl = QLabel(f"Reference:  {self._order_ref}")
        ref_lbl.setObjectName("MutedText")
        ref_lbl.setAlignment(Qt.AlignCenter)
        layout.addWidget(ref_lbl)
        # Basket table
        layout.addWidget(self._build_basket_table())
        # Summary
        n       = len(self._weights)
        tot_pct = sum(self._weights.values()) * 100
        est_val = self._portfolio_value * sum(self._weights.values())
        summary = QLabel(
            f"Stocks: {n}   •   Allocation: {tot_pct:.1f}%   •   Est. value: ₹{est_val:,.0f}"
        )
        summary.setObjectName("MutedText")
        summary.setAlignment(Qt.AlignCenter)
        layout.addWidget(summary)
        # Approver
        row1 = QHBoxLayout()
        row1.addWidget(QLabel("Approved by:"))
        self._approver_edit = QLineEdit()
        self._approver_edit.setPlaceholderText("Your name / user ID")
        row1.addWidget(self._approver_edit)
        layout.addLayout(row1)
        # Notes
        row2 = QHBoxLayout()
        row2.addWidget(QLabel("Notes:"))
        self._notes_edit = QLineEdit()
        self._notes_edit.setPlaceholderText("Reason / override (optional)")
        row2.addWidget(self._notes_edit)
        layout.addLayout(row2)
        # Confirm checkbox
        self._confirm_chk = QCheckBox(
            "I have reviewed the basket and confirm this order submission"
            if not self._dry_run else
            "I have reviewed the basket (dry-run — no real orders placed)"
        )
        # AUDIT-FIX (Round 5, 2-d-2): stateChanged(int) vs Qt.Checked enum — on
        # PySide6 >= 6.4 `s == Qt.Checked` compares int to enum member and is
        # always False, so the submit button could never be enabled. Use the
        # bool-emitting `toggled` signal instead.
        self._confirm_chk.toggled.connect(
            lambda checked: self._submit_btn.setEnabled(bool(checked)))
        layout.addWidget(self._confirm_chk)
        # Buttons
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        cancel_btn = QPushButton("Cancel")
        cancel_btn.setObjectName("GhostButton")
        cancel_btn.setFixedHeight(28)
        cancel_btn.clicked.connect(self._on_cancel)
        self._submit_btn = QPushButton(
            "Place Live Orders" if not self._dry_run else "Simulate (Dry Run)"
        )
        self._submit_btn.setObjectName("PrimaryButton")
        self._submit_btn.setFixedHeight(28)
        self._submit_btn.setEnabled(False)
        self._submit_btn.clicked.connect(self._on_submit)
        btn_row.addWidget(cancel_btn)
        btn_row.addSpacing(8)
        btn_row.addWidget(self._submit_btn)
        layout.addLayout(btn_row)

    def _build_basket_table(self) -> QTableWidget:
        cols = ["Ticker", "Weight %", "Est. Value ₹"]
        tbl  = QTableWidget(len(self._weights), len(cols))
        tbl.setHorizontalHeaderLabels(cols)
        tbl.setEditTriggers(QTableWidget.NoEditTriggers)
        tbl.setSelectionMode(QTableWidget.NoSelection)
        tbl.verticalHeader().setVisible(False)
        tbl.setMaximumHeight(min(len(self._weights) * 28 + 32, 200))
        tbl.horizontalHeader().setStretchLastSection(True)
        for row_i, (ticker, w) in enumerate(
                sorted(self._weights.items(), key=lambda x: -x[1])):
            tbl.setItem(row_i, 0, QTableWidgetItem(ticker))
            tbl.setItem(row_i, 1, QTableWidgetItem(f"{w * 100:.2f}%"))
            tbl.setItem(row_i, 2, QTableWidgetItem(
                f"₹{self._portfolio_value * w:,.0f}"))
        return tbl

    def _on_submit(self):
        self._approved = True
        self._write_audit(True)
        self.approval_result.emit(self._order_ref, True)
        self.accept()

    def _on_cancel(self):
        self._approved = False
        self._write_audit(False)
        self.approval_result.emit(self._order_ref, False)
        self.reject()

    def _write_audit(self, approved: bool):
        """AUDIT-FIX (Round 5, 2-d-1): _write_audit() was called by both
        _on_submit and _on_cancel but never defined — every button click
        raised AttributeError *before* accept()/reject() ran, so the dialog
        could never close and approval_result was never emitted. The audit
        trail is best-effort: failures are logged, never raised (the approval
        outcome must not be blocked by an audit-write hiccup)."""
        try:
            entry = (
                f"order_ref={self._order_ref} approved={approved} "
                f"dry_run={self._dry_run} "
                f"approver={self._approver_edit.text().strip()!r} "
                f"notes={self._notes_edit.text().strip()!r} "
                f"n_positions={len(self._weights)} "
                f"allocation_pct={sum(self._weights.values()) * 100:.2f}"
            )
            archlog.info("[ApprovalAudit] %s", entry)
            try:
                from qa_db import get_store
                store = get_store()
                if store is not None and hasattr(store, "save_note"):
                    store.save_note(self._order_ref, entry)
            except Exception as _store_err:
                archlog.warning(
                    "[ApprovalAudit] audit-store write failed (log-only): %s",
                    _store_err,
                )
        except Exception as _audit_err:
            archlog.error("[ApprovalAudit] audit write failed: %s", _audit_err)

    @property
    def order_ref(self) -> str:
        return self._order_ref

    @property
    def approved(self) -> bool:
        return self._approved


# ── Glass ComboBox / Menu styled entirely by QSS ─────────────────────────────
class GlassComboBox(QComboBox):
    """Standard QComboBox styled entirely by QSS."""
    def __init__(self, parent=None):
        super().__init__(parent)
        # H9-fix: use the already-imported QStyledItemDelegate (resolved at module top via the
        # PySide6/PyQt5 try/except) instead of hard-coding `from PySide6.QtWidgets import ...`,
        # which broke the binding-detection fallback on PyQt5-only installs.
        self.setItemDelegate(QStyledItemDelegate(self))


class GlassMenu(QMenu):
    """Standard QMenu styled entirely by QSS."""
    pass


# ── Provider Switcher Dialog ──────────────────────────────────────────────────
class ProviderSwitcherDialog(QDialog):
    """
    Switch DataProvider (YFinance / Bloomberg / Refinitiv) and
    DatabaseStore (SQLite / PostgreSQL) without restarting the app.
    """
    def __init__(self, status_bar=None, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_StyledBackground, True)
        self._status_bar = status_bar
        self.setWindowTitle("Provider Switcher")
        self.setMinimumWidth(460)
        self.setStyleSheet(f"""
            QDialog {{
                background-color: #0b0f19;
                color: #d0d0d0;
            }}
            QGroupBox {{
                background-color: #161b22;
                color: #d0d0d0;
                border: 1px solid #30363d;
                border-radius: 6px;
                margin-top: 12px;
                padding-top: 16px;
                font-weight: bold;
            }}
            QGroupBox::title {{
                subcontrol-origin: margin;
                subcontrol-position: top left;
                left: 12px;
                padding: 0 4px;
                color: #58a6ff;
            }}
            QRadioButton {{
                color: #d0d0d0;
                background: transparent;
                spacing: 8px;
                padding: 4px;
            }}
            QLabel {{
                color: #d0d0d0;
                background: transparent;
            }}
            QLineEdit {{
                background-color: #0d1117;
                color: #c9d1d9;
                border: 1px solid #30363d;
                border-radius: 4px;
                padding: 4px;
            }}
            QPushButton {{
                background-color: #21262d;
                color: #c9d1d9;
                border: 1px solid #30363d;
                border-radius: 4px;
                padding: 4px 12px;
            }}
            QPushButton:hover {{
                background-color: #30363d;
            }}
            QPushButton#PrimaryButton {{
                background-color: #238636;
                color: #ffffff;
                border: 1px solid #2ea44f;
            }}
            QPushButton#PrimaryButton:hover {{
                background-color: #2ea44f;
            }}
            QPushButton#GhostButton {{
                background-color: transparent;
                border: none;
                color: #8b949e;
            }}
            QPushButton#GhostButton:hover {{
                color: #c9d1d9;
            }}
        """)
        self._build_ui()

    def _build_ui(self):
        lo = QVBoxLayout(self); lo.setSpacing(14); lo.setContentsMargins(20,18,20,16)

        # ── Data Provider ────────────────────────────────────────────────────
        dp_box = QGroupBox("Data Provider"); dp_lo = QVBoxLayout(dp_box)
        self._dp_yf  = QRadioButton("YFinance (free, public — default)")
        self._dp_bb  = QRadioButton("Bloomberg  (requires blpapi)")
        self._dp_ref = QRadioButton("Refinitiv  (requires refinitiv-data)")
        self._dp_yf.setChecked(True)
        for rb in (self._dp_yf, self._dp_bb, self._dp_ref): dp_lo.addWidget(rb)
        dsn_row = QHBoxLayout()
        dsn_row.addWidget(QLabel("DSN / Path:"))
        self._dp_dsn = QLineEdit(); self._dp_dsn.setPlaceholderText("optional — leave blank for defaults")
        dsn_row.addWidget(self._dp_dsn)
        dp_test = QPushButton("Test"); dp_test.setObjectName("SecondaryButton")
        dp_test.setFixedHeight(26); dp_test.clicked.connect(self._test_dp)
        dsn_row.addWidget(dp_test); dp_lo.addLayout(dsn_row)
        self._dp_status = QLabel(); self._dp_status.setObjectName("MutedText")
        dp_lo.addWidget(self._dp_status); lo.addWidget(dp_box)

        # ── Database Store ───────────────────────────────────────────────────
        db_box = QGroupBox("Database Store"); db_lo = QVBoxLayout(db_box)
        self._db_sq  = QRadioButton("SQLite  (file-based, zero config — default)")
        self._db_pg  = QRadioButton("PostgreSQL  (requires psycopg2-binary)")
        self._db_sq.setChecked(True)
        for rb in (self._db_sq, self._db_pg): db_lo.addWidget(rb)
        db_dsn_row = QHBoxLayout()
        db_dsn_row.addWidget(QLabel("DSN / Path:"))
        self._db_dsn = QLineEdit()
        self._db_dsn.setPlaceholderText("PG: postgresql://user:pass@host/db   SQLite: /path/to/db")
        db_dsn_row.addWidget(self._db_dsn)
        db_test = QPushButton("Test"); db_test.setObjectName("SecondaryButton")
        db_test.setFixedHeight(26); db_test.clicked.connect(self._test_db)
        db_dsn_row.addWidget(db_test); db_lo.addLayout(db_dsn_row)
        self._db_status = QLabel(); self._db_status.setObjectName("MutedText")
        db_lo.addWidget(self._db_status); lo.addWidget(db_box)

        # ── Buttons ──────────────────────────────────────────────────────────
        btn_row = QHBoxLayout(); btn_row.addStretch()
        cancel_btn = QPushButton("Cancel"); cancel_btn.setObjectName("GhostButton")
        cancel_btn.setFixedHeight(28); cancel_btn.clicked.connect(self.reject)
        apply_btn  = QPushButton("Apply & Reconnect"); apply_btn.setObjectName("PrimaryButton")
        apply_btn.setFixedHeight(28); apply_btn.clicked.connect(self._on_apply)
        btn_row.addWidget(cancel_btn); btn_row.addSpacing(6); btn_row.addWidget(apply_btn)
        lo.addLayout(btn_row)

    def _test_dp(self):
        try:
            p = self._make_dp(); ok = p.ping()
            self._dp_status.setText("✅ Connected" if ok else "❌ Unreachable")
        except Exception as e: self._dp_status.setText(f"❌ {e}")

    def _test_db(self):
        try:
            s = self._make_db()
            if getattr(s, "_is_pg", False):
                if s.conn is not None:
                    self._db_status.setText("✅ Connected to PostgreSQL")
                else:
                    self._db_status.setText("❌ PostgreSQL connection failed")
            else:
                self._db_status.setText("✅ SQLite database initialized successfully")
        except Exception as e:
            self._db_status.setText(f"❌ {e}")

    def _make_dp(self):
        dsn = self._dp_dsn.text().strip()
        if self._dp_bb.isChecked():
            try:
                from qa_data.bloomberg_stub import BloombergProvider
                return BloombergProvider(dsn or None)
            except ImportError:
                raise ImportError("Bloomberg stub requires qa_data package.")
        if self._dp_ref.isChecked():
            try:
                from qa_data.refinitiv_stub import RefinitivProvider
                return RefinitivProvider(dsn or None)
            except ImportError:
                raise ImportError("Refinitiv stub requires qa_data package.")
        try:
            from qa_data.yfinance_provider import YFinanceProvider
            return YFinanceProvider()
        except ImportError:
            from data_layer import YFinanceProvider
            return YFinanceProvider()

    def _make_db(self):
        dsn = self._db_dsn.text().strip()
        if self._db_pg.isChecked():
            from qa_db.postgres_store import PostgresStore
            return PostgresStore(dsn=dsn or "postgresql://localhost/qadb")
        from qa_db.sqlite_store import SQLiteStore
        if not dsn:
            from utils import RUNTIME_DIR
            dsn = os.path.join(str(RUNTIME_DIR), "quantum_annealer_pro.db")
        return SQLiteStore(db_path=dsn)

    def _on_apply(self):
        try:
            p = self._make_dp()
            try:
                from qa_data import set_provider
                set_provider(p)
            except ImportError:
                from utils import set_provider
                set_provider(p)
            # AUDIT-FIX (Round 6, D-P2-5): data-layer providers have no `name`
            # attribute — p.name raised AttributeError AFTER the switch had
            # already succeeded, so the dialog always reported ❌ for a working
            # switch. Use the class name.
            self._dp_status.setText(f"✅ DataProvider → {type(p).__name__}")
        except Exception as e: self._dp_status.setText(f"❌ DP: {e}")
        try:
            from qa_db import set_store
            s = self._make_db(); set_store(s)
            self._db_status.setText(f"✅ DatabaseStore → {s.name}")
        except Exception as e: self._db_status.setText(f"❌ DB: {e}")
        if self._status_bar:
            self._status_bar.ping_all()
        self.accept()


# ── Strategy Profiles Dialog ─────────────────────────────────────────────────
class StrategyProfileDialog(QDialog):
    profile_loaded = pyqtSignal(dict)

    def __init__(self, current_cfg, store=None, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_StyledBackground, True)
        self._cfg   = current_cfg
        self._store = store
        self.setWindowTitle("Strategy Profiles")
        self.setMinimumSize(400, 320)
        self._build_ui()
        self._refresh()

    def _build_ui(self):
        lo = QVBoxLayout(self)
        lo.setSpacing(10); lo.setContentsMargins(18, 16, 18, 14)
        lo.addWidget(QLabel("Saved Strategy Profiles:"))
        self._list = QListWidget()
        self._list.setAlternatingRowColors(True)
        lo.addWidget(self._list)
        name_row = QHBoxLayout()
        name_row.addWidget(QLabel("Name:"))
        self._name_edit = QLineEdit()
        self._name_edit.setPlaceholderText("e.g. Aggressive Growth, Low Vol India")
        name_row.addWidget(self._name_edit)
        lo.addLayout(name_row)
        btn_row = QHBoxLayout()
        save_btn  = QPushButton("Save Current"); save_btn.setObjectName("PrimaryButton")
        save_btn.setFixedHeight(28); save_btn.clicked.connect(self._save)
        load_btn  = QPushButton("Load");         load_btn.setObjectName("SecondaryButton")
        load_btn.setFixedHeight(28); load_btn.clicked.connect(self._load)
        del_btn   = QPushButton("Delete");       del_btn.setObjectName("GhostButton")
        del_btn.setFixedHeight(28); del_btn.clicked.connect(self._delete)
        close_btn = QPushButton("Close");        close_btn.setObjectName("GhostButton")
        close_btn.setFixedHeight(28); close_btn.clicked.connect(self.accept)
        for b in (save_btn, load_btn, del_btn):
            btn_row.addWidget(b)
        btn_row.addStretch(); btn_row.addWidget(close_btn)
        lo.addLayout(btn_row)
        self._status = QLabel(); self._status.setObjectName("MutedText")
        lo.addWidget(self._status)

    def _get_store(self):
        if self._store: return self._store
        try:
            from qa_db import get_store; return get_store()
        except Exception as _e:
            return None

    def _refresh(self):
        self._list.clear()
        s = self._get_store()
        if s is None: return
        try:
            for name in (s.list_profiles() or []):
                self._list.addItem(name)
        except Exception as _e:
            archlog.error('Exception detail', exc_info=True)
            pass

    def _save(self):
        name = self._name_edit.text().strip()
        if not name: self._status.setText("Enter a profile name."); return
        s = self._get_store()
        if s is None: self._status.setText("No store available."); return
        try:
            s.save_profile(name, self._cfg)
            self._status.setText("Saved: " + name)
            self._refresh()
        except Exception as e: self._status.setText("Error: " + str(e))

    def _load(self):
        item = self._list.currentItem()
        if not item: self._status.setText("Select a profile first."); return
        s = self._get_store()
        if s is None: return
        try:
            cfg = s.load_profile(item.text())
            self.profile_loaded.emit(cfg)
            self._status.setText("Loaded: " + item.text())
        except Exception as e: self._status.setText("Error: " + str(e))

    def _delete(self):
        item = self._list.currentItem()
        if not item: return
        s = self._get_store()
        if s is None: return
        try:
            s.delete_profile(item.text())
            self._status.setText("Deleted: " + item.text())
            self._refresh()
        except Exception as _e:
            archlog.error('Exception detail', exc_info=True)
            pass


# ── Universe Manager Dialog ──────────────────────────────────────────────────
class MultiUniverseManagerDialog(QDialog):
    universe_applied = pyqtSignal(str)
    _PRESETS = [
        ("NIFTY 50",   "RELIANCE,TCS,HDFCBANK,INFY,ICICIBANK,HINDUNILVR,ITC,SBIN,BHARTIARTL,KOTAKBANK"),
        ("NIFTY BANK", "HDFCBANK,ICICIBANK,KOTAKBANK,SBIN,AXISBANK,INDUSINDBK,BANDHANBNK,FEDERALBNK"),
        ("NIFTY IT",   "TCS,INFY,HCLTECH,WIPRO,TECHM,MPHASIS,LTIM,PERSISTENT,COFORGE,LTTS"),
    ]

    def __init__(self, store=None, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_StyledBackground, True)
        self._store=store; self.setWindowTitle("Universe Manager")
        self.setMinimumSize(620,440); self._build_ui(); self._refresh()

    def _build_ui(self):
        lo=QVBoxLayout(self); lo.setContentsMargins(14,14,14,12); lo.setSpacing(8)
        split=QHBoxLayout(); split.setSpacing(10)
        left=QVBoxLayout(); left.setSpacing(4)
        left.addWidget(QLabel("Saved Universes:"))
        self._list=QListWidget(); self._list.setMaximumWidth(200)
        self._list.currentRowChanged.connect(self._on_select)
        left.addWidget(self._list); split.addLayout(left)
        right=QVBoxLayout(); right.setSpacing(4)
        nr=QHBoxLayout(); nr.addWidget(QLabel("Name:"))
        self._name_edit=QLineEdit()
        self._name_edit.setPlaceholderText("e.g. NSE500 Momentum")
        nr.addWidget(self._name_edit); right.addLayout(nr)
        right.addWidget(QLabel("Tickers (comma or one per line):"))
        self._ticker_edit=QPlainTextEdit()
        self._ticker_edit.setPlaceholderText("RELIANCE\nTCS\nINFY")
        right.addWidget(self._ticker_edit)
        pr=QHBoxLayout(); pr.addWidget(QLabel("Presets:"))
        for nm,tks in self._PRESETS:
            btn=QPushButton(nm); btn.setObjectName("GhostButton"); btn.setFixedHeight(24)
            btn.clicked.connect(lambda _,n=nm,t=tks: self._load_preset(n,t))
            pr.addWidget(btn)
        pr.addStretch(); right.addLayout(pr)
        split.addLayout(right); lo.addLayout(split)
        br=QHBoxLayout()
        for lbl,slot,obj in [("Save",self._save,"PrimaryButton"),
                              ("Load",self._load_selected,"SecondaryButton"),
                              ("Delete",self._delete,"GhostButton"),
                              ("Apply to Run",self._apply,"PrimaryButton")]:
            b=QPushButton(lbl); b.setObjectName(obj); b.setFixedHeight(28)
            b.clicked.connect(slot); br.addWidget(b)
        br.addStretch()
        cb=QPushButton("Close"); cb.setObjectName("GhostButton")
        cb.setFixedHeight(28); cb.clicked.connect(self.accept); br.addWidget(cb)
        lo.addLayout(br)
        self._status=QLabel(); self._status.setObjectName("MutedText"); lo.addWidget(self._status)

    def _get_store(self):
        if self._store: return self._store
        try:
            from qa_db import get_store; return get_store()
        except Exception as _e:
            return None

    def _load_preset(self, name, tickers):
        self._name_edit.setText(name)
        self._ticker_edit.setPlainText(tickers.replace(",", chr(10)))

    def _refresh(self):
        self._list.clear()
        s=self._get_store()
        if s is None: return
        try:
            for nm in (s.list_universes() or []): self._list.addItem(nm)
        except Exception as _e:
            archlog.error('Exception detail', exc_info=True)
            pass

    def _on_select(self, row):
        if row<0: return
        item=self._list.item(row)
        if not item: return
        self._name_edit.setText(item.text())
        s=self._get_store()
        if s is None: return
        try:
            self._ticker_edit.setPlainText(
                s.load_universe(item.text()).replace(",", chr(10)))
        except Exception as _e:
            archlog.error('Exception detail', exc_info=True)
            pass

    def _save(self):
        name=self._name_edit.text().strip(); raw=self._ticker_edit.toPlainText().strip()
        if not name or not raw: self._status.setText("Enter name and tickers."); return
        s=self._get_store()
        if s is None: self._status.setText("No store."); return
        try:
            s.save_universe(name, raw.replace(chr(10),","))
            self._status.setText("Saved: "+name); self._refresh()
        except Exception as e: self._status.setText("Error: "+str(e))

    def _load_selected(self): self._on_select(self._list.currentRow())

    def _delete(self):
        item=self._list.currentItem()
        if not item: return
        s=self._get_store()
        if s is None: return
        try:
            s.delete_universe(item.text())
            self._status.setText("Deleted: "+item.text()); self._refresh()
        except Exception as _e:
            archlog.error('Exception detail', exc_info=True)
            pass

    def _apply(self):
        raw=self._ticker_edit.toPlainText().strip()
        if raw:
            self.universe_applied.emit(raw.replace(",", chr(10)))
            self._status.setText("Applied."); self.accept()
