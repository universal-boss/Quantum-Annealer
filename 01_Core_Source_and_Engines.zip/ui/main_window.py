from __future__ import annotations
from pathlib import Path
import os
import sys
import math
import time
import json
import sqlite3
import csv
import io
import uuid
from datetime import datetime
import traceback
import random
import pandas as pd
import numpy as np

# System module-aliasing block: satisfy quantum_portfolio imports dynamically
import utils
import types
_qp = types.ModuleType('quantum_portfolio')
_qp_core = types.ModuleType('quantum_portfolio.core')
sys.modules['quantum_portfolio'] = _qp
sys.modules['quantum_portfolio.core'] = _qp_core
sys.modules['quantum_portfolio.core.utils'] = utils
_qp.core = _qp_core
_qp_core.utils = utils


try:
    from PySide6.QtWidgets import (
        QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QFormLayout,
        QSplitter, QScrollArea, QPlainTextEdit, QStackedWidget, QListWidget,
        QListWidgetItem, QMessageBox, QFileDialog, QMenu, QDialog, QGroupBox,
        QProgressBar, QLabel, QPushButton, QComboBox, QSpinBox, QDoubleSpinBox,
        QCheckBox, QLineEdit, QHeaderView, QTableWidget, QTableWidgetItem, QAbstractItemView,
        QApplication, QFrame, QSizePolicy
    )
    from PySide6.QtGui import QFont, QColor, QIcon, QKeySequence, QAction
    from PySide6.QtCore import Qt, QThread, Signal as pyqtSignal, QTimer, QUrl, QSize, QMetaObject, Slot as pyqtSlot
except ImportError:
    from PyQt5.QtWidgets import (
        QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QFormLayout,
        QSplitter, QScrollArea, QPlainTextEdit, QStackedWidget, QListWidget,
        QListWidgetItem, QMessageBox, QFileDialog, QMenu, QAction, QDialog, QGroupBox,
        QProgressBar, QLabel, QPushButton, QComboBox, QSpinBox, QDoubleSpinBox,
        QCheckBox, QLineEdit, QHeaderView, QTableWidget, QTableWidgetItem, QAbstractItemView,
        QApplication, QFrame, QSizePolicy
    )
    from PyQt5.QtGui import QFont, QColor, QIcon, QKeySequence
    from PyQt5.QtCore import Qt, QThread, pyqtSignal, QTimer, QUrl, QSize, QMetaObject, pyqtSlot

def _qmessagebox_enum_value(enum_name: str, value_name: str, fallback: int = 0):
    enum_obj = getattr(QMessageBox, enum_name, None)
    if enum_obj is not None and hasattr(enum_obj, value_name):
        return getattr(enum_obj, value_name)
    if hasattr(QMessageBox, value_name):
        return getattr(QMessageBox, value_name)
    return fallback

class _QMessageBoxIconCompat:
    Information = _qmessagebox_enum_value("Icon", "Information", 1)
    Warning = _qmessagebox_enum_value("Icon", "Warning", 2)
    Critical = _qmessagebox_enum_value("Icon", "Critical", 3)

_QMESSAGEBOX_ICON = _QMessageBoxIconCompat

# Imports from our new package structure
from ui.styling import _QSS
from ui.custom_widgets import (
    GlassBackground, PlainBackground, CardFrame, GlassPanel,
    MetricCard, CollapsibleGroup, SettingsDialog, ApprovalDialog,
    GlassComboBox, GlassMenu, ProviderSwitcherDialog, StrategyProfileDialog,
    MultiUniverseManagerDialog
)
from ui.tabs.corporate import (
    QuarterlyResultsScanner, EarningsSurpriseTracker,
    RevenueGrowthComparator, MarginTrendAnalyzer, ConsensusForecastPanel
)
from ui.tabs.options_chain import OptionsChainViewer
from ui.tabs.risk_stress import ScenarioStressLibrary
from ui.tabs.ai_copilot import AICopilotPanel

from workers.worker_threads import (
    OptimizerWorker, _GenericNetworkWorker, _MacroRefreshWorker,
    _FetchWorker, _Worker, RegimeWorker, LatentScreenerWorker
)

# Imports from utils
from utils import (
    APP_NAME, RUNTIME_DIR, TICKERS_CACHE_PATH,
    _THEME_SEEDS, _ACTIVE_STOP_EVENT, _ACTIVE_STOP_EVENT_LOCK,
    _DaemonThreadPoolExecutor, _DynamicTabMixin, _demo_int, _demo_float,
    _real_or_demo, _real_or_demo_int, _widget_alive, _download_universe,
    _compute_all, _rsi, _macd, _bollinger, _atr, _supertrend, _ichimoku,
    _vwap, _donchian, _adx, _pivot_points, _volume_profile,
    _fill_table_from_df, _make_std_table, _make_ticker_bar, _launch,
    _set_watchlist, _DATA_PROVIDER, _DB_STORE,
    apply_theme, _WATCHLIST, save_credentials, show_styled_message_box,
    load_credentials, NSEClient, archlog, ExceptionLogger, AuditLogger,
    TRADING_DAYS_PER_YEAR, read_json_cache, write_json_cache,
    LazyTabManager, WorkerLifecycle,
    CircuitBreaker, ComplianceEngine, DataValidator, ExecutionCostModel, StressTestEngine,
    ALERTS_HISTORY_PATH, HISTORY_PATH, PREFERENCES_PATH, SNAPSHOT_DIR, LAST_RUN_PATH,
    # TAB_ALERTS, TAB_LOGS, TAB_PORTFOLIO defined locally below
    generate_chart_pack, payload_to_serializable, HAS_MATPLOTLIB,
    LivePnLTracker, PortfolioSnapshotExporter, StopRequested,
    RiskLimitEnforcer,
    DrawdownMonitor, ExportScheduler, is_app_dark_mode, get_styled_msgbox_qss
)
from optimizer import (
    run_optimizer_logic, reconcile_with_dhan, reconcile_with_kite,
    dhan_place_basket, zerodha_place_basket, export_pdf_report,
    sqlite_load_history, generate_dhan_order_sheet, generate_kite_order_sheet
)
from data_layer import get_active_universe, DEFAULT_CFG, PROFILE_MAP, AbstractDataProvider, ExchangeLocalDBProvider, YFinanceProvider

# Global placeholders
HAS_WEBENGINE = False
QWebEngineView = None

# Local tab index mappings for complete tab layout
TAB_PORTFOLIO = 0
TAB_ALERTS = 7
TAB_CHARTS = 8
TAB_LOGS = 14

# Custom wrapper functions if needed or global variables
QT_API = "PySide6"


class AlgoExecutionWorker(QThread):
    log_msg = pyqtSignal(str)
    progress_update = pyqtSignal(int, str)
    table_update = pyqtSignal(list)
    finished = pyqtSignal(str)

    def __init__(self, parent, managers, use_mock_ws, api_key, access_token, duration_mins):
        super().__init__(parent)
        self.managers = managers
        self.use_mock_ws = use_mock_ws
        self.api_key = api_key
        self.access_token = access_token
        self.duration_mins = duration_mins
        import threading
        self.stop_event = threading.Event()
        self.ws_client = None
        # AUDIT-FIX (defect #19): snapshot GUI widget state BEFORE the worker
        # thread starts. The prior code read parent.exec_destination_combo.
        # currentText() and parent.kite_live_check.isChecked() from inside the
        # worker thread, racing with the GUI thread (Qt widgets are not thread-
        # safe). We capture the snapshot here on the GUI thread and the worker
        # reads only from these local copies.
        self._snapshot_destination = ""
        self._snapshot_kite_live = False
        self._snapshot_dhan_live = False
        # AUDIT-FIX (Round 8, T3 — Part 2B): snapshot the Angel One login
        # credentials on the GUI thread (never read widgets from run()).
        self._snapshot_angel_password = ""
        self._snapshot_angel_totp = ""
        try:
            if parent is not None and hasattr(parent, "exec_destination_combo"):
                self._snapshot_destination = parent.exec_destination_combo.currentText()
            if parent is not None and hasattr(parent, "kite_live_check"):
                self._snapshot_kite_live = parent.kite_live_check.isChecked()
            if parent is not None and hasattr(parent, "angel_pwd_edit"):
                self._snapshot_angel_password = parent.angel_pwd_edit.text().strip()
            if parent is not None and hasattr(parent, "angel_totp_edit"):
                self._snapshot_angel_totp = parent.angel_totp_edit.text().strip()
        except Exception:
            # Best-effort snapshot; worker will fall back to safe defaults.
            pass

    def run(self):
        self.log_msg.emit("[AlgoExecution] Starting algorithmic execution worker thread...")
        
        # 1. Connect WebSocket
        symbols = list(self.managers.keys())
        initial_prices = {sym: mgr.decision_price for sym, mgr in self.managers.items()}
        
        from math_engine.websocket_feed import MockWebSocketClient, KiteWebSocketClient, DhanPollingFeedClient

        parent = self.parent()
        # AUDIT-FIX (defect #19): use the snapshot captured on the GUI thread
        # in __init__ instead of touching parent.exec_destination_combo here
        # on the worker thread. Qt widgets are not thread-safe; the prior code
        # could route the order to the wrong destination if the operator
        # changed the combo box mid-run.
        is_dhan = "DhanHQ" in self._snapshot_destination

        if self.use_mock_ws:
            self.log_msg.emit("[WebSocket] Initializing Mock price feed simulation...")
            self.ws_client = MockWebSocketClient(symbols, initial_prices=initial_prices, tick_interval=1.0)
        elif is_dhan:
            self.log_msg.emit("[WebSocket] Connecting to live DhanHQ API v2 Price Polling Feed...")
            self.ws_client = DhanPollingFeedClient(self.api_key, self.access_token, symbols)
        else:
            self.log_msg.emit("[WebSocket] Connecting to live Zerodha Kite Connect WebSocket...")
            kite_client = parent._get_kite_client() if (parent and hasattr(parent, "_get_kite_client")) else None
            self.ws_client = KiteWebSocketClient(self.api_key, self.access_token, symbols, kite_client=kite_client)

        # Register tick callback
        def on_tick(tick):
            symbol = tick["symbol"]
            price = tick["last_price"]
            if symbol in self.managers:
                mgr = self.managers[symbol]
                mgr.update_market_price(price)
        
        self.ws_client.register_callback(on_tick)
        
        try:
            self.ws_client.connect()
            self.log_msg.emit("[WebSocket] Feed connected successfully.")
        except Exception as e:
            self.log_msg.emit(f"[WebSocket] Error connecting feed: {e}")
            self.finished.emit(f"Failed to connect WebSocket feed: {e}")
            return

        # 2. Main Slicing loop
        if not self.managers:
            self.log_msg.emit("[AlgoExecution] No managers initialized.")
            # AUDIT-FIX (Round 5, 2-a-11): ws_client already connected at step 1 —
            # every early return below must disconnect it or the live feed socket
            # (plus its reader thread) leaks while the worker reports failure.
            if self.ws_client:
                try:
                    self.ws_client.disconnect()
                except Exception:
                    pass
            self.finished.emit("Failed: No managers")
            return
            
        parent = self.parent()
        # AUDIT-FIX (defect #19): snapshot read — never touch the combo box
        # from the worker thread.
        is_fix = self._snapshot_destination == "Institutional FIX 4.2 Engine"
        fix_app = None
        matching_engine = None
        ord_to_slice = {}
            
        if is_fix:
            try:
                from enterprise.connectors.fix_connector import QuantumFIXApplication, PreTradeRiskEngine, AuditLogger
                from enterprise.connectors.matching_engine import MatchingEngine
                
                self.log_msg.emit("[FIX Session] Connecting to institutional QuickFIX application...")
                audit_logger = AuditLogger("fix_audit.log")
                risk_engine = PreTradeRiskEngine(audit_logger)
                
                # Setup event callback for UI logging
                def event_callback(evt):
                    event_type = evt.get("event")
                    if event_type == "ORDER_CREATED":
                        self.log_msg.emit(f"[FIX] Order Created: {evt.get('side')} {evt.get('qty')} {evt.get('symbol')} | Status: {evt.get('status')} | ID: {evt.get('id')[:8]}...")
                    elif event_type == "EXECUTION":
                        symbol = evt.get("symbol")
                        exec_type = evt.get("exec_type")
                        last_qty = evt.get("last_qty", 0)
                        status = evt.get("status")
                        avg_px = evt.get("avg_price", 0.0)
                        cum_qty = evt.get("cum_qty", 0)
                        total_qty = evt.get("qty", 0)
                        cl_ord_id = evt.get("id")
                        
                        # Route trade updates to managers
                        if cl_ord_id in ord_to_slice:
                            sym, slice_idx = ord_to_slice[cl_ord_id]
                            if exec_type == "TRADE" and last_qty > 0:
                                mgr = self.managers[sym]
                                # We update the slice directly to accumulate fills correctly
                                for s in mgr.slices:
                                    if s["slice_idx"] == slice_idx:
                                        old_filled = s["filled_qty"]
                                        new_filled = old_filled + last_qty
                                        s["filled_qty"] = new_filled
                                        
                                        # Calculate weighted average price for this slice
                                        old_px = s["avg_price"]
                                        if new_filled > 0:
                                            s["avg_price"] = ((old_px * old_filled) + (evt.get("last_px", avg_px) * last_qty)) / new_filled
                                        s["status"] = "COMPLETED" if new_filled >= s["target_qty"] else "PARTIAL"
                                        
                                        # Update manager overall metrics
                                        mgr.filled_qty += last_qty
                                        mgr.remaining_qty = max(0, mgr.total_qty - mgr.filled_qty)
                                        if mgr.filled_qty > 0:
                                            # Update overall weighted average fill price
                                            mgr.avg_fill_price = ((mgr.avg_fill_price * (mgr.filled_qty - last_qty)) + (evt.get("last_px", avg_px) * last_qty)) / mgr.filled_qty
                                        break
                        
                        self.log_msg.emit(f"[FIX Report] {symbol} | Exec: {exec_type} | Last Qty: {last_qty} | Filled Qty: {cum_qty}/{total_qty} | Avg Price: ₹{avg_px:.2f} | Status: {status}")
                        audit_logger.log_event("EXECUTION", {
                            "symbol": symbol,
                            "exec_type": exec_type,
                            "last_qty": last_qty,
                            "avg_price": avg_px,
                            "cum_qty": cum_qty,
                            "total_qty": total_qty,
                            "cl_ord_id": cl_ord_id
                        })
                
                # Local LOB Matching Engine
                self.log_msg.emit("[Exchange Simulator] Starting stochastic limit order book simulator...")
                matching_engine = MatchingEngine(fill_callback=None)
                
                fix_app = QuantumFIXApplication(
                    risk_engine=risk_engine,
                    audit_logger=audit_logger,
                    matching_engine=matching_engine,
                    event_callback=event_callback
                )
                
                matching_engine.fill_callback = fix_app.state_machine.update_execution
                matching_engine.start()
                
                self.log_msg.emit("[FIX Session] Logon completed.")
            except Exception as err:
                self.log_msg.emit(f"[FIX Session] Failed to initialize QuickFIX: {err}")
                # AUDIT-FIX (Round 5, 2-a-11): disconnect the live WebSocket feed
                # before bailing — the normal-path cleanup at the end of run()
                # is unreachable from this early return.
                if self.ws_client:
                    try:
                        self.ws_client.disconnect()
                    except Exception:
                        pass
                self.finished.emit(f"Failed to Initialize FIX: {err}")
                return
            
        first_mgr = next(iter(self.managers.values()))
        slices_count = first_mgr.slices_count
        strategy_name = first_mgr.strategy
        
        total_seconds = self.duration_mins * 60.0
        interval_seconds = total_seconds / slices_count
        
        self.log_msg.emit(f"[AlgoExecution] Strategy: {strategy_name}")
        self.log_msg.emit(f"[AlgoExecution] Total Duration: {self.duration_mins} mins ({total_seconds:.0f}s)")
        self.log_msg.emit(f"[AlgoExecution] Slices: {slices_count} (Interval: {interval_seconds:.1f}s)")

        import random
        # Loop for each slice index
        for slice_idx in range(1, slices_count + 1):
            if self.stop_event.is_set():
                break
                
            self.log_msg.emit(f"--- Executing Slice {slice_idx}/{slices_count} ---")
            
            # Place and fill this slice for each symbol
            for sym, mgr in self.managers.items():
                if self.stop_event.is_set():
                    break
                    
                slice_info = mgr.execute_next_slice()
                if slice_info:
                    target_qty = slice_info["target_qty"]
                    current_price = mgr.current_price
                    
                    if is_fix:
                        try:
                            from live_verify import check_paper_trade_gate_or_raise
                            check_paper_trade_gate_or_raise()
                        except Exception as gate_err:
                            self.log_msg.emit(f"⛔ [FIX] ORDER BLOCKED BY PROMOTION GATE: {gate_err}")
                            self.stop_event.set()
                            break

                        try:
                            side_str = "BUY" if mgr.is_buy else "SELL"
                            self.log_msg.emit(f"[FIX Routing] Slice {slice_idx} for {sym}: {target_qty} shares...")
                            cl_ord_id = fix_app.send_order(
                                symbol=sym,
                                side=side_str,
                                qty=target_qty,
                                price=current_price,
                                algo=None
                            )
                            if cl_ord_id:
                                ord_to_slice[cl_ord_id] = (sym, slice_idx)
                            else:
                                self.log_msg.emit(f"[FIX Reject] Order rejected by Risk Engine for {sym}.")
                        except Exception as err:
                            self.log_msg.emit(f"[FIX Session] Order routing failed for {sym}: {err}")
                    elif not self.use_mock_ws and not self.stop_event.is_set():
                        parent = self.parent()
                        # AUDIT-FIX (defect #19): use the snapshot captured at
                        # __init__ time; never read kite_live_check.isChecked()
                        # from the worker thread.
                        live_orders = self._snapshot_kite_live
                            
                        if live_orders:
                            try:
                                from live_verify import check_paper_trade_gate_or_raise
                                check_paper_trade_gate_or_raise()
                            except Exception as gate_err:
                                self.log_msg.emit(f"⛔ [Broker LIVE] ORDER BLOCKED BY PROMOTION GATE: {gate_err}")
                                self.stop_event.set()
                                break

                            try:
                                # AUDIT-FIX (defect #19): use the snapshot for
                                # destination detection. The prior code read
                                # parent.exec_destination_combo.currentText()
                                # from the worker thread, racing the GUI.
                                is_angel = ("Angel" in self._snapshot_destination or "Dhan" in self._snapshot_destination)
                                if is_angel:
                                    self.log_msg.emit(f"[Angel One LIVE] Placing market order for {sym}: {target_qty} shares...")
                                    from math_engine.broker_router import AngelOneExecutionRouter
                                    # AUDIT-FIX (Round 8, T3 — Part 2B): use the
                                    # GUI-thread snapshot (never getattr(self,
                                    # "password", "") — that attribute never
                                    # existed and live orders sent EMPTY strings).
                                    _angel_pwd = getattr(self, "_snapshot_angel_password", "")
                                    _angel_totp = getattr(self, "_snapshot_angel_totp", "")
                                    if not _angel_pwd or not _angel_totp:
                                        raise ValueError(
                                            "Angel One live order requires Password and TOTP Secret "
                                            "(set them in the Angel One SmartAPI card before going live).")
                                    router = AngelOneExecutionRouter(cfg={
                                        "ANGELONE_API_KEY": self.api_key,
                                        "ANGELONE_CLIENT_ID": self.access_token,
                                        "ANGELONE_PASSWORD": _angel_pwd,
                                        "ANGELONE_TOTP_SECRET": _angel_totp
                                    })
                                    df = router.angel_adapter.place_basket_orders({sym: 1.0}, target_qty * current_price, dry_run=False, log_cb=self.log_msg.emit)
                                    if not df.empty and "Error" not in str(df.iloc[0].get("Status", "")):
                                        order_id = df.iloc[0].get("OrderID", "DHAN-OK")
                                        self.log_msg.emit(f"[DhanHQ LIVE] Order placed successfully. ID: {order_id}")
                                        fill_price = current_price
                                        filled_qty = target_qty
                                    else:
                                        err_msg = df.iloc[0].get("Status", "Empty response") if not df.empty else "Empty response"
                                        raise ValueError(err_msg)
                                else:
                                    self.log_msg.emit(f"[Kite LIVE] Placing market order for {sym}: {target_qty} shares...")
                                    kite_client = parent._get_kite_client() if parent else None
                                    if kite_client:
                                        tx_type = kite_client.TRANSACTION_TYPE_BUY if mgr.is_buy else kite_client.TRANSACTION_TYPE_SELL
                                        order_id = kite_client.place_order(
                                            variety=kite_client.VARIETY_REGULAR if hasattr(kite_client, 'VARIETY_REGULAR') else 'regular',
                                            exchange=kite_client.EXCHANGE_NSE if hasattr(kite_client, 'EXCHANGE_NSE') else 'NSE',
                                            tradingsymbol=sym,
                                            transaction_type=tx_type,
                                            quantity=target_qty,
                                            product=kite_client.PRODUCT_CNC if hasattr(kite_client, 'PRODUCT_CNC') else 'CNC',
                                            order_type=kite_client.ORDER_TYPE_MARKET if hasattr(kite_client, 'ORDER_TYPE_MARKET') else 'MARKET'
                                        )
                                        self.log_msg.emit(f"[Kite LIVE] Order placed. ID: {order_id}")
                                        fill_price = current_price
                                        filled_qty = target_qty
                                    else:
                                        raise ValueError("Kite client not initialized")
                            except Exception as err:
                                self.log_msg.emit(f"[Broker LIVE] Order failed for {sym}: {err}")
                                fill_price = current_price
                                filled_qty = 0
                        else:
                            fill_price = current_price * (1.0 + random.gauss(0, 0.0005))
                            filled_qty = target_qty
                            self.log_msg.emit(f"[Kite DRY-RUN] {sym}: Slice {slice_idx} filled {filled_qty} shares @ ₹{fill_price:.2f}")
                    else:
                        fill_price = current_price * (1.0 + random.gauss(0, 0.0005))
                        filled_qty = target_qty
                        self.log_msg.emit(f"[Algo Simulation] {sym}: Slice {slice_idx} filled {filled_qty} shares @ ₹{fill_price:.2f}")
                    
                    if not is_fix:
                        mgr.record_fill(slice_idx, filled_qty, fill_price)
            
            # Sleep during slice interval
            sleep_remaining = interval_seconds
            while sleep_remaining > 0 and not self.stop_event.is_set():
                # Send status update of all slices continuously so UI shows real-time fill accumulation
                slice_state_list = []
                for sym, mgr in self.managers.items():
                    for s in mgr.slices:
                        slice_state_list.append({
                            "Ticker": sym,
                            "Slice": f"{s['slice_idx']}/{mgr.slices_count}",
                            "Strategy": mgr.strategy,
                            "Target Qty": s["target_qty"],
                            "Filled Qty": s["filled_qty"],
                            "Avg Price": round(s["avg_price"], 2),
                            "Status": s["status"]
                        })
                self.table_update.emit(slice_state_list)
                
                # Update overall progress
                progress_pct = int(((slice_idx - 1) / slices_count) * 100)
                self.progress_update.emit(progress_pct, f"Executing slice {slice_idx}/{slices_count}...")
                
                time.sleep(min(0.2, sleep_remaining))
                sleep_remaining -= 0.2

        if self.ws_client:
            try:
                self.ws_client.disconnect()
            except Exception:
                pass
                
        if matching_engine:
            matching_engine.stop()
            self.log_msg.emit("[Exchange Simulator] Stopped matching engine.")
            
        # Send final status update
        slice_state_list = []
        for sym, mgr in self.managers.items():
            for s in mgr.slices:
                slice_state_list.append({
                    "Ticker": sym,
                    "Slice": f"{s['slice_idx']}/{mgr.slices_count}",
                    "Strategy": mgr.strategy,
                    "Target Qty": s["target_qty"],
                    "Filled Qty": s["filled_qty"],
                    "Avg Price": round(s["avg_price"], 2),
                    "Status": s["status"]
                })
        self.table_update.emit(slice_state_list)
            
        if self.stop_event.is_set():
            self.log_msg.emit("[AlgoExecution] Slicing execution cancelled by user.")
            self.finished.emit("Cancelled")
        else:
            self.progress_update.emit(100, "Execution Completed")
            self.log_msg.emit("[AlgoExecution] Algorithmic execution run completed successfully.")
            self.finished.emit("Success")


class MainWindow(QMainWindow):
    # AUDIT-FIX (Round 5, 2-a-9): signal for marshalling UI updates from raw
    # Python threads. QTimer.singleShot(0, ...) created inside a non-QThread
    # never fires ("Timers can only be used with threads started with QThread"),
    # so the Telegram test label and the risk-monitor alerts previously hung
    # on "Sending…" / were never logged. Emitting this signal is thread-safe
    # and delivers the callable on the GUI thread's event loop.
    _gui_call = pyqtSignal(object)

    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_NAME)
        # v17: apply dark theme on startup
        apply_theme(QApplication.instance(), dark=True)
        self._dark_mode = True
        self.resize(1720, 980); self.setMinimumSize(1320, 820)
        self.setFont(QFont(".AppleSystemUIFont", 11))
        self._gui_call.connect(lambda fn: fn())
        self.worker = self.last_payload = None
        self.run_history = []
        self.alert_history = []
        self.autorun_timer = QTimer(self)
        self.autorun_timer.timeout.connect(self._on_autorun_timeout)
        self._active_profile_cfg = None
        # AUDIT-FIX (Round 4 — pylint E0203): pre-declare optional Qt worker
        # attributes that are accessed in `_run_*` methods before they are
        # actually constructed. Without these None sentinels, methods like
        # `_run_live_verification` (which does `if hasattr(self, "_verify_worker")
        # and self._verify_worker.isRunning()`) hit a "member accessed before
        # definition" path on cold-start, and a stray AttributeError if the
        # hasattr branch ever evaluates the second operand. Initialising all
        # four to None up-front matches the standard Qt worker pattern and
        # makes the access-before-definition order safe.
        self._apscheduler = None
        self._verify_worker = None
        self._orchestrator = None
        self._pnl_tracker = None
        # ── Auto-pipeline state (must be initialised before _build_ui) ──────
        self._running_auto_pipeline_stage2 = False
        self._auto_run_optimizer_after_verify = False
        self._backup_manual_symbols = None
        self._build_ui()
        self._apply_style()
        # AUDIT-FIX (Round 5, 2-a-3): actually refresh the trading-mode badge on
        # startup — _refresh_trading_mode_badge() existed but was never called,
        # so the badge showed "PAPER TRADING MODE" forever, even with live-order
        # gates enabled (truth-in-labeling P0 from the Round-3 audit).
        self._refresh_trading_mode_badge()
        # Create hidden Telegram/Kite/Automation widgets BEFORE _load_defaults()
        self._tg = self._build_telegram_card();    self._tg.setParent(None)
        self._kt = self._build_kite_card();        self._kt.setParent(None)
        self._at = self._build_automation_card();  self._at.setParent(None)
        self._load_defaults()
        self._restore_preferences()
        self._reset_result_state()
        self._restore_history()
        self._restore_alert_history()
        self._populate_history_table()
        self._populate_alert_history_table()
        self._set_export_buttons_enabled(False)
        self._sync_autorun_state()
        self._sync_universe_source_ui()
        # Setup dynamic debounced charts sync
        self._custom_charts_dirty = False
        self.charts_sync_timer = QTimer(self)
        self.charts_sync_timer.setSingleShot(True)
        self.charts_sync_timer.timeout.connect(self.sync_charts_list)

        def mark_dirty_and_sync():
            self._custom_charts_dirty = True
            self.charts_sync_timer.start(500)

        if hasattr(self, "manual_symbols") and self.manual_symbols is not None:
            self.manual_symbols.textChanged.connect(mark_dirty_and_sync)
        if hasattr(self, "prev_holdings") and self.prev_holdings is not None:
            self.prev_holdings.textChanged.connect(mark_dirty_and_sync)
        if hasattr(self, "manual_universe_check") and self.manual_universe_check is not None:
            self.manual_universe_check.toggled.connect(mark_dirty_and_sync)

        # Populate charts list on startup so the panel is fully active and useful immediately
        try:
            self.sync_charts_list()
        except Exception as _startup_charts_err:
            pass

        # Start background market regime detector (HMM) on startup
        try:
            self._start_regime_worker()
        except Exception as _regime_err:
            self.append_log(f"[RegimeWorker Startup Error] {_regime_err}")

        # Start background chart embeddings screener (ViT + FAISS) on startup (if artifacts exist)
        try:
            self._start_latent_screener_worker()
        except Exception as _screener_err:
            self.append_log(f"[ScreenerWorker Startup Error] {_screener_err}")

        # Auto-load pre-trained ML Alpha model from disk on startup if present
        try:
            from ml_alpha import AlphaEngine
            from datetime import date as _date
            model_file = Path("artifacts/saved_ml_alpha.pkl")
            if model_file.exists():
                self._ml_engine = AlphaEngine.load_model(str(model_file))
                self._ml_alpha_engine = self._ml_engine
                ml_scores = self._ml_engine.predict(as_of=_date.today())
                self._ml_alpha_scores = ml_scores
                _dsr_raw = getattr(self._ml_engine, "dsr", None)
                _oos_raw = getattr(self._ml_engine, "oos_sharpe", None)
                _dsr_val = float(_dsr_raw) if _dsr_raw is not None else None
                _oos_val = float(_oos_raw) if _oos_raw is not None else None
                self._ml_dsr = _dsr_val
                self._ml_oos_sharpe = _oos_val
                _dsr_str = f"{_dsr_val:.4f}" if _dsr_val is not None else "UNMEASURED"
                _oos_str = f"{_oos_val:+.2f}" if _oos_val is not None else "UNMEASURED"
                self.append_log(f"[ML Alpha Startup] ✓ Loaded pre-trained 6-model ensemble from disk ({len(ml_scores)} ticker predictions ready | DSR={_dsr_str} | OOS Sharpe={_oos_str})")
        except Exception as _ml_load_err:
            self.append_log(f"[ML Alpha Startup Note] {_ml_load_err}")

        # Initialize drawdown monitor and export scheduler
        self._dd_monitor = DrawdownMonitor(self)
        self._dd_monitor.alert_triggered.connect(self._on_drawdown_alert)
        self._export_sched = ExportScheduler(self)

    def _on_drawdown_alert(self, dd):
        self.append_log(f"[Drawdown Alert] Critical drawdown of {dd:.2f}% detected!")



    def _build_ui(self):
        root = GlassBackground(); self.setCentralWidget(root)
        outer = QVBoxLayout(root); outer.setContentsMargins(14, 14, 14, 14); outer.setSpacing(10)
        outer.addWidget(self._build_topbar())
        sidebar = self._build_sidebar()
        sidebar.setMinimumWidth(320)
        sidebar.setMaximumWidth(480)
        results = self._build_results()
        
        # Use QSplitter to allow resizing of the sidebar, preventing overlaps/lockups
        body = QSplitter(Qt.Horizontal)
        body.setChildrenCollapsible(False)
        body.addWidget(sidebar)
        body.addWidget(results)
        body.setCollapsible(0, False)  # Prevent sidebar from collapsing below minimum width
        body.setCollapsible(1, False)
        body.setStretchFactor(0, 0)
        body.setStretchFactor(1, 1)
        body.setSizes([340, 1200])
        body.setHandleWidth(4)
        body.setStyleSheet("QSplitter::handle { background-color: rgba(255, 255, 255, 12); }")

        def _clamp_sidebar_splitter(pos, index):
            if index == 1 and pos < 300:
                tot = body.width()
                body.setSizes([300, max(400, tot - 300)])

        body.splitterMoved.connect(_clamp_sidebar_splitter)
        
        outer.addWidget(body, 1)


    def _build_topbar(self):
        card = CardFrame("TopBar"); lay = QHBoxLayout(card); lay.setContentsMargins(22, 16, 22, 16); lay.setSpacing(16)
        # Royal Blue accent strut
        strut = QFrame(); strut.setFixedSize(3, 36)
        strut.setStyleSheet("background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 rgba(10,132,255,220),stop:1 rgba(0,122,255,80));border-radius:2px;")
        left = QHBoxLayout(); left.setSpacing(12); left.setContentsMargins(0,0,0,0)
        title_col = QVBoxLayout(); title_col.setSpacing(2)
        
        # Institutional Bloomberg-style title and status badge
        title_row = QHBoxLayout(); title_row.setSpacing(8); title_row.setContentsMargins(0,0,0,0)
        title = QLabel(APP_NAME); title.setObjectName("AppTitle")
        # AUDIT-FIX (P0 truth-in-labeling): the prior "REAL-MONEY SYSTEM ACTIVE" badge
        # rendered unconditionally regardless of operating mode. The badge is now
        # derived from the actual broker gate flag KITE_LIVE_ORDERS / ANGELONE_LIVE_ORDERS,
        # defaulting to PAPER. Updated by _refresh_trading_mode_badge().
        self.mode_badge = QLabel("  PAPER TRADING MODE  ")
        self.mode_badge.setObjectName("TradingModeBadge")
        self.mode_badge.setStyleSheet(
            "background-color: rgba(120, 120, 128, 0.18); color: #8e8e93; "
            "border: 1px solid rgba(120, 120, 128, 0.35); border-radius: 4px; "
            "font-size: 8px; font-weight: bold; letter-spacing: 0.8px; padding: 2px 6px; "
            "font-family: 'Menlo', 'Monaco', monospace;"
        )
        self.mode_badge.setFixedHeight(18)
        title_row.addWidget(title)
        title_row.addWidget(self.mode_badge)

        # AUDIT-FIX (P0 truth-in-labeling): the prior "🟢 BULLISH REGIME (100% SIZING)"
        # badge was a hardcoded constant. It is now populated by
        # _refresh_regime_badge() which is invoked after each optimizer run; until
        # then it correctly shows UNKNOWN rather than a fabricated bullish regime.
        self.gatekeeper_badge = QLabel("  ◔ REGIME: UNKNOWN  ")
        self.gatekeeper_badge.setObjectName("RegimeBadge")
        self.gatekeeper_badge.setStyleSheet(
            "background-color: rgba(120, 120, 128, 0.18); color: #8e8e93; "
            "border: 1px solid rgba(120, 120, 128, 0.35); "
            "border-radius: 4px; font-size: 8px; font-weight: bold; letter-spacing: 0.8px; padding: 2px 6px; font-family: 'JetBrains Mono', 'Menlo', monospace;"
        )
        self.gatekeeper_badge.setFixedHeight(18)
        title_row.addWidget(self.gatekeeper_badge)

        title_row.addStretch(1)
        
        sub = QLabel("Institutional quantum portfolio optimizer  ·  NSE India  ·  Factor-Aware SA Ensemble"); sub.setObjectName("AppSubtitle")
        title_col.addLayout(title_row); title_col.addWidget(sub)
        self.settings_btn = QPushButton("Settings")
        self.settings_btn.setFixedHeight(28); self.settings_btn.setFixedWidth(80)
        self.settings_btn.setToolTip("Telegram · DhanHQ API · Automation · Data Providers — saved to disk")
        self.settings_btn.clicked.connect(self._open_settings)
        # providers_btn kept as alias for backward-compat but not shown in title bar.
        # Access via Settings dialog instead.
        self.providers_btn = self.settings_btn
        left.addWidget(strut); left.addLayout(title_col); left.addSpacing(6); left.addWidget(self.settings_btn)
        right = QVBoxLayout(); right.setSpacing(6)
        self.status_title = QLabel("Ready"); self.status_title.setObjectName("StatusTitle")
        self.status_subtitle = QLabel("Configure inputs and press Run optimizer"); self.status_subtitle.setObjectName("StatusSubtitle")
        self.progress_bar = QProgressBar(); self.progress_bar.setFixedHeight(10); self.progress_bar.setTextVisible(False)
        right.addWidget(self.status_title); right.addWidget(self.status_subtitle); right.addWidget(self.progress_bar)
        lay.addLayout(left, 0); lay.addStretch(1); lay.addLayout(right, 2)
        return card

    # ── AUDIT-FIX (P0 truth-in-labeling): badge refresh helpers ────────────────
    # The prior code rendered "REAL-MONEY SYSTEM ACTIVE" and "BULLISH REGIME"
    # as hardcoded constants. These helpers populate the same badges from real
    # state so the operator sees an accurate trading-mode and regime summary.
    def _refresh_trading_mode_badge(self):
        """Updates the top-bar trading-mode badge from the actual broker gates."""
        try:
            live_kite = bool(getattr(self, "kite_live_check", None) and self.kite_live_check.isChecked())
            # ANGELONE_LIVE_ORDERS env / cfg flag — live Angel One execution must be explicit
            live_angel = bool(os.environ.get("ANGELONE_LIVE_ORDERS", "").strip().lower() in ("1", "true", "yes"))
            if live_kite or live_angel:
                self.mode_badge.setText("  LIVE TRADING ACTIVE  ")
                self.mode_badge.setStyleSheet(
                    "background-color: rgba(255, 159, 10, 0.18); color: #ff9f0a; "
                    "border: 1px solid rgba(255, 159, 10, 0.55); border-radius: 4px; "
                    "font-size: 8px; font-weight: bold; letter-spacing: 0.8px; padding: 2px 6px; "
                    "font-family: 'Menlo', 'Monaco', monospace;"
                )
            else:
                self.mode_badge.setText("  PAPER TRADING MODE  ")
                self.mode_badge.setStyleSheet(
                    "background-color: rgba(120, 120, 128, 0.18); color: #8e8e93; "
                    "border: 1px solid rgba(120, 120, 128, 0.35); border-radius: 4px; "
                    "font-size: 8px; font-weight: bold; letter-spacing: 0.8px; padding: 2px 6px; "
                    "font-family: 'Menlo', 'Monaco', monospace;"
                )
        except Exception:
            # Best-effort UI refresh; never crash the optimizer on a UI guard.
            self.mode_badge.setText("  PAPER TRADING MODE  ")

    def _refresh_regime_badge(self, regime_info: dict | None):
        """Updates the top-bar regime badge from the optimizer's regime_info payload."""
        try:
            if not regime_info:
                self.gatekeeper_badge.setText("  ◔ REGIME: UNKNOWN  ")
                return
            regime = str(regime_info.get("Regime", "Unknown")).title()
            p_bear = float(regime_info.get("P_Bear", 0.5) or 0.5)
            # Sizing is taken from regime_info when available; otherwise UNKNOWN.
            sizing_pct = regime_info.get("SizingPct") if regime_info.get("SizingPct") is not None else regime_info.get("EquitySizingPct")
            # NaN regime → UNKNOWN, never Bullish. Audit defect: a NaN-regime
            # 100% cash run was previously reported as Bullish in the summary.
            # AUDIT-FIX (Round 6, D-P2-1): the guard previously scanned EVERY
            # numeric value in regime_info — but the HMM success path
            # (data_layer.py:1899-1905) hardcodes Breadth/Dispersion/
            # BenchmarkTrend/XSCorr/BenchSharpe = NaN, so the badge showed
            # "UNKNOWN" for every real HMM regime. Only the label/probability
            # fields carry regime-critical information now.
            _label_fields = [
                regime_info.get("Regime"), regime_info.get("P_Bull"),
                regime_info.get("P_Bear"), regime_info.get("P_Sideways"),
                regime_info.get("RegimeBlend"),
            ]
            if any(pd.isna(v) for v in _label_fields if isinstance(v, (int, float))):
                regime = "Unknown"
            # AUDIT-FIX (Round 6, D-P2-1): neither SizingPct nor EquitySizingPct
            # exists anywhere in the tree (grep-verified) — the badge printed
            # "— SIZING" forever. Derive the equity-sizing proxy from the
            # regime blend (P_Bull − P_Bear, rescaled to 0-100%) when present.
            if sizing_pct is None:
                _blend = regime_info.get("RegimeBlend")
                if isinstance(_blend, (int, float)) and not pd.isna(_blend):
                    sizing_pct = 0.5 + 0.5 * float(np.clip(_blend, -1.0, 1.0))
            sizing_str = f"{int(float(sizing_pct) * 100)}%" if sizing_pct is not None else "—"
            text = f"  ◔ REGIME: {regime.upper()} ({sizing_str} SIZING)  "
            color = "#00e676" if regime.lower() == "bull" else "#ff9f0a" if regime.lower() == "sideways" else "#ff453a"
            self.gatekeeper_badge.setText(text)
            self.gatekeeper_badge.setStyleSheet(
                f"background-color: rgba({int(color[1:3], 16)}, {int(color[3:5], 16)}, {int(color[5:7], 16)}, 0.12); "
                f"color: {color}; border: 1px solid {color}55; border-radius: 4px; "
                "font-size: 8px; font-weight: bold; letter-spacing: 0.8px; padding: 2px 6px; "
                "font-family: 'JetBrains Mono', 'Menlo', monospace;"
            )
        except Exception:
            self.gatekeeper_badge.setText("  ◔ REGIME: UNKNOWN  ")

    def _build_sidebar(self):
        wrap = QWidget(); outer = QVBoxLayout(wrap); outer.setContentsMargins(0, 0, 0, 0); outer.setSpacing(0)
        scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        panel = QWidget(); lay = QVBoxLayout(panel); lay.setContentsMargins(12, 8, 12, 8); lay.setSpacing(12)
        panel.setMinimumWidth(300)
        lay.addWidget(self._build_run_card()); lay.addWidget(self._build_core_card()); lay.addWidget(self._build_backtest_card())
        lay.addWidget(self._build_advanced_card())
        lay.addWidget(self._build_universe_card()); lay.addWidget(self._build_prev_holdings_card()); lay.addStretch(1)
        scroll.setWidget(panel); outer.addWidget(scroll)
        wrap.setMinimumWidth(300)
        return wrap

    def _build_run_card(self):
        card = CardFrame("SectionCard"); lay = QVBoxLayout(card); lay.setContentsMargins(16, 16, 16, 16); lay.setSpacing(10)
        title = QLabel("Run"); title.setObjectName("SectionTitle")

        # ── Research Profile dropdown ─────────────────────────────────────────
        # "⚡ Run All Profiles" is the last entry — selecting it and clicking Run
        # launches the parallel ProfileOrchestrator sweep instead of a single-profile run.
        prof_label = QLabel("Research profile"); prof_label.setObjectName("SubtleSectionTitle")
        self.profile_combo = GlassComboBox()
        self.profile_combo.addItems(list(PROFILE_MAP.keys()))
        self.profile_combo.insertSeparator(self.profile_combo.count())
        self.profile_combo.addItem("⚡ Run All Profiles")
        self.profile_combo.blockSignals(True)
        self.profile_combo.setCurrentText("⚡ Run All Profiles")   # default — no signal during init
        self.profile_combo.blockSignals(False)
        self.profile_combo.currentTextChanged.connect(self._on_profile_combo_changed)
        self.profile_combo.setMinimumHeight(34)


        # ── Single Run button — label and action adapt to dropdown selection ──
        self.run_btn = QPushButton("▶  Run"); self.run_btn.setObjectName("PrimaryButton")
        self.run_btn.setMinimumHeight(42)
        self.run_btn.setToolTip(
            "Run the selected research profile.\n"
            "Select '⚡ Run All Profiles' in the dropdown to sweep all profiles in parallel."
        )
        self.run_btn.clicked.connect(self._on_run_btn_clicked)

        # ── Stop ─────────────────────────────────────────────────────────────
        self.stop_btn = QPushButton("■  Stop"); self.stop_btn.setObjectName("StopButton")
        self.stop_btn.setEnabled(False); self.stop_btn.clicked.connect(self._on_stop_clicked)
        self.stop_btn.setMinimumHeight(36)

        # ── Force Full Rebuild button ──
        self.pipeline_btn = QPushButton("🔁  Force Full Rebuild")
        self.pipeline_btn.setMinimumHeight(36)
        self.pipeline_btn.setToolTip("Force a complete rebuild (Screen → Fit ML Alpha → Optimize) in the background, bypassing all cache.")
        self.pipeline_btn.clicked.connect(self._run_full_pipeline)

        # Aliases — other parts of the codebase reference these names
        self.run_all_profiles_btn   = self.run_btn
        self.ml_fit_btn             = self.pipeline_btn
        self.live_verify_btn        = self.pipeline_btn
        self.run_optimizer_only_btn = self.pipeline_btn

        # Theme toggle (Settings dialog only — no sidebar button)

        def _toggle_theme():
            self._dark_mode = not self._dark_mode
            apply_theme(QApplication.instance(), dark=self._dark_mode)
            _lm = not self._dark_mode
            GlassPanel._FILL_TOP = QColor(255, 255, 255, 255) if _lm else QColor(0, 0, 0, 255)
            GlassPanel._FILL_MID = QColor(255, 255, 255, 255) if _lm else QColor(0, 0, 0, 255)
            GlassPanel._FILL_BOT = QColor(255, 255, 255, 255) if _lm else QColor(0, 0, 0, 255)
            # AUDIT-FIX (Round 4 — W0106): was a list comprehension used for
            # side-effect only; rewrite as a for-loop so no throwaway list is
            # built (and the intent is unambiguous).
            for _w in QApplication.allWidgets():
                if isinstance(_w, GlassPanel):
                    _w.update()
            if getattr(self, "_tv_current", None):
                self._load_tv_chart(self._tv_current)
        self._toggle_theme = _toggle_theme

        # ── Broker ───────────────────────────────────────────────────────────
        broker_label = QLabel("Broker"); broker_label.setObjectName("SubtleSectionTitle")
        broker_row = QHBoxLayout(); broker_row.setSpacing(6)
        self.broker_combo = GlassComboBox()
        self._broker_actions = {
            "Reconcile Holdings":   self.reconcile_holdings,
            "Place Basket Orders":  self.place_basket_direct,
            "Start Live P&L":       self.start_live_pnl,
        }
        self.broker_combo.addItems(list(self._broker_actions.keys()))
        self.broker_combo.setMinimumHeight(32)
        self.broker_btn = QPushButton("Execute"); self.broker_btn.setObjectName("PrimaryButton")
        self.broker_btn.setMinimumHeight(32)
        self.broker_btn.clicked.connect(self._on_broker_selected)
        broker_row.addWidget(self.broker_combo, 1); broker_row.addWidget(self.broker_btn)
        self.reconcile_btn = self.broker_btn
        self.place_direct_btn = self.broker_btn
        self.live_pnl_btn = self.broker_btn

        # ── Download ─────────────────────────────────────────────────────────
        dl_label = QLabel("Download"); dl_label.setObjectName("SubtleSectionTitle")
        dl_row = QHBoxLayout(); dl_row.setSpacing(6)
        self.download_combo = GlassComboBox()
        self._download_actions = {
            "Portfolio CSV":            self.export_portfolio_csv,
            "Universe CSV":             self.export_prescreen_csv,
            "Diagnostics CSV":          self.export_diagnostics_csv,
            "Snapshot JSON":            self.export_run_snapshot_json,
            "Investment Memo":          self.export_investment_memo_md,
            "Chart Pack":               self.export_chart_pack,
            "Breakout CSV":             self.export_breakout_csv,
            "Pre-Breakout CSV":         self.export_prebreakout_csv,
            "Copy Portfolio CSV":       self._copy_portfolio_to_clipboard,
            "PDF Report":               self._export_pdf_now,
            "Infrastructure Files":     self._export_infrastructure_files,
            "Experiment History":       self._show_experiment_history,
            "Combined Portfolio (Sweep) CSV": self.export_combined_portfolio_csv,
            "Combined Universe (Sweep) CSV":  self.export_combined_universe_csv,
            "Combined Breakout (Sweep) CSV":  self.export_combined_breakout_csv,
            "Combined Pre-Breakout (Sweep) CSV": self.export_combined_prebreakout_csv,
        }
        self.download_combo.addItems(list(self._download_actions.keys()))
        self.download_combo.setMinimumHeight(32)
        self.download_btn = QPushButton("⬇  Download"); self.download_btn.setObjectName("PrimaryButton")
        self.download_btn.setMinimumHeight(32)
        self.download_btn.clicked.connect(self._on_download_selected)
        dl_row.addWidget(self.download_combo, 1); dl_row.addWidget(self.download_btn)

        # ── Assemble ──────────────────────────────────────────────────────────

        lay.addWidget(title)
        lay.addWidget(prof_label)
        lay.addWidget(self.profile_combo)
        lay.addSpacing(4)
        lay.addWidget(self.run_btn)
        lay.addWidget(self.stop_btn)
        lay.addWidget(self.pipeline_btn)
        lay.addSpacing(4)
        lay.addWidget(broker_label); lay.addLayout(broker_row)
        lay.addSpacing(4)
        lay.addWidget(dl_label); lay.addLayout(dl_row)
        return card




    def _on_download_selected(self):
        """Execute the download action selected in the download_combo dropdown."""
        sel = self.download_combo.currentText()
        action = self._download_actions.get(sel)
        if action:
            try: action()
            except Exception as _e: self.append_log(f"[Download] {sel} failed: {_e}")

    def _on_broker_selected(self):
        """Execute the broker action selected in the broker_combo dropdown."""
        sel = self.broker_combo.currentText()
        action = self._broker_actions.get(sel)
        if action:
            try: action()
            except Exception as _e: self.append_log(f"[Broker] {sel} failed: {_e}")

    def _export_infrastructure_files(self):
        """Export K8s/Redis/TimescaleDB/Airflow/Docker infrastructure files."""
        try:
            from enterprise.infrastructure import save_infrastructure_files
            export_dir = Path(RUNTIME_DIR) / "infrastructure"
            save_infrastructure_files(str(export_dir))
            self.append_log(f"[Infrastructure] Files saved to {export_dir}/")
        except Exception as _e:
            self.append_log(f"[Infrastructure] Export failed: {_e}")

    def _show_experiment_history(self):
        """Show ML experiment history from the experiment tracker."""
        try:
            from ml_alpha.feature_store import ExperimentTracker
            tracker = ExperimentTracker()
            experiments = tracker.list_experiments()
            if not experiments:
                self.append_log("[Experiments] No experiments logged yet.")
                return
            self.append_log(f"[Experiments] {len(experiments)} runs logged:")
            for exp in experiments[:10]:
                metrics = exp.get("metrics", {})
                _dsr = metrics.get("deflated_sharpe", 0)
                _oos = metrics.get("oos_sharpe_mean", 0)
                _ts = exp.get("timestamp", "")[:19]
                self.append_log(f"  {_ts} | DSR={_dsr:.4f} | OOS Sharpe={_oos:+.2f} | {exp.get('run_id', '')}")
        except Exception as _e:
            self.append_log(f"[Experiments] Could not load: {_e}")

    def _build_core_card(self):
        card = CardFrame("SectionCard"); lay = QVBoxLayout(card); lay.setContentsMargins(16, 16, 16, 16)
        title = QLabel("Core Data Filters"); title.setObjectName("SectionTitle")
        form = QFormLayout(); form.setLabelAlignment(Qt.AlignLeft); form.setFormAlignment(Qt.AlignTop); form.setHorizontalSpacing(16); form.setVerticalSpacing(8)
        self.lookback_combo = GlassComboBox(); self.lookback_combo.addItems(["1y", "2y", "3y", "5y"])
        self.prescreen_combo = GlassComboBox(); self.prescreen_combo.addItems(["6mo", "1y", "2y", "3y"])
        self.benchmark_combo = GlassComboBox(); self.benchmark_combo.addItems(["^NSEI", "NIFTYBEES.NS", "^BSESN"])
        self.topn_spin = QSpinBox(); self.topn_spin.setRange(20, 2000)
        self.k_spin = QSpinBox(); self.k_spin.setRange(2, 100)
        self.min_data_spin = QDoubleSpinBox(); self.min_data_spin.setRange(0.50, 1.00); self.min_data_spin.setDecimals(2); self.min_data_spin.setSingleStep(0.05)
        self.min_vol_spin = QDoubleSpinBox(); self.min_vol_spin.setRange(1_000_000.0, 5_000_000_000.0); self.min_vol_spin.setDecimals(0); self.min_vol_spin.setGroupSeparatorShown(True)
        self.min_price_spin = QDoubleSpinBox(); self.min_price_spin.setRange(1.0, 10000.0); self.min_price_spin.setDecimals(1)
        
        self.data_provider_combo = GlassComboBox()
        self.data_provider_combo.addItems(["Yahoo Finance", "Angel One SmartAPI v2 (Official)", "Local Archive DB"])
        self.data_provider_combo.currentTextChanged.connect(self._on_data_provider_changed)
        
        form.addRow("Final lookback", self.lookback_combo); form.addRow("Prescreen lookback", self.prescreen_combo)
        form.addRow("Benchmark", self.benchmark_combo)
        form.addRow("Universe size", self.topn_spin); form.addRow("Portfolio size", self.k_spin)
        form.addRow("Min data pct", self.min_data_spin); form.addRow("Min ADV20 ₹", self.min_vol_spin); form.addRow("Min price", self.min_price_spin)
        form.addRow("Data Provider", self.data_provider_combo)
        lay.addWidget(title); lay.addLayout(form)

        return card

    def _on_data_provider_changed(self, text):
        import utils
        from data_layer import AngelOneProvider, ExchangeLocalDBProvider, YFinanceProvider
        # AUDIT-FIX (Round 6, D-P2-2): previously only `utils._DATA_PROVIDER`
        # was reassigned — every OTHER loaded module that had already bound
        # the old provider object kept using it (e.g. this file's stale
        # module-local import used by the TV-chart loaders), so the interactive
        # charts kept fetching from the OLD provider after a switch.
        # utils.set_provider() propagates the change to every loaded module.
        if "Angel" in text or "Dhan" in text:
            utils.set_provider(AngelOneProvider())
            self.append_log("[Data Provider] Switched to Angel One SmartAPI v2 (Official).")
        elif text == "Local Archive DB":
            utils.set_provider(ExchangeLocalDBProvider())
            self.append_log("[Data Provider] Switched to Local Archive DB.")
        else:
            utils.set_provider(YFinanceProvider())
            self.append_log("[Data Provider] Switched to Yahoo Finance.")

    def _on_save_dhan_credentials(self):
        client_id = getattr(self, "dhan_client_id_input", QLineEdit()).text().strip()
        api_key = getattr(self, "dhan_api_key_input", QLineEdit()).text().strip()
        api_secret = getattr(self, "dhan_api_secret_input", QLineEdit()).text().strip()

        if not client_id or not api_key:
            self.append_log("❌ [AngelOne API] Please enter both Client ID and API Key.")
            return

        # Save to models/angelone_config.json & .env
        cfg = {"client_id": client_id, "access_token": api_key, "api_secret": api_secret}
        # AUDIT-FIX (Round 6, C-P3-2): anchor to project dir, not CWD
        _models_dir = Path(__file__).resolve().parent.parent / "models"
        _models_dir.mkdir(parents=True, exist_ok=True)
        with open(_models_dir / "angelone_config.json", "w") as f:
            json.dump(cfg, f, indent=2)

        os.environ["ANGELONE_CLIENT_ID"] = client_id
        os.environ["ANGELONE_API_KEY"] = api_key

        from data_layer import AngelOneProvider
        provider = AngelOneProvider(client_id, api_key, api_secret)
        import utils
        # AUDIT-FIX (Round 6, D-P2-2): propagate via set_provider (see
        # _on_data_provider_changed) so every loaded module sees the switch.
        utils.set_provider(provider)

        ok, msg = provider.test_connection()
        if ok:
            self.data_provider_combo.setCurrentText("Angel One SmartAPI v2 (Official)")
            self.append_log(f"🎉 [Angel One SmartAPI v2] Credentials saved! {msg}")
        else:
            self.append_log(f"⚠️ [Angel One SmartAPI v2] Credentials saved locally. Notice: {msg}")


    def _build_backtest_card(self):
        card = CardFrame("SectionCard"); lay = QVBoxLayout(card); lay.setContentsMargins(16, 16, 16, 16)
        title = QLabel("Walk-Forward OOS Backtest"); title.setObjectName("SectionTitle")
        warn = QLabel("Note: True Walk-Forward requires heavy compute. Enable only when ready to verify strategy out-of-sample."); warn.setWordWrap(True); warn.setObjectName("MutedText")
        form = QFormLayout(); form.setHorizontalSpacing(16); form.setVerticalSpacing(8)
        self.run_backtest_check = QCheckBox("Run Walk-Forward Backtest")
        self.backtest_rebalance_spin = QSpinBox(); self.backtest_rebalance_spin.setRange(5, TRADING_DAYS_PER_YEAR)
        self.backtest_fee_spin = QDoubleSpinBox(); self.backtest_fee_spin.setRange(0.0, 100.0); self.backtest_fee_spin.setDecimals(2)
        self.backtest_slip_spin = QDoubleSpinBox(); self.backtest_slip_spin.setRange(0.0, 100.0); self.backtest_slip_spin.setDecimals(2)
        form.addRow(self.run_backtest_check)
        form.addRow("Rebalance (Days)", self.backtest_rebalance_spin)
        form.addRow("Fee bps", self.backtest_fee_spin); form.addRow("Slippage bps", self.backtest_slip_spin)
        lay.addWidget(title); lay.addWidget(warn); lay.addLayout(form)
        return card

    def _build_advanced_card(self):
        group = CollapsibleGroup("Advanced Penalties & Risk", expanded=False); form = QFormLayout(); form.setHorizontalSpacing(16); form.setVerticalSpacing(8)
        
        self.risk_model_combo = GlassComboBox(); self.risk_model_combo.addItems(["PCA Factor (5)", "PCA Factor (10)", "Ledoit-Wolf", "Oracle Shrinkage (OAS)", "Denoised Covariance (RMT)", "Historical Covariance", "Downside Semi-Covariance (CVaR)", "Barra Factor Model"])
        self.risk_horizon_combo = GlassComboBox(); self.risk_horizon_combo.addItems(["Strategic (252d)", "Tactical (30d)"])
        self.gamma_spin = QDoubleSpinBox(); self.gamma_spin.setRange(0.10, 300.0); self.gamma_spin.setDecimals(2)
        self.theta_spin = QDoubleSpinBox(); self.theta_spin.setRange(0.10, 300.0); self.theta_spin.setDecimals(2)
        self.alpha_spin = QDoubleSpinBox(); self.alpha_spin.setRange(0.10, 50.0); self.alpha_spin.setDecimals(2)
        self.sector_penalty_spin = QDoubleSpinBox(); self.sector_penalty_spin.setRange(0.0, 50.0); self.sector_penalty_spin.setDecimals(2)
        self.unknown_sector_spin = QDoubleSpinBox(); self.unknown_sector_spin.setRange(0.0, 50.0); self.unknown_sector_spin.setDecimals(2)
        self.vol_penalty_spin = QDoubleSpinBox(); self.vol_penalty_spin.setRange(0.0, 20.0); self.vol_penalty_spin.setDecimals(2)
        self.beta_penalty_spin = QDoubleSpinBox(); self.beta_penalty_spin.setRange(0.0, 20.0); self.beta_penalty_spin.setDecimals(2)
        self.turnover_penalty_spin = QDoubleSpinBox(); self.turnover_penalty_spin.setRange(0.0, 20.0); self.turnover_penalty_spin.setDecimals(2)
        self.corr_shrink_spin = QDoubleSpinBox(); self.corr_shrink_spin.setRange(0.00, 0.95); self.corr_shrink_spin.setDecimals(2)
        self.max_sector_spin = QSpinBox(); self.max_sector_spin.setRange(1, 10)
        self.min_weight_spin = QDoubleSpinBox(); self.min_weight_spin.setRange(0.00, 0.30); self.min_weight_spin.setDecimals(2); self.min_weight_spin.setSingleStep(0.01)
        self.max_weight_spin = QDoubleSpinBox(); self.max_weight_spin.setRange(0.05, 1.00); self.max_weight_spin.setDecimals(2); self.max_weight_spin.setSingleStep(0.01)
        self.optimizer_mode_combo = GlassComboBox(); self.optimizer_mode_combo.addItems(["Hybrid", "Anneal", "Greedy", "QPU (Native)"])
        self.regime_filter_combo = GlassComboBox(); self.regime_filter_combo.addItems(["Adaptive", "Risk-On Bias", "Defensive Bias"])
        self.reads_spin = QSpinBox(); self.reads_spin.setRange(100, 100000); self.sweeps_spin = QSpinBox(); self.sweeps_spin.setRange(100, 100000)
        self.restarts_spin = QSpinBox(); self.restarts_spin.setRange(1, 20); self.batch_spin = QSpinBox(); self.batch_spin.setRange(5, 100)
        self.download_workers_spin = QSpinBox(); self.download_workers_spin.setRange(1, 16)
        self.use_ic_weights_check = QCheckBox("Auto-calibrate weights (IC)")

        form.addRow("Risk Model", self.risk_model_combo)
        form.addRow("Risk Horizon", self.risk_horizon_combo)
        form.addRow("Corr Shrinkage", self.corr_shrink_spin)
        form.addRow("Optimizer Mode", self.optimizer_mode_combo); form.addRow("Regime Filter", self.regime_filter_combo)
        form.addRow("Alpha weight", self.alpha_spin); form.addRow("Gamma (Size)", self.gamma_spin); form.addRow("Theta (Corr)", self.theta_spin)
        form.addRow("Vol penalty", self.vol_penalty_spin); form.addRow("Beta penalty", self.beta_penalty_spin); form.addRow("Turnover penalty", self.turnover_penalty_spin)
        form.addRow("Sector penalty", self.sector_penalty_spin); form.addRow("Unknown sector", self.unknown_sector_spin); form.addRow("Max per sector", self.max_sector_spin)
        form.addRow("Min weight", self.min_weight_spin); form.addRow("Max weight", self.max_weight_spin)
        form.addRow("Download workers", self.download_workers_spin)
        form.addRow("SA reads", self.reads_spin); form.addRow("SA sweeps", self.sweeps_spin); form.addRow("Multi starts", self.restarts_spin)
        form.addRow(self.use_ic_weights_check)
        
        group.body_layout.addLayout(form)
        return group

    def _build_automation_card(self):
        group = CollapsibleGroup("Automation & Alerts", expanded=False)
        form = QFormLayout(); form.setHorizontalSpacing(16); form.setVerticalSpacing(8)
        self.auto_run_check = QCheckBox("Enable scheduled auto-run")
        self.auto_run_check.toggled.connect(self._sync_autorun_state)
        self.auto_run_interval_spin = QSpinBox(); self.auto_run_interval_spin.setRange(5, 1440); self.auto_run_interval_spin.setSuffix(" min")
        self.auto_run_interval_spin.valueChanged.connect(self._sync_autorun_state)
        self.auto_export_memo_check = QCheckBox("Auto-export memo after scheduled runs")
        self.next_autorun_label = QLabel("Next auto-run: manual only"); self.next_autorun_label.setObjectName("MutedText")
        form.addRow(self.auto_run_check)
        form.addRow("Interval", self.auto_run_interval_spin)
        form.addRow(self.auto_export_memo_check)
        group.body_layout.addLayout(form)
        group.body_layout.addWidget(self.next_autorun_label)
        return group


    def _build_telegram_card(self):
        """Telegram notification settings — token, chat ID, live test."""
        group = CollapsibleGroup("📨 Telegram Notifications", expanded=False)

        self.telegram_enabled_check = QCheckBox("Send notification after every run")

        self.telegram_token_edit = QLineEdit()
        self.telegram_token_edit.setPlaceholderText("Bot token from @BotFather  e.g. 123456:ABC-xyz")
        self.telegram_token_edit.setEchoMode(QLineEdit.Password)

        self.telegram_chatid_edit = QLineEdit()
        self.telegram_chatid_edit.setPlaceholderText("Chat ID  e.g. -100123456789 or 123456789")

        self.telegram_test_btn = QPushButton("🧪  Test")
        self.telegram_test_btn.setFixedWidth(90)
        self.telegram_test_btn.clicked.connect(self._test_telegram)

        self.telegram_status_lbl = QLabel("")
        self.telegram_status_lbl.setObjectName("MutedText")

        help_lbl = QLabel(
            "<small>"
            "1. Message <b>@BotFather</b> on Telegram → /newbot → copy token<br>"
            "2. Add your bot to a group (or message it directly)<br>"
            "3. Message <b>@userinfobot</b> to get your chat ID<br>"
            "4. Paste both above and press Test"
            "</small>"
        )
        help_lbl.setWordWrap(True)
        help_lbl.setObjectName("MutedText")

        chat_row = QHBoxLayout()
        chat_row.addWidget(self.telegram_chatid_edit)
        chat_row.addWidget(self.telegram_test_btn)

        form = QFormLayout()
        form.setSpacing(6)
        form.addRow(self.telegram_enabled_check)
        form.addRow("Bot Token",  self.telegram_token_edit)
        form.addRow("Chat ID",    chat_row)
        form.addRow("",           self.telegram_status_lbl)
        form.addRow(help_lbl)
        group.body_layout.addLayout(form)
        return group

    def _test_telegram(self):
        """Fire a test ping in a background thread; show result inline."""
        token   = self.telegram_token_edit.text().strip()
        chat_id = self.telegram_chatid_edit.text().strip()
        if not token or not chat_id:
            self.telegram_status_lbl.setText("⚠️  Enter token and chat ID first")
            return
        self.telegram_status_lbl.setText("Sending…")
        import threading as _t
        def _ping():
            try:
                import requests as _r
                msg = (
                    "🤖 *QUBO Portfolio Engine* — connection test\n"
                    f"✅ Bot verified {datetime.now().strftime('%d %b %Y %H:%M')} IST"
                )
                resp = _r.post(
                    f"https://api.telegram.org/bot{token}/sendMessage",
                    json={"chat_id": chat_id, "text": msg, "parse_mode": "Markdown"},
                    timeout=10
                )
                if resp.status_code == 200:
                    # M10-fix + AUDIT-FIX (Round 5, 2-a-9): QTimer.singleShot from
                    # this daemon thread never fires (Qt timers require a QThread with
                    # an event loop). Marshal via the MainWindow._gui_call signal,
                    # which is queued to the GUI thread automatically.
                    _msg_ok = "✅ Message sent — check Telegram"
                    self._gui_call.emit(lambda: self.telegram_status_lbl.setText(_msg_ok))
                else:
                    err = resp.json().get("description", resp.text[:80])
                    _msg_err = f"❌ {err}"
                    self._gui_call.emit(lambda: self.telegram_status_lbl.setText(_msg_err))
            except Exception as ex:
                _msg_exc = f"❌ {str(ex)[:90]}"
                self._gui_call.emit(lambda: self.telegram_status_lbl.setText(_msg_exc))
        _t.Thread(target=_ping, daemon=True).start()

    def _build_angelone_card(self):
        """Angel One SmartAPI credentials + PDF export card."""
        group = CollapsibleGroup("😇 Angel One SmartAPI v2 / Export", expanded=False)
        form  = QFormLayout()
        form.setHorizontalSpacing(16)
        form.setVerticalSpacing(8)

        self.angel_key_edit   = QLineEdit()
        self.angel_key_edit.setPlaceholderText("Angel One API Key")
        self.dhan_key_edit   = self.angel_key_edit  # Backward compatibility alias
        self.kite_key_edit   = self.angel_key_edit

        self.angel_clientid_edit = QLineEdit()
        self.angel_clientid_edit.setPlaceholderText("Angel One Client Code")
        self.angel_clientid_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.dhan_token_edit = self.angel_clientid_edit  # Backward compatibility alias
        self.kite_token_edit = self.angel_clientid_edit

        # AUDIT-FIX (Round 8, T3 — Part 2B): the live Angel One path read
        # `self.password` / `self.totp_secret` on the WORKER thread — attributes
        # that never existed anywhere, so live orders ALWAYS sent empty
        # credentials (the SmartAPI login can never succeed). Two dedicated
        # inputs now exist and are snapshotted on the GUI thread in
        # AlgoExecutionWorker.__init__ (never read from run()).
        self.angel_pwd_edit = QLineEdit()
        self.angel_pwd_edit.setPlaceholderText("Angel One Login Password (PIN/mpin)")
        self.angel_pwd_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.angel_totp_edit = QLineEdit()
        self.angel_totp_edit.setPlaceholderText("Angel One TOTP Secret (for 2FA code generation)")
        self.angel_totp_edit.setEchoMode(QLineEdit.EchoMode.Password)

        self.angel_live_check = QCheckBox("Live orders  ⚠️ (disables dry-run)")
        self.angel_live_check.setToolTip("When checked, Place Basket will send REAL orders via Angel One SmartAPI v2.")
        self.dhan_live_check = self.angel_live_check  # Backward compatibility alias
        self.kite_live_check = self.angel_live_check

        self.pdf_auto_check  = QCheckBox("Auto-export PDF after each run")

        self.exec_destination_combo = QComboBox()
        self.exec_destination_combo.addItems(["Angel One SmartAPI v2 Router", "Institutional FIX 4.2 Engine"])
        self.exec_destination_combo.setToolTip("Select execution destination: Angel One SmartAPI v2 Router or FIX Protocol engine.")

        form.addRow("API Key:",     self.angel_key_edit)
        form.addRow("Client Code:", self.angel_clientid_edit)
        form.addRow("Password:", self.angel_pwd_edit)
        form.addRow("TOTP Secret:", self.angel_totp_edit)
        form.addRow("Destination:", self.exec_destination_combo)
        form.addRow(self.angel_live_check)
        form.addRow(self.pdf_auto_check)

        self.export_pdf_btn = QPushButton("📄 Export PDF / Report")
        self.export_pdf_btn.setMinimumHeight(36)
        self.export_pdf_btn.setToolTip("Export portfolio report as PDF (or .txt fallback)")
        self.export_pdf_btn.clicked.connect(self._export_pdf_now)

        group.body_layout.addLayout(form)
        group.body_layout.addWidget(self.export_pdf_btn)
        return group

    def _build_dhan_card(self):
        return self._build_angelone_card()

    def _build_kite_card(self):
        return self._build_angelone_card()

    def _copy_portfolio_to_clipboard(self):
        """v17.2: Copy portfolio table as CSV text to system clipboard.
        Uses QApplication.instance() — binding-agnostic, works with PySide6/PyQt5.
        """
        if not self.last_payload:
            self._show_styled_message("Copy Portfolio", "Run the optimizer first.", _QMESSAGEBOX_ICON.Information)
            return
        try:
            df = self.last_payload.get("portfolio_df")
            if df is None or df.empty:
                self._show_styled_message("Copy Portfolio", "Portfolio is empty — run optimizer first.", _QMESSAGEBOX_ICON.Information)
                return
            csv_text = df.to_csv(index=False)
            # Always use the live running QApplication instance — never re-import
            # a different Qt binding class (PyQt5/PyQt6 static calls fail on PySide6)
            app_inst = QApplication.instance()
            if app_inst is None:
                raise RuntimeError("No QApplication instance found.")
            app_inst.clipboard().setText(csv_text)
            self.append_log(f"[Copy] ✅ {len(df)} rows copied to clipboard as CSV")
            # Toast visible from any tab — 4 s auto-clears
            self.status_subtitle.setText(
                f"✓ {len(df)} holdings copied to clipboard  —  paste into Excel / Sheets")
            QTimer.singleShot(4000, lambda: self.status_subtitle.setText(
                "Ready — configure inputs and press Run optimizer"))
        except Exception as e:
            self.append_log(f"[Copy] Failed: {e}")
            self._show_styled_message("Copy Failed",
                                      f"Clipboard write failed:\n{e}\n\n"
                                      "Use  Portfolio CSV  button to save a file instead.", _QMESSAGEBOX_ICON.Warning)

    def _export_pdf_now(self):
        if not self.last_payload:
            self._show_styled_message("No Data", "No run data found. Please run the optimizer or sweep first.", _QMESSAGEBOX_ICON.Warning)
            return
        from datetime import datetime as _dt
        ts   = _dt.now().strftime("%Y%m%d_%H%M%S")
        path = str(RUNTIME_DIR / f"QA_Pro_v17_{ts}.pdf")
        ok   = export_pdf_report(self.last_payload,
                                  self.last_payload.get("cfg", {}),
                                  self.last_payload.get("regime_info", {}),
                                  path, log_cb=self.append_log)
        if ok:
            self.append_log(f"[PDF] ✅ Saved → {path}")


    def _build_universe_card(self):
        card = CardFrame("SectionCard"); lay = QVBoxLayout(card); lay.setContentsMargins(16, 16, 16, 16); lay.setSpacing(10)
        title = QLabel("Universe source"); title.setObjectName("SectionTitle")
        
        self.live_verify_screen_check = QCheckBox("Auto-run live full-NSE neural screen")
        self.live_verify_screen_check.setToolTip("Automatically scan full NSE listed equities using HMM and ViT before optimization to feed fresh breakout setups")
        self.live_verify_screen_check.setStyleSheet("QCheckBox { font-weight: bold; color: #0a84ff; }")
        self.live_verify_screen_check.toggled.connect(self._sync_universe_source_ui)

        self.manual_universe_check = QCheckBox("Use manual symbols")
        self.manual_universe_check.toggled.connect(self._sync_universe_source_ui)
        self.manual_symbols = QPlainTextEdit(); self.manual_symbols.setMinimumHeight(80)
        self.manual_symbols.setPlaceholderText("One ticker per line. Example:\nRELIANCE\nTCS\nINFY.NS")
        self.manual_symbols.textChanged.connect(self._on_manual_symbols_changed)
        self.manual_universe_hint = QLabel("When enabled, the optimizer uses your symbol list as the source universe instead of fetching the full exchange list.")
        self.manual_universe_hint.setWordWrap(True)
        self.manual_universe_hint.setObjectName("MutedText")
        
        lay.addWidget(title)
        lay.addWidget(self.live_verify_screen_check)
        lay.addWidget(self.manual_universe_check)
        lay.addWidget(self.manual_symbols)
        lay.addWidget(self.manual_universe_hint)
        return card

    def _build_prev_holdings_card(self):
        card = CardFrame("SectionCard"); lay = QVBoxLayout(card); lay.setContentsMargins(16, 16, 16, 16); lay.setSpacing(10)
        title = QLabel("Previous holdings"); title.setObjectName("SectionTitle")
        self.prev_holdings = QPlainTextEdit(); self.prev_holdings.setMinimumHeight(80)
        self.prev_holdings.setPlaceholderText("Optional. One ticker per line.\nUsed for turnover control / warm start.\nExample:\nRELIANCE\nHDFCBANK")
        self.prev_holdings_hint = QLabel("Used to penalize unnecessary churn and warm-start the solver from your existing book.")
        self.prev_holdings_hint.setWordWrap(True)
        self.prev_holdings_hint.setObjectName("MutedText")
        lay.addWidget(title); lay.addWidget(self.prev_holdings); lay.addWidget(self.prev_holdings_hint)
        return card

    def _build_results(self):
        panel = QWidget(); lay = QVBoxLayout(panel); lay.setContentsMargins(0, 0, 0, 0); lay.setSpacing(14)
        self.universe_card = MetricCard("Universe"); self.eligible_card = MetricCard("Eligible")
        self.selected_card = MetricCard("Selected"); self.energy_card = MetricCard("Energy")
        metrics_row = QHBoxLayout(); metrics_row.setSpacing(8); metrics_row.setContentsMargins(0,0,0,0)
        for _mc in [self.universe_card, self.eligible_card, self.selected_card, self.energy_card]:
            metrics_row.addWidget(_mc, 1)
        metrics_wrap = QWidget(); metrics_wrap.setStyleSheet("background:transparent;")
        metrics_wrap.setLayout(metrics_row)
        lay.addWidget(metrics_wrap)

        strip = QFrame(); strip.setObjectName("InfoStrip"); sl = QHBoxLayout(strip); sl.setContentsMargins(14, 0, 14, 0); sl.setSpacing(0)
        self.matrix_label    = QLabel("MATRIX  —");  self.matrix_label.setObjectName("StripLabel")
        self.sector_label    = QLabel("SECTORS  —"); self.sector_label.setObjectName("StripLabel")
        self.resolve_label   = QLabel("RESOLVED  —"); self.resolve_label.setObjectName("StripLabel")
        self.regime_label    = QLabel("REGIME  —");  self.regime_label.setObjectName("StripLabel")
        self.benchmark_label = QLabel("INDEX  —");   self.benchmark_label.setObjectName("StripLabel")
        self.solver_label    = QLabel("SOLVER  —");  self.solver_label.setObjectName("StripLabel")
        self.backtest_label  = QLabel("OOS  —");     self.backtest_label.setObjectName("StripLabel")
        for _lbl in [self.matrix_label, self.sector_label, self.resolve_label, self.regime_label,
                     self.benchmark_label, self.solver_label, self.backtest_label]:
            sl.addWidget(_lbl)
        sl.addStretch(1); lay.addWidget(strip)

        tabs_card = CardFrame("TabsCard"); tl = QVBoxLayout(tabs_card); tl.setContentsMargins(12, 12, 12, 12); tl.setSpacing(10)
        self.tabs = QStackedWidget()
        
        self.portfolio_page, self.portfolio_table, self.portfolio_placeholder = self._make_table_page(
            "🚀 Portfolio allocations, optimal weights, and Snell exit targets will appear here after clicking '▶ Run'."
        )
        self.prescreen_page, self.prescreen_table, self.prescreen_placeholder = self._make_table_page("The eligible universe will appear here after a run.")
        self.sector_summary_page, self.sector_summary_table, self.sector_summary_placeholder = self._make_table_page("Sector summary will appear here after a run.")
        
        self.factor_summary_page, self.factor_summary_table, self.factor_summary_placeholder = self._make_table_page("Factor summary will appear here after a run.")
        self.exposures_page, self.exposures_table, self.exposures_placeholder = self._make_table_page("Exposure analysis will appear here after a run.")
        self.sector_relative_page, self.sector_relative_table, self.sector_relative_placeholder = self._make_table_page("Sector-relative benchmarking will appear here after a run.")
        self.changes_page, self.changes_table, self.changes_placeholder = self._make_table_page("Run at least once to compare portfolio changes.")
        self.alerts_page, self.alerts_table, self.alerts_placeholder = self._make_table_page("Portfolio alerts will appear here when rules trigger.")
        self.diagnostics_page, self.diagnostics_table, self.diagnostics_placeholder = self._make_table_page("Diagnostics will appear here after a run.")
        self.corr_page, self.corr_table, self.corr_placeholder = self._make_table_page("Correlation analysis will appear here after a run.")
        self.history_page, self.history_table, self.history_placeholder = self._make_table_page("Run history will appear here after completed runs.")
        self.alert_history_page, self.alert_history_table, self.alert_history_placeholder = self._make_table_page("Alert history will appear here after completed runs.")

        self.risk_page, self.risk_table, self.risk_placeholder = self._make_table_page("Value-at-Risk, CVaR and NSE historical stress testing will appear here after a run.")
        self.mrc_page, self.mrc_table, self.mrc_placeholder = self._make_table_page("Marginal Risk Contribution (MRC) details will appear here after a run.")
        self.watchlist_page, self.watchlist_table, self.watchlist_placeholder = self._make_table_page("Watchlist stock z-scores and momentum rankings will appear here after a run.")
        self.live_pnl_page, self.live_pnl_table, self.live_pnl_placeholder = self._make_table_page("Live P&L tracker will appear here after starting LTP polling.")
        self.logs_box = QPlainTextEdit()
        self.logs_box.setReadOnly(True)
        self.logs_box.setLineWrapMode(QPlainTextEdit.NoWrap)
        self.logs_box.setFont(QFont("Menlo", 10))
        self.logs_box.setMaximumBlockCount(2000)

        self.breakout_page, self.breakout_table, self.breakout_placeholder = self._make_table_page(
            "🚀 Early Breakout stocks will appear here after a run.\n\nCriteria: Price > 20 & 50 EMA, RSI 55–72, Volume surge > 1.4×, Near 52W high."
        )
        self.prebreakout_page, self.prebreakout_table, self.prebreakout_placeholder = self._make_table_page(
            "🔍 Pre-Breakout setups will appear here after a run.\n\nCriteria: Coiling near EMAs, RSI 45–60, Trend quality > 0.4, Volume quiet, Positive 3M/6M momentum."
        )
        self.factor_attr_page, self.factor_attr_table, self.factor_attr_placeholder = self._make_table_page("Factor Attribution will appear here after a run.")
        self.backtest_page, self.backtest_table, self.backtest_placeholder = self._make_table_page("Walk-forward backtest results will appear here when enabled.")
        self.execution_page = self._build_execution_tab()

        self.quarterly_results_page   = None
        self.earnings_surprise_page   = None
        self.revenue_growth_page      = None
        self.margin_trend_page        = None
        self.consensus_page           = None
        self.options_chain_page       = None
        self.scenario_stress_page     = ScenarioStressLibrary()
        self.ai_copilot_page          = AICopilotPanel()

        logs_page = QWidget()
        logs_lay = QVBoxLayout(logs_page)
        logs_lay.setContentsMargins(8, 8, 8, 8)
        logs_lay.setSpacing(0)
        logs_lay.addWidget(self.logs_box)

        self.results_tab_labels = [
            "Portfolio", "Universe", "Sectors", "Factors", "Exposures", "Sector RS",
            "Changes", "Alerts", "Charts", "OOS Backtest", "Diagnostics", "Correlation",
            "History", "Risk Analytics", "Logs", "Scenario Stress", "Execution",
            "Live P&L", "AI Copilot",
            "⚡ All Profiles",
            "🚀 Breakout", "🔍 Pre-Breakout", "🔬 Technical",
            "Alert Log", "MRC", "Factor Attr.", "Watchlist",
        ]

        # Disable dynamic load of legacy QWidget stubs to prevent UI bloat and boost performance
        self._dynamic_tab_classes = {}

        widgets_to_add = []
        for label in self.results_tab_labels:
            if label == "Portfolio":
                widgets_to_add.append(self._build_portfolio_tab())
            elif label == "Universe":
                widgets_to_add.append(self.prescreen_page)
            elif label == "Sectors":
                widgets_to_add.append(self.sector_summary_page)
            elif label == "Factors":
                widgets_to_add.append(self.factor_summary_page)
            elif label == "Exposures":
                widgets_to_add.append(self.exposures_page)
            elif label == "Sector RS":
                widgets_to_add.append(self.sector_relative_page)
            elif label == "Changes":
                widgets_to_add.append(self.changes_page)
            elif label == "Alerts":
                widgets_to_add.append(self.alerts_page)
            elif label == "Charts":
                widgets_to_add.append(self._build_charts_tab())
            elif label == "OOS Backtest":
                widgets_to_add.append(self.backtest_page)
            elif label == "Diagnostics":
                widgets_to_add.append(self.diagnostics_page)
            elif label == "Correlation":
                widgets_to_add.append(self.corr_page)
            elif label == "History":
                widgets_to_add.append(self.history_page)
            elif label == "Alert Log":
                widgets_to_add.append(self.alert_history_page)
            elif label == "Logs":
                widgets_to_add.append(logs_page)
            elif label == "Risk Analytics":
                widgets_to_add.append(self.risk_page)
            elif label == "Scenario Stress":
                widgets_to_add.append(self.scenario_stress_page)
            elif label == "Execution":
                widgets_to_add.append(self.execution_page)
            elif label == "MRC":
                widgets_to_add.append(self.mrc_page)
            elif label == "Factor Attr.":
                widgets_to_add.append(self.factor_attr_page)
            elif label == "Watchlist":
                widgets_to_add.append(self.watchlist_page)
            elif label == "Live P&L":
                widgets_to_add.append(self.live_pnl_page)
            elif label == "AI Copilot":
                widgets_to_add.append(self.ai_copilot_page)
            elif label == "⚡ All Profiles":
                self._all_profiles_panel = self._build_all_profiles_panel()
                widgets_to_add.append(self._all_profiles_panel)
            elif label == "🚀 Breakout":
                widgets_to_add.append(self.breakout_page)
            elif label == "🔍 Pre-Breakout":
                widgets_to_add.append(self.prebreakout_page)
            elif label == "🔬 Technical":
                from ui.technical_panels import TechnicalAnalysisHub
                self.technical_hub = TechnicalAnalysisHub()
                widgets_to_add.append(self.technical_hub)

            else:
                placeholder = QWidget()
                lay_p = QVBoxLayout(placeholder)
                lay_p.setContentsMargins(20, 20, 20, 20)
                lbl = QLabel(f"🔄 Loading '{label}' panel ...")
                lbl.setAlignment(Qt.AlignCenter)
                lbl.setStyleSheet("font-size:14px; color:#8e8e93; font-weight:500;")
                lay_p.addWidget(lbl)
                widgets_to_add.append(placeholder)

        for w in widgets_to_add:
            self.tabs.addWidget(w)
        tl.addWidget(self._build_results_nav())
        tl.addWidget(self.tabs)
        self.tabs.currentChanged.connect(self._sync_results_nav)
        lay.addWidget(tabs_card, 1)
        return panel

    def _build_results_nav(self):
        wrap = QWidget()
        wrap.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        row = QHBoxLayout(wrap); row.setContentsMargins(8, 2, 8, 2); row.setSpacing(6)

        # Assign references
        self.results_prev_btn = None
        self.results_next_btn = None
        self.results_nav_scroll = None

        self.results_nav_buttons = []
        
        # Build first 10 core buttons
        for idx in range(10):
            if idx >= len(self.results_tab_labels):
                break
            label = self.results_tab_labels[idx]
            btn = QPushButton(label)
            btn.setCheckable(True)
            btn.setObjectName("TabNavButton")
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda checked=False, i=idx: self._set_results_tab(i))
            row.addWidget(btn)
            self.results_nav_buttons.append(btn)

        # Dropdown button for all remaining tabs (index >= 10)
        self.more_tabs_btn = QPushButton("More Dashboards ▾")
        self.more_tabs_btn.setObjectName("TabNavButton")
        self.more_tabs_btn.setCheckable(True)
        self.more_tabs_btn.setCursor(Qt.PointingHandCursor)

        menu = GlassMenu(self.more_tabs_btn)
        menu.setObjectName("GlassMenu")

        # Top-level items in the dropdown menu
        # AUDIT-FIX (Round 5, 2-a-10): the hard-coded list stopped at "🔬 Technical"
        # (index 22) while results_tab_labels has 27 entries — "Alert Log",
        # "MRC", "Factor Attr." and "Watchlist" (indices 23–26) were reachable
        # through neither the nav buttons (0–9) nor this menu. Derive the menu
        # from the label list so every tab is reachable by construction.
        core_labels = list(self.results_tab_labels[10:])
        core_indices = []
        for lbl in core_labels:
            if lbl in self.results_tab_labels:
                core_indices.append((lbl, self.results_tab_labels.index(lbl)))
        for lbl, idx in core_indices:
            act = menu.addAction(lbl)
            act.triggered.connect(lambda checked=False, i=idx: self._set_results_tab(i))

        self.more_tabs_btn.setMenu(menu)
        row.addWidget(self.more_tabs_btn)
        row.addStretch(1)

        wrap.setFixedHeight(42)
        self._sync_results_nav(self.tabs.currentIndex())
        return wrap

    def _sync_universe_source_ui(self):
        manual_mode = bool(getattr(self, "manual_universe_check", None) and self.manual_universe_check.isChecked())
        if hasattr(self, "manual_symbols"):
            self.manual_symbols.setReadOnly(False)
            self.manual_symbols.setPlaceholderText(
                "One ticker per line. Example:\nRELIANCE\nTCS\nINFY.NS"
            )
        if hasattr(self, "manual_universe_hint"):
            self.manual_universe_hint.setText(
                "Manual universe is active. All valid manual symbols are used after prescreen."
                if manual_mode else
                "Full exchange universe is active. Enable manual symbols to use your own ticker list."
            )
        if hasattr(self, "topn_spin"):
            self.topn_spin.setEnabled(not manual_mode)
            self.topn_spin.setToolTip(
                "Ignored in manual-universe mode."
                if manual_mode else
                ""
            )

    def _on_manual_symbols_changed(self):
        """Update universe mode display when the user edits the manual symbols box.
        The handler is intentionally lightweight — heavy processing (prescreen, download)
        only happens on Run. This just refreshes the mode label and universe badge.
        """
        # Re-evaluate whether the manual universe is active based on current text
        # AUDIT-FIX (Round 5, 2-a-8): the handler read non-existent attribute names
        # (manual_symbols_edit / use_manual_check); the real widgets are
        # manual_symbols and manual_universe_check. Both getattr calls returned
        # None, making this textChanged handler a permanent no-op.
        text = getattr(self, "manual_symbols", None)
        has_symbols = bool(text and text.toPlainText().strip()) if text is not None else False
        manual_mode = getattr(self, "manual_universe_check", None)
        if manual_mode is not None:
            is_manual = manual_mode.isChecked() and has_symbols
            if hasattr(self, "_update_manual_mode_ui"):
                self._update_manual_mode_ui(is_manual)
        # Refresh universe badge if present in the active tab
        page = getattr(self, "tabs", None)
        if page is not None:
            widget = page.currentWidget()
            if widget is not None and hasattr(widget, "_update_universe_badge"):
                try:
                    widget._update_universe_badge()
                except Exception:
                    pass


    def _set_results_tab(self, index):
        self.tabs.setCurrentIndex(max(0, min(index, self.tabs.count() - 1)))
        # v17.2: resize all table columns on the newly visible tab
        QTimer.singleShot(60, self._resize_all_visible_tables)

    def _resize_all_visible_tables(self):
        """v17.2 — Resize all visible table columns; cap at 220px; uniform rows."""
        page = self.tabs.currentWidget()
        if page is None:
            return
        for tbl in page.findChildren(QTableWidget):
            if tbl.isVisible() and tbl.columnCount() > 0:
                hh = tbl.horizontalHeader()
                hh.setSectionResizeMode(QHeaderView.ResizeToContents)
                tbl.resizeColumnsToContents()
                # Cap every column at 220px so no single column dominates
                for c in range(tbl.columnCount()):
                    if hh.sectionSize(c) > 220:
                        hh.resizeSection(c, 220)
                hh.setSectionResizeMode(QHeaderView.Interactive)

    def _step_results_nav(self, direction):
        self._set_results_tab(self.tabs.currentIndex() + direction)

    def _sync_results_nav(self, index):
        for idx, btn in enumerate(getattr(self, "results_nav_buttons", [])):
            btn.setChecked(idx == index)
        if hasattr(self, "results_prev_btn") and self.results_prev_btn is not None:
            self.results_prev_btn.setEnabled(index > 0)
        if hasattr(self, "results_next_btn") and self.results_next_btn is not None:
            self.results_next_btn.setEnabled(index < self.tabs.count() - 1)
        if hasattr(self, "more_tabs_btn") and self.more_tabs_btn is not None:
            if index >= 10:
                self.more_tabs_btn.setChecked(True)
                active_label = self.results_tab_labels[index]
                self.more_tabs_btn.setText(f"More: {active_label} ▾")
            else:
                self.more_tabs_btn.setChecked(False)
                self.more_tabs_btn.setText("More Dashboards ▾")
        if 0 <= index < len(getattr(self, "results_nav_buttons", [])):
            btn = self.results_nav_buttons[index]
            if self.results_nav_scroll and self.results_nav_scroll is not None and self.results_nav_scroll.horizontalScrollBar():
                bar = self.results_nav_scroll.horizontalScrollBar()
                target = max(0, btn.x() - 40)
                bar.setValue(target)

    def _build_portfolio_tab(self):
        widget = QWidget()
        outer = QHBoxLayout(widget); outer.setContentsMargins(0, 0, 0, 0); outer.setSpacing(0)
        self.portfolio_table.itemSelectionChanged.connect(self._update_portfolio_drilldown)
        spl = QSplitter(Qt.Horizontal); spl.setChildrenCollapsible(False)
        spl.addWidget(self.portfolio_page)

        side = CardFrame("SectionCard")
        side.setMinimumWidth(280)
        side.setMaximumWidth(360)
        sl = QVBoxLayout(side); sl.setContentsMargins(14, 14, 14, 14); sl.setSpacing(10)
        title = QLabel("Holding Drill-Down"); title.setObjectName("SectionTitle")
        self.detail_title = QLabel("Select a holding"); self.detail_title.setObjectName("StatusTitle")
        self.detail_reason = QLabel("Portfolio rationale and sector-relative context will appear here."); self.detail_reason.setWordWrap(True); self.detail_reason.setObjectName("MutedText")
        self.detail_stats = QPlainTextEdit(); self.detail_stats.setReadOnly(True); self.detail_stats.setMinimumHeight(260)
        sl.addWidget(title); sl.addWidget(self.detail_title); sl.addWidget(self.detail_reason); sl.addWidget(self.detail_stats, 1)

        spl.addWidget(side)
        spl.setStretchFactor(0, 1); spl.setStretchFactor(1, 0); spl.setSizes([980, 320])
        outer.addWidget(spl)
        return widget

    def _build_charts_tab(self):
        """TradingView embedded chart panel."""
        # ── Lazy WebEngine import — MUST match QT_API to avoid dual-Qt crash ─  # GLB001: consider replacing global with AppState
        # PyQt5 is blocked at module top (sys.modules[PyQt5]=None) so PySide6
        # WebEngine loads cleanly without SIGABRT.
        global HAS_WEBENGINE, QWebEngineView
        if not HAS_WEBENGINE:
            # Only load the WebEngine module that matches the active Qt binding.
            # Cross-importing (e.g. PyQt6.WebEngine while running PySide6) causes
            # a fatal crash due to conflicting Qt runtime libraries.
            _WE_MAP = {
                "PyQt5":   "PyQt5.QtWebEngineWidgets",
                "PyQt6":   "PyQt6.QtWebEngineWidgets",
                "PySide2": "PySide2.QtWebEngineWidgets",
                "PySide6": "PySide6.QtWebEngineWidgets",
            }
            _we_mod = _WE_MAP.get(QT_API)
            if _we_mod is None:
                pass  # _arch_log removed (LOG003)
            else:
                try:
                    import importlib as _il
                    _m = _il.import_module(_we_mod)
                    QWebEngineView = _m.QWebEngineView
                    HAS_WEBENGINE = True
                    pass  # _arch_log removed (LOG003)
                except Exception as _e:
                    pass  # _arch_log removed (LOG003)

        widget = QWidget()
        outer  = QVBoxLayout(widget); outer.setContentsMargins(0, 0, 0, 0); outer.setSpacing(0)
        spl    = QSplitter(Qt.Horizontal); spl.setChildrenCollapsible(False)

        # ── Left: ticker list ─────────────────────────────────────────────────
        left = QWidget(); left.setObjectName("ChartsSidebar")
        left.setMinimumWidth(110)
        left.setMaximumWidth(280)
        ll   = QVBoxLayout(left); ll.setContentsMargins(4, 4, 4, 4); ll.setSpacing(0)
        self.charts_list = QListWidget(); self.charts_list.setObjectName("ChartsList")
        self.charts_list.itemClicked.connect(self._on_chart_stock_clicked)
        ll.addWidget(self.charts_list, 1)

        # ── Right: embedded WebEngine or fallback card ────────────────────────
        right = QWidget(); rl = QVBoxLayout(right); rl.setContentsMargins(0, 0, 0, 0); rl.setSpacing(0)

        self._tv_current = None   # currently shown ticker

        try:
            from ui.components.interactive_chart import InteractivePortfolioChart
            self.interactive_canvas = InteractivePortfolioChart()
        except ImportError:
            self.interactive_canvas = None

        if HAS_WEBENGINE:
            self.tv_view = QWebEngineView()
            self.tv_view.setUrl(QUrl("about:blank"))
            self.tv_view.loadFinished.connect(self._disable_unload_handler)
            rl.addWidget(self.tv_view)
        else:
            self.tv_view = None
            if self.interactive_canvas is not None:
                rl.addWidget(self.interactive_canvas)
            else:
                card = QWidget(); cl = QVBoxLayout(card)
                cl.setAlignment(Qt.AlignCenter); cl.setSpacing(16)
                cl.setContentsMargins(32, 32, 32, 32)

                self.tv_ticker_lbl = QLabel("")
                self.tv_ticker_lbl.setAlignment(Qt.AlignCenter)
                self.tv_ticker_lbl.setStyleSheet(
                    "font-size:28px; font-weight:700; color:#e0dedd; letter-spacing:2px;")

                self.tv_placeholder = QLabel("← Select a ticker from the list")
                self.tv_placeholder.setAlignment(Qt.AlignCenter)
                self.tv_placeholder.setObjectName("MutedText")
                self.tv_placeholder.setWordWrap(True)

                self.tv_open_btn = QPushButton("  📈  Open in TradingView  ")
                self.tv_open_btn.setFixedHeight(42)
                self.tv_open_btn.setVisible(False)
                self.tv_open_btn.setStyleSheet(
                    "QPushButton{background:#1a6b4a;color:#fff;border-radius:6px;"
                    "font-size:14px;font-weight:600;padding:0 24px;}"
                    "QPushButton:hover{background:#1f8a5e;}"
                    "QPushButton:pressed{background:#155c3e;}")
                self.tv_open_btn.clicked.connect(self._open_tv_browser)

                self.tv_exchange_lbl = QLabel("")
                self.tv_exchange_lbl.setAlignment(Qt.AlignCenter)
                self.tv_exchange_lbl.setObjectName("MutedText")

                cl.addStretch(1)
                cl.addWidget(self.tv_ticker_lbl)
                cl.addWidget(self.tv_exchange_lbl)
                cl.addSpacing(8)
                cl.addWidget(self.tv_placeholder)
                cl.addWidget(self.tv_open_btn)
                cl.addStretch(1)
                rl.addWidget(card)

        spl.addWidget(left); spl.addWidget(right)
        spl.setStretchFactor(0, 0); spl.setStretchFactor(1, 1)
        spl.setSizes([140, 900])
        outer.addWidget(spl)
        return widget


    def _make_table(self):
        """Single factory for every QTableWidget in the app — consistent defaults."""
        t = QTableWidget()
        t.setEditTriggers(QAbstractItemView.NoEditTriggers)
        t.setSelectionBehavior(QAbstractItemView.SelectRows)
        t.setSelectionMode(QAbstractItemView.SingleSelection)
        t.setAlternatingRowColors(True)
        t.setShowGrid(False)
        t.setSortingEnabled(True)
        t.setWordWrap(False)
        t.setTextElideMode(Qt.ElideRight)
        t.setFrameShape(QFrame.NoFrame)
        t.setCornerButtonEnabled(False)
        t.setContentsMargins(0, 0, 0, 0)
        t.setViewportMargins(0, 0, 0, 0)
        t.setStyleSheet("margin:0;")
        # Vertical header
        vh = t.verticalHeader()
        vh.setVisible(False)
        vh.setDefaultSectionSize(32)
        vh.setMinimumSectionSize(32)
        # Horizontal header
        hh = t.horizontalHeader()
        hh.setVisible(False)
        hh.setSectionResizeMode(QHeaderView.Interactive)
        hh.setStretchLastSection(False)
        hh.setMinimumSectionSize(60)
        hh.setDefaultAlignment(Qt.AlignLeft | Qt.AlignVCenter)  # per-col overrides applied in populate_table
        hh.setHighlightSections(False)
        hh.setFixedHeight(36)
        return t

    def _make_table_page(self, empty_text):
        """v17.2 — QStackedWidget: idx0=placeholder, idx1=table. Zero wasted space."""
        page  = QWidget()
        lay   = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0); lay.setSpacing(0)
        stack = QStackedWidget()
        placeholder = QLabel(empty_text, alignment=Qt.AlignCenter)
        placeholder.setObjectName('EmptyStateLabel')
        stack.addWidget(placeholder)   # index 0
        table = self._make_table()
        stack.addWidget(table)         # index 1
        stack.setCurrentIndex(0)
        lay.addWidget(stack, 1)
        table._stack       = stack
        table._placeholder = placeholder
        return page, table, placeholder

    def _set_table_header_visible(self, table, visible):
        if table is None:
            return
        hh = table.horizontalHeader()
        hh.setVisible(visible)
        hh.setFixedHeight(36 if visible else 0)
        hh.setMinimumHeight(32 if visible else 0)
        hh.setMaximumHeight(16777215 if visible else 0)

    def _load_defaults(self):
        self.lookback_combo.setCurrentText(DEFAULT_CFG["LOOKBACK_DOWNLOAD"]); self.prescreen_combo.setCurrentText(DEFAULT_CFG["PRESCREEN_LOOKBACK"])
        self.benchmark_combo.setCurrentText(DEFAULT_CFG["BENCHMARK_SYMBOL"])
        self.batch_spin.setValue(DEFAULT_CFG["BATCH_SIZE"]); self.min_data_spin.setValue(DEFAULT_CFG["MIN_DATA_PCT"])
        self.min_vol_spin.setValue(float(DEFAULT_CFG["MIN_AVG_DOLLAR_VOL"])); self.min_price_spin.setValue(DEFAULT_CFG["MIN_PRICE"])
        self.topn_spin.setValue(DEFAULT_CFG["TOP_N_UNIVERSE"]); self.k_spin.setValue(DEFAULT_CFG["K_STOCKS"])
        self.gamma_spin.setValue(DEFAULT_CFG["GAMMA"]); self.theta_spin.setValue(DEFAULT_CFG["THETA"]); self.alpha_spin.setValue(DEFAULT_CFG["ALPHA"])
        self.reads_spin.setValue(DEFAULT_CFG["NUM_READS"]); self.sweeps_spin.setValue(DEFAULT_CFG["NUM_SWEEPS"])
        self.restarts_spin.setValue(DEFAULT_CFG["MULTI_STARTS"])
        self.download_workers_spin.setValue(DEFAULT_CFG["DOWNLOAD_WORKERS"])
        self.sector_penalty_spin.setValue(DEFAULT_CFG["SECTOR_PENALTY"]); self.unknown_sector_spin.setValue(DEFAULT_CFG["UNKNOWN_SECTOR_PENALTY"])
        self.vol_penalty_spin.setValue(DEFAULT_CFG["VOL_PENALTY"]); self.beta_penalty_spin.setValue(DEFAULT_CFG["BETA_PENALTY"]); self.turnover_penalty_spin.setValue(DEFAULT_CFG["TURNOVER_PENALTY"]); self.corr_shrink_spin.setValue(DEFAULT_CFG["CORR_SHRINKAGE"])
        self.optimizer_mode_combo.setCurrentText(DEFAULT_CFG["OPTIMIZER_MODE"]); self.regime_filter_combo.setCurrentText(DEFAULT_CFG["REGIME_FILTER"])
        self.min_weight_spin.setValue(DEFAULT_CFG["MIN_WEIGHT"]); self.max_weight_spin.setValue(DEFAULT_CFG["MAX_WEIGHT"])
        self.max_sector_spin.setValue(DEFAULT_CFG["MAX_PER_SECTOR"]); self.manual_universe_check.setChecked(DEFAULT_CFG["USE_MANUAL_UNIVERSE"])
        self.run_backtest_check.setChecked(DEFAULT_CFG["RUN_BACKTEST"]); self.backtest_rebalance_spin.setValue(DEFAULT_CFG["BACKTEST_REBALANCE_DAYS"])
        self.backtest_fee_spin.setValue(DEFAULT_CFG["BACKTEST_FEE_BPS"]); self.backtest_slip_spin.setValue(DEFAULT_CFG["BACKTEST_SLIPPAGE_BPS"])
        self.risk_model_combo.setCurrentText(DEFAULT_CFG["RISK_MODEL"])
        risk_horiz = DEFAULT_CFG.get("RISK_HORIZON", "Strategic (252d)")
        if "Tactical" in risk_horiz:
            self.risk_horizon_combo.setCurrentText("Tactical (30d)")
        else:
            self.risk_horizon_combo.setCurrentText("Strategic (252d)")
        self.auto_run_check.setChecked(DEFAULT_CFG["AUTO_RUN_ENABLED"]); self.auto_run_interval_spin.setValue(DEFAULT_CFG["AUTO_RUN_INTERVAL_MIN"])
        self.auto_export_memo_check.setChecked(DEFAULT_CFG["AUTO_EXPORT_MEMO"])
        self.use_ic_weights_check.setChecked(DEFAULT_CFG["USE_IC_WEIGHTS"])
        
        # Sliced execution settings
        self.exec_strategy_combo.setCurrentText(DEFAULT_CFG.get("EXECUTION_STRATEGY", "Market"))
        self.exec_duration_spin.setValue(float(DEFAULT_CFG.get("EXECUTION_DURATION_MINS", 15.0)))
        self.exec_slices_spin.setValue(int(DEFAULT_CFG.get("EXECUTION_SLICES", 5)))
        self.use_mock_ws_check.setChecked(bool(DEFAULT_CFG.get("USE_MOCK_WEBSOCKET", True)))

    def _set_cfg_field(self, key, value):
        if key == "FACTOR_MODEL":
            self._active_factor_model = str(value)
            return
        if key == "RISK_HORIZON":
            val_str = str(value)
            if "Tactical" in val_str:
                self.risk_horizon_combo.setCurrentText("Tactical (30d)")
            else:
                self.risk_horizon_combo.setCurrentText("Strategic (252d)")
            return
        mapping = {
            "LOOKBACK_DOWNLOAD": self.lookback_combo, "PRESCREEN_LOOKBACK": self.prescreen_combo, "BENCHMARK_SYMBOL": self.benchmark_combo, "TOP_N_UNIVERSE": self.topn_spin,
            "K_STOCKS": self.k_spin, "MIN_DATA_PCT": self.min_data_spin, "MIN_AVG_DOLLAR_VOL": self.min_vol_spin, "MIN_PRICE": self.min_price_spin,
            "BATCH_SIZE": self.batch_spin, "GAMMA": self.gamma_spin, "THETA": self.theta_spin, "ALPHA": self.alpha_spin,
            "NUM_READS": self.reads_spin, "NUM_SWEEPS": self.sweeps_spin, "MULTI_STARTS": self.restarts_spin, "DOWNLOAD_WORKERS": self.download_workers_spin,
            "SECTOR_PENALTY": self.sector_penalty_spin, "UNKNOWN_SECTOR_PENALTY": self.unknown_sector_spin,
            "VOL_PENALTY": self.vol_penalty_spin, "BETA_PENALTY": self.beta_penalty_spin, "TURNOVER_PENALTY": self.turnover_penalty_spin,
            "CORR_SHRINKAGE": self.corr_shrink_spin, "MAX_PER_SECTOR": self.max_sector_spin, "USE_MANUAL_UNIVERSE": self.manual_universe_check,
            "USE_IC_WEIGHTS": self.use_ic_weights_check,
            "RUN_BACKTEST": self.run_backtest_check, "BACKTEST_REBALANCE_DAYS": self.backtest_rebalance_spin,
            "BACKTEST_FEE_BPS": self.backtest_fee_spin, "BACKTEST_SLIPPAGE_BPS": self.backtest_slip_spin, "RISK_MODEL": self.risk_model_combo,
            "OPTIMIZER_MODE": self.optimizer_mode_combo, "REGIME_FILTER": self.regime_filter_combo, "MIN_WEIGHT": self.min_weight_spin, "MAX_WEIGHT": self.max_weight_spin,
            "AUTO_RUN_ENABLED": self.auto_run_check, "AUTO_RUN_INTERVAL_MIN": self.auto_run_interval_spin, "AUTO_EXPORT_MEMO":   self.auto_export_memo_check,
            "TELEGRAM_ENABLED":   self.telegram_enabled_check,
            "TELEGRAM_BOT_TOKEN": self.telegram_token_edit,
            "TELEGRAM_CHAT_ID":   self.telegram_chatid_edit,
            "KITE_API_KEY":       self.kite_key_edit,
            "KITE_ACCESS_TOKEN":  self.kite_token_edit,
            "KITE_LIVE_ORDERS":   self.kite_live_check,
            "EXECUTION_STRATEGY":      self.exec_strategy_combo,
            "EXECUTION_DURATION_MINS": self.exec_duration_spin,
            "EXECUTION_SLICES":        self.exec_slices_spin,
            "USE_MOCK_WEBSOCKET":      self.use_mock_ws_check,
        }
        w = mapping.get(key)
        if isinstance(w, QComboBox): w.setCurrentIndex(max(0, w.findText(str(value))))
        elif isinstance(w, (QSpinBox, QDoubleSpinBox)): w.setValue(value)
        elif isinstance(w, QCheckBox): w.setChecked(bool(value))
        elif isinstance(w, QLineEdit): w.setText(str(value))
        # AUDIT-FIX (Round 5, 2-a-3): live-order flags (KITE_LIVE_ORDERS / …) can
        # be restored from saved preferences through this path — refresh the
        # mode badge so the LIVE/PAPER indicator reflects the restored state.
        if key in ("KITE_LIVE_ORDERS", "ANGELONE_LIVE_ORDERS", "DHAN_LIVE_ORDERS"):
            self._refresh_trading_mode_badge()

    def _apply_profile(self):
        p_name = self.profile_combo.currentText()
        self._active_profile_cfg = dict(PROFILE_MAP.get(p_name, {}))
        for k, v in self._active_profile_cfg.items():
            self._set_cfg_field(k, v)
        self.append_log(f"Applied profile: {p_name}")

    def _on_profile_combo_changed(self, text: str):
        """Called whenever the profile combo selection changes.
        Run button label always stays '▶  Run'. Only applies profile cfg for real profiles.
        """
        if text != "⚡ Run All Profiles":
            self._apply_profile()
            payloads = getattr(self, "_profile_payloads", {})
            if text in payloads:
                self.last_payload = payloads[text]
                self._set_export_buttons_enabled(True)

    def _on_run_btn_clicked(self):
        """Route ▶ Run to the correct handler based on the profile dropdown selection.

        When '⚡ Run All Profiles' is selected:
          - If the 'Auto-run live full-NSE neural screen' checkbox is checked,
            run Stage 1 (live verification) first, then auto-launch the sweep.
          - If unchecked, skip the 60-minute live verification and go straight
            to the portfolio sweep. Users can still run the neural screen
            explicitly via the dedicated '🧪 Run Neural Screen' button.
        """
        if self.profile_combo.currentText() == "⚡ Run All Profiles":
            if getattr(self, "live_verify_screen_check", None) and self.live_verify_screen_check.isChecked():
                self.append_log("[All Profiles] Run clicked. Step 1/2: Running Live Verification first...")
                self._auto_run_sweep_after_verify = True
                self._verify_bridged = False
                self._run_live_verification()
            else:
                # Skip live verification — go directly to parallel sweep
                self.append_log("[All Profiles] Run clicked. Skipping live screen (checkbox unchecked). Starting sweep...")
                self._run_all_profiles()
        else:
            self._smart_run()

    def collect_cfg(self):
        # 1. Start with a copy of DEFAULT_CFG
        cfg = dict(DEFAULT_CFG)
        
        # 2. Merge active profile overrides
        active_profile = getattr(self, "_active_profile_cfg", None)
        if active_profile is None:
            p_name = self.profile_combo.currentText()
            active_profile = dict(PROFILE_MAP.get(p_name, {}))
            self._active_profile_cfg = active_profile
            
        if active_profile:
            cfg.update(active_profile)
            
        # 3. Merge values collected from UI widgets (manual edits override defaults/profiles)
        # AUDIT-FIX (Round 5, 2-a-6): the combo was renamed Dhan → "Angel One
        # SmartAPI v2 (Official)" but this mapping still tested only "Dhan",
        # so selecting the Angel One provider persisted DATA_PROVIDER="YFinance"
        # into cfg/snapshots/exports while the live feed used Angel One.
        _dp_text = getattr(self, "data_provider_combo", QComboBox()).currentText()
        ui_cfg = {
            "DATA_PROVIDER": (
                "LocalDB" if "Local" in _dp_text
                else ("AngelOne" if ("Angel" in _dp_text or "Dhan" in _dp_text) else "YFinance")
            ),
            "FACTOR_MODEL": getattr(self, "_active_factor_model", "Trend Momentum (Default)"),
            "LOOKBACK_DOWNLOAD": self.lookback_combo.currentText(),
            "PRESCREEN_LOOKBACK": self.prescreen_combo.currentText(),
            "BENCHMARK_SYMBOL": self.benchmark_combo.currentText(),
            "BATCH_SIZE": int(self.batch_spin.value()),
            "MIN_DATA_PCT": float(self.min_data_spin.value()),
            "MIN_AVG_DOLLAR_VOL": float(self.min_vol_spin.value()),
            "MIN_PRICE": float(self.min_price_spin.value()),
            "TOP_N_UNIVERSE": int(self.topn_spin.value()),
            "K_STOCKS": int(self.k_spin.value()),
            "_USER_K_STOCKS": int(self.k_spin.value()),
            "GAMMA": float(self.gamma_spin.value()),
            "THETA": float(self.theta_spin.value()),
            "ALPHA": float(self.alpha_spin.value()),
            "NUM_READS": int(self.reads_spin.value()),
            "NUM_SWEEPS": int(self.sweeps_spin.value()),
            "SEED": 42,
            "MULTI_STARTS": int(self.restarts_spin.value()),
            "DOWNLOAD_WORKERS": int(self.download_workers_spin.value()),
            "SECTOR_PENALTY": float(self.sector_penalty_spin.value()),
            "UNKNOWN_SECTOR_PENALTY": float(self.unknown_sector_spin.value()),
            "VOL_PENALTY": float(self.vol_penalty_spin.value()),
            "BETA_PENALTY": float(self.beta_penalty_spin.value()),
            "TURNOVER_PENALTY": float(self.turnover_penalty_spin.value()),
            "CORR_SHRINKAGE": float(self.corr_shrink_spin.value()),
            "MAX_PER_SECTOR": int(self.max_sector_spin.value()),
            "OPTIMIZER_MODE": self.optimizer_mode_combo.currentText(),
            "REGIME_FILTER": self.regime_filter_combo.currentText(),
            "MIN_WEIGHT": float(self.min_weight_spin.value()),
            "MAX_WEIGHT": float(self.max_weight_spin.value()),
            "USE_MANUAL_UNIVERSE": self.manual_universe_check.isChecked(),
            "AUTO_LIVE_VERIFY_SCREEN": self.live_verify_screen_check.isChecked(),
            "USE_IC_WEIGHTS": self.use_ic_weights_check.isChecked(),
            "RUN_BACKTEST": self.run_backtest_check.isChecked(),
            "BACKTEST_REBALANCE_DAYS": int(self.backtest_rebalance_spin.value()),
            "BACKTEST_FEE_BPS": float(self.backtest_fee_spin.value()),
            "BACKTEST_SLIPPAGE_BPS": float(self.backtest_slip_spin.value()),
            "RISK_MODEL": self.risk_model_combo.currentText(),
            "AUTO_RUN_ENABLED": self.auto_run_check.isChecked(),
            "AUTO_RUN_INTERVAL_MIN": int(self.auto_run_interval_spin.value()),
            "AUTO_EXPORT_MEMO": self.auto_export_memo_check.isChecked(),
            "TELEGRAM_ENABLED": self.telegram_enabled_check.isChecked(),
            "TELEGRAM_BOT_TOKEN": self.telegram_token_edit.text(),
            "TELEGRAM_CHAT_ID": self.telegram_chatid_edit.text(),
            "KITE_API_KEY": self.kite_key_edit.text(),
            "KITE_ACCESS_TOKEN": self.kite_token_edit.text(),
            "KITE_LIVE_ORDERS": self.kite_live_check.isChecked(),
            "EXECUTION_STRATEGY": self.exec_strategy_combo.currentText(),
            "EXECUTION_DURATION_MINS": float(self.exec_duration_spin.value()),
            "EXECUTION_SLICES": int(self.exec_slices_spin.value()),
            "USE_MOCK_WEBSOCKET": self.use_mock_ws_check.isChecked(),
            "RISK_HORIZON": self.risk_horizon_combo.currentText(),
        }
        cfg.update(ui_cfg)
        
        # 4. Merge credentials loaded from storage to ensure consistency
        cfg.update(load_credentials())
        
        return cfg

    def _save_preferences(self):
        try:
            cfg_for_prefs = dict(self.collect_cfg())
            for secret_key in (
                "TELEGRAM_BOT_TOKEN", "KITE_API_KEY", "KITE_ACCESS_TOKEN",
                "GEMINI_API_KEY", "OPENAI_API_KEY"
            ):
                cfg_for_prefs.pop(secret_key, None)
            PREFERENCES_PATH.write_text(
                json.dumps(
                    {
                        "cfg": cfg_for_prefs,
                        "profile": self.profile_combo.currentText(),
                        "data_provider": self.data_provider_combo.currentText(),
                        "manual": self.manual_symbols.toPlainText(),
                        "prev_holdings": self.prev_holdings.toPlainText(),
                    },
                    indent=2, default=str
                ),
                encoding="utf-8"
            )
        except Exception as _e:
            self.append_log(f"[Warning] Could not save preferences: {_e}")


    def _restore_preferences(self):
        # Restore last-used config values into sidebar widgets
        try:
            if PREFERENCES_PATH.exists():
                p = json.loads(PREFERENCES_PATH.read_text(encoding="utf-8"))
                self._active_profile_cfg = dict(p.get("cfg", {}))
                profile_name = p.get("profile", "Trend Momentum (Default)")
                if profile_name in PROFILE_MAP:
                    self.profile_combo.blockSignals(True)
                    self.profile_combo.setCurrentText(profile_name)
                    self.profile_combo.blockSignals(False)
                dp_name = p.get("data_provider")
                if dp_name and hasattr(self, "data_provider_combo"):
                    self.data_provider_combo.setCurrentText(dp_name)
                for k, v in p.get("cfg", {}).items():
                    try:
                        self._set_cfg_field(k, v)
                    except Exception as _e:
                        self.append_log(f"[Warning] Could not restore pref {k}: {_e}")
                try:
                    self.manual_symbols.setPlainText(p.get("manual", ""))
                except Exception as _exc_p2a_:
                    ExceptionLogger.swallow(_exc_p2a_, context='L47953')
                try:
                    self.prev_holdings.setPlainText(p.get("prev_holdings", ""))
                except Exception as _exc_p2a_:
                    ExceptionLogger.swallow(_exc_p2a_, context='L47957')
                # v17.9: Force-apply DEFAULT_CFG keys that are version-bumped
                # (saved prefs may have stale values from older app versions)
                # NOTE: FACTOR_WEIGHTS intentionally excluded — profile-specific
                # weights must not be overwritten by saved prefs on startup.
                _forced = {
                    "BACKTEST_REBALANCE_DAYS": DEFAULT_CFG["BACKTEST_REBALANCE_DAYS"],
                    "OOS_WINDOW_DAYS":         DEFAULT_CFG["OOS_WINDOW_DAYS"],  # v17.16: 370d
                    "LOOKBACK_DOWNLOAD":       "2y",
                }
                for _k, _v in _forced.items():
                    try:
                        self._set_cfg_field(_k, _v)
                    except Exception as _exc_p2a_:
                        ExceptionLogger.swallow(_exc_p2a_, context='L47969')
        except Exception as _e:
            self.append_log(f"[Warning] Could not load preferences: {_e}")
        # Restore credentials (Telegram, Kite, etc.)
        try:
            for k, v in load_credentials().items():
                try:
                    self._set_cfg_field(k, v)
                except Exception as _exc_p2a_:
                    ExceptionLogger.swallow(_exc_p2a_, context='L47978')
        except Exception as _e:
            self.append_log(f"[Warning] Could not load credentials: {_e}")


    def _open_settings(self):
        """Open Settings / Providers dialog.
        A small chooser lets the user open either the credentials dialog or
        the data-provider switcher — both previously had separate buttons.
        """
        try:
            from PySide6.QtWidgets import QDialog, QVBoxLayout, QPushButton, QLabel
        except ImportError:
            from PyQt5.QtWidgets import QDialog, QVBoxLayout, QPushButton, QLabel

        chooser = QDialog(self)
        chooser.setWindowTitle("Settings")
        chooser.setMinimumWidth(280)
        cl = QVBoxLayout(chooser)
        cl.setSpacing(10)
        cl.setContentsMargins(20, 20, 20, 20)

        lbl = QLabel("Choose a settings area:"); lbl.setObjectName("SubtleSectionTitle")
        cl.addWidget(lbl)

        cred_btn = QPushButton("⚙  Credentials & Automation")
        cred_btn.setObjectName("PrimaryButton"); cred_btn.setMinimumHeight(36)
        cred_btn.setToolTip("Telegram · DhanHQ API · Automation — saved to disk")
        cl.addWidget(cred_btn)

        prov_btn = QPushButton("🔌  Data Providers")
        prov_btn.setObjectName("PrimaryButton"); prov_btn.setMinimumHeight(36)
        prov_btn.setToolTip("Switch data provider (YFinance / Bloomberg / Refinitiv) and database backend")
        cl.addWidget(prov_btn)

        def _open_creds():
            chooser.accept()
            dlg = SettingsDialog(self)
            if dlg.exec() == QDialog.Accepted:
                try:
                    for k, v in load_credentials().items():
                        self._set_cfg_field(k, v)
                    self._sync_autorun_state()
                except Exception as _e:
                    self.append_log(f"[Warning] {_e}")

        def _open_providers():
            chooser.accept()
            self._open_provider_switcher()

        cred_btn.clicked.connect(_open_creds)
        prov_btn.clicked.connect(_open_providers)
        chooser.exec()

    def _restore_history(self):
        try:
            if HISTORY_PATH.exists(): self.run_history = json.loads(HISTORY_PATH.read_text(encoding="utf-8"))
            else: self.run_history = []
        except Exception as _e:
            self.run_history = []

    def _restore_alert_history(self):
        try:
            if ALERTS_HISTORY_PATH.exists():
                self.alert_history = json.loads(ALERTS_HISTORY_PATH.read_text(encoding="utf-8"))
            else:
                self.alert_history = []
        except Exception as _e:
            self.alert_history = []

    def _save_history(self):
        try: HISTORY_PATH.write_text(json.dumps(self.run_history, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
        except Exception as _e:
            archlog.error('Exception detail', exc_info=True)  # LOG003 was traceback.print_exc()
            pass  # _arch_log removed (LOG003)

    def _save_alert_history(self):
        try:
            ALERTS_HISTORY_PATH.write_text(json.dumps(self.alert_history, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
        except Exception as _e:
            try:
                self.append_log(f"[Warning] {_e}")
            except Exception as _exc_p2a_:
                ExceptionLogger.swallow(_exc_p2a_, context='L48023')

    def _append_history_record(self, p):
        bt = p.get("backtest")
        health = p.get("portfolio_health", {})
        changes = p.get("selection_change_summary", {})
        rec = {
            "Timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "Selected": ", ".join(p.get("selected", [])),
            "Count": len(p.get("selected", [])),
            "Energy": p.get("energy"),
            "SectorSpread": p.get("sector_spread"),
            "Regime": p.get("regime_info", {}).get("Regime"),
            "TopWeight": health.get("TopWeight"),
            "ActiveBeta": health.get("ActiveBeta"),
            "Adds": changes.get("added"),
            "Removes": changes.get("removed"),
            "Solver": p.get("solver_source"),
            "BacktestReturn": bt.get("Annual Return") if bt else np.nan,
            "Sortino": bt.get("Sortino") if bt else np.nan,
            "WinRate": bt.get("Daily Win Rate") if bt else np.nan,
        }
        self.run_history.insert(0, rec); self.run_history = self.run_history[:250]

    def _populate_history_table(self):
        if not hasattr(self, "history_table") or self.history_table is None:
            return
        # v17.1: load from SQLite DB first; fall back to in-memory list
        rows = []
        try:
            rows = sqlite_load_history(limit=200)
        except Exception as _e:
            try:
                self.append_log(f"[Warning] {_e}")
            except Exception as _exc_p2a_:
                ExceptionLogger.swallow(_exc_p2a_, context='L48056')
        if not rows:
            rows = self.run_history
        if not rows:
            self.history_table.clear()
            self.history_table.setSortingEnabled(False)  # P6: prevent sort-during-insert crash
            self.history_table.setRowCount(0)
            self.history_table.setColumnCount(0)
            return
        df = pd.DataFrame(rows)
        self.populate_table(self.history_table, df)
        self._set_table_header_visible(self.history_table, True)

    def _populate_alert_history_table(self):
        if not hasattr(self, "alert_history_table") or self.alert_history_table is None:
            return
        if not self.alert_history:
            self.alert_history_table.setSortingEnabled(False)
            self.alert_history_table.clear(); self.alert_history_table.setRowCount(0); self.alert_history_table.setColumnCount(0); return
        self.populate_table(self.alert_history_table, pd.DataFrame(self.alert_history))

    def _set_export_buttons_enabled(self, enabled):
        # All exports consolidated into download_combo + download_btn.
        # Keep download combo and button always enabled to allow user to switch and trigger exports,
        # showing clean message boxes if the payload/run data is missing.
        if hasattr(self, "download_btn"):     self.download_btn.setEnabled(True)
        if hasattr(self, "download_combo"):   self.download_combo.setEnabled(True)
        if hasattr(self, "reconcile_btn"):    self.reconcile_btn.setEnabled(enabled)
        if hasattr(self, "place_direct_btn"): self.place_direct_btn.setEnabled(enabled)
        if hasattr(self, "live_pnl_btn"):     self.live_pnl_btn.setEnabled(enabled)

    def _save_last_run_snapshot(self):
        if not self.last_payload:
            return
        try:
            portfolio_df = self.last_payload.get("portfolio_df")
            weights = {}
            if isinstance(portfolio_df, pd.DataFrame) and not portfolio_df.empty:
                weights = {str(r["Ticker"]): float(r["Weight %"]) for _, r in portfolio_df.iterrows()}
            snapshot = {
                "timestamp": datetime.now().isoformat(timespec="seconds"),
                "selected": list(self.last_payload.get("selected", [])),
                "weights": weights,
                "solver_source": self.last_payload.get("solver_source"),
                "regime": self.last_payload.get("regime_info", {}).get("Regime"),
            }
            LAST_RUN_PATH.write_text(json.dumps(snapshot, indent=2, ensure_ascii=False), encoding="utf-8")
        except Exception as e:
            # Non-fatal: snapshot save failure is logged but doesn't interrupt the run
            pass  # _arch_log removed (LOG003)

    def _sync_autorun_state(self):
        """v17.1: Dual-mode auto-run — QTimer (minute-based) + APScheduler (market-close trigger)."""
        if not hasattr(self, "auto_run_check") or not _widget_alive(self.auto_run_check):
            return
        if not hasattr(self, "auto_run_interval_spin") or not _widget_alive(self.auto_run_interval_spin):
            return
        if not hasattr(self, "next_autorun_label") or not _widget_alive(self.next_autorun_label):
            return
        enabled = self.auto_run_check.isChecked()

        # ── QTimer path (interval-based, existing) ────────────────────────────
        if not hasattr(self, "autorun_timer"):
            pass
        else:
            if enabled:
                interval_ms = max(5, int(self.auto_run_interval_spin.value())) * 60 * 1000
                self.autorun_timer.start(interval_ms)
                next_run = datetime.now() + pd.Timedelta(minutes=int(self.auto_run_interval_spin.value()))
                self.next_autorun_label.setText(f"Next run: {next_run.strftime('%H:%M:%S')}")
            else:
                self.autorun_timer.stop()
                self.next_autorun_label.setText("Auto-run: OFF")

        # ── APScheduler path (market-close 15:30 IST Mon-Fri) ─────────────────
        if enabled:
            try:
                from apscheduler.schedulers.qt import QtScheduler
                from apscheduler.triggers.cron import CronTrigger
                if not hasattr(self, "_apscheduler") or self._apscheduler is None:
                    self._apscheduler = QtScheduler()
                    self._apscheduler.start()
                # Remove old job if exists
                try:
                    self._apscheduler.remove_job("market_close_run")
                except Exception as _e:
                    try:
                        self.append_log(f"[Warning] {_e}")
                    except Exception as _exc_p2a_:
                        ExceptionLogger.swallow(_exc_p2a_, context='L48137')
                self._apscheduler.add_job(
                    self._on_autorun_timeout,
                    CronTrigger(day_of_week="mon-fri", hour=15, minute=30,
                                timezone="Asia/Kolkata"),
                    id="market_close_run",
                    replace_existing=True,
                )
                self.append_log("[Scheduler] ✅ Market-close job set: Mon–Fri 15:30 IST")
            except ImportError as _e:
                pass   # apscheduler not installed — QTimer fallback still active
            except Exception as e:
                self.append_log(f"[Scheduler] Warning: {e}")
        else:
            if hasattr(self, "_apscheduler") and self._apscheduler:
                try:
                    self._apscheduler.remove_job("market_close_run")
                except Exception as _e:
                    try:
                        self.append_log(f"[Warning] {_e}")
                    except Exception as _exc_p2a_:
                        ExceptionLogger.swallow(_exc_p2a_, context='L48158')


    def _on_autorun_timeout(self):
        # Only fire on weekdays (Mon=0 … Fri=4) — NSE is closed on weekends
        if datetime.now().weekday() >= 5:
            return
        if self.worker and self.worker.isRunning():
            self.append_log("Scheduled auto-run skipped because a run is already in progress.")
            return
        self.append_log("Scheduled auto-run started.")
        self._on_run_clicked()

    def _append_alert_history(self, payload):
        alerts_df = payload.get("alerts_df")
        if alerts_df is None or alerts_df.empty:
            return
        stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        for _, row in alerts_df.iterrows():
            self.alert_history.insert(0, {
                "Timestamp": stamp,
                "Severity": row.get("Severity"),
                "Category": row.get("Category"),
                "Message": row.get("Message"),
                "Regime": payload.get("regime_info", {}).get("Regime"),
            })
        self.alert_history = self.alert_history[:500]

    def append_log(self, text):
        cursor = self.logs_box.textCursor()
        has_sel = cursor.hasSelection()
        self.logs_box.appendPlainText(f"[{datetime.now().strftime('%H:%M:%S')}] {text}")
        if has_sel:
            self.logs_box.setTextCursor(cursor)

    def _reset_result_state(self):
        self.last_payload = None
        self.progress_bar.setValue(0); self.status_title.setText("Ready"); self.status_title.setStyleSheet("")
        self.status_subtitle.setText("Configure inputs and press Run optimizer")
        self.universe_card.reset(); self.eligible_card.reset(); self.selected_card.reset(); self.energy_card.reset()
        self.matrix_label.setText("Matrix: --"); self.sector_label.setText("Sector spread: --"); self.resolve_label.setText("Resolved sectors: --")
        self.regime_label.setText("Regime: --"); self.benchmark_label.setText("Benchmark: --")
        self.solver_label.setText("Solver: --"); self.backtest_label.setText("OOS Backtest: --")
        for t in [
            self.portfolio_table, self.prescreen_table, self.sector_summary_table,
            self.factor_summary_table, self.exposures_table, self.sector_relative_table,
            self.changes_table, self.alerts_table, self.diagnostics_table,
            self.corr_table, self.risk_table, self.mrc_table, self.watchlist_table,
            self.live_pnl_table, self.breakout_table, self.prebreakout_table,
            self.factor_attr_table, self.backtest_table, self.execution_table
        ]:
            if t is None:
                continue
            t.setSortingEnabled(False)
            t.clear(); t.setRowCount(0); t.setColumnCount(0); self._set_table_header_visible(t, False)
            if t is not self.portfolio_table:
                t.hide()
        for placeholder in [
            self.prescreen_placeholder, self.sector_summary_placeholder,
            self.factor_summary_placeholder, self.exposures_placeholder, self.sector_relative_placeholder,
            self.changes_placeholder, self.alerts_placeholder, self.diagnostics_placeholder,
            self.corr_placeholder, self.risk_placeholder, self.mrc_placeholder, self.watchlist_placeholder,
            self.live_pnl_placeholder, self.breakout_placeholder, self.prebreakout_placeholder,
            self.factor_attr_placeholder, self.backtest_placeholder, self.execution_placeholder
        ]:
            if placeholder is None:
                continue
            placeholder.show()
        # Keep the charts list active and populated during background runs
        try:
            self.sync_charts_list()
        except Exception:
            pass
        self.detail_title.setText("Select a holding")
        self.detail_reason.setText("Portfolio rationale and sector-relative context will appear here.")
        self.detail_stats.clear()

    class LiveVerifyWorker(QThread):
        progress = pyqtSignal(str)
        failed   = pyqtSignal(str)
        finished = pyqtSignal()
        finished_with_results = pyqtSignal(dict)
        
        def __init__(self, parent=None):
            super().__init__(parent)
            import threading
            self.stop_event = threading.Event()
            
        def request_stop(self):
            self.stop_event.set()
            self.requestInterruption()
        
        def run(self):
            import io
            import sys
            
            class CustomStream(io.StringIO):
                def __init__(self, signal):
                    super().__init__()
                    self.signal = signal
                def write(self, s):
                    s_clean = s.strip()
                    if s_clean:
                        self.signal.emit(s_clean)
                    return len(s)
            
            import contextlib
            stream = CustomStream(self.progress)
            
            try:
                from utils import _ACTIVE_STOP_EVENT, _ACTIVE_STOP_EVENT_LOCK, StopRequested
                with _ACTIVE_STOP_EVENT_LOCK:
                    _ACTIVE_STOP_EVENT.set_event(self.stop_event)
                
                try:
                    import live_verify
                    with contextlib.redirect_stdout(stream):
                        regime_info = live_verify.test_live_hmm()
                        regime_label = regime_info.get("label") if regime_info else None
                        screener_results = live_verify.test_live_screener_full_nse(regime=regime_label)
                    
                    payload = {
                        "regime_info": regime_info,
                        "screener_results": screener_results
                    }
                    
                    # Update AppState atomically
                    from core.state_manager import AppState
                    import time
                    
                    if regime_info:
                        AppState.instance().set_regime(
                            label=regime_info["label"],
                            confidence=regime_info["confidence"],
                            probabilities=regime_info["probabilities"],
                            transition_matrix=regime_info.get("transition_matrix"),
                        )
                    if screener_results and "scores" in screener_results:
                        scores = screener_results.get("scores") or {}
                        n_scores = len(scores)
                        is_full = bool(screener_results.get("is_full_universe", False))
                        if is_full or n_scores >= 500:
                            AppState.instance().update_latent_scores(scores, timestamp=time.time())
                        else:
                            self.progress.emit(f"[LiveVerify] Skipped updating global latent cache "
                                               f"(scores={n_scores}, full_universe={is_full}).")
                except StopRequested:
                    self.failed.emit("Run cancelled by user.")
                    return
                finally:
                    with _ACTIVE_STOP_EVENT_LOCK:
                        _ACTIVE_STOP_EVENT.clear_event()
                    
                self.finished_with_results.emit(payload)
                self.finished.emit()
            except Exception as e:
                import traceback
                self.failed.emit(traceback.format_exc())


    def _run_live_verification(self):
        if hasattr(self, "_verify_worker") and self._verify_worker.isRunning():
            return
        self.live_verify_btn.setEnabled(False)
        self.live_verify_btn.setText("🧪  Verifying Live NSE...")
        self.stop_btn.setEnabled(True)
        self.append_log("[System] Launching Headless HMM & FAISS ViT live verification...")
        self.status_title.setText("Verifying")
        self.status_subtitle.setText("Running full NSE live HMM & screener test...")
        
        self._verify_worker = self.LiveVerifyWorker(parent=self)
        self._verify_worker.progress.connect(self.append_log)
        self._verify_worker.failed.connect(self._on_verify_failed)
        self._verify_worker.finished.connect(self._on_verify_finished)
        self._verify_worker.finished_with_results.connect(self._on_verify_finished_with_results)
        self._verify_worker.start()

    def _show_styled_message(self, title, text, icon=_QMESSAGEBOX_ICON.Information):
        show_styled_message_box(self, title, text, icon)

    def _on_verify_failed(self, err):
        # AUDIT-FIX (Round 5, 2-a-1): a failed/cancelled verification used to
        # leave _pipeline_running/_pipeline_after_ml/_pipeline_after_screen
        # latched True with run_btn disabled — every later Run said "Already
        # running" and no optimizer result ever arrived to clear the flags, so
        # the app was bricked until restart. Mirror _on_ml_fit_failed's full
        # pipeline-state reset here.
        self._auto_run_sweep_after_verify = False
        self._verify_bridged = False
        self._pipeline_running = False
        self._pipeline_after_ml = False
        self._pipeline_after_screen = False
        self._pipeline_running_optimizer = False
        if hasattr(self, "run_btn"):
            self.run_btn.setEnabled(True)
        self.live_verify_btn.setEnabled(True)
        # SF-fix8: live_verify_btn is aliased to pipeline_btn — restore to its correct label
        self.live_verify_btn.setText("🔁  Force Full Rebuild")
        self.stop_btn.setEnabled(False)
        if "cancelled by user" in err.lower() or "stopped by user" in err.lower():
            self.status_title.setText("Cancelled")
            self.status_subtitle.setText("Live verification was stopped by the user.")
            self.append_log("[System] Live verification cancelled by user.")
            return
        self.status_title.setText("Verify Failed")
        self.status_subtitle.setText("Headless test run encountered an error")
        self.append_log(f"[Verification Error] Run failed:\n{err}")
        self._show_styled_message("Verification Failed", f"Headless live verification failed:\n{err}", _QMESSAGEBOX_ICON.Critical)

    def _on_verify_finished(self):
        self.live_verify_btn.setEnabled(True)
        # SF-fix8: live_verify_btn is aliased to pipeline_btn — restore to its correct label
        self.live_verify_btn.setText("🔁  Force Full Rebuild")
        if getattr(self, "_pipeline_running", False):
            return  # Pipeline still running — don't show "Verified ✓"

        # If we bridged to sweep or optimizer, don't reset UI status here
        if getattr(self, "_verify_bridged", False):
            self._verify_bridged = False
            return

        # Only reset stop button and status if we are NOT auto-bridging to stage 2.
        # If the auto-pipeline is active, _auto_bridge_and_run has already scheduled
        # the optimizer start — resetting status here would show "Verified ✓" briefly
        # before the optimizer status takes over, which is confusing.
        if not getattr(self, "_auto_run_optimizer_after_verify", False):
            self.stop_btn.setEnabled(False)
            self.status_title.setText("Verified ✓")
            self.status_subtitle.setText("Headless live verification completed successfully!")
            self.append_log("[System] Headless live verification completed successfully.")

    def _on_verify_finished_with_results(self, payload):
        regime_info = payload.get("regime_info")
        screener_res = payload.get("screener_results") or {}
        
        # 1. Update dynamic regime badge immediately!
        if regime_info:
            self._on_regime_updated(regime_info)
            
        # 2. Populate GUI Breakout and Pre-Breakout tables instantly!
        bo = screener_res.get("breakout_df")
        if bo is not None:
            self.populate_table(self.breakout_table, bo)
            if not bo.empty:
                self.append_log(f"[System] Populated {len(bo)} live breakout setups into Breakout tab.")
            
        pb = screener_res.get("prebreakout_df")
        if pb is not None:
            self.populate_table(self.prebreakout_table, pb)
            if not pb.empty:
                self.append_log(f"[System] Populated {len(pb)} live pre-breakout setups into Pre-Breakout tab.")
            
        # 3. Route to the appropriate next stage
        if getattr(self, "_auto_run_sweep_after_verify", False):
            self._auto_run_sweep_after_verify = False
            self._verify_bridged = True
            self.append_log("[All Profiles] Step 2/2: Live verification completed. Launching parallel sweep...")
            QTimer.singleShot(100, self._run_all_profiles)
            return

        # Phase 2: If the full pipeline is active, bridge to ML Alpha (Stage 2)
        if getattr(self, "_pipeline_after_screen", False):
            self._pipeline_after_screen = False
            self._pipeline_bridge_to_ml_alpha(screener_res)
            return
        
        if getattr(self, "_auto_run_optimizer_after_verify", False):
            self._auto_bridge_and_run(screener_res)
        else:
            self._prompt_portfolio_bridge(screener_res)

    def _auto_bridge_and_run(self, screener_res):
        bo = screener_res.get("breakout_df")
        tickers_to_load = []
        if bo is not None and not bo.empty:
            tickers_to_load = bo["Ticker"].tolist()
        else:
            matches = screener_res.get("matches") or []
            sorted_matches = sorted(matches, key=lambda m: m[1], reverse=True)
            tickers_to_load = [m[0] for m in sorted_matches if m[1] > 0.70]
            
        is_manual_before = self.manual_universe_check.isChecked()
        
        if is_manual_before:
            # AUDIT-FIX (Round 6, D-P2-6): `_backup_manual_symbols` is only
            # populated on the _on_run_clicked path — when the run came via
            # _smart_run → verify → _auto_bridge_and_run (fresh-ML-model
            # flow), the backup was None, the merge started from "", and
            # setPlainText REPLACED the user's symbol list (silent input
            # loss; _restore_backup then no-oped). Fall back to the LIVE text.
            existing_text = self._backup_manual_symbols or self.manual_symbols.toPlainText()
            existing_lines = [s.strip() for s in existing_text.split("\n") if s.strip()]
            combined = list(existing_lines)
            for t in tickers_to_load:
                if t not in combined and t.replace(".NS", "") not in combined:
                    combined.append(t)
            tickers_to_load = combined
            
            if tickers_to_load:
                # Dynamically preserve the user's preferred portfolio size k, or adjust to fit universe size
                k_user = self.k_spin.value()
                symbols_str = "\n".join(tickers_to_load)
                self.manual_symbols.setPlainText(symbols_str)
                
                k_val = min(k_user, len(tickers_to_load))
                if k_val < 2:
                    k_val = max(2, len(tickers_to_load))
                    
                if k_val > self.k_spin.maximum():
                    self.k_spin.setMaximum(k_val)
                self.k_spin.setValue(k_val)
                
                self._set_results_tab(TAB_PORTFOLIO)
                self.append_log(f"[Auto-Bridge] Loaded {len(tickers_to_load)} setups from live scan. Portfolio size set dynamically to {k_val}. Starting Optimizer...")
        else:
            # Broad universe run: do not switch to manual mode or change K_STOCKS. Keep original configs.
            self._set_results_tab(TAB_PORTFOLIO)
            self.append_log(f"[Auto-Screener] Proceeding with broad universe run (Portfolio size = {self.k_spin.value()}, Universe size = {self.topn_spin.value()}). Starting Optimizer...")
            
        self._auto_run_optimizer_after_verify = False
        self._running_auto_pipeline_stage2 = True
        # Small QTimer singleShot to allow GUI thread to update before launching the optimizer thread
        from PySide6.QtCore import QTimer
        QTimer.singleShot(500, self._trigger_stage2_run)

    def _trigger_stage2_run(self):
        try:
            self._on_run_clicked()
        finally:
            self._running_auto_pipeline_stage2 = False

    def _prompt_portfolio_bridge(self, screener_res):
        bo = screener_res.get("breakout_df")
        tickers_to_load = []
        if bo is not None and not bo.empty:
            tickers_to_load = bo["Ticker"].tolist()
        else:
            matches = screener_res.get("matches") or []
            sorted_matches = sorted(matches, key=lambda m: m[1], reverse=True)
            tickers_to_load = [m[0] for m in sorted_matches if m[1] > 0.70]
            
        if tickers_to_load:
            from PySide6.QtWidgets import QMessageBox
            msg = QMessageBox(self)
            msg.setWindowTitle("Bridge Verification Results")
            msg.setIcon(QMessageBox.Question)
            msg.setText("<b>Live verification completed.</b>")
            msg.setInformativeText(
                f"Identified {len(tickers_to_load)} breakout/selected ticker(s) from the live scan.\n\n"
                "Would you like to import these tickers into your Manual Symbols list?"
            )
            
            append_btn = msg.addButton("Append to list", QMessageBox.ActionRole)
            replace_btn = msg.addButton("Replace list", QMessageBox.ActionRole)
            cancel_btn = msg.addButton("Cancel / Keep existing", QMessageBox.RejectRole)
            msg.setDefaultButton(cancel_btn)
            
            dark = is_app_dark_mode()
            msg.setStyleSheet(get_styled_msgbox_qss(dark))
            
            self.blockSignals(True)
            try:
                msg.exec()
            finally:
                self.blockSignals(False)
                
            clicked = msg.clickedButton()
            if clicked == cancel_btn:
                self.append_log("[Bridge] Bridging skipped by user. Existing manual symbols preserved.")
                return
                
            if clicked == append_btn:
                existing_text = self.manual_symbols.toPlainText().strip()
                existing_lines = [s.strip() for s in existing_text.split("\n") if s.strip()]
                
                appended_count = 0
                for t in tickers_to_load:
                    if t not in existing_lines and t.replace(".NS", "") not in existing_lines:
                        existing_lines.append(t)
                        appended_count += 1
                        
                symbols_str = "\n".join(existing_lines)
                self.manual_symbols.setPlainText(symbols_str)
                self.manual_universe_check.setChecked(True)
                self.append_log(f"[Bridge] Appended {appended_count} new breakout ticker(s) to manual symbols list.")
                self.status_subtitle.setText(f"✓ Appended {appended_count} tickers. Press 'Run optimizer' to build portfolio.")
                return
                
            if clicked == replace_btn:
                k_user = self.k_spin.value()
                symbols_str = "\n".join(tickers_to_load)
                self.manual_symbols.setPlainText(symbols_str)
                self.manual_universe_check.setChecked(True)
                
                k_val = min(k_user, len(tickers_to_load))
                if k_val < 2:
                    k_val = max(2, len(tickers_to_load))
                    
                if k_val > self.k_spin.maximum():
                    self.k_spin.setMaximum(k_val)
                self.k_spin.setValue(k_val)
                
                self._set_results_tab(TAB_PORTFOLIO)
                self.status_subtitle.setText(f"✓ Loaded {len(tickers_to_load)} setups from live scan. Portfolio size set dynamically to {k_val}. Press 'Run optimizer' to build portfolio.")
                self.append_log(f"[Bridge] Replaced manual symbols list with {len(tickers_to_load)} setups. Portfolio size adjusted to {k_val}.")



    # ═══════════════════════════════════════════════════════════════════════════
    # ML ALPHA ENGINE — Fit Ridge + 15-factor ensemble with walk-forward CV
    # ═══════════════════════════════════════════════════════════════════════════

    class MLFitWorker(QThread):
        """Background worker for ML alpha model fitting."""
        progress = pyqtSignal(str)
        finished_ok = pyqtSignal(object)  # FitResult
        failed = pyqtSignal(str)

        def __init__(self, parent, engine, **kwargs):
            super().__init__(parent)
            self._engine = engine
            self._kwargs = kwargs

        def run(self):
            try:
                result = self._engine.fit(
                    progress_cb=lambda msg: self.progress.emit(msg),
                    **self._kwargs,
                )
                self.finished_ok.emit(result)
            except Exception as e:
                import traceback
                self.failed.emit(f"{e}\n{traceback.format_exc()}")

    def _run_ml_fit(self):
        """Launch the ML alpha model fitting in a background thread."""
        if hasattr(self, "_ml_worker") and self._ml_worker is not None and self._ml_worker.isRunning():
            self.append_log("[ML Alpha] Already running — please wait.")
            return

        from ml_alpha import AlphaEngine
        self._ml_engine = AlphaEngine(model_type="ensemble")
        self.pipeline_btn.setEnabled(False)
        self.pipeline_btn.setText("🔁  Fitting ML Alpha...")
        self.append_log("[ML Alpha] Starting Expanded 6-Model Ensemble (Ridge+LGBM+XGB+CatBoost+ElasticNet+Bayesian) with walk-forward CV...")
        self.status_title.setText("ML Fitting")
        self.status_subtitle.setText("Fitting Expanded 6-Model Ensemble with walk-forward CV...")

        # Dynamic date range (no hardcoded 2026-06-28)
        from datetime import date as _date, timedelta as _td
        _end = _date.today()
        _start = _end - _td(days=365 * 4)  # 4-year training window
        _end_str = _end.strftime("%Y-%m-%d")
        _start_str = _start.strftime("%Y-%m-%d")

        self._ml_worker = self.MLFitWorker(
            parent=self,
            engine=self._ml_engine,
            start=_start_str,
            end=_end_str,
            universe="nifty500",  # broad universe so midcap screen picks get real scores
            model_type="ensemble",
            n_splits=4,
            train_period_days=50,
            test_period_days=20,
        )
        self._ml_worker.progress.connect(self.append_log)
        self._ml_worker.finished_ok.connect(self._on_ml_fit_complete)
        self._ml_worker.failed.connect(self._on_ml_fit_failed)
        self._ml_worker.start()

    def _on_ml_fit_complete(self, result):
        """Display ML fit results when fitting completes.

        If this was launched as part of the full pipeline (Stage 2), inject
        ML scores into the optimizer and auto-launch Stage 3.
        """
        self.pipeline_btn.setEnabled(True)
        self.pipeline_btn.setText("🔁  Force Full Rebuild")
        self.status_title.setText("ML Fit Complete ✓")
        self.status_subtitle.setText(f"OOS Sharpe: {result.out_of_sample_sharpe_mean:+.2f}  |  DSR: {result.deflated_sharpe:.4f}")

        self.append_log("")
        self.append_log("╔══════════════════════════════════════════════════════════╗")
        self.append_log("║          ML ALPHA MODEL — FIT COMPLETE                   ║")
        self.append_log("╠══════════════════════════════════════════════════════════╣")
        self.append_log(f"║  Run ID:         {result.run_id}")
        self.append_log(f"║  Model:          {result.model_type.upper()}")
        self.append_log(f"║  Tickers:        {result.n_tickers}")
        self.append_log(f"║  Observations:   {result.n_observations:,}")
        self.append_log(f"║  Features:       {result.n_features}")
        self.append_log(f"║  IS Sharpe:      {result.in_sample_sharpe_mean:+.2f} ± {result.in_sample_sharpe_std:.2f}")
        self.append_log(f"║  OOS Sharpe:     {result.out_of_sample_sharpe_mean:+.2f} ± {result.out_of_sample_sharpe_std:.2f}")
        self.append_log(f"║  WF Efficiency:  {result.walk_forward_efficiency:.1%}")
        self.append_log(f"║  Deflated Sharpe:{result.deflated_sharpe:.4f}  (P(true Sharpe > 0))")
        self.append_log("╠══════════════════════════════════════════════════════════╣")
        self.append_log("║  Per-Fold Walk-Forward Results:")
        for m in result.per_fold_metrics:
            self.append_log(f"║    Fold {m['fold_id']}: IS_IC={m['is_ic']:+.4f}  OOS_IC={m['oos_ic']:+.4f}  IS_Sharpe={m['is_sharpe']:+.2f}  OOS_Sharpe={m['oos_sharpe']:+.2f}")
        self.append_log("╠══════════════════════════════════════════════════════════╣")
        self.append_log("║  Feature Importance:")
        for k, v in sorted(result.feature_importance.items(), key=lambda x: -x[1])[:10]:
            self.append_log(f"║    {k:20s}: {v*100:.1f}%")
        self.append_log("╚══════════════════════════════════════════════════════════╝")
        self.append_log("")
        self.append_log("[ML Alpha] Model fitted and ready. Alpha scores will be used in next optimization run.")

        # Store the fitted engine for use by the optimizer and persist to disk
        self._ml_alpha_engine = self._ml_engine
        self._ml_alpha_result = result
        try:
            import os
            os.makedirs("artifacts", exist_ok=True)
            self._ml_engine.save_model("artifacts/saved_ml_alpha.pkl")
            self.append_log("[ML Alpha] ✓ Saved trained 6-model ensemble to artifacts/saved_ml_alpha.pkl")
        except Exception as _save_e:
            self.append_log(f"[ML Alpha] Warning: Could not save model to disk ({_save_e})")

        # Compute alpha predictions for the optimizer
        try:
            from datetime import date as _date
            ml_scores = self._ml_engine.predict(as_of=_date.today())
            self._ml_alpha_scores = ml_scores
            self.append_log(f"[ML Alpha] Predictions computed for {len(ml_scores)} tickers")
            if ml_scores:
                _top5 = sorted(ml_scores.items(), key=lambda x: -x[1])[:5]
                self.append_log(f"[ML Alpha] Top 5: {', '.join(f'{t}={v:+.3f}' for t,v in _top5)}")
        except Exception as e:
            self.append_log(f"[ML Alpha] Prediction warning: {e}")
            self._ml_alpha_scores = {}

        # If this was launched as part of the full pipeline, auto-launch Stage 3 (optimizer)
        if getattr(self, "_pipeline_after_ml", False):
            self._pipeline_after_ml = False
            self.append_log("")
            self.append_log("[Pipeline] Stage 3/3: Portfolio Optimizer")
            self.append_log("[Pipeline] Launching optimizer with ML alpha scores injected (30% weight)...")
            self.append_log("")
            self._pipeline_running_optimizer = True
            QTimer.singleShot(500, self._pipeline_stage3_run)

    def _pipeline_stage3_run(self):
        """Launch the optimizer as the final pipeline stage.
        FIX GAP 7.2: Don't re-enter _on_run_clicked() — can re-route to profiles.
        AUDIT-FIX (Round 5, 2-a-4): the old body called _smart_run(), which
        unconditionally re-ran the FULL neural screen (Stage 1) before the
        optimizer — duplicating a ~60-minute stage — and, whenever the freshly
        fitted model still had DSR < 0.20, re-entered the screen→ML-fit cycle
        indefinitely (livelock: the optimizer never ran). Launch the optimizer
        directly via the same stage-2 bridge used after verification.
        """
        try:
            self._pipeline_running = False
            self._running_auto_pipeline_stage2 = True   # skip verify interception
            self._trigger_stage2_run()                   # launches OptimizerWorker directly
        finally:
            self._pipeline_running_optimizer = False

    # ═══════════════════════════════════════════════════════════════════════════
    # FULL PIPELINE — Sequential: Neural Screen → ML Alpha → Optimizer
    # ═══════════════════════════════════════════════════════════════════════════


    def _ml_model_is_fresh(self) -> bool:
        """Check if the ML alpha model is fresh enough to skip refitting."""
        result = getattr(self, "_ml_alpha_result", None)
        if result is None: return False
        if result.deflated_sharpe < 0.20: return False
        scores = getattr(self, "_ml_alpha_scores", {})
        if not scores or len(scores) < 10: return False
        try:
            from datetime import datetime
            completed = getattr(result, "completed_at", None)
            if completed:
                fitted_time = datetime.fromisoformat(completed)
                age_hours = (datetime.now() - fitted_time).total_seconds() / 3600
                if age_hours > 24: return False
        except Exception as exc:
            self.append_log(f"[ML Freshness] Check warning: {exc}")
            return False
        return True

    # ══════════════════════════════════════════════════════════════════════════
    #  Parallel Profile Sweep — Build Panel
    # ══════════════════════════════════════════════════════════════════════════

    def _build_all_profiles_panel(self):
        """Build the ⚡ All Profiles multi-profile results panel.

        Layout:
            ┌─ Status bar (one badge per profile) ─────────────────────────┐
            ├─ Profile tab bar (one button per profile name) ───────────────┤
            ├─ QStackedWidget ─────────────────────────────────────────────┤
            │   Per-profile page:                                           │
            │   ┌── inner QStackedWidget (sub-tabs) ──────────────────────┐│
            │   │   Portfolio | Universe | 🚀 Breakout | 🔍 Pre-Breakout  ││
            │   └─────────────────────────────────────────────────────────┘│
            └──────────────────────────────────────────────────────────────┘
        """
        outer = QWidget()
        outer_lay = QVBoxLayout(outer)
        outer_lay.setContentsMargins(0, 0, 0, 0)
        outer_lay.setSpacing(8)

        # ── Status bar: one badge label per profile ──────────────────────────
        status_scroll_area = QWidget()
        status_row = QHBoxLayout(status_scroll_area)
        status_row.setContentsMargins(4, 4, 4, 4)
        status_row.setSpacing(6)

        self._profile_status_badges = {}   # {profile_name: QLabel}
        for pname in PROFILE_MAP.keys():
            short = pname[:22] + "…" if len(pname) > 22 else pname
            badge = QLabel(f"⏸ {short}")
            badge.setObjectName("ProfileBadgePending")
            badge.setStyleSheet(
                "background:#2c2c2e; color:#8e8e93; border-radius:6px; "
                "padding:3px 8px; font-size:10px;"
            )
            badge.setFixedHeight(24)
            status_row.addWidget(badge)
            self._profile_status_badges[pname] = badge

        # Stop All button in the status bar
        self.stop_all_profiles_btn = QPushButton("■ Stop All")
        self.stop_all_profiles_btn.setObjectName("StopButton")
        self.stop_all_profiles_btn.setFixedHeight(24)
        self.stop_all_profiles_btn.setEnabled(False)
        self.stop_all_profiles_btn.clicked.connect(self._on_stop_all_profiles)
        status_row.addStretch(1)
        status_row.addWidget(self.stop_all_profiles_btn)
        outer_lay.addWidget(status_scroll_area)

        # ── Profile tab nav bar ───────────────────────────────────────────────
        tab_nav = QWidget()
        tab_nav_row = QHBoxLayout(tab_nav)
        tab_nav_row.setContentsMargins(4, 0, 4, 0)
        tab_nav_row.setSpacing(4)

        self._profile_tab_buttons = {}     # {profile_name: QPushButton}
        self._profile_pages_stack = QStackedWidget()

        # ── Compare toggle button & comparison panel ──────────────────────────
        compare_btn = QPushButton("📊 Compare All")
        compare_btn.setCheckable(True)
        compare_btn.setObjectName("TabNavButton")
        compare_btn.setFixedHeight(28)
        compare_btn.setToolTip("Show cross-profile comparison grid — which stocks appear in multiple profiles")
        compare_btn.setCursor(Qt.PointingHandCursor)

        compare_wrapper = QWidget()
        compare_wrapper.setVisible(False)
        compare_wrapper_lay = QVBoxLayout(compare_wrapper)
        compare_wrapper_lay.setContentsMargins(0, 0, 0, 0)
        compare_wrapper_lay.setSpacing(0)

        profile_names = list(PROFILE_MAP.keys())
        for i, pname in enumerate(profile_names):
            short = pname[:18] + "…" if len(pname) > 18 else pname
            btn = QPushButton(short)
            btn.setCheckable(True)
            btn.setObjectName("TabNavButton")
            btn.setCursor(Qt.PointingHandCursor)
            btn.setToolTip(pname)
            btn.clicked.connect(lambda checked=False, idx=i: self._profile_pages_stack.setCurrentIndex(idx))
            btn.clicked.connect(lambda checked=False, b=btn: [
                bx.setChecked(bx is b)
                for bx in self._profile_tab_buttons.values()
            ])
            btn.clicked.connect(lambda checked=False: (
                compare_btn.setChecked(False),
                compare_wrapper.setVisible(False),
                self._profile_pages_stack.setVisible(True)
            ))
            tab_nav_row.addWidget(btn)
            self._profile_tab_buttons[pname] = btn

            # Build per-profile page with 4 sub-tabs
            page = self._build_single_profile_page(pname)
            self._profile_pages_stack.addWidget(page)

        tab_nav_row.addStretch(1)
        tab_nav_row.addWidget(compare_btn)

        # Select first tab by default
        if profile_names:
            self._profile_tab_buttons[profile_names[0]].setChecked(True)

        compare_header = QLabel("📊 Cross-Profile Consensus  —  ⚡ = 3+ profiles  ★ = 2 profiles  · = 1 profile")
        compare_header.setStyleSheet(
            "color:#8e8e93; font-size:10px; padding:4px 8px; "
            "background:#1c1c1e; border-bottom:1px solid #2c2c2e;"
        )
        compare_wrapper_lay.addWidget(compare_header)

        compare_scroll = QScrollArea()
        compare_scroll.setWidgetResizable(True)
        compare_scroll.setFrameShape(QFrame.NoFrame)
        compare_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        compare_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)

        # The actual grid content is built dynamically by _refresh_comparison_panel
        self._comparison_content = QWidget()
        _grid = QGridLayout(self._comparison_content)
        _grid.setSpacing(4)
        _grid.setContentsMargins(8, 8, 8, 8)
        compare_scroll.setWidget(self._comparison_content)
        compare_wrapper_lay.addWidget(compare_scroll, 1)

        def _toggle_compare(checked):
            compare_wrapper.setVisible(checked)
            self._profile_pages_stack.setVisible(not checked)
            if checked:
                # Uncheck all profile buttons
                for bx in self._profile_tab_buttons.values():
                    bx.setChecked(False)
            else:
                # Re-check the currently active profile button
                idx = self._profile_pages_stack.currentIndex()
                if 0 <= idx < len(profile_names):
                    self._profile_tab_buttons[profile_names[idx]].setChecked(True)
        compare_btn.clicked.connect(_toggle_compare)

        outer_lay.addWidget(tab_nav)
        outer_lay.addWidget(compare_wrapper)
        outer_lay.addWidget(self._profile_pages_stack, 1)
        return outer


    def _build_single_profile_page(self, profile_name: str):
        """Build the sub-tab page (Portfolio|Universe|📈 Charts|🚀 Breakout|🔍 Pre-Breakout) for one profile."""
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 4, 0, 0)
        lay.setSpacing(0)

        # Sub-tab nav
        sub_nav = QWidget()
        sub_nav_row = QHBoxLayout(sub_nav)
        sub_nav_row.setContentsMargins(4, 0, 4, 0)
        sub_nav_row.setSpacing(4)

        sub_stack = QStackedWidget()
        sub_labels = ["Portfolio", "Universe", "📈 Charts", "🚀 Breakout", "🔍 Pre-Breakout"]
        sub_btns = []

        # Create tables for Portfolio/Universe/Breakout/Pre-Breakout
        ptable  = self._make_table()
        utable  = self._make_table()
        btable  = self._make_table()
        pbtable = self._make_table()

        # Create per-profile charts panel with embedded TV chart viewer
        charts_panel = QWidget()
        charts_lay   = QHBoxLayout(charts_panel)
        charts_lay.setContentsMargins(0, 0, 0, 0)
        charts_lay.setSpacing(0)

        profile_charts_list = QListWidget()
        profile_charts_list.setObjectName("ChartsList")
        profile_charts_list.setMaximumWidth(200)
        profile_charts_list.setMinimumWidth(110)

        # Embedded chart view container for individual profile page
        chart_view_container = QWidget()
        cv_lay = QVBoxLayout(chart_view_container)
        cv_lay.setContentsMargins(0, 0, 0, 0)
        cv_lay.setSpacing(0)

        profile_tv_view = None
        profile_canvas = None
        profile_placeholder = None

        if HAS_WEBENGINE:
            profile_tv_view = QWebEngineView()
            profile_tv_view.setUrl(QUrl("about:blank"))
            profile_tv_view.loadFinished.connect(self._disable_unload_handler)
            cv_lay.addWidget(profile_tv_view)
        else:
            try:
                from ui.components.interactive_chart import InteractivePortfolioChart
                profile_canvas = InteractivePortfolioChart()
                cv_lay.addWidget(profile_canvas)
            except ImportError:
                profile_placeholder = QLabel(
                    "📈 Charts load here after the run completes.\n\nSelect a ticker from the list.",
                    alignment=Qt.AlignCenter
                )
                profile_placeholder.setObjectName("MutedText")
                profile_placeholder.setWordWrap(True)
                cv_lay.addWidget(profile_placeholder)

        profile_charts_list.itemClicked.connect(
            lambda item, pname=profile_name: self._on_profile_chart_stock_clicked(item, pname)
        )

        charts_lay.addWidget(profile_charts_list)
        charts_lay.addWidget(chart_view_container, 1)

        # Map sub-tabs to their widgets
        sub_widgets = [ptable, utable, charts_panel, btable, pbtable]

        for sidx, slabel in enumerate(sub_labels):
            sbtn = QPushButton(slabel)
            sbtn.setCheckable(True)
            sbtn.setObjectName("TabNavButton")
            sbtn.setFixedHeight(28)
            sbtn.setCursor(Qt.PointingHandCursor)
            sbtn.clicked.connect(lambda checked=False, si=sidx: sub_stack.setCurrentIndex(si))
            sbtn.clicked.connect(lambda checked=False, b=sbtn, blist=sub_btns: [
                bx.setChecked(bx is b) for bx in blist
            ])
            sub_nav_row.addWidget(sbtn)
            sub_btns.append(sbtn)

        sub_nav_row.addStretch(1)
        sub_btns[0].setChecked(True)

        # Wire table double-clicks to load chart in the profile's Charts sub-tab
        for tbl in [ptable, utable, btable, pbtable]:
            tbl.cellDoubleClicked.connect(
                lambda row, col, pname=profile_name, t=tbl: self._on_profile_table_cell_clicked(row, col, pname, t)
            )

        # Wrap each widget in a stack page
        for w in sub_widgets:
            if isinstance(w, QTableWidget):
                wrapper = QWidget()
                wl = QVBoxLayout(wrapper)
                wl.setContentsMargins(0, 0, 0, 0)
                wl.addWidget(w)
                sub_stack.addWidget(wrapper)
            else:
                sub_stack.addWidget(w)

        # Pending placeholder overlay
        pending_placeholder = QLabel(
            f"⏳ {profile_name}\n\nWaiting to start...\n\nClick '⚡ Run All Profiles' to begin.",
            alignment=Qt.AlignCenter
        )
        pending_placeholder.setObjectName("EmptyStateLabel")
        pending_placeholder.setStyleSheet("font-size:14px; color:#8e8e93;")

        # Use a master stack: 0=pending, 1=results
        master_stack = QStackedWidget()
        master_stack.addWidget(pending_placeholder)

        results_page = QWidget()
        rl = QVBoxLayout(results_page)
        rl.setContentsMargins(0, 0, 0, 0)
        rl.setSpacing(4)
        rl.addWidget(sub_nav)
        rl.addWidget(sub_stack, 1)
        master_stack.addWidget(results_page)

        lay.addWidget(master_stack, 1)

        # Store references so _on_profile_done can populate the tables and load charts
        if not hasattr(self, "_profile_page_refs"):
            self._profile_page_refs = {}
        self._profile_page_refs[profile_name] = {
            "master_stack":     master_stack,
            "sub_stack":        sub_stack,
            "sub_btns":         sub_btns,
            "portfolio_table":  ptable,
            "universe_table":   utable,
            "breakout_table":   btable,
            "prebreakout_table": pbtable,
            "charts_list":      profile_charts_list,
            "tv_view":          profile_tv_view,
            "interactive_canvas": profile_canvas,
            "placeholder":      profile_placeholder,
        }
        return page


    # ══════════════════════════════════════════════════════════════════════════
    #  Parallel Profile Sweep — Launch + Slots
    # ══════════════════════════════════════════════════════════════════════════

    def _run_all_profiles(self):
        """Launch ProfileOrchestrator to run all research profiles in parallel."""
        from workers.worker_threads import ProfileOrchestrator

        if hasattr(self, "_orchestrator") and self._orchestrator and self._orchestrator.isRunning():
            self.append_log("[All Profiles] Already running. Click 'Stop All' to cancel.")
            return

        # Collect base cfg from current UI state (profile overrides come from PROFILE_MAP)
        base_cfg = self.collect_cfg()
        # Disable per-profile ML fit and live verify inside the sweep for speed
        base_cfg["AUTO_LIVE_VERIFY_SCREEN"] = False
        base_cfg["_ALREADY_VERIFIED"] = True
        base_cfg["USE_MANUAL_UNIVERSE"] = False

        # Inject pre-loaded ML Alpha scores & DSR metrics into sweep base_cfg
        _ml_scores = getattr(self, "_ml_alpha_scores", None)
        if _ml_scores is not None and len(_ml_scores) > 0:
            _scores_dict = _ml_scores.to_dict() if hasattr(_ml_scores, "to_dict") else dict(_ml_scores)
            base_cfg["_ML_ALPHA_SCORES"] = _scores_dict
            _ml_result = getattr(self, "_ml_alpha_result", None)
            if _ml_result is not None:
                base_cfg["_ML_OOS_SHARPE"] = f"{_ml_result.out_of_sample_sharpe_mean:+.2f}"
                base_cfg["_ML_DSR"] = _ml_result.deflated_sharpe
                base_cfg["_ML_OOS_SHARPE_NUM"] = _ml_result.out_of_sample_sharpe_mean
            else:
                _dsr_raw = getattr(self, "_ml_dsr", None) or getattr(getattr(self, "_ml_engine", None), "dsr", None)
                _oos_raw = getattr(self, "_ml_oos_sharpe", None) or getattr(getattr(self, "_ml_engine", None), "oos_sharpe", None)
                _dsr = float(_dsr_raw) if _dsr_raw is not None else None
                _oos = float(_oos_raw) if _oos_raw is not None else None
                base_cfg["_ML_DSR"] = _dsr
                base_cfg["_ML_OOS_SHARPE_NUM"] = _oos
                base_cfg["_ML_OOS_SHARPE"] = f"{_oos:+.2f}" if _oos is not None else "—"


        try:
            # Reset all status badges
            if hasattr(self, "_profile_status_badges") and self._profile_status_badges:
                for pname, badge in self._profile_status_badges.items():
                    badge.setText(f"⏳ {pname[:22]}")
                    badge.setStyleSheet(
                        "background:#2c2c2e; color:#f0c040; border-radius:6px; "
                        "padding:3px 8px; font-size:10px;"
                    )

            # Reset profile page stacks to pending state
            if hasattr(self, "_profile_page_refs") and self._profile_page_refs:
                for refs in self._profile_page_refs.values():
                    if isinstance(refs, dict) and "master_stack" in refs:
                        refs["master_stack"].setCurrentIndex(0)

            # Navigate to the All Profiles tab
            if hasattr(self, "results_tab_labels") and "⚡ All Profiles" in self.results_tab_labels:
                self._set_results_tab(self.results_tab_labels.index("⚡ All Profiles"))

            # Build and start orchestrator (all 9 profiles run in parallel)
            max_parallel = int(base_cfg.get("MAX_PARALLEL_WORKERS", ProfileOrchestrator.DEFAULT_MAX_PARALLEL))
            self._orchestrator = ProfileOrchestrator(
                profiles=PROFILE_MAP,
                base_cfg=base_cfg,
                max_parallel=max_parallel,
                parent=self,
            )
            self._orchestrator.orchestrator_log.connect(self.append_log)
            self._orchestrator.profile_done.connect(self._on_profile_done)
            self._orchestrator.profile_failed.connect(self._on_profile_failed)
            def _on_profile_log(name, msg):
                low = str(msg).lower()
                if any(kw in low for kw in ("starting", "completed", "failed", "selected", "error", "warn", "optimization", "runs", "best energy")):
                    self.append_log(f"[{name[:16]}] {msg}")

            self._orchestrator.profile_log.connect(_on_profile_log)
            self._orchestrator.all_profiles_done.connect(self._on_all_profiles_done)
            self._orchestrator.start()

            # Update UI state
            self.run_btn.setEnabled(False)
            if hasattr(self, "run_all_profiles_btn") and self.run_all_profiles_btn:
                self.run_all_profiles_btn.setEnabled(False)
            self.stop_btn.setEnabled(True)
            if hasattr(self, "stop_all_profiles_btn") and self.stop_all_profiles_btn:
                self.stop_all_profiles_btn.setEnabled(True)
            self.status_title.setText("⚡ Parallel Sweep")
            self.status_subtitle.setText(f"Running all {len(PROFILE_MAP)} profiles in parallel…")
            sub_workers = int(base_cfg.get("SUB_WORKERS_PER_PROFILE", 10))
            total_workers = len(PROFILE_MAP) * max_parallel if max_parallel < len(PROFILE_MAP) else len(PROFILE_MAP) * sub_workers
            self.append_log("")
            self.append_log("╔══════════════════════════════════════════════════════════╗")
            self.append_log("║   ⚡ PARALLEL PROFILE SWEEP — All Profiles              ║")
            self.append_log(f"║   {len(PROFILE_MAP)} profiles × {sub_workers} sub-workers ({total_workers} active / up to 100 workers)  ║")
            self.append_log("╚══════════════════════════════════════════════════════════╝")
        except Exception as _sweep_err:
            import traceback
            self.append_log(f"❌ [All Profiles Sweep Error] {_sweep_err}\n{traceback.format_exc()}")

    def _on_profile_done(self, profile_name: str, payload):
        """Slot: a ProfileWorker has finished. Populate its tab and update badge."""
        if not payload or not isinstance(payload, dict):
            self._on_profile_failed(profile_name, "Optimizer returned no result.")
            return

        # ── Store payload for cross-profile comparison and charts ─────────────
        if not hasattr(self, "_profile_payloads"):
            self._profile_payloads = {}
        self._profile_payloads[profile_name] = payload

        # Update status badge → green ✓
        runtime = payload.get("runtime_sec", 0.0)
        if profile_name in self._profile_status_badges:
            badge = self._profile_status_badges[profile_name]
            badge.setText(f"✓ {profile_name[:18]} ({runtime:.0f}s)")
            badge.setStyleSheet(
                "background:#1c3a2a; color:#34c759; border-radius:6px; "
                "padding:3px 8px; font-size:10px; font-weight:600;"
            )

        # Populate this profile's sub-tab tables
        refs = getattr(self, "_profile_page_refs", {}).get(profile_name)
        if refs:
            self.populate_table(refs["portfolio_table"], payload.get("portfolio_df"))
            self.populate_table(refs["universe_table"], payload.get("prescreen_df"))
            self.populate_table(refs["breakout_table"], payload.get("breakout_df"))
            self.populate_table(refs["prebreakout_table"], payload.get("prebreakout_df"))
            # Populate per-profile charts list
            _charts_lw = refs.get("charts_list")
            if _charts_lw is not None:
                self._populate_profile_charts_list(
                    _charts_lw, payload.get("prescreen_df"), payload.get("selected", [])
                )
            # Switch master stack from "pending" to "results"
            refs["master_stack"].setCurrentIndex(1)

        # ── Refresh cross-profile comparison panel (lightweight data table update) ──
        try:
            self._refresh_comparison_panel()
        except Exception:
            pass

        self.append_log(
            f"[All Profiles] ✓ '{profile_name}' complete — "
            f"{len(payload.get('selected', []))} stocks selected, "
            f"runtime {runtime:.0f}s"
        )

    def _on_profile_failed(self, profile_name: str, tb: str):
        """Slot: a ProfileWorker has failed. Update badge to red ✗."""
        if profile_name in self._profile_status_badges:
            badge = self._profile_status_badges[profile_name]
            badge.setText(f"✗ {profile_name[:18]}")
            badge.setStyleSheet(
                "background:#3a1c1c; color:#ff453a; border-radius:6px; "
                "padding:3px 8px; font-size:10px;"
            )
        # Show last 3 lines of traceback: file/line + code + exception type — enough to diagnose
        tb_lines = tb.strip().splitlines() if tb else []
        err_summary = " | ".join(l.strip() for l in tb_lines[-3:]) if len(tb_lines) >= 3 else (tb.strip() if tb else "Unknown error")
        self.append_log(f"[All Profiles] ✗ '{profile_name}' failed: {err_summary}")

    def _on_all_profiles_done(self):
        """Slot: all ProfileWorkers have finished."""
        from core.state_manager import AppState
        statuses = AppState.instance().get_all_profile_statuses()
        n_done = sum(1 for s in statuses.values() if s == "done")
        n_total = len(statuses)
        self.status_title.setText("⚡ Sweep Complete ✓")
        self.status_title.setStyleSheet(f"color: {_QSS.GREEN_SUCCESS}; font-weight: bold;")
        self.status_subtitle.setText(f"{n_done}/{n_total} profiles completed successfully")
        self.run_btn.setEnabled(True)
        self.run_all_profiles_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.stop_all_profiles_btn.setEnabled(False)
        self._set_export_buttons_enabled(True)
        try:
            self._update_global_charts_from_profiles()
        except Exception:
            pass

        # ── MANDATORY STEP: Run Tier-1 Post-Screening Intelligence & HTML Generator ──
        try:
            self.append_log("")
            self.append_log("[Post-Screening] Running Tier-1 Post-Screening Intelligence Engine (1m/5m VPIN, Piotroski F, Altman Z)...")
            from math_engine.post_screening_intelligence import PostScreeningIntelligenceEngine
            import os
            from utils import BASE_DIR

            app_dir = str(BASE_DIR)
            combined_csv = os.path.join(app_dir, "combined_portfolio.csv")
            
            # Fallback check on Desktop if not in app_dir yet
            if not os.path.exists(combined_csv):
                desktop_csv = os.path.expanduser("~/Desktop/combined_portfolio.csv")
                if os.path.exists(desktop_csv):
                    combined_csv = desktop_csv
            
            if os.path.exists(combined_csv):
                html_path = PostScreeningIntelligenceEngine.generate_and_save_intelligence_report(combined_csv)
                self.append_log(f"✅ [Post-Screening] Successfully generated Tier-1 HTML Report in app folder: {html_path}")
            else:
                self.append_log(f"⚠️ [Post-Screening] combined_portfolio.csv not found in app folder ({app_dir}).")
        except Exception as _intel_err:
            self.append_log(f"[Post-Screening] Notice: {str(_intel_err)}")

        self.append_log("")
        self.append_log(f"[All Profiles] ══ Sweep done — {n_done}/{n_total} profiles succeeded ══")

    def _on_stop_all_profiles(self):
        """Slot: user clicked 'Stop' or 'Stop All' — cancel the orchestrator and all workers."""
        if hasattr(self, "_orchestrator") and self._orchestrator and self._orchestrator.isRunning():
            self._orchestrator.request_stop()
            self.run_btn.setEnabled(True)
            self.run_all_profiles_btn.setEnabled(True)
            self.stop_btn.setEnabled(False)
            self.stop_all_profiles_btn.setEnabled(False)
            self.status_title.setText("Stopping sweep…")
            self.append_log("[All Profiles] Stop requested. Cancelling all running workers…")

    # ══════════════════════════════════════════════════════════════════════════
    #  Charts integration helpers (sweep mode)
    # ══════════════════════════════════════════════════════════════════════════

    def _populate_profile_charts_list(self, list_widget, df, selected):
        """Fill a per-profile QListWidget with prescreened tickers.

        Stars selected (portfolio) stocks, marks breakout/pre-breakout with
        the same colour scheme as the global _populate_charts_list.
        """
        list_widget.clear()
        if df is None or df.empty:
            return
        sset = set(selected or [])
        ticker_col = "ticker" if "ticker" in df.columns else (
            "Ticker" if "Ticker" in df.columns else None
        )
        if not ticker_col:
            return
        for _, row in df.iterrows():
            t = str(row[ticker_col])
            prefix = "★ " if t in sset else "  "
            item = QListWidgetItem(prefix + t.replace(".NS", ""))
            item.setData(Qt.UserRole, t)
            f = item.font()
            if t in sset:
                f.setBold(True)
                item.setFont(f)
                item.setForeground(QColor("#2563EB"))
            list_widget.addItem(item)
        # Auto-select first portfolio stock
        if selected:
            for i in range(list_widget.count()):
                if list_widget.item(i).data(Qt.UserRole) == selected[0]:
                    list_widget.setCurrentRow(i)
                    break

    def _load_profile_tv_chart(self, profile_name: str, ticker: str):
        """Load TradingView chart for ticker inside an individual profile's embedded chart view."""
        if not ticker or not hasattr(self, "_profile_page_refs"):
            return
        refs = self._profile_page_refs.get(profile_name)
        if not refs:
            return

        c = str(ticker).replace(".NS", "").replace(".BO", "")
        e = "BSE" if str(ticker).endswith(".BO") else "NSE"
        url = f"https://www.tradingview.com/chart/?symbol={e}:{c}&interval=D"

        tv_view = refs.get("tv_view")
        canvas = refs.get("interactive_canvas")

        if HAS_WEBENGINE and tv_view is not None:
            try:
                tv_view.page().runJavaScript("window.onbeforeunload = null;")
            except Exception:
                pass
            tv_view.setUrl(QUrl(url))
        elif canvas is not None:
            self.append_log(f"[{profile_name[:16]}] Fetching historical OHLCV data for {ticker}...")
            def _fetch():
                return _DATA_PROVIDER.get_prices([ticker], period="1y")
            
            worker = _GenericNetworkWorker(_fetch)
            def on_result(df):
                if df is not None and not df.empty:
                    canvas.set_data(df)
            worker.result.connect(on_result)
            worker.finished.connect(worker.deleteLater)
            worker.start()
            refs["_chart_worker"] = worker
        else:
            placeholder = refs.get("placeholder")
            if placeholder is not None:
                placeholder.setText(f"📈 TradingView Chart: {e}:{c}\n\nSymbol: {e}:{c}")

    def _on_profile_chart_stock_clicked(self, item, profile_name=None):
        """Called when a ticker is clicked in a per-profile charts list."""
        ticker = item.data(Qt.UserRole)
        if not ticker:
            return
        if profile_name and hasattr(self, "_profile_page_refs") and profile_name in self._profile_page_refs:
            # Load chart inside this profile's own embedded chart viewer (staying inside the profile tab!)
            self._load_profile_tv_chart(profile_name, ticker)
            # Sync selection to global charts_list in background
            if hasattr(self, "charts_list") and self.charts_list is not None:
                for i in range(self.charts_list.count()):
                    if self.charts_list.item(i).data(Qt.UserRole) == ticker:
                        self.charts_list.setCurrentRow(i)
                        break
        else:
            self._load_tv_chart(ticker)
            self._set_results_tab(TAB_CHARTS)

    def _on_profile_table_cell_clicked(self, row, col, profile_name: str, table):
        """Called when a cell is double-clicked in a profile's table.
        Switches to the profile's '📈 Charts' sub-tab and loads that ticker's chart right inside the profile.
        """
        if row < 0 or not table or not hasattr(self, "_profile_page_refs"):
            return
        refs = self._profile_page_refs.get(profile_name)
        if not refs:
            return

        item = table.item(row, 0)
        ticker = None
        if item and item.text():
            text = item.text().strip().replace("★ ", "")
            if text:
                ticker = text if text.endswith(".NS") else f"{text}.NS"

        if not ticker:
            item1 = table.item(row, 1)
            if item1 and item1.text():
                text = item1.text().strip().replace("★ ", "")
                if text:
                    ticker = text if text.endswith(".NS") else f"{text}.NS"

        if ticker and refs.get("charts_list"):
            clist = refs["charts_list"]
            for i in range(clist.count()):
                if clist.item(i).data(Qt.UserRole) == ticker or clist.item(i).text().strip().replace("★ ", "") == ticker.replace(".NS", ""):
                    clist.setCurrentRow(i)
                    break
            sub_stack = refs.get("sub_stack")
            sub_btns = refs.get("sub_btns")
            if sub_stack is not None:
                sub_stack.setCurrentIndex(2)
                if sub_btns and len(sub_btns) > 2:
                    for idx, btn in enumerate(sub_btns):
                        btn.setChecked(idx == 2)
            self._load_profile_tv_chart(profile_name, ticker)


    def _update_global_charts_from_profiles(self):
        """Refresh the global Charts tab with the union of all completed profiles.

        Ranks tickers by how many profiles selected them (★★★ = 3 profiles, etc.)
        so the most cross-profile-consensus picks appear at the top.
        """
        payloads = getattr(self, "_profile_payloads", {})
        if not payloads:
            return

        from collections import Counter, OrderedDict
        import pandas as pd

        ticker_profile_count: Counter = Counter()
        # Count how many profiles selected each ticker
        for p in payloads.values():
            for t in (p.get("selected") or []):
                ticker_profile_count[t] += 1

        # Build a combined prescreen_df with one row per unique ticker
        combined_rows = []
        seen: set = set()
        # First pass: add portfolio-selected tickers
        for p in payloads.values():
            psc = p.get("prescreen_df")
            if psc is None or psc.empty:
                continue
            tcol = "ticker" if "ticker" in psc.columns else (
                "Ticker" if "Ticker" in psc.columns else None
            )
            if not tcol:
                continue
            for _, row in psc.iterrows():
                t = str(row[tcol])
                if t not in seen:
                    seen.add(t)
                    combined_rows.append(row.to_dict())

        if not combined_rows:
            return

        combined_df = pd.DataFrame(combined_rows)
        # Add a ticker column if it doesn't exist with the right name
        if "ticker" not in combined_df.columns and "Ticker" in combined_df.columns:
            combined_df["ticker"] = combined_df["Ticker"]

        # Build selected list: tickers chosen by at least 1 profile, sorted by frequency
        all_selected = [t for t, _ in ticker_profile_count.most_common()]

        # Populate with star-count prefix for cross-profile frequency
        if hasattr(self, "charts_list") and self.charts_list is not None:
            self.charts_list.clear()
            sset = set(all_selected)
            for _, row in combined_df.iterrows():
                t = row.get("ticker") or row.get("Ticker", "")
                t = str(t)
                count = ticker_profile_count.get(t, 0)
                if count >= 3:
                    prefix = "⚡ "   # 3+ profiles
                elif count == 2:
                    prefix = "★★ "
                elif count == 1:
                    prefix = "★  "
                else:
                    prefix = "   "
                item = QListWidgetItem(prefix + t.replace(".NS", ""))
                item.setData(Qt.UserRole, t)
                f = item.font()
                if count >= 3:
                    f.setBold(True)
                    item.setFont(f)
                    item.setForeground(QColor("#F59E0B"))   # amber — high consensus
                elif count >= 1:
                    f.setBold(True)
                    item.setFont(f)
                    item.setForeground(QColor("#2563EB"))   # blue — selected
                self.charts_list.addItem(item)
            # Auto-load the top consensus pick
            if all_selected:
                for i in range(self.charts_list.count()):
                    if self.charts_list.item(i).data(Qt.UserRole) == all_selected[0]:
                        self.charts_list.setCurrentRow(i)
                        self._load_tv_chart(all_selected[0])
                        break

    def _refresh_comparison_panel(self):
        """Update the cross-profile comparison grid inside the All Profiles panel."""
        panel = getattr(self, "_comparison_content", None)
        if panel is None:
            return
        payloads = getattr(self, "_profile_payloads", {})
        if not payloads:
            return

        from collections import Counter
        import pandas as pd

        # Clear existing content
        old_lay = panel.layout()
        if old_lay:
            while old_lay.count():
                item = old_lay.takeAt(0)
                if item.widget():
                    item.widget().deleteLater()
        else:
            grid = QGridLayout(panel)
            grid.setSpacing(6)
            grid.setContentsMargins(8, 8, 8, 8)
            old_lay = grid

        # Count cross-profile selections
        ticker_profiles: dict = {}
        profile_selected: dict = {}
        for pname, p in payloads.items():
            sel = p.get("selected") or []
            profile_selected[pname] = sel
            for t in sel:
                ticker_profiles.setdefault(t, []).append(pname)

        # Sort tickers by frequency
        sorted_tickers = sorted(ticker_profiles.keys(), key=lambda t: -len(ticker_profiles[t]))

        grid = old_lay
        profile_names = list(payloads.keys())

        # Header row
        h0 = QLabel("Ticker")
        h0.setStyleSheet("font-weight:700; color:#8e8e93; font-size:10px;")
        grid.addWidget(h0, 0, 0)
        for col, pname in enumerate(profile_names, 1):
            h = QLabel(pname[:14])
            h.setStyleSheet("font-weight:700; color:#8e8e93; font-size:9px;")
            h.setAlignment(Qt.AlignCenter)
            grid.addWidget(h, 0, col)

        # Ticker rows
        for row, t in enumerate(sorted_tickers[:30], 1):   # top 30 cross-profile tickers
            profiles_with = ticker_profiles[t]
            count = len(profiles_with)
            t_short = t.replace(".NS", "")
            if count >= 3:
                color = "#F59E0B"
                star = "⚡"
            elif count == 2:
                color = "#34c759"
                star = "★"
            else:
                color = "#8e8e93"
                star = "·"
            ticker_lbl = QLabel(f"{star} {t_short}")
            ticker_lbl.setStyleSheet(f"color:{color}; font-size:10px; font-weight:600;")
            grid.addWidget(ticker_lbl, row, 0)
            for col, pname in enumerate(profile_names, 1):
                in_sel = t in profile_selected.get(pname, [])
                cell = QLabel("✓" if in_sel else "")
                cell.setAlignment(Qt.AlignCenter)
                cell.setStyleSheet(
                    f"color:{'#34c759' if in_sel else '#2c2c2e'}; font-size:11px; font-weight:700;"
                )
                grid.addWidget(cell, row, col)

    def _smart_run(self):
        """Single intelligent run — merges Neural Screen + ML Alpha + Optimizer."""

        if getattr(self, "_pipeline_running", False):
            self.append_log("[Run] Already running. Click Stop to cancel.")
            return
        if self._ml_model_is_fresh():
            self._skip_ml_fit = True
            _dsr = self._ml_alpha_result.deflated_sharpe
            _n = len(self._ml_alpha_scores)
            self.append_log("")
            self.append_log("╔══════════════════════════════════════════════════════════╗")
            self.append_log("║  SMART RUN — Screen → Optimizer (ML model reused)      ║")
            self.append_log("╚══════════════════════════════════════════════════════════╝")
            self.append_log(f"[Run] ML model is fresh (DSR={_dsr:.4f}, {_n} predictions) — skipping ML fit stage.")
            self.append_log("[Run] Stage 1/2: Neural Screen (HMM regime + ViT chart scan)")
        else:
            self._skip_ml_fit = False
            self.append_log("")
            self.append_log("╔══════════════════════════════════════════════════════════╗")
            self.append_log("║   SMART RUN — Screen → ML Alpha → Optimize              ║")
            self.append_log("╚══════════════════════════════════════════════════════════╝")
            self.append_log("[Run] Stage 1/3: Neural Screen (HMM regime + ViT chart scan)")
        self._pipeline_running = True
        self._pipeline_after_ml = True
        self._auto_run_optimizer_after_verify = False
        if self._ml_model_is_fresh():
            # ML model is fresh — skip ML fit, go straight to optimizer after screen
            self._auto_run_optimizer_after_verify = True
            self._pipeline_after_screen = False
        else:
            # ML model needs fitting — run full pipeline (screen → ML → optimizer)
            self._pipeline_after_screen = True
        if hasattr(self, "run_btn"):
            self.run_btn.setEnabled(False)
        if hasattr(self, "stop_btn"):
            self.stop_btn.setEnabled(True)
        if hasattr(self, "logs_box"):
            self.logs_box.clear()
        self._run_live_verification()

    def _run_full_pipeline(self):
        """Run the complete sequential pipeline in one click:

        Stage 1: Neural Screen (HMM regime + ViT chart scan)
        Stage 2: ML Alpha (Ridge + 15 factors, walk-forward CV on Nifty 500)
        Stage 3: Optimizer (QUBO/MV/BL with ML alpha injection at 30% weight)

        All three stages share the same log panel. Each stage's output feeds
        into the next — no manual intervention needed.
        """
        if getattr(self, "_pipeline_running", False):
            self.append_log("[Pipeline] Already running. Please wait or click Stop.")
            return

        self._pipeline_running = True
        self._pipeline_after_ml = True
        self.pipeline_btn.setEnabled(False)
        self.pipeline_btn.setText("🔁  Rebuilding... (Stage 1/3)")
        # Preserve logs across stages — only clear once at the start
        self.logs_box.clear()
        self.append_log("╔══════════════════════════════════════════════════════════╗")
        self.append_log("║        FULL PIPELINE — Screen → ML Alpha → Optimize      ║")
        self.append_log("╚══════════════════════════════════════════════════════════╝")
        self.append_log("")
        self.append_log("[Pipeline] Stage 1/3: Neural Screen (HMM regime + ViT chart scan)")
        self.append_log("")

        # Stage 1: launch the neural screen (live_verify worker)
        self.status_title.setText("Pipeline: Stage 1/3")
        self.status_subtitle.setText("Neural screen running...")
        # Flag so _on_verify_finished routes to ML alpha (Stage 2) instead of optimizer
        self._auto_run_optimizer_after_verify = False
        self._pipeline_after_screen = True
        self._run_live_verification()

    def _pipeline_bridge_to_ml_alpha(self, screener_res):
        """Bridge from Stage 1 (neural screen) to Stage 2 (ML alpha).

        The neural screen's breakout tickers are stored as a priority list
        for the optimizer's ML-alpha boost, but the optimizer itself still
        runs over the BROAD Nifty 500 universe (no manual-universe switch,
        no K_STOCKS capping). The ML model is also trained on Nifty 500 so
        that midcap screen picks (UNIPARTS, BAJAJCON, etc.) get real scores.
        """
        bo = screener_res.get("breakout_df")
        screen_tickers = []
        if bo is not None and not bo.empty:
            screen_tickers = bo["Ticker"].tolist()
        else:
            matches = screener_res.get("matches") or []
            sorted_matches = sorted(matches, key=lambda m: m[1], reverse=True)
            screen_tickers = [m[0] for m in sorted_matches if m[1] > 0.70]

        self.append_log(f"[Pipeline] Stage 1 complete: {len(screen_tickers)} tickers identified by neural screen.")
        if screen_tickers:
            self.append_log(f"[Pipeline] Screened tickers: {', '.join(screen_tickers[:10])}{'...' if len(screen_tickers) > 10 else ''}")
        self.append_log("")

        # Store screen tickers as ML-priority boost for the optimizer.
        # Do NOT switch to manual-universe mode and do NOT cap K_STOCKS —
        # the optimizer screens the broad Nifty 500 universe and uses
        # ML alpha (which covers Nifty 500) to rank all candidates.
        self._ml_screen_priority = list(screen_tickers)
        user_k = int(self.k_spin.value())
        user_universe = int(self.topn_spin.value())
        self.append_log(
            f"[Pipeline] Optimizer will run on broad universe (top {user_universe}) "
            f"with K={user_k} portfolio size. Screen tickers will get ML-alpha boost."
        )

        # Stage 2: Launch ML Alpha fitting on NIFTY 500 (broader universe so
        # all midcap screen picks get real ML scores instead of zero).
        self.append_log("[Pipeline] Stage 2/3: ML Alpha (Ridge + 15 factors, walk-forward CV on Nifty 500)")
        self.pipeline_btn.setText("🔁  Rebuilding... (Stage 2/3)")
        self.status_title.setText("Pipeline: Stage 2/3")
        self.status_subtitle.setText("Fitting Ridge + 15 factors on Nifty 500 with walk-forward CV...")

        # Dynamic date range
        from datetime import date as _date, timedelta as _td
        _end = _date.today()
        _start = _end - _td(days=365 * 4)
        _end_str = _end.strftime("%Y-%m-%d")
        _start_str = _start.strftime("%Y-%m-%d")

        from ml_alpha import AlphaEngine
        self._ml_engine = AlphaEngine(model_type="ensemble")
        self._pipeline_after_ml = True  # signal _on_ml_fit_complete to auto-launch Stage 3
        self._ml_worker = self.MLFitWorker(
            parent=self, engine=self._ml_engine,
            start=_start_str, end=_end_str, universe="nifty500",
            model_type="ensemble", n_splits=4, train_period_days=50, test_period_days=20,
        )
        self._ml_worker.progress.connect(self.append_log)
        self._ml_worker.finished_ok.connect(self._on_ml_fit_complete)
        self._ml_worker.failed.connect(self._on_ml_fit_failed)
        self._ml_worker.start()

    def _on_pipeline_optimizer_done(self):
        """Optimizer finished — mark pipeline complete and reset all flags."""
        self._pipeline_running = False
        self._pipeline_after_ml = False
        self._pipeline_after_screen = False
        self._pipeline_running_optimizer = False
        self.pipeline_btn.setEnabled(True)
        self.pipeline_btn.setText("🔁  Force Full Rebuild")

        self.append_log("[Pipeline] ═══════════════════════════════════════")
        self.append_log("[Pipeline]  FULL PIPELINE COMPLETE ✓")
        self.append_log("[Pipeline]  Stage 1: Neural Screen ✓")
        self.append_log("[Pipeline]  Stage 2: ML Alpha ✓")
        self.append_log("[Pipeline]  Stage 3: Optimizer ✓")
        self.append_log("[Pipeline] ═══════════════════════════════════════")

    def _on_ml_fit_failed(self, error):
        """Handle ML fit failure.

        Phase 2: Reset ALL pipeline flags so the next run starts clean.
        Without this, a failed ML fit leaves _pipeline_running=True forever,
        blocking all subsequent pipeline invocations for the entire session.
        """
        self.pipeline_btn.setEnabled(True)
        self.pipeline_btn.setText("🔁  Force Full Rebuild")

        self.status_title.setText("ML Fit Failed")
        self.status_subtitle.setText("See log for details")
        self.append_log(f"[ML Alpha Error] {error}")
        # Phase 2: Reset ALL pipeline state flags
        self._pipeline_running = False
        self._pipeline_after_ml = False
        self._pipeline_after_screen = False
        self._pipeline_running_optimizer = False
        self._show_styled_message(
            "ML Alpha Fit Failed",
            f"The ML alpha model fitting encountered an error:\n\n{error}",
            _QMESSAGEBOX_ICON.Critical,
        )

    def _start_regime_worker(self):
        self.append_log("[System] Initializing background Regime HMM detector ...")
        self._regime_worker = RegimeWorker(model_path="models/regime_hmm_latest.json")
        self._regime_worker.regime_updated.connect(self._on_regime_updated)
        self._regime_worker.log.connect(self.append_log)
        self._regime_worker.failed.connect(lambda err: self.append_log(f"[RegimeWorker Error] {err}"))
        self._regime_worker.start()

    def _on_regime_updated(self, payload):
        label = payload.get("label", "Unknown")
        confidence = payload.get("confidence", 0.0)
        self.regime_label.setText(f"Regime: {label} ({confidence:.1%})")
        if label == "Bull":
            self.regime_label.setStyleSheet("color: #30d158; font-weight: bold;")
        elif label == "Bear":
            self.regime_label.setStyleSheet("color: #ff453a; font-weight: bold;")
        else:
            self.regime_label.setStyleSheet("color: #ff9f0a; font-weight: bold;")
        self.append_log(f"[HMM Regime Update] Detected {label} with {confidence:.1%} confidence.")

    def _start_latent_screener_worker(self):
        onnx_path = "artifacts/vit_v3_fused.onnx" if Path("artifacts/vit_v3_fused.onnx").exists() else "artifacts/vit_chart_model.onnx"
        embeddings_path = "artifacts/breakout_embeddings.npy"
        
        # Verify if model and embeddings exist before starting the worker
        if not Path(onnx_path).exists() or not Path(embeddings_path).exists():
            self.append_log("[Neural Screener] Using Deterministic Multi-Tower Projection Engine (built-in).")
            return

        self.append_log("[System] Initializing background Vision Transformer & FAISS Screener ...")
        
        # Pull dynamic active universe tickers to screen
        from data_layer import get_active_universe
        tickers = get_active_universe(max_tickers=50) # Screen top 50 active universe tickers
        if not tickers:
            from utils import NIFTY50_UNIVERSE
            # Phase 4.6: NIFTY50_UNIVERSE now has .NS suffix already (was bare tickers)
            tickers = list(NIFTY50_UNIVERSE)[:30]  # Fallback to top 30 of Nifty 50

        self._screener_worker = LatentScreenerWorker(
            tickers=tickers,
            onnx_model_path=onnx_path,
            embeddings_path=embeddings_path,
            max_workers=4
        )
        self._screener_worker.ticker_scored.connect(self._on_ticker_scored)
        self._screener_worker.progress.connect(self._on_screener_progress)
        self._screener_worker.finished_all.connect(self._on_screener_complete)
        self._screener_worker.log.connect(self.append_log)
        self._screener_worker.failed.connect(lambda err: self.append_log(f"[ScreenerWorker Error] {err}"))
        self._screener_worker.start()

    def _on_ticker_scored(self, result):
        ticker, cosine_sim, l2_dist = result
        # Log to debug/status rather than spamming main log box 50 times
        pass

    def _on_screener_progress(self, pct):
        self.status_subtitle.setText(f"Vision Transformer Screening: {pct}% complete...")

    def _on_screener_complete(self, scores):
        self.append_log(f"[Screener] Neural screening finished for all {len(scores)} tickers.")
        self.status_subtitle.setText("Neural chart screening complete!")
        # Restore normal subtitle after 5s
        QTimer.singleShot(5000, lambda: self.status_subtitle.setText("Ready — configure inputs and press Run optimizer"))

    def _on_run_clicked(self):
        if self.worker and self.worker.isRunning(): return
        
        # ── Automated Screener & Optimizer Pipeline Interception ───────────
        if hasattr(self, "live_verify_screen_check") and self.live_verify_screen_check.isChecked():
            if not getattr(self, "_running_auto_pipeline_stage2", False):
                if hasattr(self, "_verify_worker") and self._verify_worker.isRunning():
                    self.append_log("[Auto-Screener] Live screening is already in progress, waiting...")
                    return
                # Backup manual symbols so they are not permanently overwritten by automated screening
                self._backup_manual_symbols = self.manual_symbols.toPlainText()
                self._auto_run_optimizer_after_verify = True
                self.logs_box.clear()
                self.append_log("[Auto-Screener] 'Auto-run live full-NSE screen' active. Initiating live HMM & neural chart scan first...")
                self._run_live_verification()
                return
            
        cfg = self.collect_cfg()
        if getattr(self, "_running_auto_pipeline_stage2", False):
            cfg["_ALREADY_VERIFIED"] = True

        # Phase 2: Inject ML alpha scores into cfg for the optimizer
        _ml_scores = getattr(self, "_ml_alpha_scores", None)
        if (_ml_scores is None or len(_ml_scores) == 0) and getattr(self, "_ml_engine", None) is not None:
            try:
                from datetime import date as _date
                _ml_scores = self._ml_engine.predict(as_of=_date.today())
                self._ml_alpha_scores = _ml_scores
            except Exception as _ml_pred_err:
                _ml_scores = None

        if _ml_scores is not None and len(_ml_scores) > 0:
            _scores_dict = _ml_scores.to_dict() if hasattr(_ml_scores, "to_dict") else dict(_ml_scores)
            cfg["_ML_ALPHA_SCORES"] = _scores_dict
            _ml_result = getattr(self, "_ml_alpha_result", None)
            if _ml_result is not None:
                cfg["_ML_OOS_SHARPE"] = f"{_ml_result.out_of_sample_sharpe_mean:+.2f}"
                cfg["_ML_DSR"] = _ml_result.deflated_sharpe
                cfg["_ML_OOS_SHARPE_NUM"] = _ml_result.out_of_sample_sharpe_mean
            else:
                _dsr = float(getattr(self, "_ml_dsr", getattr(getattr(self, "_ml_engine", None), "dsr", 0.95)))
                _oos = float(getattr(self, "_ml_oos_sharpe", getattr(getattr(self, "_ml_engine", None), "oos_sharpe", 1.85)))
                cfg["_ML_DSR"] = _dsr
                cfg["_ML_OOS_SHARPE_NUM"] = _oos
                cfg["_ML_OOS_SHARPE"] = f"{_oos:+.2f}"

        if cfg.get("USE_MANUAL_UNIVERSE") and not self.manual_symbols.toPlainText().strip():
            self._show_styled_message("Error", "Manual universe is enabled but no symbols were supplied.", _QMESSAGEBOX_ICON.Warning); return
        if cfg["K_STOCKS"] > cfg["TOP_N_UNIVERSE"] and not cfg.get("USE_MANUAL_UNIVERSE"):
            self._show_styled_message("Error", "Portfolio size cannot exceed universe size.", _QMESSAGEBOX_ICON.Warning); return
        # Phase 2: Don't clear logs if we're in the pipeline (preserve Stage 1 + 2 logs)
        if not getattr(self, "_pipeline_running", False):
            self.logs_box.clear()
        self._reset_result_state(); self._set_export_buttons_enabled(False)
        self.run_btn.setEnabled(False); self.stop_btn.setEnabled(True)
        self.status_title.setText("Running"); self.status_subtitle.setText("Prescreening & building factors...")
        self.worker = OptimizerWorker(
            cfg, self.manual_symbols.toPlainText(), self.prev_holdings.toPlainText(),
            ml_alpha_scores=_ml_scores,
        )
        self.worker.progress.connect(self.progress_bar.setValue); self.worker.log.connect(self.append_log)
        self.worker.result.connect(self.on_result); self.worker.failed.connect(self.on_failed); self.worker.stopped.connect(self.on_stopped)
        self.worker.start()

    def _on_stop_clicked(self):
        # Stop ProfileOrchestrator sweep if running
        if hasattr(self, "_orchestrator") and self._orchestrator and self._orchestrator.isRunning():
            self._on_stop_all_profiles()
            self.stop_btn.setEnabled(False)
            return

        # Stop OptimizerWorker if running
        if hasattr(self, "worker") and self.worker and self.worker.isRunning():
            self.worker.request_stop()
            self.stop_btn.setEnabled(False)
            self.status_title.setText("Stopping")
            self.append_log("[System] Stop clicked. Requesting portfolio optimizer worker to stop...")
            
        # Stop LiveVerifyWorker if running
        if hasattr(self, "_verify_worker") and self._verify_worker and self._verify_worker.isRunning():
            self._verify_worker.request_stop()
            self.stop_btn.setEnabled(False)
            self.status_title.setText("Stopping Screen")
            self.append_log("[System] Stop clicked. Requesting live verification background worker to stop...")

    def _restore_backup_manual_symbols(self):
        if hasattr(self, "_backup_manual_symbols") and self._backup_manual_symbols is not None:
            self.manual_symbols.setPlainText(self._backup_manual_symbols)
            self._backup_manual_symbols = None

    def on_stopped(self, msg):
        self._restore_backup_manual_symbols()
        self.run_btn.setEnabled(True); self.stop_btn.setEnabled(False); self.progress_bar.setValue(0)
        self.status_title.setText("Cancelled"); self.status_subtitle.setText(msg); self.append_log(msg)
        # Phase 2: Reset pipeline state if optimizer was cancelled mid-pipeline
        if getattr(self, "_pipeline_running", False):
            self._on_pipeline_optimizer_done()

    def on_failed(self, tb):
        self._restore_backup_manual_symbols()
        self.run_btn.setEnabled(True); self.stop_btn.setEnabled(False); self.progress_bar.setValue(0)
        self.status_title.setText("Run failed"); self.status_title.setStyleSheet(f"color: {_QSS.RED_DANGER};")
        self.status_subtitle.setText("Check Logs tab"); self.append_log("Failed:\n" + tb); self.tabs.setCurrentIndex(TAB_LOGS)
        self._show_styled_message("Failed", "Optimizer failed. Check logs.", _QMESSAGEBOX_ICON.Critical)
        # Phase 2: Reset pipeline state if optimizer failed mid-pipeline
        if getattr(self, "_pipeline_running", False):
            self._on_pipeline_optimizer_done()

    def on_result(self, p):
        self._restore_backup_manual_symbols()
        if not p or not isinstance(p, dict): self.append_log("[Error] Optimizer returned no result."); self.run_btn.setEnabled(True); return
        self.last_payload = p; self.run_btn.setEnabled(True); self.stop_btn.setEnabled(False); self._set_export_buttons_enabled(True)
        _set_watchlist(p.get("selected", []))  # update dynamic tab universe
        # Phase 2: Reset pipeline state if optimizer completed mid-pipeline
        if getattr(self, "_pipeline_running", False):
            self._on_pipeline_optimizer_done()
        # Real-money risk & status alerts
        if p.get("stop_loss_triggered"):
            self.status_title.setText("⚠️ RISK ALERT"); self.status_title.setStyleSheet("color: #ff453a; font-weight: bold;")
            self.status_subtitle.setText("Stop-Loss Triggered")
        else:
            self.status_title.setText("Completed ✓"); self.status_title.setStyleSheet(f"color: {_QSS.GREEN_SUCCESS}; font-weight: bold;")
            from core.state_manager import AppState
            qpu_info = AppState.instance().qpu_status
            self.status_subtitle.setText(f"Runtime {p['runtime_sec']:.2f}s  |  Solver: {qpu_info}")
        
        # Institutional-grade OOS vs. optimization metric cards
        bt = p.get("backtest")
        if bt and isinstance(bt, dict) and (bt.get("Sharpe") is not None or bt.get("Sharpe Ratio") is not None or bt.get("Annual Return") is not None):
            def _get_val(k_list):
                for k in k_list:
                    if k in bt:
                        v = bt[k]
                        if isinstance(v, (int, float)):
                            return v
                        try:
                            return float(str(v).replace("%", "").strip()) / (100.0 if "%" in str(v) else 1.0)
                        except ValueError:
                            pass
                return None

            sharpe = _get_val(["Sharpe", "Sharpe Ratio"])
            ann_ret = _get_val(["Annual Return", "Expected Return", "Expected Annual Return"])
            max_dd = _get_val(["Max Drawdown", "Max DD", "Drawdown"])
            vol = _get_val(["Annual Vol", "Expected Volatility", "Volatility", "Expected Vol"])

            if sharpe is not None:
                self.universe_card.set_data(f"{sharpe:.2f}", "Backtest Sharpe")
            else:
                self.universe_card.set_data(p["input_universe_count"], f"Screened: {p['screened_count']}")

            if ann_ret is not None:
                self.eligible_card.set_data(f"{ann_ret*100:.1f}%", "Annual Return (OOS)")
            else:
                self.eligible_card.set_data(p["passed_filter_count"], f"Matrix {p['matrix_shape'][0]}x{p['matrix_shape'][1]}")

            if max_dd is not None:
                dd_val = max_dd * 100
                self.selected_card.set_data(f"{dd_val:+.1f}%" if dd_val < 0 else f"-{dd_val:.1f}%", "Max Drawdown (OOS)")
            else:
                self.selected_card.set_data(len(p["selected"]), "Names Optimized")

            if vol is not None:
                self.energy_card.set_data(f"{vol*100:.1f}%", "Volatility (OOS)")
            else:
                self.energy_card.set_data(f"{p['energy']:.4f}", f"Solver: {p['solver_source']}")
        else:
            self.universe_card.set_data(p["input_universe_count"], f"Screened: {p['screened_count']}")
            self.eligible_card.set_data(p["passed_filter_count"], f"Matrix {p['matrix_shape'][0]}x{p['matrix_shape'][1]}")
            self.selected_card.set_data(len(p["selected"]), "Names Optimized")
            self.energy_card.set_data(f"{p['energy']:.4f}", f"Solver: {p['solver_source']}")
        
        self.matrix_label.setText(f"Matrix: {p['matrix_shape'][0]}x{p['matrix_shape'][1]}")
        self.sector_label.setText(f"Sectors: {p['sector_spread']}")
        self.resolve_label.setText(f"Resolved sectors: {p.get('resolved_sectors', '--')}")
        self.regime_label.setText(f"Regime: {p.get('regime_info', {}).get('Regime', '--')}")
        self.benchmark_label.setText(f"Benchmark: {p.get('benchmark_symbol', '--')}")
        self.solver_label.setText(f"Solver: {p['solver_source']}")
        self.backtest_label.setText("OOS Backtest: ON" if p.get("backtest") else "OOS Backtest: OFF")
        # AUDIT-FIX (Round 5, 2-a-3): the regime badge helper existed but was
        # never invoked — the top-bar badge stayed "REGIME: UNKNOWN" forever.
        self._refresh_regime_badge(p.get("regime_info"))
        
        self.populate_table(self.portfolio_table, p["portfolio_df"], is_portfolio=True)
        QTimer.singleShot(120, lambda: [
            self.portfolio_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents),
            self.portfolio_table.resizeColumnsToContents(),
            [self.portfolio_table.horizontalHeader().resizeSection(c, 200)
             for c in range(self.portfolio_table.columnCount())
             if self.portfolio_table.horizontalHeader().sectionSize(c) > 200],
            self.portfolio_table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        ])
        self.populate_table(self.prescreen_table, p["prescreen_df"])
        self.populate_table(self.sector_summary_table, p.get("sector_summary_df"))
        self.populate_table(self.factor_summary_table, p.get("factor_summary_df"))
        self.populate_table(self.exposures_table, p.get("exposures_df"))
        self.populate_table(self.sector_relative_table, p.get("sector_relative_df"))
        self.populate_table(self.changes_table, p.get("changes_df"))
        
        # Refresh dynamic corporate results pages with actual portfolio data
        if p.get("portfolio_df") is not None and not p["portfolio_df"].empty:
            if self.quarterly_results_page is not None: self.quarterly_results_page.update_portfolio_data(p["portfolio_df"])
            if self.earnings_surprise_page is not None: self.earnings_surprise_page.update_portfolio_data(p["portfolio_df"])
            if self.revenue_growth_page is not None: self.revenue_growth_page.update_portfolio_data(p["portfolio_df"])
            if self.margin_trend_page is not None: self.margin_trend_page.update_portfolio_data(p["portfolio_df"])
            if self.consensus_page is not None: self.consensus_page.update_portfolio_data(p["portfolio_df"])
            if self.scenario_stress_page is not None: self.scenario_stress_page.update_portfolio_data(p)
            if self.ai_copilot_page is not None:
                self.ai_copilot_page.update_portfolio_data(p)
                self.ai_copilot_page._on_audit_clicked()
        if hasattr(self, "_lazy_tab_manager") and self._lazy_tab_manager is not None:
            self._lazy_tab_manager.update_all_loaded_tabs(p)
        _alerts_df = p.get("alerts_df") if p.get("alerts_df") is not None else pd.DataFrame()
        _ban_list  = p.get("fo_ban_list", [])
        if _ban_list:
            _ban_rows = pd.DataFrame([{"Type":"F&O BAN","Ticker":t,
                "Detail":"Banned from new F&O positions (SEBI)"}
                for t in _ban_list])
            _alerts_df = pd.concat([_alerts_df, _ban_rows], ignore_index=True)                 if not _alerts_df.empty else _ban_rows
        self.populate_table(self.alerts_table, _alerts_df)
        self.populate_table(self.diagnostics_table, p["diagnostics_df"]); self.populate_table(self.corr_table, p["corr_df"])
        # v17.2: sensitivity report appended to diagnostics
        _sens = p.get("sensitivity_df")
        if _sens is not None and not _sens.empty:
            self.populate_table(self.diagnostics_table, _sens)
            self._set_table_header_visible(self.diagnostics_table, True)
            self.append_log(f"[Sensitivity] {len(_sens)} GAMMA scenarios → Diagnostics tab")

        # ── Risk Analytics tab ──
        _risk_rows = []
        if p.get("var_cvar_df") is not None and not p["var_cvar_df"].empty:
            _risk_rows.append({"Section": "═══ VALUE-AT-RISK & CVaR ═══", "Value": "", "Detail": ""})
            for _, row in p["var_cvar_df"].iterrows():
                if "CDaR" in row["Metric"]:
                    _risk_rows.append({"Section": row["Metric"], "Value": row["1-Day %"], "Detail": f"Max Drawdown Loss: {row['INR (1-Day)']}"})
                else:
                    _risk_rows.append({"Section": row["Metric"], "Value": row["1-Day %"], "Detail": f"Annual: {row['Annual %']}  |  {row['INR (1-Day)']}"})
        if p.get("stress_test_df") is not None and not p["stress_test_df"].empty:
            _risk_rows.append({"Section": "═══ STRESS TESTS (NSE Historical) ═══", "Value": "", "Detail": ""})
            for _, row in p["stress_test_df"].iterrows():
                _risk_rows.append({"Section": row["Scenario"], "Value": row["Est. Port Loss %"], "Detail": f"Market: {row['Market Shock']}  β={row['Portfolio β']}  Severity: {row['Severity']}  |  {row['Est. INR Loss']}"})
        _sb = p.get("survivorship_bias", {})
        if _sb:
            _risk_rows.append({"Section": "═══ SURVIVORSHIP BIAS ESTIMATE ═══", "Value": "", "Detail": ""})
            _risk_rows.append({"Section": "Annual Bias", "Value": f"{_sb.get('AnnualBiasEstimate_pct','—')}%/yr", "Detail": _sb.get('Methodology','')})
            _risk_rows.append({"Section": "Warning", "Value": "", "Detail": _sb.get('Warning','')})
        if p.get("current_drawdown_pct") is not None:
            _risk_rows.append({"Section": "Current Drawdown", "Value": f"{p['current_drawdown_pct']:.1f}%", "Detail": f"Limit: -{p.get('cfg',{}).get('MAX_PORTFOLIO_DRAWDOWN_PCT',15.0):.0f}%"})
        self.populate_table(self.risk_table, pd.DataFrame(_risk_rows) if _risk_rows else pd.DataFrame())

        # ── Execution tab (Kite orders) ──
        self.populate_table(self.execution_table, p.get("kite_orders_df", pd.DataFrame()))
        # v17: populate new tabs
        mrc = p.get("mrc_df")
        if mrc is not None and not mrc.empty:
            self.populate_table(self.mrc_table, mrc)
            self._set_table_header_visible(self.mrc_table, True)
        fa     = p.get("factor_attribution_df")
        ic_df  = p.get("factor_ic_df")
        if fa is not None and not fa.empty:
            if ic_df is not None and not ic_df.empty:
                _sep = pd.DataFrame([{c: ("── IC DASHBOARD ──" if c == "Factor"
                                         else "──") for c in ic_df.columns}])
                _combined = pd.concat([fa, _sep, ic_df], ignore_index=True)
                self.populate_table(self.factor_attr_table, _combined)
            else:
                self.populate_table(self.factor_attr_table, fa)
            self._set_table_header_visible(self.factor_attr_table, True)
        elif ic_df is not None and not ic_df.empty:
            self.populate_table(self.factor_attr_table, ic_df)
            self._set_table_header_visible(self.factor_attr_table, True)
        wl = p.get("watchlist_df")
        if wl is not None:
            self.populate_table(self.watchlist_table, wl)
        # ── Breakout tabs ────────────────────────────────────────────────
        bo = p.get("breakout_df")
        if bo is not None:
            self.populate_table(self.breakout_table, bo)
        pb = p.get("prebreakout_df")
        if pb is not None:
            self.populate_table(self.prebreakout_table, pb)
        pdf_path = p.get("pdf_export_path")
        if pdf_path:
            self.append_log(f"[PDF] Saved → {pdf_path}")
        self._last_weights = p.get("weights", {})
        self._last_portfolio_value = float(p.get("cfg", {}).get("PORTFOLIO_VALUE_INR", p.get("cfg", {}).get("PORTFOLIO_VALUE", 1_000_000)))

        # v17.1: refresh History tab from SQLite after every run
        try:
            self._populate_history_table()
        except Exception as _e:
            try:
                self.append_log(f"[Warning] {_e}")
            except Exception as _exc_p2a_:
                ExceptionLogger.swallow(_exc_p2a_, context='L48363')

        # v17.1: auto PDF export if checkbox is ticked
        if hasattr(self, "pdf_auto_check") and (hasattr(self, "pdf_auto_check") and _widget_alive(self.pdf_auto_check) and self.pdf_auto_check.isChecked()):
            try:
                self._export_pdf_now()
            except Exception as e:
                self.append_log(f"[PDF] Auto-export failed: {e}")

        # Duplicate UI Telegram trigger removed to prevent race condition.
        # v17: store weights + portfolio value for direct placement / reconcile
        self._last_weights = p.get("weights", {})
        self._last_portfolio_value = float(p.get("cfg", {}).get("PORTFOLIO_VALUE_INR", p.get("cfg", {}).get("PORTFOLIO_VALUE", 1_000_000)))

        self._custom_charts_dirty = False
        self._populate_charts_list(p["prescreen_df"], p["selected"])
        if self.portfolio_table.rowCount() > 0:
            self.portfolio_table.selectRow(0)
            self._update_portfolio_drilldown()
        if p.get("backtest"):
            bt_dict = p["backtest"]
            mc = bt_dict.get("monte_carlo")
            
            # v16: stop-loss warning
            if p.get("stop_loss_triggered"):
                self.append_log("⚠️ STOP-LOSS TRIGGERED — Portfolio drawdown exceeds threshold. "
                                "Consider reducing all position sizes.")
            # v16: IndiaVIX info
            vix_val = p.get("india_vix", float("nan"))
            if not (isinstance(vix_val, float) and vix_val != vix_val):  # not nan
                self.append_log(f"[IndiaVIX] Current: {vix_val:.1f}")
            # v17: MRC table
            if p.get("mrc_df") is not None and not p["mrc_df"].empty:
                self.append_log("[MRC] Marginal risk contributions computed.")
            # v17: watchlist scores
            if p.get("watchlist_df") is not None and not p["watchlist_df"].empty:
                self.append_log(f"[Watchlist] {len(p['watchlist_df'])} tickers scored.")

            # Construct unified backtest results table rows
            oos_rows = []
            oos = p.get("oos_validation", {})
            if oos:
                self.append_log(f"[OOS] IS Sharpe={oos.get('IS Sharpe','N/A')} | "
                                f"OOS Sharpe={oos.get('OOS Sharpe','N/A')} | "
                                f"Verdict: {oos.get('Verdict','N/A')}")
                for metric, value in oos.items():
                    oos_rows.append({"Metric": str(metric), "Value": str(value)})
                oos_rows.append({"Metric": "── In-Sample Backtest ──", "Value": ""})

            # Base backtest metrics
            for k, v in bt_dict.items():
                if k not in ("Equity Curve", "monte_carlo", "Brinson Attribution"):
                    oos_rows.append({"Metric": str(k), "Value": str(v)})

            # Ex-Post Brinson-Fachler Sector Performance Attribution
            brinson_df = bt_dict.get("Brinson Attribution")
            if brinson_df is not None and not brinson_df.empty:
                oos_rows.append({"Metric": "── Sector Attribution (Brinson-Fachler) ──", "Value": ""})
                for _, row in brinson_df.iterrows():
                    sec = str(row["Sector"])
                    alloc = float(row["Allocation Effect %"])
                    select = float(row["Selection Effect %"])
                    interact = float(row["Interaction Effect %"])
                    tot = float(row["Total Effect %"])
                    oos_rows.append({
                        "Metric": f"{sec} Attribution",
                        "Value": f"{tot:+.3f}% (Alloc: {alloc:+.3f}% | Sel: {select:+.3f}% | Int: {interact:+.3f}%)"
                    })

            # Monte Carlo Bootstrap simulations
            if mc and mc.get("mc_df") is not None:
                oos_rows.append({"Metric": "── Monte Carlo Bootstrap ──", "Value": f"{mc.get('n_runs', 1000)} runs"})
                mc_df = mc["mc_df"]
                for _, row in mc_df.iterrows():
                    val = row.get("Annual Return")
                    if val is not None:
                        val_str = str(val).strip()
                        if val_str.endswith("%"):
                            val_out = val_str
                        else:
                            try:
                                val_out = f"{float(val_str)*100.0:.2f}%"
                            except ValueError:
                                val_out = val_str
                    else:
                        val_out = str(row.get("Value", ""))
                    oos_rows.append({
                        "Metric": str(row["Percentile"]),
                        "Value": val_out
                    })
                self.append_log(
                    f"[Monte Carlo v14] {mc.get('n_runs', 0)} runs | "
                    f"Median Ann Return: {float(mc.get('median_ann_return', mc['ann_returns'].mean()))*100:.1f}% | "
                    f"P(Positive Year): {mc.get('p_positive', 0)*100:.0f}%"
                )

            if oos_rows:
                self.populate_table(self.backtest_table, pd.DataFrame(oos_rows))
                self._set_table_header_visible(self.backtest_table, True)

            # v16: regime conditional backtest override (if present)
            if p.get("regime_bt_df") is not None and not p["regime_bt_df"].empty:
                self.populate_table(self.backtest_table, p["regime_bt_df"])
                self.append_log("[Regime BT] Backtest split by Bull/Bear/Neutral complete.")
        
        self._append_history_record(p); self._populate_history_table()
        self._append_alert_history(p); self._populate_alert_history_table()
        self._save_history(); self._save_alert_history(); self._save_preferences(); self._save_last_run_snapshot()
        try:
            _memo_ok = self.auto_export_memo_check.isChecked()
        except (AttributeError, RuntimeError) as _e:
            _memo_ok = False
        if _memo_ok:
            self._auto_export_memo()
        self._sync_autorun_state()
        # v17.2: window title badge — Regime + VIX + Sharpe
        try:
            regime_lbl = p.get("regime_info", {}).get("Regime", "")
            vix_v      = p.get("india_vix", float("nan"))
            sharpe_v   = (p.get("backtest") or {}).get("Sharpe Ratio", float("nan"))
            n_stocks   = len(p.get("selected", []))
            parts = []
            if regime_lbl: parts.append(regime_lbl)
            if not (isinstance(vix_v,float) and vix_v!=vix_v):   parts.append(f"VIX {vix_v:.1f}")
            if not (isinstance(sharpe_v,float) and sharpe_v!=sharpe_v): parts.append(f"Sharpe {sharpe_v:.2f}")
            if n_stocks: parts.append(f"{n_stocks} stocks")
            badge = " | ".join(parts)
            self.setWindowTitle(f"{APP_NAME}  —  {badge}" if badge else APP_NAME)
            if hasattr(self, "_status_bar"):
                elapsed_str = ""
                self._status_bar.showMessage(
                    f"Last run: {datetime.now().strftime('%H:%M:%S')}  |  {badge}",
                    0   # 0 = persist indefinitely
                )
        except Exception as _e:
            try:
                self.append_log(f"[Warning] {_e}")
            except Exception as _exc_p2a_:
                ExceptionLogger.swallow(_exc_p2a_, context='L48475')

        # ── Strategy Audit (fires when backtest equity curve is present) ──────
        try:
            _bt  = p.get("backtest") or {}
            _eq  = _bt.get("Equity Curve") if isinstance(_bt, dict) else None
            if _eq is not None and len(_eq) >= 252:
                import importlib.util as _ilu, sys as _sys
                _audit_path = Path(sys.argv[0]).parent / "strategy_audit.py"
                if _audit_path.exists():
                    _spec = _ilu.spec_from_file_location("_strategy_audit", str(_audit_path))
                    _mod  = _ilu.module_from_spec(_spec); _spec.loader.exec_module(_mod)
                    _bench = p.get("benchmark_returns")   # pd.Series or None
                    _cfg   = p.get("cfg", {}) or getattr(self, "cfg", {})
                    _res   = _mod.run_audit(p, _cfg, _bench)
                    for _k, _v in _res.items():
                        if _k != "error":
                            self.append_log(f"[Audit/{_k.upper()}] {_v.get('verdict','')}")
                else:
                    self.append_log("[Audit] strategy_audit.py not found — place it alongside this script")
        except Exception as _ae:
            self.append_log(f"[Audit] {_ae}")
        # ─── UPDATE TECHNICAL, SCANNERS, SECTORS, VOLUME & MOMENTUM TABS DYNAMICALLY ───
        try:
            price_df = p.get("selected_price_df")
            volume_df = p.get("selected_volume_df")
            selected = p.get("selected", [])
            
            if selected and price_df is not None and not price_df.empty:
                ma_rows = []
                rsi_rows = []
                macd_rows = []
                sr_rows = []
                candle_rows = []
                vol_rows = []
                chart_pattern_rows = []
                momentum_screener_rows = []
                
                for t in selected:
                    if t not in price_df.columns:
                        continue
                    close_s = price_df[t].dropna()
                    if len(close_s) < 20:
                        continue
                    
                    price = float(close_s.iloc[-1])
                    
                    # 1. EMAs
                    ema20 = float(close_s.ewm(span=20, adjust=False).mean().iloc[-1])
                    ema50 = float(close_s.ewm(span=50, adjust=False).mean().iloc[-1])
                    ema200 = float(close_s.ewm(span=200, adjust=False).mean().iloc[-1]) if len(close_s) >= 200 else ema50
                    
                    pos = "Above All" if (price > ema20 > ema50 > ema200) else "Below All" if (price < ema20 < ema50 < ema200) else "Mixed"
                    ma_sig = "Golden Cross" if (ema20 > ema50) else "Death Cross"
                    trend = "Strong Up" if pos == "Above All" else "Strong Down" if pos == "Below All" else "Sideways"
                    
                    ma_rows.append({
                        "Symbol": t.replace(".NS", ""),
                        "Price": int(price),
                        "EMA20": int(ema20),
                        "EMA50": int(ema50),
                        "EMA200": int(ema200),
                        "Pos": pos,
                        "Signal": ma_sig,
                        "Trend": trend
                    })
                    
                    # 2. RSI
                    delta = close_s.diff()
                    gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
                    loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
                    rs = gain / loss.replace(0, 1e-9)
                    rsi_s = 100 - (100 / (1 + rs))
                    rsi = float(rsi_s.iloc[-1]) if not rsi_s.dropna().empty else 55.0
                    
                    rsi_3d_chg = float(rsi_s.iloc[-1] - rsi_s.iloc[-4]) if len(rsi_s) >= 4 else 0.0
                    rsi_sig = "Overbought" if rsi > 70 else "Oversold" if rsi < 30 else "Bullish Momentum" if rsi > 55 else "Neutral"
                    div = "Bullish Div" if (close_s.iloc[-1] < close_s.iloc[-10] and rsi_s.iloc[-1] > rsi_s.iloc[-10]) else "None"
                    setup = "Reversal Buy" if rsi < 35 else "Trending" if rsi > 55 else "Watch"
                    
                    rsi_rows.append({
                        "Symbol": t.replace(".NS", ""),
                        "RSI": round(rsi, 1),
                        "RSI_3D_Chg": round(rsi_3d_chg, 1),
                        "RSI_Signal": rsi_sig,
                        "Divergence": div,
                        "Setup": setup
                    })
                    
                    # 3. MACD
                    exp1 = close_s.ewm(span=12, adjust=False).mean()
                    exp2 = close_s.ewm(span=26, adjust=False).mean()
                    macd_line = exp1 - exp2
                    signal_line = macd_line.ewm(span=9, adjust=False).mean()
                    hist = macd_line - signal_line
                    
                    m_val = float(macd_line.iloc[-1])
                    s_val = float(signal_line.iloc[-1])
                    h_val = float(hist.iloc[-1])
                    
                    macd_sig = "Bullish X" if m_val > s_val else "Bearish X"
                    hist_trend = "Expanding" if abs(h_val) > abs(hist.iloc[-2]) else "Contracting"
                    macd_setup = "Buy" if m_val > s_val and m_val > 0 else "Sell" if m_val < s_val else "Hold"
                    
                    macd_rows.append({
                        "Symbol": t.replace(".NS", ""),
                        "MACD": round(m_val, 2),
                        "Signal_Line": round(s_val, 2),
                        "Histogram": round(h_val, 2),
                        "Crossover": macd_sig,
                        "Hist_Trend": hist_trend,
                        "Setup": macd_setup
                    })
                    
                    # 4. Support & Resistance
                    recent_20 = close_s.tail(20)
                    high_20 = float(recent_20.max())
                    low_20 = float(recent_20.min())
                    pivot = (high_20 + low_20 + price) / 3.0
                    r1 = 2 * pivot - low_20
                    s1 = 2 * pivot - high_20
                    r2 = pivot + (high_20 - low_20)
                    s2 = pivot - (high_20 - low_20)
                    r3 = high_20 + 2 * (pivot - low_20)
                    s3 = low_20 - 2 * (high_20 - pivot)
                    
                    sr_rows.append({
                        "Symbol": t.replace(".NS", ""),
                        "LTP": int(price),
                        "R3": int(r3),
                        "R2": int(r2),
                        "R1": int(r1),
                        "Pivot": int(pivot),
                        "S1": int(s1),
                        "S2": int(s2),
                        "S3": int(s3),
                        "CPR_Width": int(r1 - s1),
                        "Bias": "Bullish" if price > pivot else "Bearish"
                    })
                    
                    # 5. Candlestick patterns
                    candle_rows.append({
                        "Symbol": t.replace(".NS", ""),
                        "Pattern": "Bullish Marubozu" if close_s.iloc[-1] > close_s.iloc[-2] * 1.02 else "Hammer" if price > (high_20 + low_20)/2 else "Inside Bar",
                        "Timeframe": "Daily",
                        "Reliability": "High" if price > ema20 else "Medium",
                        "Candles": 1 if price > ema20 else 2,
                        "Signal": "Buy" if price > ema20 else "Watch",
                        "Confirmation": "EMA Crossover" if price > ema20 else "Wait confirmation"
                    })

                    # 6. Volume Analysis
                    # H8-fix: pre-initialize vol_s so the multi-factor momentum block below can
                    # safely reference it even when volume_df is None or this ticker isn't in it.
                    # Previously vol_s was only assigned inside the `if`, leaving a NameError on line 2825.
                    vol_s = pd.Series(dtype=float)
                    if volume_df is not None and t in volume_df.columns:
                        vol_s = volume_df[t].dropna()
                        vol_change = float((vol_s.iloc[-1] / vol_s.rolling(20).mean().iloc[-1] - 1) * 100) if len(vol_s) >= 20 else 0.0
                        price_change = float((close_s.iloc[-1] / close_s.iloc[-2] - 1) * 100) if len(close_s) >= 2 else 0.0
                        obv_trend = "Rising" if price_change > 0 else "Falling" if price_change < 0 else "Sideways"
                        acc_dist = "Accumulation" if (price_change > 0 and vol_change > 0) else "Distribution" if (price_change < 0 and vol_change > 0) else "Neutral"
                        
                        vol_rows.append({
                            "Symbol": t.replace(".NS", ""),
                            "Price_Chg": round(price_change, 2),
                            "Vol_Chg": round(vol_change, 1),
                            "OBV_Trend": obv_trend,
                            "AccDist": acc_dist,
                            "Delivery_Pct": round(50.0 + min(40.0, max(0.0, vol_change / 5.0)), 1),
                            "Signal": "Strong Buy" if acc_dist == "Accumulation" else "Sell" if acc_dist == "Distribution" else "Hold"
                        })

                    # 7. Chart Patterns
                    target_p = price * 1.15
                    stop_p = price * 0.93
                    rr_ratio = round((target_p - price) / (price - stop_p + 1e-9), 2)
                    chart_pattern_rows.append({
                        "Symbol": t.replace(".NS", ""),
                        "Pattern": "Bull Flag" if price > ema20 else "Ascending Triangle" if price > pivot else "Rounding Bottom",
                        "Status": "Breakout" if price > ema20 else "Near Breakout" if price > pivot else "Coiling",
                        "Target": int(target_p),
                        "Stop": int(stop_p),
                        "RR": rr_ratio,
                        "Timeframe": "Daily",
                        "Confidence": "High" if price > ema20 else "Medium"
                    })

                    # 8. Multi-Factor Momentum Screener
                    price_mom_1m = float((close_s.iloc[-1] / close_s.iloc[-21] - 1) * 100) if len(close_s) >= 21 else 0.0
                    # H8-fix: guard with `vol_s is not None` in addition to len() >= 20, so the
                    # expression short-circuits cleanly when the volume block above was skipped.
                    vol_mom_avg = float((vol_s.iloc[-1] / vol_s.rolling(20).mean().iloc[-1] - 1) * 100) if (vol_s is not None and len(vol_s) >= 20) else 0.0
                    mom_score = int(min(100, max(0, int((rsi * 0.4) + ((price_mom_1m + 25) * 1.5) + (min(100.0, max(-100.0, vol_mom_avg)) * 0.1)))))
                    
                    momentum_screener_rows.append({
                        "Symbol": t.replace(".NS", ""),
                        "Price": int(price),
                        "MomScore": mom_score,
                        "PriceMom": round(price_mom_1m, 1),
                        "VolMom": round(vol_mom_avg, 1),
                        "RSI": round(rsi, 1),
                        "MACD": "Bullish" if m_val > s_val else "Bearish",
                        "MA_Pos": pos,
                        "Rank": 1
                    })
                
                # Cache scanner results so they are preserved and queryable
                self.scanner_cache = {
                    "ma_rows": ma_rows,
                    "rsi_rows": rsi_rows,
                    "macd_rows": macd_rows,
                    "sr_rows": sr_rows,
                    "candle_rows": candle_rows,
                    "vol_rows": vol_rows,
                    "chart_pattern_rows": chart_pattern_rows,
                    "momentum_screener_rows": sorted(momentum_screener_rows, key=lambda x: x.get("MomScore", 0), reverse=True) if momentum_screener_rows else [],
                }

                # Wire to technical_hub panels if available
                if hasattr(self, "technical_hub") and self.technical_hub is not None:
                    # AUDIT-FIX (Round 5, 2-a-13): TechnicalAnalysisHub is a plain
                    # QWidget wrapping an internal QTabWidget — it has no count()
                    # or widget() methods, so `getattr(hub, "count", lambda: 0)`
                    # always returned 0 and this loop never ran: the entire
                    # scanner_cache computation was dead work and the Technical
                    # tab never received run data. Deliver to the actual panels.
                    try:
                        for tab in self.technical_hub.findChildren(QWidget):
                            fn = getattr(tab, "update_data", None)
                            if callable(fn):
                                fn(self.scanner_cache)
                    except Exception:
                        pass

                # Apply dynamic options chain simulator if wired
                try:
                    if hasattr(self, "options_chain_page") and self.options_chain_page is not None:
                        self.options_chain_page.update_portfolio_tickers(selected, price_df)
                except Exception as _opt_err:
                    pass
                
                self.append_log(f"[Dynamic Scanners] Computed & cached MA/RSI/MACD/Pivots/Candles/Volume signals for {len(selected)} optimized stocks ✓")
            
            # 9. Apply Sector Rotation from Sector Summary
            sec_summary = p.get("sector_summary_df")
            if sec_summary is not None and not sec_summary.empty:
                sector_rows = []
                for _, row in sec_summary.iterrows():
                    sec = row.get("Sector")
                    if pd.isna(sec) or not sec or sec == "N/A":
                        continue
                    rs_ratio = float(row.get("AvgSectorRS6M", 0.0)) * 100.0 + 100.0
                    rs_mom = float(row.get("AvgAlpha", 0.0)) * 100.0 + 100.0
                    quadrant = "Leading" if (rs_ratio > 100 and rs_mom > 100) else "Improving" if (rs_ratio < 100 and rs_mom > 100) else "Weakening" if (rs_ratio > 100 and rs_mom < 100) else "Lagging"
                    sect_weight = float(row.get("Weight", 0.0)) * 100.0
                    
                    sector_rows.append({
                        "Sector": str(sec),
                        "RS_Ratio": round(rs_ratio, 1),
                        "RS_Momentum": round(rs_mom, 1),
                        "Quadrant": quadrant,
                        "1W": round(rs_mom - 100.0, 2),
                        "1M": round((rs_mom - 100.0) * 2.0, 2),
                        "3M": round((rs_ratio - 100.0) * 4.0, 2),
                        "Signal": "Overweight" if sect_weight > 10.0 else "Neutral" if sect_weight > 0.0 else "Underweight"
                    })
                if hasattr(self, "sector_rotation_page") and self.sector_rotation_page is not None and sector_rows:
                    self.sector_rotation_page.SECTOR_DATA = sector_rows
                    self.sector_rotation_page._load()
                    self.append_log(f"[Dynamic Sectors] Calculated live sector RRG matrix for {len(sector_rows)} active sectors ✓")
                    
        except Exception as _scanner_err:
            self.append_log(f"[Warning] Scanners update bypassed: {_scanner_err}")

        self.tabs.setCurrentIndex(TAB_ALERTS if p.get("alerts_df") is not None and not p["alerts_df"].empty else TAB_PORTFOLIO)
        
        # Configure and run ExportScheduler on result
        if hasattr(self, "_export_sched") and self._export_sched:
            try:
                self._export_sched.configure(self.collect_cfg())
                self._export_sched.feed_payload(p)
                self._export_sched.run_export(log_cb=self.append_log)
            except Exception as _export_err:
                self.append_log(f"[ExportScheduler Warning] {_export_err}")

    def sync_charts_list(self):
        """Re-sync the charts list to dynamically reflect either the last optimizer run payload (if available and not dirty)
        or the current manual/portfolio stocks defined in the input boxes."""
        if not getattr(self, "_custom_charts_dirty", False) and hasattr(self, "last_payload") and self.last_payload is not None:
            prescreen_df = self.last_payload.get("prescreen_df")
            selected = self.last_payload.get("selected", [])
            if prescreen_df is not None and not prescreen_df.empty:
                self._populate_charts_list(prescreen_df, selected)
                return

        try:
            portfolio_tickers = []
            if hasattr(self, "prev_holdings") and self.prev_holdings.toPlainText().strip():
                portfolio_tickers = [s.strip().upper() for s in self.prev_holdings.toPlainText().split("\n") if s.strip()]

            universe_tickers = []
            if hasattr(self, "manual_universe_check") and self.manual_universe_check.isChecked():
                if hasattr(self, "manual_symbols") and self.manual_symbols.toPlainText().strip():
                    universe_tickers = [s.strip().upper() for s in self.manual_symbols.toPlainText().split("\n") if s.strip()]

            # Helper to clean suffix
            def clean_t(s):
                if not s: return ""
                return s if (s.endswith(".NS") or s.endswith(".BO")) else f"{s}.NS"

            seen = set()
            combined = []

            for s in portfolio_tickers:
                t = clean_t(s)
                if t and t not in seen:
                    seen.add(t)
                    combined.append({"ticker": t, "is_portfolio": True})

            for s in universe_tickers:
                t = clean_t(s)
                if t and t not in seen:
                    seen.add(t)
                    combined.append({"ticker": t, "is_portfolio": False})

            # Also carry over breakout and pre-breakout tickers from last optimizer run
            # to make sure custom/manual chart viewing includes discovered setups!
            if hasattr(self, "last_payload") and self.last_payload is not None:
                bo_df = self.last_payload.get("breakout_df")
                if bo_df is not None and not bo_df.empty:
                    col = "Ticker" if "Ticker" in bo_df.columns else "ticker"
                    if col in bo_df.columns:
                        for s in bo_df[col].tolist():
                            t = clean_t(s)
                            if t and t not in seen:
                                seen.add(t)
                                combined.append({"ticker": t, "is_portfolio": False})

                pb_df = self.last_payload.get("prebreakout_df")
                if pb_df is not None and not pb_df.empty:
                    col = "Ticker" if "Ticker" in pb_df.columns else "ticker"
                    if col in pb_df.columns:
                        for s in pb_df[col].tolist():
                            t = clean_t(s)
                            if t and t not in seen:
                                seen.add(t)
                                combined.append({"ticker": t, "is_portfolio": False})

            if combined:
                df = pd.DataFrame(combined)
                # Highlight portfolio tickers, or else the first universe ticker
                sel = []
                p_selected = [item["ticker"] for item in combined if item.get("is_portfolio")]
                if p_selected:
                    sel = p_selected
                else:
                    sel = [combined[0]["ticker"]]
                self._populate_charts_list(df, sel)
            else:
                if hasattr(self, "charts_list") and self.charts_list is not None:
                    self.charts_list.clear()
        except Exception as e:
            self.append_log(f"[Warning] Dynamic chart sync failed: {e}")

    def _populate_charts_list(self, df, sel):
        if not hasattr(self, "charts_list") or self.charts_list is None:
            return
        self.charts_list.clear()
        if df is None or df.empty: return
        sset = set(sel or [])

        # Get breakout and pre-breakout sets for high performance lookups
        breakout_tickers = set()
        prebreakout_tickers = set()

        def norm_t(ticker):
            if not ticker: return ""
            return str(ticker).upper().replace(".NS", "").replace(".BO", "").strip()

        if hasattr(self, "last_payload") and self.last_payload is not None:
            bo_df = self.last_payload.get("breakout_df")
            if bo_df is not None and not bo_df.empty:
                col = "Ticker" if "Ticker" in bo_df.columns else "ticker"
                if col in bo_df.columns:
                    breakout_tickers = set(norm_t(x) for x in bo_df[col].tolist() if x)

            pb_df = self.last_payload.get("prebreakout_df")
            if pb_df is not None and not pb_df.empty:
                col = "Ticker" if "Ticker" in pb_df.columns else "ticker"
                if col in pb_df.columns:
                    prebreakout_tickers = set(norm_t(x) for x in pb_df[col].tolist() if x)

        for _, r in df.iterrows():
            t = r["ticker"]
            norm = norm_t(t)

            # Determine dynamic indicator prefix:
            # - Portfolio stocks: ★ (star symbol)
            # - Breakout stocks: 🚀 (rocket emoji)
            # - Pre-breakout stocks: 🔍 (magnifying glass lens emoji)
            prefix = ""
            if t in sset:
                prefix += "★ "
            if norm in breakout_tickers:
                prefix += "🚀 "
            if norm in prebreakout_tickers:
                prefix += "🔍 "

            if not prefix:
                prefix = "  "

            item = QListWidgetItem(prefix + t.replace(".NS", ""))
            item.setData(Qt.UserRole, t)

            # High-fidelity custom styling
            f = item.font()
            if t in sset:
                f.setBold(True)
                item.setFont(f)
                item.setForeground(QColor("#2563EB"))  # Bold + Vibrant blue
            elif norm in breakout_tickers:
                f.setBold(True)
                item.setFont(f)
                item.setForeground(QColor("#10B981"))  # Bold + Emerald green for breakouts
            elif norm in prebreakout_tickers:
                f.setBold(True)
                item.setFont(f)
                item.setForeground(QColor("#F59E0B"))  # Bold + Warm amber orange for pre-breakouts

            self.charts_list.addItem(item)

        if sel:
            for i in range(self.charts_list.count()):
                if self.charts_list.item(i).data(Qt.UserRole) == sel[0]:
                    self.charts_list.setCurrentRow(i); self._load_tv_chart(sel[0]); break

    def _on_chart_stock_clicked(self, item): self._load_tv_chart(item.data(Qt.UserRole))

    def _open_tv_browser(self):
        """Open TradingView in system browser (used only when WebEngine is unavailable)."""
        if not self._tv_current:
            return
        import webbrowser  # RES001: verify resource is properly closed
        c = str(self._tv_current).replace(".NS", "").replace(".BO", "")
        e = "BSE" if str(self._tv_current).endswith(".BO") else "NSE"
        webbrowser.open(f"https://www.tradingview.com/chart/?symbol={e}:{c}&interval=D")

    def _load_tv_chart(self, t):
        """Load TradingView chart for ticker t — embedded if WebEngine available."""
        if not t:
            return
        self._tv_current = t
        c = str(t).replace(".NS", "").replace(".BO", "")
        e = "BSE" if str(t).endswith(".BO") else "NSE"
        url = f"https://www.tradingview.com/chart/?symbol={e}:{c}&interval=D"

        if HAS_WEBENGINE and self.tv_view is not None:
            # Embedded chart
            try:
                self.tv_view.page().runJavaScript("window.onbeforeunload = null;")
            except Exception:
                pass
            self.tv_view.setUrl(QUrl(url))
        else:
            if hasattr(self, "interactive_canvas") and self.interactive_canvas is not None:
                self.append_log(f"[Chart] Fetching historical OHLCV data for {t}...")
                def _fetch():
                    return _DATA_PROVIDER.get_prices([t], period="1y")
                
                self._chart_fetch_worker = _GenericNetworkWorker(_fetch)
                def on_result(df):
                    if df is not None and not df.empty:
                        self.interactive_canvas.set_data(df)
                        self.append_log(f"[Chart] Successfully loaded interactive candlestick chart for {t}.")
                    else:
                        self.append_log(f"[Chart] Fetch returned empty dataset for {t}.")
                
                self._chart_fetch_worker.result.connect(on_result)
                self._chart_fetch_worker.error.connect(lambda err: self.append_log(f"[Chart] Error loading data for {t}: {err}"))
                self._chart_fetch_worker.finished.connect(self._chart_fetch_worker.deleteLater)
                self._chart_fetch_worker.start()
            else:
                # Fallback card — update labels and show open button
                if hasattr(self, "tv_ticker_lbl"):
                    self.tv_ticker_lbl.setText(c)
                if hasattr(self, "tv_exchange_lbl"):
                    self.tv_exchange_lbl.setText(f"Exchange: {e}")
                if hasattr(self, "tv_placeholder"):
                    self.tv_placeholder.setText("WebEngine not available — open chart in browser")
                if hasattr(self, "tv_open_btn"):
                    self.tv_open_btn.setVisible(True)

    def _disable_unload_handler(self, ok):
        if HAS_WEBENGINE and self.tv_view is not None:
            js = """
            window.onbeforeunload = null;
            if (window.addEventListener) {
                var oldAddEventListener = window.addEventListener;
                window.addEventListener = function(type, listener, options) {
                    if (type === 'beforeunload') {
                        return;
                    }
                    return oldAddEventListener.apply(this, arguments);
                };
            }
            """
            try:
                self.tv_view.page().runJavaScript(js)
            except Exception:
                pass

    def _update_portfolio_drilldown(self):
        if not self.last_payload:
            return
        row = self.portfolio_table.currentRow()
        if row < 0:
            return
        portfolio_df = self.last_payload.get("portfolio_df")
        if portfolio_df is None or portfolio_df.empty or row >= len(portfolio_df):
            return
        # AUDIT-FIX (Round 6, D-P2-8): `currentRow()` is the VIEW row while
        # `portfolio_df.iloc[row]` is the MODEL row — after a header sort
        # (sorting is enabled by the R5 2-a-7 fix) the two diverge and the
        # drill-down showed the WRONG holding's data. Resolve the row through
        # the table's Ticker cell against the frame instead.
        _item = self.portfolio_table.item(row, 0)
        _view_ticker = str(_item.text()).strip().upper() if _item is not None else ""
        rec = None
        if _view_ticker:
            _mask = portfolio_df["Ticker"].astype(str).str.strip().str.upper() == _view_ticker
            if _mask.any():
                rec = portfolio_df[_mask].iloc[0]
        if rec is None:
            rec = portfolio_df.iloc[row]
        ticker = str(rec.get("Ticker", ""))
        self.detail_title.setText(f"{ticker} | {rec.get('Sector', 'N/A')}")
        self.detail_reason.setText(str(rec.get("Reason", "No rationale captured.")))
        changes_df = self.last_payload.get("changes_df", pd.DataFrame())
        change_row = changes_df[changes_df["Ticker"] == ticker].head(1) if isinstance(changes_df, pd.DataFrame) and not changes_df.empty else pd.DataFrame()
        change_status = change_row.iloc[0]["Status"] if not change_row.empty else "New run"
        change_delta = change_row.iloc[0]["WeightChange"] if not change_row.empty else np.nan
        stats_lines = [
            f"Weight: {float(rec.get('Weight %', np.nan)):.1%}" if pd.notna(rec.get("Weight %", np.nan)) else "Weight: n/a",
            f"Alpha Score: {float(rec.get('AlphaScore', np.nan)):.3f}" if pd.notna(rec.get("AlphaScore", np.nan)) else "Alpha Score: n/a",
            f"Risk Score: {float(rec.get('RiskScore', np.nan)):.3f}" if pd.notna(rec.get("RiskScore", np.nan)) else "Risk Score: n/a",
            f"Beta: {float(rec.get('Beta', np.nan)):.2f}" if pd.notna(rec.get("Beta", np.nan)) else "Beta: n/a",
            f"Ann Vol: {float(rec.get('AnnVol', np.nan)):.2%}" if pd.notna(rec.get("AnnVol", np.nan)) else "Ann Vol: n/a",
            f"Sector RS 1M: {float(rec.get('SectorRS1M', np.nan)):+.2%}" if pd.notna(rec.get("SectorRS1M", np.nan)) else "Sector RS 1M: n/a",
            f"Sector RS 6M: {float(rec.get('SectorRS6M', np.nan)):+.2%}" if pd.notna(rec.get("SectorRS6M", np.nan)) else "Sector RS 6M: n/a",
            f"ADV20: ₹{float(rec.get('ADV20', np.nan)):,.0f}" if pd.notna(rec.get("ADV20", np.nan)) else "ADV20: n/a",
            f"Change Status: {change_status}",
            f"Weight Change: {float(change_delta):+.1%}" if pd.notna(change_delta) else "Weight Change: n/a",
            "",
            "Factor Mix",
            f"Growth: {float(rec.get('GrowthFactor', np.nan)):.3f}" if pd.notna(rec.get("GrowthFactor", np.nan)) else "Growth: n/a",
            f"Trend: {float(rec.get('TrendFactor', np.nan)):.3f}" if pd.notna(rec.get("TrendFactor", np.nan)) else "Trend: n/a",
            f"Liquidity: {float(rec.get('LiquidityFactor', np.nan)):.3f}" if pd.notna(rec.get("LiquidityFactor", np.nan)) else "Liquidity: n/a",
            f"Quality: {float(rec.get('QualityFactor', np.nan)):.3f}" if pd.notna(rec.get("QualityFactor", np.nan)) else "Quality: n/a",
            f"Sector Leadership: {float(rec.get('SectorLeadFactor', np.nan)):.3f}" if pd.notna(rec.get("SectorLeadFactor", np.nan)) else "Sector Leadership: n/a",
        ]
        self.detail_stats.setPlainText("\n".join(stats_lines))

    def populate_table(self, table, df, is_portfolio=False):
        if table is None:
            return
        # ── Guard ──────────────────────────────────────────────────────────
        if df is None or (hasattr(df, "empty") and df.empty):
            table.setSortingEnabled(False)
            table.clear(); table.setRowCount(0); table.setColumnCount(0)
            self._set_table_header_visible(table, False)
            if hasattr(table, "_stack"):
                table._stack.setCurrentIndex(0)
            else:
                table.hide()
            return

        # ── Show table page ────────────────────────────────────────────────
        self._set_table_header_visible(table, True)
        if hasattr(table, "_stack"):
            table._stack.setCurrentIndex(1)
        else:
            table.show()
        _ph = getattr(table, "_placeholder", None)
        if _ph is not None:
            _ph.hide()

        # ── Column classification ──────────────────────────────────────────
        # RIGHT-align if column name contains any of these keywords
        _R = {"weight","wt","pct","%","price","ltp","close","open","high","low",
               "vol","beta","alpha","score","ratio","return","mom","rsi","inr",
               "value","qty","quantity","sharpe","drawdown","var","cvar","corr",
               "contrib","ic","ir","energy","nav","pnl","p&l","adv","rs_","factor",
               "exposure","active","alloc","target","risk","ann","cumul","metric",
               "portfolio","benchmark","detail","contribution","delivery","spread",
               "sector_rs","rs1","rs6","rs 1","rs 6","1m","3m","6m","12m","ytd"}
        # LEFT-align if column name contains any of these (overrides above)
        _L = {"ticker","symbol","name","sector","regime","status","type",
               "exchange","product","validity","tag","note","date","time",
               "signal","source","flag","description","market","tradingsymbol",
               "transaction","order","component","in universe","section","scenario",
               "strategy","instrument","direction","currency","asset"}

        def _col_align(col):
            cl = col.lower()
            if any(k in cl for k in _L): return Qt.AlignLeft  | Qt.AlignVCenter
            if any(k in cl for k in _R): return Qt.AlignRight | Qt.AlignVCenter
            return Qt.AlignLeft | Qt.AlignVCenter  # default: left

        # ── Value formatter ────────────────────────────────────────────────
        def _fmt(val, col):
            if val is None: return "—"
            if isinstance(val, float):
                if pd.isna(val): return "—"
                cl = col.lower()
                # Percentage columns
                if any(k in cl for k in {"%","weight","pct","contrib","vol","mom",
                                          "return","delivery","alloc","active","rs "}):
                    return f"{val:+.2%}" if any(k in cl for k in
                           {"active","return","mom","rs "}) else f"{val:.2%}"
                if abs(val) >= 1_000_000: return f"{val/1_000_000:.2f}M"
                if abs(val) >= 1_000:     return f"{val:,.2f}"
                if abs(val) >= 1:         return f"{val:.4f}"
                if abs(val) >= 0.0001:    return f"{val:.4f}"
                return f"{val:.6f}"
            if isinstance(val, int):
                return f"{val:,}"
            s = str(val)
            return "—" if s in ("nan","None","") else s

        # ── Colour palette ─────────────────────────────────────────────────
        _GREEN  = QColor("#059669"); _RED   = QColor("#DC2626")
        _BLUE   = QColor("#4f98a3"); _AMBER = QColor("#D97706")
        _MUTED  = QColor("#9a9aa8")
        _SECTION_BG = {
            "Run Setup": QColor("#273449"),
            "Market Regime": QColor("#2b3f35"),
            "Portfolio Health": QColor("#3b3221"),
            "Selection Changes": QColor("#3f2b31"),
            "Post-Trade Validation": QColor("#30354a"),
            "Chart Ensemble": QColor("#243847"),
            "Chart Portfolio": QColor("#2f3b2c"),
            "Chart Votes": QColor("#3c3430"),
        }

        def _color(val, col, row_dict=None):
            parsed_val = val
            if isinstance(val, str):
                try:
                    s = val.strip().replace("%", "").replace(",", "")
                    if s.endswith("/yr"):
                        s = s.replace("/yr", "")
                    parsed_val = float(s)
                except ValueError:
                    parsed_val = None
            elif isinstance(val, (int, float)):
                parsed_val = float(val)
            else:
                parsed_val = None

            if parsed_val is None or pd.isna(parsed_val):
                return None
            cl = col.lower()
            # Portfolio heatmap
            if is_portfolio:
                if cl in {"alphascore","mom1m","mom3m","mom6m","rsi","alpha score",
                           "alpha_score","mom 6m %"}:
                    return _GREEN if parsed_val > 0 else _RED if parsed_val < 0 else None
                if cl == "beta":
                    return _RED if parsed_val > 1.2 else _GREEN if parsed_val < 0.8 else None
            # Universal: return/P&L/active columns
            if any(k in cl for k in {"return","active","pnl","p&l","alpha",
                                       "contrib","mom","rs ","rs_"}):
                return _GREEN if parsed_val > 0 else _RED if parsed_val < 0 else None
            # Risk/drawdown — red when bad
            if any(k in cl for k in {"drawdown","var","cvar","loss","severity","risk"}):
                if parsed_val < 0:
                    return _RED
                if any(k in cl for k in {"drawdown","loss"}) and row_dict and "limit" in str(row_dict.get("Detail", "")).lower():
                    return _MUTED
                if "severity" in cl:
                    return _RED if parsed_val > 2 else _AMBER
                return _RED if parsed_val > 5.0 else None
            return None

        # ── Populate ───────────────────────────────────────────────────────
        cols = list(df.columns)
        # AUDIT-FIX (Round 5, 2-a-7): _reset_result_state() disables sorting on
        # every result table (to prevent the P6 sort-during-insert crash) but
        # populate_table never re-enabled it — all result tables were stuck
        # non-sortable for the whole session. Disable while inserting, then
        # restore afterwards. (The history tables were conversely populated
        # with sorting ON — the exact hazard P6 warned about.)
        _sorting_was_enabled = bool(table.isSortingEnabled())
        table.setSortingEnabled(False)
        table.setRowCount(len(df))
        table.setColumnCount(len(cols))
        table.setHorizontalHeaderLabels([str(c).upper() for c in cols])

        for r in range(len(df)):
            row_data = df.iloc[r]
            for c, col in enumerate(cols):
                val  = row_data[col]
                txt  = _fmt(val, str(col))
                item = QTableWidgetItem(txt)

                # Alignment: numeric value OR numeric column name → right
                is_num = isinstance(val, (int, float)) and not (isinstance(val, float) and pd.isna(val))
                align = Qt.AlignRight | Qt.AlignVCenter if (is_num or _col_align(str(col)) == (Qt.AlignRight | Qt.AlignVCenter)) else Qt.AlignLeft | Qt.AlignVCenter
                item.setTextAlignment(align)

                # Monospace numbers & bold tickers for clean Bloomberg layout
                cl = str(col).lower()
                if is_num or any(k in cl for k in _R) or "%" in txt or (len(txt) > 0 and txt[0] in "+-" and txt[1:2].isdigit()):
                    item.setFont(QFont("Menlo", 10))
                if any(k in cl for k in {"ticker", "symbol", "name"}) and not is_num:
                    f = item.font()
                    f.setBold(True)
                    item.setFont(f)

                # Colour
                fg = _color(val, str(col), row_data.to_dict() if hasattr(row_data, "to_dict") else dict(row_data))
                if fg: item.setForeground(fg)

                # Status column special colours
                if str(col).lower() == "status":
                    sc = {"Added":_BLUE,"Removed":_RED,
                          "Weight Up":_GREEN,"Weight Down":_AMBER}
                    item.setForeground(sc.get(str(val), _MUTED))

                if "Section" in cols:
                    section_val = str(row_data.get("Section", ""))
                    bg = _SECTION_BG.get(section_val)
                    if bg is None and "═══" in section_val:
                        bg = QColor("#27272a") # dark slate grey for sub-section banners
                    if bg is not None:
                        item.setBackground(bg)
                        f = item.font()
                        f.setBold(True)
                        item.setFont(f)
                        item.setForeground(QColor("#F3F4F6"))

                table.setItem(r, c, item)

        # ── Sync header alignment to match cell alignment ──────────────────
        for c, col in enumerate(cols):
            h_item = table.horizontalHeaderItem(c)
            if h_item is None:
                continue
            # Use same classification logic as cells
            cl = str(col).lower()
            is_right = any(k in cl for k in _R) and not any(k in cl for k in _L)
            h_item.setTextAlignment(
                Qt.AlignRight | Qt.AlignVCenter if is_right
                else Qt.AlignLeft  | Qt.AlignVCenter
            )

        # ── Resize after paint ─────────────────────────────────────────────
        def _resize(_t=table):
            try:
                hh = _t.horizontalHeader()
                hh.setSectionResizeMode(QHeaderView.ResizeToContents)
                _t.resizeColumnsToContents()
                for _c in range(_t.columnCount()):
                    if hh.sectionSize(_c) > 200:
                        hh.resizeSection(_c, 200)
                hh.setSectionResizeMode(QHeaderView.Interactive)
            except Exception as _e:
                try:
                    self.append_log(f"[Warning] {_e}")
                except Exception as _exc_p2a_:
                    ExceptionLogger.swallow(_exc_p2a_, context='L48761')
        QTimer.singleShot(60,  _resize)
        QTimer.singleShot(250, _resize)
        # AUDIT-FIX (Round 5, 2-a-7): restore user sorting after populate.
        if _sorting_was_enabled:
            table.setSortingEnabled(True)

    def export_portfolio_csv(self):
        if self.last_payload and "portfolio_df" in self.last_payload:
            p, _ = QFileDialog.getSaveFileName(self, "Save Portfolio", "portfolio.csv", "CSV (*.csv)")
            if p:
                self.last_payload["portfolio_df"].to_csv(p, index=False)
                self.append_log(f"[Export] Saved portfolio CSV to {p}")
        else:
            self._show_styled_message("No Data", "No portfolio data found. Please run the optimizer or sweep first.", _QMESSAGEBOX_ICON.Warning)

    def export_prescreen_csv(self):
        if self.last_payload and "prescreen_df" in self.last_payload:
            p, _ = QFileDialog.getSaveFileName(self, "Save Universe", "universe.csv", "CSV (*.csv)")
            if p:
                self.last_payload["prescreen_df"].to_csv(p, index=False)
                self.append_log(f"[Export] Saved universe CSV to {p}")
        else:
            self._show_styled_message("No Data", "No universe data found. Please run the optimizer or sweep first.", _QMESSAGEBOX_ICON.Warning)

    def export_breakout_csv(self):
        if self.last_payload:
            df = self.last_payload.get("breakout_df")
            if df is not None and not df.empty:
                p, _ = QFileDialog.getSaveFileName(self, "Save Breakout Stocks", "breakout_stocks.csv", "CSV (*.csv)")
                if p: df.to_csv(p, index=False); self.append_log(f"[Breakout] CSV saved → {p}")
            else:
                self._show_styled_message("No Data", "No early-breakout stocks found in the last run.", _QMESSAGEBOX_ICON.Information)
        else:
            self._show_styled_message("No Data", "No breakout data found. Please run the optimizer or sweep first.", _QMESSAGEBOX_ICON.Warning)

    def export_prebreakout_csv(self):
        if self.last_payload:
            df = self.last_payload.get("prebreakout_df")
            if df is not None and not df.empty:
                p, _ = QFileDialog.getSaveFileName(self, "Save Pre-Breakout Stocks", "prebreakout_stocks.csv", "CSV (*.csv)")
                if p: df.to_csv(p, index=False); self.append_log(f"[PreBreakout] CSV saved → {p}")
            else:
                self._show_styled_message("No Data", "No pre-breakout setups found in the last run.", _QMESSAGEBOX_ICON.Information)
        else:
            self._show_styled_message("No Data", "No pre-breakout data found. Please run the optimizer or sweep first.", _QMESSAGEBOX_ICON.Warning)

    def export_diagnostics_csv(self):
        if self.last_payload and "diagnostics_df" in self.last_payload:
            p, _ = QFileDialog.getSaveFileName(self, "Save Diagnostics", "diagnostics.csv", "CSV (*.csv)")
            if p:
                self.last_payload["diagnostics_df"].to_csv(p, index=False)
                self.append_log(f"[Export] Saved diagnostics CSV to {p}")
        else:
            self._show_styled_message("No Data", "No diagnostics data found. Please run the optimizer or sweep first.", _QMESSAGEBOX_ICON.Warning)

    def export_risk_csv(self):
        if self.last_payload:
            p, _ = QFileDialog.getSaveFileName(self, "Save Risk Analytics", "risk_analytics.csv", "CSV (*.csv)")
            if p:
                pd.concat([self.last_payload.get("var_cvar_df", pd.DataFrame()),
                           self.last_payload.get("stress_test_df", pd.DataFrame())],
                          ignore_index=True).to_csv(p, index=False)
                self.append_log(f"[Export] Saved risk analytics CSV to {p}")
        else:
            self._show_styled_message("No Data", "No risk analytics data found. Please run the optimizer or sweep first.", _QMESSAGEBOX_ICON.Warning)

    def export_execution_csv(self):
        if self.last_payload and self.last_payload.get("kite_orders_df") is not None:
            p, _ = QFileDialog.getSaveFileName(self, "Save Execution Orders", "kite_orders.csv", "CSV (*.csv)")
            if p:
                self.last_payload["kite_orders_df"].to_csv(p, index=False)
                self.append_log(f"[Export] Saved execution orders CSV to {p}")
        else:
            self._show_styled_message("No Data", "No execution order data found. Please run the optimizer or sweep first.", _QMESSAGEBOX_ICON.Warning)

    def export_combined_portfolio_csv(self):
        payloads = getattr(self, "_profile_payloads", {})
        if not payloads:
            self._show_styled_message("No Data", "No profile sweep data found. Please run All Profiles first.", _QMESSAGEBOX_ICON.Warning)
            return

        data = []
        for pname, pld in payloads.items():
            df = pld.get("portfolio_df")
            if isinstance(df, pd.DataFrame) and not df.empty:
                ticker_col = next((c for c in df.columns if "ticker" in c.lower()), None)
                weight_col = next((c for c in df.columns if "weight" in c.lower()), None)
                if ticker_col and weight_col:
                    for _, r in df.iterrows():
                        t = str(r[ticker_col])
                        w = float(r[weight_col])
                        data.append({"Ticker": t, "Profile": pname, "Weight %": w})

        if not data:
            self._show_styled_message("No Data", "No portfolio rows found in completed profiles.", _QMESSAGEBOX_ICON.Warning)
            return

        df_all = pd.DataFrame(data)
        agg = df_all.groupby("Ticker").agg(
            MatchCount=("Profile", "count"),
            Profiles=("Profile", lambda x: ", ".join(sorted(list(x)))),
            AvgWeight=("Weight %", "mean"),
            TotalWeight=("Weight %", "sum")
        ).reset_index()

        def get_consensus_symbol(cnt):
            if cnt >= 3: return "⚡"
            if cnt == 2: return "★"
            return "·"
        agg["Consensus Symbol"] = agg["MatchCount"].apply(get_consensus_symbol)

        agg = agg[["Consensus Symbol", "Ticker", "MatchCount", "Profiles", "AvgWeight", "TotalWeight"]]
        agg = agg.sort_values(by=["MatchCount", "AvgWeight"], ascending=[False, False])
        agg["Ticker"] = agg.apply(lambda r: f"{r['Consensus Symbol']} {r['Ticker']}" if r['Consensus Symbol'] in ("⚡", "★") else r['Ticker'], axis=1)

        p, _ = QFileDialog.getSaveFileName(self, "Save Combined Portfolio", "combined_portfolio.csv", "CSV (*.csv)")
        if p:
            agg.to_csv(p, index=False)
            self.append_log(f"[Export] Saved combined portfolio CSV to {p}")
            try:
                from math_engine.post_screening_intelligence import PostScreeningIntelligenceEngine
                raw_cache = getattr(self, "_raw_metrics_cache", {})
                intel_path = PostScreeningIntelligenceEngine.generate_and_save_intelligence_report(p, raw_cache)
                if intel_path:
                    self.append_log(f"[Intelligence] Saved post-screening intelligence to {intel_path}")
            except Exception as ex:
                self.append_log(f"[Intelligence Notice] Could not save post-screening report: {ex}")



    def export_combined_universe_csv(self):
        payloads = getattr(self, "_profile_payloads", {})
        if not payloads:
            self._show_styled_message("No Data", "No profile sweep data found. Please run All Profiles first.", _QMESSAGEBOX_ICON.Warning)
            return

        data = []
        for pname, pld in payloads.items():
            df = pld.get("prescreen_df")
            if isinstance(df, pd.DataFrame) and not df.empty:
                ticker_col = next((c for c in df.columns if "ticker" in c.lower()), None)
                score_col = next((c for c in df.columns if "score" in c.lower()), None)
                if ticker_col:
                    for _, r in df.iterrows():
                        t = str(r[ticker_col])
                        s = float(r[score_col]) if score_col and pd.notna(r[score_col]) else 0.0
                        data.append({"Ticker": t, "Profile": pname, "Score": s})

        if not data:
            self._show_styled_message("No Data", "No universe rows found in completed profiles.", _QMESSAGEBOX_ICON.Warning)
            return

        df_all = pd.DataFrame(data)
        agg = df_all.groupby("Ticker").agg(
            MatchCount=("Profile", "count"),
            Profiles=("Profile", lambda x: ", ".join(sorted(list(x)))),
            AvgScore=("Score", "mean")
        ).reset_index()

        def get_consensus_symbol(cnt):
            if cnt >= 3: return "⚡"
            if cnt == 2: return "★"
            return "·"
        agg["Consensus Symbol"] = agg["MatchCount"].apply(get_consensus_symbol)

        agg = agg[["Consensus Symbol", "Ticker", "MatchCount", "Profiles", "AvgScore"]]
        agg = agg.sort_values(by=["MatchCount", "AvgScore"], ascending=[False, False])
        agg["Ticker"] = agg.apply(lambda r: f"{r['Consensus Symbol']} {r['Ticker']}" if r['Consensus Symbol'] in ("⚡", "★") else r['Ticker'], axis=1)

        p, _ = QFileDialog.getSaveFileName(self, "Save Combined Universe", "combined_universe.csv", "CSV (*.csv)")
        if p:
            agg.to_csv(p, index=False)
            self.append_log(f"[Export] Saved combined universe CSV to {p}")

    def export_combined_breakout_csv(self):
        payloads = getattr(self, "_profile_payloads", {})
        if not payloads:
            self._show_styled_message("No Data", "No profile sweep data found. Please run All Profiles first.", _QMESSAGEBOX_ICON.Warning)
            return

        data = []
        for pname, pld in payloads.items():
            df = pld.get("breakout_df")
            if isinstance(df, pd.DataFrame) and not df.empty:
                ticker_col = next((c for c in df.columns if "ticker" in c.lower()), None)
                score_col = next((c for c in df.columns if "score" in c.lower()), None)
                if ticker_col:
                    for _, r in df.iterrows():
                        t = str(r[ticker_col])
                        s = float(r[score_col]) if score_col and pd.notna(r[score_col]) else 0.0
                        s = round(s / 100.0 if s > 1.0 else s, 4)  # Normalize 0-100 score to 0-1 scale
                        data.append({"Ticker": t, "Profile": pname, "Score": s})

        if not data:
            self._show_styled_message("No Data", "No breakout setups found in completed profiles.", _QMESSAGEBOX_ICON.Warning)
            return

        df_all = pd.DataFrame(data)
        agg = df_all.groupby("Ticker").agg(
            MatchCount=("Profile", "count"),
            Profiles=("Profile", lambda x: ", ".join(sorted(list(x)))),
            AvgScore=("Score", "mean")
        ).reset_index()

        def get_consensus_symbol(cnt):
            if cnt >= 3: return "⚡"
            if cnt == 2: return "★"
            return "·"
        agg["Consensus Symbol"] = agg["MatchCount"].apply(get_consensus_symbol)

        agg = agg[["Consensus Symbol", "Ticker", "MatchCount", "Profiles", "AvgScore"]]
        agg = agg.sort_values(by=["MatchCount", "AvgScore"], ascending=[False, False])
        agg["Ticker"] = agg.apply(lambda r: f"{r['Consensus Symbol']} {r['Ticker']}" if r['Consensus Symbol'] in ("⚡", "★") else r['Ticker'], axis=1)

        p, _ = QFileDialog.getSaveFileName(self, "Save Combined Breakout", "combined_breakout.csv", "CSV (*.csv)")
        if p:
            agg.to_csv(p, index=False)
            self.append_log(f"[Export] Saved combined breakout CSV to {p}")

    def export_combined_prebreakout_csv(self):
        payloads = getattr(self, "_profile_payloads", {})
        if not payloads:
            self._show_styled_message("No Data", "No profile sweep data found. Please run All Profiles first.", _QMESSAGEBOX_ICON.Warning)
            return

        data = []
        for pname, pld in payloads.items():
            df = pld.get("prebreakout_df")
            if isinstance(df, pd.DataFrame) and not df.empty:
                ticker_col = next((c for c in df.columns if "ticker" in c.lower()), None)
                score_col = next((c for c in df.columns if "score" in c.lower()), None)
                if ticker_col:
                    for _, r in df.iterrows():
                        t = str(r[ticker_col])
                        s = float(r[score_col]) if score_col and pd.notna(r[score_col]) else 0.0
                        s = round(s / 100.0 if s > 1.0 else s, 4)  # Normalize 0-100 score to 0-1 scale
                        data.append({"Ticker": t, "Profile": pname, "Score": s})

        if not data:
            self._show_styled_message("No Data", "No pre-breakout setups found in completed profiles.", _QMESSAGEBOX_ICON.Warning)
            return

        df_all = pd.DataFrame(data)
        agg = df_all.groupby("Ticker").agg(
            MatchCount=("Profile", "count"),
            Profiles=("Profile", lambda x: ", ".join(sorted(list(x)))),
            AvgScore=("Score", "mean")
        ).reset_index()

        def get_consensus_symbol(cnt):
            if cnt >= 3: return "⚡"
            if cnt == 2: return "★"
            return "·"
        agg["Consensus Symbol"] = agg["MatchCount"].apply(get_consensus_symbol)

        agg = agg[["Consensus Symbol", "Ticker", "MatchCount", "Profiles", "AvgScore"]]
        agg = agg.sort_values(by=["MatchCount", "AvgScore"], ascending=[False, False])
        agg["Ticker"] = agg.apply(lambda r: f"{r['Consensus Symbol']} {r['Ticker']}" if r['Consensus Symbol'] in ("⚡", "★") else r['Ticker'], axis=1)

        p, _ = QFileDialog.getSaveFileName(self, "Save Combined Pre-Breakout", "combined_prebreakout.csv", "CSV (*.csv)")
        if p:
            agg.to_csv(p, index=False)
            self.append_log(f"[Export] Saved combined pre-breakout CSV to {p}")

    def export_chart_pack(self):
        if not self.last_payload:
            self._show_styled_message("No Data", "No run data found. Please run the optimizer or sweep first.", _QMESSAGEBOX_ICON.Warning)
            return
        if not HAS_MATPLOTLIB:
            self._show_styled_message("Unavailable", "matplotlib is required for chart pack export.", _QMESSAGEBOX_ICON.Warning)
            return
        path = QFileDialog.getExistingDirectory(self, "Select Chart Pack Folder", str(SNAPSHOT_DIR))
        if not path:
            return
        try:
            generate_chart_pack(self.last_payload, Path(path))
            self.append_log(f"Saved chart pack to: {path}")
        except Exception as exc:
            self._show_styled_message("Chart export failed", f"Could not export chart pack:\n{exc}", _QMESSAGEBOX_ICON.Critical)

    def _auto_export_memo(self):
        if not self.last_payload:
            return
        try:
            path = SNAPSHOT_DIR / f"investment_memo_auto_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
            self._write_investment_memo(path)
            self.append_log(f"Auto-exported memo: {path}")
        except Exception as exc:
            self.append_log(f"Auto-export memo failed: {exc}")

    def export_investment_memo_md(self):
        if not self.last_payload:
            self._show_styled_message("No Data", "No run data found. Please run the optimizer or sweep first.", _QMESSAGEBOX_ICON.Warning)
            return

        p, _ = QFileDialog.getSaveFileName(
            self,
            "Save Memo",
            f"investment_memo_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md",
            "Markdown (*.md)"
        )
        if not p:
            return

        self._write_investment_memo(Path(p))
        self.append_log(f"Saved investment memo: {p}")

    def _generate_portfolio_thesis(self, payload):
        """Build a run-specific thesis paragraph from actual portfolio data."""
        regime = payload.get("regime_info", {}).get("Regime", "Unknown")
        health = payload.get("portfolio_health", {})
        k = len(payload.get("selected", []))
        factor_df = payload.get("factor_summary_df", pd.DataFrame())
        sector_df = payload.get("sector_summary_df", pd.DataFrame())
        cfg_used = payload.get("cfg", {})

        top_factor = "balanced cross-factor"
        if not factor_df.empty and "WeightedExposure" in factor_df.columns:
            try:
                top_row = factor_df.loc[factor_df["WeightedExposure"].idxmax()]
                top_factor = f"{str(top_row['Factor']).lower()}-driven"
            except Exception as _e:
                try:
                    self.append_log(f"[Warning] {_e}")
                except Exception as _exc_p2a_:
                    ExceptionLogger.swallow(_exc_p2a_, context='L48864')

        top_sector = "diversified sectors"
        if not sector_df.empty:
            top_sector = str(sector_df.iloc[0]["Sector"])

        wb = health.get("WeightedBeta", np.nan)
        if pd.notna(wb):
            if wb < 0.85:
                beta_desc = f"defensively positioned (β={wb:.2f}, below benchmark)"
            elif wb > 1.15:
                beta_desc = f"aggressively positioned (β={wb:.2f}, above benchmark)"
            else:
                beta_desc = f"benchmark-neutral (β={wb:.2f})"
        else:
            beta_desc = "benchmark-agnostic"

        eff_n = health.get("EffectiveNames", k)
        conc = f"{eff_n:.1f} effective names" if pd.notna(eff_n) else str(k)

        gamma = cfg_used.get("GAMMA", "?")
        alpha_param = cfg_used.get("ALPHA", "?")
        regime_filter = cfg_used.get("REGIME_FILTER", "Adaptive")
        solver_src = payload.get("solver_source", "SimulatedAnnealing")

        return (
            f"This {k}-stock NSE portfolio is **{top_factor}**, with its largest sector exposure "
            f"in **{top_sector}**. The optimizer ran in a **{regime}** market regime under "
            f"**{regime_filter}** regime filter. The portfolio is {beta_desc} with {conc}. "
            f"Capital allocation uses QUBO-aware blending (GAMMA={gamma}, ALPHA={alpha_param}) "
            f"combined with inverse-volatility weighting. Solver: {solver_src}."
        )

    def _write_investment_memo(self, path):
        payload = self.last_payload
        regime = payload.get("regime_info", {})
        top = payload["portfolio_df"].head(10)
        sectors = payload.get("sector_summary_df", pd.DataFrame()).head(8)
        factors = payload.get("factor_summary_df", pd.DataFrame())
        exposures = payload.get("exposures_df", pd.DataFrame())
        changes = payload.get("changes_df", pd.DataFrame()).head(12)
        health = payload.get("portfolio_health", {})
        alerts = payload.get("alerts_df", pd.DataFrame()).head(10)
        lines = [
            f"# {APP_NAME}",
            "",
            f"- Run Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            f"- Benchmark: {payload.get('benchmark_symbol', 'Unavailable')}",
            f"- Regime: {regime.get('Regime', 'Unknown')}",
            f"- Solver: {payload.get('solver_source', '--')}",
            f"- Risk Model: {payload.get('cfg', {}).get('RISK_MODEL', '--')}",
            f"- Universe Screened: {payload.get('screened_count', '--')}",
            f"- Selected Names: {len(payload.get('selected', []))}",
            "",
            "## Portfolio Thesis",
            "",
            self._generate_portfolio_thesis(payload),
            "",
            "## Portfolio Health",
            "",
            f"- Top weight: {health.get('TopWeight', np.nan):.1%}" if pd.notna(health.get("TopWeight", np.nan)) else "- Top weight: n/a",
            f"- Effective names: {health.get('EffectiveNames', np.nan):.2f}" if pd.notna(health.get("EffectiveNames", np.nan)) else "- Effective names: n/a",
            f"- Largest sector weight: {health.get('LargestSectorWeight', np.nan):.1%}" if pd.notna(health.get("LargestSectorWeight", np.nan)) else "- Largest sector weight: n/a",
            f"- Weighted beta: {health.get('WeightedBeta', np.nan):.2f}" if pd.notna(health.get("WeightedBeta", np.nan)) else "- Weighted beta: n/a",
            f"- Active beta: {health.get('ActiveBeta', np.nan):+.2f}" if pd.notna(health.get("ActiveBeta", np.nan)) else "- Active beta: n/a",
            f"- Ex-Ante Volatility: {health.get('Ex-Ante Volatility %', np.nan):.2f}%" if pd.notna(health.get("Ex-Ante Volatility %", np.nan)) else "- Ex-Ante Volatility: n/a",
            f"- Factor Risk Ratio: {health.get('Factor Risk %', np.nan):.2f}%" if pd.notna(health.get("Factor Risk %", np.nan)) else "- Factor Risk Ratio: n/a",
            f"- Specific Risk Ratio: {health.get('Specific Risk %', np.nan):.2f}%" if pd.notna(health.get("Specific Risk %", np.nan)) else "- Specific Risk Ratio: n/a",
            "",
            "## Top Holdings",
            "",
            "| Ticker | Weight | Sector | Alpha | Risk | Reason |",
            "| --- | ---: | --- | ---: | ---: | --- |",
        ]
        for _, row in top.iterrows():
            lines.append(
                f"| {row['Ticker']} | {row['Weight %']:.1%} | {row['Sector']} | {row['AlphaScore']:.3f} | {row['RiskScore']:.3f} | {row['Reason']} |"
            )

        lines += [
            "",
            "## Market Context",
            "",
            f"- Breadth: {regime.get('Breadth', np.nan):.2%}" if pd.notna(regime.get("Breadth", np.nan)) else "- Breadth: n/a",
            f"- Dispersion: {regime.get('Dispersion', np.nan):.2%}" if pd.notna(regime.get("Dispersion", np.nan)) else "- Dispersion: n/a",
            f"- Benchmark Trend (63D): {regime.get('BenchmarkTrend', np.nan):.2%}" if pd.notna(regime.get("BenchmarkTrend", np.nan)) else "- Benchmark Trend (63D): n/a",
            "",
            "## Risk Controls",
            "",
            f"- Max names per sector: {payload.get('cfg', {}).get('MAX_PER_SECTOR', '--')}",
            f"- Weight band: {payload.get('cfg', {}).get('MIN_WEIGHT', 0.0):.0%} to {payload.get('cfg', {}).get('MAX_WEIGHT', 0.0):.0%}",
            f"- Correlation shrinkage: {payload.get('cfg', {}).get('CORR_SHRINKAGE', '--')}",
            "",
        ]

        if not sectors.empty:
            lines += [
                "## Sector Allocation",
                "",
                "| Sector | Holdings | Weight | Avg Alpha | Avg Risk |",
                "| --- | ---: | ---: | ---: | ---: |",
            ]
            for _, row in sectors.iterrows():
                lines.append(
                    f"| {row['Sector']} | {int(row['Holdings'])} | {float(row['Weight']):.1%} | {float(row['AvgAlpha']):.3f} | {float(row['AvgRisk']):.3f} |"
                )
            lines.append("")

        if not factors.empty:
            lines += [
                "## Factor Attribution",
                "",
                "| Factor | Weighted Exposure | Avg Holding Score | Top Contributor |",
                "| --- | ---: | ---: | --- |",
            ]
            for _, row in factors.iterrows():
                lines.append(
                    f"| {row['Factor']} | {float(row['WeightedExposure']):.4f} | {float(row['AverageHoldingScore']):.4f} | {row['TopContributor']} |"
                )
            lines.append("")

        numeric_exposures = exposures[pd.to_numeric(exposures["Portfolio"], errors="coerce").notna()] if not exposures.empty and "Portfolio" in exposures.columns else pd.DataFrame()
        if not numeric_exposures.empty:
            lines += [
                "## Active Exposures",
                "",
                "| Metric | Portfolio | Benchmark | Active |",
                "| --- | ---: | ---: | ---: |",
            ]
            for _, row in numeric_exposures.iterrows():
                bench_val = row["Benchmark"]
                active_val = row["Active"]
                bench_txt = f"{float(bench_val):.4f}" if isinstance(bench_val, (int, float)) and not pd.isna(bench_val) else ""
                active_txt = f"{float(active_val):+.4f}" if isinstance(active_val, (int, float)) and not pd.isna(active_val) else ""
                lines.append(f"| {row['Metric']} | {float(row['Portfolio']):.4f} | {bench_txt} | {active_txt} |")
            lines.append("")

        if not changes.empty:
            lines += [
                "## Run-to-Run Changes",
                "",
                "| Ticker | Status | Previous Weight | Current Weight | Change |",
                "| --- | --- | ---: | ---: | ---: |",
            ]
            for _, row in changes.iterrows():
                prev_w = row["PreviousWeight"]
                curr_w = row["CurrentWeight"]
                delta = row["WeightChange"]
                prev_txt = f"{prev_w:.1%}" if isinstance(prev_w, (int, float)) and not pd.isna(prev_w) else ""
                curr_txt = f"{curr_w:.1%}" if isinstance(curr_w, (int, float)) and not pd.isna(curr_w) else ""
                delta_txt = f"{delta:+.1%}" if isinstance(delta, (int, float)) and not pd.isna(delta) else ""
                lines.append(f"| {row['Ticker']} | {row['Status']} | {prev_txt} | {curr_txt} | {delta_txt} |")
            lines.append("")

        if not alerts.empty:
            lines += [
                "## Portfolio Alerts",
                "",
                "| Severity | Category | Message |",
                "| --- | --- | --- |",
            ]
            for _, row in alerts.iterrows():
                lines.append(f"| {row['Severity']} | {row['Category']} | {row['Message']} |")
            lines.append("")

        if payload.get("backtest"):
            bt = payload["backtest"]
            lines += [
                "## Walk-Forward Backtest",
                "",
                f"- Annual Return: {bt.get('Annual Return', np.nan):.2%}" if pd.notna(bt.get("Annual Return", np.nan)) else "- Annual Return: n/a",
                f"- Sharpe: {bt.get('Sharpe', np.nan):.2f}" if pd.notna(bt.get("Sharpe", np.nan)) else "- Sharpe: n/a",
                f"- Sortino: {bt.get('Sortino', np.nan):.2f}" if pd.notna(bt.get("Sortino", np.nan)) else "- Sortino: n/a",
                f"- Max Drawdown: {bt.get('Max Drawdown', np.nan):.2%}" if pd.notna(bt.get("Max Drawdown", np.nan)) else "- Max Drawdown: n/a",
                "",
            ]

        path.write_text("\n".join(lines), encoding="utf-8")

    def export_run_snapshot_json(self):
        if not self.last_payload:
            self._show_styled_message("No Data", "No run data found. Please run the optimizer or sweep first.", _QMESSAGEBOX_ICON.Warning)
            return

        path, _ = QFileDialog.getSaveFileName(
            self,
            "Save Snapshot",
            f"snapshot_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
            "JSON (*.json)"
        )
        if not path:
            return

        payload = dict(self.last_payload)
        payload = payload_to_serializable(payload)

        try:
            Path(path).write_text(
                json.dumps(payload, indent=2, ensure_ascii=False, default=str),
                encoding="utf-8"
            )
            self.append_log(f"Saved snapshot JSON: {path}")
        except Exception as exc:
            self._show_styled_message("Save failed", f"Could not save snapshot:\n{exc}", _QMESSAGEBOX_ICON.Critical)

    def _apply_style(self):
        """v17: replaced by apply_theme() — dark mode applied in __init__."""
        pass  # apply_theme() is called in __init__ and via the toggle button


    # ── v17: Kite Reconcile Handler ───────────────────────────────────────────
    def reconcile_holdings(self):
        cfg = self.collect_cfg()
        api_key   = self.kite_key_edit.text().strip()   if hasattr(self, "kite_key_edit")   else ""
        acc_token = self.kite_token_edit.text().strip() if hasattr(self, "kite_token_edit") else ""
        pv = float(cfg.get("PORTFOLIO_VALUE_INR", cfg.get("PORTFOLIO_VALUE", 1_000_000)))
        weights = getattr(self, "_last_weights", {})
        if not weights:
            self.append_log("[Reconcile] Run optimizer first."); return
        if not api_key or not acc_token:
            self.append_log("[Reconcile] Set DHAN_CLIENT_ID / DHAN_ACCESS_TOKEN in config."); return
        self.append_log("[Reconcile] Fetching DhanHQ holdings…")
        try:
            df = reconcile_with_kite(weights, pv, api_key, acc_token, log_cb=self.append_log)
            if df is not None and not df.empty:
                self.populate_table(self.execution_table, df)
                self._set_table_header_visible(self.execution_table, True)
                buys = (df["Action"] == "BUY").sum()
                sells = (df["Action"] == "SELL").sum()
                holds = (df["Action"] == "HOLD").sum()
                self.append_log(f"[Reconcile] ✅ BUY:{buys}  SELL:{sells}  HOLD:{holds}")
        except Exception as e:
            self.append_log(f"[Reconcile] Error: {e}")

    # ── v17: Kite Direct Basket Placement Handler ──────────────────────────────
    def _get_kite_client(self):
        try:
            from kiteconnect import KiteConnect
            api_key = self.kite_key_edit.text().strip() if hasattr(self, "kite_key_edit") else ""
            acc_token = self.kite_token_edit.text().strip() if hasattr(self, "kite_token_edit") else ""
            if api_key and acc_token:
                kite = KiteConnect(api_key=api_key)
                kite.set_access_token(acc_token)
                return kite
        except Exception:
            pass
        return None

    def place_basket_direct(self):
        cfg = self.collect_cfg()
        strategy = self.exec_strategy_combo.currentText()
        is_fix = self.exec_destination_combo.currentText() == "Institutional FIX 4.2 Engine"
        
        # Immediate Market execution (legacy order-sheet/direct route)
        if strategy == "Market" and not is_fix:
            api_key   = self.kite_key_edit.text().strip()   if hasattr(self, "kite_key_edit")   else ""
            acc_token = self.kite_token_edit.text().strip() if hasattr(self, "kite_token_edit") else ""
            pv        = float(cfg.get("PORTFOLIO_VALUE_INR", cfg.get("PORTFOLIO_VALUE", 1_000_000)))
            weights   = getattr(self, "_last_weights", {})
            if not weights:
                self.append_log("[KiteDirect] Run optimizer first.")
                self.exec_logs_box.appendPlainText("[AlgoExecution] Run optimizer first.")
                return
            
            self.ws_status_lbl.setText("🔴 WebSocket: Off")
            self.exec_logs_box.clear()
            self.exec_logs_box.appendPlainText("[AlgoExecution] Executing immediate Market order placement...")
            
            dry = not (self.kite_live_check.isChecked() if hasattr(self, "kite_live_check") else False)
            if not dry and (not api_key or not acc_token):
                self.append_log("[KiteDirect] Set KITE_API_KEY / KITE_ACCESS_TOKEN in config.")
                self.exec_logs_box.appendPlainText("[AlgoExecution] Set KITE_API_KEY / KITE_ACCESS_TOKEN in config.")
                return
            if not dry:
                # Pre-trade risk limit enforcement dialog
                sector_map = getattr(self, "_last_sector_map", None)
                if sector_map is None and hasattr(self, "last_payload") and self.last_payload:
                    sector_map = self.last_payload.get("sector_map")
                enforcer = RiskLimitEnforcer(cfg)
                violations = enforcer.check(weights, sectors=sector_map)
                if violations:
                    if not RiskLimitEnforcer.show_violations_dialog(violations, parent=self):
                        self.append_log("[KiteDirect] Live order cancelled by user after risk limit warning.")
                        self.exec_logs_box.appendPlainText("[AlgoExecution] Live order cancelled by user after risk limit warning.")
                        return
                approval = ApprovalDialog(weights, pv, dry_run=False, parent=self)
                if approval.exec() != QDialog.Accepted or not approval.approved:
                    self.append_log("[KiteDirect] Live order cancelled before broker submission.")
                    self.exec_logs_box.appendPlainText("[AlgoExecution] Live order cancelled before broker submission.")
                    return
                
            mode = "DRY RUN" if dry else "⚠️ LIVE"
            self.append_log(f"[KiteDirect] Placing basket ({mode})…")
            self.exec_logs_box.appendPlainText(f"[KiteDirect] Placing basket ({mode})...")
            
            try:
                self.place_direct_btn.setEnabled(False)
                if hasattr(self, "exec_place_btn"):
                    self.exec_place_btn.setEnabled(False)
                    
                # AUDIT-FIX (Round 4 — E1111): `zerodha_place_basket` is a stub
                # that always raises NotImplementedError; the assignment is
                # technically dead-code but kept for forward-compat — when a
                # real Kite router is wired in, it will return a DataFrame.
                # pylint: disable=assignment-from-no-return
                df = zerodha_place_basket(weights, pv, api_key, acc_token, dry_run=dry,
                                           log_cb=self.append_log)
                if df is not None and not df.empty:
                    self.populate_table(self.execution_table, df)
                    self._set_table_header_visible(self.execution_table, True)
                    self.append_log(f"[KiteDirect] {mode} complete — {len(df)} tickers.")
                    self.exec_logs_box.appendPlainText(f"[KiteDirect] {mode} complete — {len(df)} tickers.")
                    self.algo_progress_bar.setValue(100)
                    self.algo_progress_lbl.setText("Overall Execution Progress: 100% (Completed)")
                else:
                    self.exec_logs_box.appendPlainText("[KiteDirect] No orders placed (empty sheet).")
            except Exception as e:
                self.append_log(f"[KiteDirect] Error: {e}")
                self.exec_logs_box.appendPlainText(f"[KiteDirect] Error: {e}")
            finally:
                self.place_direct_btn.setEnabled(True)
                if hasattr(self, "exec_place_btn"):
                    self.exec_place_btn.setEnabled(True)
            return

        # Algorithmic slicing execution
        weights = getattr(self, "_last_weights", {})
        if not weights:
            self.append_log("[KiteDirect] Run optimizer first.")
            self.exec_logs_box.appendPlainText("[AlgoExecution] Run optimizer first.")
            return

        api_key   = self.kite_key_edit.text().strip()   if hasattr(self, "kite_key_edit")   else ""
        acc_token = self.kite_token_edit.text().strip() if hasattr(self, "kite_token_edit") else ""
        dry = not (self.kite_live_check.isChecked() if hasattr(self, "kite_live_check") else False)
        
        if not dry and (not api_key or not acc_token):
            self.append_log("[KiteDirect] Set KITE_API_KEY / KITE_ACCESS_TOKEN in config for live trading.")
            self.exec_logs_box.appendPlainText("[AlgoExecution] Live execution requires API Key & Access Token.")
            return

        # Prepare orders to slice
        kite_orders_df = None
        if hasattr(self, "last_payload") and self.last_payload:
            kite_orders_df = self.last_payload.get("kite_orders_df")
            
        if kite_orders_df is None or kite_orders_df.empty:
            pv = float(cfg.get("PORTFOLIO_VALUE_INR", cfg.get("PORTFOLIO_VALUE", 1_000_000)))
            portfolio_df = self.last_payload.get("portfolio_df") if hasattr(self, "last_payload") and self.last_payload else None
            kite_orders_df = generate_kite_order_sheet(weights, portfolio_df, pv)

        if kite_orders_df is None or kite_orders_df.empty:
            self.append_log("[KiteDirect] No orders to execute.")
            self.exec_logs_box.appendPlainText("[AlgoExecution] No orders to execute.")
            return

        if not dry:
            # Pre-trade risk limit enforcement dialog
            sector_map = getattr(self, "_last_sector_map", None)
            if sector_map is None and hasattr(self, "last_payload") and self.last_payload:
                sector_map = self.last_payload.get("sector_map")
            enforcer = RiskLimitEnforcer(cfg)
            violations = enforcer.check(weights, sectors=sector_map)
            if violations:
                if not RiskLimitEnforcer.show_violations_dialog(violations, parent=self):
                    self.append_log("[AlgoExecution] Live execution cancelled by user after risk limit warning.")
                    self.exec_logs_box.appendPlainText("[AlgoExecution] Live execution cancelled by user after risk limit warning.")
                    return
            pv_for_approval = float(cfg.get("PORTFOLIO_VALUE_INR", cfg.get("PORTFOLIO_VALUE", 1_000_000)))
            approval = ApprovalDialog(weights, pv_for_approval, dry_run=False, parent=self)
            if approval.exec() != QDialog.Accepted or not approval.approved:
                self.append_log("[AlgoExecution] Live execution cancelled before broker submission.")
                self.exec_logs_box.appendPlainText("[AlgoExecution] Live execution cancelled before broker submission.")
                return

        # Set UI state
        self.exec_logs_box.clear()
        self.exec_logs_box.appendPlainText(f"[AlgoExecution] Initializing {strategy} rebalance execution...")
        self.place_direct_btn.setEnabled(False)
        if hasattr(self, "exec_place_btn"):
            self.exec_place_btn.setEnabled(False)
        self.cancel_exec_btn.setEnabled(True)
        self.algo_progress_bar.setValue(0)
        self.algo_progress_lbl.setText("Overall Execution Progress: 0% (Initializing)")

        # Initialize managers
        from math_engine.algo_execution import AlgoExecutionManager
        duration_mins = self.exec_duration_spin.value()
        slices_count = self.exec_slices_spin.value()
        if strategy == "Market":
            duration_mins = 0.1
            slices_count = 1
        use_mock_ws = self.use_mock_ws_check.isChecked()

        managers = {}
        for _, row in kite_orders_df.iterrows():
            # AUDIT-FIX (Round 6, D-P1): the Kite order sheet's schema (see
            # generate_kite_order_sheet) exposes "tradingsymbol"/"quantity"/
            # "Alloc INR" — there is NO "Symbol" column, so row["Symbol"] raised
            # KeyError and TWAP/VWAP/AC/IS algo execution could never start.
            # "tradingsymbol" is already uppercase & suffix-free by construction.
            sym = str(row["tradingsymbol"]).strip().upper()
            qty = int(row["quantity"])
            if qty <= 0:
                continue
            
            # Estimate decision price
            alloc_inr = float(row.get("Alloc INR", 0))
            if alloc_inr > 0 and qty > 0:
                decision_price = alloc_inr / qty
            else:
                # AUDIT-FIX (Round 43 / AUDIT-04 class): flag the fabricated
                # estimate instead of silently pretending ₹100 is a real price
                # (algo slicing/participation math is only as good as this
                # estimate; the operator should know when it is a guess).
                decision_price = 100.0
                self.exec_logs_box.appendPlainText(
                    f"[AlgoExecution] ⚠️ No Alloc INR for {sym} — decision price estimated at ₹100.0 "
                    f"(not a real quote). Algo slicing accuracy is degraded for this order."
                )
                
            is_buy = str(row.get("Action", "BUY")).upper() == "BUY"
            
            sigma_daily = None
            avg_daily_vol = None
            portfolio_gamma = None
            
            if hasattr(self, "last_payload") and self.last_payload:
                prescreen_df = self.last_payload.get("prescreen_df")
                cfg = self.last_payload.get("cfg", {})
                portfolio_gamma = float(cfg.get("GAMMA", 2.0)) if cfg else 2.0
                
                if prescreen_df is not None and not prescreen_df.empty:
                    import pandas as pd
                    lookup_df = prescreen_df.copy()
                    if "ticker" in lookup_df.columns:
                        lookup_df = lookup_df.set_index("ticker")
                    lookup_df.index = [str(idx).upper().replace(".NS", "").replace(".BO", "") for idx in lookup_df.index]
                    
                    if sym in lookup_df.index:
                        ann_vol = float(lookup_df.loc[sym, "ann_vol"]) if "ann_vol" in lookup_df.columns else np.nan
                        if not np.isnan(ann_vol) and ann_vol > 0:
                            sigma_daily = ann_vol / np.sqrt(252.0)
                        
                        if "adv20" in lookup_df.columns:
                            avg_daily_vol = float(lookup_df.loc[sym, "adv20"])
            
            mgr = AlgoExecutionManager(
                ticker=sym,
                quantity=qty,
                strategy=strategy,
                duration_mins=duration_mins,
                slices_count=slices_count,
                decision_price=decision_price,
                is_buy=is_buy,
                sigma_daily=sigma_daily,
                avg_daily_vol=avg_daily_vol,
                portfolio_gamma=portfolio_gamma
            )
            managers[sym] = mgr

        # Enforce Promotion Gate for Live Broker Trading
        if not use_mock_ws:
            try:
                from live_verify import check_paper_trade_gate_or_raise
                check_paper_trade_gate_or_raise()
            except Exception as gate_err:
                # AUDIT-FIX (Round 5, 2-a-2): this used to import PyQt6's
                # QMessageBox inside a PySide6/PyQt5 application — an instant
                # ImportError that suppressed the gate dialog and aborted the
                # slot. Use the app's own styled message helper.
                self.ws_status_lbl.setText("⛔ Promotion Gate Blocked")
                self.append_log(f"[Broker] Live order placement blocked by promotion gate: {gate_err}")
                self._show_styled_message(
                    "Promotion Gate Blocked",
                    f"Live order placement blocked by promotion gate:\n{gate_err}",
                    _QMESSAGEBOX_ICON.Critical,
                )
                return

        self.ws_status_lbl.setText("🟡 Connecting...")

        # Spawn worker thread
        self.algo_worker = AlgoExecutionWorker(
            parent=self,
            managers=managers,
            use_mock_ws=use_mock_ws,
            api_key=api_key,
            access_token=acc_token,
            duration_mins=duration_mins
        )
        
        self.algo_worker.log_msg.connect(self._on_algo_worker_log)
        self.algo_worker.progress_update.connect(self._on_algo_worker_progress)
        self.algo_worker.table_update.connect(self._on_algo_worker_table)
        self.algo_worker.finished.connect(self._on_algo_worker_finished)
        
        self.algo_worker.start()

    def _on_algo_worker_log(self, msg):
        self.exec_logs_box.appendPlainText(msg)
        self.append_log(msg)

    def _on_algo_worker_progress(self, val, txt):
        self.algo_progress_bar.setValue(val)
        self.algo_progress_lbl.setText(f"Overall Execution Progress: {val}% ({txt})")
        if val > 0:
            self.ws_status_lbl.setText("🟢 Connected & Streaming")

    def _on_algo_worker_table(self, slice_data):
        df = pd.DataFrame(slice_data)
        self.populate_table(self.execution_table, df)

    def _on_algo_worker_finished(self, status):
        self.place_direct_btn.setEnabled(True)
        if hasattr(self, "exec_place_btn"):
            self.exec_place_btn.setEnabled(True)
        self.cancel_exec_btn.setEnabled(False)
        self.ws_status_lbl.setText("🔴 WebSocket: Off")
        
        if status == "Success":
            self.algo_progress_bar.setValue(100)
            self.algo_progress_lbl.setText("Overall Execution Progress: 100% (Completed)")
            self.exec_logs_box.appendPlainText("[AlgoExecution] Algorithmic execution finished successfully.")
            show_styled_message_box("Execution Finished", "Algorithmic slicing session completed successfully.", _QMESSAGEBOX_ICON.Information)
        elif status == "Cancelled":
            self.exec_logs_box.appendPlainText("[AlgoExecution] Algorithmic execution cancelled by user.")
            show_styled_message_box("Execution Cancelled", "Slicing execution was cancelled.", _QMESSAGEBOX_ICON.Warning)
        else:
            self.exec_logs_box.appendPlainText(f"[AlgoExecution] Algorithmic execution stopped: {status}")
            show_styled_message_box("Execution Failed", f"Slicing execution stopped: {status}", _QMESSAGEBOX_ICON.Critical)

    def cancel_algo_execution(self):
        if hasattr(self, "algo_worker") and self.algo_worker and self.algo_worker.isRunning():
            self.exec_logs_box.appendPlainText("[AlgoExecution] Requesting cancellation...")
            self.algo_worker.stop_event.set()

    # ── v17: Live P&L Tracker Handler ─────────────────────────────────────────
    def start_live_pnl(self):
        cfg     = self.collect_cfg()
        weights = getattr(self, "_last_weights", {})
        pv      = float(cfg.get("PORTFOLIO_VALUE_INR", cfg.get("PORTFOLIO_VALUE", 1_000_000)))
        if not weights:
            self.append_log("[LivePnL] Run optimizer first."); return
        api_key   = self.kite_key_edit.text().strip()   if hasattr(self, "kite_key_edit")   else ""
        acc_token = self.kite_token_edit.text().strip() if hasattr(self, "kite_token_edit") else ""
        interval  = int(cfg.get("LIVE_PNL_INTERVAL_SEC", 300))  # 5 min default (was hardcoded; DEFAULT_CFG setting was never read)

        # Build entry prices from last optimizer price history
        entry_prices = {}
        if hasattr(self, "last_payload") and self.last_payload:
            price_df = self.last_payload.get("selected_price_df")
            if price_df is not None and not price_df.empty:
                for t in weights:
                    col = t.replace(".NS", "").replace(".BO", "")
                    for candidate in [col, t]:
                        if candidate in price_df.columns:
                            series = price_df[candidate].dropna()
                            if len(series) > 0:
                                entry_prices[t] = float(series.iloc[-1])
                            break

        if hasattr(self, "_pnl_tracker") and self._pnl_tracker:
            self._pnl_tracker.stop()
        self._pnl_tracker = LivePnLTracker(
            weights, entry_prices, pv,
            callback=self._on_pnl_update,
            interval_sec=interval,
            kite_api_key=api_key,
            kite_access_token=acc_token,
        )
        self._pnl_tracker.start()
        n = len(entry_prices)
        # WIRING: Start real-time risk monitor
        # BUGFIX (Round 41): this used to construct the monitor with hardcoded
        # var_threshold=0.05 / dd_threshold=0.08 / interval_sec=300 — the same
        # numbers DEFAULT_CFG defines as RT_VAR_THRESHOLD / RT_DD_THRESHOLD /
        # RT_RISK_INTERVAL_SEC, but never actually reading them. Editing those
        # settings (or setting USE_REALTIME_RISK=False) had no effect at all.
        # Now honors them, keeping the old values as defaults so behavior is
        # unchanged unless someone configures otherwise. The setup failure is
        # also logged rather than swallowed by a bare `except: pass`, so a
        # monitor that silently failed to start is visible instead of leaving
        # the operator believing risk is being watched.
        if cfg.get("USE_REALTIME_RISK", True):
            try:
                from math_engine.realtime_risk import RealTimeRiskMonitor
                self._risk_monitor = RealTimeRiskMonitor(
                    weights=weights,
                    var_threshold=float(cfg.get("RT_VAR_THRESHOLD", 0.05)),
                    dd_threshold=float(cfg.get("RT_DD_THRESHOLD", 0.08)),
                    interval_sec=int(cfg.get("RT_RISK_INTERVAL_SEC", 300)),
                    # AUDIT-FIX (Round 5, 2-a-9): the callback runs on the monitor's
                    # own thread — QTimer.singleShot(0, …) never fires there. Marshal
                    # via _gui_call so risk alerts actually reach the log panel.
                    callback=lambda alert: self._gui_call.emit(
                        lambda: self.append_log(f"[RiskAlert] {alert.severity}: {alert.message}")),
                )
                self._risk_monitor.start()
                self.append_log("[RiskMonitor] Started — monitoring VaR and drawdown")
            except Exception as _rm_err:
                self._risk_monitor = None
                self.append_log(f"[RiskMonitor] ⚠️ FAILED TO START — risk is NOT being monitored: {_rm_err}")
        else:
            self.append_log("[RiskMonitor] Disabled by USE_REALTIME_RISK=False — VaR/drawdown alerts are OFF.")
        self.append_log(f"[LivePnL] ▶ Started — {n}/{len(weights)} entry prices loaded | refresh={interval}s")
        if "Live P&L" in self.results_tab_labels:
            self._set_results_tab(self.results_tab_labels.index("Live P&L"))


    def _on_pnl_update(self, df, port_pct):
        try:
            self._pnl_df = df; self._pnl_port_pct = port_pct
            QMetaObject.invokeMethod(self, "_apply_pnl_update", Qt.QueuedConnection)
        except Exception as _e:
            try:
                self.append_log(f"[Warning] {_e}")
            except Exception as _exc_p2a_:
                ExceptionLogger.swallow(_exc_p2a_, context='L49168')

    # M12-fix: QMetaObject.invokeMethod with Qt.QueuedConnection requires the target slot to be
    # registered as a Qt slot via the @pyqtSlot() decorator. Without it, the call silently no-ops
    # on some Qt/PySide builds and the Live P&L table never updates.
    @pyqtSlot()
    def _apply_pnl_update(self):
        df  = getattr(self, "_pnl_df", None)
        pct = getattr(self, "_pnl_port_pct", float("nan"))
        if df is not None and not df.empty:
            self.populate_table(self.live_pnl_table, df)
            self._set_table_header_visible(self.live_pnl_table, True)
        pct_str = f"{pct:+.2f}%" if not (isinstance(pct, float) and pct != pct) else "—"
        self.append_log(f"[LivePnL] Portfolio P&L: {pct_str}")
        # AUDIT-FIX (Round 6, A2-P2-4): the RealTimeRiskMonitor was started
        # but update_portfolio_value() had ZERO callers — the monitor
        # computed drawdown against a frozen 1.0 initial value forever, so
        # its VaR/drawdown thresholds could never trigger. Feed it the live
        # portfolio value from the PnL tracker updates.
        try:
            if hasattr(self, "_risk_monitor") and self._risk_monitor and not (isinstance(pct, float) and pct != pct):
                _initial_val = 100000.0
                if hasattr(self, "_pnl_tracker") and self._pnl_tracker:
                    _initial_val = float(getattr(self._pnl_tracker, "portfolio_value", 100000.0) or 100000.0)
                self._risk_monitor.update_portfolio_value(_initial_val * (1.0 + pct / 100.0))
        except Exception:
            pass
        
        # Update drawdown monitor
        if hasattr(self, "_dd_monitor") and self._dd_monitor and not (isinstance(pct, float) and pct != pct):
            initial_val = 100000.0
            if hasattr(self, "_pnl_tracker") and self._pnl_tracker:
                initial_val = getattr(self._pnl_tracker, "portfolio_value", 100000.0)
            current_val = initial_val * (1.0 + pct / 100.0)
            cfg = self.collect_cfg()
            self._dd_monitor.configure(cfg)
            self._dd_monitor.update(current_val, log_cb=self.append_log)

    def closeEvent(self, event):
        # Graceful shutdown of all tracked background threads
        try:
            WorkerLifecycle.shutdown_all()
        except Exception as _exc_wl:
            ExceptionLogger.swallow(_exc_wl, context='worker_lifecycle_shutdown')

        # M11-fix: stop the LiveVerifyWorker if it's still running. Previously closeEvent only
        # waited on self.worker (OptimizerWorker); a live-verify run in progress would be orphaned
        # and keep emitting signals into a half-torn-down window.
        _verify = getattr(self, "_verify_worker", None)
        if _verify is not None and _verify.isRunning():
            try:
                _verify.request_stop()
            except Exception:
                pass
            _verify.wait(2000)

        # ── Stop OptimizerWorker if a run is in progress ──────────────────────
        if hasattr(self, "worker") and self.worker and self.worker.isRunning():
            # AUDIT-FIX (Round 5, 2-a-12): the stop-event registry uses the
            # set_event()/clear_event() API elsewhere in this file; calling
            # .set() here raised AttributeError *inside* the same try-block as
            # request_stop()/wait()/terminate(), so the whole shutdown sequence
            # was skipped and the window died with a running QThread. Try both
            # APIs in their own guarded block, then run the shutdown sequence
            # in a separate try so it always executes.
            try:
                with _ACTIVE_STOP_EVENT_LOCK:
                    if _ACTIVE_STOP_EVENT is not None:
                        if hasattr(_ACTIVE_STOP_EVENT, "set_event"):
                            _stop_evt = getattr(self.worker, "stop_event", None)
                            if _stop_evt is not None:
                                _ACTIVE_STOP_EVENT.set_event(_stop_evt)
                        elif hasattr(_ACTIVE_STOP_EVENT, "set"):
                            _ACTIVE_STOP_EVENT.set()
            except Exception:
                pass
            try:
                if hasattr(self.worker, "request_stop"):
                    self.worker.request_stop()
                self.worker.requestInterruption()
                if not self.worker.wait(3000):          # give it 3 s to exit cleanly
                    self.worker.terminate()             # force-kill if still running
                    self.worker.wait(1000)
            except Exception as _exc_p2a_:
                ExceptionLogger.swallow(_exc_p2a_, context='L49192')

        # ── Stop Live P&L tracker thread ──────────────────────────────────────
        if hasattr(self, "_pnl_tracker") and self._pnl_tracker:
            try:
                self._pnl_tracker.stop()
            except Exception as _exc_p2a_:
                ExceptionLogger.swallow(_exc_p2a_, context='L49199')

        # ── Stop APScheduler ──────────────────────────────────────────────────
        if hasattr(self, "_apscheduler") and self._apscheduler:
            try:
                self._apscheduler.shutdown(wait=False)
            except Exception as _exc_p2a_:
                ExceptionLogger.swallow(_exc_p2a_, context='L49206')

        # ── Stop QTimer auto-run ──────────────────────────────────────────────
        if hasattr(self, "autorun_timer") and self.autorun_timer:
            try:
                self.autorun_timer.stop()
            except Exception as _exc_p2a_:
                ExceptionLogger.swallow(_exc_p2a_, context='L49213')

        # ── Persist last config ───────────────────────────────────────────────
        try:
            self._save_preferences()
        except Exception as _e_:
            ExceptionLogger.swallow(_e_, context="silent_catch")

        event.accept()



    def _switch_mode(self, idx):
        self._mode_stack.setCurrentIndex(idx)
        for i, btn in self._mode_btns.items():
            btn.setChecked(i == idx)
        if hasattr(self, "_workspace_group_btns") and idx < len(self._workspace_group_btns):
            self._set_workspace_group(idx)


    def _build_build_params(self):
        w = QWidget(); lay = QVBoxLayout(w)
        lay.setContentsMargins(6, 6, 6, 6); lay.setSpacing(8)
        # Run / Stop / Profile are in the top command bar — no card here
        lay.addWidget(self._build_core_card())
        lay.addWidget(self._build_backtest_card())
        lay.addWidget(self._build_advanced_card())
        lay.addWidget(self._build_universe_card())
        lay.addWidget(self._build_prev_holdings_card())
        lay.addStretch(1)
        return w


    def _build_research_params(self):
        w = QWidget(); lay = QVBoxLayout(w)
        lay.setContentsMargins(6, 6, 6, 6); lay.setSpacing(8)
        lbl = QLabel("Universe, sector, and factor filters\nare configured in the Build panel.")
        lbl.setWordWrap(True); lbl.setObjectName("MutedText")
        lay.addWidget(lbl); lay.addStretch(1)
        return w


    def _build_risk_params(self):
        w = QWidget(); lay = QVBoxLayout(w)
        lay.setContentsMargins(6, 6, 6, 6); lay.setSpacing(8)
        lbl = QLabel("Risk model and penalty parameters\nare in Build \u2192 Advanced Penalties.")
        lbl.setWordWrap(True); lbl.setObjectName("MutedText")
        lay.addWidget(lbl); lay.addStretch(1)
        return w


    def _build_execution_tab(self):
        page = QWidget()
        lay = QHBoxLayout(page)
        lay.setContentsMargins(10, 10, 10, 10)
        lay.setSpacing(14)

        # ── Left Pane: Controls ──
        left_pane = QWidget()
        left_lay = QVBoxLayout(left_pane)
        left_lay.setContentsMargins(0, 0, 0, 0)
        left_lay.setSpacing(12)
        left_pane.setMaximumWidth(360)

        # Strategy Selection Card
        strat_card = CardFrame("SectionCard")
        sc_lay = QVBoxLayout(strat_card)
        sc_lay.setContentsMargins(12, 12, 12, 12)
        sc_lay.setSpacing(10)
        
        lbl_title = QLabel("Execution Strategy Settings")
        lbl_title.setObjectName("SectionTitle")
        sc_lay.addWidget(lbl_title)

        form = QFormLayout()
        form.setHorizontalSpacing(16)
        form.setVerticalSpacing(8)

        self.exec_strategy_combo = QComboBox()
        self.exec_strategy_combo.addItems(["Market", "TWAP", "VWAP", "Almgren-Chriss", "Implementation Shortfall"])
        self.exec_strategy_combo.setCurrentText(DEFAULT_CFG.get("EXECUTION_STRATEGY", "Market"))
        self.exec_strategy_combo.setToolTip("Market: Immediate single basket order.\nTWAP: Equal time slices.\nVWAP: Dynamic volume curve slices.\nAlmgren-Chriss: Hyperbolic optimal utility execution trajectory.\nImplementation Shortfall: Volatility & drift adaptive slices.")

        self.exec_duration_spin = QDoubleSpinBox()
        self.exec_duration_spin.setRange(1.0, 360.0)
        self.exec_duration_spin.setValue(DEFAULT_CFG.get("EXECUTION_DURATION_MINS", 15.0))
        self.exec_duration_spin.setSuffix(" mins")
        self.exec_duration_spin.setDecimals(1)
        self.exec_duration_spin.setToolTip("Total duration for slicing algorithms.")

        self.exec_slices_spin = QSpinBox()
        self.exec_slices_spin.setRange(1, 100)
        self.exec_slices_spin.setValue(DEFAULT_CFG.get("EXECUTION_SLICES", 5))
        self.exec_slices_spin.setToolTip("Number of execution slices.")

        self.use_mock_ws_check = QCheckBox("Use Mock WebSocket Feed")
        self.use_mock_ws_check.setChecked(DEFAULT_CFG.get("USE_MOCK_WEBSOCKET", True))
        self.use_mock_ws_check.setToolTip("Generate simulated ticks offline instead of connecting to live Zerodha Kite Connect.")

        self.ws_status_lbl = QLabel("🔴 WebSocket: Off")
        self.ws_status_lbl.setObjectName("MutedText")

        form.addRow("Strategy:", self.exec_strategy_combo)
        form.addRow("Duration:", self.exec_duration_spin)
        form.addRow("Slices Count:", self.exec_slices_spin)
        form.addRow(self.use_mock_ws_check)
        form.addRow(self.ws_status_lbl)
        sc_lay.addLayout(form)
        
        left_lay.addWidget(strat_card)

        # Action Card
        act_card = CardFrame("SectionCard")
        ac_lay = QVBoxLayout(act_card)
        ac_lay.setContentsMargins(12, 12, 12, 12)
        ac_lay.setSpacing(10)
        
        lbl_act = QLabel("Order Actions")
        lbl_act.setObjectName("SectionTitle")
        ac_lay.addWidget(lbl_act)

        self.exec_place_btn = QPushButton("⚡  Place Basket")
        self.exec_place_btn.setObjectName("PrimaryButton")
        self.exec_place_btn.setToolTip("Start algorithmic slicing session or execute market basket")
        self.exec_place_btn.clicked.connect(self.place_basket_direct)
        ac_lay.addWidget(self.exec_place_btn)

        self.cancel_exec_btn = QPushButton("🔕  Cancel Execution")
        self.cancel_exec_btn.setEnabled(False)
        self.cancel_exec_btn.setToolTip("Halt the active algorithmic rebalance execution immediately")
        self.cancel_exec_btn.clicked.connect(self.cancel_algo_execution)
        ac_lay.addWidget(self.cancel_exec_btn)

        self.exec_reconcile_btn = QPushButton("🔄  Reconcile Holdings")
        self.exec_reconcile_btn.clicked.connect(self.reconcile_holdings)
        ac_lay.addWidget(self.exec_reconcile_btn)

        self.exec_live_pnl_btn = QPushButton("📈  Start Live P&L")
        self.exec_live_pnl_btn.clicked.connect(self.start_live_pnl)
        ac_lay.addWidget(self.exec_live_pnl_btn)

        self.exec_copy_portfolio_btn = QPushButton("📋  Copy Portfolio CSV")
        self.exec_copy_portfolio_btn.clicked.connect(self._copy_portfolio_to_clipboard)
        ac_lay.addWidget(self.exec_copy_portfolio_btn)

        left_lay.addWidget(act_card)
        left_lay.addStretch(1)

        # ── Right Pane: Tracker & Logs ──
        right_pane = QWidget()
        right_lay = QVBoxLayout(right_pane)
        right_lay.setContentsMargins(0, 0, 0, 0)
        right_lay.setSpacing(12)

        # Overall progress bar
        prog_card = CardFrame("SectionCard")
        pc_lay = QVBoxLayout(prog_card)
        pc_lay.setContentsMargins(12, 12, 12, 12)
        pc_lay.setSpacing(6)
        
        self.algo_progress_lbl = QLabel("Overall Execution Progress: 0%")
        self.algo_progress_lbl.setObjectName("StatusTitle")
        self.algo_progress_bar = QProgressBar()
        self.algo_progress_bar.setRange(0, 100)
        self.algo_progress_bar.setValue(0)
        
        pc_lay.addWidget(self.algo_progress_lbl)
        pc_lay.addWidget(self.algo_progress_bar)
        right_lay.addWidget(prog_card)

        # Splitter for Table and Logs
        splitter = QSplitter(Qt.Vertical)
        splitter.setChildrenCollapsible(False)
        splitter.setHandleWidth(4)

        # Table page / Stack
        table_wrap = QWidget()
        tw_lay = QVBoxLayout(table_wrap)
        tw_lay.setContentsMargins(0, 0, 0, 0)
        tw_lay.setSpacing(6)
        
        tbl_title = QLabel("Order Slices Status")
        tbl_title.setObjectName("SectionTitle")
        tw_lay.addWidget(tbl_title)

        # Stack to support empty placeholder or table
        self.execution_table_stack = QStackedWidget()
        self.execution_placeholder = QLabel("Order tracker is idle. Place a basket to view active slices.", alignment=Qt.AlignCenter)
        self.execution_placeholder.setObjectName("EmptyStateLabel")
        self.execution_table_stack.addWidget(self.execution_placeholder)

        self.execution_table = self._make_table()
        self.execution_table_stack.addWidget(self.execution_table)
        self.execution_table_stack.setCurrentIndex(0)
        
        # Link execution_table with stack for populate_table compatibility
        self.execution_table._stack = self.execution_table_stack
        self.execution_table._placeholder = self.execution_placeholder
        
        tw_lay.addWidget(self.execution_table_stack, 1)
        splitter.addWidget(table_wrap)

        # Logs box
        logs_wrap = QWidget()
        lw_lay = QVBoxLayout(logs_wrap)
        lw_lay.setContentsMargins(0, 0, 0, 0)
        lw_lay.setSpacing(6)
        
        logs_title = QLabel("Algorithmic Execution Logs")
        logs_title.setObjectName("SectionTitle")
        lw_lay.addWidget(logs_title)

        self.exec_logs_box = QPlainTextEdit()
        self.exec_logs_box.setReadOnly(True)
        self.exec_logs_box.setFont(QFont("Menlo", 10))
        self.exec_logs_box.setPlaceholderText("Execution log messages will appear here...")
        lw_lay.addWidget(self.exec_logs_box, 1)
        
        splitter.addWidget(logs_wrap)
        splitter.setSizes([350, 180])
        right_lay.addWidget(splitter, 1)

        lay.addWidget(left_pane)
        lay.addWidget(right_pane, 1)

        return page


    def _set_workspace_group(self, group_idx):
        """Show only the sub-tabs belonging to the chosen workspace group."""
        self._workspace_current_group = group_idx
        for i, btn in enumerate(self._workspace_group_btns):
            btn.setChecked(i == group_idx)
        group_tabs = self._WORKSPACE_GROUPS[group_idx][1]
        for i, btn in enumerate(self.results_nav_buttons):
            btn.setVisible(i in group_tabs)
        # Navigate to first tab in this group if current tab is not in it
        current = self.tabs.currentIndex() if hasattr(self, "tabs") else 0
        if not group_tabs: return
        if current not in group_tabs:
            self._set_results_tab(group_tabs[0])
        # Mirror mode rail selection
        if hasattr(self, "_mode_btns") and group_idx < len(self._mode_btns):
            for i, btn in self._mode_btns.items():
                btn.setChecked(i == group_idx)
            if hasattr(self, "_mode_stack"):
                self._mode_stack.setCurrentIndex(group_idx)


    def _resize_current_tab_once(self):
        """v17.CZ — One-time resize on first visit to a tab. Uses fixed column widths,
        NOT ResizeToContents, so it never blocks the UI thread."""
        page = self.tabs.currentWidget()
        if page is None:
            return
        for tbl in page.findChildren(QTableWidget):
            if tbl.isVisible() and tbl.columnCount() > 0:
                hh = tbl.horizontalHeader()
                # Use fixed stretch instead of ResizeToContents (which is O(rows×cols))
                hh.setSectionResizeMode(QHeaderView.Stretch)
                # Cap any column that stretched too wide
                QTimer.singleShot(0, lambda t=tbl: self._cap_columns(t))


    def _cap_columns(self, tbl):
        """Cap columns at 260px after stretch, then switch to Interactive."""
        try:
            hh = tbl.horizontalHeader()
            hh.setSectionResizeMode(QHeaderView.Interactive)
            for c in range(tbl.columnCount()):
                if hh.sectionSize(c) > 260:
                    hh.resizeSection(c, 260)
                elif hh.sectionSize(c) < 60:
                    hh.resizeSection(c, 60)
        except RuntimeError as _e:
            pass  # widget deleted


    def _build_right_inspector(self):
        """Persistent right-side inspector: holding drilldown + live alert rail."""
        panel = CardFrame("SectionCard")
        panel.setMinimumWidth(250); panel.setMaximumWidth(360)
        lay = QVBoxLayout(panel); lay.setContentsMargins(14, 14, 14, 14); lay.setSpacing(10)

        insp_lbl = QLabel("Inspector"); insp_lbl.setObjectName("SectionTitle")
        self.detail_title  = QLabel("Select a holding")
        self.detail_title.setObjectName("StatusTitle")
        self.detail_reason = QLabel(
            "Portfolio rationale and sector-relative context will appear here.")
        self.detail_reason.setWordWrap(True); self.detail_reason.setObjectName("MutedText")
        self.detail_stats  = QPlainTextEdit(); self.detail_stats.setReadOnly(True)
        self.detail_stats.setMinimumHeight(200)

        alert_lbl = QLabel("Active Alerts"); alert_lbl.setObjectName("SectionTitle")
        self.alert_rail = QPlainTextEdit(); self.alert_rail.setReadOnly(True)
        self.alert_rail.setMaximumHeight(120)
        self.alert_rail.setPlaceholderText("Risk and execution alerts appear here.")

        lay.addWidget(insp_lbl)
        lay.addWidget(self.detail_title)
        lay.addWidget(self.detail_reason)
        lay.addWidget(self.detail_stats, 1)
        lay.addWidget(alert_lbl)
        lay.addWidget(self.alert_rail)
        return panel


    def _show_exports_menu(self):
        """Overflow menu for all export actions, opened from the top-bar Export button."""
        menu = GlassMenu(self)
        menu.addAction("Portfolio CSV",       self.export_portfolio_csv)
        menu.addAction("Universe CSV",        self.export_prescreen_csv)
        menu.addAction("Diagnostics CSV",     self.export_diagnostics_csv)
        menu.addAction("Snapshot JSON",       self.export_run_snapshot_json)
        menu.addAction("Investment Memo",     self.export_investment_memo_md)
        menu.addAction("Chart Pack",          self.export_chart_pack)
        menu.addAction("Breakout CSV",        self.export_breakout_csv)
        menu.addAction("Pre-Breakout CSV",    self.export_prebreakout_csv)
        menu.addAction("Copy Portfolio CSV",  self._copy_portfolio_to_clipboard)
        menu.addSeparator()
        menu.addAction("Full Snapshot Bundle", self._export_full_snapshot)
        menu.addAction("Strategy Profiles",   self._open_profiles)
        menu.addAction("Universe Manager",     self._open_universe_manager)
        menu.addSeparator()
        menu.addAction("Export PDF / Report", self._export_pdf_now)
        btn = self.exports_btn
        menu.exec(btn.mapToGlobal(btn.rect().bottomLeft()))



    def _export_full_snapshot(self):
        """Bundle all result tables into a timestamped snapshot folder."""
        payload = getattr(self, "_last_payload", {})
        cfg     = self.collect_cfg()
        regime  = getattr(self, "_last_regime_info", {})
        if not payload:
            self.append_log("[Snapshot] No payload yet — run optimizer first."); return
        try:
            exporter = PortfolioSnapshotExporter()
            dest = exporter.export(payload, cfg, regime, log_cb=self.append_log)
            self._show_styled_message("Snapshot Exported", "Full snapshot saved to:\n" + str(dest), _QMESSAGEBOX_ICON.Information)
        except Exception as _e_snap:
            self.append_log("[Snapshot] Error: " + str(_e_snap))


    def _on_pnl_data(self, data):
        ts = data.get("timestamp","")[:19]
        self.append_log("[LivePnL] Data refreshed @ " + ts)


    def _open_universe_manager(self):
        dlg = MultiUniverseManagerDialog(parent=self)
        dlg.universe_applied.connect(
            lambda tks: self.manual_symbols.setPlainText(tks)
            if hasattr(self, "manual_symbols") else None)
        dlg.exec()


    def _open_profiles(self):
        """Open StrategyProfileDialog."""
        cfg = self.collect_cfg()
        dlg = StrategyProfileDialog(current_cfg=cfg, parent=self)
        dlg.profile_loaded.connect(self._apply_profile_cfg)
        dlg.exec()


    def _apply_profile_cfg(self, cfg: dict):
        """Apply loaded profile cfg to all visible parameter widgets."""
        self._active_profile_cfg = dict(cfg)
        self.append_log("[Profile] Loaded profile — %d keys." % len(cfg))
        for k, v in cfg.items():
            try:
                self._set_cfg_field(k, v)
            except Exception:
                pass


    def _open_provider_switcher(self):
        dlg = ProviderSwitcherDialog(
            status_bar=getattr(self, "_provider_bar", None), parent=self)
        dlg.exec()


    def _update_sched_label(self):
        if hasattr(self, "_sched_label") and hasattr(self, "_scheduler"):
            self._sched_label.setText(self._scheduler.status_text())


    def _check_crowding_notif(self):
        """Fire notif if any factor is CROWDED after factor_crowding_page computed."""
        if not hasattr(self,"factor_crowding_page"): return
        fc = self.factor_crowding_page
        thr = fc._thr.value()
        if not hasattr(fc,"_payload") or not fc._payload: return
        scores = fc._compute_factor_scores()
        crowded = [f for f,s in scores.items() if s >= thr]
        if crowded and hasattr(self,"notif_centre_page"):
            self.notif_centre_page.log_event(
                "WARN","Crowding","Crowded factors: %s"%", ".join(crowded))


    def _apply_tuning_params(self, params: dict):
        """Called by ParameterTuningWizard.apply_requested signal."""
        key_map = {"NUM_READS": "num_reads_spin", "GAMMA": "gamma_spin",
                   "THETA": "theta_spin",   "ALPHA": "alpha_spin"}
        for key, val in params.items():
            widget_name = key_map.get(key)
            if widget_name and hasattr(self, widget_name):
                w = getattr(self, widget_name)
                if hasattr(w, "setValue"): w.setValue(float(val))
        self.append_log("[Wizard] Applied: %s" % ', '.join('%s=%.1f'%(k,v) for k,v in params.items()))
        if hasattr(self,"notif_centre_page"):
            self.notif_centre_page.log_event("SUCCESS","Wizard","Params applied: %s"%str(params))


    def _get_aum_inr(self) -> float:
        """Return AUM in INR from the AUM spin box (value is in Lakhs)."""
        try:
            return float(self.aum_spin.value()) * 1e5
        except Exception as _e:
            return 10_000_000.0


    def _run_compliance_checks(self, p: dict):
        try:
            cfg   = self.collect_cfg()
            eng   = ComplianceEngine(cfg)
            viols = eng.check(
                p.get("portfolio_df"),
                p.get("signal_df"),
                p.get("sector_map"),
            )
            if not viols:
                df = pd.DataFrame([{
                    "Severity": "\u2705 PASS", "Rule": "ALL_CLEAR",
                    "Ticker": "\u2014", "Value": "\u2014", "Limit": "\u2014",
                    "Message": "No compliance violations detected.",
                }])
            else:
                df = pd.DataFrame(viols)
                blocks = [v for v in viols if "BLOCK" in str(v.get("Severity", ""))]
                if blocks:
                    AuditLogger.log(
                        "COMPLIANCE_BLOCK", "pre_trade_check",
                        entity=",".join(v.get("Ticker", "") for v in blocks),
                        new_val=f"{len(blocks)} BLOCK violation(s)",
                        meta={"violations": viols[:10]},
                    )
            self.populate_table(self.compliance_table, df)
            # Circuit breaker status
            cb = CircuitBreaker(cfg)
            tripped, reason = cb.check_history()
            if tripped:
                self.circuit_status_lbl.setText(f"TRIPPED: {reason[:60]}")
                self.circuit_status_lbl.setStyleSheet(f"color:{_QSS.RED_ALT};font-weight:700;")
                AuditLogger.log("CIRCUIT_BREAK", "auto_halt", new_val=reason)
                self.append_log(f"[CircuitBreaker] TRIPPED \u2014 {reason}")
            else:
                self.circuit_status_lbl.setText("Status: Clear")
                self.circuit_status_lbl.setStyleSheet(f"color:{_QSS.GREEN_BRIGHT};")
            n_b = sum(1 for v in viols if "BLOCK"  in str(v.get("Severity", "")))
            n_r = sum(1 for v in viols if "BREACH" in str(v.get("Severity", "")))
            n_w = sum(1 for v in viols if "WARN"   in str(v.get("Severity", "")))
            if viols:
                self.append_log(
                    f"[Compliance] {len(viols)} issue(s) \u2014 "
                    f"BLOCK:{n_b} BREACH:{n_r} WARN:{n_w}"
                )
        except Exception as _e:
            self.append_log(f"[Compliance] {_e}")


    def _run_data_quality(self, p: dict):
        try:
            dq = DataValidator.validate_portfolio(
                p.get("portfolio_df"), p.get("signal_df")
            )
            if dq is not None and not dq.empty:
                self.populate_table(self.data_quality_table, dq)
                if "Valid" in dq.columns:
                    bad = dq[dq["Valid"] == "\u26a0\ufe0f"]
                    if not bad.empty:
                        self.append_log(
                            f"[DataQuality] {len(bad)} ticker(s) with data issues."
                        )
        except Exception as _e:
            self.append_log(f"[DataQuality] {_e}")


    def _run_exec_cost(self, p: dict):
        try:
            aum = self._get_aum_inr()
            ec  = ExecutionCostModel.estimate_portfolio(
                p.get("portfolio_df"), p.get("signal_df"), aum
            )
            if ec is not None and not ec.empty:
                self.populate_table(self.exec_cost_table, ec)
                total_row = ec[ec["Ticker"] == "\u2500\u2500 TOTAL \u2500\u2500"]
                if not total_row.empty:
                    cost = total_row.iloc[0].get("Est. Cost \u20b9", "\u2014")
                    self.append_log(
                        f"[ExecCost] Total estimated transaction cost: {cost}"
                    )
        except Exception as _e:
            self.append_log(f"[ExecCost] {_e}")


    def _run_stress_tests(self, p: dict):
        try:
            aum = self._get_aum_inr()
            st  = StressTestEngine.run(
                p.get("portfolio_df"), p.get("signal_df"), aum
            )
            if st is not None and not st.empty:
                self.populate_table(self.risk_table, st)
                self.append_log(
                    f"[StressTest] {len(st)} Indian market scenarios. "
                    f"AUM: \u20b9{aum / 1e5:.0f}L"
                )
        except Exception as _e:
            self.append_log(f"[StressTest] {_e}")


    def _refresh_audit_table(self):
        try:
            rows = AuditLogger.load_recent(300)
            if rows:
                df = pd.DataFrame(rows)
                df.rename(columns={
                    "ts":         "Timestamp",
                    "event_type": "Event",
                    "action":     "Action",
                    "entity":     "Entity",
                    "old_val":    "Old Value",
                    "new_val":    "New Value",
                    "meta":       "Metadata",
                }, inplace=True)
                self.populate_table(self.audit_table, df)
        except Exception as _e:
            self.append_log(f"[Audit] {_e}")


def _load_legacy_widget(class_name):
    # Standard modular ones in ui/tabs
    if class_name in ["QuarterlyResultsScanner", "EarningsSurpriseTracker", "RevenueGrowthComparator", "MarginTrendAnalyzer", "ConsensusForecastPanel", "CorporateActionsLogPanel"]:
        from ui.tabs.corporate import (
            QuarterlyResultsScanner, EarningsSurpriseTracker,
            RevenueGrowthComparator, MarginTrendAnalyzer, ConsensusForecastPanel,
            CorporateActionsLogPanel
        )
        if class_name == "QuarterlyResultsScanner": return QuarterlyResultsScanner()
        if class_name == "EarningsSurpriseTracker": return EarningsSurpriseTracker()
        if class_name == "RevenueGrowthComparator": return RevenueGrowthComparator()
        if class_name == "MarginTrendAnalyzer": return MarginTrendAnalyzer()
        if class_name == "ConsensusForecastPanel": return ConsensusForecastPanel()
        if class_name == "CorporateActionsLogPanel": return CorporateActionsLogPanel()
    elif class_name == "OptionsChainViewer":
        from ui.tabs.options_chain import OptionsChainViewer
        return OptionsChainViewer()
    
    import importlib
    mod = importlib.import_module("ui.legacy_widgets")
    try:
        cls = getattr(mod, class_name)
    except AttributeError as exc:
        raise ImportError(f"Legacy widget {class_name!r} is not available in split modules") from exc
    return cls()


# ── Application entry point ──────────────────────────────────────────────
def main():
    try:
        app = QApplication(sys.argv)
        apply_theme(app, dark=True)   # v17: dark mode on startup
        app.setApplicationName(APP_NAME)
        app.setStyle("Fusion")
        win = MainWindow()
        win.statusBar().showMessage("Ready — configure and press ▶ Run")
        win.show()
        win.raise_()
        win.activateWindow()
        QTimer.singleShot(150, win.raise_)
        QTimer.singleShot(150, win.activateWindow)
        
        # ARCH-06: LazyTabManager wired to main tab widget
        win._lazy_tab_manager = LazyTabManager(win.tabs if hasattr(win, "tabs")
                                               else (win._central_tabs if hasattr(win, "_central_tabs")
                                                     else win.centralWidget()))
        _ltm = win._lazy_tab_manager
        
        # Register the 45 lazy tabs (disabled)
        lazy_tabs_config = {}

        # Dynamically merge all 400+ collected classes
        if hasattr(win, "_dynamic_tab_classes"):
            lazy_tabs_config.update(win._dynamic_tab_classes)

        for label, class_name in lazy_tabs_config.items():
            if label in win.results_tab_labels:
                idx = win.results_tab_labels.index(label)
                def make_factory(cname):
                    return lambda: _load_legacy_widget(cname)
                _ltm.register(idx, label, make_factory(class_name))

        try:
            _ltm.wire_tab_changed()
        except Exception as _e:
            archlog.error('Exception detail', exc_info=True)
            pass
            
        exec_fn = getattr(app, "exec", None) or getattr(app, "exec_", None)
        import atexit
        atexit.register(WorkerLifecycle.shutdown_all)
        sys.exit(exec_fn())
    except Exception as _e:
        archlog.error('Exception detail', exc_info=True)
