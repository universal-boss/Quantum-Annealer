"""
ui/styling.py
=============
Single source of truth for Qt stylesheet colours re-exported from utils.py.

All code must use utils._QSS (or f_QSS alias) to guarantee a single canonical
dark blue-grey palette across the entire codebase.
"""
# Re-export canonical _QSS from utils.
from utils import _QSS, f_QSS  # noqa: F401
