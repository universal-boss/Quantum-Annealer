"""
ui/tabs/ai_copilot.py
======================
AI Copilot & Quant Auditor Panel.
Provides interactive chat, news gathering, and portfolio prospects auditing powered by Gemini API (or rule-based local fallback).
"""
import sys
import time
import json
import urllib.parse
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor, as_completed
import pandas as pd

# ROUND-44 FIX: `import markdown` used to be an UNGUARDED top-level import,
# but `markdown` was never declared in requirements.txt — so on a fresh
# `pip install -r requirements.txt` environment (with PySide6 present) the
# AI Copilot tab raised ModuleNotFoundError at import time, and because
# ui/main_window.py imports this module unconditionally at ITS top level,
# the ENTIRE desktop application failed to launch. markdown is optional
# rich-rendering only: both call sites already fall back to <pre> rendering
# through their except paths, so a missing library degrades gracefully.
try:
    import markdown  # noqa: F401  (optional; declared in requirements.txt)
except ImportError:
    markdown = None
try:
    from PySide6.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QPlainTextEdit, QTextBrowser, QFrame
    )
    from PySide6.QtCore import Qt, QThread
    from PySide6.QtGui import QColor, QFont, QTextCursor
except ImportError:
    from PyQt5.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QPlainTextEdit, QTextBrowser, QFrame
    )
    from PyQt5.QtCore import Qt, QThread
    from PyQt5.QtGui import QColor, QFont, QTextCursor

from ui.styling import _QSS
from utils import load_credentials, NSEClient, _launch

class AICopilotPanel(QWidget):
    """
    Modular tab for interactive AI audits and conversational copilot functionality.
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("AICopilotPanel")
        self.last_payload = {}
        self.chat_history = []  # List of {"role": "user"|"model", "parts": [{"text": str}]}
        self._active_thread = None
        self._active_worker = None

        self._build_ui()
        self._update_status_badge()

    def _build_ui(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 14, 14, 14)
        lay.setSpacing(10)

        # 1. Header Row
        header_lay = QHBoxLayout()
        title_lbl = QLabel("🤖 AI Copilot & Portfolio Auditor")
        title_lbl.setStyleSheet("font-size: 16px; font-weight: bold; color: #ffffff;")
        header_lay.addWidget(title_lbl)
        header_lay.addStretch()

        self.status_badge = QLabel("Initializing...")
        self.status_badge.setStyleSheet(
            "background-color: rgba(255, 255, 255, 0.08); "
            "color: #8a99ad; border: 1px solid #1c1c1e; "
            "border-radius: 4px; padding: 2px 8px; font-size: 10px; font-weight: 600;"
        )
        header_lay.addWidget(self.status_badge)

        export_hdr_btn = QPushButton("📥 Export AI Report")
        export_hdr_btn.setObjectName("SecondaryButton")
        export_hdr_btn.setFixedHeight(28)
        export_hdr_btn.clicked.connect(self._export_ai_report)
        header_lay.addWidget(export_hdr_btn)

        clear_btn = QPushButton("🧹 Clear Chat")
        clear_btn.setObjectName("SecondaryButton")
        clear_btn.setFixedHeight(28)
        clear_btn.clicked.connect(self._clear_chat)
        header_lay.addWidget(clear_btn)

        lay.addLayout(header_lay)

        # 2. Chat/Response Log (QTextBrowser)
        self.chat_log = QTextBrowser()
        self.chat_log.setOpenExternalLinks(True)
        self.chat_log.setStyleSheet(
            "QTextBrowser {"
            "  background-color: #000000;"
            "  border: 1px solid #1c1c1e;"
            "  border-radius: 6px;"
            "  color: #f8f9fa;"
            "  padding: 10px;"
            "}"
        )
        self.chat_log.setFont(QFont("Menlo", 11))
        self.chat_log.setPlaceholderText("No conversation started. Click 'Generate Portfolio Audit' to run an automated analysis.")
        lay.addWidget(self.chat_log, 1)

        # 3. Input & Actions Card
        input_card = QFrame()
        input_card.setObjectName("SectionCard")
        input_lay = QVBoxLayout(input_card)
        input_lay.setContentsMargins(12, 12, 12, 12)
        input_lay.setSpacing(8)

        self.prompt_input = QPlainTextEdit()
        self.prompt_input.setPlaceholderText("Ask the AI Copilot about this portfolio (e.g., 'What are the main risks here?' or 'Suggest hedge ideas') ...")
        self.prompt_input.setFixedHeight(54)
        self.prompt_input.setStyleSheet(
            "QPlainTextEdit {"
            "  background-color: #141a1d;"
            "  border: 1px solid #1c1c1e;"
            "  border-radius: 5px;"
            "  color: #f8f9fa;"
            "  padding: 6px;"
            "}"
        )
        input_lay.addWidget(self.prompt_input)

        btn_row = QHBoxLayout()
        self.audit_btn = QPushButton("▶ Generate Portfolio Audit")
        self.audit_btn.setObjectName("PrimaryButton")
        self.audit_btn.setFixedHeight(30)
        self.audit_btn.clicked.connect(self._on_audit_clicked)
        btn_row.addWidget(self.audit_btn)

        self.send_btn = QPushButton("🚀 Send Prompt")
        self.send_btn.setObjectName("PrimaryButton")
        self.send_btn.setFixedHeight(30)
        self.send_btn.clicked.connect(self._on_send_clicked)
        btn_row.addWidget(self.send_btn)

        self.export_btn = QPushButton("📥 Export Report / CSV")
        self.export_btn.setObjectName("SecondaryButton")
        self.export_btn.setFixedHeight(30)
        self.export_btn.clicked.connect(self._export_ai_report)
        btn_row.addWidget(self.export_btn)

        self.loading_lbl = QLabel("🤖 Thinking...")
        self.loading_lbl.setStyleSheet(f"color: {_QSS.TEAL}; font-weight: bold; padding-left: 8px;")
        self.loading_lbl.hide()
        btn_row.addWidget(self.loading_lbl)

        btn_row.addStretch()
        input_lay.addLayout(btn_row)

        lay.addWidget(input_card)

    def _update_status_badge(self):
        creds = load_credentials()
        has_key = bool(creds.get("GEMINI_API_KEY"))
        if has_key:
            self.status_badge.setText("● Gemini API Connected")
            self.status_badge.setStyleSheet(
                "background-color: rgba(5, 150, 105, 0.1); "
                f"color: {_QSS.GREEN_SUCCESS}; border: 1px solid {_QSS.GREEN_SUCCESS}; "
                "border-radius: 4px; padding: 2px 8px; font-size: 10px; font-weight: 600;"
            )
        else:
            self.status_badge.setText("● Offline Local Mode")
            self.status_badge.setStyleSheet(
                "background-color: rgba(227, 179, 65, 0.1); "
                f"color: {_QSS.GOLD}; border: 1px solid {_QSS.GOLD}; "
                "border-radius: 4px; padding: 2px 8px; font-size: 10px; font-weight: 600;"
            )

    def update_portfolio_data(self, p: dict):
        """Called by MainWindow when optimization run finishes."""
        self.last_payload = p
        self._update_status_badge()

    def _clear_chat(self):
        self.chat_history.clear()
        self.chat_log.clear()
        self.chat_log.setPlaceholderText("Chat cleared. Ready for new audits or prompts.")

    def _export_ai_report(self):
        """Export current AI Copilot audit report to standalone HTML & CSV files in App Folder."""
        import os
        import pandas as pd
        # ROUND-44 FIX: the deferred `import markdown` here would raise an
        # uncaught ImportError inside _export_ai_report when the optional
        # library is absent; the module-level `markdown` (None in that case)
        # is used instead and the body_html except-fallback renders the
        # report inside <pre> tags.
        from utils import BASE_DIR
        
        # 1. Gather latest AI response
        latest_ai_text = ""
        for msg in reversed(self.chat_history):
            if msg.get("role") == "model" and msg.get("parts"):
                latest_ai_text = msg["parts"][0].get("text", "")
                if latest_ai_text:
                    break
                    
        if not latest_ai_text:
            latest_ai_text = self.chat_log.toPlainText().strip()
            
        if not latest_ai_text or "No conversation started" in latest_ai_text:
            self._append_to_chat("System", "⚠️ **No AI Report Available to Export.** Please click **'▶ Generate Portfolio Audit'** first.")
            return

        app_dir = str(BASE_DIR)
        html_out_path = os.path.join(app_dir, "AI_Copilot_Research_Report.html")
        csv_out_path = os.path.join(app_dir, "AI_Copilot_Research_Report.csv")

        # 2. Build HTML Report
        try:
            body_html = markdown.markdown(latest_ai_text, extensions=['tables', 'fenced_code', 'nl2br'])
        except Exception:
            body_html = f"<pre>{latest_ai_text}</pre>"
        
        full_html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>AI Copilot Institutional Stock Intelligence Report</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background-color: #0b0e11; color: #e2e8f0; padding: 30px; line-height: 1.6; }}
        h1, h2, h3, h4 {{ color: #f0c040; margin-top: 24px; font-weight: 700; }}
        table {{ width: 100%; border-collapse: collapse; margin: 20px 0; background-color: #141a1d; border-radius: 8px; overflow: hidden; }}
        th, td {{ padding: 12px 14px; text-align: left; border-bottom: 1px solid rgba(255,255,255,0.08); font-size: 13px; }}
        th {{ background-color: #1e262b; color: #00f2fe; font-weight: 600; text-transform: uppercase; font-size: 11px; letter-spacing: 0.5px; }}
        tr:hover {{ background-color: rgba(255,255,255,0.04); }}
        code {{ background-color: rgba(0, 242, 254, 0.1); color: #00f2fe; padding: 2px 6px; border-radius: 4px; font-family: monospace; }}
        strong {{ color: #ffffff; }}
        .header-box {{ background: linear-gradient(135deg, #141a1d 0%, #1e262b 100%); border: 1px solid rgba(240, 192, 64, 0.3); border-radius: 10px; padding: 20px; margin-bottom: 24px; }}
        .footer {{ margin-top: 40px; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 15px; color: #8a99ad; font-size: 12px; text-align: center; }}
    </style>
</head>
<body>
    <div class="header-box">
        <h1 style="margin: 0; font-size: 22px;">⚡ AI Copilot Institutional Research & Stock Intelligence Audit</h1>
        <p style="margin: 6px 0 0 0; color: #8a99ad; font-size: 13px;">Generated automatically by Quantum Annealer AI Engine • Saved to App Folder</p>
    </div>
    {body_html}
    <div class="footer">
        Generated by Quantum Annealer — Pinnacle SOTA Edition
    </div>
</body>
</html>"""

        with open(html_out_path, "w", encoding="utf-8") as f:
            f.write(full_html)

        # 3. Export CSV dataset of full post-screening intelligence
        intel_csv = os.path.join(app_dir, "post_screening_intelligence.csv")
        comb_csv = os.path.join(app_dir, "combined_portfolio.csv")
        
        target_csv = intel_csv if os.path.exists(intel_csv) else (comb_csv if os.path.exists(comb_csv) else None)
        if target_csv:
            try:
                df = pd.read_csv(target_csv)
                df.to_csv(csv_out_path, index=False)
            except Exception:
                pass

        # 4. Notify User in Chat Log
        msg = f"""✅ **AI Research Report Successfully Exported to App Folder!**

- 🌐 **HTML Report**: [AI_Copilot_Research_Report.html](file://{html_out_path})
- 📊 **CSV Data**: [AI_Copilot_Research_Report.csv](file://{csv_out_path})

Both files have been saved directly inside your App Folder (`{app_dir}`). Click the links above to view!"""

        self._append_to_chat("System", msg)

    def _on_audit_clicked(self):
        prompt = "Please run a comprehensive quantitative audit of this portfolio configuration."
        self._submit_query(prompt, send_payload_context=True)

    def _on_send_clicked(self):
        prompt = self.prompt_input.toPlainText().strip()
        if not prompt:
            return
        self.prompt_input.clear()
        self._submit_query(prompt, send_payload_context=True)

    def _ensure_payload_loaded(self):
        """Auto-loads portfolio & broad universe holdings from App Folder CSV files."""
        if not self.last_payload or self.last_payload.get("portfolio_df") is None or self.last_payload["portfolio_df"].empty:
            import os
            from utils import BASE_DIR
            
            app_dir = str(BASE_DIR)
            desktop_dir = os.path.expanduser("~/Desktop")

            app_intel = os.path.join(app_dir, "post_screening_intelligence.csv")
            app_comb = os.path.join(app_dir, "combined_portfolio.csv")
            app_univ = os.path.join(app_dir, "combined_universe.csv")
            desk_intel = os.path.join(desktop_dir, "post_screening_intelligence.csv")
            desk_comb = os.path.join(desktop_dir, "combined_portfolio.csv")

            dfs = []
            for candidate in [app_intel, app_comb, app_univ, desk_intel, desk_comb]:
                if os.path.exists(candidate):
                    try:
                        d = pd.read_csv(candidate)
                        if not d.empty:
                            dfs.append(d)
                    except Exception:
                        pass

            if dfs:
                merged_df = pd.concat(dfs, ignore_index=True)
                col = "Ticker" if "Ticker" in merged_df.columns else ("Symbol" if "Symbol" in merged_df.columns else None)
                if col:
                    merged_df = merged_df.drop_duplicates(subset=[col], keep="first")
                self.last_payload = {"portfolio_df": merged_df}

    def _get_active_tickers(self) -> list:
        """Extract stock tickers ordered by Tier-1 Quant Rank score (NOT alphabetical)."""
        self._ensure_payload_loaded()
        
        ordered_list = []
        df = self.last_payload.get("portfolio_df")
        if df is not None and not df.empty:
            col = "Ticker" if "Ticker" in df.columns else ("Symbol" if "Symbol" in df.columns else None)
            if col:
                # Rank tickers by score if available
                sort_col = None
                for c in ["Tier-1 Quant Score", "Breakout Score", "Multibagger Score", "Weight%", "Weight", "MatchCount"]:
                    if c in df.columns:
                        sort_col = c
                        break
                if sort_col:
                    sorted_df = df.sort_values(by=sort_col, ascending=False)
                    for t_val in sorted_df[col].dropna().unique():
                        clean_t = str(t_val).split()[-1]
                        if clean_t and clean_t != "CASH" and clean_t not in ordered_list:
                            ordered_list.append(clean_t)
                else:
                    for t_val in df[col].dropna().unique():
                        clean_t = str(t_val).split()[-1]
                        if clean_t and clean_t != "CASH" and clean_t not in ordered_list:
                            ordered_list.append(clean_t)

        # Append breakout watchlists
        for key in ["breakout_df", "prebreakout_df"]:
            w_df = self.last_payload.get(key)
            if w_df is not None and not w_df.empty:
                col = "Ticker" if "Ticker" in w_df.columns else ("Symbol" if "Symbol" in w_df.columns else None)
                if col:
                    for t_val in w_df[col].dropna().unique():
                        clean_t = str(t_val).split()[-1]
                        if clean_t and clean_t != "CASH" and clean_t not in ordered_list:
                            ordered_list.append(clean_t)

        return ordered_list

    def _fetch_rss_news_for_ticker(self, ticker: str) -> list:
        """Download latest 5 Google News RSS headlines for a given ticker."""
        clean_ticker = ticker.split(".")[0]  # strip .NS/BSE suffix
        query = f"{clean_ticker} stock news"
        encoded_query = urllib.parse.quote(query)
        url = f"https://news.google.com/rss/search?q={encoded_query}&hl=en-IN&gl=IN&ceid=IN:en"
        
        try:
            resp = NSEClient.get(url, timeout=10)
            if resp.status_code != 200:
                return []
                
            root = ET.fromstring(resp.content)
            items = []
            for item in root.findall(".//item")[:5]:
                title = item.find("title").text if item.find("title") is not None else ""
                pub_date = item.find("pubDate").text if item.find("pubDate") is not None else ""
                link = item.find("link").text if item.find("link") is not None else ""
                items.append({
                    "title": title,
                    "pub_date": pub_date,
                    "link": link
                })
            return items
        except Exception:
            return []

    def _fetch_all_news(self, tickers: list) -> dict:
        """Concurrently fetch news for top 8 tickers using ThreadPoolExecutor."""
        target_tickers = tickers[:8]  # Limit query size to avoid rate limits
        results = {}
        with ThreadPoolExecutor(max_workers=4) as executor:
            future_to_ticker = {
                executor.submit(self._fetch_rss_news_for_ticker, t): t
                for t in target_tickers
            }
            # L29-fix: iterate futures as they complete (as_completed) instead of in submission
            # order (dict-key iteration). The old form called future.result() in submission order,
            # which blocks on the slowest-submitted ticker even when later ones finished first.
            for future in as_completed(future_to_ticker):
                t = future_to_ticker[future]
                try:
                    results[t] = future.result()
                except Exception:
                    results[t] = []
        return results

    def _submit_query(self, prompt: str, send_payload_context: bool = True):
        # 1. Update UI and log
        self._append_to_chat("User", prompt)

        # 2. Lock UI & show thinking indicator
        self.audit_btn.setEnabled(False)
        self.send_btn.setEnabled(False)
        self.loading_lbl.setText("🤖 Thinking...")
        self.loading_lbl.show()

        # 3. Gather Payload Context
        context_str = ""
        if send_payload_context and self.last_payload:
            context_str = self._compile_context_string(self.last_payload)

        # 4. Save prompt to local conversation history
        self.chat_history.append({"role": "user", "parts": [{"text": prompt}]})

        # 5. Launch background network task (runs news fetch + API/fallback)
        self._active_thread, self._active_worker = _launch(
            self,
            self._execute_background_task,
            (prompt, context_str),
            self._on_query_success,
            self._on_query_error
        )

    def _execute_background_task(self, prompt: str, payload_context: str) -> str:
        """Executed on background thread: fetches news, runs API or enriched local audit."""
        tickers = self._get_active_tickers()
        news_data = {}
        if tickers:
            news_data = self._fetch_all_news(tickers)

        # Extract top-ranked candidate tickers per category from last_payload / intel_df
        df = self.last_payload.get("portfolio_df") if self.last_payload else None
        breakout_top, accum_top = [], []

        if df is not None and not df.empty and "Primary Classification" in df.columns:
            col = "Ticker" if "Ticker" in df.columns else ("Symbol" if "Symbol" in df.columns else None)
            if col:
                b_df = df[df["Primary Classification"].str.contains("Breakout", na=False)]
                if not b_df.empty:
                    breakout_top = [str(t).split(".")[0] for t in b_df[col].dropna().unique() if str(t) != "CASH"][:10]

                a_df = df[df["Primary Classification"].str.contains("Accumulation|Defense", na=False)]
                if not a_df.empty:
                    accum_top = [str(t).split(".")[0] for t in a_df[col].dropna().unique() if str(t) != "CASH"][:10]

        if not breakout_top:
            clean_all = [t.split(".")[0] for t in tickers if t != "CASH"]
            breakout_top = clean_all[:10]
            accum_top = clean_all[10:20] if len(clean_all) > 10 else clean_all[:10]

        g1 = " ".join(breakout_top) if breakout_top else "NSE Equities"
        g2 = " ".join(accum_top) if accum_top else g1

        # AUDIT-FIX (truth-in-labeling): do not fabricate web search headers when offline
        if news_data:
            search_header = f'Live news feeds queried: "{g1}" / "{g2}"\n\n'
        else:
            search_header = f'Tickers analyzed (offline): {g1} | {g2}\n\n'

        news_lines = [search_header, "=== LATEST REAL-TIME STOCK & CORPORATE NEWS ==="]
        if news_data:
            for t, items in news_data.items():
                if items:
                    news_lines.append(f"\nTicker: {t}")
                    for idx, item in enumerate(items, 1):
                        news_lines.append(f"  {idx}. {item['title']} ({item['pub_date']})")
                else:
                    news_lines.append(f"\nTicker: {t} - No recent news headlines found.")
        news_context = "\n".join(news_lines)

        creds = load_credentials()
        api_key = creds.get("GEMINI_API_KEY", "")

        if api_key:
            return self._run_gemini_query(api_key, prompt, payload_context, news_context, search_header)
        else:
            return search_header + self._run_local_audit_enriched(news_data)

    def _run_gemini_query(self, api_key: str, prompt: str, payload_context: str, news_context: str, search_header: str = "") -> str:
        """Sends the payload + news context + prompt to the Gemini API."""
        contents = []
        # AUDIT-FIX (Round 5, 2-c-8): the current prompt is appended to
        # chat_history in _submit_query *before* the worker launches; iterating
        # the full history AND appending full_prompt below sent the same question
        # to the API as two consecutive user turns every time. Skip the trailing
        # bare copy — the enriched full_prompt below is the single current turn.
        for msg in self.chat_history[:-1]:
            contents.append({
                "role": msg["role"],
                "parts": [{"text": msg["parts"][0]["text"]}]
            })

        full_prompt = prompt
        combined_context = f"{payload_context}\n{news_context}"
        if combined_context.strip():
            full_prompt = f"{combined_context}\n\nUser Question:\n{prompt}"

        contents.append({
            "role": "user",
            "parts": [{"text": full_prompt}]
        })

        import requests
        creds = load_credentials()
        config_model = creds.get("GEMINI_MODEL", "gemini-3.5-flash")
        
        models_to_try = []
        if config_model and config_model.strip():
            models_to_try.append(config_model.strip())
        for fallback_m in ["gemini-3.5-flash", "gemini-3.6-flash", "gemini-flash-latest", "gemini-3.5-flash-lite"]:
            if fallback_m not in models_to_try:
                models_to_try.append(fallback_m)

        base_body = {
            "contents": contents,
            "systemInstruction": {
                "parts": [
                    {
                        "text": "You are an institutional-grade Quantitative Portfolio Architect, Master Screener & AI Investment Copilot. "
                                "CRITICAL DEEP EVALUATION MANDATE: You MUST NOT rely solely on simple rank numbers. You MUST perform a comprehensive, multi-dimensional evaluation of EVERY SINGLE CANDIDATE STOCK across ALL 6 CRITICAL DIMENSIONS:\n"
                                "1. TECHNICAL MICROSTRUCTURE: Volatility Contraction Pattern (VCP), tight Bollinger Band squeeze (< 10%), high volume surge ratio (> 1.2x), distance to 50/200 SMA pivot, VPIN order-flow toxicity, Hasbrouck price impact (λ), and Relative Strength (RS 1-99).\n"
                                "2. FUNDAMENTAL FINANCIAL TRAJECTORY: Multi-quarter earnings performance (Q1, Q2, Q3, Q4 PAT & revenue YoY % growth), operating margin expansion, return on equity (ROE), and debt-to-equity ratios.\n"
                                "3. NEWS FLOW & CORPORATE INTELLIGENCE: Exchange disclosures, recent order book expansions (₹ Cr), contract wins, USFDA / regulatory product approvals, and promoter/QIP capital infusions.\n"
                                "4. HIDDEN VALUE & CAPEX EXPANSION: Balance sheet strength, capacity expansion projects, debt-light capital structures, market share gains in high-margin export/OEM segments, and 3x-5x multibagger re-rating potential.\n"
                                "5. MARGIN OF SAFETY & DOWNSIDE PROTECTION: Low PE multiples (< 20), low market beta (beta < 0.4), high daily turnover (> ₹20 Cr/day), Piotroski F-Score (≥ 7), and Altman Z-Score.\n"
                                "6. MULTIBAGGER THESIS: Clear 3-5 year growth catalysts, operating leverage, and earnings compounding trajectory.\n\n"
                                "MANDATORY TABLE POPULATION: You MUST list ALL candidate stocks provided in the context (include at least 8 to 12 stocks per category table). DO NOT TRUNCATE OR LIMIT TABLES TO 3 STOCKS. Populate EVERY single candidate stock into its respective table row. NEVER LEAVE ANY TABLE CELL BLANK OR PLACE EMPTY PIPES | | | | | |. "
                                "\n\nFormat your output strictly using this EXACT structure:\n\n"
                                f"{search_header}"
                                "Here is the comprehensive quantitative, fundamental, and market intelligence analysis across the candidate stocks, categorized into **Immediate Breakout**, **Best for Lower-Price Accumulation**, and **Multibagger Potential**:\n\n"
                                "---\n\n"
                                "### 🔥 1. Immediate Breakout Candidates (Short-to-Medium Term)\n\n"
                                "These stocks exhibit **Volatility Contraction Patterns (VCP)**, tight Bollinger Band squeezes (< 10%), and incoming volume surges (> 1.2x) near 50/200 SMA pivots that signal an impending price expansion breakout.\n\n"
                                "| Ticker & Company | Current Price | 20d Range / BB Width | Volume Surge Ratio | Key Fundamental Catalyst & News | Technical Breakout Pivot |\n"
                                "| :--- | :---: | :---: | :---: | :--- | :--- |\n"
                                "| **`TICKER.NS`**<br>(Company Name) | ₹Price | **BB_Width%** | **Ratio x** | **Bold Fundamental Headline**: Specific PAT/revenue YoY growth %, order book in ₹ Cr, capacity capex, or product approvals. | **Breakout above ₹Level** (distance to 50/200 SMA) triggers price move. |\n\n"
                                "---\n\n"
                                "### 🛡️ 2. Best for Accumulation at Lower Price (Buy on Dips)\n\n"
                                "These companies possess **deep margins of safety, low market beta (beta < 0.4), low PE multiples (< 20), high daily turnover (> ₹20 Cr/day)**, and massive balance sheet capex expansion plans.\n\n"
                                "| Ticker & Company | Current Price | PE Ratio | Market Beta (beta) | 20d Turnover | Long-Term Expansion & Fundamental Catalyst | Ideal Accumulation Zone |\n"
                                "| :--- | :---: | :---: | :---: | :---: | :--- | :--- |\n"
                                "| **`TICKER.NS`**<br>(Company Name) | ₹Price | **PE** | **beta** | ₹Turnover Cr/day | **Expansion Catalyst**: Capex plans, debt-light balance sheet, capacity expansion, or market share gains. | **Accumulate on dips near ₹Zone** (Margin of Safety). |\n\n"
                                "---\n\n"
                                "### 🚀 3. High-Probability Multibagger Candidates (3x to 5x Potential)\n\n"
                                "These high-growth companies exhibit **> 25% YoY earnings growth, market cap headroom, export market approvals/acquisitions, debt-light balance sheets**, and strong 3M/6M relative performance.\n\n"
                                "#### A. `TICKER1.NS` (Company Name) — **Top Fundamental Multibagger**\n"
                                "- **Current Price**: ₹Price | **6M Return**: **+Return%** | **Market Beta**: **beta**\n"
                                "- **Business Profile**: Detailed business & operating profile, market position, and competitive moat.\n"
                                "- **Hidden Growth Catalysts**:\n"
                                "  1. **Strategic Acquisition / Capex**: Details of capacity expansion or acquisitions.\n"
                                "  2. **International Regulatory Approvals**: Export market approvals or key contract wins.\n"
                                "  3. **Debt-Light Balance Sheet**: Balance sheet structure and organic expansion capability.\n"
                                "  4. **Earnings Acceleration**: Specific multi-quarter YoY net profit/revenue growth figures.\n"
                                "- **Multibagger Thesis**: Clear quantitative thesis for 3x-5x multi-year price re-rating.\n\n"
                                "#### B. `TICKER2.NS` (Company Name) — **Turnaround Multibagger**\n"
                                "- **Current Price**: ₹Price | **6M Return**: **+Return%** | **3M Return**: **+Return%**\n"
                                "- **Business Profile**: Detailed business & operating profile.\n"
                                "- **Hidden Growth Catalysts**:\n"
                                "  1. **Financial Restructuring**: Capital structure changes and margin expansion.\n"
                                "  2. **Export Traction & Margin Recovery**: Segmental profitability and new orders.\n"
                                "  3. **High Volatility Alpha**: Volatility contraction and institutional momentum.\n"
                                "- **Multibagger Thesis**: Operating leverage and earnings compounding thesis.\n\n"
                                "---\n\n"
                                "### 🎯 Final Research Summary & Action Plan\n\n"
                                "1. **For Immediate Swing Trades (Breakout)**: Watch key breakout pivots and volume surge confirmation.\n"
                                "2. **For Long-Term Low-Risk Wealth (Accumulation)**: Accumulation targets near margin-of-safety zones.\n"
                                "3. **For High-Risk High-Reward Alpha (Multibagger)**: Capital allocation strategy into 3x-5x compounders."
                    }
                ]
            },
            "generationConfig": {
                "temperature": 0.2
            }
        }

        headers = {"Content-Type": "application/json"}
        last_err = ""

        for model_name in models_to_try:
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{model_name}:generateContent"  # AUDIT-FIX (Round 6, F8)
            
            # Pass 1: Try with googleSearch tool
            body_with_tool = dict(base_body)
            body_with_tool["tools"] = [{"googleSearch": {}}]
            try:
                resp = requests.post(url, json=body_with_tool, headers={**headers, "x-goog-api-key": api_key}, timeout=45)
                if resp.status_code == 200:
                    data = resp.json()
                    candidate = data["candidates"][0]
                    parts = candidate.get("content", {}).get("parts", [])
                    text_parts = [p.get("text", "") for p in parts if "text" in p]
                    result_text = "".join(text_parts).strip()
                    if result_text:
                        return result_text
            except Exception as ex:
                last_err = str(ex)

            # Pass 2: If 429 Quota Exceeded on googleSearch tool, fallback to pure text generation (news_context is already in prompt)
            try:
                resp_no_tool = requests.post(url, json=base_body, headers={**headers, "x-goog-api-key": api_key}, timeout=45)
                if resp_no_tool.status_code == 200:
                    data = resp_no_tool.json()
                    candidate = data["candidates"][0]
                    parts = candidate.get("content", {}).get("parts", [])
                    text_parts = [p.get("text", "") for p in parts if "text" in p]
                    result_text = "".join(text_parts).strip()
                    if result_text:
                        return result_text
                last_err = f"HTTP {resp_no_tool.status_code}: {resp_no_tool.text}"
            except Exception as ex:
                last_err = str(ex)

        # Pass 3: If API is blocked/unreachable, fallback gracefully to enriched local audit
        return self._run_local_audit_enriched({})

    def _run_local_audit_enriched(self, news_data: dict) -> str:
        """Compiles an enriched quantitative and news fallback report locally."""
        p = self.last_payload
        if not p or p.get("portfolio_df") is None or p["portfolio_df"].empty:
            return "### ❌ No Active Portfolio Data\n\nPlease run the portfolio optimizer first."

        df = p["portfolio_df"]
        total_assets = len(df)
        
        # Calculate sector concentration
        sec_df = p.get("sector_summary_df")
        top_sector = "None"
        top_sector_wt = 0.0
        sector_warnings = []
        if sec_df is not None and not sec_df.empty:
            # AUDIT-FIX (Round 5, 2-c-3): the optimizer's sector-summary column
            # is "Weight %" (with a space) — the lookup list missed it entirely,
            # so holdings weights fell back to 0.00 and the sort silently didn't
            # happen. "Weight %" is checked first.
            wt_col = [c for c in ["Weight %", "Weight%", "Weight", "Weight_pct"] if c in sec_df.columns]
            sec_col = [c for c in ["Sector"] if c in sec_df.columns]
            if wt_col and sec_col:
                s_sorted = sec_df.sort_values(by=wt_col[0], ascending=False)
                top_sector = s_sorted.iloc[0][sec_col[0]]
                top_sector_wt = float(s_sorted.iloc[0][wt_col[0]])
                # AUDIT-FIX (Round 5, 2-c-2): the sector summary stores weights as
                # DECIMAL fractions (0.35). `0.35 > 35.0` is never True, so the
                # concentration warning and trim recommendation could never fire
                # and the memo displayed "0.3%". Normalize fraction→percent
                # before comparing/displaying (values > 1.5 are assumed already %).
                if top_sector_wt <= 1.5:
                    top_sector_wt *= 100.0
                if top_sector_wt > 35.0:
                    sector_warnings.append(f"⚠️ **High Sector Concentration:** {top_sector} sector accounts for {top_sector_wt:.1f}% of the portfolio (threshold: 35%).")

        # Top holdings
        # AUDIT-FIX (Round 5, 2-c-3): match the optimizer's real column name.
        _wt_sort_col = next((c for c in ("Weight %", "Weight%", "Weight") if c in df.columns), None)
        sorted_df = df.sort_values(by=_wt_sort_col, ascending=False) if _wt_sort_col else df
        top_holdings = []
        for idx, row in sorted_df.head(3).iterrows():
            ticker = row.get("Ticker") or row.get("Symbol") or f"Asset {idx}"
            # AUDIT-FIX (Round 6, D-P2-7): portfolio_df["Weight %"] stores
            # DECIMAL fractions (Σ=1) — the previous code printed them raw,
            # showing "RELIANCE: 0.40%" for a 40% position. Convert ×100;
            # also match the "Weight %" (spaced) column first.
            weight = (row.get("Weight %") if row.get("Weight %") is not None else row.get("Weight%") if row.get("Weight%") is not None else row.get("Weight")) or 0.0
            try:
                weight_pct = float(weight) * 100.0 if float(weight) <= 1.5 else float(weight)
            except (TypeError, ValueError):
                weight_pct = 0.0
            top_holdings.append(f"- **{ticker}**: {weight_pct:.2f}%")

        # Sharpe and return/vol
        diag_df = p.get("diagnostics_df")
        sharpe = 0.0
        ret_val = 0.0
        vol_val = 0.0
        if diag_df is not None and not diag_df.empty:
            for _, row in diag_df.iterrows():
                metric = str(row.get("Metric", ""))
                val = str(row.get("Value", "0"))
                if "Sharpe" in metric:
                    try: sharpe = float(val)
                    except (ValueError, TypeError): pass
                elif "Return" in metric:
                    try: ret_val = float(val.replace("%",""))
                    except (ValueError, TypeError): pass
                elif "Vol" in metric or "Risk" in metric:
                    try: vol_val = float(val.replace("%",""))
                    except (ValueError, TypeError): pass

        # Risk metrics (VaR / CVaR)
        var_df = p.get("var_cvar_df")
        var_1d = "N/A"
        cvar_1d = "N/A"
        if var_df is not None and not var_df.empty:
            for _, row in var_df.iterrows():
                metric = str(row.get("Metric", ""))
                val = str(row.get("1-Day %", ""))
                if "VaR" in metric:
                    var_1d = val
                elif "CVaR" in metric:
                    cvar_1d = val

        # Drawdown and F&O Ban
        drawdown = p.get("current_drawdown_pct", 0.0)
        max_drawdown_limit = p.get("cfg", {}).get("MAX_PORTFOLIO_DRAWDOWN_PCT", 15.0)
        drawdown_warning = ""
        if abs(drawdown) > max_drawdown_limit:
            drawdown_warning = f"⚠️ **Drawdown Alert:** Current drawdown is {drawdown:.2f}%, exceeding the risk policy limit of -{max_drawdown_limit:.2f}%."

        ban_list = p.get("fo_ban_list", [])
        ban_warning = ""
        if ban_list:
            ban_warning = f"⚠️ **F&O Ban List Exposure:** The following assets are currently in the SEBI F&O ban list: {', '.join(ban_list)}. New position scaling is restricted."

        # Breakouts
        breakout_df = p.get("breakout_df", pd.DataFrame()) if p.get("breakout_df") is not None else pd.DataFrame()
        prebreakout_df = p.get("prebreakout_df", pd.DataFrame()) if p.get("prebreakout_df") is not None else pd.DataFrame()
        breakout_count = len(breakout_df)
        prebreakout_count = len(prebreakout_df)

        # Build output memo
        memo = f"""# 🤖 Local Investment Audit & Risk Memo

**Generated:** {time.strftime("%Y-%m-%d %H:%M:%S")}
**Auditor Mode:** Local Mathematical Rule-Based Engine (Offline Fallback)

---

### 📊 Executive Portfolio Statistics
- **Total Assets Selected:** {total_assets} stocks
- **Estimated Sharpe Ratio:** {sharpe:.2f}
- **Expected Portfolio Return:** {ret_val:.2f}%
- **Expected Portfolio Volatility:** {vol_val:.2f}%
- **1-Day Value-at-Risk (VaR):** {var_1d}
- **1-Day Conditional VaR (CVaR):** {cvar_1d}
- **Current Portfolio Drawdown:** {drawdown:.2f}% (Limit: -{max_drawdown_limit:.2f}%)

---

### 🛡️ Concentration & Allocation Audit
- **Top Sector Exposure:** {top_sector} ({top_sector_wt:.1f}%)
- **Top 3 Holding Positions:**
{chr(10).join(top_holdings)}

"""
        if sector_warnings or drawdown_warning or ban_warning:
            memo += "### ⚠️ Risk Notifications & Policy Warnings\n"
            if sector_warnings:
                for w in sector_warnings:
                    memo += f"- {w}\n"
            if drawdown_warning:
                memo += f"- {drawdown_warning}\n"
            if ban_warning:
                memo += f"- {ban_warning}\n"
            memo += "\n"
        else:
            memo += "### ✅ Risk Policy Compliance\n- Portfolio style concentration, drawdown limits, and sector weights are fully compliant with risk policy guidelines.\n\n"

        memo += f"""### 🎯 Setup & Signal Scanner Summary
- **🚀 Breakout Signals:** {breakout_count} setups identified in the active universe.
- **🔍 Pre-Breakout Setups:** {prebreakout_count} coiling signals found.

---

### 📰 Real-Time News & Prospects Analysis
"""
        target_tickers = self._get_active_tickers()[:8]
        if target_tickers:
            for t in target_tickers:
                items = news_data.get(t, [])
                memo += f"\n#### **{t}**\n"
                if items:
                    for item in items[:3]:
                        memo += f"- {item['title']} *(Source: Google News)*\n"
                else:
                    memo += "- No recent news headlines found.\n"
                
                # Dynamic prospects / multibagger estimation
                is_breakout = False
                bo_col = "Ticker" if "Ticker" in breakout_df.columns else ("Symbol" if "Symbol" in breakout_df.columns else None)
                if bo_col and t in breakout_df[bo_col].values:
                    is_breakout = True
                    
                is_prebreakout = False
                pbo_col = "Ticker" if "Ticker" in prebreakout_df.columns else ("Symbol" if "Symbol" in prebreakout_df.columns else None)
                if pbo_col and t in prebreakout_df[pbo_col].values:
                    is_prebreakout = True
                
                if is_breakout:
                    prospect = "🚀 **High growth breakout setup.** Volume surge suggests strong momentum. High potential of short-term outperformance."
                elif is_prebreakout:
                    prospect = "🔍 **Pre-breakout watch setup.** Coiling near EMA bases; potential base expansion pattern."
                else:
                    prospect = "⚖️ **Neutral asset allocation.** Standard holding profile."
                memo += f"  - **Prospect & Growth Potential:** {prospect}\n"
        else:
            memo += "\n- No active tickers found to retrieve news."

        memo += "\n---\n\n### 📝 Strategic Quant Recommendations\n1. "
        recs = []
        if top_sector_wt > 35.0:
            recs.append(f"Trim allocations in **{top_sector}** to bring concentration below 30% and mitigate sector risk.")
        else:
            recs.append("Sector exposures are balanced. Maintain diversification bounds.")

        if ban_list:
            recs.append(f"Avoid initiating new positions in **{', '.join(ban_list)}** until they are cleared from the SEBI ban list.")

        if sharpe < 1.0:
            recs.append("The portfolio Sharpe ratio is suboptimal. Consider enabling momentum or quality growth filters.")
        else:
            recs.append("Portfolio Sharpe ratio is solid. Maintain execution boundaries.")

        if breakout_count > 0:
            recs.append(f"Leverage breakout signals; monitor trailing stops closely on the {breakout_count} breakout stock(s).")

        memo += "\n1. ".join(recs)
        return memo

    def _on_query_success(self, response_text: str):
        # Re-enable UI
        self.audit_btn.setEnabled(True)
        self.send_btn.setEnabled(True)
        self.loading_lbl.hide()

        # Append model response
        self.chat_history.append({"role": "model", "parts": [{"text": response_text}]})
        self._append_to_chat("AI", response_text)

    def _on_query_error(self, err_msg: str):
        # Re-enable UI
        self.audit_btn.setEnabled(True)
        self.send_btn.setEnabled(True)
        self.loading_lbl.hide()

        # Append error notification and local fallback
        err_box = f"⚠️ **Gemini API Error:** `{err_msg}`\n\n**Running Local Rule-Based Auditor Fallback:**\n\n"
        # Since local report requires news, we try to run the local report directly (already compiled on thread if possible,
        # but here we run a fallback local report with whatever cached news or empty news we have)
        local_report = self._run_local_audit_enriched({})
        self._append_to_chat("AI", err_box + local_report)

    def _append_to_chat(self, sender: str, text: str):
        # Convert markdown text to clean HTML without destructive re-parsing of entire document
        try:
            html_body = markdown.markdown(text, extensions=['tables', 'fenced_code', 'nl2br'])
        except Exception:
            html_body = f"<pre style='color: #e2e8f0;'>{text}</pre>"
            
        sender_color = _QSS.TEAL if sender == "AI" else _QSS.GOLD
        formatted_html = f"""
        <div style="margin-bottom: 14px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
            <div style="font-weight: bold; color: {sender_color}; font-size: 13px; margin-bottom: 6px;">
                {sender}:
            </div>
            <div style="color: #e2e8f0; font-size: 12px; line-height: 1.6;">
                {html_body}
            </div>
        </div>
        <hr style="border: 0; border-top: 1px solid rgba(255,255,255,0.1); margin: 14px 0;">
        """
        
        cursor = self.chat_log.textCursor()
        cursor.movePosition(QTextCursor.End)
        cursor.insertHtml(formatted_html)
        
        # Scroll to bottom
        bar = self.chat_log.verticalScrollBar()
        if bar:
            bar.setValue(bar.maximum())

    def _compile_context_string(self, p: dict) -> str:
        lines = []
        lines.append("=== PORTFOLIO QUANT DATA ===")
        
        # 1. Holdings
        df = p.get("portfolio_df")
        if df is not None and not df.empty:
            lines.append("\nHoldings & Allocation:")
            # AUDIT-FIX (Round 6, D-P2-7): the optimizer's column is "Weight %"
            # (with a space) — the previous list missed it, so the Gemini
            # prompt context contained holdings WITHOUT any weights.
            cols = [c for c in ["Ticker", "Symbol", "Weight %", "Weight%", "Weight", "Sector", "Volatility"] if c in df.columns]
            lines.append(df[cols].to_string(index=False))
            
            # Enrich with PostScreeningIntelligence metrics
            try:
                from math_engine.post_screening_intelligence import PostScreeningIntelligenceEngine
                intel_df = PostScreeningIntelligenceEngine.analyze_portfolio_dataframe(df)
                if not intel_df.empty:
                    lines.append("\nPost-Screening Pre-Calculated Technical & Fundamental Metrics:")
                    intel_cols = [c for c in ["Ticker", "Primary Classification", "Breakout Score", "Accumulation Score", "Multibagger Score", "3M Return %", "6M Return %", "BB Width %", "20d Range %", "Market Beta", "PE Ratio", "ADV20 (₹Cr)"] if c in intel_df.columns]
                    lines.append(intel_df[intel_cols].to_string(index=False))
            except Exception as _ex:
                pass
            
        # 2. Sector weights
        sec_df = p.get("sector_summary_df")
        if sec_df is not None and not sec_df.empty:
            lines.append("\nSector Summary:")
            lines.append(sec_df.to_string(index=False))

        # 3. Optimization / Diagnostics
        diag_df = p.get("diagnostics_df")
        if diag_df is not None and not diag_df.empty:
            lines.append("\nDiagnostics & Metrics:")
            lines.append(diag_df.to_string(index=False))

        # 4. VaR / CVaR Risk
        var_df = p.get("var_cvar_df")
        if var_df is not None and not var_df.empty:
            lines.append("\nValue-at-Risk / CVaR Risk:")
            lines.append(var_df.to_string(index=False))

        # 5. Stress Testing
        stress_df = p.get("stress_test_df")
        if stress_df is not None and not stress_df.empty:
            lines.append("\nHistorical Stress Tests:")
            lines.append(stress_df.to_string(index=False))

        # 6. Marginal Risk Contribution
        mrc_df = p.get("mrc_df")
        if mrc_df is not None and not mrc_df.empty:
            lines.append("\nMarginal Risk Contribution (MRC):")
            lines.append(mrc_df.to_string(index=False))

        # 7. Factor Attribution
        fa_df = p.get("factor_attribution_df")
        if fa_df is not None and not fa_df.empty:
            lines.append("\nFactor Attribution:")
            lines.append(fa_df.to_string(index=False))

        # 8. Drawdown & F&O Ban
        drawdown = p.get("current_drawdown_pct")
        if drawdown is not None:
            lines.append(f"\nCurrent Drawdown: {drawdown:.2f}%")
        ban = p.get("fo_ban_list")
        if ban:
            lines.append(f"\nF&O Ban List: {', '.join(ban)}")
            
        return "\n".join(lines)
