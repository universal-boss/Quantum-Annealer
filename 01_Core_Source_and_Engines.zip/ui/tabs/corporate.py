import sqlite3
import random
from pathlib import Path
try:
    from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QTableWidget, QTableWidgetItem, QHeaderView, QAbstractItemView, QLineEdit, QPushButton
    from PySide6.QtGui import QColor, QFont
    from PySide6.QtCore import Qt
except ImportError:
    from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QTableWidget, QTableWidgetItem, QHeaderView, QAbstractItemView, QLineEdit, QPushButton
    from PyQt5.QtGui import QColor, QFont
    from PyQt5.QtCore import Qt

from ui.styling import _QSS
from utils import archlog, RUNTIME_DIR


def _safe_fund(v, default: float = 0.0) -> float:
    """AUDIT-FIX (Round 5, 2-c-1): fundamentals fetchers return NaN sentinels for
    failed tickers (cached 24h). Every `== 0.0` / `<= 0.0` guard is False for
    NaN, so NaN flowed into int() conversions and raised ValueError —
    aborting the whole results refresh. Coerce non-finite values to 0.0 so the
    existing "no data" guards fire."""
    try:
        f = float(v)
    except (TypeError, ValueError):
        return default
    if f != f:  # NaN check
        return default
    return f

class QuarterlyResultsScanner(QWidget):
    """TAB 323 — Q-results scanner: revenue/PAT beat/miss across Nifty 50.

    AUDIT-FIX (defect #18, mock widget labeling):
    The audit found that this tab ships hardcoded quarterly results (the
    RESULTS list below) and only overrides them when a specific SQLite file
    (RUNTIME_DIR/fundamentals_history.db) exists. In most installs the file is
    absent, so the operator sees a frozen snapshot of Q3 FY25 numbers presented
    as if they were live scanner output. The header now explicitly says
    "SIMULATION (hardcoded snapshot; refresh via fundamentals_history.db)" so
    the operator cannot mistake the canned numbers for a live scan.
    """

    RESULTS = [
        {"Symbol":"RELIANCE","Sector":"Energy","RevAct":244800,"RevEst":241200,"PATAct":19407,"PATEst":18900,"RevBeat":True,"PATBeat":True},
        {"Symbol":"TCS","Sector":"IT","RevAct":63973,"RevEst":63200,"PATAct":12380,"PATEst":12100,"RevBeat":True,"PATBeat":True},
        {"Symbol":"HDFCBANK","Sector":"Banking","RevAct":89421,"RevEst":88000,"PATAct":17616,"PATEst":17200,"RevBeat":True,"PATBeat":True},
        {"Symbol":"INFY","Sector":"IT","RevAct":40925,"RevEst":41200,"PATAct":7033,"PATEst":7150,"RevBeat":False,"PATBeat":False},
        {"Symbol":"ICICIBANK","Sector":"Banking","RevAct":67204,"RevEst":66800,"PATAct":12630,"PATEst":12400,"RevBeat":True,"PATBeat":True},
        {"Symbol":"HINDUNILVR","Sector":"FMCG","RevAct":15205,"RevEst":15100,"PATAct":2893,"PATEst":2850,"RevBeat":True,"PATBeat":True},
        {"Symbol":"BAJFINANCE","Sector":"NBFC","RevAct":16132,"RevEst":16500,"PATAct":4246,"PATEst":4400,"RevBeat":False,"PATBeat":False},
        {"Symbol":"MARUTI","Sector":"Auto","RevAct":39620,"RevEst":38900,"PATAct":3864,"PATEst":3700,"RevBeat":True,"PATBeat":True},
        {"Symbol":"WIPRO","Sector":"IT","RevAct":22208,"RevEst":22500,"PATAct":3188,"PATEst":3250,"RevBeat":False,"PATBeat":False},
        {"Symbol":"NESTLEIND","Sector":"FMCG","RevAct":4862,"RevEst":4900,"PATAct":934,"PATEst":950,"RevBeat":False,"PATBeat":False},
        {"Symbol":"LTIM","Sector":"IT","RevAct":9660,"RevEst":9580,"PATAct":1404,"PATEst":1380,"RevBeat":True,"PATBeat":True},
        {"Symbol":"AXISBANK","Sector":"Banking","RevAct":36091,"RevEst":35800,"PATAct":7130,"PATEst":7000,"RevBeat":True,"PATBeat":True},
        {"Symbol":"SUNPHARMA","Sector":"Pharma","RevAct":13513,"RevEst":13200,"PATAct":2850,"PATEst":2780,"RevBeat":True,"PATBeat":True},
        {"Symbol":"TITAN","Sector":"Consumer","RevAct":11742,"RevEst":12100,"PATAct":1021,"PATEst":1080,"RevBeat":False,"PATBeat":False},
        {"Symbol":"DRREDDY","Sector":"Pharma","RevAct":8214,"RevEst":8100,"PATAct":1416,"PATEst":1380,"RevBeat":True,"PATBeat":True},
    ]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.load_db_data()
        self._build_ui()

    def load_db_data(self):
        db_path = RUNTIME_DIR / "fundamentals_history.db"
        if not db_path.exists():
            return
        conn = None
        try:
            conn = sqlite3.connect(str(db_path))
            cur = conn.cursor()
            cur.execute("SELECT ticker, sector, rev_act, rev_est, pat_act, pat_est, rev_beat, pat_beat FROM quarterly_results")
            rows = cur.fetchall()
            if rows:
                results = []
                for r in rows:
                    results.append({
                        "Symbol": r[0],
                        "Sector": r[1],
                        "RevAct": int(r[2]),
                        "RevEst": int(r[3]),
                        "PATAct": int(r[4]),
                        "PATEst": int(r[5]),
                        "RevBeat": bool(r[6]),
                        "PATBeat": bool(r[7])
                    })
                self.RESULTS = results
        except Exception as e:
            print(f"Error loading quarterly results from DB: {e}")
        finally:
            if conn:
                conn.close()

    def _build_ui(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12,12,12,12); lay.setSpacing(8)

        # AUDIT-FIX (defect #18): mark the tab as a simulation when the local
        # fundamentals_history.db is absent (the hardcoded RESULTS list is
        # then the only data source, which is a frozen snapshot, not a scan).
        _has_db = (RUNTIME_DIR / "fundamentals_history.db").exists()
        _sim_suffix = "" if _has_db else "  —  SIMULATION (hardcoded snapshot; refresh via fundamentals_history.db)"
        hdr = QLabel("📋  Quarterly Results Scanner — Q4 FY26" + _sim_suffix)
        hdr.setStyleSheet("font-size:15px;font-weight:bold;")
        lay.addWidget(hdr)

        ctrl = QHBoxLayout()
        ctrl.addWidget(QLabel("Filter:"))
        self._filter = QComboBox()
        self._filter.addItems(["All","Beat Both","Miss Both","Rev Beat","PAT Beat","Rev Miss","PAT Miss"])
        self._filter.currentIndexChanged.connect(self._load)
        ctrl.addWidget(self._filter)
        ctrl.addWidget(QLabel("Sector:"))
        self._sector = QComboBox()
        sectors = ["All"] + sorted(set(r["Sector"] for r in self.RESULTS))
        self._sector.addItems(sectors)
        self._sector.currentIndexChanged.connect(self._load)
        ctrl.addWidget(self._sector)
        ctrl.addStretch()
        lay.addLayout(ctrl)

        # beat/miss scorecard
        self._score_lbl = QLabel("")
        self._score_lbl.setStyleSheet("font-size:12px;font-weight:bold;padding:4px;color:#0a84ff;")
        lay.addWidget(self._score_lbl)

        self._tbl = QTableWidget(0, 9)
        self._tbl.setHorizontalHeaderLabels(["Symbol","Sector","Rev Act","Rev Est",
                                              "Rev Surp%","PAT Act","PAT Est","PAT Surp%","Verdict"])
        self._tbl.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self._tbl.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self._tbl.setAlternatingRowColors(True)
        # Table styling handled globally by QSS theme
        lay.addWidget(self._tbl)

        self._info = QLabel("Values in ₹ Crore  |  Q4 FY26 results")
        self._info.setStyleSheet("color:#8e8e93;font-size:11px;")
        lay.addWidget(self._info)
        self._load()

    def _load(self):
        filt   = self._filter.currentText()
        sector = self._sector.currentText()
        rows   = self.RESULTS
        if sector != "All": rows = [r for r in rows if r["Sector"]==sector]
        if filt=="Beat Both":  rows = [r for r in rows if r["RevBeat"] and r["PATBeat"]]
        elif filt=="Miss Both": rows = [r for r in rows if r["RevBeat"] is not None and r["PATBeat"] is not None and not r["RevBeat"] and not r["PATBeat"]]
        elif filt=="Rev Beat":  rows = [r for r in rows if r["RevBeat"]]
        elif filt=="PAT Beat":  rows = [r for r in rows if r["PATBeat"]]
        elif filt=="Rev Miss":  rows = [r for r in rows if r["RevBeat"] is not None and not r["RevBeat"]]
        elif filt=="PAT Miss":  rows = [r for r in rows if r["PATBeat"] is not None and not r["PATBeat"]]

        # AUDIT-FIX (Round 5, 2-c-7): "Beat Both" scorecard counted
        # revenue-only beats. Match the row filter (RevBeat AND PATBeat).
        beat_both  = sum(1 for r in self.RESULTS if r["RevBeat"] and r["PATBeat"])
        miss_both  = sum(1 for r in self.RESULTS if r["RevBeat"] is not None and r["PATBeat"] is not None and not r["RevBeat"] and not r["PATBeat"])
        total_valid = sum(1 for r in self.RESULTS if r["RevBeat"] is not None)
        beat_rate_str = f"{(beat_both/total_valid*100):.0f}%" if total_valid > 0 else "N/A"
        self._score_lbl.setText(f"Beat Both: {beat_both}/{len(self.RESULTS)}  |  "
                                 f"Miss Both: {miss_both}/{len(self.RESULTS)}  |  "
                                 f"Beat Rate: {beat_rate_str}")

        self._tbl.setRowCount(len(rows))
        for r,d in enumerate(rows):
            if d["RevAct"] is None or d["RevEst"] is None:
                rev_act_str = "N/A"
                rev_est_str = "N/A"
                rev_surp_str = "N/A"
                rev_color = QColor(_QSS.ORANGE)
            else:
                rev_act_str = f"₹{d['RevAct']:,}"
                rev_est_str = f"₹{d['RevEst']:,}"
                rev_surp = (d["RevAct"]-d["RevEst"])/d["RevEst"]*100 if d["RevEst"] else 0
                rev_surp_str = f"{rev_surp:+.1f}%"
                rev_color = QColor(_QSS.GREEN_4) if rev_surp>=0 else QColor(_QSS.RED_4)

            if d["PATAct"] is None or d["PATEst"] is None:
                pat_act_str = "N/A"
                pat_est_str = "N/A"
                pat_surp_str = "N/A"
                pat_color = QColor(_QSS.ORANGE)
            else:
                pat_act_str = f"₹{d['PATAct']:,}"
                pat_est_str = f"₹{d['PATEst']:,}"
                pat_surp = (d["PATAct"]-d["PATEst"])/d["PATEst"]*100 if d["PATEst"] else 0
                pat_surp_str = f"{pat_surp:+.1f}%"
                pat_color = QColor(_QSS.GREEN_4) if pat_surp>=0 else QColor(_QSS.RED_4)

            if d["RevBeat"] is None or d["PATBeat"] is None:
                verdict = "Data Unavailable"
                verdict_color = QColor(_QSS.ORANGE)
            else:
                verdict  = ("✅ Beat Both" if d["RevBeat"] and d["PATBeat"] else
                            "❌ Miss Both" if not d["RevBeat"] and not d["PATBeat"] else
                            "⚡ Mixed")
                verdict_color = (QColor(_QSS.GREEN_4) if "Beat" in verdict else
                                 QColor(_QSS.RED_4) if "Miss" in verdict else QColor(_QSS.ORANGE))

            self._tbl.setItem(r,0,QTableWidgetItem(d["Symbol"]))
            self._tbl.setItem(r,1,QTableWidgetItem(d["Sector"]))
            self._tbl.setItem(r,2,QTableWidgetItem(rev_act_str))
            self._tbl.setItem(r,3,QTableWidgetItem(rev_est_str))
            rs=QTableWidgetItem(rev_surp_str)
            rs.setForeground(rev_color)
            self._tbl.setItem(r,4,rs)
            self._tbl.setItem(r,5,QTableWidgetItem(pat_act_str))
            self._tbl.setItem(r,6,QTableWidgetItem(pat_est_str))
            ps=QTableWidgetItem(pat_surp_str)
            ps.setForeground(pat_color)
            self._tbl.setItem(r,7,ps)
            v=QTableWidgetItem(verdict)
            v.setForeground(verdict_color)
            self._tbl.setItem(r,8,v)
        self._info.setText(f"Showing {len(rows)} results  |  Q4 FY26  |  All values ₹ Crore")

    def update_portfolio_data(self, portfolio_df):
        if portfolio_df is None or (hasattr(portfolio_df, 'empty') and portfolio_df.empty):
            return
        db_path = RUNTIME_DIR / "fundamentals_history.db"
        
        tickers = [str(row.get("Ticker", "")).replace(".NS", "").strip() for _, row in portfolio_df.iterrows()]
        results = []
        loaded_tickers = set()
        
        if db_path.exists():
            conn = None
            try:
                conn = sqlite3.connect(str(db_path))
                cur = conn.cursor()
                placeholders = ",".join("?" for _ in tickers)
                cur.execute(f"SELECT ticker, sector, rev_act, rev_est, pat_act, pat_est, rev_beat, pat_beat FROM quarterly_results WHERE ticker IN ({placeholders})", tickers)
                rows = cur.fetchall()
                for r in rows:
                    results.append({
                        "Symbol": r[0],
                        "Sector": r[1],
                        "RevAct": int(r[2]),
                        "RevEst": int(r[3]),
                        "PATAct": int(r[4]),
                        "PATEst": int(r[5]),
                        "RevBeat": bool(r[6]),
                        "PATBeat": bool(r[7])
                    })
                    loaded_tickers.add(r[0])
            except Exception as e:
                print(f"Error updating portfolio data from DB: {e}")
            finally:
                if conn:
                    conn.close()
                
        from data_layer import fetch_fundamentals
        tickers_ns = [f"{t}.NS" if not t.endswith(".NS") else t for t in tickers]
        fund_data = fetch_fundamentals(tickers_ns)

        for _, row in portfolio_df.iterrows():
            t = str(row.get("Ticker", "")).replace(".NS", "").strip()
            if t in loaded_tickers:
                continue
            sec = str(row.get("Sector", "Others"))
            close = float(row.get("Price", 500.0))
            
            t_ns = f"{t}.NS"
            fd = fund_data.get(t_ns) or fund_data.get(t) or {"roe": 0.0, "de_ratio": 0.0, "rev_growth": 0.0, "pe_ratio": 0.0}
            roe = _safe_fund(fd.get("roe", 0.0))
            rev_growth = _safe_fund(fd.get("rev_growth", 0.0))
            
            if roe == 0.0 and rev_growth == 0.0:
                results.append({
                    "Symbol": t,
                    "Sector": sec,
                    "RevAct": None,
                    "RevEst": None,
                    "PATAct": None,
                    "PATEst": None,
                    "RevBeat": None,
                    "PATBeat": None
                })
            else:
                # Rev actual = close * revenue-multiple anchored to rev_growth
                rev_act = int(close * 20.0 * (1.0 + rev_growth))
                # Rev estimate = what analysts expected before the quarter (prev year baseline)
                rev_est = int(close * 20.0)  # no-growth baseline estimate
                pat_act = int(rev_act * max(0.01, roe))
                pat_est = int(rev_est * max(0.01, roe))  # estimate uses baseline rev
                
                results.append({
                    "Symbol": t,
                    "Sector": sec,
                    "RevAct": rev_act,
                    "RevEst": rev_est,
                    "PATAct": pat_act,
                    "PATEst": pat_est,
                    "RevBeat": rev_act >= rev_est,
                    "PATBeat": pat_act >= pat_est
                })
            
        self.RESULTS = results
        self._sector.blockSignals(True)
        self._sector.clear()
        self._sector.addItems(["All"] + sorted(set(r["Sector"] for r in results)))
        self._sector.blockSignals(False)
        self._load()


class EarningsSurpriseTracker(QWidget):
    """TAB 324 — EPS surprise %, analyst revision, stock reaction."""

    SURPRISE_DATA = [
        {"Symbol":"RELIANCE","EPSAct":28.8,"EPSEst":27.2,"Surp":5.9,"Revision":"+3.2%","StockRxn":+2.4,"Trend":"Upgrading"},
        {"Symbol":"TCS","EPSAct":34.2,"EPSEst":33.4,"Surp":2.4,"Revision":"+1.8%","StockRxn":+1.1,"Trend":"Stable"},
        {"Symbol":"HDFCBANK","EPSAct":23.1,"EPSEst":22.6,"Surp":2.2,"Revision":"+1.5%","StockRxn":+0.8,"Trend":"Stable"},
        {"Symbol":"INFY","EPSAct":16.8,"EPSEst":17.2,"Surp":-2.3,"Revision":"-2.1%","StockRxn":-3.2,"Trend":"Downgrading"},
        {"Symbol":"BAJFINANCE","EPSAct":62.4,"EPSEst":64.8,"Surp":-3.7,"Revision":"-3.4%","StockRxn":-4.1,"Trend":"Downgrading"},
        {"Symbol":"MARUTI","EPSAct":121.4,"EPSEst":116.2,"Surp":4.5,"Revision":"+4.1%","StockRxn":+3.8,"Trend":"Upgrading"},
        {"Symbol":"SUNPHARMA","EPSAct":11.9,"EPSEst":11.6,"Surp":2.6,"Revision":"+2.2%","StockRxn":+1.6,"Trend":"Stable"},
        {"Symbol":"WIPRO","EPSAct":13.1,"EPSEst":13.4,"Surp":-2.2,"Revision":"-1.9%","StockRxn":-1.8,"Trend":"Downgrading"},
        {"Symbol":"ICICIBANK","EPSAct":18.2,"EPSEst":17.8,"Surp":2.2,"Revision":"+1.8%","StockRxn":+1.4,"Trend":"Stable"},
        {"Symbol":"DRREDDY","EPSAct":84.6,"EPSEst":82.4,"Surp":2.7,"Revision":"+2.4%","StockRxn":+2.1,"Trend":"Upgrading"},
    ]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.load_db_data()
        self._build_ui()

    def load_db_data(self):
        db_path = RUNTIME_DIR / "fundamentals_history.db"
        if not db_path.exists():
            return
        conn = None
        try:
            conn = sqlite3.connect(str(db_path))
            cur = conn.cursor()
            cur.execute("SELECT ticker, eps_act, eps_est, surprise, revision, stock_reaction, trend FROM earnings_surprise")
            rows = cur.fetchall()
            if rows:
                surprise = []
                for r in rows:
                    surprise.append({
                        "Symbol": r[0],
                        "EPSAct": float(r[1]),
                        "EPSEst": float(r[2]),
                        "Surp": float(r[3]),
                        "Revision": str(r[4]),
                        "StockRxn": float(r[5]),
                        "Trend": str(r[6])
                    })
                self.SURPRISE_DATA = surprise
        except Exception as e:
            print(f"Error loading earnings surprise from DB: {e}")
        finally:
            if conn:
                conn.close()

    def _build_ui(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12,12,12,12); lay.setSpacing(8)

        hdr = QLabel("🎯  Earnings Surprise Tracker")
        hdr.setStyleSheet("font-size:15px;font-weight:bold;")
        lay.addWidget(hdr)

        ctrl = QHBoxLayout()
        ctrl.addWidget(QLabel("Filter:"))
        self._filter = QComboBox()
        self._filter.addItems(["All","Positive Surprise","Negative Surprise","Upgrading","Downgrading"])
        self._filter.currentIndexChanged.connect(self._load)
        ctrl.addWidget(self._filter)
        ctrl.addWidget(QLabel("Sort:"))
        self._sort = QComboBox()
        self._sort.addItems(["EPS Surprise %","Stock Reaction","Analyst Revision"])
        self._sort.currentIndexChanged.connect(self._load)
        ctrl.addWidget(self._sort)
        ctrl.addStretch()
        lay.addLayout(ctrl)

        self._tbl = QTableWidget(0, 7)
        self._tbl.setHorizontalHeaderLabels(["Symbol","EPS Actual","EPS Est","Surprise %",
                                              "Analyst Revision","Stock Rxn %","Trend"])
        self._tbl.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self._tbl.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self._tbl.setAlternatingRowColors(True)
        # Table styling handled globally by QSS theme
        lay.addWidget(self._tbl)

        self._info = QLabel("")
        self._info.setStyleSheet("color:#8e8e93;font-size:11px;")
        lay.addWidget(self._info)
        self._load()

    def _load(self):
        filt = self._filter.currentText()
        sort = self._sort.currentText()
        rows = list(self.SURPRISE_DATA)
        if filt=="Positive Surprise":  rows=[r for r in rows if r["Surp"] is not None and r["Surp"]>0]
        elif filt=="Negative Surprise": rows=[r for r in rows if r["Surp"] is not None and r["Surp"]<0]
        elif filt=="Upgrading":        rows=[r for r in rows if r["Trend"]=="Upgrading"]
        elif filt=="Downgrading":      rows=[r for r in rows if r["Trend"]=="Downgrading"]
        if sort=="EPS Surprise %":     rows=sorted(rows,key=lambda x:(x["Surp"] is not None, x["Surp"] or -9999.0),reverse=True)
        elif sort=="Stock Reaction":   rows=sorted(rows,key=lambda x:(x["StockRxn"] is not None, x["StockRxn"] or -9999.0),reverse=True)

        self._tbl.setRowCount(len(rows))
        for r,d in enumerate(rows):
            self._tbl.setItem(r,0,QTableWidgetItem(d["Symbol"]))
            if d["EPSAct"] is None:
                self._tbl.setItem(r,1,QTableWidgetItem("N/A"))
            else:
                self._tbl.setItem(r,1,QTableWidgetItem(f"₹{d['EPSAct']:.1f}"))
            
            if d["EPSEst"] is None:
                self._tbl.setItem(r,2,QTableWidgetItem("N/A"))
            else:
                self._tbl.setItem(r,2,QTableWidgetItem(f"₹{d['EPSEst']:.1f}"))
            
            if d["Surp"] is None:
                s = QTableWidgetItem("N/A")
                s.setForeground(QColor(_QSS.ORANGE))
            else:
                s=QTableWidgetItem(f"{d['Surp']:+.1f}%")
                s.setForeground(QColor(_QSS.GREEN_4) if d["Surp"]>=0 else QColor(_QSS.RED_4))
            self._tbl.setItem(r,3,s)
            
            rev=QTableWidgetItem(d["Revision"])
            if d["Revision"] == "N/A":
                rev.setForeground(QColor(_QSS.ORANGE))
            else:
                rev.setForeground(QColor(_QSS.GREEN_4) if "+" in d["Revision"] else QColor(_QSS.RED_4))
            self._tbl.setItem(r,4,rev)
            
            if d["StockRxn"] is None:
                rx = QTableWidgetItem("N/A")
                rx.setForeground(QColor(_QSS.ORANGE))
            else:
                rx=QTableWidgetItem(f"{d['StockRxn']:+.1f}%")
                rx.setForeground(QColor(_QSS.GREEN_4) if d["StockRxn"]>=0 else QColor(_QSS.RED_4))
            self._tbl.setItem(r,5,rx)
            
            t=QTableWidgetItem(d["Trend"])
            t.setForeground(QColor(_QSS.GREEN_4) if d["Trend"]=="Upgrading" else
                            QColor(_QSS.RED_4) if d["Trend"]=="Downgrading" else QColor(_QSS.ORANGE))
            self._tbl.setItem(r,6,t)

        pos = sum(1 for r in self.SURPRISE_DATA if r["Surp"] is not None and r["Surp"]>0)
        valid_surp = [r["Surp"] for r in self.SURPRISE_DATA if r["Surp"] is not None]
        avg_surp = (sum(valid_surp) / len(valid_surp) if valid_surp else 0.0)
        self._info.setText(f"Positive surprises: {pos}/{len(self.SURPRISE_DATA)}  |  "
                           f"Avg EPS surprise: {avg_surp:+.1f}%  |  Q4 FY26")

    def update_portfolio_data(self, portfolio_df):
        if portfolio_df is None or (hasattr(portfolio_df, 'empty') and portfolio_df.empty):
            return
        db_path = RUNTIME_DIR / "fundamentals_history.db"
        
        tickers = [str(row.get("Ticker", "")).replace(".NS", "").strip() for _, row in portfolio_df.iterrows()]
        surprise = []
        loaded_tickers = set()
        
        if db_path.exists():
            conn = None
            try:
                conn = sqlite3.connect(str(db_path))
                cur = conn.cursor()
                placeholders = ",".join("?" for _ in tickers)
                cur.execute(f"SELECT ticker, eps_act, eps_est, surprise, revision, stock_reaction, trend FROM earnings_surprise WHERE ticker IN ({placeholders})", tickers)
                rows = cur.fetchall()
                for r in rows:
                    surprise.append({
                        "Symbol": r[0],
                        "EPSAct": float(r[1]),
                        "EPSEst": float(r[2]),
                        "Surp": float(r[3]),
                        "Revision": str(r[4]),
                        "StockRxn": float(r[5]),
                        "Trend": str(r[6])
                    })
                    loaded_tickers.add(r[0])
            except Exception as e:
                print(f"Error updating surprise from DB: {e}")
            finally:
                if conn:
                    conn.close()
                
        from data_layer import fetch_fundamentals
        tickers_ns = [f"{t}.NS" if not t.endswith(".NS") else t for t in tickers]
        fund_data = fetch_fundamentals(tickers_ns)

        for _, row in portfolio_df.iterrows():
            t = str(row.get("Ticker", "")).replace(".NS", "").strip()
            if t in loaded_tickers:
                continue
            close = float(row.get("Price", 500.0))
            
            t_ns = f"{t}.NS"
            fd = fund_data.get(t_ns) or fund_data.get(t) or {"roe": 0.0, "de_ratio": 0.0, "rev_growth": 0.0, "pe_ratio": 0.0}
            pe = _safe_fund(fd.get("pe_ratio", 0.0))
            rev_growth = _safe_fund(fd.get("rev_growth", 0.0))
            
            if pe <= 0.0 and rev_growth == 0.0:
                surprise.append({
                    "Symbol": t,
                    "EPSAct": None,
                    "EPSEst": None,
                    "Surp": None,
                    "Revision": "N/A",
                    "StockRxn": None,
                    "Trend": "N/A"
                })
            else:
                # Trailing EPS actual = Price / trailing PE
                eps_act = close / pe if pe > 0 else (close * 0.04)
                # EPS estimate = what it would have been without growth this year
                # i.e. prior-year EPS = eps_act / (1 + rev_growth)
                prior_year_eps = eps_act / (1.0 + rev_growth) if (1.0 + rev_growth) > 0 else eps_act
                eps_est = max(0.1, prior_year_eps)
                
                surp = (eps_act - eps_est) / (eps_est + 1e-9) * 100.0
                # Stock reaction: empirically ~30% of EPS surprise (no random noise)
                rxn = round(surp * 0.3, 1)
                # Analyst revision reflects the revenue growth direction
                rev_pct = round(rev_growth * 100.0, 1)
                rev = f"+{rev_pct}%" if rev_pct > 0 else f"{rev_pct}%"
                trend = "Upgrading" if surp > 2.0 else "Downgrading" if surp < -2.0 else "Stable"
                
                surprise.append({
                    "Symbol": t,
                    "EPSAct": round(max(0.1, eps_act), 1),
                    "EPSEst": round(max(0.1, eps_est), 1),
                    "Surp": round(surp, 1),
                    "Revision": rev,
                    "StockRxn": rxn,
                    "Trend": trend
                })
        self.SURPRISE_DATA = surprise
        self._load()


class RevenueGrowthComparator(QWidget):
    """TAB 325 — Sector revenue growth: IT/Banking/FMCG/Auto/Pharma."""

    SECTOR_REVENUE = {
        "IT":      {"Q4FY24":52840,"Q1FY25":54120,"Q2FY25":55380,"Q3FY25":56920,"Q4FY25":58240,"Q4FY26":63200},
        "Banking": {"Q4FY24":224000,"Q1FY25":232000,"Q2FY25":238000,"Q3FY25":244000,"Q4FY25":251000,"Q4FY26":267000},
        "FMCG":    {"Q4FY24":41200,"Q1FY25":42100,"Q2FY25":43400,"Q3FY25":44200,"Q4FY25":45100,"Q4FY26":47800},
        "Auto":    {"Q4FY24":128000,"Q1FY25":132000,"Q2FY25":138000,"Q3FY25":142000,"Q4FY25":148000,"Q4FY26":158000},
        "Pharma":  {"Q4FY24":42800,"Q1FY25":44200,"Q2FY25":46100,"Q3FY25":48200,"Q4FY25":50400,"Q4FY26":54800},
    }

    def __init__(self, parent=None):
        super().__init__(parent)
        self.load_db_data()
        self._build_ui()

    def load_db_data(self):
        db_path = RUNTIME_DIR / "fundamentals_history.db"
        if not db_path.exists():
            return
        conn = None
        try:
            conn = sqlite3.connect(str(db_path))
            cur = conn.cursor()
            cur.execute("""
                SELECT sector, SUM(Q4FY24), SUM(Q1FY25), SUM(Q2FY25), SUM(Q3FY25), SUM(Q4FY25), SUM(Q4FY26)
                FROM ticker_quarterly_revenues
                GROUP BY sector
            """)
            rows = cur.fetchall()
            if rows:
                sector_rev = {}
                for r in rows:
                    sec = str(r[0])
                    if sec == "Others" or sec == "N/A" or not sec.strip():
                        continue
                    sector_rev[sec] = {
                        "Q4FY24": int(r[1] or 0),
                        "Q1FY25": int(r[2] or 0),
                        "Q2FY25": int(r[3] or 0),
                        "Q3FY25": int(r[4] or 0),
                        "Q4FY25": int(r[5] or 0),
                        "Q4FY26": int(r[6] or 0)
                    }
                if sector_rev:
                    self.SECTOR_REVENUE = sector_rev
        except Exception as e:
            print(f"Error loading sector revenues from DB: {e}")
        finally:
            if conn:
                conn.close()

    def _build_ui(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12,12,12,12); lay.setSpacing(8)

        hdr = QLabel("📊  Sector Revenue Growth Comparator")
        hdr.setStyleSheet("font-size:15px;font-weight:bold;")
        lay.addWidget(hdr)

        ctrl = QHBoxLayout()
        ctrl.addWidget(QLabel("View:"))
        self._view = QComboBox()
        self._view.addItems(["YoY Growth %","Absolute Revenue (₹Cr)","QoQ Growth %"])
        self._view.currentIndexChanged.connect(self._load)
        ctrl.addWidget(self._view)
        ctrl.addStretch()
        lay.addLayout(ctrl)

        quarters = ["Q4FY24","Q1FY25","Q2FY25","Q3FY25","Q4FY25","Q4FY26"]
        self._tbl = QTableWidget(0, len(quarters)+2)
        self._tbl.setHorizontalHeaderLabels(["Sector"]+quarters+["YoY Q4"])
        self._tbl.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self._tbl.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self._tbl.setAlternatingRowColors(True)
        # Table styling handled globally by QSS theme
        lay.addWidget(self._tbl)

        self._info = QLabel("")
        self._info.setStyleSheet("color:#8e8e93;font-size:11px;")
        lay.addWidget(self._info)
        self._load()

    def _load(self):
        view = self._view.currentText()
        quarters = ["Q4FY24","Q1FY25","Q2FY25","Q3FY25","Q4FY25","Q4FY26"]
        self._tbl.setRowCount(len(self.SECTOR_REVENUE))
        for r,(sector,data) in enumerate(self.SECTOR_REVENUE.items()):
            self._tbl.setItem(r,0,QTableWidgetItem(sector))
            for c,q in enumerate(quarters):
                val = data[q]
                if view=="Absolute Revenue (₹Cr)":
                    txt = f"₹{val:,}"
                elif view=="YoY Growth %" and c>=4:
                    # AUDIT-FIX (Round 5, 2-c-4): quarters[] is non-contiguous
                    # (Q1FY26–Q3FY26 skipped) so `list(data.keys())[c-4]` picked
                    # Q1FY25 for Q4FY26 — a 9-month comparison mislabeled as
                    # YoY and contradicting the "YoY Q4" column. Map each
                    # quarter explicitly to its same-quarter-prior-FY baseline.
                    _prev_map = {"Q4FY25": "Q4FY24", "Q4FY26": "Q4FY25"}
                    prev_yr_q = _prev_map.get(q)
                    if prev_yr_q is not None and prev_yr_q in data:
                        pv = data[prev_yr_q]
                        txt = f"{(val-pv)/pv*100:+.1f}%" if pv else "+0.0%"
                    else:
                        txt = "—"
                elif view=="QoQ Growth %" and c>0:
                    prev_q = quarters[c-1]
                    pv = data[prev_q]
                    txt = f"{(val-pv)/pv*100:+.1f}%" if pv else "+0.0%"
                else:
                    txt = f"₹{val:,}"
                item = QTableWidgetItem(txt)
                if "%" in txt:
                    try:
                        v=float(txt.replace("%","").replace("+",""))
                        item.setForeground(QColor(_QSS.GREEN_4) if v>=8 else
                                           QColor("#8bc34a") if v>=5 else
                                           QColor(_QSS.ORANGE) if v>=0 else QColor(_QSS.RED_4))
                    except Exception as _e:
                        archlog.error('Exception detail', exc_info=True)
                        pass
                self._tbl.setItem(r,c+1,item)
            # YoY Q4FY26 vs Q4FY25
            yoy = (data["Q4FY26"]-data["Q4FY25"])/data["Q4FY25"]*100 if data["Q4FY25"] else 0
            yoy_item=QTableWidgetItem(f"{yoy:+.1f}%")
            yoy_item.setForeground(QColor(_QSS.GREEN_4) if yoy>=8 else
                                   QColor(_QSS.ORANGE) if yoy>=0 else QColor(_QSS.RED_4))
            yoy_item.setFont(QFont("",-1,QFont.Bold))
            self._tbl.setItem(r,7,yoy_item)

        if self.SECTOR_REVENUE:
            best_sector = max(self.SECTOR_REVENUE.items(),
                              key=lambda x:(x[1]["Q4FY26"]-x[1]["Q4FY25"])/x[1]["Q4FY25"] if x[1]["Q4FY25"] else 0)
            self._info.setText(f"Fastest growing sector Q4FY26: {best_sector[0]}  |  View: {view}")
        else:
            self._info.setText(f"No sectors loaded  |  View: {view}")

    def update_portfolio_data(self, portfolio_df):
        if portfolio_df is None or (hasattr(portfolio_df, 'empty') and portfolio_df.empty):
            return
        db_path = RUNTIME_DIR / "fundamentals_history.db"
        
        tickers = [str(row.get("Ticker", "")).replace(".NS", "").strip() for _, row in portfolio_df.iterrows()]
        sector_rev = {}
        loaded_sectors = set()
        
        if db_path.exists():
            conn = None
            try:
                conn = sqlite3.connect(str(db_path))
                cur = conn.cursor()
                placeholders = ",".join("?" for _ in tickers)
                cur.execute(f"""
                    SELECT sector, SUM(Q4FY24), SUM(Q1FY25), SUM(Q2FY25), SUM(Q3FY25), SUM(Q4FY25), SUM(Q4FY26)
                    FROM ticker_quarterly_revenues
                    WHERE ticker IN ({placeholders})
                    GROUP BY sector
                """, tickers)
                rows = cur.fetchall()
                for r in rows:
                    sec = str(r[0])
                    sector_rev[sec] = {
                        "Q4FY24": int(r[1] or 0),
                        "Q1FY25": int(r[2] or 0),
                        "Q2FY25": int(r[3] or 0),
                        "Q3FY25": int(r[4] or 0),
                        "Q4FY25": int(r[5] or 0),
                        "Q4FY26": int(r[6] or 0)
                    }
                    loaded_sectors.add(sec)
            except Exception as e:
                print(f"Error updating sector revenues from DB: {e}")
            finally:
                if conn:
                    conn.close()
                
        # Let's group tickers by sector first
        sector_tickers = {}
        for _, row in portfolio_df.iterrows():
            t = str(row.get("Ticker", "")).replace(".NS", "").strip()
            sec = str(row.get("Sector", "Others"))
            if sec in loaded_sectors or sec == "Others" or not sec.strip():
                continue
            if sec not in sector_tickers:
                sector_tickers[sec] = []
            sector_tickers[sec].append((t, float(row.get("Price", 500.0))))
            
        all_missing_tickers = []
        for sec, items in sector_tickers.items():
            all_missing_tickers.extend([item[0] for item in items])
            
        from data_layer import fetch_fundamentals
        tickers_ns = [f"{t}.NS" if not t.endswith(".NS") else t for t in all_missing_tickers]
        fund_data = fetch_fundamentals(tickers_ns)
        
        for sec, items in sector_tickers.items():
            if sec not in sector_rev:
                sector_rev[sec] = {"Q4FY24": 0, "Q1FY25": 0, "Q2FY25": 0, "Q3FY25": 0, "Q4FY25": 0, "Q4FY26": 0}
            
            # Compute average rev_growth for this sector
            growths = []
            for t, _ in items:
                t_ns = f"{t}.NS"
                fd = fund_data.get(t_ns) or fund_data.get(t) or {}
                if "rev_growth" in fd:
                    growths.append(fd["rev_growth"])
            
            avg_growth = sum(growths)/len(growths) if growths else 0.05
            
            for t, close in items:
                base = close * 15.0
                sector_rev[sec]["Q4FY24"] += int(base * 0.85)
                sector_rev[sec]["Q1FY25"] += int(base * 0.88)
                sector_rev[sec]["Q2FY25"] += int(base * 0.90)
                sector_rev[sec]["Q3FY25"] += int(base * 0.93)
                sector_rev[sec]["Q4FY25"] += int(base * 0.96)
                # Q4FY26: apply real average rev_growth — no random spread
                sector_rev[sec]["Q4FY26"] += int(base * 0.96 * (1.0 + avg_growth))
                
        if sector_rev:
            self.SECTOR_REVENUE = sector_rev
            self._load()


class MarginTrendAnalyzer(QWidget):
    """TAB 326 — EBITDA/PAT margin: 8-quarter rolling, expansion signal."""

    MARGIN_DATA = {
        "TCS":       {"EBITDA":[27.2,27.8,28.1,27.9,28.4,28.6,29.1,28.8],
                      "PAT":   [19.1,19.4,19.8,19.6,20.1,20.3,20.7,20.4]},
        "HDFCBANK":  {"EBITDA":[24.1,24.8,25.2,24.9,25.4,25.8,26.2,25.9],
                      "PAT":   [19.8,20.2,20.8,20.5,21.1,21.4,21.9,21.6]},
        "MARUTI":    {"EBITDA":[8.2, 9.1, 9.8,10.2,10.8,11.2,11.8,11.4],
                      "PAT":   [5.4, 6.1, 6.8, 7.2, 7.8, 8.1, 8.6, 8.2]},
        "SUNPHARMA": {"EBITDA":[24.8,25.2,26.1,25.8,26.4,26.8,27.4,27.1],
                      "PAT":   [18.4,18.8,19.4,19.1,19.8,20.2,20.8,20.4]},
        "HINDUNILVR":{"EBITDA":[23.8,24.1,24.6,24.3,24.8,25.1,25.4,25.0],
                      "PAT":   [17.2,17.5,17.9,17.6,18.1,18.4,18.7,18.3]},
    }
    QUARTERS = ["Q1FY25","Q2FY25","Q3FY25","Q4FY25","Q1FY26","Q2FY26","Q3FY26","Q4FY26"]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.load_db_data()
        self._build_ui()

    def load_db_data(self):
        db_path = RUNTIME_DIR / "fundamentals_history.db"
        if not db_path.exists():
            return
        conn = None
        try:
            conn = sqlite3.connect(str(db_path))
            cur = conn.cursor()
            cur.execute("SELECT ticker, ebitda_q1, ebitda_q2, ebitda_q3, ebitda_q4, ebitda_q5, ebitda_q6, ebitda_q7, ebitda_q8, pat_q1, pat_q2, pat_q3, pat_q4, pat_q5, pat_q6, pat_q7, pat_q8 FROM margin_trends")
            rows = cur.fetchall()
            if rows:
                margin_data = {}
                for r in rows:
                    margin_data[r[0]] = {
                        "EBITDA": [float(val) for val in r[1:9]],
                        "PAT": [float(val) for val in r[9:17]]
                    }
                self.MARGIN_DATA = margin_data
        except Exception as e:
            print(f"Error loading margin trends from DB: {e}")
        finally:
            if conn:
                conn.close()

    def _build_ui(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12,12,12,12); lay.setSpacing(8)

        hdr = QLabel("📐  Margin Trend Analyzer — 8-Quarter Rolling")
        hdr.setStyleSheet("font-size:15px;font-weight:bold;")
        lay.addWidget(hdr)

        ctrl = QHBoxLayout()
        ctrl.addWidget(QLabel("Metric:"))
        self._metric = QComboBox()
        # L28-fix: drop "Both" from the combo options. Previously picking "Both" silently
        # force-set metric_key to "EBITDA" only (see _load below), so the user's selection
        # had no effect and the PAT column was never shown. Removing the option is the
        # simplest fix — callers who want both can switch the combo manually.
        self._metric.addItems(["EBITDA Margin", "PAT Margin"])
        self._metric.currentIndexChanged.connect(self._load)
        ctrl.addWidget(self._metric)
        ctrl.addStretch()
        lay.addLayout(ctrl)

        cols = ["Symbol"]+self.QUARTERS+["Trend","8Q Change"]
        self._tbl = QTableWidget(0, len(cols))
        self._tbl.setHorizontalHeaderLabels(cols)
        self._tbl.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self._tbl.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self._tbl.setAlternatingRowColors(True)
        # Table styling handled globally by QSS theme
        lay.addWidget(self._tbl)

        self._info = QLabel("Expansion = latest margin > 8Q average  |  Values in %")
        self._info.setStyleSheet("color:#8e8e93;font-size:11px;")
        lay.addWidget(self._info)
        self._load()

    def _load(self):
        metric_key = "EBITDA" if self._metric.currentText()=="EBITDA Margin" else "PAT"
        if self._metric.currentText()=="Both": metric_key="EBITDA"

        self._tbl.setRowCount(len(self.MARGIN_DATA))
        for r,(sym,data) in enumerate(self.MARGIN_DATA.items()):
            margins = data[metric_key]
            valid_margins = [m for m in margins if m is not None]
            
            self._tbl.setItem(r,0,QTableWidgetItem(sym))
            
            if not valid_margins:
                for c in range(8):
                    self._tbl.setItem(r, c+1, QTableWidgetItem("N/A"))
                t = QTableWidgetItem("N/A")
                t.setForeground(QColor(_QSS.ORANGE))
                self._tbl.setItem(r, 9, t)
                ch = QTableWidgetItem("N/A")
                ch.setForeground(QColor(_QSS.ORANGE))
                self._tbl.setItem(r, 10, ch)
                continue
                
            avg8 = sum(valid_margins) / len(valid_margins)
            latest = margins[-1] if margins[-1] is not None else avg8
            first = margins[0] if margins[0] is not None else avg8
            chg = latest - first
            trend = "↑ Expanding" if chg>0.5 else "↓ Contracting" if chg<-0.5 else "→ Stable"
            
            for c,m in enumerate(margins):
                if m is None:
                    item = QTableWidgetItem("N/A")
                    item.setForeground(QColor(_QSS.ORANGE))
                else:
                    item=QTableWidgetItem(f"{m:.1f}%")
                    item.setForeground(QColor(_QSS.GREEN_4) if m>avg8 else QColor(_QSS.RED_4))
                self._tbl.setItem(r,c+1,item)
                
            t=QTableWidgetItem(trend)
            t.setForeground(QColor(_QSS.GREEN_4) if "Expand" in trend else
                            QColor(_QSS.RED_4) if "Contract" in trend else QColor(_QSS.ORANGE))
            self._tbl.setItem(r,9,t)
            ch=QTableWidgetItem(f"{chg:+.1f}%")
            ch.setForeground(QColor(_QSS.GREEN_4) if chg>0 else QColor(_QSS.RED_4))
            self._tbl.setItem(r,10,ch)

        expanding = 0
        total_valid = 0
        for d in self.MARGIN_DATA.values():
            m_list = d[metric_key]
            if m_list and m_list[-1] is not None and m_list[0] is not None:
                total_valid += 1
                if m_list[-1] > m_list[0]:
                    expanding += 1
                    
        self._info.setText(f"Expanding margins: {expanding}/{total_valid}  |  "
                           f"Metric: {self._metric.currentText()}  |  8 quarters FY25-FY26")

    def update_portfolio_data(self, portfolio_df):
        if portfolio_df is None or (hasattr(portfolio_df, 'empty') and portfolio_df.empty):
            return
        db_path = RUNTIME_DIR / "fundamentals_history.db"
        
        tickers = [str(row.get("Ticker", "")).replace(".NS", "").strip() for _, row in portfolio_df.iterrows()]
        margin_data = {}
        loaded_tickers = set()
        
        if db_path.exists():
            conn = None
            try:
                conn = sqlite3.connect(str(db_path))
                cur = conn.cursor()
                placeholders = ",".join("?" for _ in tickers)
                cur.execute(f"SELECT ticker, ebitda_q1, ebitda_q2, ebitda_q3, ebitda_q4, ebitda_q5, ebitda_q6, ebitda_q7, ebitda_q8, pat_q1, pat_q2, pat_q3, pat_q4, pat_q5, pat_q6, pat_q7, pat_q8 FROM margin_trends WHERE ticker IN ({placeholders})", tickers)
                rows = cur.fetchall()
                for r in rows:
                    margin_data[r[0]] = {
                        "EBITDA": [float(val) for val in r[1:9]],
                        "PAT": [float(val) for val in r[9:17]]
                    }
                    loaded_tickers.add(r[0])
            except Exception as e:
                print(f"Error updating margins from DB: {e}")
            finally:
                if conn:
                    conn.close()
                
        from data_layer import fetch_fundamentals
        tickers_ns = [f"{t}.NS" if not t.endswith(".NS") else t for t in tickers]
        fund_data = fetch_fundamentals(tickers_ns)

        for _, row in portfolio_df.iterrows():
            t = str(row.get("Ticker", "")).replace(".NS", "").strip()
            if t in loaded_tickers:
                continue
            
            t_ns = f"{t}.NS"
            fd = fund_data.get(t_ns) or fund_data.get(t) or {"roe": 0.0, "de_ratio": 0.0, "rev_growth": 0.0, "pe_ratio": 0.0}
            roe = _safe_fund(fd.get("roe", 0.0))
            de = _safe_fund(fd.get("de_ratio", 0.0))
            
            if roe == 0.0 and de == 0.0:
                margin_data[t] = {"EBITDA": [None]*8, "PAT": [None]*8}
            else:
                # Dupont: NPM ≈ ROE / (Asset_Turnover * Equity_Multiplier)
                # Asset turnover ~1.5x (industry average), equity multiplier = 1 + D/E
                base_pat = max(3.0, min(35.0, (roe * 100.0) / (1.5 * (1.0 + de))))
                # EBITDA margin: approximate from PAT by adding back depreciation+tax
                # For Indian listed companies, EBITDA is roughly 1.5x PAT on average
                base_eb = max(5.0, min(50.0, base_pat * 1.5))
                # 8-quarter linear trend: flat series — we cannot fabricate quarterly trajectory
                # from annual ratios. Show flat values derived from current fundamentals.
                eb_list = [round(base_eb, 1)] * 8
                pat_list = [round(base_pat, 1)] * 8
                margin_data[t] = {"EBITDA": eb_list, "PAT": pat_list}
        self.MARGIN_DATA = margin_data
        self._load()


class ConsensusForecastPanel(QWidget):
    """TAB 327 — Analyst EPS consensus: 1Y/2Y forward, revision trend."""

    CONSENSUS_DATA = [
        {"Symbol":"RELIANCE","CMP":1284,"TP":1480,"Upside":15.3,"EPS_FY26":112,"EPS_FY27":132,"PEF":11.5,"Rec":"BUY","Analysts":42,"UpgCnt":8,"DngCnt":1},
        {"Symbol":"TCS","CMP":3380,"TP":3820,"Upside":13.0,"EPS_FY26":142,"EPS_FY27":162,"PEF":23.8,"Rec":"BUY","Analysts":38,"UpgCnt":6,"DngCnt":2},
        {"Symbol":"HDFCBANK","CMP":1648,"TP":1920,"Upside":16.5,"EPS_FY26":96,"EPS_FY27":112,"PEF":17.2,"Rec":"BUY","Analysts":44,"UpgCnt":10,"DngCnt":0},
        {"Symbol":"INFY","CMP":1412,"TP":1520,"Upside":7.6,"EPS_FY26":68,"EPS_FY27":75,"PEF":20.8,"Rec":"HOLD","Analysts":36,"UpgCnt":2,"DngCnt":6},
        {"Symbol":"BAJFINANCE","CMP":6840,"TP":7200,"Upside":5.3,"EPS_FY26":295,"EPS_FY27":345,"PEF":23.2,"Rec":"HOLD","Analysts":32,"UpgCnt":3,"DngCnt":5},
        {"Symbol":"ICICIBANK","CMP":1182,"TP":1420,"Upside":20.1,"EPS_FY26":74,"EPS_FY27":88,"PEF":16.0,"Rec":"BUY","Analysts":41,"UpgCnt":9,"DngCnt":0},
        {"Symbol":"MARUTI","CMP":12240,"TP":13800,"Upside":12.7,"EPS_FY26":498,"EPS_FY27":574,"PEF":24.6,"Rec":"BUY","Analysts":28,"UpgCnt":7,"DngCnt":1},
        {"Symbol":"SUNPHARMA","CMP":1682,"TP":1920,"Upside":14.1,"EPS_FY26":60,"EPS_FY27":71,"PEF":28.0,"Rec":"BUY","Analysts":24,"UpgCnt":5,"DngCnt":1},
        {"Symbol":"WIPRO","CMP":488,"TP":480,"Upside":-1.6,"EPS_FY26":23,"EPS_FY27":25,"PEF":21.2,"Rec":"HOLD","Analysts":30,"UpgCnt":1,"DngCnt":7},
        {"Symbol":"DRREDDY","CMP":1142,"TP":1380,"Upside":20.8,"EPS_FY26":356,"EPS_FY27":412,"PEF":3.2,"Rec":"BUY","Analysts":22,"UpgCnt":6,"DngCnt":0},
    ]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.load_db_data()
        self._build_ui()

    def load_db_data(self):
        db_path = RUNTIME_DIR / "fundamentals_history.db"
        if not db_path.exists():
            return
        conn = None
        try:
            conn = sqlite3.connect(str(db_path))
            cur = conn.cursor()
            cur.execute("SELECT ticker, cmp, target_price, upside, eps_fy26, eps_fy27, pe_fwd, recommendation, analysts, upgrades_count, downgrades_count FROM consensus_forecasts")
            rows = cur.fetchall()
            if rows:
                consensus = []
                for r in rows:
                    consensus.append({
                        "Symbol": r[0],
                        "CMP": int(r[1] or 0),
                        "TP": int(r[2] or 0),
                        "Upside": float(r[3] or 0.0),
                        "EPS_FY26": float(r[4] or 0.0),
                        "EPS_FY27": float(r[5] or 0.0),
                        "PEF": float(r[6] or 0.0),
                        "Rec": str(r[7] or "HOLD"),
                        "Analysts": int(r[8] or 0),
                        "UpgCnt": int(r[9] or 0),
                        "DngCnt": int(r[10] or 0)
                    })
                self.CONSENSUS_DATA = consensus
        except Exception as e:
            print(f"Error loading consensus forecasts from DB: {e}")
        finally:
            if conn:
                conn.close()

    def _build_ui(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12,12,12,12); lay.setSpacing(8)

        hdr = QLabel("🔭  Analyst Consensus Forecast Panel")
        hdr.setStyleSheet("font-size:15px;font-weight:bold;")
        lay.addWidget(hdr)

        ctrl = QHBoxLayout()
        ctrl.addWidget(QLabel("Filter:"))
        self._filter = QComboBox()
        self._filter.addItems(["All","BUY","HOLD","Upside >15%","Upgrades > Downgrades"])
        self._filter.currentIndexChanged.connect(self._load)
        ctrl.addWidget(self._filter)
        ctrl.addWidget(QLabel("Sort:"))
        self._sort = QComboBox()
        self._sort.addItems(["Upside %","EPS FY27","P/E Fwd","# Analysts"])
        self._sort.currentIndexChanged.connect(self._load)
        ctrl.addWidget(self._sort)
        ctrl.addStretch()
        lay.addLayout(ctrl)

        self._tbl = QTableWidget(0, 10)
        self._tbl.setHorizontalHeaderLabels(["Symbol","CMP","Target","Upside","EPS FY26",
                                              "EPS FY27","Fwd P/E","Rating","Analysts","Upgrades"])
        self._tbl.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self._tbl.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self._tbl.setAlternatingRowColors(True)
        # Table styling handled globally by QSS theme
        lay.addWidget(self._tbl)

        self._info = QLabel("")
        self._info.setStyleSheet("color:#8e8e93;font-size:11px;")
        lay.addWidget(self._info)
        self._load()

    def _load(self):
        filt = self._filter.currentText()
        sort = self._sort.currentText()
        rows = list(self.CONSENSUS_DATA)
        if filt=="BUY":    rows=[r for r in rows if r["Rec"]=="BUY"]
        elif filt=="HOLD": rows=[r for r in rows if r["Rec"]=="HOLD"]
        elif filt=="Upside >15%": rows=[r for r in rows if r["Upside"] is not None and r["Upside"]>15]
        elif filt=="Upgrades > Downgrades": rows=[r for r in rows if r["UpgCnt"] is not None and r["DngCnt"] is not None and r["UpgCnt"]>r["DngCnt"]]
        if sort=="Upside %":   rows=sorted(rows,key=lambda x:(x["Upside"] is not None, x["Upside"] or -9999.0),reverse=True)
        elif sort=="EPS FY27": rows=sorted(rows,key=lambda x:(x["EPS_FY27"] is not None, x["EPS_FY27"] or -9999.0),reverse=True)
        elif sort=="P/E Fwd":  rows=sorted(rows,key=lambda x:(x["PEF"] is not None, x["PEF"] or 9999.0))
        elif sort=="# Analysts":rows=sorted(rows,key=lambda x:(x["Analysts"] is not None, x["Analysts"] or -9999.0),reverse=True)

        self._tbl.setRowCount(len(rows))
        rec_colors={"BUY":"#4caf50","HOLD":"#ffc107","SELL":"#f44336"}
        for r,d in enumerate(rows):
            self._tbl.setItem(r,0,QTableWidgetItem(d["Symbol"]))
            self._tbl.setItem(r,1,QTableWidgetItem(f"₹{d['CMP']:,}"))
            
            if d["TP"] is None:
                self._tbl.setItem(r,2,QTableWidgetItem("N/A"))
            else:
                self._tbl.setItem(r,2,QTableWidgetItem(f"₹{d['TP']:,}"))
                
            if d["Upside"] is None:
                up = QTableWidgetItem("N/A")
                up.setForeground(QColor(_QSS.ORANGE))
            else:
                up=QTableWidgetItem(f"{d['Upside']:+.1f}%")
                up.setForeground(QColor(_QSS.GREEN_4) if d["Upside"]>10 else
                                  QColor(_QSS.ORANGE) if d["Upside"]>0 else QColor(_QSS.RED_4))
            self._tbl.setItem(r,3,up)
            
            if d["EPS_FY26"] is None:
                self._tbl.setItem(r,4,QTableWidgetItem("N/A"))
            else:
                self._tbl.setItem(r,4,QTableWidgetItem(f"₹{d['EPS_FY26']}"))
                
            if d["EPS_FY27"] is None:
                self._tbl.setItem(r,5,QTableWidgetItem("N/A"))
            else:
                self._tbl.setItem(r,5,QTableWidgetItem(f"₹{d['EPS_FY27']}"))
                
            if d["PEF"] is None:
                self._tbl.setItem(r,6,QTableWidgetItem("N/A"))
            else:
                self._tbl.setItem(r,6,QTableWidgetItem(f"{d['PEF']:.1f}x"))
                
            rec=QTableWidgetItem(d["Rec"])
            rec.setForeground(QColor(rec_colors.get(d["Rec"],_QSS.MUTED)))
            self._tbl.setItem(r,7,rec)
            
            if d["Analysts"] is None:
                self._tbl.setItem(r,8,QTableWidgetItem("N/A"))
            else:
                self._tbl.setItem(r,8,QTableWidgetItem(str(d["Analysts"])))
                
            if d["UpgCnt"] is None or d["DngCnt"] is None:
                ug = QTableWidgetItem("N/A")
                ug.setForeground(QColor(_QSS.ORANGE))
            else:
                ug=QTableWidgetItem(f"▲{d['UpgCnt']} ▼{d['DngCnt']}")
                ug.setForeground(QColor(_QSS.GREEN_4) if d["UpgCnt"]>d["DngCnt"] else
                                  QColor(_QSS.RED_4) if d["DngCnt"]>d["UpgCnt"] else QColor(_QSS.ORANGE))
            self._tbl.setItem(r,9,ug)

        buy_ct = sum(1 for r in self.CONSENSUS_DATA if r["Rec"]=="BUY") if self.CONSENSUS_DATA else 0
        valid_upsides = [r["Upside"] for r in self.CONSENSUS_DATA if r["Upside"] is not None]
        avg_up  = (sum(valid_upsides)/len(valid_upsides) if valid_upsides else 0.0)
        self._info.setText(f"BUY: {buy_ct}/{len(self.CONSENSUS_DATA)}  |  "
                           f"Avg upside: {avg_up:.1f}%  |  "
                           f"Filter: {filt}  |  FY26-FY27 forward estimates")

    def update_portfolio_data(self, portfolio_df):
        if portfolio_df is None or (hasattr(portfolio_df, 'empty') and portfolio_df.empty):
            return
        db_path = RUNTIME_DIR / "fundamentals_history.db"
        
        tickers = [str(row.get("Ticker", "")).replace(".NS", "").strip() for _, row in portfolio_df.iterrows()]
        consensus = []
        loaded_tickers = set()
        
        if db_path.exists():
            conn = None
            try:
                conn = sqlite3.connect(str(db_path))
                cur = conn.cursor()
                placeholders = ",".join("?" for _ in tickers)
                cur.execute(f"SELECT ticker, cmp, target_price, upside, eps_fy26, eps_fy27, pe_fwd, recommendation, analysts, upgrades_count, downgrades_count FROM consensus_forecasts WHERE ticker IN ({placeholders})", tickers)
                rows = cur.fetchall()
                for r in rows:
                    consensus.append({
                        "Symbol": r[0],
                        "CMP": int(r[1] or 0),
                        "TP": int(r[2] or 0),
                        "Upside": float(r[3] or 0.0),
                        "EPS_FY26": float(r[4] or 0.0),
                        "EPS_FY27": float(r[5] or 0.0),
                        "PEF": float(r[6] or 0.0),
                        "Rec": str(r[7] or "HOLD"),
                        "Analysts": int(r[8] or 0),
                        "UpgCnt": int(r[9] or 0),
                        "DngCnt": int(r[10] or 0)
                    })
                    loaded_tickers.add(r[0])
            except Exception as e:
                print(f"Error updating consensus from DB: {e}")
            finally:
                if conn:
                    conn.close()
                
        from data_layer import fetch_fundamentals
        tickers_ns = [f"{t}.NS" if not t.endswith(".NS") else t for t in tickers]
        fund_data = fetch_fundamentals(tickers_ns)

        for _, row in portfolio_df.iterrows():
            t = str(row.get("Ticker", "")).replace(".NS", "").strip()
            if t in loaded_tickers:
                continue
            close = float(row.get("Price", 500.0))
            
            t_ns = f"{t}.NS"
            fd = fund_data.get(t_ns) or fund_data.get(t) or {"roe": 0.0, "de_ratio": 0.0, "rev_growth": 0.0, "pe_ratio": 0.0}
            pe = _safe_fund(fd.get("pe_ratio", 0.0))
            rev_growth = _safe_fund(fd.get("rev_growth", 0.0))
            
            if pe <= 0.0 and rev_growth == 0.0:
                consensus.append({
                    "Symbol": t,
                    "CMP": int(close),
                    "TP": None,
                    "Upside": None,
                    "EPS_FY26": None,
                    "EPS_FY27": None,
                    "PEF": None,
                    "Rec": "HOLD",
                    "Analysts": None,
                    "UpgCnt": None,
                    "DngCnt": None
                })
            else:
                # Upside = expected price appreciation from revenue growth
                # Conservative: 80% of rev_growth flows through to price (no random)
                upside = round(rev_growth * 100.0 * 0.8, 1)
                target = round(close * (1.0 + upside / 100.0), 1)
                
                # Forward EPS: trailing EPS grown by rev_growth for FY26, then again for FY27
                eps_base = close / pe if pe > 0.0 else close * 0.04
                eps_fy26 = round(eps_base * (1.0 + rev_growth), 1)
                eps_fy27 = round(eps_fy26 * (1.0 + rev_growth), 1)
                
                pe_fwd = round(close / max(1e-9, eps_fy26), 1)
                rec = "BUY" if upside > 12.0 else "HOLD" if upside > 0.0 else "SELL"
                # Analyst count/upgrade/downgrade data not derivable from fundamentals
                # — show None so the UI renders N/A rather than fabricating numbers
                
                consensus.append({
                    "Symbol": t,
                    "CMP": int(close),
                    "TP": int(target),
                    "Upside": upside,
                    "EPS_FY26": eps_fy26,
                    "EPS_FY27": eps_fy27,
                    "PEF": pe_fwd,
                    "Rec": rec,
                    "Analysts": None,
                    "UpgCnt": None,
                    "DngCnt": None
                })
        self.CONSENSUS_DATA = consensus
        self._load()


class CorporateActionsLogPanel(QWidget):
    """TAB 328 — Corporate actions: Splits, bonuses, and dividends from local DB."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.actions_data = []
        self._build_ui()
        self.load_data()

    def _build_ui(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 12, 12, 12)
        lay.setSpacing(8)

        hdr = QLabel("📢  Point-in-Time Corporate Actions & Adjustments Log")
        hdr.setStyleSheet("font-size:15px;font-weight:bold;")
        lay.addWidget(hdr)

        ctrl = QHBoxLayout()
        ctrl.addWidget(QLabel("Ticker Filter:"))
        self._ticker_filter = QLineEdit()
        self._ticker_filter.setPlaceholderText("e.g. AAPL, Reliance")
        self._ticker_filter.textChanged.connect(self._filter_and_sort)
        ctrl.addWidget(self._ticker_filter)

        ctrl.addWidget(QLabel("Action Type:"))
        self._type_filter = QComboBox()
        self._type_filter.addItems(["All", "SPLIT", "BONUS", "DIVIDEND"])
        self._type_filter.currentIndexChanged.connect(self._filter_and_sort)
        ctrl.addWidget(self._type_filter)

        ctrl.addWidget(QLabel("Sort by:"))
        self._sort_by = QComboBox()
        self._sort_by.addItems(["Ex-Date (Newest)", "Ex-Date (Oldest)", "Ticker"])
        self._sort_by.currentIndexChanged.connect(self._filter_and_sort)
        ctrl.addWidget(self._sort_by)

        self._refresh_btn = QPushButton("🔄 Refresh")
        self._refresh_btn.clicked.connect(self.load_data)
        ctrl.addWidget(self._refresh_btn)
        
        ctrl.addStretch()
        lay.addLayout(ctrl)

        # Table Widget
        self._tbl = QTableWidget(0, 6)
        self._tbl.setHorizontalHeaderLabels([
            "Ticker", "Action Type", "Ex-Date", "Ratio (New/Old)", "Amount (₹)", "Announcement Date"
        ])
        self._tbl.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self._tbl.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self._tbl.setAlternatingRowColors(True)
        lay.addWidget(self._tbl)

        # Info Label
        self._info = QLabel("Total: 0 actions")
        self._info.setStyleSheet("color:#8e8e93;font-size:11px;")
        lay.addWidget(self._info)

    def load_data(self):
        """Load corporate actions from SQLite fundamentals_history.db."""
        db_path = RUNTIME_DIR / "fundamentals_history.db"
        if not db_path.exists():
            self._info.setText("Error: fundamentals_history.db not found.")
            return

        conn = None
        try:
            conn = sqlite3.connect(str(db_path))
            cur = conn.cursor()
            
            # Check if corporate_actions table exists
            cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='corporate_actions'")
            if not cur.fetchone():
                self._info.setText("Error: corporate_actions table does not exist in DB.")
                return

            cur.execute("""
                SELECT ticker, type, ex_date, ratio, amount, publish_date
                FROM corporate_actions
            """)
            rows = cur.fetchall()

            self.actions_data = []
            for r in rows:
                self.actions_data.append({
                    "ticker": str(r[0]),
                    "type": str(r[1]),
                    "ex_date": str(r[2]),
                    "ratio": float(r[3] or 1.0),
                    "amount": float(r[4] or 0.0),
                    "publish_date": str(r[5] or "")
                })

            self._filter_and_sort()

        except Exception as e:
            self._info.setText(f"Error loading corporate actions: {e}")
        finally:
            if conn:
                conn.close()

    def _filter_and_sort(self):
        ticker_q = self._ticker_filter.text().strip().upper()
        type_q = self._type_filter.currentText()
        sort_q = self._sort_by.currentText()

        # Filtering
        rows = list(self.actions_data)
        if ticker_q:
            rows = [r for r in rows if ticker_q in r["ticker"].upper()]
        if type_q != "All":
            rows = [r for r in rows if r["type"] == type_q]

        # Sorting
        if sort_q == "Ex-Date (Newest)":
            rows = sorted(rows, key=lambda x: x["ex_date"], reverse=True)
        elif sort_q == "Ex-Date (Oldest)":
            rows = sorted(rows, key=lambda x: x["ex_date"])
        elif sort_q == "Ticker":
            rows = sorted(rows, key=lambda x: (x["ticker"], x["ex_date"]))

        # Populating Table
        self._tbl.setRowCount(len(rows))
        for r, d in enumerate(rows):
            self._tbl.setItem(r, 0, QTableWidgetItem(d["ticker"]))
            
            type_item = QTableWidgetItem(d["type"])
            if d["type"] == "SPLIT":
                type_item.setForeground(QColor(_QSS.GREEN_4) if hasattr(_QSS, "GREEN_4") else QColor("#34c759"))
            elif d["type"] == "BONUS":
                type_item.setForeground(QColor(_QSS.ORANGE) if hasattr(_QSS, "ORANGE") else QColor("#ff9500"))
            else:
                type_item.setForeground(QColor("#0a84ff"))
            self._tbl.setItem(r, 1, type_item)
            
            self._tbl.setItem(r, 2, QTableWidgetItem(d["ex_date"]))
            
            # Ratio
            ratio_str = f"{d['ratio']:.2f}" if d["type"] in ("SPLIT", "BONUS") else "-"
            self._tbl.setItem(r, 3, QTableWidgetItem(ratio_str))
            
            # Amount
            amt_str = f"₹{d['amount']:.2f}" if d["type"] == "DIVIDEND" else "-"
            self._tbl.setItem(r, 4, QTableWidgetItem(amt_str))
            
            self._tbl.setItem(r, 5, QTableWidgetItem(d["publish_date"]))

        # Count stats
        splits = sum(1 for r in rows if r["type"] == "SPLIT")
        bonuses = sum(1 for r in rows if r["type"] == "BONUS")
        dividends = sum(1 for r in rows if r["type"] == "DIVIDEND")
        
        self._info.setText(
            f"Showing {len(rows)} actions  |  Splits: {splits}  |  Bonuses: {bonuses}  |  Dividends: {dividends}"
        )

    def update_portfolio_data(self, portfolio_df):
        self.load_data()
