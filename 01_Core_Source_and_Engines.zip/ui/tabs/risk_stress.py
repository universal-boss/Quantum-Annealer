"""
ui/tabs/risk_stress.py
=======================
Advanced Risk Analytics & Stress Testing tab modules.
Ports ScenarioStressLibrary dynamically into the modular application structure.
"""
import sys
try:
    from PySide6.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QDoubleSpinBox, QSpinBox, QTableWidget, QTableWidgetItem, QHeaderView
    )
    from PySide6.QtGui import QColor
    from PySide6.QtCore import Qt
except ImportError:
    from PyQt5.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QDoubleSpinBox, QSpinBox, QTableWidget, QTableWidgetItem, QHeaderView
    )
    from PyQt5.QtGui import QColor
    from PyQt5.QtCore import Qt

from ui.styling import _QSS

try:
    from PySide6.QtCore import Signal
except ImportError:
    from PyQt5.QtCore import Signal


class ScenarioStressLibrary(QWidget):
    """
    Historical stress scenarios applied dynamically to portfolio weights.
    """
    SCENARIOS = [
        ("COVID Crash 2020",      -0.380, 33,  "S&P/Nifty -38% in 33 days (Feb-Mar 2020)"),
        ("Taper Tantrum 2013",    -0.100, 65,  "Nifty -10% in 65 days (May-Aug 2013)"),
        ("2008 GFC",              -0.500, 365, "Global markets -50% over 12 months"),
        ("Dot-Com 2000",          -0.450, 400, "Tech-heavy -45% over ~13 months"),
        ("India VIX Spike 2015",  -0.200, 30,  "Nifty -20% in 30 days (Aug 2015)"),
        ("Russia-Ukraine 2022",   -0.150, 60,  "Commodity shock -15% in 60 days"),
        ("Custom Shock",          -0.150, 45,  "User-defined scenario"),
    ]

    _fit_ready = Signal(object, object)  # (tester or None, fit_key)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("ScenarioStressLibrary")
        # AUDIT-FIX (Round 6, D-P2-12): background macro-fit state (see the
        # D-P2-12 note in _run_all) — fitted-tester cache keyed by payload
        # date-range + notional.
        self._fitted_tester = None
        self._fit_key = None
        self._fit_worker = None
        self._fit_in_flight = False
        self._fit_ready.connect(self._on_fit_ready)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 14, 14, 14)
        lay.setSpacing(10)
        
        # Header layout
        tb = QHBoxLayout()
        self._title = QLabel("Historical Scenario Stress Library")
        self._title.setStyleSheet("font-size: 16px; font-weight: bold; color: #ffffff;")
        tb.addWidget(self._title)
        tb.addStretch()
        
        run_btn = QPushButton("▶ Run Stress Test")
        run_btn.setObjectName("PrimaryButton")
        run_btn.setFixedHeight(30)
        run_btn.setMinimumWidth(150)
        run_btn.clicked.connect(self._run_all)
        tb.addWidget(run_btn)
        lay.addLayout(tb)
        
        # Config options row
        cfg_row = QHBoxLayout()
        cfg_row.setSpacing(16)
        
        lbl_notional = QLabel("Notional (₹):")
        lbl_notional.setStyleSheet("font-weight: bold; color: #8e8e93;")
        cfg_row.addWidget(lbl_notional)
        
        self._notional = QDoubleSpinBox()
        self._notional.setRange(100_000, 10_000_000_000)
        self._notional.setValue(10_000_000)
        self._notional.setSingleStep(1_000_000)
        self._notional.setDecimals(0)
        self._notional.setGroupSeparatorShown(True)
        self._notional.setFixedHeight(28)
        self._notional.setMinimumWidth(150)
        cfg_row.addWidget(self._notional)
        
        lbl_beta = QLabel("Portfolio Beta vs Index:")
        lbl_beta.setStyleSheet("font-weight: bold; color: #8e8e93;")
        cfg_row.addWidget(lbl_beta)
        
        self._beta_spin = QDoubleSpinBox()
        self._beta_spin.setRange(0.1, 3.0)
        self._beta_spin.setSingleStep(0.05)
        self._beta_spin.setValue(1.0)
        self._beta_spin.setDecimals(2)
        self._beta_spin.setFixedHeight(28)
        self._beta_spin.setMinimumWidth(100)
        cfg_row.addWidget(self._beta_spin)
        cfg_row.addStretch()
        lay.addLayout(cfg_row)
        
        # Custom scenario parameters row
        cust_row = QHBoxLayout()
        cust_row.setSpacing(16)
        
        lbl_cust_pct = QLabel("Custom Market Drop %:")
        lbl_cust_pct.setStyleSheet("font-weight: bold; color: #8e8e93;")
        cust_row.addWidget(lbl_cust_pct)
        
        self._cust_pct = QDoubleSpinBox()
        self._cust_pct.setRange(-99.0, -1.0)
        self._cust_pct.setValue(-15.0)
        self._cust_pct.setDecimals(1)
        self._cust_pct.setFixedHeight(28)
        self._cust_pct.setMinimumWidth(100)
        cust_row.addWidget(self._cust_pct)
        
        lbl_cust_days = QLabel("Shock Duration (Days):")
        lbl_cust_days.setStyleSheet("font-weight: bold; color: #8e8e93;")
        cust_row.addWidget(lbl_cust_days)
        
        self._cust_days = QSpinBox()
        self._cust_days.setRange(1, 500)
        self._cust_days.setValue(45)
        self._cust_days.setFixedHeight(28)
        self._cust_days.setMinimumWidth(100)
        cust_row.addWidget(self._cust_days)
        cust_row.addStretch()
        lay.addLayout(cust_row)
        
        # Scenario Results Table
        self._tbl = QTableWidget(0, 6)
        self._tbl.setHorizontalHeaderLabels([
            "Scenario", "Market Shock", "Duration (Days)", "Est. Portfolio Loss %", "Notional Impact", "Recovery Estimate"
        ])
        self._tbl.setEditTriggers(QTableWidget.NoEditTriggers)
        self._tbl.horizontalHeader().setStretchLastSection(True)
        self._tbl.verticalHeader().setVisible(False)
        self._tbl.setAlternatingRowColors(True)
        self._tbl.setFixedHeight(220)
        lay.addWidget(self._tbl)
        
        # Per-Stock Breakdown
        lbl_breakdown = QLabel("Per-Stock Risk Contribution (Worst Scenario Case):")
        lbl_breakdown.setStyleSheet("font-size: 13px; font-weight: bold; color: #ffffff;")
        lay.addWidget(lbl_breakdown)
        
        self._stock_tbl = QTableWidget(0, 4)
        self._stock_tbl.setHorizontalHeaderLabels(["Ticker", "Portfolio Weight", "Weighted Loss %", "Loss Value (Notional)"])
        self._stock_tbl.setEditTriggers(QTableWidget.NoEditTriggers)
        self._stock_tbl.horizontalHeader().setStretchLastSection(True)
        self._stock_tbl.verticalHeader().setVisible(False)
        self._stock_tbl.setAlternatingRowColors(True)
        self._stock_tbl.setFixedHeight(180)
        lay.addWidget(self._stock_tbl)
        
        # Status & Summary
        self._summary_label = QLabel("Run stress test scenarios to analyze portfolio risk exposures.")
        self._summary_label.setStyleSheet("color: #8e8e93; font-style: italic; font-size: 11px;")
        self._summary_label.setWordWrap(True)
        lay.addWidget(self._summary_label)
        lay.addStretch()
        
        self._payload = {}

    # ── AUDIT-FIX (Round 6, D-P2-12): background macro-fit machinery ──────
    def _fit_key_for(self, price_df, notional):
        try:
            _idx = price_df.index
            return (str(_idx[0]), str(_idx[-1]), int(notional), tuple(price_df.columns[:20]))
        except Exception:
            return None

    def _try_take_cached_tester(self, price_df, notional):
        key = self._fit_key_for(price_df, notional) if price_df is not None else None
        if key is not None and self._fit_key == key and self._fitted_tester is not None:
            return self._fitted_tester
        return None

    def _start_background_fit(self, price_df, notional):
        key = self._fit_key_for(price_df, notional) or ("anon",)
        self._fit_in_flight = True
        pdf = price_df.copy()

        def _do_fit():
            import numpy as np
            import pandas as pd
            asset_returns = np.log(pdf / pdf.shift(1)).dropna()
            idx = asset_returns.index
            if hasattr(idx, "tz") and idx.tz is not None:
                idx = idx.tz_localize(None)
                asset_returns.index = idx
            try:
                start_str = idx[0].strftime("%Y-%m-%d")
                end_str = (idx[-1] + pd.Timedelta(days=4)).strftime("%Y-%m-%d")
                from data.price_feed import safe_download
                raw_macro_full = safe_download(["^VIX", "CL=F", "DX-Y.NYB", "^TNX"], period="5y")
                if isinstance(raw_macro_full.columns, pd.MultiIndex):
                    raw_macro = raw_macro_full["Close"]
                else:
                    raw_macro = raw_macro_full
                raw_macro = raw_macro.loc[start_str:end_str]
                if hasattr(raw_macro.index, "tz") and raw_macro.index.tz is not None:
                    raw_macro.index = raw_macro.index.tz_localize(None)
                raw_macro = raw_macro.ffill().bfill()
                macro_returns = np.log(raw_macro / raw_macro.shift(1)).dropna()
                if hasattr(macro_returns.index, "tz") and macro_returns.index.tz is not None:
                    macro_returns.index = macro_returns.index.tz_localize(None)
                factor_returns = pd.DataFrame(index=idx)
                factor_returns["VIX"] = macro_returns["^VIX"].reindex(idx).ffill().bfill()
                factor_returns["OIL"] = macro_returns["CL=F"].reindex(idx).ffill().bfill()
                factor_returns["DXY"] = macro_returns["DX-Y.NYB"].reindex(idx).ffill().bfill()
                factor_returns["BOND"] = macro_returns["^TNX"].reindex(idx).ffill().bfill()
                factor_returns = factor_returns.fillna(0.0)
            except Exception:
                market_ret = asset_returns.mean(axis=1)
                rng = np.random.default_rng(42)
                factor_returns = pd.DataFrame({
                    "VIX": -6.0 * market_ret + rng.normal(0, 0.05, len(idx)),
                    "OIL": 0.2 * market_ret + rng.normal(0, 0.02, len(idx)),
                    "DXY": -0.3 * market_ret + rng.normal(0, 0.008, len(idx)),
                    "BOND": -0.1 * market_ret + rng.normal(0, 0.012, len(idx)),
                }, index=idx)
            from math_engine.stress_tester import MacroFactorStressTester
            tester = MacroFactorStressTester(portfolio_value_inr=float(notional))
            tester.fit(asset_returns, factor_returns)
            return tester

        from workers.worker_threads import _GenericNetworkWorker
        worker = _GenericNetworkWorker(_do_fit)
        self._fit_worker = worker

        def _done(res):
            self._fit_in_flight = False
            self._fit_ready.emit(res, key)

        def _failed(_err):
            self._fit_in_flight = False
            self._fit_ready.emit(None, key)

        worker.result.connect(_done)
        worker.error.connect(_failed)
        worker.start()

    def _on_fit_ready(self, tester, key):
        if tester is not None:
            self._fitted_tester = tester
            self._fit_key = key
            self._summary_label.setText("OLS macro factor fit complete — advanced scenario engine active.")
            self._run_all()
        else:
            self._summary_label.setText("OLS macro factor fit unavailable — using beta heuristic scenarios.")

    def update_portfolio_data(self, payload):
        """Standard updater called by MainWindow on optimizer result."""
        self._payload = payload
        
        # Auto-extract beta if present
        ph = payload.get("portfolio_health") or {}
        if ph.get("WeightedBeta") is not None:
            try:
                self._beta_spin.setValue(float(ph["WeightedBeta"]))
            except Exception:
                pass
        self._run_all()

    def _get_weights(self):
        p = self._payload
        pdf = p.get("portfolio_df")
        if pdf is not None and not pdf.empty:
            cc = {c.lower(): c for c in pdf.columns}
            tc = next((cc[k] for k in cc if 'ticker' in k or 'symbol' in k or 'stock' in k), pdf.columns[0])
            wc = next((cc[k] for k in cc if 'weight' in k), None)
            if wc:
                pairs = []
                for _, row in pdf.iterrows():
                    try:
                        # AUDIT-FIX (Round 5, 2-c-6): skip the CASH sleeve — cash
                        # has no market beta, so shocking it overstated portfolio
                        # losses by w_cash × market_drop × beta and rendered a
                        # bogus "CASH … −7.6%" loss row, exactly when the risk
                        # overlay had parked the portfolio in cash.
                        if str(row[tc]).strip().upper() == "CASH":
                            continue
                        w = float(row[wc])
                        if w > 0:
                            pairs.append((str(row[tc]), w))
                    except Exception:
                        pass
                if pairs:
                    total = sum(w for _, w in pairs)
                    if total > 1.5:  # expressed as percentage (e.g. 10% instead of 0.1)
                        pairs = [(t, w / 100.0) for t, w in pairs]
                    return pairs
        sel = p.get("selected", [])
        # AUDIT-FIX (Round 5, 2-c-6): filter CASH from the equal-weight fallback too.
        sel = [t for t in sel if str(t).strip().upper() != "CASH"]
        return [(t, 1.0 / len(sel)) for t in sel] if sel else []

    def _simulate_advanced(self, tester, weights_dict, scenario_shocks, expected_annual_return=0.15):
        sim = tester.simulate_scenario(weights_dict, scenario_shocks)
        port_drop = sim["portfolio_return"]
        daily_pos = expected_annual_return / 252
        recovery_days = int(abs(port_drop) / daily_pos) if daily_pos > 0 else 9999
        return port_drop, recovery_days, sim["asset_impacts"]

    def _simulate_heuristic(self, market_drop, days, beta, weights, expected_annual_return=0.15):
        # port_drop = beta-adjusted portfolio return under the macro shock.
        # asset_impacts stores the raw per-stock return shock (= market_drop * beta).
        # _fill_stock_table then computes the weighted contribution (w * asset_ret).
        # Bug fix: use market_drop * beta as the common asset-level shock so that
        # _fill_stock_table correctly weights each ticker's contribution independently.
        asset_shock = market_drop * beta
        port_drop = sum(w * asset_shock for _, w in weights) if weights else asset_shock
        daily_pos = expected_annual_return / 252
        recovery_days = int(abs(port_drop) / daily_pos) if daily_pos > 0 else 9999
        asset_impacts = {t: asset_shock for t, w in weights}
        return port_drop, recovery_days, asset_impacts

    def _run_all(self):
        weights = self._get_weights()
        if not weights:
            self._title.setText("Scenario Library — No active portfolio loaded")
            self._summary_label.setText("Run the Optimizer first to load portfolio weights into Scenario Library.")
            return
            
        beta = self._beta_spin.value()
        notional = self._notional.value()
        weights_dict = {t: w for t, w in weights}
        expected_annual_return = self._payload.get("cfg", {}).get("EXPECTED_ANNUAL_RETURN", 0.15)
        
        # ── 1. Attempt Advanced OLS Factor Fit ───────────────────────────────
        # AUDIT-FIX (Round 5, 2-c-5): the optimizer payload stores the price
        # frame under "selected_price_df" (see main_window's on_result usage);
        # "price_df" was always None, so the OLS factor engine never fit and
        # every scenario silently fell back to the beta heuristic — while the
        # label still advertised "OLS Factor + Barra Stress" when Barra
        # diagnostics were present.
        # AUDIT-FIX (Round 6, D-P0): the R5 "or" idiom evaluated bool(DataFrame)
        # (pandas raises "truth value of a DataFrame is ambiguous") because
        # "selected_price_df" is ALWAYS a DataFrame (possibly empty) — never
        # None — so this line crashed _run_all on every result and aborted
        # MainWindow.on_result mid-refresh. Explicit None/empty checks only.
        price_df = self._payload.get("selected_price_df")
        if price_df is None or (hasattr(price_df, "empty") and price_df.empty):
            price_df = self._payload.get("price_df")
        # AUDIT-FIX (Round 6, D-P2-12): the macro download (4 tickers × 5y via
        # yfinance, no timeout) + OLS fit ran SYNCHRONOUSLY on the GUI thread
        # inside on_result — the event loop froze for the whole download on
        # every optimizer run. The fitted tester is now cached per payload
        # date-range and computed on a background worker; while a fit is in
        # flight the scenarios use the beta heuristic (as they always did on
        # any download failure), and the table refreshes from the queued
        # _on_fit_ready signal when the fit lands.
        tester = self._try_take_cached_tester(price_df, notional)
        if tester is None and price_df is not None and not price_df.empty and not self._fit_in_flight:
            self._start_background_fit(price_df, notional)

        # Scenario Mapping
        scenarios_shocks = {
            "2008 GFC": {"VIX": 50.0, "OIL": -30.0, "DXY": 10.0, "BOND": -5.0},
            "COVID Crash 2020": {"VIX": 65.0, "OIL": -45.0, "DXY": 5.0, "BOND": -8.0},
            "Taper Tantrum 2013": {"VIX": 15.0, "OIL": -10.0, "DXY": 8.0, "BOND": 15.0},
            "Dot-Com 2000": {"VIX": 35.0, "OIL": -15.0, "DXY": 5.0, "BOND": -2.0},
            "India VIX Spike 2015": {"VIX": 45.0, "OIL": -20.0, "DXY": 4.0, "BOND": -3.0},
            "Russia-Ukraine 2022": {"VIX": 25.0, "OIL": 40.0, "DXY": 8.0, "BOND": 12.0},
            "US Market Crash Spillover": {"VIX": 35.0, "OIL": -15.0, "DXY": 6.0, "BOND": -4.0},
            "Govt Policy/Rate Shock": {"VIX": 20.0, "OIL": -5.0, "DXY": 4.0, "BOND": 25.0},
            "Custom Shock": {
                "VIX": abs(self._cust_pct.value()) * 2.0,
                "OIL": self._cust_pct.value() * 0.5,
                "DXY": abs(self._cust_pct.value()) * 0.1,
                "BOND": self._cust_pct.value() * 0.2
            }
        }
            
        self._tbl.setRowCount(0)
        worst_pnl = 0.0
        worst_name = ""
        worst_asset_impacts = {}
        worst_rec_days = 0
        
        # Scenario specifications
        scenarios = [
            ("COVID Crash 2020",      -0.380, 33,  "S&P/Nifty -38% (Feb-Mar 2020)"),
            ("Taper Tantrum 2013",    -0.100, 65,  "Nifty -10% (May-Aug 2013)"),
            ("2008 GFC",              -0.500, 365, "Global markets -50%"),
            ("Dot-Com 2000",          -0.450, 400, "Tech-heavy -45%"),
            ("India VIX Spike 2015",  -0.200, 30,  "Nifty -20% (Aug 2015)"),
            ("Russia-Ukraine 2022",   -0.150, 60,  "Commodity shock -15%"),
            ("US Market Crash Spillover", -0.080, 10,  "US crash spillover to Nifty (-8%)"),
            ("Govt Policy/Rate Shock", -0.050, 15,  "Surprise rate hike or tax shock (-5%)"),
            ("Custom Shock",          self._cust_pct.value() / 100.0, self._cust_days.value(), "User scenario"),
        ]

        # Combine with active Barra style factor scenarios if present in the diagnostics payload
        diag = self._payload.get("factor_risk_diagnostics") or {}
        factor_stress = diag.get("factor_stress_tests") or {}
        factor_asset_stress = diag.get("factor_stress_asset_tests") or {}
        
        scenarios_to_run = []
        for name, mkt_drop, days, desc in scenarios:
            scenarios_to_run.append((name, mkt_drop, days, desc, "macro", None, None))
            
        if factor_stress:
            barra_scenarios_info = {
                "Momentum Crash (Value Rotation)": (15, "Momentum -3.0, Value +2.0, Growth -1.0"),
                "Growth Compression (Tech Selloff)": (20, "Growth -3.0, Quality -1.0, Volatility +2.0"),
                "Liquidity Squeeze / Credit Crunch": (30, "Liquidity -4.0, Volatility +3.0, Leverage -2.0"),
                "Quality Flight to Safety": (15, "Quality +3.0, Size -1.5, Volatility -2.0")
            }
            for sc_name, pnl_pct in factor_stress.items():
                days, desc = barra_scenarios_info.get(sc_name, (20, "Style Factor Shock"))
                asset_imps = factor_asset_stress.get(sc_name, {})
                scenarios_to_run.append((sc_name, None, days, desc, "barra", pnl_pct, asset_imps))
        
        for name, mkt_drop, days, desc, sc_type, sc_pnl_pct, sc_asset_imps in scenarios_to_run:
            if sc_type == "barra":
                port_pnl_pct = sc_pnl_pct
                asset_impacts = sc_asset_imps
                shock_lbl = desc
                daily_pos = expected_annual_return / 252
                rec_days = int(abs(port_pnl_pct) / daily_pos) if (port_pnl_pct < 0 and daily_pos > 0) else 0
            else:
                if tester is not None and name in scenarios_shocks:
                    port_pnl_pct, rec_days, asset_impacts = self._simulate_advanced(tester, weights_dict, scenarios_shocks[name], expected_annual_return)
                else:
                    port_pnl_pct, rec_days, asset_impacts = self._simulate_heuristic(mkt_drop, days, beta, weights, expected_annual_return)
                
                if tester is not None and name in scenarios_shocks:
                    sh = scenarios_shocks[name]
                    shock_lbl = f"VIX {sh['VIX']:+.0f}%, Oil {sh['OIL']:+.0f}%"
                else:
                    shock_lbl = f"Market {mkt_drop*100:+.1f}%"
                
            pnl_rs = notional * port_pnl_pct
            rec_str = f"{rec_days} days (~{rec_days/21:.0f} mo)" if rec_days < 3000 else "3+ years"
            
            r = self._tbl.rowCount()
            self._tbl.insertRow(r)
            self._tbl.setItem(r, 0, QTableWidgetItem(name))
            self._tbl.setItem(r, 1, QTableWidgetItem(shock_lbl))
            self._tbl.setItem(r, 2, QTableWidgetItem(str(days)))
            
            pct_item = QTableWidgetItem(f"{port_pnl_pct*100:+.2f}%")
            pct_item.setTextAlignment(Qt.AlignCenter)
            pct_item.setForeground(QColor(_QSS.RED if port_pnl_pct < 0 else _QSS.GREEN))
            self._tbl.setItem(r, 3, pct_item)
            
            pnl_item = QTableWidgetItem(f"₹{pnl_rs:,.0f}")
            pnl_item.setTextAlignment(Qt.AlignCenter)
            pnl_item.setForeground(QColor(_QSS.RED if pnl_rs < 0 else _QSS.GREEN))
            self._tbl.setItem(r, 4, pnl_item)
            
            self._tbl.setItem(r, 5, QTableWidgetItem(rec_str))
            
            if port_pnl_pct < worst_pnl:
                worst_pnl = port_pnl_pct
                worst_name = name
                worst_asset_impacts = asset_impacts
                worst_rec_days = rec_days
                
        # Fill worst case stock breakdown
        self._fill_stock_table(weights, worst_asset_impacts, notional)
        
        worst_rs = notional * worst_pnl
        engine_lbl = "OLS Factor + Barra Stress" if factor_stress else ("OLS Macro Factor Prop" if tester is not None else "Beta Heuristic")
        
        self._summary_label.setText(
            f"Risk Engine: {engine_lbl} | Worst Case: {worst_name} → Est. Portfolio P&L: {worst_pnl*100:.2f}% (₹{abs(worst_rs):,.0f}) | "
            f"Recovery Est: {worst_rec_days} days"
        )
        self._title.setText(f"Scenario Library — {len(scenarios_to_run)} Stress Tests | Worst: {worst_name} ({worst_pnl*100:.2f}%)")
 
    def _fill_stock_table(self, weights, asset_impacts, notional):
        self._stock_tbl.setRowCount(0)
        for ticker, w in sorted(weights, key=lambda x: -x[1]):
            asset_ret = asset_impacts.get(ticker, 0.0)
            weighted_loss = w * asset_ret
            pnl_rs = notional * weighted_loss
            r = self._stock_tbl.rowCount()
            self._stock_tbl.insertRow(r)
            self._stock_tbl.setItem(r, 0, QTableWidgetItem(ticker))
            self._stock_tbl.setItem(r, 1, QTableWidgetItem(f"{w*100:.2f}%"))
            
            c_item = QTableWidgetItem(f"{weighted_loss*100:+.3f}%")
            c_item.setTextAlignment(Qt.AlignCenter)
            c_item.setForeground(QColor(_QSS.RED if weighted_loss < 0 else _QSS.GREEN))
            self._stock_tbl.setItem(r, 2, c_item)
            
            pnl_item = QTableWidgetItem(f"₹{pnl_rs:,.0f}")
            pnl_item.setTextAlignment(Qt.AlignCenter)
            pnl_item.setForeground(QColor(_QSS.RED if pnl_rs < 0 else _QSS.GREEN))
            self._stock_tbl.setItem(r, 3, pnl_item)
