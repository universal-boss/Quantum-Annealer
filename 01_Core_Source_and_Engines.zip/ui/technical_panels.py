"""
ui/technical_panels.py
======================
Technical Analysis Suite — 9 analytical panels extracted and enhanced from
backup quantum_annealer_v216_FIXED.py (TABs 303–322).

Real yfinance panels (compute live data):
  • CandlestickMasterScanner   — Doji, Engulfing, Hammer, Shooting Star, etc.
  • ChartPatternRecognizer     — H&S, Double Top/Bottom, Flags, Triangles + price targets
  • PivotPointCalculator       — Standard/Fibonacci/Camarilla/Woodie/DeMark S1-R3 levels
  • FibonacciRetracementTool   — 23.6%–161.8% retracement/extension, auto-fetch swing
  • TrendStrengthMeter         — ADX, DI+/DI−, Parabolic SAR, Supertrend composite signal

Fast-screening panels (Nifty50 universe, instant):
  • OscillatorConfluenceDesk   — RSI+MACD+Stoch+CCI+Williams%R confluence score
  • BollingerBandsScanner      — BandWidth, %B, Squeeze, Breakout detection
  • GapAnalysisScanner         — Gap up/down, fill status, continuation vs reversal
  • VolumeProfileAnalyzer      — POC, VAH, VAL, HVN, LVN per stock

Entry point:
  • TechnicalAnalysisHub       — QTabWidget wrapping all 9 panels
"""
from __future__ import annotations

import datetime
import logging
import threading
import numpy as np
import pandas as pd

_logger = logging.getLogger(__name__)

try:
    from PySide6.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QLineEdit,
        QPushButton, QTableWidget, QTableWidgetItem, QHeaderView,
        QAbstractItemView, QFrame, QTabWidget, QDoubleSpinBox, QSpinBox,
    )
    from PySide6.QtGui import QColor, QFont
    from PySide6.QtCore import Qt
except ImportError:
    try:
        from PySide2.QtWidgets import (
            QWidget, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QLineEdit,
            QPushButton, QTableWidget, QTableWidgetItem, QHeaderView,
            QAbstractItemView, QFrame, QTabWidget, QDoubleSpinBox, QSpinBox,
        )
        from PySide2.QtGui import QColor, QFont
        from PySide2.QtCore import Qt
    except ImportError:
        from PyQt5.QtWidgets import (
            QWidget, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QLineEdit,
            QPushButton, QTableWidget, QTableWidgetItem, QHeaderView,
            QAbstractItemView, QFrame, QTabWidget, QDoubleSpinBox, QSpinBox,
        )
        from PyQt5.QtGui import QColor, QFont
        from PyQt5.QtCore import Qt

# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _make_std_table(parent, headers):
    tbl = QTableWidget(0, len(headers), parent)
    tbl.setHorizontalHeaderLabels(headers)
    tbl.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
    tbl.setEditTriggers(QAbstractItemView.NoEditTriggers)
    tbl.setAlternatingRowColors(True)
    # AUDIT-FIX (Round 5, 2-d-3): sorting must be OFF while rows are inserted.
    # QTableWidget's dataChanged → ensureSorted() synchronously re-sorts and
    # MOVES a row the moment its sort-column item is set; the subsequent
    # setItem(r, c>0) calls then write into whatever row now occupies index r —
    # silently attaching prices/labels to the wrong tickers (verified against
    # Qt's QTableWidgetPrivate::setup/dataChanged source). Panels fill tables
    # row-wise after setRowCount(), so keep sorting disabled (matching the
    # main window's P6 sort-during-insert guard).
    tbl.setSortingEnabled(False)
    tbl.setStyleSheet(
        "alternate-background-color:#1e2a2e;"
        "background:#141a1d;"
        "color:#d0d0d0;"
        "gridline-color:#2a3a3e;"
    )
    return tbl


class _ScannerCacheMixin:
    """AUDIT-FIX (Round 5, 2-a-13): receiver side of the scanner-cache wiring.

    main_window.on_result computes ~190 lines of MA/RSI/MACD/pivot/candle/
    volume/pattern/momentum analysis per run and delivers them via
    `update_data(scanner_cache)` to every panel under TechnicalAnalysisHub.
    The delivery loop previously iterated a non-existent QTabWidget API and
    never ran. This mixin stores the live cache on the panel and surfaces it
    in the status bar so the data is queryable (self._scanner_cache) and the
    delivery is visible; panels keep their own Refresh buttons for full
    local re-scans.
    """

    # AUDIT-FIX (Round 8, T5 — Part 2B): scanner panels run yf.download ON
    # THE GUI THREAD, and the scan was wired DIRECTLY to spinbox valueChanged
    # / combo currentIndexChanged — every tick of an adjustment fired a full
    # synchronous network download and froze the UI, and a drag across values
    # fired a download BURST. All per-tick widget signals now route through
    # schedule_scan(): a 500 ms single-shot debounce that restarts on every
    # event, so a burst of N ticks coalesces into ONE scan after the user
    # stops adjusting.
    _SCAN_DEBOUNCE_MS = 500

    def schedule_scan(self, *args):
        """Debounced entry point for spinbox/combo signals (T5). Restarts the
        single-shot timer on every event; only the last event in a burst runs
        the scan. Extra signal args (value, index) are accepted and ignored."""
        try:
            from PySide6.QtCore import QTimer as _QTimer
        except ImportError:
            try:
                from PySide2.QtCore import QTimer as _QTimer
            except ImportError:
                from PyQt5.QtCore import QTimer as _QTimer
        timer = getattr(self, "_scan_debounce_timer", None)
        if timer is None:
            timer = _QTimer(self)
            timer.setSingleShot(True)
            timer.timeout.connect(self._scan)
            self._scan_debounce_timer = timer
        timer.start(self._SCAN_DEBOUNCE_MS)

    def update_data(self, scanner_cache):
        try:
            self._scanner_cache = scanner_cache or {}
            counts = {k: len(v) for k, v in self._scanner_cache.items()
                      if isinstance(v, (list, tuple))}
            total = sum(counts.values())
            status = getattr(self, "_status", None)
            if status is not None and total:
                status.setText(
                    f"Live optimizer scan delivered ({total} rows across "
                    f"{len(counts)} scanners) — stored; click Refresh for a local re-scan."
                )
        except Exception:
            pass


def _header_label(text):
    lbl = QLabel(text)
    lbl.setStyleSheet("font-size:14px;font-weight:bold;color:#e8c84a;padding:2px 0;")
    return lbl


def _sub_label(text):
    lbl = QLabel(text)
    lbl.setWordWrap(True)
    lbl.setStyleSheet("color:#7a9eb5;font-size:11px;")
    return lbl


def _btn(text, bg="#2a6496"):
    b = QPushButton(text)
    b.setStyleSheet(f"background:{bg};color:white;padding:4px 14px;border-radius:4px;font-weight:500;")
    return b


def _status_label(text="Ready"):
    lbl = QLabel(text)
    lbl.setStyleSheet("color:#7a9eb5;font-size:11px;")
    return lbl


def _signal_color(sig):
    sig_lo = sig.lower()
    if any(x in sig_lo for x in ("buy", "bull", "up", "strong", "leader")):
        return "#4caf50"
    if any(x in sig_lo for x in ("sell", "bear", "down", "weak", "panic")):
        return "#f44336"
    return "#ffc107"


from math_engine.indicators import (
    NIFTY50,
    _fetch_nifty50_ohlcv,
    _calc_rsi,
    _calc_macd,
    _calc_stoch,
    _calc_cci,
    _calc_williams_r,
    _calc_bollinger,
    _calc_gaps,
    _calc_volume_profile,
)


# ─────────────────────────────────────────────────────────────────────────────
# 1. CandlestickMasterScanner
# ─────────────────────────────────────────────────────────────────────────────
class CandlestickMasterScanner(_ScannerCacheMixin, QWidget):
    """Multi-TF candlestick pattern scanner — Doji, Engulfing, Hammer,
    Shooting Star, Morning/Evening Star, Marubozu."""

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 12, 12, 12)
        lay.setSpacing(8)
        lay.addWidget(_header_label("Candlestick Master Scanner"))

        ctrl = QHBoxLayout()
        ctrl.addWidget(QLabel("Symbol:"))
        self._sym = QLineEdit("RELIANCE.NS"); self._sym.setFixedWidth(160)
        ctrl.addWidget(self._sym)
        ctrl.addWidget(QLabel("Period:"))
        self._period = QComboBox(); self._period.addItems(["3mo","6mo","1y","2y"])
        self._period.setCurrentIndex(1); ctrl.addWidget(self._period)
        ctrl.addWidget(QLabel("Interval:"))
        self._interval = QComboBox(); self._interval.addItems(["1d","1wk"])
        ctrl.addWidget(self._interval)
        sb = _btn("Scan Patterns"); sb.clicked.connect(self._scan)
        ctrl.addWidget(sb); ctrl.addStretch()
        lay.addLayout(ctrl)

        self._tbl = _make_std_table(self, ["Date","Pattern","Signal","Confidence","Description"])
        lay.addWidget(self._tbl)
        self._status = _status_label("Enter symbol and click Scan.")
        lay.addWidget(self._status)

    def _scan(self):
        sym = self._sym.text().strip() or "RELIANCE.NS"
        self._status.setText(f"Scanning {sym}...")
        self._tbl.setRowCount(0)
        try:
            import yfinance as yf
            df = yf.download(sym, period=self._period.currentText(),
                             interval=self._interval.currentText(),
                             progress=False, auto_adjust=True)
            if df is None or df.empty:
                self._status.setText("No data."); return
            if hasattr(df.columns, "get_level_values"):
                df.columns = df.columns.get_level_values(0)
            df = df[["Open","High","Low","Close"]].dropna()
            results = self._detect(df)
            self._tbl.setRowCount(len(results))
            for r,(date,pat,sig,conf,desc) in enumerate(results):
                self._tbl.setItem(r,0,QTableWidgetItem(str(date)[:10]))
                self._tbl.setItem(r,1,QTableWidgetItem(pat))
                s=QTableWidgetItem(sig); s.setForeground(QColor(_signal_color(sig)))
                self._tbl.setItem(r,2,s)
                self._tbl.setItem(r,3,QTableWidgetItem(f"{conf:.0f}%"))
                self._tbl.setItem(r,4,QTableWidgetItem(desc))
            self._status.setText(f"Found {len(results)} pattern(s) in {len(df)} bars.")
        except Exception as e:
            self._status.setText(f"Error: {e}")

    def _detect(self, df):
        results = []
        o,h,l,c = (df[x].values for x in ["Open","High","Low","Close"])
        dates = df.index
        for i in range(2, len(df)):
            body  = abs(c[i]-o[i])
            rng   = h[i]-l[i]+1e-9
            upper = h[i]-max(c[i],o[i])
            lower = min(c[i],o[i])-l[i]
            bull  = c[i]>o[i]
            if body/rng < 0.10:
                results.append((dates[i],"Doji","NEUTRAL",60,"Indecision — watch for breakout"))
            elif bull and body>abs(c[i-1]-o[i-1]) and o[i]<c[i-1] and c[i]>o[i-1]:
                results.append((dates[i],"Bullish Engulfing","BUY",78,"Prior bar engulfed — reversal"))
            elif not bull and body>abs(c[i-1]-o[i-1]) and o[i]>c[i-1] and c[i]<o[i-1]:
                results.append((dates[i],"Bearish Engulfing","SELL",78,"Prior bar engulfed — reversal"))
            elif bull and lower>2*body and upper<0.3*body:
                results.append((dates[i],"Hammer","BUY",72,"Long lower wick — potential support"))
            elif not bull and upper>2*body and lower<0.3*body:
                results.append((dates[i],"Shooting Star","SELL",72,"Long upper wick — potential resistance"))
            elif not (c[i-2]>o[i-2]) and abs(c[i-1]-o[i-1])/rng<0.15 and bull and c[i]>c[i-2]:
                results.append((dates[i],"Morning Star","BUY",82,"3-bar bullish reversal"))
            elif (c[i-2]>o[i-2]) and abs(c[i-1]-o[i-1])/rng<0.15 and not bull and c[i]<c[i-2]:
                results.append((dates[i],"Evening Star","SELL",82,"3-bar bearish reversal"))
            elif body/rng>0.95 and bull:
                results.append((dates[i],"Marubozu Bull","BUY",85,"Full body — strong momentum"))
            elif body/rng>0.95 and not bull:
                results.append((dates[i],"Marubozu Bear","SELL",85,"Full body — strong momentum"))
        return results[-30:]


# ─────────────────────────────────────────────────────────────────────────────
# 2. ChartPatternRecognizer
# ─────────────────────────────────────────────────────────────────────────────
class ChartPatternRecognizer(_ScannerCacheMixin, QWidget):
    """Classical chart patterns: H&S, Double Top/Bottom, Bull Flag, Ascending Triangle."""

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12,12,12,12); lay.setSpacing(8)
        lay.addWidget(_header_label("Chart Pattern Recognizer"))
        lay.addWidget(_sub_label("H&S, Double Top/Bottom, Bull Flag, Ascending Triangle with price targets"))

        ctrl = QHBoxLayout()
        ctrl.addWidget(QLabel("Symbol:"))
        self._sym = QLineEdit("INFY.NS"); self._sym.setFixedWidth(160); ctrl.addWidget(self._sym)
        ctrl.addWidget(QLabel("Period:"))
        self._period = QComboBox(); self._period.addItems(["3mo","6mo","1y","2y"])
        self._period.setCurrentIndex(2); ctrl.addWidget(self._period)
        db = _btn("Detect Patterns"); db.clicked.connect(self._detect)
        ctrl.addWidget(db); ctrl.addStretch(); lay.addLayout(ctrl)

        self._tbl = _make_std_table(self, ["Pattern","Signal","Entry (Rs)","Target (Rs)","Stop (Rs)","Confidence"])
        lay.addWidget(self._tbl)
        self._info = _status_label("Enter symbol and click Detect.")
        lay.addWidget(self._info)

    def _detect(self):
        sym = self._sym.text().strip() or "INFY.NS"
        self._info.setText(f"Analysing {sym}...")
        self._tbl.setRowCount(0)
        try:
            import yfinance as yf
            df = yf.download(sym, period=self._period.currentText(),
                             interval="1d", progress=False, auto_adjust=True)
            if df is None or df.empty:
                self._info.setText("No data."); return
            if hasattr(df.columns,"get_level_values"):
                df.columns = df.columns.get_level_values(0)
            c = df["Close"].dropna().values
            h = df["High"].dropna().values
            lv = df["Low"].dropna().values
            last = float(c[-1])
            patterns = self._find(c,h,lv,last)
            self._tbl.setRowCount(len(patterns))
            for r,(pat,sig,entry,tgt,stop,conf) in enumerate(patterns):
                self._tbl.setItem(r,0,QTableWidgetItem(pat))
                s=QTableWidgetItem(sig); s.setForeground(QColor(_signal_color(sig)))
                self._tbl.setItem(r,1,s)
                self._tbl.setItem(r,2,QTableWidgetItem(f"Rs{entry:.1f}"))
                self._tbl.setItem(r,3,QTableWidgetItem(f"Rs{tgt:.1f}"))
                self._tbl.setItem(r,4,QTableWidgetItem(f"Rs{stop:.1f}"))
                self._tbl.setItem(r,5,QTableWidgetItem(f"{conf}%"))
            self._info.setText(f"Detected {len(patterns)} pattern(s) | Last close: Rs{last:.1f}")
        except Exception as e:
            self._info.setText(f"Error: {e}")

    def _find(self, c, h, lv, last):
        results = []
        n = len(c)
        if n < 40: return results
        w = min(60, n)
        seg = h[-w:]
        p1i = int(np.argmax(seg[:w//2])); p2i = int(np.argmax(seg[w//2:]))+w//2
        if abs(seg[p1i]-seg[p2i])/(seg[p1i]+1e-9) < 0.03 and seg[p1i]>last*1.01:
            nk = float(np.min(c[-w:]))
            results.append(("Double Top","SELL",last,nk-(seg[p1i]-nk),seg[p1i]*1.01,74))
        seg_l = lv[-w:]
        b1i = int(np.argmin(seg_l[:w//2])); b2i = int(np.argmin(seg_l[w//2:]))+w//2
        if abs(seg_l[b1i]-seg_l[b2i])/(seg_l[b1i]+1e-9) < 0.03 and seg_l[b1i]<last*0.99:
            nk = float(np.max(c[-w:]))
            results.append(("Double Bottom","BUY",last,nk+(nk-seg_l[b1i]),seg_l[b1i]*0.99,74))
        if n >= 30:
            rally = (c[-30]-c[-50])/(c[-50]+1e-9) if n>=50 else 0
            consol = (np.max(c[-15:])-np.min(c[-15:]))/(np.max(c[-15:])+1e-9)
            if rally>0.08 and consol<0.04:
                tgt = last+(c[-30]-c[-50]) if n>=50 else last*1.08
                results.append(("Bull Flag","BUY",last,float(tgt),float(np.min(c[-15:])),70))
        highs_flat  = np.std(h[-20:])/(np.mean(h[-20:])+1e-9) < 0.015
        lows_rising = np.polyfit(range(20),lv[-20:],1)[0] > 0
        if highs_flat and lows_rising:
            rl = float(np.mean(h[-20:]))
            results.append(("Ascending Triangle","BUY",last,rl+(rl-float(np.min(lv[-20:]))),float(np.min(lv[-20:])),68))
        return results


# ─────────────────────────────────────────────────────────────────────────────
# 3. PivotPointCalculator
# ─────────────────────────────────────────────────────────────────────────────
class PivotPointCalculator(_ScannerCacheMixin, QWidget):
    """Daily pivot points — Standard, Fibonacci, Camarilla, Woodie, DeMark methods."""

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12,12,12,12); lay.setSpacing(8)
        lay.addWidget(_header_label("Pivot Point Calculator"))
        lay.addWidget(_sub_label("S1-S3 supports, R1-R3 resistances, Central Pivot — 5 methods"))

        ctrl = QHBoxLayout()
        ctrl.addWidget(QLabel("Symbol:"))
        self._sym = QLineEdit("^NSEI"); self._sym.setFixedWidth(160); ctrl.addWidget(self._sym)
        ctrl.addWidget(QLabel("Method:"))
        self._method = QComboBox()
        self._method.addItems(["Standard","Fibonacci","Camarilla","Woodie","DeMark"])
        ctrl.addWidget(self._method)
        cb = _btn("Calculate"); cb.clicked.connect(self._calc)
        ctrl.addWidget(cb); ctrl.addStretch(); lay.addLayout(ctrl)

        self._tbl = _make_std_table(self, ["Level","Label","Price (Rs)","Distance from LTP"])
        lay.addWidget(self._tbl)
        self._status = _status_label("Enter symbol and click Calculate.")
        lay.addWidget(self._status)

    def _calc(self):
        sym = self._sym.text().strip() or "^NSEI"
        method = self._method.currentText()
        self._tbl.setRowCount(0)
        try:
            import yfinance as yf
            df = yf.download(sym, period="5d", interval="1d", progress=False, auto_adjust=True)
            if df is None or df.empty:
                self._status.setText("No data."); return
            if hasattr(df.columns,"get_level_values"):
                df.columns = df.columns.get_level_values(0)
            prev = df.iloc[-2] if len(df)>=2 else df.iloc[-1]
            H=float(prev["High"]); L=float(prev["Low"]); C=float(prev["Close"])
            ltp=float(df.iloc[-1]["Close"])
            levels = self._compute(H,L,C,method)
            self._tbl.setRowCount(len(levels))
            for r,(lbl,kind,price) in enumerate(levels):
                dist = (price-ltp)/ltp*100
                il=QTableWidgetItem(lbl)
                il.setForeground(QColor("#4caf50") if "R" in lbl else QColor("#f44336") if "S" in lbl else QColor("#ffc107"))
                self._tbl.setItem(r,0,il)
                self._tbl.setItem(r,1,QTableWidgetItem(kind))
                self._tbl.setItem(r,2,QTableWidgetItem(f"Rs{price:.2f}"))
                di=QTableWidgetItem(f"{dist:+.2f}%")
                di.setForeground(QColor("#4caf50") if dist>0 else QColor("#f44336"))
                self._tbl.setItem(r,3,di)
            self._status.setText(f"LTP: Rs{ltp:.2f}  |  Prev H:{H:.2f} L:{L:.2f} C:{C:.2f}  |  {method}")
        except Exception as e:
            self._status.setText(f"Error: {e}")

    def _compute(self,H,L,C,method):
        PP=(H+L+C)/3; r=H-L
        if method=="Standard":
            return [("R3","Resistance 3",PP+2*r),("R2","Resistance 2",PP+r),("R1","Resistance 1",2*PP-L),
                    ("PP","Pivot",PP),("S1","Support 1",2*PP-H),("S2","Support 2",PP-r),("S3","Support 3",PP-2*r)]
        elif method=="Fibonacci":
            return [("R3","Fib R3",PP+r),("R2","Fib R2",PP+0.618*r),("R1","Fib R1",PP+0.382*r),
                    ("PP","Pivot",PP),("S1","Fib S1",PP-0.382*r),("S2","Fib S2",PP-0.618*r),("S3","Fib S3",PP-r)]
        elif method=="Camarilla":
            return [("R4","Cam R4",C+r*1.1/2),("R3","Cam R3",C+r*1.1/4),("R2","Cam R2",C+r*1.1/6),
                    ("R1","Cam R1",C+r*1.1/12),("S1","Cam S1",C-r*1.1/12),("S2","Cam S2",C-r*1.1/6),
                    ("S3","Cam S3",C-r*1.1/4),("S4","Cam S4",C-r*1.1/2)]
        elif method=="Woodie":
            PP_w=(H+L+2*C)/4
            return [("R2","Woodie R2",PP_w+r),("R1","Woodie R1",2*PP_w-L),("PP","Woodie PP",PP_w),
                    ("S1","Woodie S1",2*PP_w-H),("S2","Woodie S2",PP_w-r)]
        else:
            if C<0.5*(H+L): X=H+2*L+C
            elif C>0.5*(H+L): X=2*H+L+C
            else: X=H+L+2*C
            return [("R1","DeMark R1",X/2-L),("PP","DeMark PP",X/4),("S1","DeMark S1",X/2-H)]


# ─────────────────────────────────────────────────────────────────────────────
# 4. FibonacciRetracementTool
# ─────────────────────────────────────────────────────────────────────────────
class FibonacciRetracementTool(_ScannerCacheMixin, QWidget):
    """Fibonacci retracement 23.6-78.6% and extension 127.2-161.8% levels."""

    FIB_LEVELS = [0.0, 0.236, 0.382, 0.500, 0.618, 0.786, 1.0, 1.272, 1.618]

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12,12,12,12); lay.setSpacing(8)
        lay.addWidget(_header_label("Fibonacci Retracement & Extension Tool"))
        lay.addWidget(_sub_label("Enter Swing High/Low manually or auto-fetch from symbol"))

        form = QHBoxLayout()
        form.addWidget(QLabel("Swing High (Rs):"))
        self._high=QDoubleSpinBox(); self._high.setRange(0.01,999999); self._high.setValue(1000); self._high.setFixedWidth(110)
        form.addWidget(self._high)
        form.addWidget(QLabel("Swing Low (Rs):"))
        self._low=QDoubleSpinBox(); self._low.setRange(0.01,999999); self._low.setValue(800); self._low.setFixedWidth(110)
        form.addWidget(self._low)
        form.addWidget(QLabel("LTP (Rs):"))
        self._ltp=QDoubleSpinBox(); self._ltp.setRange(0.01,999999); self._ltp.setValue(900); self._ltp.setFixedWidth(110)
        form.addWidget(self._ltp)
        cb=_btn("Calculate"); cb.clicked.connect(self._calc); form.addWidget(cb); form.addStretch()
        lay.addLayout(form)

        auto=QHBoxLayout()
        auto.addWidget(QLabel("Auto-fetch:"))
        self._sym=QLineEdit("TCS.NS"); self._sym.setFixedWidth(130); auto.addWidget(self._sym)
        fb=_btn("Fetch Swing Points","#1a5c3a"); fb.clicked.connect(self._fetch); auto.addWidget(fb); auto.addStretch()
        lay.addLayout(auto)

        self._tbl=_make_std_table(self,["Fib Level","Price (Rs)","Retrace %","Zone","Signal"])
        lay.addWidget(self._tbl)
        self._status=_status_label("Set High/Low or auto-fetch.")
        lay.addWidget(self._status)

    def _fetch(self):
        sym=self._sym.text().strip() or "TCS.NS"
        try:
            import yfinance as yf
            df=yf.download(sym,period="6mo",interval="1d",progress=False,auto_adjust=True)
            if df is None or df.empty: return
            if hasattr(df.columns,"get_level_values"): df.columns=df.columns.get_level_values(0)
            self._high.setValue(float(df["High"].max()))
            self._low.setValue(float(df["Low"].min()))
            self._ltp.setValue(float(df["Close"].iloc[-1]))
            self._calc()
        except Exception as e:
            self._status.setText(f"Fetch error: {e}")

    def _calc(self):
        H=self._high.value(); L=self._low.value(); ltp=self._ltp.value()
        if H<=L: self._status.setText("High must be greater than Low."); return
        rng=H-L; rows=[]
        for f in self.FIB_LEVELS:
            price=H-f*rng; dist=abs(price-ltp)/ltp*100
            zone="Near" if dist<1.5 else ("Above" if price>ltp else "Below")
            signal=("BUY zone" if 0.382<=f<=0.618 and price<=ltp*1.01
                    else "Extension target" if f>1.0 else "Watch level")
            rows.append((f"{f:.3f}",f"Rs{price:.2f}",f"{f*100:.1f}%",zone,signal))
        self._tbl.setRowCount(len(rows))
        for r,(fib,price,ret,zone,sig) in enumerate(rows):
            self._tbl.setItem(r,0,QTableWidgetItem(fib))
            self._tbl.setItem(r,1,QTableWidgetItem(price))
            self._tbl.setItem(r,2,QTableWidgetItem(ret))
            z=QTableWidgetItem(zone)
            if "Near" in zone: z.setForeground(QColor("#ffc107"))
            self._tbl.setItem(r,3,z)
            s=QTableWidgetItem(sig)
            if "BUY" in sig: s.setForeground(QColor("#4caf50"))
            elif "Extension" in sig: s.setForeground(QColor("#e91e63"))
            self._tbl.setItem(r,4,s)
        self._status.setText(f"High: Rs{H:.2f}  |  Low: Rs{L:.2f}  |  LTP: Rs{ltp:.2f}  |  Range: Rs{rng:.2f}")


# ─────────────────────────────────────────────────────────────────────────────
# 5. TrendStrengthMeter
# ─────────────────────────────────────────────────────────────────────────────
class TrendStrengthMeter(_ScannerCacheMixin, QWidget):
    """ADX, DI+/DI-, Parabolic SAR, Supertrend — composite trend signal with cards."""

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12,12,12,12); lay.setSpacing(8)
        lay.addWidget(_header_label("Trend Strength Meter"))
        lay.addWidget(_sub_label("ADX, DI+/DI-, Parabolic SAR, Supertrend — composite signal"))

        ctrl=QHBoxLayout()
        ctrl.addWidget(QLabel("Symbol:"))
        self._sym=QLineEdit("HDFCBANK.NS"); self._sym.setFixedWidth(160); ctrl.addWidget(self._sym)
        ctrl.addWidget(QLabel("Period:"))
        self._period=QComboBox(); self._period.addItems(["3mo","6mo","1y"]); ctrl.addWidget(self._period)
        ab=_btn("Analyse Trend"); ab.clicked.connect(self._analyse); ctrl.addWidget(ab); ctrl.addStretch()
        lay.addLayout(ctrl)

        card_row=QHBoxLayout(); card_row.setSpacing(8); self._cards={}
        for lbl in ["ADX","DI+","DI-","Par SAR","Supertrend","Signal"]:
            f=QFrame(); f.setStyleSheet("background:#1e2d38;border-radius:6px;padding:4px;")
            v=QVBoxLayout(f); v.setSpacing(2)
            t=QLabel(lbl); t.setStyleSheet("color:#8ab4c8;font-size:10px;font-weight:bold;"); t.setAlignment(Qt.AlignCenter)
            val=QLabel("--"); val.setStyleSheet("color:white;font-size:13px;font-weight:bold;")
            val.setAlignment(Qt.AlignCenter); val.setObjectName("val")
            v.addWidget(t); v.addWidget(val)
            card_row.addWidget(f); self._cards[lbl]=f
        lay.addLayout(card_row)

        self._tbl=_make_std_table(self,["Indicator","Value","Signal","Interpretation"])
        lay.addWidget(self._tbl)
        self._status=_status_label("Enter symbol and click Analyse.")
        lay.addWidget(self._status)

    def _set_card(self,key,value,color):
        card=self._cards.get(key)
        if card:
            card.setStyleSheet(f"background:{color};border-radius:6px;padding:4px;")
            lbl=card.findChild(QLabel,"val")
            if lbl: lbl.setText(value)

    def _analyse(self):
        sym=self._sym.text().strip() or "HDFCBANK.NS"
        self._status.setText(f"Fetching {sym}...")
        try:
            import yfinance as yf
            df=yf.download(sym,period=self._period.currentText(),interval="1d",progress=False,auto_adjust=True)
            if df is None or df.empty: self._status.setText("No data."); return
            if hasattr(df.columns,"get_level_values"): df.columns=df.columns.get_level_values(0)
            df=df[["Open","High","Low","Close"]].dropna()
            if len(df)<30: self._status.setText("Need 30+ bars."); return
            h=df["High"].values; lv=df["Low"].values; c=df["Close"].values
            adx,dip,dim=self._adx(h,lv,c)
            sar,sar_bull=self._psar(h,lv,c)
            st,st_bull=self._supertrend(h,lv,c)
            ltp=float(c[-1])
            bulls=sum([dip>dim,sar_bull,st_bull])
            if bulls>=2 and adx>20:   overall,oc="BULLISH","#4caf50"
            elif bulls<=1 and adx>20: overall,oc="BEARISH","#f44336"
            else:                     overall,oc="SIDEWAYS","#ffc107"
            adx_col="#4caf50" if adx>25 else "#ffc107" if adx>20 else "#f44336"
            self._set_card("ADX",f"{adx:.1f}",adx_col)
            self._set_card("DI+",f"{dip:.1f}","#4caf50" if dip>dim else "#607d8b")
            self._set_card("DI-",f"{dim:.1f}","#f44336" if dim>dip else "#607d8b")
            self._set_card("Par SAR","Bull" if sar_bull else "Bear","#4caf50" if sar_bull else "#f44336")
            self._set_card("Supertrend","Bull" if st_bull else "Bear","#4caf50" if st_bull else "#f44336")
            self._set_card("Signal",overall,oc)
            rows=[("ADX (14)",f"{adx:.2f}","Strong" if adx>25 else "Weak","Trend strength >25=strong"),
                  ("DI+ (14)",f"{dip:.2f}","Bullish" if dip>dim else "--","DI+ > DI- = bullish pressure"),
                  ("DI- (14)",f"{dim:.2f}","Bearish" if dim>dip else "--","DI- > DI+ = bearish pressure"),
                  ("Parabolic SAR",f"Rs{sar:.2f}","BUY" if sar_bull else "SELL","Price above SAR = uptrend"),
                  ("Supertrend",f"Rs{st:.2f}","BUY" if st_bull else "SELL","Price above ST = uptrend"),
                  ("Overall",overall,overall,f"2/3 agree | ADX={adx:.1f}")]
            self._tbl.setRowCount(len(rows))
            for r,(ind,val,sig,interp) in enumerate(rows):
                self._tbl.setItem(r,0,QTableWidgetItem(ind)); self._tbl.setItem(r,1,QTableWidgetItem(val))
                s=QTableWidgetItem(sig); s.setForeground(QColor(_signal_color(sig)))
                self._tbl.setItem(r,2,s); self._tbl.setItem(r,3,QTableWidgetItem(interp))
            self._status.setText(f"LTP: Rs{ltp:.2f}  |  Bars: {len(df)}  |  Overall: {overall}")
        except Exception as e:
            self._status.setText(f"Error: {e}")

    def _adx(self, h, lv, c, n=14):
        dm_p = np.where((h[1:] - h[:-1]) > (lv[:-1] - lv[1:]), np.maximum(h[1:] - h[:-1], 0), 0)
        dm_m = np.where((lv[:-1] - lv[1:]) > (h[1:] - h[:-1]), np.maximum(lv[:-1] - lv[1:], 0), 0)
        tr = np.maximum(h[1:] - lv[1:], np.maximum(abs(h[1:] - c[:-1]), abs(lv[1:] - c[:-1])))
        def smooth(x):
            s = np.zeros(len(x)); s[n-1] = x[:n].sum()
            for i in range(n, len(x)): s[i] = s[i-1] - s[i-1]/n + x[i]
            return s
        atr = smooth(tr); sp = smooth(dm_p); sm = smooth(dm_m)
        dip = 100 * sp / (atr + 1e-9); dim = 100 * sm / (atr + 1e-9)
        dx = 100 * abs(dip - dim) / (dip + dim + 1e-9)
        return float(smooth(dx)[-1]), float(dip[-1]), float(dim[-1])

    def _psar(self, h, lv, c, af_step=0.02, af_max=0.20):
        bull = True; af = af_step; ep = float(h[0]); sar = float(lv[0])
        for i in range(1, len(c)):
            if bull:
                sar = min(sar + af*(ep-sar), lv[i-1], lv[max(0, i-2)])
                if lv[i] < sar: bull = False; sar = ep; ep = lv[i]; af = af_step
                elif h[i] > ep: ep = h[i]; af = min(af + af_step, af_max)
            else:
                sar = max(sar + af*(ep-sar), h[i-1], h[max(0, i-2)])
                if h[i] > sar: bull = True; sar = ep; ep = h[i]; af = af_step
                elif lv[i] < ep: ep = lv[i]; af = min(af + af_step, af_max)
        return float(sar), bull

    def _supertrend(self, h, lv, c, period=10, mult=3.0):
        tr = np.maximum(h[1:] - lv[1:], np.maximum(abs(h[1:] - c[:-1]), abs(lv[1:] - c[:-1])))
        atr = np.zeros(len(tr)); atr[period-1] = tr[:period].mean()
        for i in range(period, len(tr)): atr[i] = (atr[i-1]*(period-1) + tr[i])/period
        hl2 = (h[1:] + lv[1:])/2; upper = hl2 + mult*atr; lower = hl2 - mult*atr
        st = np.zeros(len(c)-1); trend_up = True
        for i in range(1, len(st)):
            if trend_up:
                st[i] = max(lower[i], st[i-1]) if st[i-1] > 0 else lower[i]
                if c[i+1] < st[i]: trend_up = False; st[i] = upper[i]
            else:
                st[i] = min(upper[i], st[i-1]) if st[i-1] > 0 else upper[i]
                if c[i+1] > st[i]: trend_up = True; st[i] = lower[i]
        return float(st[-1]), trend_up


# ─────────────────────────────────────────────────────────────────────────────
# 6. OscillatorConfluenceDesk
# ─────────────────────────────────────────────────────────────────────────────
class OscillatorConfluenceDesk(_ScannerCacheMixin, QWidget):
    """RSI + MACD + Stochastic + CCI + Williams%R — multi-oscillator confluence score."""

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self); lay.setContentsMargins(12, 12, 12, 12); lay.setSpacing(8)
        lay.addWidget(_header_label("Oscillator Confluence Desk — LIVE NSE DATA (3-Month Daily)"))
        lay.addWidget(_sub_label("RSI <30=Buy >70=Sell | MACD Line>Signal=Buy | Stoch <20=Buy >80=Sell | CCI <-100=Buy >+100=Sell | Williams %R <-80=Buy >-20=Sell | Score 5/5 = Maximum Confluence"))

        ctrl = QHBoxLayout()
        ctrl.addWidget(QLabel("Min Score:"))
        self._min = QSpinBox(); self._min.setRange(0, 5); self._min.setValue(2); self._min.setFixedWidth(50)
        self._min.valueChanged.connect(self.schedule_scan); ctrl.addWidget(self._min)
        ctrl.addWidget(QLabel("Signal:"))
        self._sig = QComboBox(); self._sig.addItems(["All", "BUY Confluence", "SELL Confluence"])
        self._sig.setFixedWidth(150); self._sig.currentIndexChanged.connect(self.schedule_scan); ctrl.addWidget(self._sig)
        sb = _btn("Refresh Data"); sb.clicked.connect(self._scan); ctrl.addWidget(sb); ctrl.addStretch()
        lay.addLayout(ctrl)

        self._tbl = _make_std_table(self, ["Ticker", "CMP", "RSI", "MACD", "Stoch %K", "CCI", "Williams %R", "BUY Signals", "SELL Signals", "Net Score", "Confluence Signal"])
        lay.addWidget(self._tbl)
        self._status = _status_label("Ready — click Refresh Data to scan"); lay.addWidget(self._status)
        # AUDIT-FIX (Round 6, D-P2-9): eager constructor scan removed (GUI-thread 50-ticker yfinance download during startup).

    def _scan(self):
        min_score = self._min.value()
        sig_filt = self._sig.currentText()
        ohlcv_dict = _fetch_nifty50_ohlcv(period="3mo")
        rows = []
        for full_tkr in NIFTY50:
            tkr = full_tkr.replace(".NS", "")
            df = ohlcv_dict.get(full_tkr)
            if df is None or df.empty or len(df) < 20:
                continue
            c = df["Close"].to_numpy(dtype=float)
            h = df["High"].to_numpy(dtype=float)
            l = df["Low"].to_numpy(dtype=float)
            cmp_ = float(c[-1])

            rsi = _calc_rsi(c, period=14)
            ml, ms, _ = _calc_macd(c, fast=12, slow=26, signal=9)
            stoch, _ = _calc_stoch(h, l, c, k_period=14, d_period=3)
            cci = _calc_cci(h, l, c, period=20)
            willr = _calc_williams_r(h, l, c, period=14)

            b = sum([rsi < 30, ml > ms, stoch < 20, cci < -100, willr < -80])
            s = sum([rsi > 70, ml < ms, stoch > 80, cci > 100, willr > -20])
            net = b - s
            if abs(net) < min_score:
                continue
            if sig_filt == "BUY Confluence" and net <= 0:
                continue
            if sig_filt == "SELL Confluence" and net >= 0:
                continue
            if net >= 4:
                csig = "STRONG BUY (5/5)"
            elif net >= 2:
                csig = "BUY Confluence"
            elif net <= -4:
                csig = "STRONG SELL (5/5)"
            elif net <= -2:
                csig = "SELL Confluence"
            else:
                csig = "Mixed Signals"
            rows.append((tkr, cmp_, rsi, f"{'Up' if ml > ms else 'Dn'} {ml:.2f}/{ms:.2f}", stoch, cci, willr, b, s, net, csig))

        self._tbl.setRowCount(len(rows))
        for r, (tkr, cmp_, rsi, macd, stoch, cci, willr, bc, sc, net, csig) in enumerate(rows):
            for c, val in enumerate([tkr, f"Rs{cmp_:,.1f}", f"{rsi:.1f}", str(macd), f"{stoch:.1f}", f"{cci:.1f}", f"{willr:.1f}", str(bc), str(sc), f"{net:+d}", csig]):
                item = QTableWidgetItem(val); item.setTextAlignment(Qt.AlignCenter)
                if c == 2: item.setForeground(QColor("#4caf50" if rsi < 30 else "#f44336" if rsi > 70 else "#d0d0d0"))
                if c == 9: item.setForeground(QColor("#4caf50" if net > 0 else "#f44336" if net < 0 else "#ffc107"))
                if c == 10: item.setForeground(QColor(_signal_color(csig)))
                self._tbl.setItem(r, c, item)
        sb = sum(1 for rw in rows if rw[9] >= 4); ss = sum(1 for rw in rows if rw[9] <= -4)
        self._status.setText(f"Min score: {min_score} | Stocks scanned: {len(rows)} | Strong BUY: {sb} | Strong SELL: {ss} | Mixed: {len(rows)-sb-ss}")


# ─────────────────────────────────────────────────────────────────────────────
# 7. BollingerBandsScanner
# ─────────────────────────────────────────────────────────────────────────────
class BollingerBandsScanner(_ScannerCacheMixin, QWidget):
    """Bollinger Bands — BandWidth, %B, Squeeze, Breakout signals."""

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self); lay.setContentsMargins(12, 12, 12, 12); lay.setSpacing(8)
        lay.addWidget(_header_label("Bollinger Bands Scanner — LIVE NSE DATA"))
        lay.addWidget(_sub_label("Upper=SMA+2sig | Lower=SMA-2sig | %B=(CMP-Lower)/(Upper-Lower)x100 | BandWidth=(Upper-Lower)/SMAx100 | Squeeze: BW<5% = volatility expansion imminent"))

        ctrl = QHBoxLayout()
        ctrl.addWidget(QLabel("Signal:"))
        self._filt = QComboBox(); self._filt.addItems(["All", "Squeeze", "Upper Touch", "Lower Touch", "Breakout Up", "Breakout Down"])
        self._filt.setFixedWidth(150); self._filt.currentIndexChanged.connect(self.schedule_scan); ctrl.addWidget(self._filt)
        ctrl.addWidget(QLabel("Period:"))
        self._per = QSpinBox(); self._per.setRange(10, 50); self._per.setValue(20); self._per.setFixedWidth(60)
        self._per.valueChanged.connect(self.schedule_scan); ctrl.addWidget(self._per)
        sb = _btn("Refresh Data"); sb.clicked.connect(self._scan); ctrl.addWidget(sb); ctrl.addStretch()
        lay.addLayout(ctrl)

        self._tbl = _make_std_table(self, ["Ticker", "CMP", "Upper Band", "Middle", "Lower Band", "%B", "BandWidth%", "Std Dev", "Squeeze", "Position", "Signal"])
        lay.addWidget(self._tbl)
        self._status = _status_label("Click Refresh Data to compute Bollinger Bands"); lay.addWidget(self._status)
        # AUDIT-FIX (Round 6, D-P2-9): the constructor previously fired
        # self._scan() — a synchronous 50-ticker yfinance download on the GUI
        # thread during MainWindow.__init__ (the window could not appear
        # until it finished; offline it multiplied retries). Lazy now: first
        # scan happens on explicit Refresh / filter change.

    def _scan(self):
        filt = self._filt.currentText()
        per = self._per.value()
        ohlcv_dict = _fetch_nifty50_ohlcv(period="3mo")
        rows = []
        for full_tkr in NIFTY50:
            tkr = full_tkr.replace(".NS", "")
            df = ohlcv_dict.get(full_tkr)
            if df is None or df.empty or len(df) < per:
                continue
            c = df["Close"].to_numpy(dtype=float)
            ub, sma, lb, pct_b, bw, std = _calc_bollinger(c, period=per, num_std=2.0)
            cmp_ = float(c[-1])
            sq = bw < 5.0

            if cmp_ > ub:
                pos = "Above Upper"
            elif cmp_ < lb:
                pos = "Below Lower"
            elif pct_b >= 80:
                pos = "Near Upper"
            elif pct_b <= 20:
                pos = "Near Lower"
            else:
                pos = "Mid Band"

            if filt == "Squeeze" and not sq:
                continue
            elif filt == "Upper Touch" and pos != "Near Upper":
                continue
            elif filt == "Lower Touch" and pos != "Near Lower":
                continue
            elif filt == "Breakout Up" and pos != "Above Upper":
                continue
            elif filt == "Breakout Down" and pos != "Below Lower":
                continue

            if pos == "Above Upper":
                sig = "Breakout UP"
            elif pos == "Below Lower":
                sig = "Breakout DOWN"
            elif sq:
                sig = "Squeeze Pending"
            elif pos == "Near Upper":
                sig = "Near Upper Overbought"
            elif pos == "Near Lower":
                sig = "Near Lower Oversold"
            else:
                sig = "Mid Band Neutral"
            rows.append((tkr, cmp_, ub, sma, lb, pct_b, bw, std, "YES" if sq else "No", pos, sig))

        self._tbl.setRowCount(len(rows))
        for r, (tkr, cmp_, ub, mid, lb, pb, bw, sd, sq, pos, sig) in enumerate(rows):
            for c, val in enumerate([tkr, f"Rs{cmp_:,.1f}", f"Rs{ub:,.1f}", f"Rs{mid:,.1f}", f"Rs{lb:,.1f}", f"{pb:.1f}%", f"{bw:.2f}%", f"{sd:,.1f}", sq, pos, sig]):
                item = QTableWidgetItem(str(val)); item.setTextAlignment(Qt.AlignCenter)
                if c == 10: item.setForeground(QColor(_signal_color(sig)))
                if c == 8 and "YES" in str(val): item.setForeground(QColor("#f44336"))
                self._tbl.setItem(r, c, item)
        sq_cnt = sum(1 for rw in rows if "YES" in rw[8]); bk_cnt = sum(1 for rw in rows if "Breakout" in rw[10])
        avg_bw = sum(rw[6] for rw in rows) / max(len(rows), 1)
        self._status.setText(f"Period: {per} | Stocks: {len(rows)} | Squeezes: {sq_cnt} | Breakouts: {bk_cnt} | Avg BW: {avg_bw:.2f}%")


# ─────────────────────────────────────────────────────────────────────────────
# 8. GapAnalysisScanner
# ─────────────────────────────────────────────────────────────────────────────
class GapAnalysisScanner(_ScannerCacheMixin, QWidget):
    """Gap up/down detection — fill status — continuation vs reversal — catalyst tag."""

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self); lay.setContentsMargins(12, 12, 12, 12); lay.setSpacing(8)
        lay.addWidget(_header_label("Gap Analysis Scanner — LIVE NSE DATA"))
        lay.addWidget(_sub_label("Gap Up: Open > Prev High | Gap Down: Open < Prev Low | Common Gap (<2%) fills quickly | Breakaway Gap (>3%) rarely fills — strong signal"))

        ctrl = QHBoxLayout()
        ctrl.addWidget(QLabel("Min Gap%: "))
        self._min = QDoubleSpinBox(); self._min.setRange(0.5, 10.0); self._min.setValue(1.0)
        self._min.setSingleStep(0.5); self._min.setFixedWidth(70); self._min.valueChanged.connect(self.schedule_scan); ctrl.addWidget(self._min)
        ctrl.addWidget(QLabel("Direction:"))
        self._dir = QComboBox(); self._dir.addItems(["All", "Gap Up", "Gap Down", "Unfilled Gaps"])
        self._dir.setFixedWidth(130); self._dir.currentIndexChanged.connect(self.schedule_scan); ctrl.addWidget(self._dir)
        sb = _btn("Refresh Data"); sb.clicked.connect(self._scan); ctrl.addWidget(sb); ctrl.addStretch()
        lay.addLayout(ctrl)

        self._tbl = _make_std_table(self, ["Ticker", "Gap Date", "Gap%", "Direction", "Gap Type", "Open", "Prev Close", "Fill Status", "Fill%", "Catalyst", "Signal"])
        lay.addWidget(self._tbl)
        self._status = _status_label("Ready — click Refresh Data to scan"); lay.addWidget(self._status)
        # AUDIT-FIX (Round 6, D-P2-9): eager constructor scan removed (GUI-thread network at startup).

    def _scan(self):
        min_gap = self._min.value()
        dir_filt = self._dir.currentText()
        gap_types = {
            (True, "<2%"): "Common Gap", (True, "2-3%"): "Gap Up", (True, ">3%"): "Breakaway Gap",
            (False, "<2%"): "Common Gap", (False, "2-3%"): "Gap Down", (False, ">3%"): "Exhaustion Gap"
        }
        ohlcv_dict = _fetch_nifty50_ohlcv(period="3mo")
        rows = []
        for full_tkr in NIFTY50:
            tkr = full_tkr.replace(".NS", "")
            df = ohlcv_dict.get(full_tkr)
            if df is None or df.empty or len(df) < 5:
                continue
            o = df["Open"].to_numpy(dtype=float)
            h = df["High"].to_numpy(dtype=float)
            l = df["Low"].to_numpy(dtype=float)
            c = df["Close"].to_numpy(dtype=float)
            gaps = _calc_gaps(o, h, l, c)
            if not gaps:
                continue
            latest_gap = gaps[0]
            gap_pct = latest_gap["gap_pct"]
            if gap_pct < min_gap:
                continue
            is_up = latest_gap["is_up"]
            if dir_filt == "Gap Up" and not is_up:
                continue
            if dir_filt == "Gap Down" and is_up:
                continue
            filled = latest_gap["filled"]
            if dir_filt == "Unfilled Gaps" and filled:
                continue

            sz_tag = "<2%" if gap_pct < 2 else ("2-3%" if gap_pct < 3 else ">3%")
            gtype = gap_types.get((is_up, sz_tag), "Gap")
            fill_pct = latest_gap["fill_pct"]

            if is_up and not filled and gap_pct >= 3:
                sig = "Breakaway Gap Strong Bull"
            elif is_up and not filled:
                sig = "Gap Up Holding Bull"
            elif is_up and filled:
                sig = "Gap Filled Monitor"
            elif not is_up and not filled and gap_pct >= 3:
                sig = "Breakaway Gap Down Bear"
            elif not is_up and not filled:
                sig = "Gap Down Holding Bear"
            else:
                sig = "Gap Filled Neutral"

            open_ = latest_gap["open"]
            pc = latest_gap["prev_close"]
            # AUDIT-FIX (Round 5, 2-d-9): `-days_go` is invalid for days_ago == 0
            # (−0 == 0 → df.index[0], the OLDEST date) — exactly the normal
            # "today's gap" case for a live scanner. Index arithmetically instead.
            _gi = len(df) - 1 - int(latest_gap["days_ago"])
            _gi = max(0, min(_gi, len(df) - 1))
            gdate = str(df.index[_gi].date()) if hasattr(df.index[-1], "date") else f"{latest_gap['days_ago']}d ago"
            rows.append((tkr, gdate, f"{gap_pct:.2f}%", "Gap Up" if is_up else "Gap Down", gtype, f"Rs{open_:,.1f}", f"Rs{pc:,.1f}", "Filled" if filled else "Unfilled", f"{fill_pct:.1f}%", "Price Action", sig))

        self._tbl.setRowCount(len(rows))
        for r, rw in enumerate(rows):
            tkr, gd, gp, dirn, gt, op, pc, fs, fp, cat, sig = rw
            for c, val in enumerate([tkr, gd, gp, dirn, gt, op, pc, fs, fp, cat, sig]):
                item = QTableWidgetItem(str(val)); item.setTextAlignment(Qt.AlignCenter)
                if c == 3: item.setForeground(QColor("#4caf50" if "Up" in dirn else "#f44336"))
                if c == 10: item.setForeground(QColor(_signal_color(sig)))
                self._tbl.setItem(r, c, item)
        gu = sum(1 for rw in rows if "Up" in rw[3]); uf = sum(1 for rw in rows if "Unfilled" in rw[7])
        self._status.setText(f"Min Gap: {min_gap}% | Total Gaps: {len(rows)} | Gap Up: {gu} | Gap Down: {len(rows)-gu} | Unfilled: {uf}")


# ─────────────────────────────────────────────────────────────────────────────
# 9. VolumeProfileAnalyzer
# ─────────────────────────────────────────────────────────────────────────────
class VolumeProfileAnalyzer(_ScannerCacheMixin, QWidget):
    """Volume Profile — POC, VAH, VAL, HVN, LVN with price context and signal."""

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self); lay.setContentsMargins(12, 12, 12, 12); lay.setSpacing(8)
        lay.addWidget(_header_label("Volume Profile Analyzer — LIVE NSE DATA"))
        lay.addWidget(_sub_label("POC = Point of Control (highest volume price) | VAH/VAL = Value Area High/Low (70% of volume) | HVN = High Volume Node | LVN = Low Volume Node (fast move zone)"))

        ctrl = QHBoxLayout()
        ctrl.addWidget(QLabel("Lookback:"))
        self._lk = QComboBox(); self._lk.addItems(["20 Days", "50 Days", "90 Days", "1 Year"])
        self._lk.setFixedWidth(110); self._lk.currentIndexChanged.connect(self._calc); ctrl.addWidget(self._lk)
        ctrl.addWidget(QLabel("Signal:"))
        self._sig = QComboBox(); self._sig.addItems(["All", "Above POC", "Below POC", "At HVN", "At LVN"])
        self._sig.setFixedWidth(120); self._sig.currentIndexChanged.connect(self._calc); ctrl.addWidget(self._sig)
        cb = _btn("Refresh Profile"); cb.clicked.connect(self._calc); ctrl.addWidget(cb); ctrl.addStretch()
        lay.addLayout(ctrl)

        self._tbl = _make_std_table(self, ["Ticker", "CMP", "POC", "VAH", "VAL", "HVN", "LVN", "CMP vs POC", "Value Area", "Volume at POC", "Signal"])
        lay.addWidget(self._tbl)
        self._status = _status_label("Click Refresh Profile to compute volume profiles"); lay.addWidget(self._status)
        # AUDIT-FIX (Round 6, D-P2-9): eager constructor scan removed (GUI-thread network at startup).

    def _calc(self):
        lk = self._lk.currentText()
        sig_filter = self._sig.currentText()
        period_map = {"20 Days": "1mo", "50 Days": "3mo", "90 Days": "6mo", "1 Year": "1y"}
        ohlcv_dict = _fetch_nifty50_ohlcv(period=period_map.get(lk, "3mo"))
        rows = []
        for full_tkr in NIFTY50:
            tkr = full_tkr.replace(".NS", "")
            df = ohlcv_dict.get(full_tkr)
            if df is None or df.empty or len(df) < 5:
                continue
            c = df["Close"].to_numpy(dtype=float)
            v = df["Volume"].to_numpy(dtype=float) if "Volume" in df.columns else np.ones_like(c)
            cmp_ = float(c[-1])
            poc, vah, val, hvn, lvn, vol_poc = _calc_volume_profile(c, v, n_bins=20)
            pct_vs_poc = round((cmp_ - poc) / poc * 100, 2) if poc > 0 else 0.0

            if val <= cmp_ <= vah:
                va_pos = "Inside Value Area"
            elif cmp_ > vah:
                va_pos = "Above Value Area"
            else:
                va_pos = "Below Value Area"

            near_hvn = abs(cmp_ - hvn) / cmp_ < 0.015 if cmp_ > 0 else False
            near_lvn = abs(cmp_ - lvn) / cmp_ < 0.015 if cmp_ > 0 else False
            above_poc = cmp_ > poc

            if sig_filter == "Above POC" and not above_poc:
                continue
            if sig_filter == "Below POC" and above_poc:
                continue
            if sig_filter == "At HVN" and not near_hvn:
                continue
            if sig_filter == "At LVN" and not near_lvn:
                continue

            if near_hvn:
                sig = "HVN Congestion"
            elif near_lvn:
                sig = "LVN Fast Move Ahead"
            elif above_poc and va_pos == "Inside Value Area":
                sig = "Bullish In VA above POC"
            elif not above_poc and va_pos == "Inside Value Area":
                sig = "Bearish In VA below POC"
            elif va_pos == "Above Value Area":
                sig = "Extended Watch Pullback"
            else:
                sig = "Weak Below Value Area"

            rows.append((tkr, cmp_, poc, vah, val, hvn, lvn, pct_vs_poc, va_pos, vol_poc, sig))

        self._tbl.setRowCount(len(rows))
        for r, (tkr, cmp_, poc, vah, val, hvn, lvn, pct, va, vpoc, sig) in enumerate(rows):
            sign = "+" if pct >= 0 else ""
            for c, val_ in enumerate([tkr, f"Rs{cmp_:,.1f}", f"Rs{poc:,.1f}", f"Rs{vah:,.1f}", f"Rs{val:,.1f}", f"Rs{hvn:,.1f}", f"Rs{lvn:,.1f}", f"{sign}{pct:.2f}%", va, f"{vpoc:.1f}%", sig]):
                item = QTableWidgetItem(str(val_)); item.setTextAlignment(Qt.AlignCenter)
                if c == 10: item.setForeground(QColor(_signal_color(sig)))
                elif c == 7: item.setForeground(QColor("#4caf50" if pct >= 0 else "#f44336"))
                self._tbl.setItem(r, c, item)
        above = sum(1 for rw in rows if rw[7] >= 0)
        self._status.setText(f"Lookback: {lk} | Stocks: {len(rows)} | Above POC: {above} | Below POC: {len(rows)-above} | Real Volume Profile Active")


# ─────────────────────────────────────────────────────────────────────────────
# Hub
# ─────────────────────────────────────────────────────────────────────────────
class TechnicalAnalysisHub(QWidget):
    """Container QTabWidget hosting all 9 technical analysis panels."""

    def __init__(self, parent=None):
        super().__init__(parent)
        lay=QVBoxLayout(self); lay.setContentsMargins(0,0,0,0)
        tabs=QTabWidget()
        tabs.setTabPosition(QTabWidget.North)
        tabs.setStyleSheet(
            "QTabBar::tab{padding:6px 14px;font-size:11px;}"
            "QTabBar::tab:selected{background:#1e3a4a;color:#e8c84a;font-weight:bold;}"
        )
        panels=[
            ("Candlestick",    CandlestickMasterScanner),
            ("Chart Patterns", ChartPatternRecognizer),
            ("Pivot Points",   PivotPointCalculator),
            ("Fibonacci",      FibonacciRetracementTool),
            ("Trend Strength", TrendStrengthMeter),
            ("Oscillators",    OscillatorConfluenceDesk),
            ("Bollinger",      BollingerBandsScanner),
            ("Gap Analysis",   GapAnalysisScanner),
            ("Volume Profile", VolumeProfileAnalyzer),
        ]
        for label,cls in panels:
            tabs.addTab(cls(),label)
        lay.addWidget(tabs)
