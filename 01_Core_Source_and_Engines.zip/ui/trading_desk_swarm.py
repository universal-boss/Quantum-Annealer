"""
ui/trading_desk_swarm.py
========================
Multi-Agent LLM Trading Desk Swarm (Risk, Alpha, Execution, & PM Sub-Agents).

AUDIT-FIX (defect #18, mock widget labeling):
The audit found that this module presents itself as a "Multi-Agent LLM Trading
Desk" with specialized Risk/Alpha/Execution/PM sub-agents, but the
implementation is actually a small set of if-statements over VaR / regime /
VPIN thresholds — no LLM is invoked anywhere. To prevent the operator from
mistaking this rule-based ensemble for a real multi-LLM swarm, every output
now carries an explicit "SIMULATION (rule-based; no LLM)" prefix until the
module is rewired to call actual LLMs (Gemini / Claude / etc.) per sub-agent.

Spawns specialized AI sub-agents playing real quantitative roles:
  1. Risk Agent: Audits VaR/CVaR, liquidity limits, and compliance.
  2. Alpha Agent: Evaluates factor momentum, VCP patterns, and neural embeddings.
  3. Execution Agent: Evaluates order book toxicity (VPIN) and slippage.
  4. PM Agent: Synthesizes sub-agent votes into final trade allocation decisions.
"""
from __future__ import annotations

import logging
from typing import Dict, Any, List

logger = logging.getLogger(__name__)

# AUDIT-FIX (defect #18): constant prefix used by every agent vote so the
# operator cannot miss the fact that this is a rule-based simulation, not a
# live multi-LLM swarm. The prefix is short to avoid log bloat.
_SIMULATION_TAG = "[SIMULATION: rule-based, no LLM] "


class LLMTradingDeskSwarm:
    """
    Multi-Agent LLM Consensus Trading Desk.

    AUDIT-FIX (defect #18): despite the class name, the current implementation
    does not call any LLM. It is a rule-based vote ensemble. Every verdict
    string carries a SIMULATION tag until real LLM sub-agents are wired in.
    """

    @classmethod
    def evaluate_trade_consensus(cls, profile_name: str, candidate_tickers: List[str],
                                 market_regime: str, risk_metrics: Dict[str, Any]) -> Dict[str, Any]:
        """
        Synthesizes votes across Risk, Alpha, Execution, and PM sub-agents.
        """
        if not candidate_tickers:
            return {"consensus_verdict": "ABORT", "pm_approval": False, "agent_votes": {}, "_simulation_tag": _SIMULATION_TAG.strip()}

        # Risk Agent Audit
        var99 = float(risk_metrics.get("var99_pct", 2.0))
        risk_vote = "APPROVED" if var99 <= 4.0 else "REJECTED (High VaR)"

        # Alpha Agent Audit
        alpha_vote = "APPROVED" if market_regime in ("Bull", "Sideways") else "CAUTION (Bear Market)"

        # Execution Agent Audit
        vpin = float(risk_metrics.get("vpin", 0.40))
        exec_vote = "APPROVED" if vpin < 0.65 else "REJECTED (Toxic Order Flow)"

        # PM Agent Final Decision
        votes_passed = sum(1 for v in [risk_vote, alpha_vote, exec_vote] if "APPROVED" in v)
        pm_approval = bool(votes_passed >= 2)

        return {
            "profile": profile_name,
            "consensus_verdict": "PROCEED" if pm_approval else "HALTED",
            "pm_approval": pm_approval,
            "_simulation_tag": _SIMULATION_TAG.strip(),  # AUDIT-FIX (defect #18): caller-visible marker
            "agent_votes": {
                "Risk_Agent":      _SIMULATION_TAG + risk_vote,
                "Alpha_Agent":      _SIMULATION_TAG + alpha_vote,
                "Execution_Agent":  _SIMULATION_TAG + exec_vote,
                "PM_Agent":         _SIMULATION_TAG + (f"Consensus {votes_passed}/3 -> Approved" if pm_approval else "Rejected by consensus"),
            }
        }
