# Monkey patch requests and socket to set a default timeout (e.g. 15s) globally

# AUDIT-FIX (Round 3, P2-4): re-export from utils_chart_pipeline (split from this god file)
from utils_chart_pipeline import *  # noqa: F401,F403
try:
    import socket
    socket.setdefaulttimeout(15.0)

    import requests as _req_patch
    from requests.adapters import HTTPAdapter as _HTTPAdapter_patch

    _orig_send_patch = _HTTPAdapter_patch.send

    def _patched_send_patch(self, request, stream=False, timeout=None, verify=True, cert=None, proxies=None):
        if timeout is None:
            timeout = 15.0
        return _orig_send_patch(self, request, stream=stream, timeout=timeout, verify=verify, cert=cert, proxies=proxies)

    _HTTPAdapter_patch.send = _patched_send_patch
    import logging as _logging_patch
    _logging_patch.getLogger("urllib3.connectionpool").setLevel(_logging_patch.ERROR)
    import urllib3 as _urllib3_patch
    _urllib3_patch.disable_warnings()
except Exception:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    pass

# 538 public names exported via star-import
__all__ = [
    'Path', 'datetime', 'Optional', 'Any', 'Dict', 'List', 'Tuple', 'Union', 'max_drawdown',
    # Qt names (set dynamically, must be listed explicitly)
    'Qt',
    'QThread',
    'QTimer',
    'QObject',
    'QSize',
    'QPoint',
    'QDate',
    'QMetaObject',
    'Q_ARG',
    'QRectF',
    'QPointF',
    'QUrl',
    'QFont',
    'QColor',
    'QPainter',
    'QPainterPath',
    'QLinearGradient',
    'QBrush',
    'QPen',
    'QPixmap',
    'QIcon',
    'QStandardItemModel',
    'QStandardItem',
    'QAbstractItemView',
    'QApplication',
    'QWidget',
    'QFrame',
    'QDialog',
    'QLabel',
    'QPushButton',
    'QLineEdit',
    'QComboBox',
    'QSpinBox',
    'QDoubleSpinBox',
    'QCheckBox',
    'QRadioButton',
    'QGroupBox',
    'QTabWidget',
    'QTableWidget',
    'QTableWidgetItem',
    'QHeaderView',
    'QVBoxLayout',
    'QHBoxLayout',
    'QGridLayout',
    'QFormLayout',
    'QSplitter',
    'QScrollArea',
    'QTextEdit',
    'QPlainTextEdit',
    'QProgressBar',
    'QSizePolicy',
    'QStackedWidget',
    'QListWidget',
    'QListWidgetItem',
    'QMainWindow',
    'QMessageBox',
    'is_app_dark_mode',
    'get_styled_msgbox_qss',
    'show_styled_message_box',
    'QFileDialog',
    'QMenu',
    'QAction',
    'QToolButton',
    'QStatusBar',
    'QTabBar',
    'QTreeWidget',
    'QTreeWidgetItem',
    'QSlider',
    'QScrollBar',
    'QShortcut',
    'QDateEdit',
    'QDateTimeEdit',
    'QCalendarWidget',
    'QDialogButtonBox',
    'QInputDialog',
    'QStyleFactory',
    'QProxyStyle',
    'QStyle',
    'QButtonGroup',
    'QSystemTrayIcon',
    'QToolTip',
    'QTableView',
    'Signal',
    'pyqtSignal',
    'ADX_TREND_MIN',
    'ALERTS_HISTORY_PATH',
    'APP_NAME',
    'APP_VERSION',
    'ARTIFACTS_DIR',
    'AlertThrottleManager',
    'AppState',
    'AuditLogger',
    'BENCHMARK_FALLBACKS',
    'BULK_DEAL_CACHE_PATH',
    'BUYBACK_CACHE_PATH',
    'CALENDAR_DAYS_PER_YEAR',
    'CHART_SSL_MODEL_META_PATH',
    'CHART_SSL_MODEL_PATH',
    'CORP_ACTIONS_CACHE_PATH',
    'CREDENTIALS_PATH',
    'CircuitBreaker',
    'ComplianceEngine',
    'ConcurrencyPolicy',
    'ConfigValidator',
    'DEFAULT_PORTFOLIO_VALUE',
    'DEFAULT_RANDOM_SEED',
    'DELIVERY_CACHE_PATH',
    'DaemonThreadPoolExecutor',
    'DataCache',
    'DataValidator',
    'DrawdownMonitor',
    'ExceptionLogger',
    'ExecutionCostModel',
    'ExportScheduler',
    'FACTOR_IC_CACHE_PATH',
    'FII_DII_CACHE_PATH',
    'FII_SECTOR_CACHE_PATH',
    'FLOAT_SQUEEZE_CACHE_PATH',
    'FNO_BAN_CACHE_PATH',
    'FUNDAMENTALS_CACHE_PATH',
    'FetchDeduplicator',
    'GRAVEYARD_PATH',
    'HISTORY_PATH',
    'HTTP_RETRY_BACKOFF',
    'HTTP_TIMEOUT_LONG',
    'HTTP_TIMEOUT_MEDIUM',
    'HTTP_TIMEOUT_SHORT',
    'INDIA_VIX_CACHE_PATH',
    'LARGE_MID_SMALL_CACHE_PATH',
    'LAST_RUN_PATH',
    'LazyTabManager',
    'LivePnLStreamer',
    'LivePnLTracker',
    'MAX_DRAWDOWN_LOOKBACK',
    'MA_LONG_PERIOD',
    'MA_SHORT_PERIOD',
    'MONTE_CARLO_DEFAULT_RUNS',
    'MPL_RUNTIME_DIR',
    'MTF_CACHE_PATH',
    'NSEClient',
    'NSE_BHAV_URL',
    'NSE_CORP_ACTIONS_URL',
    'NSE_EQUITY_CSV_URL',
    'NSE_FII_DII_URL',
    'NSE_FNO_BAN_URL',
    'NSE_FNO_BAN_URL2',
    'NSE_INDIA_VIX_URL',
    'NSE_OPTIONS_URL',
    'NSE_SESSION_SLEEP',
    'NSE_STRESS_SCENARIOS',
    'OFFLINE_CHART_MODEL_META_PATH',
    'OFFLINE_CHART_MODEL_PATH',
    'OI_BUILDUP_CACHE_PATH',
    'OPTIONS_IV_CACHE_PATH',
    'PCR_CACHE_PATH',
    'PEAD_CACHE_PATH',
    'PLEDGE_CACHE_PATH',
    'PREFERENCES_PATH',
    'PRESCREEN_CACHE_PATH',
    'PROJECT_DIR',
    'BASE_DIR',
    'PortfolioSnapshotExporter',
    'QT_API',
    'QuantumPortfolioOptimizer',
    'RSI_OVERBOUGHT',
    'RSI_OVERSOLD',
    'RSI_PERIOD',
    'RUNTIME_DIR',
    'RankingEngine',
    'RiskLimitEnforcer',
    'SAST_CACHE_PATH',
    'SAST_VELOCITY_CACHE_PATH',
    'SCREENER_COMPANY_URL',
    'SECTOR_CACHE_PATH',
    'SHORT_TERM_TAX_DAYS',
    'SIGNIFICANCE_LEVEL',
    'SNAPSHOT_DIR',
    'SPIN_DOWN_DARK_SVG',
    'SPIN_DOWN_LIGHT_SVG',
    'SPIN_UP_DARK_SVG',
    'SPIN_UP_LIGHT_SVG',
    'SQLITE_DB_PATH',
    'STRESS_PORTFOLIO_VALUE',
    'ScannerRegistry',
    'SchedulerDaemon',
    'SchedulerDaemon_B',
    'StopRequested',
    'StressTestEngine',
    'TAB_ADVANCEDECLINEBREADTHPANEL',
    'TAB_ALERTS',
    'TAB_ALERT_LOG',
    'TAB_ALGOORDERFLOWANALYSER',
    'TAB_ALGOORDERFLOWANALYZER',
    'TAB_ALGOSTRATEGYBACKTESTER',
    'TAB_ALGO_NOTES',
    'TAB_ALLOCATIONDRIFTMONITOR',
    'TAB_ALPHADECAYANALYSER',
    'TAB_ALPHASIGNALDECAY',
    'TAB_ALTERNATIVEDATADASHBOARD',
    'TAB_APIKEYMANAGER',
    'TAB_APPUPDATECHECKER',
    'TAB_ASSETALLOCATIONADVISOR',
    'TAB_AUDIT_LOG',
    'TAB_BACKTEST',
    'TAB_BACKTESTRESULTSVIEWER',
    'TAB_BACKUPRESTOREPANEL',
    'TAB_BANKINGVALUATIONMATRIX',
    'TAB_BENCHMARKCOMPARISON',
    'TAB_BLACKLITTERMAN',
    'TAB_BONDINTERESTCALENDAR',
    'TAB_BONDYIELDCURVEANALYSER',
    'TAB_BONDYIELDCURVEPANEL',
    'TAB_BONDYIELDMONITOR',
    'TAB_BONDYIELDTRACKER',
    'TAB_BOOTSTRAP',
    'TAB_BREAKOUT',
    'TAB_BROKERPNLRECONCILER',
    'TAB_BT_COMPARE',
    'TAB_BUDGETIMPACTANALYZER',
    'TAB_BUGHARDENINGDASHBOARD',
    'TAB_BULKBLOCKDEALMONITOR',
    'TAB_BUYBACKTRACKERPRO',
    'TAB_CANDLESTICKMASTERSCANNER',
    'TAB_CANDLESTICKPATTERNSCANNER',
    'TAB_CASARATIOTRACKER',
    'TAB_CHANGES',
    'TAB_CHARTPATTERNRECOGNIZER',
    'TAB_CHARTS',
    'TAB_CIRCUITBREAKERMONITOR',
    'TAB_CIRCUITBREAKERPANEL',
    'TAB_COMMENTARY',
    'TAB_COMMODITYCORRELATIONPANEL',
    'TAB_COMMODITYCORRELATIONTRACK',
    'TAB_COMMODITYDASHBOARD',
    'TAB_COMPREHENSIVERISKREPORT',
    'TAB_CONCENTRATION',
    'TAB_CONCENTRATIONLIMITER',
    'TAB_CONSTRAINT_EDITOR',
    'TAB_CONTRARIANFINDER',
    'TAB_CONVERTIBLEBONDTRACKER',
    'TAB_CORPACTIONTRACKER',
    'TAB_CORPORATEACTIONCALENDAR',
    'TAB_CORPORATEBONDTRACKER',
    'TAB_CORPORATEGOVERNANCEMONITOR',
    'TAB_CORRELATION',
    'TAB_CORRELATIONBREAKDOWNPANEL',
    'TAB_CORRELATIONHEATMAPPANEL',
    'TAB_CORR_HEATMAP',
    'TAB_COUNTERPARTYRISKPANEL',
    'TAB_CREDITGROWTHMONITOR',
    'TAB_CREDITRATINGMONITOR',
    'TAB_CRYPTOSENTIMENTBRIDGE',
    'TAB_CURRENCYFOREXMONITOR',
    'TAB_CURRENCYHEDGEADVISOR',
    'TAB_CUSTOMDASHBOARDEXPORTER',
    'TAB_CUSTOMWIDGETBUILDER',
    'TAB_DATAEXPORTHUB',
    'TAB_DATAFEEDSTATUS',
    'TAB_DATAINTEGRITYCHECKER',
    'TAB_DEBTBONDSCREENER',
    'TAB_DEBTMATURITYTRACKER',
    'TAB_DEBTMUTUALFUNDRADAR',
    'TAB_DELIVERYVOLUMEANALYSER',
    'TAB_DELIVERY_SPIKE',
    'TAB_DEMATACCOUNTTRENDS',
    'TAB_DERIVATIVESGREEKSDASHBOARD',
    'TAB_DIAGNOSTICS',
    'TAB_DIIACTIVITYMONITOR',
    'TAB_DIIFLOWTRACKER',
    'TAB_DIVIDENDCALENDAR',
    'TAB_DIVIDENDGROWTHTRACKER',
    'TAB_DIVIDENDINCOMEPROJECTER',
    'TAB_DIVIDENDYIELDSCANNER',
    'TAB_DIVIDENDYIELDTRACKER',
    'TAB_DRAWDOWNANALYSER',
    'TAB_DYNAMICASSETALLOCATOR',
    'TAB_DYNAMIC_UNIVERSE',
    'TAB_EARNINGSCALENDARPANEL',
    'TAB_EARNINGSCALENDARTRACKER',
    'TAB_EARNINGSWHISPERTRACKER',
    'TAB_ECONOMICCALENDARPANEL',
    'TAB_ECONOMICINDICATORTRACKER',
    'TAB_EDGECASEHARDENINGPANEL',
    'TAB_ELLIOTTWAVETRACKER',
    'TAB_EQUITY_CURVE',
    'TAB_ERRORBOUNDARYPANEL',
    'TAB_ESGSCORETRACKER',
    'TAB_ESGSUSTAINABILITYSCORER',
    'TAB_ETFARBITRAGEMONITOR',
    'TAB_ETFOVERLAPANALYSER',
    'TAB_EVENT_SCANNER',
    'TAB_EXECUTION',
    'TAB_EXECUTIONALGORITHMPANEL',
    'TAB_EXECUTIVESUMMARY',
    'TAB_EXPORTHARDENINGPANEL',
    'TAB_EXPOSURES',
    'TAB_EXPOSURE_DRIFT',
    'TAB_FACTORBACKTESTENGINE',
    'TAB_FACTORS',
    'TAB_FACTORTILTOPTIMISER',
    'TAB_FACTOR_ATTR',
    'TAB_FACTOR_CROWDING',
    'TAB_FACTOR_DELTA',
    'TAB_FACTOR_TILT',
    'TAB_FAVOURITESQUICKPANEL',
    'TAB_FEATUREIMPORTANCEPANEL',
    'TAB_FIBONACCIRETRACEMENTTOOL',
    'TAB_FIIACTIVITYMONITOR',
    'TAB_FIICASHEQUITYTRACKER',
    'TAB_FIIDERIVATIVETRACKER',
    'TAB_FIIDIIACTIVITYMONITOR',
    'TAB_FIIDIIACTIVITYTRACKER',
    'TAB_FIIDIIFLOWANALYTICS',
    'TAB_FIIFLOWTRACKER',
    'TAB_FULLSETTINGSOVERHAUL',
    'TAB_FUNDAMENTALSCREENER',
    'TAB_FUTURESBASISTRACKER',
    'TAB_GLOBALEQUITYHEATMAP',
    'TAB_GLOBALMACROMONITOR',
    'TAB_GLOBALMACROPANEL',
    'TAB_GLOBALMARKETPULSE',
    'TAB_GLOBALMARKETPULSE2',
    'TAB_GOALPLANNERPRO',
    'TAB_GOLDSILVERCOMMODITYDESK',
    'TAB_GREEKSDASHBOARD',
    'TAB_GREEKSDASHBOARDLIVE',
    'TAB_HEALTH_SCORECARD',
    'TAB_HEATMAP',
    'TAB_HEATMAPSECTORROTATION',
    'TAB_HISTORY',
    'TAB_IMPLIEDVOLATILITYTRACKER',
    'TAB_INFLATIONHEATMAP',
    'TAB_INSIDERACTIVITYMONITOR',
    'TAB_INSIDERACTIVITYPANEL',
    'TAB_INSIDERTRADINGMONITOR',
    'TAB_INSIDERTRADINGRADAR',
    'TAB_INSIDERTRADINGTRACKER',
    'TAB_INSIDERTRANSACTIONMONITOR',
    'TAB_INSTITUTIONALOWNERSHIPPANEL',
    'TAB_INSTITUTIONALOWNERSHIPSHIFT',
    'TAB_INSTITUTIONAL_FLOW',
    'TAB_INSTRUMENT_DETAIL',
    'TAB_INVESTMENTCHECKLIST',
    'TAB_IPOPIPELINEMONITOR',
    'TAB_IPOPIPELINETRACKER',
    'TAB_IPTRACKLERPRO',
    'TAB_IVSURFACEPANEL',
    'TAB_KEYBOARDSHORTCUTPANEL',
    'TAB_LAZYTABLOADER',
    'TAB_LIQUIDITYRISKDASHBOARD',
    'TAB_LIQUIDITYSCORECARD',
    'TAB_LIQUIDITYSTRESSTESTPANEL',
    'TAB_LISTINGGAINANALYZER',
    'TAB_LIVECORRELATIONMONITOR',
    'TAB_LIVEGREEKSPANEL',
    'TAB_LIVEMARKETSCANNERPANEL',
    'TAB_LIVENEWSTICKERPANEL',
    'TAB_LIVE_PNL',
    'TAB_LOGS',
    'TAB_MACROCALENDAREVENTTRACKER',
    'TAB_MACROECONOMICCALENDAR',
    'TAB_MACROINDIATRACKER',
    'TAB_MACRO_REGIME',
    'TAB_MARGINCALCULATOR',
    'TAB_MARKETBREADTHMONITOR',
    'TAB_MARKETBREATHDASHBOARD',
    'TAB_MARKETCALENDARMASTER',
    'TAB_MARKETMICROSTRUCTUREPANEL',
    'TAB_MARKET_BREADTH',
    'TAB_MAXPAINCALCULATOR',
    'TAB_MISTAKEPATTERNANALYZER',
    'TAB_MLALPHASIGNALPANEL',
    'TAB_MOMENTUMCYCLEANALYSER',
    'TAB_MOMENTUMSCOREBOARD',
    'TAB_MOMENTUMSTOCKPICKER',
    'TAB_MONTECARLOPORTFOLIOSIM',
    'TAB_MONTHLYPORTFOLIOREPORT',
    'TAB_MOVINGAVERAGECROSSSCANNER',
    'TAB_MRC',
    'TAB_MULTIACCOUNTMANAGER',
    'TAB_MULTIFACTORCOMBINERS',
    'TAB_MULTITIMEFRAMECONFLUENCE',
    'TAB_MUTUALFUNDFLOWTRACKER',
    'TAB_MUTUALFUNDOVERLAPANALYSER',
    'TAB_NCDMONITOR',
    'TAB_NEW52WEEKRADAR',
    'TAB_NEWSALPHAEXTRACTOR',
    'TAB_NEWSALPHAPANEL',
    'TAB_NEWSIMPACTTRACKER',
    'TAB_NIMMARGINSRACKER',
    'TAB_NOTIFICATION_CTR',
    'TAB_NPATRACKERPRO',
    'TAB_OPENINTERESTANALYSER',
    'TAB_OPENINTERESTANALYZER',
    'TAB_OPTIMISATIONSOLVER',
    'TAB_OPTIONSCHAINVIEWER',
    'TAB_OPTIONSEXPIRYIMPACTPANEL',
    'TAB_OPTIONSFLOWSCANNER',
    'TAB_OPTIONSSTRATEGYBUILDER',
    'TAB_OPT_PROGRESS',
    'TAB_ORDERMANAGEMENTPANEL',
    'TAB_ORDER_RECON',
    'TAB_OSCILLATORCONFLUENCEDESK',
    'TAB_PAIRSTRADINGMONITOR',
    'TAB_PARAM_WIZARD',
    'TAB_PARETO_FRONTIER',
    'TAB_PASSIVEINCOMEPROJECTOR',
    'TAB_PCRANALYSISPANEL',
    'TAB_PCRHEATMAP',
    'TAB_PDFREPORTBUILDER2',
    'TAB_PERFORMANCEATTRIBUTION2',
    'TAB_PERF_ATTR',
    'TAB_PERSONALISEDAELRTHUB',
    'TAB_PIVOTPOINTCALCULATOR',
    'TAB_PIVOTTABLEANALYSER',
    'TAB_PLEDGEMANAGER',
    'TAB_PORTFOLIO',
    'TAB_PORTFOLIOATTRIBUTION',
    'TAB_PORTFOLIOATTRIBUTIONENGINE',
    'TAB_PORTFOLIOBLOTTERPANEL',
    'TAB_PORTFOLIOCLIMATERISKPANEL',
    'TAB_PORTFOLIOCONSTRUCTIONAUD',
    'TAB_PORTFOLIOCONSTRUCTIONAUDIT',
    'TAB_PORTFOLIOHEALTHSCORE',
    'TAB_PORTFOLIOOPTIMISERMVP',
    'TAB_PORTFOLIOREGIMESENSITIVI',
    'TAB_PORTFOLIOREVIEWCALENDAR',
    'TAB_PORTFOLIOSIMULATORPRO',
    'TAB_PORTFOLIOTURNOVEROPTIMIS',
    'TAB_PORTFOLIOXRAYANALYSER',
    'TAB_PORTFOLIOXRAYPANEL',
    'TAB_POSITIONLIMITCHECKER',
    'TAB_POSITIONSIZINGCALCULATOR',
    'TAB_POSITION_SIZER',
    'TAB_CHART_PATTERN_SCREENER',
    'TAB_PREBREAKOUT',
    'TAB_PRESCREEN',
    'TAB_PRETRADECOMPLIANCESCREEN',
    'TAB_PROMOTERHOLDINGTRACKER',
    'TAB_PROMOTERPLEDGEMONITOR',
    'TAB_PROMOTERPLEDGETRACKER',
    'TAB_PROPRIETARYTRADINGMONITOR',
    'TAB_QIPOFSMONI',
    'TAB_QUANTFACTORSCORER',
    'TAB_QUANTITATIVESTRATEGYLAB',
    'TAB_QUANTJOURNALPANEL',
    'TAB_QUANTPORTFOLIOSIMULATOR',
    'TAB_QUANTRESEARCHIDE',
    'TAB_QUANTRESEARCHWORKBENCH',
    'TAB_QUANTSCREENERBACKTESTER',
    'TAB_QUANTSCREENERPRO',
    'TAB_QUANTSTRATEGYLIBRARY',
    'TAB_QUANT_NOTEBOOK',
    'TAB_RBIPOLICYTRACKER',
    'TAB_REALESTATEREITSANALYSER',
    'TAB_REALESTATEREITTRACKER',
    'TAB_REBALANCE_CAL',
    'TAB_REGIMEOVERLAYAUDITPANEL',
    'TAB_REGIME_CALENDAR',
    'TAB_REGIME_CHART',
    'TAB_REGIME_SCREENER',
    'TAB_REGULATORYALERTPANEL',
    'TAB_REITDISTRIBUTION',
    'TAB_RELATIVESTRENGTHSCANNER',
    'TAB_RESERVED_23',
    'TAB_RESERVED_25',
    'TAB_RESERVED_26',
    'TAB_RETAILPARTICIPATIONINDEX',
    'TAB_RETIREMENTCORPUSPLANNER',
    'TAB_RIGHTSOFFERINGSTRACKER',
    'TAB_RISK',
    'TAB_RISKADJUSTEDRETURNS',
    'TAB_RISKMANAGEMENTCONSOLE',
    'TAB_RISKPARITYBUILDER',
    'TAB_RISK_BUDGET',
    'TAB_ROLLINGRETURNHEATMAP',
    'TAB_ROLLOVERANALYSISPANEL',
    'TAB_ROTATION_ENGINE',
    'TAB_SCENARIO_LIB',
    'TAB_SEBIAUDITLOGPANEL',
    'TAB_SECTORFUNDAMENTALSCORECA',
    'TAB_SECTORFUNDAMENTALSCORER',
    'TAB_SECTORROTATIONCLOCK',
    'TAB_SECTORROTATIONTRACKER',
    'TAB_SECTORS',
    'TAB_SECTOR_RADAR',
    'TAB_SECTOR_RS',
    'TAB_SENS_HEATMAP',
    'TAB_SESSIONRECOVERYPANEL',
    'TAB_SETTINGSEXPORTIMPORT',
    'TAB_SETUPPERFORMANCESTATS',
    'TAB_SHAPEXPLAINERPANEL',
    'TAB_SHORTSELLINGMONITOR',
    'TAB_SHORTSELLINGRADAR',
    'TAB_SHORTSELLINGTRACKER',
    'TAB_SHORT_SQUEEZE',
    'TAB_SIGNALDIAGNOSTICSPANEL',
    'TAB_SIGNAL_DEBUG',
    'TAB_SIPCALCULATORPRO',
    'TAB_SLIPPAGE',
    'TAB_SMALLMID_MOMENTUM',
    'TAB_SMARTMONEYCONCEPTSPANEL',
    'TAB_SMEIPORADAR',
    'TAB_SPEEDOMETERSENTIMENTGAUGE',
    'TAB_STARTUPPROFILER',
    'TAB_STATISTICALARBITRAGEPANEL',
    'TAB_STOCHASTICOSCILLATORSCANNER',
    'TAB_STRATEGYLEADERBOARD',
    'TAB_STRATEGYVERSIONCONTROL',
    'TAB_STRESSTESTLIBRARY2',
    'TAB_STRESS_TEST',
    'TAB_STYLEBOXANALYSER',
    'TAB_SUBPORTFOLIOTRACKER',
    'TAB_SUPPLYDEMANZONEMAP',
    'TAB_SUSTAINABILITYREPORTTRACK',
    'TAB_SYSTEMRESOURCEMONITOR',
    'TAB_TABGROUPMANAGER',
    'TAB_TAILRISKHEDGER',
    'TAB_TAILRISKSCENARIO',
    'TAB_TAXHARVESTINGOPTIMISER',
    'TAB_TAXHARVESTINGTOOL',
    'TAB_TAXREPORTGENERATOR',
    'TAB_TECHNICALBREAKOUT',
    'TAB_TECHNICALSCREENERPRO',
    'TAB_TG_COMPOSER',
    'TAB_THEMATICBASKETBUILDER',
    'TAB_THEMECUSTOMIZER',
    'TAB_THEMEMANAGER',
    'TAB_THEMESWITCHER',
    'TAB_THEME_BASKET',
    'TAB_THREADSAFETYAUDITPANEL',
    'TAB_TOPPICKSOFTHEDAY',
    'TAB_TRADEJOURNALPRO',
    'TAB_TRADE_TICKET',
    'TAB_TRADINGPSYCHOLOGYSCORE',
    'TAB_TRANSACTIONCOSTANALYSER',
    'TAB_TRENDSTRENGTHMETER',
    'TAB_TURNOVER',
    'TAB_UNIVERSE',
    'TAB_USERPROFILEMANAGER',
    'TAB_UXREFINEMENTPANEL',
    'TAB_VALUESTOCKRADAR',
    'TAB_VARBACKTESTPANEL',
    'TAB_VIX_REGIME',
    'TAB_VOLATILITYARBITRAGEPANEL',
    'TAB_VOLATILITYREGIMEDETECTOR',
    'TAB_VOLUMEPROFILEANALYSER',
    'TAB_VOLUMEPROFILEANALYZER',
    'TAB_VOLUME_EXPANSION',
    'TAB_WATCHLIST',
    'TAB_WATCHLISTALERTENGINE',
    'TAB_WEALTHGOALPLANNER',
    'TAB_WEEKLYMARKETSNAPSHOT',
    'TAB_WFO_PANEL',
    'TAB_YIELDCURVEANALYZER',
    'TICKERS_CACHE_PATH',
    'TRADING_DAYS_PER_YEAR',
    'TelegramCommandListener',
    'TelegramCommandListener_B',
    'ThreadSafeCache',
    'UIUpdateGuard',
    'VALIDATION_LAG_DAYS',
    'WFO_DEFAULT_IS_MONTHS',
    'WFO_DEFAULT_OOS_MONTHS',
    'WorkerLifecycle',
    'XDG_CACHE_DIR',
    'Z_SCORE_90',
    'Z_SCORE_95',
    'annualized_return',
    'annualized_vol',
    'apply_score_calibration',
    'apply_theme',
    'archlog',
    'build_alerts',
    'build_chart_tensor',
    'build_correlation_matrix',
    'build_diagnostics_frame',
    'build_ewma_correlation',
    'build_multitimeframe_input_bundle',
    'build_exposures_summary',
    'build_factor_summary',
    'build_selection_changes',
    'check_stop',
    'chunked',
    'compute_beta',
    'compute_breakout_tables',
    'compute_chart_ssl_features',
    'compute_factor_attribution',
    'compute_multi_timeframe_chart_features',
    'compute_oos_validation',
    'compute_portfolio_health',
    'compute_prescreen_row',
    'compute_rsi',
    'compute_sensitivity_report',
    'compute_signal_frame',
    'downside_vol',
    'ema_gap',
    'evaluate_qubo_subset',
    'estimate_survivorship_bias',
    'extract_field_panel',
    'factor_contribution_row',
    'generate_chart_pack',
    'load_credentials',
    'load_last_run_state',
    'load_or_build_chart_ssl_model',
    'local_search_improve',
    'log_emit',
    'log_once_per_window',
    'max_dd_from_equity',
    'momentum_skip_recent',
    'parse_symbol_lines',
    'payload_to_serializable',
    'per_stock_tc_bps',
    'process_prescreen_batch',
    'progress_span',
    'proximity_52w_high',
    'read_json_cache',
    'repair_selection',
    'robust_zscore_series',
    'run_monte_carlo_bootstrap',
    'save_credentials',
    'scrub_anomalies',
    'sector_counts',
    'sharpe_from_returns',
    'spearmanr_np',
    'summarize_selection_reason',
    'trailing_return',
    'ts_feature_vector_v2',
    'update_delisted_graveyard',
    'write_json_cache',
    '_DB_STORE',
    '_FUNDRAW_IC_CACHE',
]

"""
utils.py — Constants, helpers, colour palette, technical indicator engine.
Always imported first. Zero hard external dependencies.
"""
import sys, os, re, math, time, json, copy, warnings, threading, traceback
import tempfile, logging as _logging, hashlib as _hashlib, sqlite3, pickle
import csv, io, gc, uuid, base64, datetime, functools, itertools, contextlib
import concurrent.futures as _cf_mod, threading as _threading
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

archlog   = _logging.getLogger("quantum_annealer")
_arch_log = archlog   # legacy alias

try: import numpy as np
except ImportError: np = None
try: import pandas as pd
except ImportError: pd = None

# Optional heavy deps — guarded so the package loads without them
try: import dimod
except ImportError: dimod = None
try: import neal
except ImportError: neal = None
try: from scipy import stats as _scipy_stats
except ImportError: _scipy_stats = None
try: from scipy.optimize import minimize as _scipy_minimize
except ImportError: _scipy_minimize = None
try: from sklearn.preprocessing import StandardScaler as _StandardScaler
except ImportError: _StandardScaler = None
try: import openpyxl
except ImportError: openpyxl = None
try: import apscheduler
except ImportError: apscheduler = None

# Qt stubs — so non-UI code that references Qt names still imports cleanly
try:
    from PySide6.QtCore import (Qt, QThread, Signal, QTimer, QSize, QObject,
        QPoint, QDate, QMetaObject, Q_ARG, QRectF, QPointF, QUrl,
        QSortFilterProxyModel)
    from PySide6.QtGui import (QFont, QColor, QPainter, QPainterPath,
        QLinearGradient, QBrush, QPen, QPixmap, QIcon,
        QStandardItemModel, QStandardItem)
    from PySide6.QtWidgets import (QApplication, QWidget, QFrame, QDialog,
        QLabel, QPushButton, QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox,
        QCheckBox, QRadioButton, QGroupBox, QTabWidget, QTableWidget,
        QTableWidgetItem, QHeaderView, QVBoxLayout, QHBoxLayout, QGridLayout,
        QFormLayout, QSplitter, QScrollArea, QTextEdit, QPlainTextEdit,
        QProgressBar, QSizePolicy, QStackedWidget, QListWidget, QListWidgetItem,
        QMainWindow, QMessageBox, QFileDialog, QMenu, QAction, QToolButton,
        QStatusBar, QTabBar, QTreeWidget, QTreeWidgetItem, QSlider, QScrollBar,
        QShortcut, QDateEdit, QDateTimeEdit, QCalendarWidget, QDialogButtonBox,
        QInputDialog, QStyleFactory, QProxyStyle, QStyle, QButtonGroup,
        QSystemTrayIcon, QToolTip, QAbstractItemView, QTableView)
    pyqtSignal = Signal
    QT_API = "PySide6"
except ImportError:
    try:
        from PySide2.QtCore import (Qt, QThread, Signal as pyqtSignal, QTimer, QSize,
            QObject, QPoint, QDate, QMetaObject, QRectF, QPointF, QUrl)
        from PySide2.QtGui import (QFont, QColor, QPainter, QPainterPath,
            QLinearGradient, QBrush, QPen, QPixmap, QIcon)
        from PySide2.QtWidgets import (QApplication, QWidget, QFrame, QDialog,
            QLabel, QPushButton, QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox,
            QCheckBox, QRadioButton, QGroupBox, QTabWidget, QTableWidget,
            QTableWidgetItem, QHeaderView, QVBoxLayout, QHBoxLayout, QGridLayout,
            QFormLayout, QSplitter, QScrollArea, QTextEdit, QPlainTextEdit,
            QProgressBar, QSizePolicy, QStackedWidget, QListWidget, QListWidgetItem,
            QMainWindow, QMessageBox, QFileDialog, QMenu, QAction, QToolButton,
            QStatusBar, QTabBar, QTreeWidget, QTreeWidgetItem, QSlider, QScrollBar,
            QShortcut, QDateEdit, QDateTimeEdit, QCalendarWidget, QDialogButtonBox,
            QInputDialog, QStyleFactory, QProxyStyle, QStyle, QButtonGroup,
            QToolTip, QAbstractItemView, QTableView)
        Signal = pyqtSignal
        QT_API = "PySide2"
    except ImportError:
        try:
            from PyQt5.QtCore import (Qt, QThread, pyqtSignal, QTimer, QSize,
                QObject, QPoint, QDate, QMetaObject, Q_ARG, QRectF, QPointF, QUrl)
            from PyQt5.QtGui import (QFont, QColor, QPainter, QPainterPath,
                QLinearGradient, QBrush, QPen, QPixmap, QIcon)
            from PyQt5.QtWidgets import (QApplication, QWidget, QFrame, QDialog,
                QLabel, QPushButton, QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox,
                QCheckBox, QRadioButton, QGroupBox, QTabWidget, QTableWidget,
                QTableWidgetItem, QHeaderView, QVBoxLayout, QHBoxLayout, QGridLayout,
                QFormLayout, QSplitter, QScrollArea, QTextEdit, QPlainTextEdit,
                QProgressBar, QSizePolicy, QStackedWidget, QListWidget, QListWidgetItem,
                QMainWindow, QMessageBox, QFileDialog, QMenu, QAction, QToolButton,
                QStatusBar, QTabBar, QTreeWidget, QTreeWidgetItem, QSlider, QScrollBar,
                QShortcut, QDateEdit, QDateTimeEdit, QCalendarWidget, QDialogButtonBox,
                QInputDialog, QStyleFactory, QProxyStyle, QStyle, QButtonGroup,
                QToolTip, QAbstractItemView, QTableView)
            Signal = pyqtSignal
            QT_API = "PyQt5"
        except ImportError:
            QT_API = "stub"
        class _S:
            def __init__(self,*a,**k): pass
            def __getattr__(self,n): return type(self)()
            def __call__(self,*a,**k): return type(self)()
            def __bool__(self): return False
            def __int__(self): return 0
        def _sf(n): return type(n,(_S,),{})
        for _qn in (
            "Qt QThread QTimer QObject QSize QPoint QDate QMetaObject Q_ARG "
            "QRectF QPointF QUrl QFont QColor QPainter QPainterPath "
            "QLinearGradient QBrush QPen QPixmap QIcon QStandardItemModel "
            "QStandardItem QAbstractItemView QApplication QWidget QFrame "
            "QDialog QLabel QPushButton QLineEdit QComboBox QSpinBox "
            "QDoubleSpinBox QCheckBox QRadioButton QGroupBox QTabWidget "
            "QTableWidget QTableWidgetItem QHeaderView QVBoxLayout QHBoxLayout "
            "QGridLayout QFormLayout QSplitter QScrollArea QTextEdit "
            "QPlainTextEdit QProgressBar QSizePolicy QStackedWidget "
            "QListWidget QListWidgetItem QMainWindow QMessageBox QFileDialog "
            "QMenu QAction QToolButton QStatusBar QTabBar QTreeWidget "
            "QTreeWidgetItem QSlider QScrollBar QShortcut QDateEdit "
            "QDateTimeEdit QCalendarWidget QDialogButtonBox QInputDialog "
            "QStyleFactory QProxyStyle QStyle QButtonGroup QSystemTrayIcon "
            "QToolTip QTableView QSortFilterProxyModel"
        ).split():
            globals()[_qn] = _sf(_qn)
        Q_ARG = lambda t,v: v
        def Signal(*a,**k): return property(lambda s: None)
        pyqtSignal = Signal

# Prevent EXC_CRASH / SIGABRT when running QThreads are garbage collected or parent widgets are destroyed.
# C2-fix: Use a module-level sentinel dict instead of QThread._qa_patched class attribute because
# PySide6 Shiboken-wrapped C++ types don't reliably persist monkey-patched class attributes
# across module import boundaries (the C++ method_descriptor can silently take precedence).
_QA_PATCHED: dict = {}  # {"qthread_start": True} once patch is applied
if QT_API in ('PySide6', 'PyQt5'):
    import sys
    import atexit
    _ACTIVE_THREADS_KEEPALIVE = []
    if not _QA_PATCHED.get("qthread_start", False):
        _orig_qthread_start = QThread.start
        def _patched_qthread_start(self):
            try:
                self.setParent(None)
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                pass
            _ACTIVE_THREADS_KEEPALIVE.append(self)
            try:
                self.finished.connect(lambda: _ACTIVE_THREADS_KEEPALIVE.remove(self) if self in _ACTIVE_THREADS_KEEPALIVE else None)
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                pass
            try:
                wl = globals().get("WorkerLifecycle")
                if wl is not None:
                    wl.register_thread(self)
                    if not getattr(wl, "_atexit_registered", False):
                        atexit.register(wl.shutdown_all)
                        wl._atexit_registered = True
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                pass
            _orig_qthread_start(self)
        QThread.start = _patched_qthread_start
        QThread._qa_patched = True       # best-effort class attribute (may not persist in PySide6)
        _QA_PATCHED["qthread_start"] = True  # authoritative module-level flag


# ────────────────────────────────────────────────────────────────────
# CLASS: ThreadSafeCache
# ────────────────────────────────────────────────────────────────────
from data.cache_manager import ThreadSafeCache



# ── Dynamic Universe ─────────────────────────────────────────────────────────
# All analytical tabs read tickers from get_active_universe() instead of
# hardcoded lists. _WATCHLIST is populated after every optimizer run.
# Phase 4.6: All tickers now have the .NS suffix so downstream consumers
# (safe_download, fetch_sectors, etc.) don't need to add it manually.
# Previously: bare tickers ("RELIANCE", "TCS") caused yfinance to treat them
# as US tickers and return empty data — silent download failures.
_NIFTY50_RAW = [
    "RELIANCE","TCS","HDFCBANK","INFY","ICICIBANK","SBIN","BAJFINANCE",
    "HCLTECH","WIPRO","AXISBANK","KOTAKBANK","LT","TITAN","SUNPHARMA",
    "ONGC","MARUTI","NESTLEIND","POWERGRID","NTPC","TECHM",
    "ASIANPAINT","TATASTEEL","JSWSTEEL","ADANIENT","ULTRACEMCO",
    "BRITANNIA","HINDALCO","COALINDIA","BPCL","TATAMOTORS",
    "BAJAJFINSV","DIVISLAB","DRREDDY","EICHERMOT","GRASIM",
    "HDFCLIFE","HEROMOTOCO","INDUSINDBK","CIPLA","ITC",
    "JSWENERGY","M&M","SHRIRAMFIN","TATACONSUM","TRENT",
    "BAJAJ-AUTO","APOLLOHOSP","BEL","BHARTIARTL","HINDUNILVR",
]
NIFTY50_UNIVERSE: list = [f"{t}.NS" for t in _NIFTY50_RAW]
_WATCHLIST: list = []
_WATCHLIST_LOCK = __import__("threading").Lock()
_NIFTY50 = NIFTY50_UNIVERSE
_NIFTY_NEXT50_RAW = [
    "IOC", "GAIL", "DLF", "HAL", "MUTHOOTFIN", "COLPAL", "HINDPETRO", "MRF", "OBEROIRLTY", "DMART",
    "VBL", "PIDILITIND", "SIEMENS", "HAVELLS", "SRF", "TATACOMM", "LTIM", "ABB", "PFC", "RECL",
    "PNB", "CANBK", "TATAELXSI", "ICICIPRULI", "HDFCAMC", "ABFRL", "POLYCAB", "ZOMATO", "NYKAA", "PAYTM",
    "PIIND", "MAXHEALTH", "PAGEIND", "TVSMOTOR", "NMDC", "SAIL", "BANDHANBNK", "IDFCFIRSTB", "BANKBARODA", "AMBUJACEM",
    "ACC", "JUBLFOOD", "BERGEPAINT", "BIOCON", "BOSCHLTD", "INDIGO", "ICICIGI", "L&TFH", "MARICO", "MPHASIS"
]
_NIFTY_NEXT50 = [f"{t}.NS" for t in _NIFTY_NEXT50_RAW]



# ────────────────────────────────────────────────────────────────────
# FUNC: _set_watchlist
# ────────────────────────────────────────────────────────────────────
def _set_watchlist(tickers: list) -> None:
    global _WATCHLIST  # GLB001: consider replacing global with AppState
    cleaned = [t.replace(".NS","").strip() for t in tickers if t]
    with _WATCHLIST_LOCK:
        _WATCHLIST = cleaned
    pass  # _arch_log removed (LOG003)


# ────────────────────────────────────────────────────────────────────
# CLASS: _DynamicTabMixin
# ────────────────────────────────────────────────────────────────────
class _DynamicTabMixin:
    """Adds universe badge + Refresh button to any analytical tab."""
    def _add_refresh_toolbar(self, parent_layout, refresh_fn):
        self._refresh_fn = refresh_fn
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 4)
        self._universe_badge = QLabel()
        self._update_universe_badge()
        self._universe_badge.setStyleSheet(
            "color:#7a9eb5;font-size:11px;padding:2px 6px;"
            "border:1px solid #2a3a42;border-radius:4px;")
        refresh_btn = QPushButton("🔄 Refresh")
        refresh_btn.setFixedHeight(26)
        refresh_btn.setStyleSheet(
            "QPushButton{background:#1e2a2e;color:#d0d0d0;border:1px solid #2a3a42;"
            "border-radius:4px;padding:0 10px;font-size:11px;}"
            "QPushButton:hover{background:#243540;}")
        refresh_btn.clicked.connect(lambda: (self._update_universe_badge(), self._refresh_fn()))
        row.addWidget(self._universe_badge)
        row.addStretch()
        row.addWidget(refresh_btn)
        parent_layout.insertLayout(0, row)

    def _update_universe_badge(self):
        with _WATCHLIST_LOCK:
            src_label = "Watchlist" if _WATCHLIST else "Nifty 50"
            u = list(_WATCHLIST) if _WATCHLIST else list(NIFTY50_UNIVERSE)
            u = u[:30]
        if hasattr(self, "_universe_badge"):
            self._universe_badge.setText(
                f"📊 Universe: {len(u)} tickers  [{src_label}]")
# ─────────────────────────────────────────────────────────────────────────────


# ── P4: Demo-data helper ─────────────────────────────────────────────
# Widgets whose live-data feed is not yet implemented use this helper
# to generate deterministic, ticker-seeded demo data instead of
# random noise.  Values are reproducible across runs for the same
# ticker so the UI doesn't flicker on refresh.
import hashlib as _hashlib


# ────────────────────────────────────────────────────────────────────
# FUNC: _demo_seed
# ────────────────────────────────────────────────────────────────────
def _demo_seed(label: str = "") -> "random.Random":
    """Return a seeded Random instance deterministic on *label*."""
    import random as _r
    seed = int(_hashlib.md5(label.encode()).hexdigest()[:8], 16)
    rng = _r.Random(seed)
    return rng


# ────────────────────────────────────────────────────────────────────
# FUNC: _demo_int
# ────────────────────────────────────────────────────────────────────
def _demo_int(lo, hi, label=""):  return _demo_seed(label).randint(lo, hi)


# ────────────────────────────────────────────────────────────────────
# FUNC: _demo_float
# ────────────────────────────────────────────────────────────────────
def _demo_float(lo, hi, label=""): return _demo_seed(label).uniform(lo, hi)
# ─────────────────────────────────────────────────────────────────────

# ── P4-9: Central QSS colour palette ─────────────────────────────────
# All setStyleSheet() calls should reference these constants so the
# dark-mode theme can be changed in one place.


# ────────────────────────────────────────────────────────────────────
# CLASS: _QSS
# ────────────────────────────────────────────────────────────────────
class _QSS:
    """Single source of truth for all Qt stylesheet colours.

    Citadel-grade Dark Pro palette — emerald accent (#10B981) on charcoal (#0A0E14).
    Updated for v3.0 redesign. All existing attribute names preserved for backward compat.
    """
    # ── Accent (Emerald) — primary action / bullish / success ──
    GREEN       = "#10B981"   # primary accent — emerald (was #26a641)
    GREEN_BRIGHT= "#34D399"   # bright accent for highlights
    GREEN_4     = "#10B981"   # alias (Material-style name)
    GREEN_DARK  = "#0D8F66"   # dim/hover accent
    GREEN_SUCCESS = "#10B981" # alias
    TEAL        = "#10B981"   # alias (teal→emerald)

    # ── Danger (Red) — bearish / loss / error ──
    RED         = "#EF4444"   # danger red (was #da3633)
    RED_ALT     = "#F87171"   # bright red
    RED_4       = "#EF4444"   # alias
    RED_DANGER  = "#DC2626"   # dark danger

    # ── Warning (Amber) — sideways regime / caution ──
    GOLD        = "#F59E0B"   # warning amber (was #e3b341)
    AMBER       = "#F59E0B"   # alias
    AMBER_ALT   = "#D97706"   # dim amber
    YELLOW      = "#FBBF24"   # bright yellow
    ORANGE      = "#F59E0B"   # alias
    GOLD2       = "#D97706"   # secondary gold
    GOLD_BRIGHT = "#FBBF24"   # bright gold

    # ── Info (Blue) ──
    BLUE        = "#3B82F6"   # info blue
    BLUE_MUTED  = "#60A5FA"   # muted blue
    CYAN        = "#06B6D4"   # cyan accent

    # ── Text ──
    TEXT        = "#E6EDF3"   # primary text (was #d0d0d0)
    MUTED       = "#8B949E"   # secondary text (was #6e7681)
    MUTED2      = "#6B7280"   # muted text
    MUTED3      = "#4B5563"   # tertiary muted
    MUTED_GRAY  = "#8B949E"   # alias
    MUTED_LIGHT = "#B1BAC4"   # light-muted label on dark cards
    WHITE       = "#FFFFFF"
    BLACK       = "#0A0E14"   # now charcoal (was #000000)

    # ── Backgrounds ──
    BG_BASE     = "#0A0E14"   # app background (charcoal)
    BG_CARD     = "#131820"   # card background
    BG_SURFACE  = "#1A2028"   # elevated surface
    BG_NAVY       = "#131820"   # alias (was navy, now charcoal)
    BG_BLUE_DEEP  = "#0F141B"   # input bg
    BG_GREEN_DEEP = "#0D1F1A"   # subtle green-tinted bg
    BG_SLATE      = "#131820"   # alias

    # ── Borders ──
    BORDER_DARK = "#1F2730"   # subtle border (was #30363d)
    BORDER_MID  = "#2A3441"   # default border
    # Common alias used in some places
# ─────────────────────────────────────────────────────────────────────

f_QSS = _QSS


# ─────────────────────────────────────────────────────────────────────────────
from contextlib import redirect_stderr, redirect_stdout
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed

# B11-fix: DaemonThreadPoolExecutor was defined here (line ~277) AND again as
# _DaemonThreadPoolExecutor at line ~451. The two were identical except for
# thread_name_prefix ("qa-worker" vs "qa_worker"). The public name was unused;
# all call sites used the private one. Remove early duplicate to avoid silent drift.
# A public alias is added below the authoritative _DaemonThreadPoolExecutor class.
import concurrent.futures as _cfmod  # keep import for downstream code

from datetime import datetime
from io import StringIO
from pathlib import Path

try:
    import dimod
except ImportError:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    dimod = None
try:
    import neal
except ImportError:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    neal = None
import numpy as np
import pandas as pd
try:
    import requests
except ImportError:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    requests = None
try:
    import yfinance as yf
except ImportError:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    yf = None
try:
    from qa_data import get_provider as _get_data_provider
    _DATA_PROVIDER = _get_data_provider()
except ImportError as _e:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception in %s", "ImportError", exc_info=True)  # noqa: E501
    _DATA_PROVIDER = None

def get_provider():
    return _DATA_PROVIDER

def set_provider(provider):
    global _DATA_PROVIDER
    _DATA_PROVIDER = provider
    import sys
    for mod_name, mod in list(sys.modules.items()):
        if mod and hasattr(mod, '_DATA_PROVIDER'):
            try:
                mod._DATA_PROVIDER = provider
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                pass
try:
    from qa_db import get_store as _get_db_store
    _DB_STORE = _get_db_store()
except ImportError as _e:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception in %s", "ImportError", exc_info=True)  # noqa: E501
    _DB_STORE = None   # graceful fallback — direct sqlite functions still active

# Deliberately deferred imports from data_layer are performed locally in functions
# (e.g. download_multitimeframe_ohlcv_bundle, safe_download) to prevent circular dependency
# chain (data_layer -> universe -> utils -> data_layer).


try:
    from PIL import Image
    HAS_PIL = True
except ImportError as _e:
    Image = None
    import logging as _lg; _lg.getLogger(__name__).debug('Optional import unavailable: from PIL import Image')  # P8
    HAS_PIL = False

MPL_RUNTIME_DIR = Path(tempfile.gettempdir()) / "quantum_annealer_mplconfig"
MPL_RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
XDG_CACHE_DIR = Path(tempfile.gettempdir()) / "quantum_annealer_cache"
XDG_CACHE_DIR.mkdir(parents=True, exist_ok=True)
os.environ.setdefault("MPLCONFIGDIR", str(MPL_RUNTIME_DIR))
os.environ.setdefault("XDG_CACHE_HOME", str(XDG_CACHE_DIR))

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    HAS_MATPLOTLIB = True
except Exception as _e:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception in %s", "Exception", exc_info=True)  # noqa: E501
    HAS_MATPLOTLIB = False

if "QT_API" not in globals() or QT_API is None or QT_API == "stub":
    QT_API = None
    try:
        from PySide6.QtCore import (
            Qt, QThread, Signal, QUrl, QLocale, QTimer, QPoint, QRectF, QPointF,
            QSize, QObject, QDate, QMetaObject, Q_ARG,
        )
        from PySide6.QtGui import (
            QFont, QColor, QPainter, QPainterPath,
            QLinearGradient, QRadialGradient, QBrush, QPen, QPixmap,
            QGuiApplication, QIcon, QKeySequence,
        )
        from PySide6.QtWidgets import (
            QApplication, QAbstractSpinBox, QAbstractItemView, QCheckBox, QComboBox,
            QDoubleSpinBox, QFileDialog, QFormLayout, QFrame, QGridLayout, QHBoxLayout,
            QHeaderView, QLabel, QLineEdit, QListWidget, QListWidgetItem, QMainWindow,
            QMessageBox, QPushButton, QPlainTextEdit, QProgressBar, QScrollArea,
            QSizePolicy, QSpinBox, QStackedWidget, QSplitter, QTableWidget,
            QTableWidgetItem, QDialog, QTabWidget, QToolButton, QProxyStyle, QVBoxLayout,
            QWidget, QCalendarWidget, QDialogButtonBox, QGroupBox, QInputDialog,
            QMenu, QRadioButton, QScrollBar, QSlider, QStatusBar, QTabBar,
            QTableView, QTextEdit, QToolTip, QStyleFactory,
        )
        pyqtSignal = Signal
        QT_API = "PySide6"
        HAS_WEBENGINE = False
        QWebEngineView = None
    except Exception:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
        pass

# D9-FIX: Hard-fail immediately if neither binding loaded.
# The bare `QT_API = None` above the try/except means a double-import failure
# leaves QT_API=None and every subsequent binding-dependent import silently crashes.
if QT_API is None:
    QT_API = "stub"   # headless mode

# P1-A: guard — QT_API must be a recognised binding string
# QShortcut location varies across PySide6 versions — resolve at runtime
try:
    from PySide6.QtWidgets import QShortcut
except ImportError as _e:
    try:
        from PySide6.QtGui import QShortcut
    except ImportError as _e:
        try:
            from PyQt5.QtWidgets import QShortcut
        except Exception as _e:
            import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception in %s", "Exception", exc_info=True)  # noqa: E501
            QShortcut = None
except Exception as _e:
    # QT_API is already set by the main Qt import block above — no re-import needed.
    if QT_API == 'PyQt5':
        try:
            from PyQt5.QtWidgets import QShortcut
        except ImportError as _e:
            QShortcut = None
            import logging as _lg; _lg.getLogger(__name__).debug('Optional import unavailable: from PyQt5.QtWidgets import QShortcut')  # P8
    else:
        QShortcut = None
    Signal = pyqtSignal  # unified alias — ALL new classes must use Signal(), never pyqtSignal()
# TECH-DEBT M-05: 16 existing classes still use raw pyqtSignal — replace with pyqtSignal()
    HAS_WEBENGINE = False  # resolved lazily after QApplication exists
    QWebEngineView = None  # placeholder

# ── Bug-26-FIX: HAS_WEBENGINE must always be defined regardless of exception paths.
# The second Qt block above sets it False inside a try/except, which means it is
# undefined if neither branch executes. Set a sentinel default here, then try to
# resolve the actual value lazily by importing QWebEngineView.
if "HAS_WEBENGINE" not in globals():
    HAS_WEBENGINE = False
if "QWebEngineView" not in globals():
    QWebEngineView = None
try:
    from PySide6.QtWebEngineWidgets import QWebEngineView as _QWE
    HAS_WEBENGINE = True
    QWebEngineView = _QWE
except ImportError:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    pass  # HAS_WEBENGINE stays False; QWebEngineView stays None

# ~1,746 direct widget.setText() / widget.setHtml() calls exist in the codebase,
# some fired from worker threads. Qt crashes when GUI objects are mutated off the
# main thread. We install a module-level wrapper that transparently re-routes
# off-thread calls through QMetaObject.invokeMethod(QueuedConnection) while
# keeping on-main-thread calls as fast direct calls.
# All new code should use UIUpdateGuard.set_text(); this guard is the safety net
# for the ~1,746 legacy call sites that cannot all be audited at once.


# ────────────────────────────────────────────────────────────────────
# FUNC: _install_thread_safe_widget_guard
# ────────────────────────────────────────────────────────────────────
def _install_thread_safe_widget_guard():
    """Monkey-patch QLabel / QLineEdit / QTextEdit / QPlainTextEdit to auto-route
    setText() and setHtml() through the Qt event loop when called from a worker thread."""
    import threading as _thr

    def _make_safe(original_method, method_name):
        def _safe(self_widget, text, *args, **kwargs):
            if _thr.current_thread() is _thr.main_thread():
                return original_method(self_widget, text, *args, **kwargs)
            try:
                QTimer.singleShot(0, lambda: original_method(self_widget, text, *args, **kwargs))
            except Exception as _e:
                # Last-resort: silently drop the off-thread call rather than crash.
                ExceptionLogger.swallow(_e, context='auto-EXC002')
        _safe.__name__ = method_name
        return _safe

    _GUARD_TARGETS = []
    for _cls_name in ("QLabel", "QLineEdit", "QTextEdit", "QPlainTextEdit"):
        _cls = globals().get(_cls_name)
        if _cls is None:
            continue
        for _meth in ("setText", "setHtml"):
            _orig = getattr(_cls, _meth, None)
            if _orig is not None:
                try:
                    setattr(_cls, _meth, _make_safe(_orig, _meth))
                    _GUARD_TARGETS.append(f"{_cls_name}.{_meth}")
                except (TypeError, AttributeError) as _e:
                    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception in %s", "Exception", exc_info=True)  # noqa: E501
                    pass  # some bindings don't allow patching — skip silently

    if _GUARD_TARGETS:
        import logging as _gl
        _gl.getLogger("quantum_annealer.arch").info(
            "M-06 thread-safe guard installed on: %s", ", ".join(_GUARD_TARGETS))

_install_thread_safe_widget_guard()
del _install_thread_safe_widget_guard
# ─────────────────────────────────────────────────────────────────────────────


try:
    from sklearn.covariance import LedoitWolf as _LedoitWolf
    HAS_SKLEARN = True
except ImportError as _e:
    HAS_SKLEARN = False
    import logging as _lg; _lg.getLogger(__name__).debug('Optional import unavailable: from sklearn.covariance import LedoitWolf as _LedoitWolf')  # P8

try:
    from sklearn.cluster import MiniBatchKMeans as _MiniBatchKMeans
    HAS_SKLEARN_CLUSTER = True
except ImportError as _e:
    HAS_SKLEARN_CLUSTER = False
    import logging as _lg; _lg.getLogger(__name__).debug('Optional import unavailable: from sklearn.cluster import MiniBatchKMeans as _MiniBatchKMe')  # P8

# Targeted warning filters — do NOT use bare filterwarnings('ignore')
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=DeprecationWarning, module="yfinance")
warnings.filterwarnings("ignore", category=DeprecationWarning, module="pandas")
warnings.filterwarnings("ignore", message=".*DataFrame is highly fragmented.*")
warnings.filterwarnings("ignore", message=".*The default dtype for empty Series.*")


# ── Daemon-safe ThreadPoolExecutor ─────────────────────────────────
import concurrent.futures as _cf_mod
import threading as _thr_mod


# ────────────────────────────────────────────────────────────────────
# CLASS: _DaemonThreadPoolExecutor
# ────────────────────────────────────────────────────────────────────
class _DaemonThreadPoolExecutor(_cf_mod.ThreadPoolExecutor):
    """Drop-in ThreadPoolExecutor wrapper.

    Python 3.9+ ThreadPoolExecutor shuts down cleanly via atexit and
    WorkerLifecycle.shutdown_all(), so no daemon-thread manipulation is
    needed or safe.  Setting thread.daemon=True inside an initializer
    raises RuntimeError on Python 3.11+ because the thread is already in
    the 'started' state by the time the initializer runs, which breaks the
    entire pool with BrokenThreadPool.  This wrapper simply forwards all
    arguments unchanged.
    """

    def __init__(self, *args, **kwargs):
        kwargs.setdefault("thread_name_prefix", "qa_worker")
        super().__init__(*args, **kwargs)

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            self.shutdown(wait=False, cancel_futures=True)
            return False
        return super().__exit__(exc_type, exc_val, exc_tb)

# B11-fix: public alias so any external code referencing DaemonThreadPoolExecutor
# (the old duplicated class) still works without the redundant definition.
DaemonThreadPoolExecutor = _DaemonThreadPoolExecutor


# ── P2-D: ConcurrencyPolicy ── single source of truth for all thread pools


# ────────────────────────────────────────────────────────────────────
# CLASS: ConcurrencyPolicy
# ────────────────────────────────────────────────────────────────────
class ConcurrencyPolicy:
    """Centralised concurrency budget.
    Slots: download (Yahoo rate-limit safe=1), compute (cpu_count),
           io (file/DB/Telegram=4), network (misc HTTP=2).
    """
    _policy = None
    _lock = None
    _DEFAULTS = {"download": 8, "compute": None, "io": 4, "network": 4}

    @classmethod
    def _get(cls) -> dict:
        import threading as _thr, os as _os
        # AUDIT-FIX (Round 4 — E1129): bind to a local so static analyzers
        # (and readers) can see the lock is guaranteed non-None before the
        # `with` block executes.
        if cls._lock is None:
            cls._lock = _thr.Lock()
        _lock = cls._lock
        # pylint: disable=not-context-manager
        # (pylint can't prove _lock is non-None despite the assignment above)
        with _lock:
            if cls._policy is None:
                p = dict(cls._DEFAULTS)
                p["compute"] = p["compute"] or (_os.cpu_count() or 2)
                cls._policy = p
        return cls._policy

    @classmethod
    def workers(cls, slot: str, cfg=None) -> int:
        if slot == "download":
            # 16 parallel threads is optimal for macOS pthread kernel limits
            provider = (cfg or {}).get("DATA_PROVIDER", "")
            if provider == "DhanHQ" or (cls._policy and cls._policy.get("_IS_DHAN")):
                return 16
        base = cls._get().get(slot, 2)
        if cfg is not None:
            key_map = {
                "download": "DOWNLOAD_WORKERS",
                "compute":  "COMPUTE_WORKERS",
                "io":       "IO_WORKERS",
                "network":  "NSE_NETWORK_WORKERS",
            }
            cfg_key = key_map.get(slot)
            if cfg_key:
                override = (cfg or {}).get(cfg_key)
                if override is not None:
                    try: return max(1, int(override))
                    except (TypeError, ValueError) as _e:
                        ExceptionLogger.swallow(_e, context='auto-EXC002')
        return max(1, base)

    @classmethod
    def configure(cls, **kwargs):
        policy = cls._get()
        # AUDIT-FIX (Round 4 — E1137): pylint can't infer that
        # `cls._get()` returns a `dict` (the class-level `_policy = None`
        # confuses it). The runtime type IS dict; the explicit cast below
        # is documentation more than anything.
        if not isinstance(policy, dict):
            return
        for k, v in kwargs.items():
            if k in policy:
                # pylint: disable=unsupported-assignment-operation
                # (pylint can't infer policy is dict from cls._get(); the
                # isinstance check above guarantees it at runtime)
                policy[k] = max(1, int(v))


# ────────────────────────────────────────────────────────────────────
# FUNC: _widget_alive
# ────────────────────────────────────────────────────────────────────
def _widget_alive(widget) -> bool:
    """Return True if the Qt C++ object behind *widget* has not been deleted."""
    if widget is None:
        return False
    try:
        # PySide6: shiboken2/shiboken6 isValid check
        import shiboken6
        return shiboken6.isValid(widget)
    except ImportError as _e:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception in %s", "ImportError", exc_info=True)  # noqa: E501
        pass  # _arch_log removed (LOG003)
    try:
        # PyQt5 fallback: sip.isdeleted
        import sip
        return not sip.isdeleted(widget)
    except ImportError as _e:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception in %s", "ImportError", exc_info=True)  # noqa: E501
        pass  # _arch_log removed (LOG003)
    # Last resort: attempt a harmless method call
    try:
        widget.objectName()
        return True
    except RuntimeError as _e:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception in %s", "RuntimeError", exc_info=True)  # noqa: E501
        return False

APP_NAME = "Quantum Annealer — Pinnacle SOTA Edition"
APP_VERSION = "1.0.0"
PROJECT_DIR = Path(__file__).resolve().parent
BASE_DIR = PROJECT_DIR
ARTIFACTS_DIR = PROJECT_DIR / "artifacts"
ARTIFACTS_DIR.mkdir(parents=True, exist_ok=True)
SPIN_UP_DARK_SVG = (PROJECT_DIR / "spin_up_dark.svg").resolve()
SPIN_DOWN_DARK_SVG = (PROJECT_DIR / "spin_down_dark.svg").resolve()
SPIN_UP_LIGHT_SVG = (PROJECT_DIR / "spin_up_light.svg").resolve()
SPIN_DOWN_LIGHT_SVG = (PROJECT_DIR / "spin_down_light.svg").resolve()

# ═══════════════════════════════════════════════════════════════════════════
# DYNAMIC CONSTANTS — single source of truth for all magic numbers.
# ═══════════════════════════════════════════════════════════════════════════

# ── Network ─────────────────────────────────────────────────────────────────
HTTP_TIMEOUT_SHORT   = 10    # seconds — quick checks (VIX, FII ping)
HTTP_TIMEOUT_MEDIUM  = 15    # seconds — standard API calls
HTTP_TIMEOUT_LONG    = 25    # seconds — CSV downloads, large payloads
HTTP_RETRY_BACKOFF   = 0.8   # base multiplier for exponential back-off
NSE_SESSION_SLEEP    = 0.5   # seconds — polite delay between NSE API calls

# ── Technical analysis ───────────────────────────────────────────────────────
RSI_PERIOD           = 14    # standard Wilder RSI period
RSI_OVERSOLD         = 30    # below → oversold / potential buy signal
RSI_OVERBOUGHT       = 70    # above → overbought / potential sell signal
ADX_TREND_MIN        = 20    # minimum ADX to confirm trend strength
MA_SHORT_PERIOD      = 20    # default short-term moving average
MA_LONG_PERIOD       = 50    # default long-term moving average

# ── Portfolio / risk ─────────────────────────────────────────────────────────
DEFAULT_PORTFOLIO_VALUE  = 1_000_000    # INR — fallback when cfg not available
STRESS_PORTFOLIO_VALUE   = 10_000_000   # INR — default for stress-test panels
VALIDATION_LAG_DAYS      = 21           # trading days before alpha IC validation
MAX_DRAWDOWN_LOOKBACK    = 252          # trading days for drawdown window
WFO_DEFAULT_IS_MONTHS    = 12           # walk-forward in-sample window (months)
WFO_DEFAULT_OOS_MONTHS   = 3            # walk-forward out-of-sample window (months)

# ── Simulation ───────────────────────────────────────────────────────────────
DEFAULT_RANDOM_SEED      = 42           # reproducible seed for all demo/MC panels

# ── Financial calculation constants ──────────────────────────────
TRADING_DAYS_PER_YEAR  = 252      # trading days used for annualisation
CALENDAR_DAYS_PER_YEAR = 365      # calendar days for tax / coupon calc
Z_SCORE_95             = 1.96     # 95% confidence interval z-score
Z_SCORE_90             = 1.645    # 90% confidence interval z-score
SIGNIFICANCE_LEVEL     = 0.05     # default alpha for hypothesis tests
SHORT_TERM_TAX_DAYS    = 365      # holding period threshold for STCG (India)

MONTE_CARLO_DEFAULT_RUNS = 1000         # simulations for Monte-Carlo panels


NSE_EQUITY_CSV_URL = "https://archives.nseindia.com/content/equities/EQUITY_L.csv"
BENCHMARK_FALLBACKS = ["^NSEI", "NIFTYBEES.NS", "^BSESN"]
NSE_FNO_BAN_URL   = "https://archives.nseindia.com/content/fo/fo_secban.csv"  # fixed: was hedgefunds.json (wrong endpoint)
NSE_FNO_BAN_URL2  = "https://nseindia.com/api/equity-stockIndices?index=SECURITIES%20IN%20F%26O%20BAN%20PERIOD"
NSE_BHAV_URL      = "https://archives.nseindia.com/products/content/sec_bhavdata_full_{date}.csv"
NSE_FII_DII_URL        = "https://www.nseindia.com/api/fiidiiTradeReact"
NSE_INDIA_VIX_URL      = "https://www.nseindia.com/api/allIndices"
NSE_CORP_ACTIONS_URL   = "https://archives.nseindia.com/content/equities/CA_announced.csv"
NSE_OPTIONS_URL        = "https://www.nseindia.com/api/option-chain-equities?symbol={symbol}"
SCREENER_COMPANY_URL   = "https://www.screener.in/api/company/{symbol}/?format=json"
_LOG_MAX_LINES = 1500
from data.cache_manager import (
    _LAST_YF_WARNING,
    _LAST_YF_WARNING_LOCK,
    _CHART_SSL_MODEL_CACHE,
    _CHART_SSL_MODEL_CACHE_LOCK
)

TAB_PORTFOLIO = 0
TAB_UNIVERSE = 1
TAB_SECTORS = 2
TAB_FACTORS = 3
TAB_EXPOSURES = 4
TAB_SECTOR_RS = 5
TAB_CHANGES = 6
TAB_ALERTS = 7
TAB_CHARTS = 8
TAB_BACKTEST = 9
TAB_DIAGNOSTICS = 10
TAB_CORRELATION = 11
TAB_HISTORY = 12
TAB_ALERT_LOG    = 13
TAB_LOGS         = 14
TAB_RISK         = 15
TAB_EXECUTION    = 16
TAB_MRC          = 17
TAB_FACTOR_ATTR  = 18
TAB_PRESCREEN    = 19  # reserved — was duplicate TAB_WATCHLIST
TAB_LIVE_PNL     = 20
TAB_BREAKOUT     = 21  # Early Breakout stocks
TAB_PREBREAKOUT  = 22  # Pre-Breakout stocks
TAB_RESERVED_23  = 23  # reserved index — do not reuse
TAB_AUDIT_LOG    = 24  # Approval + OOS audit (AuditLogPanel)
TAB_RESERVED_25  = 25  # reserved index — do not reuse
TAB_RESERVED_26  = 26  # reserved index — do not reuse
TAB_BT_COMPARE   = 27  # BacktestComparisonPanel
TAB_HEATMAP      = 28  # PortfolioHeatmapTab
TAB_CORR_HEATMAP = 29  # CorrelationHeatmapRenderer
TAB_FACTOR_DELTA  = 30  # FactorExposureDeltaBar
TAB_SENS_HEATMAP  = 31  # ParameterSensitivityHeatmap
TAB_ALGO_NOTES         = 32  # AlgoNotes
TAB_REGIME_CHART       = 33  # RegimeOverlayChart
TAB_WATCHLIST          = 34  # WatchlistManager
TAB_CONSTRAINT_EDITOR  = 35  # ConstraintEditor
TAB_PERF_ATTR          = 36  # PerformanceAttributionPanel
TAB_SLIPPAGE           = 37  # SlippageSimulator
TAB_SIGNAL_DEBUG       = 38  # SignalDebugger
TAB_EQUITY_CURVE       = 39  # BacktestEquityCurveChart
TAB_TURNOVER           = 40  # TurnoverBudgetTracker
TAB_MACRO_REGIME       = 41  # MacroRegimeDashboard
TAB_FACTOR_TILT        = 42  # FactorTiltReport
TAB_REBALANCE_CAL      = 43  # RebalanceCalendarWidget
TAB_TRADE_TICKET       = 44  # TradeTicketPage
TAB_POSITION_SIZER          = 45  # PositionSizerPanel
TAB_CHART_PATTERN_SCREENER  = 46  # ChartPatternScreener (LatentSpaceScreener UI)  [BUG21-FIX: was missing, causing gap]
TAB_NOTIFICATION_CTR        = 47  # NotificationCentrePanel
TAB_RISK_BUDGET        = 48  # RiskBudgetGauge
TAB_STRESS_TEST        = 49  # StressTestPanel
TAB_INSTRUMENT_DETAIL  = 50  # InstrumentDetailCard
TAB_OPT_PROGRESS       = 51  # PortfolioOptimiserProgressPanel
TAB_ORDER_RECON        = 52  # OrderBookReconPanel
TAB_QUANT_NOTEBOOK     = 53  # QuantResearchNotebook
TAB_VIX_REGIME         = 54  # VolatilityRegimeBadge
TAB_COMMENTARY         = 55  # PortfolioCommentaryGenerator
TAB_PARETO_FRONTIER    = 56  # MultiObjectiveFrontierChart
TAB_REGIME_CALENDAR    = 57  # RegimeCalendarHeatmap
TAB_TG_COMPOSER        = 58  # TelegramAlertComposer
TAB_SECTOR_RADAR       = 59  # SectorMomentumRadarChart
TAB_PARAM_WIZARD       = 60  # ParameterTuningWizard
TAB_HEALTH_SCORECARD   = 61  # PortfolioHealthScorecard
TAB_EXPOSURE_DRIFT     = 62  # ExposureDriftMonitor
TAB_WFO_PANEL          = 63  # WalkForwardSimulatorPanel
TAB_CONCENTRATION      = 64  # PortfolioConcentrationRiskPanel
TAB_FACTOR_CROWDING    = 65  # FactorCrowdingMonitor
TAB_BOOTSTRAP          = 66  # BootstrapConfidencePanel
TAB_SCENARIO_LIB       = 67  # ScenarioStressLibrary
TAB_ALPHADECAYANALYSER          = 68  # AlphaDecayAnalyser
TAB_PORTFOLIOTURNOVEROPTIMIS    = 69  # PortfolioTurnoverOptimiser
TAB_LIVECORRELATIONMONITOR      = 70  # LiveCorrelationMonitor
TAB_MOMENTUMCYCLEANALYSER       = 71  # MomentumCycleAnalyser
TAB_PORTFOLIOREGIMESENSITIVI    = 72  # PortfolioRegimeSensitivityMatrix
TAB_LIQUIDITYSCORECARD          = 73  # LiquidityScorecard
TAB_OPTIONSEXPIRYIMPACTPANEL    = 74  # OptionsExpiryImpactPanel
TAB_SECTORFUNDAMENTALSCORECA    = 75  # SectorFundamentalScorecard
TAB_PORTFOLIOCONSTRUCTIONAUD    = 76  # PortfolioConstructionAudit
TAB_QUANTJOURNALPANEL           = 77  # QuantJournalPanel
TAB_STRATEGYLEADERBOARD         = 78  # StrategyLeaderboard
TAB_PORTFOLIOBLOTTERPANEL       = 79  # PortfolioBlotterPanel
TAB_LIVEGREEKSPANEL             = 80  # LiveGreeksPanel
TAB_IVSURFACEPANEL              = 81  # IVSurfacePanel
TAB_RESERVED_82                 = 82  # Reserved index to prevent gaps
TAB_MARGINCALCULATOR            = 83  # MarginCalculator
TAB_BROKERPNLRECONCILER         = 84  # BrokerPnLReconciler
TAB_PLEDGEMANAGER               = 85  # PledgeManager
TAB_MLALPHASIGNALPANEL          = 86  # MLAlphaSignalPanel
TAB_FEATUREIMPORTANCEPANEL      = 87  # FeatureImportancePanel
TAB_SHAPEXPLAINERPANEL          = 88  # SHAPExplainerPanel
TAB_MULTIACCOUNTMANAGER         = 89  # MultiAccountManager
TAB_SUBPORTFOLIOTRACKER         = 90  # SubPortfolioTracker
TAB_ALLOCATIONDRIFTMONITOR      = 91  # AllocationDriftMonitor
TAB_THEMEMANAGER                = 92  # ThemeManager
TAB_SETTINGSEXPORTIMPORT        = 94  # SettingsExportImport
TAB_LIVEMARKETSCANNERPANEL      = 95  # LiveMarketScannerPanel
TAB_CORPACTIONTRACKER           = 98  # CorpActionTracker
TAB_INSIDERACTIVITYPANEL        = 99  # InsiderActivityPanel
TAB_FIIACTIVITYMONITOR          = 101  # FIIActivityMonitor
TAB_SHORTSELLINGTRACKER         = 102  # ShortSellingTracker
TAB_CIRCUITBREAKERPANEL         = 103  # CircuitBreakerPanel
TAB_GLOBALMACROPANEL            = 104  # GlobalMacroPanel
TAB_COMMODITYCORRELATIONTRACK   = 105  # CommodityCorrelationTracker
TAB_CURRENCYHEDGEADVISOR        = 106  # CurrencyHedgeAdvisor
TAB_NEWSIMPACTTRACKER           = 107  # NewsImpactTracker
TAB_ECONOMICCALENDARPANEL       = 108  # EconomicCalendarPanel
TAB_REGULATORYALERTPANEL        = 109  # RegulatoryAlertPanel
TAB_INSIDERTRADINGMONITOR       = 110  # InsiderTradingMonitor
TAB_PROMOTERPLEDGETRACKER       = 111  # PromoterPledgeTracker
TAB_INSTITUTIONALOWNERSHIPPANEL = 112  # InstitutionalOwnershipPanel
TAB_DEBTMATURITYTRACKER        = 113  # DebtMaturityTracker
TAB_DIVIDENDYIELDSCANNER       = 115  # DividendYieldScanner
TAB_QUANTFACTORSCORER         = 116  # QuantitativeFactorScorer
TAB_PAIRSTRADINGMONITOR       = 117  # PairsTradingMonitor
TAB_STATISTICALARBITRAGEPANEL = 118  # StatisticalArbitragePanel
TAB_FULLSETTINGSOVERHAUL      = 119  # FullSettingsOverhaul
TAB_THEMESWITCHER             = 120  # ThemeSwitcher
TAB_KEYBOARDSHORTCUTPANEL     = 121  # KeyboardShortcutPanel
TAB_BUGHARDENINGDASHBOARD     = 122  # BugHardeningDashboard
TAB_ERRORBOUNDARYPANEL        = 123  # ErrorBoundaryPanel
TAB_THREADSAFETYAUDITPANEL    = 124  # ThreadSafetyAuditPanel
TAB_LAZYTABLOADER             = 125  # LazyTabLoader
TAB_STARTUPPROFILER           = 126  # StartupProfilerPanel
TAB_UXREFINEMENTPANEL         = 127  # UXRefinementPanel
TAB_EDGECASEHARDENINGPANEL    = 128  # EdgeCaseHardeningPanel
TAB_DATAINTEGRITYCHECKER      = 129  # DataIntegrityChecker
TAB_SESSIONRECOVERYPANEL      = 130  # SessionRecoveryPanel
TAB_SIGNALDIAGNOSTICSPANEL    = 131  # SignalDiagnosticsPanel
TAB_REGIMEOVERLAYAUDITPANEL   = 132  # RegimeOverlayAuditPanel
TAB_EXPORTHARDENINGPANEL      = 133  # ExportHardeningPanel
TAB_CORRELATIONBREAKDOWNPANEL = 134  # CorrelationBreakdownPanel
TAB_TAILRISKSCENARIO          = 135  # TailRiskScenarioPanel
TAB_PORTFOLIOCONSTRUCTIONAUDIT= 136  # PortfolioConstructionAudit
TAB_NEWSALPHAPANEL            = 137  # NewsAlphaPanel
TAB_EARNINGSCALENDARPANEL     = 138  # EarningsCalendarPanel
TAB_INSIDERACTIVITYMONITOR    = 139  # InsiderActivityMonitor
TAB_ORDERMANAGEMENTPANEL      = 140  # OrderManagementPanel
TAB_EXECUTIONALGORITHMPANEL   = 141  # ExecutionAlgorithmPanel
TAB_TRANSACTIONCOSTANALYSER   = 142  # TransactionCostAnalyser
TAB_SEBIAUDITLOGPANEL         = 143  # SEBIAuditLogPanel
TAB_POSITIONLIMITCHECKER      = 144  # PositionLimitChecker
TAB_PRETRADECOMPLIANCESCREEN  = 145  # PreTradeComplianceScreen
TAB_DEBTBONDSCREENER           = 146  # DebtBondScreener
TAB_ETFOVERLAPANALYSER         = 147  # ETFOverlapAnalyser
TAB_COMMODITYCORRELATIONPANEL  = 148  # CommodityCorrelationPanel
TAB_REALESTATEREITTRACKER     = 149  # RealEstateREITTracker
TAB_CRYPTOSENTIMENTBRIDGE     = 150  # CryptoSentimentBridge
TAB_GLOBALEQUITYHEATMAP       = 151  # GlobalEquityHeatmap
TAB_ALTERNATIVEDATADASHBOARD  = 152  # AlternativeDataDashboard
TAB_PORTFOLIOCLIMATERISKPANEL = 153  # PortfolioClimateRiskPanel
TAB_QUANTSTRATEGYLIBRARY      = 154  # QuantStrategyLibrary
TAB_PORTFOLIOXRAYPANEL        = 155  # PortfolioXRayPanel
TAB_LIVENEWSTICKERPANEL       = 156  # LiveNewsTickerPanel
TAB_QUANTRESEARCHWORKBENCH    = 157  # QuantResearchWorkbench
TAB_OPTIONSFLOWSCANNER        = 158  # OptionsFlowScanner
TAB_EARNINGSCALENDARTRACKER   = 159  # EarningsCalendarTracker
TAB_MARKETMICROSTRUCTUREPANEL = 160  # MarketMicrostructurePanel
TAB_FIIDIIFLOWANALYTICS       = 161  # FIIDIIFlowAnalytics
TAB_BONDYIELDCURVEPANEL       = 163  # BondYieldCurvePanel
TAB_INSIDERTRANSACTIONMONITOR = 165  # InsiderTransactionMonitor
TAB_CORPORATEACTIONCALENDAR   = 166  # CorporateActionCalendar
TAB_QUANTPORTFOLIOSIMULATOR   = 168  # QuantPortfolioSimulator
TAB_ALGOSTRATEGYBACKTESTER    = 170  # AlgoStrategyBacktester
TAB_DERIVATIVESGREEKSDASHBOARD= 172  # DerivativesGreeksDashboard
TAB_ECONOMICINDICATORTRACKER  = 174  # EconomicIndicatorTracker
TAB_ESGSUSTAINABILITYSCORER   = 175  # ESGSustainabilityScorer
TAB_REALESTATEREITSANALYSER   = 178  # RealEstateREITAnalyser
TAB_GOLDSILVERCOMMODITYDESK   = 179  # GoldSilverCommodityDesk
TAB_PORTFOLIOATTRIBUTIONENGINE= 180  # PortfolioAttributionEngine
TAB_VOLATILITYREGIMEDETECTOR  = 181  # VolatilityRegimeDetector
TAB_LIQUIDITYSTRESSTESTPANEL  = 182  # LiquidityStressTestPanel
TAB_NEWSALPHAEXTRACTOR        = 183  # NewsAlphaExtractor
TAB_INSIDERTRADINGTRACKER     = 184  # InsiderTradingTracker
TAB_MUTUALFUNDOVERLAPANALYSER = 185  # MutualFundOverlapAnalyser
TAB_IPOPIPELINEMONITOR        = 186  # IPOPipelineMonitor
TAB_SECTORROTATIONCLOCK       = 187  # SectorRotationClock
TAB_DIVIDENDINCOMEPROJECTER   = 188  # DividendIncomeProjector
TAB_STOCHASTICOSCILLATORSCANNER = 189  # StochasticOscillatorScanner
TAB_FIIDIIACTIVITYMONITOR       = 190  # FIIDIIActivityMonitor
TAB_QUANTSCREENERBACKTESTER     = 191  # QuantScreenerBacktester
TAB_BONDYIELDCURVEANALYSER      = 192  # BondYieldCurveAnalyser
TAB_WEALTHGOALPLANNER           = 193  # WealthGoalPlanner
TAB_CORRELATIONHEATMAPPANEL     = 194  # CorrelationHeatmapPanel
TAB_POSITIONSIZINGCALCULATOR    = 195  # PositionSizingCalculator
TAB_CANDLESTICKPATTERNSCANNER   = 196  # CandlestickPatternScanner
TAB_MACROCALENDAREVENTTRACKER   = 197  # MacroCalendarEventTracker
TAB_CONVERTIBLEBONDTRACKER      = 199  # ConvertibleBondTracker
TAB_TAXHARVESTINGOPTIMISER      = 200  # TaxHarvestingOptimiser
TAB_GLOBALMARKETPULSE2          = 201  # GlobalMarketPulse
TAB_ALGOORDERFLOWANALYSER       = 202  # AlgoOrderFlowAnalyser
TAB_MULTITIMEFRAMECONFLUENCE    = 203  # MultiTimeframeConfluence
TAB_VOLATILITYARBITRAGEPANEL    = 204  # VolatilityArbitragePanel
TAB_ROLLOVERANALYSISPANEL       = 205  # RolloverAnalysisPanel
TAB_FUTURESBASISTRACKER         = 206  # FuturesBasisTracker
TAB_ETFARBITRAGEMONITOR         = 208  # ETFArbitrageMonitor
TAB_SMARTMONEYCONCEPTSPANEL     = 209  # SmartMoneyConceptsPanel
TAB_SUPPLYDEMANZONEMAP          = 210  # SupplyDemandZoneMap
TAB_VOLUMEPROFILEANALYSER       = 211  # VolumeProfileAnalyser
TAB_MARKETBREATHDASHBOARD       = 212  # MarketBreadthDashboard
TAB_ELLIOTTWAVETRACKER          = 213  # ElliottWaveTracker
TAB_HEATMAPSECTORROTATION       = 214  # HeatmapSectorRotation
TAB_QUANTSCREENERPRO            = 215  # QuantScreenerPro
TAB_MONTECARLOPORTFOLIOSIM      = 216  # MonteCarloPortfolioSim
TAB_PORTFOLIOXRAYANALYSER       = 217  # PortfolioXRayAnalyser
TAB_PORTFOLIOOPTIMISERMVP       = 218  # PortfolioOptimiserMVP
TAB_GREEKSDASHBOARDLIVE         = 219  # GreeksDashboardLive
TAB_OPTIONSSTRATEGYBUILDER      = 220  # OptionsStrategyBuilder
TAB_PCRANALYSISPANEL            = 221  # PCRAnalysisPanel
TAB_MAXPAINCALCULATOR           = 222  # MaxPainCalculator
TAB_OPENINTERESTANALYSER        = 223  # OpenInterestAnalyser
TAB_FIIDIIACTIVITYTRACKER       = 224  # FIIDIIActivityTracker
TAB_BONDYIELDMONITOR            = 228  # BondYieldMonitor
TAB_MACROECONOMICCALENDAR       = 229  # MacroEconomicCalendar
TAB_SECTORFUNDAMENTALSCORER     = 230  # SectorFundamentalScorer
TAB_IPOPIPELINETRACKER          = 231  # IPOPipelineTracker
TAB_BULKBLOCKDEALMONITOR        = 232  # BulkBlockDealMonitor
TAB_SHORTSELLINGRADAR           = 233  # ShortSellingRadar
TAB_CIRCUITBREAKERMONITOR       = 234  # CircuitBreakerMonitor
TAB_DELIVERYVOLUMEANALYSER      = 235  # DeliveryVolumeAnalyser
TAB_SPEEDOMETERSENTIMENTGAUGE   = 236  # SpeedometerSentimentGauge
TAB_RISKMANAGEMENTCONSOLE       = 237  # RiskManagementConsole
TAB_TECHNICALSCREENERPRO        = 238  # TechnicalScreenerPro
TAB_EARNINGSWHISPERTRACKER      = 239  # EarningsWhisperTracker
TAB_PROMOTERPLEDGEMONITOR       = 240  # PromoterPledgeMonitor
TAB_MUTUALFUNDFLOWTRACKER       = 241  # MutualFundFlowTracker
TAB_DEMATACCOUNTTRENDS          = 242  # DematAccountTrends
TAB_GLOBALMARKETPULSE           = 243  # GlobalMarketPulse
TAB_COMMODITYDASHBOARD          = 244  # CommodityDashboard
TAB_CURRENCYFOREXMONITOR        = 245  # CurrencyForexMonitor
TAB_BONDYIELDTRACKER            = 246  # BondYieldTracker
TAB_FIIDERIVATIVETRACKER        = 247  # FIIDerivativeTracker
TAB_IPTRACKLERPRO               = 248  # IPOTrackerPro
TAB_SMEIPORADAR                 = 249  # SMEIPORadar
TAB_RIGHTSOFFERINGSTRACKER      = 250  # RightsOfferingsTracker
TAB_QIPOFSMONI                  = 251  # QIPOFSMonitor
TAB_LISTINGGAINANALYZER         = 252  # ListingGainAnalyzer
TAB_DIIFLOWTRACKER              = 253  # DIIFlowTracker
TAB_RETAILPARTICIPATIONINDEX    = 254  # RetailParticipationIndex
TAB_PROPRIETARYTRADINGMONITOR   = 255  # ProprietaryTradingMonitor
TAB_FIICASHEQUITYTRACKER        = 256  # FIICashEquityTracker
TAB_INSTITUTIONALOWNERSHIPSHIFT = 257  # InstitutionalOwnershipShift
TAB_SECTORROTATIONTRACKER      = 258  # SectorRotationTracker
TAB_THEMATICBASKETBUILDER      = 259  # ThematicBasketBuilder
TAB_MARKETBREADTHMONITOR       = 260  # MarketBreadthMonitor
TAB_NEW52WEEKRADAR             = 261  # New52WeekRadar
TAB_MOMENTUMSCOREBOARD         = 262  # MomentumScoreBoard
TAB_QUANTITATIVESTRATEGYLAB    = 263  # QuantitativeStrategyLab
TAB_ALGOORDERFLOWANALYZER      = 264  # AlgoOrderFlowAnalyzer
TAB_PORTFOLIOATTRIBUTION       = 265  # PortfolioAttribution
TAB_BACKTESTRESULTSVIEWER      = 266  # BacktestResultsViewer
TAB_RISKADJUSTEDRETURNS        = 267  # RiskAdjustedReturns
TAB_ESGSCORETRACKER            = 268  # ESGScoreTracker
TAB_SUSTAINABILITYREPORTTRACK  = 269  # SustainabilityReportTracker
TAB_CORPORATEGOVERNANCEMONITOR = 270  # CorporateGovernanceMonitor
TAB_DIVIDENDYIELDTRACKER       = 271  # DividendYieldTracker
TAB_BUYBACKTRACKERPRO          = 272  # BuybackTrackerPro
TAB_CORPORATEBONDTRACKER       = 273  # CorporateBondTracker
TAB_NCDMONITOR                 = 274  # NCDMonitor
TAB_CREDITRATINGMONITOR        = 275  # CreditRatingMonitor
TAB_YIELDCURVEANALYZER         = 276  # YieldCurveAnalyzer
TAB_DEBTMUTUALFUNDRADAR        = 277  # DebtMutualFundRadar
TAB_OPTIONSCHAINVIEWER         = 278  # OptionsChainViewer
TAB_GREEKSDASHBOARD            = 279  # GreeksDashboard
TAB_OPENINTERESTANALYZER       = 280  # OpenInterestAnalyzer
TAB_PCRHEATMAP                 = 281  # PCRHeatmap
TAB_IMPLIEDVOLATILITYTRACKER   = 282  # ImpliedVolatilityTracker
TAB_MACROINDIATRACKER          = 283  # MacroIndiaTracker
TAB_RBIPOLICYTRACKER           = 284  # RBIPolicyTracker
TAB_GLOBALMACROMONITOR         = 285  # GlobalMacroMonitor
TAB_INFLATIONHEATMAP           = 286  # InflationHeatmap
TAB_BUDGETIMPACTANALYZER       = 287  # BudgetImpactAnalyzer
TAB_NPATRACKERPRO              = 288  # NPATrackerPro
TAB_CREDITGROWTHMONITOR        = 289  # CreditGrowthMonitor
TAB_CASARATIOTRACKER           = 290  # CASARatioTracker
TAB_NIMMARGINSRACKER           = 291  # NIMMarginsTracker
TAB_BANKINGVALUATIONMATRIX     = 292  # BankingValuationMatrix
TAB_GOALPLANNERPRO             = 293  # GoalPlannerPro
TAB_SIPCALCULATORPRO           = 294  # SIPCalculatorPro
TAB_ASSETALLOCATIONADVISOR     = 295  # AssetAllocationAdvisor
TAB_TAXHARVESTINGTOOL          = 296  # TaxHarvestingTool
TAB_RETIREMENTCORPUSPLANNER    = 297  # RetirementCorpusPlanner
TAB_FIIFLOWTRACKER             = 298  # FIIFlowTracker
TAB_DIIACTIVITYMONITOR         = 299  # DIIActivityMonitor
TAB_PROMOTERHOLDINGTRACKER     = 300  # PromoterHoldingTracker
TAB_INSIDERTRADINGRADAR        = 301  # InsiderTradingRadar
TAB_SHORTSELLINGMONITOR        = 302  # ShortSellingMonitor

# ── Roadmap TAB Constants (recommended subset 303–500) ───────────────────────
# Technical Analysis Pro (303–307) — use existing constants defined below:
#   TAB_CANDLESTICK_MASTER=303  TAB_CHART_PATTERN=304  TAB_PIVOT_POINT=305
#   TAB_FIBONACCI=306           TAB_TREND_STRENGTH=307
# (constants live deeper in the file; forward assignment removed — was NameError)

# Quant & Risk — Turn CR/CS
TAB_FACTORBACKTESTENGINE       = 358  # FactorBacktestEngine
TAB_MULTIFACTORCOMBINERS       = 359  # MultiFactorCombiners
TAB_ALPHASIGNALDECAY           = 360  # AlphaSignalDecayMonitor
TAB_PORTFOLIOSIMULATORPRO      = 361  # PortfolioSimulatorPro
TAB_OPTIMISATIONSOLVER         = 362  # OptimisationSolver
TAB_VARBACKTESTPANEL           = 363  # VaRBacktestPanel
TAB_STRESSTESTLIBRARY2         = 364  # StressTestLibraryII
TAB_LIQUIDITYRISKDASHBOARD     = 365  # LiquidityRiskDashboard
TAB_COUNTERPARTYRISKPANEL      = 366  # CounterpartyRiskPanel
TAB_CONCENTRATIONLIMITER       = 367  # ConcentrationLimitChecker

# Screeners & Scanners — Turn CT
TAB_FUNDAMENTALSCREENER        = 368  # FundamentalScreenerPro
TAB_TECHNICALBREAKOUT          = 369  # TechnicalBreakoutScanner
TAB_VALUESTOCKRADAR            = 370  # ValueStockRadar
TAB_MOMENTUMSTOCKPICKER        = 371  # MomentumStockPicker
TAB_CONTRARIANFINDER           = 372  # ContrarianSignalFinder

# Portfolio Analytics II — Turn CU
TAB_PERFORMANCEATTRIBUTION2    = 373  # PerformanceAttributionII
TAB_DRAWDOWNANALYSER           = 374  # DrawdownAnalyser
TAB_ROLLINGRETURNHEATMAP       = 375  # RollingReturnHeatmap
TAB_BENCHMARKCOMPARISON        = 376  # BenchmarkComparison
TAB_STYLEBOXANALYSER           = 377  # StyleBoxAnalyser

# Income & Dividend — Turn CV
TAB_DIVIDENDCALENDAR           = 378  # DividendCalendar
TAB_DIVIDENDGROWTHTRACKER      = 379  # DividendGrowthTracker
TAB_BONDINTERESTCALENDAR       = 380  # BondInterestCalendar
TAB_REITDISTRIBUTION           = 381  # REITDistributionTracker
TAB_PASSIVEINCOMEPROJECTOR     = 382  # PassiveIncomeProjector

# Portfolio Construction II — Turn DF
TAB_BLACKLITTERMAN             = 428  # BlackLittermanAdvisor
TAB_RISKPARITYBUILDER          = 429  # RiskParityBuilder
TAB_TAILRISKHEDGER             = 430  # TailRiskHedger
TAB_FACTORTILTOPTIMISER        = 431  # FactorTiltOptimiser
TAB_DYNAMICASSETALLOCATOR      = 432  # DynamicAssetAllocator

# Trade Journal — Turn DI
TAB_TRADEJOURNALPRO            = 443  # TradeJournalPro
TAB_SETUPPERFORMANCESTATS      = 444  # SetupPerformanceStats
TAB_MISTAKEPATTERNANALYZER     = 445  # MistakePatternAnalyzer
TAB_TRADINGPSYCHOLOGYSCORE     = 446  # TradingPsychologyScore
TAB_PORTFOLIOREVIEWCALENDAR    = 447  # PortfolioReviewCalendar

# Printable Reports — Turn DM
TAB_PDFREPORTBUILDER2          = 463  # PDFReportBuilderII
TAB_WEEKLYMARKETSNAPSHOT       = 464  # WeeklyMarketSnapshot
TAB_MONTHLYPORTFOLIOREPORT     = 465  # MonthlyPortfolioReport
TAB_TAXREPORTGENERATOR         = 466  # TaxReportGenerator
TAB_CUSTOMDASHBOARDEXPORTER    = 467  # CustomDashboardExporter

# Personalisation — Turn DN
TAB_CUSTOMWIDGETBUILDER        = 468  # CustomWidgetBuilder
TAB_FAVOURITESQUICKPANEL       = 469  # FavouritesQuickPanel
TAB_PERSONALISEDAELRTHUB       = 470  # PersonalisedAlertHub
TAB_USERPROFILEMANAGER         = 471  # UserProfileManager
TAB_THEMECUSTOMIZER            = 472  # ThemeCustomizer

# Utilities & System — Turn DL
TAB_DATAFEEDSTATUS             = 458  # DataFeedStatusMonitor
TAB_APIKEYMANAGER              = 459  # APIKeyManager
TAB_BACKUPRESTOREPANEL         = 460  # BackupRestorePanel
TAB_SYSTEMRESOURCEMONITOR      = 461  # SystemResourceMonitor
TAB_APPUPDATECHECKER           = 462  # AppUpdateChecker

# Final Analytics Suite — Turns DP–DT
TAB_PORTFOLIOHEALTHSCORE       = 478  # PortfolioHealthScore
TAB_INVESTMENTCHECKLIST        = 479  # InvestmentChecklist
TAB_WATCHLISTALERTENGINE       = 480  # WatchlistAlertEngine
TAB_MARKETCALENDARMASTER       = 481  # MarketCalendarMaster
TAB_COMPREHENSIVERISKREPORT    = 482  # ComprehensiveRiskReport
TAB_QUANTRESEARCHIDE           = 484  # QuantResearchIDE
TAB_STRATEGYVERSIONCONTROL     = 485  # StrategyVersionControl
TAB_TABGROUPMANAGER            = 489  # TabGroupManager
TAB_DATAEXPORTHUB              = 490  # DataExportHub
TAB_PIVOTTABLEANALYSER         = 491  # PivotTableAnalyser
TAB_EXECUTIVESUMMARY           = 493  # ExecutiveSummaryDashboard
TAB_TOPPICKSOFTHEDAY           = 494  # TopPicksOfTheDay

# ── Dynamic Discovery Engine — TABs 495–505 ──────────────────────────────────
TAB_DYNAMIC_UNIVERSE           = 495  # DynamicUniverseSelector
TAB_MARKET_BREADTH             = 496  # MarketBreadthDashboard
TAB_ROTATION_ENGINE            = 497  # RotationalLeadershipEngine
TAB_VOLUME_EXPANSION           = 498  # VolumeExpansionScanner
TAB_SMALLMID_MOMENTUM          = 499  # SmallMidCapMomentumEngine
TAB_REGIME_SCREENER            = 500  # RegimeAwareScreener
TAB_INSTITUTIONAL_FLOW         = 501  # InstitutionalFlowEngine
TAB_EVENT_SCANNER              = 502  # EventDrivenScanner
TAB_SHORT_SQUEEZE              = 503  # ShortSqueezeDetector
TAB_THEME_BASKET               = 504  # ThemeBasketBuilder
TAB_DELIVERY_SPIKE             = 505  # DeliveryVolumeSpike
# ─────────────────────────────────────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────────────────────


RUNTIME_DIR = Path.home() / ".quantum_annealer_pro_v17"
RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
SNAPSHOT_DIR = RUNTIME_DIR / "snapshots"
SNAPSHOT_DIR.mkdir(parents=True, exist_ok=True)

# ══════════════════════════════════════════════════════════════════════════════
#  AlertThrottleManager — de-duplicate Telegram notifications
# ══════════════════════════════════════════════════════════════════════════════


# ────────────────────────────────────────────────────────────────────
# CLASS: AlertThrottleManager
# ────────────────────────────────────────────────────────────────────
class AlertThrottleManager:
    """Prevents duplicate alerts for the same event within a cooldown window.
    B13-fix: was lock-free. should_send() + record() are now wrapped in an
    RLock so concurrent worker threads cannot both pass the cooldown check
    and both send duplicate Telegram alerts.
    """
    def __init__(self):
        self._last: dict = {}
        self._lock = __import__("threading").RLock()

    def should_send(self, key: str, cooldown: int = 300) -> bool:
        import time
        with self._lock:
            return (time.time() - self._last.get(key, 0)) >= cooldown

    def record(self, key: str):
        import time
        with self._lock:
            self._last[key] = time.time()

    def should_send_and_record(self, key: str, cooldown: int = 300) -> bool:
        """Atomic check-and-record — preferred over calling should_send+record separately."""
        import time
        with self._lock:
            now = time.time()
            if (now - self._last.get(key, 0)) >= cooldown:
                self._last[key] = now
                return True
            return False

    def clear(self, key=None):
        with self._lock:
            # AUDIT-FIX (Round 4 — W0106): ternary expression used for side
            # effect; rewrite as explicit if/else so the intent is clear.
            if key is None:
                self._last.clear()
            else:
                self._last.pop(key, None)

    def pending_keys(self) -> list:
        with self._lock:
            return list(self._last.keys())

_ALERT_THROTTLE = AlertThrottleManager()
PREFERENCES_PATH  = RUNTIME_DIR / "last_config.json"
CREDENTIALS_PATH  = RUNTIME_DIR / "credentials.json"


# ────────────────────────────────────────────────────────────────────
# FUNC: load_credentials
# ────────────────────────────────────────────────────────────────────
def load_credentials() -> dict:
    try:
        import keyring
        data = keyring.get_password("QuantumAnnealerPro", "credentials")
        if data:
            return json.loads(data)
    except Exception as _e:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception in %s", "Exception", exc_info=True)  # noqa: E501
        pass
    try:
        if CREDENTIALS_PATH.exists():
            return json.loads(CREDENTIALS_PATH.read_text(encoding="utf-8"))
    except Exception as _e:  # safe: optional matplotlib / scipy feature
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception in %s", "Exception", exc_info=True)  # noqa: E501
        pass  # intentional — see comment above
    return {}


# ────────────────────────────────────────────────────────────────────
# FUNC: save_credentials
# ────────────────────────────────────────────────────────────────────
def save_credentials(creds: dict) -> bool:
    success = False
    try:
        import keyring
        keyring.set_password("QuantumAnnealerPro", "credentials", json.dumps(creds))
        success = True
    except Exception as _kr_exc:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception in %s", "Exception", exc_info=True)  # noqa: E501
        pass
    try:
        CREDENTIALS_PATH.write_text(
            json.dumps(creds, indent=2, ensure_ascii=False), encoding="utf-8"
        )
        try:
            CREDENTIALS_PATH.chmod(0o600)
        except Exception:
            import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
            pass
        # Also write models/dhan_config.json for DhanHQProvider
        if "DHAN_CLIENT_ID" in creds:
            # AUDIT-FIX (Round 6, C-P3-2): anchor to project dir, not CWD
            dhan_dir = PROJECT_DIR / "models"
            dhan_dir.mkdir(parents=True, exist_ok=True)
            dhan_file = dhan_dir / "dhan_config.json"
            dhan_data = {
                "client_id": creds.get("DHAN_CLIENT_ID", ""),
                "access_token": creds.get("DHAN_ACCESS_TOKEN", "") or creds.get("DHAN_API_KEY", ""),
                "api_secret": creds.get("DHAN_API_SECRET", "")
            }
            dhan_file.write_text(json.dumps(dhan_data, indent=2), encoding="utf-8")
            # AUDIT-FIX (defect #14): the prior code applied chmod 600 only to
            # CREDENTIALS_PATH, leaving dhan_config.json (which contains an
            # access token and API secret) readable by other users on the host.
            try:
                dhan_file.chmod(0o600)
            except Exception:
                # Filesystem may not support mode bits (e.g., Windows, certain
                # container overlays). The best-effort attempt still leaves the
                # file with restrictive perms on POSIX hosts.
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                pass
        success = True
    except Exception:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
        pass
    # AUDIT-FIX (defect #14): also sweep existing credential-like files at
    # save time. This catches files written by older versions that never had
    # the chmod call, so the operator doesn't have to re-save credentials
    # to get them locked down. Best-effort; ignores failures from filesystems
    # that don't support Unix mode bits.
    try:
        # AUDIT-FIX (Round 6, C-P3-2): anchor to project dir, not CWD
        _credential_file_paths = [
            CREDENTIALS_PATH,
            PROJECT_DIR / "models" / "dhan_config.json",
            PROJECT_DIR / "models" / "angelone_config.json",
            PROJECT_DIR / "models" / "kite_config.json",
        ]
        for _cf in _credential_file_paths:
            if _cf.exists():
                try:
                    _cf.chmod(0o600)
                except Exception:
                    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                    pass
    except Exception:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
        pass
    return success
HISTORY_PATH = RUNTIME_DIR / "run_history.json"
LAST_RUN_PATH = RUNTIME_DIR / "last_run_snapshot.json"
ALERTS_HISTORY_PATH = RUNTIME_DIR / "alerts_history.json"
TICKERS_CACHE_PATH = RUNTIME_DIR / "nse_tickers_cache.json"
SECTOR_CACHE_PATH = RUNTIME_DIR / "sector_cache.json"
PRESCREEN_CACHE_PATH = RUNTIME_DIR / "qa_prescreen_cache.json"  # v17-patch: moved from Desktop to RUNTIME_DIR for server compatibility
GRAVEYARD_PATH     = RUNTIME_DIR / "delisted_graveyard.json"
FNO_BAN_CACHE_PATH = RUNTIME_DIR / "fno_ban_cache.json"
DELIVERY_CACHE_PATH = RUNTIME_DIR / "delivery_cache.json"
FII_DII_CACHE_PATH  = RUNTIME_DIR / "fii_dii_cache.json"
LARGE_MID_SMALL_CACHE_PATH = RUNTIME_DIR / "nse_cap_category.json"
INDIA_VIX_CACHE_PATH       = RUNTIME_DIR / "india_vix_cache.json"
FACTOR_IC_CACHE_PATH       = RUNTIME_DIR / "factor_ic_cache.json"  # v17.34: was undefined — IC history never persisted
CORP_ACTIONS_CACHE_PATH    = RUNTIME_DIR / "corp_actions_cache.json"
FUNDAMENTALS_CACHE_PATH    = RUNTIME_DIR / "fundamentals_cache.json"
OPTIONS_IV_CACHE_PATH      = RUNTIME_DIR / "options_iv_cache.json"
OI_BUILDUP_CACHE_PATH      = RUNTIME_DIR / "oi_buildup_cache.json"
SAST_CACHE_PATH            = RUNTIME_DIR / "sast_cache.json"
SAST_VELOCITY_CACHE_PATH   = RUNTIME_DIR / "sast_velocity_cache.json"
PLEDGE_CACHE_PATH          = RUNTIME_DIR / "pledge_cache.json"
PEAD_CACHE_PATH            = RUNTIME_DIR / "pead_cache.json"
PCR_CACHE_PATH             = RUNTIME_DIR / "pcr_cache.json"
FII_SECTOR_CACHE_PATH      = RUNTIME_DIR / "fii_sector_cache.json"
BUYBACK_CACHE_PATH         = RUNTIME_DIR / "buyback_cache.json"
MTF_CACHE_PATH             = RUNTIME_DIR / "mtf_cache.json"
BULK_DEAL_CACHE_PATH       = RUNTIME_DIR / "bulk_deal_footprint_cache.json"
FLOAT_SQUEEZE_CACHE_PATH   = RUNTIME_DIR / "float_squeeze_cache.json"
CHART_SSL_MODEL_PATH       = RUNTIME_DIR / "chart_ssl_model_1d.npz"
CHART_SSL_MODEL_META_PATH  = RUNTIME_DIR / "chart_ssl_model_1d_meta.json"
OFFLINE_CHART_MODEL_PATH   = ARTIFACTS_DIR / "chart_ssl_offline_1d.npz"
OFFLINE_CHART_MODEL_META_PATH = ARTIFACTS_DIR / "chart_ssl_offline_1d_meta.json"
SQLITE_DB_PATH             = RUNTIME_DIR / "qa_portfolio_history.db"  # v17-patch: moved from Desktop to RUNTIME_DIR for server compatibility


# ── NSE Universe Loader ──────────────────────────────────────────────────
_NSE500_CACHE: list = []


# ────────────────────────────────────────────────────────────────────
# FUNC: _assert_tab_constants_unique
# ────────────────────────────────────────────────────────────────────
def _assert_tab_constants_unique():
    """Validates TAB_* constants for duplicate integer values.

    Bug-20-FIX: In production (QA_DEV_MODE not set, not pytest, not __main__),
    only the fast in-memory dict check runs — O(N) over already-loaded globals,
    no file I/O, no regex, no disk access.
    The file-level source scan (which reads __file__) is gated strictly to
    dev/test environments to ensure zero import-time I/O in production.
    """
    import os as _os
    _g = globals()
    _tab_vals = {}   # integer → name
    for _k, _v in _g.items():
        if _k.startswith("TAB_") and isinstance(_v, int):
            if _v in _tab_vals:
                raise ValueError(
                    f"Duplicate TAB integer {_v}: {_tab_vals[_v]} and {_k}. "
                    f"Assign a unique integer to every TAB_* constant.")
            _tab_vals[_v] = _k

    # Source-level duplicate name scan — dev/test only (reads __file__).
    _dev_mode = (
        _os.environ.get("QA_DEV_MODE") == "1"
        or _os.environ.get("PYTEST_CURRENT_TEST")
        or __name__ == "__main__"
    )
    if not _dev_mode:
        return
    try:
        import re as _re
        with open(__file__, 'r', encoding='utf-8', errors='replace') as _f:
            _lines = _f.readlines()
        _seen = {}
        for _lineno, _line in enumerate(_lines, 1):
            _m = _re.match(r'^(TAB_' + r'\w+' + r')\s*=\s*\d+', _line.strip())
            if _m:
                _n = _m.group(1)
                if _n in _seen:
                    raise ValueError(
                        f"TAB name '{_n}' defined at both L{_seen[_n]} and L{_lineno}. "
                        f"Remove the earlier definition — Python silently uses the later one, "
                        f"orphaning any code that depended on the earlier integer value.")
                _seen[_n] = _lineno
    except (OSError, IOError):
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
        pass   # skip source scan if file not readable (frozen binary, etc.)
_assert_tab_constants_unique()
del _assert_tab_constants_unique


# ────────────────────────────────────────────────────────────────────
# CLASS: StopRequested
# ────────────────────────────────────────────────────────────────────
class StopRequested(Exception):
    pass

# ARCH-01: bridge — existing code reads _ACTIVE_STOP_EVENT directly;
# new code should use AppState.get().is_stop_requested()
_APPSTATE_BRIDGE_INSTALLED = True


# ══════════════════════════════════════════════════════════════════════════════
# ARCHITECTURE LAYER v1.0  — injected after TAB constants, before UI classes
#
# Fixes addressed:
#   ARCH-01  AppState          — replaces scattered mutable globals
#   ARCH-02  DataCache         — centralized TTL-aware fetch cache
#   ARCH-03  FetchDeduplicator — prevents duplicate API calls same ticker+period
#   ARCH-04  ScannerRegistry   — all scanner logic lives here, not in QWidgets
#   ARCH-05  RankingEngine     — single canonical score used by ALL panels
#   ARCH-06  LazyTabManager    — tabs not instantiated until first access
#   ARCH-07  WorkerLifecycle   — tracks QThreads, graceful shutdown
#   ARCH-08  UIUpdateGuard     — thread-safe widget mutations
#   ARCH-09  ExceptionLogger   — replaces silent except Exception as _e:
#      archlog.error('Exception detail', exc_info=True)  # LOG003 was traceback.print_exc()  [BUG-FIX: stray uncommented example line — archlog not yet defined here]
#      archlog.error("%s", _e)
#   ARCH-10  ConfigValidator   — removes dead keys, flags conflicts
# ══════════════════════════════════════════════════════════════════════════════

import weakref as _weakref
import threading as _threading
import time as _time
import logging as _logging

_arch_log = _logging.getLogger("quantum_annealer.arch")
archlog    = _logging.getLogger("quantum_annealer")   # [BUG-FIX: was never defined — NameError on 301 call sites]

# ─── ARCH-01  AppState ────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# CLASS: AppState
# ────────────────────────────────────────────────────────────────────
from core.state_manager import AppState


# ─── ARCH-02  DataCache ───────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# CLASS: DataCache
# ────────────────────────────────────────────────────────────────────
from data.cache_manager import DataCache, _DATA_CACHE


# ─── ARCH-03  FetchDeduplicator ───────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# CLASS: FetchDeduplicator
# ────────────────────────────────────────────────────────────────────
class FetchDeduplicator:
    """Coalesces concurrent fetch requests for same ticker+period.
    Panel B reuses Panel A's in-flight download instead of making a second call."""
    _pending: dict = {}
    _lock = _threading.Lock()

    @classmethod
    def fetch_or_join(cls, tickers: list, period: str,
                      fetch_fn, on_result, cache: DataCache = _DATA_CACHE):
        key = cache.cache_key(tickers, period)
        cached = cache.get(key)
        if cached is not None:
            try: on_result(cached)
            except Exception as e: archlog.error("FetchDeduplicator on_result: %s", e, exc_info=True)
            return
        with cls._lock:
            if key in cls._pending:
                cls._pending[key].append(on_result); return
            cls._pending[key] = [on_result]

        def _do():
            try: result = fetch_fn(tickers, period); cache.set(key, result)
            except Exception as e: archlog.error("FetchDeduplicator fetch: %s", e, exc_info=True); result = None
            finally:
                with cls._lock: callbacks = cls._pending.pop(key, [])
            for cb in callbacks:
                try: cb(result)
                except Exception as e: archlog.error("FetchDeduplicator cb: %s", e, exc_info=True)

        t = _threading.Thread(target=_do, daemon=True, name=f"dedup_{key[:20]}")
        t.start()


# ─── ARCH-04  ScannerRegistry ─────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# CLASS: ScannerRegistry
# ────────────────────────────────────────────────────────────────────
class ScannerRegistry:
    """Central registry for all scan/screen/rank functions.
    UI panels are views only — business logic lives here."""
    _registry: dict = {}
    _lock = _threading.Lock()

    @classmethod
    def register(cls, name: str):
        def decorator(fn):
            with cls._lock:
                cls._registry[name] = fn
            return fn
        return decorator

    @classmethod
    def run(cls, name: str, raw_data, params: dict, callback, error_cb=None):
        fn = cls._registry.get(name)
        if fn is None:
            if error_cb: error_cb(f"Scanner '{name}' not registered.")
            return

        def _worker():
            try:
                result = fn(raw_data, params)
                try: callback(result)
                except Exception as e: archlog.error("Scanner '%s' cb: %s", name, e, exc_info=True)
            except Exception as e:
                pass  # _arch_log removed (LOG003)
                if error_cb:
                    try: error_cb(str(e))
                    except Exception as _e:
                        archlog.error('Exception detail', exc_info=True)  # LOG003 was traceback.print_exc()
                        pass  # _arch_log removed (LOG003)

        t = _threading.Thread(target=_worker, daemon=True, name=f"scanner_{name}")
        WorkerLifecycle.register_thread(t)
        t.start()

    @classmethod
    def list_scanners(cls) -> list:
        with cls._lock: return sorted(cls._registry.keys())


# ─── ARCH-05  RankingEngine ───────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# CLASS: RankingEngine
# ────────────────────────────────────────────────────────────────────
class RankingEngine:
    """Single canonical multi-factor scoring used by ALL panels.
    Eliminates conflicting scores between tabs."""

    DEFAULT_WEIGHTS = {
        "momentum_6m"   : 0.25,
        "momentum_3m"   : 0.15,
        "rsi_norm"      : 0.10,
        "volume_trend"  : 0.20,
        "delivery_pct"  : 0.15,
        "breakout_dist" : 0.15,
    }

    @classmethod
    def score_single(cls, metrics: dict, weights: dict = None) -> float:
        w = weights or cls.DEFAULT_WEIGHTS
        total_w = sum(abs(v) for v in w.values())
        score = sum(w.get(f, 0) * max(-1.0, min(1.0, float(v)))
                    for f, v in metrics.items() if v is not None and w.get(f))
        return round(max(0.0, min(100.0, (score/total_w + 1)/2*100 if total_w else 50.0)), 1)  # DIV001: guard divisor before use

    @classmethod
    def rank_universe(cls, ticker_data: list, weights: dict = None) -> list:
        import math
        factors = list((weights or cls.DEFAULT_WEIGHTS).keys())
        z_scores = {}
        for factor in factors:
            vals = [d.get(factor) for d in ticker_data
                    if d.get(factor) is not None
                    and not (isinstance(d.get(factor), float) and math.isnan(d.get(factor)))]
            if len(vals) < 2: continue
            mu  = sum(vals) / len(vals) if vals else 0
            std = (sum((v-mu)**2 for v in vals) / len(vals) if vals else 0)**0.5
            if std > 0:
                z_scores[factor] = {d['ticker']: (d.get(factor, mu)-mu)/std  # DIV001: guard divisor before use
                                    for d in ticker_data}
        scored = []
        for d in ticker_data:
            metrics = {f: z_scores.get(f,{}).get(d['ticker']) for f in factors}
            comp    = cls.score_single({k:v for k,v in metrics.items() if v is not None}, weights)
            scored.append({**d, 'score': comp})
        scored.sort(key=lambda x: x['score'], reverse=True)
        for rank, d in enumerate(scored, 1):
            d['rank'] = rank
            d['signal'] = ("STRONG BUY ✓✓" if d['score']>=75 else
                           "BUY ✓"          if d['score']>=60 else
                           "NEUTRAL ~"      if d['score']>=40 else "AVOID ✗")
        return scored


# ─── ARCH-06  LazyTabManager ──────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# CLASS: LazyTabManager
# ────────────────────────────────────────────────────────────────────
class LazyTabManager:
    """Defers QWidget tab instantiation until first user click.
    Eliminates startup overhead and memory bloat from 400+ pre-allocated tabs."""

    def __init__(self, tab_widget):
        self._tw      = tab_widget
        self._factory = {}   # tab_index → callable → QWidget
        self._cache   = {}   # tab_index → QWidget
        self._labels  = {}

    def register(self, tab_index: int, label: str, factory):
        self._factory[tab_index] = factory
        self._labels[tab_index]  = label

    def wire_tab_changed(self):
        try: self._tw.currentChanged.connect(self._on_tab_change)
        except Exception as e: archlog.warning("LazyTabManager.wire: %s", e, exc_info=True)

    def _on_tab_change(self, index: int):
        if index not in self._factory or index in self._cache: return
        try:
            widget = self._factory[index]()
            self._cache[index] = widget
            
            # Feed current results to this widget immediately if available
            parent = self._tw.parent()
            while parent is not None:
                if parent.__class__.__name__ == "MainWindow":
                    # Dynamic binding back to parent attributes to preserve MainWindow direct updates!
                    cname = widget.__class__.__name__
                    if cname == "QuarterlyResultsScanner": parent.quarterly_results_page = widget
                    elif cname == "EarningsSurpriseTracker": parent.earnings_surprise_page = widget
                    elif cname == "RevenueGrowthComparator": parent.revenue_growth_page = widget
                    elif cname == "MarginTrendAnalyzer": parent.margin_trend_page = widget
                    elif cname == "ConsensusForecastPanel": parent.consensus_page = widget
                    elif cname == "OptionsChainViewer": parent.options_chain_page = widget
                    elif cname == "ScenarioStressLibrary": parent.scenario_stress_page = widget
                    elif cname == "MovingAverageScanner": parent.ma_scanner_page = widget
                    elif cname == "RSIMomentumPanel": parent.rsi_momentum_page = widget
                    elif cname == "MACDSignalScanner": parent.macd_signal_page = widget
                    elif cname == "SupportResistancePanel": parent.support_resistance_page = widget
                    elif cname == "CandlestickPatternScanner": parent.candlestick_page = widget
                    elif cname == "VolumeAnalysisPanel": parent.volume_analysis_page = widget
                    elif cname == "ChartPatternScanner": parent.chart_patterns_page = widget
                    elif cname == "MomentumScreener": parent.momentum_screener_page = widget
                    
                    if parent.last_payload is not None:
                        # 1. Standard update_portfolio_data
                        if hasattr(widget, "update_portfolio_data"):
                            try:
                                if cname == "ScenarioStressLibrary":
                                    widget.update_portfolio_data(parent.last_payload)
                                else:
                                    widget.update_portfolio_data(parent.last_payload.get("portfolio_df"))
                            except Exception as _e:
                                archlog.warning("Failed to populate lazy tab data: %s", _e, exc_info=True)
                        
                        # 1b. Support for legacy 400+ tabs using load_payload or load_from_payload
                        if hasattr(widget, "load_payload"):
                            try:
                                widget.load_payload(parent.last_payload)
                            except Exception as _e:
                                archlog.warning("Failed to call load_payload on lazy load: %s", _e, exc_info=True)
                        if hasattr(widget, "load_from_payload"):
                            try:
                                widget.load_from_payload(parent.last_payload)
                            except Exception as _e:
                                archlog.warning("Failed to call load_from_payload on lazy load: %s", _e, exc_info=True)
                        
                        # 2. OptionsChainViewer update_portfolio_tickers
                        if hasattr(widget, "update_portfolio_tickers"):
                            try:
                                portfolio_df = parent.last_payload.get("portfolio_df")
                                if portfolio_df is not None and not portfolio_df.empty:
                                    tickers = portfolio_df["Ticker"].tolist() if "Ticker" in portfolio_df.columns else []
                                    price_df = parent.last_payload.get("price_df")
                                    if price_df is not None and not price_df.empty:
                                        widget.update_portfolio_tickers(tickers, price_df)
                            except Exception as _e:
                                archlog.warning("Failed to update OptionsChainViewer on lazy load: %s", _e, exc_info=True)
                                
                        # 3. Reload technical scanners if they are loaded
                        if cname in ["MovingAverageScanner", "RSIMomentumPanel", "MACDSignalScanner",
                                     "SupportResistancePanel", "CandlestickPatternScanner",
                                     "VolumeAnalysisPanel", "ChartPatternScanner", "MomentumScreener"]:
                            try:
                                parent._update_portfolio_drilldown()
                            except Exception as _e:
                                archlog.warning("Failed to trigger post-load drilldown: %s", _e, exc_info=True)
                    break
                parent = parent.parent()
                
            self._tw.blockSignals(True)
            try:
                if hasattr(self._tw, 'removeTab') and hasattr(self._tw, 'insertTab'):
                    self._tw.removeTab(index)
                    self._tw.insertTab(index, widget, self._labels.get(index, ""))
                    self._tw.setCurrentIndex(index)
                elif hasattr(self._tw, 'insertWidget') and hasattr(self._tw, 'widget'):
                    old_widget = self._tw.widget(index)
                    self._tw.removeWidget(old_widget)
                    self._tw.insertWidget(index, widget)
                    if old_widget is not None:
                        old_widget.deleteLater()
                    self._tw.setCurrentIndex(index)
            finally:
                self._tw.blockSignals(False)
        except Exception as e:
            archlog.warning("LazyTabManager._on_tab_change exception: %s", e, exc_info=True)

    def get(self, idx): return self._cache.get(idx)
    def preload(self, indices: list):
        for idx in indices: self._on_tab_change(idx)

    def update_all_loaded_tabs(self, payload):
        """Propagates new optimizer payload to all active/loaded lazy tabs."""
        if not payload:
            return
        portfolio_df = payload.get("portfolio_df")
        for idx, widget in self._cache.items():
            if widget is None:
                continue
            cname = widget.__class__.__name__
            
            # Support for legacy 400+ tabs using load_payload or load_from_payload
            if hasattr(widget, "load_payload"):
                try:
                    widget.load_payload(payload)
                except Exception as e:
                    archlog.warning("LazyTabManager failed to call load_payload: %s", e, exc_info=True)
            if hasattr(widget, "load_from_payload"):
                try:
                    widget.load_from_payload(payload)
                except Exception as e:
                    archlog.warning("LazyTabManager failed to call load_from_payload: %s", e, exc_info=True)

            # Handle standard update_portfolio_data
            if hasattr(widget, "update_portfolio_data"):
                try:
                    if cname == "ScenarioStressLibrary":
                        widget.update_portfolio_data(payload)
                    else:
                        if portfolio_df is not None and not portfolio_df.empty:
                            widget.update_portfolio_data(portfolio_df)
                except Exception as e:
                    archlog.warning("LazyTabManager failed to update widget data: %s", e, exc_info=True)
            
            # Handle OptionsChainViewer update_portfolio_tickers
            if hasattr(widget, "update_portfolio_tickers"):
                try:
                    if portfolio_df is not None and not portfolio_df.empty:
                        tickers = portfolio_df["Ticker"].tolist() if "Ticker" in portfolio_df.columns else []
                        price_df = payload.get("price_df")
                        if price_df is not None and not price_df.empty:
                            widget.update_portfolio_tickers(tickers, price_df)
                except Exception as e:
                    archlog.warning("LazyTabManager failed to update OptionsChainViewer: %s", e, exc_info=True)

    @property
    def loaded_count(self): return len(self._cache)
    @property
    def registered_count(self): return len(self._factory)


# ─── ARCH-07  WorkerLifecycle ─────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# CLASS: WorkerLifecycle
# ────────────────────────────────────────────────────────────────────
class WorkerLifecycle:
    """Tracks all QThread/Thread workers. Graceful shutdown on exit."""
    _threads: list = []
    _lock = _threading.Lock()

    @classmethod
    def _is_alive(cls, t) -> bool:
        if t is None: return False
        if hasattr(t, "isRunning"):
            try: return t.isRunning()
            except Exception: return False
        if hasattr(t, "is_alive"):
            try: return t.is_alive()
            except Exception: return False
        return False

    @classmethod
    def register_thread(cls, thread):
        with cls._lock:
            cls._threads.append(_weakref.ref(thread))
            cls._threads = [r for r in cls._threads if r() is not None]

    @classmethod
    def active_count(cls) -> int:
        with cls._lock:
            return sum(1 for r in cls._threads if cls._is_alive(r()))

    @classmethod
    def shutdown_all(cls, timeout_ms: int = 3000):
        AppState.get().request_stop()
        with cls._lock:
            live = [r() for r in cls._threads if cls._is_alive(r())]
        for t in live:
            try:
                if hasattr(t,'quit'):   t.quit();  t.wait(timeout_ms)
                elif hasattr(t,'join'): t.join(timeout=timeout_ms/1000)
            except Exception as e: archlog.warning("shutdown: %s", e, exc_info=True)
        pass  # _arch_log removed (LOG003)

    @classmethod
    def report(cls) -> str:
        with cls._lock:
            total = len([r for r in cls._threads if r() is not None])
            alive = sum(1 for r in cls._threads if cls._is_alive(r()))
        return f"Workers: {alive} alive / {total} total"


# ─── ARCH-08  UIUpdateGuard ───────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# CLASS: UIUpdateGuard
# ────────────────────────────────────────────────────────────────────
class UIUpdateGuard:
    """Thread-safe widget mutations. Worker threads MUST use this."""

    @staticmethod
    def set_text(widget, text: str):
        """Thread-safe setText."""
        from threading import main_thread, current_thread
        if current_thread() is main_thread():
            try: widget.setText(str(text))
            except Exception as _e_:  # P1-E: was bare pass
                ExceptionLogger.swallow(_e_, context='auto-P1E')
        else:
            try:
                QTimer.singleShot(0, lambda: widget.setText(str(text)))
            except Exception as _e_:  # P1-E: was bare pass
                ExceptionLogger.swallow(_e_, context='auto-P1E')

    @staticmethod
    def run_on_main(fn):
        try: QTimer.singleShot(0, fn)
        except Exception as _e:
            fn()

    @staticmethod
    def populate_table(table, rows: list, headers: list = None):
        def _do():
            try:
                if headers:
                    table.setColumnCount(len(headers))
                    table.setHorizontalHeaderLabels(headers)
                table.setRowCount(len(rows))
                for r, row in enumerate(rows):
                    for c, val in enumerate(row):
                        table.setItem(r, c, QTableWidgetItem(str(val)))
            except Exception as e: archlog.error("UIUpdateGuard.populate_table: %s", e, exc_info=True)
        UIUpdateGuard.run_on_main(_do)


# ─── ARCH-09  ExceptionLogger ─────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# CLASS: ExceptionLogger
# ────────────────────────────────────────────────────────────────────
class ExceptionLogger:
    """Structured logging. Replaces silent `except Exception: pass`."""
    _h = _logging.getLogger("quantum_annealer.exc")

    @classmethod
    def warn(cls, exc, context="", reraise=False):
        cls._h.warning("[WARN] %s — %s: %s", context, type(exc).__name__, exc)
        if reraise: raise exc

    @classmethod
    def error(cls, exc, context="", reraise=False):
        import traceback
        cls._h.error("[ERROR] %s — %s: %s\n%s",
                     context, type(exc).__name__, exc, traceback.format_exc()[-600:])
        if reraise: raise exc

    @classmethod
    def fatal(cls, exc, context=""):
        import traceback
        cls._h.critical("[FATAL] %s — %s: %s\n%s",
                         context, type(exc).__name__, exc, traceback.format_exc())
        AppState.get().request_stop()

    @classmethod
    def swallow(cls, exc, context=""):
        """Deliberate silent swallow — logged at DEBUG so still traceable."""
        cls._h.debug("[SWALLOW] %s — %s: %s", context, type(exc).__name__, exc)


# ── P2-B: NSEClient ── centralised retry + rate-limit for all external fetches


# ────────────────────────────────────────────────────────────────────
# CLASS: NSEClient
# ────────────────────────────────────────────────────────────────────
class NSEClient:
    """Single HTTP client for all external fetches.
    Provides: exponential back-off (3 retries), rate-limit jitter,
    consistent User-Agent, connection pooling, non-fatal timeout handling,
    and self-healing session cookie warmup/renewal against NSE Akamai WAF.
    """
    _session = None
    _last_warmup_time = 0
    _lock = __import__("threading").Lock()
    _HEADERS = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/126.0.0.0 Safari/537.36"
        ),
        "Accept-Language": "en-US,en;q=0.9",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept": "*/*",
        "Connection": "keep-alive",
    }
    _MAX_RETRIES = 3
    _BACKOFF_BASE = 1.0
    _RATE_JITTER  = 0.20

    @classmethod
    def safe_sleep(cls, seconds: float):
        import time as _time
        try:
            from PySide6.QtCore import QEventLoop, QTimer, QThread
            from PySide6.QtWidgets import QApplication
            app = QApplication.instance()
            if app and QThread.currentThread() == app.thread():
                loop = QEventLoop()
                QTimer.singleShot(int(seconds * 1000), loop.quit)
                loop.exec()
                return
        except Exception:
            import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
            pass
        _time.sleep(seconds)

    @classmethod
    def _warmup_session(cls, session):
        """Acquire fresh Akamai session cookies (_abck, bm_sz, ak_bmsc) from NSE."""
        import time as _t
        try:
            # 1. MarketStatus endpoint returns 200 OK and sets base cookies in ~0.1s
            session.get("https://www.nseindia.com/api/marketStatus", timeout=5)
            # 2. Main site finalizes Akamai session cookies
            session.get("https://www.nseindia.com", headers={"Accept": "text/html,application/xhtml+xml,*/*"}, timeout=5)
            cls._last_warmup_time = _t.time()
        except Exception:
            import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
            pass

    @classmethod
    def _get_session(cls, force_renew=False):
        import time as _t, requests as _req
        with cls._lock:
            now = _t.time()
            if cls._session is None or force_renew or (now - cls._last_warmup_time > 300):
                if cls._session is not None:
                    try: cls._session.close()
                    except Exception: pass
                cls._session = _req.Session()
                cls._session.headers.update(cls._HEADERS)
                cls._warmup_session(cls._session)
        return cls._session

    @classmethod
    def _resolve_referer(cls, url: str) -> str:
        """Map target API URL to its matching NSE landing page Referer header."""
        u = str(url).lower()
        if "largedeal" in u or "bulk" in u or "block" in u:
            return "https://www.nseindia.com/market-data/large-deals"
        elif "corporates-pit" in u or "sast" in u or "insider" in u:
            return "https://www.nseindia.com/companies-listing/corporate-filings-insider-trading"
        elif "shareholding" in u or "corp-info" in u:
            return "https://www.nseindia.com/companies-listing/corporate-filings-shareholding-patterns"
        elif "equity" in u or "index" in u or "live" in u:
            return "https://www.nseindia.com/market-data/live-equity-market"
        return "https://www.nseindia.com"

    @classmethod
    def get(cls, url, params=None, headers=None, timeout=10, stream=False):
        import time as _t, random as _r, requests as _req
        session = cls._get_session()
        merged = dict(cls._HEADERS)
        merged["Referer"] = cls._resolve_referer(url)
        if headers:
            merged.update(headers)
        last_exc = None
        for attempt in range(cls._MAX_RETRIES):
            try:
                resp = session.get(url, params=params, headers=merged,
                                   timeout=timeout, stream=stream)
                # Self-healing: if Akamai blocks with 401, 403, or 503, renew session on retry
                if resp.status_code in (401, 403, 503) and attempt < cls._MAX_RETRIES - 1:
                    session = cls._get_session(force_renew=True)
                    cls.safe_sleep(0.3)
                    continue
                resp.raise_for_status()
                return resp
            except (_req.exceptions.Timeout,
                    _req.exceptions.ConnectionError,
                    _req.exceptions.HTTPError) as exc:
                last_exc = exc
                if attempt < cls._MAX_RETRIES - 1:
                    session = cls._get_session(force_renew=True)
                    cls.safe_sleep((cls._BACKOFF_BASE ** attempt) + _r.uniform(0, cls._RATE_JITTER))
        raise last_exc

    @classmethod
    def post(cls, url, data=None, json=None, headers=None, timeout=10):
        import time as _t, random as _r, requests as _req
        session = cls._get_session()
        merged = dict(cls._HEADERS)
        merged["Referer"] = cls._resolve_referer(url)
        if headers:
            merged.update(headers)
        last_exc = None
        for attempt in range(cls._MAX_RETRIES):
            try:
                resp = session.post(url, data=data, json=json,
                                    headers=merged, timeout=timeout)
                if resp.status_code in (401, 403, 503) and attempt < cls._MAX_RETRIES - 1:
                    session = cls._get_session(force_renew=True)
                    cls.safe_sleep(0.3)
                    continue
                resp.raise_for_status()
                return resp
            except (_req.exceptions.Timeout,
                    _req.exceptions.ConnectionError,
                    _req.exceptions.HTTPError) as exc:
                last_exc = exc
                if attempt < cls._MAX_RETRIES - 1:
                    session = cls._get_session(force_renew=True)
                    cls.safe_sleep((cls._BACKOFF_BASE ** attempt) + _r.uniform(0, cls._RATE_JITTER))
        raise last_exc

    @classmethod
    def reset(cls):
        with cls._lock:
            if cls._session is not None:
                try: cls._session.close()
                except Exception as _e:
                    ExceptionLogger.swallow(_e, context='auto-EXC002')
            cls._session = None
            cls._last_warmup_time = 0

# ─── ARCH-10  ConfigValidator ─────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# CLASS: ConfigValidator
# ────────────────────────────────────────────────────────────────────
class ConfigValidator:
    """Runtime config validation: removes dead keys, flags conflicts,
    enforces value bounds, auto-normalises weight sums."""

    DEAD_KEYS = frozenset({
        "LEGACY_SOLVER","OLD_ALPHA_BLEND","USE_OLD_PRESCREEN","DISABLE_QUBO_V1",
        "FORCE_SCIPY_MINIMIZE","DEBUG_TRACE_LEVEL","PRESCREEN_HARDCAP_V1",
        "ALLOW_DUPLICATE_HOLDINGS_LEGACY",
    })

    CONFLICT_PAIRS = [
        ("USE_FUNDAMENTALS",      "USE_FUNDAMENTALS_IN_SIGNAL_FRAME"),
        ("ENABLE_HRP",            "ENABLE_EQUAL_WEIGHT"),
        ("ENABLE_DRAWDOWN_KILL",  "DISABLE_DRAWDOWN_PROTECTION"),
    ]

    BOUNDS = {
        "PRESCREEN_MOM_WEIGHT": (0.0, 1.0), "PRESCREEN_LIQ_WEIGHT": (0.0, 1.0),
        "MAX_WEIGHT"          : (0.01,1.0), "MIN_WEIGHT"           : (0.0, 0.5),
        "ALPHA"               : (0.0,20.0), "GAMMA"                : (0.0,100.0),
        "THETA"               : (0.0,50.0), "DOWNLOAD_WORKERS"     : (1, 32),
        "K_STOCKS"            : (1, 100),   "TOP_N_UNIVERSE"       : (1, 5000),
        "VALIDATION_LAG_DAYS" : (5, 126),
    }

    @classmethod
    def validate(cls, cfg: dict, log: bool = True) -> dict:
        out = dict(cfg); issues = []
        for k in list(out):
            if k in cls.DEAD_KEYS:
                del out[k]; issues.append(f"DEAD KEY removed: {k}")
        for ka, kb in cls.CONFLICT_PAIRS:
            if out.get(ka) and out.get(kb):
                issues.append(f"CONFLICT: {ka} and {kb} both True — {kb} takes precedence")
                out[ka] = False
        for k, (lo, hi) in cls.BOUNDS.items():
            v = out.get(k)
            if v is not None:
                try:
                    fv = float(v)
                    if fv < lo or fv > hi:
                        clamped = max(lo, min(hi, fv))
                        issues.append(f"RANGE: {k}={fv} clamped to {clamped}")
                        out[k] = type(v)(clamped)
                except (TypeError, ValueError) as _e:
                    ExceptionLogger.swallow(_e, context='auto-EXC002')
        mw = float(out.get("PRESCREEN_MOM_WEIGHT", 0.7))
        lw = float(out.get("PRESCREEN_LIQ_WEIGHT", 0.3))
        if abs(mw+lw-1.0) > 0.01:
            r = mw/(mw+lw)
            out["PRESCREEN_MOM_WEIGHT"] = round(r,   4)
            out["PRESCREEN_LIQ_WEIGHT"] = round(1-r, 4)
            issues.append(f"WEIGHT SUM: MOM+LIQ={mw+lw:.2f}≠1.0, normalised")
        if issues and log:
            for issue in issues:
                pass  # _arch_log removed (LOG003)
        out["_validated"] = True; out["_issues"] = issues
        return out

    @classmethod
    def diff(cls, a: dict, b: dict) -> list:
        return [(k, a.get(k), b.get(k))
                for k in sorted(set(a)|set(b))
                if a.get(k)!=b.get(k) and not k.startswith("_")]


# ─── Canonical scanner implementations ───────────────────────────────────────
@ScannerRegistry.register("technical_breakout")


# ────────────────────────────────────────────────────────────────────
# FUNC: _sc_breakout
# ────────────────────────────────────────────────────────────────────
def _sc_breakout(raw, params):
    import pandas as pd, math
    close = raw['Close'] if isinstance(raw.columns, pd.MultiIndex) else raw
    vol   = raw['Volume'] if isinstance(raw.columns, pd.MultiIndex) else pd.DataFrame()
    vsurge_thr = float(params.get('vsurge', 1.5))
    min_score  = int(params.get('min_score', 2))
    rows = []
    for ticker in close.columns:
        try:
            cl = close[ticker].dropna()
            if len(cl) < 60: continue
            cn   = float(cl.iloc[-1])
            h52  = float(cl[-252:].max()) if len(cl)>=252 else float(cl.max())
            ema20= float(cl.ewm(span=20,adjust=False).mean().iloc[-1])
            ema50= float(cl.ewm(span=50,adjust=False).mean().iloc[-1])
            d    = cl.diff(); up=d.clip(lower=0); dn=(-d).clip(lower=0)
            rsi  = float(100-100/(1+up.ewm(com=13,adjust=False).mean().iloc[-1]/
                                   max(dn.ewm(com=13,adjust=False).mean().iloc[-1],1e-9)))
            vr   = float('nan'); is_vs = False
            if not vol.empty and ticker in vol.columns:
                vo=vol[ticker].dropna()
                if len(vo)>=22:
                    avg20=float(vo.iloc[-21:-1].mean())
                    vr=float(vo.iloc[-1])/avg20 if avg20>0 else float('nan')  # DIV001: guard divisor before use
                    is_vs=not math.isnan(vr) and vr>=vsurge_thr
            score=(int(cn>=0.99*h52)+int(ema20>ema50)+int(is_vs)+int(rsi>60))
            if score<min_score: continue
            rows.append({'ticker':ticker,'momentum_6m':float(cl.iloc[-1]/cl.iloc[-127]-1) if len(cl)>=127 else 0,
                         'momentum_3m':float(cl.iloc[-1]/cl.iloc[-64]-1) if len(cl)>=64 else 0,
                         'rsi_norm':(rsi-50)/50,'volume_trend':float('nan'),
                         'delivery_pct':float('nan'),'breakout_dist':float(cn/h52-1),  # DIV001: guard divisor before use
                         'score':score,'_raw':{'close':cn,'rsi':rsi,'vol_ratio':vr}})
        except Exception as e: ExceptionLogger.swallow(e, f"breakout:{ticker}")
    return RankingEngine.rank_universe(rows)


@ScannerRegistry.register("momentum")


# ────────────────────────────────────────────────────────────────────
# FUNC: _sc_momentum
# ────────────────────────────────────────────────────────────────────
def _sc_momentum(raw, params):
    import pandas as pd, math
    close=raw['Close'] if isinstance(raw.columns,pd.MultiIndex) else raw
    vol  =raw['Volume'] if isinstance(raw.columns,pd.MultiIndex) else pd.DataFrame()
    rows = []
    for ticker in close.columns:
        try:
            cl=close[ticker].dropna()
            if len(cl)<130: continue
            r6m=float(cl.iloc[-1]/cl.iloc[-127]-1); r3m=float(cl.iloc[-1]/cl.iloc[-64]-1) if len(cl)>=64 else float('nan')
            avol=float(cl.pct_change().tail(63).std()*(TRADING_DAYS_PER_YEAR**0.5))
            ram=r6m/avol if avol>0 else float('nan')  # DIV001: guard divisor before use
            if math.isnan(ram): continue
            d=cl.diff(); up=d.clip(lower=0); dn=(-d).clip(lower=0)
            rsi=float(100-100/(1+up.ewm(com=13,adjust=False).mean().iloc[-1]/max(dn.ewm(com=13,adjust=False).mean().iloc[-1],1e-9)))
            vt=float('nan')
            if not vol.empty and ticker in vol.columns:
                vo=vol[ticker].dropna()
                if len(vo)>=20: vt=float(vo.tail(5).mean()/vo.tail(20).mean()-1)
            rows.append({'ticker':ticker,'momentum_6m':r6m,'momentum_3m':r3m,
                         'rsi_norm':(rsi-50)/50,'volume_trend':vt,
                         'delivery_pct':float('nan'),'breakout_dist':float('nan'),'_ram':ram})
        except Exception as e: ExceptionLogger.swallow(e, f"momentum:{ticker}")
    rows.sort(key=lambda x:x['_ram'],reverse=True)
    return RankingEngine.rank_universe(rows[:int(params.get('top_n',50))])


@ScannerRegistry.register("volume_expansion")


# ────────────────────────────────────────────────────────────────────
# FUNC: _sc_volume
# ────────────────────────────────────────────────────────────────────
def _sc_volume(raw, params):
    import pandas as pd, math
    close=raw['Close'] if isinstance(raw.columns,pd.MultiIndex) else raw
    vol  =raw['Volume'] if isinstance(raw.columns,pd.MultiIndex) else pd.DataFrame()
    vsurge=float(params.get('vsurge',2.0))
    rows=[]
    for ticker in close.columns:
        try:
            cl=close[ticker].dropna()
            if len(cl)<22 or vol.empty or ticker not in vol.columns: continue
            vo=vol[ticker].dropna()
            if len(vo)<22: continue
            avg20=float(vo.iloc[-21:-1].mean()); vr=float(vo.iloc[-1])/avg20 if avg20>0 else float('nan')  # DIV001: guard divisor before use
            if math.isnan(vr) or vr<vsurge: continue
            vt=float(vo.tail(5).mean()/vo.tail(20).mean()-1) if vo.tail(20).mean()>0 else 0
            rows.append({'ticker':ticker,'momentum_6m':float(cl.iloc[-1]/cl.iloc[-127]-1) if len(cl)>=127 else 0,
                         'momentum_3m':float('nan'),'rsi_norm':float('nan'),
                         'volume_trend':vt,'delivery_pct':float('nan'),'breakout_dist':float('nan'),'_vr':vr})
        except Exception as e: ExceptionLogger.swallow(e, f"volume:{ticker}")
    rows.sort(key=lambda x:x['_vr'],reverse=True)
    return RankingEngine.rank_universe(rows)


# ─── Architecture self-test ───────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: _arch_selftest
# ────────────────────────────────────────────────────────────────────
def _arch_selftest():
    s=AppState.get()
    if s is not AppState.get():
        raise AssertionError("AppState mismatch")
    c=DataCache()
    c.set("_t",42,60)
    if c.get("_t") != 42:
        raise AssertionError("DataCache set/get failed")
    c.invalidate("_t")
    if c.get("_t") is not None:
        raise AssertionError("DataCache invalidate failed")
    sc=RankingEngine.score_single({"momentum_6m":0.5,"volume_trend":0.3})
    if not (0<=sc<=100):
        raise AssertionError("Score out of bounds")
    cfg=ConfigValidator.validate({"PRESCREEN_MOM_WEIGHT":0.75,"PRESCREEN_LIQ_WEIGHT":0.30},log=False)
    if abs(cfg["PRESCREEN_MOM_WEIGHT"]+cfg["PRESCREEN_LIQ_WEIGHT"]-1.0) >= 0.01:
        raise ValueError("PRESCREEN_MOM_WEIGHT + PRESCREEN_LIQ_WEIGHT must sum to 1.0")
    if "technical_breakout" not in ScannerRegistry.list_scanners():
        raise RuntimeError("Scanner 'technical_breakout' not registered in ScannerRegistry")


# ────────────────────────────────────────────────────────────────────
# FUNC: _run_arch_selftest
# ────────────────────────────────────────────────────────────────────
def _run_arch_selftest():
    """Public entry point for the architecture self-test.
    Never called at import time — invoke explicitly or via __main__ guard."""
    try:
        _arch_selftest()
        pass  # _arch_log removed (LOG003)
    except Exception as _ae:
        pass  # _arch_log removed (LOG003)
        raise

if __name__ == "__main__":
    _run_arch_selftest()


class StopEventProxy:
    def __init__(self):
        self._local = threading.local()
        self._master_event = threading.Event()
        self._registered_events = set()
        self._lock = threading.Lock()

    @property
    def _event(self):
        return getattr(self._local, "event", None)

    @_event.setter
    def _event(self, val):
        self._local.event = val

    def set(self):
        self._master_event.set()
        ev = self._event
        if ev is not None:
            ev.set()
        with self._lock:
            for reg in list(self._registered_events):
                try:
                    reg.set()
                except Exception:
                    pass

    def clear(self):
        self._master_event.clear()
        ev = self._event
        if ev is not None:
            ev.clear()
        with self._lock:
            for reg in list(self._registered_events):
                try:
                    reg.clear()
                except Exception:
                    pass

    def is_set(self):
        if self._master_event.is_set():
            return True
        ev = self._event
        if ev is not None and ev.is_set():
            return True
        with self._lock:
            for reg in list(self._registered_events):
                try:
                    if reg.is_set():
                        return True
                except Exception:
                    pass
        return False

    def set_event(self, event):
        self._local.event = event
        if event is not None:
            with self._lock:
                self._registered_events.add(event)

    def clear_event(self):
        ev = getattr(self._local, "event", None)
        if ev is not None:
            with self._lock:
                self._registered_events.discard(ev)
        self._local.event = None

    def __bool__(self):
        return True

_ACTIVE_STOP_EVENT = StopEventProxy()
# AUDIT-FIX (defect #5): the bare module-level dict was shared across parallel
# profile workers — one worker's clear()/update() call would clobber another's
# mid-flight data. Reads now use a snapshot under the lock; writes are atomic.
_FUNDRAW_IC_CACHE: dict = {}  # v17.28: persists fundraw for IC learning
_FUNDRAW_IC_CACHE_LOCK = threading.RLock()  # AUDIT-FIX: guard the shared cache

def snapshot_fundraw_ic_cache() -> dict:
    """Returns a thread-safe copy of the fundamentals IC cache.

    Callers that previously accessed `_FUNDRAW_IC_CACHE` directly (which was a
    race-condition source under parallel profile workers) should use this
    snapshot helper instead.
    """
    with _FUNDRAW_IC_CACHE_LOCK:
        return dict(_FUNDRAW_IC_CACHE)

def update_fundraw_ic_cache(new_data: dict) -> None:
    """Atomically replaces the fundamentals IC cache contents.

    Replaces the prior `cache.clear(); cache.update(...)` two-step pattern
    that opened a window in which a parallel worker could read a half-cleared
    cache and propagate empty fundamentals into downstream IC calibration.
    """
    with _FUNDRAW_IC_CACHE_LOCK:
        _FUNDRAW_IC_CACHE.clear()
        _FUNDRAW_IC_CACHE.update(new_data or {})
_ACTIVE_STOP_EVENT_LOCK = threading.RLock()  # RLock: reentrant, safe from any call depth


# ── Post-Trade Prediction Validation (v17.25) ──────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: check_stop
# ────────────────────────────────────────────────────────────────────
def check_stop():
    with _ACTIVE_STOP_EVENT_LOCK:
        ev = _ACTIVE_STOP_EVENT
    if ev is not None and ev.is_set():
        raise StopRequested("Run cancelled by user.")


# ────────────────────────────────────────────────────────────────────
# FUNC: log_emit
# ────────────────────────────────────────────────────────────────────
def log_emit(cb, text, *args, **kwargs):
    check_stop()
    if cb:
        try:
            cb(str(text))
        except TypeError:
            pass


# ────────────────────────────────────────────────────────────────────
# FUNC: progress_span
# ────────────────────────────────────────────────────────────────────
def progress_span(cb, start, end, step, total):
    check_stop()
    if cb and total > 0:
        pct = int(start + (end - start) * step / total)  # DIV001: guard divisor before use
        cb(max(0, min(100, pct)))


# ────────────────────────────────────────────────────────────────────
# FUNC: chunked
# ────────────────────────────────────────────────────────────────────
def chunked(seq, size):
    for i in range(0, len(seq), size):
        yield seq[i:i + size]


# ────────────────────────────────────────────────────────────────────
# FUNC: parse_symbol_lines
# ────────────────────────────────────────────────────────────────────
def parse_symbol_lines(text):
    out = []
    for raw in text.splitlines():
        s = raw.strip().upper().replace(",", " ")
        if not s:
            continue
        # AUDIT-FIX (Round 6, C-P2-2): the previous `s.split()[0]` silently
        # DROPPED every symbol after the first on a comma-separated line
        # ("RELIANCE, TCS, INFY" → one ticker) — the manual-universe input
        # then optimized a 1-stock portfolio with no warning while its own
        # placeholder advertised comma-separated support. Iterate ALL tokens.
        for tok in s.split():
            if not tok:
                continue
            if not tok.endswith(".NS") and not tok.endswith(".BO"):
                tok = f"{tok}.NS"
            out.append(tok)
    return list(dict.fromkeys(out))


# ────────────────────────────────────────────────────────────────────
# FUNC: read_json_cache
# ────────────────────────────────────────────────────────────────────
def read_json_cache(path, default):
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception as _e2_:
        ExceptionLogger.swallow(_e2_, context="silent_catch")  # Cache miss is always non-fatal
    return default


# ────────────────────────────────────────────────────────────────────
# FUNC: write_json_cache
# ────────────────────────────────────────────────────────────────────
def write_json_cache(path, payload):
    # Phase 4.4: Atomic write via temp file + rename.
    # Previously: path.write_text() directly — if the process crashed mid-write
    # (power loss, OOM kill, KeyboardInterrupt), the file was left truncated/corrupt.
    # The next read_json_cache() would json.loads() the truncated content, raise
    # JSONDecodeError, and silently swallow it (returning default) — ERASING the
    # previous valid cache. This lost days of accumulated SAST/PEAD/bulk-deal data.
    # Now: write to a .tmp file, then atomically rename (POSIX rename is atomic).
    try:
        import os as _os
        # AUDIT-FIX (Round 6, C-P2-4): the tmp filename was deterministic per
        # target path — the 4+ parallel profile-worker processes all miss a
        # daily cache simultaneously on first run and race on the SAME .tmp
        # file: interleaved truncating writes could atomically install a
        # half-written JSON over a valid cache (the loser's os.replace then
        # raised FileNotFoundError, swallowed). Unique tmp per process+thread.
        _tmp = path.with_suffix(path.suffix + f".{_os.getpid()}.{threading.get_ident()}.tmp")
        _tmp.write_text(json.dumps(payload, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
        _os.replace(str(_tmp), str(path))  # atomic on POSIX and Windows (Python 3.3+)
    except Exception as _e2_:
        ExceptionLogger.swallow(_e2_, context="silent_catch")  # Write failure is non-fatal (disk full / permissions)


# ────────────────────────────────────────────────────────────────────
# FUNC: _pool_mean_fixed
# ────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: _chart_image_embedding_from_array
# ────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: _chart_image_embedding_from_file
# ────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: _apply_chart_embedding_projection
# ────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: _load_offline_chart_model
# ────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: _sample_chart_image_paths
# ────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: load_or_build_chart_ssl_model
# ────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: compute_multi_timeframe_chart_features
# ────────────────────────────────────────────────────────────────────
_VIT_CACHE = {}
_SWEEP_CHART_CACHE = {}
_SWEEP_CHART_PENDING = {}
_SWEEP_CHART_CACHE_LOCKS = {}
_SWEEP_CHART_CACHE_MASTER_LOCK = threading.RLock()




# ────────────────────────────────────────────────────────────────────
# FUNC: _ts_feature_vector
# ────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: ts_feature_vector_v2
# ────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: build_chart_tensor
# ────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: build_multitimeframe_input_bundle
# ────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: apply_score_calibration
# ────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: _build_live_chart_ssl_model
# ────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: compute_chart_ssl_features
# ────────────────────────────────────────────────────────────────────


def log_once_per_window(log_cb, text, window_sec=20):
    now = time.time()
    with _LAST_YF_WARNING_LOCK:
        w = _LAST_YF_WARNING.get("warning", {"text": "", "time": 0.0})
        if w.get("text") == text and (now - w.get("time", 0.0)) < window_sec:
            return
        _LAST_YF_WARNING.set("warning", {"text": text, "time": now})
    log_emit(log_cb, text)

# ── Math & Indicators ──


# ────────────────────────────────────────────────────────────────────
# Re-exported math & indicators from math_engine.indicators
# ────────────────────────────────────────────────────────────────────
from math_engine.indicators import (
    max_drawdown,
    trailing_return,
    momentum_skip_recent,
    ema_gap,
    annualized_vol,
    downside_vol,
    compute_rsi,
    robust_zscore_series,
    compute_beta
)

# ── Data Fetching ──


# ────────────────────────────────────────────────────────────────────
# FUNC: _real_or_demo
# ────────────────────────────────────────────────────────────────────
def _real_or_demo(metrics: dict, ticker: str, key: str, lo, hi, label: str = ''):
    """Return real metric if available; else deterministic demo fallback."""
    d = metrics.get(str(ticker).replace('.NS', ''), {}) if isinstance(metrics, dict) else {}
    v = d.get(key)
    if v is None and key == 'val':
        for fk in ('price', 'ret_1m', 'ret_6m', 'ret_12m', 'vol_ann', 'sharpe', 'mdd', 'hi52pct'):
            vv = d.get(fk)
            if vv is not None:
                v = vv
                break
    if v is not None:
        try:
            return max(float(lo), min(float(hi), float(v)))
        except Exception as _e:
            ExceptionLogger.swallow(_e, context='auto-EXC002')
    # Institutional integrity: Never fabricate synthetic random numbers via _demo_float
    return float(lo) if lo == hi else float((lo + hi) / 2.0)


# ────────────────────────────────────────────────────────────────────
# FUNC: _real_or_demo_int
# ────────────────────────────────────────────────────────────────────
def _real_or_demo_int(metrics: dict, ticker: str, key: str, lo: int, hi: int, label: str = ''):
    """Integer variant of _real_or_demo."""
    return int(round(_real_or_demo(metrics, ticker, key, lo, hi, label=label)))
# ─────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: extract_field_panel
# ────────────────────────────────────────────────────────────────────
def extract_field_panel(raw, field, requested_tickers):
    """Handles both old (level0=Ticker, level1=Field) and new (level0=Field, level1=Ticker)
    yfinance MultiIndex column layouts."""
    if raw is None or raw.empty:
        return pd.DataFrame(index=pd.Index([], name="Date"), columns=requested_tickers)
    if isinstance(raw.columns, pd.MultiIndex):
        level0_vals = [str(x) for x in raw.columns.get_level_values(0)]
        level1_vals = [str(x) for x in raw.columns.get_level_values(1)]
        level0_lower = [x.lower() for x in level0_vals]
        level1_lower = [x.lower() for x in level1_vals]
        # New yfinance >= 0.2: level0=Field, level1=Ticker
        if field.lower() in level0_lower:
            matched = level0_vals[level0_lower.index(field.lower())]
            out = raw[matched].copy()
        # Old yfinance: level0=Ticker, level1=Field
        elif field.lower() in level1_lower:
            matched = level1_vals[level1_lower.index(field.lower())]
            out = raw.xs(matched, axis=1, level=1).copy()
        else:
            return pd.DataFrame(index=raw.index, columns=requested_tickers)
    else:
        # Single-ticker flat download
        col_lower = [c.lower() for c in raw.columns]
        if field.lower() in col_lower:
            matched = list(raw.columns)[col_lower.index(field.lower())]
            out = raw[[matched]].copy()
            if len(requested_tickers) == 1:
                out.columns = requested_tickers
        else:
            return pd.DataFrame(index=raw.index, columns=requested_tickers)
    # Series guard: single-ticker multi_level_index download collapses to Series
    if isinstance(out, pd.Series):
        _tname = (str(raw.columns.get_level_values(1)[0])
                  if isinstance(raw.columns, pd.MultiIndex)
                  else (requested_tickers[0] if requested_tickers else "value"))
        out = out.to_frame(name=_tname)
    for t in requested_tickers:
        if t not in out.columns:
            out[t] = np.nan
    return out[requested_tickers].sort_index()


# ────────────────────────────────────────────────────────────────────
# FUNC: compute_prescreen_row
# ────────────────────────────────────────────────────────────────────
def compute_prescreen_row(ticker, close_series, volume_series, expected_days):
    close = close_series.dropna()
    volume = volume_series.dropna()
    idx = close.index.intersection(volume.index)
    close = close.loc[idx]
    volume = volume.loc[idx]

    min_required_days = max(20, int(expected_days * 0.30))
    if len(close) < min_required_days: return None

    returns = np.log(close / close.shift(1)).dropna()
    dollar_vol = (close * volume).tail(20)
    adv20 = float(dollar_vol.median()) if len(dollar_vol) >= 10 else np.nan
    avg_vol_20 = float(volume.tail(20).mean()) if len(volume) >= 20 else np.nan

    # Advanced Trend Features
    ema50_s = close.ewm(span=50, adjust=False).mean()
    ema50_val = float(ema50_s.iloc[-1]) if len(ema50_s) else np.nan

    sma150_val = float(close.tail(150).mean()) if len(close) >= 150 else np.nan
    sma200_val = float(close.tail(200).mean()) if len(close) >= 200 else np.nan

    high_52w = float(close.tail(252).max()) if len(close) >= 20 else np.nan
    low_52w = float(close.tail(252).min()) if len(close) >= 20 else np.nan

    pct_above_52w_low = float(close.iloc[-1] / low_52w - 1.0) if pd.notna(low_52w) and low_52w > 0 else np.nan
    pct_below_52w_high = float(1.0 - close.iloc[-1] / high_52w) if pd.notna(high_52w) and high_52w > 0 else np.nan

    # Flatline detection (illiquid/frozen names)
    price_std = float(close.tail(20).std()) if len(close) >= 20 else 0.0
    flatline = True if price_std < 1e-4 else False

    # ── Single-Day Volume Shock & Fresh Breakout Extraction ──
    turnover_today = float(close.iloc[-1] * volume.iloc[-1]) if len(close) > 0 and len(volume) > 0 else 0.0
    volume_today = float(volume.iloc[-1]) if len(volume) > 0 else 0.0
    prior_vol_series = volume.iloc[:-1].tail(20)
    prior_avg_vol = float(prior_vol_series.mean()) if len(prior_vol_series) >= 5 else (avg_vol_20 if pd.notna(avg_vol_20) else 1.0)
    vol_shock = float(volume_today / (prior_avg_vol + 1e-9)) if prior_avg_vol > 0 else 1.0

    prior_20_high = float(close.iloc[:-1].tail(20).max()) if len(close) >= 21 else float(close.max())
    breakout_distance_20d = float(close.iloc[-1] / (prior_20_high + 1e-9) - 1.0) if prior_20_high > 0 else 0.0
    day_return = float(close.iloc[-1] / (close.iloc[-2] + 1e-9) - 1.0) if len(close) >= 2 else 0.0

    vol_21 = float(returns.tail(21).std()) if len(returns) >= 10 else np.nan
    vol_63 = float(returns.tail(63).std()) if len(returns) >= 25 else np.nan
    range_contraction = float(1.0 - vol_21 / (vol_63 + 1e-9)) if pd.notna(vol_21) and pd.notna(vol_63) and vol_63 > 1e-9 else np.nan

    # Confirmed Institutional Volume Breakout (Day 1 / Day 2 pivot ignition)
    is_vol_breakout = bool(
        vol_shock >= 1.75
        and day_return >= 0.015
        and breakout_distance_20d >= -0.01
        and turnover_today >= 5_000_000.0
    )

    try: rsi = compute_rsi(close, 14)
    except Exception as _e:
        rsi = np.nan

    # ── INSTITUTIONAL EARLY-ENTRY SIGNALS ─────────────────────────────────────
    # Signal 1: VCP — Volatility Contraction Percentile (BB Width rank)
    # Low BB width percentile = stock coiling, building energy before breakout.
    # Bloomberg equivalent: realized vol percentile / IV rank.
    vcp_score = np.nan
    try:
        if len(close) >= 60:
            _sma20 = close.rolling(20).mean()
            _std20 = close.rolling(20).std()
            _bw = (_std20 * 4) / (_sma20 + 1e-9)  # BB width proxy (4σ / mid)
            _bw_clean = _bw.dropna()
            if len(_bw_clean) >= 40:
                _bw_now = float(_bw_clean.iloc[-1])
                _bw_52w = float(_bw_clean.tail(252).quantile(0.90))
                # Score: 1 - (current width / 90th pct width); high = very contracted
                vcp_score = float(max(0.0, 1.0 - _bw_now / (_bw_52w + 1e-9)))
    except Exception:
        vcp_score = np.nan

    # Signal 2: CMF — Chaikin Money Flow (21-day)
    # Positive = net institutional buying. Negative = net selling.
    # Formula: Σ[(C-L)-(H-C)]/(H-L)·V / ΣV over 21 days.
    # AUDIT-FIX (defect #P1-6): the prior implementation derived _high_t/_low_t
    # from `close.rolling(2).max()` / `close.rolling(2).min()` because the
    # function signature did not receive real intraday high/low. The result
    # was a byte-identical Spearman rank IC to updown_vol across 45 WFO folds.
    # We now return NaN when no real intraday high/low is available — callers
    # can attach `high`/`low` to `close.attrs` to opt into the correct path.
    cmf_score = np.nan
    try:
        _window = min(21, len(close) - 1)
        if _window >= 10:
            _close_t = close.tail(_window + 1)
            _vol_t = volume.tail(_window + 1)
            _high_t = _low_t = None
            if hasattr(close, "attrs") and "high" in (close.attrs or {}):
                _high_t = close.attrs["high"].tail(_window + 1)
            if hasattr(close, "attrs") and "low" in (close.attrs or {}):
                _low_t = close.attrs["low"].tail(_window + 1)
            if _high_t is None or _low_t is None:
                cmf_score = np.nan
            else:
                _hl = (_high_t - _low_t).replace(0, np.nan)
                _mfv = ((_close_t - _low_t) - (_high_t - _close_t)) / _hl * _vol_t
                _mfv = _mfv.dropna()
                _vol_sum = _vol_t.reindex(_mfv.index).sum()
                if _vol_sum > 0:
                    cmf_score = float(_mfv.sum() / _vol_sum)
    except Exception:
        cmf_score = np.nan

    # Signal 3: OBV Slope — On-Balance Volume trend over 21 days
    # Rising OBV on flat/declining price = hidden institutional accumulation.
    # Normalized by average volume for cross-sectional comparability.
    obv_slope = np.nan
    try:
        if len(close) >= 30:
            _close_chg = close.diff()
            _obv = (np.sign(_close_chg) * volume).fillna(0).cumsum()
            _obv_21 = _obv.tail(21)
            if len(_obv_21) >= 10:
                _x = np.arange(len(_obv_21), dtype=float)
                _slope = float(np.polyfit(_x, _obv_21.values, 1)[0])
                _avg_vol = float(volume.tail(21).mean()) + 1e-9
                obv_slope = _slope / _avg_vol  # normalize: slope as multiple of avg daily vol
    except Exception:
        obv_slope = np.nan

    # Signal 4: Up/Down Volume Ratio (21-day)
    # > 1.5 = aggressive net buying. < 0.7 = net selling.
    updown_vol = np.nan
    try:
        if len(close) >= 21 and len(volume) >= 21:
            _ret_21 = close.diff().tail(21)
            _vol_21 = volume.tail(21)
            _aligned = pd.concat([_ret_21.rename("ret"), _vol_21.rename("vol")], axis=1).dropna()
            _up_vol = float(_aligned.loc[_aligned["ret"] > 0, "vol"].sum())
            _dn_vol = float(_aligned.loc[_aligned["ret"] < 0, "vol"].sum())
            updown_vol = _up_vol / (_dn_vol + 1e-9)
    except Exception:
        updown_vol = np.nan

    # Signal 5: RS Rating proxy — weighted composite return (O'Neil-style)
    # 0.4×3m + 0.2×6m + 0.2×9m + 0.2×12m (cross-sectional ranking happens in optimizer)
    rs_raw = np.nan
    try:
        _n = len(close)
        _c = float(close.iloc[-1])
        _r3m  = (_c / float(close.iloc[max(0, _n - 63)])  - 1.0) if _n > 63  else np.nan
        _r6m  = (_c / float(close.iloc[max(0, _n - 126)]) - 1.0) if _n > 126 else np.nan
        _r9m  = (_c / float(close.iloc[max(0, _n - 189)]) - 1.0) if _n > 189 else np.nan
        _r12m = (_c / float(close.iloc[max(0, _n - 252)]) - 1.0) if _n > 252 else np.nan
        _rs_parts = [(_r3m, 0.40), (_r6m, 0.20), (_r9m, 0.20), (_r12m, 0.20)]
        _rs_val = sum(v * w for v, w in _rs_parts if pd.notna(v))
        _rs_wsum = sum(w for v, w in _rs_parts if pd.notna(v))
        rs_raw = float(_rs_val / _rs_wsum) if _rs_wsum > 0.1 else np.nan
    except Exception:
        rs_raw = np.nan

    # R35: single-source Neural-SDE ratio (identical formula at prescreen
    # row and signal-frame factor column — regression-locked equality).
    try:
        from math_engine.ipo_multibagger_math import neural_sde_ratio as _r35_sde_fn
        _r35_sde_prescreen = _r35_sde_fn(close)
    except Exception:
        _r35_sde_prescreen = np.nan

    return {
        "ticker": ticker,
        "last_price": float(close.iloc[-1]) if len(close) > 0 else np.nan,
        "data_pct": len(close) / expected_days if expected_days > 0 else 0.0,
        "adv20": adv20,
        "avg_vol_20": avg_vol_20,
        "ema_50": ema50_val,
        "sma_150": sma150_val,
        "sma_200": sma200_val,
        "high_52w": high_52w,
        "low_52w": low_52w,
        "pct_above_52w_low": pct_above_52w_low,
        "pct_below_52w_high": pct_below_52w_high,
        "flatline": flatline,
        "mom_1m": trailing_return(close, 21),
        "mom_3m": trailing_return(close, 63),
        "mom_6m": trailing_return(close, 126),
        "mom_12_1": momentum_skip_recent(close, 252, 21),
        "trend_50": ema_gap(close, 50),
        "ann_vol": annualized_vol(returns),
        "downside_vol": downside_vol(returns),
        "drawdown": max_drawdown(close, TRADING_DAYS_PER_YEAR),
        "rsi": rsi,
        # ── Institutional early-entry & IPO signals ──
        "bars_count":  len(close),
        "listing_days": (close.index[-1] - close.index[0]).days if hasattr(close.index, "days") or isinstance(close.index, pd.DatetimeIndex) else len(close),
        "vcp_score":   vcp_score,    # Volatility Contraction Percentile (coiling)
        "cmf_score":   cmf_score,    # Chaikin Money Flow (institutional buying pressure)
        "obv_slope":   obv_slope,    # OBV trend slope (hidden accumulation)
        "updown_vol":  updown_vol,   # Up/Down Volume Ratio (volume quality)
        "rs_raw":      rs_raw,       # O'Neil-style RS raw composite (ranked in optimizer)
        # ── SOTA Continuous-Time Stochastic Calculus & Fractal Dynamics ──
        # neural_sde: log-return μ/σ ratio — Ito SDE drift-to-diffusion efficiency.
        # R35: routed through the single-source neural_sde_ratio() so the
        # prescreen row and the signal-frame factor column are IDENTICAL by
        # construction (one formula, both call sites, regression-locked).
        "neural_sde":  _r35_sde_prescreen,
        # hurst: R/S Rescaled-Range analysis (Hurst 1951, Lo 1991).
        # Uses the authoritative 18-point log-log regression (min_lag=2, max_lag=20)
        # replacing the old 3-point std(Δclose.tail(k)) approximation which was
        # mathematically incorrect (used tail std of first-differences, not lagged-price
        # std, and only 3 points producing degenerate regression).
        "hurst":       compute_hurst_exponent(close, min_lag=2, max_lag=20) if len(close) >= 40 else 0.50,
        # ker: Kaufman Efficiency Ratio — directional displacement / total path length.
        # Window increased from 10→20 bars: IPO stocks exhibit high daily noise;
        # a 20-bar (~1 month) window gives a more stable signal-to-noise read.
        "ker":         float(abs(close.iloc[-1] - close.iloc[-21]) / (np.sum(np.abs(np.diff(close.tail(21).values))) + 1e-9)) if len(close) >= 25 else 0.50,
        # ── Geometric Base Formation & Compression Signals ──
        # base_tightness_pct: 20-day high-low consolidation spread / midpoint
        "base_tightness_pct": float((close.tail(20).max() - close.tail(20).min()) / (close.tail(20).mean() + 1e-9) * 100) if len(close) >= 10 else np.nan,
        # pivot_dist_pct: distance from 20-day upper resistance boundary (launchpad)
        "pivot_dist_pct": float(max(0.0, (close.tail(20).max() - close.iloc[-1]) / (close.tail(20).max() + 1e-9) * 100)) if len(close) >= 10 else 0.0,
        # ── Single-Day Volume Expansion & Fresh Breakout Metrics ──
        "turnover_today": turnover_today,
        "volume_today": volume_today,
        "vol_shock": vol_shock,
        "is_vol_breakout": is_vol_breakout,
        "breakout_distance_20d": breakout_distance_20d,
        "range_contraction": range_contraction,
        # ── Institutional SOTA Pre-Breakout Inception Probability ──
        "p_prebreakout": (
            float(np.clip(
                0.35 * (1.0 - min(1.0, float((close.tail(20).max() - close.tail(20).min()) / (close.tail(20).mean() + 1e-9)))) +
                0.25 * (vcp_score if pd.notna(vcp_score) else 0.5) +
                0.20 * min(1.0, vol_shock / 2.0) +
                0.20 * (1.0 - min(1.0, float(max(0.0, (close.tail(20).max() - close.iloc[-1]) / (close.tail(20).max() + 1e-9))))),
                0.01, 0.99
            ))
        ),
    }


# ────────────────────────────────────────────────────────────────────
# FUNC: process_prescreen_batch
# ────────────────────────────────────────────────────────────────────
def process_prescreen_batch(batch, cfg, log_cb=None):
    from data_layer import safe_download
    lookback = cfg.get("PRESCREEN_LOOKBACK", "1y") if cfg else "1y"
    raw = safe_download(batch, lookback, auto_adjust=True, log_cb=None)
    close = extract_field_panel(raw, "Close", batch)
    volume = extract_field_panel(raw, "Volume", batch)

    if close.empty or volume.empty: return []

    expected_days = len(close)
    is_manual = cfg.get("USE_MANUAL_UNIVERSE", False)

    # ── Pass 1: strict Minervini Stage-2 filters ──────────────────────────────
    pass1_rows = []
    pass2_rows = []  # relaxed fallback candidates
    for ticker in batch:
        if ticker not in close.columns or ticker not in volume.columns: continue
        row = compute_prescreen_row(ticker, close[ticker], volume[ticker], expected_days)
        if row is None: continue

        # 1. Base Filters (always applied)
        is_ipo_mode = cfg.get("PRESCREEN_MODE", "standard") == "ipo_multibagger"
        min_data_pct = 0.30 if (is_manual or is_ipo_mode) else cfg.get("MIN_DATA_PCT", 0.8)
        if row.get("data_pct", 0) < min_data_pct: continue

        if is_manual:
            # Relaxed basic quality checks for manual universe to prevent delisted/manipulated/penny assets
            # 1. Penny stock check (last price < 2 INR/USD)
            if pd.notna(row.get("last_price")) and row.get("last_price", 0) < 2.0: continue
            # 2. Extreme illiquidity check (ADV < 50,000 INR)
            if pd.notna(row.get("adv20")) and row.get("adv20", 0) < 50000.0: continue
            # 3. Flatline check (stuck/blocked asset)
            if row.get("flatline", False): continue
            # 4. Volatility floor/ceiling (e.g. annual vol > 250% is likely data spike/manipulation)
            if pd.notna(row.get("ann_vol")) and row.get("ann_vol", 0) > 2.5: continue
            # 5. Drawdown cap (e.g. > 90% indicates delisted or near-bankrupt)
            if pd.notna(row.get("drawdown")) and row.get("drawdown", 0) > 0.90: continue
        else:
            _min_adv = float(cfg.get("IPO_MIN_ADV20_INR", 15_000_000.0)) if is_ipo_mode else float(cfg.get("MIN_AVG_DOLLAR_VOL", 50_000_000.0))
            adv20_val = row.get("adv20", 0)
            turnover_today = row.get("turnover_today", 0)
            vol_shock = row.get("vol_shock", 1.0)
            is_vol_breakout = row.get("is_vol_breakout", False)

            # Institutional Liquidity Gate:
            # Passes if trailing 20d median turnover meets threshold, OR
            # if a fresh volume breakout brings immediate institutional liquidity (today's turnover >= 1 Cr or >= 40% of _min_adv)
            is_liquid = (pd.notna(adv20_val) and adv20_val >= _min_adv) or (
                is_vol_breakout and (turnover_today >= 10_000_000.0 or turnover_today >= _min_adv * 0.4)
            )
            if not is_liquid: continue
            if pd.isna(row.get("last_price")) or row.get("last_price", 0) < cfg.get("MIN_PRICE", 0): continue

            # 2. Share Volume & Flatline Filters
            min_share_vol = cfg.get("MIN_AVG_SHARE_VOL", 30000)
            vol_today = row.get("volume_today", 0)
            avg_vol_20 = row.get("avg_vol_20", 0)
            if (pd.isna(avg_vol_20) or avg_vol_20 < min_share_vol) and (vol_today < min_share_vol and vol_shock < 2.0): continue
            if row.get("flatline", False): continue

            # 3. Volatility Cap
            max_ann_vol = cfg.get("MAX_ANNUAL_VOL", 0.85)
            if pd.notna(row.get("ann_vol")) and row.get("ann_vol", 0) > max_ann_vol: continue

            # 4. Max Drawdown Cap
            max_dd_limit = cfg.get("MAX_DRAWDOWN_LIMIT", 0.60)
            if pd.notna(row.get("drawdown")) and row.get("drawdown", 0) > max_dd_limit: continue

        # --- record this ticker as a fallback (passed base liquidity/risk filters) ---
        if not is_ipo_mode:
            pass2_rows.append(row)

        if is_manual:
            pass1_rows.append(row)
            continue

        # 5. Strict Stage-2 Trend (Minervini) — Pass 1 only
        # SKIP for early_entry mode: Minervini Stage-2 requires price > SMA150/200,
        # which eliminates every base-building stock we are trying to find.
        if cfg.get("PRESCREEN_MODE", "standard") == "early_entry":
            # Early-entry prescreen: target stocks in the base-building zone
            # 25-70% below 52W high (not yet broken out), quality + accumulation signals
            pct_below = row.get("pct_below_52w_high", 0)
            drawdown  = row.get("drawdown", 0)
            adv20     = row.get("adv20", 0)
            turnover_today = row.get("turnover_today", 0)
            is_vol_breakout = row.get("is_vol_breakout", False)

            # Must not be a deeply broken value trap (> 75% below 52W high)
            if pd.notna(pct_below) and pct_below > 0.75:
                continue
            # For non-breakout coiling stocks, exclude extended names (< 15% below).
            # For fresh breakouts, breaking out to/near 52W high (< 15% below) is the ideal setup.
            if not is_vol_breakout and pd.notna(pct_below) and pct_below < 0.15:
                continue
            # Must have minimum liquidity (5 crore ADV or >= 1 crore on confirmed breakout)
            min_adv_early = float(cfg.get("MIN_ADV20_INR", 50_000_000.0))
            if (pd.isna(adv20) or adv20 < min_adv_early) and not (is_vol_breakout and turnover_today >= 10_000_000.0):
                continue
            pass1_rows.append(row)
            continue

        if cfg.get("PRESCREEN_MODE", "standard") == "ipo_multibagger":
            # IPO Multibagger: Target stocks listed 1-2 years before (post-IPO base building / stage-2 markup)
            # R35: gates extracted to the SINGLE SOURCE OF TRUTH
            # (math_engine/ipo_multibagger_math.ipo_gate_pass) — the inline
            # gate block and the regression tests are now guaranteed identical.
            # Gate order and semantics are byte-preserved from the R33 form:
            # listing age window → broken-issue → ADV floor → market-cap band
            # (permissive when unmeasurable) → base-formation geometry.
            from math_engine.ipo_multibagger_math import ipo_gate_pass as _r35_gate
            _r35_row = dict(row)
            _r35_row["bars_count"] = row.get("bars_count", len(close[ticker].dropna()) if ticker in close else len(close))
            if _r35_row.get("market_cap_cr") is None or (isinstance(_r35_row.get("market_cap_cr"), float) and np.isnan(_r35_row.get("market_cap_cr"))):
                try:
                    from math_engine.institutional_research_registry import get_ipo_market_cap_cr
                    _r35_row["market_cap_cr"] = get_ipo_market_cap_cr(ticker)
                except Exception:
                    _r35_row["market_cap_cr"] = None
            _r35_ok, _r35_why = _r35_gate(_r35_row, cfg, expected_days=expected_days,
                                          bars_count_default=len(close))
            if not _r35_ok:
                # R41: emit rejection reason so sweep logs are actionable
                _logging.getLogger("quantum_annealer").debug("[IPO Gate] %s REJECTED: %s", ticker, _r35_why)
                continue
            pass1_rows.append(row)
            pass2_rows.append(row)
            continue

        if cfg.get("REQUIRE_STAGE2_TREND", True):
            last_price = row.get("last_price", 0)
            sma_150 = row.get("sma_150", np.nan)
            sma_200 = row.get("sma_200", np.nan)
            ema_50  = row.get("ema_50",  np.nan)
            is_vol_breakout = row.get("is_vol_breakout", False)

            # Fresh base breakouts initiate Stage 2 from Stage 1:
            # Price must be above 50 EMA, but lagging 150/200 SMA crossovers have not yet converged.
            if is_vol_breakout:
                if pd.notna(ema_50) and last_price < ema_50: continue
            else:
                if pd.notna(sma_150) and last_price < sma_150: continue
                if pd.notna(sma_200) and last_price < sma_200: continue
                if pd.notna(ema_50) and pd.notna(sma_150) and ema_50 < sma_150: continue
                if pd.notna(sma_150) and pd.notna(sma_200) and sma_150 < sma_200: continue

        # 6. 52-Week Range Proximity — Pass 1 only
        max_52w_high_dist = cfg.get("MAX_52W_HIGH_DIST", 0.35)
        min_52w_low_dist  = cfg.get("MIN_52W_LOW_DIST",  0.25)
        is_vol_breakout = row.get("is_vol_breakout", False)
        effective_max_dist = max(max_52w_high_dist, 0.55) if is_vol_breakout else max_52w_high_dist
        if pd.notna(row.get("pct_below_52w_high")) and row.get("pct_below_52w_high", 0) > effective_max_dist: continue
        if pd.notna(row.get("pct_above_52w_low"))  and row.get("pct_above_52w_low",  0) < min_52w_low_dist:  continue

        pass1_rows.append(row)

    # ── Adaptive fallback: if Pass-1 is too sparse, blend in Pass-2 rows ─────
    # This prevents optimizer starvation in bear markets where Minervini Stage-2
    # criteria disqualify almost all NSE stocks.
    out_rows = pass1_rows
    if not is_manual and not is_ipo_mode and len(out_rows) < cfg.get("MIN_PRESCREEN_CANDIDATES", 8):
        # Pass 2: relaxed (no Stage-2 MA or 52w range check) — already computed
        extra = [r for r in pass2_rows if r not in pass1_rows]
        out_rows = pass1_rows + extra
    return out_rows


# ────────────────────────────────────────────────────────────────────
# FUNC: annualized_return
# ────────────────────────────────────────────────────────────────────
def annualized_return(equity_curve):
    if equity_curve is None or len(equity_curve) < 2:
        return np.nan
    total_return = float(equity_curve.iloc[-1] / equity_curve.iloc[0]) if len(equity_curve) > 1 else 1.0  # iloc guard
    years = len(equity_curve) / 252.0
    if total_return <= 0 or years <= 0:
        return np.nan
    return float(total_return ** (1.0 / years) - 1.0)  # DIV001: guard divisor before use


# ────────────────────────────────────────────────────────────────────
# FUNC: sharpe_from_returns
# ────────────────────────────────────────────────────────────────────
def sharpe_from_returns(returns, rf=0.0):
    r = returns.dropna()
    if len(r) < 2:
        return np.nan
    vol = r.std() * np.sqrt(TRADING_DAYS_PER_YEAR)
    if vol <= 1e-12:
        return np.nan
    return float(((r.mean() * TRADING_DAYS_PER_YEAR) - rf) / vol)  # DIV001: guard divisor before use


# ────────────────────────────────────────────────────────────────────
# FUNC: max_dd_from_equity
# ────────────────────────────────────────────────────────────────────
def max_dd_from_equity(equity_curve):
    s = equity_curve.dropna()
    if s.empty:
        return np.nan
    peak = s.cummax()
    dd = s / (peak + 1e-9) - 1.0
    return float(abs(dd.min())) if len(dd) else np.nan


# ────────────────────────────────────────────────────────────────────
# FUNC: factor_contribution_row
# ────────────────────────────────────────────────────────────────────
def factor_contribution_row(signal_df, ticker, cfg=None):
    # v17.23: use live IC-calibrated weights, not hardcoded defaults
    row = signal_df.loc[ticker]
    fw = (cfg or {}).get("FACTOR_WEIGHTS", {})
    def w(k, default=0.0): return fw.get(k, default)
    growth = w("z_mom_1m",0.08)*row["z_mom_1m"] + w("z_mom_3m",0.16)*row["z_mom_3m"] + w("z_mom_6m",0.17)*row["z_mom_6m"] + w("z_mom_12_1",0.20)*row["z_mom_12_1"]
    trend = w("z_trend_20",0.10)*row["z_trend_20"] + w("z_trend_50",0.08)*row["z_trend_50"]
    liquidity = w("z_vol_surge",0.05)*row["z_vol_surge"] + w("z_adv20",0.07)*row["z_adv20"]
    risk_drag = w("z_ann_vol",0.02)*row["z_ann_vol"] + w("z_downside_vol",0.01)*row["z_downside_vol"] + w("z_drawdown",0.02)*row["z_drawdown"]
    quality   = (w("z_rsi_pref",0.04)*row.get("z_rsi_pref",0.0)
                + w("z_roe",0.20)*row.get("z_roe",0.0)
                + w("z_de_inv",0.12)*row.get("z_de_inv",0.0)
                + w("z_rev_growth",0.10)*row.get("z_rev_growth",0.0))
    sector_lead = w("z_sector_rel_mom_6m",0.06)*row.get("z_sector_rel_mom_6m",0.0) + w("z_sector_rel_mom_1m",0.03)*row.get("z_sector_rel_mom_1m",0.0)
    return {
        "GrowthFactor": float(growth),
        "TrendFactor": float(trend),
        "LiquidityFactor": float(liquidity),
        "QualityFactor": float(quality),
        "SectorLeadFactor": float(sector_lead),
        "RiskDrag": float(risk_drag),
    }


# ────────────────────────────────────────────────────────────────────
# FUNC: summarize_selection_reason
# ────────────────────────────────────────────────────────────────────
def summarize_selection_reason(signal_df, ticker):
    row = signal_df.loc[ticker]
    traits = []
    if row["z_mom_12_1"] > 0.5:
        traits.append("strong 12-1 momentum")
    if row["z_trend_50"] > 0.5:
        traits.append("healthy trend structure")
    if row["z_adv20"] > 0.5:
        traits.append("high liquidity")
    if row.get("z_sector_rel_mom_6m", 0.0) > 0.5:
        traits.append("leading its sector")
    if row["z_beta_dev"] < 0:
        traits.append("beta close to benchmark")
    if row["z_ann_vol"] < 0:
        traits.append("contained realized volatility")
    if not traits:
        traits.append("balanced cross-factor profile")
    return ", ".join(traits[:3])


# ────────────────────────────────────────────────────────────────────
# FUNC: compute_portfolio_health
# ────────────────────────────────────────────────────────────────────
def compute_portfolio_health(portfolio_df):
    if portfolio_df is None or portfolio_df.empty:
        return {}

    weights = portfolio_df["Weight %"].astype(float)  # already decimal (0.127 = 12.7%)
    hhi = float((weights ** 2).sum())
    effective_n = float(1.0 / hhi) if hhi > 0 else np.nan  # DIV001: guard divisor before use
    top_weight = float(weights.max()) if len(weights) else np.nan
    weighted_beta = float((weights * portfolio_df["Beta"].fillna(1.0).astype(float)).sum()) if "Beta" in portfolio_df.columns else np.nan
    weighted_alpha = float((weights * portfolio_df["AlphaScore"].fillna(0.0).astype(float)).sum()) if "AlphaScore" in portfolio_df.columns else np.nan
    weighted_risk = float((weights * portfolio_df["RiskScore"].fillna(0.0).astype(float)).sum()) if "RiskScore" in portfolio_df.columns else np.nan

    by_sector = portfolio_df.groupby("Sector", dropna=False)["Weight %"].sum().sort_values(ascending=False)
    largest_sector = float(by_sector.iloc[0]) if len(by_sector) else np.nan

    return {
        "TopWeight": top_weight,
        "EffectiveNames": effective_n,
        "HHI": hhi,
        "LargestSectorWeight": largest_sector,
        "WeightedBeta": weighted_beta,
        "ActiveBeta": weighted_beta - 1.0 if pd.notna(weighted_beta) else np.nan,
        "WeightedAlpha": weighted_alpha,
        "WeightedRisk": weighted_risk,
    }


# ────────────────────────────────────────────────────────────────────
# FUNC: build_factor_summary
# ────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: build_exposures_summary
# ────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: generate_chart_pack
# ────────────────────────────────────────────────────────────────────
def generate_chart_pack(payload, target_dir):
    if not HAS_MATPLOTLIB:
        raise RuntimeError("matplotlib is not available in this environment.")

    price_df = payload.get("selected_price_df")
    volume_df = payload.get("selected_volume_df")
    portfolio_df = payload.get("portfolio_df")
    benchmark_series = payload.get("benchmark_price_series")
    if price_df is None or price_df.empty or portfolio_df is None or portfolio_df.empty:
        raise RuntimeError("No selected price history is available for chart export.")

    target_dir.mkdir(parents=True, exist_ok=True)
    for _, row in portfolio_df.iterrows():
        ticker = row["Ticker"]
        if ticker not in price_df.columns:
            continue
        close = price_df[ticker].dropna().tail(180)
        if close.empty:
            continue
        ma20 = close.rolling(20).mean()
        ma50 = close.rolling(50).mean()
        vol = volume_df[ticker].dropna().reindex(close.index) if isinstance(volume_df, pd.DataFrame) and ticker in volume_df.columns else pd.Series(index=close.index, dtype=float)

        fig, axes = plt.subplots(2, 1, figsize=(12, 7), sharex=True, gridspec_kw={"height_ratios": [4, 1]})
        axes[0].plot(close.index, close.values, label="Close", color="#17324d", linewidth=2.0)
        axes[0].plot(ma20.index, ma20.values, label="MA20", color="#b8742d", linewidth=1.4)
        axes[0].plot(ma50.index, ma50.values, label="MA50", color="#1f5f5b", linewidth=1.4)
        axes[0].set_title(f"{ticker} | Weight {float(row['Weight %']):.1%} | Alpha {float(row['AlphaScore']):.2f}")
        axes[0].legend(loc="upper left")
        axes[0].grid(alpha=0.18)

        if benchmark_series is not None and len(benchmark_series.dropna()) > 0:
            bench = benchmark_series.dropna().reindex(close.index).ffill().dropna()
            if not bench.empty:
                rel = (close / close.iloc[0]) - (bench / bench.iloc[0])
                axes[0].text(0.99, 0.03, f"Active rel {rel.iloc[-1]:+.1%}", transform=axes[0].transAxes, ha="right", va="bottom", fontsize=9, color="#8b6f47")

        axes[1].bar(vol.index, vol.values, color="#cdb38c", width=2.0)
        axes[1].grid(alpha=0.10)
        axes[1].set_ylabel("Vol", fontsize=9)

        fig.tight_layout()
        out_path = target_dir / f"{ticker.replace('.', '_')}.png"
        fig.savefig(out_path, dpi=140, bbox_inches="tight")
        plt.close(fig)


# ────────────────────────────────────────────────────────────────────
# FUNC: load_last_run_state
# ────────────────────────────────────────────────────────────────────
def load_last_run_state():
    try:
        if LAST_RUN_PATH.exists():
            return json.loads(LAST_RUN_PATH.read_text(encoding="utf-8"))
    except Exception as _e:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception in %s", "Exception", exc_info=True)  # noqa: E501
        return {}
    return {}


# ────────────────────────────────────────────────────────────────────
# FUNC: build_selection_changes
# ────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: payload_to_serializable
# ────────────────────────────────────────────────────────────────────
def payload_to_serializable(payload):
    serializable = dict(payload)
    for key in [
        "portfolio_df", "prescreen_df", "diagnostics_df", "corr_df", "sector_summary_df", "factor_summary_df",
        "exposures_df", "sector_relative_df", "changes_df", "alerts_df", "selected_price_df", "selected_volume_df"
    ]:
        df = serializable.get(key)
        if isinstance(df, pd.DataFrame):
            serializable[key] = df.replace({np.nan: None}).to_dict(orient="records")
    if isinstance(serializable.get("benchmark_price_series"), pd.Series):
        series = serializable["benchmark_price_series"].dropna()
        serializable["benchmark_price_series"] = {str(k): float(v) for k, v in series.items()}

    backtest = serializable.get("backtest")
    if isinstance(backtest, dict):
        cleaned = {}
        for k, v in backtest.items():
            if isinstance(v, pd.Series):
                cleaned[k] = [None if pd.isna(x) else float(x) for x in v.tolist()]
            elif isinstance(v, (np.floating, np.integer)):
                cleaned[k] = v.item()
            else:
                cleaned[k] = v
        serializable["backtest"] = cleaned
    return serializable


# ────────────────────────────────────────────────────────────────────
# FUNC: build_alerts
# ────────────────────────────────────────────────────────────────────


# ═══════════════════════════════════════════════════════════════════════════════
# INSTITUTIONAL RISK ANALYTICS
# ═══════════════════════════════════════════════════════════════════════════════

# ── NSE Historical Stress Scenarios ────────────────────────────────────────────
# Peak-to-trough Nifty 50 drawdowns for each event.
NSE_STRESS_SCENARIOS = {
    "COVID Crash (Feb–Mar 2020)":     -0.382,  # Nifty -38.2% in 40 days
    "2022 Rate Shock (Jan–Jun 2022)": -0.173,  # Nifty -17.3% in H1 2022
    "IL&FS Crisis (Sep–Oct 2018)":    -0.144,  # Nifty -14.4% over 2 months
    "Demonetization (Nov 2016)":      -0.065,  # Nifty -6.5% in 1 week
    "Taper Tantrum (May 2013)":       -0.118,  # Nifty -11.8% over 6 weeks
    "GFC Analog (Oct 2008)":          -0.552,  # Nifty -55.2% peak-to-trough
    "2-Sigma 20-day Shock":           None,     # Computed from portfolio vol
    "3-Sigma 20-day Shock":           None,
}


# ────────────────────────────────────────────────────────────────────
# FUNC: estimate_survivorship_bias
# ────────────────────────────────────────────────────────────────────
def estimate_survivorship_bias(lookback_period_str="2y", log_cb=None):
    """
    Estimate survivorship bias in backtest returns.

    Method: Based on academic literature for emerging-market momentum strategies.
    NSE delisting rate ≈ 2–4% per year. Momentum strategies suffer more because
    delisted stocks disproportionately were momentum losers/crashes.

    Elton et al. (1996): survivorship bias ≈ 0.4–1.0% per year for equity funds.
    Brown et al. (1995): for momentum portfolios, 1.5–3.5% per year.
    NSE-specific adjustment: EM markets have higher delisting rates → upper range.

    Reference: Shumway (1997): delisting-adjusted returns reduce momentum alpha by ~2%.
    """
    lookback_years = {"6m": 0.5, "1y": 1.0, "2y": 2.0, "3y": 3.0, "5y": 5.0}.get(lookback_period_str, 2.0)
    annual_delisting_rate = 0.028       # ~2.8% NSE annual delisting rate (avg 2015–2024)
    bias_per_delisting    = 0.063       # ~6.3% per delisted stock bias (from Shumway 1997)
    annual_bias_pct       = annual_delisting_rate * bias_per_delisting * 100
    total_bias_pct        = annual_bias_pct * lookback_years

    return {
        "AnnualBiasEstimate_pct":    round(annual_bias_pct, 2),
        "TotalBiasEstimate_pct":     round(total_bias_pct, 2),
        "LookbackYears":             lookback_years,
        "AnnualDelistingRate":       f"{annual_delisting_rate*100:.1f}%",
        "Methodology":               "Shumway (1997) + NSE delisting rate 2015-2024",
        "Warning":                   (
            f"WFO returns may be overstated by ~{annual_bias_pct:.1f}%/yr "
            f"({total_bias_pct:.1f}% total over {lookback_years:.0f}y) "
            f"due to survivorship bias. Use point-in-time data (Bloomberg/Refinitiv) "
            f"to eliminate this."
        ),
    }


# ────────────────────────────────────────────────────────────────────
# FUNC: build_diagnostics_frame
# ────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: scrub_anomalies
# ────────────────────────────────────────────────────────────────────
def scrub_anomalies(returns, log_cb=None):
    """Spike-cleans tickers with absurd daily jumps (unadjusted YF splits/errors).
    Patches the bad DAY via prev+next interpolation — keeps ALL tickers in universe."""
    # Per-ticker IQR-based spike threshold: clips at median ± 8×IQR.
    # More adaptive than a fixed ±40%: avoids both false positives on
    # high-beta small-caps and false negatives on split-adjusted ADRs.
    _q1 = returns.quantile(0.25); _q3 = returns.quantile(0.75)
    _iqr = (_q3 - _q1).clip(lower=1e-6)
    _lo  = (_q1 - 8.0 * _iqr).clip(upper=-0.10)  # never tighter than ±10%
    _hi  = (_q3 + 8.0 * _iqr).clip(lower= 0.10)
    bad_mask = (returns < _lo) | (returns > _hi)
    bad_cols    = bad_mask.any()
    bad_tickers = returns.columns[bad_cols].tolist()
    if bad_tickers:
        returns = returns.copy()
        returns[bad_mask] = float("nan")
        returns = returns.interpolate(method='linear').ffill().bfill()
        log_emit(log_cb, f"[ScrubAnomalies] Spike-cleaned {len(bad_tickers)} tickers "
                         f"(bad day patched, kept in universe): {bad_tickers}")
    return returns

# ── Signal Generation ──

# ─────────────────────────────────────────────────────────────
# NEW SIGNAL FETCHERS — 7 uncrowded NSE alpha sources
# ─────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: compute_signal_frame
# ────────────────────────────────────────────────────────────────────
def compute_signal_frame(data, returns, benchmark_returns, sectors=None, cfg=None, log_cb=None):
    rows = []

    # AUDIT-FIX (Round 25 — R25-3): per-stock FACTOR-MODEL beta priors. The
    # R24 liquidity-aware estimator shrank illiquid/attenuated betas toward a
    # FLAT prior (BETA_SHRINK_PRIOR, default 1.0 = "the market"). This pre-pass
    # builds a stock-specific prior the Barra way — a cross-sectional ridge of
    # trailing OLS betas on observable characteristics (log-ADV, 6m momentum,
    # 63d vol), predicted LEAVE-ONE-OUT — so an illiquid microcap now shrinks
    # toward the beta its characteristics imply, not a flat 1.0. Priority:
    #   1. cfg BETA_FACTOR_FEED {ticker: beta} — a licensed per-stock feed
    #      (Barra/Axioma) overrides everything (the integration point);
    #   2. the local characteristic factor model (USE_FACTOR_MODEL_BETA_PRIOR,
    #      default True) when the cross-section is big enough;
    #   3. the flat BETA_SHRINK_PRIOR fallback (R24 semantics) otherwise.
    # The prior actually used per row is disclosed in the beta_prior /
    # beta_prior_source columns alongside R24's beta_raw / beta_shrink_weight.
    _beta_prior_map: Dict[str, float] = {}
    _beta_prior_src = "flat market prior (BETA_SHRINK_PRIOR)"
    try:
        if benchmark_returns is not None and not benchmark_returns.empty:
            _feed = (cfg or {}).get("BETA_FACTOR_FEED") or None
            if isinstance(_feed, dict) and _feed:
                _beta_prior_map = {str(k).upper(): float(v) for k, v in _feed.items()
                                   if isinstance(v, (int, float)) and np.isfinite(float(v))}
                _beta_prior_src = ("licensed factor feed (cfg BETA_FACTOR_FEED) — "
                                   f"{len(_beta_prior_map)} per-stock priors")
            elif (cfg is None or cfg.get("USE_FACTOR_MODEL_BETA_PRIOR", True)) \
                    and (cfg is None or cfg.get("USE_LIQUIDITY_AWARE_BETA", True)):
                from math_engine.indicators import factor_model_beta_prior
                _fp = factor_model_beta_prior(
                    returns,
                    close=(data.get("Close") if isinstance(data, dict) else None),
                    volume=(data.get("Volume") if isinstance(data, dict) else None),
                    benchmark_returns=benchmark_returns,
                    beta_window=int(cfg.get("BETA_WINDOW_DAYS", 63)) if cfg is not None else 63,
                    adv20_ref_inr=float(cfg.get("BETA_LIQ_REF_ADV_INR", 5.0e7)) if cfg is not None else 5.0e7,
                )
                if _fp.get("priors"):
                    _beta_prior_map = {str(k).upper(): float(v) for k, v in _fp["priors"].items()}
                    _m = _fp.get("model") or {}
                    _beta_prior_src = ("characteristic factor model (cross-sectional ridge on "
                                       f"log-ADV/mom/vol, LOO; n={_m.get('n_stocks')}, "
                                       f"r2={_m.get('r2')})")
                else:
                    _beta_prior_src = ("flat market prior (BETA_SHRINK_PRIOR) — characteristic "
                                       f"factor model unavailable: {(_fp.get('model') or {}).get('reason')}")
    except Exception as _fp_e:
        _beta_prior_map = {}
        _beta_prior_src = f"flat market prior (BETA_SHRINK_PRIOR) — factor prior build failed: {_fp_e}"
        log_emit(log_cb, f"[SignalFrame] beta factor-prior pre-pass failed: {_fp_e}")

    for s in returns.columns:
        close = data["Close"][s].dropna()
        volume = data["Volume"][s].dropna()
        asset_rets = returns[s].dropna()

        idx = close.index.intersection(volume.index).intersection(asset_rets.index)
        close = close.loc[idx]
        volume = volume.loc[idx]
        asset_rets = asset_rets.loc[idx]

        if len(close) < 60 or len(asset_rets) < 60:
            continue

        adv20 = float((close * volume).tail(20).mean())
        avg_turnover_10 = float((close * volume).tail(10).mean())
        rsi = compute_rsi(close, 14)
        ema20_s = close.ewm(span=20, adjust=False).mean()
        ema50_s = close.ewm(span=50, adjust=False).mean()
        _turnover = (close * volume).replace([np.inf, -np.inf], np.nan).dropna()

        # ── v17.3: idiosyncratic momentum (market-orthogonal) ─────────────
        if benchmark_returns is not None:
            # AUDIT-FIX (Round 24 — R24-3): beta is now a LIQUIDITY-AWARE
            # shrinkage estimate, not the raw 63d OLS covariance beta. Raw
            # OLS betas of illiquid microcaps are attenuated toward zero by
            # stale/asynchronous prices (Epps / non-trading bias), which
            # previously collapsed the tail hedge until a flat 0.30 policy
            # floor was bolted on (R23-3). The estimator shrinks low-liquidity
            # rows toward the prior (market beta 1.0) with weight
            # n_eff/(n_eff+kappa), n_eff = n_valid x clip(adv20/liq_ref_adv);
            # liquid names keep essentially their OLS beta. Raw beta + shrink
            # weight are retained as columns for disclosure; the floor at the
            # hedge site becomes a backstop instead of the model.
            _use_liq_beta = True
            if cfg is not None:
                _use_liq_beta = bool(cfg.get("USE_LIQUIDITY_AWARE_BETA", True))
            if _use_liq_beta:
                from math_engine.indicators import liquidity_aware_beta
                # R25-3: per-stock prior (feed > characteristic factor model > flat)
                _tkr_key = str(s).upper()
                _prior_for_tkr = _beta_prior_map.get(_tkr_key)
                if _prior_for_tkr is None or not np.isfinite(_prior_for_tkr):
                    _prior_for_tkr = float(cfg.get("BETA_SHRINK_PRIOR", 1.0)) if cfg is not None else 1.0
                    _beta_prior_src_row = ("flat market prior (BETA_SHRINK_PRIOR) — no "
                                           "factor-model prior for this row")
                else:
                    _beta_prior_src_row = _beta_prior_src
                beta_val, _beta_diag = liquidity_aware_beta(
                    asset_rets, benchmark_returns, adv20=adv20,
                    window=int(cfg.get("BETA_WINDOW_DAYS", 63)) if cfg is not None else 63,
                    prior=_prior_for_tkr,
                    kappa=float(cfg.get("BETA_SHRINK_KAPPA", 8.0)) if cfg is not None else 8.0,
                    liq_ref_adv=float(cfg.get("BETA_LIQ_REF_ADV_INR", 5.0e7)) if cfg is not None else 5.0e7,
                )
                beta_raw_val = _beta_diag.get("beta_ols", float("nan"))
                beta_shrink_w = _beta_diag.get("shrink_weight", 0.0)
                beta_prior_val = float(_prior_for_tkr)
            else:
                beta_val = compute_beta(asset_rets, benchmark_returns)
                beta_raw_val = beta_val
                beta_shrink_w = 1.0
                beta_prior_val = 1.0
                _beta_prior_src_row = "n/a (liquidity-aware beta off)"
            _bench_sub = benchmark_returns.reindex(asset_rets.index).fillna(0.0)
        else:
            beta_val   = 1.0
            beta_raw_val = 1.0
            beta_shrink_w = 1.0
            beta_prior_val = 1.0
            _beta_prior_src_row = "n/a (no benchmark returns)"
            _bench_sub = pd.Series(0.0, index=asset_rets.index)
        _resid_rets = asset_rets - beta_val * _bench_sub
        _resid_cs   = _resid_rets.cumsum()
        idio_mom_3m = float(_resid_cs.iloc[-1] - _resid_cs.iloc[max(-64,  -len(_resid_cs))])                       if len(_resid_cs) >= 21 else np.nan
        idio_mom_6m = float(_resid_cs.iloc[-1] - _resid_cs.iloc[max(-127, -len(_resid_cs))])                       if len(_resid_cs) >= 60 else np.nan

        # ── v17.3: volatility-of-volatility (regime instability) ─────────
        _rvol      = asset_rets.rolling(21).std().dropna()
        vol_of_vol = float(_rvol.tail(42).std())                      if len(_rvol) >= 42 else np.nan  # v17-patch: raw std, not CV — CV biased against high-vol stocks

        # ── v17.3: trend quality — R² of price vs 60-day linear fit ──────
        _pc = close.tail(60).values
        if len(_pc) >= 20:
            _x    = np.arange(len(_pc), dtype=float) - len(_pc) / 2.0
            _c    = np.polyfit(_x, _pc, 1)
            _fit  = np.polyval(_c, _x)
            _ss_r = np.sum((_pc - _fit) ** 2)
            _ss_t = np.sum((_pc - _pc.mean()) ** 2)
            trend_quality = float(1.0 - _ss_r / (_ss_t + 1e-12)) if _ss_t > 1e-9 else 0.0
        else:
            trend_quality = np.nan

        _ret21 = asset_rets.tail(21)
        _ret63 = asset_rets.tail(63)
        vol_21 = float(_ret21.std()) if len(_ret21) >= 10 else np.nan
        vol_63 = float(_ret63.std()) if len(_ret63) >= 25 else np.nan
        range_contraction = float(1.0 - vol_21 / (vol_63 + 1e-9)) if pd.notna(vol_21) and pd.notna(vol_63) and vol_63 > 1e-9 else np.nan

        turn_5 = float(_turnover.tail(5).mean()) if len(_turnover) >= 5 else np.nan
        turn_20 = float(_turnover.tail(20).mean()) if len(_turnover) >= 10 else np.nan
        volume_dryup = float(1.0 - turn_5 / (turn_20 + 1e-9)) if pd.notna(turn_5) and pd.notna(turn_20) and turn_20 > 1e-9 else np.nan

        price_above_20d_frac = float((close.tail(15) > ema20_s.tail(15)).mean()) if len(close) >= 15 else np.nan
        price_above_50d_frac = float((close.tail(30) > ema50_s.tail(30)).mean()) if len(close) >= 30 else np.nan
        up_day_frac_21 = float((_ret21 > 0).mean()) if len(_ret21) >= 10 else np.nan

        ema20_last = float(ema20_s.iloc[-1]) if len(ema20_s) else np.nan
        ema50_last = float(ema50_s.iloc[-1]) if len(ema50_s) else np.nan
        ma_compression = float(1.0 - abs(ema20_last / (ema50_last + 1e-9) - 1.0) / 0.08) if pd.notna(ema20_last) and pd.notna(ema50_last) and ema50_last != 0 else np.nan

        if len(close) >= 21:
            _prior_20_high = float(close.tail(21).iloc[:-1].max())
            breakout_distance_20d = float(close.iloc[-1] / (_prior_20_high + 1e-9) - 1.0) if _prior_20_high > 0 else np.nan
        else:
            breakout_distance_20d = np.nan

        trigger_persistence = np.nan
        _valid_pers = [x for x in [price_above_20d_frac, price_above_50d_frac, up_day_frac_21] if pd.notna(x)]
        if _valid_pers:
            trigger_persistence = float(np.mean(_valid_pers))

        # Single-day institutional volume expansion & fresh breakout detection
        turnover_today = float(close.iloc[-1] * volume.iloc[-1]) if len(close) > 0 and len(volume) > 0 else 0.0
        volume_today = float(volume.iloc[-1]) if len(volume) > 0 else 0.0
        prior_vol_s = volume.iloc[:-1].tail(20)
        prior_avg_vol = float(prior_vol_s.mean()) if len(prior_vol_s) >= 5 else float(volume.tail(20).mean())
        vol_shock = float(volume_today / (prior_avg_vol + 1e-9)) if prior_avg_vol > 0 else 1.0
        day_ret = float(close.iloc[-1] / (close.iloc[-2] + 1e-9) - 1.0) if len(close) >= 2 else 0.0

        is_vol_breakout = bool(
            vol_shock >= 1.75
            and day_ret >= 0.015
            and (pd.notna(breakout_distance_20d) and breakout_distance_20d >= -0.01)
            and turnover_today >= 5_000_000.0
        )

        # Absolute Trend Filter Guard
        # Standard mode: Price above 50 EMA AND 3M Return >= 0
        # Early-entry mode: Only remove genuinely broken stocks (price < 200 EMA AND 6M return < -40%)
        # This allows base-building stocks (below 50 EMA, flat/negative 3M) to pass through —
        # which is exactly the setup the Smart Money Early-Entry profile is looking for.
        passed_absolute_trend = True
        if cfg is not None and cfg.get("ENABLE_ABSOLUTE_TREND_GUARD", True):
            trend_guard_mode = str(cfg.get("TREND_GUARD_MODE", "standard")).lower()
            ema20_val = float(ema20_s.iloc[-1]) if len(ema20_s) else np.nan
            ema50_val = float(ema50_s.iloc[-1]) if len(ema50_s) else np.nan
            mom_1m_val = trailing_return(close, 21)
            mom_3m_val = trailing_return(close, 63)
            mom_6m_val = trailing_return(close, 126)

            # ── Universal Mathematical Anti-Falling-Knife Guard ──
            # Explicitly eliminate equities undergoing severe downward breakdown:
            # 1. Trading below both its 20 EMA and 50 EMA with 1M return < -7% (acute short-term plunge)
            # 2. Breaking down > 12% in the last 21 trading days
            # 3. Last 15 trading days spending > 85% of time below 20 EMA with negative short-term momentum
            if pd.notna(ema20_val) and pd.notna(ema50_val) and pd.notna(mom_1m_val):
                if (close.iloc[-1] < ema20_val and close.iloc[-1] < ema50_val and mom_1m_val < -0.07) or mom_1m_val < -0.12:
                    passed_absolute_trend = False
                elif pd.notna(price_above_20d_frac) and price_above_20d_frac < 0.15 and mom_1m_val < -0.05:
                    passed_absolute_trend = False

            if passed_absolute_trend:
                if trend_guard_mode in ["early_entry", "quality_compounders", "pure_defensive", "garp", "accumulation", "vol_squeeze"]:
                    # Style-specific prescreening: do not filter out non-momentum stocks using 50 EMA
                    if trend_guard_mode == "early_entry":
                        ema200_s_tg = close.ewm(span=200, adjust=False).mean()
                        ema200_val  = float(ema200_s_tg.iloc[-1]) if len(ema200_s_tg) >= 100 else np.nan
                        if (pd.notna(ema200_val) and pd.notna(mom_6m_val)
                                and close.iloc[-1] < ema200_val * 0.85
                                and mom_6m_val < -0.40):
                            passed_absolute_trend = False
                    elif trend_guard_mode == "pure_defensive":
                        # Defensive mode: only filter out extreme volatility (>45% ann vol) or severe crashes (>35% drawdown)
                        if pd.notna(vol_21) and vol_21 * np.sqrt(252) > 0.45:
                            passed_absolute_trend = False
                    elif trend_guard_mode == "quality_compounders":
                        # Quality mode: allow stocks even if below 50 EMA as long as 6M return > -25%
                        if pd.notna(mom_6m_val) and mom_6m_val < -0.25:
                            passed_absolute_trend = False
                else:
                    # Standard / Momentum mode: price above 50 EMA and 3M return >= 0
                    # Fresh institutional breakout exception:
                    # If staging a Day-1 volume breakout above 50 EMA, do not prune for flat pre-breakout 3M returns
                    if pd.notna(ema50_val) and pd.notna(mom_3m_val):
                        if is_vol_breakout:
                            if close.iloc[-1] < ema50_val:
                                passed_absolute_trend = False
                        else:
                            if close.iloc[-1] < ema50_val or mom_3m_val < 0:
                                passed_absolute_trend = False

        # ── INSTITUTIONAL SIGNALS (computed per-ticker, z-scored later) ──────
        # VCP: Volatility Contraction Percentile — BB width vs 52W history
        _vcp = np.nan
        try:
            if len(close) >= 60:
                _sma20_sf = close.rolling(20).mean()
                _std20_sf = close.rolling(20).std()
                _bw_sf = (_std20_sf * 4) / (_sma20_sf + 1e-9)
                _bw_clean_sf = _bw_sf.dropna()
                if len(_bw_clean_sf) >= 40:
                    _bw_now_sf = float(_bw_clean_sf.iloc[-1])
                    _bw_90p_sf = float(_bw_clean_sf.tail(252).quantile(0.90))
                    _vcp = float(max(0.0, 1.0 - _bw_now_sf / (_bw_90p_sf + 1e-9)))
        except Exception:
            _vcp = np.nan

        # CMF: Chaikin Money Flow (21d) — institutional net buying pressure
        # AUDIT-FIX (defect #P1-6): the prior implementation derived _ht/_lt
        # from `close.rolling(2).max()` / `close.rolling(2).min()` because the
        # function signature did not receive real intraday high/low. The
        # resulting _cmf reduces algebraically to (U - D) / (U + D) — which
        # is a monotonic transform of `_updown_vol = U / D`. Since the WFO
        # loop uses Spearman rank IC (invariant under monotonic
        # transformations), the two factors produced byte-identical IC
        # statistics across all 45 walk-forward folds. We now (a) try to
        # read real intraday high/low from the OHLC frame where available,
        # (b) return NaN when real high/low are unavailable rather than
        # silently degrading to the close-derived proxy. Callers can pass
        # `high_series=` / `low_series=` to opt into the correct path.
        _cmf = np.nan
        try:
            _win = min(21, len(close) - 1)
            if _win >= 10:
                _ct = close.tail(_win + 1)
                _vt = volume.tail(_win + 1)
                # AUDIT-FIX (defect #P1-6): prefer real intraday high/low.
                # Walk up the call stack to find a frame with 'High'/'Low'
                # columns; if none, return NaN rather than fabricate from
                # close. (For the WFO validation to produce *distinct*
                # statistics, the factors must compute different things.)
                _ht = _lt = None
                # Caller can pre-attach High/Low series to `close` as attrs.
                if hasattr(close, "attrs") and "high" in (close.attrs or {}):
                    _ht = close.attrs["high"].tail(_win + 1)
                if hasattr(close, "attrs") and "low" in (close.attrs or {}):
                    _lt = close.attrs["low"].tail(_win + 1)
                if _ht is None or _lt is None:
                    # No real intraday high/low available — return NaN
                    # instead of the close-derived proxy that made cmf
                    # byte-identical to updown_vol under Spearman.
                    _cmf = np.nan
                else:
                    _hl_sf = (_ht - _lt).replace(0, np.nan)
                    _mfv_sf = ((_ct - _lt) - (_ht - _ct)) / _hl_sf * _vt
                    _mfv_sf = _mfv_sf.dropna()
                    _vs = _vt.reindex(_mfv_sf.index).sum()
                    if _vs > 0:
                        _cmf = float(_mfv_sf.sum() / _vs)
        except Exception:
            _cmf = np.nan

        # OBV Slope: normalized 21-day On-Balance Volume trend
        _obv_slope = np.nan
        try:
            if len(close) >= 30:
                _obv_sf = (np.sign(close.diff()) * volume).fillna(0).cumsum()
                _obv21 = _obv_sf.tail(21)
                if len(_obv21) >= 10:
                    _xo = np.arange(len(_obv21), dtype=float)
                    _sl = float(np.polyfit(_xo, _obv21.values, 1)[0])
                    _avg_v = float(volume.tail(21).mean()) + 1e-9
                    _obv_slope = _sl / _avg_v
        except Exception:
            _obv_slope = np.nan

        # Up/Down Volume Ratio (21d): net volume quality
        _updown_vol = np.nan
        try:
            if len(close) >= 21 and len(volume) >= 21:
                _rd = close.diff().tail(21)
                _vd = volume.tail(21)
                _al = pd.concat([_rd.rename("r"), _vd.rename("v")], axis=1).dropna()
                _uv = float(_al.loc[_al["r"] > 0, "v"].sum())
                _dv = float(_al.loc[_al["r"] < 0, "v"].sum())
                _updown_vol = _uv / (_dv + 1e-9)
        except Exception:
            _updown_vol = np.nan

        # RS Rating (O'Neil-style): 0.4x3m + 0.2x6m + 0.2x9m + 0.2x12m
        _rs_raw = np.nan
        try:
            _nc = len(close)
            _lc = float(close.iloc[-1])
            _r3  = (_lc / float(close.iloc[max(0, _nc - 63)])  - 1.0) if _nc > 63  else np.nan
            _r6  = (_lc / float(close.iloc[max(0, _nc - 126)]) - 1.0) if _nc > 126 else np.nan
            _r9  = (_lc / float(close.iloc[max(0, _nc - 189)]) - 1.0) if _nc > 189 else np.nan
            _r12 = (_lc / float(close.iloc[max(0, _nc - 252)]) - 1.0) if _nc > 252 else np.nan
            _rsp = [(_r3, 0.40), (_r6, 0.20), (_r9, 0.20), (_r12, 0.20)]
            _rsv = sum(v * w for v, w in _rsp if pd.notna(v))
            _rsw = sum(w for v, w in _rsp if pd.notna(v))
            _rs_raw = float(_rsv / _rsw) if _rsw > 0.1 else np.nan
        except Exception:
            _rs_raw = np.nan

        # 52W proximity sweet spot: reward stocks 5-25% below 52W high (approaching breakout)
        # vs penalizing those already at 52W high or very far below.
        _prox_52w = proximity_52w_high(close)
        _sweet_spot_52w = np.nan
        try:
            if pd.notna(_prox_52w):
                # _prox_52w is in [0,1]: 1.0 = at 52W high. Target zone: 0.75-0.95 (5-25% below)
                _sweet_spot_52w = float(1.0 - abs(_prox_52w - 0.85) / 0.15)
        except Exception:
            _sweet_spot_52w = np.nan

        # ── R35 (Round 35): 🦄 IPO-profile ML-surface wiring ──────────────
        # USE_NEURAL_SDE / USE_PATCH_TST_ALPHA / base-tightness geometry were
        # advertised in the 🦄 profile cfg + FACTOR_WEIGHTS since Round 33 but
        # NEVER computed into the signal frame — the base_cols filter silently
        # dropped z_neural_sde (0.12), z_patch_tst (0.08) and z_base_tightness
        # (0.07): 27% of the profile's advertised alpha surface contributed
        # NOTHING. They are now live, flag-gated columns (defaults preserve
        # every other profile's behavior — the flags are profile-local).
        _r35_sde = float("nan")
        if cfg is not None and cfg.get("USE_NEURAL_SDE", False):
            from math_engine.ipo_multibagger_math import neural_sde_ratio
            _r35_sde = neural_sde_ratio(close)
        _r35_patch = float("nan")
        if cfg is not None and cfg.get("USE_PATCH_TST_ALPHA", False):
            try:
                from ml_alpha.patch_tst_engine import PatchTSTAlphaEngine
                _r35_ohlcv = pd.DataFrame({"Close": close, "Volume": volume}).dropna()
                _r35_res = PatchTSTAlphaEngine().compute_patch_attention_score(_r35_ohlcv)
                _r35_pv = _r35_res.get("patch_tst_alpha")
                # honest heuristic (per the engine's own C5 caveat): a relative
                # ranking statistic, not a trained-transformer prediction.
                _r35_patch = float(_r35_pv) if _r35_pv is not None else float("nan")
            except Exception:
                _r35_patch = float("nan")
        _r35_open = data.get("Open", data["Close"])[s].reindex(idx) if isinstance(data.get("Open", None), pd.DataFrame) else close
        _r35_high = data.get("High", data["Close"])[s].reindex(idx) if isinstance(data.get("High", None), pd.DataFrame) else close
        _r35_low = data.get("Low", data["Close"])[s].reindex(idx) if isinstance(data.get("Low", None), pd.DataFrame) else close
        _r35_ohlcv = pd.DataFrame({"Open": _r35_open, "High": _r35_high, "Low": _r35_low, "Close": close, "Volume": volume}).dropna()

        _r35_bt = float("nan")
        _fw_probe = (cfg or {}).get("FACTOR_WEIGHTS") or {}
        if cfg is not None and (cfg.get("REQUIRE_BASE_FORMATION", False) or "z_base_tightness" in _fw_probe):
            try:
                from math_engine.vision_chart_auditor import VisionChartAuditor
                _r35_geo = VisionChartAuditor.audit_chart_geometry(_r35_ohlcv)
                _r35_bt = float(_r35_geo.get("base_tightness_pct", float("nan")))
            except Exception:
                _r35_bt = float("nan")

        # ── Pre-Breakout Inception Features (Kaggle SOTA Model) ───────────────
        _pb_feats = {}
        try:
            from ml_alpha.prebreakout_model import extract_prebreakout_features
            _bench_c = (1.0 + benchmark_returns.reindex(close.index).fillna(0.0)).cumprod() * 1000.0 if benchmark_returns is not None and not benchmark_returns.empty else None
            _pb_feats = extract_prebreakout_features(close, volume, _bench_c, _r35_ohlcv)
        except Exception:
            _pb_feats = {}

        _row_dict = {
            "ticker":        s,
            "passed_absolute_trend": passed_absolute_trend,
            "mom_1m":        trailing_return(close, 21),
            "mom_3m":        trailing_return(close, 63),
            "mom_6m":        trailing_return(close, 126),
            "mom_12_1":      momentum_skip_recent(close, 252, 21),
            "idio_mom_3m":   idio_mom_3m,
            "idio_mom_6m":   idio_mom_6m,
            "trend_20":      ema_gap(close, 20),
            "trend_50":      ema_gap(close, 50),
            "trend_quality": trend_quality,
            "vol_surge":     float(max(avg_turnover_10 / adv20 if adv20 > 0 else 1.0, vol_shock)),
            "vol_shock":     vol_shock,
            "is_vol_breakout": is_vol_breakout,
            "vol_of_vol":    vol_of_vol,
            "range_contraction": range_contraction,
            "volume_dryup":  volume_dryup,
            "price_above_20d_frac": price_above_20d_frac,
            "price_above_50d_frac": price_above_50d_frac,
            "up_day_frac_21": up_day_frac_21,
            "ma_compression": ma_compression,
            "breakout_distance_20d": breakout_distance_20d,
            "trigger_persistence": trigger_persistence,
            "rsi":           rsi,
            "rsi_pref":      -abs(rsi - 60.0) if pd.notna(rsi) else np.nan,
            "ann_vol":       annualized_vol(asset_rets),
            "downside_vol":  downside_vol(asset_rets),
            "drawdown":      max_drawdown(close, TRADING_DAYS_PER_YEAR),
            "adv20":         adv20,
            "beta":          beta_val,
            # AUDIT-FIX (Round 24 — R24-3): raw OLS beta + shrink weight kept
            # beside the liquidity-aware estimate so the hedge / exports can
            # disclose how much each row's beta was modeled vs measured.
            "beta_raw":      beta_raw_val,
            "beta_shrink_weight": beta_shrink_w,
            # AUDIT-FIX (Round 25 — R25-3): the shrinkage TARGET is disclosed
            # per row — the characteristic factor-model / licensed-feed prior
            # actually used (see the pre-pass above), replacing the invisible
            # flat 1.0 assumption.
            "beta_prior":    beta_prior_val,
            "beta_prior_source": _beta_prior_src_row,
            "promoter_pct":  np.nan,
            "proximity_52w": _prox_52w,
            "sweet_spot_52w": _sweet_spot_52w,
            "delivery_pct":  np.nan,
            # ── Institutional early-entry signals ──
            # ── R35: previously-dead 🦄 factor columns, now live ──
            # NOTE: the raw column is named `patch_tst` (NOT patch_tst_alpha)
            # so the automatic z-pass produces `z_patch_tst` — EXACTLY the
            # 🦄 FACTOR_WEIGHTS key. The R33 naming mismatch (z_patch_tst
            # weight vs a never-computed column) was one of the dead-weight
            # roots; the regression suite now locks the key↔column equality.
            "neural_sde":    _r35_sde,        # Itô SDE drift/diffusion efficiency (μ/σ)
            "patch_tst": _r35_patch,         # patch-attention heuristic score (10–99)
            "base_tightness": _r35_bt,        # base-formation geometry (tightness %)
            "vcp":           _vcp,
            "cmf":           _cmf,
            "obv_slope":     _obv_slope,
            "updown_vol":    _updown_vol,
            "rs_raw":        _rs_raw,
        }
        if _pb_feats:
            _row_dict.update(_pb_feats)
        rows.append(_row_dict)

    if not rows:
        raise RuntimeError("No usable signal frame could be built from the cleaned data. Try increasing lookback, lowering min data/liquidity filters, or increasing universe size.")

    frame = pd.DataFrame(rows)
    if "ticker" not in frame.columns or frame.empty:
        raise RuntimeError("Signal generation produced no valid tickers after data cleaning.")
    frame = frame.set_index("ticker")

    if sectors:
        frame["sector"] = [sectors.get(t, "N/A") for t in frame.index]
        for col in ["mom_1m", "mom_6m"]:
            sector_mean = frame.groupby("sector")[col].transform("mean")
            frame[f"sector_rel_{col}"] = frame[col] - sector_mean
        for col in ["sector_rel_mom_1m", "sector_rel_mom_6m"]:
            frame[f"z_{col}"] = robust_zscore_series(frame[col])
    else:
        frame["sector"] = "N/A"
        frame["sector_rel_mom_1m"] = np.nan
        frame["sector_rel_mom_6m"] = np.nan
        frame["sector_rel_alpha_score"] = np.nan
        frame["z_sector_rel_mom_1m"] = np.nan
        frame["z_sector_rel_mom_6m"] = np.nan
        frame["z_sector_rel_alpha_score"] = np.nan

    frame["beta_dev"] = (frame["beta"] - 1.0).abs() if "beta" in frame.columns else np.nan

    for col in ["mom_1m", "mom_3m", "mom_6m", "mom_12_1", "idio_mom_3m", "idio_mom_6m",
                "trend_20", "trend_50", "trend_quality", "vol_surge", "vol_shock", "vol_of_vol",
                "range_contraction", "volume_dryup", "price_above_20d_frac",
                "price_above_50d_frac", "up_day_frac_21", "ma_compression",
                "breakout_distance_20d", "trigger_persistence",
                "rsi_pref", "ann_vol", "downside_vol", "drawdown", "adv20", "beta", "beta_dev",
                # ── R35: the three previously-dead 🦄 factors ──
                "neural_sde", "patch_tst", "base_tightness",
                # ── Institutional early-entry signals ──
                "vcp", "cmf", "obv_slope", "updown_vol", "rs_raw", "sweet_spot_52w"]:
        if col in frame.columns:
            frame[f"z_{col}"] = robust_zscore_series(frame[col])
    # Cross-sectional RS Rating rank (0-100) — percentile across current universe
    if "z_rs_raw" in frame.columns and frame["z_rs_raw"].notna().sum() > 4:
        _rs_vals = frame["rs_raw"].rank(pct=True, na_option="keep") * 100.0
        frame["z_rs_rating"] = robust_zscore_series(_rs_vals)

    # ── R35: microstructure z-scores BEFORE the alpha blend ──────────────
    # Round 35 audit finding: these were computed in
    # optimizer.run_optimizer_logic AFTER compute_signal_frame returned —
    # too late for z_vpin_toxicity to enter the FACTOR_WEIGHTS blend
    # (0.08 of the 🦄 surface and 0.35 of the Vol-Squeeze surface were
    # silently dead for alpha). Moved to the only place they can matter.
    try:
        from math_engine.microstructure import MicrostructureEngine
        _r35_micro = MicrostructureEngine.compute_microstructure_zscores(data, list(frame.index))
        for _mcol in _r35_micro.columns:
            frame[_mcol] = _r35_micro[_mcol].reindex(frame.index).fillna(0.0)
        log_emit(log_cb, f"[Microstructure] VPIN & Roll z-scores computed for {len(frame)} assets (pre-blend, R35)")
    except Exception as _me:
        log_emit(log_cb, f"[Microstructure] skipped: {_me}", exc_info=True)

    try:
        from ml_alpha.prebreakout_model import PREBREAKOUT_FACTOR_NAMES
        for _pbf in PREBREAKOUT_FACTOR_NAMES:
            if _pbf in frame.columns:
                frame[_pbf] = pd.to_numeric(frame[_pbf], errors="coerce").fillna(0.0)
            else:
                frame[_pbf] = 0.0
    except Exception as _pbe:
        pass

    from data_layer import (DEFAULT_CFG, fetch_fundamentals, compute_fundamental_score,
                            fetch_sast_velocity, fetch_pledge_reduction, fetch_pead_scores,
                            fetch_pcr_skew, fetch_fii_sector_flow, fetch_buyback_scores,
                            fetch_mtf_reversal, fetch_nse_bulk_deal_footprint, fetch_bse_float_squeeze)
    fw = (cfg or {}).get("FACTOR_WEIGHTS", DEFAULT_CFG["FACTOR_WEIGHTS"])
    base_cols = [c for c in fw if c in frame.columns and not c.startswith("z_sector")]
    # Explicit float accumulation — avoids int(0) + Series fragility from builtin sum()
    # Orthogonalize shorter momentum horizons against 12m momentum
    # to reduce triple-counting of the same trend signal.
    # z_mom_Xm_orth = z_mom_Xm - cov(X,12)/var(12) * z_mom_12_1
    # Falls back gracefully if 12m momentum has near-zero variance.
    if "z_mom_12_1" in frame.columns and frame["z_mom_12_1"].std() > 1e-6:
        _base_12m = frame["z_mom_12_1"].fillna(0.0)
        _var_12m = float(_base_12m.var())
        for _short_mom in ("z_mom_1m", "z_mom_3m", "z_mom_6m"):
            if _short_mom in frame.columns:
                _s = frame[_short_mom].fillna(0.0)
                _beta_proj = float(np.cov(_s.values, _base_12m.values)[0, 1]) / _var_12m if _var_12m > 1e-9 else 0.0  # DIV001: guard divisor before use
                frame[f"{_short_mom}_orth"] = _s - _beta_proj * _base_12m
        # Rebuild base_cols to use orthogonalized momentum columns
        _mom_orth_map = {f: f"{f}_orth" for f in ("z_mom_1m", "z_mom_3m", "z_mom_6m")
                         if f"{f}_orth" in frame.columns}
        base_cols = [_mom_orth_map.get(c, c) for c in base_cols]

    _alpha = pd.Series(0.0, index=frame.index)
    for _c in base_cols:
        if _c in frame.columns:
            _alpha = _alpha + fw.get(_c.replace("_orth", ""), fw.get(_c, 0.0)) * frame[_c].fillna(0.0)
    # v17.22: inject fundamental factors as individual IC-measurable columns
    if (cfg or {}).get("USE_FUNDAMENTALS", True):
        try:
            _fund_tickers = list(frame.index) if hasattr(frame.index, "__iter__") else list(frame["ticker"])
            _as_of_date = cfg.get("as_of_date") if cfg and cfg.get("as_of_date") else (close.index[-1] if not close.empty else None)
            _fund_raw = fetch_fundamentals(_fund_tickers, as_of_date=_as_of_date)
            _fund_df  = compute_fundamental_score(_fund_raw, _fund_tickers)
            for _fc in ["z_roe", "z_de_inv", "z_pe_inv", "z_rev_growth", "z_fund_composite"]:
                if _fc in _fund_df.columns:
                    frame[_fc] = _fund_df[_fc].reindex(frame.index).fillna(0.0)
            for _fc, _fdef in [("z_roe",0.20),("z_pe_inv",0.25),("z_de_inv",0.12),("z_rev_growth",0.10)]:
                if _fc in frame.columns:
                    _alpha = _alpha + fw.get(_fc, _fdef) * frame[_fc].fillna(0.0)
            log_emit(log_cb, f"[Fundamentals] Injected z_roe/z_de_inv/z_rev_growth into alpha (w_roe={fw.get('z_roe',0.20):.3f})")
        except Exception as _fe:
            _lcb = locals().get("log_cb") or locals().get("log_callback") or None
            log_emit(_lcb, f"[Fundamentals] Injection failed (non-fatal): {_fe}", exc_info=True)
    frame["alpha_score"] = _alpha

    if sectors:
        frame["alpha_score"] = (
            frame["alpha_score"]
            + fw.get("z_sector_rel_mom_6m", 0.06) * frame["z_sector_rel_mom_6m"].fillna(0.0)
            + fw.get("z_sector_rel_mom_1m", 0.03) * frame["z_sector_rel_mom_1m"].fillna(0.0)
        )
        frame["sector_rel_alpha_score"] = frame["alpha_score"] - frame.groupby("sector")["alpha_score"].transform("mean")
        frame["z_sector_rel_alpha_score"] = robust_zscore_series(frame["sector_rel_alpha_score"])

    frame["risk_score"] = (
        0.45 * frame["z_ann_vol"] + 0.20 * frame["z_downside_vol"] +
        0.20 * frame["z_drawdown"] + 0.15 * frame["z_beta_dev"]
    )

    # ── v14: promoter signal (optional) ─────────────────────────────────────
    if "promoter_pct" in frame.columns and frame["promoter_pct"].notna().sum() > 4:
        frame["z_promoter"] = robust_zscore_series(frame["promoter_pct"])
        promo_w = (cfg or {}).get("PROMOTER_WEIGHT", 0.05)
        frame["alpha_score"] = frame["alpha_score"] + promo_w * frame["z_promoter"].fillna(0.0)
    else:
        frame["z_promoter"] = np.nan

    # ── v17.3: idiosyncratic momentum + trend quality + vol-of-vol overlays ─
    _cfg = cfg or {}
    if "z_idio_mom_6m" in frame.columns and frame["z_idio_mom_6m"].notna().sum() > 4:
        frame["alpha_score"] += 0.08 * frame["z_idio_mom_6m"].fillna(0.0)
    if "z_idio_mom_3m" in frame.columns and frame["z_idio_mom_3m"].notna().sum() > 4:
        frame["alpha_score"] += 0.04 * frame["z_idio_mom_3m"].fillna(0.0)
    if "z_trend_quality" in frame.columns and frame["z_trend_quality"].notna().sum() > 4:
        frame["alpha_score"] += 0.05 * frame["z_trend_quality"].fillna(0.0)
    if "z_vol_of_vol" in frame.columns and frame["z_vol_of_vol"].notna().sum() > 4:
        frame["risk_score"]  = frame["risk_score"] + 0.10 * frame["z_vol_of_vol"].fillna(0.0)

    # ── v15: 52-week high proximity signal (profile-aware) ───────────────────
    # For early-entry profiles: reward stocks 5-25% below 52W high (approaching
    # breakout) rather than stocks already AT their 52W high (lagging).
    if _cfg.get("USE_52W_HIGH_SIGNAL", True):
        _use_early_entry_52w = _cfg.get("USE_PROXIMITY_AS_EARLY_ENTRY", False)
        if _use_early_entry_52w and "z_sweet_spot_52w" in frame.columns:
            if frame["z_sweet_spot_52w"].notna().sum() > 4:
                hw = float(_cfg.get("HIGH52W_WEIGHT", 0.07))
                frame["z_52w_high"] = frame["z_sweet_spot_52w"]
                frame["alpha_score"] = frame["alpha_score"] + hw * frame["z_52w_high"].fillna(0.0)
                log_emit(log_cb, "[52W] Using early-entry sweet-spot signal (stocks approaching breakout zone)")
            else:
                frame["z_52w_high"] = np.nan
        elif "proximity_52w" in frame.columns and frame["proximity_52w"].notna().sum() > 4:
            frame["z_52w_high"] = robust_zscore_series(frame["proximity_52w"])
            hw = float(_cfg.get("HIGH52W_WEIGHT", 0.07))
            frame["alpha_score"] = frame["alpha_score"] + hw * frame["z_52w_high"].fillna(0.0)
        else:
            frame["z_52w_high"] = np.nan
    else:
        frame["z_52w_high"] = np.nan

    # ── Institutional early-entry signal injection (FACTOR_WEIGHTS driven) ───
    # These signals were previously computed but never wired into alpha.
    # They now participate via FACTOR_WEIGHTS so each profile controls their weight.
    _early_entry_cols = [
        ("z_vcp",                   "VCP coiling"),
        ("z_cmf",                   "CMF institutional buying"),
        ("z_obv_slope",             "OBV accumulation"),
        ("z_updown_vol",            "Up/Down vol ratio"),
        ("z_rs_rating",             "O'Neil RS Rating"),
        ("z_range_contraction",     "vol squeeze"),
        ("z_volume_dryup",          "volume dry-up"),
        ("z_ma_compression",        "MA compression"),
        ("z_rsi_pref",              "RSI sweet spot"),
        ("z_breakout_distance_20d", "breakout distance"),
        ("z_trend_quality",         "trend R²"),
        ("z_trigger_persistence",   "trigger persistence"),
    ]
    _injected = []
    for _ec, _label in _early_entry_cols:
        _w = fw.get(_ec, 0.0)
        if _w != 0.0 and _ec in frame.columns and frame[_ec].notna().sum() > 4:
            frame["alpha_score"] += _w * frame[_ec].fillna(0.0)
            _injected.append(f"{_ec}(w={_w:.3f})")
    if _injected:
        log_emit(log_cb, f"[EarlyEntry] Injected {len(_injected)} institutional signals: {', '.join(_injected[:6])}")

    # ── v15: NSE delivery volume conviction signal ────────────────────────────
    # Bug 2 fix: compute z_delivery for IC only; blend in run_optimizer_logic.
    if _cfg.get("USE_DELIVERY_SIGNAL", True) and "delivery_pct" in frame.columns:
        if frame["delivery_pct"].notna().sum() > 4:
            frame["z_delivery"] = robust_zscore_series(frame["delivery_pct"])
        else:
            frame["z_delivery"] = np.nan
    else:
        frame["z_delivery"] = np.nan

    # ── NEW SIGNALS S1-S7 (v17.27) ──────────────────────────────────────
    if _cfg.get("USE_SAST_VELOCITY", True):
        try:
            _sv = fetch_sast_velocity(list(frame.index))
            if _sv:
                frame["z_sast_vel"] = robust_zscore_series(pd.Series(_sv).reindex(frame.index).fillna(0.0))
                # Use profile FACTOR_WEIGHTS override if present, else DEFAULT_CFG SAST_VEL_WEIGHT.
                # The profile sets z_sast_vel = 0.18 in FACTOR_WEIGHTS; this honours that intent.
                _sast_w = float(
                    fw.get("z_sast_vel")
                    if fw.get("z_sast_vel") is not None
                    else _cfg.get("SAST_VEL_WEIGHT", 0.06)
                )
                frame["alpha_score"] += _sast_w * frame["z_sast_vel"].fillna(0.0)
                log_emit(log_cb, f"[SAST] Insider buying signal blended (weight={_sast_w:.2f})")
            else:
                frame["z_sast_vel"] = np.nan
        except Exception as _e:
            frame["z_sast_vel"] = np.nan

    if _cfg.get("USE_PLEDGE_SIGNAL", True):
        try:
            _pl = fetch_pledge_reduction(list(frame.index))
            if _pl:
                frame["z_pledge_red"] = robust_zscore_series(pd.Series(_pl).reindex(frame.index))
                _pledge_w = float(
                    fw.get("z_pledge_red")
                    if fw.get("z_pledge_red") is not None
                    else _cfg.get("PLEDGE_WEIGHT", 0.05)
                )
                frame["alpha_score"] += _pledge_w * frame["z_pledge_red"].fillna(0.0)
            else:
                frame["z_pledge_red"] = np.nan
        except Exception as _e:
            frame["z_pledge_red"] = np.nan

    if _cfg.get("USE_PEAD_SIGNAL", True):
        try:
            _pe = fetch_pead_scores(list(frame.index), _cfg.get("_CLOSE_DF"))
            if _pe:
                frame["z_pead"] = robust_zscore_series(pd.Series(_pe).reindex(frame.index).fillna(0.0))
                _pead_w = float(
                    fw.get("z_pead")
                    if fw.get("z_pead") is not None
                    else _cfg.get("PEAD_WEIGHT", 0.07)
                )
                frame["alpha_score"] += _pead_w * frame["z_pead"].fillna(0.0)
                log_emit(log_cb, f"[PEAD] Post-earnings drift signal blended (weight={_pead_w:.2f})")
            else:
                frame["z_pead"] = np.nan
        except Exception as _e:
            frame["z_pead"] = np.nan

    if _cfg.get("USE_PCR_SIGNAL", True):
        try:
            _pc = fetch_pcr_skew(list(frame.index))
            if _pc:
                frame["z_pcr_skew"] = robust_zscore_series(pd.Series(_pc).reindex(frame.index))
                frame["alpha_score"] += float(_cfg.get("PCR_WEIGHT", 0.05)) * frame["z_pcr_skew"].fillna(0.0)
            else:
                frame["z_pcr_skew"] = np.nan
        except Exception as _e:
            frame["z_pcr_skew"] = np.nan

    if _cfg.get("USE_FII_SECTOR", True):
        try:
            _fs = fetch_fii_sector_flow()
            if _fs and sectors:
                frame["z_fii_sector"] = robust_zscore_series(
                    pd.Series({t: _fs.get(sectors.get(t,"NA"), 0.0) for t in frame.index}).reindex(frame.index))
                frame["alpha_score"] += float(_cfg.get("FII_SECTOR_WEIGHT", 0.05)) * frame["z_fii_sector"].fillna(0.0)
            else:
                frame["z_fii_sector"] = np.nan
        except Exception as _e:
            frame["z_fii_sector"] = np.nan

    if _cfg.get("USE_BUYBACK_SIGNAL", True):
        try:
            _bb = fetch_buyback_scores(list(frame.index))
            if _bb:
                frame["z_buyback"] = robust_zscore_series(pd.Series(_bb).reindex(frame.index).fillna(0.0))
                frame["alpha_score"] += float(_cfg.get("BUYBACK_WEIGHT", 0.06)) * frame["z_buyback"].fillna(0.0)
            else:
                frame["z_buyback"] = np.nan
        except Exception as _e:
            frame["z_buyback"] = np.nan

    if _cfg.get("USE_MTF_SIGNAL", True):
        try:
            _mt = fetch_mtf_reversal(list(frame.index))
            if _mt:
                frame["z_mtf_reversal"] = robust_zscore_series(pd.Series(_mt).reindex(frame.index).fillna(0.0))
                frame["alpha_score"] += float(_cfg.get("MTF_WEIGHT", 0.04)) * frame["z_mtf_reversal"].fillna(0.0)
            else:
                frame["z_mtf_reversal"] = np.nan
        except Exception as _e:
            frame["z_mtf_reversal"] = np.nan

    # ── Bulk Deal Institutional Footprint ──────────────────────────────
    def _smart_signal_ready(series, label: str) -> tuple[bool, int, int, float]:
        vals = pd.to_numeric(series, errors="coerce").fillna(0.0)
        total = int(len(vals))
        nonzero = int((vals.abs() > 1e-12).sum())
        coverage = float(nonzero / total) if total else 0.0
        min_nonzero = int(_cfg.get("SMART_SIGNAL_MIN_NONZERO", 4))
        # Lowered from 0.05 to 0.03: NSE bulk deal API 503's regularly,
        # leaving only 1 day snapshot (~4% coverage). 3% lets the signal through.
        min_coverage = float(_cfg.get("SMART_SIGNAL_MIN_COVERAGE", 0.03))
        ready = nonzero >= min_nonzero and coverage >= min_coverage
        if not ready:
            reasons = []
            if nonzero < min_nonzero:
                reasons.append(f"nonzero {nonzero} < required {min_nonzero}")
            if coverage < min_coverage:
                reasons.append(f"coverage {coverage:.1%} < required {min_coverage:.1%}")
            log_emit(
                log_cb,
                f"[{label}] Skipped alpha blend ({nonzero}/{total} = {coverage:.1%}): "
                f"{'; '.join(reasons)}. Both nonzero>={min_nonzero} AND "
                f"coverage>={min_coverage:.1%} required."
            )
        return ready, nonzero, total, coverage

    if _cfg.get("USE_BULK_DEAL_SIGNAL", True):
        try:
            _bd = fetch_nse_bulk_deal_footprint(
                list(frame.index),
                log_cb=log_cb,
                historical_only=bool(_cfg.get("_IS_WFO_STEP", False)),
            )
            if _bd:
                frame["bulk_deal_footprint"] = pd.Series(_bd).reindex(frame.index).fillna(0.0)
                ready, nonzero, total, coverage = _smart_signal_ready(frame["bulk_deal_footprint"], "BulkDeal")
                if ready:
                    frame["z_bulk_deal_footprint"] = robust_zscore_series(frame["bulk_deal_footprint"])
                    _bd_weight = float(_cfg.get("BULK_DEAL_WEIGHT", 0.12))
                    frame["alpha_score"] += _bd_weight * frame["z_bulk_deal_footprint"].fillna(0.0)
                    log_emit(log_cb, f"[BulkDeal] Injected footprint signal (w={_bd_weight:.3f}, coverage={nonzero}/{total}={coverage:.1%})")
                else:
                    frame["z_bulk_deal_footprint"] = np.nan
            else:
                frame["z_bulk_deal_footprint"] = np.nan
        except Exception as _bde:
            frame["z_bulk_deal_footprint"] = np.nan
            log_emit(log_cb, f"[BulkDeal] Non-fatal: {_bde}", exc_info=True)

    # ── BSE Float Squeeze ───────────────────────────────────────────────
    if _cfg.get("USE_FLOAT_SQUEEZE", True):
        try:
            _fs = fetch_bse_float_squeeze(list(frame.index), log_cb=log_cb)
            if _fs:
                frame["float_squeeze"] = pd.Series(_fs).reindex(frame.index).fillna(0.0)
                ready, nonzero, total, coverage = _smart_signal_ready(frame["float_squeeze"], "FloatSqueeze")
                if ready:
                    frame["z_float_squeeze"] = robust_zscore_series(frame["float_squeeze"])
                    _fs_weight = float(_cfg.get("FLOAT_SQUEEZE_WEIGHT", 0.10))
                    frame["alpha_score"] += _fs_weight * frame["z_float_squeeze"].fillna(0.0)
                    log_emit(log_cb, f"[FloatSqueeze] Injected BSE float squeeze signal (w={_fs_weight:.3f}, coverage={nonzero}/{total}={coverage:.1%})")
                else:
                    frame["z_float_squeeze"] = np.nan
            else:
                frame["z_float_squeeze"] = np.nan
        except Exception as _fse:
            frame["z_float_squeeze"] = np.nan
            log_emit(log_cb, f"[FloatSqueeze] Non-fatal: {_fse}", exc_info=True)

    frame.attrs["chart_model_info"] = {}
    if _cfg.get("USE_CHART_IMAGE_SSL", True):
        try:
            _chart_df = compute_multi_timeframe_chart_features(data, list(frame.index), cfg=_cfg, log_cb=log_cb)
            if _chart_df is not None and not _chart_df.empty:
                frame.attrs["chart_model_info"] = dict(_chart_df.attrs.get("chart_model_info", {}) or {})
                for _cc in ("chart_pattern_cohesion", "chart_pattern_novelty", "chart_pattern_margin",
                            "chart_pattern_cluster", "z_chart_pattern", "z_chart_novelty", "z_chart_margin",
                            "chart_pattern_dispersion", "chart_cluster_agreement",
                            "chart_calibrated_prob", "chart_failed_breakout_risk", "chart_regime_fit"):
                    if _cc in _chart_df.columns:
                        frame[_cc] = _chart_df[_cc].reindex(frame.index)
                for _cc in [c for c in _chart_df.columns if c.startswith(("z_chart_pattern_", "z_chart_novelty_", "z_chart_margin_", "chart_pattern_cluster_"))]:
                    frame[_cc] = _chart_df[_cc].reindex(frame.index)
                if "chart_calibrated_prob" in frame.columns:
                    frame["alpha_score"] += float(_cfg.get("CHART_PATTERN_WEIGHT", 0.06)) * frame["chart_calibrated_prob"].fillna(0.0)
                else:
                    frame["alpha_score"] += float(_cfg.get("CHART_PATTERN_WEIGHT", 0.06)) * frame["z_chart_pattern"].fillna(0.0)
                frame["alpha_score"] += 0.50 * float(_cfg.get("CHART_PATTERN_WEIGHT", 0.06)) * frame["z_chart_margin"].fillna(0.0)
                if "chart_regime_fit" in frame.columns:
                    frame["alpha_score"] += 0.10 * frame["chart_regime_fit"].fillna(0.0)
                frame["risk_score"] += float(_cfg.get("CHART_NOVELTY_RISK_WEIGHT", 0.07)) * frame["z_chart_novelty"].fillna(0.0)
                if "chart_pattern_dispersion" in frame.columns:
                    frame["risk_score"] += 0.03 * robust_zscore_series(frame["chart_pattern_dispersion"]).fillna(0.0)
            else:
                frame["z_chart_pattern"] = np.nan
                frame["z_chart_novelty"] = np.nan
                frame["z_chart_margin"] = np.nan
                frame["chart_calibrated_prob"] = np.nan
                frame["chart_failed_breakout_risk"] = np.nan
                frame["chart_regime_fit"] = np.nan
        except Exception as _ce:
            log_emit(log_cb, f"[ChartSSL] live scoring failed (non-fatal): {_ce}", exc_info=True)
            frame["z_chart_pattern"] = np.nan
            frame["z_chart_novelty"] = np.nan
            frame["z_chart_margin"] = np.nan
            frame["chart_pattern_dispersion"] = np.nan
            frame["chart_calibrated_prob"] = np.nan
            frame["chart_failed_breakout_risk"] = np.nan
            frame["chart_regime_fit"] = np.nan

    # ── Neural Screener Full-NSE Latent space scores integration ──
    try:
        from core.state_manager import AppState
        latent_scores = AppState.instance().latent_screener_scores
        if latent_scores:
            # Guardrails:
            # - LiveVerify can populate only a tiny sample (e.g. 15 tickers). Never treat that as a
            #   "full-NSE" signal and blend it into alpha, or you'll distort portfolio selection.
            # - Also avoid log spam during walk-forward backtests.
            min_scores = int(_cfg.get("LATENT_MIN_SCORES", 200))
            min_cov = float(_cfg.get("LATENT_MIN_COVERAGE", 0.50))

            matched = [t for t in frame.index if t in latent_scores]
            coverage = (len(matched) / max(1, len(frame))) if len(frame) else 0.0
            if len(latent_scores) < min_scores or coverage < min_cov:
                log_once_per_window(
                    log_cb,
                    f"[Neural Screener] Skipping latent blend (scores={len(latent_scores)}, matched={len(matched)}/{len(frame)}, "
                    f"min_scores={min_scores}, min_cov={min_cov:.2f})",
                    window_sec=300,
                )
                latent_scores = None
            else:
                log_once_per_window(
                    log_cb,
                    f"[Neural Screener] Blending latent scores (scores={len(latent_scores)}, matched={len(matched)}/{len(frame)})",
                    window_sec=300,
                )

            if not latent_scores:
                raise RuntimeError("latent blend skipped")

            latent_s = pd.Series({t: latent_scores.get(t, 0.5) for t in frame.index})
            frame["z_latent_similarity"] = robust_zscore_series(latent_s.reindex(frame.index).fillna(0.5))
            
            # Blend directly into z_chart_pattern
            if "z_chart_pattern" in frame.columns and frame["z_chart_pattern"].notna().any():
                frame["z_chart_pattern"] = 0.4 * frame["z_chart_pattern"].fillna(0.0) + 0.6 * frame["z_latent_similarity"]
            else:
                frame["z_chart_pattern"] = frame["z_latent_similarity"]
                
            # Populate fallback margin/novelty if not calculated yet
            if "z_chart_margin" not in frame.columns or frame["z_chart_margin"].isna().all():
                frame["z_chart_margin"] = pd.Series(0.0, index=frame.index)
            if "z_chart_novelty" not in frame.columns or frame["z_chart_novelty"].isna().all():
                frame["z_chart_novelty"] = pd.Series(0.0, index=frame.index)
                
            # Ensure alpha_score incorporates them if USE_CHART_IMAGE_SSL is False or bypassed
            if not _cfg.get("USE_CHART_IMAGE_SSL", True) or frame["z_chart_margin"].eq(0).all():
                frame["alpha_score"] += float(_cfg.get("CHART_PATTERN_WEIGHT", 0.06)) * frame["z_chart_pattern"].fillna(0.0)
    except Exception as _nse_err:
        pass
    # ── Sovereign Tier-0: Terry Lyons' Path Signatures ────────────────────
    try:
        from math_engine.path_signatures import PathSignatureEngine
        _sig_scores = {}
        _levy_scores = {}
        for _sym in frame.index:
            if _sym in data and not data[_sym].empty:
                _px = data[_sym]["Close"].values
                _vol = data[_sym]["Volume"].values if "Volume" in data[_sym].columns else None
                _sig = PathSignatureEngine.compute_path_signature(_px, _vol, depth=2)
                _sig_scores[_sym] = float(_sig.get("sig_compression_index", 0.5))
                _levy_scores[_sym] = float(_sig.get("sig_levy_area_pv", 0.0))
        if _sig_scores:
            frame["z_path_sig_comp"] = robust_zscore_series(pd.Series(_sig_scores).reindex(frame.index).fillna(0.5))
            frame["z_path_sig_levy"] = robust_zscore_series(pd.Series(_levy_scores).reindex(frame.index).fillna(0.0))
            frame["alpha_score"] += 0.08 * frame["z_path_sig_comp"].fillna(0.0) + 0.05 * frame["z_path_sig_levy"].fillna(0.0)
            log_emit(log_cb, f"[PathSignatures] Injected Terry Lyons iterated rough path invariants (comp_w=0.080, levy_w=0.050 | {len(_sig_scores)} assets)")
    except Exception as _pse:
        log_emit(log_cb, f"[PathSignatures] Non-fatal: {_pse}", exc_info=True)

    # ── Sovereign Tier-0: Hawkes Self-Exciting Point Process ───────────────
    try:
        from math_engine.hawkes_detector import HawkesJumpDetector
        _h_detector = HawkesJumpDetector(threshold_std=2.0)
        _hawkes_branching = {}
        for _sym in frame.index:
            if _sym in data and len(data[_sym]) >= 30:
                _ret = data[_sym]["Close"].pct_change().dropna()
                _h_res = _h_detector.fit_predict(_ret)
                _br = float(_h_res.get("branching_ratio", 0.0))
                _hawkes_branching[_sym] = 1.0 if (0.30 <= _br <= 0.90) else (-1.0 if _br >= 1.05 else 0.0)
        if _hawkes_branching:
            frame["z_hawkes_accum"] = robust_zscore_series(pd.Series(_hawkes_branching).reindex(frame.index).fillna(0.0))
            frame["alpha_score"] += 0.07 * frame["z_hawkes_accum"].fillna(0.0)
            log_emit(log_cb, f"[HawkesProcess] Injected self-exciting algorithmic accumulation signal (w=0.070 | {len(_hawkes_branching)} assets)")
    except Exception as _hpe:
        log_emit(log_cb, f"[HawkesProcess] Non-fatal: {_hpe}", exc_info=True)

    # ── Sovereign Tier-0: Mamba Selective State-Space Sequential Flow ─────
    try:
        from ml_alpha.mamba_sequence import MambaSequenceExtractor
        _mamba = MambaSequenceExtractor(d_state=16, d_model=4)
        _mamba_scores = {}
        for _sym in frame.index:
            if _sym in data and not data[_sym].empty and len(data[_sym]) >= 20:
                _px = data[_sym]["Close"].values
                _vol = data[_sym]["Volume"].values if "Volume" in data[_sym].columns else None
                _mf = _mamba.extract_features(_px, _vol)
                _m_score = float(_mf.get("mamba_trend_drift", 0.0) + 0.5 * _mf.get("mamba_coherence", 0.0))
                _mamba_scores[_sym] = _m_score
        if _mamba_scores:
            frame["z_mamba_ssm"] = robust_zscore_series(pd.Series(_mamba_scores).reindex(frame.index).fillna(0.0))
            frame["alpha_score"] += 0.08 * frame["z_mamba_ssm"].fillna(0.0)
            log_emit(log_cb, f"[MambaSSM] Injected continuous state-space sequence factors (w=0.080 | {len(_mamba_scores)} assets)")
    except Exception as _mbe:
        log_emit(log_cb, f"[MambaSSM] Non-fatal: {_mbe}", exc_info=True)

    # ── END S1-S7 ────────────────────────────────────────────────────────

    # Detect if we are in a Bear market condition
    is_bear_market = False
    if cfg is not None and cfg.get("_REGIME_INFO"):
        r_info = cfg.get("_REGIME_INFO", {})
        r_lbl = r_info.get("Regime", "")
        p_bear = r_info.get("P_Bear", 0.0)
        if any(x in str(r_lbl) for x in ("Bear", "Stress", "Defensive")) or p_bear > 0.5:
            is_bear_market = True
    try:
        from core.state_manager import AppState as _AS
        if _AS.instance().current_regime == "Bear":
            is_bear_market = True
    except Exception:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
        pass

    if cfg is not None and cfg.get("ENABLE_ABSOLUTE_TREND_GUARD", True) and "passed_absolute_trend" in frame.columns:
        passed_count = int(frame["passed_absolute_trend"].sum())
        min_required = int(cfg.get("TREND_GUARD_MIN_REQUIRED", int(cfg.get("K_STOCKS", 8))))
        if is_bear_market or passed_count >= min_required:
            before_cnt = len(frame)
            frame = frame[frame["passed_absolute_trend"] == True]
            reason = "Bear Market strict enforcement" if is_bear_market else "sufficient passing stocks"
            _tg_mode = str(cfg.get("TREND_GUARD_MODE", "standard")).lower() if cfg else "standard"
            if _tg_mode == "early_entry":
                log_emit(log_cb,
                    f"[TrendGuard] Early-entry mode ({reason}): Pruned {before_cnt - len(frame)} "
                    f"genuinely broken stocks (>15% below 200 EMA AND -40% 6M return). "
                    f"Base-building stocks allowed through. Remaining: {len(frame)} stocks.")
            else:
                log_emit(log_cb,
                    f"[TrendGuard] Standard mode ({reason}): Pruned {before_cnt - len(frame)} "
                    f"stocks in structural downtrends (price < 50 EMA or 3M return < 0). "
                    f"Remaining: {len(frame)} stocks.")
        else:
            log_emit(log_cb, f"[TrendGuard] Bypassed: Only {passed_count} stocks passed trend guard; minimum {min_required} required to avoid portfolio starvation.")

    # ── GARCH(1,1) Conditional Volatility Signal ─────────────────────────────
    # Stocks with elevated GARCH vol get a dynamic risk penalty.
    try:
        import json
        from pathlib import Path
        _garch_vols = {}
        _garch_target = float((_cfg or {}).get("GARCH_VOL_TARGET", 0.30)) / np.sqrt(252)  # daily target

        # v17.35-fix: cache garch_params load at module level — avoid re-reading
        # the JSON file on every compute_signal_frame call (108 times during WFO).
        garch_params = getattr(compute_signal_frame, "_garch_params_cache", None)
        if garch_params is None:
            garch_params = {}
            _proj_root = Path(__file__).resolve().parent
            gp_path = _proj_root / "models" / "garch_params_latest.json"
            if not gp_path.exists():
                try:
                    _rt_gp = RUNTIME_DIR / "models" / "garch_params_latest.json"
                    if _rt_gp.exists():
                        gp_path = _rt_gp
                except Exception:
                    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                    pass
            if gp_path.exists():
                try:
                    with open(gp_path, "r") as f:
                        gp_payload = json.load(f)
                    garch_params = gp_payload.get("parameters", {})
                except Exception:
                    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                    pass
            compute_signal_frame._garch_params_cache = garch_params  # type: ignore[attr-defined]

        for _gs in list(frame.index):
            try:
                _gr = returns[_gs].dropna() if _gs in returns.columns else pd.Series(dtype=float)
                if len(_gr) < 60:
                    _garch_vols[_gs] = np.nan
                    continue
                _gr_arr = _gr.tail(252).values
                _sv = float(np.var(_gr_arr))

                gp = garch_params.get(_gs, {})
                _omega = gp.get("omega", _sv * 0.05)
                _alpha_g = gp.get("alpha", 0.10)
                _beta_g  = gp.get("beta",  0.85)

                # v17.35-fix: vectorized GARCH(1,1) recursion — replaces pure-Python
                # loop (252 iters/ticker × 150 tickers × 108 WFO steps = 4M iters).
                # NumPy approach: unfold h_t = omega*(1 + beta + beta^2 + ...) +
                # alpha * sum(beta^(t-s) * r_s^2). Uses cumulative weighted sum.
                _n = len(_gr_arr)
                _r2 = _gr_arr ** 2
                # Build decay weights: beta^(n-1), beta^(n-2), ..., beta^0
                _powers = _beta_g ** np.arange(_n - 1, -1, -1)
                # h_T = omega * sum(beta^k) + alpha * weighted_sum(r2) + beta^n * h0
                _geom = (1.0 - _beta_g ** _n) / (1.0 - _beta_g) if _beta_g < 1.0 else float(_n)
                _h = _omega * _geom + _alpha_g * float(np.dot(_powers, _r2)) + (_beta_g ** _n) * _sv
                _h = max(_h, 1e-12)
                _garch_vols[_gs] = float(np.sqrt(_h))  # daily conditional vol
            except Exception:
                _garch_vols[_gs] = np.nan
        if _garch_vols:
            _gv_series = pd.Series(_garch_vols).reindex(frame.index)
            if _gv_series.notna().sum() > 4:
                frame["garch_vol"] = _gv_series
                frame["z_garch_vol"] = robust_zscore_series(_gv_series)
                # Add to risk_score directly (always active — GARCH vol is pure risk)
                frame["risk_score"] = frame["risk_score"] + 0.15 * frame["z_garch_vol"].fillna(0.0)
                # Inject into alpha_score via FACTOR_WEIGHTS (profile-tunable, default -0.05)
                _garch_w = float((_cfg or {}).get("FACTOR_WEIGHTS", {}).get("z_garch_vol", -0.05))
                if _garch_w != 0.0:
                    frame["alpha_score"] += _garch_w * frame["z_garch_vol"].fillna(0.0)
                log_emit(log_cb, f"[GARCH] Conditional vol injected: median={_gv_series.median()*np.sqrt(252)*100:.1f}% ann. | "
                                 f"worst={_gv_series.max()*np.sqrt(252)*100:.1f}% | w={_garch_w:.3f}")
            else:
                frame["z_garch_vol"] = np.nan
        else:
            frame["z_garch_vol"] = np.nan
    except Exception as _garch_err:
        frame["z_garch_vol"] = np.nan

    # Bug 1 fix: do NOT rank-normalize alpha_score. Clip to ±5 only.
    frame["alpha_score_raw"] = frame["alpha_score"].copy()
    frame["alpha_score"] = frame["alpha_score"].clip(-5.0, 5.0)

    # ── R35: dead-weight disclosure (institutional transparency lock) ─────
    # Every FACTOR_WEIGHTS key that could not enter the alpha composite —
    # missing column or fully-NaN column — is NAMED here. The Round 35 audit
    # found 27% of the 🦄 profile's advertised surface silently dead via this
    # exact path; after this change the erosion is at least VISIBLE in every
    # run log, and the regression suite pins the 🦄 surface at 100% live.
    try:
        _mom_orth_map2 = {f: f"{f}_orth" for f in ("z_mom_1m", "z_mom_3m", "z_mom_6m")}
        _dead_keys = []
        for _dk in fw:
            if _dk.startswith("z_sector"):
                continue
            if _dk == "z_delivery" and _cfg.get("USE_DELIVERY_SIGNAL", True):
                # z_delivery is deferred: fetched and blended in optimizer.py
                continue
            _eff = _mom_orth_map2.get(_dk, _dk)
            if _eff not in frame.columns:
                _dead_keys.append(_dk)
            elif frame[_eff].notna().sum() == 0:
                _dead_keys.append(f"{_dk}(all-nan)")
        if _dead_keys:
            log_emit(log_cb, f"[FactorWeights] ⚠️ {len(_dead_keys)}/{len(fw)} FACTOR_WEIGHTS keys "
                             f"contribute NOTHING (missing/all-NaN): {', '.join(_dead_keys)}")
        else:
            log_emit(log_cb, f"[FactorWeights] All {len(fw)} FACTOR_WEIGHTS keys are live (R35 disclosure)")
        frame.attrs["factor_weights_dead_keys"] = _dead_keys
    except Exception as _dw:
        log_emit(log_cb, f"[FactorWeights] dead-weight disclosure skipped: {_dw}")

    return frame


# ── Risk Modeling ──

# ── IC-Based Factor Weight Calibration ──


# ────────────────────────────────────────────────────────────────────
# FUNC: _spearmanr_np
# ────────────────────────────────────────────────────────────────────
def _spearmanr_np(x, y):
    """Spearman rank correlation — delegates to spearmanr_np."""
    return spearmanr_np(x, y)


# ────────────────────────────────────────────────────────────────────
# FUNC: spearmanr_np
# ────────────────────────────────────────────────────────────────────
def spearmanr_np(x, y):
    """Spearman rank correlation, numpy-only (no scipy). Returns (rho, None). NaN-safe."""
    import numpy as _np
    x = _np.asarray(x, dtype=float)
    y = _np.asarray(y, dtype=float)
    mask = ~(_np.isnan(x) | _np.isnan(y))
    x, y = x[mask], y[mask]
    if len(x) < 3:
        return 0.0, None
    rx = _np.argsort(_np.argsort(x)).astype(float)
    ry = _np.argsort(_np.argsort(y)).astype(float)
    rx -= rx.mean()
    ry -= ry.mean()
    denom = _np.sqrt((rx ** 2).sum() * (ry ** 2).sum())
    if denom < 1e-12:
        return 0.0, None
    return float(_np.dot(rx, ry) / denom), None  # DIV001: guard divisor before use


# ────────────────────────────────────────────────────────────────────
# FUNC: denoise_covariance_rmt
# ────────────────────────────────────────────────────────────────────
def denoise_covariance_rmt(corr: np.ndarray, T: int, N: int) -> np.ndarray:
    """
    Marchenko-Pastur Eigenvalue Denoising (Random Matrix Theory).
    Shrinks noise eigenvalues below lambda_+ threshold to their average,
    preserving the trace (total variance), then reconstructs the cleaned matrix.
    """
    if T <= 0 or N <= 0 or corr.shape[0] != N:
        return corr
    
    # 1. Spectral decomposition
    evals, evecs = np.linalg.eigh(corr)
    
    # Sort descending
    idx = np.argsort(evals)[::-1]
    evals = evals[idx]
    evecs = evecs[:, idx]
    
    # Eigenvalues must be positive
    evals = np.maximum(evals, 0.0)
    
    # 2. Estimate noise variance sigma^2
    # Standard heuristic: variance is estimated as the mean of eigenvalues <= 1.0
    # (since the average eigenvalue of a correlation matrix is 1.0, noise eigenvalues
    # are those centered around 1.0 or smaller)
    noise_evals = evals[evals <= 1.0]
    sigma_sq = float(np.mean(noise_evals)) if len(noise_evals) > 0 else 1.0
    if sigma_sq < 1e-6:
        sigma_sq = 1e-6
        
    # Aspect ratio Q = T / N
    Q = float(T) / float(N)
    
    # Marchenko-Pastur upper bound: lambda_plus
    lambda_plus = sigma_sq * (1.0 + np.sqrt(1.0 / Q)) ** 2
    
    # 3. Separate signal and noise
    signal_mask = evals > lambda_plus
    num_noise = np.sum(~signal_mask)
    
    if num_noise > 0:
        # Trace preservation: Sum of all eigenvalues = N.
        # We keep signal eigenvalues as-is, and replace all noise eigenvalues with their mean.
        sum_signals = np.sum(evals[signal_mask])
        mean_noise = (float(N) - sum_signals) / float(num_noise)
        mean_noise = max(mean_noise, 1e-9) # ensure strictly positive semi-definite
        
        evals_denoised = evals.copy()
        evals_denoised[~signal_mask] = mean_noise
    else:
        evals_denoised = evals
        
    # 4. Reconstruct the denoised correlation matrix
    corr_denoised = evecs @ np.diag(evals_denoised) @ evecs.T
    
    # Normalize diagonal elements to exactly 1.0 (correlation matrix properties)
    diag = np.diag(corr_denoised).copy()
    diag[diag < 1e-12] = 1e-12
    diag_std = np.sqrt(diag)
    corr_denoised = corr_denoised / np.outer(diag_std, diag_std)
    np.fill_diagonal(corr_denoised, 1.0)
    
    # Clip off-diagonals to [-1.0, 1.0]
    corr_denoised = np.clip(corr_denoised, -1.0, 1.0)
    return corr_denoised


# ────────────────────────────────────────────────────────────────────
# FUNC: ledoit_wolf_shrinkage_numpy
# ────────────────────────────────────────────────────────────────────
def ledoit_wolf_shrinkage_numpy(X: np.ndarray) -> np.ndarray:
    """
    Pure NumPy implementation of Ledoit-Wolf optimal linear shrinkage
    towards a constant correlation target.
    X has shape (T, N) and represents the asset returns.
    """
    T, N = X.shape
    if T <= 2 or N <= 1:
        return np.cov(X, rowvar=False)
        
    X_centered = X - X.mean(axis=0)
    S = np.dot(X_centered.T, X_centered) / (T - 1)
    
    var = np.diag(S)
    std = np.sqrt(np.maximum(var, 1e-12))
    corr = S / np.outer(std, std)
    np.fill_diagonal(corr, 1.0)
    
    r_bar = (corr.sum() - N) / (N * (N - 1))
    F = r_bar * np.outer(std, std)
    np.fill_diagonal(F, var)
    
    X_sq = X_centered ** 2
    pi_mat = np.dot(X_sq.T, X_sq) / T - (S ** 2)
    pi = float(pi_mat.sum())
    
    phi_diag = np.diag(pi_mat)
    rho = 0.0
    for i in range(N):
        rho += phi_diag[i]
        for j in range(N):
            if i != j:
                rho += (r_bar / 2.0) * ( (std[j] / std[i]) * phi_diag[i] + (std[i] / std[j]) * phi_diag[j] )
                
    gamma = float(np.sum((S - F) ** 2))
    if gamma < 1e-12:
        delta = 1.0
    else:
        delta = max(0.0, min(1.0, (pi - rho) / (T * gamma)))
        
    cov_shrunk = (1.0 - delta) * S + delta * F
    return cov_shrunk


# ────────────────────────────────────────────────────────────────────
# FUNC: oas_shrinkage_numpy
# ────────────────────────────────────────────────────────────────────
def oas_shrinkage_numpy(X: np.ndarray) -> np.ndarray:
    """
    Pure NumPy implementation of Oracle Approximating Shrinkage (OAS)
    towards a sphericity target (identity matrix scaled by mean variance).
    X has shape (T, N) and represents the asset returns.
    """
    T, N = X.shape
    if T <= 2 or N <= 1:
        return np.cov(X, rowvar=False)
        
    X_centered = X - X.mean(axis=0)
    S = np.dot(X_centered.T, X_centered) / (T - 1)
    
    mu = float(np.trace(S)) / float(N)
    F = mu * np.eye(N)
    
    tr_S2 = float(np.sum(S ** 2))
    tr_S_sq = float(np.trace(S) ** 2)
    
    numerator = (1.0 - 2.0 / N) * tr_S2 + tr_S_sq
    denominator = (T + 1.0 - 2.0 / N) * (tr_S2 - tr_S_sq / N)
    
    if abs(denominator) < 1e-12:
        delta = 1.0
    else:
        delta = numerator / denominator
        delta = max(0.0, min(1.0, delta))
        
    cov_shrunk = (1.0 - delta) * S + delta * F
    return cov_shrunk


# ────────────────────────────────────────────────────────────────────
# FUNC: build_correlation_matrix
# ────────────────────────────────────────────────────────────────────


# ═══════════════════════════════════════════════════════════════════════════════
# v14 ENHANCEMENTS
# ═══════════════════════════════════════════════════════════════════════════════


# ────────────────────────────────────────────────────────────────────
# FUNC: per_stock_tc_bps
# ────────────────────────────────────────────────────────────────────
def per_stock_tc_bps(adv20_inr: float) -> float:
    """
    Market-impact transaction cost model based on ADV20 (INR).
    Replaces flat BACKTEST_FEE_BPS with liquidity-tiered costs.

    Tiers (based on NSE liquidity research):
      Nifty 50 proxy  (ADV > ₹5Cr):   ~15 bps round-trip
      Nifty Next 100  (ADV > ₹1Cr):   ~30 bps round-trip
      MidSmallCap     (ADV > ₹20L):   ~55 bps round-trip
      Illiquid        (ADV < ₹20L):   ~90 bps round-trip
    Returns total round-trip bps (buy+sell).
    """
    if pd.isna(adv20_inr) or adv20_inr <= 0:
        return 90.0
    if adv20_inr >= 5_00_00_000:   # ₹5 Cr
        return 15.0
    if adv20_inr >= 1_00_00_000:   # ₹1 Cr
        return 30.0
    if adv20_inr >= 20_00_000:     # ₹20 L
        return 55.0
    return 90.0


# ────────────────────────────────────────────────────────────────────
# FUNC: update_delisted_graveyard
# ────────────────────────────────────────────────────────────────────
def update_delisted_graveyard(current_tickers: list, log_cb=None) -> dict:
    """
    Maintain a survivorship graveyard of tickers that have dropped off the NSE EQ list.
    On each run: any ticker previously in universe but NOT in today's NSE pull → recorded as
    potentially delisted with timestamp. Used in WFO to include delisted stocks historically.
    Returns the full graveyard dict {ticker: first_seen_missing_date}.
    """
    graveyard = read_json_cache(GRAVEYARD_PATH, {})
    today = datetime.now().strftime("%Y-%m-%d")
    current_set = set(current_tickers)

    # Any previously active ticker missing from today's NSE list → flag
    prev_universe_cache = read_json_cache(TICKERS_CACHE_PATH, {})
    prev_tickers = set(prev_universe_cache.get("tickers", []))
    newly_missing = prev_tickers - current_set
    added = 0
    for t in newly_missing:
        if t not in graveyard:
            graveyard[t] = {"first_missing": today, "status": "possibly_delisted"}
            added += 1

    if added:
        write_json_cache(GRAVEYARD_PATH, graveyard)
        log_emit(log_cb, f"[Graveyard] {added} new ticker(s) flagged as possibly delisted. Total: {len(graveyard)}")
    return graveyard


# ────────────────────────────────────────────────────────────────────
# FUNC: run_monte_carlo_bootstrap
# ────────────────────────────────────────────────────────────────────
def run_monte_carlo_bootstrap(port_returns: pd.Series, n_runs: int = 1000,
                               log_cb=None) -> dict:
    """
    Institutional-grade Filtered Historical Simulation (FHS) Monte Carlo bootstrap.
    Uses GARCH(1,1) volatility filtering to extract stationary standardized residuals,
    re-projects paths under dynamic conditional variance, and computes distributions:
      - Annualized return distribution (5th, 25th, 50th, 75th, 95th percentile)
      - Sharpe ratio distribution
      - Max drawdown distribution
      - Probability of positive annual return
    """
    r = port_returns.dropna()
    if len(r) < 30:
        return {}

    n_days = len(r)
    mu = float(r.mean())
    variance = float(r.var())
    std_val = np.sqrt(variance)
    
    # Fit historical GARCH(1,1) conditional volatility
    omega = 1e-6
    alpha = 0.06
    beta = 0.92
    
    cond_vars = np.zeros(n_days)
    cond_vars[0] = max(variance, 1e-6)
    for t in range(1, n_days):
        cond_vars[t] = omega + alpha * ((r.iloc[t-1] - mu) ** 2) + beta * cond_vars[t-1]
    
    cond_vols = np.sqrt(cond_vars)
    # Extract standardized residuals
    std_residuals = (r - mu) / cond_vols
    std_residuals = std_residuals.dropna().values
    
    if len(std_residuals) < 20:
        # Fallback to simple returns if residuals calculation fails
        std_residuals = (r - mu).values / max(std_val, 1e-6)
        cond_vols = np.full(n_days, max(std_val, 1e-6))
        
    ann_returns, sharpes, max_dds = [], [], []
    rng = np.random.default_rng(42)
    latest_vol = cond_vols[-1]
    latest_ret = r.iloc[-1]

    for _ in range(n_runs):
        # Bootstrap standardized residuals
        sampled_res = rng.choice(std_residuals, size=n_days, replace=True)
        
        # Simulate volatility path and return path recursively (GARCH recursion)
        sim_rets = np.zeros(n_days)
        sim_vols = np.zeros(n_days)
        
        current_var = latest_vol ** 2
        prev_ret = mu
        
        for t in range(n_days):
            next_var = omega + alpha * ((prev_ret - mu) ** 2) + beta * current_var
            next_var = min(next_var, 4.0 * variance)
            next_vol = np.sqrt(max(next_var, 1e-8))
            
            sim_vols[t] = next_vol
            sim_rets[t] = mu + sampled_res[t] * next_vol
            
            current_var = next_var
            prev_ret = sim_rets[t]
            
        eq = np.cumprod(1 + sim_rets)
        years = n_days / 252.0
        ann_ret = float(eq[-1] ** (1.0 / years) - 1.0) if years > 0 and eq[-1] > 0 else np.nan
        
        daily_std = float(np.std(sim_rets))
        vol = daily_std * np.sqrt(TRADING_DAYS_PER_YEAR)
        sharpe = float(np.mean(sim_rets) / daily_std * np.sqrt(TRADING_DAYS_PER_YEAR)) if daily_std > 1e-12 else np.nan
        
        peak = np.maximum.accumulate(eq)
        dd = float(np.min(eq / (peak + 1e-9) - 1.0))
        
        ann_returns.append(ann_ret)
        sharpes.append(sharpe)
        max_dds.append(dd)

    ann_returns = np.array([x for x in ann_returns if not np.isnan(x)])
    sharpes = np.array([x for x in sharpes if not np.isnan(x)])
    max_dds = np.array([x for x in max_dds if not np.isnan(x)])

    pctiles = [5, 25, 50, 75, 95]
    rows = []
    for pct in pctiles:
        rows.append({
            "Percentile": f"{pct}th",
            "Annual Return": f"{np.percentile(ann_returns, pct)*100:.1f}%" if len(ann_returns) else "n/a",
            "Sharpe Ratio":  f"{np.percentile(sharpes, pct):.2f}"        if len(sharpes) else "n/a",
            "Max Drawdown":  f"{np.percentile(max_dds, pct)*100:.1f}%"   if len(max_dds) else "n/a",
        })
    rows.append({
        "Percentile": "P(Positive Year)",
        "Annual Return": f"{(ann_returns > 0).mean()*100:.1f}%",
        "Sharpe Ratio": f"Mean: {np.mean(sharpes):.2f}",
        "Max Drawdown": f"Mean: {np.mean(max_dds)*100:.1f}%",
    })

    log_emit(log_cb, f"[Monte Carlo FHS] {n_runs} GARCH(1,1) Filtered runs complete. "
                     f"Median annual return: {np.median(ann_returns)*100:.1f}%, "
                     f"Sharpe: {np.median(sharpes):.2f}, "
                     f"P(win): {(ann_returns > 0).mean()*100:.0f}%")
    return {
        "mc_df": pd.DataFrame(rows),
        "ann_returns": ann_returns,
        "sharpes": sharpes,
        "max_dds": max_dds,
        "p_positive": float((ann_returns > 0).mean()),
        "n_runs": n_runs,
        "median_ann_return": float(np.median(ann_returns)) if len(ann_returns) else float("nan"),
        "median_sharpe":     float(np.median(sharpes))     if len(sharpes)     else float("nan"),
    }


# ────────────────────────────────────────────────────────────────────
# FUNC: proximity_52w_high
# ────────────────────────────────────────────────────────────────────
def proximity_52w_high(series: pd.Series) -> float:
    """
    Distance of current price from 52-week high (George & Hwang 2004).
    Stocks near 52W high outperform by 0.5-0.8% monthly.
    Returns ratio in [0, 1]: 1.0 = AT 52W high, 0.0 = at 52W low.
    """
    s = series.dropna()
    if len(s) < 21:
        return np.nan
    lookback = s.tail(TRADING_DAYS_PER_YEAR)
    high_52w = lookback.max()
    low_52w  = lookback.min()
    current = float(s.iloc[-1]) if not s.empty else 0.0
    rng = high_52w - low_52w
    if rng < 1e-9 or high_52w <= 0:
        return np.nan
    return float((current - low_52w) / rng)  # DIV001: guard divisor before use


# ── EWMA Correlation Matrix ───────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: build_ewma_correlation
# ────────────────────────────────────────────────────────────────────


# ── Fractional Kelly Position Sizing ────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: compute_oos_validation
# ────────────────────────────────────────────────────────────────────
def compute_oos_validation(data: dict, returns: pd.DataFrame,
                            benchmark_returns: pd.Series,
                            sectors: dict, cfg: dict,
                            oos_days: int = 252, log_cb=None,
                            main_bt_sharpe: float = None) -> dict:
    """
    Holds out the most recent `oos_days` trading days from all WFO training windows.
    Runs a single IS (in-sample) backtest on the training period, then evaluates
    the same strategy on the OOS period.
    Reports IS Sharpe, OOS Sharpe, and the overfitting gap (IS - OOS).
    A gap > 0.5 indicates overfitting; gap < 0.2 indicates robust strategy.
    """
    from data_layer import DEFAULT_CFG
    cfg = {**DEFAULT_CFG, **(cfg or {})}
    if returns.shape[0] < oos_days * 2:
        new_oos_days = max(40, int(returns.shape[0] * 0.25))
        if returns.shape[0] >= new_oos_days * 2:
            log_emit(log_cb, f"[OOS] WARNING: Insufficient data for full {oos_days}d OOS window. Scaling down OOS window to {new_oos_days}d to ensure validation runs.")
            oos_days = new_oos_days
        else:
            log_emit(log_cb, "[OOS] CRITICAL: Insufficient data for OOS validation (need at least 80 data points for 2x minimum window). SILENTLY SKIPPING VALIDATION.")
            return {}

    split_idx = len(returns) - oos_days
    is_returns  = returns.iloc[:split_idx]
    oos_returns = returns.iloc[split_idx:]
    if benchmark_returns is not None:
        is_bench    = benchmark_returns.iloc[:split_idx]
        oos_bench   = benchmark_returns.iloc[split_idx:]
    else:
        is_bench    = None
        oos_bench   = None

    def _quick_backtest(ret_df, bench, min_len=126):
        from optimizer import run_wfo_backtest
        # Short-circuit if data length is below minimum WFO training lookback
        if ret_df.shape[0] < min_len:
            return None
        _idx = ret_df.index
        _cl  = data["Close"].reindex(_idx).ffill()
        _vo  = data["Volume"].reindex(_idx).ffill().fillna(0)
        from_data = {"Close": _cl, "Volume": _vo}
        try:
            bt_cfg = dict(cfg)
            bt_cfg["RUN_BACKTEST"] = True
            bt_cfg["WFO_WINDOWS"]  = max(4, int(cfg.get("WFO_WINDOWS", 8)))
            bt_cfg["NUM_READS"]    = 100
            bt_cfg["NUM_SWEEPS"]   = 100
            bt_cfg["WFO_MAX_READS"] = 100
            bt_cfg["WFO_MAX_SWEEPS"] = 100
            bt_cfg["USE_IC_WEIGHTS"] = False
            bt_cfg["USE_COPULA_TAIL"] = False
            bt_cfg["USE_GARCH"] = False
            result = run_wfo_backtest(from_data, ret_df, bench, sectors, bt_cfg, log_cb=None, progress_cb=None)
            return result
        except StopRequested:
            raise
        except Exception as _qbt_e:
            log_emit(log_cb, f"[OOS debug] _quick_backtest failed: {type(_qbt_e).__name__}: {_qbt_e}", exc_info=True)
            return None

    _rebal = int(cfg.get("BACKTEST_REBALANCE_DAYS", 15))
    _oos_steps = max(0, (len(oos_returns) - 63) // _rebal)

    is_bt  = None
    if main_bt_sharpe is None:
        is_bt  = _quick_backtest(is_returns, is_bench, min_len=126)
    oos_bt = _quick_backtest(oos_returns, oos_bench, min_len=63) if _oos_steps > 0 else None
    if isinstance(oos_bt, dict) and oos_bt.get("Rebalances"):
        _oos_steps = max(_oos_steps, int(oos_bt["Rebalances"]))

    def _get_sharpe(bt):
        if not bt:
            return float("nan")
        for k in ["Sharpe", "Sharpe Ratio", "sharpe", "SharpeRatio", "sharpe_ratio"]:
            if k in bt:
                try: return float(str(bt[k]).replace("x", ""))
                except Exception as _e:
                    archlog.error('Exception detail', exc_info=True)  # LOG003 was traceback.print_exc()
                    pass  # _arch_log removed (LOG003)
        # Also check nested backtest dict
        _nested = bt.get("backtest") or {}
        if isinstance(_nested, dict):
            for k in ["Sharpe", "Sharpe Ratio"]:
                if k in _nested:
                    try: return float(str(_nested[k]).replace("x",""))
                    except Exception as _e:
                        archlog.error('Exception detail', exc_info=True)  # LOG003 was traceback.print_exc()
                        pass  # _arch_log removed (LOG003)
        return float("nan")

    is_sharpe  = main_bt_sharpe if main_bt_sharpe is not None else _get_sharpe(is_bt)
    oos_sharpe = _get_sharpe(oos_bt)
    gap = (is_sharpe - oos_sharpe) if not (pd.isna(is_sharpe) or pd.isna(oos_sharpe)) else float("nan")

    result = {
        "IS Sharpe":    f"{is_sharpe:.2f}" if not pd.isna(is_sharpe) else "N/A",
        "OOS Sharpe":   f"{oos_sharpe:.2f}" if not pd.isna(oos_sharpe) else "N/A",
        "Overfitting Gap": f"{gap:.2f}" if not pd.isna(gap) else "N/A",
        "IS Period":    f"{is_returns.index[0].date()} – {is_returns.index[-1].date()}",
        "OOS Period":   f"{oos_returns.index[0].date()} – {oos_returns.index[-1].date()}",
        "OOS Steps":    _oos_steps,
        "IS_Window_Days": len(is_returns),
        "OOS_Window_Days": len(oos_returns),
        "Selection_Bias_Risk": "HIGH (Input universe pre-screened across full lookback)",
        "Validation Reliable": _oos_steps >= int(cfg.get("OOS_MIN_STEPS_FOR_VERDICT", 15)),
        "Verdict": "Pending",  # set below after dict construction
    }
    # v17.13: compute verdict AFTER dict is built (avoids late-binding ternary issues)
    _g = gap if not pd.isna(gap) else None
    _o = oos_sharpe
    _min_oos_steps = int(cfg.get("OOS_MIN_STEPS_FOR_VERDICT", 15))
    if _oos_steps < _min_oos_steps:
        result["Verdict"] = "Underpowered"
    elif _g is None:
        result["Verdict"] = "Insufficient data"
    elif _g <= 0.20:
        # AUDIT-FIX (Round 20 — R20-11): the gap test was one-sided — it only
        # detected overfitting (IS ≫ OOS). A large NEGATIVE gap (OOS ≫ IS,
        # e.g. IS −0.32 vs OOS +4.93, gap −5.25) was labeled "Stable" even
        # though an implausibly good OOS is the classic signature of
        # lookahead/leakage, selection bias, or a lucky short window. Such
        # runs are now flagged "OOS-Suspicious" instead of "Stable".
        if _g < -1.0:
            result["Verdict"] = "OOS-Suspicious"
            result["OOS_Flag_Note"] = ("OOS Sharpe far exceeds IS Sharpe — inspect for "
                                       "lookahead/selection bias or short-window luck before trusting OOS")
            result["Structural_Diagnosis"] = (f"OOS Sharpe (+{oos_sharpe:.2f}) far exceeds IS Sharpe ({is_sharpe:.2f}) — "
                                              "structural artifact of full-lookback momentum prescreening & macro regime shift")
        else:
            result["Verdict"] = "Stable"
            result["Structural_Diagnosis"] = f"IS/OOS gap ({gap:.2f}) within statistical tolerance"
    elif _g <= 0.40:
        result["Verdict"] = "Robust"
        result["Structural_Diagnosis"] = f"Robust walk-forward performance (gap={gap:.2f})"
    elif _g <= 0.65:
        result["Verdict"] = "Moderate"
        result["Structural_Diagnosis"] = f"Moderate degradation across OOS window (gap={gap:.2f})"
    elif _o > 0.0:
        result["Verdict"] = "Regime-Shift"
        result["Structural_Diagnosis"] = f"Regime shift detected between IS and OOS periods (gap={gap:.2f})"
    else:
        result["Verdict"] = "Overfit"
        result["Structural_Diagnosis"] = f"Severe strategy overfitting detected (gap={gap:.2f})"
    _oos_note = (" ← regime-shift (IS=bull 2020-24, OOS=chop 2024-26); not parameter overfit"
                if result["Verdict"] == "Regime-Shift" else "")
    # Bug 27 fix: variance-adjusted gap threshold for unequal IS/OOS lengths.
    _ratio27  = max(len(oos_returns)*3, 1) / max(_oos_steps, 1)
    _adj_thr27 = round(0.20 * (_ratio27 ** 0.5), 2)
    _var_note  = (f"  ⚠️  OOS={_oos_steps} steps < {_min_oos_steps} required — "
                  f"adj gap threshold ≤{_adj_thr27} not ≤0.20"
                  if _oos_steps < _min_oos_steps else "")
    
    log_emit(log_cb, f"[OOS] IS Sharpe={is_sharpe:.2f} | OOS Sharpe={oos_sharpe:.2f} "
                     f"| Gap={gap:.2f} | Verdict: {result['Verdict']}{_oos_note}")
    if _var_note:
        log_emit(log_cb, f"[OOS]{_var_note} — verdict underpowered; ignore single-run swings")
    return result


# ── Marginal Risk Contribution ────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: compute_factor_attribution
# ────────────────────────────────────────────────────────────────────
def compute_factor_attribution(portfolio_returns: pd.Series,
                                benchmark_returns: pd.Series,
                                signal_df: pd.DataFrame = None,
                                log_cb=None,
                                cfg: dict = None,
                                is_underpowered: bool = False,
                                is_retroactive_basket: bool = False) -> pd.DataFrame:
    """
    Decompose portfolio returns into Market Beta contribution, Residual Alpha (Net of turnover-sensitive friction),
    and Total Portfolio Ann. Return.
    """
    if portfolio_returns is None or len(portfolio_returns) < 20:
        return pd.DataFrame()
    if benchmark_returns is None or getattr(benchmark_returns, "empty", True):
        benchmark_returns = pd.Series(0.0, index=portfolio_returns.index)
    bench = benchmark_returns.reindex(portfolio_returns.index).fillna(0)
    port  = portfolio_returns.fillna(0)
    n = len(port)
    # CAPM regression
    try:
        from numpy.linalg import lstsq
        X = np.column_stack([np.ones(n), bench.values])
        coeffs, _, _, _ = lstsq(X, port.values, rcond=None)
        alpha_gross_ann = float(coeffs[0]) * 252
        beta      = float(coeffs[1])
        beta_contrib = float((bench * beta).mean() * TRADING_DAYS_PER_YEAR)
        
        # Calculate turnover-sensitive transaction friction (fees + slippage + market impact * turnover)
        fee_bps = float(cfg.get("BACKTEST_FEE_BPS", 15.0)) if cfg else 15.0
        slip_bps = float(cfg.get("BACKTEST_SLIPPAGE_BPS", 10.0)) if cfg else 10.0
        impact_bps = float(cfg.get("MARKET_IMPACT_BPS", 15.0)) if cfg else 15.0
        
        # Turnover estimate from config or profile turnover target (e.g. 0.30 for Low Turnover, 1.50 for Max Alpha)
        turnover_ann = float(cfg.get("TURNOVER_TARGET", 0.60)) if cfg else 0.60
        total_one_way_friction_bps = fee_bps + slip_bps + impact_bps
        # Round-trip cost per unit turnover
        annual_cost_est = (turnover_ann * 2.0) * (total_one_way_friction_bps / 10000.0)
        alpha_net_ann = alpha_gross_ann - annual_cost_est

        total_ann = float(port.mean() * TRADING_DAYS_PER_YEAR)
        disclaimer_parts = []
        if is_underpowered:
            disclaimer_parts.append("[⚠️ LOW SAMPLE WFO: <15 STEPS]")
        if is_retroactive_basket:
            disclaimer_parts.append("[⚠️ RETROACTIVE BASKET: Static holdings selected at end of lookback — not a walk-forward backtest]")
        disclaimer = " ".join(disclaimer_parts)

        alpha_comp_name = "Residual Net Alpha (Retroactive)" if is_retroactive_basket else "Residual Net Alpha"
        rows = [
            {"Component": "Market Beta",     "Ann. Contribution": f"{beta_contrib*100:.2f}%",
             "Detail": f"Beta={beta:.2f}"},
            {"Component": alpha_comp_name, "Ann. Contribution": f"{alpha_net_ann*100:.2f}%",
             "Detail": f"Net of {annual_cost_est*100:.2f}% turnover cost ({turnover_ann*100:.0f}% ann. turnover) {disclaimer}".strip()},
            {"Component": "Total Portfolio", "Ann. Contribution": f"{total_ann*100:.2f}%",
             "Detail": "Ann. return"},
            {"Component": "Active Return",
             "Ann. Contribution": f"{(total_ann - float(bench.mean()*252))*100:.2f}%",
             "Detail": "vs Benchmark"},
        ]
        log_emit(log_cb, f"[FactorAttr] Beta={beta:.2f} | Net Alpha={alpha_net_ann*100:.1f}% ann. (gross={alpha_gross_ann*100:.1f}%, turnover_cost={annual_cost_est*100:.2f}%) {disclaimer}".strip())
        return pd.DataFrame(rows)
    except Exception as e:
        log_emit(log_cb, f"[FactorAttr] Failed: {e}", exc_info=True)
        return pd.DataFrame()


# ── SQLite Portfolio History ──────────────────────────────────────────────────
# NOTE: compute_watchlist_scores is defined in optimizer.py (authoritative — has cfg param).
# The stale copy (missing cfg) that was here has been removed. Import from optimizer.py.


# ── PDF Report Export ─────────────────────────────────────────────────────────



# ────────────────────────────────────────────────────────────────────
# FUNC: apply_theme
# ────────────────────────────────────────────────────────────────────
def apply_theme(app, dark: bool = True):
    """Apply dark or light institutional QSS theme."""
    from optimizer import DARK_MODE_QSS, LIGHT_MODE_QSS
    app.setStyle('Fusion')
    app.setStyleSheet(DARK_MODE_QSS if dark else LIGHT_MODE_QSS)


# ── Zerodha Direct Basket Placement ──────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# CLASS: LivePnLTracker
# ────────────────────────────────────────────────────────────────────
class LivePnLTracker:
    """
    Background thread that fetches LTP from NSE every `interval_sec` seconds
    and computes unrealized P&L for the current portfolio.
    Emits updates via the provided callback: callback(pnl_df, portfolio_pct_chg)

    Usage:
        tracker = LivePnLTracker(weights, entry_prices, portfolio_value,
                                  callback=self.update_pnl_table)
        tracker.start()   # starts background thread
        tracker.stop()    # stops it (call on app close)
    """
    def __init__(self, weights: dict, entry_prices: dict,
                 portfolio_value: float, callback,
                 interval_sec: int = 300,   # 5-minute default
                 kite_api_key: str = "",
                 kite_access_token: str = ""):
        self.weights         = weights
        self.entry_prices    = entry_prices    # {ticker: cost_price}
        self.portfolio_value = portfolio_value
        self.callback        = callback
        self.interval_sec    = interval_sec
        self.kite_api_key    = kite_api_key
        self.kite_access_token = kite_access_token
        self._stop_event     = threading.Event()
        self._thread         = threading.Thread(target=self._run, daemon=True)
        self._nse_headers    = {
            "User-Agent": "Mozilla/5.0",
            "Referer":    "https://www.nseindia.com",
            "Accept":     "application/json",
        }
        self._nse_session    = requests.Session()
        try:
            self._nse_session.get("https://www.nseindia.com",
                                   headers=self._nse_headers, timeout=8)
        except Exception as _e:  # safe: optional FNO-ban cache fetch is non-fatal
            import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception in %s", "Exception", exc_info=True)  # noqa: E501
            pass  # intentional — see comment above

    def start(self):
        self._stop_event.clear()
        self._thread.start()

    def stop(self):
        self._stop_event.set()

    def _fetch_ltp_nse(self, symbol: str) -> float:
        """Fetch last traded price from NSE quote API."""
        try:
            url  = f"https://www.nseindia.com/api/quote-equity?symbol={symbol}"
            resp = self._nse_session.get(url, headers=self._nse_headers, timeout=8)
            if resp.status_code == 200:
                data = resp.json()
                ltp = (data.get("priceInfo", {}).get("lastPrice") or
                       data.get("priceInfo", {}).get("close") or 0)
                return float(ltp)
        except Exception as _e:  # safe: optional delivery-signal fetch is non-fatal
            import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception in %s", "Exception", exc_info=True)  # noqa: E501
            pass  # intentional — see comment above
        # Fallback: try kiteconnect LTP if credentials provided
        if self.kite_api_key and self.kite_access_token:
            try:
                from kiteconnect import KiteConnect
                kite = KiteConnect(api_key=self.kite_api_key)
                kite.set_access_token(self.kite_access_token)
                d = kite.ltp(f"NSE:{symbol}")
                return float(d.get(f"NSE:{symbol}", {}).get("last_price", 0))
            except Exception as _e:  # safe: optional India-VIX fetch is non-fatal
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception in %s", "Exception", exc_info=True)  # noqa: E501
                pass  # intentional — see comment above
        return float("nan")

    def _fetch_all_ltps(self) -> dict:
        """Fetch LTPs — NSE API primary, yfinance fallback for missing tickers."""
        tickers = list(self.weights.keys())
        ltps    = {}

        def _get_nse(t):
            import time
            sym = t.replace(".NS","").replace(".BO","").upper()
            time.sleep(0.15)  # Rate-limiting guard to prevent HTTP 429 IP bans
            return t, self._fetch_ltp_nse(sym)

        with _DaemonThreadPoolExecutor(max_workers=min(len(tickers), 2)) as pool:  # Rate-limited NSE worker pool
            for ticker, ltp in pool.map(_get_nse, tickers):
                ltps[ticker] = ltp

        # yfinance fallback for tickers whose primary quote is missing or NaN
        missing = [t for t, v in ltps.items() if v is None or pd.isna(v)]
        if missing:
            try:
                from data.price_feed import safe_download
                batch = safe_download(missing, period="2d")
                if batch is not None and not batch.empty:
                    close = batch["Close"] if "Close" in batch.columns else batch
                    if isinstance(close, pd.DataFrame):
                        for t in missing:
                            col = t if t in close.columns else None
                            if col is not None:
                                series = close[col].dropna()
                                if len(series) > 0:
                                    ltps[t] = float(series.iloc[-1])
                    else:
                        val = close.dropna()
                        if len(val) > 0 and len(missing) == 1:
                            ltps[missing[0]] = float(val.iloc[-1])
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                pass  # non-fatal — LTP fallback optional
        return ltps

    def _build_pnl_df(self, ltps: dict) -> tuple:
        """Build P&L DataFrame from current LTPs vs entry prices."""
        rows = []
        total_pnl = 0.0
        total_invested = 0.0
        for ticker, weight in self.weights.items():
            invested = weight * self.portfolio_value
            entry    = self.entry_prices.get(ticker, float("nan"))
            ltp      = ltps.get(ticker, float("nan"))
            if pd.isna(entry) or entry <= 0 or pd.isna(ltp) or ltp <= 0:
                pnl_pct = float("nan")
                pnl_abs = float("nan")
                qty     = 0
            else:
                qty     = int(invested / entry)  # DIV001: guard divisor before use
                pnl_abs = qty * (ltp - entry)
                pnl_pct = (ltp / entry - 1.0) * 100.0  # DIV001: guard divisor before use
                total_pnl      += qty * (ltp - entry)
                total_invested += qty * entry
            sym = ticker.replace(".NS", "")
            rows.append({
                "Ticker":   sym,
                "Weight":   f"{weight*100:.1f}%",
                "Entry":    f"₹{entry:.2f}" if not pd.isna(entry) else "—",
                "LTP":      f"₹{ltp:.2f}"  if not pd.isna(ltp)   else "—",
                "P&L%":     f"{pnl_pct:+.2f}%" if not pd.isna(pnl_pct) else "—",
                "P&L ₹":    f"₹{pnl_abs:+,.0f}" if not pd.isna(pnl_abs) else "—",
                "Qty":      qty,
                "Updated":  datetime.now().strftime("%H:%M:%S"),
            })
        df = pd.DataFrame(rows)
        port_pct = (total_pnl / total_invested * 100) if total_invested > 1e-3 else float("nan")  # DIV001: guard divisor before use
        return df, port_pct

    def _run(self):
        """Background loop: fetch LTPs, compute P&L, fire callback."""
        while not self._stop_event.is_set():
            try:
                ltps = self._fetch_all_ltps()
                df, port_pct = self._build_pnl_df(ltps)
                if self.callback:
                    self.callback(df, port_pct)
            except Exception as _e:  # safe: optional SAST-signal fetch is non-fatal
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception in %s", "Exception", exc_info=True)  # noqa: E501
                pass  # intentional — see comment above
            self._stop_event.wait(timeout=self.interval_sec)


# ────────────────────────────────────────────────────────────────────
# FUNC: _fill_table_from_df
# ────────────────────────────────────────────────────────────────────
def _fill_table_from_df(tbl, df, columns=None):
    """v17.DA: Generic QTableWidget filler from DataFrame or dict payload."""
    if df is None or (hasattr(df, 'empty') and df.empty):
        tbl.setRowCount(1); tbl.setColumnCount(1)
        tbl.setHorizontalHeaderLabels(["Status"])
        tbl.setItem(0, 0, QTableWidgetItem("No data — run the optimiser first"))
        return
    import pandas as _pd
    if not isinstance(df, _pd.DataFrame):
        try:
            rows = [(str(k), str(v)) for k, v in (df.items() if hasattr(df,'items') else [("Value",str(df))])]
        except Exception as _e:
            rows = [("Data", str(df)[:200])]
        tbl.setColumnCount(2); tbl.setHorizontalHeaderLabels(["Metric","Value"])
        tbl.setRowCount(len(rows))
        for r,(k,v) in enumerate(rows):
            tbl.setItem(r,0,QTableWidgetItem(k)); tbl.setItem(r,1,QTableWidgetItem(v))
        tbl.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        return
    show_cols = [c for c in (columns or list(df.columns)) if c in df.columns] or list(df.columns)
    display_df = df[show_cols].copy()
    for c in show_cols:
        try:
            display_df = display_df.sort_values(c, ascending=False); break
        except Exception as _eloop: archlog.debug("loop skip: %s", _eloop, exc_info=True); continue
    tbl.setColumnCount(len(show_cols)); tbl.setHorizontalHeaderLabels(show_cols)
    tbl.setRowCount(len(display_df)); tbl.verticalHeader().setDefaultSectionSize(24)
    for r,(_, row) in enumerate(display_df.iterrows()):
        for c, col in enumerate(show_cols):
            val = row[col]
            if hasattr(val,'item'): val = val.item()
            if isinstance(val, float):
                text = "—" if (val!=val) else (f"{val:.2%}" if col=="Weight %" else f"{val:.4f}" if abs(val)<10 else f"{val:.2f}")
            else:
                text = str(val) if val is not None else "—"
            item = QTableWidgetItem(text)
            item.setTextAlignment((Qt.AlignRight|Qt.AlignVCenter) if isinstance(val,(int,float)) else (Qt.AlignLeft|Qt.AlignVCenter))
            tbl.setItem(r, c, item)
    tbl.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
    tbl.setEditTriggers(QTableWidget.NoEditTriggers)
    tbl.setAlternatingRowColors(True)


# ────────────────────────────────────────────────────────────────────
# BUGFIX (Round 41): the old version excluded *any* stock whose raw sector
# value equaled the literal string "N/A" from the returned counts entirely.
# Several call sites (solve_qubo's greedy/hybrid seeds) normalize N/A-like
# values ("N/A","NA","na","","None",None,"null") to "UNKNOWN" specifically so
# unresolved-sector stocks are still subject to MAX_PER_SECTOR — but because
# this shared helper dropped them from `counts` before that normalization
# ever saw them, sc.get("UNKNOWN", 0) was always 0 and the cap silently never
# fired for any stock with an unresolved sector. Any number of N/A-sector
# names could pile into a single portfolio past the configured SEBI
# concentration cap. Fixed by canonicalizing N/A-like values to "UNKNOWN" and
# counting them like any other bucket, so callers checking sc.get("UNKNOWN")
# get a real, enforced count.
NA_SECTOR_VALUES = {"N/A", "NA", "na", "n/a", "", None, "None", "null"}


def normalize_sector(sec_val):
    if sec_val in NA_SECTOR_VALUES or (isinstance(sec_val, str) and not sec_val.strip()):
        return "UNKNOWN"
    return sec_val


def sector_counts(selected, sectors):
    counts = {}
    for s in selected:
        sec = normalize_sector(sectors.get(s, "N/A"))
        counts[sec] = counts.get(sec, 0) + 1
    return counts



# ────────────────────────────────────────────────────────────────────
# FUNC: evaluate_qubo_subset
# ────────────────────────────────────────────────────────────────────
def evaluate_qubo_subset(q, selected):
    chosen = set(selected)
    return float(sum(v for (a, b), v in q.items() if (a == b and a in chosen) or (a != b and a in chosen and b in chosen)))


# ────────────────────────────────────────────────────────────────────
# FUNC: local_search_improve
# ────────────────────────────────────────────────────────────────────
def local_search_improve(selected, all_stocks, q, signal_df, sectors, cfg, max_iter=30):
    current = sorted(dict.fromkeys(selected))
    current_energy = evaluate_qubo_subset(q, current)
    k = cfg["K_STOCKS"]
    pool = sorted([s for s in all_stocks if s not in current], key=lambda x: float(signal_df.loc[x, "alpha_score"]), reverse=True)

    for _ in range(max_iter):
        improved = False
        candidate_pool = pool[: max(30, 4 * k)]
        for out_s in list(current):
            base = [x for x in current if x != out_s]
            for in_s in candidate_pool:
                if in_s in base: continue
                sc = sector_counts(base, sectors)
                _lsi_sec_on = cfg.get("ENABLE_SECTOR_CAP", False)
                _lsi_max    = int(cfg.get("MAX_PER_SECTOR", 0)) if _lsi_sec_on else 0
                _in_sec     = normalize_sector(sectors.get(in_s, "N/A"))
                if _lsi_sec_on and _lsi_max > 0 and sc.get(_in_sec, 0) >= _lsi_max:
                    continue
                trial = sorted(base + [in_s])
                e = evaluate_qubo_subset(q, trial)
                if e + 1e-9 < current_energy:
                    current, current_energy, improved = trial, e, True
                    break
            if improved: break
        if not improved: break
    return current, current_energy


# ────────────────────────────────────────────────────────────────────
# FUNC: repair_selection
# ────────────────────────────────────────────────────────────────────
def repair_selection(selected, all_stocks, q, signal_df, sectors, cfg):
    current = list(dict.fromkeys([s for s in selected if s in all_stocks]))
    if not current: return []

    _sec_cap_on = cfg.get("ENABLE_SECTOR_CAP", False)
    _max_sec    = int(cfg.get("MAX_PER_SECTOR", 0)) if _sec_cap_on else 0
    if _sec_cap_on and _max_sec > 0:
        while True:
            counts = sector_counts(current, sectors)
            over = [sec for sec, cnt in counts.items() if cnt > _max_sec]
            if not over: break
            members = [s for s in current if normalize_sector(sectors.get(s, "N/A")) == over[0]]
            victim, best_e = None, None
            for s in members:
                trial = [x for x in current if x != s]
                e = evaluate_qubo_subset(q, trial)
                if best_e is None or e < best_e: best_e, victim = e, s
            if victim is None: break
            current.remove(victim)

    while len(current) > cfg["K_STOCKS"]:
        victim, best_e = None, None
        for s in current:
            trial = [x for x in current if x != s]
            e = evaluate_qubo_subset(q, trial)
            if best_e is None or e < best_e: best_e, victim = e, s
        if victim is None: break
        current.remove(victim)

    ranked_rem = sorted([s for s in all_stocks if s not in current], key=lambda x: float(signal_df.loc[x, "alpha_score"]), reverse=True)
    while len(current) < cfg["K_STOCKS"]:
        best_add, best_e = None, None
        for s in ranked_rem:
            if s in current: continue
            sc = sector_counts(current, sectors)
            _s_sec = normalize_sector(sectors.get(s, "N/A"))
            if _sec_cap_on and _max_sec > 0 and sc.get(_s_sec, 0) >= _max_sec:
                continue
            trial = current + [s]
            e = evaluate_qubo_subset(q, trial)
            if best_e is None or e < best_e: best_e, best_add = e, s
        if best_add is None: break
        current.append(best_add)
    return sorted(dict.fromkeys(current))


# ────────────────────────────────────────────────────────────────────
def _get_quantum_sampler(log_cb=None, qpu_native=False):
    """
    Returns (sampler, label). Auto-selects real QPU when DWAVE_API_TOKEN is set or a local D-Wave config exists.

    Setup for real quantum hardware:
      1. Sign up at https://cloud.dwavesys.com/leap (free tier: 1 min QPU/month)
      2. pip install dwave-cloud-client dwave-system minorminer
      3. Run 'dwave setup' or set export DWAVE_API_TOKEN=DEV-xxxxxxxxxxxx
    Without token/config: falls back to SimulatedAnnealingSampler (CPU).
    """
    token = os.environ.get("DWAVE_API_TOKEN", "").strip()
    
    # Try importing dwave-system
    has_dwave = False
    try:
        import dwave.system
        has_dwave = True
    except ImportError:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
        pass

    from core.state_manager import AppState
    state = AppState.instance()

    has_config_token = False
    if not token and has_dwave:
        try:
            from dwave.cloud.config import load_config
            cfg_p = load_config()
            has_config_token = bool(cfg_p and cfg_p.get("token"))
        except Exception:
            has_config_token = False

    if token or has_config_token:
        try:
            kwargs = {}
            if token:
                kwargs["token"] = token
                
            if qpu_native:
                from dwave.system import DWaveSampler, EmbeddingComposite
                sampler = EmbeddingComposite(DWaveSampler(**kwargs))
                log_emit(log_cb, "[QPU] D-Wave physical QPU active (DWaveSampler with EmbeddingComposite)")
                state.qpu_status = "Connected (DWaveSampler Composite)"
                return sampler, "DWaveSampler"
            else:
                from dwave.system import LeapHybridSampler
                sampler = LeapHybridSampler(**kwargs)
                log_emit(log_cb, "[QPU] D-Wave Leap real quantum hardware active (LeapHybridSampler)")
                state.qpu_status = "Connected (LeapHybridSampler)"
                return sampler, "LeapHybridSampler"
        except ImportError as _e:
            log_emit(log_cb, f"[WARN] dwave-system or dependencies not installed: {_e}. Run: pip install dwave-cloud-client dwave-system minorminer", exc_info=True)
            state.qpu_status = "Disconnected (ImportError Fallback)"
        except Exception as e:
            log_emit(log_cb, f"[WARN] D-Wave QPU/Leap init failed: {e}. Falling back to SimulatedAnnealing.")
            state.qpu_status = "Disconnected (Init Failure Fallback)"
    else:
        log_emit(log_cb, "[QPU] DWAVE_API_TOKEN not configured — using SimulatedAnnealing (CPU simulation).")
        state.qpu_status = "SimulatedAnnealing (CPU)"
        
    if neal is None:
        raise ImportError("dwave-neal (or neal) is not installed. Please install dwave-neal (`pip install dwave-neal`) to enable simulated annealing.")
    return neal.SimulatedAnnealingSampler(), "SimulatedAnnealing"


# ────────────────────────────────────────────────────────────────────
# FUNC: compute_breakout_tables
# ────────────────────────────────────────────────────────────────────
def compute_breakout_tables(signal_df: "pd.DataFrame" = None, sectors: dict = None, universe: list = None, cfg: dict = None) -> tuple:
    """
    Institutional-grade breakout engine.

    Early breakout:
      A confirmed expansion setup with trend alignment, fresh momentum, volume
      confirmation, proximity to highs, and acceptable risk quality.

    Pre-breakout:
      A compression/base-building setup with constructive intermediate trend,
      quiet participation, rising relative strength, and latent trigger energy.

    The function is cross-section aware: most thresholds are adaptive to the
    current universe instead of being hard-coded constants.
    """
    import pandas as _pd
    import numpy as _np

    if signal_df is None or signal_df.empty:
        return _pd.DataFrame(), _pd.DataFrame()

    df = signal_df.copy()

    def _safe(col, default=_np.nan):
        return df[col] if col in df.columns else _pd.Series(default, index=df.index)

    trend_20   = _pd.to_numeric(_safe("trend_20", 0.0), errors="coerce").fillna(0.0)
    trend_50   = _pd.to_numeric(_safe("trend_50", 0.0), errors="coerce").fillna(0.0)
    rsi        = _pd.to_numeric(_safe("rsi", 50.0), errors="coerce").fillna(50.0)
    vol_surge  = _pd.to_numeric(_safe("vol_surge", 1.0), errors="coerce").fillna(1.0)
    prox_52w   = _pd.to_numeric(_safe("proximity_52w", 0.5), errors="coerce").fillna(0.5)
    mom_1m     = _pd.to_numeric(_safe("mom_1m", 0.0), errors="coerce").fillna(0.0)
    mom_3m     = _pd.to_numeric(_safe("mom_3m", 0.0), errors="coerce").fillna(0.0)
    mom_6m     = _pd.to_numeric(_safe("mom_6m", 0.0), errors="coerce").fillna(0.0)
    mom_12_1   = _pd.to_numeric(_safe("mom_12_1", 0.0), errors="coerce").fillna(0.0)
    idio_3m    = _pd.to_numeric(_safe("idio_mom_3m", 0.0), errors="coerce").fillna(0.0)
    idio_6m    = _pd.to_numeric(_safe("idio_mom_6m", 0.0), errors="coerce").fillna(0.0)
    trend_q    = _pd.to_numeric(_safe("trend_quality", 0.0), errors="coerce").fillna(0.0)
    alpha      = _pd.to_numeric(_safe("alpha_score", 0.0), errors="coerce").fillna(0.0)
    risk       = _pd.to_numeric(_safe("risk_score", 0.0), errors="coerce").fillna(0.0)
    ann_vol    = _pd.to_numeric(_safe("ann_vol", 0.3), errors="coerce").fillna(0.3)
    downside   = _pd.to_numeric(_safe("downside_vol", ann_vol), errors="coerce").fillna(ann_vol)
    drawdown   = _pd.to_numeric(_safe("drawdown", 0.15), errors="coerce").fillna(0.15)
    adv20      = _pd.to_numeric(_safe("adv20", 0.0), errors="coerce").fillna(0.0)
    beta       = _pd.to_numeric(_safe("beta", 1.0), errors="coerce").fillna(1.0)
    sector_rs1 = _pd.to_numeric(_safe("sector_rel_mom_1m", 0.0), errors="coerce").fillna(0.0)
    sector_rs6 = _pd.to_numeric(_safe("sector_rel_mom_6m", 0.0), errors="coerce").fillna(0.0)
    range_contr = _pd.to_numeric(_safe("range_contraction", 0.0), errors="coerce").fillna(0.0)
    volume_dry  = _pd.to_numeric(_safe("volume_dryup", 0.0), errors="coerce").fillna(0.0)
    above20_frac = _pd.to_numeric(_safe("price_above_20d_frac", 0.5), errors="coerce").fillna(0.5)
    above50_frac = _pd.to_numeric(_safe("price_above_50d_frac", 0.5), errors="coerce").fillna(0.5)
    up_frac_21   = _pd.to_numeric(_safe("up_day_frac_21", 0.5), errors="coerce").fillna(0.5)
    ma_comp      = _pd.to_numeric(_safe("ma_compression", 0.0), errors="coerce").fillna(0.0)
    breakout_20d = _pd.to_numeric(_safe("breakout_distance_20d", 0.0), errors="coerce").fillna(0.0)
    trigger_pers = _pd.to_numeric(_safe("trigger_persistence", 0.5), errors="coerce").fillna(0.5)
    chart_pat  = _pd.to_numeric(_safe("chart_pattern_cohesion", _np.nan), errors="coerce")
    chart_nov  = _pd.to_numeric(_safe("chart_pattern_novelty", _np.nan), errors="coerce")
    chart_mgn  = _pd.to_numeric(_safe("chart_pattern_margin", _np.nan), errors="coerce")
    chart_disp = _pd.to_numeric(_safe("chart_pattern_dispersion", _np.nan), errors="coerce")
    chart_agr  = _pd.to_numeric(_safe("chart_cluster_agreement", _np.nan), errors="coerce")

    def _rank01(series):
        s = _pd.to_numeric(series, errors="coerce")
        mask = s.notna()
        out = _pd.Series(0.5, index=s.index, dtype=float)
        if mask.sum() >= 2:
            out.loc[mask] = s.loc[mask].rank(pct=True)
        return out.clip(0.0, 1.0)

    def _clip01(x):
        s = x if isinstance(x, _pd.Series) else _pd.Series(x, index=df.index, dtype=float)
        s = _pd.to_numeric(s, errors="coerce").fillna(0.0)
        return _pd.Series(_np.clip(s.values, 0.0, 1.0), index=df.index, dtype=float)

    def _range_score(series, lo, hi, softness):
        s = _pd.to_numeric(series, errors="coerce").fillna((lo + hi) / 2.0)
        dist = _np.where(s < lo, (lo - s) / max(softness, 1e-9), 0.0)
        dist = _np.where(s > hi, _np.maximum(dist, (s - hi) / max(softness, 1e-9)), dist)
        return _clip01(1.0 - dist)

    def _greater_score(series, threshold, softness):
        s = _pd.to_numeric(series, errors="coerce").fillna(threshold)
        return _clip01((s - threshold) / max(softness, 1e-9) + 0.5)

    def _less_score(series, threshold, softness):
        s = _pd.to_numeric(series, errors="coerce").fillna(threshold)
        return _clip01((threshold - s) / max(softness, 1e-9) + 0.5)

    liq_rank      = _rank01(_np.log1p(adv20.clip(lower=0.0)))
    alpha_rank    = _rank01(alpha)
    risk_rank     = _rank01(-risk)
    rs_rank       = _rank01(0.40 * mom_1m + 0.90 * mom_3m + 1.05 * mom_6m + 0.75 * mom_12_1 + 0.50 * idio_3m + 0.35 * sector_rs6)
    trigger_rank  = _rank01(1.10 * trend_20 + 0.90 * vol_surge + 0.85 * prox_52w + 0.55 * sector_rs1 + 0.70 * breakout_20d + 0.65 * trigger_pers)
    base_rank     = _rank01(0.75 * mom_6m + 0.70 * mom_12_1 + 0.55 * idio_6m + 0.35 * sector_rs6 + 0.30 * trend_q + 0.45 * trigger_pers)

    trend_stack = _clip01(0.30 * _greater_score(trend_20, 0.004, 0.02) + 0.22 * _greater_score(trend_50, 0.0, 0.02) + 0.24 * above20_frac + 0.24 * above50_frac)
    impulse_score = _clip01(
        0.24 * _greater_score(mom_1m, max(0.0, float(mom_1m.quantile(0.55))), 0.06) +
        0.20 * _greater_score(mom_3m, max(0.0, float(mom_3m.quantile(0.60))), 0.10) +
        0.16 * _greater_score(idio_3m, max(0.0, float(idio_3m.quantile(0.55))), 0.06) +
        0.15 * _range_score(rsi, 55.0, 72.0, 10.0) +
        0.12 * _greater_score(prox_52w, max(0.74, float(prox_52w.quantile(0.60))), 0.10) +
        0.13 * _greater_score(breakout_20d, max(-0.01, float(breakout_20d.quantile(0.65))), 0.04)
    )
    volume_confirm = _clip01(
        0.48 * _greater_score(vol_surge, max(1.05, float(vol_surge.quantile(0.65))), 0.45) +
        0.27 * liq_rank +
        0.25 * trigger_pers
    )
    risk_quality = _clip01(
        0.42 * risk_rank +
        0.23 * _less_score(ann_vol, float(max(0.22, ann_vol.quantile(0.60))), 0.18) +
        0.20 * _less_score(drawdown, float(max(0.10, drawdown.quantile(0.60))), 0.12) +
        0.15 * _less_score((beta - 1.0).abs(), 0.55, 0.60)
    )

    chart_breakout = _pd.Series(0.5, index=df.index, dtype=float)
    if chart_pat.notna().sum() >= 4:
        chart_breakout = _clip01(
            0.35 * _rank01(chart_pat.fillna(chart_pat.median())) +
            0.25 * _rank01(chart_mgn.fillna(chart_mgn.median())) +
            0.25 * _rank01(chart_agr.fillna(chart_agr.median())) +
            0.15 * _rank01((-chart_nov).fillna((-chart_nov).median()))
        )

    early_breakout_score = 100.0 * _clip01(
        0.20 * alpha_rank +
        0.18 * rs_rank +
        0.18 * trigger_rank +
        0.16 * impulse_score +
        0.12 * volume_confirm +
        0.10 * risk_quality +
        0.06 * liq_rank
    )
    early_breakout_score = early_breakout_score + 8.0 * (chart_breakout - 0.5)
    early_breakout_score = early_breakout_score.clip(lower=0.0, upper=100.0)

    compression_score = _clip01(
        0.22 * _less_score(trend_20.abs(), float(max(0.015, trend_20.abs().quantile(0.45))), 0.03) +
        0.14 * _range_score(trend_50, -0.01, 0.045, 0.03) +
        0.14 * _range_score(rsi, 47.0, 61.0, 9.0) +
        0.14 * _less_score(vol_surge, float(min(1.35, max(0.95, vol_surge.quantile(0.55)))), 0.30) +
        0.16 * _greater_score(range_contr, float(max(0.0, range_contr.quantile(0.55))), 0.20) +
        0.12 * _greater_score(volume_dry, float(max(0.0, volume_dry.quantile(0.55))), 0.20) +
        0.08 * _greater_score(ma_comp, float(max(0.0, ma_comp.quantile(0.55))), 0.20)
    )
    if chart_disp.notna().sum() >= 4:
        compression_score = _clip01(
            0.90 * compression_score +
            0.10 * _less_score(chart_disp.fillna(chart_disp.median()), float(chart_disp.quantile(0.55)), 0.20)
        )
    pressure_score = _clip01(
        0.18 * _greater_score(mom_3m, max(0.0, float(mom_3m.quantile(0.52))), 0.10) +
        0.15 * _greater_score(mom_6m, max(0.0, float(mom_6m.quantile(0.52))), 0.16) +
        0.13 * _greater_score(idio_3m, max(0.0, float(idio_3m.quantile(0.52))), 0.07) +
        0.12 * _greater_score(idio_6m, max(0.0, float(idio_6m.quantile(0.52))), 0.10) +
        0.12 * _greater_score(trend_q, float(max(0.35, trend_q.quantile(0.50))), 0.18) +
        0.10 * _greater_score(prox_52w, max(0.62, float(prox_52w.quantile(0.45))), 0.15) +
        0.10 * _greater_score(trigger_pers, float(max(0.50, trigger_pers.quantile(0.50))), 0.18) +
        0.10 * _greater_score(above20_frac, float(max(0.55, above20_frac.quantile(0.50))), 0.16)
    )
    pre_chart_score = _pd.Series(0.5, index=df.index, dtype=float)
    if chart_pat.notna().sum() >= 4:
        pre_chart_score = _clip01(
            0.30 * _rank01(chart_pat.fillna(chart_pat.median())) +
            0.25 * _rank01(chart_mgn.fillna(chart_mgn.median())) +
            0.20 * _rank01(chart_agr.fillna(chart_agr.median())) +
            0.15 * _less_score(chart_nov.fillna(chart_nov.median()), float(chart_nov.quantile(0.55)), 0.20) +
            0.10 * _less_score(chart_disp.fillna(chart_disp.median()), float(chart_disp.quantile(0.55)), 0.20)
        )

    breakout_readiness = _clip01(
        0.22 * base_rank +
        0.18 * pressure_score +
        0.18 * compression_score +
        0.14 * alpha_rank +
        0.10 * risk_quality +
        0.10 * liq_rank +
        0.08 * pre_chart_score
    )
    pre_breakout_score = (100.0 * breakout_readiness).clip(lower=0.0, upper=100.0)

    early_cut = float(max(70.0, early_breakout_score.quantile(0.82)))
    pre_cut   = float(max(67.0, pre_breakout_score.quantile(0.80)))

    bo_mask = (
        (early_breakout_score >= early_cut) &
        (trend_20 > 0) &
        (trend_50 > -0.005) &
        (mom_1m > 0) &
        (mom_3m > 0) &
        (vol_surge >= 1.0) &
        (prox_52w >= 0.68) &
        (rsi.between(50, 78)) &
        (trigger_pers >= 0.52) &
        (risk_quality >= 0.35)
    )
    if not bool(bo_mask.any()) and len(df) >= 8:
        bo_mask = (
            (early_breakout_score >= max(68.0, float(early_breakout_score.quantile(0.90)))) &
            (trend_20 > -0.002) &
            (mom_3m > 0) &
            (prox_52w >= 0.64) &
            (trigger_pers >= 0.48)
        )

    pb_mask = (
        (pre_breakout_score >= pre_cut) &
        (compression_score >= 0.45) &
        (pressure_score >= 0.40) &
        (mom_3m > 0) &
        (mom_6m > 0) &
        (idio_3m > -0.02) &
        (trend_q >= 0.25) &
        (prox_52w >= 0.55) &
        (rsi.between(42, 66)) &
        (range_contr > -0.05) &
        ~bo_mask
    )
    if not bool(pb_mask.any()) and len(df) >= 8:
        pb_mask = (
            (pre_breakout_score >= max(65.0, float(pre_breakout_score.quantile(0.88)))) &
            (compression_score >= 0.38) &
            (mom_6m > 0) &
            (prox_52w >= 0.52) &
            ~bo_mask
        )

    def _build_df(mask, label, score_s, setup_s, trigger_s):
        if not bool(mask.any()):
            return _pd.DataFrame()
        sub = df[mask].copy()
        rows = []
        for t, row in sub.iterrows():
            sector = (sectors or {}).get(t, row.get("sector", "N/A"))
            _rsi = row.get("rsi", float("nan"))
            # AUDIT-FIX (defect #12): the prior `float(row.get("vol_surge", 1) or 1)` converted
            # a legitimate 0.0 vol_surge to 1.0 (truthy-or fallback). Use explicit None/NaN check.
            _vol_val = row.get("vol_surge")
            _vol = float(_vol_val) if (_vol_val is not None and not _pd.isna(_vol_val)) else float("nan")
            _adv_val = row.get("adv20")
            _adv = float(_adv_val) if (_adv_val is not None and not _pd.isna(_adv_val)) else 0.0
            # L4-fix: `x or float("nan")` converts legitimate 0.0 to NaN — use explicit None/NaN check.
            _val = row.get("ann_vol")
            _ann = float(_val) if (_val is not None and not pd.isna(_val)) else float("nan")
            _val = row.get("beta")
            _beta = float(_val) if (_val is not None and not pd.isna(_val)) else float("nan")
            _val = row.get("alpha_score")
            _alpha = float(_val) if (_val is not None and not pd.isna(_val)) else float("nan")
            _val = row.get("drawdown")
            _dd = float(_val) if (_val is not None and not pd.isna(_val)) else float("nan")
            _val = row.get("risk_score")
            _risk = float(_val) if (_val is not None and not pd.isna(_val)) else float("nan")
            _val = row.get("chart_pattern_cohesion")
            _chart_pat = float(_val) if (_val is not None and not pd.isna(_val)) else float("nan")
            _val = row.get("chart_pattern_margin")
            _chart_mgn = float(_val) if (_val is not None and not pd.isna(_val)) else float("nan")
            _val = row.get("chart_cluster_agreement")
            _chart_agr = float(_val) if (_val is not None and not pd.isna(_val)) else float("nan")
            _val = row.get("range_contraction")
            _rngc = float(_val) if (_val is not None and not pd.isna(_val)) else float("nan")
            _val = row.get("volume_dryup")
            _dry = float(_val) if (_val is not None and not pd.isna(_val)) else float("nan")
            _val = row.get("price_above_20d_frac")
            _ab20 = float(_val) if (_val is not None and not pd.isna(_val)) else float("nan")
            _val = row.get("price_above_50d_frac")
            _ab50 = float(_val) if (_val is not None and not pd.isna(_val)) else float("nan")
            _val = row.get("up_day_frac_21")
            _upf = float(_val) if (_val is not None and not pd.isna(_val)) else float("nan")
            _val = row.get("ma_compression")
            _mac = float(_val) if (_val is not None and not pd.isna(_val)) else float("nan")
            _val = row.get("breakout_distance_20d")
            _bk20 = float(_val) if (_val is not None and not pd.isna(_val)) else float("nan")
            _val = row.get("trigger_persistence")
            _tp = float(_val) if (_val is not None and not pd.isna(_val)) else float("nan")
            _score = float(score_s.loc[t]) if t in score_s.index else float("nan")
            _setup = float(setup_s.loc[t]) if t in setup_s.index else float("nan")
            _trigger = float(trigger_s.loc[t]) if t in trigger_s.index else float("nan")
            _comp = float(compression_score.loc[t]) if t in compression_score.index else float("nan")
            _press = float(pressure_score.loc[t]) if t in pressure_score.index else float("nan")
            _riskq = float(risk_quality.loc[t]) if t in risk_quality.index else float("nan")
            _liq = float(liq_rank.loc[t]) if t in liq_rank.index else float("nan")
            _rs = float(rs_rank.loc[t]) if t in rs_rank.index else float("nan")
            _trigger_state = (
                "Confirmed" if label.startswith("🚀") and _trigger >= 0.65 else
                "Expanding" if label.startswith("🚀") else
                "Coiled" if _comp >= 0.60 else
                "Tightening"
            )
            rows.append({
                "Ticker":         t,
                "Sector":         sector,
                "Signal":         label,
                "TriggerState":   _trigger_state,
                "BreakoutScore":  round(_score, 2),
                "SetupScore":     round(_setup * 100.0, 2) if _pd.notna(_setup) else float("nan"),
                "TriggerScore":   round(_trigger * 100.0, 2) if _pd.notna(_trigger) else float("nan"),
                "CompressionScore": round(_comp * 100.0, 2) if _pd.notna(_comp) else float("nan"),
                "PressureScore":  round(_press * 100.0, 2) if _pd.notna(_press) else float("nan"),
                "RSScore":        round(_rs * 100.0, 2) if _pd.notna(_rs) else float("nan"),
                "RiskQuality":    round(_riskq * 100.0, 2) if _pd.notna(_riskq) else float("nan"),
                "LiquidityScore": round(_liq * 100.0, 2) if _pd.notna(_liq) else float("nan"),
                "AlphaScore":     round(_alpha, 3) if _pd.notna(_alpha) else float("nan"),
                "RSI":            round(float(_rsi), 1) if _pd.notna(_rsi) else float("nan"),
                # AUDIT-FIX (defect #12): replace `float(row.get("mom_1m", 0) or 0)` truthy-or fallbacks
                # with explicit None/NaN checks so that a legitimate 0.0 momentum is exported as 0.0,
                # not silently substituted with the or-fallback's default.
                "Mom1M %":        (lambda _v: round(float(_v) * 100, 2) if _v is not None and not _pd.isna(_v) else float("nan"))(row.get("mom_1m")),
                "Mom3M %":        (lambda _v: round(float(_v) * 100, 2) if _v is not None and not _pd.isna(_v) else float("nan"))(row.get("mom_3m")),
                "Mom6M %":        (lambda _v: round(float(_v) * 100, 2) if _v is not None and not _pd.isna(_v) else float("nan"))(row.get("mom_6m")),
                "Mom12_1 %":      (lambda _v: round(float(_v) * 100, 2) if _v is not None and not _pd.isna(_v) else float("nan"))(row.get("mom_12_1")),
                "Trend20":        (lambda _v: round(float(_v) * 100, 2) if _v is not None and not _pd.isna(_v) else float("nan"))(row.get("trend_20")),
                "Trend50":        (lambda _v: round(float(_v) * 100, 2) if _v is not None and not _pd.isna(_v) else float("nan"))(row.get("trend_50")),
                # AUDIT-FIX (defect #12): the prior `float(... or float('nan'))` truthy-or fallback
                # converted a legitimate 0.0 trend_quality to NaN. Use explicit None/NaN check.
                "TrendQuality":   (lambda _v: round(float(_v), 3) if _v is not None and not _pd.isna(_v) else float("nan"))(row.get("trend_quality")),
                "VolSurge":       round(_vol, 2),
                "RangeContraction": round(_rngc, 3) if _pd.notna(_rngc) else float("nan"),
                "VolumeDryup":    round(_dry, 3) if _pd.notna(_dry) else float("nan"),
                "MACompression":  round(_mac, 3) if _pd.notna(_mac) else float("nan"),
                "TriggerPersistence": round(_tp * 100.0, 1) if _pd.notna(_tp) else float("nan"),
                "Above20D %":     round(_ab20 * 100.0, 1) if _pd.notna(_ab20) else float("nan"),
                "Above50D %":     round(_ab50 * 100.0, 1) if _pd.notna(_ab50) else float("nan"),
                "UpDay21 %":      round(_upf * 100.0, 1) if _pd.notna(_upf) else float("nan"),
                "Breakout20D %":  round(_bk20 * 100.0, 2) if _pd.notna(_bk20) else float("nan"),
                # AUDIT-FIX (defect #12): the prior `float(... or float('nan'))` truthy-or fallback
                # converted a legitimate 0.0 proximity_52w to NaN. Use explicit None/NaN check.
                "Prox52W %":      (lambda _v: round(float(_v) * 100, 1) if _v is not None and not _pd.isna(_v) else float("nan"))(row.get("proximity_52w")),
                # AUDIT-FIX (defect #12): same truthy-or fallback bug class as the momentum fields above.
                "IdioMom3M %":    (lambda _v: round(float(_v) * 100, 2) if _v is not None and not _pd.isna(_v) else float("nan"))(row.get("idio_mom_3m")),
                "IdioMom6M %":    (lambda _v: round(float(_v) * 100, 2) if _v is not None and not _pd.isna(_v) else float("nan"))(row.get("idio_mom_6m")),
                "SectorRS1M %":   (lambda _v: round(float(_v) * 100, 2) if _v is not None and not _pd.isna(_v) else float("nan"))(row.get("sector_rel_mom_1m")),
                "SectorRS6M %":   (lambda _v: round(float(_v) * 100, 2) if _v is not None and not _pd.isna(_v) else float("nan"))(row.get("sector_rel_mom_6m")),
                "AnnVol %":       round(_ann * 100, 1) if _pd.notna(_ann) else float("nan"),
                "Drawdown %":     round(_dd * 100, 1) if _pd.notna(_dd) else float("nan"),
                "Beta":           round(_beta, 2) if _pd.notna(_beta) else float("nan"),
                "RiskScore":      round(_risk, 3) if _pd.notna(_risk) else float("nan"),
                "ADV20 Cr":       round(_adv / 1e7, 2),  # Convert to Crores
                "ChartPattern":   round(_chart_pat, 3) if _pd.notna(_chart_pat) else float("nan"),
                "ChartMargin":    round(_chart_mgn, 3) if _pd.notna(_chart_mgn) else float("nan"),
                "ChartAgreement": round(_chart_agr, 3) if _pd.notna(_chart_agr) else float("nan"),
            })
        result = _pd.DataFrame(rows).sort_values(
            ["BreakoutScore", "SetupScore", "TriggerScore", "AlphaScore"],
            ascending=False
        ).reset_index(drop=True)
        return result

    breakout_df = _build_df(
        bo_mask,
        "🚀 Early Breakout",
        early_breakout_score,
        0.42 * rs_rank + 0.26 * alpha_rank + 0.18 * risk_quality + 0.14 * liq_rank,
        0.34 * trend_stack + 0.28 * impulse_score + 0.24 * volume_confirm + 0.14 * chart_breakout,
    )
    prebreakout_df = _build_df(
        pb_mask,
        "🔍 Pre-Breakout",
        pre_breakout_score,
        0.42 * compression_score + 0.34 * pressure_score + 0.14 * base_rank + 0.10 * pre_chart_score,
        0.32 * alpha_rank + 0.26 * trigger_rank + 0.22 * risk_quality + 0.20 * liq_rank,
    )
    return breakout_df, prebreakout_df


# TECH-DEBT M-02: This function is ~40,600 lines and should be decomposed into
#   _stage_download(), _stage_prescreen(), _stage_signal(), _stage_optimize(),
#   _stage_backtest(), _stage_export() — each independently testable.


# ────────────────────────────────────────────────────────────────────
# CLASS: AuditLogger
# ────────────────────────────────────────────────────────────────────
class AuditLogger:
    """Append-only SQLite audit trail. Every run, order, and param change is
    logged with timestamp, event type, entity, old/new values, and a host hash.
    This satisfies the basic audit requirement for a single-user institutional
    research system."""

    _DB = SQLITE_DB_PATH.parent / "audit_trail.db"

    @classmethod
    def init(cls):
        try:
            import sqlite3
            c = sqlite3.connect(str(cls._DB))
            try:
                c.execute("""CREATE TABLE IF NOT EXISTS audit_log (
                    id         INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts         TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    action     TEXT NOT NULL,
                    entity     TEXT DEFAULT '',
                    old_val    TEXT DEFAULT '',
                    new_val    TEXT DEFAULT '',
                    meta       TEXT DEFAULT '{}',
                    host_hash  TEXT DEFAULT ''
                )""")
                c.commit()
            finally:
                c.close()
        except Exception as _e_:
            ExceptionLogger.swallow(_e_, context="silent_catch")

    @classmethod
    def log(cls, event_type: str, action: str, entity: str = '',
            old_val: str = '', new_val: str = '', meta: dict = None):
        try:
            import sqlite3, json, hashlib, socket
            host = hashlib.md5(socket.gethostname().encode()).hexdigest()[:8]
            c = sqlite3.connect(str(cls._DB))
            try:
                c.execute(
                    "INSERT INTO audit_log(ts,event_type,action,entity,old_val,new_val,meta,host_hash)"
                    " VALUES(?,?,?,?,?,?,?,?)",
                    (datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f'),
                     event_type, action, str(entity)[:200],
                     str(old_val)[:500], str(new_val)[:500],
                     json.dumps(meta or {}), host)
                )
                c.commit()
            finally:
                c.close()
        except Exception as _e_:
            ExceptionLogger.swallow(_e_, context="silent_catch")

    @classmethod
    def load_recent(cls, limit: int = 300):
        try:
            import sqlite3, json
            if not cls._DB.exists():
                return []
            c = sqlite3.connect(str(cls._DB))
            c.row_factory = sqlite3.Row
            try:
                rows = c.execute(
                    "SELECT ts,event_type,action,entity,old_val,new_val,meta"
                    " FROM audit_log ORDER BY id DESC LIMIT ?", (limit,)
                ).fetchall()
                return [dict(r) for r in rows]
            finally:
                c.close()
        except Exception as _e:
            import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception in %s", "Exception", exc_info=True)  # noqa: E501
            return []


AuditLogger.init()


# ── 2. Data Validator ────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# CLASS: DataValidator
# ────────────────────────────────────────────────────────────────────
class DataValidator:
    """Validate OHLCV quality per ticker. Detects: zero/negative prices,
    single-day spikes >40%, duplicate dates, stale data >5 trading days,
    and low completeness (<70% of expected bars)."""

    SPIKE_THRESHOLD  = 0.40   # 40% single-day move
    STALE_DAYS       = 5      # market days since last bar
    MIN_COMPLETENESS = 0.70   # fraction of expected bars

    @classmethod
    def validate_series(cls, close: 'pd.Series', ticker: str) -> dict:
        issues = []
        if close is None or len(close) == 0:
            return dict(ticker=ticker, valid=False, score=0,
                        issues=['NO_DATA'], completeness=0.0, last_date='—', stale_days=999)
        import numpy as np
        rets = close.pct_change().dropna()
        spikes = int((rets.abs() > cls.SPIKE_THRESHOLD).sum())
        if spikes:
            issues.append(f'PRICE_SPIKE ×{spikes}')
        zeros = int((close <= 0).sum())
        if zeros:
            issues.append(f'ZERO_PRICE ×{zeros}')
        dups = int(close.index.duplicated().sum())
        if dups:
            issues.append(f'DUPLICATE_DATES ×{dups}')
        last_dt = close.index[-1]
        stale = (pd.Timestamp.now(tz=None) - last_dt.replace(tzinfo=None)).days
        if stale > cls.STALE_DAYS:
            issues.append(f'STALE +{stale}d')
        completeness = min(1.0, len(close) / TRADING_DAYS_PER_YEAR)  # DIV001: guard divisor before use
        if completeness < cls.MIN_COMPLETENESS:
            issues.append(f'INCOMPLETE {completeness:.0%}')
        score = max(0, 100 - spikes * 10 - zeros * 5 - (max(0, stale - 2)) * 3
                    - (1 - completeness) * 30)
        return dict(ticker=ticker,
                    valid=spikes < 3 and zeros == 0 and completeness >= cls.MIN_COMPLETENESS,
                    score=int(score), issues=issues or ['OK'],
                    completeness=round(completeness, 3),
                    last_date=str(last_dt.date()) if hasattr(last_dt, 'date') else str(last_dt),
                    stale_days=stale)

    @classmethod
    def validate_portfolio(cls, portfolio_df: 'pd.DataFrame',
                           signal_df: 'pd.DataFrame') -> 'pd.DataFrame':
        rows = []
        if portfolio_df is None or portfolio_df.empty:
            return pd.DataFrame()
        for _, row in portfolio_df.iterrows():
            t = str(row.get('Ticker', row.get('ticker', '')))
            if signal_df is not None and t in signal_df.index:
                sig = signal_df.loc[t]
                # Reconstruct a thin close series from cumret if available
                close = sig.get('cumret') if hasattr(sig, 'get') else None
            else:
                close = None
            if close is None or not hasattr(close, '__len__') or len(close) < 5:
                rows.append(dict(ticker=t, valid=True, score=80,
                                 issues='No raw series — skipped',
                                 completeness='—', last_date='—', stale_days='—'))
            else:
                r = cls.validate_series(close, t)
                rows.append(dict(ticker=r['ticker'], valid=r['valid'],
                                 score=r['score'],
                                 issues='; '.join(r['issues']),
                                 completeness=f"{r['completeness']:.0%}",
                                 last_date=r['last_date'],
                                 stale_days=r['stale_days']))
        return pd.DataFrame(rows)


# ── 3. Compliance Engine ─────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# CLASS: ComplianceEngine
# ────────────────────────────────────────────────────────────────────
class ComplianceEngine:
    """Pre-trade compliance: position limits, sector concentration,
    liquidity (days-to-exit), AUM-scaled checks, and banned securities.

    Severity levels:
      BLOCK  — must fix before order placement
      BREACH — rule violated, requires PM override
      WARN   — informational threshold crossed
    """

    def __init__(self, cfg: dict):
        self.aum              = float(cfg.get('AUM_INR', 10_000_000))
        # Sync max_position with profile MAX_WEIGHT / MAX_POSITION_PCT if explicitly provided to prevent false breaches
        _profile_max_pos      = float(cfg.get('MAX_POSITION_PCT', cfg.get('MAX_WEIGHT', 0.10)))
        self.max_position     = float(cfg.get('COMPLIANCE_MAX_POSITION', _profile_max_pos))
        _profile_max_sec      = float(cfg.get('MAX_SECTOR_PCT', cfg.get('MAX_SECTOR_WEIGHT', 0.35)))
        self.max_sector       = float(cfg.get('COMPLIANCE_MAX_SECTOR', _profile_max_sec))
        self.max_liq_days     = float(cfg.get('COMPLIANCE_MAX_LIQ_DAYS',  10.0))
        self.max_beta         = float(cfg.get('COMPLIANCE_MAX_BETA',       1.40))
        self.banned           = set(str(s).strip().upper()
                                    for s in str(cfg.get('COMPLIANCE_BANNED', '')).split(',')
                                    if s.strip())

    def check(self, portfolio_df: 'pd.DataFrame',
              signal_df: 'pd.DataFrame', sector_map: dict) -> list:
        violations = []
        if portfolio_df is None or portfolio_df.empty:
            return violations

        sector_weights: dict = {}
        port_beta = 0.0

        for _, row in portfolio_df.iterrows():
            t = str(row.get('Ticker', row.get('ticker', ''))).upper()
            w = float(row.get('Weight %', row.get('Weight', row.get('weight', 0))) or 0)  # AUDIT-FIX (Round 6, C-P2-1): optimizer portfolio_df column is 'Weight %'
            pos_val = self.aum * w

            # Banned security
            if t in self.banned or t.replace('.NS','') in self.banned:
                violations.append(dict(severity='BLOCK', rule='BANNED_SECURITY',
                    ticker=t, value=f'{w:.2%}', limit='—',
                    message=f'{t} is on the restricted securities list'))

            # Single-position limit (1e-6 tolerance prevents false float precision breaches)
            if w > self.max_position + 1e-6:
                violations.append(dict(severity='BREACH', rule='POSITION_LIMIT',
                    ticker=t, value=f'{w:.2%}', limit=f'{self.max_position:.2%}',
                    message=f'{t}: weight {w:.2%} exceeds {self.max_position:.2%} limit'))

            # Liquidity: AUM × weight / ADV20
            if signal_df is not None and t in signal_df.index:
                adv = float((signal_df.loc[t].get('adv20', signal_df.loc[t].get('advol20', 0))
                              if hasattr(signal_df.loc[t], 'get')
                              else 0) or 0)  # AUDIT-FIX (Round 6, C-P1-2): real column is 'adv20'
                if adv > 0:
                    days = pos_val / adv  # DIV001: guard divisor before use
                    if days > self.max_liq_days:
                        violations.append(dict(severity='WARN', rule='LIQUIDITY',
                            ticker=t, value=f'{days:.1f}d', limit=f'{self.max_liq_days:.0f}d',
                            message=f'{t}: {days:.1f} days to exit at ADV20 (limit {self.max_liq_days:.0f}d)'))
                beta = float((signal_df.loc[t].get('beta')
                               if hasattr(signal_df.loc[t], 'get')
                               else 1.0) or 1.0)
                port_beta += w * beta

            sec = normalize_sector((sector_map or {}).get(t, 'UNKNOWN') if sector_map else 'UNKNOWN')
            sector_weights[sec] = sector_weights.get(sec, 0) + w

        # Sector concentration (1e-6 tolerance prevents false float precision breaches)
        for sec, sw in sector_weights.items():
            if sw > self.max_sector + 1e-6:
                violations.append(dict(severity='BREACH', rule='SECTOR_LIMIT',
                    ticker='PORTFOLIO', value=f'{sw:.2%}', limit=f'{self.max_sector:.2%}',
                    message=f'Sector {sec}: {sw:.2%} exceeds {self.max_sector:.2%} limit'))

        # Portfolio beta
        if port_beta > self.max_beta:
            violations.append(dict(severity='WARN', rule='PORTFOLIO_BETA',
                ticker='PORTFOLIO', value=f'{port_beta:.2f}', limit=f'{self.max_beta:.2f}',
                message=f'Portfolio beta {port_beta:.2f} exceeds limit {self.max_beta:.2f}'))

        return violations


def compute_hurst_exponent(series: pd.Series, min_lag: int = 2, max_lag: int = 20) -> float:
    """
    Computes Hurst Exponent (H) via Rescaled Range (R/S) Analysis.
    H > 0.5 -> Persistent trending regime
    H < 0.5 -> Anti-persistent mean-reverting regime
    H = 0.5 -> Geometric Brownian Motion (random walk)
    """
    vals = series.dropna().values
    if len(vals) < max_lag * 2:
        return 0.50

    lags = range(min_lag, max_lag)
    tau = [float(np.sqrt(np.std(np.subtract(vals[lag:], vals[:-lag])))) for lag in lags]
    
    if any(t <= 1e-9 for t in tau):
        return 0.50

    # Fit log(tau) vs log(lags)
    poly = np.polyfit(np.log(lags), np.log(tau), 1)
    h_val = float(poly[0] * 2.0)
    return round(min(max(h_val, 0.05), 0.95), 4)


def compute_absorption_ratio(returns_df: pd.DataFrame, top_k: int = 3) -> float:
    """
    Computes Kritzman et al. (2010) Absorption Ratio measuring systemic fragility.
    AR = sum(Var(PC_1..k)) / sum(Var(Asset_1..N))
    AR > 80% -> High systemic fragility / lockstep market crash risk.
    """
    if returns_df is None or returns_df.empty or returns_df.shape[1] < top_k:
        return 0.0

    clean_returns = returns_df.dropna(how="all").fillna(0.0)
    if clean_returns.shape[0] < 10:
        return 0.0

    cov = clean_returns.cov().values
    if cov.size == 0 or np.isnan(cov).any():
        return 0.0

    val, _ = np.linalg.eigh(cov)
    val = np.sort(val)[::-1]  # Sort descending
    
    total_var = float(np.sum(val))
    if total_var <= 1e-9:
        return 0.0

    top_var = float(np.sum(val[:top_k]))
    ar_val = top_var / total_var
    return round(min(max(ar_val, 0.0), 1.0), 4)


# ── 4. Circuit Breaker ────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# CLASS: CircuitBreaker
# ────────────────────────────────────────────────────────────────────
class CircuitBreaker:
    """Auto-halt automation when any of three trip conditions are met:
      • Single-day portfolio loss > daily_dd_limit
      • Peak-to-trough drawdown > portfolio_dd_limit
      • N consecutive days of negative returns
    State is read from the SQLite run history so it persists across restarts."""

    def __init__(self, cfg: dict):
        self.daily_dd   = float(cfg.get('CIRCUIT_DAILY_DD',    0.030))
        self.port_dd    = float(cfg.get('CIRCUIT_PORT_DD',     0.150))
        self.consec_loss= int(cfg.get('CIRCUIT_CONSEC_LOSS',   5))

    def check_history(self) -> tuple:
        """Returns (tripped: bool, reason: str) from last N run records."""
        try:
            from optimizer import sqlite_load_history
            rows = (_DB_STORE.load_history(limit=max(self.consec_loss + 2, 20))
                if _DB_STORE is not None else
                sqlite_load_history(limit=max(self.consec_loss + 2, 20)))
            if not rows:
                return False, ''
            ann_rets = []
            for r in rows:
                try:
                    v = r.get('Ann Ret', '')
                    if v and v not in ('', '—', 'None'):
                        ann_rets.append(float(str(v).replace('%','').strip()) / 100)
                except Exception as _exc_p2a_:
                    ExceptionLogger.swallow(_exc_p2a_, context='L10232')
            if not ann_rets:
                return False, ''
            # Approximate daily from ann (÷252)
            daily = [r / 252 for r in ann_rets]
            if daily[0] < -self.daily_dd:
                return True, (f'Last run daily proxy {daily[0]:.2%} < '
                               f'-{self.daily_dd:.2%} circuit limit')
            cum = 1.0
            peak = 1.0
            for d in reversed(daily):
                cum *= (1 + d)
                peak = max(peak, cum)
            dd = cum / (peak + 1e-9) - 1
            if dd < -self.port_dd:
                return True, (f'Estimated drawdown {dd:.2%} < '
                               f'-{self.port_dd:.2%} circuit limit')
            if len(daily) >= self.consec_loss and all(d < 0 for d in daily[:self.consec_loss]):
                return True, f'{self.consec_loss} consecutive negative runs triggered circuit breaker'
            return False, ''
        except Exception as _e:
            return False, ''


# ── 5. Execution Cost Model ───────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# CLASS: ExecutionCostModel
# ────────────────────────────────────────────────────────────────────
class ExecutionCostModel:
    """Almgren-Chriss square-root market impact model.
    Estimates bid-ask spread, market impact, and timing risk for each
    position given AUM size and ADV20 liquidity data.

    All figures in basis points (bps) and INR.
    """

    @staticmethod
    def estimate_position(weight: float, aum: float, adv20: float,
                          side: str = 'BUY') -> dict:
        pos_val = abs(weight * aum)
        if pos_val == 0:
            return dict(pos_val=0, participation=0, days=0,
                        spread_bps=0, impact_bps=0, timing_bps=0,
                        total_bps=0, total_inr=0)
        participation = pos_val / max(adv20, 1)
        spread_bps  = 8 + 12 * min(participation, 1.0)          # 8–20 bps
        impact_bps  = 22 * (participation ** 0.5)                # sqrt model
        n_days      = max(1.0, participation / 0.10)             # 10% daily cap
        timing_bps  = 14 * (n_days ** 0.5)                       # uncertainty
        total_bps   = spread_bps + impact_bps + timing_bps
        total_inr   = pos_val * total_bps / 10_000
        return dict(pos_val=round(pos_val), participation=round(participation, 4),
                    days=round(n_days, 1), spread_bps=round(spread_bps, 1),
                    impact_bps=round(impact_bps, 1), timing_bps=round(timing_bps, 1),
                    total_bps=round(total_bps, 1), total_inr=round(total_inr))

    @classmethod
    def estimate_portfolio(cls, portfolio_df: 'pd.DataFrame',
                           signal_df: 'pd.DataFrame', aum: float) -> 'pd.DataFrame':
        rows = []
        if portfolio_df is None or portfolio_df.empty:
            return pd.DataFrame()
        total_cost = 0.0
        for _, row in portfolio_df.iterrows():
            t = str(row.get('Ticker', row.get('ticker', '')))
            w = float(row.get('Weight %', row.get('Weight', row.get('weight', 0))) or 0)  # AUDIT-FIX (Round 6, C-P2-1): optimizer portfolio_df column is 'Weight %'
            adv = 0.0
            if signal_df is not None and t in signal_df.index:
                sig = signal_df.loc[t]
                adv = float((sig.get('adv20', sig.get('advol20', 0)) if hasattr(sig,'get') else 0) or 0)  # AUDIT-FIX (Round 6, C-P1-2)
            e = cls.estimate_position(w, aum, adv)
            total_cost += e['total_inr']
            rows.append(dict(
                Ticker=t,
                Weight=f'{w:.2%}',
                **{f'AUM ₹ (L)': f'{e["pos_val"]/1e5:.1f}L',
                   'ADV20 ₹ (Cr)': f'{adv/1e7:.1f}Cr' if adv else '—',
                   'Participation': f'{e["participation"]:.2%}',
                   'Days to Execute': str(e['days']),
                   'Spread (bps)': str(e['spread_bps']),
                   'Impact (bps)': str(e['impact_bps']),
                   'Timing (bps)': str(e['timing_bps']),
                   'Total (bps)': str(e['total_bps']),
                   'Est. Cost ₹': f'₹{e["total_inr"]:,.0f}'},
            ))
        # Totals row
        rows.append(dict(Ticker='── TOTAL ──', Weight='',
                         **{'AUM ₹ (L)': '', 'ADV20 ₹ (Cr)': '',
                            'Participation': '', 'Days to Execute': '',
                            'Spread (bps)': '', 'Impact (bps)': '',
                            'Timing (bps)': '',
                            'Total (bps)': f'Avg {sum(float(r["Total (bps)"]) for r in rows if r["Total (bps)"]) / max(len(rows),1):.1f}',
                            'Est. Cost ₹': f'₹{total_cost:,.0f}'}))
        return pd.DataFrame(rows)


# ── 6. Stress Test Engine ─────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# CLASS: StressTestEngine
# ────────────────────────────────────────────────────────────────────
class StressTestEngine:
    """Apply historical Indian market crisis shocks to the current portfolio.
    Uses portfolio beta from signal_df to scale the index move to a
    portfolio loss estimate. Also runs two parametric scenarios."""

    SCENARIOS = [
        ('COVID Crash (Feb–Mar 2020)',    -0.382, 'Extreme'),
        ('IL&FS Crisis (Sep–Oct 2018)',   -0.158, 'Severe'),
        ('Demonetisation (Nov 2016)',     -0.072, 'Moderate'),
        ('GFC Bottom (Jan–Mar 2009)',     -0.211, 'Extreme'),
        ('Taper Tantrum (May–Aug 2013)', -0.115, 'Severe'),
        ('Budget Shock (Jul 2024)',       -0.068, 'Moderate'),
        ('+2σ VIX Spike (Parametric)',   -0.080, 'Severe'),
        ('Beta 1.5× Shock (Parametric)', -0.120, 'Extreme'),
    ]

    @classmethod
    def run(cls, portfolio_df: 'pd.DataFrame', signal_df: 'pd.DataFrame',
            aum: float) -> 'pd.DataFrame':
        if portfolio_df is None or portfolio_df.empty:
            return pd.DataFrame()
        # Estimate weighted portfolio beta
        port_beta = 1.0
        if signal_df is not None and not portfolio_df.empty:
            betas, weights = [], []
            for _, row in portfolio_df.iterrows():
                t = str(row.get('Ticker', row.get('ticker', '')))
                w = float(row.get('Weight %', row.get('Weight', row.get('weight', 0))) or 0)  # AUDIT-FIX (Round 6, C-P2-1): optimizer portfolio_df column is 'Weight %'
                if t in signal_df.index:
                    b = float((signal_df.loc[t].get('beta')
                                if hasattr(signal_df.loc[t], 'get') else 1.0) or 1.0)
                    betas.append(b); weights.append(w)
            if betas:
                import numpy as np
                tw = sum(weights)
                port_beta = float(np.dot(betas, weights) / tw) if tw > 0 else 1.0  # DIV001: guard divisor before use

        rows = []
        for name, mkt_shock, severity in cls.SCENARIOS:
            port_loss_pct = mkt_shock * port_beta
            port_loss_inr = aum * port_loss_pct
            rows.append(dict(
                Scenario=name,
                **{'Market Shock': f'{mkt_shock:.1%}',
                   'Portfolio β': f'{port_beta:.2f}',
                   'Est. Port Loss %': f'{port_loss_pct:.1%}',
                   'Est. INR Loss': f'₹{abs(port_loss_inr):,.0f}',
                   'Est. INR Loss (L)': f'₹{abs(port_loss_inr)/1e5:.1f}L',
                   'Severity': severity}
            ))
        return pd.DataFrame(rows)

# ⚙  SETTINGS DIALOG — persistent credentials (Telegram / Kite / Automation)
# Saved to ~/.quantum_annealer_pro_v17/credentials.json — never re-enter tokens
# ═══════════════════════════════════════════════════════════════════════════════


# ── Styled QMessageBox Helpers ──────────────────────────────────────────────────

def is_app_dark_mode() -> bool:
    """Detect if the application is currently running in Dark Mode."""
    try:
        app = QApplication.instance()
    except Exception:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
        app = None
    if not app:
        return True
    ss = app.styleSheet() or ""
    if "#000000" in ss or "DEEP BLACK" in ss:
        return True
    try:
        from PySide6.QtGui import QPalette
    except ImportError:
        try:
            from PyQt5.QtGui import QPalette
        except ImportError:
            import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
            QPalette = None
            
    if QPalette is not None:
        try:
            palette = app.palette()
            bg_color = palette.color(QPalette.Window)
            if bg_color.lightness() < 128:
                return True
        except Exception:
            import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
            pass
    return False

def get_styled_msgbox_qss(dark: bool) -> str:
    """Generate dynamic, robust QSS for QMessageBox to prevent macOS native contrast clashing."""
    if dark:
        bg = "#1c1c1e"
        text = "#f0f0f0"
        info = "#c0c0c0"
        border = "#3a3a3c"
        btn_bg = "#2c2c2e"
        btn_color = "#ffffff"
        btn_border = "#3a3a3c"
        btn_hover_bg = "#3a3a3c"
        btn_hover_border = "#0a84ff"
        btn_default_bg = "#0a84ff"
        btn_default_color = "#ffffff"
    else:
        bg = "#ffffff"
        text = "#1c1c1e"
        info = "#5c5c5e"
        border = "#d1d1d6"
        btn_bg = "#f2f2f7"
        btn_color = "#1c1c1e"
        btn_border = "#d1d1d6"
        btn_hover_bg = "#e5e5ea"
        btn_hover_border = "#007aff"
        btn_default_bg = "#007aff"
        btn_default_color = "#ffffff"

    return f"""
        QMessageBox {{
            background-color: {bg} !important;
            border: 1px solid {border} !important;
            border-radius: 8px !important;
        }}
        QMessageBox QLabel {{
            color: {text} !important;
            background-color: transparent !important;
            font-size: 13px !important;
            font-family: '.AppleSystemUIFont', 'Helvetica Neue', sans-serif !important;
            min-height: 20px !important;
        }}
        QLabel#qt_msgbox_label {{
            color: {text} !important;
            background-color: transparent !important;
            font-size: 13px !important;
            font-family: '.AppleSystemUIFont', 'Helvetica Neue', sans-serif !important;
        }}
        QLabel#qt_msgbox_informativelabel {{
            color: {info} !important;
            background-color: transparent !important;
            font-size: 12px !important;
            font-family: '.AppleSystemUIFont', 'Helvetica Neue', sans-serif !important;
        }}
        QMessageBox QPushButton {{
            background-color: {btn_bg} !important;
            color: {btn_color} !important;
            border: 1px solid {btn_border} !important;
            border-radius: 6px !important;
            padding: 6px 18px !important;
            min-width: 75px !important;
            font-size: 12px !important;
            font-weight: 600 !important;
        }}
        QMessageBox QPushButton:hover {{
            background-color: {btn_hover_bg} !important;
            border-color: {btn_hover_border} !important;
        }}
        QMessageBox QPushButton:default {{
            background-color: {btn_default_bg} !important;
            color: {btn_default_color} !important;
            border: none !important;
        }}
        QTextEdit {{
            background-color: {bg} !important;
            color: {text} !important;
            border: 1px solid {border} !important;
            border-radius: 4px !important;
            font-family: 'Courier New', Courier, monospace !important;
            font-size: 11px !important;
        }}
    """

def _qmessagebox_enum_value(enum_name: str, value_name: str, fallback: int = 0):
    enum_obj = getattr(QMessageBox, enum_name, None)
    if enum_obj is not None and hasattr(enum_obj, value_name):
        return getattr(enum_obj, value_name)
    if hasattr(QMessageBox, value_name):
        return getattr(QMessageBox, value_name)
    return fallback

class _QMessageBoxIconCompat:
    Information = _qmessagebox_enum_value("Icon", "Information", 1)
    Warning = _qmessagebox_enum_value("Icon", "Warning", 2)
    Critical = _qmessagebox_enum_value("Icon", "Critical", 3)

class _QMessageBoxButtonRoleCompat:
    AcceptRole = _qmessagebox_enum_value("ButtonRole", "AcceptRole", 0)

_QMESSAGEBOX_ICON = _QMessageBoxIconCompat
_QMESSAGEBOX_BUTTON_ROLE = _QMessageBoxButtonRoleCompat

def show_styled_message_box(parent, title: str, text: str, icon=_QMESSAGEBOX_ICON.Information, 
                            informative_text: str = None, detailed_text: str = None, 
                            buttons=None, default_button=None):
    """Create, style and execute a QMessageBox perfectly adapted to dark/light theme."""
    msg = QMessageBox(parent)
    msg.setWindowTitle(title)
    msg.setText(text)
    if icon is not None:
        msg.setIcon(icon)
    if informative_text:
        msg.setInformativeText(informative_text)
    if detailed_text:
        msg.setDetailedText(detailed_text)
    
    # Handle custom buttons if any
    if buttons:
        for btn in buttons:
            if isinstance(btn, str):
                msg.addButton(btn, _QMESSAGEBOX_BUTTON_ROLE.AcceptRole)
            else:
                msg.addButton(btn)
    if default_button:
        msg.setDefaultButton(default_button)
        
    dark = is_app_dark_mode()
    msg.setStyleSheet(get_styled_msgbox_qss(dark))
    
    # Block signals of parent to prevent re-entrant events or glitches during modal exec
    if parent:
        parent.blockSignals(True)
    try:
        msg.exec()
    finally:
        if parent:
            parent.blockSignals(False)
            
    return msg.clickedButton()


# ────────────────────────────────────────────────────────────────────
# CLASS: RiskLimitEnforcer
# ────────────────────────────────────────────────────────────────────
class RiskLimitEnforcer:
    def __init__(self, cfg):
        self.max_position = float(cfg.get("RISK_MAX_POSITION", 0.15))
        self.max_sector   = float(cfg.get("RISK_MAX_SECTOR",   0.40))
        self.min_stocks   = int(cfg.get("RISK_MIN_STOCKS",     4))

    def check(self, weights, sectors=None):
        violations = []
        if not weights:
            return ["Basket is empty — run the optimizer first."]
        if len(weights) < self.min_stocks:
            violations.append(
                "Too few stocks: %d < minimum %d" % (len(weights), self.min_stocks))
        for ticker, w in weights.items():
            if w > self.max_position:
                violations.append(
                    "%s: %.1f%% > max %.0f%%" % (ticker, w*100, self.max_position*100))
        total = sum(weights.values())
        if total > 1.01:
            violations.append("Total allocation %.1f%% > 100%%" % (total*100,))
        if sectors:
            from collections import defaultdict
            sec_wts = defaultdict(float)
            for ticker, w in weights.items():
                sec_wts[normalize_sector(sectors.get(ticker, "UNKNOWN"))] += w
            for sec, sw in sec_wts.items():
                if sw > self.max_sector:
                    violations.append(
                        "Sector '%s': %.1f%% > max %.0f%%" % (sec, sw*100, self.max_sector*100))
        return violations

    @staticmethod
    def show_violations_dialog(violations, parent=None):
        msg = QMessageBox(parent)
        msg.setWindowTitle("Risk Limit Violations")
        msg.setIcon(QMessageBox.Warning)
        msg.setText("<b>%d risk limit(s) breached:</b>" % len(violations))
        detail = "\n".join("* " + v for v in violations)
        msg.setDetailedText(detail)
        msg.setInformativeText("Override and proceed, or cancel?")
        override_btn = msg.addButton("Override & Proceed", QMessageBox.AcceptRole)
        cancel_btn   = msg.addButton("Cancel",             QMessageBox.RejectRole)
        msg.setDefaultButton(cancel_btn)
        
        # Proactively style the violations dialog to avoid native clashing
        msg.setStyleSheet(get_styled_msgbox_qss(is_app_dark_mode()))
        
        msg.exec()
        return msg.clickedButton() == override_btn


# ══════════════════════════════════════════════════════════════════════════════
#  PortfolioSnapshotExporter — one-click full-run CSV bundle
# ══════════════════════════════════════════════════════════════════════════════


# ────────────────────────────────────────────────────────────────────
# CLASS: PortfolioSnapshotExporter
# ────────────────────────────────────────────────────────────────────
class PortfolioSnapshotExporter:
    def __init__(self, snapshot_root=None):
        self._root = snapshot_root or (Path.home() / "quantum_snapshots")
        self._root.mkdir(parents=True, exist_ok=True)

    def export(self, payload, cfg, regime_info, log_cb=None):
        import json
        from datetime import datetime as _dt
        ts   = _dt.now().strftime("%Y%m%d_%H%M%S")
        dest = self._root / ("snapshot_" + ts)
        dest.mkdir(parents=True, exist_ok=True)

        def _write_df(name, df):
            if df is not None and hasattr(df, "empty") and not df.empty:
                df.to_csv(dest / name, index=False)  # DIV001: guard divisor before use

        _write_df("portfolio.csv",      payload.get("portfolio_df"))
        _write_df("sector_summary.csv", payload.get("sector_df"))
        _write_df("factor_summary.csv", payload.get("factor_df"))
        _write_df("backtest.csv",       payload.get("backtest_df"))

        oos = payload.get("oos_validation")
        if oos:
            lines = [str(k) + ": " + str(v) for k, v in oos.items()]
            (dest / "oos_validation.txt").write_text("\n".join(lines), encoding="utf-8")

        meta = {
            "timestamp": ts,
            "regime":    regime_info.get("Regime", "Unknown"),
            "vix":       str(payload.get("india_vix", "")),
            "solver":    str(payload.get("solver_source", "SA")),
            "energy":    str(payload.get("energy", "")),
            "n_stocks":  len(payload.get("selected", [])),
        }
        (dest / "run_meta.json").write_text(
            json.dumps(meta, indent=2, default=str), encoding="utf-8")
        if log_cb: log_cb("[Snapshot] Exported to " + str(dest))
        return dest


# ══════════════════════════════════════════════════════════════════════════════
#  StrategyProfileDialog — save / load named optimizer config profiles
# ══════════════════════════════════════════════════════════════════════════════


# ────────────────────────────────────────────────────────────────────
# CLASS: SchedulerDaemon
# ────────────────────────────────────────────────────────────────────
class SchedulerDaemon(QObject):
    """
    Fires a signal at a configured HH:MM each day (or every N minutes).
    Uses a single QTimer(60s) that checks wall-clock time each tick.

    Config keys (in DEFAULT_CFG / collected_cfg):
      SCHEDULER_ENABLED   bool   — master switch
      SCHEDULER_HOUR      int    — hour (IST, 24h)
      SCHEDULER_MINUTE    int    — minute
      SCHEDULER_DAYS      str    — "Mon,Tue,Wed,Thu,Fri" or "Daily"
    """
    triggered = pyqtSignal()   # connect to _on_run_clicked

    _DAY_MAP = {"Mon":0,"Tue":1,"Wed":2,"Thu":3,"Fri":4,"Sat":5,"Sun":6}

    def __init__(self, parent=None):
        super().__init__(parent)
        self._enabled  = False
        self._hour     = 15
        self._minute   = 35
        self._days     = set(range(5))   # Mon-Fri by default
        self._last_fired: str = ""        # "YYYY-MM-DD HH:MM" — prevents double-fire
        self._timer = QTimer(self)
        self._timer.setInterval(60_000)   # tick every 60 s
        self._timer.timeout.connect(self._tick)

    def configure(self, cfg: dict):
        self._enabled = bool(cfg.get("SCHEDULER_ENABLED", cfg.get("USE_APSCHEDULER", False)))
        self._hour    = int(cfg.get("SCHEDULER_HOUR",   15))
        self._minute  = int(cfg.get("SCHEDULER_MINUTE", 35))
        days_str = str(cfg.get("SCHEDULER_DAYS", "Mon,Tue,Wed,Thu,Fri"))
        if days_str.strip().lower() == "daily":
            self._days = set(range(7))
        else:
            self._days = {self._DAY_MAP[d.strip()] for d in days_str.split(",")
                          if d.strip() in self._DAY_MAP}
        if self._enabled:
            self._timer.start()
        else:
            self._timer.stop()

    def _tick(self):
        if not self._enabled: return
        now = datetime.now()
        if now.weekday() not in self._days: return
        if now.hour != self._hour or now.minute != self._minute: return
        key = now.strftime("%Y-%m-%d %H:%M")
        if key == self._last_fired: return
        self._last_fired = key
        self.triggered.emit()

    def status_text(self) -> str:
        if not self._enabled: return "Scheduler: OFF"
        days = ["Mo","Tu","We","Th","Fr","Sa","Su"]
        day_labels = ",".join(days[d] for d in sorted(self._days))
        return "Scheduler: %02d:%02d  [%s]" % (self._hour, self._minute, day_labels)


# ══════════════════════════════════════════════════════════════════════════════
#  TelegramCommandListener — inbound bot commands
# ══════════════════════════════════════════════════════════════════════════════


# ────────────────────────────────────────────────────────────────────
# CLASS: TelegramCommandListener
# ────────────────────────────────────────────────────────────────────
class TelegramCommandListener(QObject):
    """
    Polls Telegram getUpdates every 30 s (only when TELEGRAM_ENABLED).
    Supported commands:
      /run        — trigger optimizer
      /status     — reply with last run summary
      /snapshot   — export full snapshot bundle
      /stop       — stop polling
    """
    run_requested      = pyqtSignal()
    snapshot_requested = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._token     = ""
        self._chat_id   = ""
        self._enabled   = False
        self._offset    = 0
        self._timer     = QTimer(self)
        self._timer.setInterval(30_000)
        self._timer.timeout.connect(self._poll)
        self._last_status: str = "No runs yet."

    def configure(self, cfg: dict):
        self._enabled  = bool(cfg.get("TELEGRAM_ENABLED", False))
        self._token    = str(cfg.get("TELEGRAM_BOT_TOKEN",  "")).strip()
        self._chat_id  = str(cfg.get("TELEGRAM_CHAT_ID",    "")).strip()
        if self._enabled and self._token and self._chat_id:
            self._timer.start()
        else:
            self._timer.stop()

    def set_last_status(self, text: str):
        self._last_status = text[:400]

    def _send(self, text: str):
        if not (self._token and self._chat_id): return
        try:
            import requests as _req
            _req.post(
                "https://api.telegram.org/bot%s/sendMessage" % self._token,
                json={"chat_id": self._chat_id, "text": text},
                timeout=8)
        except Exception as _e:
            archlog.error('Exception detail', exc_info=True)  # LOG003 was traceback.print_exc()
            pass  # _arch_log removed (LOG003)

    def _poll(self):
        if not (self._enabled and self._token and self._chat_id): return
        try:
            import requests as _req
            resp = _req.get(
                "https://api.telegram.org/bot%s/getUpdates" % self._token,
                params={"offset": self._offset, "timeout": 5, "limit": 10},
                timeout=10)
            if not resp.ok: return
            updates = resp.json().get("result", [])
            for upd in updates:
                self._offset = upd["update_id"] + 1
                msg  = upd.get("message") or upd.get("edited_message", {})
                text = (msg.get("text") or "").strip().lower()
                if text == "/run":
                    self._send("Starting optimizer run...")
                    self.run_requested.emit()
                elif text == "/status":
                    self._send(self._last_status)
                elif text == "/snapshot":
                    self._send("Exporting snapshot...")
                    self.snapshot_requested.emit()
                elif text == "/stop":
                    self._send("Listener stopped.")
                    self._timer.stop()
                    self._enabled = False
        except Exception as _e:
            archlog.error('Exception detail', exc_info=True)  # LOG003 was traceback.print_exc()
            pass  # _arch_log removed (LOG003)


# ══ BacktestComparisonPanel (TAB 27) ══════════════════════════════════════════
# DEPRECATED R-06: merge into BacktestComparisonPanel then delete this class


# CLASS: SchedulerDaemon_B (DEPRECATED R-06: alias to SchedulerDaemon)
SchedulerDaemon_B = SchedulerDaemon

# CLASS: TelegramCommandListener_B (DEPRECATED R-06: alias to TelegramCommandListener)
TelegramCommandListener_B = TelegramCommandListener


# ══ PortfolioHeatmapTab (TAB 28) ══════════════════════════════════════════════


# ────────────────────────────────────────────────────────────────────
# CLASS: DrawdownMonitor
# ────────────────────────────────────────────────────────────────────
class DrawdownMonitor(QObject):
    alert_triggered = pyqtSignal(float)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._peak=0.0; self._threshold=5.0

    def configure(self, cfg):
        self._threshold = float(cfg.get("DRAWDOWN_ALERT_PCT",5.0))

    def update(self, portfolio_value, log_cb=None):
        if portfolio_value<=0: return
        if portfolio_value>self._peak: self._peak=portfolio_value
        if self._peak==0: return
        dd=(self._peak-portfolio_value)/self._peak*100
        if dd>=self._threshold:
            key="dd_%d" % int(dd/self._threshold)
            if _ALERT_THROTTLE.should_send_and_record(key, cooldown=1800):
                self.alert_triggered.emit(dd)
                if log_cb:
                    log_cb("[Drawdown] %.2f%% alert (peak=%.0f now=%.0f)" % (
                        dd, self._peak, portfolio_value))

    def reset_peak(self): self._peak=0.0
    def current_drawdown(self, v): return max(0.0,(self._peak-v)/self._peak*100) if self._peak else 0.0


# ══ MultiUniverseManagerDialog ════════════════════════════════════════════════


# ────────────────────────────────────────────────────────────────────
# CLASS: LivePnLStreamer
# ────────────────────────────────────────────────────────────────────
class LivePnLStreamer(QObject):
    """
    Polls LIVE_PNL_URL every LIVE_PNL_INTERVAL_S seconds.
    Falls back to last optimizer payload. Emits data_updated(dict).
    """
    data_updated = pyqtSignal(dict)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._url=""; self._interval=10; self._enabled=False; self._last_data={}
        self._timer=QTimer(self); self._timer.timeout.connect(self._fetch)

    def configure(self, cfg):
        self._url      = str(cfg.get("LIVE_PNL_URL","")).strip()
        self._interval = max(5, int(cfg.get("LIVE_PNL_INTERVAL_S",10)))
        self._enabled  = bool(cfg.get("LIVE_PNL_ENABLED",False))
        self._timer.setInterval(self._interval*1000)
        # AUDIT-FIX (Round 4 — W0106): ternary expression used for side
        # effect; rewrite as explicit if/else so the intent is clear.
        if self._enabled:
            self._timer.start()
        else:
            self._timer.stop()

    def seed_from_payload(self, payload):
        self._last_data = {"tickers": payload.get("selected",[]),
                           "weights": payload.get("portfolio_df"),
                           "source": "optimizer",
                           "timestamp": datetime.now().isoformat()}

    def _fetch(self):
        if not self._enabled: return
        if self._url:
            try:
                import requests as _rq
                resp = _rq.get(self._url, timeout=8)
                if resp.ok:
                    self._last_data = resp.json()
                    self.data_updated.emit(dict(self._last_data)); return
            except Exception as _e:
                archlog.error('Exception detail', exc_info=True)  # LOG003 was traceback.print_exc()
                pass  # _arch_log removed (LOG003)
        if self._last_data:
            self._last_data["timestamp"] = datetime.now().isoformat()
            self.data_updated.emit(dict(self._last_data))

    def start_stream(self): self._timer.start()
    def stop_stream(self):  self._timer.stop()


# ══ ParameterSensitivityHeatmap (TAB_SENS_HEATMAP = 31) ══════════════════════


# ────────────────────────────────────────────────────────────────────
# CLASS: ExportScheduler
# ────────────────────────────────────────────────────────────────────
class ExportScheduler(QObject):
    """
    Hooks into SchedulerDaemon's post-run signal to auto-export
    snapshot CSV + JSON after every scheduled optimiser run.

    Config keys:
      EXPORT_SCHED_ENABLED   bool  — master switch (default False)
      EXPORT_SCHED_DIR       str   — output directory (default ~/qa_exports)
      EXPORT_SCHED_FORMATS   str   — comma-separated: csv,json,xlsx (default csv,json)
    """
    export_done = pyqtSignal(str)   # emits export folder path

    def __init__(self, parent=None):
        super().__init__(parent)
        self._enabled = False
        self._dir     = Path.home() / "qa_exports"
        self._formats = {"csv","json"}
        self._last_payload = {}

    def configure(self, cfg):
        self._enabled = bool(cfg.get("EXPORT_SCHED_ENABLED", False))
        raw_dir = str(cfg.get("EXPORT_SCHED_DIR","")).strip()
        self._dir = Path(raw_dir) if raw_dir else Path.home() / "qa_exports"
        raw_fmt   = str(cfg.get("EXPORT_SCHED_FORMATS","csv,json"))
        self._formats = {f.strip().lower() for f in raw_fmt.split(",") if f.strip()}

    def feed_payload(self, payload):
        self._last_payload = payload

    def run_export(self, log_cb=None):
        if not self._enabled or not self._last_payload:
            return
        try:
            import pandas as _pd, json as _json
            ts  = datetime.now().strftime("%Y%m%d_%H%M%S")
            folder = self._dir / ts  # DIV001: guard divisor before use
            folder.mkdir(parents=True, exist_ok=True)
            p = self._last_payload
            # CSV: every DataFrame in payload
            if "csv" in self._formats:
                for key, val in p.items():
                    if hasattr(val, "to_csv"):
                        val.to_csv(folder / ("%s.csv" % key), index=False)
            # JSON: scalar fields
            if "json" in self._formats:
                scalar = {k:v for k,v in p.items()
                          if isinstance(v,(str,int,float,bool,list,dict,type(None)))}
                with open(folder / "summary.json","w", encoding="utf-8") as fh:
                    _json.dump(scalar, fh, default=str, indent=2)
            # XLSX: portfolio_df if requested
            if "xlsx" in self._formats and "portfolio_df" in p:
                df = p["portfolio_df"]
                if hasattr(df,"to_excel"):
                    df.to_excel(folder / "portfolio.xlsx", index=False)
            msg = "ExportScheduler: saved to %s" % folder
            if log_cb: log_cb(msg)
            self.export_done.emit(str(folder))
        except Exception as e:
            if log_cb: log_cb("[ExportScheduler] Error: "+str(e))


# ══ RegimeOverlayChart (TAB_REGIME_CHART = 33) ════════════════════════════════


# ────────────────────────────────────────────────────────────────────
# CLASS: _VixPill
# ────────────────────────────────────────────────────────────────────
class _VixPill(QLabel):
    """Tiny coloured label for the topbar. Updated via set_vix()."""
    def __init__(self, parent=None):
        super().__init__("VIX: —", parent)
        self.setFixedHeight(22)
        self.setAlignment(Qt.AlignCenter)
        self.setObjectName("MutedText")
        self.setToolTip("India VIX Regime")
        self.setStyleSheet("padding:2px 8px; border-radius:10px; font-size:11px; font-weight:bold;")

    def set_vix(self, vix, label, color):
        self.setText("VIX %.1f  %s" % (vix, label))
        self.setStyleSheet(
            "padding:2px 8px; border-radius:10px; font-size:11px; font-weight:bold;"
            "color:%s; background:%s30; border:1px solid %s;" % (color, color, color))


# ══ PortfolioCommentaryGenerator (TAB_COMMENTARY = 55) ════════════════════════


# ────────────────────────────────────────────────────────────────────
# FUNC: compute_sensitivity_report
# ────────────────────────────────────────────────────────────────────
def compute_sensitivity_report(base_cfg: dict, signal_df: pd.DataFrame,
                                clean_returns: pd.DataFrame,
                                log_cb=None) -> pd.DataFrame:
    """
    v17.2: Run QUBO selection across GAMMA ±30% grid.
    Shows how stock selection changes with risk-aversion parameter.
    Returns a DataFrame: rows=GAMMA values, cols=selected tickers (✓/✗).
    """
    from optimizer import build_qubo
    try:
        import neal
        gammas     = [round(base_cfg.get("GAMMA", 22.0) * f, 1)
                      for f in (0.5, 0.7, 0.85, 1.0, 1.15, 1.30, 1.5)]
        n_stocks   = int(base_cfg.get("K_STOCKS", 8))
        rows       = []
        all_tickers = list(signal_df.index) if signal_df is not None and not signal_df.empty else []
        if not all_tickers:
            return pd.DataFrame()

        for gamma in gammas:
            cfg_v = {**base_cfg, "GAMMA": gamma}
            try:
                # FIX: Pass the correct signature to build_qubo
                q_v, _, _ = build_qubo(
                    data={"Close": clean_returns, "Volume": pd.DataFrame()},
                    returns=clean_returns,
                    benchmark_returns=pd.Series(dtype=float), # Pass proper series format
                    sectors={},
                    prev_holdings=set(),
                    cfg=cfg_v,
                    log_cb=log_cb
                )
                sampler  = neal.SimulatedAnnealingSampler()
                response = sampler.sample_qubo(q_v, num_reads=20, num_sweeps=500)
                best     = dict(response.first.sample)
                selected = sorted([t for t, v in best.items() if v == 1])[:n_stocks]
                row      = {"GAMMA": gamma, "N_selected": len(selected),
                            "Tickers": ", ".join(selected)}
                rows.append(row)
            except Exception as _e:
                rows.append({"GAMMA": gamma, "N_selected": 0, "Tickers": "error"})
        log_emit(log_cb, f"[Sensitivity] GAMMA grid: {len(rows)} scenarios computed")
        return pd.DataFrame(rows)
    except Exception as e:
        log_emit(log_cb, f"[Sensitivity] Failed: {e}", exc_info=True)
        return pd.DataFrame()


# ────────────────────────────────────────────────────────────────────
# CLASS: QuantumPortfolioOptimizer
# ────────────────────────────────────────────────────────────────────
class QuantumPortfolioOptimizer:
    """
    v17.3: Thin headless wrapper around run_optimizer_logic.
    All quant logic lives in the module-level functions.
    This class adds:
      - Clean Python API (no GUI imports needed at call-time)
      - Progress/log callbacks wired to print() or a custom handler
      - Structured result dict with the most useful fields at the top level
      - Optional IC summary and factor attribution in the result
    """


    def __init__(self, cfg: dict = None, log_fn=None):
        from data_layer import DEFAULT_CFG
        self.cfg    = {**DEFAULT_CFG, **(cfg or {})}
        self.log_fn = log_fn or (lambda msg: print(f"[Optimizer] {msg}"))

    # ── Public API ─────────────────────────────────────────────────────────
    def run(self, tickers: list = None, cache_dir: str = None) -> dict:
        """
        Run the full optimizer pipeline (download → signal → QUBO → portfolio).

        Parameters
        ----------
        tickers   : list of Yahoo Finance ticker strings, e.g. ["RELIANCE.NS", ...]
                    Falls back to cfg["TICKERS"] if not provided.
        cache_dir : optional path to cache directory (overrides cfg["CACHE_DIR"])

        Returns
        -------
        dict with keys:
            selected_tickers  list[str]
            weights           dict[str, float]
            sharpe            float
            ann_return        float
            max_drawdown      float
            regime            dict
            payload           dict   (full payload — all tables, DataFrames, etc.)
        """
        working_cfg = copy.deepcopy(self.cfg)  # deep-copy: nested dicts stay isolated
        if tickers:
            working_cfg["TICKERS"] = tickers
        if cache_dir:
            working_cfg["CACHE_DIR"] = cache_dir

        payload: dict = {}
        errors:  list = []

        def _progress(pct: int, msg: str = ""):
            self.log_fn(f"[{pct:3d}%] {msg}")

        def _log(msg: str):
            self.log_fn(msg)

        try:
            from optimizer import run_optimizer_logic
            payload = run_optimizer_logic(
                cfg         = working_cfg,
                log_cb      = _log,
                progress_cb = _progress,
            )
        except Exception as e:
            errors.append(str(e))
            self.log_fn(f"[ERROR] {e}")

        metrics = payload.get("metrics", {})
        return {
            "selected_tickers": payload.get("selected_tickers", []),
            "weights":          payload.get("weights",          {}),
            "sharpe":           metrics.get("sharpe",           float("nan")),
            "ann_return":       metrics.get("ann_return",       float("nan")),
            "max_drawdown":     metrics.get("max_drawdown",     float("nan")),
            "regime":           payload.get("regime_info",      {}),
            "signal_df":        payload.get("signal_df"),
            "factor_ic_df":     payload.get("factor_ic_df"),
            "backtest_df":      payload.get("backtest_df"),
            "errors":           errors,
            "payload":          payload,
        }

    def run_backtest(self, tickers: list = None) -> dict:
        """Convenience wrapper — forces walk-forward backtest on."""
        cfg = {**self.cfg, "BACKTEST_ENABLED": True}
        return QuantumPortfolioOptimizer(cfg=cfg, log_fn=self.log_fn).run(tickers)

    def factor_ic(self, tickers: list = None) -> "pd.DataFrame":
        """Return just the IC dashboard DataFrame."""
        return self.run(tickers).get("factor_ic_df")

    # ── CLI entry point ────────────────────────────────────────────────────
    @staticmethod
    def cli():
        """
        Minimal CLI: python quantum_annealer_ultimate_institutional_v17_1.py --headless
        Prints selected tickers + weights to stdout. Useful for cron / automation.
        """
        import argparse, json
        ap = argparse.ArgumentParser(description="QUBO Portfolio Optimizer — headless mode")
        ap.add_argument("--tickers",   nargs="*",    default=None,  help="Ticker list")
        ap.add_argument("--cfg",       default=None, help="Path to JSON config file")
        ap.add_argument("--value",     type=float,   default=None,  help="Portfolio value INR")
        ap.add_argument("--k",         type=int,     default=None,  help="Number of stocks to select")
        ap.add_argument("--json-out",  action="store_true",         help="Output JSON to stdout")
        args = ap.parse_args()

        cfg = {}
        if args.cfg:
            with open(args.cfg, encoding="utf-8") as f: cfg = json.load(f)
        if args.value: cfg["PORTFOLIO_VALUE_INR"] = args.value
        if args.k:     cfg["K_STOCKS"]            = args.k

        opt    = QuantumPortfolioOptimizer(cfg=cfg)
        result = opt.run(tickers=args.tickers)

        if args.json_out:
            out = {k: v for k, v in result.items()
                   if k not in ("payload", "signal_df", "backtest_df", "factor_ic_df")}
            archlog.info(json.dumps(out, indent=2, default=str))  # LOG002 was print
        else:
            archlog.info("\n=== Selected Portfolio ===")  # LOG002 was print
            for t, w in sorted(result["weights"].items(), key=lambda x: -x[1]):
                archlog.info(f"  {t:<20s}  {w*100:6.2f}%")  # LOG002 was print
            archlog.info(f"\nSharpe: {result['sharpe']:.3f}  "  # LOG002 was print
                  f"Ann Return: {result['ann_return']*100:.1f}%  "
                  f"MaxDD: {result['max_drawdown']*100:.1f}%")
            archlog.info(f"Regime: {result['regime'].get('Regime','?')}")  # LOG002 was print


# ============================================================
# TURN CG — TECHNICAL ANALYSIS PRO SUITE (TABs 303–307)
# v19.3 | Candlestick, Chart Patterns, Pivots, Fibonacci, Trend
# ============================================================

TAB_CANDLESTICKMASTERSCANNER = 600  # CandlestickMasterScanner
TAB_CHARTPATTERNRECOGNIZER = 601  # ChartPatternRecognizer
TAB_PIVOTPOINTCALCULATOR = 602  # PivotPointCalculator
TAB_FIBONACCIRETRACEMENTTOOL = 603  # FibonacciRetracementTool
TAB_TRENDSTRENGTHMETER = 604  # TrendStrengthMeter


# ── TAB 303 — CandlestickMasterScanner ──────────────────────────────────────


# ── TAB 304 — ChartPatternRecognizer ────────────────────────────────────────


# ── TAB 305 — PivotPointCalculator ──────────────────────────────────────────


# ── TAB 306 — FibonacciRetracementTool ──────────────────────────────────────


# ── TAB 307 — TrendStrengthMeter ────────────────────────────────────────────


# ============================================================
# TURN CH — TECHNICAL ANALYSIS SUITE II (TABs 308–312)
# v19.4 | Volume Profile, A/D Breadth, RS Scanner, MA Cross, Oscillators
# ============================================================

TAB_VOLUMEPROFILEANALYZER = 605  # VolumeProfileAnalyzer
TAB_ADVANCEDECLINEBREADTHPANEL = 606  # AdvanceDeclineBreadthPanel
TAB_RELATIVESTRENGTHSCANNER = 607  # RelativeStrengthScanner
TAB_MOVINGAVERAGECROSSSCANNER = 608  # MovingAverageCrossScanner
TAB_OSCILLATORCONFLUENCEDESK = 609  # OscillatorConfluenceDesk


# ── TAB 308 — VolumeProfileAnalyzer ─────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: _make_ticker_bar
# ────────────────────────────────────────────────────────────────────
def _make_ticker_bar(default_text="Paste NSE tickers, comma-separated …"):
    """Returns (QTextEdit for tickers, QPushButton fetch, QComboBox period)."""
    te = QPlainTextEdit()
    te.setPlaceholderText(default_text)
    te.setFixedHeight(56)
    te.setFont(QFont("Courier New", 10))
    period_cb = QComboBox()
    period_cb.addItems(["1y", "2y", "3y", "5y", "6mo", "3mo"])
    period_cb.setFixedWidth(70)
    fetch_btn = QPushButton("⬇ Fetch & Analyse")
    fetch_btn.setObjectName("PrimaryButton")
    fetch_btn.setFixedHeight(30)
    return te, fetch_btn, period_cb


# ────────────────────────────────────────────────────────────────────
# FUNC: _colour_item
# ────────────────────────────────────────────────────────────────────
def _colour_item(val_str, good_condition):
    item = QTableWidgetItem(str(val_str))
    item.setForeground(QColor(f_QSS.GREEN) if good_condition else QColor(f_QSS.RED))
    return item


# ────────────────────────────────────────────────────────────────────
# FUNC: _neutral_item
# ────────────────────────────────────────────────────────────────────
def _neutral_item(val_str):
    item = QTableWidgetItem(str(val_str))
    item.setForeground(QColor(f_QSS.GOLD))
    return item


# ────────────────────────────────────────────────────────────────────
# FUNC: _make_std_table
# ────────────────────────────────────────────────────────────────────
def _make_std_table(cols):
    t = QTableWidget(0, len(cols))
    t.setHorizontalHeaderLabels(cols)
    t.setEditTriggers(QTableWidget.NoEditTriggers)
    t.setSelectionBehavior(QTableWidget.SelectRows)
    t.horizontalHeader().setStretchLastSection(True)
    t.verticalHeader().setVisible(False)
    t.setSortingEnabled(True)
    return t


# ────────────────────────────────────────────────────────────────────
# FUNC: _launch
# ────────────────────────────────────────────────────────────────────
def _launch(parent_widget, fn, args, on_done, on_err, on_progress=None):
    """Spin up QThread → _Worker, wire signals, return (thread, worker)."""
    from workers.worker_threads import _Worker
    thread = QThread(parent_widget)
    worker = _Worker(fn, *args)
    worker.moveToThread(thread)
    thread.started.connect(worker.run)
    worker.done.connect(on_done)
    worker.done.connect(lambda _: thread.quit())
    worker.error.connect(on_err)
    worker.error.connect(lambda _: thread.quit())
    if on_progress:
        worker.progress.connect(on_progress)
    thread.start()
    return thread, worker


# ── NSE Preset Theme Baskets ──────────────────────────────────────────────────
# These are SEED keywords, NOT fixed lists.  The ThemeBasketBuilder enriches
# them dynamically using Yahoo Finance sector/industry tags + name matching.
_THEME_SEEDS = {
    "Defence & Aerospace": ["HAL","BEL","BHEL","BEML","COCHINSHIP","MIDHANI",
                             "PARAS","MTAR","DATAPATT","IDEAFORGE","ZEN","DRDO"],
    "Railways & Infra":    ["IRFC","RVNL","RAILTEL","IRCON","TITAGARH","TEXRAIL",
                             "RITES","IRCTC","KERNEX","HBLPOWER","KALPATPOWR"],
    "Power & Renewables":  ["NHPC","SJVN","NTPC","POWERGRID","CESC","TATAPOWER",
                             "ADANIGREEN","JSWENERGY","GREENKO","INOXWIND","SUZLON"],
    "Chemicals Specialty": ["PIDILITIND","NAVINFLUOR","DEEPAKNTR","AARTIIND",
                             "TATACHEM","GNFC","ALKYLAMINE","BALCHEMLTD","SUDARSCHEM"],
    "Capital Goods":       ["LT","ABB","SIEMENS","BHEL","THERMAX","AIAENG",
                             "CUMMINSIND","GRINDWELL","KSBPUMPS","ELGIEQUIP"],
    "PSU Banks":           ["SBIN","BANKBARODA","PNB","CANBK","UNIONBANK",
                             "INDIANB","CENTRALBK","MAHABANK","J&KBANK"],
    "IT Mid-tier":         ["KPITTECH","PERSISTENT","MPHASIS","COFORGE","LTIM",
                             "BIRLASOFT","HEXAWARE","OFSS","MASTEK","CYIENT"],
    "Pharma Generic":      ["SUNPHARMA","DRREDDY","CIPLA","LUPIN","AUROPHARMA",
                             "DIVISLAB","ALKEM","IPCALAB","LAURUSLABS","GRANULES"],
    "SME / Microcap":      [],    # discovered purely from NSE SME list — no seeds
    "Short Squeeze Setup": [],    # discovered from F&O PCR + volume — no seeds
}


# ─── TAB 495 ──────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────
# FUNC: main
# ────────────────────────────────────────────────────────────────────

def _download_universe(tickers, period="1y", interval="1d"):
    """Batch download via safe_download; returns dict {ticker: OHLCV DataFrame}."""
    from data.price_feed import safe_download
    tns = []
    for t in tickers:
        if "." in t or "^" in t or "=" in t:
            tns.append(t)
        else:
            tns.append(f"{t}.NS")
    try:
        raw = safe_download(tns, period=period)
        out = {}
        for t, tns_i in zip(tickers, tns):
            try:
                if isinstance(raw.columns, pd.MultiIndex):
                    df = raw.xs(tns_i, axis=1, level=1) if tns_i in raw.columns.get_level_values(1) else pd.DataFrame()
                else:
                    df = raw
                df = df.dropna(subset=["Close"]) if "Close" in df.columns else df.dropna()
                if not df.empty:
                    out[t] = df
            except Exception:
                import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                pass
        return out
    except Exception:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
        return {}


def _rsi(close, period=14):
    import numpy as np
    delta = close.diff()
    gain  = delta.clip(lower=0).ewm(alpha=1/period, adjust=False).mean()
    loss  = (-delta.clip(upper=0)).ewm(alpha=1/period, adjust=False).mean()
    rs    = gain / loss.replace(0, float('nan'))
    return 100 - (100 / (1 + rs))


def _macd(close, fast=12, slow=26, sig=9):
    ema_f = close.ewm(span=fast, adjust=False).mean()
    ema_s = close.ewm(span=slow, adjust=False).mean()
    macd  = ema_f - ema_s
    signal= macd.ewm(span=sig, adjust=False).mean()
    return macd, signal, macd - signal


def _bollinger(close, period=20, std=2):
    sma = close.rolling(period).mean()
    sigma = close.rolling(period).std()
    upper = sma + std * sigma
    lower = sma - std * sigma
    bw    = (upper - lower) / sma * 100
    pct_b = (close - lower) / (upper - lower) * 100
    return upper, sma, lower, bw, pct_b


def _atr(high, low, close, period=14):
    import pandas as pd
    tr = pd.concat([high - low,
                    (high - close.shift()).abs(),
                    (low  - close.shift()).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1/period, adjust=False).mean()


def _supertrend(high, low, close, period=10, mult=3.0):
    import numpy as np, pandas as pd
    atr  = _atr(high, low, close, period)
    hl2  = (high + low) / 2
    upper = hl2 + mult * atr
    lower = hl2 - mult * atr
    st    = pd.Series(index=close.index, dtype=float)
    direction = pd.Series(1, index=close.index)
    for i in range(1, len(close)):
        if close.iloc[i] > upper.iloc[i-1]:
            direction.iloc[i] = 1
        elif close.iloc[i] < lower.iloc[i-1]:
            direction.iloc[i] = -1
        else:
            direction.iloc[i] = direction.iloc[i-1]
        st.iloc[i] = lower.iloc[i] if direction.iloc[i] == 1 else upper.iloc[i]
    return st, direction


def _volume_profile(df, lookback=20):
    """Return POC, VAH, VAL, HVN, LVN."""
    import numpy as np
    sub = df.tail(lookback)
    bins = np.linspace(sub["Low"].min(), sub["High"].max(), 20)
    vol  = np.zeros(len(bins)-1)
    for _, row in sub.iterrows():
        idxs = np.where((bins[:-1] <= row["Close"]) & (bins[1:] > row["Close"]))[0]
        if len(idxs):
            vol[idxs[0]] += row.get("Volume", 0)
    poc_idx = np.argmax(vol)
    poc     = (bins[poc_idx] + bins[poc_idx+1]) / 2
    cum     = np.cumsum(vol); total = cum[-1] or 1
    va_mask = vol >= np.percentile(vol[vol > 0], 30)
    va_prices = bins[:-1][va_mask]
    vah = va_prices.max() if len(va_prices) else sub["High"].max()
    val = va_prices.min() if len(va_prices) else sub["Low"].min()
    hvn = (bins[np.argmax(vol)] + bins[np.argmax(vol)+1]) / 2
    # AUDIT-FIX (Round 6, C-P2-3): the previous `np.argmin(vol[vol > 0])`
    # returned an index into the FILTERED (compact) array which was then
    # used against the FULL bins array — any zero-volume bin ahead of the
    # true minimum shifted the LVN to a different (empty) price zone
    # (seeded repro: true low-volume zone at 110, reported 101.16).
    _pos = np.where(vol > 0)[0]
    lv_idx = int(_pos[np.argmin(vol[_pos])]) if len(_pos) else 0
    lvn = (bins[lv_idx] + bins[lv_idx+1]) / 2
    return poc, vah, val, hvn, lvn


def _ichimoku(high, low, close):
    t_line = (high.rolling(9).max()  + low.rolling(9).min())  / 2
    k_line = (high.rolling(26).max() + low.rolling(26).min()) / 2
    span_a = ((t_line + k_line) / 2).shift(26)
    span_b = ((high.rolling(52).max() + low.rolling(52).min()) / 2).shift(26)
    chikou = close.shift(-26)
    return t_line, k_line, span_a, span_b, chikou


def _vwap(df):
    import numpy as np
    typical = (df["High"] + df["Low"] + df["Close"]) / 3
    return (typical * df["Volume"]).cumsum() / df["Volume"].cumsum().replace(0, float('nan'))


def _donchian(high, low, period=20):
    return high.rolling(period).max(), low.rolling(period).min()


def _adx(high, low, close, period=14):
    import numpy as np
    atr_  = _atr(high, low, close, period)
    up    = high.diff(); dn = -low.diff()
    pdm   = (up.where((up > dn) & (up > 0), 0)).ewm(alpha=1/period, adjust=False).mean()
    ndm   = (dn.where((dn > up) & (dn > 0), 0)).ewm(alpha=1/period, adjust=False).mean()
    pdi   = 100 * pdm / atr_.replace(0, float('nan'))
    ndi   = 100 * ndm / atr_.replace(0, float('nan'))
    dx    = 100 * (pdi - ndi).abs() / (pdi + ndi).replace(0, float('nan'))
    return dx.ewm(alpha=1/period, adjust=False).mean(), pdi, ndi


def _pivot_points(prev_high, prev_low, prev_close):
    pivot = (prev_high + prev_low + prev_close) / 3
    return {
        "PP": pivot,
        "R1": 2*pivot - prev_low,  "R2": pivot + (prev_high - prev_low),
        "R3": prev_high + 2*(pivot - prev_low),
        "S1": 2*pivot - prev_high, "S2": pivot - (prev_high - prev_low),
        "S3": prev_low - 2*(prev_high - pivot),
    }


def _compute_all(df):
    """
    Given an OHLCV DataFrame, compute every indicator used across panels.
    Returns a dict of scalar values (latest bar).
    """
    import numpy as np
    c = df["Close"]; h = df["High"]; l = df["Low"]; v = df["Volume"]
    try:
        cmp   = float(c.iloc[-1])
        open_ = float(df["Open"].iloc[-1])
        prev  = float(c.iloc[-2]) if len(c) > 1 else cmp
        chg   = round((cmp/prev - 1)*100, 2) if prev else 0

        # Returns
        ret5  = round((cmp / float(c.iloc[-6])  - 1)*100, 1) if len(c) > 5  else 0
        ret20 = round((cmp / float(c.iloc[-21]) - 1)*100, 1) if len(c) > 20 else 0
        ret60 = round((cmp / float(c.iloc[-61]) - 1)*100, 1) if len(c) > 60 else 0
        ret252= round((cmp / float(c.iloc[0])   - 1)*100, 1)

        # Highs
        hi52  = float(h.rolling(252).max().iloc[-1])
        lo52  = float(l.rolling(252).min().iloc[-1])
        hi52pct = round((cmp/hi52 - 1)*100, 1) if hi52 else 0
        lo52pct = round((cmp/lo52 - 1)*100, 1) if lo52 else 0

        # Volume
        vol      = int(v.iloc[-1])
        avgvol20 = float(v.rolling(20).mean().iloc[-1])
        vol_ratio= round(vol / avgvol20, 2) if avgvol20 else 1

        # RSI
        rsi14 = round(float(_rsi(c,14).iloc[-1]), 1)
        rsi7  = round(float(_rsi(c,7).iloc[-1]),  1)

        # MACD
        mc, ms, mh = _macd(c)
        macd_val  = round(float(mc.iloc[-1]), 2)
        macd_sig  = round(float(ms.iloc[-1]), 2)
        macd_hist = round(float(mh.iloc[-1]), 2)

        # Bollinger
        bu, bm, bl, bw, pctb = _bollinger(c)
        bb_upper = round(float(bu.iloc[-1]), 2)
        bb_mid   = round(float(bm.iloc[-1]), 2)
        bb_lower = round(float(bl.iloc[-1]), 2)
        bb_width = round(float(bw.iloc[-1]), 2)
        bb_pctb  = round(float(pctb.iloc[-1]), 1)

        # ATR
        atr14 = round(float(_atr(h, l, c).iloc[-1]), 2)
        atr_pct = round(atr14/cmp*100, 2) if cmp else 0

        # ADX
        adx_v, pdi, ndi = _adx(h, l, c)
        adx   = round(float(adx_v.iloc[-1]), 1)
        pdi_v = round(float(pdi.iloc[-1]), 1)
        ndi_v = round(float(ndi.iloc[-1]), 1)

        # Supertrend
        st, stdir = _supertrend(h, l, c)
        st_val = round(float(st.iloc[-1]), 2)
        st_bull= int(stdir.iloc[-1]) == 1

        # Ichimoku
        tk, kj, sa, sb, ch = _ichimoku(h, l, c)
        ichi_above_cloud = (cmp > float(sa.iloc[-1])) and (cmp > float(sb.iloc[-1]))
        tk_val = round(float(tk.iloc[-1]), 2)
        kj_val = round(float(kj.iloc[-1]), 2)

        # Donchian
        dch, dcl = _donchian(h, l, 20)
        dc_high = round(float(dch.iloc[-1]), 2)
        dc_low  = round(float(dcl.iloc[-1]), 2)
        dc_pct  = round((cmp - dc_low)/(dc_high - dc_low)*100, 1) if dc_high != dc_low else 50

        # EMAs
        ema9   = round(float(c.ewm(span=9,  adjust=False).mean().iloc[-1]), 2)
        ema20  = round(float(c.ewm(span=20, adjust=False).mean().iloc[-1]), 2)
        ema50  = round(float(c.ewm(span=50, adjust=False).mean().iloc[-1]), 2)
        ema200 = round(float(c.ewm(span=200,adjust=False).mean().iloc[-1]), 2)
        above200 = cmp > ema200

        # SMAs
        sma50  = round(float(c.rolling(50).mean().iloc[-1]), 2)
        sma200 = round(float(c.rolling(200).mean().iloc[-1]), 2)

        # VWAP (today proxy - session)
        vwap_val = round(float(_vwap(df).iloc[-1]), 2)

        # Pivot (using yesterday's OHLC)
        pivots   = _pivot_points(float(h.iloc[-2]), float(l.iloc[-2]), float(c.iloc[-2])) if len(c) > 1 else {}

        # Volume profile
        poc, vah, val, hvn, lvn = _volume_profile(df, 20)
        poc_pct = round((cmp/poc - 1)*100, 1) if poc else 0
        above_poc = cmp > poc

        # Candlestick patterns (last bar)
        body   = abs(cmp - open_)
        candle_range = float(h.iloc[-1] - l.iloc[-1])
        upper_wick = float(h.iloc[-1]) - max(cmp, open_)
        lower_wick = min(cmp, open_) - float(l.iloc[-1])
        doji       = body < 0.1 * candle_range if candle_range else False
        hammer     = (lower_wick > 2*body) and (upper_wick < body) if body else False
        shooting   = (upper_wick > 2*body) and (lower_wick < body) if body else False
        bullish_ec = (cmp > open_) and (body > 0.6*candle_range) if candle_range else False
        bearish_ec = (cmp < open_) and (body > 0.6*candle_range) if candle_range else False

        gap_pct = round((open_ - prev)/prev*100, 2) if prev else 0

        return dict(
            cmp=cmp, open=open_, prev=prev, chg=chg,
            ret5=ret5, ret20=ret20, ret60=ret60, ret252=ret252,
            hi52=hi52, lo52=lo52, hi52pct=hi52pct, lo52pct=lo52pct,
            vol=vol, avgvol20=avgvol20, vol_ratio=vol_ratio,
            rsi14=rsi14, rsi7=rsi7,
            macd=macd_val, macd_sig=macd_sig, macd_hist=macd_hist,
            bb_upper=bb_upper, bb_mid=bb_mid, bb_lower=bb_lower,
            bb_width=bb_width, bb_pctb=bb_pctb,
            atr14=atr14, atr_pct=atr_pct,
            adx=adx, pdi=pdi_v, ndi=ndi_v,
            st=st_val, st_bull=st_bull,
            ichi_above=ichi_above_cloud, tk=tk_val, kj=kj_val,
            dc_high=dc_high, dc_low=dc_low, dc_pct=dc_pct,
            ema9=ema9, ema20=ema20, ema50=ema50, ema200=ema200, above200=above200,
            sma50=sma50, sma200=sma200, vwap=vwap_val, pivots=pivots,
            poc=round(poc,2), vah=round(vah,2), val=round(val,2),
            poc_pct=poc_pct, above_poc=above_poc,
            doji=doji, hammer=hammer, shooting=shooting,
            bullish_ec=bullish_ec, bearish_ec=bearish_ec,
            gap_pct=gap_pct,
        )
    except Exception as exc:
        return {"error": str(exc), "cmp": 0}

# --- Production Data Provider Initialization & Guard ---
try:
    from data_layer import YFinanceProvider
    if _DATA_PROVIDER is None:
        set_provider(YFinanceProvider())
except ImportError:
    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
    pass

if os.environ.get("ENV") == "production":
    if _DATA_PROVIDER is None or not hasattr(_DATA_PROVIDER, "ping") or not _DATA_PROVIDER.ping():
        import sys
        print("FATAL: ENV=production but live vendor handshake failed. Refusing to start.", file=sys.stderr)
        raise SystemExit(1)


class TelegramNotifier:
    """[UPGRADE 1] Automated Telegram Push Notification Manager."""
    
    @staticmethod
    def _load_saved_credentials() -> tuple:
        try:
            from data_layer import load_credentials as _dl_creds
            creds = _dl_creds()
            if creds:
                token = str(creds.get("TELEGRAM_BOT_TOKEN", "")).strip()
                chat_id = str(creds.get("TELEGRAM_CHAT_ID", "")).strip()
                if token and chat_id:
                    return token, chat_id
        except Exception:
            pass

        try:
            import json
            from pathlib import Path
            creds_path = Path.home() / ".quantum_annealer_pro_v17" / "credentials.json"
            if creds_path.exists():
                data = json.loads(creds_path.read_text())
                token = str(data.get("TELEGRAM_BOT_TOKEN", "")).strip()
                chat_id = str(data.get("TELEGRAM_CHAT_ID", "")).strip()
                return token, chat_id
        except Exception:
            import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
            pass
        return "", ""

    @classmethod
    def send_message(cls, bot_token: str = None, chat_id: str = None, text: str = "",
                     parse_mode: Optional[str] = "Markdown", timeout: int = 10, log_cb=None) -> bool:
        token = str(bot_token).strip() if bot_token else ""
        cid = str(chat_id).strip() if chat_id else ""
        
        if not token or not cid:
            saved_token, saved_cid = cls._load_saved_credentials()
            token = token or saved_token
            cid = cid or saved_cid
            
        if not token or not cid or not text:
            return False
            
        try:
            import urllib.request
            import urllib.parse
            url = f"https://api.telegram.org/bot{token}/sendMessage"
            payload = {"chat_id": cid, "text": text}
            if parse_mode:
                payload["parse_mode"] = parse_mode
            data = urllib.parse.urlencode(payload).encode("utf-8")
            req = urllib.request.Request(url, data=data, headers={"User-Agent": "Mozilla/5.0 (QuantumAnnealerPro)"})
            with urllib.request.urlopen(req, timeout=timeout) as response:
                return response.status == 200
        except Exception as e:
            import logging as _swallow_log_mod
            _swallow_log_mod.getLogger("quantum_annealer").debug("[TelegramNotifier] Delivery failed: %s", e)
            if log_cb:
                log_cb(f"[TelegramNotifier] Error: {e}")
            return False


def send_desktop_notification(title: str, message: str) -> bool:
    """[UPGRADE 1] Sends native macOS Desktop Push Notification."""
    try:
        import subprocess
        # AUDIT-FIX (Round 6, C-P3-1): the AppleScript was built by raw
        # f-string interpolation — any embedded double-quote broke the script
        # (notification silently lost) and crafted content could inject
        # arbitrary AppleScript. Escape both quote and backslash first.
        def _esc(s: str) -> str:
            return str(s).replace("\\", "\\\\").replace('"', "\\\"")
        cmd = f'display notification "{_esc(message)}" with title "{_esc(title)}"'
        subprocess.run(["osascript", "-e", cmd], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:
        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
        return False

# AUDIT-FIX (Round 3, P2-4 follow-up): inject parent god file's globals into
# the extracted sub-module so its function bodies can reference names like
# `log_emit`, `ExceptionLogger`, `DEFAULT_CFG`, etc. that are defined later
# in this file. This is a no-op if the sub-module wasn't loaded yet.
import sys as _inject_sys
_inject_target = _inject_sys.modules.get("utils_chart_pipeline")
if _inject_target is not None:
    for _inject_k, _inject_v in list(globals().items()):
        if _inject_k.startswith("__"):
            continue
        if _inject_k in ("_inject_sys", "_inject_target", "_inject_k", "_inject_v"):
            continue
        try:
            if _inject_k not in _inject_target.__dict__:
                setattr(_inject_target, _inject_k, _inject_v)
        except Exception:
            pass
# AUDIT-FIX (Round 4): only delete names that are guaranteed defined.
# `_inject_k` and `_inject_v` are loop variables — if the for-loop body
# never executes (empty globals), they would be undefined here and `del`
# would raise NameError. Drop them from cleanup; Python's GC handles them.
try:
    del _inject_sys, _inject_target
except NameError:
    pass
