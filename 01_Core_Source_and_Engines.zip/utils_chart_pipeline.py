"""
utils_chart_pipeline.py — Chart SSL pipeline + multi-timeframe features
==========================================================================

AUDIT-FIX (Round 3, P2-4): extracted from utils.py (originally ~1,500 LOC
of chart-image SSL helpers + multi-timeframe dual-tower feature builders
+ apply_score_calibration + compute_chart_ssl_features).

This module groups the entire chart-SSL pipeline:
  - Chart image embedding (from array, from file)
  - Offline chart SSL model load/build
  - Multi-timeframe dual-tower feature computation
  - 1-D time-series feature vectors (v1 and v2)
  - Chart tensor + multitimeframe input bundle builders
  - Score calibration (apply_score_calibration)
  - Live chart SSL model build + compute_chart_ssl_features

The parent utils.py re-exports every name from this module so all existing
`from utils import apply_score_calibration` call sites keep working without
modification.

AUDIT-FIX (Round 4 — late-bound names): several names used by function
bodies in this file (`log_emit`, `_VIT_CACHE`, `_SWEEP_CHART_CACHE*`,
`CHART_SSL_MODEL_PATH`, `HAS_PIL`, `_MiniBatchKMeans`, `read_json_cache`,
`write_json_cache`, `check_stop`, `ExceptionLogger`, `robust_zscore_series`,
`_CHART_SSL_MODEL_CACHE`, etc.) are *defined in utils.py* (or
math_engine.indicators). Because `utils.py` imports *this* module at its
line 4 — before any of those names are defined — a top-level
`from utils import ...` here would create a circular import. Instead,
utils.py's end-of-file injection block (`utils.py` last 15 lines) copies
all of its globals into this module's `__dict__` after it finishes
loading. The names are therefore available by the time any function in
this module is actually called.

Static analyzers (pyflakes, pylint) cannot see this runtime injection and
report false-positive F821/E0602 warnings. The file-level directives
below silence them. Do NOT remove without first converting every
late-bound reference to a deferred import inside the calling function.

"""
from __future__ import annotations

# AUDIT-FIX (Round 4): silence false-positive undefined-name warnings from
# pyflakes/pylint. See the module docstring above for the late-binding
# rationale. The names ARE available at call time via utils.py's
# end-of-file injection block.
# flake8: noqa: F821
# pylint: disable=E0602,undefined-variable

# AUDIT-FIX (Round 3, P2-4 follow-up): STANDARD_IMPORTS added to fix latent NameError
import sys, os, re, math, time, json, copy, warnings, threading, traceback
import tempfile, logging as _logging, hashlib as _hashlib, sqlite3, pickle
import csv, io, gc, uuid, base64
import collections, functools, itertools, contextlib
import concurrent.futures as _cf_mod, threading as _threading
from pathlib import Path
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple, Union, Callable, Sequence
from collections import Counter
try:
    import numpy as np
except ImportError:
    np = None
try:
    import pandas as pd
except ImportError:
    pd = None

# AUDIT-FIX (Round 4): robust_zscore_series is defined in
# math_engine.indicators (not utils.py). Import it directly so this module
# is self-sufficient when imported standalone. Wrapped in try/except so
# the module still loads if math_engine isn't installed yet.
try:
    from math_engine.indicators import robust_zscore_series  # noqa: F401
except Exception:  # pragma: no cover — late binding fallback
    pass


# Chart pipeline functions use numpy, pandas, and deferred imports from optimizer.

from typing import TYPE_CHECKING  # noqa
if TYPE_CHECKING:
    # Forward declarations for type hints — never executed at runtime
    pass

def _pool_mean_fixed(mat: np.ndarray, out_h: int, out_w: int) -> np.ndarray:
    arr = np.asarray(mat, dtype=np.float32)
    h, w = arr.shape[:2]
    if h < out_h or w < out_w:
        return np.zeros((out_h, out_w), dtype=np.float32)
    h_trim = (h // out_h) * out_h
    w_trim = (w // out_w) * out_w
    arr = arr[:h_trim, :w_trim]
    return arr.reshape(out_h, h_trim // out_h, out_w, w_trim // out_w).mean(axis=(1, 3))

def _chart_image_embedding_from_array(arr: np.ndarray) -> np.ndarray | None:
    try:
        raw = np.asarray(arr, dtype=np.float32)
        if raw.ndim == 3:
            raw = raw.mean(axis=2)
        if raw.size == 0:
            return None
        lo = float(np.nanmin(raw))
        hi = float(np.nanmax(raw))
        if not np.isfinite(lo) or not np.isfinite(hi) or hi - lo < 1e-9:
            return None
        norm = (raw - lo) / (hi - lo + 1e-9)
        resized = Image.fromarray(np.clip(norm * 255.0, 0, 255).astype(np.uint8), mode="L").resize((64, 48))
        base = np.asarray(resized, dtype=np.float32) / 255.0
        gx = np.diff(base, axis=1, prepend=base[:, :1])
        gy = np.diff(base, axis=0, prepend=base[:1, :])
        grad = np.sqrt(gx * gx + gy * gy)
        grad = grad / (float(grad.mean()) + 1e-6)
        pooled = _pool_mean_fixed(grad, 12, 16).ravel()
        row_sig = _pool_mean_fixed(grad.mean(axis=1, keepdims=True), 12, 1).ravel()
        col_sig = _pool_mean_fixed(grad.mean(axis=0, keepdims=True).T, 16, 1).ravel()
        feat = np.concatenate([pooled, row_sig, col_sig]).astype(np.float32)
        feat = np.nan_to_num(feat, nan=0.0, posinf=0.0, neginf=0.0)
        return feat / (float(np.linalg.norm(feat)) + 1e-6)
    except Exception as _e:
        return None

def _chart_image_embedding_from_file(path: Path) -> np.ndarray | None:
    try:
        with Image.open(path) as img:
            return _chart_image_embedding_from_array(np.asarray(img.convert("L"), dtype=np.float32))
    except Exception as _e:
        return None

def _apply_chart_embedding_projection(vec: np.ndarray, model: dict | None) -> np.ndarray | None:
    if vec is None:
        return None
    out = np.asarray(vec, dtype=np.float32)
    if model is None:
        return out
    mean = model.get("proj_mean")
    comps = model.get("proj_components")
    scale = model.get("proj_scale")
    if mean is not None and comps is not None:
        out = out - np.asarray(mean, dtype=np.float32)
        out = np.dot(out, np.asarray(comps, dtype=np.float32).T)
        if scale is not None:
            out = out / (np.asarray(scale, dtype=np.float32) + 1e-6)
        out = np.nan_to_num(out, nan=0.0, posinf=0.0, neginf=0.0)
        norm = float(np.linalg.norm(out))
        if norm > 1e-9:
            out = out / norm  # DIV001: guard divisor before use
    return out.astype(np.float32)

def _load_offline_chart_model(cfg: dict, log_cb=None) -> dict | None:
    if not (cfg or {}).get("USE_OFFLINE_CHART_MODEL", True):
        return None
    timeframe = str((cfg or {}).get("CHART_IMAGE_TIMEFRAME", "1d")).lower()
    from optimizer import _resolve_chart_artifact_paths
    model_path, meta_path = _resolve_chart_artifact_paths(cfg or {}, timeframe)
    if not model_path.exists():
        return None
    meta = read_json_cache(meta_path, {})
    if meta and str(meta.get("timeframe", "")).lower() not in ("", timeframe):
        return None
    try:
        cached = np.load(model_path, allow_pickle=False)
        model = {
            "centers": cached["centers"].astype(np.float32),
            "distance_scale": float(cached["distance_scale"][0]),
            "sample_count": int(cached["sample_count"][0]),
            "corpus_count": int(cached["corpus_count"][0]),
            "timeframe": timeframe,
            "artifact_path": str(model_path),
            "root": str(meta.get("root", "")),
            "kind": "offline",
        }
        for key in ("proj_mean", "proj_components", "proj_scale"):
            if key in cached.files:
                model[key] = cached[key].astype(np.float32)
        log_emit(log_cb, f"[ChartSSL] Loaded offline chart model ({model['sample_count']:,} samples, {len(model['centers'])} prototypes).")
        return model
    except Exception as exc:
        log_emit(log_cb, f"[ChartSSL] Offline artifact load failed (non-fatal): {exc}")
        return None

def _sample_chart_image_paths(root: Path, timeframe: str = "1d", max_files: int = 12000, seed: int = 42) -> tuple[list[Path], int]:
    if not root.exists():
        return [], 0
    needle = f"_{str(timeframe).lower()}_"
    rng = np.random.default_rng(seed)
    reservoir: list[Path] = []
    seen = 0
    for path in root.rglob("*.png"):
        check_stop()
        if needle not in path.name.lower():
            continue
        seen += 1
        if len(reservoir) < max_files:
            reservoir.append(path)
            continue
        j = int(rng.integers(0, seen))
        if j < max_files:
            reservoir[j] = path
    return reservoir, seen

def load_or_build_chart_ssl_model(cfg: dict, log_cb=None) -> dict | None:
    if not (cfg or {}).get("USE_CHART_IMAGE_SSL", True):
        return None
    if not HAS_PIL or not HAS_SKLEARN_CLUSTER:
        log_emit(log_cb, "[ChartSSL] PIL/sklearn cluster support unavailable — image feature skipped.")
        return None
    offline = _load_offline_chart_model(cfg or {}, log_cb=log_cb)
    if offline is not None:
        return offline

    root = Path((cfg or {}).get("CHART_IMAGE_DATASET_DIR", (cfg or {}).get("CHART_IMAGE_DATASET_DIR", "Dataset/Unlabeled"))).expanduser()
    timeframe = str((cfg or {}).get("CHART_IMAGE_TIMEFRAME", "1d")).lower()
    max_train = int((cfg or {}).get("CHART_IMAGE_MAX_TRAIN", 12000))
    n_clusters = int((cfg or {}).get("CHART_IMAGE_N_CLUSTERS", 24))
    # In-memory cache hit: train once per timeframe per process (avoids 18×4 WFO retrains)
    if timeframe in _CHART_SSL_MODEL_CACHE:
        return _CHART_SSL_MODEL_CACHE[timeframe]

    # Per-timeframe disk paths: each timeframe gets its own .npz so they never evict each other
    _tf_model_path = CHART_SSL_MODEL_PATH.with_name(f"chartsslmodel_{timeframe}.npz")
    _tf_meta_path  = Path(str(CHART_SSL_MODEL_META_PATH).replace("chartsslmodel1dmeta", f"chartsslmodel_{timeframe}meta"))
    meta = read_json_cache(_tf_meta_path, {})

    if _tf_model_path.exists() and meta.get("root") == str(root) and meta.get("timeframe") == timeframe \
       and int(meta.get("max_train", 0)) == max_train and int(meta.get("n_clusters", 0)) == n_clusters:
        try:
            cached = np.load(_tf_model_path, allow_pickle=False)
            result = {
                "centers": cached["centers"].astype(np.float32),
                "distance_scale": float(cached["distance_scale"][0]),
                "sample_count": int(cached["sample_count"][0]),
                "corpus_count": int(cached["corpus_count"][0]),
                "timeframe": timeframe,
                "root": str(root),
            }
            _CHART_SSL_MODEL_CACHE.set(timeframe, result)
            return result
        except Exception as _e_:
            ExceptionLogger.swallow(_e_, context="silent_catch")

    paths, corpus_count = _sample_chart_image_paths(root, timeframe=timeframe, max_files=max_train, seed=int((cfg or {}).get("SEED", 42)))
    if len(paths) < max(200, n_clusters * 8):
        log_emit(log_cb, f"[ChartSSL] Not enough {timeframe} images under {root} — found {len(paths)} sampled.")
        return None

    feats = []
    for i, path in enumerate(paths, start=1):
        emb = _chart_image_embedding_from_file(path)
        if emb is not None:
            proj = _apply_chart_embedding_projection(emb, None)
            if proj is not None:
                feats.append(proj)
        if i % 1500 == 0:
            log_emit(log_cb, f"[ChartSSL] Encoded {i}/{len(paths)} sampled chart images...")

    if len(feats) < max(120, n_clusters * 5):
        log_emit(log_cb, f"[ChartSSL] Only {len(feats)} valid image embeddings — feature skipped.")
        return None

    x = np.vstack(feats).astype(np.float32)
    k = max(4, min(n_clusters, len(x) // 40 or 4))
    model = _MiniBatchKMeans(
        n_clusters=k,
        random_state=int((cfg or {}).get("SEED", 42)),
        batch_size=min(2048, len(x)),
        n_init=3,
    )
    labels = model.fit_predict(x)
    dists = np.linalg.norm(x - model.cluster_centers_[labels], axis=1)
    distance_scale = float(np.median(dists) + 1e-6)
    try:
        np.savez_compressed(
            _tf_model_path,
            centers=model.cluster_centers_.astype(np.float32),
            distance_scale=np.array([distance_scale], dtype=np.float32),
            sample_count=np.array([len(x)], dtype=np.int32),
            corpus_count=np.array([corpus_count], dtype=np.int32),
        )
        write_json_cache(_tf_meta_path, {
            "root": str(root),
            "timeframe": timeframe,
            "max_train": max_train,
            "n_clusters": k,
        })
    except Exception as cache_exc:
        log_emit(log_cb, f"[ChartSSL] Cache save failed (non-fatal): {cache_exc}")
    log_emit(log_cb, f"[ChartSSL] Trained {k} pattern prototypes from {len(x):,}/{corpus_count:,} sampled {timeframe} images.")
    trained = {
        "centers": model.cluster_centers_.astype(np.float32),
        "distance_scale": distance_scale,
        "sample_count": len(x),
        "corpus_count": corpus_count,
        "timeframe": timeframe,
        "root": str(root),
    }
    _CHART_SSL_MODEL_CACHE.set(timeframe, trained)  # in-memory: skip retraining in WFO loop
    return trained

def _get_sweep_chart_ticker_lock(cache_key: str) -> threading.Lock:
    with _SWEEP_CHART_CACHE_MASTER_LOCK:
        if cache_key not in _SWEEP_CHART_CACHE_LOCKS:
            _SWEEP_CHART_CACHE_LOCKS[cache_key] = threading.Lock()
        return _SWEEP_CHART_CACHE_LOCKS[cache_key]

def compute_multi_timeframe_chart_features(daily_data, tickers: list, cfg=None, log_cb=None) -> pd.DataFrame:
    """Computes upgraded v3 multi-timeframe dual-tower retrieval features for the optimizer."""
    from math_engine.onnx_inference import LatentEmbeddingGenerator
    from math_engine.latent_screener import LatentSpaceScreener
    from data_layer import download_multitimeframe_ohlcv_bundle

    cfg = cfg or {}
    
    # Initialize generators and screeners (cached)
    if "vit" not in _VIT_CACHE or "screener" not in _VIT_CACHE:
        if "vit" not in _VIT_CACHE:
            _VIT_CACHE["vit"] = LatentEmbeddingGenerator("artifacts/vit_v3_fused.onnx")
        if "screener" not in _VIT_CACHE:
            _VIT_CACHE["screener"] = LatentSpaceScreener("artifacts")
    vit = _VIT_CACHE["vit"]
    screener = _VIT_CACHE["screener"]
    
    # Determine the regime tag if provided in cfg
    regime_info = cfg.get("_REGIME_INFO", {}) if cfg else {}
    if not regime_info:
        regime_info = (cfg.get("_REGIME_INFO") or cfg.get("_REGIME_INFO_PREFETCHED", {})) if cfg else {}
    regime_str = None
    if isinstance(regime_info, dict):
        regime_str = regime_info.get("Regime")
    if not regime_str and cfg:
        regime_str = cfg.get("_CANONICAL_MARKET_REGIME") or cfg.get("CURRENT_MARKET_REGIME")
        
    # Map to standard Bull/Bear/Sideways regime for bank partitions
    regime = None
    if regime_str:
        r_lower = regime_str.lower()
        if any(x in r_lower for x in ("bull", "risk-on", "trend", "strength")):
            regime = "bull"
        elif any(x in r_lower for x in ("bear", "stress", "defensive")):
            regime = "bear"
        else:
            regime = "sideways"
            
    log_emit(log_cb, f"[ChartV3] Initialized dual-tower retrieval. Market Regime={regime}")
    
    rows = {}
    tickers_to_download = []
    waiting_events = []

    # Step 1: Collect cached, in-flight, or fresh tickers under the master lock
    with _SWEEP_CHART_CACHE_MASTER_LOCK:
        for t in tickers:
            cache_key = f"{t}:{regime}"
            if cache_key in _SWEEP_CHART_CACHE:
                rows[t] = _SWEEP_CHART_CACHE[cache_key]
            elif cache_key in _SWEEP_CHART_PENDING:
                waiting_events.append((t, cache_key, _SWEEP_CHART_PENDING[cache_key]))
            else:
                evt = threading.Event()
                _SWEEP_CHART_PENDING[cache_key] = evt
                tickers_to_download.append((t, cache_key, evt))

    # Step 2: Download and process fresh tickers claimed by this thread first (enables true parallel processing)
    if tickers_to_download:
        missing_tickers = [t for t, _, _ in tickers_to_download]
        try:
            bundle_data = download_multitimeframe_ohlcv_bundle(missing_tickers, cfg=cfg, log_cb=log_cb)
        except Exception as bundle_ex:
            log_emit(log_cb, f"[ChartV3] Data bundle download failed: {bundle_ex}")
            bundle_data = {}

        for t, cache_key, evt in tickers_to_download:
            try:
                check_stop()
                tf_bundle = build_multitimeframe_input_bundle(bundle_data, t, benchmark_series=None, cfg=cfg)
                if not tf_bundle:
                    with _SWEEP_CHART_CACHE_MASTER_LOCK:
                        _SWEEP_CHART_PENDING.pop(cache_key, None)
                    evt.set()
                    continue
                    
                # Generate fused embeddings per timeframe
                tf_embeddings = {}
                for tf, inputs in tf_bundle.items():
                    img = inputs["image"]
                    ts = inputs["ts"]
                    tf_embeddings[tf] = vit.generate_fused_embedding(img, ts, regime=regime, timeframe=tf)
                    
                # Score timeframe bundle
                score = screener.score_timeframe_bundle(tf_embeddings, regime=regime)
                
                best_bank = score["best_bank"]
                similarity = score["best_cosine_similarity"]
                novelty = score["novelty"]
                margin = score["margin"]
                agreement = score["agreement"]
                prob = score["calibrated_probability"]
                
                # Risk is matching failed breakout or trap patterns
                failed_breakout_risk = float(similarity) if best_bank in ("failed_breakout", "mean_reversion_trap") else 0.0
                
                # Map best_bank to a cluster ID for backward compatibility
                bank_to_cluster = {
                    "breakout": 0,
                    "prebreakout": 1,
                    "failed_breakout": 2,
                    "distribution": 3,
                    "mean_reversion_trap": 4
                }
                cluster_id = bank_to_cluster.get(best_bank, 0)
                
                feature_dict = {
                    "chart_pattern_cohesion": float(similarity),
                    "chart_pattern_novelty": float(novelty),
                    "chart_pattern_margin": float(margin),
                    "chart_cluster_agreement": float(agreement),
                    "chart_pattern_dispersion": float(1.0 - agreement),
                    "chart_pattern_cluster": int(cluster_id),
                    "chart_calibrated_prob": float(prob),
                    "chart_failed_breakout_risk": float(failed_breakout_risk),
                    "chart_regime_fit": float(0.10 if (regime and best_bank in ("breakout", "prebreakout")) else 0.0),
                }
                with _SWEEP_CHART_CACHE_MASTER_LOCK:
                    _SWEEP_CHART_CACHE[cache_key] = feature_dict
                    _SWEEP_CHART_PENDING.pop(cache_key, None)
                rows[t] = feature_dict
                evt.set()
            except Exception as ticker_ex:
                log_emit(log_cb, f"[ChartV3] Failed to score {t}: {ticker_ex}")
                with _SWEEP_CHART_CACHE_MASTER_LOCK:
                    _SWEEP_CHART_PENDING.pop(cache_key, None)
                evt.set()
            finally:
                # AUDIT-FIX (Round 5, 2-b-5): a BaseException (KeyboardInterrupt /
                # SystemExit / cooperative stop) escaped the except-Exception and
                # left waiters in Step 3 blocked on evt.wait() forever (logical
                # deadlock — no lock held, no timeout). Ensure the event is ALWAYS
                # set, even on the abort path.
                if not evt.is_set():
                    evt.set()

    # Step 3: Collect results from in-flight computations in other parallel threads
    for t, cache_key, evt in waiting_events:
        # AUDIT-FIX (Round 5, 2-b-5): bound the wait — a wedged/abandoned producer
        # must not hang the whole sweep thread indefinitely.
        if not evt.wait(timeout=600.0):
            log_emit(log_cb, f"[ChartV3] Timed out waiting for in-flight {t}; skipping.")
            continue
        with _SWEEP_CHART_CACHE_MASTER_LOCK:
            if cache_key in _SWEEP_CHART_CACHE:
                rows[t] = _SWEEP_CHART_CACHE[cache_key]
            
    if not rows:
        return pd.DataFrame(index=tickers)
        
    out = pd.DataFrame.from_dict(rows, orient="index")
    out["z_chart_pattern"] = robust_zscore_series(out["chart_pattern_cohesion"])
    out["z_chart_novelty"] = robust_zscore_series(out["chart_pattern_novelty"])
    out["z_chart_margin"] = robust_zscore_series(out["chart_pattern_margin"])
    
    # Store ensemble info in attrs
    try:
        total_clusters = sum(arr.shape[0] for arr in screener.bank_manager._raw_arrays.values())
    except Exception:
        total_clusters = 1800
    out.attrs["chart_model_info"] = {
        "kind": "vit_v3_dual_tower",
        "timeframe": "multi",
        "clusters": total_clusters,
        "sample_count": total_clusters,
        "corpus_count": 2122,
        "timeframes": ["1h", "4h", "1d", "1wk"],
        "regime": regime,
    }
    
    log_emit(log_cb, f"[ChartV3] Completed dual-tower scoring for {len(rows)}/{len(tickers)} tickers.")
    return out

def _ts_feature_vector(close_s: pd.Series, volume_s: pd.Series | None,
                        window: int = 30) -> np.ndarray | None:
    """I1-fix: extract a compact 1-D feature vector from raw price/volume data.
    No PIL, no pixel rendering — purely numerical.
    Vector layout (35 dims):
      [0:30]  min-max normalised close prices over the window
      [30]    realised volatility (annualised, log returns, 10-day)
      [31]    RSI-14 signal (normalised 0-1)
      [32]    volume trend: log(avg_last5 / avg_first5) clipped ±3
      [33]    linear slope of normalised prices (OLS, units: 1/window)
      [34]    high-low range ratio: (max-min)/mean — proxy for volatility regime
    """
    s = close_s.dropna()
    if len(s) < window:
        return None
    w = s.iloc[-window:].values.astype(np.float64)
    lo, hi = w.min(), w.max()
    if hi - lo < 1e-9:
        return None
    norm = (w - lo) / (hi - lo)                              # [0:30]

    # Realised vol
    rets = np.diff(np.log(w + 1e-9))
    rv = float(np.std(rets[-10:]) * np.sqrt(TRADING_DAYS_PER_YEAR)) if len(rets) >= 10 else 0.0

    # RSI-14
    rsi_val = 0.5
    try:
        _rsi_scalar = compute_rsi(close_s, 14)  # returns float, not Series
        if _rsi_scalar is not None and not (isinstance(_rsi_scalar, float) and __import__('math').isnan(_rsi_scalar)):
            rsi_val = float(_rsi_scalar) / 100.0
    except Exception as _e2_:
        ExceptionLogger.swallow(_e2_, context="silent_catch")

    # Volume trend
    vtend = 0.0
    if volume_s is not None:
        # AUDIT-FIX (Round 5, 2-b-1): align the volume window to the CLOSE window
        # being scored. The old `volume_s.dropna().iloc[-window:]` always took
        # the final `window` bars of the full series, so every training window
        # received the SAME (end-of-sample) volume trend and 4 of 5 windows
        # embedded bars from after their own end — future data in the feature
        # vector and a per-ticker constant dominating the k-means distance.
        _vol_aligned = volume_s.reindex(close_s.index).dropna().iloc[-window:]
        vs = _vol_aligned.values.astype(np.float64) if len(_vol_aligned) > 0 else np.array([], dtype=np.float64)
        if len(vs) >= 10:
            h5 = float(vs[-5:].mean()) + 1e-6
            f5 = float(vs[:5].mean())  + 1e-6
            vtend = float(np.clip(np.log(h5 / f5), -3.0, 3.0))  # DIV001: guard divisor before use

    # OLS slope of normalised prices
    xs = np.arange(len(norm), dtype=np.float64)
    xs -= xs.mean()
    slope = float(np.dot(xs, norm) / (np.dot(xs, xs) + 1e-9))

    # Range ratio
    mean_p = float(w.mean()) + 1e-9
    range_ratio = float((hi - lo) / mean_p) if mean_p != 0 else 0.0  # DIV001 guarded  # DIV001: guard divisor before use

    vec = np.concatenate([norm,
                          np.array([rv, rsi_val, vtend, slope, range_ratio],
                                   dtype=np.float32)])
    return vec.astype(np.float32)

def ts_feature_vector_v2(closes: pd.Series, highs: pd.Series, lows: pd.Series,
                         volumes: pd.Series, opens: Optional[pd.Series] = None,
                         benchmark_series: Optional[pd.Series] = None,
                         window: int = 96) -> np.ndarray:
    """Extracts a rich 512-dimensional numerical feature vector from OHLCV data.

    Includes normalized price/volume series, multi-horizon returns, volatility structure,
    technical indicators (RSI, Bollinger, CMF, OBV), EMA compression, wick metrics,
    and relative strength vs benchmark. Zero-pads to exactly 512 dimensions.
    """
    def get_norm_series(s, win):
        arr = s.tail(win).to_numpy(dtype=np.float64)
        if len(arr) < win:
            arr = np.pad(arr, (win - len(arr), 0), 'edge')
        mn = arr.min()
        mx = arr.max()
        denom = mx - mn
        if denom < 1e-9:
            denom = 1e-9
        return (arr - mn) / denom

    closes_norm = get_norm_series(closes, window)
    highs_norm = get_norm_series(highs, window)
    lows_norm = get_norm_series(lows, window)
    volumes_norm = get_norm_series(volumes, window)

    # Multi-horizon returns
    log_rets = np.log(closes / closes.shift(1)).dropna()
    r1 = float(np.log(closes.iloc[-1] / closes.iloc[-2])) if len(closes) >= 2 else 0.0
    r3 = float(np.log(closes.iloc[-1] / closes.iloc[-4])) if len(closes) >= 4 else 0.0
    r5 = float(np.log(closes.iloc[-1] / closes.iloc[-6])) if len(closes) >= 6 else 0.0
    r10 = float(np.log(closes.iloc[-1] / closes.iloc[-11])) if len(closes) >= 11 else 0.0
    r20 = float(np.log(closes.iloc[-1] / closes.iloc[-21])) if len(closes) >= 21 else 0.0

    # Realized volatility structure
    v5 = float(log_rets.tail(5).std() * np.sqrt(TRADING_DAYS_PER_YEAR)) if len(log_rets) >= 5 else 0.0
    v10 = float(log_rets.tail(10).std() * np.sqrt(TRADING_DAYS_PER_YEAR)) if len(log_rets) >= 10 else 0.0
    v21 = float(log_rets.tail(21).std() * np.sqrt(TRADING_DAYS_PER_YEAR)) if len(log_rets) >= 21 else 0.0
    v63 = float(log_rets.tail(63).std() * np.sqrt(TRADING_DAYS_PER_YEAR)) if len(log_rets) >= 63 else 0.0

    # ATR Ratio
    prev_close = closes.shift(1)
    tr = pd.concat([highs - lows, (highs - prev_close).abs(), (lows - prev_close).abs()], axis=1).max(axis=1)
    atr14 = tr.ewm(alpha=1/14, min_periods=14, adjust=False).mean()
    atr28 = tr.ewm(alpha=1/28, min_periods=28, adjust=False).mean()
    atr_ratio = float(atr14.iloc[-1] / (atr28.iloc[-1] + 1e-9)) if len(tr) >= 28 else 1.0

    # OBV Slope
    obv = (np.sign(closes.diff()) * volumes).fillna(0).cumsum()
    obv_21 = obv.tail(21)
    if len(obv_21) >= 10:
        xo = np.arange(len(obv_21), dtype=float)
        obv_slope = float(np.polyfit(xo, obv_21.values, 1)[0]) / (volumes.tail(21).mean() + 1e-9)
    else:
        obv_slope = 0.0

    # Chaikin Money Flow
    cmf_val = 0.0
    if len(closes) >= 21:
        hl = highs - lows
        hl[hl < 1e-9] = 1e-9
        ad = ((closes - lows) - (highs - closes)) / hl * volumes
        cmf_val = float(ad.tail(21).sum() / (volumes.tail(21).sum() + 1e-9))

    # RSIs using true Wilder EWM
    def compute_rsi_wilder(series, period):
        delta = series.diff()
        gain = delta.clip(lower=0)
        loss = -delta.clip(upper=0)
        avg_gain = gain.ewm(alpha=1/period, min_periods=period, adjust=False).mean()
        avg_loss = loss.ewm(alpha=1/period, min_periods=period, adjust=False).mean()
        rs = avg_gain / (avg_loss + 1e-9)
        return float(100 - (100 / (1 + rs)).iloc[-1]) if len(series) >= period else 50.0

    rsi14 = compute_rsi_wilder(closes, 14) / 100.0
    rsi28 = compute_rsi_wilder(closes, 28) / 100.0

    # EMAs and MA Compression
    ema20 = closes.ewm(span=20, adjust=False).mean()
    ema50 = closes.ewm(span=50, adjust=False).mean()
    ema20_dist = float(closes.iloc[-1] / (ema20.iloc[-1] + 1e-9) - 1.0) if len(closes) >= 20 else 0.0
    ema50_dist = float(closes.iloc[-1] / (ema50.iloc[-1] + 1e-9) - 1.0) if len(closes) >= 50 else 0.0

    ema20_last = ema20.iloc[-1] if len(ema20) else 0.0
    ema50_last = ema50.iloc[-1] if len(ema50) else 0.0
    ma_compression = float(1.0 - abs(ema20_last / (ema50_last + 1e-9) - 1.0) / 0.08) if ema50_last != 0 else 0.0

    # Bollinger Bands
    sma20 = closes.rolling(20).mean()
    std20 = closes.rolling(20).std()
    bb_upper = sma20 + 2 * std20
    bb_lower = sma20 - 2 * std20
    bb_width = (bb_upper - bb_lower) / (sma20 + 1e-9)
    bb_pct = (closes - bb_lower) / (bb_upper - bb_lower + 1e-9)

    bb_width_val = float(bb_width.iloc[-1]) if len(bb_width) >= 20 and not pd.isna(bb_width.iloc[-1]) else 0.0
    bb_pct_val = float(bb_pct.iloc[-1]) if len(bb_pct) >= 20 and not pd.isna(bb_pct.iloc[-1]) else 0.5

    # Up/Down Volume Ratio
    updown_vol = 1.0
    if len(closes) >= 21:
        rd = closes.diff().tail(21)
        vd = volumes.tail(21)
        uv = float(vd[rd > 0].sum())
        dv = float(vd[rd < 0].sum())
        updown_vol = uv / (dv + 1e-9)

    # Trigger Persistence
    above20_frac = float((closes > ema20).tail(21).mean()) if len(closes) >= 21 else 0.5
    above50_frac = float((closes > ema50).tail(50).mean()) if len(closes) >= 50 else 0.5
    up_day_frac_21 = float((log_rets > 0).tail(21).mean()) if len(log_rets) >= 21 else 0.5

    # Wick/Body Ratios
    if opens is None:
        opens = closes.shift(1).fillna(closes)
    body = (closes - opens).abs()
    hl_range = highs - lows
    hl_range[hl_range < 1e-9] = 1e-9

    upper_wick = (highs - closes.combine(opens, max)) / hl_range
    lower_wick = (closes.combine(opens, min) - lows) / hl_range

    upper_wick_val = float(upper_wick.tail(10).mean()) if len(closes) >= 10 else 0.0
    lower_wick_val = float(lower_wick.tail(10).mean()) if len(closes) >= 10 else 0.0

    # Relative Strength Correlation vs Benchmark
    rs_corr = 0.0
    if benchmark_series is not None:
        try:
            s_ret = log_rets.tail(63)
            b_ret = np.log(benchmark_series / benchmark_series.shift(1)).dropna().tail(63)
            idx = s_ret.index.intersection(b_ret.index)
            if len(idx) >= 10:
                rs_corr = float(s_ret.loc[idx].corr(b_ret.loc[idx]))
        except Exception:
            rs_corr = 0.0

    features = np.concatenate([
        closes_norm,
        highs_norm,
        lows_norm,
        volumes_norm,
        [r1, r3, r5, r10, r20],
        [v5, v10, v21, v63],
        [atr_ratio, obv_slope, cmf_val],
        [rsi14, rsi28],
        [ema20_dist, ema50_dist, ma_compression],
        [bb_width_val, bb_pct_val],
        [updown_vol],
        [above20_frac, above50_frac, up_day_frac_21],
        [upper_wick_val, lower_wick_val],
        [rs_corr]
    ])

    # Pad to exactly 512 dimensions
    target_dim = 512
    if len(features) < target_dim:
        features = np.pad(features, (0, target_dim - len(features)), 'constant')
    else:
        features = features[:target_dim]

    return features.astype(np.float32)

def build_chart_tensor(ohlcv_df: pd.DataFrame,
                       benchmark_series: Optional[pd.Series] = None,
                       size: Tuple[int, int] = (224, 224),
                       channels: int = 4) -> np.ndarray:
    """Transforms raw OHLCV data into a multi-channel normalized tensor representation."""
    width = size[1]
    height = size[0]

    close = ohlcv_df["close"].tail(96).to_numpy(dtype=np.float32)
    volume = ohlcv_df["volume"].tail(96).to_numpy(dtype=np.float32)

    x_old = np.linspace(0, 1, len(close))
    x_new = np.linspace(0, 1, width)

    close_interp = np.interp(x_new, x_old, close)
    volume_interp = np.interp(x_new, x_old, volume)

    def norm(arr):
        mn, mx = arr.min(), arr.max()
        denom = mx - mn
        return (arr - mn) / (denom if denom > 1e-9 else 1e-9)

    c1 = norm(close_interp)
    c2 = norm(volume_interp)

    sma = ohlcv_df["close"].rolling(20).mean().tail(96).fillna(ohlcv_df["close"]).to_numpy(dtype=np.float32)
    sma_interp = np.interp(x_new, x_old, sma)
    c3 = norm(sma_interp)

    if benchmark_series is not None:
        # AUDIT-FIX (Round 5, 2-b-4): ffill() fills interior gaps only — a
        # benchmark starting later than the ticker leaves leading NaNs after
        # reindex, and norm() has no NaN guard, silently NaN-ing the whole 4th
        # channel. bfill() covers the leading edge.
        bench = benchmark_series.reindex(ohlcv_df.index).ffill().bfill().tail(96).to_numpy(dtype=np.float32)
        bench_interp = np.interp(x_new, x_old, bench)
        c4 = norm(close_interp / (bench_interp + 1e-9))
    else:
        hl = (ohlcv_df["high"] - ohlcv_df["low"]).tail(96).to_numpy(dtype=np.float32)
        hl_interp = np.interp(x_new, x_old, hl)
        c4 = norm(hl_interp)

    # AUDIT-FIX (Round 5, 2-b-6): channel 4 is written unconditionally below —
    # a channels=3 request crashed with IndexError. Validate up front.
    if channels < 4:
        raise ValueError(
            f"build_chart_tensor requires channels >= 4 (writes 4 channels), got channels={channels}"
        )

    tensor = np.zeros((channels, height, width), dtype=np.float32)
    for i in range(height):
        tensor[0, i, :] = c1
        tensor[1, i, :] = c2
        tensor[2, i, :] = c3
        tensor[3, i, :] = c4

    return tensor

def build_multitimeframe_input_bundle(data_dict: Dict[str, Dict[str, pd.DataFrame]],
                                     ticker: str,
                                     benchmark_series: Optional[pd.Series] = None,
                                     cfg: Optional[dict] = None) -> Dict[str, Dict[str, np.ndarray]]:
    """Builds visual tensors and temporal feature vectors for multiple timeframes."""
    tfs = ["1h", "4h", "1d", "1wk"]
    bundle = {}

    for tf in tfs:
        tf_data = data_dict.get(tf)
        if not tf_data:
            continue

        close_df = tf_data.get("Close")
        high_df = tf_data.get("High")
        low_df = tf_data.get("Low")
        volume_df = tf_data.get("Volume")
        open_df = tf_data.get("Open")

        if close_df is None or ticker not in close_df.columns:
            continue

        closes = close_df[ticker].dropna()
        highs = high_df[ticker].dropna() if high_df is not None and ticker in high_df.columns else closes
        lows = low_df[ticker].dropna() if low_df is not None and ticker in low_df.columns else closes
        volumes = volume_df[ticker].dropna() if volume_df is not None and ticker in volume_df.columns else pd.Series(0.0, index=closes.index)
        opens = open_df[ticker].dropna() if open_df is not None and ticker in open_df.columns else closes.shift(1).fillna(closes)

        common_idx = closes.index.intersection(highs.index).intersection(lows.index).intersection(volumes.index).intersection(opens.index)
        if len(common_idx) < 10:
            continue
        closes = closes.loc[common_idx]
        highs = highs.loc[common_idx]
        lows = lows.loc[common_idx]
        volumes = volumes.loc[common_idx]
        opens = opens.loc[common_idx]

        ts_feat = ts_feature_vector_v2(closes, highs, lows, volumes, opens, benchmark_series, window=96)
        ohlcv_df = pd.DataFrame({"close": closes, "high": highs, "low": lows, "volume": volumes, "open": opens})
        chart_tensor = build_chart_tensor(ohlcv_df, benchmark_series)

        bundle[tf] = {
            "image": chart_tensor,
            "ts": ts_feat
        }

    return bundle

def apply_score_calibration(raw_score: float, context_key: str) -> float:
    """Calibrates a raw cosine similarity score to a probability estimate.

    AUDIT-FIX (defect #17, ViT-untrained guard):
    The audit confirmed that the shipped ViT chart model has untrained random
    weights (LayerNorm weights exactly 1.0, positional embeddings and CLS
    token exactly zero, convolution/linear weights at their PyTorch default
    init bounds). The previous "dynamic calibration for dummy/untrained model
    outputs (around 0.12)" branch below was a hand-tuned sigmoid that laundered
    noise-level cosine similarity (≈0.12) into 0.5-ish "probabilities" which
    then flowed into chart_pattern_cohesion / z_chart_pattern alpha factors.

    Going forward, this function returns NaN when the raw score is in the
    noise band (|raw_score - 0.12| < 0.15) UNLESS the operator has explicitly
    opted into the untrained model via cfg flag USE_UNTRAINED_VIT=true. The
    NaN propagates into the signal frame as chart_pattern_cohesion=NaN, which
    downstream factor blending skips (NaN-weighted contributions evaluate to 0
    in the standard sum). This stops random-network outputs from influencing
    portfolio selection.
    """
    # AUDIT-FIX (defect #17): noise-band guard. The audit found that the
    # shipped ViT's raw cosine similarities cluster around 0.12 (random
    # projections of normalized vectors). When the input falls in this band
    # and the operator has not opted into using the untrained model, return
    # NaN so downstream factor blending treats the chart signal as missing.
    import os as _os
    _allow_untrained = _os.environ.get("USE_UNTRAINED_VIT", "0").strip().lower() in ("1", "true", "yes")
    if not _allow_untrained and abs(raw_score - 0.12) < 0.15:
        return float("nan")
    # AUDIT-FIX (Round 5, 2-b-3): gate the legacy steep band on the opt-in flag,
    # matching its own comment. Ungated, raw scores in [0.27, 0.30) fell through
    # the noise guard into k=50/x0=0.12 — a ~22,000× calibration cliff at the
    # 0.30 boundary (0.299999→0.99988 vs 0.300000→0.00005) and weak 0.28
    # similarities calibrated to ~99.97% "probability".
    if _allow_untrained and raw_score < 0.30:
        # Legacy band — retained for back-compat when explicitly opted in.
        k, x0 = 50.0, 0.12
    else:
        params = {
            "breakout": (20.0, 0.80),
            "prebreakout": (15.0, 0.78),
            "failed_breakout": (18.0, 0.82),
            "distribution": (15.0, 0.80),
            "mean_reversion_trap": (16.0, 0.81),
        }
        k, x0 = params.get(context_key, (18.0, 0.80))

    p = 1.0 / (1.0 + np.exp(-k * (raw_score - x0)))
    return float(np.clip(p, 0.0, 1.0))

def _build_live_chart_ssl_model(data: dict, tickers: list, cfg: dict, log_cb=None) -> dict | None:
    """I1-fix: 1-D time-series clustering — replaces the pixel-rendering approach.
    Clusters normalised 30-bar price windows directly; ~100x less memory than image K-Means.
    No PIL dependency required."""
    if not HAS_SKLEARN_CLUSTER:
        return None
    window     = int(cfg.get("CHART_TS_WINDOW", 30))
    n_clusters = int(cfg.get("CHART_IMAGE_N_CLUSTERS", 24))
    step       = max(1, window // 2)
    close_df   = data.get("Close")
    volume_df  = data.get("Volume")
    if close_df is None or close_df.empty:
        return None

    feats: list[np.ndarray] = []
    for ticker in tickers:
        if ticker not in close_df.columns:
            continue
        cs = close_df[ticker].dropna()
        vs = volume_df[ticker].dropna() if (volume_df is not None and ticker in volume_df.columns) else None
        total = len(cs)
        for end in range(total, max(total - window * 8, window), -step):
            vec = _ts_feature_vector(cs.iloc[max(0, end - window): end], vs, window=window)
            if vec is not None:
                feats.append(vec)

    min_needed = max(n_clusters * 5, 50)
    if len(feats) < min_needed:
        log_emit(log_cb, f"[ChartSSL] 1-D model: only {len(feats)}/{min_needed} vectors — insufficient.")
        return None

    x  = np.vstack(feats).astype(np.float32)
    k  = max(4, min(n_clusters, len(x) // 8))
    km = _MiniBatchKMeans(n_clusters=k, random_state=int(cfg.get("SEED", 42)),
                          batch_size=min(1024, len(x)), n_init=3)
    labels = km.fit_predict(x)
    dists  = np.linalg.norm(x - km.cluster_centers_[labels], axis=1)
    dist_scale = float(np.median(dists) + 1e-6)
    log_emit(log_cb, f"[ChartSSL] 1-D model built: {k} prototypes from {len(x):,} "
                     f"time-series windows (memory-efficient, no image rendering).")
    return {
        "centers":        km.cluster_centers_.astype(np.float32),
        "distance_scale": dist_scale,
        "sample_count":   len(x),
        "corpus_count":   len(tickers),
        "timeframe":      cfg.get("CHART_IMAGE_TIMEFRAME", "live"),
        "root":           "live",
        "model_type":     "timeseries",   # sentinel: skip image rendering in score step
    }

def compute_chart_ssl_features(data, tickers: list, cfg=None, log_cb=None) -> pd.DataFrame:
    # v17-fix: FORCE 1D time-series model unconditionally.
    # Bypasses load_or_build_chart_ssl_model which scans the local Dataset/Unlabeled
    # PNG folder and triggers the 69-min image-encoding loop whenever those files exist.
    # The 1D OHLCV clustering is 100x faster and equally effective for live scoring.
    _tf_cache_key = str((cfg or {}).get("CHART_IMAGE_TIMEFRAME", "1d")).lower()
    if _tf_cache_key in _CHART_SSL_MODEL_CACHE:
        model = _CHART_SSL_MODEL_CACHE.get(_tf_cache_key)  # v17-patch: reuse, skip rebuild
    else:
        model = _build_live_chart_ssl_model(data, tickers, cfg=cfg or {}, log_cb=log_cb)
        if model is not None:
            _CHART_SSL_MODEL_CACHE.set(_tf_cache_key, model)  # cache for remaining timeframes

    if model is None:
        log_emit(log_cb, "[ChartSSL] Live model build failed — chart features neutral (0).")
        return pd.DataFrame(index=tickers)

    rows   = {}
    bars   = int((cfg or {}).get("CHART_IMAGE_WINDOW_BARS", 96))
    centers = np.asarray(model["centers"], dtype=np.float32)
    scale   = float(model.get("distance_scale", 1.0) or 1.0)

    # I1-fix: 1-D ts path — no image rendering, 100x less memory
    if model.get("model_type") == "timeseries":
        ts_window = int((cfg or {}).get("CHART_TS_WINDOW", 30))
        close_df  = data.get("Close")
        volume_df = data.get("Volume")
        for ticker in tickers:
            check_stop()
            if close_df is None or ticker not in close_df.columns:
                continue
            cs  = close_df[ticker].dropna()
            vs  = (volume_df[ticker].dropna()
                   if volume_df is not None and ticker in volume_df.columns
                   else None)
            vec = _ts_feature_vector(cs, vs, window=ts_window)
            if vec is None:
                continue
            vec = vec.astype(np.float32)
            td  = centers.shape[1]
            if vec.shape[0] != td:
                log_emit(log_cb, f"[WARN] ChartSSL vector size ({vec.shape[0]}) mismatches model centers ({td}). Aligning dynamically.")
            if vec.shape[0] < td:
                vec = np.pad(vec, (0, td - vec.shape[0]))
            elif vec.shape[0] > td:
                vec = vec[:td]
            dists = np.linalg.norm(centers - vec[np.newaxis, :], axis=1)
            dn    = dists / (scale + 1e-9)
            order = np.sort(dn)
            rows[ticker] = {
                "chart_pattern_cohesion": float(np.exp(-float(order[0]))),
                "chart_pattern_novelty":  float(order[0]),
                "chart_pattern_margin":   float(order[1] - order[0]) if len(order) > 1 else 0.0,
                "chart_pattern_cluster":  int(np.argmin(dists)),
            }
        if rows:
            out = pd.DataFrame.from_dict(rows, orient="index")
            out["z_chart_pattern"] = robust_zscore_series(out["chart_pattern_cohesion"])
            out["z_chart_novelty"] = robust_zscore_series(out["chart_pattern_novelty"])
            out["z_chart_margin"]  = robust_zscore_series(out["chart_pattern_margin"])
            log_emit(log_cb, f"[ChartSSL] 1-D ts: scored {len(rows)} tickers ({len(centers)} clusters).")
            return out
        return pd.DataFrame(index=tickers)

    # v17_fast-70 I1-fix: Remove 2D image rendering entirely.
    # All models — online/offline alike — are scored via the 1D ts vector path.
    # Eliminates PIL/matplotlib memory pressure and the >60-min bottleneck.
    ts_window = int((cfg or {}).get("CHART_TS_WINDOW", 30))
    close_df  = data.get("Close")
    volume_df = data.get("Volume")
    for ticker in tickers:
        check_stop()
        if close_df is None or ticker not in close_df.columns:
            continue
        cs  = close_df[ticker].dropna()
        vs  = (volume_df[ticker].dropna()
               if volume_df is not None and ticker in volume_df.columns
               else None)
        vec = _ts_feature_vector(cs, vs, window=ts_window)
        if vec is None:
            continue
        vec = vec.astype(np.float32)
        td  = centers.shape[1]
        if vec.shape[0] != td:
            log_emit(log_cb, f"[WARN] ChartSSL vector size ({vec.shape[0]}) mismatches model centers ({td}). Aligning dynamically.")
        if vec.shape[0] < td:
            vec = np.pad(vec, (0, td - vec.shape[0]))
        elif vec.shape[0] > td:
            vec = vec[:td]
        d     = np.linalg.norm(centers - vec[np.newaxis, :], axis=1)
        dn    = d / (scale + 1e-9)
        order = np.sort(dn)
        rows[ticker] = {
            "chart_pattern_cohesion": float(np.exp(-float(order[0]))),
            "chart_pattern_novelty":  float(order[0]),
            "chart_pattern_margin":   float(order[1] - order[0]) if len(order) > 1 else 0.0,
            "chart_pattern_cluster":  int(np.argmin(d)),
        }

    if not rows:
        log_emit(log_cb, "[ChartSSL] No tickers produced valid 1-D feature vectors (chart features neutral).")
        return pd.DataFrame(index=tickers)

    out = pd.DataFrame.from_dict(rows, orient="index")
    out["z_chart_pattern"] = robust_zscore_series(out["chart_pattern_cohesion"])
    out["z_chart_novelty"] = robust_zscore_series(out["chart_pattern_novelty"])
    out["z_chart_margin"] = robust_zscore_series(out["chart_pattern_margin"])
    out.attrs["chart_model_info"] = {
        "kind": model.get("kind", "online"),
        "timeframe": model.get("timeframe", str((cfg or {}).get("CHART_IMAGE_TIMEFRAME", "1d")).lower()),
        "sample_count": int(model.get("sample_count", 0) or 0),
        "corpus_count": int(model.get("corpus_count", 0) or 0),
        "clusters": int(len(centers)),
        "artifact_path": str(model.get("artifact_path", "")),
    }
    log_emit(log_cb, f"[ChartSSL] Scored {len(out)} live tickers against {len(centers)} image archetypes.")
    return out


# Re-export the moved names so `from <new_module> import X` works
__all__ = [
    '_pool_mean_fixed',
    '_chart_image_embedding_from_array',
    '_chart_image_embedding_from_file',
    '_apply_chart_embedding_projection',
    '_load_offline_chart_model',
    '_sample_chart_image_paths',
    'load_or_build_chart_ssl_model',
    '_get_sweep_chart_ticker_lock',
    'compute_multi_timeframe_chart_features',
    '_ts_feature_vector',
    'ts_feature_vector_v2',
    'build_chart_tensor',
    'build_multitimeframe_input_bundle',
    'apply_score_calibration',
    '_build_live_chart_ssl_model',
    'compute_chart_ssl_features',
]


# AUDIT-FIX (Round 3, P2-4 follow-up): appended cluster

def build_factor_summary(portfolio_df):
    if portfolio_df is None or portfolio_df.empty:
        return pd.DataFrame()

    weights = portfolio_df["Weight %"].astype(float)
    factors = [
        ("GrowthFactor", "Growth"),
        ("TrendFactor", "Trend"),
        ("LiquidityFactor", "Liquidity"),
        ("QualityFactor", "Quality"),
        ("SectorLeadFactor", "Sector Leadership"),
        ("ChartPatternZ", "Chart Pattern"),
        ("ChartNoveltyZ", "Chart Novelty"),
    ]
    rows = []
    for col, label in factors:
        if col not in portfolio_df.columns:
            continue
        series = portfolio_df[col].astype(float)
        rows.append({
            "Factor": label,
            "WeightedExposure": float((weights * series).sum()),
            "AverageHoldingScore": float(series.mean()),
            "TopContributor": portfolio_df.loc[series.idxmax(), "Ticker"] if not series.empty and series.notna().any() else "",
            "BottomContributor": portfolio_df.loc[series.idxmin(), "Ticker"] if not series.empty and series.notna().any() else "",
        })
    if "RiskScore" in portfolio_df.columns:
        risk_series = portfolio_df["RiskScore"].astype(float)
        rows.append({
            "Factor": "Risk Load",
            "WeightedExposure": float((weights * risk_series).sum()),
            "AverageHoldingScore": float(risk_series.mean()),
            "TopContributor": portfolio_df.loc[risk_series.idxmax(), "Ticker"] if not risk_series.empty and risk_series.notna().any() else "",
            "BottomContributor": portfolio_df.loc[risk_series.idxmin(), "Ticker"] if not risk_series.empty and risk_series.notna().any() else "",
        })
    return pd.DataFrame(rows)

def build_exposures_summary(portfolio_df, benchmark_symbol, regime_info):
    if portfolio_df is None or portfolio_df.empty:
        return pd.DataFrame()

    weights = portfolio_df["Weight %"].astype(float)
    rows = []
    exposure_specs = [
        ("Weighted Beta", float((weights * portfolio_df["Beta"].fillna(1.0).astype(float)).sum()) if "Beta" in portfolio_df.columns else np.nan, 1.0),
        ("Annualized Vol", float((weights * portfolio_df["AnnVol"].fillna(0.0).astype(float)).sum()) if "AnnVol" in portfolio_df.columns else np.nan, np.nan),
        ("Alpha Score", float((weights * portfolio_df["AlphaScore"].fillna(0.0).astype(float)).sum()) if "AlphaScore" in portfolio_df.columns else np.nan, np.nan),
        ("Risk Score", float((weights * portfolio_df["RiskScore"].fillna(0.0).astype(float)).sum()) if "RiskScore" in portfolio_df.columns else np.nan, np.nan),
        ("1M Momentum", float((weights * portfolio_df["Mom1M"].fillna(0.0).astype(float)).sum()) if "Mom1M" in portfolio_df.columns else np.nan, np.nan),
        ("6M Momentum", float((weights * portfolio_df["Mom6M"].fillna(0.0).astype(float)).sum()) if "Mom6M" in portfolio_df.columns else np.nan, np.nan),
        ("Sector RS 1M", float((weights * portfolio_df["SectorRS1M"].fillna(0.0).astype(float)).sum()) if "SectorRS1M" in portfolio_df.columns else np.nan, 0.0),
        ("Sector RS 6M", float((weights * portfolio_df["SectorRS6M"].fillna(0.0).astype(float)).sum()) if "SectorRS6M" in portfolio_df.columns else np.nan, 0.0),
    ]
    for metric, value, benchmark in exposure_specs:
        rows.append({
            "Metric": metric,
            "Portfolio": value,
            "Benchmark": benchmark,
            "Active": value - benchmark if pd.notna(value) and pd.notna(benchmark) else np.nan,
        })

    rows.append({"Metric": "Benchmark Symbol", "Portfolio": benchmark_symbol, "Benchmark": "", "Active": ""})
    rows.append({"Metric": "Market Regime", "Portfolio": regime_info.get("Regime", "Unknown"), "Benchmark": "", "Active": ""})
    return pd.DataFrame(rows)

def build_selection_changes(selected, portfolio_df, previous_state):
    current = set(selected or [])
    previous = set(previous_state.get("selected", []) or [])
    added = sorted(current - previous)
    removed = sorted(previous - current)
    stayed = sorted(current & previous)
    prev_weights = previous_state.get("weights", {}) or {}
    curr_weights = {}
    if portfolio_df is not None and not portfolio_df.empty:
        curr_weights = {str(r["Ticker"]): float(r["Weight %"]) for _, r in portfolio_df.iterrows()}

    rows = []
    for ticker in added:
        rows.append({"Ticker": ticker, "Status": "Added", "PreviousWeight": prev_weights.get(ticker), "CurrentWeight": curr_weights.get(ticker), "WeightChange": curr_weights.get(ticker, 0.0)})
    for ticker in removed:
        rows.append({"Ticker": ticker, "Status": "Removed", "PreviousWeight": prev_weights.get(ticker), "CurrentWeight": np.nan, "WeightChange": -float(prev_weights.get(ticker, 0.0) or 0.0)})
    for ticker in stayed:
        prev_w = float(prev_weights.get(ticker, 0.0) or 0.0)
        curr_w = float(curr_weights.get(ticker, 0.0) or 0.0)
        delta = curr_w - prev_w
        if abs(delta) >= 0.01:
            status = "Weight Up" if delta > 0 else "Weight Down"
        else:
            status = "Unchanged"
        rows.append({"Ticker": ticker, "Status": status, "PreviousWeight": prev_w, "CurrentWeight": curr_w, "WeightChange": delta})

    changes_df = pd.DataFrame(rows)
    if not changes_df.empty:
        status_order = {"Added": 0, "Removed": 1, "Weight Up": 2, "Weight Down": 3, "Unchanged": 4}
        changes_df["_order"] = changes_df["Status"].map(status_order).fillna(99)
        changes_df = changes_df.sort_values(["_order", "Ticker"]).drop(columns="_order").reset_index(drop=True)
    summary = {
        "added": len(added),
        "removed": len(removed),
        "up": int((changes_df["Status"] == "Weight Up").sum()) if not changes_df.empty else 0,
        "down": int((changes_df["Status"] == "Weight Down").sum()) if not changes_df.empty else 0,
        "unchanged": int((changes_df["Status"] == "Unchanged").sum()) if not changes_df.empty else 0,
    }
    return changes_df, summary

def build_alerts(payload):
    alerts = []
    health = payload.get("portfolio_health", {}) or {}
    cfg = payload.get("cfg", {}) or {}
    regime = payload.get("regime_info", {}).get("Regime", "Unknown")
    changes = payload.get("selection_change_summary", {}) or {}
    bt = payload.get("backtest") or {}

    top_weight = health.get("TopWeight")
    if pd.notna(top_weight) and top_weight > min(0.18, float(cfg.get("MAX_WEIGHT", 1.0)) + 0.02):
        alerts.append({"Severity": "High", "Category": "Concentration", "Message": f"Top position is elevated at {top_weight:.1%}."})

    largest_sector = health.get("LargestSectorWeight")
    if pd.notna(largest_sector) and largest_sector > 0.35:
        alerts.append({"Severity": "High", "Category": "Sector Risk", "Message": f"Largest sector carries {largest_sector:.1%} of capital."})  # decimal→% display

    active_beta = health.get("ActiveBeta")
    if pd.notna(active_beta) and abs(active_beta) > 0.20:
        alerts.append({"Severity": "Medium", "Category": "Benchmark Drift", "Message": f"Active beta is {active_beta:+.2f} versus benchmark."})

    effective_n = health.get("EffectiveNames")
    if pd.notna(effective_n) and effective_n < max(4.0, float(cfg.get("K_STOCKS", 0)) * 0.7):
        alerts.append({"Severity": "Medium", "Category": "Diversification", "Message": f"Effective diversification is thin at {effective_n:.1f} names."})  # 1dp sufficient

    if regime in {"Risk-Off Stress", "Transitional"} and payload.get("cfg", {}).get("REGIME_FILTER") == "Risk-On Bias":
        alerts.append({"Severity": "Medium", "Category": "Regime", "Message": f"Portfolio is being forced into a risk-on stance during a {regime} market."})

    if changes.get("added", 0) >= max(3, int(cfg.get("K_STOCKS", 0) * 0.4)):
        alerts.append({"Severity": "Low", "Category": "Turnover", "Message": f"Run introduced {changes.get('added', 0)} new names versus the prior snapshot."})

    if bt:
        mdd = bt.get("Max Drawdown")
        sharpe = bt.get("Sharpe")
        tracking_error = bt.get("Tracking Error")
        if pd.notna(mdd) and mdd < -0.20:
            alerts.append({"Severity": "High", "Category": "Backtest", "Message": f"Walk-forward max drawdown reached {mdd:.1%}."})
        if pd.notna(sharpe) and sharpe < 0.5:
            alerts.append({"Severity": "Medium", "Category": "Backtest", "Message": f"Walk-forward Sharpe is weak at {sharpe:.2f}."})
        if pd.notna(tracking_error) and tracking_error > 0.20:
            alerts.append({"Severity": "Low", "Category": "Tracking Error", "Message": f"Tracking error is elevated at {tracking_error:.1%}."})

    if not alerts:
        alerts.append({"Severity": "Info", "Category": "Health", "Message": "No major portfolio health flags were triggered on this run."})

    return pd.DataFrame(alerts)

def build_diagnostics_frame(payload, regime_info):
    health = payload.get("portfolio_health", {})
    rows = []
    def _add(section, metric, value):
        rows.append({"Section": section, "Metric": metric, "Value": value})

    for metric, value in [
        ("Energy", payload["energy"]),
        ("Risk Model", payload["cfg"]["RISK_MODEL"]),
        ("Optimizer Mode", payload["cfg"]["OPTIMIZER_MODE"]),
        ("Benchmark", payload["benchmark_symbol"]),
        ("QUBO Terms", payload["qubo_terms"]),
        ("Resolved Sectors", payload["resolved_sectors"]),
    ]:
        _add("Run Setup", metric, value)

    for metric, value in [
        ("Regime", regime_info.get("Regime", "Unknown")),
        ("Regime Blend [-1,+1]", round(regime_info.get("RegimeBlend", float("nan")), 3)),
        ("P(Bull)", round(regime_info.get("P_Bull", float("nan")), 3)),
        ("P(Sideways)", round(regime_info.get("P_Sideways", float("nan")), 3)),
        ("P(Bear)", round(regime_info.get("P_Bear", float("nan")), 3)),
        ("Market Breadth", regime_info.get("Breadth", "N/A")),
        ("Dispersion", regime_info.get("Dispersion", "N/A")),
        ("Benchmark Trend 63D", regime_info.get("BenchmarkTrend", "N/A")),
    ]:
        _add("Market Regime", metric, value)

    for metric, value in [
        ("Top Weight", health.get("TopWeight", np.nan)),
        ("Effective Names", health.get("EffectiveNames", np.nan)),
        ("Largest Sector Weight", health.get("LargestSectorWeight", np.nan)),
        ("Weighted Beta", health.get("WeightedBeta", np.nan)),
        ("Active Beta", health.get("ActiveBeta", np.nan)),
        ("Weighted Alpha", health.get("WeightedAlpha", np.nan)),
        ("Weighted Risk", health.get("WeightedRisk", np.nan)),
        ("Ex-Ante Volatility %", health.get("Ex-Ante Volatility %", np.nan)),
        ("Factor Risk %", health.get("Factor Risk %", np.nan)),
        ("Specific Risk %", health.get("Specific Risk %", np.nan)),
        ("Active Share %", health.get("Active Share %", np.nan)),
        ("Diversification Ratio", health.get("Diversification Ratio", np.nan)),
        ("Risk Entropy (Normalized)", health.get("Risk Entropy (Normalized)", np.nan)),
    ]:
        _add("Portfolio Health", metric, value)

    for metric, value in [
        ("Selection Adds", payload.get("selection_change_summary", {}).get("added", 0)),
        ("Selection Removes", payload.get("selection_change_summary", {}).get("removed", 0)),
    ]:
        _add("Selection Changes", metric, value)

    pt = payload.get("post_trade_df")
    if pt is not None and not pt.empty:
        latest = pt.iloc[-1]
        _add("Post-Trade Validation", "PostTrade IC (last validated)", latest.get("Realized IC", float("nan")))
        _add("Post-Trade Validation", "PostTrade Hit Rate % (last)", latest.get("Hit Rate (%)", float("nan")))
        _add("Post-Trade Validation", "PostTrade TopQ Ret % (last)", latest.get("Top-Q Ret (%)", float("nan")))

    chart_info = payload.get("chart_model_info", {}) or {}
    portfolio_df = payload.get("portfolio_df")
    prescreen_df = payload.get("prescreen_df")
    if chart_info:
        _add("Chart Ensemble", "Chart Model Kind", chart_info.get("kind", "n/a"))
        if chart_info.get("kind") == "ensemble":
            _add("Chart Ensemble", "Chart Ensemble Timeframes", ",".join(chart_info.get("timeframes", [])))
            models = chart_info.get("models", []) or []
            for model in models:
                tf = str(model.get("timeframe", "n/a"))
                _add("Chart Ensemble", f"Chart {tf} Samples", int(model.get("sample_count", 0) or 0))
                _add("Chart Ensemble", f"Chart {tf} Corpus", int(model.get("corpus_count", 0) or 0))
                _add("Chart Ensemble", f"Chart {tf} Clusters", int(model.get("clusters", 0) or 0))
                _add("Chart Ensemble", f"Chart {tf} Weight", round(float(model.get("weight", 0.0) or 0.0), 3))
        else:
            _add("Chart Ensemble", "Chart Timeframe", chart_info.get("timeframe", "n/a"))
            _add("Chart Ensemble", "Chart Samples", int(chart_info.get("sample_count", 0) or 0))
            _add("Chart Ensemble", "Chart Corpus", int(chart_info.get("corpus_count", 0) or 0))
            _add("Chart Ensemble", "Chart Clusters", int(chart_info.get("clusters", 0) or 0))

    if isinstance(portfolio_df, pd.DataFrame) and not portfolio_df.empty:
        for col, label in [
            ("ChartPatternZ", "Portfolio Chart Pattern Z"),
            ("ChartNoveltyZ", "Portfolio Chart Novelty Z"),
            ("ChartMarginZ", "Portfolio Chart Margin Z"),
            ("ChartDispersion", "Portfolio Chart Dispersion"),
            ("ChartAgreement", "Portfolio Chart Agreement"),
        ]:
            if col in portfolio_df.columns:
                s = pd.to_numeric(portfolio_df[col], errors="coerce").dropna()
                if not s.empty:
                    _add("Chart Portfolio", label, round(float(s.mean()), 4))

    if isinstance(prescreen_df, pd.DataFrame) and not prescreen_df.empty:
        selected = set(payload.get("selected", []) or [])
        if selected and "ticker" in prescreen_df.columns:
            sel_df = prescreen_df[prescreen_df["ticker"].isin(selected)].copy()
        else:
            sel_df = pd.DataFrame()
        if not sel_df.empty:
            for tf in ("1h", "4h", "1d", "1wk"):
                for col, label in [
                    (f"z_chart_pattern_{tf}", f"Selected {tf} Pattern Z"),
                    (f"z_chart_novelty_{tf}", f"Selected {tf} Novelty Z"),
                    (f"z_chart_margin_{tf}", f"Selected {tf} Margin Z"),
                ]:
                    if col in sel_df.columns:
                        s = pd.to_numeric(sel_df[col], errors="coerce").dropna()
                        if not s.empty:
                            _add("Chart Votes", label, round(float(s.mean()), 4))
    return pd.DataFrame(rows)

def build_correlation_matrix(returns, method="PCA Factor (5)", shrinkage=0.25, cfg=None, signal_df=None):
    if signal_df is None and cfg is not None:
        signal_df = cfg.get("_SIGNAL_DF")
    ret_array = returns.fillna(0).values
    
    # ── v17-patch: wire EWMA and Ledoit-Wolf — both were silently dropped before ──
    if method == "EWMA":
        try:
            lam = float((cfg or {}).get("EWMA_LAMBDA", 0.94))
            return build_ewma_correlation(returns, lam=lam)
        except Exception as _e_:
            ExceptionLogger.swallow(_e_, context="silent_catch")  # fall through to PCA on any error
            
    if "Ledoit-Wolf" in method:
        try:
            if HAS_SKLEARN:
                lw = _LedoitWolf()
                lw.fit(returns.fillna(0).values)
                cov_lw = lw.covariance_
            else:
                cov_lw = ledoit_wolf_shrinkage_numpy(returns.fillna(0).values)
            std_lw = np.sqrt(np.diag(cov_lw))
            std_lw[std_lw < 1e-12] = 1e-12
            corr_lw = cov_lw / np.outer(std_lw, std_lw)
            np.fill_diagonal(corr_lw, 1.0)
            corr_lw = np.clip(corr_lw, -1.0, 1.0)
            # Sovereign Tier-0: Marchenko-Pastur RMT spectral denoising pass
            _T_ret, _N_ret = returns.shape
            corr_lw = denoise_covariance_rmt(corr_lw, _T_ret, _N_ret)
            base_corr = pd.DataFrame(corr_lw, index=returns.columns, columns=returns.columns)
        except Exception as _e_:
            try:
                cov_lw = ledoit_wolf_shrinkage_numpy(returns.fillna(0).values)
                std_lw = np.sqrt(np.diag(cov_lw))
                std_lw[std_lw < 1e-12] = 1e-12
                corr_lw = cov_lw / np.outer(std_lw, std_lw)
                np.fill_diagonal(corr_lw, 1.0)
                corr_lw = np.clip(corr_lw, -1.0, 1.0)
                base_corr = pd.DataFrame(corr_lw, index=returns.columns, columns=returns.columns)
            except Exception as _e2_:
                base_corr = returns.corr().fillna(0.0)
                
    elif "Oracle" in method or "OAS" in method:
        try:
            cov_oas = oas_shrinkage_numpy(returns.fillna(0).values)
            std_oas = np.sqrt(np.diag(cov_oas))
            std_oas[std_oas < 1e-12] = 1e-12
            corr_oas = cov_oas / np.outer(std_oas, std_oas)
            np.fill_diagonal(corr_oas, 1.0)
            corr_oas = np.clip(corr_oas, -1.0, 1.0)
            _T_ret, _N_ret = returns.shape
            corr_oas = denoise_covariance_rmt(corr_oas, _T_ret, _N_ret)
            base_corr = pd.DataFrame(corr_oas, index=returns.columns, columns=returns.columns)
        except Exception as _e_:
            base_corr = returns.corr().fillna(0.0)
            
    elif "RMT" in method or "Denoised" in method:
        try:
            T, N = returns.shape
            raw_corr = returns.corr().fillna(0.0).values
            denoised_c = denoise_covariance_rmt(raw_corr, T, N)
            base_corr = pd.DataFrame(denoised_c, index=returns.columns, columns=returns.columns)
        except Exception as _e_:
            base_corr = returns.corr().fillna(0.0)
            
    elif "Barra" in method:
        try:
            from math_engine.factor_risk import FactorRiskDecomposer
            decomposer = FactorRiskDecomposer()
            if signal_df is not None:
                exposures = decomposer.compute_factor_exposures(signal_df)
                stocks = [s for s in returns.columns if s in exposures.index]
                if len(stocks) >= 4:
                    B = exposures.loc[stocks].to_numpy(dtype=np.float32)
                    clean_rets = returns[stocks].fillna(0.0).to_numpy(dtype=np.float32)
                    Sigma = np.cov(clean_rets, rowvar=False)
                    if Sigma.ndim == 0:
                        Sigma = Sigma.reshape(1, 1)
                    B_pinv = np.linalg.pinv(B)
                    factor_returns = clean_rets @ B_pinv.T
                    F = np.cov(factor_returns, rowvar=False)
                    if F.ndim == 0:
                        F = F.reshape(1, 1)
                    Sigma_factor = B @ F @ B.T
                    specific_variances = np.diag(Sigma) - np.diag(Sigma_factor)
                    specific_variances = np.clip(specific_variances, 1e-8, None)
                    D = np.diag(specific_variances)
                    Sigma_recon = Sigma_factor + D
                    std_recon = np.sqrt(np.diag(Sigma_recon))
                    std_recon[std_recon < 1e-12] = 1e-12
                    corr_recon = Sigma_recon / np.outer(std_recon, std_recon)
                    np.fill_diagonal(corr_recon, 1.0)
                    corr_recon = np.clip(corr_recon, -1.0, 1.0)
                    base_corr = pd.DataFrame(corr_recon, index=stocks, columns=stocks)
                    base_corr = base_corr.reindex(index=returns.columns, columns=returns.columns).fillna(0.0)
                    np.fill_diagonal(base_corr.values, 1.0)
                else:
                    base_corr = returns.corr().fillna(0.0)
            else:
                base_corr = returns.corr().fillna(0.0)
        except Exception:
            base_corr = returns.corr().fillna(0.0)
            
    elif "Semi-Covariance" in method or "Downside" in method:
        try:
            # Downside returns (clip positive returns to 0.0)
            downside_rets = np.minimum(ret_array, 0.0)
            T, N = downside_rets.shape
            # Semi-covariance
            semi_cov = np.dot(downside_rets.T, downside_rets) / (T - 1)
            # Convert to semi-correlation
            std_semi = np.sqrt(np.diag(semi_cov))
            std_semi[std_semi < 1e-12] = 1e-12
            corr_semi = semi_cov / np.outer(std_semi, std_semi)
            np.fill_diagonal(corr_semi, 1.0)
            corr_semi = np.clip(corr_semi, -1.0, 1.0)
            base_corr = pd.DataFrame(corr_semi, index=returns.columns, columns=returns.columns)
        except Exception as _e_:
            base_corr = returns.corr().fillna(0.0)
            
    elif "PCA" in method:
        try: n_factors = int(''.join(filter(str.isdigit, method)))
        except Exception as _e:
            n_factors = 5
        
        if ret_array.shape[1] < n_factors:
            base_corr = returns.corr().fillna(0.0)
        else:
            corr_raw = np.corrcoef(ret_array, rowvar=False)
            corr_raw = np.nan_to_num(corr_raw, copy=False, nan=0.0, posinf=0.0, neginf=0.0)
            np.fill_diagonal(corr_raw, 1.0)
            
            eigenvalues, eigenvectors = np.linalg.eigh(corr_raw)
            idx = np.argsort(eigenvalues)[::-1]
            eigenvalues = eigenvalues[idx]
            eigenvectors = eigenvectors[:, idx]
            eigenvalues[eigenvalues < 0] = 0
            
            factor_loadings = eigenvectors[:, :n_factors] * np.sqrt(eigenvalues[:n_factors])
            approx_corr = np.dot(factor_loadings, factor_loadings.T)
            np.fill_diagonal(approx_corr, 1.0)
            base_corr = pd.DataFrame(approx_corr, index=returns.columns, columns=returns.columns)
    else:
        base_corr = returns.corr().fillna(0.0)
        
    if "Ledoit-Wolf" in method or "Oracle" in method or "OAS" in method:
        # Shrinkage toward identity/target is already applied inside the estimator
        vals = base_corr.values.copy()
    else:
        # For raw/PCA/semi-covariance bases, shrink toward the average-correlation target
        off = base_corr.values.copy()
        np.fill_diagonal(off, np.nan)
        avg_r = float(np.nanmean(off)) if np.isfinite(off).any() else 0.0
        vals = (1.0 - shrinkage) * base_corr.values + shrinkage * (
            avg_r * (1.0 - np.eye(len(base_corr))) + np.eye(len(base_corr)))
    vals = np.clip(vals, -1.0, 1.0)
    np.fill_diagonal(vals, 1.0)
    return pd.DataFrame(vals, index=base_corr.index, columns=base_corr.columns)

def build_ewma_correlation(returns: pd.DataFrame, lam: float = 0.94) -> pd.DataFrame:
    """
    RiskMetrics exponentially weighted correlation matrix.
    Recent data weighted more heavily — critical during regime shifts.
    λ=0.94 is the JP Morgan RiskMetrics standard for daily data.
    """
    ret_array = returns.fillna(0).values
    n_obs, n_assets = ret_array.shape
    if n_obs < 30 or n_assets < 2:
        return returns.corr().fillna(0.0)

    # Build exponential weights: most recent = highest weight
    weights = np.array([(1 - lam) * (lam ** i) for i in range(n_obs - 1, -1, -1)])
    weights /= weights.sum()

    # Weighted mean
    w_mean = np.average(ret_array, weights=weights, axis=0)
    centered = ret_array - w_mean

    # Weighted covariance
    cov = np.einsum('t,ti,tj->ij', weights, centered, centered)
    std_diag = np.sqrt(np.diag(cov))
    std_diag[std_diag < 1e-12] = 1e-12
    outer = np.outer(std_diag, std_diag)
    corr = np.where(outer != 0, cov / np.where(outer != 0, outer, 1.0), 0.0)  # DIV001 guarded
    np.fill_diagonal(corr, 1.0)
    corr = np.clip(corr, -1.0, 1.0)
    return pd.DataFrame(corr, index=returns.columns, columns=returns.columns)

# Extend __all__ with newly moved names

try:
    __all__.extend(['build_factor_summary', 'build_exposures_summary', 'build_selection_changes', 'build_alerts', 'build_diagnostics_frame', 'build_correlation_matrix', 'build_ewma_correlation'])
except NameError:
    __all__ = ['build_factor_summary', 'build_exposures_summary', 'build_selection_changes', 'build_alerts', 'build_diagnostics_frame', 'build_correlation_matrix', 'build_ewma_correlation']
