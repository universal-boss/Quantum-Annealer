"""
utils_nse.py — Consolidated NSE scraping surface (AUDIT-FIX Round 3, P2-2)
=========================================================================

The audit (Chapter 5) found 17 NSE-hitting surfaces in the codebase with
duplicated session-warmup, retry, gzip-decompress, daily-cache, and per-
ticker-pacing logic — plus 5 different User-Agent strings, 8 inline
warmup copies, and 16 distinct silent-constant-fallback policies.

This module provides the canonical primitives:

  - NSEClient (re-exported from utils.py)  — shared HTTP session
  - NSEClient.fetch_json()                 — GET + retry + decompress + JSON decode
  - nse_parsers.decode_nse_response()       — gzip/zlib/deflate/brotli ladder
  - nse_parsers.normalize_nse_columns()     — column-norm helper
  - nse_parsers.parse_nse_date()            — 6-format date sniffing
  - nse_parsers.extract_records()           — records-list extraction
  - daily_cached() decorator               — read_json_cache/write_json_cache
                                              boilerplate with sentinel_ok=False
                                              (refuses to cache "N/A"/None/empty-set)
  - NSEPerTickerPool                       — shared token-bucket per-ticker pool
  - Sentinel.MISSING                       — explicit "no data" marker

Every fetcher in data_layer.py is migrated onto these primitives, eliminating
~700 lines of duplicated boilerplate and 5 different UA strings.
"""
from __future__ import annotations

import functools
import gzip
import io
import json
import logging
import threading
import time
import zlib
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, TYPE_CHECKING

import numpy as np

# ROUND-44 FIX: the quoted annotation `"pd.DataFrame"` on
# nse_parsers.normalize_nse_columns referenced a `pd` that was never
# importable at module scope (pandas is imported INSIDE the function) — a
# latent NameError under typing.get_type_hints() and a static-analyzer
# undefined-name. Import for type-checking only (no runtime cost).
if TYPE_CHECKING:
    import pandas as pd

logger = logging.getLogger(__name__)


# --------------------------------------------------------------------------- #
# Sentinel: explicit "no data" marker                                          #
# --------------------------------------------------------------------------- #
class _Sentinel:
    """Singleton marker for explicit 'no data available' values.

    Replaces the 16 different silent-constant-fallback policies
    (15.0 for VIX, "Neutral" for FII/DII, 0.0 for fundamentals,
    0.5 for IV rank, 0.0 for pledge reduction, etc.) with one
    explicit marker that downstream code must check before using.
    """
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __repr__(self) -> str:
        return "Sentinel.MISSING"

    def __bool__(self) -> bool:
        return False

    def __eq__(self, other) -> bool:
        return isinstance(other, _Sentinel)

    def __hash__(self) -> int:
        return hash("Sentinel.MISSING")


class Sentinel:
    MISSING = _Sentinel()


# AUDIT-FIX (Round 5, 2-b-7): JSON-safe cache encodings for Sentinel.MISSING
# and set results (see daily_cached).
_SENTINEL_MISSING_TAG = "__SENTINEL_MISSING__"
_NSE_SET_WRAPPER_KEY = "__nse_set__"


# --------------------------------------------------------------------------- #
# nse_parsers: shared parsing primitives                       #
# --------------------------------------------------------------------------- #
class nse_parsers:
    """Pure parsing helpers lifted from 4+ duplicated inline copies."""

    @staticmethod
    def decode_nse_response(resp) -> bytes:
        """Decode an NSE HTTP response to raw bytes, handling the
        gzip/zlib/deflate/brotli ladder that NSE uses inconsistently.

        Lifted from data_layer.py:fetch_corp_actions_blackout:_try_decompress
        (the most complete of the 4 inline copies) and made canonical.
        """
        if hasattr(resp, "content") and isinstance(resp.content, (bytes, bytearray)):
            content = bytes(resp.content)
        elif isinstance(resp, (bytes, bytearray)):
            content = bytes(resp)
        elif isinstance(resp, str):
            try:
                content = resp.encode("latin-1")
            except Exception:
                content = resp.encode("utf-8", errors="ignore")
        else:
            content = b""

        enc = (resp.headers.get("Content-Encoding", "") if hasattr(resp, "headers") else "").lower()

        # Check gzip magic header b'\x1f\x8b' or declared encoding
        if enc == "gzip" or content.startswith(b"\x1f\x8b"):
            try:
                return gzip.decompress(content)
            except Exception:
                pass
        elif enc == "deflate" or content.startswith(b"\x78\x9c") or content.startswith(b"\x78\x01") or content.startswith(b"\x78\xda"):
            try:
                return zlib.decompress(content)
            except zlib.error:
                try:
                    return zlib.decompress(content, -zlib.MAX_WBITS)
                except zlib.error:
                    pass
        elif enc == "br":
            try:
                import brotli
                return brotli.decompress(content)
            except ImportError:
                return content

        # Auto-detect if declared encoding failed
        try:
            return gzip.decompress(content)
        except Exception:
            pass
        try:
            return zlib.decompress(content)
        except zlib.error:
            pass
        try:
            return zlib.decompress(content, -zlib.MAX_WBITS)
        except zlib.error:
            pass
        try:
            import brotli
            return brotli.decompress(content)
        except Exception:
            pass

        return content

    @staticmethod
    def decode_nse_text(resp) -> str:
        """Decode an NSE HTTP response to a string."""
        raw = nse_parsers.decode_nse_response(resp)
        try:
            return raw.decode("utf-8")
        except UnicodeDecodeError:
            try:
                return raw.decode("latin-1")
            except Exception:
                return raw.decode("utf-8", errors="replace")

    @staticmethod
    def decode_nse_json(resp):
        """Decode an NSE HTTP response to a JSON object."""
        text = nse_parsers.decode_nse_text(resp)
        if not text or not text.strip():
            return {}
        try:
            return json.loads(text)
        except json.JSONDecodeError as e:
            logger.warning("[nse_parsers] JSON decode failed: %s (text[:200]=%s)", e, text[:200])
            return {}

    @staticmethod
    def normalize_nse_columns(df) -> "pd.DataFrame":
        """Normalize NSE column names: strip, upper, spaces → underscores."""
        import pandas as pd  # local import to avoid hard dep at module load
        if df is None or df.empty:
            return df
        df.columns = [str(c).strip().upper().replace(" ", "_") for c in df.columns]
        return df

    @staticmethod
    def parse_nse_date(s: str) -> Optional[datetime]:
        """Parse an NSE date string. Handles 6 formats (dd-Mmm-yyyy,
        dd-mm-yyyy, dd/mm/yyyy, yyyy-mm-dd, dd-Mmm-yy, yyyy-mm-ddTHH:MM:SS)."""
        if not s or not isinstance(s, str):
            return None
        s = s.strip()
        formats = [
            "%d-%b-%Y",    # 15-Jan-2024
            "%d-%m-%Y",    # 15-01-2024
            "%d/%m/%Y",    # 15/01/2024
            "%Y-%m-%d",    # 2024-01-15
            "%d-%b-%y",    # 15-Jan-24
            "%Y-%m-%dT%H:%M:%S",  # ISO
        ]
        for fmt in formats:
            try:
                return datetime.strptime(s, fmt)
            except ValueError:
                continue
        return None

    @staticmethod
    def extract_records(parsed: Any) -> List[Dict]:
        """Extract the records list from a parsed NSE response.

        Handles dict-wrapped ({'data': [...]}) and bare-list responses.
        """
        if isinstance(parsed, dict):
            for key in ("data", "records", "rows", "result"):
                if key in parsed and isinstance(parsed[key], list):
                    return parsed[key]
            return []
        if isinstance(parsed, list):
            return parsed
        return []


# --------------------------------------------------------------------------- #
# NSEClient.fetch_json: canonical GET + retry + decompress + JSON decode      #
# --------------------------------------------------------------------------- #
def _install_fetch_json():
    """Monkey-patch NSEClient with fetch_json classmethod.

    Done as a deferred install so NSEClient is loaded from utils.py first,
    avoiding import cycles.
    """
    try:
        from utils import NSEClient  # late import to break cycle
    except Exception:
        return  # utils.py not importable; falls back to direct fetchers

    if hasattr(NSEClient, "fetch_json"):
        return  # already installed

    @classmethod
    def fetch_json(cls,
                   url: str,
                   *,
                   params: Optional[Dict] = None,
                   headers: Optional[Dict] = None,
                   timeout: int = 15,
                   expected: tuple = (200,),
                   widen_window_on_empty: Optional[Callable[[Dict], Dict]] = None,
                   ) -> Any:
        """GET + auto-decompress + JSON decode + 3-retry backoff + session self-heal.

        Args:
            url: NSE API URL.
            params: Query params (e.g. {"symbol": "RELIANCE"}).
            headers: Extra headers (e.g. {"X-Requested-With": "XMLHttpRequest"}).
            timeout: HTTP timeout in seconds.
            expected: HTTP status codes considered "success".
            widen_window_on_empty: Optional callable(params_dict) -> new_params_dict.
                Called when the first request returns an empty `data` list,
                to widen the date window and retry once. Replaces the 4
                duplicated "30d → 60d/90d" fallback patterns.

        Returns:
            Parsed JSON object (dict, list, or empty dict on failure).

        Raises:
            RuntimeError: if all retries fail (caller must handle — no silent
                constant fallback).
        """
        last_exc = None
        for attempt in range(cls._MAX_RETRIES):
            try:
                resp = cls.get(url, params=params, headers=headers, timeout=timeout)
                if resp.status_code not in expected:
                    last_exc = RuntimeError(f"HTTP {resp.status_code} from {url}")
                    if attempt < cls._MAX_RETRIES - 1:
                        cls.safe_sleep((cls._BACKOFF_BASE ** attempt) * 0.5)
                        continue
                    break

                parsed = nse_parsers.decode_nse_json(resp)

                # Apply "widen window" fallback if response is empty
                if widen_window_on_empty is not None and isinstance(parsed, dict):
                    records = nse_parsers.extract_records(parsed)
                    # AUDIT-FIX (Round 5, 2-b-2): only widen while another attempt
                    # remains. On the final iteration, `continue` exits the loop
                    # and falls through to `raise RuntimeError(... last_exc=None)` —
                    # discarding a perfectly valid HTTP-200 response (e.g. a
                    # legitimately-empty corp-actions window) and turning every
                    # empty endpoint into a hard failure.
                    if (not records and params is not None
                            and attempt < cls._MAX_RETRIES - 1):
                        widened_params = widen_window_on_empty(dict(params))
                        if widened_params != params:
                            logger.info("[NSEClient.fetch_json] empty response, widening window: %s → %s",
                                        params.get("from_date"), widened_params.get("from_date"))
                            params = widened_params
                            continue  # retry with widened window

                return parsed

            except Exception as exc:
                last_exc = exc
                if attempt < cls._MAX_RETRIES - 1:
                    cls.safe_sleep((cls._BACKOFF_BASE ** attempt) + 0.20)
                else:
                    break

        # All retries exhausted — raise so caller can decide policy.
        raise RuntimeError(f"NSEClient.fetch_json({url}) failed after {cls._MAX_RETRIES} attempts: {last_exc}")

    NSEClient.fetch_json = fetch_json


# --------------------------------------------------------------------------- #
# daily_cached decorator: read_json_cache/write_json_cache boilerplate        #
# --------------------------------------------------------------------------- #
def daily_cached(cache_path: str | Path, key: str = "data", cache_key: str = "date",
                 sentinel_ok: bool = False):
    """Decorator: read JSON cache, return early if today's entry exists,
    else call the wrapped function and persist its result.

    Args:
        cache_path: Path to the JSON cache file.
        key: Key under which the result is stored in the cache dict
            (default "data"; some legacy callers use "blocked", "banned",
            "result").
        cache_key: Date key for invalidation (default "date"; holds today's
            YYYY-MM-DD string).
        sentinel_ok: If False (default), refuse to cache Sentinel.MISSING,
            None, empty dict, empty list, empty set, or "N/A" string — so
            transient HTTP failures stay retryable next run. This is the
            AUDIT-FIX for the bug where the sectors "N/A" and F&O-ban empty
            set were cached for the whole day after one transient failure.

    Usage:
        @daily_cached(FII_DII_CACHE_PATH, key="data")
        def fetch_fii_dii_flow():
            return NSEClient.fetch_json(...)
    """
    def decorator(fn: Callable) -> Callable:
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            # AUDIT-FIX (Round 5, 2-b-9): self-heal the deferred fetch_json
            # install. If utils.py imported utils_nse during its own partial
            # initialization, the module-level install attempt silently failed
            # (partially-initialized utils) and was never retried — every
            # NSEClient.fetch_json(...) call site then raised AttributeError.
            # The hasattr guard inside _install_fetch_json makes this idempotent.
            try:
                _install_fetch_json()
            except Exception:
                pass
            from utils import read_json_cache, write_json_cache  # late import
            cache = read_json_cache(cache_path, {})
            today_str = datetime.now().strftime("%Y-%m-%d")
            # AUDIT-FIX (Round 5, 2-b-8): `cache.get(key)` treated valid falsy
            # results (0 / 0.0 / False) as absent — they were written to cache
            # but refetched on every call all day. Use an identity check instead.
            if cache.get(cache_key) == today_str and cache.get(key) is not None:
                _val = cache.get(key)
                if _val == _SENTINEL_MISSING_TAG:
                    return Sentinel.MISSING
                # sets are JSON-serialized wrapped in {"__nse_set__": [...]}
                if (isinstance(_val, dict) and len(_val) == 1
                        and _NSE_SET_WRAPPER_KEY in _val
                        and isinstance(_val[_NSE_SET_WRAPPER_KEY], list)):
                    return set(_val[_NSE_SET_WRAPPER_KEY])
                return _val

            # Call the wrapped fetcher
            result = fn(*args, **kwargs)

            # Sentinel guard: refuse to cache "no data" markers
            if not sentinel_ok:
                _is_sentinel = (
                    result is None
                    or result is Sentinel.MISSING
                    or (isinstance(result, dict) and not result)
                    or (isinstance(result, (list, set)) and not result)
                    or (isinstance(result, str) and (result.upper() == "N/A" or not result.strip()))
                )
                if _is_sentinel:
                    logger.info("[daily_cached] not caching sentinel for %s (transient failure stays retryable)",
                                Path(cache_path).name)
                    return result

            # AUDIT-FIX (Round 5, 2-b-7): make the stored value JSON-safe. With
            # sentinel_ok=True a Sentinel.MISSING result previously crashed
            # write_json_cache (TypeError: not JSON serializable); non-empty sets
            # (the module's own F&O-ban use case) crashed the same way. Encode
            # the sentinel as a marker string and sets as sorted lists.
            if result is Sentinel.MISSING:
                stored = _SENTINEL_MISSING_TAG
            elif isinstance(result, set):
                stored = {_NSE_SET_WRAPPER_KEY: sorted(result)}
            else:
                stored = result
            write_json_cache(cache_path, {cache_key: today_str, key: stored})
            return result

        return wrapper
    return decorator


# --------------------------------------------------------------------------- #
# NSEPerTickerPool: shared rate-limited per-ticker worker pool                #
# --------------------------------------------------------------------------- #
class NSEPerTickerPool:
    """Thread pool that paces NSE per-symbol calls against a shared token
    bucket so we don't hammer NSE's throttle limit.

    Replaces 6 ad-hoc pacing policies:
      - time.sleep(0.15) per ticker (LivePnLTracker)
      - "sleep every 20 tickers" (fetch_sectors)
      - cap at tickers[:30] (fetch_iv_rank)
      - cap at tickers[:60] (fetch_oi_buildup_signal)
      - _DaemonThreadPoolExecutor with min(16, max(6, n//15)) (fetch_pledge_reduction)
      - time.sleep(NSE_SESSION_SLEEP) (fetch_oi_buildup_signal)

    With one shared token bucket (default: 6 req/s, matching NSE's observed
    throttle threshold), fairness is enforced and per-ticker caps become
    unnecessary — the bucket paces every caller.
    """
    _lock = threading.Lock()
    _tokens: float = 6.0
    _max_tokens: float = 6.0
    _refill_rate: float = 6.0  # tokens per second
    _last_refill: float = time.time()

    @classmethod
    def acquire(cls, tokens: float = 1.0, timeout: float = 30.0) -> bool:
        """Block until tokens are available, or timeout. Returns True if acquired."""
        import time as _t
        deadline = _t.time() + timeout
        while _t.time() < deadline:
            with cls._lock:
                now = _t.time()
                elapsed = now - cls._last_refill
                cls._tokens = min(cls._max_tokens, cls._tokens + elapsed * cls._refill_rate)
                cls._last_refill = now
                if cls._tokens >= tokens:
                    cls._tokens -= tokens
                    return True
            time.sleep(max(0.05, tokens / cls._refill_rate / 2))
        return False

    @classmethod
    def map_per_ticker(cls, fn: Callable, tickers: List[str], *args, **kwargs) -> Dict[str, Any]:
        """Apply fn(ticker, *args, **kwargs) to each ticker with rate-limited pacing.

        Returns a dict {ticker: result}. Tickers where fn raised are omitted
        from the result (no silent constant fallback).
        """
        results: Dict[str, Any] = {}
        for ticker in tickers:
            if not cls.acquire(timeout=30.0):
                logger.warning("[NSEPerTickerPool] token bucket exhausted at ticker %s; skipping rest", ticker)
                break
            try:
                results[ticker] = fn(ticker, *args, **kwargs)
            except Exception as exc:
                logger.debug("[NSEPerTickerPool] fn(%s) failed: %s", ticker, exc, exc_info=True)
                continue
        return results


# --------------------------------------------------------------------------- #
# Auto-install NSEClient.fetch_json on first import                           #
# --------------------------------------------------------------------------- #
try:
    _install_fetch_json()
except Exception as _e:
    logger.debug("[utils_nse] deferred fetch_json install failed: %s", _e, exc_info=True)
