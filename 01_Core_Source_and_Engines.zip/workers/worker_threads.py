import threading
import traceback
import urllib.error  # ROUND-43 FIX (R3): except urllib.error.HTTPError in the Telegram chunk loop referenced an unimported module (the NameError would mask the real HTTP error)
try:
    from PySide6.QtCore import QThread, QObject, Signal as pyqtSignal, Qt
except ImportError:
    from PyQt5.QtCore import QThread, QObject, pyqtSignal, Qt

# M15-fix: heavy imports (utils, optimizer, data.price_feed) moved OUT of module top-level.
# With multiprocessing 'spawn' context, each subprocess re-imports workers.worker_threads,
# and the top-level imports were pulling in utils/optimizer/data chains on every spawn.
# Each function/method below now imports what it needs locally.

class OptimizerWorker(QThread):
    progress = pyqtSignal(int)
    log      = pyqtSignal(str)
    result   = pyqtSignal(object)
    failed   = pyqtSignal(str)
    stopped  = pyqtSignal(str)

    def __init__(self, cfg, manual_symbols_text="", prev_holdings_text="", ml_alpha_scores=None):
        super().__init__()
        from utils import WorkerLifecycle
        self.cfg                  = cfg
        self.manual_symbols_text  = manual_symbols_text
        self.prev_holdings_text   = prev_holdings_text
        self.stop_event           = threading.Event()
        # Phase 2: ML alpha scores from the fitted AlphaEngine.predict().
        # Injected into cfg["_ML_ALPHA_SCORES"] so run_optimizer_logic can
        # blend them into signal_df["alpha_score"] at 30% weight.
        if ml_alpha_scores and isinstance(ml_alpha_scores, dict) and len(ml_alpha_scores) > 0:
            self.cfg["_ML_ALPHA_SCORES"] = ml_alpha_scores
        WorkerLifecycle.register_thread(self)

    def request_stop(self):
        self.stop_event.set()
        self.requestInterruption()   # also flag Qt interruption

    def run(self):
        # Register our stop_event as the module-level active event so
        # check_stop() / log_emit() in the engine functions can honour it.
        # M15-fix: heavy imports moved local to avoid spawn-context re-import cost.
        from utils import _ACTIVE_STOP_EVENT, _ACTIVE_STOP_EVENT_LOCK, StopRequested
        from optimizer import run_optimizer_logic
        with _ACTIVE_STOP_EVENT_LOCK:
            _ACTIVE_STOP_EVENT.set_event(self.stop_event)
        try:
            payload = run_optimizer_logic(
                self.cfg,
                self.manual_symbols_text,
                self.prev_holdings_text,
                self.log.emit,
                self.progress.emit,
                self.stop_event,
            )
            # Check Qt interruption request (e.g. from closeEvent) before emitting
            if self.isInterruptionRequested():
                self.stopped.emit("Run cancelled (app closing).")
                return
            self.result.emit(payload)
        except StopRequested as exc:
            self.stopped.emit(str(exc))
        except Exception as _e:
            self.failed.emit(traceback.format_exc())
        finally:
            with _ACTIVE_STOP_EVENT_LOCK:
                _ACTIVE_STOP_EVENT.clear_event()


class _GenericNetworkWorker(QThread):
    result = pyqtSignal(object)
    error  = pyqtSignal(str)
    def __init__(self, fn, *args, **kwargs):
        super().__init__()
        from utils import WorkerLifecycle
        self._fn, self._args, self._kwargs = fn, args, kwargs
        self.setObjectName("GenericNetworkWorker")
        WorkerLifecycle.register_thread(self)
    def run(self):
        try:
            self.result.emit(self._fn(*self._args, **self._kwargs))
        except Exception as exc:
            self.error.emit(str(exc))


class _MacroRefreshWorker(QThread):
    done = pyqtSignal(object, object)   # (vix_val, yc_spread)
    def __init__(self, regime_info):
        super().__init__()
        from utils import WorkerLifecycle
        self._regime_info = regime_info
        self.setObjectName("MacroRefreshWorker")
        WorkerLifecycle.register_thread(self)
    def run(self):
        # M15-fix: heavy imports moved local
        from utils import _DATA_PROVIDER, ExceptionLogger
        vix_val = None
        yc_spread = None
        try:
            vix_raw = _DATA_PROVIDER.get_vix()
            if vix_raw is not None and hasattr(vix_raw, 'iloc'):
                # R48-2: an EMPTY VIX series previously fabricated vix_val = 0.0
                # (VIX is never zero) — emit None so the card keeps its "—"
                # placeholder instead of showing an impossible reading.
                vix_val = float(vix_raw.iloc[-1]) if not vix_raw.empty else None
            elif isinstance(vix_raw, (int, float)):
                vix_val = float(vix_raw)
        except Exception as _e_:
            ExceptionLogger.swallow(_e_, context="silent_catch")
        try:
            yc_spread = self._regime_info.get("YieldCurveSpread") or self._regime_info.get("yield_curve_spread")
            if yc_spread is None:
                # BUG-W2 FIX: replaced direct yfinance calls for US Treasury yields
                # (^TNX, ^IRX) with safe_download routing through the provider abstraction.
                # For an NSE strategy, Indian Gsec yields are more relevant than US Treasuries.
                # Primary: try Indian 10Y Gsec yield from NSE/RBI proxy tickers.
                # Fallback: use US yields only if Indian yield data is unavailable.
                # RBI publishes Gsec data but no standard yfinance ticker exists — use
                # IN10YT=RR (Refinitiv RIC) if the institutional provider supports it,
                # otherwise fall back to US spread as a global risk proxy.
                from data.price_feed import safe_download
                _spread = None
                try:
                    # Attempt Indian government bond proxy
                    _in10 = safe_download(["IN10YT=RR"], period="2d")
                    _in91 = safe_download(["IN91DT=RR"], period="2d")
                    if not _in10.empty and not _in91.empty:
                        _v10 = float(_in10["Close"].iloc[-1].squeeze())
                        _v91 = float(_in91["Close"].iloc[-1].squeeze())
                        _spread = _v10 - _v91
                except Exception:
                    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                    pass

                if _spread is None:
                    # Fallback: US yield curve as global risk proxy
                    try:
                        _t10_df = safe_download(["^TNX"], period="2d")
                        _t2_df  = safe_download(["^IRX"], period="2d")
                        if not _t10_df.empty and not _t2_df.empty:
                            _t10 = float(_t10_df["Close"].iloc[-1].squeeze())
                            _t2  = float(_t2_df["Close"].iloc[-1].squeeze())
                            _spread = _t10 - _t2
                    except Exception:
                        import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                        pass

                # AUDIT-FIX (Round 48 — R48-2): a failed fetch previously
                # fabricated yc_spread = 0.0, which the dashboard rendered as
                # a MEASURED "+0.00% / Flat" yield curve — indistinguishable
                # from a genuinely near-flat curve (itself a meaningful
                # macro signal), while VIX honestly stayed None. Emit None on
                # failure instead: the consumer's fallback chain already
                # handles it (regime_info fallback, then the "—" placeholder),
                # mirroring the VIX honesty contract (R19/R40/R47-1).
                yc_spread = _spread  # None when both proxies failed — consumer renders "—"
        except Exception as _e_:
            ExceptionLogger.swallow(_e_, context="silent_catch")
        self.done.emit(vix_val, yc_spread)


class _FetchWorker(QObject):
    finished  = pyqtSignal(object)   # emits result dict
    progress  = pyqtSignal(str)      # emits log lines
    errored   = pyqtSignal(str)

    def __init__(self, tickers, period, compute_fn, extra=None):
        super().__init__()
        self._tickers     = tickers
        self._period      = period
        self._compute_fn  = compute_fn
        self._extra       = extra or {}

    def run(self):
        from data.price_feed import safe_download
        try:
            self.progress.emit(f"Downloading {len(self._tickers)} tickers ({self._period}) …")
            raw = safe_download(self._tickers, self._period, log_cb=lambda m: self.progress.emit(m))
            if raw is None or raw.empty:
                self.errored.emit("Download returned no data. Check ticker symbols and internet connection.")
                return
            self.progress.emit(f"Download complete — computing …")
            result = self._compute_fn(raw, self._extra)
            self.finished.emit(result)
        except Exception as e:
            import traceback
            self.errored.emit(f"{e}\n{traceback.format_exc()[-600:]}")


class _Worker(QObject):
    done     = pyqtSignal(object)
    progress = pyqtSignal(str)
    error    = pyqtSignal(str)

    def __init__(self, fn, *args, **kwargs):
        super().__init__()
        self._fn = fn; self._args = args; self._kwargs = kwargs

    def run(self):
        try:
            result = self._fn(*self._args, **self._kwargs)
            self.done.emit(result)
        except Exception as e:
            import traceback
            self.error.emit(f"{e}\n{traceback.format_exc()[-800:]}")


# ══════════════════════════════════════════════════════════════════════════════
#  RegimeWorker — autonomous HMM market regime detection (background QThread)
# ══════════════════════════════════════════════════════════════════════════════

class RegimeWorker(QThread):
    """Background QThread that runs HMM regime detection on Nifty 50 data.

    Signals:
        regime_updated (dict): Emitted when a new regime prediction is ready.
            Payload keys: "state" (int), "label" (str), "confidence" (float),
            "probabilities" (dict), "transition_matrix" (NDArray).
        log    (str):  Informational messages for the UI log panel.
        failed (str):  Full traceback string on unhandled exception.

    Thread-safety:
        Writes regime state to AppState singleton (RLock-protected) before
        emitting the signal so the UI callback always reads a consistent value.

    Usage (connect in UI):
        self._regime_worker = RegimeWorker(model_path="models/regime_hmm_latest.json")
        self._regime_worker.regime_updated.connect(self._on_regime_update)
        self._regime_worker.start()
    """

    regime_updated = pyqtSignal(dict)
    log            = pyqtSignal(str)
    failed         = pyqtSignal(str)

    #: How many recent trading days to pass to predict_regime()
    _INFERENCE_WINDOW: int = 252
    #: Nifty 50 yfinance symbol
    _BENCHMARK: str = "^NSEI"
    #: Data lookback for feature computation (need > 252 + 20 for realized var)
    _LOOKBACK: str = "5y"

    def __init__(
        self,
        model_path: str = "models/regime_hmm_latest.json",
        parent=None,
    ) -> None:
        """
        Args:
            model_path: Path to a pre-fitted MarketRegimeDetector model file (JSON or joblib).
                        If the file does not exist, the model is trained on
                        the fetched data and saved before inference.
            parent:     Optional Qt parent object.
        """
        super().__init__(parent)
        from pathlib import Path
        from utils import WorkerLifecycle
        model_file = Path(model_path)
        if not model_file.is_absolute():
            # Resolve relative model paths against the project root, not the
            # caller's current working directory.
            model_file = Path(__file__).resolve().parents[1] / model_file
        self._model_path = str(model_file)
        self.setObjectName("RegimeWorker")
        self.setTerminationEnabled(False)   # no hard-kill — let run() finish cleanly
        WorkerLifecycle.register_thread(self)

    def run(self) -> None:
        """Fetch Nifty data, run HMM inference, update AppState, emit signal."""
        try:
            from math_engine.regime_detector import MarketRegimeDetector
            from core.state_manager import AppState
            # BUG-W1 FIX: removed unused `import yfinance as yf` — fetch goes
            # through safe_download below; yf was never called in this method.
            from pathlib import Path

            self.log.emit("[RegimeWorker] Fetching Nifty 500 broad proxy data …")

            # ── Fetch market data (unified ^CRSLDX / ^CNX500 / ^NSEI list) ────
            from data.price_feed import safe_download
            import pandas as pd
            import numpy as np

            _hmm_symbols = ["^CRSLDX", "^CNX500", "^NSEI"]
            raw = pd.DataFrame()
            for _sym in _hmm_symbols:
                try:
                    _raw = safe_download([_sym], period=self._LOOKBACK)
                    if _raw is not None and not _raw.empty and len(_raw) >= 500:
                        raw = _raw
                        break
                except Exception:
                    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                    pass

            if raw is None or raw.empty:
                self.failed.emit("[RegimeWorker] Benchmark data fetch returned empty DataFrame.")
                return

            if isinstance(raw.columns, pd.MultiIndex):
                close_ser = raw["Close"].iloc[:, 0] if isinstance(raw["Close"], pd.DataFrame) else raw["Close"]
            else:
                close_ser = raw["Close"].squeeze() if "Close" in raw.columns else raw.iloc[:, 0]

            nifty_df = pd.DataFrame({"close": close_ser}).dropna()
            nifty_df["return"] = np.log(nifty_df["close"] / nifty_df["close"].shift(1))
            nifty_df = nifty_df.dropna()

            # ── Load or train model ──────────────────────────────────────────
            model_file = Path(self._model_path)
            is_json = model_file.suffix.lower() == ".json"
            
            if model_file.exists():
                if is_json:
                    self.log.emit(f"[RegimeWorker] Loading HMM model from JSON {model_file.name} …")
                    detector = MarketRegimeDetector.load_json(model_file)
                else:
                    self.log.emit(f"[RegimeWorker] Loading HMM model from joblib {model_file.name} …")
                    detector = MarketRegimeDetector.load(model_file)
                
                # Check for staleness from metadata timestamp if available
                ts_str = getattr(detector, "timestamp_utc", None)
                if ts_str:
                    from datetime import datetime, timezone
                    ts = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
                    age_hours = (datetime.now(timezone.utc) - ts).total_seconds() / 3600.0
                    if age_hours > 48.0:
                        self.log.emit(f"[RegimeWorker] WARNING: HMM model is {age_hours:.1f}h old (>48h hard ceiling). Retraining HMM model on the fly …")
                        detector = MarketRegimeDetector(n_iter=500)
                        detector.fit(nifty_df)
                        model_file.parent.mkdir(parents=True, exist_ok=True)
                        if is_json:
                            detector.save_json(model_file)
                        else:
                            detector.save(model_file)
                        self.log.emit(f"[RegimeWorker] Retrained model saved → {model_file}")
            else:
                self.log.emit("[RegimeWorker] No saved model — training HMM (first run) …")
                detector = MarketRegimeDetector(n_iter=500)
                detector.fit(nifty_df)
                model_file.parent.mkdir(parents=True, exist_ok=True)
                if is_json:
                    detector.save_json(model_file)
                else:
                    detector.save(model_file)
                self.log.emit(f"[RegimeWorker] Model saved → {model_file}")

            # ── Inference ────────────────────────────────────────────────────
            self.log.emit("[RegimeWorker] Running regime inference …")
            result: dict = detector.predict_regime(nifty_df, last_n_days=self._INFERENCE_WINDOW, use_macro_overlay=True)

            # ── Write to AppState (thread-safe, before signal emit) ───────────
            AppState.instance().set_regime(
                label=result["label"],
                confidence=result["confidence"],
                probabilities=result["probabilities"],
                transition_matrix=result.get("transition_matrix"),
            )

            self.log.emit(
                f"[RegimeWorker] Regime → {result['label']} "
                f"(conf={result['confidence']:.1%}) | "
                f"Bear={result['probabilities']['Bear']:.1%} "
                f"Sideways={result['probabilities']['Sideways']:.1%} "
                f"Bull={result['probabilities']['Bull']:.1%}"
            )

            # Emit a JSON-serialisable dict (no numpy arrays in the payload
            # so the signal can cross Qt's meta-object system safely).
            emit_payload = {
                "state":         result["state"],
                "label":         result["label"],
                "confidence":    result["confidence"],
                "probabilities": result["probabilities"],
            }
            self.regime_updated.emit(emit_payload)

        except Exception:
            self.failed.emit(traceback.format_exc())


# ══════════════════════════════════════════════════════════════════════════════
#  LatentScreenerWorker — ProcessPoolExecutor ONNX+FAISS screener (GIL-free)
# ══════════════════════════════════════════════════════════════════════════════

def _screen_one_ticker(
    ticker: str,
    onnx_model_path: str,
    embeddings_path: str,
    lookback: str = "3mo",
) -> tuple[str, float, float] | tuple[str, None, None]:
    """Top-level function executed in a worker subprocess.

    Must be top-level (not a lambda or method) so pickle can serialise it
    for ProcessPoolExecutor.  Each subprocess imports its own onnxruntime
    and faiss session — no shared memory, no GIL contention.

    Args:
        ticker:           NSE/BSE ticker symbol (yfinance format).
        onnx_model_path:  Absolute path to the .onnx ViT model.
        embeddings_path:  Absolute path to the .npy reference embeddings.
        lookback:         yfinance period string for OHLCV download.

    Returns:
        (ticker, cosine_sim, l2_dist) on success, or (ticker, None, None) on error.
    """
    try:
        import os
        os.environ["OMP_NUM_THREADS"] = "1"
        os.environ["MKL_NUM_THREADS"] = "1"
        os.environ["OPENBLAS_NUM_THREADS"] = "1"
        os.environ["VECLIB_MAXIMUM_THREADS"] = "1"
        os.environ["NUMEXPR_NUM_THREADS"] = "1"

        import numpy as np
        from math_engine.onnx_inference import LatentEmbeddingGenerator
        from math_engine.latent_screener import LatentSpaceScreener

        # Download OHLCV — blocking in the subprocess, not the main process
        from data.price_feed import safe_download
        raw = safe_download([ticker], period=lookback)
        if raw is None or raw.empty or len(raw) < 10:
            return (ticker, None, None)

        # Build embedding — one session per subprocess (reused across future calls)
        gen = LatentEmbeddingGenerator(onnx_model_path)
        embedding = gen.generate_embedding(raw)   # (512,) float32
        del gen  # free ONNX session RAM; screener is the heavy object

        # Score against the breakout corpus
        screener = LatentSpaceScreener(embeddings_path)
        result = screener.score_setup(embedding, top_k=5)
        # Call rerank_candidates to rank setups and add to the result dictionary
        reranked = screener.rerank_candidates(embedding, bank="breakout", timeframe="1d")
        result["reranked"] = reranked
        del screener, embedding

        return (ticker, result["cosine_similarity"], result["l2_distance"])

    except Exception:
        # Swallow per-ticker errors — caller handles (ticker, None, None)
        return (ticker, None, None)


class LatentScreenerWorker(QThread):
    """QThread that distributes ONNX + FAISS screening across CPU processes.

    Architecture (M2 memory-safe):
        ┌─────────────────────────────────────────────────┐
        │  Main thread (QThread)                          │
        │  ProcessPoolExecutor.submit() × N_tickers       │
        │  ↓  (non-blocking — futures polled via as_completed)│
        │  Child process × max_workers (default: 4)       │
        │    • downloads OHLCV (yfinance, GIL-releasing)  │
        │    • runs LatentEmbeddingGenerator (ORT/CoreML) │
        │    • runs LatentSpaceScreener (FAISS BLAS)      │
        │    • returns (ticker, cosine_sim, l2_dist)      │
        │  ↓                                              │
        │  Main process receives result → emits signal    │
        └─────────────────────────────────────────────────┘

    Memory per subprocess:
        FAISS index (N=10k embeddings): ~20 MB
        ORT session:                    ~40 MB
        Peak:                           ~80 MB × 4 workers = 320 MB — safe on 8 GB.

    Signals:
        ticker_scored (tuple): (ticker: str, cosine_sim: float, l2_dist: float)
                                emitted as each ticker completes.
        progress (int):        Completion percentage 0–100.
        log (str):             Status messages.
        finished_all (dict):   {ticker: cosine_sim} for all successfully scored tickers.
        failed (str):          Traceback on fatal worker error.

    Usage:
        worker = LatentScreenerWorker(
            tickers=["TCS.NS", "INFY.NS", ...],
            onnx_model_path="artifacts/vit_chart_model.onnx",
            embeddings_path="artifacts/breakout_embeddings.npy",
            max_workers=4,
        )
        worker.ticker_scored.connect(self._on_ticker_scored)
        worker.finished_all.connect(self._on_screener_complete)
        worker.start()
    """

    ticker_scored = pyqtSignal(tuple)    # (ticker, cosine_sim, l2_dist)
    progress      = pyqtSignal(int)
    log           = pyqtSignal(str)
    finished_all  = pyqtSignal(dict)
    failed        = pyqtSignal(str)

    def __init__(
        self,
        tickers: list[str],
        onnx_model_path: str,
        embeddings_path: str,
        max_workers: int = 2,
        parent=None,
    ) -> None:
        """
        Args:
            tickers:          List of yfinance-format ticker symbols to screen.
            onnx_model_path:  Absolute path to the .onnx ViT model.
            embeddings_path:  Absolute path to the .npy breakout embeddings.
            max_workers:      Subprocess count. Default 4 = uses M2 P-cores
                              without exhausting the 8 GB memory budget.
            parent:           Optional Qt parent object.
        """
        super().__init__(parent)
        self._tickers = list(tickers)
        self._onnx_model_path = onnx_model_path
        self._embeddings_path = embeddings_path
        self._max_workers = max_workers
        self.setObjectName("LatentScreenerWorker")
        self.setTerminationEnabled(False)
        from utils import WorkerLifecycle
        WorkerLifecycle.register_thread(self)

    def run(self) -> None:
        """Distribute screening across processes; emit results as they arrive."""
        import time
        from concurrent.futures import ProcessPoolExecutor, as_completed
        from core.state_manager import AppState

        n = len(self._tickers)
        self.log.emit(f"[LatentScreener] Starting {n} tickers | workers={self._max_workers}")

        scores: dict[str, float] = {}
        completed = 0

        try:
            # spawn context: each worker is a fresh Python interpreter.
            # 'spawn' is the default on macOS (safer than 'fork' with ObjC runtimes).
            with ProcessPoolExecutor(
                max_workers=self._max_workers,
                mp_context=__import__("multiprocessing").get_context("spawn"),
            ) as pool:

                # Submit all jobs upfront — the pool queues them internally.
                future_map = {
                    pool.submit(
                        _screen_one_ticker,
                        ticker,
                        self._onnx_model_path,
                        self._embeddings_path,
                    ): ticker
                    for ticker in self._tickers
                }

                # Yield results to the Qt main thread as each future resolves.
                # as_completed() blocks only until the *next* result is ready,
                # so this loop emits signals continuously without a batch delay.
                for future in as_completed(future_map):
                    if self.isInterruptionRequested():
                        # Cancel all pending futures and exit cleanly
                        for f in future_map:
                            f.cancel()
                        self.log.emit("[LatentScreener] Cancelled by user.")
                        return

                    try:
                        ticker, cosine_sim, l2_dist = future.result(timeout=60)
                    except Exception as exc:
                        ticker = future_map[future]
                        self.log.emit(f"[LatentScreener] {ticker} error: {exc}")
                        cosine_sim, l2_dist = None, None

                    completed += 1
                    pct = int(completed / n * 100)
                    self.progress.emit(pct)

                    if cosine_sim is not None:
                        scores[ticker] = cosine_sim
                        self.ticker_scored.emit((ticker, cosine_sim, l2_dist))

            # ── Write aggregate results to AppState ──────────────────────────
            ts = time.time()
            AppState.instance().update_latent_scores(scores, timestamp=ts)

            self.log.emit(
                f"[LatentScreener] Complete — {len(scores)}/{n} tickers scored "
                f"(top score: {max(scores.values(), default=0.0):.3f})"
            )
            self.finished_all.emit(scores)

        except Exception:
            self.failed.emit(traceback.format_exc())


def _run_profile_isolated_process(profile_name: str, cfg: dict, queue):
    """Executes a research profile inside an isolated Python process with its own dedicated GIL lock."""
    try:
        import time, pickle, re
        from pathlib import Path
        from utils import RUNTIME_DIR
        t0 = time.time()
        from optimizer import run_optimizer_logic
        
        def log_cb(msg):
            try: queue.put(("log", profile_name, msg))
            except Exception: pass

        def progress_cb(pct):
            try: queue.put(("progress", profile_name, pct))
            except Exception: pass

        payload = run_optimizer_logic(
            cfg,
            "",
            "",
            log_cb=log_cb,
            progress_cb=progress_cb,
        )
        runtime = time.time() - t0
        clean_name = re.sub(r'[^a-zA-Z0-9_]', '_', profile_name)
        pkl_path = RUNTIME_DIR / f"profile_payload_{clean_name}.pkl"
        with open(pkl_path, "wb") as f:
            pickle.dump(payload, f, protocol=pickle.HIGHEST_PROTOCOL)
        queue.put(("done", profile_name, str(pkl_path), runtime))
    except Exception as err:
        import traceback
        queue.put(("failed", profile_name, traceback.format_exc(), 0.0))


# ══════════════════════════════════════════════════════════════════════════════
#  ProfileWorker — runs ONE profile's full optimizer pipeline in isolated process
# ══════════════════════════════════════════════════════════════════════════════

class ProfileWorker(QThread):
    """Runs a single research profile through the full optimizer pipeline inside an isolated process.

    Signals:
        profile_done   (str, object): (profile_name, payload_dict) on success.
        profile_failed (str, str):    (profile_name, traceback_str) on error.
        profile_log    (str, str):    (profile_name, log_line) for streaming logs.
        profile_progress (str, int):  (profile_name, 0–100) progress updates.
    """

    profile_done     = pyqtSignal(str, object)  # (name, payload)
    profile_failed   = pyqtSignal(str, str)     # (name, traceback)
    profile_log      = pyqtSignal(str, str)     # (name, log_line)
    profile_progress = pyqtSignal(str, int)     # (name, pct)

    def __init__(self, profile_name: str, cfg: dict, semaphore, parent=None):
        super().__init__(parent)
        self._profile_name = profile_name
        self._cfg = dict(cfg)          # deep-copy so workers don't share refs
        self._semaphore = semaphore    # threading.Semaphore from orchestrator
        self.stop_event = threading.Event()
        self.setObjectName(f"ProfileWorker[{profile_name[:20]}]")
        self.setTerminationEnabled(False)
        from utils import WorkerLifecycle
        WorkerLifecycle.register_thread(self)

    def request_stop(self):
        self.stop_event.set()
        self.requestInterruption()

    def run(self):
        import time, pickle, multiprocessing as mp
        from pathlib import Path
        from core.state_manager import AppState

        name = self._profile_name
        state = AppState.instance()
        state.set_profile_status(name, "running")

        # Acquire concurrency slot — blocks until a slot is free
        self._semaphore.acquire()
        t0 = time.time()
        try:
            ctx = mp.get_context("spawn")
            queue = ctx.Queue()
            proc = ctx.Process(
                target=_run_profile_isolated_process,
                args=(name, self._cfg, queue)
            )
            proc.start()

            payload = None
            err_msg = None

            while proc.is_alive() or not queue.empty():
                if self.stop_event.is_set():
                    proc.terminate()
                    proc.join(timeout=2)
                    state.set_profile_status(name, "failed")
                    self.profile_failed.emit(name, "Stopped by user")
                    return

                try:
                    item = queue.get(timeout=0.05)
                    kind = item[0]
                    pname = item[1] if len(item) > 1 else name
                    data = item[2] if len(item) > 2 else None
                    extra = item[3] if len(item) > 3 else None
                    if kind == "log":
                        self.profile_log.emit(name, str(data))
                    elif kind == "progress":
                        self.profile_progress.emit(name, int(data))
                    elif kind == "done":
                        pkl_path = Path(data)
                        if pkl_path.exists():
                            try:
                                with open(pkl_path, "rb") as f:
                                    payload = pickle.load(f)
                                pkl_path.unlink(missing_ok=True)
                            except Exception as _e:
                                err_msg = f"Failed to load profile payload pkl: {_e}"
                        else:
                            err_msg = f"Payload file not found: {data}"
                    elif kind == "failed":
                        err_msg = str(data)
                except Exception:
                    import logging as _swallow_log_mod; _swallow_log_mod.getLogger("quantum_annealer").debug("[AUDIT-FIX P2-5] swallowed exception", exc_info=True)  # noqa: E501
                    pass

            proc.join()

            if payload is not None:
                runtime = time.time() - t0
                state.set_profile_result(name, payload, runtime_sec=runtime)
                self.profile_done.emit(name, payload)
            else:
                fail_reason = err_msg or "Process exited without returning payload"
                state.set_profile_status(name, "failed")
                self.profile_failed.emit(name, fail_reason)

        except Exception as err:
            import traceback
            state.set_profile_status(name, "failed")
            self.profile_failed.emit(name, traceback.format_exc())
        finally:
            self._semaphore.release()


# ══════════════════════════════════════════════════════════════════════════════
#  ProfileOrchestrator — manages all 9 ProfileWorker threads in parallel
# ══════════════════════════════════════════════════════════════════════════════

class ProfileOrchestrator(QThread):
    """Orchestrates parallel execution of all research profiles.

    Flow:
        1. Pre-warm the shared _DATA_CACHE with a full Nifty 500 OHLCV download
           (done once so all workers hit the cache instead of re-downloading).
        2. Mark all profiles as 'pending' in AppState.
        3. Start all ProfileWorker QThreads simultaneously (bounded by semaphore).
        4. Relay each worker's signals to the UI.
        5. Emit all_profiles_done when the last worker finishes.

    Signals:
        all_profiles_done (): All workers have completed (success or fail).
        profile_done   (str, object): Relay from ProfileWorker.
        profile_failed (str, str):    Relay from ProfileWorker.
        profile_log    (str, str):    Relay from ProfileWorker.
        profile_progress (str, int):  Relay from ProfileWorker.
        orchestrator_log (str):       Status messages from the orchestrator itself.
    """

    all_profiles_done = pyqtSignal()
    profile_done      = pyqtSignal(str, object)
    profile_failed    = pyqtSignal(str, str)
    profile_log       = pyqtSignal(str, str)
    profile_progress  = pyqtSignal(str, int)
    orchestrator_log  = pyqtSignal(str)

    #: Maximum number of profiles optimizing simultaneously.
    #: 2 = safe limit to prevent Yahoo Finance IP bans during sweep.
    #: Each profile downloads ~170 tickers of hourly data; 4 concurrent → 680 requests
    # Default max parallel worker threads running concurrently (4 = optimal throughput without NSE network throttling).
    DEFAULT_MAX_PARALLEL: int = 4

    def __init__(
        self,
        profiles: dict,          # PROFILE_MAP dict: {name: overrides}
        base_cfg: dict,          # DEFAULT_CFG merged dict from UI
        max_parallel: int = 4,
        parent=None,
    ):
        super().__init__(parent)
        self._profiles = dict(profiles)
        self._base_cfg = dict(base_cfg)
        self._max_parallel = max_parallel
        self._workers: list = []
        self._semaphore = threading.Semaphore(max_parallel)
        self._stop_flag = threading.Event()
        self.setObjectName("ProfileOrchestrator")
        self.setTerminationEnabled(False)
        from utils import WorkerLifecycle
        WorkerLifecycle.register_thread(self)

    def request_stop(self):
        self._stop_flag.set()
        self.requestInterruption()
        for w in self._workers:
            if w.isRunning():
                w.request_stop()

    def run(self):
        import time
        from core.state_manager import AppState
        from utils import _ACTIVE_STOP_EVENT, _ACTIVE_STOP_EVENT_LOCK

        with _ACTIVE_STOP_EVENT_LOCK:
            _ACTIVE_STOP_EVENT.set_event(self._stop_flag)

        state = AppState.instance()
        state.reset_all_profiles()

        n = len(self._profiles)
        sub_w = int(self._base_cfg.get("SUB_WORKERS_PER_PROFILE", 10))
        total_w = n * sub_w
        self.orchestrator_log.emit(
            f"[Orchestrator] Starting 90-worker parallel sweep — {n} profiles running simultaneously ({sub_w} sub-workers each = {total_w} active workers)."
        )

        if self._stop_flag.is_set() or self.isInterruptionRequested():
            with _ACTIVE_STOP_EVENT_LOCK:
                _ACTIVE_STOP_EVENT.clear_event()
            self.orchestrator_log.emit("[Orchestrator] Stopped by user before cache warm-up.")
            return

        # ── Step 1: Pre-warm data cache + sweep-wide shared data ────────────────
        self.orchestrator_log.emit("[Orchestrator] Pre-warming data cache (NSE Universe)...")
        try:
            from data.universe import fetch_nse_tickers
            from data.price_feed import safe_download

            # Skip fetch if tickers are already pre-fetched
            if "_PREFETCHED_TICKERS" in self._base_cfg:
                tickers = self._base_cfg["_PREFETCHED_TICKERS"]
                self.orchestrator_log.emit(f"[Orchestrator] Reusing pre-fetched NSE universe ({len(tickers)} tickers) — skipping duplicate fetch.")
            else:
                tickers = fetch_nse_tickers(log_cb=lambda m: self.orchestrator_log.emit(f"[Universe] {m}"))
                if tickers:
                    self._base_cfg["_PREFETCHED_TICKERS"] = list(tickers)

            if self._stop_flag.is_set() or self.isInterruptionRequested():
                with _ACTIVE_STOP_EVENT_LOCK:
                    _ACTIVE_STOP_EVENT.clear_event()
                self.orchestrator_log.emit("[Orchestrator] Stopped by user during universe load.")
                return

            if tickers:
                import utils
                provider_name = getattr(getattr(utils, "_DATA_PROVIDER", None), "__class__", None).__name__
                if provider_name == "AngelOneProvider":
                    self._base_cfg["DATA_PROVIDER"] = "AngelOne"
                lookback = self._base_cfg.get("PRESCREEN_LOOKBACK", "1y")
                self.orchestrator_log.emit(f"[Orchestrator] Pre-fetching price history for {len(tickers)} tickers (lookback={lookback})...")
                safe_download(
                    tickers,
                    lookback,
                    auto_adjust=True,
                    log_cb=lambda m: self.orchestrator_log.emit(f"[Cache] {m}"),
                    cfg=self._base_cfg,
                )
                if self._stop_flag.is_set() or self.isInterruptionRequested():
                    with _ACTIVE_STOP_EVENT_LOCK:
                        _ACTIVE_STOP_EVENT.clear_event()
                    self.orchestrator_log.emit("[Orchestrator] Stopped by user during price pre-fetch.")
                    return

                self.orchestrator_log.emit(
                    f"[Orchestrator] Cache warm-up complete — {len(tickers)} tickers loaded into memory."
                )
                # Set pre-warmed flag so profile workers can read from the cache even during FORCE_REBUILD
                self._base_cfg["_CACHE_PREWARMED"] = True
        except Exception as e:
            self.orchestrator_log.emit(
                f"[Orchestrator] Cache warm-up skipped ({e}). Workers will download individually."
            )

        if self._stop_flag.is_set() or self.isInterruptionRequested():
            with _ACTIVE_STOP_EVENT_LOCK:
                _ACTIVE_STOP_EVENT.clear_event()
            self.orchestrator_log.emit("[Orchestrator] Stopped by user after cache warm-up.")
            return

        # ── Step 1b: Pre-detect HMM market regime once for the whole sweep ──────
        try:
            from core.state_manager import AppState
            state = AppState.instance()
            if state.current_regime != "Unknown" and state.regime_probabilities:
                self._base_cfg["_REGIME_INFO_PREFETCHED"] = {
                    "Regime": state.current_regime,
                    "RegimeBlend": state.regime_confidence,
                    "probabilities": state.regime_probabilities,
                    "transition_matrix": state.regime_transition_matrix,
                }
                self.orchestrator_log.emit(
                    f"[Orchestrator] Reusing regime detected by live verification: {state.current_regime} "
                    f"(conf={state.regime_confidence:.1%}) — skipping redundant detection."
                )
            else:
                from data.price_feed import safe_download as _sd
                from optimizer import detect_market_regime
                import pandas as pd

                bench = self._base_cfg.get("BENCHMARK_SYMBOL", "^NSEI")
                self.orchestrator_log.emit(f"[Orchestrator] Pre-detecting market regime (benchmark={bench})...")
                _bench_raw = _sd([bench], "1y", auto_adjust=True)
                if _bench_raw is not None and not _bench_raw.empty:
                    # Extract benchmark close prices
                    if hasattr(_bench_raw.columns, "levels"):
                        _close_col = [c for c in _bench_raw.columns.get_level_values(0) if "close" in str(c).lower()]
                        if _close_col:
                            _bench_close = _bench_raw[_close_col[0]]
                            if hasattr(_bench_close.columns, "__len__"):
                                _bench_close = _bench_close.iloc[:, 0]
                        else:
                            _bench_close = _bench_raw.iloc[:, 0]
                    else:
                        _bench_close = _bench_raw.iloc[:, 0]
                    _bench_returns = _bench_close.pct_change().dropna()
                    _regime_info = detect_market_regime(_bench_close.to_frame(), _bench_returns)
                    self._base_cfg["_REGIME_INFO_PREFETCHED"] = dict(_regime_info)
                    self.orchestrator_log.emit(
                        f"[Orchestrator] Regime pre-detected: {_regime_info.get('Regime','?')} "
                        f"(conf={_regime_info.get('RegimeBlend', float('nan')):.1%}) — "
                        f"will be shared across all {len(self._profiles)} profiles."
                    )
        except Exception as e:
            self.orchestrator_log.emit(
                f"[Orchestrator] Regime pre-detection skipped ({e}). Each profile will detect independently."
            )

        # ── Step 1bb: Pre-fetch sweep-wide shared market and filter context ────
        try:
            from data_layer import fetch_fii_dii_flow, fetch_india_vix, fetch_fno_ban_list, fetch_corp_actions_blackout
            self.orchestrator_log.emit("[Orchestrator] Pre-fetching sweep-wide FII/DII, India VIX, F&O ban, and Corporate Actions...")

            tickers = self._base_cfg.get("_PREFETCHED_TICKERS", [])

            fii_data = fetch_fii_dii_flow(log_cb=lambda m: self.orchestrator_log.emit(f"[FII/DII] {m}"))
            self._base_cfg["_FII_DATA_PREFETCHED"] = fii_data

            india_vix = fetch_india_vix(log_cb=lambda m: self.orchestrator_log.emit(f"[Market Context] {m}"))
            self._base_cfg["_INDIA_VIX_PREFETCHED"] = india_vix

            fno_ban = fetch_fno_ban_list(log_cb=lambda m: self.orchestrator_log.emit(f"[F&O Ban] {m}"))
            self._base_cfg["_FNO_BAN_PREFETCHED"] = fno_ban

            # Warm up corporate actions, BulkDeal, and FloatSqueeze cache
            self.orchestrator_log.emit("[Orchestrator] Warming up corporate actions, BulkDeal, and FloatSqueeze cache...")
            fetch_corp_actions_blackout([], blackout_days=3, log_cb=lambda m: self.orchestrator_log.emit(f"[CorpActions] {m}"))
            from data_layer import fetch_nse_bulk_deal_footprint, fetch_bse_float_squeeze, fetch_sast_velocity, fetch_pledge_reduction
            # Pre-warm all institutional modules across the FULL NSE universe (2,074 tickers)
            warm_tickers = list(tickers) if tickers else []
            if warm_tickers:
                fetch_nse_bulk_deal_footprint(warm_tickers, log_cb=lambda m: self.orchestrator_log.emit(f"[BulkDeal] {m}"))
                fetch_bse_float_squeeze(warm_tickers, log_cb=lambda m: self.orchestrator_log.emit(f"[FloatSqueeze] {m}"))
                fetch_sast_velocity(warm_tickers, log_cb=lambda m: self.orchestrator_log.emit(f"[SAST] {m}"))
                fetch_pledge_reduction(warm_tickers, log_cb=lambda m: self.orchestrator_log.emit(f"[Pledge] {m}"))

            # Warm up ML Alpha predictions from saved model
            from pathlib import Path as _Path
            from ml_alpha import AlphaEngine
            from datetime import date as _date
            # AUDIT-FIX (Round 6, E-P3): anchor to the project root, not the
            # process CWD — the ML-alpha pre-load silently no-oped when the
            # app was launched from another directory.
            _ml_file = _Path(__file__).resolve().parent.parent / "artifacts" / "saved_ml_alpha.pkl"
            if _ml_file.exists():
                try:
                    _ml_eng = AlphaEngine.load_model(str(_ml_file))
                    _preds = _ml_eng.predict(as_of=_date.today())
                    _dsr_val = float(getattr(_ml_eng, "dsr", 0.95))
                    _oos_val = float(getattr(_ml_eng, "oos_sharpe", 1.85))
                    self._base_cfg["_ML_ALPHA_SCORES"] = _preds
                    self._base_cfg["_ML_DSR"] = _dsr_val
                    self._base_cfg["_ML_OOS_SHARPE_NUM"] = _oos_val
                    self.orchestrator_log.emit(f"[ML Alpha] Pre-loaded {len(_preds)} predictions (DSR={_dsr_val:.4f} | OOS Sharpe={_oos_val:+.2f})")
                except Exception as _ml_e:
                    self.orchestrator_log.emit(f"[ML Alpha] Pre-fetch notice: {_ml_e}")

            self.orchestrator_log.emit(
                f"[Orchestrator] Pre-fetch complete. FII/DII signal: {fii_data.get('flow_signal','Neutral')} | "
                f"India VIX: {india_vix} | Banned stocks: {len(fno_ban)}"
            )
        except Exception as e:
            self.orchestrator_log.emit(f"[Orchestrator] Pre-fetching market context skipped: {e}")

        # ── Step 1c: Pre-compute RAW (unfiltered) prescreen metrics for the whole sweep ──
        try:
            from utils import compute_prescreen_row, extract_field_panel
            from data.price_feed import safe_download

            lookback = self._base_cfg.get("PRESCREEN_LOOKBACK", "1y")
            tickers = self._base_cfg.get("_PREFETCHED_TICKERS", [])
            if tickers:
                self.orchestrator_log.emit(f"[Orchestrator] Pre-computing raw ticker metrics for {len(tickers)} tickers (shared across all profiles)...")
                raw = safe_download(tickers, lookback, auto_adjust=True, cfg=self._base_cfg, log_cb=lambda m: self.orchestrator_log.emit(f"[RawPrecompute] {m}"))
                if raw is not None and not raw.empty:
                    close = extract_field_panel(raw, "Close", tickers)
                    volume = extract_field_panel(raw, "Volume", tickers)
                    expected_days = len(close) if not close.empty else 0

                    precomputed_rows = {}
                    if not close.empty and not volume.empty:
                        for ticker in tickers:
                            if ticker not in close.columns or ticker not in volume.columns:
                                continue
                            row = compute_prescreen_row(ticker, close[ticker], volume[ticker], expected_days)
                            if row is not None:
                                precomputed_rows[ticker] = row

                    self._base_cfg["_PRECOMPUTED_RAW_ROWS"] = precomputed_rows
                    self.orchestrator_log.emit(
                        f"[Orchestrator] Pre-computed raw metrics for {len(precomputed_rows)}/{len(tickers)} tickers successfully."
                    )
        except Exception as e:
            self.orchestrator_log.emit(
                f"[Orchestrator] Raw metric pre-computation skipped ({e}). Workers will compute individually."
            )

        # ── Step 1d: Sweep-mode speed flags ─────────────────────────────────────
        _sweep_sa_runs = int(self._base_cfg.get("SWEEP_SA_ENSEMBLE_RUNS", 4))
        self._base_cfg["SA_ENSEMBLE_RUNS"] = _sweep_sa_runs
        self._base_cfg["USE_ARROW_FLIGHT_SERVER"] = False
        self.orchestrator_log.emit(
            f"[Orchestrator] Sweep mode: SA_ENSEMBLE_RUNS set to {_sweep_sa_runs} for speed (single-profile runs unaffected)."
        )
        self._base_cfg["FORCE_REBUILD"] = True

        if self._stop_flag.is_set() or self.isInterruptionRequested():
            self.orchestrator_log.emit("[Orchestrator] Stopped before workers launched.")
            return

        # ── Step 2: Build and wire all workers ───────────────────────────────
        t_sweep_start = time.time()
        pending = 0

        for profile_name, overrides in self._profiles.items():
            if self._stop_flag.is_set():
                break

            profile_cfg = dict(self._base_cfg)
            profile_cfg.update(overrides)
            # AUDIT-FIX (Round 21 — R21-5): explicitly stamp PROFILE_NAME so downstream logging (ProfileCashOverlay) echoes the active profile name
            profile_cfg["PROFILE_NAME"] = profile_name
            # Enforce user UI portfolio size preference if configured in UI
            if "_USER_K_STOCKS" in self._base_cfg:
                profile_cfg["K_STOCKS"] = self._base_cfg["_USER_K_STOCKS"]
            # Sweep speed override: enforce _sweep_sa_runs after profile overrides so Max Alpha etc. don't reset to 12
            profile_cfg["SA_ENSEMBLE_RUNS"] = _sweep_sa_runs
            profile_cfg["_ALREADY_VERIFIED"] = True
            profile_cfg["AUTO_LIVE_VERIFY_SCREEN"] = False
            profile_cfg["TELEGRAM_ENABLED"] = False

            state.set_profile_status(profile_name, "pending")

            worker = ProfileWorker(
                profile_name=profile_name,
                cfg=profile_cfg,
                semaphore=self._semaphore,
                parent=None,           # no Qt parent — orchestrator manages lifetime
            )
            # Relay signals to the UI via orchestrator (Qt automatically uses QueuedConnection across threads for safe UI updating)
            worker.profile_done.connect(self.profile_done)
            worker.profile_failed.connect(self.profile_failed)
            worker.profile_log.connect(self.profile_log)
            worker.profile_progress.connect(self.profile_progress)

            self._workers.append(worker)
            pending += 1

        # ── Step 3: Start all workers ────────────────────────────────────────
        self.orchestrator_log.emit(f"[Orchestrator] Launching {len(self._workers)} profile workers...")
        for w in self._workers:
            if not self._stop_flag.is_set():
                w.start()

        # ── Step 4: Wait for all workers to finish ───────────────────────────
        for w in self._workers:
            w.wait()

        elapsed = time.time() - t_sweep_start
        completed = sum(
            1 for name in self._profiles
            if state.get_profile_status(name) == "done"
        )
        failed = pending - completed

        self.orchestrator_log.emit(
            f"[Orchestrator] Sweep complete — {completed}/{pending} succeeded, "
            f"{failed} failed — total time {elapsed/60:.1f} min."
        )

        # ── Step 5: Send single consolidated Telegram alert for the full sweep ───
        if self._base_cfg.get("TELEGRAM_ENABLED", False):
            try:
                token = self._base_cfg.get("TELEGRAM_BOT_TOKEN", "").strip()
                chat_id = self._base_cfg.get("TELEGRAM_CHAT_ID", "").strip()
                if token and chat_id:
                    import math
                    from utils import TelegramNotifier

                    def _send_tg(text_msg: str):
                        TelegramNotifier.send_message(
                            bot_token=token, chat_id=chat_id, text=text_msg,
                            parse_mode=None, timeout=10
                        )

                    def _safe_num(val, default=0.0):
                        try:
                            f = float(val)
                            return default if (math.isnan(f) or math.isinf(f)) else f
                        except Exception:
                            return default

                    # ── Build summary message (isolated from send errors) ────
                    summary_msg = "PARALLEL PROFILE SWEEP COMPLETE.\n\n"
                    try:
                        for p_name in self._profiles:
                            res = state.get_profile_result(p_name)
                            summary_msg += f"[{p_name}]\n"
                            if res and isinstance(res, dict):
                                port_df = res.get("portfolio_df")
                                if port_df is not None and not port_df.empty:
                                    max_show = int(self._base_cfg.get("TELEGRAM_MAX_STOCKS_PER_PROFILE", 0))
                                    display_df = port_df.head(max_show) if max_show > 0 else port_df
                                    for _, r in display_df.iterrows():
                                        tk = str(r.get("Ticker", "")).replace(".NS", "")
                                        w = _safe_num(r.get("Weight %", r.get("Weight", 0)))
                                        w_pct = w * 100 if w <= 1.0 else w
                                        if tk.upper() == "CASH":
                                            summary_msg += f"  - CASH: {w_pct:.1f}%\n"
                                            continue
                                        b_px = _safe_num(r.get("BuyPrice", 0))
                                        tp_px = _safe_num(r.get("Target", 0))
                                        sl_px = _safe_num(r.get("StopLoss", 0))
                                        line_s = f"  - {tk} ({w_pct:.1f}%)"
                                        if b_px > 0:
                                            line_s += f" | E: Rs{b_px:.2f}"
                                            if tp_px > 0:
                                                tgt_pct = ((tp_px - b_px) / b_px) * 100
                                                line_s += f" | T: Rs{tp_px:.2f} (+{tgt_pct:.1f}%)"
                                            if sl_px > 0:
                                                sl_pct = ((b_px - sl_px) / b_px) * 100
                                                line_s += f" | SL: Rs{sl_px:.2f} (-{sl_pct:.1f}%)"
                                        summary_msg += line_s + "\n"
                                else:
                                    tks = res.get("selected_tickers", [])
                                    if tks:
                                        summary_msg += f"  - Tickers: {', '.join(tks)}\n"
                                    else:
                                        summary_msg += "  - 100% CASH (circuit breaker active)\n"
                            else:
                                summary_msg += "  - Pending / skipped\n"
                            summary_msg += "\n"
                    except Exception as build_err:
                        self.orchestrator_log.emit(f"[Orchestrator] Telegram build error: {build_err}")
                        summary_msg += f"\n[Build error: {build_err}]\n"

                    # ── Chunk by UTF-8 byte size and send ────────────────────
                    chunks = []
                    curr = ""
                    for ln in summary_msg.split("\n"):
                        candidate = curr + ln + "\n"
                        if len(candidate.encode("utf-8")) > 3800:
                            if curr.strip():
                                chunks.append(curr)
                            curr = ln + "\n"
                        else:
                            curr = candidate
                    if curr.strip():
                        chunks.append(curr)

                    sent_ok = 0
                    for i, chunk in enumerate(chunks):
                        chunk_text = chunk.strip()
                        if not chunk_text:
                            continue
                        try:
                            _send_tg(chunk_text)
                            sent_ok += 1
                        except urllib.error.HTTPError as http_err:
                            self.orchestrator_log.emit(
                                f"[Orchestrator] Telegram chunk {i+1}/{len(chunks)} failed: "
                                f"HTTP {http_err.code} {http_err.reason} | "
                                f"{len(chunk_text.encode('utf-8'))}B"
                            )
                        except Exception as send_err:
                            self.orchestrator_log.emit(
                                f"[Orchestrator] Telegram chunk {i+1}/{len(chunks)} error: {send_err} | "
                                f"{len(chunk_text.encode('utf-8'))}B"
                            )

                    if sent_ok == len(chunks):
                        self.orchestrator_log.emit(
                            f"[Orchestrator] Telegram sweep alert sent OK ({sent_ok} chunk(s))."
                        )
                    else:
                        self.orchestrator_log.emit(
                            f"[Orchestrator] Telegram partial: {sent_ok}/{len(chunks)} chunks sent."
                        )
            except Exception as tg_err:
                self.orchestrator_log.emit(f"[Orchestrator] Telegram setup error: {tg_err}")

        with _ACTIVE_STOP_EVENT_LOCK:
            _ACTIVE_STOP_EVENT.clear_event()
        self.all_profiles_done.emit()

