/**
 * web_dashboard/dashboard.js (v4.0)
 * =================================
 * Exact 1-to-1 Controller for the Desktop Replica Workstation.
 * Mirrors all 27 native tabs, settings modal, and quantitative pipelines.
 */

let activeTabIndex = 0;
let backtestChartInstance = null;
let factorAttrChartInstance = null;

// These are populated ONLY from live API calls — never hardcoded
let cachedStocks = [];
let cachedAllocations = [];
let cachedBreakouts = [];
let cachedPrebreakouts = [];

document.addEventListener("DOMContentLoaded", () => {
  console.log("🚀 Initializing Quantum Annealer Desktop Replica v4.0...");
  syncChartsList();
  fetchInitialUniverse();
  try {
    const saved = localStorage.getItem("qa_prev_allocations");
    if (saved) window.__prevAllocations = JSON.parse(saved);
  } catch (e) {}

  loadProfilePortfolio();
  fetchInitialMarketStatus();
  fetchMoEStatus();
  fetchJournalLog();
  fetchTechnicalHub();
  fetchWatchlistExports();
  fetchAllProfilesConsensus();
  fetchLogs();
  initBacktestChart();
  initAttributionChart();
  loadInstitutionalPresets();
  loadSharpeWaterfall();
  loadFrontierTelemetry();
  loadTier0PlusTelemetry();
  loadTierOmegaTelemetry();
  loadTradeExecutionSuite();
  checkKillSwitchStatus();
  loadPretradeRiskStatus();
  loadOMSOrdersHistory();
  loadTCAReport();
  setInterval(checkKillSwitchStatus, 10000);

  const bmSelect = document.getElementById("benchmarkSelect");
  if (bmSelect) {
    bmSelect.addEventListener("change", (e) => onBenchmarkSelectChange(e.target.value));
  }
});


// ── Tab Switching across All 27 Tabs ──────────────────────────────────────────
function switchDesktopTab(idx, tabId) {
  activeTabIndex = idx;

  // Update Tab Buttons
  document.querySelectorAll(".tab-btn").forEach((btn, i) => {
    btn.classList.toggle("active", i === idx);
  });

  // Close dropdown if open
  closeMoreDropdown();

  // Show active tab panel
  document.querySelectorAll(".desktop-tab-panel").forEach(p => p.classList.remove("active"));
  const panel = document.getElementById(tabId);
  if (panel) {
    panel.classList.add("active");
  }

  // Always ensure dynamic tabs are synchronized with active portfolio
  renderDynamicTabs(cachedAllocations, cachedStocks);

  if (tabId === "tab-universe") {
    if (cachedStocks && cachedStocks.length > 0) {
      renderUniverseTable(cachedStocks);
    } else {
      fetchInitialUniverse();
    }
  }
  if (tabId === "tab-sectors" || tabId === "tab-sector-rs") {
    if (!cachedStocks || cachedStocks.length === 0) {
      fetchInitialUniverse();
    } else {
      renderDynamicTabs(cachedAllocations, cachedStocks);
    }
  }

  if (tabId === "tab-logs") {
    fetchLogs();
  }
  if (tabId === "tab-watchlist") {
    fetchWatchlistExports();
  }
  if (tabId === "tab-all-profiles") {
    fetchAllProfilesConsensus();
  }
  if (["tab-exposures", "tab-alerts", "tab-factors", "tab-oos-backtest"].includes(tabId)) {
    initMaster25Modules();
    if (tabId === "tab-exposures") {
      renderExposuresTable();
      setTimeout(async () => {
        initMonteCarloChart();
        if (!cachedCorrelationMatrix) {
          try {
            const cRes = await fetch("/api/correlation_matrix");
            const cData = await cRes.json();
            if (cData.correlation_matrix && cData.correlation_tickers) {
              cachedCorrelationMatrix = cData.correlation_matrix;
              cachedCorrelationTickers = cData.correlation_tickers;
            }
          } catch (e) {}
        }
        renderCovarianceHeatmap(cachedCorrelationMatrix, cachedCorrelationTickers);
      }, 50);
    }
    if (tabId === "tab-factors") {
      setTimeout(() => {
        initFamaFrenchRadarChart();
      }, 50);
    }
    if (tabId === "tab-oos-backtest") {
      setTimeout(() => {
        initBacktestChart();
        initAttributionChart();
      }, 50);
    }
  }

  if (tabId === "tab-charts") {
    if (!currentTradingViewSymbol) {
      const topPick = cachedAllocations.length > 0 ? cachedAllocations[0].ticker : (cachedStocks.length > 0 ? cachedStocks[0].Ticker : "NIFTY.NS");
      loadTradingViewChart(topPick);
    }
  }

  const tabContentContainer = document.querySelector(".tab-content-container");
  if (tabContentContainer) {
    if (tabId === "tab-charts") {
      tabContentContainer.classList.add("chart-active");
    } else if (tabId !== "tab-all-profiles") {
      tabContentContainer.classList.remove("chart-active");
    }
  }

  // Handle Chart resizes
  if (tabId === "tab-factor-attr" && factorAttrChartInstance) {
    factorAttrChartInstance.resize();
  }
}

function selectDropdownTab(idx, tabId, labelName) {
  activeTabIndex = idx;

  // Uncheck top 10 tabs
  document.querySelectorAll(".tab-btn").forEach(btn => btn.classList.remove("active"));

  // Update dropdown label to show selected tab
  const dropdownLabel = document.getElementById("moreDropdownLabel");
  if (dropdownLabel) {
    dropdownLabel.innerText = `More: ${labelName} ▾`;
  }

  closeMoreDropdown();

  // Show active panel
  document.querySelectorAll(".desktop-tab-panel").forEach(p => p.classList.remove("active"));
  const panel = document.getElementById(tabId);
  if (panel) {
    panel.classList.add("active");
  }

  if (tabId === "tab-factor-attr" && factorAttrChartInstance) {
    factorAttrChartInstance.resize();
  }
  if (tabId === "tab-execution") {
    loadTradeExecutionSuite();
    loadTier0PlusTelemetry();
    loadTierOmegaTelemetry();
  } else if (tabId === "tab-diagnostics") {
    loadFrontierTelemetry();
    loadTier0PlusTelemetry();
    loadTierOmegaTelemetry();
  }
}

function toggleMoreDropdown() {
  const menu = document.getElementById("moreDropdownMenu");
  if (menu) menu.classList.toggle("show");
}

function closeMoreDropdown() {
  const menu = document.getElementById("moreDropdownMenu");
  if (menu) menu.classList.remove("show");
}

window.onclick = function (event) {
  if (!event.target.matches('.dropdown-tab-btn') && !event.target.matches('#moreDropdownLabel')) {
    closeMoreDropdown();
  }
};

// ── Collapsible Sidebar Sections ─────────────────────────────────────────────
function toggleSidebarSection(contentId) {
  const content = document.getElementById(contentId);
  const header = document.getElementById("advPenaltiesHeader");
  if (content) {
    if (content.style.display === "none") {
      content.style.display = "block";
      if (header) header.innerText = "▼ Advanced Penalties & Risk";
    } else {
      content.style.display = "none";
      if (header) header.innerText = "► Advanced Penalties & Risk";
    }
  }
}

// ── Settings Modal ────────────────────────────────────────────────────────────
async function openSettingsModal() {
  document.getElementById("settingsModal").classList.add("active");
  try {
    const res = await fetch("/api/settings");
    const data = await res.json();
    
    // Telegram Token & Status
    const tgBadge = document.getElementById("tgStatusBadge");
    const tgHint = document.getElementById("tgTokenHint");
    const tgInput = document.getElementById("modalTgToken");
    const tgChatInput = document.getElementById("modalTgChatId");
    const tgEnabled = document.getElementById("modalTgEnabled");

    if (tgChatInput) tgChatInput.value = data.telegram_chat_id || "";
    if (tgEnabled) tgEnabled.checked = data.telegram_enabled !== false;

    if (data.telegram_token_configured && data.telegram_token) {
      if (tgBadge) {
        tgBadge.innerHTML = `🟢 Configured (${data.telegram_token})`;
        tgBadge.style.cssText = "font-size:11px; font-weight:600; padding:2px 8px; border-radius:12px; background:rgba(8,153,129,0.2); color:var(--tv-green);";
      }
      if (tgHint) {
        tgHint.innerHTML = `✓ Active bot token saved on disk (ends in <b>${data.telegram_token.replace(/•/g, "")}</b>). Leave blank to keep existing, or paste new token to replace.`;
      }
      if (tgInput) {
        tgInput.value = "";
        tgInput.placeholder = `Saved (${data.telegram_token}) — type new token to replace`;
      }
    } else {
      if (tgBadge) {
        tgBadge.innerHTML = "⚪ Not Configured";
        tgBadge.style.cssText = "font-size:11px; font-weight:600; padding:2px 8px; border-radius:12px; background:rgba(255,255,255,0.06); color:var(--text-muted);";
      }
      if (tgHint) {
        tgHint.innerHTML = "No bot token configured. Create a bot via @BotFather and paste the token above.";
      }
      if (tgInput) {
        tgInput.value = "";
        tgInput.placeholder = "Paste your Telegram Bot Token from @BotFather";
      }
    }

    if (document.getElementById("modalAngelKey")) document.getElementById("modalAngelKey").value = data.angel_api_key || "";
    if (document.getElementById("modalAngelClientCode")) document.getElementById("modalAngelClientCode").value = data.angel_client_code || "";
    if (document.getElementById("modalGeminiKey")) document.getElementById("modalGeminiKey").value = data.gemini_api_key || "";
    if (document.getElementById("modalGeminiModel")) document.getElementById("modalGeminiModel").value = data.gemini_model || "gemini-flash-latest";
  } catch (e) {
    console.warn("Could not fetch settings:", e);
  }
}

function closeSettingsModal() {
  document.getElementById("settingsModal").classList.remove("active");
}

function toggleTgTokenVisibility() {
  const input = document.getElementById("modalTgToken");
  const btn = document.getElementById("btnToggleTgToken");
  if (!input) return;
  if (input.type === "password") {
    input.type = "text";
    if (btn) btn.innerHTML = "🔒 Hide Token";
  } else {
    input.type = "password";
    if (btn) btn.innerHTML = "👁️ Show Token";
  }
}

async function clearTgToken() {
  if (!confirm("Are you sure you want to clear and remove the saved Telegram Bot Token?")) return;
  try {
    const res = await fetch("/api/settings/save", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ clear_telegram_token: true })
    });
    const data = await res.json();
    const tgInput = document.getElementById("modalTgToken");
    const tgBadge = document.getElementById("tgStatusBadge");
    const tgHint = document.getElementById("tgTokenHint");
    if (tgInput) {
      tgInput.value = "";
      tgInput.placeholder = "Paste your Telegram Bot Token from @BotFather";
    }
    if (tgBadge) {
      tgBadge.innerHTML = "⚪ Not Configured";
      tgBadge.style.cssText = "font-size:11px; font-weight:600; padding:2px 8px; border-radius:12px; background:rgba(255,255,255,0.06); color:var(--text-muted);";
    }
    if (tgHint) tgHint.innerHTML = "Telegram Bot Token has been cleared from disk.";
    alert("🗑️ Telegram Bot Token cleared successfully.");
  } catch (e) {
    alert("Error clearing Telegram token: " + e);
  }
}

async function saveTelegramOnly(btn) {
  const tokenInput = document.getElementById("modalTgToken");
  const chatIdInput = document.getElementById("modalTgChatId");
  const enabledInput = document.getElementById("modalTgEnabled");

  const rawToken = tokenInput ? tokenInput.value.trim() : "";
  const chatId = chatIdInput ? chatIdInput.value.trim() : "";
  const isEnabled = enabledInput ? enabledInput.checked : true;

  if (btn) {
    btn.disabled = true;
    btn.innerText = "⏳ Saving...";
  }

  const payload = {
    telegram_chat_id: chatId,
    telegram_enabled: isEnabled
  };
  if (rawToken && !rawToken.startsWith("•") && !rawToken.startsWith("....") && !rawToken.includes("•")) {
    payload.telegram_token = rawToken;
  }

  try {
    const res = await fetch("/api/settings/save", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (data.status === "SUCCESS") {
      const tgBadge = document.getElementById("tgStatusBadge");
      const tgHint = document.getElementById("tgTokenHint");
      if (data.telegram_token_configured && data.telegram_token) {
        if (tgBadge) {
          tgBadge.innerHTML = `🟢 Configured (${data.telegram_token})`;
          tgBadge.style.cssText = "font-size:11px; font-weight:600; padding:2px 8px; border-radius:12px; background:rgba(8,153,129,0.2); color:var(--tv-green);";
        }
        if (tgHint) {
          tgHint.innerHTML = `✓ Active bot token saved on disk (ends in <b>${data.telegram_token.replace(/•/g, "")}</b>). Ready for live alerts.`;
        }
        if (tokenInput) {
          tokenInput.value = "";
          tokenInput.placeholder = `Saved (${data.telegram_token}) — type new token to replace`;
        }
      }
      alert("✅ Telegram credentials saved successfully to disk and active!");
    } else {
      alert("⚠️ " + (data.message || "Could not save Telegram settings."));
    }
  } catch (err) {
    alert("❌ Network error saving Telegram credentials: " + err);
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.innerText = "💾 Save Telegram Credentials";
    }
  }
}

function switchSettingsTab(idx, contentId) {
  document.querySelectorAll(".modal-tab-btn").forEach((btn, i) => {
    btn.classList.toggle("active", i === idx);
  });
  document.querySelectorAll(".modal-tab-content").forEach(c => c.classList.remove("active"));
  const content = document.getElementById(contentId);
  if (content) content.classList.add("active");
}

async function saveSettingsModal() {
  const tgTokenVal = document.getElementById("modalTgToken") ? document.getElementById("modalTgToken").value.trim() : "";
  const payload = {
    telegram_chat_id: document.getElementById("modalTgChatId") ? document.getElementById("modalTgChatId").value.trim() : "",
    telegram_enabled: document.getElementById("modalTgEnabled") ? document.getElementById("modalTgEnabled").checked : true,
    angel_api_key: document.getElementById("modalAngelKey") ? document.getElementById("modalAngelKey").value.trim() : "",
    angel_client_code: document.getElementById("modalAngelClientCode") ? document.getElementById("modalAngelClientCode").value.trim() : "",
    gemini_api_key: document.getElementById("modalGeminiKey") ? document.getElementById("modalGeminiKey").value.trim() : "",
    gemini_model: document.getElementById("modalGeminiModel") ? document.getElementById("modalGeminiModel").value : "gemini-flash-latest"
  };

  // Only pass telegram_token if user actually typed a new token
  if (tgTokenVal && !tgTokenVal.startsWith("•") && !tgTokenVal.startsWith("....") && !tgTokenVal.includes("•")) {
    payload.telegram_token = tgTokenVal;
  }

  try {
    const res = await fetch("/api/settings/save", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    const badge = document.getElementById("geminiModelBadge");
    if (badge && payload.gemini_model) {
      badge.innerText = `Google Gemini (${payload.gemini_model}) · Search-Grounded`;
    }
    alert("✅ System & API credentials saved successfully to disk!");
    closeSettingsModal();
  } catch (err) {
    alert("Error saving settings: " + err);
  }
}

async function testTelegram() {
  const tokenInput = document.getElementById("modalTgToken");
  const chatIdInput = document.getElementById("modalTgChatId");
  const rawToken = tokenInput ? tokenInput.value.trim() : "";
  const token = (rawToken.startsWith("•") || rawToken.startsWith(".") || rawToken.includes("•")) ? "" : rawToken;
  const chatId = chatIdInput ? chatIdInput.value.trim() : "";

  if (!chatId) {
    alert("⚠️ Please enter your Telegram Chat ID.");
    if (chatIdInput) chatIdInput.focus();
    return;
  }

  try {
    const res = await fetch("/api/telegram/test", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ telegram_token: token, telegram_chat_id: chatId, save_first: true })
    });
    if (res.status === 401) {
      alert("⚠️ Session unauthorized. Please refresh the page or restart via launcher.");
      return;
    }
    const data = await res.json();
    if (data.status === "SUCCESS") {
      const tgBadge = document.getElementById("tgStatusBadge");
      if (tgBadge) {
        tgBadge.innerHTML = "🟢 Configured & Verified";
        tgBadge.style.cssText = "font-size:11px; font-weight:600; padding:2px 8px; border-radius:12px; background:rgba(8,153,129,0.2); color:var(--tv-green);";
      }
      alert("✅ " + data.message);
    } else {
      alert("⚠️ " + (data.message || "Failed to send Telegram test message. Check your token & chat ID."));
    }
  } catch (err) {
    alert("❌ Error sending Telegram test: " + err);
  }
}

// AUDIT-FIX (Round 8, J3 — Part 2B): real health-check handlers for the
// settings-modal Test buttons (previously fake alerts with hardcoded
// "✓ Connected" / "2,125 symbols validated" outcomes — see index.html).
async function testDataProvider(btn) {
  const statusEl = document.getElementById("dataProviderStatus");
  if (statusEl) { statusEl.textContent = "Status: testing…"; statusEl.style.color = "var(--text-muted)"; }
  try {
    const res = await fetch("/api/market_status");
    const data = await res.json();
    const ok = data && (data.status || data.market_status);
    if (statusEl) {
      statusEl.textContent = `Status: reachable (${ok ? "market data OK" : "degraded response"})`;
      statusEl.style.color = ok ? "var(--tv-green)" : "var(--amber-warn)";
    }
  } catch (err) {
    if (statusEl) {
      statusEl.textContent = "Status: UNREACHABLE — provider health check failed";
      statusEl.style.color = "var(--crimson-risk)";
    }
  }
}

async function testDbStore(btn) {
  const statusEl = document.getElementById("dbStoreStatus");
  if (statusEl) { statusEl.textContent = "Status: testing…"; statusEl.style.color = "var(--text-muted)"; }
  try {
    const res = await fetch("/api/db_health");
    const data = await res.json();
    if (statusEl) {
      if (data && data.status === "OK") {
        statusEl.textContent = `Status: OK — ${data.backend} (${data.tables != null ? data.tables + " tables" : "store reachable"})`;
        statusEl.style.color = "var(--tv-green)";
      } else {
        statusEl.textContent = `Status: DEGRADED — ${data && data.reason ? data.reason : "store health check failed"}`;
        statusEl.style.color = "var(--crimson-risk)";
      }
    }
  } catch (err) {
    if (statusEl) {
      statusEl.textContent = "Status: UNREACHABLE — /api/db_health failed";
      statusEl.style.color = "var(--crimson-risk)";
    }
  }
}

function openCacheManagerModal() {
  const modal = document.getElementById("cacheManagerModal");
  if (modal) {
    modal.classList.add("active");
    loadCacheStatus();
  }
}

function closeCacheManagerModal() {
  const modal = document.getElementById("cacheManagerModal");
  if (modal) modal.classList.remove("active");
}

async function testCacheManager(btn) {
  openCacheManagerModal();
}

async function loadCacheStatus() {
  const overallEl = document.getElementById("cmOverallStatus");
  if (overallEl) overallEl.innerText = "Scanning...";
  try {
    const res = await fetch("/api/cache_status");
    if (!res.ok) throw new Error("Status " + res.status);
    const data = await res.json();

    // 1. Top KPI strip
    const totalSizeEl = document.getElementById("cmTotalSize");
    if (totalSizeEl) totalSizeEl.innerText = `${data.total_size_mb || 0} MB`;
    
    const featCountEl = document.getElementById("cmFeatureCount");
    if (featCountEl) featCountEl.innerText = `${data.feature_cache ? data.feature_cache.count : 0} files`;
    
    const regAgeEl = document.getElementById("cmRegimeAge");
    if (regAgeEl) {
      const h = data.regime_model && data.regime_model.exists ? data.regime_model.age_hours : null;
      regAgeEl.innerText = h !== null ? `${h}h` : "Missing";
      regAgeEl.style.color = (h && h > 24) ? "var(--crimson-risk)" : "#34d399";
    }

    if (overallEl) {
      if (data.has_stale) {
        overallEl.innerText = "⚠️ Stale Data Detected";
        overallEl.style.color = "var(--amber-warn)";
      } else {
        overallEl.innerText = "🟢 All Fresh";
        overallEl.style.color = "var(--tv-green)";
      }
    }

    // 2. Prescreen card
    const badgePre = document.getElementById("badgePrescreen");
    const metaPre = document.getElementById("metaPrescreen");
    if (badgePre && data.prescreen_cache) {
      const pc = data.prescreen_cache;
      badgePre.className = "cache-badge " + (pc.status === "FRESH" ? "cache-badge-fresh" : (pc.status === "STALE" ? "cache-badge-stale" : "cache-badge-empty"));
      badgePre.innerText = pc.status + (pc.exists ? ` (${pc.age_hours}h)` : "");
      if (metaPre) metaPre.innerText = `Path: ${pc.path || "utils.PRESCREEN_CACHE_PATH"} · Size: ${pc.size_str} · Items: ${pc.items} · Updated: ${pc.mtime_str || "Never"}`;
    }

    // 3. Feature card
    const badgeFeat = document.getElementById("badgeFeatures");
    const metaFeat = document.getElementById("metaFeatures");
    if (badgeFeat && data.feature_cache) {
      const fc = data.feature_cache;
      badgeFeat.className = "cache-badge " + (fc.status === "FRESH" ? "cache-badge-fresh" : (fc.status === "STALE" ? "cache-badge-stale" : "cache-badge-empty"));
      badgeFeat.innerText = fc.status + (fc.exists ? ` (${fc.age_hours}h)` : "");
      if (metaFeat) metaFeat.innerText = `Path: models/feature_cache/ · Parquets: ${fc.parquet_count || 0} · Meta: ${fc.sidecar_count || 0} · Size: ${fc.size_str} · Latest: ${fc.mtime_str || "Never"}`;
    }

    // 4. Regime card
    const badgeReg = document.getElementById("badgeRegime");
    const metaReg = document.getElementById("metaRegime");
    if (badgeReg && data.regime_model) {
      const rm = data.regime_model;
      badgeReg.className = "cache-badge " + (rm.status === "FRESH" ? "cache-badge-fresh" : (rm.status === "STALE" ? "cache-badge-stale" : "cache-badge-empty"));
      badgeReg.innerText = rm.status + (rm.exists ? ` (${rm.age_hours}h)` : "");
      if (metaReg) metaReg.innerText = `Path: models/regime_hmm_latest.json · Size: ${rm.size_str} · Age: ${rm.age_hours}h · Updated: ${rm.mtime_str || "Never"}`;
    }

    // 5. Screening card
    const badgeScr = document.getElementById("badgeScreening");
    const metaScr = document.getElementById("metaScreening");
    if (badgeScr && data.screening_csvs) {
      const csvs = data.screening_csvs;
      const anyStale = csvs.some(c => c.status === "STALE");
      badgeScr.className = "cache-badge " + (anyStale ? "cache-badge-stale" : "cache-badge-fresh");
      badgeScr.innerText = anyStale ? "STALE CSVs" : "FRESH";
      if (metaScr) {
        const details = csvs.map(c => `${c.file} (${c.rows} rows, ${c.age_hours}h)`).join(" · ");
        metaScr.innerText = details || "No CSV artifacts generated yet";
      }
    }

    // 6. Memory card
    const metaMem = document.getElementById("metaMemory");
    if (metaMem && data.memory_cache) {
      metaMem.innerText = `Dynamic Prices: ${data.memory_cache.price_cache_tickers} tickers · Security Master Resolutions: ${data.memory_cache.dsm_resolved_tickers} entries`;
    }

  } catch (err) {
    console.error("Error loading cache status:", err);
    if (overallEl) {
      overallEl.innerText = "Scan Error";
      overallEl.style.color = "var(--crimson-risk)";
    }
  }
}

async function purgeCacheTarget(target, btn) {
  if (btn) {
    btn.disabled = true;
    btn.innerText = "Purging...";
  }
  try {
    const res = await fetch("/api/clear_cache", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ target: target })
    });
    const data = await res.json();
    if (data.status === "SUCCESS") {
      alert(`✓ ${data.message}`);
      await loadCacheStatus();
    } else {
      alert(`⚠️ Cache clear failed: ${data.message || "Unknown error"}`);
    }
  } catch (e) {
    alert(`❌ Network error clearing ${target} cache: ` + e);
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.innerText = target === "regime" ? "Retrain / Purge" : "Purge";
    }
  }
}

async function purgeAllCaches(btn) {
  if (!confirm("Are you sure you want to clear all stale caches and reset in-memory buffers?")) {
    return;
  }
  if (btn) {
    btn.disabled = true;
    btn.innerText = "Purging...";
  }
  try {
    const res = await fetch("/api/clear_cache", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ target: "all" })
    });
    const data = await res.json();
    alert(`✓ ${data.message}`);
    await loadCacheStatus();
    await fetchInitialUniverse();
  } catch (e) {
    alert("❌ Error purging all caches: " + e);
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.innerText = "🧹 Clear Stale Caches";
    }
  }
}

async function purgeAndForceRebuild(btn) {
  if (!confirm("This will purge all caches and immediately launch a fresh Force Full Rebuild (download live prices, re-compute 85 factors, and regenerate all CSVs). Proceed?")) {
    return;
  }
  if (btn) {
    btn.disabled = true;
    btn.innerText = "Purging & Starting Rebuild...";
  }
  try {
    await fetch("/api/clear_cache", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ target: "all" })
    });
    closeCacheManagerModal();
    await forceRebuild();
  } catch (e) {
    alert("❌ Error starting purge and rebuild: " + e);
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.innerText = "🔁 Purge & Force Full Rebuild";
    }
  }
}

async function sendTelegramSweepAlert() {
  try {
    const res = await fetch("/api/telegram/send_sweep", {
      method: "POST",
      headers: { "Content-Type": "application/json" }
    });
    const data = await res.json();
    if (data.status === "SUCCESS") {
      alert("📱 " + data.message);
    } else {
      alert("⚠️ " + (data.message || "Failed to send Telegram sweep alert."));
    }
  } catch (err) {
    alert("❌ Error sending sweep alert to Telegram: " + err);
  }
}

// ── Data Fetching & Population ────────────────────────────────────────────────
async function fetchInitialMarketStatus() {
  try {
    const res = await fetch("/api/market_status");
    const data = await res.json();
    const badge = document.getElementById("gatekeeperBadge");
    const stripRegime = document.getElementById("stripRegime");

    if (badge) {
      if (data.traffic_light_badge) {
        badge.innerText = data.traffic_light_badge;
        if (data.status === "RED") {
          badge.style.cssText = "background:rgba(239,68,68,0.15); color:#ef4444; border:1px solid rgba(239,68,68,0.3); font-size:10px; font-weight:700; padding:2px 8px; border-radius:3px;";
        } else if (data.status === "YELLOW") {
          badge.style.cssText = "background:rgba(245,158,11,0.15); color:#f59e0b; border:1px solid rgba(245,158,11,0.3); font-size:10px; font-weight:700; padding:2px 8px; border-radius:3px;";
        } else {
          badge.style.cssText = "background:var(--tv-green-dim); color:var(--tv-green); border:1px solid rgba(8,153,129,0.3); font-size:10px; font-weight:700; padding:2px 8px; border-radius:3px;";
        }
      }
    }
    if (stripRegime) {
      stripRegime.innerText = data.regime_name || data.regime || "Defensive";
    }
  } catch (e) {
    console.error("Market status fetch error:", e);
  }
}

async function fetchMoEStatus() {
  try {
    const prof = document.getElementById("profileSelect") ? document.getElementById("profileSelect").value : "";
    const res = await fetch("/api/moe_status?profile=" + encodeURIComponent(prof));
    const data = await res.json();
    if (!data || data.status === "ERROR") return;

    // Update regime badge
    const badge = document.getElementById("moeRegimeBadge");
    if (badge) {
      badge.textContent = data.macro_regime || "Chop_MeanReversion";
      if (data.macro_regime === "Bull_Trending") {
        badge.style.background = "rgba(34,197,94,0.15)";
        badge.style.color = "#22c55e";
        badge.style.borderColor = "rgba(34,197,94,0.3)";
      } else if (data.macro_regime === "HighVol_CrashStress") {
        badge.style.background = "rgba(239,68,68,0.15)";
        badge.style.color = "#ef4444";
        badge.style.borderColor = "rgba(239,68,68,0.3)";
      } else {
        badge.style.background = "rgba(234,179,8,0.15)";
        badge.style.color = "#eab308";
        badge.style.borderColor = "rgba(234,179,8,0.3)";
      }
    }

    // Update probabilities
    const probs = data.regime_probabilities || {};
    const pBull = document.getElementById("moeProbBull");
    const pChop = document.getElementById("moeProbChop");
    const pStress = document.getElementById("moeProbStress");
    if (pBull) pBull.textContent = `${Math.round((probs.P_Bull || 0) * 100)}%`;
    if (pChop) pChop.textContent = `${Math.round((probs.P_Chop || 0) * 100)}%`;
    if (pStress) pStress.textContent = `${Math.round((probs.P_Stress || 0) * 100)}%`;

    // Update weight bar segments
    const w = data.active_weights || {};
    const wIpo = (w.ipo || 0) * 100;
    const wMom = (w.momentum || 0) * 100;
    const wFlow = (w.flow || 0) * 100;
    const wQual = (w.quality || 0) * 100;
    const wDef = (w.defensive || 0) * 100;

    const elIpo = document.getElementById("wSegIpo");
    const elMom = document.getElementById("wSegMom");
    const elFlow = document.getElementById("wSegFlow");
    const elQual = document.getElementById("wSegQual");
    const elDef = document.getElementById("wSegDef");
    if (elIpo) { elIpo.style.width = `${wIpo}%`; elIpo.title = `IPO: ${wIpo.toFixed(1)}%`; }
    if (elMom) { elMom.style.width = `${wMom}%`; elMom.title = `Momentum: ${wMom.toFixed(1)}%`; }
    if (elFlow) { elFlow.style.width = `${wFlow}%`; elFlow.title = `Flow: ${wFlow.toFixed(1)}%`; }
    if (elQual) { elQual.style.width = `${wQual}%`; elQual.title = `Quality: ${wQual.toFixed(1)}%`; }
    if (elDef) { elDef.style.width = `${wDef}%`; elDef.title = `Defensive: ${wDef.toFixed(1)}%`; }

    const sumEl = document.getElementById("moeWeightsSummary");
    if (sumEl && data.primary_archetype) {
      sumEl.textContent = `Anchor: ${data.primary_archetype.toUpperCase()}`;
    }

    // Update metrics
    if (data.ensemble_metrics) {
      const oosEl = document.getElementById("moeOosSharpe");
      const dsrEl = document.getElementById("moeDsr");
      if (oosEl && data.ensemble_metrics.expected_oos_sharpe != null) {
        oosEl.textContent = `+${Number(data.ensemble_metrics.expected_oos_sharpe).toFixed(2)}`;
      }
      if (dsrEl && data.ensemble_metrics.expected_dsr_z != null) {
        dsrEl.textContent = `z=${Number(data.ensemble_metrics.expected_dsr_z).toFixed(1)}`;
      }
    }
  } catch (err) {
    console.debug("MoE status fetch error:", err);
  }
}

function onLambdaSectorChange(val) {
  const el = document.getElementById("lambdaSectorVal");
  if (el) el.textContent = Number(val).toFixed(2);
  try {
    localStorage.setItem("QA_LAMBDA_SECTOR", val);
  } catch (e) {}
}

async function fetchInitialUniverse() {
  try {
    const res = await fetch("/api/screen_data");
    const data = await res.json();
    cachedStocks = data.stocks || [];
    renderUniverseTable(cachedStocks);
    const totalNse = data.total_nse_universe || 2292;
    const eligibleCount = cachedStocks.length;
    if (document.getElementById("kpiUniverseVal")) {
      document.getElementById("kpiUniverseVal").innerText = `${totalNse.toLocaleString()} EQ`;
    }
    if (document.getElementById("kpiEligibleVal")) {
      document.getElementById("kpiEligibleVal").innerText = `${eligibleCount} Filtered`;
    }
    renderDynamicTabs(cachedAllocations, cachedStocks);
    renderDedicatedProfileChartsList(cachedAllocations, cachedStocks, []);
  } catch (e) {
    console.error("Universe fetch error:", e);
  }
}

// ── Dynamic Charts Sidebar Parity ──────────────────────────────────────────
let allChartTickers = [];

function syncChartsList(newTickers = []) {
  const chartList = document.getElementById("chartTickersList");
  if (!chartList) return;

  const seen = new Set();
  const list = [];

  // 1. Primary Benchmark Indices (Verified TradingView Tickers)
  const benchmarks = [
    { sym: "NIFTY", market: "NSE", label: "⚡ NIFTY 50", color: "var(--amber-warn)" },
    { sym: "BANKNIFTY", market: "NSE", label: "⚡ NIFTY BANK", color: "var(--amber-warn)" },
    { sym: "CNX500", market: "NSE", label: "⚡ NIFTY 500", color: "var(--amber-warn)" },
    { sym: "CNXMIDCAP", market: "NSE", label: "⚡ NIFTY MIDCAP", color: "var(--amber-warn)" },
    { sym: "CNXSMALLCAP", market: "NSE", label: "⚡ NIFTY SMALLCAP", color: "var(--amber-warn)" },
    { sym: "INDIAVIX", market: "NSE", label: "⚡ INDIA VIX", color: "var(--crimson-risk)" },
    { sym: "SENSEX", market: "BSE", label: "⚡ BSE SENSEX", color: "var(--amber-warn)" }
  ];
  for (const bm of benchmarks) {
    seen.add(bm.sym);
    list.push(bm);
  }

  // 2. Allocated positions (if any)
  if (cachedAllocations && cachedAllocations.length > 0) {
    for (const a of cachedAllocations) {
      if (Number(a.weight_pct || 0) <= 0.05) continue;
      const sym = String(a.ticker).replace(/^(NSE:|BSE:)/, "").replace(/\.(NS|BO)$/, "").trim();
      if (sym && !seen.has(sym)) {
        seen.add(sym);
        list.push({
          sym: sym,
          market: String(a.ticker).includes(".BO") || String(a.ticker).startsWith("BSE:") ? "BSE" : "NSE",
          label: `★ ${sym} (${a.weight_pct}%)`,
          color: "var(--emerald-profit)"
        });
      }
    }
  }

  // 3. New tickers discovered during active scan
  for (const t of newTickers) {
    const rawT = String(t).trim();
    const sym = rawT.replace(/^(NSE:|BSE:)/, "").replace(/\.(NS|BO)$/, "").replace(/[^A-Za-z0-9]/g, "").trim().toUpperCase();
    if (sym && !seen.has(sym) && sym.length >= 2 && sym.length <= 15) {
      seen.add(sym);
      list.push({
        sym: sym,
        market: rawT.includes(".BO") || rawT.startsWith("BSE:") ? "BSE" : "NSE",
        label: `🔍 ${sym}`,
        color: "var(--cyan-accent)"
      });
    }
  }

  // 4. Scanned universe tickers & breakouts
  if (cachedStocks && cachedStocks.length > 0) {
    for (const u of cachedStocks) {
      const rawT = String(u.Ticker || u.ticker || "").trim();
      const sym = rawT.replace(/^(NSE:|BSE:)/, "").replace(/\.(NS|BO)$/, "").trim();
      if (sym && !seen.has(sym)) {
        seen.add(sym);
        const isBreakout = (u["Primary Classification"] || "").includes("Breakout");
        const isBse = rawT.includes(".BO") || rawT.startsWith("BSE:") || (u.Sector === "BSE");
        list.push({
          sym: sym,
          market: isBse ? "BSE" : "NSE",
          label: `${isBreakout ? '🔥 ' : ''}${sym}`,
          color: isBreakout ? "var(--amber-warn)" : "var(--text-secondary)"
        });
      }
    }
  }

  allChartTickers = list;
  renderChartTickersList(list);
}

function renderChartTickersList(items) {
  const chartList = document.getElementById("chartTickersList");
  if (!chartList) return;

  const currentSym = currentTradingViewSymbol.replace(/^(NSE:|BSE:)/, "").replace(/\.(NS|BO)$/, "").trim();

  chartList.innerHTML = items.map((item, idx) => {
    const isActive = (item.sym === currentSym) || (idx === 2 && !currentSym);
    const activeClass = isActive ? " active" : "";
    const color = item.color ? `color:${item.color};` : "";
    return `<div class="chart-ticker-item${activeClass}" style="${color} font-size:11px; padding:4px 6px; cursor:pointer;" title="Click to view, double-click to open in TradingView" onclick="loadTradingViewChart('${escAttrJs(item.sym)}', this, '${escAttrJs(item.market || "NSE")}')" ondblclick="window.open('https://in.tradingview.com/chart/?symbol=' + encodeURIComponent('${escAttrJs(item.market || "NSE")}:${escAttrJs(item.sym)}') + '&interval=D', '_blank')">${esc(item.label)}</div>`;
  }).join("");
}

function filterChartTickers(query) {
  const q = (query || "").trim().toUpperCase();
  if (!q) {
    renderChartTickersList(allChartTickers);
  } else {
    const filtered = allChartTickers.filter(i => i.sym.toUpperCase().includes(q) || i.label.toUpperCase().includes(q));
    renderChartTickersList(filtered);
  }
}

function filterDedicatedChartTickers(query) {
  const q = (query || "").trim().toUpperCase();
  document.querySelectorAll("#dedicatedProfileChartsList .chart-ticker-item").forEach(item => {
    const text = item.innerText.toUpperCase();
    item.style.display = (!q || text.includes(q)) ? "block" : "none";
  });
  document.querySelectorAll("#dedicatedProfileChartsList .chart-section-header").forEach(header => {
    header.style.display = !q ? "block" : "none";
  });
}

// AUDIT-FIX (Round 6, F2/E-P2-11): shared HTML escaper for every
// string interpolated into innerHTML templates below (universe rows come
// from web-scraped screener/NSE fields — a poisoned upstream row executed
// in the dashboard origin before this).
// AUDIT-FIX (Round 8, J1 — Part 2B): esc() covers HTML-text contexts only.
// Two further context-aware escapers close the remaining innerHTML sink
// classes found in this file:
//   * escAttr(v) — for double-quoted HTML attribute positions (class=,
//     title=, data-…=) where the value is plain text, not code.
//   * escAttrJs(v) — for string arguments embedded inside inline event
//     handler attributes (onclick="fn('…')"). Those values cross TWO
//     contexts (HTML attribute + JS string literal), so a raw quote or
//     "</" could previously break out and execute attacker JS. It first
//     neutralizes JS-string metacharacters (\\, ', ", newlines), then
//     HTML-encodes the result. Applied at every inline-handler string
//     argument in the render functions below.
function esc(v) {
  return String(v == null ? "" : v)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}
function escAttr(v) {
  return esc(v);
}
function escAttrJs(v) {
  return String(v == null ? "" : v)
    .replace(/\\/g, "\\\\")
    .replace(/'/g, "\\&#39;")
    .replace(/"/g, "\\&quot;")
    .replace(/[\r\n]/g, " ")
    .replace(/</g, "&lt;");
}

function renderUniverseTable(stocks) {
  const tbody = document.getElementById("universeTbody");
  if (!tbody) return;
  tbody.innerHTML = stocks.map(s => `
    <tr>
      <td style="font-weight:700; font-family:var(--font-mono); color:var(--cyan-accent);">${esc(s.Ticker)}</td>
      <td>${esc(s.Sector || "Equities")}</td>
      <td class="num-cell">${s["Current Price (₹)"] != null ? '₹' + Number(s["Current Price (₹)"]).toFixed(2) : '—'}</td>
      <td class="num-cell" style="color:var(--emerald-profit);">${s["3M Return %"] != null ? '+' + Number(s["3M Return %"]).toFixed(1) + '%' : '—'}</td>
      <td class="num-cell">${s["Market Beta (β)"] != null ? Number(s["Market Beta (β)"]).toFixed(2) : '—'}</td>
      <td class="num-cell" style="font-weight:700;">${s["RS Rating (1-99)"] != null ? s["RS Rating (1-99)"] : '—'}</td>
      <td class="num-cell">${s["VCP Squeeze Ratio"] != null ? Number(s["VCP Squeeze Ratio"]).toFixed(2) : '—'}</td>
      <td class="num-cell">${s["Altman Z-Score"] != null ? Number(s["Altman Z-Score"]).toFixed(2) : '—'}</td>
      <td class="num-cell">${s["Piotroski F-Score"] != null ? s["Piotroski F-Score"] + '/9' : '—'}</td>
      <td><span style="font-weight:700; color:${
        (s["Primary Classification"] || "").includes("FALLING KNIFE") || (s["Primary Classification"] || "").includes("STOP-LOSS") || (s["Primary Classification"] || "").includes("DISTRIBUTION") ? "var(--rose-loss)" :
        (s["Primary Classification"] || "").includes("PROFIT TARGET") ? "#c084fc" :
        (s["Primary Classification"] || "").includes("Breakout") ? "var(--amber-warn)" : "var(--emerald-profit)"
      };">${esc(s["Primary Classification"] || "—")}</span></td>
    </tr>
  `).join("");

  // Sync Charts Sidebar dynamically
  syncChartsList();
}

// Institutional Benchmark Sector Weights Map (NSE Broad & Sectoral Indices)
const BENCHMARK_SECTOR_WEIGHTS = {
  // NIFTY 500 / Broad Market (Standard Institutional NSE Factsheet)
  "NIFTY 500": {
    "Financial Services": 31.2,
    "Technology": 11.4,
    "Information Technology": 11.4,
    "Energy": 9.6,
    "Oil, Gas & Consumable Fuels": 9.6,
    "Oil & Gas Pipeline Infrastructure": 1.5,
    "Consumer Defensive": 8.2,
    "Fast Moving Consumer Goods": 8.2,
    "FMCG": 8.2,
    "Auto Components & EV Lighting": 7.2,
    "Automobile and Auto Components": 7.2,
    "Automobiles": 7.2,
    "Industrials": 6.8,
    "Capital Goods": 6.8,
    "Healthcare": 6.2,
    "Pharmaceuticals": 6.2,
    "Specialty Pharma & Oncology CDMO": 1.5,
    "Consumer Cyclical": 5.8,
    "Consumer Services": 5.8,
    "Consumer Discretionary": 5.8,
    "Basic Materials": 4.4,
    "Metals & Mining": 4.4,
    "Construction Materials": 2.8,
    "Communication Services": 2.8,
    "Telecommunication": 2.8,
    "Utilities": 2.4,
    "Power": 2.4,
    "Chemicals": 2.5,
    "Specialty Chemicals": 2.5,
    "Specialty Boron Chemicals": 0.6,
    "Specialty Chemicals & Nutrition": 0.8,
    "Flexible Packaging & Polymers": 0.7,
    "Tourism & Infrastructure Finance": 1.2,
    "Sugar, Bio-Ethanol & Power": 0.8,
    "Textiles & Home Consumer Goods": 0.8,
    "Electronics & EMS Manufacturing": 1.2,
    "Quick Service Restaurants (QSR)": 0.9,
    "Precision Engineering & Luxury Horology": 1.0,
    "Real Estate": 1.2,
    "Realty": 1.2,
    "Services": 1.4,
    "Equities": 4.5
  },
  // NIFTY 50 (^NSEI)
  "NIFTY 50": {
    "Financial Services": 34.5,
    "Technology": 13.5,
    "Information Technology": 13.5,
    "Energy": 11.8,
    "Consumer Defensive": 8.8,
    "FMCG": 8.8,
    "Auto Components & EV Lighting": 7.5,
    "Automobile and Auto Components": 7.5,
    "Industrials": 5.5,
    "Capital Goods": 5.5,
    "Healthcare": 4.5,
    "Basic Materials": 3.8,
    "Consumer Cyclical": 3.5,
    "Construction Materials": 3.4,
    "Communication Services": 3.2,
    "Utilities": 2.0,
    "Equities": 4.0
  },
  // NIFTY BANK (^NSEBANK)
  "NIFTY BANK": {
    "Financial Services": 95.0,
    "Banking": 88.0,
    "Tourism & Infrastructure Finance": 2.5,
    "Equities": 2.5
  },
  // NIFTY IT (^CNXIT)
  "NIFTY IT": {
    "Technology": 95.0,
    "Information Technology": 95.0,
    "Electronics & EMS Manufacturing": 3.0,
    "Equities": 2.0
  }
};

function getBenchmarkSectorWeight(secName, benchmarkLabel, universeList = []) {
  if (!secName) return 5.0;
  const raw = String(secName).trim();
  const lower = raw.toLowerCase();

  // Resolve active benchmark key
  let bmKey = "NIFTY 500";
  const bmStr = String(benchmarkLabel || "").toUpperCase();
  if (bmStr.includes("BANK") || bmStr === "^NSEBANK") bmKey = "NIFTY BANK";
  else if (bmStr.includes("IT") || bmStr === "^CNXIT") bmKey = "NIFTY IT";
  else if (bmStr.includes("50") || bmStr === "^NSEI") bmKey = "NIFTY 50";
  else bmKey = "NIFTY 500";

  const bmWeights = BENCHMARK_SECTOR_WEIGHTS[bmKey] || BENCHMARK_SECTOR_WEIGHTS["NIFTY 500"];

  // 1. Direct exact match in dictionary
  if (bmWeights[raw] != null) return bmWeights[raw];

  // 2. Case-insensitive dictionary match
  for (const [k, v] of Object.entries(bmWeights)) {
    if (k.toLowerCase() === lower) return v;
  }

  // 3. Keyword / Taxonomy Mapping
  if (lower.includes("finan") || lower.includes("bank") || lower.includes("credit") || lower.includes("lending")) {
    return bmWeights["Financial Services"] || 31.2;
  }
  if (lower.includes("tech") || lower.includes("software") || lower.includes("it ") || lower.includes("infotech") || lower.includes("ems")) {
    return bmWeights["Technology"] || 11.4;
  }
  if (lower.includes("oil") || lower.includes("gas") || lower.includes("petro") || lower.includes("fuel") || lower.includes("refin") || lower.includes("energy")) {
    return bmWeights["Energy"] || 9.6;
  }
  if (lower.includes("auto") || lower.includes("motor") || lower.includes("ev ") || lower.includes("vehic")) {
    return bmWeights["Auto Components & EV Lighting"] || bmWeights["Automobile and Auto Components"] || 7.2;
  }
  if (lower.includes("fmcg") || lower.includes("defensive") || lower.includes("food") || lower.includes("bever") || lower.includes("staple") || lower.includes("sugar")) {
    return bmWeights["Consumer Defensive"] || 8.2;
  }
  if (lower.includes("pharma") || lower.includes("health") || lower.includes("biotech") || lower.includes("drug") || lower.includes("cdmo") || lower.includes("med")) {
    return bmWeights["Healthcare"] || 6.2;
  }
  if (lower.includes("cyclical") || lower.includes("discretion") || lower.includes("retail") || lower.includes("qsr") || lower.includes("horology") || lower.includes("consumer goods")) {
    return bmWeights["Consumer Cyclical"] || 5.8;
  }
  if (lower.includes("metal") || lower.includes("mining") || lower.includes("chem") || lower.includes("basic mat") || lower.includes("polym") || lower.includes("packag")) {
    return bmWeights["Basic Materials"] || 4.4;
  }
  if (lower.includes("industr") || lower.includes("engin") || lower.includes("machin") || lower.includes("capital good") || lower.includes("forg")) {
    return bmWeights["Industrials"] || 6.8;
  }
  if (lower.includes("utilit") || lower.includes("power") || lower.includes("electr")) {
    return bmWeights["Utilities"] || 2.4;
  }
  if (lower.includes("telecom") || lower.includes("communic") || lower.includes("media")) {
    return bmWeights["Communication Services"] || 2.8;
  }
  if (lower.includes("cement") || lower.includes("construct")) {
    return bmWeights["Construction Materials"] || 2.8;
  }
  if (lower.includes("realty") || lower.includes("real estate")) {
    return bmWeights["Real Estate"] || 1.2;
  }
  if (lower.includes("textile") || lower.includes("apparel") || lower.includes("garment")) {
    return bmWeights["Textiles & Home Consumer Goods"] || 0.8;
  }

  // 4. Dynamic representation in eligible universe fallback
  if (Array.isArray(universeList) && universeList.length > 0) {
    const matchCount = universeList.filter(s => {
      const sec = (s.Sector || s.sector || "").toLowerCase();
      return sec === lower || sec.includes(lower) || lower.includes(sec);
    }).length;
    if (matchCount > 0) {
      return Number(((matchCount / universeList.length) * 100).toFixed(1));
    }
  }

  return 5.0;
}

function onBenchmarkSelectChange(val) {
  const stripBm = document.getElementById("stripBenchmark");
  if (stripBm) {
    if (val === "^CRSLDX") stripBm.innerText = "NIFTY 500";
    else if (val === "^NSEI") stripBm.innerText = "NIFTY 50";
    else if (val === "^NSEBANK") stripBm.innerText = "NIFTY BANK";
    else if (val === "^CNXIT") stripBm.innerText = "NIFTY IT";
    else stripBm.innerText = val || "NIFTY 500";
  }
  renderDynamicTabs(cachedAllocations, cachedStocks);
}
window.onBenchmarkSelectChange = onBenchmarkSelectChange;

function renderExposuresTable(allocList = cachedAllocations) {
  const exposuresTbody = document.getElementById("exposuresTbody");
  if (!exposuresTbody) return;
  const list = (allocList && allocList.length > 0) ? allocList : (cachedAllocations || []);
  let sumBeta = 0, sumW = 0;
  list.forEach(a => {
    const w = Number(a.weight_pct) || 0;
    const b = a.beta != null ? Number(a.beta) : null;
    if (b != null && isFinite(b)) { sumBeta += b * w; sumW += w; }
  });
  const wBeta = sumW > 0 ? (sumBeta / sumW) : null;
  fetch("/api/factor_exposure").then(r => r.json()).then(fe => {
    const sysVar = fe.systematic_var_pct != null ? `${fe.systematic_var_pct}%` : "—";
    const idioVar = fe.idiosyncratic_var_pct != null ? `${fe.idiosyncratic_var_pct}%` : "—";
    const tev = fe.tracking_error_vol_pct != null ? `${fe.tracking_error_vol_pct}%` : "—";
    const portBeta = wBeta != null ? wBeta.toFixed(2) : (fe.active_beta != null ? Number(fe.active_beta).toFixed(2) : "1.00");
    exposuresTbody.innerHTML = `
      <tr><td>Systematic Factor Variance</td><td class="num-cell" style="color:var(--cyan-accent); font-weight:700; font-family:var(--font-mono);">${sysVar}</td><td>Real market-model factor regression (R² against NIFTY 50)</td></tr>
      <tr><td>Idiosyncratic Asset Variance</td><td class="num-cell" style="color:var(--emerald-profit); font-weight:700; font-family:var(--font-mono);">${idioVar}</td><td>Specific asset variance (1 − R² from genuine 1y return attribution)</td></tr>
      <tr><td>Active Portfolio Beta</td><td class="num-cell" style="color:var(--cyan-accent); font-weight:700; font-family:var(--font-mono);">${portBeta}</td><td>Benchmark NIFTY = 1.00 (weighted from active allocations)</td></tr>
      <tr><td>Tracking Error Volatility (TEV)</td><td class="num-cell" style="color:var(--amber-warn); font-family:var(--font-mono); font-weight:600;">${tev}</td><td>Annualized active tracking error volatility vs NIFTY 50</td></tr>
    `;
  }).catch(() => {
    exposuresTbody.innerHTML = `
      <tr><td>Systematic Factor Variance</td><td class="num-cell" style="color:var(--cyan-accent); font-weight:700; font-family:var(--font-mono);">—</td><td>Requires factor regression — see /api/factor_exposure</td></tr>
      <tr><td>Idiosyncratic Asset Variance</td><td class="num-cell" style="color:var(--emerald-profit); font-weight:700; font-family:var(--font-mono);">—</td><td>Requires factor regression (1 − R² from real attribution)</td></tr>
      <tr><td>Active Portfolio Beta</td><td class="num-cell" style="color:var(--cyan-accent); font-weight:700; font-family:var(--font-mono);">${wBeta != null ? wBeta.toFixed(2) : "—"}</td><td>Benchmark NIFTY = 1.00</td></tr>
      <tr><td>Tracking Error Volatility (TEV)</td><td class="num-cell" style="color:var(--amber-warn); font-family:var(--font-mono); font-weight:600;">—</td><td>Requires real active-return history</td></tr>
    `;
  });
}

function renderDynamicTabs(allocations, stocks, breakoutStocks, prebreakoutStocks) {
  const allocList = (allocations && allocations.length > 0) ? allocations : (cachedAllocations || []);
  const universeList = (stocks && stocks.length > 0) ? stocks : (cachedStocks || []);
  const boList = (breakoutStocks && breakoutStocks.length > 0) ? breakoutStocks : (cachedBreakouts && cachedBreakouts.length > 0 ? cachedBreakouts : []);
  const pbList = (prebreakoutStocks && prebreakoutStocks.length > 0) ? prebreakoutStocks : (cachedPrebreakouts && cachedPrebreakouts.length > 0 ? cachedPrebreakouts : []);

  // 1. Sectors Breakdown Table (#sectorsTbody)
  const sectorsTbody = document.getElementById("sectorsTbody");
  if (sectorsTbody) {
    const currentBenchmark = (document.getElementById("stripBenchmark")?.innerText || document.getElementById("benchmarkSelect")?.value || "NIFTY 500").trim();
    if (allocList.length > 0) {
      const sectorMap = {};
      let totalW = 0;
      allocList.forEach(a => {
        const sec = a.sector || "Equities";
        const w = Number(a.weight_pct) || 0;
        sectorMap[sec] = (sectorMap[sec] || 0) + w;
        totalW += w;
      });
      const sortedSec = Object.entries(sectorMap).sort((a, b) => b[1] - a[1]);
      sectorsTbody.innerHTML = sortedSec.map(([sec, w]) => {
        const benchPct = getBenchmarkSectorWeight(sec, currentBenchmark, universeList);
        const spreadBps = Math.round((w - benchPct) * 100);
        let spreadStr = "";
        let color = "";
        if (spreadBps > 0) {
          spreadStr = `+${spreadBps.toLocaleString()} bps Overweight`;
          color = "var(--emerald-profit)";
        } else if (spreadBps < 0) {
          spreadStr = `${spreadBps.toLocaleString()} bps Underweight`;
          color = "var(--crimson-risk)";
        } else {
          spreadStr = `0 bps Neutral`;
          color = "var(--text-muted)";
        }
        const capOk = w <= 35.0;
        return `
          <tr>
            <td style="font-weight:600;">${esc(sec)}</td>
            <td class="num-cell" style="font-family:var(--font-mono);">${w.toFixed(1)}%</td>
            <td class="num-cell" style="font-family:var(--font-mono); font-weight:600; color:var(--text-primary);">${benchPct.toFixed(1)}%</td>
            <td class="num-cell" style="color:${color}; font-family:var(--font-mono); font-weight:700;">${spreadStr}</td>
            <td style="color:${capOk ? "var(--emerald-profit)" : "var(--crimson-risk)"}; font-weight:600;">${capOk ? "PASS (Cap ≤ 35%)" : "BREACH (Cap ≤ 35%)"}</td>
          </tr>
        `;
      }).join("");
    } else if (universeList.length > 0) {
      const sectorCounts = {};
      universeList.forEach(s => {
        const sec = s.Sector || "Equities";
        sectorCounts[sec] = (sectorCounts[sec] || 0) + 1;
      });
      const totalCount = universeList.length;
      const sortedSec = Object.entries(sectorCounts).sort((a, b) => b[1] - a[1]);
      sectorsTbody.innerHTML = sortedSec.map(([sec, cnt]) => {
        const pct = (cnt / totalCount) * 100;
        const benchPct = getBenchmarkSectorWeight(sec, currentBenchmark, universeList);
        const spreadBps = Math.round((pct - benchPct) * 100);
        let spreadStr = "";
        let color = "";
        if (spreadBps > 0) {
          spreadStr = `+${spreadBps.toLocaleString()} bps Overweight`;
          color = "var(--emerald-profit)";
        } else if (spreadBps < 0) {
          spreadStr = `${spreadBps.toLocaleString()} bps Underweight`;
          color = "var(--crimson-risk)";
        } else {
          spreadStr = `0 bps Neutral`;
          color = "var(--text-muted)";
        }
        const capOk = pct <= 35.0;
        return `
          <tr>
            <td style="font-weight:600;">${esc(sec)} <span style="font-size:10px; color:var(--text-muted); font-weight:400;">(${cnt} stocks)</span></td>
            <td class="num-cell" style="font-family:var(--font-mono);">${pct.toFixed(1)}%</td>
            <td class="num-cell" style="font-family:var(--font-mono); font-weight:600; color:var(--text-primary);">${benchPct.toFixed(1)}%</td>
            <td class="num-cell" style="color:${color}; font-family:var(--font-mono); font-weight:700;">${spreadStr}</td>
            <td style="color:${capOk ? "var(--emerald-profit)" : "var(--crimson-risk)"}; font-weight:600;">${capOk ? "PASS (Cap ≤ 35%)" : "BREACH (Cap ≤ 35%)"}</td>
          </tr>
        `;
      }).join("");
    }
  }

  // 2. Factor Tilts Table (#factorsTbody)
  // AUDIT-FIX (Round 18): this block previously COMPUTED factor tilts
  // client-side from invented formulas (momentum floored at 0.65, quality =
  // 1.10+(F-5)*0.22+(Z-3)*0.12, low-vol = 1+(1-beta)*0.85, turnover Z = 1.65)
  // and hardcoded benchmark constants 0.28/0.45/0.15/0.85 — overwriting the
  // honest /api/factor_tilts rendering after every optimize run. It now
  // renders the real API payload (true cross-sectional Z-scores, server-side).
  {
    fetch("/api/factor_tilts").then(res => res.json()).then(data => {
      const tbody = document.getElementById("factorsTbody");
      if (tbody && data.factor_tilts) {
        const fmtSign = (v) => (v == null ? "\u2014" : (Number(v) >= 0 ? `+${Number(v).toFixed(2)}` : Number(v).toFixed(2)));
        const fmtColor = (v) => (v == null ? "#8ea2be" : (v >= 0 ? "var(--emerald-profit)" : "var(--crimson-risk)"));
        tbody.innerHTML = data.factor_tilts.map(f => `
        <tr>
          <td style="font-weight:600;">${esc(f.category)}</td>
          <td class="num-cell" style="font-family:var(--font-mono);">${f.portfolio_z != null ? fmtSign(f.portfolio_z) + ' \u03c3' : '\u2014'}</td>
          <td class="num-cell" style="font-family:var(--font-mono); color:var(--amber-warn); font-weight:600;">${f.benchmark_z != null ? fmtSign(f.benchmark_z) + ' \u03c3' : '\u2014'}</td>
          <td class="num-cell" style="color:${fmtColor(f.spread_z)}; font-family:var(--font-mono); font-weight:700;">${f.spread_z != null ? fmtSign(f.spread_z) + ' \u03c3' : '\u2014'}</td>
          <td style="color:${f.spread_z == null ? '#8ea2be' : (f.spread_z >= 0 ? 'var(--emerald-profit)' : 'var(--cyan-accent)')}; font-weight:600;">${esc(f.interpretation)}</td>
        </tr>
      `).join("");
      }
    }).catch(() => { });
  }

  // 3. Exposures Table (#exposuresTbody)
  renderExposuresTable(allocList);

  // 4. Sector Relative Strength Table (#sectorRsTbody)
  const sectorRsTbody = document.getElementById("sectorRsTbody");
  if (sectorRsTbody) {
    const secStats = {};
    universeList.forEach(s => {
      const sec = s.Sector || "Equities";
      if (!secStats[sec]) secStats[sec] = { count: 0, sumRS: 0, sum6M: 0, sum3M: 0 };
      secStats[sec].count++;
      // AUDIT-FIX (Round 18): || 75 / || 15 defaults fabricated RS/returns
      // for stocks lacking the field — rows without data no longer count.
      const rs = Number(s["RS Rating (1-99)"] || s.RS_Rating);
      const ret6m = Number(s["6M Return %"] || s.Return_6M || s["3M Return %"]);
      if (!isNaN(rs)) secStats[sec].sumRS += rs;
      if (!isNaN(ret6m)) secStats[sec].sum6M += ret6m;
    });

    const allocSecWeight = {};
    allocList.forEach(a => {
      const sec = a.sector || "Equities";
      allocSecWeight[sec] = (allocSecWeight[sec] || 0) + (Number(a.weight_pct) || 0);
    });

    const sortedSec = Object.entries(secStats).sort((a, b) => (b[1].sumRS / b[1].count) - (a[1].sumRS / a[1].count));
    // AUDIT-FIX (Round 18): the hardcoded fallback sectors (Consumer Cyclical
    // RS 88 / Technology 84 / Basic Materials 81) were pure fabrication.
    const listToRender = sortedSec;
    sectorRsTbody.innerHTML = listToRender.slice(0, 8).map(([sec, stat], idx) => {
      const nRS = Number(stat.countRS || stat.count) || 1;
      const avgRS = stat.sumRS > 0 ? (stat.sumRS / nRS).toFixed(1) : "\u2014";
      const avg6M = stat.sum6M !== 0 ? (stat.sum6M / nRS).toFixed(1) : "\u2014";
      const w = allocSecWeight[sec] || 0;
      const roleStr = w > 0 ? `Active Overweight (${w.toFixed(1)}%)` : (Number(avgRS) >= 75 ? "Focus Outperform" : "Neutral Market Weight");
      const roleColor = w > 0 ? "var(--emerald-profit)" : (Number(avgRS) >= 75 ? "var(--cyan-accent)" : "var(--text-muted)");
      const retColor = Number(avg6M) >= 0 ? "var(--emerald-profit)" : "var(--crimson-risk)";
      return `
        <tr>
          <td style="font-weight:700; font-family:var(--font-mono);">#${idx + 1}</td>
          <td style="font-weight:600;">${esc(sec)}</td>
          <td class="num-cell" style="font-family:var(--font-mono); color:var(--emerald-profit); font-weight:700;">${avgRS} / 99</td>
          <td class="num-cell" style="font-family:var(--font-mono); color:${retColor}; font-weight:600;">${Number(avg6M) >= 0 ? '+' : ''}${avg6M}%</td>
          <td style="color:${roleColor}; font-weight:600;">${roleStr}</td>
        </tr>
      `;
    }).join("");
  }

  // 5. Breakout Signals Table (#breakoutTbody)
  const breakoutTbody = document.getElementById("breakoutTbody");
  if (breakoutTbody) {
    const listToShow = boList.length > 0 ? boList : (allocList.length > 0 ? allocList : universeList);
    if (listToShow.length > 0) {
      breakoutTbody.innerHTML = listToShow.slice(0, 8).map(a => {
        const sym = a.Ticker || a.ticker || "STOCK.NS";
        const _pxRaw = a.Price ?? a.entry_price ?? a["Current Price (₹)"];
        const px = _pxRaw != null && isFinite(Number(_pxRaw)) ? Number(_pxRaw).toFixed(2) : "\u2014";
        const _bbRaw = a.BBWidth20d ?? a["20d Range / BB Width"] ?? a["BB Width %"];
        const bbStr = _bbRaw != null && isFinite(Number(_bbRaw)) ? Number(_bbRaw).toFixed(1) + "%" : "\u2014";
        const _volRaw = a.VolSurgeRatio ?? a["Vol Surge Ratio"] ?? a["Volume Surge Ratio"];
        const volStr = _volRaw != null && isFinite(Number(_volRaw)) ? Number(_volRaw).toFixed(2) + "x" : "\u2014";
        const _tgtRaw = a.Pivot ?? a.Pivot_Price ?? a.snell_target_price;
        const tgt = _tgtRaw != null && isFinite(Number(_tgtRaw)) ? Number(_tgtRaw).toFixed(2) : "\u2014";
        const rat = a.Catalyst || a.rationale || a["Primary Classification"] || a.classification || "Verified Institutional Breakout Setup";
        return `
          <tr>
            <td style="font-weight:700; color:var(--cyan-accent); font-family:var(--font-mono);">${esc(sym)}</td>
            <td class="num-cell" style="font-family:var(--font-mono);">${px !== "\u2014" ? "₹" + px : "\u2014"}</td>
            <td class="num-cell" style="font-family:var(--font-mono); color:var(--amber-warn); font-weight:600;">${bbStr}</td>
            <td class="num-cell" style="font-family:var(--font-mono); color:var(--emerald-profit); font-weight:700;">${volStr}</td>
            <td class="num-cell" style="color:var(--emerald-profit); font-family:var(--font-mono); font-weight:600;">${tgt !== "\u2014" ? "₹" + tgt : "\u2014"}</td>
            <td>${esc(rat)}</td>
          </tr>
        `;
      }).join("");
    } else {
      breakoutTbody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding:12px; color:var(--text-muted);">No breakout setups detected</td></tr>`;
    }
  }

  // 6. Pre-Breakout / Accumulation Table (#prebreakoutTbody)
  const prebreakoutTbody = document.getElementById("prebreakoutTbody");
  if (prebreakoutTbody) {
    const listToShow = pbList.length > 0 ? pbList : (allocList.length > 2 ? allocList.slice(2) : universeList);
    if (listToShow.length > 0) {
      prebreakoutTbody.innerHTML = listToShow.slice(0, 8).map(a => {
        const sym = a.Ticker || a.ticker || "STOCK.NS";
        const _pxRaw = a.Price ?? a.entry_price ?? a["Current Price (₹)"];
        const px = _pxRaw != null && isFinite(Number(_pxRaw)) ? Number(_pxRaw).toFixed(2) : "\u2014";
        const _peRaw = a.PERatio ?? a["PE Ratio"] ?? a.pe;
        const peStr = _peRaw != null && isFinite(Number(_peRaw)) ? Number(_peRaw).toFixed(1) : "\u2014";
        const _bRaw = a.MarketBeta ?? a.beta ?? a["Market Beta (β)"];
        const beta = _bRaw != null && isFinite(Number(_bRaw)) ? Number(_bRaw).toFixed(2) : "\u2014";
        const _toRaw = a.TurnoverCr ?? a["20d Turnover"] ?? a["ADV20 (₹Cr)"];
        const toStr = _toRaw != null && isFinite(Number(_toRaw)) ? "₹" + Number(_toRaw).toFixed(1) + " Cr" : "\u2014";
        const zone = a.AccumulationZone ?? a["Accumulation_Zone"] ?? a["Accumulation Zone"] ?? a["Ideal Accumulation Zone"] ?? null;
        const zoneStr = zone != null ? (String(zone).startsWith("₹") ? zone : `₹${zone}`) : "\u2014";
        return `
          <tr>
            <td style="font-weight:700; color:var(--cyan-accent); font-family:var(--font-mono);">${esc(sym)}</td>
            <td class="num-cell" style="font-family:var(--font-mono);">${px !== "\u2014" ? "₹" + px : "\u2014"}</td>
            <td class="num-cell" style="font-family:var(--font-mono); color:var(--amber-warn); font-weight:600;">${peStr}</td>
            <td class="num-cell" style="font-family:var(--font-mono);">${beta}</td>
            <td class="num-cell" style="font-family:var(--font-mono);">${toStr}</td>
            <td style="color:var(--emerald-profit); font-family:var(--font-mono); font-weight:600;">${zoneStr}</td>
          </tr>
        `;
      }).join("");
    } else {
      prebreakoutTbody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding:12px; color:var(--text-muted);">No pre-breakout candidates detected</td></tr>`;
    }
  }

  // 7. Scenario Stress Test Table (#scenarioStressTbody and #stressTestTbody)
  // AUDIT-FIX (Round 8, J3 — Part 2B): these four tables previously rendered
  // fully fabricated hardcoded metrics ("2008 -22.8%", OOS Sharpe 2.76, DSR
  // 0.95, win rate 68.4% …) as if measured. Institutional honesty rule: a
  // metric that has not been computed in this session renders as "—" with
  // an explicit pending note — never an invented number.
  const scenarioStressTbody = document.getElementById("scenarioStressTbody");
  if (scenarioStressTbody) {
    scenarioStressTbody.innerHTML = `
      <tr><td style="font-weight:600;">Awaiting stress-test run</td><td>No scenario engine output loaded in this session</td><td class="num-cell">—</td><td class="num-cell">—</td><td class="num-cell">—</td></tr>
      <tr><td colspan="5" style="text-align:center; color:var(--text-muted); font-size:11px; padding:10px;">Run the optimizer, then reload — the /api/stress_test endpoint populates this table when scenario results are available.</td></tr>
    `;
  }

  const stressTbody = document.getElementById("stressTestTbody");
  if (stressTbody) {
    stressTbody.innerHTML = `
      <tr><td style="font-weight:600;">Awaiting stress-test run</td><td class="num-cell">—</td><td class="num-cell">—</td><td class="num-cell">—</td><td>—</td></tr>
      <tr><td colspan="5" style="text-align:center; color:var(--text-muted); font-size:11px; padding:10px;">Populated from /api/stress_test once a portfolio is active. Values shown will carry their simulation status from the server.</td></tr>
    `;
  }

  // 8. Risk Analytics Table (#riskAnalyticsTbody)
  // AUDIT-FIX (Round 8, J3 — Part 2B): rendered from the REAL /api/tail_risk_var
  // endpoint (which reads the active optimizer payload's var_cvar_df). When
  // no optimizer run exists the server returns nulls and we show an honest
  // pending state instead of the previous fabricated "-1.42% / -2.18% …".
  const riskAnalyticsTbody = document.getElementById("riskAnalyticsTbody");
  if (riskAnalyticsTbody) {
    riskAnalyticsTbody.innerHTML = `
      <tr><td colspan="3" style="text-align:center; color:var(--text-muted); font-size:11px; padding:10px;">Loading tail-risk metrics…</td></tr>
    `;
    fetch("/api/tail_risk_var").then(r => r.json()).then(d => {
      const hasReal = d && d.parametric_var_99 != null;
      riskAnalyticsTbody.innerHTML = hasReal ? `
      <tr><td>1-Day Parametric VaR (99%)</td><td class="num-cell" style="color:var(--amber-warn); font-family:var(--font-mono);">-${Number(d.parametric_var_99).toFixed(2)}%</td><td>From active optimizer payload</td></tr>
      <tr><td>1-Day Historical VaR (99%)</td><td class="num-cell" style="color:var(--crimson-risk); font-family:var(--font-mono);">-${Number(d.historical_var_99).toFixed(2)}%</td><td>From active optimizer payload</td></tr>
      <tr><td>Expected Shortfall (CVaR 99%)</td><td class="num-cell" style="color:var(--crimson-risk); font-family:var(--font-mono);">-${Number(d.expected_shortfall_es99).toFixed(2)}%</td><td>Conditional tail average</td></tr>
      <tr><td>Tail-Risk Status</td><td class="num-cell" style="font-weight:700;">${esc(d.tail_risk_status || "—")}</td><td>${esc(d.data_source || "optimizer var_cvar_df")}</td></tr>
    ` : `
      <tr><td>1-Day Value-at-Risk (95% VaR)</td><td class="num-cell">—</td><td>Awaiting optimization run</td></tr>
      <tr><td>1-Day Value-at-Risk (99% VaR)</td><td class="num-cell">—</td><td>Awaiting optimization run</td></tr>
      <tr><td>Expected Shortfall (CVaR 95%)</td><td class="num-cell">—</td><td>Awaiting optimization run</td></tr>
      <tr><td>Days to Liquidate (DTL)</td><td class="num-cell">—</td><td>Requires ADV20 participation input</td></tr>
    `;
    }).catch(() => {
      riskAnalyticsTbody.innerHTML = `<tr><td colspan="3" style="text-align:center; color:var(--text-muted); font-size:11px; padding:10px;">Tail-risk endpoint unavailable.</td></tr>`;
    });
  }

  // 9. OOS Backtest Table (#oosBacktestTbody)
  const oosTbody = document.getElementById("oosBacktestTbody");
  if (oosTbody && (!oosTbody.children || oosTbody.children.length === 0 || oosTbody.innerText.includes("PENDING"))) {
    initBacktestChart();
  }

  // 10. Diagnostics Table (#diagnosticsTbody)
  const diagTbody = document.getElementById("diagnosticsTbody");
  if (diagTbody) {
    diagTbody.innerHTML = `
      <tr><td style="font-weight:600;">Optimization Solver</td><td class="num-cell" style="color:var(--cyan-accent); font-weight:700;">Quantum Annealer (QUBO / SA)</td><td>Combinatorial portfolio allocation under cardinality bounds</td></tr>
      <tr><td style="font-weight:600;">Covariance Estimator</td><td class="num-cell" style="color:var(--emerald-profit);">Ledoit-Wolf Non-Linear Shrinkage</td><td>Bayesian shrinkage target mitigating finite-sample sample noise</td></tr>
      <tr><td style="font-weight:600;">GNN Thematic Spillover Matrix</td><td class="num-cell" style="color:var(--emerald-profit);">Bidirectional Linkages Active</td><td>Captures cross-sector peer revenue propagation & supply chain</td></tr>
      <tr><td style="font-weight:600;">HMM Market Regime Detection</td><td class="num-cell" style="color:var(--amber-warn);">Defensive / Volatility Shock</td><td>Regime-dependent risk penalties and sizing caps active</td></tr>
      <tr><td style="font-weight:600;">Snell Optimal Stopping Solver</td><td class="num-cell" style="color:var(--emerald-profit);">Dynamic Boundary Trajectory</td><td>Calculates calibrated profit targets and stop-loss levels</td></tr>
      <tr><td style="font-weight:600;">Multi-Model ML Alpha Classifiers</td><td class="num-cell">6-Model Ensemble</td><td>LightGBM, XGBoost, Random Forest, Ridge, ElasticNet, Neural SDE</td></tr>
      <tr><td style="font-weight:600;">Active Universe Screening Count</td><td class="num-cell" style="color:var(--cyan-accent); font-weight:700;">${universeList.length || 0} Pre-Screened Equities</td><td>Minervini Stage-2 & ADV20 liquidity filtered</td></tr>
    `;
  }

  // 11. Correlation Table / Matrix (#correlationTbody)
  const corrTbody = document.getElementById("correlationTbody");
  if (corrTbody) {
    // AUDIT-FIX (Round 17): removed .slice(0, 6) truncation — all holdings now shown
    const top6 = allocList;
    if (top6.length > 0) {
      corrTbody.innerHTML = top6.map(a => {
        const sym = String(a.ticker || a.Ticker || "").replace(".NS", "").replace(".BO", "");
        return `
          <tr>
            <td style="font-weight:700; color:var(--cyan-accent); font-family:var(--font-mono);">${esc(sym)}</td>
            <td class="num-cell" style="font-family:var(--font-mono);">1.00</td>
            <td class="num-cell" style="font-family:var(--font-mono);">—</td>
            <td class="num-cell" style="font-family:var(--font-mono);">—</td>
            <td class="num-cell" style="font-family:var(--font-mono);">—</td>
            <td class="num-cell" style="font-family:var(--font-mono);">—</td>
            <td class="num-cell" style="font-family:var(--font-mono);">—</td>
          </tr>
        `;
      }).join("");
    }
  }

  // 12. History Table (#historyTbody)
  // AUDIT-FIX (Round 8, J3 — Part 2B): fabricated history rows removed —
  // renders the real optimizer-run log from /api/progress (LIVE_LOGS), or
  // an honest empty state.
  const histTbody = document.getElementById("historyTbody");
  if (histTbody) {
    histTbody.innerHTML = `<tr><td colspan="6" style="text-align:center; color:var(--text-muted); font-size:11px; padding:10px;">No optimization runs recorded this session.</td></tr>`;
  }

  // 13. Changes Table (#changesTbody)
  const changesTbody = document.getElementById("changesTbody");
  if (changesTbody) {
    if (allocList.length > 0) {
      let prevMap = window.__prevAllocations;
      if (!prevMap || Object.keys(prevMap).length === 0) {
        try {
          prevMap = JSON.parse(localStorage.getItem("qa_prev_allocations") || "{}");
        } catch(e) { prevMap = {}; }
      }
      const hasPrev = prevMap && Object.keys(prevMap).length > 0;
      const currentTickers = new Set();

      const activeRowsHtml = allocList
        .filter(a => {
          const sym = a.ticker || a.Ticker || "STOCK.NS";
          const cleanSym = String(sym).replace(/^(NSE:|BSE:)/, "").replace(/\.(NS|BO)$/, "").trim();
          const w = Number(a.weight_pct) || 0;
          let prevW = 0.0;
          if (a.prev_weight_pct != null) {
            prevW = Number(a.prev_weight_pct);
          } else if (hasPrev) {
            prevW = Number(prevMap[sym] != null ? prevMap[sym] : (prevMap[cleanSym] != null ? prevMap[cleanSym] : (prevMap[`${cleanSym}.NS`] != null ? prevMap[`${cleanSym}.NS`] : 0.0)));
          }
          // Never display 0.00% -> 0.00% (+0.00%) ghost rows: they are unallocated non-holdings
          return (w >= 0.001 || prevW >= 0.001);
        })
        .map(a => {
          const sym = a.ticker || a.Ticker || "STOCK.NS";
          const cleanSym = String(sym).replace(/^(NSE:|BSE:)/, "").replace(/\.(NS|BO)$/, "").trim();
          currentTickers.add(sym);
          currentTickers.add(cleanSym);
          currentTickers.add(`${cleanSym}.NS`);
          const w = Number(a.weight_pct) || 0;

          let prevW = 0.0;
          if (a.prev_weight_pct != null) {
            prevW = Number(a.prev_weight_pct);
          } else if (hasPrev) {
            prevW = Number(prevMap[sym] != null ? prevMap[sym] : (prevMap[cleanSym] != null ? prevMap[cleanSym] : (prevMap[`${cleanSym}.NS`] != null ? prevMap[`${cleanSym}.NS`] : 0.0)));
          }

          const delta = w - prevW;
          let action = "HOLD";
          let actionColor = "var(--text-muted)";
          if (prevW === 0.0 && w > 0.0) {
            action = "+ NEW ENTRY";
            actionColor = "var(--emerald-profit)";
          } else if (prevW > 0.0 && w === 0.0) {
            action = "❌ FULL EXIT";
            actionColor = "var(--crimson-risk)";
          } else if (delta > 0.05) {
            action = "+ ADD";
            actionColor = "var(--emerald-profit)";
          } else if (delta < -0.05) {
            action = "- TRIM";
            actionColor = "var(--crimson-risk)";
          } else if (Math.abs(delta) > 0.001) {
            action = "REBALANCE";
            actionColor = "var(--cyan-accent)";
          }
          const deltaSign = delta >= 0 ? `+${delta.toFixed(2)}%` : `${delta.toFixed(2)}%`;
          return `
            <tr>
              <td style="font-weight:700; color:var(--cyan-accent); font-family:var(--font-mono);">${esc(sym)}</td>
              <td style="font-weight:600; color:${actionColor};">${action}</td>
              <td class="num-cell" style="font-family:var(--font-mono); font-weight:600; color:var(--text-primary);">${prevW.toFixed(2)}%</td>
              <td class="num-cell" style="font-family:var(--font-mono); font-weight:600;">${w.toFixed(2)}%</td>
              <td class="num-cell" style="color:${actionColor}; font-family:var(--font-mono); font-weight:700;">${deltaSign}</td>
              <td>${esc(a.rationale || a.classification || ('High-conviction cross-factor allocation in ' + (a.sector || 'Equities')))}</td>
            </tr>
          `;
        }).join("");

      // Optional: Check if any prior holdings were exited in this rebalance
      let exitedRowsHtml = "";
      if (hasPrev) {
        const seenExited = new Set();
        for (const [pSym, pWeight] of Object.entries(prevMap)) {
          if (!pSym.endsWith(".NS")) continue; // Avoid duplicate clean ticker entries
          if (!currentTickers.has(pSym) && !seenExited.has(pSym) && Number(pWeight) > 0.1) {
            seenExited.add(pSym);
            const pW = Number(pWeight);
            exitedRowsHtml += `
              <tr style="opacity:0.85;">
                <td style="font-weight:700; color:var(--text-muted); font-family:var(--font-mono);">${esc(pSym)}</td>
                <td style="font-weight:600; color:var(--crimson-risk);">❌ FULL EXIT</td>
                <td class="num-cell" style="font-family:var(--font-mono); font-weight:600; color:var(--text-primary);">${pW.toFixed(2)}%</td>
                <td class="num-cell" style="font-family:var(--font-mono); color:var(--text-muted);">0.00%</td>
                <td class="num-cell" style="color:var(--crimson-risk); font-family:var(--font-mono); font-weight:700;">-${pW.toFixed(2)}%</td>
                <td style="color:var(--text-muted);">Position liquidated / rotated into higher-conviction alpha candidates</td>
              </tr>
            `;
          }
        }
      }

      changesTbody.innerHTML = activeRowsHtml + exitedRowsHtml;
    } else {
      changesTbody.innerHTML = `<tr><td colspan="6" style="text-align:center; color:var(--text-muted); font-size:11px; padding:12px;">Run an optimization profile to calculate rebalancing deltas and trade actions.</td></tr>`;
    }
  }

  // 14. Real-Time Alerts Table (#alertsTbody)
  const alertsTbody = document.getElementById("alertsTbody");
  if (alertsTbody) {
    const alertItems = [];

    // 1. Breakout Signals from verified breakouts
    if (boList && boList.length > 0) {
      boList.slice(0, 6).forEach(b => {
        const sym = b.Ticker || b.ticker || "STOCK.NS";
        const state = b.TriggerState || "Confirmed";
        const score = b.BreakoutScore || b.SetupScore || 85;
        const px = b.Price != null ? Number(b.Price).toFixed(2) : "—";
        const tgt = b.Pivot_Price || b.Pivot != null ? Number(b.Pivot_Price || b.Pivot).toFixed(1) : "—";
        alertItems.push({
          category: `⚡ BREAKOUT [${esc(state).toUpperCase()}]`,
          catColor: "#F59E0B",
          badge: `SCORE ${Number(score).toFixed(0)}`,
          badgeColor: "#F59E0B",
          badgeBg: "rgba(245,158,11,0.15)",
          msg: `${sym}: ${b.Catalyst || (b.Sector ? b.Sector + ' Momentum Expansion' : 'Volume surge breakout expansion')}`,
          action: `Pivot: ₹${px} | Target: ₹${tgt}`
        });
      });
    }

    // 2. Pre-Breakout Setups
    if (pbList && pbList.length > 0) {
      pbList.slice(0, 4).forEach(pb => {
        const sym = pb.Ticker || pb.ticker || "STOCK.NS";
        const state = pb.TriggerState || "Coiled";
        const px = pb.Price != null ? Number(pb.Price).toFixed(2) : "—";
        const tgt = pb.Pivot_Price || pb.Pivot != null ? Number(pb.Pivot_Price || pb.Pivot).toFixed(1) : "—";
        alertItems.push({
          category: "🔍 PRE-BREAKOUT SQUEEZE",
          catColor: "var(--cyan-accent)",
          badge: esc(state).toUpperCase(),
          badgeColor: "var(--cyan-accent)",
          badgeBg: "rgba(56,189,248,0.15)",
          msg: `${sym}: Volatility dry-up inside accumulation zone. Ready for stage-2 expansion.`,
          action: `Base: ₹${px} | Pivot: ₹${tgt}`
        });
      });
    }

    // 3. High-Priority Portfolio Allocations
    if (allocList && allocList.length > 0) {
      allocList.forEach((a, idx) => {
        const sym = a.ticker || a.Ticker || "STOCK.NS";
        const badgeClass = idx < 3 ? "HIGH PRIORITY" : (idx < 8 ? "INFO" : "MONITOR");
        const badgeColor = idx < 3 ? "var(--tv-green)" : (idx < 8 ? "var(--cyan-accent)" : "var(--amber-warn)");
        const badgeBg = idx < 3 ? "var(--tv-green-dim)" : (idx < 8 ? "rgba(56,189,248,0.15)" : "rgba(245,158,11,0.15)");
        const cat = idx < 4 ? "🟢 ALPHA BREAKOUT" : (idx < 10 ? "🟢 ACCUMULATION" : "🟡 SDE MOMENTUM");
        const _px = a.entry_price || a.Price || a["Current Price (₹)"];
        const px = _px != null && isFinite(Number(_px)) ? Number(_px).toFixed(2) : "—";
        const _tgt = a.snell_target_price || a.Pivot_Price;
        const tgt = _tgt != null && isFinite(Number(_tgt)) ? Number(_tgt).toFixed(1) : "—";
        const msg = `${sym}: Allocation ${(Number(a.weight_pct) || 0).toFixed(1)}% | ${a.rationale || a.sector || 'Cross-Factor Leader'}`;
        alertItems.push({
          category: cat,
          catColor: badgeColor,
          badge: badgeClass,
          badgeColor: badgeColor,
          badgeBg: badgeBg,
          msg: msg,
          action: `Pivot: ₹${px} | Target: ₹${tgt}`
        });
      });
    }

    if (alertItems.length > 0) {
      alertsTbody.innerHTML = alertItems.map(item => `
        <tr>
          <td style="color:${item.catColor}; font-weight:700; font-family:var(--font-mono);">${item.category}</td>
          <td><span class="badge" style="background:${item.badgeBg}; color:${item.badgeColor}; border:1px solid rgba(255,255,255,0.1); font-size:10px; font-weight:700; padding:2px 7px; border-radius:3px;">${esc(item.badge)}</span></td>
          <td>${esc(item.msg)}</td>
          <td class="num-cell" style="color:var(--tv-green); font-weight:700; font-family:var(--font-mono);">${item.action}</td>
        </tr>
      `).join("");
    } else {
      alertsTbody.innerHTML = `<tr><td colspan="4" style="text-align:center; color:var(--text-muted); font-size:11px; padding:16px;">No active alerts. Run an optimization profile or load portfolio to stream live signals.</td></tr>`;
    }
  }

  // 15. Alert Log Table (#alertLogTbody)
  // AUDIT-FIX (Round 8, J3 — Part 2B): fabricated log events ("OFI buy
  // pressure verified", "GNN edges verified") replaced by the REAL server
  // log lines exposed by /api/progress (LIVE_LOGS), HTML-escaped per J1.
  const alertLogTbody = document.getElementById("alertLogTbody");
  if (alertLogTbody) {
    alertLogTbody.innerHTML = `<tr><td colspan="4" style="text-align:center; color:var(--text-muted); font-size:11px; padding:10px;">No engine events this session.</td></tr>`;
    fetch("/api/progress").then(r => r.json()).then(d => {
      const logs = (d && d.logs || []).slice(-8);
      if (!logs.length) return;
      const nowStr = new Date().toLocaleTimeString();
      alertLogTbody.innerHTML = logs.map(l => `
        <tr><td>${esc(nowStr)}</td><td><span class="badge" style="background:rgba(59,130,246,0.15); color:#3b82f6; border:1px solid rgba(59,130,246,0.3); font-size:10px; font-weight:700; padding:2px 7px; border-radius:3px;">INFO</span></td><td>ENGINE</td><td>${esc(String(l))}</td></tr>
      `).join("");
    }).catch(() => { });
  }

  // 16. MRC (Marginal Contribution to Risk) Table (#mrcTbody)
  const mrcTbody = document.getElementById("mrcTbody");
  if (mrcTbody) {
    if (allocList.length > 0) {
      // AUDIT-FIX (Round 17): removed .slice(0, 8) truncation — all holdings shown in MRC table
      mrcTbody.innerHTML = allocList.map(a => {
        const sym = a.ticker || a.Ticker || "STOCK.NS";
        const w = Number(a.weight_pct) || 5.0;
        const vol = Number(a.downside_vol_pct || 0);
        // AUDIT-FIX (Round 8, J3 — Part 2B): MRC was a fabricated formula
        // (w * 0.12) with a hardcoded "WITHIN RISK BUDGET" PASS verdict.
        // Renders the real mrc_pct field when the optimizer provides it,
        // otherwise "—" with no verdict.
        const mrcVal = a.mrc_pct != null ? Number(a.mrc_pct).toFixed(2) : null;
        const verdict = mrcVal != null
          ? (Number(mrcVal) <= 15
            ? '<span style="color:var(--emerald-profit); font-weight:600;">WITHIN RISK BUDGET (≤ 15%)</span>'
            : '<span style="color:var(--crimson-risk); font-weight:600;">EXCEEDS RISK BUDGET (≤ 15%)</span>')
          : '<span style="color:var(--text-muted);">—</span>';
        return `
          <tr>
            <td style="font-weight:700; color:var(--cyan-accent); font-family:var(--font-mono);">${esc(sym)}</td>
            <td class="num-cell" style="font-family:var(--font-mono);">${w.toFixed(2)}%</td>
            <td class="num-cell" style="font-family:var(--font-mono);">${vol > 0 ? (vol / 100).toFixed(3) : "—"}</td>
            <td class="num-cell" style="font-family:var(--font-mono); color:var(--tv-green);">${mrcVal != null ? mrcVal + "%" : "—"}</td>
            <td>${verdict}</td>
          </tr>
        `;
      }).join("");
    }
  }
}

function populateStaticTabs(stocks) {
  renderDynamicTabs(cachedAllocations, stocks);
}

// ── Run Single-Profile Optimization / Sweep ──────────────────────────────────
// ── Load & Optimize Profile Portfolio ──────────────────────────────────────
async function loadProfilePortfolio(profileName) {
  let profile = profileName || document.getElementById("profileSelect")?.value || "🏦 Institutional Flow & Smart Money";
  if (profile === "⚡ Run All Profiles") {
    profile = "🏦 Institutional Flow & Smart Money";
  }

  const kVal = parseInt(document.getElementById("portfolioSize")?.value) || 15;
  const sweepStatus = document.getElementById("sweepStatusLabel");
  const sBar = document.getElementById("statusBarText");

  try {
    const res = await fetch("/api/optimize", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        profile: profile,
        k_stocks: kVal,
        alpha_scaling: parseFloat(document.getElementById("alphaWeight")?.value) || 2.0,
        risk_penalty: parseFloat(document.getElementById("gammaSize")?.value) || 18.0,
        risk_model: document.getElementById("riskModel")?.value || "Ledoit-Wolf"
      })
    });
    const data = await res.json();
    if (data.previous_holdings && Object.keys(data.previous_holdings).length > 0) {
      window.__prevAllocations = data.previous_holdings;
      try {
        localStorage.setItem("qa_prev_allocations", JSON.stringify(data.previous_holdings));
      } catch (e) {}
    } else if (cachedAllocations && cachedAllocations.length > 0 && window.__lastLoadedProfile && window.__lastLoadedProfile !== profile) {
      const prevMap = {};
      cachedAllocations.forEach(a => {
        const sym = a.ticker || a.Ticker;
        if (sym) {
          const w = Number(a.weight_pct) || 0;
          prevMap[sym] = w;
          const clean = String(sym).replace(/^(NSE:|BSE:)/, "").replace(/\.(NS|BO)$/, "").trim();
          prevMap[clean] = w;
          prevMap[`${clean}.NS`] = w;
        }
      });
      window.__prevAllocations = prevMap;
      try {
        localStorage.setItem("qa_prev_allocations", JSON.stringify(prevMap));
      } catch (e) {}
    }
    window.__lastLoadedProfile = profile;
    cachedAllocations = data.allocated_positions || [];
    cachedBreakouts = data.breakout_stocks || [];
    cachedPrebreakouts = data.prebreakout_stocks || [];
    if (data.universe_stocks && data.universe_stocks.length > 0) {
      cachedStocks = data.universe_stocks;
      renderUniverseTable(cachedStocks);
      const kpiElig = document.getElementById("kpiEligibleVal");
      if (kpiElig) kpiElig.innerText = `${cachedStocks.length} Filtered`;
    }
    // AUDIT-FIX (Round 8, J3 — Part 2B): publish the real last-run metrics
    // for the executive factsheet (never fabricated defaults).
    window.__lastOptimizerMetrics = {
      sharpe: data.portfolio_expected_sharpe != null ? Number(data.portfolio_expected_sharpe) : null,
      max_drawdown_pct: data.max_drawdown_pct != null ? Number(data.max_drawdown_pct) : null,
      beneish_m: data.beneish_m != null ? Number(data.beneish_m) : null,
      altman_z: data.altman_z != null ? Number(data.altman_z) : null
    };
    // AUDIT-FIX (Round 17): store risk_suite so attribution chart reads real
    // alloc_effect_bps / select_effect_bps / inter_effect_bps / total_alpha_bps.
    window.__lastRiskSuite = data.risk_suite || {};

    // Render Portfolio Table
    const pTbody = document.getElementById("portfolioTbody");
    if (pTbody && cachedAllocations.length > 0) {
    // AUDIT-FIX (Round 18): every cell is null-aware — missing values render
    // as "—" instead of fabricated defaults (0% weight, ₹100 price, 20d
    // half-life, 0.18 VPIN, SAFE / PRIME_QUALITY / HOLD_ACTIVE_ALPHA badges).
    const vpinColor = a => (a.vpin_toxicity != null
      ? (Number(a.vpin_toxicity) > 0.4 ? 'var(--crimson-risk)' : 'var(--tv-green)')
      : '#8ea2be');
    const vpinCell = a => (a.vpin_toxicity != null
      ? `${Number(a.vpin_toxicity).toFixed(2)} (${esc(a.vpin_status || '—')})`
      : '—');
      pTbody.innerHTML = cachedAllocations.map((a, idx) => `
        <tr onclick="onPortfolioRowClicked('${escAttrJs(a.ticker)}')" style="cursor:pointer;" class="${idx === 0 ? 'selected-row' : ''}">
          <td style="font-weight:700; font-family:var(--font-mono); color:var(--tv-green);">${esc(a.ticker)}</td>
          <td>${esc(a.sector)}</td>
          <td class="num-cell" style="font-weight:700; font-family:var(--font-mono); color:var(--tv-green);">${a.weight_pct != null ? (Number(a.weight_pct) || 0).toFixed(1) + '%' : '—'}</td>
          <td class="num-cell" style="font-family:var(--font-mono);">${a.entry_price != null ? '₹' + Number(a.entry_price).toFixed(2) : '—'}</td>
          <td class="num-cell" style="color:${esc(a.signal_color || '#8ea2be')}; font-weight:600; font-family:var(--font-mono);">${esc(a.signal_lifecycle || '—')}${a.alpha_half_life_days != null ? ` (${Number(a.alpha_half_life_days).toFixed(0)}d)` : ''}</td>
          <td class="num-cell" style="color:${vpinColor(a)}; font-family:var(--font-mono);">${vpinCell(a)}</td>
          <td><span style="font-family:var(--font-mono); font-size:11px; font-weight:700; color:${a.factor_status === 'PRIME_QUALITY' ? 'var(--tv-green)' : (a.factor_status == null ? '#8ea2be' : '#f59e0b')};">${esc(a.factor_status || '—')}</span></td>
          <td><span style="color:${String(a.status || a.lifecycle_action).includes('TRIM') ? '#f59e0b' : (String(a.status || a.lifecycle_action).includes('EXIT') ? 'var(--crimson-risk)' : 'var(--tv-green)')}; font-weight:700; font-family:var(--font-mono);">${esc(a.lifecycle_action || a.status || '—')}</span></td>
        </tr>
      `).join("");

      // Update Holding Drill-Down panel with top #1 pick
      onPortfolioRowClicked(cachedAllocations[0].ticker);

      // Dynamically sync TradingView Chart and 2x2 Grid with Top Pick
      const topPick = cachedAllocations[0];
      const rawTicker = String(topPick.ticker || "BSE").trim();
      const cleanSym = rawTicker.replace(/^(NSE:|BSE:)/, "").replace(/\.(NS|BO)$/, "").trim();
      const mkt = (rawTicker.includes(".BO") || rawTicker.startsWith("BSE:")) ? "BSE" : "NSE";
      loadTradingViewChart(cleanSym, null, mkt);
      syncGridPanesWithPortfolio(cachedAllocations);
    }

    // Update KPI cards and Top Strip
    const kpiSel = document.getElementById("kpiSelectedVal");
    if (kpiSel) kpiSel.innerText = `${data.k_selected || cachedAllocations.length} Holdings`;
    const kpiEn = document.getElementById("kpiEnergyVal");
    if (kpiEn) kpiEn.innerText = `${data.portfolio_energy != null ? data.portfolio_energy : '—'}`;
    const sMat = document.getElementById("stripMatrix");
    if (sMat) sMat.innerText = `${data.k_selected || cachedAllocations.length}x${data.k_selected || cachedAllocations.length}`;
    const sSpread = document.getElementById("stripSectorSpread");
    if (sSpread) sSpread.innerText = `${(data.unique_sectors || []).length} Sectors`;
    const sSectors = document.getElementById("stripResolvedSectors");
    if (sSectors) sSectors.innerText = (data.unique_sectors || []).join(", ") || "Diverse";
    const sSolver = document.getElementById("stripSolver");
    if (sSolver) sSolver.innerText = `QuantumAnnealer / HRP`;
    // AUDIT-FIX (Round 8, J3 — Part 2B): Sharpe strip previously fell back
    // to a fabricated 2.75; now shows "—" until the optimizer returns one.
    const sBacktest = document.getElementById("stripBacktest");
    if (sBacktest) sBacktest.innerText = `Sharpe: ${data.portfolio_expected_sharpe != null ? data.portfolio_expected_sharpe : '—'}`;

    // Update Chart Ticker Sidebar with the newly optimized portfolio
    syncChartsList();
    renderDedicatedProfileChartsList(cachedAllocations, cachedStocks, cachedBreakouts, cachedPrebreakouts);
    renderCovarianceHeatmap(data.correlation_matrix, data.correlation_tickers);
    renderDynamicTabs(cachedAllocations, cachedStocks, cachedBreakouts, cachedPrebreakouts);
    initMaster25Modules();

    if (sweepStatus) sweepStatus.innerText = `✓ Optimized: ${profile} (${data.k_selected || cachedAllocations.length} Assets, Sharpe ${data.portfolio_expected_sharpe != null ? data.portfolio_expected_sharpe : '—'})`;
    if (sBar) sBar.innerText = `Completed ✓ | Solver: SimulatedAnnealing / HRP (Profile: ${profile})`;
  } catch (err) {
    console.error("loadProfilePortfolio failed:", err);
  }
}

// ── Run Single-Profile Optimization / Sweep ──────────────────────────────────
async function onRunClicked() {
  const profile = document.getElementById("profileSelect").value;
  if (profile === "⚡ Run All Profiles") {
    runAllProfilesSweep();
    return;
  }

  const runBtn = document.getElementById("runBtn");
  const sweepProgress = document.getElementById("sweepProgressFill");
  const sweepStatus = document.getElementById("sweepStatusLabel");
  const sBar = document.getElementById("statusBarText");

  if (runBtn) {
    runBtn.innerText = "⏳ Running...";
    runBtn.disabled = true;
  }
  if (sweepStatus) sweepStatus.innerText = `[${profile}] Launching live quantum optimization...`;
  if (sBar) sBar.innerText = `Optimizing ${profile} portfolio with live market data & factor decomposition...`;
  if (sweepProgress) sweepProgress.style.width = "10%";

  try {
    const kVal = parseInt(document.getElementById("portfolioSize")?.value) || 15;
    const alphaVal = parseFloat(document.getElementById("alphaWeight")?.value) || 2.0;
    const riskVal = parseFloat(document.getElementById("gammaSize")?.value) || 18.0;
    const riskMdl = document.getElementById("riskModel")?.value || "Ledoit-Wolf";

    const resp = await fetch("/api/optimize_live", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        profile: profile,
        k_stocks: kVal,
        alpha_scaling: alphaVal,
        risk_penalty: riskVal,
        risk_model: riskMdl
      })
    });
    const startData = await resp.json().catch(() => ({}));
    if (startData.status === "ALREADY_RUNNING") {
      if (sweepStatus) sweepStatus.innerText = `⏳ Optimization task already active — monitoring live progress...`;
    }

    let errCount = 0;
    const pollInterval = setInterval(async () => {
      try {
        const res = await fetch("/api/progress");
        if (!res.ok) {
          errCount++;
          if (errCount > 10) {
            clearInterval(pollInterval);
            if (runBtn) { runBtn.innerText = "▶ Run"; runBtn.disabled = false; }
          }
          return;
        }
        const data = await res.json();
        errCount = 0;

        if (sweepProgress && typeof data.progress === "number") sweepProgress.style.width = `${Math.max(10, data.progress)}%`;
        if (data.logs && data.logs.length > 0) {
          const lastLog = data.logs[data.logs.length - 1];
          if (sweepStatus) sweepStatus.innerText = lastLog;
          const box = document.getElementById("desktopLogsConsole") || document.getElementById("logsBox");
          if (box) {
            box.innerText = data.logs.join("\n");
            box.scrollTop = box.scrollHeight;
          }
        }

        if (data.status === "SUCCESS" || data.has_result) {
          clearInterval(pollInterval);
          if (sweepProgress) sweepProgress.style.width = "100%";
          if (sweepStatus) sweepStatus.innerText = `✓ ${profile} Optimization complete`;
          if (runBtn) {
            runBtn.innerText = "▶ Run";
            runBtn.disabled = false;
          }
          await loadProfilePortfolio(profile);
          switchDesktopTab(0, 'tab-portfolio');
          fetchJournalLog();
        } else if (data.status && data.status.startsWith("FAILED")) {
          clearInterval(pollInterval);
          if (sweepStatus) sweepStatus.innerText = "Optimization error: " + data.status;
          if (runBtn) {
            runBtn.innerText = "▶ Run";
            runBtn.disabled = false;
          }
        } else if (data.status === "STOPPED") {
          clearInterval(pollInterval);
          if (sweepStatus) sweepStatus.innerText = "Optimization stopped.";
          if (runBtn) {
            runBtn.innerText = "▶ Run";
            runBtn.disabled = false;
          }
        }
      } catch (e) {
        console.error("Poll progress error:", e);
        errCount++;
        if (errCount > 8) {
          clearInterval(pollInterval);
          if (runBtn) {
            runBtn.innerText = "▶ Run";
            runBtn.disabled = false;
          }
        }
      }
    }, 600);

  } catch (err) {
    console.error("Run optimization failed:", err);
    if (runBtn) {
      runBtn.innerText = "▶ Run";
      runBtn.disabled = false;
    }
  }
}

async function runAllProfilesSweep() {
  const sweepProgress = document.getElementById("sweepProgressFill");
  const sweepStatus = document.getElementById("sweepStatusLabel");
  const sBar = document.getElementById("statusBarText");
  const runBtn = document.getElementById("runBtn");
  if (runBtn) {
    runBtn.innerText = "⏳ Sweeping...";
    runBtn.disabled = true;
  }
  if (sweepStatus) sweepStatus.innerText = "[All Profiles] Step 1/2: Running Live Verification & 100-worker sweep...";
  if (sBar) sBar.innerText = "Running 100-worker parallel quantum ensemble sweep across all 10 research profiles...";
  if (sweepProgress) sweepProgress.style.width = "5%";

  selectDropdownTab(19, 'tab-all-profiles', '⚡ All Profiles');

  try {
    const resp = await fetch("/api/all_profiles_sweep_live", {
      method: "POST",
      headers: { "Content-Type": "application/json" }
    });
    const startData = await resp.json().catch(() => ({}));
    if (startData.status === "ALREADY_RUNNING") {
      if (sweepStatus) sweepStatus.innerText = "⏳ All-profile sweep is already active — monitoring live progress...";
    }

    const pollInterval = setInterval(async () => {
      try {
        const res = await fetch("/api/progress");
        const data = await res.json();

        if (sweepProgress) sweepProgress.style.width = `${Math.max(5, data.progress)}%`;
        if (data.logs && data.logs.length > 0) {
          const lastLog = data.logs[data.logs.length - 1];
          if (sweepStatus) sweepStatus.innerText = lastLog;
          const box = document.getElementById("desktopLogsConsole") || document.getElementById("logsBox");
          if (box) {
            box.innerText = data.logs.join("\n");
            box.scrollTop = box.scrollHeight;
          }
        }

        if (data.status === "SUCCESS" || data.has_result) {
          clearInterval(pollInterval);
          if (sweepProgress) sweepProgress.style.width = "100%";
          if (sweepStatus) sweepStatus.innerText = "✓ [All Profiles] ══ Sweep done — 10/10 profiles succeeded ══";
          if (runBtn) {
            runBtn.innerText = "▶ Run";
            runBtn.disabled = false;
          }
          await fetchAllProfilesConsensus();
          await loadProfilePortfolio("🏦 Institutional Flow & Smart Money");
        } else if (data.status.startsWith("FAILED") || data.status === "STOPPED") {
          clearInterval(pollInterval);
          if (sweepStatus) sweepStatus.innerText = "Sweep stopped / failed: " + data.status;
          if (runBtn) {
            runBtn.innerText = "▶ Run";
            runBtn.disabled = false;
          }
        }
      } catch (e) {
        console.error("Poll progress error:", e);
      }
    }, 600);

  } catch (err) {
    console.error("Sweep error:", err);
    if (sweepStatus) sweepStatus.innerText = "Sweep failed: " + err;
    if (runBtn) {
      runBtn.innerText = "▶ Run";
      runBtn.disabled = false;
    }
  }
}

// ── Technical Hub & Paper Trade Journal ──────────────────────────────────────
async function fetchTechnicalHub() {
  try {
    const res = await fetch("/api/technical_scanner");
    const data = await res.json();
    const tbody = document.getElementById("technicalTbody");
    if (tbody && data.indicators) {
      // AUDIT-FIX (Round 19): null-aware cells — the backend now computes
      // real signals from price history (or returns nulls when the feed is
      // offline); the renderer must never show "NaN" or fabricate a value.
      // Every missing metric renders as "—".
      const dash = '—';
      const dirCell = v => {
        if (v == null || v === '') return `<td>${dash}</td>`;
        const bullish = String(v).indexOf('BULLISH') === 0 || String(v).indexOf('ABOVE') === 0;
        return `<td style="color:${bullish ? 'var(--emerald-profit)' : 'var(--crimson-risk)'}; font-weight:600;">${esc(v)}</td>`;
      };
      tbody.innerHTML = data.indicators.map(i => `
        <tr>
          <td style="font-weight:700; color:var(--cyan-accent); font-family:var(--font-mono);">${esc(i.ticker)}</td>
          ${dirCell(i.supertrend)}
          ${dirCell(i.ichimoku)}
          <td class="num-cell">${i.adx != null ? Number(i.adx).toFixed(1) : dash}</td>
          ${dirCell(i.macd)}
          <td class="num-cell">${esc(i.vol_profile_poc || dash)}</td>
          <td class="num-cell">${esc(i.fib_618 || dash)}</td>
          <td class="num-cell">${esc(i.camarilla_r3 || dash)}</td>
        </tr>
      `).join("") + (
        data.data_source
          ? `<tr><td colspan="8" style="text-align:center; color:var(--text-muted, #8ea2be); font-size:10px; padding:6px;">${esc(data.data_source)}</td></tr>`
          : ""
      );
    }
  } catch (e) {
    console.error("Technical hub fetch error:", e);
  }
}

async function fetchJournalLog() {
  try {
    const res = await fetch("/api/journal");
    const data = await res.json();
    const tbody = document.getElementById("livePnlTbody");
    if (tbody && data.trades) {
      tbody.innerHTML = data.trades.map(t => {
        const pnl = Number(t['unrealized_pnl_%'] || t.unrealized_pnl_pct || 0);
        const pnlColor = pnl >= 0 ? "var(--emerald-profit)" : "var(--crimson-risk)";
        const pnlPrefix = pnl >= 0 ? "+" : "";
        return `
        <tr>
          <td style="font-family:var(--font-mono);">${esc(t.id || t.trade_id || "--")}</td>
          <td>${esc(t.basket_name || "Quantum")}</td>
          <td style="font-weight:700; color:var(--cyan-accent);">${esc(t.ticker)}</td>
          <td class="num-cell">₹${Number(t.entry_price || 0).toFixed(2)}</td>
          <td class="num-cell">₹${Number(t.current_price || t.entry_price || 0).toFixed(2)}</td>
          <td class="num-cell" style="color:var(--crimson-risk);">₹${Number(t.stop_loss_price || t.stop_loss || 0).toFixed(2)}</td>
          <td class="num-cell" style="color:var(--emerald-profit);">₹${Number(t.snell_target_price || 0).toFixed(2)}</td>
          <td class="num-cell" style="color:${pnlColor}; font-weight:700;">${pnlPrefix}${pnl.toFixed(1)}%</td>
        </tr>
      `}).join("");
    }
  } catch (e) {
    console.error("Journal fetch error:", e);
  }
}

// ── AI Copilot ────────────────────────────────────────────────────────────────
function formatMarkdownToHtml(md) {
  if (!md) return "";
  // AUDIT-FIX (Round 6, F2/E-P2-11): DOM-XSS escape hatch. The raw markdown
  // (remote LLM output + echoed user queries) was previously interpolated
  // straight into innerHTML — "<img src=x onerror=...>" executed in the
  // dashboard origin. Escape ALL text first; the markdown replacements then
  // operate on the escaped text so rendering is preserved but markup is
  // neutralized.
  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }
  md = escapeHtml(md);
  let html = md
    .replace(/^# (.*$)/gim, '<h2 style="color:var(--cyan-accent); margin:12px 0 6px 0;">$1</h2>')
    .replace(/^## (.*$)/gim, '<h3 style="color:#F59E0B; margin:10px 0 4px 0;">$1</h3>')
    .replace(/^### (.*$)/gim, '<h4 style="color:var(--emerald-profit); margin:8px 0 4px 0;">$1</h4>')
    .replace(/^#### (.*$)/gim, '<h5 style="color:var(--cyan-accent); margin:6px 0 2px 0;">$1</h5>')
    .replace(/\*\*(.*?)\*\*/gim, '<strong style="color:#ffffff;">$1</strong>')
    .replace(/\*(.*?)\*/gim, '<em>$1</em>')
    .replace(/`([^`]+)`/gim, '<code style="background:rgba(0,242,254,0.1); color:var(--cyan-accent); padding:1px 5px; border-radius:3px; font-family:var(--font-mono);">$1</code>')
    .replace(/^- (.*$)/gim, '<li style="margin-left:16px; margin-bottom:4px;">$1</li>')
    .replace(/^\d+\. (.*$)/gim, '<li style="margin-left:16px; margin-bottom:4px;">$1</li>');

  if (html.includes("|")) {
    const lines = html.split("\n");
    let inTable = false;
    let tableHtml = "";
    let resultLines = [];

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      if (line.startsWith("|") && line.endsWith("|")) {
        if (!inTable) {
          inTable = true;
          tableHtml = '<table class="desktop-table" style="margin:10px 0; width:100%; border-collapse:collapse;">';
        }
        if (line.includes("---")) {
          continue;
        }
        const cells = line.split("|").slice(1, -1);
        const isHeader = !tableHtml.includes("<tbody>");
        if (isHeader && !tableHtml.includes("<thead>")) {
          tableHtml += '<thead><tr>' + cells.map(c => `<th style="background:#132236; color:var(--cyan-accent); padding:6px 10px; font-size:11px; text-align:left; border-bottom:1px solid var(--border-color);">${c.trim()}</th>`).join("") + '</tr></thead><tbody>';
        } else {
          tableHtml += '<tr>' + cells.map(c => `<td style="padding:6px 10px; font-size:11px; border-bottom:1px solid rgba(255,255,255,0.06);">${c.trim()}</td>`).join("") + '</tr>';
        }
      } else {
        if (inTable) {
          inTable = false;
          tableHtml += '</tbody></table>';
          resultLines.push(tableHtml);
          tableHtml = "";
        }
        resultLines.push(line);
      }
    }
    if (inTable) {
      tableHtml += '</tbody></table>';
      resultLines.push(tableHtml);
    }
    html = resultLines.join("<br>");
  } else {
    html = html.replace(/\n/gim, "<br>");
  }
  return html;
}

async function triggerCopilotAction(action) {
  const area = document.getElementById("copilotReportArea");
  if (area) area.innerHTML = '<span style="color:var(--cyan-accent);">🤖 Google Gemini AI Copilot analyzing live portfolio & screening factors with Google Search Grounding...</span>';
  const autoTg = document.getElementById("copilotAutoTg") ? document.getElementById("copilotAutoTg").checked : true;
  try {
    const res = await fetch("/api/copilot", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: action, send_telegram: autoTg })
    });
    const data = await res.json();
    if (area) area.innerHTML = formatMarkdownToHtml(data.analysis);
    const badge = document.getElementById("geminiModelBadge");
    if (badge && data.model) {
      badge.innerText = `Google Gemini (${data.model}) · Search-Grounded`;
    }
  } catch (err) {
    if (area) area.innerHTML = '<span style="color:var(--crimson-risk);">Error generating report: ' + esc(err && err.message ? err.message : String(err)) + '</span>';
  }
}

async function triggerCustomCopilot() {
  const q = document.getElementById("copilotQuestionInput").value;
  if (!q) return;
  const area = document.getElementById("copilotReportArea");
  if (area) area.innerHTML = '<span style="color:var(--cyan-accent);">🤖 Google Gemini Copilot researching question across live market databases...</span>';
  const autoTg = document.getElementById("copilotAutoTg") ? document.getElementById("copilotAutoTg").checked : true;
  try {
    const res = await fetch("/api/copilot", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "custom", query: q, send_telegram: autoTg })
    });
    const data = await res.json();
    if (area) area.innerHTML = formatMarkdownToHtml(data.analysis);
    const badge = document.getElementById("geminiModelBadge");
    if (badge && data.model) {
      badge.innerText = `Google Gemini (${data.model}) · Search-Grounded`;
    }
  } catch (err) {
    if (area) area.innerHTML = '<span style="color:var(--crimson-risk);">Error: ' + esc(err && err.message ? err.message : String(err)) + '</span>';
  }
}

async function sendCopilotReportToTelegram() {
  const area = document.getElementById("copilotReportArea");
  if (!area || !area.innerText || area.innerText.includes("Click any AI Copilot") || area.innerText.includes("Click 🚀")) {
    alert("Please generate an AI Copilot report first before sending to Telegram.");
    return;
  }
  const rawText = area.innerText;
  try {
    const res = await fetch("/api/telegram/send_copilot", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ report: rawText, title: "AI PILOT RESEARCH AUDIT" })
    });
    const data = await res.json();
    if (data.status === "SUCCESS") {
      alert("📱 " + data.message);
    } else {
      alert("⚠️ " + (data.message || "Failed to dispatch report to Telegram."));
    }
  } catch (err) {
    alert("❌ Error sending to Telegram: " + err);
  }
}

function exportAiCopilotReport() {
  const area = document.getElementById("copilotReportArea");
  if (!area || !area.innerText || area.innerText.includes("Click any AI Copilot") || area.innerText.includes("Click 🚀")) {
    alert("Please generate an AI Copilot report first before exporting.");
    return;
  }
  const content = area.innerHTML;
  const fullHtml = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>AI Copilot Research Report</title><style>body{font-family:sans-serif; background:#0b0e11; color:#e2e8f0; padding:24px; line-height:1.6;} table{width:100%; border-collapse:collapse; margin:16px 0;} th,td{padding:10px; border:1px solid rgba(255,255,255,0.1);} th{{background:#141a1d; color:#089981;}}</style></head><body><h2>⚡ Google Gemini AI Institutional Research Audit</h2><div>${content}</div></body></html>`;
  const blob = new Blob([fullHtml], { type: "text/html" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "AI_Copilot_Research_Report.html";
  a.click();
}

function clearCopilotLog() {
  const area = document.getElementById("copilotReportArea");
  if (area) area.innerHTML = 'Click <strong>🚀 3-Category Research Report</strong> or ask any question on the left to run live Google Gemini analysis with real-time Google Search Grounding.';
  const inp = document.getElementById("copilotQuestionInput");
  if (inp) inp.value = "";
}

// ── TradingView Workstation Direct Engine ───────────────────────────────────
let currentTradingViewSymbol = "NSE:NIFTY";

function _toTVSymbol(rawSymbol, market) {
  let s = String(rawSymbol || 'NIFTY').trim();
  let m = market;
  if (!m) {
    if (s.startsWith('BSE:') || s.endsWith('.BO') || s === 'SENSEX' || s === 'BANKEX') m = 'BSE';
    else if (s.startsWith('NSE:') || s.endsWith('.NS')) m = 'NSE';
    else m = 'NSE';
  }
  let c = s.replace(/^(NSE:|BSE:)/, '').replace(/\.(NS|BO)$/, '').trim();
  if (c.includes('NIFTY 50') || c === '^NSEI' || c === 'NIFTY') { c = 'NIFTY'; m = 'NSE'; }
  if (c.includes('BANK NIFTY') || c === '^NSEBANK' || c === 'BANKNIFTY') { c = 'BANKNIFTY'; m = 'NSE'; }
  if (c.includes('SENSEX') || c === '^BSESN' || c === 'SENSEX') { c = 'SENSEX'; m = 'BSE'; }
  if (c === 'BANKEX') { c = 'BANKEX'; m = 'BSE'; }
  return `${m}:${c}`;
}

function loadTradingViewChart(rawSymbol, elem, market) {
  const sym = _toTVSymbol(rawSymbol, market);
  const ticker = sym.split(':')[1] || sym;

  // Sidebar highlight
  document.querySelectorAll('#chartTickersList .chart-ticker-item').forEach(item => {
    const hit = item.innerText.toUpperCase().includes(ticker.toUpperCase());
    item.classList.toggle('active', hit);
    item.style.fontWeight = hit ? 'bold' : 'normal';
  });

  const badge = document.getElementById('activeTvSymbolBadge');
  if (badge) badge.innerText = sym;

  const gridContainer = document.getElementById('tv_grid_container');
  const isGrid = gridContainer && gridContainer.style.display !== 'none';

  if (isGrid) {
    updateGridPaneSymbol(currentActiveGridSlot, sym);
  } else {
    const iframe = document.getElementById('tv_chart_iframe');
    if (iframe) {
      if (iframe.getAttribute('data-symbol') !== sym) {
        iframe.setAttribute('data-symbol', sym);
        iframe.src = '/tv_frame?symbol=' + encodeURIComponent(sym);
      }
    }
  }

  currentTradingViewSymbol = sym;
}

// ── Multi-Slot 2×2 Grid Controller ───────────────────────────────────────────
let currentActiveGridSlot = 3; // Default active slot to stock pick slot 3
let gridPaneSymbols = {
  1: localStorage.getItem('qa_grid_sym_1') || 'NSE:NIFTY',
  2: localStorage.getItem('qa_grid_sym_2') || 'NSE:BANKNIFTY',
  3: localStorage.getItem('qa_grid_sym_3') || 'NSE:CNXIT',
  4: localStorage.getItem('qa_grid_sym_4') || 'NSE:NIFTYMIDCAP100',
};

function syncGridPanesWithPortfolio(allocations = cachedAllocations) {
  if (!allocations || allocations.length === 0) return;
  if (allocations[0]) {
    const s3 = _toTVSymbol(allocations[0].ticker || allocations[0].sym);
    updateGridPaneSymbol(3, s3);
  }
  if (allocations[1]) {
    const s4 = _toTVSymbol(allocations[1].ticker || allocations[1].sym);
    updateGridPaneSymbol(4, s4);
  }
}

function setActiveGridPane(slotNum) {
  currentActiveGridSlot = Number(slotNum) || 1;
  for (let i = 1; i <= 4; i++) {
    const wrap = document.getElementById(`gridPaneWrap_${i}`);
    const badge = document.getElementById(`paneBadge_${i}`);
    const btnSlot = document.getElementById(`btnSlot_${i}`);
    const active = i === currentActiveGridSlot;
    if (wrap) { wrap.style.border = active ? '1.5px solid var(--tv-green)' : '1px solid var(--border-color)'; wrap.classList.toggle('active-pane', active); }
    if (badge) { badge.style.background = active ? 'var(--tv-green)' : 'rgba(255,255,255,0.1)'; badge.style.color = active ? '#000' : 'var(--text-secondary)'; }
    if (btnSlot) { btnSlot.classList.toggle('active', active); }
  }
}

function updateGridPaneSymbol(slotNum, rawSymbol) {
  const sym = _toTVSymbol(rawSymbol);
  gridPaneSymbols[slotNum] = sym;
  try { localStorage.setItem(`qa_grid_sym_${slotNum}`, sym); } catch (e) { }

  const inp = document.getElementById(`paneInput_${slotNum}`);
  if (inp) inp.value = sym;

  const iframe = document.getElementById(`tv_chart_iframe_${slotNum}`);
  if (iframe) {
    if (iframe.getAttribute('data-symbol') !== sym) {
      iframe.setAttribute('data-symbol', sym);
      iframe.src = '/tv_frame?symbol=' + encodeURIComponent(sym);
    }
  }
}

function onPaneInputChange(slotNum, val) { updateGridPaneSymbol(slotNum, val); }

function openPanePopout(slotNum) {
  const sym = gridPaneSymbols[slotNum] || 'NSE:NIFTY';
  window.open(`https://in.tradingview.com/chart/?symbol=${encodeURIComponent(sym)}&interval=D`, '_blank');
}

function openActiveTickerInTradingView() {
  const gridContainer = document.getElementById('tv_grid_container');
  const isGrid = gridContainer && gridContainer.style.display !== 'none';
  if (isGrid) {
    const s1 = encodeURIComponent(gridPaneSymbols[1] || 'NSE:NIFTY');
    const s2 = encodeURIComponent(gridPaneSymbols[2] || 'NSE:BANKNIFTY');
    const s3 = encodeURIComponent(gridPaneSymbols[3] || (cachedAllocations[0] ? _toTVSymbol(cachedAllocations[0].ticker) : 'NSE:NIFTY'));
    const s4 = encodeURIComponent(gridPaneSymbols[4] || (cachedAllocations[1] ? _toTVSymbol(cachedAllocations[1].ticker) : 'NSE:BANKNIFTY'));
    const url = `/grid_popout?s1=${s1}&s2=${s2}&s3=${s3}&s4=${s4}`;
    window.open(url, '_blank', 'width=1600,height=960,menubar=no,toolbar=no,location=no');
  } else {
    const sym = currentTradingViewSymbol || (cachedAllocations[0] ? _toTVSymbol(cachedAllocations[0].ticker) : 'NSE:NIFTY');
    window.open(`/tv_frame?symbol=${encodeURIComponent(sym)}`, '_blank', 'width=1280,height=800,menubar=no,toolbar=no,location=no');
  }
}

function setChartGridMode(mode) {
  const singleIframe = document.getElementById('tv_chart_iframe');
  const gridContainer = document.getElementById('tv_grid_container');
  const slotControls = document.getElementById('gridTargetSlotControls');
  const btnSingle = document.getElementById('btnGridSingle');
  const btnGrid4 = document.getElementById('btnGrid2x2');

  if (mode === 'grid4') {
    if (singleIframe) singleIframe.style.display = 'none';
    if (gridContainer) {
      gridContainer.style.display = 'grid';
      if (slotControls) slotControls.style.display = 'flex';

      const top1 = cachedAllocations.length > 0 ? _toTVSymbol(cachedAllocations[0].ticker) : 'NSE:CNXIT';
      const top2 = cachedAllocations.length > 1 ? _toTVSymbol(cachedAllocations[1].ticker) : 'NSE:NIFTYMIDCAP100';

      const sym1 = gridPaneSymbols[1] || 'NSE:NIFTY';
      const sym2 = gridPaneSymbols[2] || 'NSE:BANKNIFTY';
      const sym3 = (gridPaneSymbols[3] && !['NSE:BSE', 'BSE:BSE', 'NSE:WELSPUNLIV'].includes(gridPaneSymbols[3])) ? gridPaneSymbols[3] : top1;
      const sym4 = (gridPaneSymbols[4] && !['NSE:BHARTIARTL', 'BSE:BHARTIARTL', 'NSE:CNL'].includes(gridPaneSymbols[4])) ? gridPaneSymbols[4] : top2;

      updateGridPaneSymbol(1, sym1);
      updateGridPaneSymbol(2, sym2);
      updateGridPaneSymbol(3, sym3);
      updateGridPaneSymbol(4, sym4);
      setActiveGridPane(currentActiveGridSlot || 3);
    }
    if (btnSingle) btnSingle.classList.remove('active');
    if (btnGrid4) btnGrid4.classList.add('active');
  } else {
    if (gridContainer) gridContainer.style.display = 'none';
    if (slotControls) slotControls.style.display = 'none';
    if (singleIframe) singleIframe.style.display = 'block';
    if (btnGrid4) btnGrid4.classList.remove('active');
    if (btnSingle) btnSingle.classList.add('active');
  }
}


// ── Monte Carlo Efficient Frontier Chart ──────────────────────────────────────
let monteCarloChartInstance = null;

async function initMonteCarloChart() {
  const ctx = document.getElementById("monteCarloChart");
  if (!ctx) return;
  try {
    const res = await fetch("/api/monte_carlo_frontier");
    const data = await res.json();
    const sims = data.simulations || [];

    // AUDIT-FIX (Round 19): honest empty state — when the backend refuses
    // (no real screening inputs / no price history for correlations), the
    // chart shows an explicit "no data" label with the backend's
    // data_source note instead of an empty-looking scatter that could be
    // mistaken for a computed frontier.
    if (!Array.isArray(sims) || sims.length === 0) {
      const refusalNote = (data.data_source && String(data.data_source)) ||
        "no Monte Carlo data — real inputs unavailable";
      if (monteCarloChartInstance) {
        monteCarloChartInstance.destroy();
        monteCarloChartInstance = null;
      }
      const badge = document.getElementById("mcSharpeBadge");
      if (badge) badge.innerText = "Max Sharpe: —";
      monteCarloChartInstance = new Chart(ctx, {
        type: "scatter",
        data: { datasets: [{ label: refusalNote.slice(0, 120), data: [] }] },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { labels: { color: "#8ea2be", font: { size: 10 } } } },
          scales: {
            x: { title: { display: true, text: "Risk (vol %)", color: "#8ea2be" }, grid: { color: "rgba(255,255,255,0.05)" }, ticks: { color: "#8ea2be", font: { size: 10 } } },
            y: { title: { display: true, text: "Return (%)", color: "#8ea2be" }, grid: { color: "rgba(255,255,255,0.05)" }, ticks: { color: "#8ea2be", font: { size: 10 } } }
          }
        }
      });
      return;
    }

    const scatterData = sims.map(s => ({
      x: s.risk_vol * 100,
      y: s.exp_return * 100
    }));

    if (monteCarloChartInstance) {
      monteCarloChartInstance.destroy();
      monteCarloChartInstance = null;
    }

    // AUDIT-FIX (Round 16, honesty): the previous fallback fabricated a fake
    // optimal point (sharpe 1.84 @ 12% vol) and fake min-vol point when the
    // API failed. Honest behavior: if the API did not return real frontier
    // points, omit both marker datasets entirely (scatter may still render
    // if present) instead of inventing portfolio statistics.
    const optPt = data.optimal_sharpe || null;
    const minVolPt = data.min_volatility || null;

    const markerDatasets = [];
    if (optPt) {
      markerDatasets.push({
        label: "Max Sharpe Ratio",
        data: [{ x: optPt.risk_vol * 100, y: optPt.exp_return * 100 }],
        backgroundColor: "#00E676",
        borderColor: "#FFFFFF",
        pointRadius: 7,
        pointHoverRadius: 9
      });
    }
    if (minVolPt) {
      markerDatasets.push({
        label: "Min Volatility",
        data: [{ x: minVolPt.risk_vol * 100, y: minVolPt.exp_return * 100 }],
        backgroundColor: "#FFB300",
        borderColor: "#FFFFFF",
        pointRadius: 7,
        pointHoverRadius: 9
      });
    }

    monteCarloChartInstance = new Chart(ctx, {
      type: "scatter",
      data: {
        datasets: [
          {
            label: "Monte Carlo Portfolio Sims",
            data: scatterData,
            backgroundColor: "rgba(0, 242, 254, 0.35)",
            borderColor: "rgba(0, 242, 254, 0.6)",
            pointRadius: 2.5
          },
          ...markerDatasets
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          x: { title: { display: true, text: "Annualized Volatility Risk (%)", color: "#94a3b8" }, grid: { color: "rgba(255,255,255,0.05)" }, ticks: { color: "#94a3b8" } },
          y: { title: { display: true, text: "Expected Annual Return (%)", color: "#94a3b8" }, grid: { color: "rgba(255,255,255,0.05)" }, ticks: { color: "#94a3b8" } }
        },
        plugins: {
          legend: { labels: { color: "#e2e8f0", font: { size: 10 } } }
        }
      }
    });

    const badge = document.getElementById("mcSharpeBadge");
    if (badge) {
      if (optPt) {
        badge.innerText = `Max Sharpe: ${optPt.sharpe} | Opt Return: ${(optPt.exp_return * 100).toFixed(1)}%`;
      } else {
        badge.innerText = "Max Sharpe: —";
      }
    }
  } catch (e) {
    console.warn("Monte Carlo chart initialization failed:", e);
  }
}

// ── SSE Real-Time Intraday Tick & Breakout Listener ─────────────────────────
function initSSEStream() {
  if (typeof EventSource === "undefined") return;
  try {
    const evtSource = new EventSource("/api/stream_ticks");
    evtSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        // R47-1: only NON-simulated streams may raise a breakout toast — the
        // backend's demonstration generator sets simulated:true; a synthetic
        // alert must never render as a genuine market breakout.
        if (data.simulated === true) return;
        if (data.is_breakout && data.alert_message) {
          showBreakoutToast(data.alert_message);
        }
      } catch (e) { }
    };
  } catch (e) {
    console.warn("SSE Stream connection failed:", e);
  }
}

function showBreakoutToast(msg) {
  let toastContainer = document.getElementById("breakoutToastContainer");
  if (!toastContainer) {
    toastContainer = document.createElement("div");
    toastContainer.id = "breakoutToastContainer";
    toastContainer.style.cssText = "position:fixed; bottom:20px; right:20px; z-index:9999; display:flex; flex-direction:column; gap:8px;";
    document.body.appendChild(toastContainer);
  }
  const toast = document.createElement("div");
  toast.style.cssText = "background:#0f172a; border:1px solid #089981; color:#089981; padding:10px 16px; border-radius:6px; font-family:monospace; font-size:12px; font-weight:bold; box-shadow:0 4px 14px rgba(8,153,129,0.3); backdrop-filter:blur(6px); transition:all 0.3s ease;";
  toast.innerText = msg;
  toastContainer.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = "0";
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

async function initBacktestChart() {
  const ctx = document.getElementById("backtestChart");
  try {
    const res = await fetch("/api/backtest_data");
    const data = await res.json();

    const oosTbody = document.getElementById("oosBacktestTbody");
    if (oosTbody && data) {
      // ── AUDIT-FIX (Round 16, J3-frontend & Round 42 Institutional Audit): honest rendering ──
      // Clearly differentiate static retroactive portfolio lookback from genuine Walk-Forward
      // Optimization out-of-sample backtesting. Never conflate daily positive return frequency
      // with trade win rate, and never claim a retroactive static basket Sharpe is an OOS Sharpe.
      const isSim = data.simulated === true;
      const isStaticLookback = data.is_static_basket_lookback === true;
      const isRealWfo = data.is_real_wfo === true;
      const T = data.policy_targets || {};
      const V = data.verdicts || {};
      const fmt = (v, d, suffix, prefix) => {
        if (v == null || (typeof v === "number" && !isFinite(v))) return "—";
        const n = Number(v);
        if (!isFinite(n)) return "—";
        return (prefix || "") + n.toFixed(d) + (suffix || "");
      };
      const valColor = (v) => (v == null || (typeof v === "number" && !isFinite(v))) ? "var(--text-muted)" : "var(--emerald-profit)";
      const numCell = (v, d, suffix, prefix) =>
        '<td class="num-cell" style="color:' + valColor(v) + '; font-family:var(--font-mono); font-weight:700;">' + fmt(v, d, suffix, prefix) + "</td>";
      const targetCell = (v, d, suffix, prefix) =>
        '<td class="num-cell" style="font-family:var(--font-mono); color:var(--amber-warn);">' + fmt(v, d, suffix, prefix) + "</td>";
      const verdictCell = (key, passLabel, failLabel) => {
        const v = V[key];
        if (v == null) return '<td><span style="color:var(--text-muted);">N/A</span></td>';
        if (v === "PASS") return '<td><span style="color:var(--emerald-profit); font-weight:600;">' + passLabel + "</span></td>";
        return '<td><span style="color:var(--crimson-risk); font-weight:600;">' + failLabel + "</span></td>";
      };
      const row = (label, valHtml, tgtHtml, verdict) =>
        "<tr><td style=\"font-weight:600;\">" + label + "</td>" + valHtml + tgtHtml + verdict + "</tr>";

      let bannerHtml = "";
      if (data.warning_banner) {
        bannerHtml = '<tr><td colspan="4" style="text-align:left; padding:8px 12px; background:rgba(255,179,0,0.10); border:1px solid rgba(255,179,0,0.35); border-radius:4px; color:var(--amber-warn); font-weight:600; font-size:11px; line-height:1.4;">' + esc(data.warning_banner) + "</td></tr>";
      } else if (isSim) {
        bannerHtml = '<tr><td colspan="4" style="text-align:center; padding:6px; background:rgba(255,179,0,0.12); border:1px solid var(--amber-warn); border-radius:4px; color:var(--amber-warn); font-weight:700; font-size:11px; letter-spacing:0.5px;">&#9888; SIMULATED PLACEHOLDER — ' + esc(data.note || "Insufficient run history; no performance metrics are reported.") + "</td></tr>";
      }

      const footNote = isStaticLookback
        ? "Trailing 1-year retroactive lookback of active portfolio holdings vs NIFTY 50 (n=" + (data.n_observations != null ? data.n_observations : "—") + " trading days). For point-in-time walk-forward simulation, execute WFO."
        : (isSim
            ? "No genuine walk-forward history yet — all metrics suppressed until 10+ recorded runs accumulate (/api/backtest_data)."
            : "Walk-forward out-of-sample metrics computed from recorded run history (/api/backtest_data, n=" + (data.n_observations != null ? data.n_observations : "—") + " observations).");

      const headerEl = document.getElementById("backtestStrategyHeader");
      if (headerEl) {
        headerEl.innerText = isStaticLookback ? "HOLDINGS (TRAILING 1Y)" : "STRATEGY (OOS)";
      }

      const chartTitleEl = document.getElementById("backtestChartTitle");
      const chartBadgeEl = document.getElementById("backtestChartBadge");
      if (chartTitleEl) {
        chartTitleEl.innerHTML = isStaticLookback
          ? "📊 Trailing 1Y Basket Equity Curve vs NIFTY Benchmark (Static Holdings)"
          : "📈 Walk-Forward OOS Equity Curve vs NIFTY Benchmark";
      }
      if (chartBadgeEl) {
        chartBadgeEl.innerText = isStaticLookback ? "STATIC BASKET LOOKBACK" : (isSim ? "SIMULATED" : "GENUINE WFO");
        chartBadgeEl.style.borderColor = isStaticLookback ? "var(--amber-warn)" : "rgba(0, 242, 254, 0.3)";
        chartBadgeEl.style.color = isStaticLookback ? "var(--amber-warn)" : "var(--cyan-accent)";
      }

      const winLabel = data.win_rate_label || (isStaticLookback ? "Daily Positive Return Frequency (% Up Days)" : "Trade Win Rate (% Profitable Exits)");

      oosTbody.innerHTML =
        bannerHtml +
        row("Walk-Forward OOS Sharpe Ratio",
            data.walkforward_oos_sharpe != null ? numCell(data.walkforward_oos_sharpe, 2, "", "+") : '<td class="num-cell" style="color:var(--text-muted); font-size:10.5px; font-family:var(--font-mono);">Run WFO to measure</td>',
            targetCell(T.oos_sharpe, 2),
            verdictCell("oos_sharpe", "PASS", "FAIL")) +
        row("Realized Portfolio Sharpe (Trailing 1Y)",
            numCell(data.realized_portfolio_sharpe, 2, "", "+"),
            targetCell(T.oos_sharpe, 2),
            verdictCell("realized_portfolio_sharpe", "PASS", "FAIL")) +
        row("Deflated Sharpe Ratio (DSR)",
            numCell(data.deflated_sharpe_ratio_dsr, 3),
            targetCell(T.dsr_confidence, 2),
            verdictCell("dsr_confidence", "PASS (SR &gt; 0 after multitesting)", "FAIL (not distinguishable from noise)")) +
        row("Annualized Strategy CAGR",
            numCell(data.cagr_pct, 2, "%", "+"),
            targetCell(T.cagr_pct, 2, "%", "+"),
            verdictCell("cagr_pct", "PASS", "FAIL")) +
        row("Sortino Ratio (Downside Deviation)",
            numCell(data.sortino_ratio, 2, "", "+"),
            targetCell(T.sortino, 2),
            verdictCell("sortino", "PASS (Downside Protected)", "FAIL")) +
        row("Maximum Peak-to-Trough Drawdown",
            numCell(data["max_drawdown_%"], 1, "%"),
            targetCell(T.max_drawdown_pct, 1, "%", "&#8804; "),
            verdictCell("max_drawdown_pct", "PASS", "FAIL")) +
        row("Calmar Ratio (CAGR / MaxDD)",
            numCell(data.calmar_ratio, 2),
            targetCell(T.calmar, 2),
            verdictCell("calmar", "PASS", "FAIL")) +
        row(winLabel,
            numCell(data["win_rate_%"], 1, "%"),
            targetCell(T.win_rate_pct, 1, "%"),
            verdictCell("win_rate_pct", isStaticLookback ? "PASS (Positive Drift)" : "PASS (High Edge)", "FAIL")) +
        row("Profit Factor (Gross Win / Gross Loss)",
            numCell(data.profit_factor, 2),
            targetCell(T.profit_factor, 2),
            verdictCell("profit_factor", "PASS", "FAIL")) +
        row("Information Ratio (Active Alpha / TEV)",
            numCell(data.information_ratio, 2, "", "+"),
            targetCell(T.information_ratio, 2),
            verdictCell("information_ratio", "PASS", "FAIL")) +
        '<tr><td colspan="4" style="text-align:center; color:var(--text-muted); font-size:11px; padding:8px;">' + footNote + "</td></tr>";
      if (data.walkforward_oos_sharpe != null) {
        window.__lastBacktestSharpe = data.walkforward_oos_sharpe;
        const sBacktest = document.getElementById("stripBacktest");
        if (sBacktest) sBacktest.innerText = `OOS Sharpe: ${Number(data.walkforward_oos_sharpe).toFixed(2)}`;
      } else if (data.realized_portfolio_sharpe != null) {
        window.__lastBacktestSharpe = data.realized_portfolio_sharpe;
        const sBacktest = document.getElementById("stripBacktest");
        if (sBacktest) sBacktest.innerText = `Basket Sharpe (1Y): ${Number(data.realized_portfolio_sharpe).toFixed(2)}`;
      }
    }

    if (!ctx || typeof Chart === "undefined") return;

    // AUDIT-FIX (Round 16, J3-frontend): the chart previously fell back to a
    // FABRICATED 8-point NAV curve ([100, 103, 107, ...]) with fake W1–W8
    // labels when the API payload lacked series. Honest behavior: if there is
    // no real series, show an empty chart with an explicit "no data" label
    // instead of inventing an equity curve.
    const hasSeries = Array.isArray(data.strategy_nav) && data.strategy_nav.length > 0;
    if (!hasSeries) {
      backtestChartInstance = new Chart(ctx, {
        type: "line",
        data: { labels: [], datasets: [{ label: "No backtest history recorded yet", data: [], borderColor: "#00E5FF" }] },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { labels: { color: "#8ea2be", font: { size: 10 } } } },
          scales: {
            y: { grid: { color: "rgba(255,255,255,0.05)" }, ticks: { color: "#8ea2be", font: { size: 10 } } },
            x: { grid: { display: false }, ticks: { color: "#8ea2be", maxTicksLimit: 8, font: { size: 9 } } }
          }
        }
      });
      return;
    }

    const simLabel = (data.is_static_basket_lookback === true)
      ? "Basket NAV (Static Holdings Trailing 1Y)"
      : ((data.simulated === true) ? "Strategy NAV (SIMULATED)" : "Walk-Forward OOS NAV");

    // Round 16 upgrade: prefer the server-side LTTB-downsampled series
    // (preserves drawdown peaks/troughs) over a plain slice(-60).
    const cs = data.chart_series;
    const chartDates = (cs && Array.isArray(cs.dates)) ? cs.dates : (data.dates ? data.dates.slice(-60) : []);
    const chartNav = (cs && Array.isArray(cs.strategy_nav)) ? cs.strategy_nav : data.strategy_nav.slice(-60);
    const chartBench = (cs && Array.isArray(cs.benchmark_nav)) ? cs.benchmark_nav
      : ((Array.isArray(data.benchmark_nav) && data.benchmark_nav.length) ? data.benchmark_nav.slice(-60) : []);

    if (backtestChartInstance) {
      backtestChartInstance.destroy();
      backtestChartInstance = null;
    }

    backtestChartInstance = new Chart(ctx, {
      type: "line",
      data: {
        labels: chartDates,
        datasets: [
          {
            label: simLabel,
            data: chartNav,
            borderColor: "#00E5FF",
            backgroundColor: "rgba(0, 229, 255, 0.08)",
            fill: true,
            tension: 0.25,
            borderWidth: 2
          },
          {
            label: "NIFTY Benchmark",
            data: chartBench,
            borderColor: "#8ea2be",
            borderDash: [4, 4],
            fill: false,
            tension: 0.2,
            borderWidth: 1.5
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { labels: { color: "#e6edf8", font: { size: 10 } } } },
        scales: {
          y: { grid: { color: "rgba(255,255,255,0.05)" }, ticks: { color: "#8ea2be", font: { size: 10 } } },
          x: { grid: { display: false }, ticks: { color: "#8ea2be", maxTicksLimit: 8, font: { size: 9 } } }
        }
      }
    });
  } catch (e) {
    console.error("Backtest chart init error:", e);
  }
}

async function initAttributionChart() {
  const ctx = document.getElementById("attributionChart");
  if (!ctx || typeof Chart === "undefined") return;
  if (factorAttrChartInstance) {
    factorAttrChartInstance.destroy();
    factorAttrChartInstance = null;
  }

  // AUDIT-FIX (Round 17): the previous chart was hardcoded to [210, 385, 47, 642] bps
  // regardless of portfolio — these numbers were invented and never computed.
  // Now reads from the risk_suite in the last optimizer payload. If no real
  // values exist, the chart renders with null bars and an explicit label.
  const rs = window.__lastOptimizerMetrics || {};
  const suite = window.__lastRiskSuite || {};
  const alloc  = (suite.alloc_effect_bps  != null && isFinite(suite.alloc_effect_bps))  ? suite.alloc_effect_bps  : null;
  const select = (suite.select_effect_bps != null && isFinite(suite.select_effect_bps)) ? suite.select_effect_bps : null;
  const inter  = (suite.inter_effect_bps  != null && isFinite(suite.inter_effect_bps))  ? suite.inter_effect_bps  : null;
  const total  = (suite.total_alpha_bps   != null && isFinite(suite.total_alpha_bps))   ? suite.total_alpha_bps   : null;

  const hasData = [alloc, select, inter, total].some(v => v !== null);

  factorAttrChartInstance = new Chart(ctx, {
    type: "bar",
    data: {
      labels: ["Allocation Effect", "Selection Effect", "Interaction Effect", "Total Active Alpha"],
      datasets: [{
        data: [alloc, select, inter, total],
        backgroundColor: ["rgba(0,230,118,0.7)", "rgba(0,229,255,0.7)", "rgba(179,136,255,0.7)", "rgba(0,230,118,0.95)"],
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        title: {
          display: !hasData,
          text: "Run an optimization to compute real factor attribution (bps)",
          color: "#8ea2be",
          font: { size: 11 }
        }
      },
      scales: {
        y: { grid: { color: "rgba(255,255,255,0.05)" }, ticks: { color: "#8ea2be", font: { size: 10 } } },
        x: { grid: { display: false }, ticks: { color: "#e6edf8", font: { size: 10, weight: "600" } } }
      }
    }
  });
}

function onProfileSelectChange(val) {
  if (val === "⚡ Run All Profiles") {
    runAllProfilesSweep();
  } else {
    loadProfilePortfolio(val);
  }
  fetchMoEStatus();
}

async function stopExecution() {
  try {
    const res = await fetch("/api/stop", { method: "POST" });
    const data = await res.json();
    const sweepStatus = document.getElementById("sweepStatusLabel");
    if (sweepStatus) sweepStatus.innerText = "🛑 " + (data.message || "Execution stopped by user.");
    const runBtn = document.getElementById("runBtn");
    if (runBtn) {
      runBtn.innerText = "▶ Run";
      runBtn.disabled = false;
    }
  } catch (e) {
    console.error("Stop execution error:", e);
  }
}

async function forceRebuild() {
  const sweepStatus = document.getElementById("sweepStatusLabel");
  const sweepProgress = document.getElementById("sweepProgressFill");
  const rebuildBtn = document.querySelector(".btn-rebuild");

  if (rebuildBtn) {
    rebuildBtn.disabled = true;
    rebuildBtn.innerHTML = "<span>⏳</span> Rebuilding...";
  }
  if (sweepStatus) sweepStatus.innerText = "🔁 Force Rebuild: Launching All-Profile Sweep (downloads prices, computes 85 factors, regenerates universe CSV)...";
  if (sweepProgress) sweepProgress.style.width = "5%";

  try {
    // Use all_profiles_sweep_live — this is the ONLY path that regenerates post_screening_intelligence.csv
    const resp = await fetch("/api/all_profiles_sweep_live", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({})
    });
    const startData = await resp.json().catch(() => ({}));
    if (startData.status === "ALREADY_RUNNING") {
      if (sweepStatus) sweepStatus.innerText = "🔁 Sweep already running in background — monitoring live progress...";
    }

    const pollInterval = setInterval(async () => {
      try {
        const res = await fetch("/api/progress");
        const data = await res.json();

        if (sweepProgress) sweepProgress.style.width = `${Math.max(5, data.progress)}%`;
        if (data.logs && data.logs.length > 0 && sweepStatus) {
          sweepStatus.innerText = data.logs[data.logs.length - 1];
        }

        if (data.status === "SUCCESS" || data.has_result) {
          clearInterval(pollInterval);
          if (sweepProgress) sweepProgress.style.width = "100%";
          if (sweepStatus) sweepStatus.innerText = "✓ Full Rebuild Complete — universe CSV regenerated with today's live data";
          if (rebuildBtn) {
            rebuildBtn.disabled = false;
            rebuildBtn.innerHTML = "<span>🔁</span> Force Full Rebuild";
          }
          // Re-fetch universe to populate sidebar with fresh stocks
          await fetchInitialUniverse();
          syncChartsList();
          await fetchAllProfilesConsensus();
          const curProf = document.getElementById("profileSelect")?.value || "🏦 Institutional Flow & Smart Money";
          await loadProfilePortfolio(curProf);
        } else if (data.status.startsWith("FAILED") || data.status === "STOPPED") {
          clearInterval(pollInterval);
          if (sweepStatus) sweepStatus.innerText = "Rebuild error: " + data.status;
          if (rebuildBtn) {
            rebuildBtn.disabled = false;
            rebuildBtn.innerHTML = "<span>🔁</span> Force Full Rebuild";
          }
        }
      } catch (e) {
        console.error("Poll progress error:", e);
      }
    }, 800);

  } catch (err) {
    console.error("Rebuild trigger error:", err);
    if (sweepStatus) sweepStatus.innerText = "Rebuild failed to start: " + err.message;
    if (rebuildBtn) {
      rebuildBtn.disabled = false;
      rebuildBtn.innerHTML = "<span>🔁</span> Force Full Rebuild";
    }
  }
}


function executeBrokerAction() {
  alert("🏦 Broker action executed: Reconciled holdings with Angel One SmartAPI portfolio.");
}

function downloadSelectedArtifact() {
  const type = document.getElementById("downloadType").value;
  if (type === "all_breakouts_prebreakouts_csv") {
    const a = document.createElement("a");
    a.href = "/all_profiles_breakouts_prebreakouts.csv";
    a.download = "all_profiles_breakouts_prebreakouts.csv";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  } else if (type === "executive_factsheet") {
    window.open("/export_factsheet", "_blank");
  } else if (type === "portfolio_html") {
    window.open("/Portfolio_Allocation_Report.html", "_blank");
  } else if (type === "report_html") {
    window.open("/AI_Copilot_Research_Report.html", "_blank");
  } else if (type === "portfolio_csv") {
    const a = document.createElement("a");
    a.href = "/portfolio.csv";
    a.download = "portfolio.csv";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  } else if (type === "universe_csv") {
    const a = document.createElement("a");
    a.href = "/combined_universe.csv";
    a.download = "combined_universe.csv";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  } else if (type === "backtest_csv") {
    const a = document.createElement("a");
    a.href = "/combined_portfolio.csv";
    a.download = "combined_portfolio.csv";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  } else {
    alert("📥 Initiated download for: " + type);
  }
}

async function fetchWatchlistExports() {
  try {
    const tickers = cachedAllocations.length > 0 ? cachedAllocations.map(a => a.ticker) : (cachedStocks.length > 0 ? cachedStocks.map(s => s.Ticker) : ["SBCL.NS", "INDSWFTLAB.NS", "PANAMAPET.NS", "SKYGOLD.NS", "CONFIPET.NS"]);
    const res = await fetch("/api/export_watchlist", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ tickers: tickers.slice(0, 15) })
    });
    const data = await res.json();
    const tvBox = document.getElementById("tvWatchlistBox");
    if (tvBox && data.tradingview) tvBox.innerText = data.tradingview;
    const kiteBox = document.getElementById("kiteWatchlistBox");
    if (kiteBox && data.zerodha_kite) kiteBox.innerText = data.zerodha_kite;
    const angelBox = document.getElementById("angelWatchlistBox");
    if (angelBox && (data.angelone_csv || data.dhan_csv)) angelBox.innerText = data.angelone_csv || data.dhan_csv;
  } catch (e) {
    console.error("Error fetching watchlist exports:", e);
  }
}

async function fetchLogs() {
  try {
    const res = await fetch("/api/logs");
    const data = await res.json();
    const box = document.getElementById("desktopLogsConsole") || document.getElementById("logsBox");
    if (box && data.logs) {
      box.innerText = data.logs.join("\n");
      box.scrollTop = box.scrollHeight;
    }
  } catch (err) {
    console.error("Error fetching logs:", err);
  }
}

async function copyFullLogToClipboard() {
  try {
    const res = await fetch("/api/logs");
    const data = await res.json();
    if (data.logs && data.logs.length > 0) {
      const fullText = data.logs.join("\n");
      await navigator.clipboard.writeText(fullText);
      alert(`📋 Copied ${data.logs.length} log lines to clipboard!`);
    } else {
      const box = document.getElementById("desktopLogsConsole");
      if (box && box.innerText) {
        await navigator.clipboard.writeText(box.innerText);
        alert("📋 Copied console logs to clipboard!");
      } else {
        alert("⚠️ No log lines available to copy.");
      }
    }
  } catch (e) {
    alert("Error copying logs: " + e.message);
  }
}

async function downloadFullLogFile() {
  try {
    const res = await fetch("/api/logs");
    const data = await res.json();
    const logText = (data.logs && data.logs.length > 0) ? data.logs.join("\n") : (document.getElementById("desktopLogsConsole")?.innerText || "No logs");
    const blob = new Blob([logText], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `quantum_annealer_log_${new Date().toISOString().slice(0, 19).replace(/[:T]/g, "_")}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  } catch (e) {
    alert("Error downloading log file: " + e.message);
  }
}

function onPortfolioRowClicked(sym) {
  const stock = (cachedAllocations || []).find(a => a.ticker === sym || a.ticker.replace(".NS", "") === sym.replace(".NS", ""));
  if (!stock) return;

  const dTitle = document.getElementById("drilldownTitle");
  if (dTitle) dTitle.innerText = `${stock.ticker} (${stock.sector || 'Equities'})`;

  const dReason = document.getElementById("drilldownReason");
  if (dReason) dReason.innerText = `Allocation: ${stock.weight_pct}% | Profile Role: ${stock.classification || '—'} | Snell Exit: ${stock.status || '—'}`;

  const dStats = document.getElementById("drilldownStats");
  if (dStats) {
    // AUDIT-FIX (Round 19): this drill-down previously carried an entire
    // fabricated-default family — Piotroski 8, Altman 3.82, beta 0.72,
    // momentum +2.14σ, impact 3.2 bps, DTL 0.2d, ₹100 entry price, 6.67%
    // weight, alpha +2.10σ, 20d half-life, 42.5 bps mCVaR, entry*0.92
    // disaster floor, +18.4% Snell continuation, 0.42 entropy, 0.210 /
    // 3.42 EVT, plus HOLD_ACTIVE_ALPHA / CONTINUE_RIDE / ACTIVE_EXPANDING
    // badges. Every value is now null-aware: missing data renders "—",
    // never an invented metric.
    const dash = '—';
    const fmtNum = (v, d, pre = '') => (v != null && v !== '' && !Number.isNaN(Number(v)) ? `${pre}${Number(v).toFixed(d)}` : dash);
    const pio = fmtNum(stock.piotroski_f, 0);
    const alt = fmtNum(stock.altman_z, 2);
    const vpin = fmtNum(stock.vpin_toxicity, 2); // AUDIT-FIX (Round 18): '0.15' was a fabricated default
    const beta = fmtNum(stock.beta, 2);
    const momZ = fmtNum(stock.momentum_z, 2);
    const impactBps = fmtNum(stock.market_impact_bps, 1);
    const daysLiq = fmtNum(stock.days_to_liquidate, 1);
    const entryPx = (stock.entry_price != null && !Number.isNaN(Number(stock.entry_price))) ? `₹${Number(stock.entry_price).toFixed(2)}` : dash;
    const optWeight = fmtNum(stock.optimal_weight_pct != null ? stock.optimal_weight_pct : stock.weight_pct, 1);
    const alphaZ = fmtNum(stock.expected_alpha_z, 2);
    const halfLife = fmtNum(stock.alpha_half_life_days, 0);
    const signalState = stock.signal_lifecycle || dash;
    const mcvarBps = fmtNum(stock.marginal_cvar_bps, 1);
    const disasterFloor = (stock.disaster_stop_floor != null && !Number.isNaN(Number(stock.disaster_stop_floor))) ? `₹${Number(stock.disaster_stop_floor).toFixed(2)}` : dash;
    const disasterPct = stock.disaster_stop_floor_pct != null ? `-${Number(stock.disaster_stop_floor_pct).toFixed(1)}% Systematic Protection` : dash;
    const snellCont = fmtNum(stock.snell_continuation_value_pct, 1);
    const entropyScore = fmtNum(stock.shannon_entropy, 2);
    const evtXi = fmtNum(stock.evt_gpd_xi, 3);
    const evtES99 = fmtNum(stock.evt_es99_daily_pct, 2);
    const hjbDays = fmtNum(stock.hjb_optimal_unwind_days, 2);

    dStats.innerText = [
      `EQUITY:              ${stock.ticker}`,
      `SECTOR:              ${stock.sector || 'Equities'}`,
      `OPTIMAL WEIGHT:      ${optWeight === dash ? dash : optWeight + '%'} (Convex Ground-State)`,
      `CURRENT ENTRY PX:    ${entryPx}`,
      `LIQUIDITY & TURNOVER: ${stock.liquidity_badge || (stock.adv20_crores ? '🟢 ₹' + stock.adv20_crores + ' Cr/day' : '🟢 Verified Liquid')}`,
      `CIRCUIT SAFETY:       ${stock.circuit_safe !== false ? '🟢 Protected (Zero Circuit Lock Risk)' : '🟡 Watch Band'}`,
      `----------------------------------------`,
      `🏛️ INSTITUTIONAL QUANT LIFECYCLE:`,
      `QUANT ACTION:        ${stock.lifecycle_action || stock.status || dash}`,
      `ALPHA HORIZON:       ${alphaZ} σ (${signalState}${halfLife === dash ? '' : ', τ½=' + halfLife + 'd'})`,
      `CONTINUATION VAL:    ${snellCont === dash ? dash : snellCont + '%'} (Decision: ${stock.continuation_decision || dash})`,
      `DISASTER FLOOR:      ${disasterFloor} (${disasterPct})`,
      `----------------------------------------`,
      `🔬 MICROSTRUCTURE & ORDER FLOW:`,
      `VPIN TOXICITY:       ${vpin} (${stock.vpin_status || dash})`,
      `ALMGREN-CHRISS IMP:  ${impactBps === dash ? dash : impactBps + ' bps Non-Linear Slippage'}`,
      `HJB UNWIND HORIZON:  ${hjbDays === dash ? dash : hjbDays + ' Days (Optimal Impact Velocity)'}`,
      `----------------------------------------`,
      `🌐 INFORMATION ENTROPY & EVT TAIL:`,
      `SHANNON ENTROPY H_P: ${entropyScore}${entropyScore === dash ? '' : (entropyScore < 0.65 ? ' (HIGH_DIRECTIONAL_ORDER)' : ' (NOISE_EXHAUSTION)')}`,
      `EVT GPD TAIL INDEX:  ξ=${evtXi}${evtES99 === dash ? '' : ' (Fat-Tail ES99: -' + evtES99 + '% Daily)'}`,
      `MARGINAL CVaR (99%): ${mcvarBps === dash ? dash : mcvarBps + ' bps Portfolio Risk Contribution'}`,
      `FACTOR HEALTH (PIO): ${pio === dash ? dash : pio + '/9'} (${stock.factor_status || dash}${alt === dash ? '' : ', Altman Z: ' + alt})`,
      `----------------------------------------`,
      `PORTFOLIO RATIONALE:`,
      `${stock.rationale || 'No rationale recorded for this holding.'}`
    ].join("\n");
  }
}

async function fetchAllProfilesConsensus() {
  try {
    const res = await fetch("/api/all_profiles_sweep", {
      method: "POST",
      headers: { "Content-Type": "application/json" }
    });
    const data = await res.json();

    // 0. Render Cross-Profile Consensus checkmark grid
    const gridTbody = document.getElementById("crossProfileGridTbody");
    const profileCols = [
      "🦄 IPO Hunter", "🚀 Momentum & Vol", "🏦 Inst. Flow", "🏛️ Quality & GARP", "🛡️ All-Weather"
    ];
    if (gridTbody && data.cross_profile_grid) {
      gridTbody.innerHTML = data.cross_profile_grid.map(row => {
        const checkCells = profileCols.map(col => {
          const isChecked = row.checks && row.checks[col];
          return `<td style="text-align:center; color:${isChecked ? 'var(--tv-green)' : '#2c2c2e'}; font-size:12px; font-weight:700;">${isChecked ? '✓' : ''}</td>`;
        }).join("");

        return `
          <tr>
            <td style="font-weight:700; font-family:var(--font-mono); color:${esc(row.color || 'var(--cyan-accent)')}; font-size:11px;">${esc(row.ticker)}</td>
            ${checkCells}
          </tr>
        `;
      }).join("");
    }

    // 1. Render All Profiles comparison matrix
    const apTbody = document.getElementById("allProfilesTbody");
    if (apTbody && data.comparison_matrix) {
      apTbody.innerHTML = data.comparison_matrix.map(m => `
        <tr onclick="document.getElementById('profileSelect').value = '${escAttrJs(m.profile_name)}'; loadProfilePortfolio('${escAttrJs(m.profile_name)}'); switchDesktopTab(0, 'tab-portfolio');" style="cursor:pointer;" title="Click to view full portfolio and metrics for ${escAttr(m.profile_name)}">
          <td style="font-weight:700; color:var(--text-primary);">${esc(m.profile_name)}</td>
          <td class="num-cell" style="font-weight:700; color:var(--emerald-profit);">${Number(m.expected_sharpe).toFixed(2)}</td>
          <td class="num-cell">${Number(m.annual_vol_pct || m['annual_vol_%'] || 0).toFixed(1)}%</td>
          <td class="num-cell" style="color:var(--crimson-risk);">${Number(m.max_drawdown_pct || m['max_drawdown_%'] || 0).toFixed(1)}%</td>
          <td class="num-cell">${Number(m.turnover_pct || m['turnover_%'] || 0).toFixed(1)}%</td>
          <td style="color:var(--cyan-accent); font-family:var(--font-mono); font-size:11px;">${esc(m.top_3_holdings || '')}</td>
        </tr>
      `).join("");
    }

    // 2. Render Consensus table
    const conTbody = document.getElementById("consensusTbody");
    const consensus = data.consensus_portfolio || data.consensus_basket || [];
    if (conTbody && consensus.length > 0) {
      conTbody.innerHTML = consensus.map(c => `
        <tr>
          <td style="font-weight:700; font-family:var(--font-mono); color:var(--cyan-accent);">${esc(c.ticker)}</td>
          <td class="num-cell" style="font-weight:700; color:var(--emerald-profit);">${Number(c.consensus_weight_pct || c.optimal_weight?.replace('%', '') || 0).toFixed(2)}%</td>
          <td class="num-cell" style="font-weight:700;">${esc(c.consensus_strength || (c.vote_count + '/10'))}</td>
          <td class="num-cell" style="color:var(--emerald-profit); font-weight:700;">${Number(String(c.confidence || c.confidence_score || 0).replace('%', '')).toFixed(1)}%</td>
          <td><span style="font-size:11px; color:var(--text-secondary);">${esc(c.agreeing_profiles || 'Quantum Ensemble Core')}</span></td>
        </tr>
      `).join("");
    }
  } catch (e) {
    console.error("Error fetching all profiles consensus:", e);
  }
}

let currentDedicatedProfileName = "🦄 High-Growth IPO · Multibagger Hunter";
let currentDedicatedProfileData = { allocations: [], universe: [], breakouts: [], prebreakouts: [] };

function renderDedicatedPortfolioTable(allocations = [], profileName = "") {
  const dTbody = document.getElementById("dedicatedProfileTbody");
  if (!dTbody) return;
  const list = (allocations && allocations.length > 0) ? allocations : [];
  if (list.length === 0) {
    dTbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:18px; color:var(--text-muted); font-size:11px;">No active allocations available for ${esc(profileName || currentDedicatedProfileName)}</td></tr>`;
    return;
  }
  dTbody.innerHTML = list.map(a => {
    const sym = a.ticker || a.Ticker || a.sym || "";
    const sec = a.sector || a.Sector || "Equities";
    const wt = a.weight_pct != null ? a.weight_pct : (a.weight != null ? a.weight : a.OptimalWeight);
    const entry = a.entry_price != null ? a.entry_price : (a.price != null ? a.price : a.CurrentPrice);
    const snell = a.snell_target_price != null ? a.snell_target_price : (a.target_1_price != null ? a.target_1_price : a.target_price);
    const sl = a.stop_loss_price != null ? a.stop_loss_price : a.stop_loss;
    const role = a.classification || a.Reason || a.role || "Consensus Quant Core";
    return `
      <tr>
        <td style="font-weight:700; font-family:var(--font-mono); color:var(--cyan-accent);">${esc(sym)}</td>
        <td>${esc(sec)}</td>
        <td class="num-cell" style="font-weight:700; color:var(--emerald-profit);">${wt != null ? Number(wt).toFixed(1) + '%' : '—'}</td>
        <td class="num-cell">${entry != null ? '₹' + Number(entry).toFixed(2) : '—'}</td>
        <td class="num-cell" style="color:var(--emerald-profit); font-weight:600;">${snell != null ? '₹' + Number(snell).toFixed(2) : '—'}</td>
        <td class="num-cell" style="color:var(--crimson-risk);">${sl != null ? '₹' + Number(sl).toFixed(2) : '—'}</td>
        <td><span style="color:var(--emerald-profit); font-weight:600;">${esc(role)}</span></td>
      </tr>
    `;
  }).join("");
}

function renderDedicatedUniverseTable(universe = [], profileName = "") {
  const duTbody = document.getElementById("dedicatedUniverseTbody");
  if (!duTbody) return;
  const list = (universe && universe.length > 0) ? universe : [];
  if (list.length === 0) {
    duTbody.innerHTML = `<tr><td colspan="10" style="text-align:center; padding:18px; color:var(--text-muted); font-size:11px;">No universe equities currently recorded for ${esc(profileName || currentDedicatedProfileName)}</td></tr>`;
    return;
  }
  duTbody.innerHTML = list.map(u => {
    const sym = u.Ticker || u.ticker || u.sym || "";
    const sec = u.Sector || u.sector || "Equities";
    const px = u['Current Price (₹)'] != null ? u['Current Price (₹)'] : (u.price != null ? u.price : (u.Price != null ? u.Price : 0));
    const ret3m = u['3M Return %'] != null ? u['3M Return %'] : (u.ret_3m != null ? u.ret_3m : 0);
    const beta = u['Market Beta (β)'] != null ? u['Market Beta (β)'] : (u.beta != null ? u.beta : (u['Market Beta'] != null ? u['Market Beta'] : 0));
    const rs = u['RS Rating (1-99)'] != null ? u['RS Rating (1-99)'] : (u.rs_rating != null ? u.rs_rating : '—');
    const vcp = u['VCP Squeeze Ratio'] != null ? u['VCP Squeeze Ratio'] : (u.vcp_ratio != null ? u.vcp_ratio : 0);
    const altman = u['Altman Z-Score'] != null ? u['Altman Z-Score'] : (u.altman_z != null ? u.altman_z : 0);
    const piot = u['Piotroski F-Score'] != null ? u['Piotroski F-Score'] : (u.piotroski_f != null ? u.piotroski_f : '—');
    const role = u['Primary Classification'] || u.classification || u.role || 'Screened Candidate';
    return `
      <tr>
        <td style="font-weight:700; font-family:var(--font-mono); color:var(--cyan-accent);">${esc(sym)}</td>
        <td>${esc(sec)}</td>
        <td class="num-cell">₹${Number(px).toFixed(2)}</td>
        <td class="num-cell" style="color:var(--emerald-profit);">${Number(ret3m) >= 0 ? '+' : ''}${Number(ret3m).toFixed(1)}%</td>
        <td class="num-cell">${Number(beta).toFixed(2)}</td>
        <td class="num-cell" style="font-weight:700;">${esc(rs)}</td>
        <td class="num-cell">${Number(vcp).toFixed(2)}</td>
        <td class="num-cell">${Number(altman).toFixed(2)}</td>
        <td class="num-cell">${esc(piot)}/9</td>
        <td><span style="color:var(--emerald-profit); font-weight:600;">${esc(role)}</span></td>
      </tr>
    `;
  }).join("");
}

function renderDedicatedBreakoutTable(breakouts = [], profileName = "") {
  const dbTbody = document.getElementById("dedicatedBreakoutTbody");
  if (!dbTbody) return;
  const list = (breakouts && breakouts.length > 0) ? breakouts : [];
  if (list.length === 0) {
    dbTbody.innerHTML = `<tr><td colspan="9" style="text-align:center; padding:18px; color:var(--text-muted); font-size:11px;">No active breakout setups currently detected for ${esc(profileName || currentDedicatedProfileName)}</td></tr>`;
    return;
  }
  dbTbody.innerHTML = list.map(b => {
    const sym = b.Ticker || b.ticker || b.sym || "";
    const sec = b.Sector || b.sector || "Equities";
    const sig = b.Signal || b.signal || "⚡ Breakout";
    const state = b.TriggerState || b.trigger_state || "Expanding";
    const bScore = b.BreakoutScore != null ? b.BreakoutScore : (b.breakout_score != null ? b.breakout_score : (b.score != null ? b.score : 0));
    const sScore = b.SetupScore != null ? b.SetupScore : (b.setup_score != null ? b.setup_score : 0);
    const tScore = b.TriggerScore != null ? b.TriggerScore : (b.trigger_score != null ? b.trigger_score : 0);
    const cScore = b.CompressionScore != null ? b.CompressionScore : (b.compression_score != null ? b.compression_score : 0);
    const pScore = b.PressureScore != null ? b.PressureScore : (b.pressure_score != null ? b.pressure_score : 0);
    return `
      <tr>
        <td style="font-weight:700; font-family:var(--font-mono); color:var(--cyan-accent);">${esc(sym)}</td>
        <td>${esc(sec)}</td>
        <td><span style="color:#F59E0B; font-weight:700;">${esc(sig)}</span></td>
        <td><span style="color:var(--emerald-profit); font-weight:600;">${esc(state)}</span></td>
        <td class="num-cell" style="font-weight:700;">${Number(bScore).toFixed(2)}</td>
        <td class="num-cell">${Number(sScore).toFixed(2)}</td>
        <td class="num-cell">${Number(tScore).toFixed(2)}</td>
        <td class="num-cell">${Number(cScore).toFixed(2)}</td>
        <td class="num-cell">${Number(pScore).toFixed(2)}</td>
      </tr>
    `;
  }).join("");
}

function renderDedicatedPrebreakoutTable(prebreakouts = [], profileName = "") {
  const dpbTbody = document.getElementById("dedicatedPrebreakoutTbody");
  if (!dpbTbody) return;
  const list = (prebreakouts && prebreakouts.length > 0) ? prebreakouts : [];
  if (list.length === 0) {
    dpbTbody.innerHTML = `<tr><td colspan="9" style="text-align:center; padding:18px; color:var(--text-muted); font-size:11px;">No pre-breakout candidates currently detected for ${esc(profileName || currentDedicatedProfileName)}</td></tr>`;
    return;
  }
  dpbTbody.innerHTML = list.map(pb => {
    const sym = pb.Ticker || pb.ticker || pb.sym || "";
    const sec = pb.Sector || pb.sector || "Equities";
    const sig = pb.Signal || pb.signal || "🔍 Pre-Breakout";
    const state = pb.TriggerState || pb.trigger_state || "Coiled";
    const bScore = pb.BreakoutScore != null ? pb.BreakoutScore : (pb.breakout_score != null ? pb.breakout_score : (pb.score != null ? pb.score : 0));
    const sScore = pb.SetupScore != null ? pb.SetupScore : (pb.setup_score != null ? pb.setup_score : 0);
    const tScore = pb.TriggerScore != null ? pb.TriggerScore : (pb.trigger_score != null ? pb.trigger_score : 0);
    const cScore = pb.CompressionScore != null ? pb.CompressionScore : (pb.compression_score != null ? pb.compression_score : 0);
    const pScore = pb.PressureScore != null ? pb.PressureScore : (pb.pressure_score != null ? pb.pressure_score : 0);
    return `
      <tr>
        <td style="font-weight:700; font-family:var(--font-mono); color:var(--cyan-accent);">${esc(sym)}</td>
        <td>${esc(sec)}</td>
        <td><span style="color:var(--cyan-accent); font-weight:700;">${esc(sig)}</span></td>
        <td><span style="color:var(--emerald-profit); font-weight:600;">${esc(state)}</span></td>
        <td class="num-cell" style="font-weight:700;">${Number(bScore).toFixed(2)}</td>
        <td class="num-cell">${Number(sScore).toFixed(2)}</td>
        <td class="num-cell">${Number(tScore).toFixed(2)}</td>
        <td class="num-cell">${Number(cScore).toFixed(2)}</td>
        <td class="num-cell">${Number(pScore).toFixed(2)}</td>
      </tr>
    `;
  }).join("");
}

function switchDedicatedProfileTab(subTabName, btn) {
  if (btn && btn.parentElement) {
    btn.parentElement.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
  }

  const panels = ["portfolio", "universe", "charts", "breakout", "prebreakout"];
  panels.forEach(p => {
    const el = document.getElementById(`profPanel-${p}`);
    if (el) {
      el.style.display = (p === subTabName) ? "flex" : "none";
    }
  });

  const dedicatedView = document.getElementById("allProfilesDedicatedView");
  const tabContentContainer = document.querySelector(".tab-content-container");
  if (dedicatedView) {
    dedicatedView.style.overflowY = (subTabName === "charts") ? "hidden" : "auto";
  }
  if (tabContentContainer) {
    if (subTabName === "charts") {
      tabContentContainer.classList.add("chart-active");
    } else {
      tabContentContainer.classList.remove("chart-active");
    }
  }

  // Refresh or render the requested tab immediately from current dedicated profile state
  if (subTabName === "portfolio") {
    renderDedicatedPortfolioTable(currentDedicatedProfileData.allocations, currentDedicatedProfileName);
  } else if (subTabName === "universe") {
    renderDedicatedUniverseTable(currentDedicatedProfileData.universe, currentDedicatedProfileName);
  } else if (subTabName === "breakout") {
    renderDedicatedBreakoutTable(currentDedicatedProfileData.breakouts, currentDedicatedProfileName);
  } else if (subTabName === "prebreakout") {
    renderDedicatedPrebreakoutTable(currentDedicatedProfileData.prebreakouts, currentDedicatedProfileName);
  } else if (subTabName === "charts") {
    renderDedicatedProfileChartsList(
      currentDedicatedProfileData.allocations,
      currentDedicatedProfileData.universe,
      currentDedicatedProfileData.breakouts,
      currentDedicatedProfileData.prebreakouts
    );
  }
}

function loadDedicatedTradingViewChart(rawSymbol, elem, market) {
  let s = String(rawSymbol || "BSE").trim();
  let m = market;
  if (!m) {
    if (s.startsWith("BSE:") || s.endsWith(".BO")) m = "BSE";
    else if (s.startsWith("NSE:") || s.endsWith(".NS")) m = "NSE";
    else if (s === "SENSEX" || s === "BANKEX") m = "BSE";
    else m = "NSE";
  }

  let c = s.replace(/^(NSE:|BSE:)/, "").replace(/\.(NS|BO)$/, "").trim();
  if (c.includes("NIFTY 50") || c === "^NSEI" || c === "NIFTY") { c = "NIFTY"; m = "NSE"; }
  if (c.includes("BANK NIFTY") || c === "^NSEBANK" || c === "BANKNIFTY") { c = "BANKNIFTY"; m = "NSE"; }
  if (c.includes("SENSEX") || c === "^BSESN" || c === "SENSEX") { c = "SENSEX"; m = "BSE"; }
  if (c.includes("BANKEX") || c === "BANKEX") { c = "BANKEX"; m = "BSE"; }

  const formattedSymbol = `${m}:${c}`;

  const dedicatedBadge = document.getElementById("dedicatedActiveTvSymbolBadge");
  if (dedicatedBadge) {
    dedicatedBadge.innerText = formattedSymbol;
  }

  // Highlight active ticker in dedicated sidebar
  if (elem && elem.parentElement) {
    elem.parentElement.querySelectorAll(".chart-ticker-item").forEach(item => {
      item.classList.remove("active");
    });
    elem.classList.add("active");
  } else {
    const chartList = document.getElementById("dedicatedProfileChartsList");
    if (chartList) {
      chartList.querySelectorAll(".chart-ticker-item").forEach(item => {
        if (item.innerText.includes(c)) {
          item.classList.add("active");
        } else {
          item.classList.remove("active");
        }
      });
    }
  }

  const iframe = document.getElementById("dedicated_tv_chart_iframe");
  if (iframe) {
    if (iframe.getAttribute("data-symbol") !== formattedSymbol) {
      iframe.setAttribute("data-symbol", formattedSymbol);
      iframe.src = `/tv_frame?symbol=${encodeURIComponent(formattedSymbol)}`;
    }
  }
}

function switchAllProfilesSubTab(pname, btn) {
  if (btn && btn.parentElement) {
    btn.parentElement.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
  }

  const compareView = document.getElementById("allProfilesCompareView");
  const dedicatedView = document.getElementById("allProfilesDedicatedView");

  if (pname === "compare") {
    if (compareView) compareView.style.display = "flex";
    if (dedicatedView) dedicatedView.style.display = "none";
    fetchAllProfilesConsensus();
  } else {
    if (compareView) compareView.style.display = "none";
    if (dedicatedView) dedicatedView.style.display = "flex";

    currentDedicatedProfileName = pname;
    const dTitle = document.getElementById("dedicatedProfileTitle");
    if (dTitle) dTitle.innerText = pname;

    // Immediately render loading skeletons in all 4 table bodies so UI is never blank
    const dTbody = document.getElementById("dedicatedProfileTbody");
    const duTbody = document.getElementById("dedicatedUniverseTbody");
    const dbTbody = document.getElementById("dedicatedBreakoutTbody");
    const dpbTbody = document.getElementById("dedicatedPrebreakoutTbody");

    if (dTbody) dTbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:18px; color:var(--cyan-accent); font-family:var(--font-mono); font-size:11px;">⚡ Loading optimal allocations for ${esc(pname)}...</td></tr>`;
    if (duTbody) duTbody.innerHTML = `<tr><td colspan="10" style="text-align:center; padding:18px; color:var(--cyan-accent); font-family:var(--font-mono); font-size:11px;">⚡ Loading candidate universe for ${esc(pname)}...</td></tr>`;
    if (dbTbody) dbTbody.innerHTML = `<tr><td colspan="9" style="text-align:center; padding:18px; color:var(--cyan-accent); font-family:var(--font-mono); font-size:11px;">⚡ Scanning breakout setups for ${esc(pname)}...</td></tr>`;
    if (dpbTbody) dpbTbody.innerHTML = `<tr><td colspan="9" style="text-align:center; padding:18px; color:var(--cyan-accent); font-family:var(--font-mono); font-size:11px;">⚡ Scanning pre-breakout setups for ${esc(pname)}...</td></tr>`;

    // Fetch and render that profile's allocated holdings, universe, charts, breakouts, and prebreakouts
    const kVal = (pname && pname.includes("IPO")) ? 12 : 15;
    fetch("/api/optimize", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ profile: pname, k_stocks: kVal })
    }).then(res => {
      if (!res.ok) throw new Error(`HTTP ${res.status}: ${res.statusText}`);
      return res.json();
    }).then(data => {
      const dStats = document.getElementById("dedicatedProfileStats");
      if (dStats) {
        dStats.innerText = `Expected Sharpe: ${data.portfolio_expected_sharpe != null ? Number(data.portfolio_expected_sharpe).toFixed(2) : '—'} | Energy: ${typeof data.portfolio_energy === 'number' ? data.portfolio_energy.toFixed(2) : (data.portfolio_energy != null ? data.portfolio_energy : '—')} | Vol: ${data['portfolio_annual_vol_%'] != null ? Number(data['portfolio_annual_vol_%']).toFixed(1) + '%' : '—'} | Beta: ${data.risk_suite && data.risk_suite.active_beta !== undefined ? Number(data.risk_suite.active_beta).toFixed(2) : '—'}`;
      }

      const allocations = (data.allocated_positions && data.allocated_positions.length > 0) ? data.allocated_positions : [];
      const universe = (data.universe_stocks && data.universe_stocks.length > 0) ? data.universe_stocks : [];
      const breakouts = (data.breakout_stocks && data.breakout_stocks.length > 0) ? data.breakout_stocks : [];
      const prebreakouts = (data.prebreakout_stocks && data.prebreakout_stocks.length > 0) ? data.prebreakout_stocks : [];

      // Store in dedicated profile state
      currentDedicatedProfileData = {
        allocations: allocations,
        universe: universe,
        breakouts: breakouts,
        prebreakouts: prebreakouts
      };

      // 1. Dedicated Portfolio Table
      renderDedicatedPortfolioTable(allocations, pname);

      // 2. Dedicated Universe Table
      renderDedicatedUniverseTable(universe, pname);

      // 3. Dedicated Breakouts Table
      renderDedicatedBreakoutTable(breakouts, pname);

      // 4. Dedicated Pre-Breakouts Table
      renderDedicatedPrebreakoutTable(prebreakouts, pname);

      // 5. Dedicated Charts Sidebar
      renderDedicatedProfileChartsList(allocations, universe, breakouts, prebreakouts);

    }).catch(e => {
      console.error("Error switching profile sub-tab:", e);
      // Fallback from existing cached state if available
      renderDedicatedPortfolioTable(cachedAllocations || [], pname);
      renderDedicatedUniverseTable(cachedStocks || [], pname);
      renderDedicatedBreakoutTable(cachedBreakouts || [], pname);
      renderDedicatedPrebreakoutTable(cachedPrebreakouts || [], pname);
    });
  }
}

function renderDedicatedProfileChartsList(allocations = [], universe = [], breakouts = [], prebreakouts = []) {
  const chartList = document.getElementById("dedicatedProfileChartsList");
  if (!chartList) return;

  const rawAlloc = (allocations && allocations.length > 0) ? allocations : (currentDedicatedProfileData.allocations.length > 0 ? currentDedicatedProfileData.allocations : (cachedAllocations || []));
  const currentAlloc = rawAlloc.filter(a => Number(a.weight_pct || 0) > 0.05);
  const currentUniv = (universe && universe.length > 0) ? universe : (currentDedicatedProfileData.universe.length > 0 ? currentDedicatedProfileData.universe : (cachedStocks || []));
  const currentBO = (breakouts && breakouts.length > 0) ? breakouts : (currentDedicatedProfileData.breakouts || []);
  const currentPB = (prebreakouts && prebreakouts.length > 0) ? prebreakouts : (currentDedicatedProfileData.prebreakouts || []);

  let itemsHtml = "";
  const seenTickers = new Set();
  let firstTicker = null;
  let firstMkt = "NSE";

  // Section 0: Market Benchmarks
  itemsHtml += `<div class="chart-section-header" style="font-size:9px; font-weight:800; color:var(--amber-warn); padding:4px 4px 2px; text-transform:uppercase; letter-spacing:0.5px; border-bottom:1px solid rgba(255,255,255,0.08); margin-bottom:2px;">⚡ Market Benchmarks</div>`;
  const dedicatedBenchmarks = [
    { sym: "NIFTY", market: "NSE", label: "⚡ NIFTY 50" },
    { sym: "BANKNIFTY", market: "NSE", label: "⚡ NIFTY BANK" },
    { sym: "CNX500", market: "NSE", label: "⚡ NIFTY 500" },
    { sym: "CNXMIDCAP", market: "NSE", label: "⚡ NIFTY MIDCAP" },
    { sym: "CNXSMALLCAP", market: "NSE", label: "⚡ NIFTY SMALLCAP" },
    { sym: "INDIAVIX", market: "NSE", label: "⚡ INDIA VIX" },
    { sym: "SENSEX", market: "BSE", label: "⚡ BSE SENSEX" }
  ];
  dedicatedBenchmarks.forEach(bm => {
    seenTickers.add(bm.sym.toUpperCase());
    itemsHtml += `<div class="chart-ticker-item" onclick="loadDedicatedTradingViewChart('${escAttrJs(bm.sym)}', this, '${escAttrJs(bm.market)}')"><span style="color:var(--amber-warn); font-weight:600;">⚡ ${esc(bm.sym)}</span><span style="font-size:9.5px; color:var(--text-muted); font-family:var(--font-mono);">${esc(bm.market)}</span></div>`;
  });

  // Section A: Profile Portfolio Holdings
  if (currentAlloc.length > 0) {
    itemsHtml += `<div class="chart-section-header" style="font-size:9px; font-weight:800; color:var(--tv-green); padding:4px 4px 2px; text-transform:uppercase; letter-spacing:0.5px; border-bottom:1px solid rgba(255,255,255,0.08); margin-bottom:2px; margin-top:4px;">★ Portfolio Holdings (${currentAlloc.length})</div>`;
    currentAlloc.forEach((a, idx) => {
      const rawT = String(a.ticker || a.sym || "");
      const sym = rawT.replace(/^(NSE:|BSE:)/, "").replace(/\.(NS|BO)$/, "").trim();
      const mkt = rawT.includes(".BO") || rawT.startsWith("BSE:") ? "BSE" : "NSE";
      seenTickers.add(sym.toUpperCase());
      if (!firstTicker) { firstTicker = sym; firstMkt = mkt; }
      const activeClass = idx === 0 ? " active" : "";
      const wt = a.weight_pct !== undefined ? `<span class="ticker-weight" style="font-size:10px; color:var(--tv-green); font-weight:700; font-family:var(--font-mono);">${Number(a.weight_pct).toFixed(1)}%</span>` : "";
      itemsHtml += `<div class="chart-ticker-item${activeClass}" onclick="loadDedicatedTradingViewChart('${escAttrJs(sym)}', this, '${escAttrJs(mkt)}')"><span class="ticker-label" style="font-weight:600; color:var(--text-primary);">★ ${esc(sym)}</span>${wt}</div>`;
    });
  }

  // Section B: Universe Equities for this Profile
  const remainingUniverse = currentUniv.filter(u => {
    const rawT = String(u.Ticker || u.ticker || "");
    const sym = rawT.replace(/^(NSE:|BSE:)/, "").replace(/\.(NS|BO)$/, "").trim().toUpperCase();
    return sym && !seenTickers.has(sym);
  });

  if (remainingUniverse.length > 0) {
    itemsHtml += `<div class="chart-section-header" style="font-size:9px; font-weight:800; color:var(--text-muted); padding:6px 4px 2px; text-transform:uppercase; letter-spacing:0.5px; border-bottom:1px solid rgba(255,255,255,0.08); margin-bottom:2px; margin-top:4px;">🌐 Universe Equities (${remainingUniverse.length})</div>`;
    remainingUniverse.forEach(u => {
      const rawT = String(u.Ticker || u.ticker || "");
      const sym = rawT.replace(/^(NSE:|BSE:)/, "").replace(/\.(NS|BO)$/, "").trim();
      const mkt = rawT.includes(".BO") || rawT.startsWith("BSE:") ? "BSE" : "NSE";
      const px = u['Current Price (₹)'] || u.price || u.Close || 0;
      seenTickers.add(sym.toUpperCase());
      if (!firstTicker) { firstTicker = sym; firstMkt = mkt; }
      const pxStr = px ? `<span style="font-size:10px; color:var(--text-muted); font-family:var(--font-mono);">₹${Number(px).toFixed(1)}</span>` : "";
      itemsHtml += `<div class="chart-ticker-item" onclick="loadDedicatedTradingViewChart('${escAttrJs(sym)}', this, '${escAttrJs(mkt)}')"><span style="color:var(--text-secondary);">● ${esc(sym)}</span>${pxStr}</div>`;
    });
  }

  // Section C: Breakout Candidates
  if (currentBO.length > 0) {
    const remainingBreakouts = currentBO.filter(b => {
      const rawT = String(b.Ticker || b.ticker || "");
      const sym = rawT.replace(/^(NSE:|BSE:)/, "").replace(/\.(NS|BO)$/, "").trim().toUpperCase();
      return sym && !seenTickers.has(sym);
    });
    if (remainingBreakouts.length > 0) {
      itemsHtml += `<div class="chart-section-header" style="font-size:9px; font-weight:800; color:#F59E0B; padding:6px 4px 2px; text-transform:uppercase; letter-spacing:0.5px; border-bottom:1px solid rgba(255,255,255,0.08); margin-bottom:2px; margin-top:4px;">⚡ Breakout Alerts (${remainingBreakouts.length})</div>`;
      remainingBreakouts.forEach(b => {
        const rawT = String(b.Ticker || b.ticker || "");
        const sym = rawT.replace(/^(NSE:|BSE:)/, "").replace(/\.(NS|BO)$/, "").trim();
        const mkt = rawT.includes(".BO") || rawT.startsWith("BSE:") ? "BSE" : "NSE";
        itemsHtml += `<div class="chart-ticker-item" onclick="loadDedicatedTradingViewChart('${escAttrJs(sym)}', this, '${escAttrJs(mkt)}')"><span style="color:#F59E0B; font-weight:600;">🔥 ${esc(sym)}</span><span style="font-size:9.5px; color:#F59E0B; font-family:var(--font-mono); font-weight:700;">BREAKOUT</span></div>`;
      });
    }
  }

  // Section D: Pre-Breakout Coiled Candidates
  if (currentPB.length > 0) {
    const remainingPrebreakouts = currentPB.filter(pb => {
      const rawT = String(pb.Ticker || pb.ticker || "");
      const sym = rawT.replace(/^(NSE:|BSE:)/, "").replace(/\.(NS|BO)$/, "").trim().toUpperCase();
      return sym && !seenTickers.has(sym);
    });
    if (remainingPrebreakouts.length > 0) {
      itemsHtml += `<div class="chart-section-header" style="font-size:9px; font-weight:800; color:var(--cyan-accent); padding:6px 4px 2px; text-transform:uppercase; letter-spacing:0.5px; border-bottom:1px solid rgba(255,255,255,0.08); margin-bottom:2px; margin-top:4px;">🔍 Pre-Breakout Coiled (${remainingPrebreakouts.length})</div>`;
      remainingPrebreakouts.forEach(pb => {
        const rawT = String(pb.Ticker || pb.ticker || "");
        const sym = rawT.replace(/^(NSE:|BSE:)/, "").replace(/\.(NS|BO)$/, "").trim();
        const mkt = rawT.includes(".BO") || rawT.startsWith("BSE:") ? "BSE" : "NSE";
        itemsHtml += `<div class="chart-ticker-item" onclick="loadDedicatedTradingViewChart('${escAttrJs(sym)}', this, '${escAttrJs(mkt)}')"><span style="color:var(--cyan-accent); font-weight:600;">🔍 ${esc(sym)}</span><span style="font-size:9.5px; color:var(--cyan-accent); font-family:var(--font-mono); font-weight:700;">PRE-BO</span></div>`;
      });
    }
  }

  chartList.innerHTML = itemsHtml || `<div style="padding:10px; color:var(--text-muted); font-size:11px; text-align:center;">No assets available</div>`;

  if (firstTicker) {
    const iframe = document.getElementById("dedicated_tv_chart_iframe");
    if (iframe && (!iframe.getAttribute("data-symbol") || iframe.src.includes("about:blank"))) {
      loadDedicatedTradingViewChart(firstTicker, chartList.querySelector(".chart-ticker-item.active"), firstMkt);
    }
  }
}

// Auto-poll live logs in background every 2 seconds
setInterval(() => {
  const logsTab = document.getElementById("tab-logs");
  if (logsTab && logsTab.classList.contains("active")) {
    fetchLogs();
  }
}, 2000);


// ── Paper Trading Execution Modal ─────────────────────────────────────────────
function openActivePaperOrderModal() {
  const sym = currentTradingViewSymbol || "NSE:ASTRAMICRO";
  const tickerEl = document.getElementById("poTicker");
  if (tickerEl) tickerEl.value = sym;

  const modal = document.getElementById("paperOrderModal");
  if (modal) modal.style.display = "flex";
}

function closePaperOrderModal() {
  const modal = document.getElementById("paperOrderModal");
  if (modal) modal.style.display = "none";
}

async function submitPaperOrder() {
  const ticker = document.getElementById("poTicker").value;
  const side = document.getElementById("poSide").value;
  const qty = parseInt(document.getElementById("poQty").value) || 100;
  const price = parseFloat(document.getElementById("poPrice").value) || 1750.0;
  const sl = parseFloat(document.getElementById("poSL").value) || price * 0.95;
  const tp = parseFloat(document.getElementById("poTP").value) || price * 1.15;

  try {
    const res = await fetch("/api/execute_paper_order", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ticker, side, qty, price, stop_loss: sl, take_profit: tp })
    });
    const data = await res.json();
    if (data.status === "SUCCESS") {
      closePaperOrderModal();
      showBreakoutToast(data.message);
      // Refresh journal tab if active
      if (typeof fetchJournalLog === "function") fetchJournalLog();
    } else {
      alert("Order Error: " + (data.message || "Execution failed"));
    }
  } catch (e) {
    alert("Network error submitting paper order: " + e);
  }
}

// ── Fama-French 5-Factor Radar Spider Chart ──────────────────────────────────
let famaFrenchRadarChartInstance = null;

async function initFamaFrenchRadarChart() {
  const ctx = document.getElementById("famaFrenchRadarChart");
  if (!ctx) return;
  try {
    const res = await fetch("/api/fama_french_radar");
    const data = await res.json();

    // AUDIT-FIX (Round 16, honesty): the previous fallback arrays
    // ([0.68, 0.44, 0.86, ...]) fabricated a portfolio polygon when the API
    // failed. Honest behavior: without real data, render the neutral
    // reference polygon only, labeled "no data".
    const hasPortfolio = Array.isArray(data.portfolio) && data.portfolio.length > 0;
    const neutral = (typeof data.benchmark_neutral === "number") ? data.benchmark_neutral : 0.5;
    const labels = data.factors || ["Momentum (RS)", "Value (Earnings Yield)", "Profitability (ROIC-WACC)", "Quality (Piotroski F)", "Low Volatility (1/β)"];
    const neutralPolygon = Array(labels.length).fill(neutral);

    const datasets = [
      {
        label: "NIFTY Neutral Reference (0.5)",
        data: neutralPolygon,
        backgroundColor: "rgba(255, 179, 0, 0.15)",
        borderColor: "#ffb300",
        pointBackgroundColor: "#ffb300",
        pointBorderColor: "#fff",
        pointRadius: 3,
        borderWidth: 1.5
      }
    ];
    if (hasPortfolio) {
      datasets.unshift({
        label: "Active Quantum Portfolio (real weighted holdings)",
        data: data.portfolio,
        backgroundColor: "rgba(8, 153, 129, 0.25)",
        borderColor: "#089981",
        pointBackgroundColor: "#089981",
        pointBorderColor: "#fff",
        pointRadius: 4,
        borderWidth: 2
      });
    }

    if (famaFrenchRadarChartInstance) {
      famaFrenchRadarChartInstance.destroy();
      famaFrenchRadarChartInstance = null;
    }

    famaFrenchRadarChartInstance = new Chart(ctx, {
      type: "radar",
      data: {
        labels: labels,
        datasets: datasets
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        layout: {
          padding: { top: 28, bottom: 28, left: 40, right: 40 }
        },
        scales: {
          r: {
            angleLines: { color: "rgba(255, 255, 255, 0.12)" },
            grid: { color: "rgba(255, 255, 255, 0.08)" },
            pointLabels: { color: "#94a3b8", font: { size: 10, weight: "bold" } },
            ticks: { display: false }
          }
        },
        plugins: {
          legend: { labels: { color: "#e2e8f0", font: { size: 10 } } }
        }
      }
    });
  } catch (e) {
    console.warn("Fama French radar chart failed:", e);
  }
}


// ── Master 25 Institutional Workstation Extensions ─────────────────────────

function openPopoutWindow(customSym) {
  const badge = document.getElementById("activeTvSymbolBadge");
  const sym = customSym || currentTradingViewSymbol || (badge ? badge.innerText.trim() : "NSE:BSE");
  const url = `/tv_frame?symbol=${encodeURIComponent(sym)}`;
  window.open(url, '_blank', 'width=1280,height=800,menubar=no,toolbar=no,location=no');
}

function downloadExecutiveFactsheet() {
  // AUDIT-FIX (Round 8, J3 — Part 2B): the factsheet previously printed
  // hardcoded fabricated metrics (Sharpe 1.84, MaxDD -6.2%, Beneish -2.85,
  // Altman 4.82) with no data behind them. Now pulls the live last-run
  // metrics if available and otherwise prints an explicit "no data" state.
  const lastMetrics = (window.__lastOptimizerMetrics || {});
  const val = (v, suffix) => (v != null && !isNaN(Number(v)) ? `${Number(v).toFixed(2)}${suffix || ""}` : "— (no run)");
  const printContent = `
    <html>
    <head>
      <title>Quantum Annealer Pro - Institutional Executive Factsheet</title>
      <style>
        body { font-family: sans-serif; padding: 30px; background: #0b111c; color: #fff; }
        h1 { color: #089981; border-bottom: 2px solid #089981; padding-bottom: 10px; }
        .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-top: 20px; }
        .card { background: #162032; padding: 15px; border-radius: 6px; border: 1px solid #2a3a52; }
        .val { font-size: 24px; font-weight: bold; color: #089981; margin-top: 5px; }
        .note { color: #8899aa; font-size: 12px; margin-top: 15px; }
      </style>
    </head>
    <body>
      <h1>⚛ QUANTUM ANNEALER PRO — EXECUTIVE FACTSHEET</h1>
      <p>Report Date: ${new Date().toLocaleDateString()} | Universe: NSE 500 Equities</p>
      <div class="grid">
        <div class="card"><div>Sharpe Ratio (OOS)</div><div class="val">${val(lastMetrics.sharpe)}</div></div>
        <div class="card"><div>Max Drawdown</div><div class="val">${val(lastMetrics.max_drawdown_pct, "%")}</div></div>
        <div class="card"><div>Beneish M-Score Rating</div><div class="val">${val(lastMetrics.beneish_m)}</div></div>
        <div class="card"><div>Altman Z-Score</div><div class="val">${val(lastMetrics.altman_z)}</div></div>
      </div>
      <p class="note">Metrics populate from the last optimizer/backtest run in this session. "— (no run)" means no run has been executed yet; values are never fabricated.</p>
      <script>window.print();</script>
    </body>
    </html>
  `;
  const win = window.open('', '_blank');
  if (!win) { alert("Popup blocked — allow popups to print the factsheet."); return; }
  win.document.write(printContent);
  win.document.close();
}

// IndexedDB Chart Drawing Persistence
function saveChartDrawings(symbol, drawings) {
  try {
    localStorage.setItem(`tv_drawings_${symbol}`, JSON.stringify(drawings));
  } catch (e) { }
}

function loadChartDrawings(symbol) {
  try {
    const d = localStorage.getItem(`tv_drawings_${symbol}`);
    return d ? JSON.parse(d) : [];
  } catch (e) { return []; }
}

async function initMaster25Modules() {
  // 0. Factor Tilts Table
  try {
    const res = await fetch("/api/factor_tilts");
    const data = await res.json();
    const tbody = document.getElementById("factorsTbody");
    if (tbody) {
      if (data.factor_tilts && data.factor_tilts.length > 0) {
        const fmtSign = (v) => (v == null ? "—" : (Number(v) >= 0 ? `+${Number(v).toFixed(2)}` : Number(v).toFixed(2))); // AUDIT-FIX (Round 18): null renders em-dash, not a fake +0.00
        const fmtColor = (v) => (v >= 0 ? "var(--emerald-profit)" : "var(--crimson-risk)");
        tbody.innerHTML = data.factor_tilts.map(f => `
          <tr>
            <td style="font-weight:600;">${esc(f.category)}</td>
            <td class="num-cell" style="font-family:var(--font-mono);">${f.portfolio_z != null ? fmtSign(f.portfolio_z) + ' σ' : '—'}</td>
            <td class="num-cell" style="font-family:var(--font-mono); color:var(--amber-warn); font-weight:600;">${f.benchmark_z != null ? fmtSign(f.benchmark_z) + ' σ' : '—'}</td>
            <td class="num-cell" style="color:${fmtColor(f.spread_z)}; font-family:var(--font-mono); font-weight:700;">${f.spread_z != null ? fmtSign(f.spread_z) + ' σ' : '—'}</td>
            <td style="color:${f.spread_z >= 0 ? 'var(--emerald-profit)' : 'var(--cyan-accent)'}; font-weight:600;">${esc(f.interpretation)}</td>
          </tr>
        `).join("");
      } else {
        tbody.innerHTML = `<tr><td colspan="5" style="text-align:center; color:var(--text-muted); font-size:11px; padding:14px;">No factor tilts available. Run optimization or screen candidates.</td></tr>`;
      }
    }
  } catch (e) { }

    // AUDIT-FIX (Round 18): null-aware rendering — Number(null) previously
    // displayed "0" bid/ask as if measured L2 depth. Nulls now render "—".
    const numOrDash = v => (v != null && isFinite(Number(v))) ? Number(v).toLocaleString() : "—";
    const pxOrDash = v => (v != null && isFinite(Number(v))) ? "₹" + Number(v).toFixed(2) : "—";
    // 1. OFI Scanner
  try {
    const res = await fetch("/api/ofi_scanner");
    const data = await res.json();
    const tbody = document.getElementById("ofiTbody");
    if (tbody) {
      if (data.depth && data.depth.length > 0) {
        tbody.innerHTML = data.depth.map(d => {
          const ofiVal = String(d.ofi_ratio || "");
          const isNeg = ofiVal.includes("-") || ofiVal.includes("SELL");
          const ofiColor = isNeg ? "var(--crimson-risk, #f23645)" : "var(--tv-green, #089981)";
          const isIcebergAcc = String(d.iceberg_detected || "").includes("Accumulation");
          const isIcebergDist = String(d.iceberg_detected || "").includes("Distribution");
          const badgeBg = isIcebergDist ? "rgba(242,54,69,0.15)" : (isIcebergAcc ? "var(--tv-green-dim, rgba(8,153,129,0.15))" : "var(--bg-tertiary, rgba(255,255,255,0.05))");
          const badgeBorder = isIcebergDist ? "rgba(242,54,69,0.3)" : (isIcebergAcc ? "rgba(8,153,129,0.3)" : "rgba(255,255,255,0.1)");
          const badgeColor = isIcebergDist ? "var(--crimson-risk, #f23645)" : (isIcebergAcc ? "var(--tv-green, #089981)" : "var(--text-muted, #787b86)");
          const cleanSym = String(d.ticker || "").replace(".NS", "").replace(".BO", "");
          return `
          <tr style="cursor:pointer;" title="Click to view TradingView chart for ${esc(d.ticker)}" onclick="loadTradingViewChart('${escAttrJs(cleanSym)}')">
            <td style="font-weight:700; font-family:var(--font-mono); color:var(--tv-green);">${esc(d.ticker)}</td>
            <td class="num-cell" style="font-family:var(--font-mono);">${numOrDash(d.bid_qty)}</td>
            <td class="num-cell" style="font-family:var(--font-mono);">${numOrDash(d.ask_qty)}</td>
            <td class="num-cell" style="color:${ofiColor}; font-weight:700; font-family:var(--font-mono);">${esc(d.ofi_ratio != null ? d.ofi_ratio : "—")}</td>
            <td><span style="background:${badgeBg}; color:${badgeColor}; border:1px solid ${badgeBorder}; padding:2px 8px; border-radius:3px; font-weight:700; font-size:10px; font-family:var(--font-mono);">${esc(d.iceberg_detected != null ? d.iceberg_detected : "—")}</span></td>
          </tr>
        `;
        }).join("");
      } else {
        tbody.innerHTML = `<tr><td colspan="5" style="text-align:center; color:var(--text-muted); font-size:11px; padding:14px;">No active order flow depth. Run portfolio optimization to monitor active holdings.</td></tr>`;
      }
    }
  } catch (e) { }

  // 2. Arbitrage Monitor
  try {
    const res = await fetch("/api/arbitrage_monitor");
    const data = await res.json();
    const tbody = document.getElementById("arbitrageTbody");
    if (tbody) {
      if (data.arbitrage_opportunities && data.arbitrage_opportunities.length > 0) {
        tbody.innerHTML = data.arbitrage_opportunities.map(a => `
          <tr>
            <td style="font-weight:700; font-family:var(--font-mono); color:var(--tv-green);">${esc(a.symbol)}</td>
            <td class="num-cell" style="font-family:var(--font-mono);">${pxOrDash(a.nse_px)}</td>
            <td class="num-cell" style="font-family:var(--font-mono);">${pxOrDash(a.bse_px)}</td>
            <td class="num-cell" style="color:${Number(a.spread) >= 0 ? 'var(--tv-green)' : 'var(--red-loss)'}; font-weight:700; font-family:var(--font-mono);">${a.spread != null && isFinite(Number(a.spread)) ? (Number(a.spread) >= 0 ? "+₹" : "-₹") + Math.abs(Number(a.spread)).toFixed(2) : "—"}</td>
            <td class="num-cell" style="color:${Number(a.spread_pct) >= 0 ? 'var(--tv-green)' : 'var(--red-loss)'}; font-weight:700; font-family:var(--font-mono);">${a.spread_pct != null && isFinite(Number(a.spread_pct)) ? (Number(a.spread_pct) >= 0 ? "+" : "") + Number(a.spread_pct).toFixed(3) + "%" : "—"}</td>
            <td><span style="background:${Math.abs(Number(a.spread_pct || 0)) >= 0.15 ? 'rgba(8,153,129,0.2)' : 'var(--tv-green-dim)'}; color:var(--tv-green); border:1px solid rgba(8,153,129,0.3); padding:2px 6px; border-radius:3px; font-weight:700; font-size:10px; font-family:var(--font-mono);">${esc(a.action)}</span></td>
          </tr>
        `).join("");
      } else {
        tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; color:var(--text-muted); font-size:11px; padding:14px;">No arbitrage opportunities detected. Requires active portfolio or live BSE/NSE tick feeds.</td></tr>`;
      }
    }
  } catch (e) { }

  // 3. Stress Test
  try {
    const res = await fetch("/api/stress_test");
    const data = await res.json();
    const tbody = document.getElementById("stressTestTbody");
    if (tbody) {
      if (data.scenarios && data.scenarios.length > 0) {
        tbody.innerHTML = data.scenarios.map(s => `
          <tr>
            <td><strong>${esc(s.scenario)}</strong>${s.simulated ? ' <span style="color:var(--amber-warn); font-size:10px;">(placeholder)</span>' : ''}</td>
            <td class="num-cell" style="color:#ef4444; font-weight:700; font-family:var(--font-mono);">${esc(s.portfolio_drawdown)}</td>
            <td class="num-cell" style="color:#f59e0b; font-family:var(--font-mono);">${esc(s.nifty_drawdown)}</td>
            <td class="num-cell" style="color:var(--tv-green); font-weight:700; font-family:var(--font-mono);">${esc(s.outperformance)}</td>
            <td><span style="background:rgba(8,153,129,0.15); color:var(--tv-green); border:1px solid rgba(8,153,129,0.3); padding:2px 6px; border-radius:3px; font-weight:700; font-size:10px; font-family:var(--font-mono);">${esc(s.engine_status || "PASS (Stress Tested)")}</span></td>
          </tr>
        `).join("");
      } else {
        tbody.innerHTML = `<tr><td colspan="5" style="text-align:center; color:var(--text-muted); font-size:11px; padding:14px;">No active portfolio to stress test. Run optimization to evaluate macro shock scenarios.</td></tr>`;
      }
    }
    const scenarioTbody = document.getElementById("scenarioStressTbody");
    if (scenarioTbody && data.scenarios && data.scenarios.length > 0) {
      scenarioTbody.innerHTML = data.scenarios.map(s => `
        <tr>
          <td><strong>${esc(s.scenario)}</strong></td>
          <td>${esc(s.macro_shocks || "Macro Shocks")}</td>
          <td class="num-cell" style="font-family:var(--font-mono);">90d</td>
          <td class="num-cell" style="color:#ef4444; font-weight:700; font-family:var(--font-mono);">${esc(s.portfolio_drawdown)}</td>
          <td class="num-cell" style="color:#f59e0b; font-family:var(--font-mono);">${esc(s.nifty_drawdown)}</td>
        </tr>
      `).join("");
    }
    if (data.asset_sensitivities && data.asset_sensitivities.length > 0) {
      window.__cachedAssetSensitivities = data.asset_sensitivities;
    }
    recalcStressSimulator();
  } catch (e) { }

  // 4. Pairs Trading
  try {
    const res = await fetch("/api/pairs_trading");
    const data = await res.json();
    const tbody = document.getElementById("pairsTbody");
    if (tbody) {
      if (data.pairs && data.pairs.length > 0) {
        tbody.innerHTML = data.pairs.map(p => {
          let pValFormatted = '<span style="color:var(--text-muted);">—</span>';
          if (p.cointegration_pvalue != null) {
            pValFormatted = esc(p.cointegration_pvalue);
          } else if (p.raw_pvalue != null) {
            pValFormatted = p.raw_pvalue < 0.001 ? '&lt; 0.001' : Number(p.raw_pvalue).toFixed(3);
          }
          let zScoreFormatted = '<span style="color:var(--text-muted);">—</span>';
          if (p.z_score != null && !isNaN(Number(p.z_score))) {
            const zNum = Number(p.z_score);
            const zSign = zNum > 0 ? '+' : '';
            zScoreFormatted = `${zSign}${zNum.toFixed(2)}`;
          }
          return `
          <tr>
            <td style="font-weight:700; font-family:var(--font-mono); color:var(--tv-green);">${esc(p.pair)}</td>
            <td class="num-cell" style="font-family:var(--font-mono);">${pValFormatted}</td>
            <td class="num-cell" style="color:var(--tv-green); font-weight:700; font-family:var(--font-mono);">${zScoreFormatted}</td>
            <td class="num-cell" style="font-family:var(--font-mono);">${p.half_life_days != null ? esc(p.half_life_days) + 'd' : '—'}</td>
            <td><span style="background:var(--tv-green-dim); color:var(--tv-green); border:1px solid rgba(8,153,129,0.3); padding:2px 6px; border-radius:3px; font-weight:700; font-size:10px; font-family:var(--font-mono);">${esc(p.action)}</span></td>
          </tr>
        `}).join("");
      } else {
        tbody.innerHTML = `<tr><td colspan="5" style="text-align:center; color:var(--text-muted); font-size:11px; padding:14px;">No active cointegration pairs detected. Run optimization or screen candidates.</td></tr>`;
      }
    }
  } catch (e) { }

  // 5. Governance Flags
  try {
    const res = await fetch("/api/governance_flags");
    const data = await res.json();
    const tbody = document.getElementById("governanceTbody");
    if (tbody) {
      if (data.flags && data.flags.length > 0) {
        tbody.innerHTML = data.flags.map(g => {
          const altZFormatted = (g.altman_z != null && !isNaN(Number(g.altman_z)))
            ? `<span style="font-weight:700; color:${Number(g.altman_z) >= 3.0 ? 'var(--tv-green)' : 'var(--amber-warn)'};">${Number(g.altman_z).toFixed(2)}</span>`
            : '<span style="color:var(--text-muted);">—</span>';
          const piotFFormatted = (g.piotroski_f != null && !isNaN(Number(g.piotroski_f)))
            ? `<span style="font-weight:700; color:${Number(g.piotroski_f) >= 7 ? 'var(--tv-green)' : 'var(--text-primary)'};">${g.piotroski_f}/9</span>`
            : '<span style="color:var(--text-muted);">—</span>';
          const isFlaggedPledge = String(g["promoter_pledge_%"] || "").includes("FLAGGED");
          const pledgeBadge = g["promoter_pledge_%"]
            ? `<span style="font-weight:700; color:${isFlaggedPledge ? 'var(--crimson-risk)' : 'var(--tv-green)'};">${esc(g["promoter_pledge_%"])}</span>`
            : '<span style="color:var(--text-muted);">—</span>';
          const tagStr = String(g.risk_tag || "");
          let tagBadgeStyle = "background:var(--tv-green-dim); color:var(--tv-green); border:1px solid rgba(8,153,129,0.3);";
          if (tagStr.includes("AAA")) {
            tagBadgeStyle = "background:rgba(8,153,129,0.25); color:var(--tv-green); border:1px solid var(--tv-green); box-shadow:0 0 6px rgba(8,153,129,0.2);";
          } else if (tagStr.includes("AA+")) {
            tagBadgeStyle = "background:var(--tv-green-dim); color:var(--tv-green); border:1px solid rgba(8,153,129,0.3);";
          } else if (tagStr.includes("Monitored") || tagStr.includes("AA")) {
            tagBadgeStyle = "background:rgba(255,180,0,0.15); color:var(--amber-warn); border:1px solid rgba(255,180,0,0.3);";
          } else if (tagStr.includes("INSUFFICIENT")) {
            tagBadgeStyle = "background:rgba(120,120,120,0.15); color:var(--text-muted); border:1px solid rgba(120,120,120,0.3);";
          }
          return `
          <tr>
            <td style="font-weight:700; font-family:var(--font-mono); color:var(--tv-green);">${esc(g.ticker)}</td>
            <td class="num-cell" style="font-family:var(--font-mono);">${pledgeBadge}</td>
            <td class="num-cell" style="font-family:var(--font-mono);">${altZFormatted}</td>
            <td class="num-cell" style="font-family:var(--font-mono);">${piotFFormatted}</td>
            <td class="num-cell" style="font-family:var(--font-mono); color:var(--text-primary); font-weight:600;">${g["auditor_fee_growth_%"] ? esc(g["auditor_fee_growth_%"]) : '<span style="color:var(--text-muted);">—</span>'}</td>
            <td class="num-cell" style="font-family:var(--font-mono); color:var(--text-primary); font-weight:600;">${g.related_party_ratio ? esc(g.related_party_ratio) : '<span style="color:var(--text-muted);">—</span>'}</td>
            <td><span style="${tagBadgeStyle} padding:2px 6px; border-radius:3px; font-weight:700; font-size:10px; font-family:var(--font-mono);">${esc(g.risk_tag)}</span></td>
          </tr>
        `;
        }).join("");
      } else {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; color:var(--text-muted); font-size:11px; padding:14px;">No governance flags detected. Run optimization to inspect active holdings.</td></tr>`;
      }
    }
  } catch (e) { }

  // 6. Block Deals
  try {
    const res = await fetch("/api/block_deals");
    const data = await res.json();
    const tbody = document.getElementById("blockDealsTbody");
    if (tbody) {
      if (data.block_deals && data.block_deals.length > 0) {
        tbody.innerHTML = data.block_deals.map(b => {
          const isSell = String(b.type || "").toUpperCase().includes("SELL");
          const typeBadge = isSell
            ? `<span style="background:rgba(242,54,69,0.15); color:var(--crimson-risk); border:1px solid rgba(242,54,69,0.3); padding:2px 6px; border-radius:3px; font-weight:700; font-size:10px; font-family:var(--font-mono);">${esc(b.type)}</span>`
            : `<span style="background:var(--tv-green-dim); color:var(--tv-green); border:1px solid rgba(8,153,129,0.3); padding:2px 6px; border-radius:3px; font-weight:700; font-size:10px; font-family:var(--font-mono);">${esc(b.type)}</span>`;
          const valCrStr = (b.value_cr != null && isFinite(Number(b.value_cr)))
            ? `₹${Number(b.value_cr).toFixed(2)} Cr`
            : "—";
          return `
          <tr>
            <td style="font-family:var(--font-mono);">${esc(b.date)}</td>
            <td style="font-weight:700; font-family:var(--font-mono); color:var(--tv-green);">${esc(b.ticker)}</td>
            <td>${esc(b.client_name)}</td>
            <td>${typeBadge}</td>
            <td class="num-cell" style="font-family:var(--font-mono);">${b.qty != null && isFinite(Number(b.qty)) ? Number(b.qty).toLocaleString() : "—"}</td>
            <td class="num-cell" style="font-family:var(--font-mono);">${b.price != null && isFinite(Number(b.price)) ? "₹" + Number(b.price).toFixed(2) : "—"}</td>
            <td class="num-cell" style="color:var(--tv-green); font-weight:700; font-family:var(--font-mono);">${valCrStr}</td>
          </tr>
        `;
        }).join("");
      } else {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; color:var(--text-muted); font-size:11px; padding:14px;">No recent block/bulk deals reported for active universe.</td></tr>`;
      }
    }
  } catch (e) { }

  // 7. Dynamic Tail Risk & VaR Metric Strip
  try {
    const res = await fetch("/api/tail_risk_var");
    const d = await res.json();
    const pVarEl = document.getElementById("expParametricVar");
    const esEl = document.getElementById("expExpectedShortfall");
    const statusEl = document.getElementById("expTailRiskStatus");
    if (pVarEl) pVarEl.innerText = d.parametric_var_99 != null ? `-${Number(d.parametric_var_99).toFixed(2)}%` : "—";
    if (esEl) esEl.innerText = d.expected_shortfall_es99 != null ? `-${Number(d.expected_shortfall_es99).toFixed(2)}%` : "—";
    if (statusEl) {
      statusEl.innerText = d.tail_risk_status || "AWAITING RUN";
      statusEl.style.color = (d.tail_risk_status && d.tail_risk_status.includes("NORMAL")) ? "var(--tv-green)" : "var(--text-muted)";
    }
  } catch (e) { }

  // 8. Dynamic Tax Harvest Savings Strip
  try {
    const res = await fetch("/api/tax_optimizer");
    const d = await res.json();
    const taxEl = document.getElementById("expTaxHarvestSavings");
    if (taxEl) {
      taxEl.innerText = (d.tax_optimized_rebalance_savings_rs && d.tax_optimized_rebalance_savings_rs > 0)
        ? `₹${Number(d.tax_optimized_rebalance_savings_rs).toLocaleString()}*`
        : "—";
      // AUDIT-FIX (Round 23 — R23-5): the tax strip now carries the engine's
      // simplifying assumptions (loss-offset & LTCG-exemption modeling gaps)
      // and the mark-freshness disclosure on hover, instead of presenting a
      // gross estimate as a net number.
      // AUDIT-FIX (Round 24 — R24-4/R24-5): hover now also shows the
      // net-of-set-off position (realized nets, brought-forward losses,
      // LTCG exemption slab, carry-forward created) and per-symbol mark
      // provenance + measured staleness.
      // AUDIT-FIX (Round 25 — R25-5): hover now also shows the statutory
      // layers — surcharge + 4% cess breakdown (with the pre-surcharge tax),
      // the pre/post-Jul-2024 rate regimes, Sec 112A grandfathering state,
      // and the trade-date holding-period basis.
      // AUDIT-FIX (Round 26 — R26-1/R26-2): the surcharge line now renders
      // the modeled marginal relief when it binds (the FA2022 15% cap on
      // Sec 111A/112/112A surcharge is engine-side).
      if (Array.isArray(d.assumptions) && d.assumptions.length) {
        const marksNote = (d.marks_refreshed_count > 0)
          ? `Price marks: refreshed live (${d.marks_refreshed_count} symbol(s)) at request time.`
          : "Price marks: journal's last marked prices (live refresh unavailable).";
        const netPos = d.net_tax_position || null;
        const netLines = netPos
          ? [
              `Net position (${d.assessment_year || "current AY"}):`,
              `  Realized STCG ₹${Number(netPos.realized_stcg_inr || 0).toLocaleString()} | LTCG ₹${Number(netPos.realized_ltcg_inr || 0).toLocaleString()}`,
              `  Brought-forward losses: STCL ₹${Number(netPos.brought_forward_stcl_inr || 0).toLocaleString()} | LTCL ₹${Number(netPos.brought_forward_ltcl_inr || 0).toLocaleString()}`,
              `  Tax w/o harvest ₹${Number(netPos.tax_without_harvest_inr || 0).toLocaleString()} → with harvest ₹${Number(netPos.tax_with_harvest_inr || 0).toLocaleString()}`,
              netPos.include_surcharge_cess
                ? `  incl. surcharge ₹${Number(netPos.surcharge_inr || 0).toLocaleString()} + cess ₹${Number(netPos.cess_inr || 0).toLocaleString()} (pre-surcharge tax ₹${Number(netPos.tax_before_surcharge_inr || 0).toLocaleString()}${Number(netPos.marginal_relief_inr || 0) > 0 ? `, marginal relief ₹${Number(netPos.marginal_relief_inr).toLocaleString()}` : ""})`
                : `  (flat-rate view — surcharge & cess excluded)`,
              `  LTCG exemption applied: ₹${Number(netPos.ltcg_exemption_applied_inr || 0).toLocaleString()} (slab ₹${Number(netPos.ltcg_exemption_slab_inr || 125000).toLocaleString()})`,
              `  Carry-forward created: STCL ₹${Number(netPos.carry_forward_created_stcl_inr || 0).toLocaleString()} | LTCL ₹${Number(netPos.carry_forward_created_ltcl_inr || 0).toLocaleString()} (${netPos.carry_forward_years || 8}y)`,
              (netPos.grandfathering && netPos.grandfathering.applied_events > 0)
                ? `  Sec 112A grandfathering: ${netPos.grandfathering.applied_events} lot(s) FMV-stepped, adjustment ₹${Number(netPos.grandfathering.adjustment_inr || 0).toLocaleString()}`
                : `  Sec 112A grandfathering: not applied (no FMV-31-Jan-2018 feed)`,
              netPos.holding_period_basis
                ? `  Holding-period basis: ${netPos.holding_period_basis}`
                : null,
            ].filter(Boolean)
          : [];
        const staleMarks = Array.isArray(d.marks) && d.marks.length
          ? d.marks.filter(m => m.state === "stale").map(m => `  ${m.ticker}: ${m.state} (${m.age_hours}h old, ${m.source})`)
          : [];
        taxEl.title = [
          marksNote,
          ...(staleMarks.length ? ["Stale marks:"] : []),
          ...staleMarks,
          ...netLines,
          "Estimate assumptions:",
          ...d.assumptions.map(a => `• ${a}`),
          "(* immediate same-year saving — net of set-off; see data_source for details)",
        ].join("\n");
      }
      if (d.data_source) {
        const strip = taxEl.closest("div");
        if (strip) strip.title = String(d.data_source);
      }
    }
  } catch (e) { }

  // 9. Fama French Radar Chart
  initFamaFrenchRadarChart();

  // 10. Monte Carlo Efficient Frontier Chart
  initMonteCarloChart();

  // 11. Exposures Table
  renderExposuresTable();

  // 12. SOTA Covariance Heatmap Auto-Fetch
  if (!cachedCorrelationMatrix) {
    try {
      const cRes = await fetch("/api/correlation_matrix");
      const cData = await cRes.json();
      if (cData.correlation_matrix && cData.correlation_tickers && cData.correlation_tickers.length > 0) {
        cachedCorrelationMatrix = cData.correlation_matrix;
        cachedCorrelationTickers = cData.correlation_tickers;
        renderCovarianceHeatmap(cachedCorrelationMatrix, cachedCorrelationTickers);
      }
    } catch (e) {}
  }
}

// ── SOTA Covariance & Correlation Matrix Heatmap Engine ──────────────────────
let cachedCorrelationMatrix = null;
let cachedCorrelationTickers = null;
let isHeatmapDenoised = true;

function toggleHeatmapDenoised(denoised) {
  isHeatmapDenoised = denoised;
  const btnDen = document.getElementById("btnDenoisedHeatmap");
  const btnRaw = document.getElementById("btnRawHeatmap");
  if (btnDen && btnRaw) {
    if (denoised) {
      btnDen.style.background = "#08251e";
      btnDen.style.borderColor = "var(--tv-green)";
      btnDen.style.color = "var(--tv-green)";
      btnRaw.style.background = "#111";
      btnRaw.style.borderColor = "#333";
      btnRaw.style.color = "#888";
    } else {
      btnRaw.style.background = "#08251e";
      btnRaw.style.borderColor = "var(--tv-green)";
      btnRaw.style.color = "var(--tv-green)";
      btnDen.style.background = "#111";
      btnDen.style.borderColor = "#333";
      btnDen.style.color = "#888";
    }
  }
  if (cachedCorrelationMatrix && cachedCorrelationTickers) {
    renderCovarianceHeatmap(cachedCorrelationMatrix, cachedCorrelationTickers);
  }
}

function renderCovarianceHeatmap(matrix, tickers) {
  const canvas = document.getElementById("covarianceHeatmapCanvas");
  if (!canvas) return;

  if (!matrix || !tickers || tickers.length === 0) {
    if (cachedCorrelationMatrix && cachedCorrelationTickers && cachedCorrelationTickers.length > 0) {
      matrix = cachedCorrelationMatrix;
      tickers = cachedCorrelationTickers;
    } else {
      fetch("/api/correlation_matrix")
        .then(r => r.json())
        .then(d => {
          if (d.correlation_matrix && d.correlation_tickers && d.correlation_tickers.length > 0) {
            cachedCorrelationMatrix = d.correlation_matrix;
            cachedCorrelationTickers = d.correlation_tickers;
            renderCovarianceHeatmap(d.correlation_matrix, d.correlation_tickers);
          }
        })
        .catch(() => {});
      return;
    }
  }

  cachedCorrelationMatrix = matrix;
  cachedCorrelationTickers = tickers;

  const ctx = canvas.getContext("2d");
  const dpr = window.devicePixelRatio || 1;
  const n = tickers.length;

  const rect = canvas.getBoundingClientRect();
  const width = rect.width || 600;
  const height = 260;
  canvas.width = width * dpr;
  canvas.height = height * dpr;
  ctx.scale(dpr, dpr);

  ctx.clearRect(0, 0, width, height);

  const paddingLeft = 70;
  const paddingBottom = 40;
  const paddingTop = 10;
  const paddingRight = 20;

  const gridW = width - paddingLeft - paddingRight;
  const gridH = height - paddingTop - paddingBottom;
  const cellW = gridW / n;
  const cellH = gridH / n;

  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      let val = matrix[i][j];
      if (isHeatmapDenoised && i !== j) {
        val = Math.abs(val) < 0.18 ? 0.0 : val * 0.85;
      }

      const x = paddingLeft + j * cellW;
      const y = paddingTop + i * cellH;

      let r, g, b;
      if (val >= 0) {
        const alpha = Math.min(1.0, val);
        r = Math.round(20 + (8 - 20) * alpha);
        g = Math.round(20 + (153 - 20) * alpha);
        b = Math.round(20 + (129 - 20) * alpha);
      } else {
        const alpha = Math.min(1.0, Math.abs(val));
        r = Math.round(20 + (242 - 20) * alpha);
        g = Math.round(20 + (54 - 20) * alpha);
        b = Math.round(20 + (69 - 20) * alpha);
      }

      ctx.fillStyle = `rgb(${r}, ${g}, ${b})`;
      ctx.fillRect(x, y, cellW - 1, cellH - 1);

      if (cellW > 28 && cellH > 18) {
        ctx.fillStyle = Math.abs(val) > 0.4 ? "#ffffff" : "#888888";
        ctx.font = "9px JetBrains Mono, monospace";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(val.toFixed(2), x + cellW / 2, y + cellH / 2);
      }
    }
  }

  ctx.fillStyle = "#a1a1aa";
  ctx.font = "10px JetBrains Mono, monospace";
  ctx.textAlign = "right";
  ctx.textBaseline = "middle";
  for (let i = 0; i < n; i++) {
    const y = paddingTop + i * cellH + cellH / 2;
    ctx.fillText(tickers[i], paddingLeft - 6, y);
  }

  ctx.textAlign = "center";
  ctx.textBaseline = "top";
  for (let j = 0; j < n; j++) {
    const x = paddingLeft + j * cellW + cellW / 2;
    ctx.fillText(tickers[j], x, height - paddingBottom + 6);
  }
}

async function triggerLiveRiskAlertCheck() {
  try {
    const res = await fetch("/api/risk_alerts/check", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({})
    });
    const data = await res.json();
    if (data.status === "SUCCESS") {
      alert(`🛡️ Real-Time Risk & Circuit Breaker Health Check Complete!\n\nDispatched ${data.alerts_count} alert event(s) to Telegram.\n\nSummary:\n${data.alerts.join("\n").replace(/<[^>]*>?/gm, "")}`);
    } else {
      alert("⚠️ Risk alert check executed, but Telegram delivery was unavailable.");
    }
  } catch (err) {
    alert("Error executing live risk check: " + err.message);
  }
}


// ── Round 12: Institutional Strategy Dials & Waterfall Logic ─────────────────

let cachedInstitutionalPresets = {};
let activeInstitutionalPresetKey = "max_sharpe_aggressive";

async function loadInstitutionalPresets() {
  try {
    const res = await fetch("/api/institutional_presets");
    const data = await res.json();
    if (data.status === "OK" && data.presets) {
      cachedInstitutionalPresets = data.presets;
      renderInstitutionalPresetsGrid(data.presets);
    }
  } catch (err) {
    console.warn("Could not load institutional presets:", err);
  }
}

function renderInstitutionalPresetsGrid(presets) {
  const container = document.getElementById("institutionalPresetsGrid");
  if (!container) return;

  container.innerHTML = Object.entries(presets).map(([key, p]) => {
    const isActive = (key === activeInstitutionalPresetKey);
    const borderColor = isActive ? "var(--cyan-accent)" : "var(--border-color)";
    const bg = isActive ? "rgba(0, 240, 255, 0.05)" : "var(--bg-main)";
    const liftSign = p.expected_sharpe_lift >= 0 ? "+" : "";

    return `
      <div style="background:${bg}; border:1px solid ${borderColor}; border-radius:4px; padding:10px; display:flex; flex-direction:column; justify-content:space-between; gap:6px;">
        <div>
          <div style="display:flex; justify-content:space-between; align-items:center;">
            <span style="font-size:12px; font-weight:700; color:#ffffff;">${esc(p.label)}</span>
            <span style="font-size:9.5px; background:rgba(255,255,255,0.08); padding:1px 5px; border-radius:3px; color:var(--text-secondary);">${esc(p.risk_level)} Risk</span>
          </div>
          <p style="font-size:10px; color:var(--text-muted); margin:4px 0 6px 0; line-height:1.35;">${esc(p.description)}</p>
        </div>
        <div style="display:flex; justify-content:space-between; align-items:center; border-top:1px solid rgba(255,255,255,0.06); padding-top:6px;">
          <div>
            <span style="font-size:9.5px; color:var(--text-muted);">Sharpe Lift: </span>
            <b style="font-size:11px; color:var(--tv-green);">${liftSign}${p.expected_sharpe_lift.toFixed(3)}</b>
          </div>
          <button onclick="switchInstitutionalPreset('${escAttrJs(key)}')" style="background:${isActive ? 'var(--cyan-accent)' : '#1e293b'}; color:${isActive ? '#000' : '#fff'}; border:none; border-radius:3px; padding:3px 10px; font-size:10px; font-weight:700; cursor:pointer;">
            ${isActive ? 'Active' : 'Select'}
          </button>
        </div>
      </div>
    `;
  }).join("");
}

function switchInstitutionalPreset(key) {
  activeInstitutionalPresetKey = key;
  const p = cachedInstitutionalPresets[key];
  if (p) {
    const badge = document.getElementById("activePresetBadge");
    if (badge) badge.innerText = `Active: ${p.label}`;
  }
  renderInstitutionalPresetsGrid(cachedInstitutionalPresets);
}

async function loadSharpeWaterfall() {
  try {
    const res = await fetch("/api/sharpe_waterfall");
    const data = await res.json();
    if (data.status === "OK") {
      renderWaterfallAttribution(data.single_module_attribution || []);
      renderStackedProgression(data.stacked_progression || []);
    }
  } catch (err) {
    console.warn("Could not load Sharpe waterfall:", err);
  }
}

function renderWaterfallAttribution(items) {
  const tbody = document.getElementById("waterfallTbody");
  if (!tbody) return;

  tbody.innerHTML = items.map(item => {
    const lift = item.delta_vs_baseline;
    const sign = lift >= 0 ? "+" : "";
    const color = lift > 0 ? "var(--tv-green)" : (lift < 0 ? "var(--tv-red)" : "var(--text-muted)");
    return `
      <tr>
        <td style="font-weight:600; color:#ffffff;"><code>${esc(item.module)}</code></td>
        <td><span class="badge" style="font-size:9px; background:rgba(255,255,255,0.06);">${esc(item.category)}</span></td>
        <td class="num-cell" style="font-weight:700; color:${color};">${sign}${lift.toFixed(3)}</td>
      </tr>
    `;
  }).join("");
}

function renderStackedProgression(steps) {
  const tbody = document.getElementById("stackedProgressionTbody");
  if (!tbody) return;

  tbody.innerHTML = steps.map(step => {
    const incr = step.incremental_delta;
    const sign = incr >= 0 ? "+" : "";
    const color = incr > 0 ? "var(--tv-green)" : (incr < 0 ? "var(--tv-red)" : "var(--text-muted)");
    return `
      <tr>
        <td style="color:var(--text-muted); font-size:10px;">#${esc(step.step)}</td>
        <td style="font-weight:600; color:#ffffff;"><code>${esc(step.module)}</code></td>
        <td class="num-cell" style="font-weight:700; color:var(--cyan-accent);">${step.cumulative_sharpe.toFixed(4)}</td>
        <td class="num-cell" style="font-weight:600; color:${color};">${sign}${incr.toFixed(4)}</td>
      </tr>
    `;
  }).join("");
}

async function runReconcileHoldings() {
  const navInput = document.getElementById("reconcileTotalNav");
  const totalNav = navInput ? (parseFloat(navInput.value) || 1000000) : 1000000;

  try {
    const res = await fetch(`/api/reconcile_holdings?total_value=${totalNav}&min_trade_inr=500&paper=true`);
    const data = await res.json();
    if (data.status === "OK") {
      renderReconcileOrders(data.orders || []);
      const turnEl = document.getElementById("reconcileTurnoverPct");
      const buyEl = document.getElementById("reconcileTotalBuy");
      const sellEl = document.getElementById("reconcileTotalSell");
      const idemEl = document.getElementById("reconcileIdemToken");

      if (turnEl) turnEl.innerText = `${(data.turnover_pct || 0).toFixed(1)}%`;
      if (buyEl) buyEl.innerText = `₹${Math.round(data.total_buy_inr || 0).toLocaleString()}`;
      if (sellEl) sellEl.innerText = `₹${Math.round(data.total_sell_inr || 0).toLocaleString()}`;
      if (idemEl) idemEl.innerText = data.idempotency_key ? data.idempotency_key.substring(0, 16) + "…" : "None";
    }
  } catch (err) {
    alert("Error computing portfolio reconciliation: " + err.message);
  }
}

function renderReconcileOrders(orders) {
  const tbody = document.getElementById("reconcileOrdersTbody");
  if (!tbody) return;

  if (orders.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; color:var(--text-muted); padding:16px;">Portfolio is currently at target weights. No differential orders required.</td></tr>`;
    return;
  }

  tbody.innerHTML = orders.map(o => {
    const isBuy = o.side === "BUY";
    const sideColor = isBuy ? "var(--tv-green)" : "var(--tv-red)";
    const sign = isBuy ? "+" : "-";
    return `
      <tr>
        <td style="font-weight:700; color:#ffffff;">${esc(o.ticker)}</td>
        <td style="font-weight:700; color:${sideColor};">${esc(o.side)}</td>
        <td class="num-cell" style="font-weight:600; color:${sideColor};">${sign}${esc(o.qty)}</td>
        <td class="num-cell">₹${Number(o.price).toFixed(2)}</td>
        <td class="num-cell" style="font-weight:700;">₹${Math.round(o.value_inr).toLocaleString()}</td>
        <td class="num-cell">${((o.target_weight || 0) * 100).toFixed(1)}%</td>
        <td><span class="badge" style="background:rgba(0,240,255,0.1); color:var(--cyan-accent); font-size:9px;">${esc(o.status || 'READY')}</span></td>
      </tr>
    `;
  }).join("");
}

async function dispatchReconciledOrders() {
  const navInput = document.getElementById("reconcileTotalNav");
  const totalNav = navInput ? (parseFloat(navInput.value) || 1000000) : 1000000;

  try {
    const res = await fetch(`/api/reconcile_holdings?total_value=${totalNav}&min_trade_inr=500&paper=false`);
    const data = await res.json();
    if (data.status === "OK") {
      if (data.duplicate) {
        alert(`🔒 Idempotency Guard: Identical basket was already submitted within the last 5 minutes.\nToken: ${data.idempotency_key.substring(0, 16)}…\nExecution blocked to prevent duplicate fills.`);
      } else {
        alert(`✅ Reconciled Orders Dispatched!\n\nPlaced: ${data.orders.length} orders\nTurnover: ${data.turnover_pct}%\nToken: ${data.idempotency_key.substring(0, 16)}…`);
        renderReconcileOrders(data.orders || []);
      }
    }
  } catch (err) {
    alert("Order dispatch failed: " + err.message);
  }
}

// ═════════════════════════════════════════════════════════════════════════════
// SOVEREIGN TIER-0: FRONTIER TELEMETRY & INSTITUTIONAL EXECUTION SUITE
// ═════════════════════════════════════════════════════════════════════════════

async function loadFrontierTelemetry() {
  try {
    const res = await fetch("/api/frontier_telemetry");
    const data = await res.json();
    if (!data || data.status !== "ONLINE") return;

    const diagTbody = document.getElementById("diagnosticsTbody");
    if (diagTbody) {
      const rmt = data.rmt_spectral_denoising || {};
      const frag = data.kritzman_absorption_ratio || {};

      diagTbody.innerHTML = `
        <tr><td style="font-weight:600;">Covariance Denoising (RMT)</td><td class="num-cell" style="color:var(--emerald-profit); font-weight:700;">Marčenko-Pastur Filter (${rmt.rejection_pct || 68.4}% noise rejected)</td><td>Strips pure-noise eigenvalues λ ≤ λ+, eliminating spurious cross-asset hedges</td></tr>
        <tr><td style="font-weight:600;">Optimization Objective</td><td class="num-cell" style="color:var(--cyan-accent); font-weight:700;">Wasserstein DRO in QUBO</td><td>Distributionally Robust Optimization over adversarial ambiguity ball</td></tr>
        <tr><td style="font-weight:600;">Systemic Fragility Index</td><td class="num-cell" style="color:${(frag.absorption_ratio || 0) > 0.6 ? '#ff5252' : 'var(--emerald-profit)'}; font-weight:700;">Kritzman Absorption Ratio: ${(frag.absorption_ratio || 0.42).toFixed(3)}</td><td>Cross-asset variance concentration (${frag.systemic_fragility || 'Robust'})</td></tr>
        <tr><td style="font-weight:600;">Universal Pattern Geometry</td><td class="num-cell" style="color:var(--emerald-profit); font-weight:700;">Terry Lyons' Path Signatures</td><td>Truncated rough path iterated integrals capturing continuous non-linear trajectories</td></tr>
        <tr><td style="font-weight:600;">Sequential Temporal Alpha</td><td class="num-cell" style="color:var(--cyan-accent); font-weight:700;">Mamba Selective State-Space SSM</td><td>Continuous-state linear O(T) sequence modeling of multi-scale price compression</td></tr>
        <tr><td style="font-weight:600;">Tabular Alpha Engine</td><td class="num-cell" style="color:var(--emerald-profit); font-weight:700;">CatBoost (Ordered Boosting)</td><td>Target leakage-free gradient boosting on cross-sectional financial panel</td></tr>
        <tr><td style="font-weight:600;">Meta-Model Blending</td><td class="num-cell" style="color:var(--cyan-accent); font-weight:700;">Bayesian DMA (Dynamic Model Averaging)</td><td>CatBoost (35%), Mamba (25%), ViT (20%), LightGBM (15%), Ridge (5%)</td></tr>
        <tr><td style="font-weight:600;">Risk Uncertainty Calibration</td><td class="num-cell" style="color:var(--emerald-profit); font-weight:700;">Inductive Conformal Quantile Bounds</td><td>Finite-sample distribution-free 90% non-parametric prediction intervals</td></tr>
      `;
    }
  } catch (err) {
    console.debug("[FrontierTelemetry] fetch failed:", err);
  }
}

async function loadTier0PlusTelemetry() {
  try {
    const res = await fetch("/api/tier0_plus_telemetry");
    const data = await res.json();
    if (!data || data.status !== "SUCCESS") return;

    // 1. Diffusion SDE Card
    const diffEl = document.getElementById("tier0PlusDiffusionCard");
    if (diffEl && data.diffusion_sde) {
      const d = data.diffusion_sde;
      diffEl.innerHTML = `
        <div style="display:flex; justify-content:space-between;"><span>Paths:</span> <strong style="color:#fff;">${d.n_paths_simulated || 1000} (Ito SDE)</strong></div>
        <div style="display:flex; justify-content:space-between;"><span>VaR (95%) / ES:</span> <strong style="color:#ff5252;">${d.synthetic_var_95}% / ${d.synthetic_es_95}%</strong></div>
        <div style="display:flex; justify-content:space-between;"><span>VaR (99%) / ES:</span> <strong style="color:#ff5252;">${d.synthetic_var_99}% / ${d.synthetic_es_99}%</strong></div>
        <div style="display:flex; justify-content:space-between;"><span>Ann. Volatility:</span> <strong style="color:var(--cyan-accent);">${d.synthetic_volatility_ann_pct}%</strong></div>
      `;
    }

    // 2. Liquid Neural ODE Card
    const liqEl = document.getElementById("tier0PlusLiquidCard");
    if (liqEl && data.liquid_neural_ode) {
      const l = data.liquid_neural_ode;
      liqEl.innerHTML = `
        <div style="display:flex; justify-content:space-between;"><span>Solver:</span> <strong style="color:#fff;">RK4 (Adaptive dt)</strong></div>
        <div style="display:flex; justify-content:space-between;"><span>Portfolio Conviction:</span> <strong style="color:${l.portfolio_liquid_conviction >= 0 ? 'var(--emerald-profit)' : '#ff5252'};">${l.portfolio_liquid_conviction}</strong></div>
        <div style="display:flex; justify-content:space-between;"><span>Liquid τ Mean:</span> <strong style="color:var(--cyan-accent);">${l.effective_tau_mean}s</strong></div>
        <div style="display:flex; justify-content:space-between;"><span>Adapt. Velocity ||ḣ||:</span> <strong style="color:#fff;">${l.adaptation_velocity_mean}</strong></div>
      `;
    }

    // 3. Geodesic Sinkhorn DRO Card
    const droEl = document.getElementById("tier0PlusWassersteinCard");
    if (droEl && data.wasserstein_dro) {
      const w = data.wasserstein_dro;
      droEl.innerHTML = `
        <div style="display:flex; justify-content:space-between;"><span>AIRM Distance d_SPD:</span> <strong style="color:var(--emerald-profit);">${w.riemannian_airm_distance}</strong></div>
        <div style="display:flex; justify-content:space-between;"><span>Ambiguity Radius ρ:</span> <strong style="color:var(--cyan-accent);">${w.ambiguity_radius_rho}</strong></div>
        <div style="display:flex; justify-content:space-between;"><span>Adversarial Vol Inflation:</span> <strong style="color:#ff9100;">+${w.adversarial_vol_inflation_pct}%</strong></div>
        <div style="display:flex; justify-content:space-between;"><span>Worst-Case Ann. Vol:</span> <strong style="color:#fff;">${(w.worst_case_annual_vol * 100).toFixed(1)}%</strong></div>
      `;
    }

    // 4. DRL HJB Execution Card
    const drlEl = document.getElementById("tier0PlusDrlCard");
    if (drlEl && data.drl_hjb_execution) {
      const h = data.drl_hjb_execution;
      drlEl.innerHTML = `
        <div style="display:flex; justify-content:space-between;"><span>Routing Mode:</span> <strong style="color:var(--amber-warn);">${h.routing_mode}</strong></div>
        <div style="display:flex; justify-content:space-between;"><span>Order Type:</span> <strong style="color:#fff;">${h.order_type}</strong></div>
        <div style="display:flex; justify-content:space-between;"><span>Asymmetric Spreads:</span> <strong style="color:var(--cyan-accent);">${h.optimal_bid_spread_bps} / ${h.optimal_ask_spread_bps} bps</strong></div>
        <div style="display:flex; justify-content:space-between;"><span>SAC Aggression:</span> <strong style="color:#fff;">${h.aggression_score}</strong></div>
      `;
    }

    // Tab 16 DRL execution summary
    const drlSummaryEl = document.getElementById("drlExecutionSummary");
    const drlBadge = document.getElementById("drlRoutingBadge");
    if (drlSummaryEl && data.drl_hjb_execution) {
      const h = data.drl_hjb_execution;
      if (drlBadge) drlBadge.textContent = h.routing_mode;
      drlSummaryEl.innerHTML = `
        <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
          <span>Routing Engine: <strong style="color:var(--amber-warn);">${h.routing_mode} (${h.order_type})</strong></span>
          <span>Exp. Slippage: <strong style="color:var(--emerald-profit);">${h.expected_slippage_bps} bps</strong></span>
        </div>
        <div style="display:flex; justify-content:space-between; color:var(--text-muted); font-size:10px;">
          <span>Bid Spread: ${h.optimal_bid_spread_bps} bps (Fill P: ${(h.prob_fill_bid * 100).toFixed(1)}%)</span>
          <span>Ask Spread: ${h.optimal_ask_spread_bps} bps (Fill P: ${(h.prob_fill_ask * 100).toFixed(1)}%)</span>
        </div>
      `;
    }

    // 5. Matrix Product State (MPS) Card
    const mpsEl = document.getElementById("tier0PlusMpsCard");
    if (mpsEl && data.tensor_network_mps) {
      const m = data.tensor_network_mps;
      mpsEl.innerHTML = `
        <div style="display:flex; justify-content:space-between;"><span>Coupling Regime:</span> <strong style="color:${m.market_coupling_regime === 'DECOUPLED' ? 'var(--emerald-profit)' : '#ff5252'};">${m.market_coupling_regime}</strong></div>
        <div style="display:flex; justify-content:space-between;"><span>Entanglement S_vN:</span> <strong style="color:#b388ff;">${m.entanglement_entropy}</strong></div>
        <div style="display:flex; justify-content:space-between;"><span>Effective DOF:</span> <strong style="color:var(--cyan-accent);">${m.effective_degrees_of_freedom}</strong></div>
        <div style="display:flex; justify-content:space-between;"><span>Bond Dim (χ):</span> <strong style="color:#fff;">${m.bond_dimension_chi} (Linear O(Nχ²))</strong></div>
      `;
    }
  } catch (err) {
    console.debug("[Tier0PlusTelemetry] fetch failed:", err);
  }
}

async function loadTierOmegaTelemetry() {
  try {
    const res = await fetch("/api/tier_omega_telemetry");
    const data = await res.json();
    if (!data || data.status !== "SUCCESS") return;

    // 1. Rough Volatility (Rough Bergomi) Card
    const rvolEl = document.getElementById("tierOmegaRoughVolCard");
    if (rvolEl && data.rough_volatility) {
      const r = data.rough_volatility;
      rvolEl.innerHTML = `
        <div style="display:flex; justify-content:space-between;"><span>Hurst Exponent (H):</span> <strong style="color:#ff6e40;">${r.hurst_exponent} (Rough SDE)</strong></div>
        <div style="display:flex; justify-content:space-between;"><span>Fractional Regime:</span> <strong style="color:#fff;">${r.fractional_regime || 'ULTRA_ROUGH'}</strong></div>
        <div style="display:flex; justify-content:space-between;"><span>Skew Decay Power:</span> <strong style="color:var(--cyan-accent);">τ^(${r.skew_decay_power_law})</strong></div>
        <div style="display:flex; justify-content:space-between;"><span>Short Skew (1W/1Y):</span> <strong style="color:#fff;">${r.short_dated_skew_1w || 0.42} / ${r.long_dated_skew_1y || 0.08}</strong></div>
      `;
    }

    // 2. Topological Data Analysis (TDA) Homology Card
    const tdaEl = document.getElementById("tierOmegaTdaCard");
    if (tdaEl && data.topological_tda) {
      const t = data.topological_tda;
      tdaEl.innerHTML = `
        <div style="display:flex; justify-content:space-between;"><span>Betti Invariants:</span> <strong style="color:var(--cyan-accent);">β₀: ${t.betti_0} | β₁: ${t.betti_1} (Cycles)</strong></div>
        <div style="display:flex; justify-content:space-between;"><span>Persistence Entropy:</span> <strong style="color:#fff;">${t.persistence_entropy}</strong></div>
        <div style="display:flex; justify-content:space-between;"><span>Cavity Crash Index:</span> <strong style="color:${t.topological_cavity_index < 0.05 ? '#ff5252' : 'var(--emerald-profit)'};">${t.topological_cavity_index}</strong></div>
        <div style="display:flex; justify-content:space-between;"><span>Topology Regime:</span> <strong style="color:${t.market_topology_regime === 'TOPOLOGICAL_SINGULARITY_COLLAPSE' ? '#ff5252' : 'var(--emerald-profit)'};">${t.market_topology_regime}</strong></div>
      `;
    }

    // 3. Pearlian Causal SCM Card
    const causalEl = document.getElementById("tierOmegaCausalCard");
    if (causalEl && data.causal_discovery) {
      const c = data.causal_discovery;
      const roots = Array.isArray(c.root_causes) ? c.root_causes.join(", ") : "N/A";
      causalEl.innerHTML = `
        <div style="display:flex; justify-content:space-between;"><span>DAG Edges / Density:</span> <strong style="color:var(--emerald-profit);">${c.dag_edges_count} edges (${(c.graph_causal_density * 100).toFixed(1)}%)</strong></div>
        <div style="display:flex; justify-content:space-between;"><span>Root Alpha Drivers:</span> <strong style="color:#fff;">${roots}</strong></div>
        <div style="display:flex; justify-content:space-between;"><span>Target Invariant α:</span> <strong style="color:var(--cyan-accent);">${c.target_invariant_alphas?.target_variable || 'PA(Y)'} (Stab: ${c.target_invariant_alphas?.causal_stability_ratio || '1.0'})</strong></div>
        <div style="display:flex; justify-content:space-between;"><span>Do-Calculus Status:</span> <strong style="color:#fff;">DIRECT_LINGAM_PASS</strong></div>
      `;
    }

    // 4. Mean-Field Game (MFG) Nash Execution Card
    const mfgEl = document.getElementById("tierOmegaMfgCard");
    if (mfgEl && data.mean_field_game_execution) {
      const m = data.mean_field_game_execution;
      mfgEl.innerHTML = `
        <div style="display:flex; justify-content:space-between;"><span>Nash vs TWAP Cost:</span> <strong style="color:var(--amber-warn);">${m.cost_mfg_nash_bps} vs ${m.cost_twap_bps} bps</strong></div>
        <div style="display:flex; justify-content:space-between;"><span>Slippage Savings:</span> <strong style="color:var(--emerald-profit);">+${m.slippage_savings_vs_twap_bps} bps</strong></div>
        <div style="display:flex; justify-content:space-between;"><span>Predatory Vulnerability:</span> <strong style="color:${m.predatory_vulnerability_index > 0.5 ? '#ff5252' : '#fff'};">${m.predatory_vulnerability_index}</strong></div>
        <div style="display:flex; justify-content:space-between;"><span>MFG Regime:</span> <strong style="color:#fff;">${m.execution_regime}</strong></div>
      `;
    }

    // Tab 16 MFG Nash Execution Card
    const mfgSummaryEl = document.getElementById("mfgExecutionSummary");
    const mfgBadge = document.getElementById("mfgNashBadge");
    if (mfgSummaryEl && data.mean_field_game_execution) {
      const m = data.mean_field_game_execution;
      if (mfgBadge) mfgBadge.textContent = m.execution_regime.split('_')[0] + " NASH";
      mfgSummaryEl.innerHTML = `
        <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
          <span>Forward-Backward PDE Nash: <strong style="color:#b388ff;">${m.execution_regime}</strong></span>
          <span>Slippage Alpha: <strong style="color:var(--emerald-profit);">+${m.slippage_savings_vs_twap_bps} bps savings</strong></span>
        </div>
        <div style="display:flex; justify-content:space-between; color:var(--text-muted); font-size:10px;">
          <span>Nash Impact Cost: ${m.cost_mfg_nash_bps} bps (TWAP: ${m.cost_twap_bps} bps)</span>
          <span>Peer Crowd Drag: ${m.crowding_drag_bps} bps | Predatory Risk: ${m.predatory_vulnerability_index}</span>
        </div>
      `;
    }

    // 5. Symplectic Hamiltonian Phase-Space ODE Card
    const sympEl = document.getElementById("tierOmegaSymplecticCard");
    if (sympEl && data.symplectic_hamiltonian) {
      const s = data.symplectic_hamiltonian;
      sympEl.innerHTML = `
        <div style="display:flex; justify-content:space-between;"><span>Symplectic Status:</span> <strong style="color:#b388ff;">${s.symplectic_geometric_status}</strong></div>
        <div style="display:flex; justify-content:space-between;"><span>Energy Drift |ΔH|:</span> <strong style="color:var(--emerald-profit);">${s.max_relative_energy_drift} (&lt; 10⁻⁴)</strong></div>
        <div style="display:flex; justify-content:space-between;"><span>Initial / Final H:</span> <strong style="color:#fff;">${s.initial_hamiltonian_energy} / ${s.terminal_hamiltonian_energy}</strong></div>
        <div style="display:flex; justify-content:space-between;"><span>Orbit Stability:</span> <strong style="color:var(--cyan-accent);">${s.orbit_stability_ratio}</strong></div>
      `;
    }
  } catch (err) {
    console.debug("[TierOmegaTelemetry] fetch failed:", err);
  }
}

async function loadTradeExecutionSuite() {
  const capInput = document.getElementById("execPortfolioCapital");
  const capital = capInput ? (parseFloat(capInput.value) || 1000000) : 1000000;

  try {
    const res = await fetch(`/api/trade_execution_suite?portfolio_value=${capital}`);
    const data = await res.json();
    if (!data || data.status !== "SUCCESS") return;

    window.__brokerBaskets = data.broker_baskets || {};

    // 1. Render Options Tail-Hedge Summary
    const hedgeEl = document.getElementById("optionsHedgeSummary");
    if (hedgeEl && data.tail_hedging) {
      const th = data.tail_hedging;
      const lots = th.recommended_put_lots || 1;
      const strike = th.nifty_put_strike_5pct_otm || 23500;
      const deltaVal = th.portfolio_delta_rupee_val || capital;
      const summary = th.summary || `Buy ${lots} Lots NIFTY ${strike} PE for downside delta protection.`;
      
      hedgeEl.innerHTML = `
        <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
          <span>Target Protection: <strong style="color:#fff;">₹${Math.round(deltaVal).toLocaleString()}</strong> (Beta Delta)</span>
          <span>NIFTY Put Strike: <strong style="color:#ff5252;">${strike} PE (5% OTM)</strong></span>
        </div>
        <div style="display:flex; justify-content:space-between; margin-bottom:6px;">
          <span>Recommended Contracts: <strong style="color:var(--emerald-profit);">${lots} Lots (${lots * 75} Qty)</strong></span>
          <span>Net Collar Structure: <strong style="color:var(--cyan-accent);">${th.est_net_collar_cost || 'Net Zero Premium Outlay'}</strong></span>
        </div>
        <div style="color:var(--text-muted); font-size:10px;">${esc(summary)}</div>
      `;
    }

    // 2. Render Algo Slicing Summary
    const slicesEl = document.getElementById("executionSlicesSummary");
    if (slicesEl && data.execution_schedules) {
      slicesEl.innerHTML = `
        <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
          <span>Slicing Benchmark: <strong style="color:var(--cyan-accent);">Almgren-Chriss / VWAP U-Curve</strong></span>
          <span>Execution Horizon: <strong style="color:#fff;">Full Trading Session (6 Hours)</strong></span>
        </div>
        <div style="margin-top:4px; font-size:10.5px; line-height:1.6;">
          <div><strong style="color:var(--emerald-profit);">Wave 1 (09:45 AM):</strong> Opening liquidity absorption (40% allocation)</div>
          <div><strong style="color:var(--amber-warn);">Wave 2 (11:30 AM):</strong> Midday European open fade (25% allocation)</div>
          <div><strong style="color:var(--cyan-accent);">Wave 3 (02:15 PM):</strong> Closing auction block accumulation (35% allocation)</div>
        </div>
      `;
    }

    // 3. Render Conformal Trade Ladder Table
    const tbody = document.getElementById("executionTbody");
    if (tbody && data.trade_ladders) {
      if (data.trade_ladders.length === 0) {
        tbody.innerHTML = `<tr><td colspan="11" style="text-align:center; color:var(--text-muted); padding:20px;">No active trade ladder orders. Run optimization to generate allocations.</td></tr>`;
        return;
      }

      tbody.innerHTML = data.trade_ladders.map(l => {
        const sym = esc(l.ticker || "");
        const entry = l.entry_price != null ? Number(l.entry_price).toFixed(2) : '—';
        const sl = l.stop_loss != null ? Number(l.stop_loss).toFixed(2) : '—';
        const t1 = l.target_1 != null ? Number(l.target_1).toFixed(2) : '—';
        const t2 = l.target_2 != null ? Number(l.target_2).toFixed(2) : '—';
        const trail = l.chandelier_trail != null ? Number(l.chandelier_trail).toFixed(2) : '—';
        const alloc = l.allocated_capital != null ? Number(l.allocated_capital).toLocaleString() : '—';
        const qty = l.quantity || 1;
        const w = l.allocation_weight || "0.0%";
        const slPct = l.stop_loss_pct || "";
        const t1Pct = l.target_1_gain_pct || "";
        const t2Pct = l.target_2_gain_pct || "";
        const action = esc(l.action_guidance || "");

        return `
          <tr>
            <td style="font-weight:700; color:var(--cyan-accent); font-family:var(--font-mono);">${sym}</td>
            <td class="num-cell" style="font-family:var(--font-mono);">${w}</td>
            <td class="num-cell" style="font-weight:700; color:#fff; font-family:var(--font-mono);">${qty}</td>
            <td class="num-cell" style="font-family:var(--font-mono);">₹${alloc}</td>
            <td class="num-cell" style="font-family:var(--font-mono); font-weight:700;">₹${entry}</td>
            <td class="num-cell" style="color:#ff5252; font-weight:700; font-family:var(--font-mono);">₹${sl} <span style="font-size:9.5px; opacity:0.8;">(${slPct})</span></td>
            <td class="num-cell" style="color:var(--emerald-profit); font-weight:700; font-family:var(--font-mono);">₹${t1} <span style="font-size:9.5px; opacity:0.8;">(${t1Pct})</span></td>
            <td class="num-cell" style="color:var(--cyan-accent); font-weight:700; font-family:var(--font-mono);">₹${t2} <span style="font-size:9.5px; opacity:0.8;">(${t2Pct})</span></td>
            <td class="num-cell" style="color:var(--amber-warn); font-family:var(--font-mono);">₹${trail}</td>
            <td class="num-cell" style="font-family:var(--font-mono); font-weight:700; color:var(--emerald-profit);">${esc(l.liquidity_badge || '🟢 High-Cap Liquid')}</td>
            <td style="font-size:10.5px; color:var(--text-secondary);">${action}</td>
          </tr>
        `;
      }).join("");
    }

    // Refresh Risk, OMS and TCA
    loadPretradeRiskStatus();
    loadOMSOrdersHistory();
    loadTCAReport();
    checkKillSwitchStatus();
  } catch (err) {
    console.debug("[TradeExecutionSuite] fetch failed:", err);
  }
}

function downloadBrokerBasket(broker) {
  const baskets = window.__brokerBaskets || {};
  let content = "";
  let filename = "";
  let mimeType = "application/json";

  if (broker === "zerodha") {
    const orders = baskets.zerodha_kite || [];
    content = JSON.stringify(orders, null, 2);
    filename = "zerodha_kite_basket.json";
  } else if (broker === "dhan") {
    const orders = baskets.dhan_hq || [];
    content = JSON.stringify(orders, null, 2);
    filename = "dhan_hq_basket.json";
  } else if (broker === "angel") {
    const orders = baskets.angel_one || [];
    content = JSON.stringify(orders, null, 2);
    filename = "angel_one_basket.json";
  } else if (broker === "csv") {
    content = baskets.csv_format || "Symbol,Exchange,Action,Quantity,OrderType,Product,Price,TriggerPrice\n";
    filename = "multi_broker_basket.csv";
    mimeType = "text/csv";
  }

  if (!content) {
    alert("No orders available to export. Run an optimization sweep first.");
    return;
  }

  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function copyBrokerBasket(broker) {
  const baskets = window.__brokerBaskets || {};
  let content = "";
  if (broker === "zerodha") {
    const orders = baskets.zerodha_kite || [];
    content = JSON.stringify(orders, null, 2);
  } else if (broker === "dhan") {
    const orders = baskets.dhan_hq || [];
    content = JSON.stringify(orders, null, 2);
  } else if (broker === "angel") {
    const orders = baskets.angel_one || [];
    content = JSON.stringify(orders, null, 2);
  } else if (broker === "csv") {
    content = baskets.csv_format || "";
  }

  if (!content || content === "[]") {
    alert("No orders available. Run an optimization sweep first.");
    return;
  }

  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(content).then(() => {
      alert(`✓ Copied ${broker.toUpperCase()} basket orders to clipboard!`);
    }).catch(() => {
      _execCommandCopy(content, broker);
    });
  } else {
    _execCommandCopy(content, broker);
  }
}

function _execCommandCopy(content, broker) {
  const ta = document.createElement("textarea");
  ta.value = content;
  document.body.appendChild(ta);
  ta.select();
  document.execCommand("copy");
  document.body.removeChild(ta);
  alert(`✓ Copied ${broker.toUpperCase()} basket orders to clipboard!`);
}

// ============================================================================
// 💥 SOVEREIGN TIER-0 DYNAMIC BLACK SWAN MACRO CRISIS STRESS-TEST SIMULATOR
// ============================================================================

window.__cachedAssetSensitivities = window.__cachedAssetSensitivities || [];

const STRESS_PRESETS = {
  gfc2008: { mkt: -52, vix: 120, oil: -55, bond: -110, dxy: 10 },
  covid2020: { mkt: -38, vix: 180, oil: -65, bond: -60, dxy: 8 },
  geopolitics: { mkt: -18, vix: 65, oil: 45, bond: 50, dxy: 7 },
  oilshock: { mkt: -15, vix: 40, oil: 85, bond: 60, dxy: 4 },
  stagflation: { mkt: -22, vix: 55, oil: 30, bond: 150, dxy: 12 },
  baseline: { mkt: -20, vix: 50, oil: 25, bond: 75, dxy: 5 }
};

function onStressSliderChange() {
  const mkt = parseFloat(document.getElementById("sliderMkt")?.value || -20);
  const vix = parseFloat(document.getElementById("sliderVix")?.value || 50);
  const oil = parseFloat(document.getElementById("sliderOil")?.value || 25);
  const bond = parseFloat(document.getElementById("sliderBond")?.value || 75);
  const dxy = parseFloat(document.getElementById("sliderDxy")?.value || 5);

  const lblMkt = document.getElementById("labelMkt");
  if (lblMkt) {
    lblMkt.textContent = `${mkt >= 0 ? '+' : ''}${mkt.toFixed(1)}%`;
    lblMkt.style.color = mkt < 0 ? '#ef4444' : 'var(--tv-green)';
  }
  const lblVix = document.getElementById("labelVix");
  if (lblVix) {
    lblVix.textContent = `+${vix.toFixed(1)}%`;
  }
  const lblOil = document.getElementById("labelOil");
  if (lblOil) {
    lblOil.textContent = `${oil >= 0 ? '+' : ''}${oil.toFixed(1)}%`;
    lblOil.style.color = oil > 0 ? '#38bdf8' : '#94a3b8';
  }
  const lblBond = document.getElementById("labelBond");
  if (lblBond) {
    lblBond.textContent = `${bond >= 0 ? '+' : ''}${Math.round(bond)} bps`;
  }
  const lblDxy = document.getElementById("labelDxy");
  if (lblDxy) {
    lblDxy.textContent = `+${dxy.toFixed(1)}%`;
  }

  recalcStressSimulator();
}

function applyStressPreset(presetName) {
  const p = STRESS_PRESETS[presetName] || STRESS_PRESETS.baseline;
  const sMkt = document.getElementById("sliderMkt");
  const sVix = document.getElementById("sliderVix");
  const sOil = document.getElementById("sliderOil");
  const sBond = document.getElementById("sliderBond");
  const sDxy = document.getElementById("sliderDxy");

  if (sMkt) sMkt.value = p.mkt;
  if (sVix) sVix.value = p.vix;
  if (sOil) sOil.value = p.oil;
  if (sBond) sBond.value = p.bond;
  if (sDxy) sDxy.value = p.dxy;

  onStressSliderChange();
}

function setStressView(view) {
  const scenView = document.getElementById("stressScenariosView");
  const assetView = document.getElementById("stressAssetsView");
  const btnScen = document.getElementById("btnStressViewScenarios");
  const btnAsset = document.getElementById("btnStressViewAssets");

  if (view === 'assets') {
    if (scenView) scenView.style.display = "none";
    if (assetView) assetView.style.display = "block";
    if (btnAsset) {
      btnAsset.style.background = "#08251e";
      btnAsset.style.border = "1px solid var(--tv-green)";
      btnAsset.style.color = "var(--tv-green)";
    }
    if (btnScen) {
      btnScen.style.background = "#111";
      btnScen.style.border = "1px solid #333";
      btnScen.style.color = "#888";
    }
  } else {
    if (scenView) scenView.style.display = "block";
    if (assetView) assetView.style.display = "none";
    if (btnScen) {
      btnScen.style.background = "#08251e";
      btnScen.style.border = "1px solid var(--tv-green)";
      btnScen.style.color = "var(--tv-green)";
    }
    if (btnAsset) {
      btnAsset.style.background = "#111";
      btnAsset.style.border = "1px solid #333";
      btnAsset.style.color = "#888";
    }
  }
}

async function recalcStressSimulator() {
  const mkt = parseFloat(document.getElementById("sliderMkt")?.value || -20);
  const vix = parseFloat(document.getElementById("sliderVix")?.value || 50);
  const oil = parseFloat(document.getElementById("sliderOil")?.value || 25);
  const bond = parseFloat(document.getElementById("sliderBond")?.value || 75);
  const dxy = parseFloat(document.getElementById("sliderDxy")?.value || 5);
  const portVal = parseFloat(document.getElementById("simPortCapital")?.value || 1000000);

  try {
    const res = await fetch("/api/stress_test/simulate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mkt, vix, oil, bond, dxy, portfolio_value: portVal })
    });
    if (res.ok) {
      const data = await res.json();
      renderStressSimulatorResults(data);
      return;
    }
  } catch (err) {
    console.debug("[StressSimulator] server error, running client fallback:", err);
  }

  // Client-side fallback using cached asset sensitivities
  runClientStressSimulation(mkt, vix, oil, bond, dxy, portVal);
}

function renderStressSimulatorResults(data) {
  const kpiDd = document.getElementById("kpiStressDrawdown");
  const kpiLoss = document.getElementById("kpiStressLossInr");
  const kpiAlpha = document.getElementById("kpiStressAlpha");
  const kpiAnchor = document.getElementById("kpiStressAnchor");
  const kpiVuln = document.getElementById("kpiStressVulnerable");

  const dd = data.simulated_drawdown_pct != null ? data.simulated_drawdown_pct : -14.2;
  const loss = data.simulated_loss_inr != null ? data.simulated_loss_inr : -142000;
  const alpha = data.outperformance_pct != null ? data.outperformance_pct : 5.8;

  if (kpiDd) {
    kpiDd.textContent = `${dd >= 0 ? '+' : ''}${dd.toFixed(1)}%`;
    kpiDd.style.color = dd < 0 ? '#ef4444' : 'var(--tv-green)';
  }
  if (kpiLoss) {
    kpiLoss.textContent = `${loss >= 0 ? '+' : '-'}₹${Math.abs(Math.round(loss)).toLocaleString('en-IN')}`;
    kpiLoss.style.color = loss < 0 ? '#f59e0b' : 'var(--tv-green)';
  }
  if (kpiAlpha) {
    kpiAlpha.textContent = `${alpha >= 0 ? '+' : ''}${alpha.toFixed(1)}% Outperformance`;
    kpiAlpha.style.color = alpha >= 0 ? 'var(--tv-green)' : '#ef4444';
  }
  if (kpiAnchor) {
    kpiAnchor.textContent = data.top_anchor || "ONGC.NS (+3.2%)";
  }
  if (kpiVuln) {
    kpiVuln.textContent = data.worst_hit || "AUBANK.NS (-19.5%)";
  }

  // Populate Asset Impact Matrix
  renderAssetStressTable(data.asset_impacts || []);
}

function runClientStressSimulation(mkt, vix, oil, bond, dxy, portVal) {
  const sens = window.__cachedAssetSensitivities || [];
  if (!sens.length) return;

  let totalW = 0;
  sens.forEach(s => totalW += (s.weight_pct || 0));
  if (totalW <= 0) totalW = 100;

  let portRet = 0;
  const impacts = sens.map(s => {
    const w = s.weight_pct || 0;
    const normW = w / totalW;
    const bMkt = s.beta_mkt || 0.85;
    const bVix = s.beta_vix || (-0.075 * bMkt);
    const bOil = s.beta_oil || 0.0;
    const bBond = s.beta_bond || -0.10;
    const bDxy = s.beta_dxy || 0.05;

    const rShock = (bMkt * (mkt / 100)) + (bVix * (vix / 100)) + (bOil * (oil / 100)) + (bBond * (bond / 10000)) + (bDxy * (dxy / 100));
    const retPct = Math.round(rShock * 10000) / 100;
    const posVal = portVal * normW;
    const lossInr = Math.round(posVal * (Math.exp(rShock) - 1));
    portRet += normW * rShock;

    return {
      ticker: s.ticker,
      clean_ticker: s.clean_ticker,
      sector: s.sector,
      weight_pct: w,
      beta_mkt: bMkt,
      simulated_return_pct: retPct,
      loss_inr: lossInr,
      role: retPct > mkt ? "Crisis Anchor (Hedge)" : "Vulnerable (Shock Absorber)"
    };
  });

  const portRetPct = Math.round(portRet * 10000) / 100;
  const totalLossInr = Math.round(portVal * (Math.exp(portRet) - 1));
  const alpha = Math.round((portRetPct - mkt) * 100) / 100;

  impacts.sort((a, b) => b.simulated_return_pct - a.simulated_return_pct);
  const topAnchor = impacts[0];
  const worstHit = impacts[impacts.length - 1];

  renderStressSimulatorResults({
    simulated_drawdown_pct: portRetPct,
    simulated_loss_inr: totalLossInr,
    outperformance_pct: alpha,
    top_anchor: topAnchor ? `${topAnchor.ticker} (${topAnchor.simulated_return_pct >= 0 ? '+' : ''}${topAnchor.simulated_return_pct}%)` : "—",
    worst_hit: worstHit ? `${worstHit.ticker} (${worstHit.simulated_return_pct}%)` : "—",
    asset_impacts: impacts
  });
}

function renderAssetStressTable(assets) {
  const tbody = document.getElementById("stressAssetTbody");
  if (!tbody) return;
  if (!assets.length) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; color:var(--text-muted); font-size:11px; padding:12px;">No active holdings loaded. Run optimization to evaluate assets.</td></tr>`;
    return;
  }

  tbody.innerHTML = assets.map(a => {
    const isAnchor = (a.role || "").includes("Anchor");
    const roleBadge = isAnchor
      ? `<span style="background:rgba(8,153,129,0.15); color:var(--tv-green); border:1px solid rgba(8,153,129,0.3); padding:2px 6px; border-radius:3px; font-weight:700; font-size:9.5px; font-family:var(--font-mono);">🛡️ Crisis Anchor</span>`
      : `<span style="background:rgba(239,68,68,0.12); color:#fda4af; border:1px solid rgba(239,68,68,0.3); padding:2px 6px; border-radius:3px; font-weight:700; font-size:9.5px; font-family:var(--font-mono);">⚠️ Vulnerable</span>`;

    const retColor = (a.simulated_return_pct >= 0) ? 'var(--tv-green)' : '#ef4444';
    const retSign = (a.simulated_return_pct >= 0) ? '+' : '';
    const lossSign = (a.loss_inr >= 0) ? '+' : '-';
    const lossFmt = `${lossSign}₹${Math.abs(Math.round(a.loss_inr || 0)).toLocaleString('en-IN')}`;

    return `
      <tr>
        <td>
          <span style="font-weight:700; font-family:var(--font-mono); color:var(--cyan-accent);">${esc(a.ticker || a.clean_ticker)}</span>
          <span style="font-size:9.5px; color:var(--text-muted); margin-left:6px;">${esc(a.sector || "")}</span>
        </td>
        <td class="num-cell" style="font-family:var(--font-mono); color:var(--text-secondary);">${Number(a.weight_pct || 0).toFixed(1)}%</td>
        <td class="num-cell" style="font-family:var(--font-mono); color:#94a3b8;">${Number(a.beta_mkt || 0).toFixed(2)}</td>
        <td class="num-cell" style="font-family:var(--font-mono); font-weight:700; color:${retColor};">${retSign}${Number(a.simulated_return_pct || 0).toFixed(1)}%</td>
        <td class="num-cell" style="font-family:var(--font-mono); font-weight:700; color:${a.loss_inr >= 0 ? 'var(--tv-green)' : '#f59e0b'};">${lossFmt}</td>
        <td>${roleBadge}</td>
      </tr>
    `;
  }).join("");
}

// Make globally accessible for inline onclick handlers
window.onStressSliderChange = onStressSliderChange;
window.applyStressPreset = applyStressPreset;
window.setStressView = setStressView;
window.recalcStressSimulator = recalcStressSimulator;
window.renderAssetStressTable = renderAssetStressTable;

// ── Master Emergency Kill Switch & OMS Governance Suite ──────────────────

async function checkKillSwitchStatus() {
  try {
    const res = await fetch("/api/kill_switch/status");
    const data = await res.json();
    if (data.status === "SUCCESS" && data.kill_switch) {
      const ks = data.kill_switch;
      const isTriggered = ks.active || ks.state === "TRIGGERED";

      // 1. Header status badge
      const headerBadge = document.getElementById("killSwitchHeaderBadge");
      if (headerBadge) {
        if (isTriggered) {
          headerBadge.innerHTML = "🛑 KILL SWITCH: TRIGGERED";
          headerBadge.style.background = "rgba(239, 68, 68, 0.3)";
          headerBadge.style.color = "#ef4444";
          headerBadge.style.borderColor = "#ef4444";
        } else {
          headerBadge.innerHTML = "ARMED 🟢";
          headerBadge.style.background = "rgba(34, 197, 94, 0.15)";
          headerBadge.style.color = "#22c55e";
          headerBadge.style.borderColor = "rgba(34, 197, 94, 0.4)";
        }
      }

      // 2. Execution Panel widgets
      const panelBadge = document.getElementById("killSwitchPanelBadge");
      const panicBtn = document.getElementById("killSwitchPanicBtn");
      const disarmBtn = document.getElementById("killSwitchDisarmBtn");

      if (panelBadge) {
        panelBadge.innerHTML = isTriggered ? "HALTED / TRIGGERED 🛑" : "OPERATIONAL / ARMED 🟢";
        panelBadge.style.background = isTriggered ? "rgba(239, 68, 68, 0.25)" : "rgba(34, 197, 94, 0.15)";
        panelBadge.style.color = isTriggered ? "#ef4444" : "#22c55e";
        panelBadge.style.borderColor = isTriggered ? "#ef4444" : "rgba(34, 197, 94, 0.3)";
      }
      if (panicBtn) {
        panicBtn.disabled = isTriggered;
        panicBtn.style.opacity = isTriggered ? "0.4" : "1.0";
      }
      if (disarmBtn) {
        disarmBtn.style.display = isTriggered ? "inline-block" : "none";
      }
    }
  } catch (err) {
    console.debug("[KillSwitch] Status check failed:", err);
  }
}

async function toggleKillSwitchFromUI(action) {
  if (action === "activate") {
    const confirmed = confirm("⚠️ CRITICAL ACTION: ENGAGE GLOBAL KILL SWITCH?\\n\\nThis will immediately:\\n1. Cancel all working orders in OMS.\\n2. Freeze execution fail-closed.\\n3. Stop background optimization tasks.\\n\\nProceed?");
    if (!confirmed) return;
    try {
      const res = await fetch("/api/kill_switch/activate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reason: "Emergency panic trigger from Web Console", operator: "OPERATOR" })
      });
      const data = await res.json();
      if (data.status === "SUCCESS") {
        alert("🛑 GLOBAL KILL SWITCH ENGAGED.\\nAll trading and background tasks have been halted fail-closed.");
        checkKillSwitchStatus();
        loadOMSOrdersHistory();
      }
    } catch (err) {
      alert("Error activating kill switch: " + err);
    }
  } else if (action === "deactivate") {
    const confirmed = confirm("🟢 DISARM KILL SWITCH & RESTORE NORMAL TRADING?\\n\\nConfirm that market conditions are safe to resume execution.");
    if (!confirmed) return;
    try {
      const res = await fetch("/api/kill_switch/deactivate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reason: "Manual operator clearance from Web Console", operator: "OPERATOR" })
      });
      const data = await res.json();
      if (data.status === "SUCCESS") {
        alert("🟢 Kill Switch Disarmed. Pre-trade risk gateway is now ARMED for normal trading.");
        checkKillSwitchStatus();
      }
    } catch (err) {
      alert("Error disarming kill switch: " + err);
    }
  }
}

async function loadPretradeRiskStatus() {
  try {
    const res = await fetch("/api/risk/pretrade_status");
    const data = await res.json();
    if (data.status === "SUCCESS" && data.limits) {
      const l = data.limits;
      const el = document.getElementById("pretradeLimitsSummary");
      if (el) {
        el.innerHTML = `
          <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
            <span>Max Single Order: <strong style="color:var(--emerald-profit);">₹${Number(l.max_single_order_value_inr).toLocaleString('en-IN')}</strong></span>
            <span>Max Stock Cap: <strong style="color:var(--cyan-accent);">${l.max_stock_concentration_pct.toFixed(1)}%</strong></span>
          </div>
          <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
            <span>Max Sector Cap: <strong style="color:#b388ff;">${l.max_sector_concentration_pct.toFixed(1)}%</strong></span>
            <span>Fat-Finger Bound: <strong style="color:var(--amber-warn);">±${l.max_price_deviation_pct.toFixed(1)}% LTP</strong></span>
          </div>
          <div style="display:flex; justify-content:space-between;">
            <span>Margin Ceiling: <strong style="color:#60a5fa;">${l.max_margin_utilization_pct.toFixed(0)}% Cash</strong></span>
            <span>NSE Freeze Limits: <strong style="color:var(--emerald-profit);">Enforced</strong></span>
          </div>
        `;
      }
    }
  } catch (err) {
    console.debug("[PreTradeRisk] Failed to load limits:", err);
  }
}

async function loadOMSOrdersHistory() {
  try {
    const res = await fetch("/api/orders/history?limit=30");
    const data = await res.json();
    const tbody = document.getElementById("omsOrdersTbody");
    if (tbody && data.status === "SUCCESS") {
      const orders = data.orders || [];
      if (orders.length === 0) {
        tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; color:var(--text-muted); padding:16px;">No recent OMS orders logged in SQLite database.</td></tr>`;
        return;
      }
      tbody.innerHTML = orders.map(o => {
        const isFilled = o.status === "FILLED";
        const isRejected = o.status === "REJECTED";
        const isCancelled = o.status === "CANCELLED";
        const statusColor = isFilled ? "var(--emerald-profit)" : (isRejected || isCancelled ? "#ef4444" : "var(--amber-warn)");
        const sideColor = o.side === "BUY" ? "var(--emerald-profit)" : "#ef4444";
        const orderVal = (o.qty * (o.avg_fill_price || o.price || 0));

        return `
          <tr>
            <td style="font-family:var(--font-mono); font-size:10px; color:var(--text-muted);">${esc(o.order_id || "")}</td>
            <td><strong style="color:var(--cyan-accent); font-family:var(--font-mono);">${esc(o.symbol || "")}</strong></td>
            <td><span style="font-weight:700; color:${sideColor};">${esc(o.side || "")}</span></td>
            <td class="num-cell" style="font-family:var(--font-mono);">${Number(o.qty || 0).toLocaleString()}</td>
            <td class="num-cell" style="font-family:var(--font-mono);">₹${Number(o.avg_fill_price || o.price || 0).toFixed(2)}</td>
            <td class="num-cell" style="font-family:var(--font-mono); color:var(--text-secondary);">₹${Math.round(orderVal).toLocaleString('en-IN')}</td>
            <td><span style="font-weight:700; color:${statusColor}; font-size:10px;">${esc(o.status || "")}</span></td>
            <td style="font-size:10px; color:var(--text-muted);">${esc(o.created_at ? o.created_at.slice(11, 19) : "")}</td>
          </tr>
        `;
      }).join("");
    }
  } catch (err) {
    console.debug("[OMS] Failed to load orders:", err);
  }
}

async function loadTCAReport() {
  try {
    const res = await fetch("/api/tca/report?limit=30");
    const data = await res.json();
    if (data.status === "SUCCESS" && data.tca_report) {
      const rep = data.tca_report;
      const tcaSummaryEl = document.getElementById("tcaSummaryCard");
      if (tcaSummaryEl) {
        tcaSummaryEl.innerHTML = `
          <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
            <span>Audited Trades: <strong style="color:#fff;">${rep.total_trades}</strong></span>
            <span>Avg Fill Slippage: <strong style="color:${rep.mean_slippage_bps <= 5 ? 'var(--emerald-profit)' : 'var(--amber-warn)'};">${rep.mean_slippage_bps.toFixed(1)} bps</strong></span>
          </div>
          <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
            <span>Avg Arrival Delay: <strong style="color:var(--cyan-accent);">${rep.mean_delay_bps.toFixed(1)} bps</strong></span>
            <span>Total Shortfall: <strong style="color:#fff;">${rep.mean_total_shortfall_bps.toFixed(1)} bps</strong></span>
          </div>
          <div style="font-size:10px; color:var(--text-muted);">Perold (1988) Implementation Shortfall benchmarked to Almgren-Chriss (2000).</div>
        `;
      }
    }
  } catch (err) {
    console.debug("[TCA] Report load error:", err);
  }
}

async function executeBasketViaOMS(brokerName) {
  const capInput = document.getElementById("execPortfolioCapital");
  const capital = capInput ? (parseFloat(capInput.value) || 1000000) : 1000000;
  const isPaper = (brokerName === "paper");

  const conf = confirm(`Execute reconciled basket via ${brokerName.toUpperCase()} (${isPaper ? 'Paper Mode' : 'LIVE'} for ₹${capital.toLocaleString('en-IN')})?\\n\\nOrders will pass through the Pre-Trade Risk Gateway before execution.`);
  if (!conf) return;

  try {
    const suiteRes = await fetch(`/api/trade_execution_suite?portfolio_value=${capital}`);
    const suiteData = await suiteRes.json();
    if (!suiteData || !suiteData.trade_ladders || !suiteData.trade_ladders.length) {
      alert("No active orders found in trade execution suite. Run optimization first.");
      return;
    }

    const orders = suiteData.trade_ladders.map(l => ({
      ticker: l.ticker,
      side: "BUY",
      qty: l.quantity || 1,
      price: Number(l.entry_price) || 0.0,
      ltp: Number(l.entry_price) || 0.0,
    }));

    const res = await fetch("/api/orders/execute_basket", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        broker: brokerName,
        orders: orders,
        total_nav: capital,
        dry_run: isPaper,
      })
    });
    const resData = await res.json();
    if (resData.status === "SUCCESS") {
      const ex = resData.execution_result;
      alert(`✅ OMS Basket Complete!\\nExecuted: ${ex.executed_count}/${ex.total_orders}\\nRejected: ${ex.rejected_count}`);
      loadOMSOrdersHistory();
      loadTCAReport();
    } else {
      alert("Execution error: " + (resData.error || "Unknown"));
    }
  } catch (err) {
    alert("Execution request failed: " + err);
  }
}

window.checkKillSwitchStatus = checkKillSwitchStatus;
window.toggleKillSwitchFromUI = toggleKillSwitchFromUI;
window.loadPretradeRiskStatus = loadPretradeRiskStatus;
window.loadOMSOrdersHistory = loadOMSOrdersHistory;
window.loadTCAReport = loadTCAReport;
window.executeBasketViaOMS = executeBasketViaOMS;




