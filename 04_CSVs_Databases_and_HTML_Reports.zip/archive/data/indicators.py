"""Data-layer technical indicators.

This module provides indicator functions for the data layer. Functions that
overlap with math_engine.indicators are re-exported from there for
consistency. Functions unique to this module (trailing_return,
momentum_skip_recent, ema_gap, downside_vol) are implemented here.

Both this module and math_engine.indicators are importable — use either.
data.indicators for data-layer convenience, math_engine.indicators for
the math engine's more rigorous implementations.
"""
import numpy as np
import pandas as pd

TRADING_DAYS_PER_YEAR = 252

# ── Re-export shared functions from math_engine for consistency ──────────────
try:
    from math_engine.indicators import max_drawdown, compute_rsi, compute_beta
except ImportError:
    # Fallback implementations if math_engine isn't available
    def max_drawdown(series: pd.Series, lookback: int = TRADING_DAYS_PER_YEAR) -> float:
        """Calculates peak-to-trough maximum drawdown over lookback period."""
        s = series.dropna()
        s = s[s > 0]  # filter zero/negative prices
        if len(s) < 20:
            return float('nan')
        if len(s) > lookback:
            s = s.iloc[-lookback:]
        peak = s.cummax()
        dd = s / (peak + 1e-9) - 1.0
        return float(abs(dd.min())) if len(dd) else float('nan')

    def compute_rsi(series: pd.Series, period: int = 14) -> float:
        """Calculates standard Relative Strength Index (RSI)."""
        s = series.dropna()
        if len(s) < period + 3:
            return float('nan')
        delta = s.diff()
        gain = delta.clip(lower=0)
        loss = -delta.clip(upper=0)
        avg_gain = gain.ewm(alpha=1.0/period, min_periods=period, adjust=False).mean()
        avg_loss = loss.ewm(alpha=1.0/period, min_periods=period, adjust=False).mean()
        rs = avg_gain / avg_loss.replace(0, np.nan)
        rsi = 100 - (100 / (1 + rs))
        rsi = rsi.fillna(100.0)  # RSI=100 when no losses (Wilder's convention)
        out = rsi.dropna()
        return float(out.iloc[-1]) if not out.empty else float('nan')

    def compute_beta(asset_returns: pd.Series, benchmark_returns: pd.Series, window: int = 63) -> float:
        """Calculates trailing systematic beta relative to benchmark returns."""
        if benchmark_returns is None or asset_returns.empty or benchmark_returns.empty:
            return float('nan')
        common = asset_returns.index.intersection(benchmark_returns.index)
        if len(common) < 40:
            return float('nan')
        tail = common[-window:]
        a, b = asset_returns.loc[tail].values, benchmark_returns.loc[tail].values
        var_b = np.var(b, ddof=1)
        if var_b < 1e-12:
            return float('nan')
        return float(np.cov(a, b)[0, 1] / var_b)


# ── Unique functions (not in math_engine.indicators) ─────────────────────────

def trailing_return(series: pd.Series, bars: int) -> float:
    """Calculates simple trailing return over the given number of bars."""
    s = series.dropna()
    if len(s) <= bars:
        return float('nan')
    return float(s.iloc[-1] / s.iloc[-bars - 1] - 1.0)

def momentum_skip_recent(series: pd.Series, long_bars: int = 252, skip_bars: int = 21) -> float:
    """Calculates long-term return skipping the most recent skip_bars period."""
    s = series.dropna()
    if len(s) <= long_bars + skip_bars:
        return float('nan')
    recent = s.iloc[-skip_bars - 1]
    old = s.iloc[-long_bars - skip_bars - 1]
    if old == 0 or pd.isna(old) or pd.isna(recent):
        return float('nan')
    return float(recent / old - 1.0)

def ema_gap(series: pd.Series, span: int) -> float:
    """Calculates deviation of last price from its EMA."""
    s = series.dropna()
    if len(s) < span + 5:
        return float('nan')
    ema = s.ewm(span=span, adjust=False).mean().iloc[-1]
    if pd.isna(ema) or ema == 0:
        return float('nan')
    return float(s.iloc[-1] / ema - 1.0)

def annualized_vol(returns: pd.Series) -> float:
    """Annualizes standard deviation of returns."""
    r = returns.dropna()
    if len(r) < 20:
        return float('nan')
    return float(r.std() * np.sqrt(TRADING_DAYS_PER_YEAR))

def downside_vol(returns: pd.Series) -> float:
    """Annualizes downside standard deviation (semi-deviation) of negative returns."""
    r = returns.dropna()
    if len(r) < 20:
        return float('nan')
    dn = r[r < 0]
    if len(dn) < 8:
        return 0.0
    return float(dn.std() * np.sqrt(TRADING_DAYS_PER_YEAR))

def robust_zscore_series(series: pd.Series, clip: float = 4.0) -> pd.Series:
    """MAD-based robust Z-score with winsorization limits."""
    s = pd.to_numeric(series, errors="coerce")
    med = s.median()
    mad = (s - med).abs().median()
    if pd.notna(mad) and mad > 1e-9:
        z = (s - med) / (1.4826 * mad)
    else:
        std = s.std()
        if pd.notna(std) and std > 1e-9:
            z = (s - s.mean()) / std
        else:
            z = pd.Series(0.0, index=s.index)
    return z.clip(-clip, clip)
