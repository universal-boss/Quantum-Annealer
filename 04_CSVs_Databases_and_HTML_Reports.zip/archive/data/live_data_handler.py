"""
data/live_data_handler.py
==========================
Consumes serialized Arrow tick streams and maintains in-memory real-time pricing caches.
Calculates updates to rolling metrics (LTP, price change, latency) with zero-copy efficiency.
"""
from __future__ import annotations

import time
import logging
import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional
from enterprise.connectors.live_tick_feed import ArrowTickSerializer

logger = logging.getLogger(__name__)


class KalmanClockSynchronizer:
    """Kalman filter to estimate clock offset and filter out network packet jitter."""

    def __init__(self, process_noise: float = 1e-6, measurement_noise: float = 1e-3):
        self.x = np.zeros(2) # State: [offset, drift]
        self.P = np.eye(2) * 1.0 # State covariance
        self.Q = np.eye(2) * process_noise # Process noise covariance
        self.R = measurement_noise # Measurement noise covariance
        self.last_t = None

    def update_clock_offset(self, t_receive: float, t_timestamp: float) -> tuple[float, bool]:
        """Runs the Kalman Filter step to update estimated clock offset.
        
        Returns:
            Tuple[estimated_offset, is_jitter_anomaly]
        """
        z = t_receive - t_timestamp
        
        if self.last_t is None:
            self.x[0] = z
            self.last_t = t_receive
            return float(self.x[0]), False
            
        dt = t_receive - self.last_t
        self.last_t = t_receive
        
        # 1. Predict
        F = np.array([
            [1.0, dt],
            [0.0, 1.0]
        ])
        self.x = F @ self.x
        self.P = F @ self.P @ F.T + self.Q
        
        # 2. Measurement Update
        H = np.array([1.0, 0.0])
        y = z - (H @ self.x)
        S = max(float(H @ self.P @ H.T + self.R), 1e-9)
        
        # Jitter anomaly detection: deviation > 3 standard deviations
        is_anomaly = abs(y) > 3.0 * np.sqrt(S)
        
        if not is_anomaly:
            K = (self.P @ H.T) / S
            self.x = self.x + K * y
            self.P = (np.eye(2) - np.outer(K, H)) @ self.P
            
        return float(self.x[0]), is_anomaly


class LiveDataHandler:
    """Listens to Arrow tick streams, updates in-memory states, and performs latency auditing."""

    def __init__(self, symbols: List[str]):
        self.symbols = [s.upper() for s in symbols]
        self.prices: Dict[str, float] = {}
        self.last_update_times: Dict[str, float] = {}
        self.latencies: List[float] = []
        self.clock_synchronizer = KalmanClockSynchronizer()

    def handle_arrow_stream(self, arrow_payload: bytes):
        """Callback to handle serialized Apache Arrow tick bytes."""
        t_receive = time.time()
        
        try:
            # Deserialize using Arrow zero-copy memory mapping
            df_ticks = ArrowTickSerializer.arrow_batch_to_df(arrow_payload)
            if df_ticks.empty:
                return

            # Process and update prices
            for _, row in df_ticks.iterrows():
                sym = str(row["symbol"]).upper()
                price = float(row["last_price"])
                timestamp = float(row["timestamp"])

                self.prices[sym] = price
                self.last_update_times[sym] = timestamp

                # Filter latency via Kalman Clock Synchronizer to shield against packet jitter
                offset, is_anomaly = self.clock_synchronizer.update_clock_offset(t_receive, timestamp)
                
                # Audit serialization-to-deserialization latency
                latency_ms = (t_receive - timestamp) * 1000.0
                
                if is_anomaly:
                    logger.warning(
                        f"[LatencyJitterShield] Anomaly detected: packet timestamp indicates latency of "
                        f"{latency_ms:.2f} ms (outlier jitter spike)."
                    )
                else:
                    self.latencies.append(latency_ms)
                    # Keep latency list size constrained to prevent memory leak
                    if len(self.latencies) > 1000:
                        self.latencies.pop(0)

            # Periodically log benchmarks (e.g. average latency)
            avg_latency = sum(self.latencies) / len(self.latencies) if self.latencies else 0.0
            logger.debug(f"[LiveDataHandler] Deserialized {len(df_ticks)} ticks. Average pipeline latency: {avg_latency:.4f} ms")

        except Exception as e:
            logger.error(f"[LiveDataHandler] Error handling Arrow stream: {e}", exc_info=True)

    def get_latest_price(self, symbol: str) -> Optional[float]:
        """Query the latest in-memory price of a symbol."""
        return self.prices.get(symbol.upper())

    def get_latency_profile(self) -> Dict[str, float]:
        """Return average and peak latency benchmarks."""
        if not self.latencies:
            return {"avg_ms": 0.0, "peak_ms": 0.0}
        return {
            "avg_ms": float(sum(self.latencies) / len(self.latencies)),
            "peak_ms": float(max(self.latencies))
        }


class KalmanPriceFilter:
    """[LAYER 5] 1D Kalman Filter to filter high-frequency bid-ask noise and extract true latent asset price."""

    def __init__(self, process_variance: float = 1e-4, measurement_variance: float = 1e-2):
        self.x = None  # Latent price estimate
        self.P = 1.0   # Error covariance
        self.Q = process_variance
        self.R = measurement_variance

    def filter_price(self, raw_price: float) -> float:
        z = float(raw_price)
        if z <= 0:
            return z
        if self.x is None:
            self.x = z
            return z

        x_pred = self.x
        P_pred = self.P + self.Q

        K = P_pred / (P_pred + self.R)
        self.x = x_pred + K * (z - x_pred)
        self.P = (1.0 - K) * P_pred
        return float(self.x)


def check_sector_lead_lag_freeze(ticker: str, sector_returns: Dict[str, float] = None, threshold: float = -0.008) -> bool:
    """
    [LAYER 4] Cross-Asset Lead-Lag & Intra-Sector Cointegration Freeze.
    Freezes buy limit order generation if the sector index is in a distribution drop (e.g. < -0.8%).
    """
    if not sector_returns:
        return False
    try:
        sector_map = {
            "RELIANCE": "ENERGY", "ONGC": "ENERGY", "IOC": "ENERGY", "BPCL": "ENERGY",
            "HDFCBANK": "BANKING", "ICICIBANK": "BANKING", "SBIN": "BANKING", "KOTAKBANK": "BANKING",
            "TCS": "IT", "INFY": "IT", "WIPRO": "IT", "HCLTECH": "IT", "TECHM": "IT",
            "TATAMOTORS": "AUTO", "MARUTI": "AUTO", "M&M": "AUTO", "HEROMOTOCO": "AUTO"
        }
        sym = ticker.replace(".NS", "").replace(".BO", "").upper()
        sector = sector_map.get(sym, None)
        if not sector or sector not in sector_returns:
            return False

        sec_ret = float(sector_returns[sector])
        if sec_ret < threshold:
            logger.warning(f"[LeadLagFreeze] Freeze triggered for {ticker}: Sector {sector} return {sec_ret:.2%} < {threshold:.2%}")
            return True
        return False
    except Exception:
        return False
