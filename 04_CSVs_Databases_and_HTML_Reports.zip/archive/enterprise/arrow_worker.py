"""
enterprise/arrow_worker.py
==========================
High-speed quantitative data serialization using Apache Arrow IPC.
Serializes large pricing matrices with PyArrow to eliminate Python pickle
bottlenecks when passing data frames across parallel CPU screening tasks.

Phase 5.1: Removed serialize_with_pickle / deserialize_with_pickle entirely.
pickle.loads is arbitrary code execution — a public RCE vector. All cross-process
serialization must go through serialize_with_arrow / deserialize_with_arrow.
"""
from __future__ import annotations

import time
import numpy as np
import pandas as pd
from typing import Tuple

try:
    import pyarrow as pa
    import pyarrow.ipc as ipc
    HAS_ARROW = True
except ImportError:
    HAS_ARROW = False
    print("WARNING: pyarrow is not installed. Install via: pip install pyarrow")


def generate_synthetic_universe(n_assets: int = 500, n_days: int = 1000) -> pd.DataFrame:
    """Generate a large synthetic pricing returns matrix."""
    np.random.seed(42)
    dates = pd.date_range(end=pd.Timestamp.now(), periods=n_days, freq="D")
    tickers = [f"TICKER_{i}" for i in range(n_assets)]
    data = np.random.normal(0.0002, 0.012, (n_days, n_assets))
    return pd.DataFrame(data, index=dates, columns=tickers)


# Phase 5.1: serialize_with_pickle and deserialize_with_pickle DELETED.
# pickle.loads executes arbitrary code — it is an RCE vector if any code path
# receives bytes from a queue, network socket, Redis, or DB column and passes
# it through. Use serialize_with_arrow / deserialize_with_arrow instead.


def serialize_with_arrow(df: pd.DataFrame) -> "pa.Buffer":
    """Serialize Pandas DataFrame into an Apache Arrow IPC stream buffer."""
    if not HAS_ARROW:
        raise RuntimeError("PyArrow is required for Arrow serialization. Install: pip install pyarrow")
    table = pa.Table.from_pandas(df)
    sink = pa.BufferOutputStream()
    with ipc.new_stream(sink, table.schema) as writer:
        writer.write_table(table)
    return sink.getvalue()


def deserialize_with_arrow(buf: "pa.Buffer") -> pd.DataFrame:
    """Deserialize Apache Arrow IPC stream buffer back into a Pandas DataFrame."""
    if not HAS_ARROW:
        raise RuntimeError("PyArrow is required for Arrow deserialization. Install: pip install pyarrow")
    with ipc.open_stream(buf) as reader:
        table = reader.read_all()
    return table.to_pandas()


def run_benchmark():
    """Benchmark Apache Arrow IPC serialization performance."""
    print("==================================================")
    print("BENCHMARK: APACHE ARROW IPC SERIALIZATION")
    print("==================================================")

    print("Generating synthetic universe matrix (500 assets x 1000 days)...")
    df = generate_synthetic_universe(500, 1000)
    print(f"Data shape: {df.shape} | Approximate size in RAM: {df.memory_usage().sum() / 1e6:.2f} MB\n")

    if not HAS_ARROW:
        print("Cannot benchmark: pyarrow is not installed.")
        return

    t0 = time.perf_counter()
    arrow_buf = serialize_with_arrow(df)
    t_ser_arrow = (time.perf_counter() - t0) * 1000

    t0 = time.perf_counter()
    df_arrow = deserialize_with_arrow(arrow_buf)
    t_deser_arrow = (time.perf_counter() - t0) * 1000

    print(f"APACHE ARROW IPC:")
    print(f"  Serialization time  : {t_ser_arrow:.2f} ms")
    print(f"  Deserialization time: {t_deser_arrow:.2f} ms")
    print(f"  Serialized payload  : {arrow_buf.size / 1e6:.2f} MB")
    print("==================================================")
    print("Note: Arrow supports zero-copy deserialization in shared memory stores")
    print("(Ray/Plasma), reducing physical memory copy times to near-zero.")
    print("==================================================")


if __name__ == "__main__":
    if HAS_ARROW:
        run_benchmark()
    else:
        print("Install pyarrow to run the benchmark: pip install pyarrow")
