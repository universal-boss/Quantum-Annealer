"""
enterprise/connectors/bloomberg_feed.py
=======================================
Bloomberg quantitative market data feed driver.
Wraps the official Bloomberg blpapi SDK to query historical end-of-day and live tick data.
Returns an empty DataFrame when no active Bloomberg session exists — callers must handle
the offline case explicitly. Synthetic price generation has been removed.
"""
from __future__ import annotations

import logging
from datetime import datetime
from typing import List, Dict, Any, Optional
import pandas as pd

logger = logging.getLogger(__name__)

# Bloomberg Open API library imports
try:
    import blpapi
    HAS_BLPAPI = True
except ImportError:
    HAS_BLPAPI = False
    logger.warning("[BloombergFeed] blpapi SDK not found. Connector running in offline simulation mode.")


class BloombergFeed:
    """Institutional Bloomberg OpenAPI (blpapi) price feed driver.
    
    Establishes data sessions with a local Bloomberg Terminal (localhost:8194)
    or a remote enterprise B-PIPE cloud connection, returning structured Pandas data.
    """

    def __init__(self, host: str = "127.0.0.1", port: int = 8194) -> None:
        self.host = host
        self.port = port
        self.session: Optional[blpapi.Session] = None
        self.is_connected = False

    def connect(self) -> bool:
        """Establish connection session to Bloomberg Desktop or B-PIPE server."""
        if not HAS_BLPAPI:
            return False
            
        try:
            session_options = blpapi.SessionOptions()
            session_options.setServerHost(self.host)
            session_options.setServerPort(self.port)
            
            self.session = blpapi.Session(session_options)
            if not self.session.start():
                logger.error("[BloombergFeed] Failed to start Bloomberg session.")
                return False
                
            if not self.session.openService("//blp/refdata"):
                logger.error("[BloombergFeed] Failed to open Bloomberg Reference Data service.")
                self.session.stop()
                return False
                
            self.is_connected = True
            logger.info(f"[BloombergFeed] Connected to Bloomberg API session at {self.host}:{self.port}")
            return True
        except Exception as e:
            logger.error(f"[BloombergFeed] Session connection error: {e}")
            return False

    def get_historical_prices(
        self,
        tickers: List[str],
        fields: List[str],
        start_date: datetime,
        end_date: datetime
    ) -> pd.DataFrame:
        """Fetch historical price matrices from Bloomberg refdata service.
        
        Args:
            tickers: Bloomberg ticker strings (e.g., ["AAPL US Equity", "TSLA US Equity"])
            fields: Bloomberg fields (e.g., ["PX_LAST", "PX_VOLUME", "PX_BID", "PX_ASK"])
            start_date: Query window start.
            end_date: Query window end.
            
        Returns:
            Multivariate Pandas DataFrame indexed by Date.
        """
        if not self.is_connected or not self.session:
            return self._simulate_prices(tickers, fields, start_date, end_date)

        try:
            ref_data_service = self.session.getService("//blp/refdata")
            request = ref_data_service.createRequest("HistoricalDataRequest")
            
            # Populate query criteria
            for t in tickers:
                request.getElement("securities").appendValue(t)
            for f in fields:
                request.getElement("fields").appendValue(f)
                
            request.set("startDate", start_date.strftime("%Y%m%d"))
            request.set("endDate", end_date.strftime("%Y%m%d"))
            request.set("periodicitySelection", "DAILY")

            logger.info(f"[BloombergFeed] Submitting historical request for {len(tickers)} securities...")
            self.session.sendRequest(request)
            
            # Event parsing loop
            data_rows = []
            while True:
                event = self.session.nextEvent(5000)
                if event.eventType() in [blpapi.Event.RESPONSE, blpapi.Event.PARTIAL_RESPONSE]:
                    for msg in event:
                        security_data = msg.getElement("securityData")
                        security_name = security_data.getElementAsString("security")
                        field_data_arr = security_data.getElement("fieldData")
                        
                        for i in range(field_data_arr.numValues()):
                            field_data = field_data_arr.getValueAsElement(i)
                            date_str = field_data.getElementAsString("date")
                            dt = datetime.strptime(date_str, "%Y-%m-%d")
                            
                            row = {"Date": dt, "Ticker": security_name}
                            for f in fields:
                                if field_data.hasElement(f):
                                    row[f] = field_data.getElementAsFloat(f)
                            data_rows.append(row)
                            
                if event.eventType() == blpapi.Event.RESPONSE:
                    break

            df = pd.DataFrame(data_rows)
            if df.empty:
                return pd.DataFrame()
                
            # Pivot into standard multi-index or columns structure
            pivoted = df.pivot(index="Date", columns="Ticker", values=fields[0])
            logger.info(f"[BloombergFeed] Successfully retrieved {len(pivoted)} price matrices rows.")
            return pivoted
        except Exception as e:
            logger.error(f"[BloombergFeed] Historical request failed: {e}. Falling back to simulation.")
            return self._simulate_prices(tickers, fields, start_date, end_date)

    def disconnect(self) -> None:
        """Gracefully release Bloomberg sessions."""
        if self.session and self.is_connected:
            self.session.stop()
            self.is_connected = False
            logger.info("[BloombergFeed] Session stopped successfully.")

    def _simulate_prices(
        self,
        tickers: List[str],
        fields: List[str],
        start_date: datetime,
        end_date: datetime
    ) -> pd.DataFrame:
        """Returns an empty DataFrame when Bloomberg is unavailable.
        
        Previously this method generated synthetic random prices as a fallback,
        which risked feeding fabricated data into the optimizer. That behaviour
        has been removed. Callers must handle an empty DataFrame explicitly.
        """
        logger.error(
            "[BloombergFeed] No active Bloomberg session — cannot fetch real price data for: %s. "
            "Connect a Bloomberg Terminal or switch to a supported data provider (YFinance / Local DB).",
            tickers,
        )
        return pd.DataFrame()
