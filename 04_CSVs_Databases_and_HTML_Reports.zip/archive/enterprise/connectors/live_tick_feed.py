"""
enterprise/connectors/live_tick_feed.py
=======================================
High-performance async tick feed handler utilizing Apache Arrow serialization.
Subscribes to live market data and packages price ticks into PyArrow RecordBatches
to achieve sub-millisecond serialization latency and support zero-copy sharing.
"""
from __future__ import annotations

import io
import time
import asyncio
import logging
from typing import Dict, List, Any, Optional, Callable
import pandas as pd

try:
    import pyarrow as pa
    import pyarrow.ipc as ipc
    HAS_ARROW = True
except ImportError:
    HAS_ARROW = False

logger = logging.getLogger(__name__)


class ArrowTickSerializer:
    """Serializes tick dictionaries into high-performance Apache Arrow payloads."""

    @staticmethod
    def ticks_to_arrow_batch(ticks: List[Dict[str, Any]]) -> Optional[bytes]:
        """Convert a list of tick dicts into a serialized Apache Arrow RecordBatch.
        
        Fields: symbol, last_price, timestamp.
        """
        if not HAS_ARROW:
            raise RuntimeError("PyArrow is required for Arrow tick serialization.")
            
        if not ticks:
            return None

        symbols = [str(t.get("symbol", "")).upper() for t in ticks]
        prices = [float(t.get("last_price", 0.0)) for t in ticks]
        timestamps = [float(t.get("timestamp", time.time())) for t in ticks]

        # Define schema explicitly
        schema = pa.schema([
            ("symbol", pa.string()),
            ("last_price", pa.float64()),
            ("timestamp", pa.float64())
        ])

        # Build Arrow RecordBatch
        batch = pa.RecordBatch.from_arrays(
            [pa.array(symbols), pa.array(prices), pa.array(timestamps)],
            schema=schema
        )

        # Write to an IPC Stream
        sink = pa.BufferOutputStream()
        with ipc.new_stream(sink, schema) as writer:
            writer.write_batch(batch)
            
        return sink.getvalue().to_pybytes()

    @staticmethod
    def arrow_batch_to_df(buf_bytes: bytes) -> pd.DataFrame:
        """De-serialize an Arrow IPC stream buffer back to a Pandas DataFrame."""
        if not HAS_ARROW:
            raise RuntimeError("PyArrow is required for Arrow tick de-serialization.")
            
        buf = pa.py_buffer(buf_bytes)
        with ipc.open_stream(buf) as reader:
            batch = reader.read_next_batch()
            
        # Convert directly to pandas
        return batch.to_pandas()


class AsyncLiveTickFeed:
    """Async coordinator that manages live WebSocket tick ingestion and Arrow serialization."""

    def __init__(self, symbols: List[str], use_mock: bool = True):
        self.symbols = symbols
        self.use_mock = use_mock
        self.queue: asyncio.Queue[Dict[str, Any]] = asyncio.Queue()
        self.callbacks: List[Callable[[bytes], None]] = []
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._running = False
        self._feed_client = None

    def register_arrow_callback(self, cb: Callable[[bytes], None]):
        """Register callback that receives serialized Arrow tick batches."""
        if cb not in self.callbacks:
            self.callbacks.append(cb)

    def _on_tick_received(self, tick_data: Dict[str, Any]):
        """Callback wired to the raw websocket clients."""
        if self._running and self._loop:
            # Safely submit tick_data to the event loop's queue
            self._loop.call_soon_threadsafe(self.queue.put_nowait, tick_data)

    async def start(self):
        """Start async tick consumer and connect the underlying websocket client."""
        self._loop = asyncio.get_running_loop()
        self._running = True
        
        # Initialize either Mock or Kite client depending on flag
        if self.use_mock:
            from math_engine.websocket_feed import MockWebSocketClient
            # Set initial prices to 100 for simulation
            init_prices = {s: 100.0 for s in self.symbols}
            self._feed_client = MockWebSocketClient(self.symbols, initial_prices=init_prices, tick_interval=0.1)
        else:
            # Kite client will be resolved by credentials in prod, fallback mock for safety
            from math_engine.websocket_feed import MockWebSocketClient
            self._feed_client = MockWebSocketClient(self.symbols, tick_interval=0.1)

        self._feed_client.register_callback(self._on_tick_received)
        self._feed_client.connect()

        # Run the ingestion processing loop
        self._task = asyncio.create_task(self._process_queue_loop())
        logger.info("[AsyncLiveTickFeed] Async Arrow Tick Feed successfully started.")

    async def _process_queue_loop(self):
        """Batch ticks from queue every 50ms and serialize to Arrow RecordBatches."""
        while self._running:
            ticks = []
            
            # Wait for at least one tick
            try:
                tick = await self.queue.get()
                ticks.append(tick)
                self.queue.task_done()
            except asyncio.CancelledError:
                break

            # Drain any other pending ticks immediately to batch them
            while not self.queue.empty():
                try:
                    tick = self.queue.get_nowait()
                    ticks.append(tick)
                    self.queue.task_done()
                except asyncio.QueueEmpty:
                    break
                except asyncio.CancelledError:
                    break

            # Serialize batch to Arrow
            try:
                arrow_payload = ArrowTickSerializer.ticks_to_arrow_batch(ticks)
                if arrow_payload:
                    for cb in self.callbacks:
                        cb(arrow_payload)
            except Exception as e:
                logger.error(f"[AsyncLiveTickFeed] Serialization error: {e}")

            # Micro-sleep to allow ticks accumulation (e.g. 50ms batching window)
            try:
                await asyncio.sleep(0.05)
            except asyncio.CancelledError:
                break

    async def stop(self):
        """Stop the async ingestion loop and disconnect raw feed."""
        self._running = False
        if hasattr(self, "_task") and self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        if self._feed_client:
            self._feed_client.disconnect()
            self._feed_client.unregister_callback(self._on_tick_received)
        logger.info("[AsyncLiveTickFeed] Async Arrow Tick Feed stopped.")

