"""
enterprise/connectors/refinitiv_feed.py
=======================================
Refinitiv quantitative data feed driver.
Wraps the official refinitiv.data (RD) SDK to query pricing databases.
Returns an empty DataFrame when no active Refinitiv session exists — callers must handle
the offline case explicitly. Synthetic price generation has been removed.
"""
from __future__ import annotations

import logging
from datetime import datetime
from typing import List, Optional
import pandas as pd

logger = logging.getLogger(__name__)

# Refinitiv Data SDK imports
try:
    import refinitiv.data as rd
    from refinitiv.data.content import historical_pricing
    HAS_REFINITIV = True
except ImportError:
    HAS_REFINITIV = False
    logger.warning("[RefinitivFeed] refinitiv.data SDK not found. Connector running in offline simulation mode.")


class RefinitivFeed:
    """Institutional Refinitiv Data (RD) Platform pricing feed driver.
    
    Connects to the Refinitiv Data Platform cloud service or a locally running
    Eikon / Workspace application runtime, returning structured Pandas data.
    """

    def __init__(self, app_key: Optional[str] = None) -> None:
        self.app_key = app_key
        self.is_session_open = False

    def open_session(self) -> bool:
        """Initialize and open the Refinitiv platform or desktop session."""
        if not HAS_REFINITIV or not self.app_key:
            return False
            
        try:
            # Connect to local workspace if app_key is provided
            rd.open_platform_session(
                app_key=self.app_key,
                deployment=rd.session.Deployment.DESKTOP
            )
            self.is_session_open = True
            logger.info("[RefinitivFeed] Successfully established Refinitiv Desktop workspace session.")
            return True
        except Exception as e:
            logger.error(f"[RefinitivFeed] Platform session failed to open: {e}")
            return False

    def get_historical_prices(
        self,
        tickers: List[str],
        start_date: datetime,
        end_date: datetime,
        fields: Optional[List[str]] = None
    ) -> pd.DataFrame:
        """Fetch historical price matrices from Refinitiv Data service.
        
        Args:
            tickers: RIC codes (e.g. ["AAPL.O", "TCS.NS", "IBM.N"])
            start_date: Query window start.
            end_date: Query window end.
            fields: Pricing fields.
            
        Returns:
            Pandas DataFrame of historical pricing.
        """
        # L32-fix: avoid mutable default arg — materialize per-call instead
        fields = fields or ["TR.PriceClose"]
        if not self.is_session_open:
            return self._simulate_prices(tickers, start_date, end_date)

        try:
            # Query EOD Pricing Summaries
            response = historical_pricing.summaries.Definition(
                universe=tickers,
                interval=historical_pricing.summaries.Interval.DAILY,
                start=start_date.strftime("%Y-%m-%d"),
                end=end_date.strftime("%Y-%m-%d"),
                fields=fields
            ).get_data()
            
            if response.is_success:
                df = response.data.df
                # Parse output columns/structure depending on single or multi RIC response
                logger.info(f"[RefinitivFeed] Successfully queried {len(df)} rows from historical summaries.")
                return df
            else:
                logger.error(f"[RefinitivFeed] RD platform request failed: {response.status.message}")
                return self._simulate_prices(tickers, start_date, end_date)
        except Exception as e:
            logger.error(f"[RefinitivFeed] Historical prices fetch exception: {e}")
            return self._simulate_prices(tickers, start_date, end_date)

    def close_session(self) -> None:
        """Close active platform sessions."""
        if HAS_REFINITIV and self.is_session_open:
            rd.close_session()
            self.is_session_open = False
            logger.info("[RefinitivFeed] Session closed successfully.")

    def _simulate_prices(
        self,
        tickers: List[str],
        start_date: datetime,
        end_date: datetime
    ) -> pd.DataFrame:
        """Returns an empty DataFrame when Refinitiv is unavailable.

        Previously this method generated synthetic random prices as a fallback,
        which risked feeding fabricated data into the optimizer. That behaviour
        has been removed. Callers must handle an empty DataFrame explicitly.
        """
        logger.error(
            "[RefinitivFeed] No active Refinitiv session — cannot fetch real price data for: %s. "
            "Connect a Refinitiv Workspace or switch to a supported data provider (YFinance / Local DB).",
            tickers,
        )
        return pd.DataFrame()
