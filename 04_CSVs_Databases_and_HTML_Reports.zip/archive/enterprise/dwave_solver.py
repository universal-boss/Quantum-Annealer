"""
enterprise/dwave_solver.py
==========================
D-Wave hybrid quantum solver client wrapper for portfolio optimization.
Formulates the mean-variance allocation problem as a Constrained Quadratic Model (CQM)
and connects to D-Wave's Leap cloud sampler, with a graceful classical fallback solver.
"""
from __future__ import annotations

import logging
import numpy as np
from typing import Dict, List, Tuple, Optional

logger = logging.getLogger(__name__)

# Ocean SDK imports wrapped to fail gracefully if not installed
try:
    import dimod
    from dwave.system import LeapHybridCQMSampler
    HAS_DWAVE = True
except ImportError:
    HAS_DWAVE = False
    logger.warning("[DWaveSolver] D-Wave Ocean SDK not installed. Solver will run in classical fallback mode.")


class DWavePortfolioOptimizer:
    """Enterprise hybrid quantum portfolio optimizer.
    
    Uses dimod Constrained Quadratic Model (CQM) interface to formulate the allocation problem
    and submits it to D-Wave's remote Leap hardware, falling back to SciPy SQP solver if offline.
    """

    def __init__(self, token: Optional[str] = None, profile: Optional[str] = None) -> None:
        self.token = token
        self.profile = profile
        
        # Load from credentials if token is None
        if not self.token:
            try:
                import os, json
                creds_path = "/Users/deepak/.quantum_annealer_pro_v17/credentials.json"
                if os.path.exists(creds_path):
                    with open(creds_path, "r") as f:
                        creds = json.load(f)
                        self.token = creds.get("dwave_token") or creds.get("token")
                        self.profile = creds.get("dwave_profile") or creds.get("profile")
            except Exception as e:
                logger.warning("[DWaveSolver] Could not load local credentials file: %s", e)

        self.has_quantum = HAS_DWAVE and (self.token is not None or self.profile is not None)


    def optimize(
        self,
        tickers: List[str],
        expected_returns: np.ndarray,
        covariance_matrix: np.ndarray,
        risk_aversion: float = 2.5,
        max_weight: float = 0.35,
        time_limit: Optional[float] = None
    ) -> Dict[str, float]:
        """Formulate and solve the mean-variance optimization problem.
        
        Objective:
            Minimize:  (risk_aversion / 2) * w^T * Sigma * w - w^T * mu
            Subject to: Sum(w_i) = 1.0,  0 <= w_i <= max_weight
            
        Returns:
            Dict mapping ticker -> optimal weight fraction.
        """
        n = len(tickers)
        if n == 0:
            return {}

        # ── 1. D-Wave Cloud CQM Solver Path ──────────────────────────────────
        if self.has_quantum:
            try:
                logger.info("[DWaveSolver] Formulating Constrained Quadratic Model (CQM)...")
                cqm = dimod.ConstrainedQuadraticModel()
                
                # Register continuous real variables for weights: 0.0 <= w_i <= max_weight
                weights = {
                    t: dimod.Real(t, lower_bound=0.0, upper_bound=max_weight)
                    for t in tickers
                }
                
                # Define Objective Function: Risk - Expected Return
                # Objective: 0.5 * gamma * sum_{i,j} w_i * w_j * Sigma_{i,j} - sum_i w_i * mu_i
                objective = dimod.QuadraticModel()
                
                # Linear term: -mu_i * w_i
                for i, t in enumerate(tickers):
                    objective.add_linear(t, -expected_returns[i])
                    
                # Quadratic term: 0.5 * gamma * Sigma_{i,j} * w_i * w_j
                for i, t_i in enumerate(tickers):
                    for j, t_j in enumerate(tickers):
                        coeff = 0.5 * risk_aversion * covariance_matrix[i, j]
                        if i == j:
                            # C3-fix: variables are dimod.Real (not binary), so w_i^2 must be
                            # added as a QUADRATIC term, not linear. Using add_linear here
                            # silently produced 0.5*gamma*Sigma_ii*w_i (linear) instead of
                            # 0.5*gamma*Sigma_ii*w_i^2 (quadratic), corrupting the risk term.
                            objective.add_quadratic(t_i, t_i, coeff)
                        else:
                            objective.add_quadratic(t_i, t_j, coeff)
                            
                cqm.set_objective(objective)
                
                # Add Budget Constraint: Sum(w_i) == 1.0
                cqm.add_constraint(
                    dimod.quicksum(weights[t] for t in tickers) == 1.0,
                    label="budget_equality"
                )
                
                logger.info("[DWaveSolver] Connecting to LeapHybridCQMSampler cloud hardware...")
                if self.profile:
                    sampler = LeapHybridCQMSampler(profile=self.profile)
                else:
                    sampler = LeapHybridCQMSampler(token=self.token)
                
                # Submit job (non-blocking server side queue, returns future-like object)
                if time_limit is not None:
                    sampleset = sampler.sample_cqm(cqm, time_limit=time_limit, label="Portfolio Optimization Run")
                else:
                    sampleset = sampler.sample_cqm(cqm, label="Portfolio Optimization Run")
                
                # Retrieve the lowest energy feasible sample
                feasible_samples = sampleset.filter(lambda row: row.feasible)
                if len(feasible_samples) > 0:
                    best_sample = feasible_samples.first.sample
                    opt_weights = {t: float(best_sample[t]) for t in tickers}
                    logger.info("[DWaveSolver] Optimal weights successfully solved by D-Wave hybrid quantum solver.")
                    return opt_weights
                else:
                    logger.warning("[DWaveSolver] D-Wave returned no feasible samples. Falling back to classical solver.")
            except Exception as e:
                logger.error("[DWaveSolver] Quantum solver exception: %s. Falling back to classical.", e)

        # ── 2. Classical Fallback Solver Path (SciPy SQP) ───────────────────
        return self._solve_classical(tickers, expected_returns, covariance_matrix, risk_aversion, max_weight)

    def _solve_classical(
        self,
        tickers: List[str],
        expected_returns: np.ndarray,
        covariance_matrix: np.ndarray,
        risk_aversion: float,
        max_weight: float,
    ) -> Dict[str, float]:
        """Classical numerical optimization fallback using Sequential Least Squares Programming (SLSQP)."""
        logger.info("[DWaveSolver] Running classical fallback optimizer (SciPy SLSQP)...")
        from scipy.optimize import minimize
        
        n = len(tickers)
        
        # Objective: minimize 0.5 * gamma * w^T * Sigma * w - w^T * mu
        def objective_fn(w):
            risk = 0.5 * risk_aversion * np.dot(w, np.dot(covariance_matrix, w))
            ret = np.dot(w, expected_returns)
            return risk - ret
            
        # Initial guess (equal weights)
        w0 = np.ones(n) / n
        
        # Constraints: Sum(w_i) == 1.0
        constraints = {"type": "eq", "fun": lambda w: np.sum(w) - 1.0}
        
        # Bounds: 0.0 <= w_i <= max_weight
        bounds = [(0.0, max_weight) for _ in range(n)]
        
        res = minimize(
            objective_fn,
            w0,
            method="SLSQP",
            bounds=bounds,
            constraints=constraints,
            options={"ftol": 1e-9, "maxiter": 1000}
        )
        
        if res.success:
            opt_weights = {tickers[i]: float(res.x[i]) for i in range(n)}
            logger.info("[DWaveSolver] Classical optimizer successfully converged.")
            return opt_weights
        else:
            logger.error("[DWaveSolver] Classical optimizer failed: %s", res.message)
            # Safe absolute fallback: equal weights
            return {t: 1.0 / n for t in tickers}
