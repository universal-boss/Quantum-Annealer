"""
enterprise/grpc_math_service.py
===============================
High-performance gRPC server wrapper for quantitative services.
Exposes regime detection and factor risk attribution endpoints via Protocol Buffers.
Inherits dynamically from compiled Proto files with fallback decorators.
"""
from __future__ import annotations

import sys
import os
import time
import json
from typing import Any
from pathlib import Path
from concurrent import futures
import logging
import numpy as np
import pandas as pd

# Dyn path updates for parent packages
sys.path.append(str(Path(__file__).resolve().parents[1]))
from math_engine.regime_detector import MarketRegimeDetector
from math_engine.factor_risk import FactorRiskDecomposer

logger = logging.getLogger(__name__)

# gRPC imports
try:
    import grpc
    # We dynamically add the enterprise/ directory to path for proto imports
    sys.path.append(str(Path(__file__).resolve().parent))
    import math_service_pb2 as pb2
    import math_service_pb2_grpc as pb2_grpc
    HAS_GRPC = True
except ImportError:
    HAS_GRPC = False
    logger.warning("[gRPCService] grpcio or compiled protobuf files missing. Server running in stub validation mode.")

# Define Base Servicer Class dynamically depending on import availability
if HAS_GRPC:
    BaseServicer = pb2_grpc.MathServiceServicer
else:
    BaseServicer = object


class MathServiceServicer(BaseServicer):
    """gRPC Server Implementation for quantitative analysis endpoints."""

    def PredictRegime(self, request, context) -> Any:
        """Runs Gaussian HMM regime prediction over input index price series."""
        if not HAS_GRPC:
            if context is not None and hasattr(context, "set_details"):
                context.set_details("gRPC dependencies not found.")
            return None

        # Start timer for timeout (100ms maximum)
        start_time = time.time()
        timeout_limit = 0.100 # 100ms
        
        def run_inference():
            prices = list(request.prices)
            last_n_days = request.last_n_days
            use_macro_overlay = request.use_macro_overlay

            if len(prices) < 100:
                raise ValueError(f"Prices list must contain at least 100 observations (got {len(prices)}).")

            # Dynamic fit
            df = pd.DataFrame({"close": prices})
            detector = MarketRegimeDetector(n_iter=100)
            detector.fit(df)

            if getattr(detector, "_fit_failed", False):
                raise RuntimeError("EM algorithm failed to converge.")

            return detector.predict_regime(df, last_n_days=last_n_days, use_macro_overlay=use_macro_overlay)

        # H10-fix: don't use `with` — its __exit__ calls shutdown(wait=True), which blocks
        # past the 100ms timeout and holds the gRPC handler thread for the full inference.
        # L30-fix: avoid shadowing builtin TimeoutError — just use `except Exception:`.
        from concurrent.futures import ThreadPoolExecutor
        exec_pool = ThreadPoolExecutor(max_workers=1)
        future = exec_pool.submit(run_inference)
        try:
            res = future.result(timeout=timeout_limit)
        except Exception as e:
            logger.warning(f"Regime inference exceeded timeout or failed ({e}). Falling back to latest saved model.")
            try:
                latest_model_path = Path("models/regime_hmm_latest.json")
                if latest_model_path.exists():
                    detector = MarketRegimeDetector.load_json(latest_model_path)
                    prices = list(request.prices)
                    df = pd.DataFrame({"close": prices})
                    res = detector.predict_regime(df, last_n_days=request.last_n_days, use_macro_overlay=request.use_macro_overlay)
                else:
                    raise FileNotFoundError("models/regime_hmm_latest.json not found")
            except Exception as fallback_err:
                logger.error(f"Fallback model load failed: {fallback_err}")
                # Phase 5.7: Return confidence=0.0 and label "UNKNOWN" for fallbacks.
                # Previously: confidence=1.0 with label "Sideways" — downstream trading
                # logic treated this as high-conviction regime signal and sized positions
                # accordingly. A timeout during a regime shift would cause the system to
                # trade as if confidently in "Sideways" when reality is unknown.
                res = {
                    "state": -1,
                    "label": "UNKNOWN",
                    "confidence": 0.0,
                    "probabilities": {"Bear": 0.0, "Sideways": 0.0, "Bull": 0.0},
                    "raw_probabilities": {"Bear": 0.0, "Sideways": 0.0, "Bull": 0.0}
                }
        finally:
            exec_pool.shutdown(wait=False)

        try:
            probs = res.get("probabilities", {"Bear": 0.0, "Sideways": 1.0, "Bull": 0.0})
            raw_probs = res.get("raw_probabilities", probs)
            if isinstance(raw_probs, np.ndarray):
                raw_probs = {
                    "Bear": float(raw_probs[0]) if raw_probs.size > 0 else 0.0,
                    "Sideways": float(raw_probs[1]) if raw_probs.size > 1 else 1.0,
                    "Bull": float(raw_probs[2]) if raw_probs.size > 2 else 0.0,
                }
            elif isinstance(raw_probs, (list, tuple)):
                raw_probs = {
                    "Bear": float(raw_probs[0]) if len(raw_probs) > 0 else 0.0,
                    "Sideways": float(raw_probs[1]) if len(raw_probs) > 1 else 1.0,
                    "Bull": float(raw_probs[2]) if len(raw_probs) > 2 else 0.0,
                }
            # If standard pb2 doesn't have raw_probabilities field, we catch gracefully
            try:
                response = pb2.RegimeResponse(
                    state=res["state"],
                    label=res["label"],
                    confidence=res["confidence"],
                    probabilities=probs,
                    raw_probabilities=raw_probs
                )
            except TypeError:
                response = pb2.RegimeResponse(
                    state=res["state"],
                    label=res["label"],
                    confidence=res["confidence"],
                    probabilities=probs
                )
            return response
        except Exception as build_err:
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(f"Response building failed: {build_err}")
            return pb2.RegimeResponse()

    def DecomposeRisk(self, request, context) -> Any:
        """Decomposes portfolio variance into Systematic and Specific risk segments."""
        if not HAS_GRPC:
            if context is not None and hasattr(context, "set_details"):
                context.set_details("gRPC dependencies not found.")
            return None

        try:
            # 1. Rebuild returns matrix
            returns_dict = {}
            for ticker, f_list in request.returns.items():
                returns_dict[ticker] = list(f_list.values)
            returns_df = pd.DataFrame(returns_dict)

            # 2. Rebuild exposure matrix B
            exposures_dict = {}
            for ticker, exp_map in request.exposures.items():
                exposures_dict[ticker] = dict(exp_map.values)
            exposures_df = pd.DataFrame.from_dict(exposures_dict, orient="index")

            # 3. Weights dict
            weights_dict = dict(request.weights)

            # Aligned check
            common = list(set(returns_df.columns).intersection(exposures_df.index).intersection(weights_dict.keys()))
            if not common:
                context.set_code(grpc.StatusCode.INVALID_ARGUMENT)
                context.set_details("Data mismatch: returns columns, exposures index, and weights must align.")
                return pb2.RiskResponse()

            aligned_returns = returns_df[common]
            aligned_exposures = exposures_df.loc[common]
            aligned_weights = {t: weights_dict[t] for t in common}

            # Factor Risk Decomposition
            decomposer = FactorRiskDecomposer(n_factors=len(aligned_exposures.columns))
            risk = decomposer.decompose_risk(
                returns=aligned_returns,
                exposures=aligned_exposures,
                weights=aligned_weights,
                use_ledoit_wolf=True
            )

            return pb2.RiskResponse(
                portfolio_volatility=risk["portfolio_volatility"],
                factor_volatility=risk["factor_volatility"],
                specific_volatility=risk["specific_volatility"],
                factor_risk_ratio=risk["factor_risk_ratio"],
                specific_risk_ratio=risk["specific_risk_ratio"],
                portfolio_exposures=risk["portfolio_exposures"],
                factor_contributions=risk["factor_contributions"],
                security_mcr=risk["security_mcr"],
                security_ccr=risk["security_ccr"],
                ex_ante_var_95=risk["ex_ante_var_95"],
                ex_ante_var_99=risk["ex_ante_var_99"],
                ex_ante_cvar_95=risk["ex_ante_cvar_95"],
                ex_ante_cvar_99=risk["ex_ante_cvar_99"]
            )
        except Exception as e:
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(f"Risk decomposition failed: {str(e)}")
            return pb2.RiskResponse()


def serve(port: int = 50051) -> None:
    """Launch the gRPC server listening on the specified port."""
    if not HAS_GRPC:
        print("gRPC is not installed. Server cannot start. Run: pip install grpcio")
        return

    # Start REST API server in a separate daemon thread
    try:
        import threading
        import uvicorn
        from math_service import app

        # Phase 5.5: TLS + API key for REST API.
        # Previously: host="0.0.0.0" with no TLS, no auth, no rate limiter.
        # Anyone on the network could trigger expensive HMM fits (DoS) and
        # read portfolio risk decompositions (data exfiltration).
        # Now: bind to loopback only (front with authenticated reverse proxy in prod),
        # enable TLS if certs are available, require API key header.
        _api_key = os.environ.get("QA_API_KEY")
        _tls_cert = os.environ.get("QA_TLS_CERT")
        _tls_key = os.environ.get("QA_TLS_KEY")
        _bind_host = "127.0.0.1"  # loopback only — use reverse proxy for external access

        # Add API key middleware to the FastAPI app
        if _api_key:
            from fastapi import Security, HTTPException
            from fastapi.security import APIKeyHeader
            _api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)

            async def _verify_api_key(api_key: str = Security(_api_key_header)):
                if api_key != _api_key:
                    raise HTTPException(status_code=401, detail="Invalid or missing API key")
                return api_key

            # Apply to all routes
            for route in app.routes:
                if hasattr(route, 'dependant'):
                    route.dependant.dependencies.insert(0, _verify_api_key)

        _uvicorn_kwargs = {"host": _bind_host, "port": 8000, "log_level": "info"}
        if _tls_cert and _tls_key:
            _uvicorn_kwargs["ssl_certfile"] = _tls_cert
            _uvicorn_kwargs["ssl_keyfile"] = _tls_key
            print("REST API: TLS enabled")
        else:
            print("WARNING: REST API running WITHOUT TLS. Set QA_TLS_CERT and QA_TLS_KEY for production.")

        rest_thread = threading.Thread(
            target=uvicorn.run,
            args=(app,),
            kwargs=_uvicorn_kwargs,
            daemon=True
        )
        rest_thread.start()
        print(f"REST API (FastAPI) running on {_bind_host}:8000...")
    except Exception as e:
        print(f"Failed to start REST API: {e}")

    # Startup verification check
    try:
        latest_model_path = Path("models/regime_hmm_latest.json")
        if latest_model_path.exists():
            # Check model age
            mtime = latest_model_path.stat().st_mtime
            age_hours = (time.time() - mtime) / 3600.0
            if age_hours > 48.0:
                print(f"❌ Startup validation failed: models/regime_hmm_latest.json is too old ({age_hours:.1f} hours). Max allowed is 48 hours. Run nightly_model_trainer first.")
                sys.exit(1)
            
            with open(latest_model_path) as f:
                json.load(f)
            print(f"✅ Startup validation: models/regime_hmm_latest.json loaded successfully (Age: {age_hours:.1f}h).")
        else:
            print("❌ Startup validation failed: models/regime_hmm_latest.json not found. Run nightly_model_trainer first.")
            sys.exit(1)
    except Exception as e:
        print(f"❌ Startup validation failed: {e}")
        sys.exit(1)

    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    pb2_grpc.add_MathServiceServicer_to_server(MathServiceServicer(), server)

    # Register standard gRPC Health Check
    try:
        from grpc_health.v1 import health
        from grpc_health.v1 import health_pb2
        from grpc_health.v1 import health_pb2_grpc

        health_servicer = health.HealthServicer()
        health_servicer.set("", health_pb2.HealthCheckResponse.SERVING)
        health_pb2_grpc.add_HealthServicer_to_server(health_servicer, server)
        print("Standard gRPC Health check registered.")
    except Exception as e:
        print(f"Standard gRPC Health check failed to register: {e}")

    # Phase 5.4: TLS for gRPC server.
    # Previously: server.add_insecure_port(f"[::]:{port}") bound to ALL interfaces
    # with no TLS, no auth. Anyone with network reach could invoke PredictRegime /
    # DecomposeRisk, exhaust CPU, and exfiltrate portfolio data.
    # Now: use secure_port with TLS certs if available, bind to loopback by default.
    _grpc_tls_cert = os.environ.get("QA_GRPC_TLS_CERT")
    _grpc_tls_key = os.environ.get("QA_GRPC_TLS_KEY")
    _grpc_bind = os.environ.get("QA_GRPC_BIND", "127.0.0.1")  # loopback by default

    if _grpc_tls_cert and _grpc_tls_key:
        with open(_grpc_tls_key, "rb") as f:
            private_key = f.read()
        with open(_grpc_tls_cert, "rb") as f:
            certificate_chain = f.read()
        server_credentials = grpc.ssl_server_credentials(
            [(private_key, certificate_chain)]
        )
        server.add_secure_port(f"{_grpc_bind}:{port}", server_credentials)
        print(f"gRPC server: TLS enabled, bound to {_grpc_bind}:{port}")
    else:
        # Development fallback: insecure port on loopback only
        if os.environ.get("ENV", "development").lower() == "production":
            print("REFUSING to start gRPC in production without TLS. Set QA_GRPC_TLS_CERT and QA_GRPC_TLS_KEY.")
            sys.exit(1)
        server.add_insecure_port(f"{_grpc_bind}:{port}")
        print(f"WARNING: gRPC running WITHOUT TLS on {_grpc_bind}:{port} (development mode only).")

    print(f"High-Performance gRPC Math Service running on port {port}...")
    server.start()
    try:
        while True:
            time.sleep(86400)
    except KeyboardInterrupt:
        server.stop(0)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    serve()
