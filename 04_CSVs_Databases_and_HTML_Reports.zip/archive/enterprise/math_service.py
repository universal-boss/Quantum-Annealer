"""
enterprise/math_service.py
==========================
Stateless enterprise REST API microservice prototype wrapping core quantitative models.
Uses FastAPI to expose the HMM market regime classifier and Barra-style factor risk models.
"""
from __future__ import annotations

import sys
import os
from pathlib import Path
import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional

try:
    from fastapi import FastAPI, HTTPException
    from pydantic import BaseModel, Field
    import uvicorn
except ImportError:
    raise ImportError("FastAPI, Pydantic, and Uvicorn are required. Install via: pip install fastapi pydantic uvicorn")

# Dynamically add parent directory to python path for internal engine module imports
sys.path.append(str(Path(__file__).resolve().parents[1]))
from math_engine.regime_detector import MarketRegimeDetector
from math_engine.factor_risk import FactorRiskDecomposer

app = FastAPI(
    title="Quantum Annealer: Enterprise Math Service",
    description="Stateless gRPC/REST quantitative microservice API for HMM and Barra-style portfolio risk.",
    version="1.0.0"
)

# ── Pydantic Request & Response Schemas ──────────────────────────────────────

class RegimePredictRequest(BaseModel):
    prices: List[float] = Field(..., description="Historical prices of market index", min_length=120)
    last_n_days: int = Field(252, description="Inference window length", ge=100)
    use_macro_overlay: bool = Field(False, description="Apply global macro Bayesian overlays")

class RegimePredictResponse(BaseModel):
    state: int
    label: str
    confidence: float
    probabilities: Dict[str, float]
    raw_probabilities: Dict[str, float]
    signals: Dict[str, float]

class RiskDecomposeRequest(BaseModel):
    # returns: dict mapping ticker -> list of returns
    returns: Dict[str, List[float]] = Field(..., description="Historical assets daily returns")
    # exposures: dict mapping ticker -> dict of style exposures (e.g. Size, Value, Momentum)
    exposures: Dict[str, Dict[str, float]] = Field(..., description="Barra style factor exposure matrix B")
    # weights: dict mapping ticker -> portfolio weight
    weights: Dict[str, float] = Field(..., description="Portfolio constituent weights")

class RiskDecomposeResponse(BaseModel):
    portfolio_volatility: float
    factor_volatility: float
    specific_volatility: float
    factor_risk_ratio: float
    specific_risk_ratio: float
    portfolio_exposures: Dict[str, float]
    factor_contributions: Dict[str, float]
    security_mcr: Dict[str, float]
    security_ccr: Dict[str, float]
    ex_ante_var_95: float
    ex_ante_var_99: float
    ex_ante_cvar_95: float
    ex_ante_cvar_99: float


# ── REST API Endpoint Implementations ────────────────────────────────────────

@app.post("/regime/predict", response_model=RegimePredictResponse)
async def predict_market_regime(req: RegimePredictRequest):
    """Run Hidden Markov Model (HMM) inference on historical index prices to classify regime."""
    try:
        # Construct expected input dataframe
        df = pd.DataFrame({"close": req.prices})
        
        # Instantiate a pre-fitted model or fit dynamically (for prototype we fit dynamically)
        detector = MarketRegimeDetector(n_iter=100)
        detector.fit(df)
        
        if getattr(detector, "_fit_failed", False):
            raise HTTPException(status_code=500, detail="EM algorithm failed to converge on provided prices.")
            
        result = detector.predict_regime(df, last_n_days=req.last_n_days, use_macro_overlay=req.use_macro_overlay)
        return {
            "state": result["state"],
            "label": result["label"],
            "confidence": result["confidence"],
            "probabilities": result["probabilities"],
            "raw_probabilities": result.get("raw_probabilities", result["probabilities"]),
            "signals": result.get("signals", {
                "macro_shock_applied": float(result.get("macro_shock_applied", False)),
                "macro_shock_factor": float(result.get("macro_shock_factor", 0.0)),
                "kl_divergence": float(result.get("kl_divergence", 0.0)),
            })
        }
    except HTTPException:
        # M13-fix: re-raise HTTPException as-is (don't catch as 400)
        raise
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Regime prediction error: {str(e)}")


@app.post("/risk/decompose", response_model=RiskDecomposeResponse)
async def decompose_portfolio_risk(req: RiskDecomposeRequest):
    """Decompose portfolio risk into systematic and specific risk segments."""
    try:
        # 1. Aligned asset returns
        returns_df = pd.DataFrame(req.returns)
        
        # 2. Exposure matrix B
        exposures_df = pd.DataFrame.from_dict(req.exposures, orient="index")
        
        # Verify alignment
        common_assets = list(set(returns_df.columns).intersection(exposures_df.index).intersection(req.weights.keys()))
        if not common_assets:
            raise ValueError("No matching aligned assets found between returns, exposures, and weights.")
            
        aligned_returns = returns_df[common_assets]
        aligned_exposures = exposures_df.loc[common_assets]
        aligned_weights = {ticker: req.weights[ticker] for ticker in common_assets}
        
        # Instantiate and run Barra risk decomposer
        decomposer = FactorRiskDecomposer(n_factors=len(aligned_exposures.columns))
        risk = decomposer.decompose_risk(
            returns=aligned_returns,
            exposures=aligned_exposures,
            weights=aligned_weights,
            use_ledoit_wolf=True
        )
        
        return {
            "portfolio_volatility": risk["portfolio_volatility"],
            "factor_volatility": risk["factor_volatility"],
            "specific_volatility": risk["specific_volatility"],
            "factor_risk_ratio": risk["factor_risk_ratio"],
            "specific_risk_ratio": risk["specific_risk_ratio"],
            "portfolio_exposures": risk["portfolio_exposures"],
            "factor_contributions": risk["factor_contributions"],
            "security_mcr": risk["security_mcr"],
            "security_ccr": risk["security_ccr"],
            "ex_ante_var_95": risk["ex_ante_var_95"],
            "ex_ante_var_99": risk["ex_ante_var_99"],
            "ex_ante_cvar_95": risk["ex_ante_cvar_95"],
            "ex_ante_cvar_99": risk["ex_ante_cvar_99"]
        }
    except Exception as e:
        import traceback
        print(traceback.format_exc())
        raise HTTPException(status_code=400, detail=f"Risk decomposition error: {str(e)}")


if __name__ == "__main__":
    # Runs the local uvicorn development server on port 8000
    uvicorn.run(app, host="127.0.0.1", port=8000)
