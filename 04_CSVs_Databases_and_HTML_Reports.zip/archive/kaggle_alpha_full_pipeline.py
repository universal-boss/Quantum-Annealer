"""
kaggle_alpha_full_pipeline.py
=============================
Single unified script that runs BOTH pipelines and compares them:

  STAGE 1 — Setup & Data
    • Install packages, patch read-only filesystem, find project dir
    • Fetch Nifty 500 universe + 5y OHLCV prices (ONE download, shared)
    • Apply liquidity + staleness filters

  STAGE 2 — Proven Quant Strategies (baseline)
    • 12-1 momentum, idiosyncratic low-vol, 3d reversal, vol momentum
    • IC-calibrated, regime-conditioned, ATR position sizing
    • Walk-forward OOS backtest with asymmetric transaction costs
    • Outputs: equity_curve_quant.csv, backtest_results.json

  STAGE 3 — ML Alpha (100+ factors + 5-model ensemble)
    • Vectorised factor computation (no per-ticker signature loop)
    • PIT fundamentals (75d lag), selective rank transforms
    • CPCV (15 paths), per-fold feature selection, NNLS stacking
    • Outputs: ml_alpha_model.pkl, fit_result.json

  STAGE 4 — Comparison
    • Side-by-side Sharpe / alpha / drawdown
    • Verdict: which to deploy, or blend both

Download from Kaggle Output:
  ml_alpha_model.pkl      → copy to QuantumAnnealer/models/
  fit_result.json         → ML metrics
  backtest_results.json   → Quant metrics
  equity_curve_quant.csv  → Quant equity curve
  comparison.json         → Head-to-head summary

USAGE:
  1. Upload QuantumAnnealer.zip as a Kaggle Dataset
  2. Create Kaggle Notebook, attach dataset, enable Internet
  3. Paste this entire script into a single cell and run
  4. Download the 5 output files from the Output panel
"""

import os, sys, json, pickle, subprocess, importlib, warnings, math
from datetime import date, timedelta
from pathlib import Path
import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║  STAGE 1 — SETUP & DATA                                                     ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

# ── 1a. Find project dir ──────────────────────────────────────────────────────
PROJECT_DIR = None
for _search in ["/kaggle/input", "/kaggle/working", "."]:
    if not os.path.isdir(_search): continue
    for _root, _dirs, _files in os.walk(_search):
        if "launch_desktop.py" in _files and "ml_alpha" in _dirs:
            PROJECT_DIR = _root; break
        for _d in _dirs:
            _c = os.path.join(_root, _d)
            if os.path.isfile(os.path.join(_c, "launch_desktop.py")):
                PROJECT_DIR = _c; break
        if PROJECT_DIR: break
    if PROJECT_DIR: break

if not PROJECT_DIR:
    print("Auto-detect failed. Listing /kaggle/input:")
    if os.path.isdir("/kaggle/input"):
        for item in os.listdir("/kaggle/input"):
            print(f"  /kaggle/input/{item}")
            sub = os.path.join("/kaggle/input", item)
            if os.path.isdir(sub):
                for s in os.listdir(sub)[:10]: print(f"    {s}")
    PROJECT_DIR = "/kaggle/input/quantum-annealer/QuantumAnnealer"

print(f"✓ Project: {PROJECT_DIR}")
sys.path.insert(0, PROJECT_DIR)

# ── 1b. Install packages ──────────────────────────────────────────────────────
print("Installing packages...")
subprocess.run(
    [sys.executable, "-m", "pip", "install", "-q",
     "yfinance", "pydantic", "arch", "dimod", "dwave-neal",
     "scipy", "lightgbm", "catboost", "torch"],
    check=False,
)
os.environ["LIGHTGBM_NUM_THREADS"] = str(os.cpu_count() or 4)
for _e in ["OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"]:
    os.environ.pop(_e, None)
print("✓ Packages installed")

# ── 1c. Patch read-only filesystem (idempotent) ───────────────────────────────
import os as _os, pathlib as _pathlib

for _d in ["/tmp/qa_artifacts", "/tmp/qa_feature_cache",
           "/tmp/qa_experiments", "/tmp/qa_runtime"]:
    Path(_d).mkdir(parents=True, exist_ok=True)

if not getattr(_os.mkdir, "_qa_patched", False):
    _orig_os_mkdir = _os.mkdir
    def _safe_os_mkdir(path, mode=0o777, *, _orig=_orig_os_mkdir):
        try: return _orig(path, mode)
        except (OSError, PermissionError): pass
    _safe_os_mkdir._qa_patched = True
    _os.mkdir = _safe_os_mkdir

if not getattr(_pathlib.Path.mkdir, "_qa_patched", False):
    _orig_pmkdir = _pathlib.Path.mkdir
    def _safe_pmkdir(self, mode=0o777, parents=False, exist_ok=False, *, _orig=_orig_pmkdir):
        try: return _orig(self, mode=mode, parents=parents, exist_ok=exist_ok)
        except (OSError, PermissionError): pass
    _safe_pmkdir._qa_patched = True
    _pathlib.Path.mkdir = _safe_pmkdir

if not getattr(_pathlib.Path.resolve, "_qa_patched", False):
    _orig_resolve = _pathlib.Path.resolve
    def _safe_resolve(self, strict=False, *, _orig=_orig_resolve):
        try: return _orig(self, strict=strict)
        except (OSError, RuntimeError): return _pathlib.Path(str(self))
    _safe_resolve._qa_patched = True
    _pathlib.Path.resolve = _safe_resolve

import utils as _utils_mod
_utils_mod.ARTIFACTS_DIR = Path("/tmp/qa_artifacts")
_utils_mod.RUNTIME_DIR   = Path("/tmp/qa_runtime")
_utils_mod.RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
for _attr, _fname in [
    ("TICKERS_CACHE_PATH",           "nse_tickers_cache.json"),
    ("PRESCREEN_CACHE_PATH",         "qa_prescreen_cache.json"),
    ("FACTOR_IC_CACHE_PATH",         "factor_ic_cache.json"),
    ("SQLITE_DB_PATH",               "qa_portfolio_history.db"),
    ("OFFLINE_CHART_MODEL_PATH",     "chart_ssl_offline_1d.npz"),
    ("OFFLINE_CHART_MODEL_META_PATH","chart_ssl_offline_1d_meta.json"),
]:
    if hasattr(_utils_mod, _attr):
        setattr(_utils_mod, _attr, _utils_mod.RUNTIME_DIR / _fname)

sys.path.insert(0, os.path.join(PROJECT_DIR, "ml_alpha"))
_fs = importlib.import_module("ml_alpha.feature_store")
def _safe_fs_init(self, cache_dir=None):
    self.cache_dir = Path("/tmp/qa_feature_cache")
    self.cache_dir.mkdir(parents=True, exist_ok=True)
def _safe_et_init(self, experiments_dir=None):
    self.experiments_dir = Path("/tmp/qa_experiments")
    self.experiments_dir.mkdir(parents=True, exist_ok=True)
_fs.FeatureStore.__init__ = _safe_fs_init
_fs.ExperimentTracker.__init__ = _safe_et_init
_fs.CACHE_DIR = Path("/tmp/qa_feature_cache")
_fs.EXPERIMENTS_DIR = Path("/tmp/qa_experiments")
print("✓ Filesystem patches applied")

# ── 1d. Import project ML modules ────────────────────────────────────────────
from ml_alpha import AlphaEngine
from ml_alpha.metrics import (
    spearman_ic, quantile_sharpe, deflated_sharpe_ratio, walk_forward_efficiency,
)
from ml_alpha.walk_forward import CombinatorialPurgedCV
from ml_alpha.labeling import (
    compute_daily_volatility, triple_barrier_labels, labels_to_forward_returns,
)
from ml_alpha.feature_selection import select_factors
print("✓ Project modules imported")

# ── 1e. Fetch universe ────────────────────────────────────────────────────────
print(f"\n{'═'*70}")
print("STAGE 1 — FETCH UNIVERSE + PRICES  (shared by both pipelines)")
print(f"{'═'*70}")

engine = AlphaEngine(model_type="blend")
_end   = date.today()
_start = _end - timedelta(days=365 * 5)   # 5y: enough for both quant backtest & ML training
print(f"Period: {_start} → {_end}")

print("Fetching Nifty 500 universe...")
tickers = engine._get_universe("nifty500")
print(f"  {len(tickers)} tickers from _get_universe")

if len(tickers) < 50:
    print(f"  ⚠ Only {len(tickers)} — trying NSE archive fallback")
    import urllib.request, csv as _csv, io as _io
    _fb = []
    for _idx_name, _url in [
        ("nifty50",  "https://archives.nseindia.com/content/indices/ind_nifty50list.csv"),
        ("nifty100", "https://archives.nseindia.com/content/indices/ind_nifty100list.csv"),
        ("nifty500", "https://archives.nseindia.com/content/indices/ind_nifty500list.csv"),
    ]:
        if len(_fb) >= 300: break
        try:
            _req = urllib.request.Request(_url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(_req, timeout=20) as _r:
                for _row in _csv.DictReader(_io.StringIO(_r.read().decode("utf-8", "ignore"))):
                    _s = _row.get("Symbol") or _row.get("SYMBOL")
                    if _s: _fb.append(f"{_s.strip()}.NS")
            print(f"  ✓ {_idx_name}: {len(_fb)} cumulative")
        except Exception as _e:
            print(f"  ✗ {_idx_name}: {_e}")
    if _fb:
        tickers = list(dict.fromkeys(_fb))
        print(f"  ✓ Fallback universe: {len(tickers)} tickers")

if len(tickers) < 10:
    print("❌ FATAL: Cannot obtain universe. Check Kaggle internet setting.")
    sys.exit(1)

# ── 1f. Fetch prices (ONE download, shared) ───────────────────────────────────
# Warmup of 450d ensures factors needing 252d of history are valid at _start
print("Fetching prices (5y + 450d warmup)...")
panel, benchmark = engine._fetch_prices(tickers, _start - timedelta(days=450), _end)
close_df  = panel.get("Close",  pd.DataFrame()).sort_index()
high_df   = panel.get("High",   pd.DataFrame()).sort_index()
low_df    = panel.get("Low",    pd.DataFrame()).sort_index()
volume_df = panel.get("Volume", pd.DataFrame()).sort_index()
open_df   = panel.get("Open",   pd.DataFrame()).sort_index()
print(f"  {len(close_df)} trading days, {close_df.shape[1]} raw tickers")

# ── 1g. Benchmark series ──────────────────────────────────────────────────────
import yfinance as yf
_bench_raw = yf.download("^NSEI", start=_start - timedelta(days=450),
                          end=_end, progress=False, auto_adjust=False)
if isinstance(_bench_raw.columns, pd.MultiIndex):
    _bench_raw.columns = _bench_raw.columns.get_level_values(0)
bench_ret = _bench_raw["Close"].pct_change().dropna()
print(f"  Benchmark (^NSEI): {len(bench_ret)} days")

# ── 1h. Liquidity + staleness filter (shared) ────────────────────────────────
# PIT: use head(63) — stocks liquid at TRAINING START, not end (no survivorship)
_MIN_ADV = 500_000_000   # ₹50 crore
adv_63   = (volume_df.head(63) * close_df.head(63)).mean()
liquid   = adv_63[adv_63 >= _MIN_ADV].index.tolist()

# Also drop stale-price stocks (>10% zero-return days — microstructure artifact)
ret_all   = close_df.pct_change()
zero_pct  = (ret_all.abs() < 1e-6).mean()
not_stale = zero_pct[zero_pct <= 0.10].index.tolist()

keep = [t for t in liquid if t in not_stale and t in close_df.columns]
_n_raw = close_df.shape[1]

close_df  = close_df[keep]
high_df   = high_df[keep]   if all(c in high_df.columns   for c in keep) else high_df.reindex(columns=keep)
low_df    = low_df[keep]    if all(c in low_df.columns    for c in keep) else low_df.reindex(columns=keep)
volume_df = volume_df[keep] if all(c in volume_df.columns for c in keep) else volume_df.reindex(columns=keep)
open_df   = open_df[keep]   if all(c in open_df.columns   for c in keep) else open_df.reindex(columns=keep)
tickers   = keep

print(f"  Liquidity filter (ADV ≥ ₹{_MIN_ADV/1e7:.0f}cr, PIT head(63)): "
      f"kept {len(keep)}, dropped {_n_raw - len(keep)}")

master_idx = close_df.index.sort_values()
print(f"✓ Data ready: {len(master_idx)} trading days × {len(tickers)} liquid tickers\n")


# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║  STAGE 2 — PROVEN QUANT STRATEGIES  (baseline)                             ║
# ╚══════════════════════════════════════════════════════════════════════════════╝
print(f"{'═'*70}")
print("STAGE 2 — PROVEN QUANT STRATEGIES  (your honest baseline)")
print(f"{'═'*70}\n")

# ── Signal definitions ────────────────────────────────────────────────────────
def cs_zscore(df):
    """Cross-sectional z-score per date."""
    m = df.mean(axis=1); s = df.std(axis=1).replace(0, np.nan)
    return df.sub(m, axis=0).div(s, axis=0)

# 1. 12-1 Momentum (Jegadeesh-Titman 1993)
S_mom  = close_df.shift(21) / close_df.shift(252) - 1

# 2. Idiosyncratic low-vol (beta-adjusted, 63d window)
#    Removes systematic risk so we're not just picking low-beta stocks
print("Computing idiosyncratic low-vol...")
_ret_all = np.log(close_df / close_df.shift(1))
_br      = bench_ret.reindex(close_df.index, method="ffill").fillna(0)
_betas   = _ret_all.apply(
    lambda col: col.rolling(63).cov(_br) / _br.rolling(63).var().replace(0, np.nan)
)
_idio    = _ret_all.sub(_betas.multiply(_br, axis=0))
S_ivol   = -(_idio.rolling(63).std() * np.sqrt(252))   # high = low idio-vol = buy

# 3. 3-day reversal
S_rev  = -close_df.pct_change(3)

# 4. Volume-confirmed 6-month momentum
_mom126       = close_df.pct_change(126)
_vol_trend    = (volume_df.rolling(20).mean() /
                 volume_df.rolling(60).mean().replace(0, np.nan) - 1).clip(-0.5, 0.5).fillna(0)
S_vmom        = _mom126 * (1 + _vol_trend)

Z_mom  = cs_zscore(S_mom)
Z_ivol = cs_zscore(S_ivol)
Z_rev  = cs_zscore(S_rev)
Z_vmom = cs_zscore(S_vmom)
print("✓ Signals computed")

# ── Regime indicator (Nifty 21d realized vol) ─────────────────────────────────
_nifty_vol = bench_ret.rolling(21).std() * np.sqrt(252)
_v75, _v25 = _nifty_vol.quantile(0.75), _nifty_vol.quantile(0.25)
_regime    = (_nifty_vol - _v25).clip(0) / max(_v75 - _v25, 1e-6)  # 0=high vol, 1=low vol
_regime    = _regime.reindex(close_df.index, method="ffill").fillna(0.5)

# ── IC calibration on training period ────────────────────────────────────────
REBALANCE_DAYS = 21
TRAIN_YEARS    = 3
HOLDINGS       = 15
MAX_WEIGHT     = 0.10
FEE_BPS        = 10.0
STT_BPS_SELL   = 10.0
SLIPPAGE_BPS   = 10.0
QUANT_FWD_DAYS = 21

all_dates = close_df.index.sort_values()
# Only use dates from _start onward for the quant backtest split
_oos_start_idx = all_dates.searchsorted(pd.Timestamp(_start))
all_dates_bt   = all_dates[_oos_start_idx:]
cutoff         = all_dates_bt[int(len(all_dates_bt) * (TRAIN_YEARS / 5))]

print(f"\nCalibrating signal weights (training: {all_dates_bt[0].date()} → {cutoff.date()})...")
fwd_ret_all = close_df.shift(-QUANT_FWD_DAYS) / close_df - 1

ics = {}
DECAY_HL = 63   # exponential IC halflife (3 months)
for name, sig in [("momentum_12_1", Z_mom), ("idiosync_lowvol", Z_ivol),
                   ("reversal_3d", Z_rev), ("vol_momentum", Z_vmom)]:
    aligned = pd.DataFrame({
        "sig": sig.loc[:cutoff].stack(),
        "ret": fwd_ret_all.loc[:cutoff].stack()
    }).dropna()
    if len(aligned) > 100:
        ic_daily = aligned.groupby(level=0).apply(
            lambda g: g["sig"].corr(g["ret"], method="spearman") if len(g) > 5 else 0.0
        )
        n = len(ic_daily)
        decay_w = np.exp(-np.arange(n)[::-1] / DECAY_HL)
        decay_w /= decay_w.sum()
        ic_val = float(np.dot(ic_daily.values, decay_w)) if n > 0 else 0.0
        ics[name] = ic_val if np.isfinite(ic_val) else 0.0
    else:
        ics[name] = 0.0

signs   = {k: float(np.sign(v)) if abs(v) > 1e-4 else 1.0 for k, v in ics.items()}
abs_ics = {k: abs(v) for k, v in ics.items()}
total_ic = sum(abs_ics.values())
weights_q = ({k: abs_ics[k] / total_ic for k in ics} if total_ic > 1e-9
             else {k: 0.25 for k in ics})
print(f"  ICs (exp-decay): {ics}")
print(f"  Weights:         {weights_q}")

# Composite (regime-adaptive)
def _composite_at(dt):
    rs = float(_regime.get(dt, 0.5))
    return (
        weights_q["momentum_12_1"]  * (0.5 + 0.5*rs)       * signs["momentum_12_1"]  * Z_mom.loc[:dt].iloc[-1] +
        weights_q["idiosync_lowvol"]                         * signs["idiosync_lowvol"] * Z_ivol.loc[:dt].iloc[-1] +
        weights_q["reversal_3d"]    * (0.5 + 0.5*(1-rs))    * signs["reversal_3d"]    * Z_rev.loc[:dt].iloc[-1] +
        weights_q["vol_momentum"]   * (0.5 + 0.5*rs)        * signs["vol_momentum"]   * Z_vmom.loc[:dt].iloc[-1]
    ).dropna()

# ATR% for position sizing
_atr_pct = ((high_df - low_df) / close_df.replace(0, np.nan)).rolling(21).mean()

# ── OOS walk-forward backtest ─────────────────────────────────────────────────
print(f"\nOOS backtest ({cutoff.date()} → {all_dates_bt[-1].date()})...")
oos_dates       = [d for d in all_dates_bt if d > cutoff]
rebalance_dates = set(oos_dates[::REBALANCE_DAYS])
portfolio_rets  = []
equity_q        = [1.0]
holdings_hist   = []
cur_w           = {}
daily_ret       = close_df.pct_change().fillna(0)

for dt in oos_dates:
    tc_cost = 0.0
    if dt in rebalance_dates:
        scores = _composite_at(dt)
        if len(scores) < HOLDINGS:
            portfolio_rets.append(0.0); equity_q.append(equity_q[-1]); continue

        ranked = scores.sort_values(ascending=False)
        sel    = ranked.head(HOLDINGS).index.tolist()

        # ATR-normalized weights (risk parity)
        atr_now = _atr_pct.loc[:dt].iloc[-1].reindex(sel).fillna(0.02)
        inv_atr = (1 / atr_now.replace(0, np.nan)).fillna(0)
        raw_w   = (inv_atr / inv_atr.sum()) if inv_atr.sum() > 0 else pd.Series(1/len(sel), index=sel)
        raw_w   = raw_w.clip(upper=MAX_WEIGHT)
        raw_w   = raw_w / raw_w.sum()
        new_w   = {t: float(w) for t, w in raw_w.items()}

        # Asymmetric costs (STT on sells only — India)
        buys  = {t: max(0, new_w.get(t, 0) - cur_w.get(t, 0)) for t in set(new_w) | set(cur_w)}
        sells = {t: max(0, cur_w.get(t, 0)  - new_w.get(t, 0)) for t in set(new_w) | set(cur_w)}
        tc_cost = (sum(buys.values())  * (FEE_BPS + SLIPPAGE_BPS) / 10000 +
                   sum(sells.values()) * (FEE_BPS + STT_BPS_SELL + SLIPPAGE_BPS) / 10000)
        cur_w = new_w
        holdings_hist.append({
            "date": dt.strftime("%Y-%m-%d"),
            "rebalance": len(holdings_hist) + 1,
            "holdings": cur_w,
            "tc_cost_bps": tc_cost * 10000,
            "regime_score": float(_regime.get(dt, 0.5)),
        })

    pr = (sum(cur_w.get(t, 0) * float(daily_ret.loc[dt].get(t, 0)) for t in cur_w)
          if cur_w else 0.0)
    if dt in rebalance_dates: pr -= tc_cost
    portfolio_rets.append(pr)
    equity_q.append(equity_q[-1] * (1 + pr))

# ── Quant metrics ─────────────────────────────────────────────────────────────
pret_q   = pd.Series(portfolio_rets, index=oos_dates[:len(portfolio_rets)])
eq_q     = pd.Series(equity_q[1:], index=pret_q.index)
br_q     = bench_ret.reindex(pret_q.index).fillna(0)
bench_eq = (1 + br_q).cumprod()

q_ann    = pret_q.mean() * 252
q_vol    = pret_q.std()  * np.sqrt(252)
q_sharpe = (q_ann - 0.07) / q_vol if q_vol > 0 else 0.0
q_maxdd  = float((eq_q / eq_q.cummax() - 1).min())
q_beta   = pret_q.cov(br_q) / br_q.var() if br_q.var() > 0 else 0.0
q_alpha  = (pret_q - q_beta * br_q).mean() * 252
q_mn_ret = pret_q - q_beta * br_q
q_mn_sh  = q_mn_ret.mean() * 252 / (q_mn_ret.std() * np.sqrt(252)) if q_mn_ret.std() > 0 else 0.0
q_hit    = float((pret_q > 0).mean())
q_bench_ann = br_q.mean() * 252
q_bench_vol = br_q.std()  * np.sqrt(252)
q_bench_sh  = (q_bench_ann - 0.07) / q_bench_vol if q_bench_vol > 0 else 0.0

print(f"\n── Quant Results ──")
print(f"  Annual Return:   {q_ann*100:+.2f}%  (Benchmark: {q_bench_ann*100:+.2f}%)")
print(f"  Sharpe (gross):  {q_sharpe:+.2f}   Sharpe (mkt-neutral): {q_mn_sh:+.2f}")
print(f"  Alpha:           {q_alpha*100:+.2f}%  Beta: {q_beta:.2f}  MaxDD: {q_maxdd*100:.2f}%")
print(f"  Hit rate:        {q_hit*100:.1f}%")

# Save quant equity curve
OUTPUT_DIR = "/kaggle/working"
os.makedirs(OUTPUT_DIR, exist_ok=True)

_eq_quant_df = pd.DataFrame({
    "portfolio": eq_q,
    "benchmark": bench_eq,
    "market_neutral": (1 + q_mn_ret).cumprod(),
})
_eq_quant_df.to_csv(os.path.join(OUTPUT_DIR, "equity_curve_quant.csv"))

_rows_q = []
for h in holdings_hist:
    for t, w in h["holdings"].items():
        _rows_q.append({"date": h["date"], "rebalance": h["rebalance"],
                        "ticker": t, "weight": w,
                        "regime_score": h.get("regime_score", 0)})
pd.DataFrame(_rows_q).to_csv(os.path.join(OUTPUT_DIR, "portfolio_holdings.csv"), index=False)

_quant_results = {
    "pipeline": "Proven Quant Strategies",
    "strategies": "12-1 momentum + idiosyncratic low-vol + 3d reversal + vol momentum",
    "oos_period": f"{pret_q.index[0].date()} → {pret_q.index[-1].date()}",
    "n_rebalances": len(holdings_hist),
    "annual_return_pct": float(q_ann * 100),
    "benchmark_return_pct": float(q_bench_ann * 100),
    "alpha_pct": float(q_alpha * 100),
    "sharpe": float(q_sharpe),
    "sharpe_market_neutral": float(q_mn_sh),
    "benchmark_sharpe": float(q_bench_sh),
    "beta": float(q_beta),
    "max_drawdown_pct": float(q_maxdd * 100),
    "hit_rate_pct": float(q_hit * 100),
    "signal_ics": ics,
    "signal_weights": weights_q,
}
with open(os.path.join(OUTPUT_DIR, "backtest_results.json"), "w") as f:
    json.dump(_quant_results, f, indent=2, default=str)
print("✓ Quant results saved\n")


# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║  STAGE 3 — ML ALPHA  (100+ factors, 5-model ensemble)                      ║
# ╚══════════════════════════════════════════════════════════════════════════════╝
print(f"{'═'*70}")
print("STAGE 3 — ML ALPHA  (100+ vectorised factors, CPCV, NNLS stacking)")
print(f"{'═'*70}\n")

# ── 3a. Dynamic Vectorised Factor Library ─────────────────────────────────────
# We dynamically parameterize base calculations to produce 200+ features.
def _sdiv(a, b): return a / b.where(b != 0, other=np.nan)

def compute_dynamic_momentum(c, w): return c / c.shift(w) - 1.0
def compute_dynamic_vol(c, w): return c.pct_change().rolling(w).std() * np.sqrt(252)
def compute_dynamic_breakout(c, w): return _sdiv(c, c.shift(1).rolling(w).max())
def compute_dynamic_dd(c, w): return 1.0 - _sdiv(c, c.rolling(w).max())
def compute_dynamic_amihud(c, v, w): return _sdiv(c.pct_change().abs(), (v * c)).rolling(w).mean()
def compute_dynamic_obv_slope(c, v, w):
    obv = (np.sign(c.diff()).fillna(0) * v).cumsum()
    return _sdiv(obv.diff(w), v.rolling(w).mean())
def compute_dynamic_overnight(c, o, w): return (o / c.shift(1) - 1.0).rolling(w).mean()
def compute_dynamic_intraday(c, o, w): return (c / o - 1.0).rolling(w).mean()
def compute_dynamic_parkinson(h, l, w):
    lhl = np.log(_sdiv(h, l))
    return (lhl**2 / (4 * np.log(2))).rolling(w).mean() * 252
def compute_dynamic_vwap_dist(c, h, l, v, w):
    typ = (h + l + c) / 3.0
    vwap = _sdiv((typ * v).rolling(w).sum(), v.rolling(w).sum())
    return (c - vwap) / vwap * 100.0
def compute_dynamic_close2mid(c, h, l, w):
    rng = (h - l).where((h - l) != 0, other=np.nan)
    return ((c - l) / rng).rolling(w).mean() - 0.5

_WINDOWS_MOM  = [5, 10, 21, 42, 63, 126, 252]
_WINDOWS_VOL  = [10, 21, 42, 63, 126, 252]
_WINDOWS_TECH = [10, 21, 63, 126]
_STALE_SUBS   = ["lot_measure", "zero_ret", "vol_conc_hhi"]

factor_panels = {}
_h = high_df.reindex(columns=tickers) if high_df is not None else None
_l = low_df.reindex(columns=tickers) if low_df is not None else None
_v = volume_df.reindex(columns=tickers) if volume_df is not None else None
_o = open_df.reindex(columns=tickers) if open_df is not None else None

print("Dynamically computing 200+ parameterized factors...")
for w in _WINDOWS_MOM:
    factor_panels[f"mom_{w}"] = compute_dynamic_momentum(close_df, w).reindex(master_idx)
    factor_panels[f"breakout_{w}"] = compute_dynamic_breakout(close_df, w).reindex(master_idx)
for w in _WINDOWS_VOL:
    factor_panels[f"vol_{w}"] = compute_dynamic_vol(close_df, w).reindex(master_idx)
    factor_panels[f"maxdd_{w}"] = compute_dynamic_dd(close_df, w).reindex(master_idx)
    if _h is not None and _l is not None:
        factor_panels[f"parkinson_{w}"] = compute_dynamic_parkinson(_h, _l, w).reindex(master_idx)
for w in _WINDOWS_TECH:
    if _v is not None:
        factor_panels[f"amihud_{w}"] = compute_dynamic_amihud(close_df, _v, w).reindex(master_idx)
        factor_panels[f"obv_slope_{w}"] = compute_dynamic_obv_slope(close_df, _v, w).reindex(master_idx)
        factor_panels[f"vol_trend_{w}"] = (_v.rolling(w // 2 + 1).mean() / _v.rolling(w * 2 + 1).mean() - 1.0).reindex(master_idx)
    if _o is not None:
        factor_panels[f"overnight_{w}"] = compute_dynamic_overnight(close_df, _o, w).reindex(master_idx)
        factor_panels[f"intraday_{w}"] = compute_dynamic_intraday(close_df, _o, w).reindex(master_idx)
        factor_panels[f"oi_spread_{w}"] = (compute_dynamic_overnight(close_df, _o, w) - compute_dynamic_intraday(close_df, _o, w)).reindex(master_idx)

def f_rsi14(c):
    d = c.diff(); g = d.clip(lower=0).ewm(alpha=1/14, min_periods=14, adjust=False).mean()
    l = (-d.clip(upper=0)).ewm(alpha=1/14, min_periods=14, adjust=False).mean()
    return 100.0 - 100.0 / (1.0 + _sdiv(g, l))
def f_macd(c):
    h = c.ewm(span=12, adjust=False).mean() - c.ewm(span=26, adjust=False).mean()
    return _sdiv((h - h.ewm(span=9, adjust=False).mean()), c) * 100.0
factor_panels["rsi_14"] = f_rsi14(close_df).reindex(master_idx)
factor_panels["macd_hist"] = f_macd(close_df).reindex(master_idx)
for w in [21, 63]:
    if _h is not None and _l is not None:
        factor_panels[f"close2mid_{w}"] = compute_dynamic_close2mid(close_df, _h, _l, w).reindex(master_idx)
        if _v is not None:
            factor_panels[f"vwap_dist_{w}"] = compute_dynamic_vwap_dist(close_df, _h, _l, _v, w).reindex(master_idx)

# ── 3c. Point-in-time fundamentals ────────────────────────────────────────────
_REPORT_LAG = 75
_MAX_STALE  = 200
def _find_row(df, aliases):
    if df is None or df.empty: return None
    ilow = {str(i).lower().replace(" ", ""): i for i in df.index}
    for a in aliases:
        k = a.lower().replace(" ", "")
        for ik, orig in ilow.items():
            if k in ik: return df.loc[orig]
    return None

def _fetch_fund_pit(ticker, idx):
    try:
        import yfinance as _yf
        t  = _yf.Ticker(ticker)
        qf = t.quarterly_financials
        qb = t.quarterly_balance_sheet
        if qf is None or qf.empty or qb is None or qb.empty: return {}
        rev = _find_row(qf, ["Total Revenue", "TotalRevenue", "Revenue"])
        ni  = _find_row(qf, ["Net Income", "NetIncome"])
        eq  = _find_row(qb, ["Stockholders Equity", "Total Stockholder Equity", "Total Equity Gross Minority Interest"])
        dbt = _find_row(qb, ["Total Debt", "TotalDebt"])
        if rev is None or ni is None: return {}
        periods = sorted(rev.index)
        ratios  = {"fund_roe": {}, "fund_de": {}, "fund_margin": {}, "fund_rev_g": {}, "fund_ni_g": {}}
        for i, pe in enumerate(periods):
            avail = pd.Timestamp(pe) + pd.Timedelta(days=_REPORT_LAG)
            rv, ni_v = rev.get(pe), ni.get(pe)
            eq_v, dbt_v = eq.get(pe), dbt.get(pe)
            if rv and rv != 0 and ni_v is not None: ratios["fund_margin"][avail] = ni_v / rv
            if eq_v and eq_v != 0:
                if ni_v is not None: ratios["fund_roe"][avail] = ni_v / eq_v
                if dbt_v is not None: ratios["fund_de"][avail]  = dbt_v / eq_v
            if i >= 4:
                pp = periods[i-4]
                rv_p, ni_p = rev.get(pp), ni.get(pp)
                if rv is not None and rv_p and rv_p != 0: ratios["fund_rev_g"][avail] = (rv - rv_p) / abs(rv_p)
                if ni_v is not None and ni_p and ni_p != 0: ratios["fund_ni_g"][avail] = (ni_v - ni_p) / abs(ni_p)
        out = {}
        for rn, vals in ratios.items():
            if not vals: continue
            s = pd.Series(vals).sort_index()
            ri = s.reindex(idx, method="ffill")
            ds = pd.Series(idx, index=idx).apply(lambda d: (d - s.index[s.index<=d].max()).days if (s.index<=d).any() else 10**9)
            ri[ds > _MAX_STALE] = float("nan")
            out[rn] = ri
        return out
    except Exception: return {}

print("Fetching PIT fundamentals (75d reporting lag)...")
_fund_acc = {k: {} for k in ["fund_roe","fund_de","fund_margin","fund_rev_g","fund_ni_g"]}
_fund_n   = 0
for _i, _t in enumerate(tickers):
    _res = _fetch_fund_pit(_t, master_idx)
    if _res:
        _fund_n += 1
        for _rn, _ser in _res.items(): _fund_acc[_rn][_t] = _ser
for _rn, _cols in _fund_acc.items():
    if _cols: factor_panels[_rn] = pd.DataFrame(_cols).reindex(master_idx)
_dropped = [f for f in list(factor_panels) if any(s in f for s in _STALE_SUBS)]
for f in _dropped: del factor_panels[f]

# ── 3d. Dynamic rank transforms ──────────────────────────────────────────────
print("Generating rank versions of all factors...")
for _fn, _df in list(factor_panels.items()):
    if isinstance(_df, pd.DataFrame) and not _df.empty:
        factor_panels[f"{_fn}_rank"] = _df.rank(axis=1, pct=True)
print(f"  Total factors generated: {len(factor_panels)}")

# ── 3e. Preprocess ────────────────────────────────────────────────────────────
print("Preprocessing (cross-sectional winsorise + z-score)...")
_MIN_CS = 30
processed = {}
for _fn, _df in factor_panels.items():
    if not isinstance(_df, pd.DataFrame) or _df.empty: continue
    def _win(row):
        v = row.dropna()
        return row.clip(v.quantile(0.01), v.quantile(0.99)) if len(v) >= _MIN_CS else row
    def _zsc(row):
        v = row.dropna()
        if len(v) < _MIN_CS: return row
        std = v.std()
        return (row - v.mean()) / std if np.isfinite(std) and std > 1e-9 else row * 0.0
    try:
        processed[_fn] = _df.apply(_win, axis=1).apply(_zsc, axis=1).fillna(0.0)
    except Exception: processed[_fn] = _df.fillna(0.0)

# ── 3f. Training dataset + target ─────────────────────────────────────────────
print("Building training dataset (triple-barrier labels)...")
ML_FWD = 21; ML_REB = 5
vol_df   = compute_daily_volatility(close_df, span=100)
tb_labs  = triple_barrier_labels(close_df, vol_df, upper_mult=2.0, lower_mult=1.0, max_holding_days=ML_FWD)
if tb_labs.empty or tb_labs.isna().all().all():
    fwd_s  = (close_df.shift(-ML_FWD) / close_df - 1).stack(); fwd_s.name = "forward_return"
    tb_s   = pd.Series(0, index=fwd_s.index, name="tb_label")
else:
    fwd_s, tb_s = labels_to_forward_returns(tb_labs, close_df, ML_FWD)
    fwd_s.name = "forward_return"; tb_s.name = "tb_label"
feat_series = {f: processed[f].stack() for f in processed if isinstance(processed[f], pd.DataFrame)}
df_ml = pd.concat([fwd_s, tb_s] + list(feat_series.values()), axis=1).dropna(subset=["forward_return"])
feat_cols = [c for c in df_ml.columns if c not in ("forward_return","tb_label")]
df_ml["forward_return"] = df_ml.groupby(level=0)["forward_return"].transform(lambda g: g.clip(g.quantile(0.01), g.quantile(0.99)))
df_ml["forward_return"] = df_ml.groupby(level=0)["forward_return"].rank(pct=True) - 0.5
_all_dt = df_ml.index.get_level_values(0).unique().sort_values()
if len(_all_dt) > 252: df_ml = df_ml.loc[df_ml.index.get_level_values(0) >= _all_dt[252]]
df_ml = df_ml.loc[df_ml.index.get_level_values(0).isin(_all_dt[::ML_REB])]

# ── 3g. Dynamic Feature Selection ─────────────────────────────────────────────
print("\nDynamic Feature Selection (IC + LassoCV path)...")
try:
    sel_feats, ic_stats = select_factors(
        {f: processed[f] for f in feat_cols if f in processed},
        df_ml["forward_return"], df_ml[feat_cols], df_ml["forward_return"],
        ic_threshold=0.01, min_features=10,
    )
    print(f"  Selected {len(sel_feats)}/{len(feat_cols)} features dynamically")
    for _fn, _st in sorted(ic_stats.items(), key=lambda x: -abs(x[1].get("mean_ic",0)))[:15]:
        if _fn in sel_feats:
            print(f"    ✓ {_fn:35s} IC={_st['mean_ic']:+.4f}")
except Exception as _fse:
    print(f"  Dynamic selection failed ({_fse}) — using fallback list")
    sel_feats = feat_cols[:30] if len(feat_cols) > 30 else feat_cols

# ── 3h. Inline ensemble ───────────────────────────────────────────────────────
import platform as _pl
_is_arm = (_pl.system() == "Darwin" and _pl.machine() == "arm64")
_HAS_LGB = _HAS_CB = _HAS_SK = _HAS_TORCH = False
try:
    from sklearn.linear_model import Ridge as _Ridge, LogisticRegression as _LR
    from sklearn.ensemble import RandomForestRegressor as _RF
    _HAS_SK = True
except ImportError: pass
if not _is_arm:
    try: import lightgbm as _lgb; _HAS_LGB = True
    except ImportError: pass
    try: import catboost as _cb; _HAS_CB = True
    except ImportError: pass
try:
    import torch as _torch, torch.nn as _nn, torch.optim as _opt
    from torch.utils.data import DataLoader as _DL, TensorDataset as _TDS
    _HAS_TORCH = True
except ImportError: pass

class _MLP(_nn.Module):
    def __init__(self, d, h=128, dr=0.4):
        super().__init__()
        self.net = _nn.Sequential(
            _nn.Linear(d,h),    _nn.BatchNorm1d(h),    _nn.ReLU(), _nn.Dropout(dr),
            _nn.Linear(h,h//2), _nn.BatchNorm1d(h//2), _nn.ReLU(), _nn.Dropout(dr),
            _nn.Linear(h//2,1),
        )
    def forward(self, x): return self.net(x).squeeze(-1)

class _MLPWrap:
    def __init__(self, d, h=128, dr=0.4, lr=1e-3, ep=30, bs=512):
        self.d=d; self.h=h; self.dr=dr; self.lr=lr; self.ep=ep; self.bs=bs
        self.dev = "cuda" if _HAS_TORCH and _torch.cuda.is_available() else "cpu"
        self.m = None
    def fit(self, X, y):
        self.m = _MLP(self.d, self.h, self.dr).to(self.dev)
        opt  = _opt.Adam(self.m.parameters(), lr=self.lr, weight_decay=1e-3)
        crit = _nn.MSELoss()
        Xt = _torch.FloatTensor(X).to(self.dev)
        yt = _torch.FloatTensor(y).to(self.dev)
        # drop_last=True: BatchNorm1d crashes on batch of 1
        ldr = _DL(_TDS(Xt, yt), batch_size=self.bs, shuffle=True, drop_last=True)
        self.m.train()
        for _ in range(self.ep):
            for bx, by in ldr:
                opt.zero_grad(); crit(self.m(bx), by).backward(); opt.step()
        return self
    def predict(self, X):
        self.m.eval()
        with _torch.no_grad():
            return self.m(_torch.FloatTensor(X).to(self.dev)).cpu().numpy()

class Ensemble:
    """Ridge + LGB LambdaRank + CB YetiRank + MLP with NNLS stacking.

    Random Forest deliberately excluded: RF optimises absolute MSE and
    memorises return levels rather than learning relative ordering.
    In CPCV, its OOF predictions look artificially good (NNLS hands it
    67–99% weight), but it collapses OOS. Ranking-loss models (LGB/CB)
    are structurally immune to this because they never predict absolute
    values — only pairwise rank relationships.
    """
    def __init__(self, fwd=21, nsf=5):
        self.fwd=max(1,int(fwd)); self.nsf=max(2,min(int(nsf),5))
        self._models={}; self._fnames=[]; self._bmn=[]; self._sw={}; self._meta=None

    def _splits(self, n):
        fs=n//self.nsf; pg=self.fwd; splits=[]
        for i in range(self.nsf):
            vs=i*fs; ve=(i+1)*fs if i<self.nsf-1 else n
            vi=np.arange(vs,ve)
            ti=np.concatenate([np.arange(0,max(0,vs-pg)), np.arange(min(n,ve+pg),n)])
            if len(ti)>50 and len(vi)>10: splits.append((ti,vi))
        return splits

    def _build(self, name, dim):
        if name=="ridge": return _Ridge(alpha=1.0)
        if name=="lgbm"  and _HAS_LGB:
            return _lgb.LGBMRanker(n_estimators=200,learning_rate=0.02,num_leaves=12,
                max_depth=4,min_child_samples=100,subsample=0.7,colsample_bytree=0.6,
                reg_alpha=1.5,reg_lambda=10.0,random_state=42,verbosity=-1,objective="lambdarank")
        if name=="catboost" and _HAS_CB:
            return _cb.CatBoostRanker(iterations=200,learning_rate=0.02,depth=4,
                l2_leaf_reg=10.0,random_seed=42,verbose=0,loss_function="YetiRank")
        # RF deliberately excluded from ensemble — kept here only as fallback
        # if name=="rf" and _HAS_SK:
        #     return _RF(n_estimators=100,max_depth=6,min_samples_leaf=100,
        #                max_features="sqrt",random_state=42,n_jobs=-1)
        if name=="mlp" and _HAS_TORCH and dim>0:
            return _MLPWrap(dim)
        return None

    def _fit_rank(self, m, name, X, y, dates):
        try:
            if dates is None: return False
            ud, inv = np.unique(dates, return_inverse=True)
            if len(ud)<5: return False
            yi = np.zeros(len(y), dtype=int)
            for g in range(len(ud)):
                gm = inv==g
                if gm.sum()<10: continue
                try: yi[gm] = pd.qcut(y[gm], 10, labels=False, duplicates="drop")
                except Exception: yi[gm] = np.clip((pd.Series(y[gm]).rank(pct=True)*10).astype(int),0,9)
            if name=="lgbm":
                si=np.argsort(inv); m.fit(X[si],yi[si],group=np.bincount(inv[si]).tolist()); return True
            elif name=="catboost":
                m.fit(X,yi,group_id=inv); return True
        except Exception as e:
            print(f"  ⚠ Rank fit {name}: {e}")
        return False

    def fit(self, X, y, meta_labels=None):
        Xc=X.fillna(0.0); ya=y.to_numpy(float); mask=~np.isnan(ya)
        Xc=Xc.loc[mask]; ya=ya[mask]
        dates=(Xc.index.get_level_values(0).to_numpy()
               if isinstance(Xc.index,pd.MultiIndex) else None)
        self._fnames=list(Xc.columns); Xa=Xc.to_numpy(float); n=len(ya); dim=Xa.shape[1]
        bmn=["ridge"]
        if _HAS_LGB: bmn.append("lgbm")
        if _HAS_CB:  bmn.append("catboost")
        # RF deliberately excluded — see class docstring
        if _HAS_TORCH: bmn.append("mlp")
        self._bmn=bmn

        oof={}
        if _HAS_SK and n>200:
            try:
                splits=self._splits(n); om=np.full((n,len(bmn)),np.nan)
                for _,(ti,vi) in enumerate(splits):
                    Xtr,Xv=Xa[ti],Xa[vi]; ytr=ya[ti]; dtr=dates[ti] if dates is not None else None
                    if len(Xtr)<50: continue
                    for mi,mn in enumerate(bmn):
                        try:
                            m=self._build(mn,dim=dim)
                            if m is None: continue
                            if mn in ("lgbm","catboost"):
                                if self._fit_rank(m,mn,Xtr,ytr,dtr): om[vi,mi]=m.predict(Xv)
                            else: m.fit(Xtr,ytr); om[vi,mi]=m.predict(Xv)
                        except: pass
                for mi,mn in enumerate(bmn): oof[mn]=om[:,mi]
            except: pass

        fitted=[]
        for mn in bmn:
            try:
                m=self._build(mn,dim=dim)
                if m is None: continue
                if mn in ("lgbm","catboost"):
                    if self._fit_rank(m,mn,Xa,ya,dates): self._models[mn]=m; fitted.append(mn)
                else: m.fit(Xa,ya); self._models[mn]=m; fitted.append(mn)
            except: pass

        if oof and len(fitted)>=2 and _HAS_SK:
            try:
                from scipy.optimize import nnls
                oa=np.column_stack([oof[m] for m in fitted])
                vm=~np.any(np.isnan(oa),axis=1)
                if vm.sum()>100:
                    w,_=nnls(oa[vm],ya[vm]); ws=w.sum()
                    if ws>1e-9: w=w/ws
                    else:
                        # IC-proportional fallback (not equal weight)
                        _ic_w=[]
                        for mn in fitted:
                            if mn in oof and np.isfinite(oof[mn]).any():
                                vld=~np.isnan(oof[mn])&~np.isnan(ya)
                                _ic_w.append(max(0.0, float(np.corrcoef(oof[mn][vld],ya[vld])[0,1]))
                                             if vld.sum()>10 else 0.0)
                            else: _ic_w.append(0.0)
                        t=sum(_ic_w); w=np.array(_ic_w)/t if t>1e-9 else np.ones(len(fitted))/len(fitted)
                    self._sw=dict(zip(fitted, w.round(4)))
                    print(f"  NNLS stacking weights: {self._sw}")
            except Exception as _se:
                print(f"  ⚠ Stacking failed ({_se})")

        if meta_labels is not None and _HAS_SK:
            try:
                ml=meta_labels.loc[mask].to_numpy(float); v=ml!=0
                if v.sum()>50: self._meta=_LR(max_iter=500); self._meta.fit(Xa[v],ml[v])
            except: pass
        return {"fitted":fitted,"stacking":bool(self._sw)}

    def predict(self, X):
        Xc=X.fillna(0.0); Xa=Xc.to_numpy(float); bp={}
        for mn,m in self._models.items():
            try:
                p=m.predict(Xa)
                if len(p)==len(Xc): bp[mn]=p
            except: pass
        if not bp: return pd.Series(0.0,index=Xc.index)
        if self._sw and len(bp)>=2:
            try:
                ac={m:w for m,w in self._sw.items() if m in bp}; ws=sum(ac.values())
                ap=sum(bp[m]*(w/ws) for m,w in ac.items()) if ws>1e-9 else np.mean(list(bp.values()),axis=0)
            except: ap=np.mean(list(bp.values()),axis=0)
        else: ap=np.mean(list(bp.values()),axis=0)
        if self._meta is not None:
            try:
                mp=self._meta.predict_proba(Xa)
                if 1.0 in self._meta.classes_.tolist():
                    ap=ap*(0.5+mp[:,list(self._meta.classes_).index(1.0)])
            except: pass
        return pd.Series(ap,index=Xc.index)

    def feature_importance(self):
        imp={}; c=0
        for mn in ("lgbm","catboost","rf"):
            if mn not in self._models: continue
            m=self._models[mn]
            if hasattr(m,"feature_importances_"):
                fi=m.feature_importances_
                if len(fi)==len(self._fnames):
                    for fn,v in zip(self._fnames,fi): imp[fn]=imp.get(fn,0)+v; c+=1
        if c>0 and imp:
            t=sum(imp.values())
            if t>0: imp={k:v/t for k,v in imp.items()}
        return imp

    def stacking_weights(self): return dict(self._sw)

print(f"✓ Ensemble: Ridge{' + LGB LambdaRank' if _HAS_LGB else ''}"
      f"{' + CB YetiRank' if _HAS_CB else ''} + RF{' + MLP' if _HAS_TORCH else ''} (NNLS)")

# ── 3i. CPCV ──────────────────────────────────────────────────────────────────
print(f"\nRunning CPCV (6 groups, 2 test → 15 paths)...")
cv = CombinatorialPurgedCV(
    n_groups=6, n_test_groups=2,
    purge_window_days=ML_FWD + 4,
    forward_return_days=ML_FWD,
)

unique_dates_ml = pd.DatetimeIndex(sorted(df_ml.index.get_level_values(0).unique()))
per_fold        = []
is_sharpes, oos_sharpes = [], []
all_oos_ls      = []

for fold in cv.split(unique_dates_ml):
    _fid = getattr(fold, "path_id", getattr(fold, "fold_id", 0))
    tr_m = df_ml.index.get_level_values(0).isin(fold.train_idx)
    te_m = df_ml.index.get_level_values(0).isin(fold.test_idx)
    tr   = df_ml[tr_m]; te = df_ml[te_m]
    if len(tr)<100 or len(te)<10: continue

    try:
        ff, _ = select_factors(
            {f: processed[f] for f in feat_cols if f in processed},
            tr["forward_return"], tr[feat_cols], tr["forward_return"],
            ic_threshold=0.01, min_features=10,
        )
    except Exception:
        ff = sel_feats

    try:
        m = Ensemble(fwd=ML_FWD)
        m.fit(tr[ff], tr["forward_return"], meta_labels=tr.get("tb_label"))
    except Exception as _e:
        print(f"  ⚠ Fold {_fid} failed ({_e}) — Ridge fallback")
        from ml_alpha.model import AlphaEnsemble
        m = AlphaEnsemble(model_type="blend"); m.fit(tr[ff], tr["forward_return"])

    is_p  = pd.Series(m.predict(tr[ff]).values, index=tr.index)
    oos_p = pd.Series(m.predict(te[ff]).values, index=te.index)
    is_ic   = spearman_ic(is_p.values,  tr["forward_return"].values)
    oos_ic  = spearman_ic(oos_p.values, te["forward_return"].values)
    is_sh,  _   = quantile_sharpe(is_p,  tr["forward_return_raw"], ML_FWD)
    oos_sh, ols = quantile_sharpe(oos_p, te["forward_return_raw"], ML_FWD)
    if len(ols)>0: all_oos_ls.append(ols)
    is_sharpes.append(is_sh); oos_sharpes.append(oos_sh)
    per_fold.append({"fold_id":_fid,"train_size":len(tr),"test_size":len(te),
                     "is_ic":is_ic,"oos_ic":oos_ic,"is_sharpe":is_sh,"oos_sharpe":oos_sh})
    print(f"  Path {_fid:2d}: IS_IC={is_ic:+.4f}  OOS_IC={oos_ic:+.4f}  "
          f"IS_Sh={is_sh:+.2f}  OOS_Sh={oos_sh:+.2f}")

# ── 3j. DSR ───────────────────────────────────────────────────────────────────
ml_is_mean  = float(np.mean(is_sharpes))  if is_sharpes  else 0.0
ml_oos_mean = float(np.mean(oos_sharpes)) if oos_sharpes else 0.0
wf_eff      = walk_forward_efficiency(is_sharpes, oos_sharpes)
n_trials    = max(1, len(feat_cols) * len(per_fold))

all_ls = pd.concat(all_oos_ls) if all_oos_ls else pd.Series(dtype=float)
_n_raw = len(all_ls)
_u_dt  = (all_ls.index.get_level_values(0).nunique()
           if isinstance(all_ls.index, pd.MultiIndex) and _n_raw > 0
           else all_ls.index.nunique() if _n_raw > 0 else 0)

if len(all_ls)>10 and all_ls.std()>1e-9:
    skew  = float(np.clip(all_ls.skew()     if np.isfinite(all_ls.skew())    else 0.0, -1.5, 1.5))
    kurt  = float(np.clip(all_ls.kurtosis()+3 if np.isfinite(all_ls.kurtosis()) else 3.0, 2.5, 8.0))
    slen  = _u_dt
else:
    skew=0.0; kurt=3.0; slen=252

dsr = deflated_sharpe_ratio(observed_sharpe=ml_oos_mean, n_trials=n_trials,
                             sample_length=slen, skewness=skew,
                             kurtosis=kurt, holding_days=ML_FWD)
if not np.isfinite(dsr): dsr=0.0

# ── 3k. Final model ───────────────────────────────────────────────────────────
print("\nRetraining final model on all data...")
try:
    final_model = Ensemble(fwd=ML_FWD)
    final_model.fit(df_ml[sel_feats], df_ml["forward_return"], meta_labels=df_ml.get("tb_label"))
except Exception:
    from ml_alpha.model import AlphaEnsemble
    final_model = AlphaEnsemble(model_type="blend")
    final_model.fit(df_ml[sel_feats], df_ml["forward_return"])

fi = final_model.feature_importance() if hasattr(final_model,"feature_importance") else {}

print(f"\n── ML Results ──")
print(f"  IS  Sharpe:  {ml_is_mean:+.2f} ± {float(np.std(is_sharpes)):.2f}")
print(f"  OOS Sharpe:  {ml_oos_mean:+.2f} ± {float(np.std(oos_sharpes)):.2f}")
print(f"  WF Eff:      {wf_eff:.1%}")
print(f"  DSR:         {dsr:.4f}  (n_trials={n_trials})")
print(f"  Features:    {len(sel_feats)} selected from {len(feat_cols)}")

# Save ML model
model_path = os.path.join(OUTPUT_DIR, "ml_alpha_model.pkl")
with open(model_path, "wb") as f:
    pickle.dump({"feature_names": sel_feats, "fitted_model": final_model}, f)

_ml_results = {
    "pipeline": "ML Alpha (100+ factors)",
    "is_sharpe_mean": ml_is_mean, "is_sharpe_std": float(np.std(is_sharpes)),
    "oos_sharpe_mean": ml_oos_mean, "oos_sharpe_std": float(np.std(oos_sharpes)),
    "walk_forward_efficiency": wf_eff,
    "deflated_sharpe": dsr, "n_trials": n_trials,
    "n_features": len(sel_feats), "feature_importance": fi,
    "per_fold_metrics": per_fold,
    "stacking_weights": final_model.stacking_weights() if hasattr(final_model,"stacking_weights") else {},
}
with open(os.path.join(OUTPUT_DIR, "fit_result.json"), "w") as f:
    json.dump(_ml_results, f, indent=2, default=str)
print("✓ ML model + metrics saved\n")


# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║  STAGE 4 — COMPARISON                                                       ║
# ╚══════════════════════════════════════════════════════════════════════════════╝
print(f"{'═'*70}")
print("STAGE 4 — COMPARISON: Quant vs ML")
print(f"{'═'*70}\n")

_ml_sharpe = ml_oos_mean
_q_sharpe  = q_sharpe

print(f"{'Metric':<30} {'Quant Strategies':>20} {'ML Alpha':>20}")
print("─" * 72)
print(f"{'OOS Sharpe':<30} {_q_sharpe:>20.2f} {_ml_sharpe:>20.2f}")
print(f"{'Market-Neutral Sharpe':<30} {q_mn_sh:>20.2f} {'N/A (L-S proxy)':>20}")
print(f"{'Annual Return':<30} {q_ann*100:>19.2f}% {ml_oos_mean*0.15*100:>19.1f}% est")
print(f"{'Alpha vs Nifty':<30} {q_alpha*100:>19.2f}% {'N/A':>20}")
print(f"{'Max Drawdown':<30} {q_maxdd*100:>19.2f}% {'N/A':>20}")
print(f"{'DSR':<30} {'N/A':>20} {dsr:>20.4f}")
print(f"{'WF Efficiency':<30} {'N/A':>20} {wf_eff:>19.1%}")

print()
if _q_sharpe > _ml_sharpe + 0.2:
    verdict = ("QUANT WINS: Use quant strategies as primary signal. "
               "The ML model is not adding sufficient edge beyond what simple quant factors provide. "
               "Consider: add ML as a secondary confirmation layer or wait for more data.")
    deploy = "quant"
elif _ml_sharpe > _q_sharpe + 0.2:
    verdict = ("ML WINS: Use ml_alpha_model.pkl. "
               "The ML ensemble is extracting cross-factor information beyond simple quant signals. "
               "Copy ml_alpha_model.pkl → QuantumAnnealer/models/")
    deploy  = "ml"
elif dsr < 0.5:
    verdict = ("QUANT WINS BY DEFAULT: ML OOS Sharpe is inconclusive (DSR < 0.5) — "
               "we can't be confident it has real edge after accounting for the factor search width. "
               "Quant strategies have academic backing and don't require this test.")
    deploy  = "quant"
else:
    verdict = ("BLEND BOTH: Sharpes are within 0.2 of each other. "
               "Run both in production and equal-weight blend their signals "
               "— diversification will reduce drawdowns without sacrificing Sharpe. "
               "If ML DSR > 0.95, weight it 60%; otherwise equal weight.")
    deploy  = "blend"

print(f"VERDICT: {verdict}\n")

comparison = {
    "quant": {
        "sharpe_gross":          float(_q_sharpe),
        "sharpe_market_neutral": float(q_mn_sh),
        "alpha_pct":             float(q_alpha*100),
        "max_drawdown_pct":      float(q_maxdd*100),
        "beta":                  float(q_beta),
    },
    "ml": {
        "oos_sharpe":            float(_ml_sharpe),
        "deflated_sharpe":       float(dsr),
        "walk_forward_eff":      float(wf_eff),
        "n_features":            len(sel_feats),
    },
    "recommendation": {
        "deploy": deploy,
        "verdict": verdict,
    }
}
with open(os.path.join(OUTPUT_DIR, "comparison.json"), "w") as f:
    json.dump(comparison, f, indent=2, default=str)

print("✅ All outputs saved to /kaggle/working/:")
print("   ml_alpha_model.pkl      ← copy to QuantumAnnealer/models/ if ML wins")
print("   fit_result.json         ← ML metrics")
print("   backtest_results.json   ← Quant metrics")
print("   equity_curve_quant.csv  ← Quant equity curve")
print("   portfolio_holdings.csv  ← Quant holdings history")
print("   comparison.json         ← Head-to-head verdict")
