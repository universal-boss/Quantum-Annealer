"""
kaggle_e2e_pipeline.py — END-TO-END: Screen → ML → Optimizer Backtest
=====================================================================
Runs the FULL pipeline on Kaggle:
  1. SCREEN: Fetch Nifty 500 universe, prescreen liquidity (top 100-150)
  2. ML: Train 6-model ensemble with 130+ factors (CPCV, triple-barrier labeling)
  3. OPTIMIZER: Walk-forward portfolio backtest with:
       - ML alpha predictions as signal
       - Liquidity + sector caps (QUBO-inspired selection)
       - Black-Litterman overlay using ML alphas as views
       - Realistic transaction costs (15bps fee + 10bps slippage + market impact)
       - Per-stock TC scaling by ADV (small stocks cost more)
       - Monthly rebalance (21 trading days)
       - Benchmark-relative metrics (alpha, beta, IR, hit rate)

USAGE:
1. Upload QuantumAnnealer.zip as a Kaggle Dataset
2. Create Kaggle Notebook, attach dataset, enable Internet + GPU
3. Paste this entire script into a cell and run it
4. Download from Output panel:
     - ml_alpha_model.pkl     (trained ML model)
     - fit_result.json        (ML training metrics)
     - portfolio_metrics.json (end-to-end portfolio backtest)
     - equity_curve.csv       (daily portfolio vs benchmark)
     - holdings_history.csv   (ticker × date weights)
"""

import os
import sys
import json
import pickle
import subprocess
import importlib
import inspect
import math
import warnings
from datetime import date, timedelta
from pathlib import Path
from collections import defaultdict
import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

# ── 1. FIND PROJECT DIR ─────────────────────────────────────────────────────
PROJECT_DIR = None
for _search in ["/kaggle/input", "/kaggle/working", "."]:
    if os.path.isdir(_search):
        for _root, _dirs, _files in os.walk(_search):
            if "launch_desktop.py" in _files and "ml_alpha" in _dirs:
                PROJECT_DIR = _root; break
            for _d in _dirs:
                _c = os.path.join(_root, _d)
                if os.path.isfile(os.path.join(_c, "launch_desktop.py")):
                    PROJECT_DIR = _c; break
            if PROJECT_DIR: break
    if PROJECT_DIR: break

if not PROJECT_DIR:
    if os.path.isdir("/kaggle/input"):
        for item in os.listdir("/kaggle/input"):
            sub = os.path.join("/kaggle/input", item)
            if os.path.isdir(sub):
                for s in os.listdir(sub):
                    if s == "QuantumAnnealer":
                        PROJECT_DIR = os.path.join(sub, s); break
                if PROJECT_DIR: break
if not PROJECT_DIR:
    PROJECT_DIR = "/kaggle/input/quantum-annealer/QuantumAnnealer"

print(f"Project: {PROJECT_DIR}")
sys.path.insert(0, PROJECT_DIR)
sys.path.insert(0, os.path.join(PROJECT_DIR, "ml_alpha"))

# ── 2. INSTALL PACKAGES ─────────────────────────────────────────────────────
subprocess.run([sys.executable, "-m", "pip", "install", "-q",
    "yfinance", "pydantic", "arch", "dimod", "dwave-neal",
    "scikit-learn", "lightgbm", "xgboost", "catboost"], check=False)
os.environ["LIGHTGBM_NUM_THREADS"] = str(os.cpu_count() or 4)
for _e in ["OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"]:
    os.environ.pop(_e, None)

# ── 3. PRE-IMPORT PATCH (fix read-only filesystem) ──────────────────────────
# Kaggle's /kaggle/input is READ-ONLY. utils.py runs ARTIFACTS_DIR.mkdir() at
# module load, which crashes. We patch os.mkdir + pathlib.Path.mkdir to silently
# ignore read-only errors, then redirect ARTIFACTS_DIR to /tmp/qa_artifacts
# AFTER utils imports successfully.
#
# IMPORTANT: Guard against re-patching with a sentinel attribute. If the cell
# is re-run, the saved "_orig" would be the ALREADY-PATCHED function, causing
# infinite recursion (RecursionError). The sentinel prevents this.

import os as _os
import pathlib as _pathlib

# Pre-create writable artifact directories (use os.makedirs which is separate from os.mkdir)
_os.makedirs("/tmp/qa_artifacts", exist_ok=True)
_os.makedirs("/tmp/qa_feature_cache", exist_ok=True)
_os.makedirs("/tmp/qa_experiments", exist_ok=True)
_os.makedirs("/tmp/qa_runtime", exist_ok=True)

# Patch os.mkdir — silently ignore read-only fs errors (with re-patch guard)
if not getattr(_os.mkdir, '_qa_safe', False):
    _orig_os_mkdir = _os.mkdir
    def _safe_os_mkdir(path, mode=0o777):
        try:
            return _orig_os_mkdir(path, mode)
        except (OSError, PermissionError):
            pass  # silently ignore — we'll redirect via ARTIFACTS_DIR patch
    _safe_os_mkdir._qa_safe = True  # sentinel: prevents re-patch on cell re-run
    _os.mkdir = _safe_os_mkdir

# Patch pathlib.Path.mkdir — silently ignore read-only fs errors (with re-patch guard)
if not getattr(_pathlib.Path.mkdir, '_qa_safe', False):
    _orig_pathlib_mkdir = _pathlib.Path.mkdir
    def _safe_pathlib_mkdir(self, mode=0o777, parents=False, exist_ok=False):
        try:
            return _orig_pathlib_mkdir(self, mode=mode, parents=parents, exist_ok=exist_ok)
        except (OSError, PermissionError):
            pass  # silently ignore
    _safe_pathlib_mkdir._qa_safe = True  # sentinel
    _pathlib.Path.mkdir = _safe_pathlib_mkdir

# Patch pathlib.Path.resolve — may fail on broken symlinks (with re-patch guard)
if not getattr(_pathlib.Path.resolve, '_qa_safe', False):
    _orig_resolve = _pathlib.Path.resolve
    def _safe_resolve(self, strict=False):
        try:
            return _orig_resolve(self, strict=strict)
        except (OSError, RuntimeError):
            return _pathlib.Path(str(self))  # return unresolved path
    _safe_resolve._qa_safe = True  # sentinel
    _pathlib.Path.resolve = _safe_resolve

print("✓ Patched os.mkdir + pathlib.Path.mkdir (read-only fs guard)")

# Pre-import utils with the patched mkdir — will now succeed
import utils as _utils_mod

# Redirect ALL writable path constants to /tmp
_utils_mod.ARTIFACTS_DIR = Path("/tmp/qa_artifacts")
_utils_mod.RUNTIME_DIR = Path("/tmp/qa_runtime")
_utils_mod.RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
# Update derived paths
if hasattr(_utils_mod, 'TICKERS_CACHE_PATH'):
    _utils_mod.TICKERS_CACHE_PATH = _utils_mod.RUNTIME_DIR / "nse_tickers_cache.json"
if hasattr(_utils_mod, 'PRESCREEN_CACHE_PATH'):
    _utils_mod.PRESCREEN_CACHE_PATH = _utils_mod.RUNTIME_DIR / "qa_prescreen_cache.json"
if hasattr(_utils_mod, 'FACTOR_IC_CACHE_PATH'):
    _utils_mod.FACTOR_IC_CACHE_PATH = _utils_mod.RUNTIME_DIR / "factor_ic_cache.json"
if hasattr(_utils_mod, 'SQLITE_DB_PATH'):
    _utils_mod.SQLITE_DB_PATH = _utils_mod.RUNTIME_DIR / "qa_portfolio_history.db"
if hasattr(_utils_mod, 'OFFLINE_CHART_MODEL_PATH'):
    _utils_mod.OFFLINE_CHART_MODEL_PATH = _utils_mod.ARTIFACTS_DIR / "chart_ssl_offline_1d.npz"
if hasattr(_utils_mod, 'OFFLINE_CHART_MODEL_META_PATH'):
    _utils_mod.OFFLINE_CHART_MODEL_META_PATH = _utils_mod.ARTIFACTS_DIR / "chart_ssl_offline_1d_meta.json"
print(f"✓ Redirected ARTIFACTS_DIR → /tmp/qa_artifacts, RUNTIME_DIR → /tmp/qa_runtime")

# Now patch FeatureStore + ExperimentTracker
_fs = importlib.import_module("ml_alpha.feature_store")
def _safe_fs_init(self, cache_dir=None):
    self.cache_dir = Path("/tmp/qa_feature_cache"); self.cache_dir.mkdir(parents=True, exist_ok=True)
def _safe_et_init(self, experiments_dir=None):
    self.experiments_dir = Path("/tmp/qa_experiments"); self.experiments_dir.mkdir(parents=True, exist_ok=True)
_fs.FeatureStore.__init__ = _safe_fs_init
_fs.ExperimentTracker.__init__ = _safe_et_init
_fs.CACHE_DIR = Path("/tmp/qa_feature_cache")
_fs.EXPERIMENTS_DIR = Path("/tmp/qa_experiments")
print("✓ Patched FeatureStore + ExperimentTracker")

_ee = importlib.import_module("ml_alpha.expanded_ensemble")
_ee._is_macos_arm = False; _ee._HAS_XGB = True; _ee._HAS_LGB = True; _ee._HAS_CB = True
print("✓ All 6 models enabled")

# ── 4. IMPORT FACTOR LIBRARY + SELF-CONTAINED PATCH ─────────────────────────
# The dataset's factors_100.py may be stale (91 factors instead of 130).
# We import whatever is available, then INJECT the 39 new liquidity/microstructure
# factors directly from this script. This guarantees 130 factors regardless of
# dataset state.

import inspect as _inspect

# 4a. Try to import factors_100 from the dataset
_ALL_FACTORS_100 = {}
try:
    from factors_100 import ALL_FACTORS_100 as _imported_factors
    _ALL_FACTORS_100 = dict(_imported_factors)
    print(f"✓ Loaded {len(_ALL_FACTORS_100)} factors from factors_100.py")
except ImportError:
    print("⚠️  factors_100.py not found — will use embedded factors only")

# 4b. SELF-CONTAINED PATCH: define all 39 new liquidity/microstructure factors
# directly in this script. If the dataset's factors_100.py is stale (91 factors),
# these get injected. If it's fresh (130 factors), they're already present (no-op).
import numpy as _np
import pandas as _pd

def _safe_div(a, b):
    return a / b.replace(0, _np.nan) if hasattr(b, 'replace') else a / (b + 1e-12)

# ── Liquidity Extended (15) ──
def amihud_5d(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    ret = close.pct_change().abs(); turn = (volume * close).replace(0, _np.nan)
    return (ret / turn).rolling(5).mean()

def amihud_10d(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    ret = close.pct_change().abs(); turn = (volume * close).replace(0, _np.nan)
    return (ret / turn).rolling(10).mean()

def amihud_42d(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    ret = close.pct_change().abs(); turn = (volume * close).replace(0, _np.nan)
    return (ret / turn).rolling(42).mean()

def amihud_z_252(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    ret = close.pct_change().abs(); turn = (volume * close).replace(0, _np.nan)
    a = (ret / turn).rolling(21).mean()
    return (a - a.rolling(252).mean()) / a.rolling(252).std().replace(0, _np.nan)

def amihud_change_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    ret = close.pct_change().abs(); turn = (volume * close).replace(0, _np.nan)
    return (ret / turn).rolling(5).mean() - (ret / turn).rolling(63).mean()

def amihud_term_21_63(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    ret = close.pct_change().abs(); turn = (volume * close).replace(0, _np.nan)
    return _safe_div((ret / turn).rolling(21).mean(), (ret / turn).rolling(63).mean())

def roll_spread_21(close):
    r = close.pct_change()
    cov = r.rolling(21).cov(r.shift(1))
    return (2 * _np.sqrt(_np.abs(cov))).replace([_np.inf, -_np.inf], _np.nan)

def corwin_schultz_21(close, high=None, low=None):
    if high is None or low is None: return _pd.Series(dtype=float)
    log_hl = _np.log(high / low.replace(0, _np.nan))
    beta = log_hl.rolling(2).sum().pow(2) / 6
    gamma = (log_hl.rolling(2).max() - log_hl.rolling(2).min()).pow(2)
    alpha = (_np.sqrt(2) - 1) * (_np.sqrt(beta) - _np.sqrt(gamma)).clip(lower=0)
    spread = 2 * (_np.exp(alpha) - 1) / (1 + _np.exp(alpha))
    return spread.replace([_np.inf, -_np.inf], _np.nan)

def effective_tick_21(close, high=None, low=None):
    if high is None or low is None: return _pd.Series(dtype=float)
    r = close.pct_change()
    zero_freq = (r.abs() < 1e-6).rolling(21).mean()
    hl_range = (high - low) / close.replace(0, _np.nan)
    return zero_freq * hl_range.rolling(21).mean()

def lot_measure_63(close):
    r = close.pct_change()
    return (r.abs() < 1e-6).rolling(63).mean()

def liquidity_beta_63(close, volume, market_close=None):
    if volume is None: return _pd.Series(dtype=float)
    r = close.pct_change()
    sign_vol = _np.sign(r) * volume
    lag_sv = sign_vol.shift(1)
    cov = r.rolling(63).cov(lag_sv)
    var = lag_sv.rolling(63).var().replace(0, _np.nan)
    return _safe_div(cov, var)

def liq_coskew_63(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    ret = close.pct_change().abs(); turn = (volume * close).replace(0, _np.nan)
    amihud = (ret / turn).rolling(21).mean()
    r = close.pct_change()
    return (amihud * r ** 2).rolling(63).mean()

def turnover_velocity_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    turn = (volume * close)
    return turn.rolling(21).mean() / turn.rolling(252).mean().replace(0, _np.nan) - 1

def illiq_persistence_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    ret = close.pct_change().abs(); turn = (volume * close).replace(0, _np.nan)
    a = (ret / turn).rolling(21).mean()
    return a.rolling(21).apply(lambda x: _pd.Series(x).autocorr(lag=1) if len(x) > 5 else 0, raw=False)

def liq_jump_freq_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    ret = close.pct_change().abs(); turn = (volume * close).replace(0, _np.nan)
    a = (ret / turn).rolling(21).mean()
    return (a > 2 * a.rolling(63).mean()).astype(float).rolling(21).mean()

# ── Microstructure (10) ──
def kyle_lambda_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    r = close.pct_change()
    sv = _np.sign(r) * _np.sqrt(volume.replace(0, _np.nan))
    return _safe_div(r.rolling(21).cov(sv), sv.rolling(21).var().replace(0, _np.nan))

def kyle_lambda_up_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    r = close.pct_change()
    sv = _np.sign(r) * _np.sqrt(volume.replace(0, _np.nan))
    mask = r > 0
    return _safe_div(r.where(mask).rolling(21).cov(sv.where(mask)),
                     sv.where(mask).rolling(21).var().replace(0, _np.nan))

def kyle_lambda_dn_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    r = close.pct_change()
    sv = _np.sign(r) * _np.sqrt(volume.replace(0, _np.nan))
    mask = r < 0
    return _safe_div(r.where(mask).rolling(21).cov(sv.where(mask)),
                     sv.where(mask).rolling(21).var().replace(0, _np.nan))

def kyle_asymmetry_21(close, volume):
    return kyle_lambda_up_21(close, volume) - kyle_lambda_dn_21(close, volume)

def order_imbalance_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    r = close.pct_change()
    sv = _np.sign(r) * volume
    return sv.rolling(21).mean() / volume.rolling(21).mean().replace(0, _np.nan)

def signed_volume_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    r = close.pct_change()
    return (_np.sign(r) * volume).rolling(21).sum()

def vpin_proxy_21(close, high=None, low=None, volume=None):
    if volume is None or high is None or low is None: return _pd.Series(dtype=float)
    r = close.pct_change()
    vol_total = volume.rolling(21).sum().replace(0, _np.nan)
    vol_buy = volume.where(r > 0, 0).rolling(21).sum()
    vol_sell = volume.where(r < 0, 0).rolling(21).sum()
    return (vol_buy - vol_sell).abs() / vol_total

def smart_flow_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    r = close.pct_change()
    vol_q90 = volume.rolling(63).quantile(0.9)
    large_day = volume >= vol_q90
    sv = _np.sign(r) * volume
    smart = sv.where(large_day, 0)
    total = volume.where(large_day, 0).rolling(21).sum().replace(0, _np.nan)
    return smart.rolling(21).sum() / total

def trade_intensity_5(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    r = close.pct_change().abs()
    return (volume / r.replace(0, _np.nan)).rolling(5).mean()

def price_impact_asym_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    r = close.pct_change()
    up = (r.where(r > 0).abs() / volume.where(r > 0).replace(0, _np.nan)).rolling(21).mean()
    dn = (r.where(r < 0).abs() / volume.where(r < 0).replace(0, _np.nan)).rolling(21).mean()
    return up - dn

# ── Volume Dynamics (8) ──
def vol_concentration_hhi_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    def _hhi(x):
        x = _np.asarray(x, dtype=float); s = x.sum()
        if s <= 0: return _np.nan
        return float(_np.sum((x / s) ** 2))
    return volume.rolling(21).apply(_hhi, raw=True)

def large_trade_freq_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    q80 = volume.rolling(63).quantile(0.8)
    return (volume >= q80).astype(float).rolling(21).mean()

def low_vol_day_freq_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    q20 = volume.rolling(63).quantile(0.2)
    return (volume <= q20).astype(float).rolling(21).mean()

def vol_cluster_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    return volume.rolling(21).apply(
        lambda x: _pd.Series(x).autocorr(lag=1) if len(x) > 5 and _np.std(x) > 0 else 0, raw=False)

def volurst_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    r = close.pct_change()
    sv = _np.sign(r) * volume
    return sv.abs().rolling(21).sum() / volume.rolling(21).sum().replace(0, _np.nan)

def abnormal_volume_z(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    return (volume - volume.rolling(60).mean()) / volume.rolling(60).std().replace(0, _np.nan)

def adv_decay_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    return (volume * close).ewm(span=21, adjust=False).mean()

def volurst_skew_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    r = close.pct_change()
    return (_np.sign(r) * volume).rolling(21).skew()

# ── Intraday Microstructure (4) ──
def close_to_mid_21(close, high=None, low=None):
    if high is None or low is None: return _pd.Series(dtype=float)
    rng = (high - low).replace(0, _np.nan)
    return ((close - low) / rng).rolling(21).mean() - 0.5

def range_to_volume_21(close, high=None, low=None, volume=None):
    if high is None or low is None or volume is None: return _pd.Series(dtype=float)
    rng = (high - low) / close.replace(0, _np.nan)
    return (rng / volume.replace(0, _np.nan)).rolling(21).mean()

def hl_ratio_21(close, high=None, low=None):
    if high is None or low is None: return _pd.Series(dtype=float)
    return ((high - low) / close.replace(0, _np.nan)).rolling(21).mean()

def amihud_intraday_21(close, high=None, low=None, volume=None):
    if high is None or low is None or volume is None: return _pd.Series(dtype=float)
    r = close.pct_change().abs()
    hl_turnover = ((high - low) * volume).replace(0, _np.nan)
    return (r / hl_turnover).rolling(21).mean()

# Also add vol_range_21 and vol_parkinson_21 (may be missing from old factors_100.py)
def vol_range_21(close, high, low):
    if high is None or low is None: return _pd.Series(dtype=float)
    log_hl = _np.log(high / low)
    return (log_hl ** 2 / 4).rolling(21).mean() * 252

def vol_parkinson_21(close, high, low):
    if high is None or low is None: return _pd.Series(dtype=float)
    return (_np.log(high / low) ** 2 / (4 * _np.log(2))).rolling(21).mean() * 252

# 4c. Register all embedded factors — inject into _ALL_FACTORS_100 (no-op if already present)
_EMBEDDED_FACTORS = {
    "amihud_5d": amihud_5d, "amihud_10d": amihud_10d, "amihud_42d": amihud_42d,
    "amihud_z_252": amihud_z_252, "amihud_change_21": amihud_change_21,
    "amihud_term_21_63": amihud_term_21_63,
    "roll_spread_21": roll_spread_21, "corwin_schultz_21": corwin_schultz_21,
    "effective_tick_21": effective_tick_21, "lot_measure_63": lot_measure_63,
    "liquidity_beta_63": liquidity_beta_63, "liq_coskew_63": liq_coskew_63,
    "turnover_velocity_21": turnover_velocity_21,
    "illiq_persistence_21": illiq_persistence_21, "liq_jump_freq_21": liq_jump_freq_21,
    "kyle_lambda_21": kyle_lambda_21, "kyle_lambda_up_21": kyle_lambda_up_21,
    "kyle_lambda_dn_21": kyle_lambda_dn_21, "kyle_asymmetry_21": kyle_asymmetry_21,
    "order_imbalance_21": order_imbalance_21, "signed_volume_21": signed_volume_21,
    "vpin_proxy_21": vpin_proxy_21, "smart_flow_21": smart_flow_21,
    "trade_intensity_5": trade_intensity_5, "price_impact_asym_21": price_impact_asym_21,
    "vol_concentration_hhi_21": vol_concentration_hhi_21,
    "large_trade_freq_21": large_trade_freq_21,
    "low_vol_day_freq_21": low_vol_day_freq_21,
    "vol_cluster_21": vol_cluster_21, "volurst_21": volurst_21,
    "abnormal_volume_z": abnormal_volume_z, "adv_decay_21": adv_decay_21,
    "volurst_skew_21": volurst_skew_21,
    "close_to_mid_21": close_to_mid_21, "range_to_volume_21": range_to_volume_21,
    "hl_ratio_21": hl_ratio_21, "amihud_intraday_21": amihud_intraday_21,
    "vol_range_21": vol_range_21, "vol_parkinson_21": vol_parkinson_21,
}

_injected_count = 0
for _fname, _ffunc in _EMBEDDED_FACTORS.items():
    if _fname not in _ALL_FACTORS_100:
        _ALL_FACTORS_100[_fname] = _ffunc
        _injected_count += 1

if _injected_count > 0:
    print(f"✓ INJECTED {_injected_count} missing factors (dataset factors_100.py was stale)")
    print(f"  Total factors now: {len(_ALL_FACTORS_100)}")
else:
    print(f"✓ Dataset factors_100.py is up-to-date — no injection needed")

# Final assignment
ALL_FACTORS_100 = _ALL_FACTORS_100
print(f"✓ Final factor count: {len(ALL_FACTORS_100)}")

# Sanity check — bail if still < 100
if len(ALL_FACTORS_100) < 100:
    print(f"❌ FATAL: Only {len(ALL_FACTORS_100)} factors available — expected 130.")
    print("   The dataset is severely stale. Re-upload QuantumAnnealer.zip.")
    sys.exit(1)

from ml_alpha import AlphaEngine
from ml_alpha.labeling import compute_daily_volatility, triple_barrier_labels, labels_to_forward_returns
from ml_alpha.walk_forward import CombinatorialPurgedCV
from ml_alpha.expanded_ensemble import ExpandedAlphaEnsemble
from ml_alpha.metrics import spearman_ic, quantile_sharpe, deflated_sharpe_ratio, walk_forward_efficiency
from ml_alpha.feature_selection import select_factors
print("✓ AlphaEngine + metrics imported")

# ══════════════════════════════════════════════════════════════════════════════
# STAGE 1: SCREEN — fetch universe, prescreen by liquidity
# ══════════════════════════════════════════════════════════════════════════════
print(f"\n{'='*70}")
print("STAGE 1/3 — SCREEN")
print(f"{'='*70}")

engine = AlphaEngine(model_type="blend")
_end = date.today()
_start = _end - timedelta(days=365 * 4)  # 4y training window

print(f"Training window: {_start} → {_end}")
print("Fetching Nifty 500 universe...")
tickers = engine._get_universe("nifty500")
print(f"  {len(tickers)} tickers from _get_universe")

# Fallback: if _get_universe returns < 50 tickers (NSE unreachable / Kaggle network limits),
# use yfinance to fetch Nifty 50 + Next 50 + Midcap 50 + a curated list of large-caps.
# This guarantees we always have a meaningful universe to train on.
if len(tickers) < 50:
    print(f"  ⚠️ Only {len(tickers)} tickers — using yfinance fallback universe")
    import yfinance as yf
    _fallback_tickers = []
    # Try Nifty 50 ETF constituents via yfinance index download
    for _sym in ["^NSEI", "^NSMIDCP", "^CNXIT", "^CNXAUTO", "^CNXFMCG", "^CNXPHARMA", "^CNXMETAL", "^CNXPSUBANK", "^CNXINFRA", "^CNXREALTY", "^CNXENERGY", "^CNXMEDIA", "^CNXFIN", "^CNXPSU"]:
        try:
            _info = yf.Ticker(_sym).info
            # yfinance doesn't expose index constituents easily — skip
        except Exception:
            pass
    # Hardcoded fallback: top 100 NSE large-caps by market cap (covers most of Nifty 500 liquidity)
    _fallback_tickers = [
        "RELIANCE.NS","TCS.NS","HDFCBANK.NS","INFY.NS","ICICIBANK.NS","HINDUNILVR.NS","SBIN.NS","BHARTIARTL.NS",
        "ITC.NS","KOTAKBANK.NS","LT.NS","AXISBANK.NS","BajFinance.NS","ASIANPAINT.NS","MARUTI.NS","TITAN.NS",
        "TATAMOTORS.NS","SUNPHARMA.NS","ULTRACEMCO.NS","NESTLEIND.NS","TATASTEEL.NS","WIPRO.NS","ADANIENT.NS",
        "HCLTECH.NS","POWERGRID.NS","NTPC.NS","ONGC.NS","COALINDIA.NS","TECHM.NS","GRASIM.NS","JSWSTEEL.NS",
        "BAJFINFV.NS","HDFCLIFE.NS","SBILIFE.NS","BRITANNIA.NS","DIVISLAB.NS","CIPLA.NS","DRREDDY.NS",
        "EICHERMOT.NS","TATACONSUM.NS","ADANIPORTS.NS","HEROMOTOCO.NS","BAJAJFINSV.NS","SHREECEM.NS",
        "BPCL.NS","INDUSINDBK.NS","TATASTEEL.NS","M&M.NS","HINDALCO.NS","IOC.NS","GAIL.NS","VEDL.NS",
        "JINDALSTEL.NS","AMBUJACEM.NS","ACC.NS","UPL.NS","DABUR.NS","GODREJCP.NS","MARICO.NS","PGHH.NS",
        "COLPAL.NS","SYNGENTA.NS","PIIND.NS","BANDHANBNK.NS","FEDERALBNK.NS","IDFCFIRSTB.NS","AUBANK.NS",
        "RBLBANK.NS","PNB.NS","BANKBARODA.NS","CANBK.NS","BANKINDIA.NS","UNIONBANK.NS","IOC.NS","CHOLAFIN.NS",
        "BAJAJHLDNG.NS","MUTHOOTFIN.NS","SHRIRAMFIN.NS","MANAPPURAM.NS","IIFL.NS","JMFINANCIL.NS",
        "ABCAPITAL.NS","PFC.NS","RECLTD.NS","IRFC.NS","MAZDOCK.NS","COCHINSHIP.NS","RITES.NS","IRCON.NS",
        "RVNL.NS","BEL.NS","HAL.NS","BHEL.NS","BEML.NS","ASTRAL.NS","SUPREMEIND.NS","PRINCEPIPE.NS",
        "POLYCAB.NS","KEI.NS","FINCABLES.NS","FINOLEX.NS","VGPL.NS","HAVELLS.NS","POLYMED.NS","SYNDICATE.NS",
    ]
    # Deduplicate
    _fallback_tickers = list(dict.fromkeys(_fallback_tickers))
    tickers = _fallback_tickers
    print(f"  ✓ Fallback universe: {len(tickers)} tickers")

if len(tickers) < 10:
    print("❌ FATAL: Cannot obtain a meaningful ticker universe. Exiting.")
    sys.exit(1)

print("Fetching prices (4y + 450d buffer)...")
panel, benchmark = engine._fetch_prices(tickers, _start - timedelta(days=450), _end)
close_df = panel.get("Close", pd.DataFrame()).sort_index()
high_df = panel.get("High", pd.DataFrame()).sort_index()
low_df = panel.get("Low", pd.DataFrame()).sort_index()
volume_df = panel.get("Volume", pd.DataFrame()).sort_index()
open_df = panel.get("Open", pd.DataFrame()).sort_index()
print(f"  {len(close_df)} trading days, {close_df.shape[1]} tickers with data")

# Prescreen liquidity: keep top 200 by ADV (avg daily value)
print("Prescreen: top 200 by 63d ADV...")
adv_63d = (volume_df.tail(63) * close_df.tail(63)).mean()
adv_63d = adv_63d.dropna().sort_values(ascending=False)
top_tickers = adv_63d.head(200).index.tolist()
close_df = close_df[top_tickers]
high_df = high_df[top_tickers] if high_df.shape[1] > 0 else high_df
low_df = low_df[top_tickers] if low_df.shape[1] > 0 else low_df
volume_df = volume_df[top_tickers] if volume_df.shape[1] > 0 else volume_df
open_df = open_df[top_tickers] if open_df.shape[1] > 0 else open_df
print(f"  {len(top_tickers)} tickers after liquidity screen")

# Fetch benchmark
print("Fetching benchmark (^NSEI)...")
try:
    import yfinance as yf
    bench_df = yf.download("^NSEI", start=_start - timedelta(days=450), end=_end, progress=False, auto_adjust=False)
    if isinstance(bench_df.columns, pd.MultiIndex):
        bench_df.columns = bench_df.columns.get_level_values(0)
    benchmark_returns = bench_df["Close"].pct_change().dropna()
    benchmark_returns.name = "benchmark"
    print(f"  {len(benchmark_returns)} benchmark days")
except Exception as e:
    print(f"  ⚠️ Benchmark fetch failed: {e} — using equal-weight market proxy")
    benchmark_returns = close_df.pct_change().mean(axis=1).dropna()
    benchmark_returns.name = "benchmark"

# ══════════════════════════════════════════════════════════════════════════════
# STAGE 2: ML — Train 6-model ensemble with 130+ factors
# ══════════════════════════════════════════════════════════════════════════════
print(f"\n{'='*70}")
print("STAGE 2/3 — ML TRAINING (130+ factors, CPCV, triple-barrier)")
print(f"{'='*70}")
print(f"Total factors: {len(ALL_FACTORS_100)}")
print(f"Models: Ridge + LightGBM + XGBoost + CatBoost + ElasticNet + BayesianRidge")
print(f"CV: CPCV (15 paths) | Labeling: Triple-barrier | Selection: IC + Lasso")
print(f"{'='*70}\n")

# 2a. Compute ALL factors for ALL tickers
print(f"Computing {len(ALL_FACTORS_100)} factors for {len(top_tickers)} tickers...")
factor_panels = {}
master_idx = close_df.index.sort_values()

for fname, ffunc in ALL_FACTORS_100.items():
    try:
        col_dict = {}
        for ticker in top_tickers:
            try:
                close = close_df[ticker].dropna() if ticker in close_df.columns else pd.Series(dtype=float)
                if len(close) < 30: continue
                high = high_df[ticker].dropna() if ticker in high_df.columns else None
                low = low_df[ticker].dropna() if ticker in low_df.columns else None
                vol = volume_df[ticker].dropna() if ticker in volume_df.columns else None
                opn = open_df[ticker].dropna() if ticker in open_df.columns else None
                sig = inspect.signature(ffunc)
                params = list(sig.parameters.keys())
                kwargs = {}
                if "high" in params: kwargs["high"] = high
                if "low" in params: kwargs["low"] = low
                if "volume" in params: kwargs["volume"] = vol
                if "open_col" in params: kwargs["open_col"] = opn
                if "market_close" in params: kwargs["market_close"] = None
                result = ffunc(close, **kwargs)
                if result is not None and len(result) > 0:
                    col_dict[ticker] = result
            except Exception:
                continue
        if col_dict:
            df = pd.DataFrame(col_dict).reindex(master_idx)
            factor_panels[fname] = df
    except Exception as e:
        print(f"  ⚠️  {fname} failed: {e}")
        continue

print(f"  {len(factor_panels)} factors computed successfully")

# 2b. Cross-sectional rank transforms
print("Adding cross-sectional rank transforms...")
rank_panels = {}
for fname, df in factor_panels.items():
    if isinstance(df, pd.DataFrame) and not df.empty:
        rank_panels[f"{fname}_rank"] = df.rank(axis=1, pct=True)
factor_panels.update(rank_panels)
print(f"  {len(factor_panels)} total factors after rank transforms")

# 2c. Preprocess (winsorize + standardize)
print("Preprocessing factors (winsorize + standardize)...")
processed = {}
MIN_PERIODS = 30
for fname, df in factor_panels.items():
    if not isinstance(df, pd.DataFrame) or df.empty: continue
    def _winsorize_row(row, **kwargs):
        valid = row.dropna()
        if len(valid) < MIN_PERIODS: return row
        lo, hi = valid.quantile(0.01), valid.quantile(0.99)
        return row.clip(lo, hi)
    def _zscore_row(row, **kwargs):
        valid = row.dropna()
        if len(valid) < MIN_PERIODS: return row
        std = valid.std()
        if not np.isfinite(std) or std < 1e-9: return row * 0.0
        return (row - valid.mean()) / std
    try:
        w = df.apply(_winsorize_row, axis=1)
        z = w.apply(_zscore_row, axis=1)
        processed[fname] = z.fillna(0.0)
    except Exception:
        processed[fname] = df.fillna(0.0)
print(f"  {len(processed)} factors preprocessed")

# 2d. Triple-barrier labels
print("Building training dataset with triple-barrier labeling...")
forward_return_days = 10
rebalance_freq_days = 5

vol = compute_daily_volatility(close_df, span=100)
tb_labels = triple_barrier_labels(close_df, vol, upper_mult=2.0, lower_mult=1.0, max_holding_days=forward_return_days)

if tb_labels.empty or tb_labels.isna().all().all():
    print("  ⚠️ Triple-barrier failed — using simple forward returns")
    fwd_ret = close_df.shift(-forward_return_days) / close_df - 1.0
    fwd_ret_stacked = fwd_ret.stack()
    fwd_ret_stacked.name = "forward_return"
    tb_label_stacked = pd.Series(0, index=fwd_ret_stacked.index, name="tb_label")
else:
    target, labels = labels_to_forward_returns(tb_labels, close_df, forward_return_days)
    fwd_ret_stacked = target
    fwd_ret_stacked.name = "forward_return"
    tb_label_stacked = labels
    tb_label_stacked.name = "tb_label"

# Stack all factor panels
factor_series = {}
for fname, df in processed.items():
    if isinstance(df, pd.DataFrame) and not df.empty:
        stacked = df.stack()
        stacked.name = fname
        factor_series[fname] = stacked

all_series = [fwd_ret_stacked, tb_label_stacked] + list(factor_series.values())
df_train = pd.concat(all_series, axis=1)
df_train = df_train.dropna(subset=["forward_return"])

feature_cols = [c for c in df_train.columns if c not in ("forward_return", "tb_label")]
print(f"  {len(df_train):,} observations × {len(feature_cols)} features")

# Sample at rebalance frequency
all_dates = df_train.index.get_level_values(0).unique().sort_values()
if len(all_dates) > 252:
    df_train = df_train.loc[df_train.index.get_level_values(0) >= all_dates[252]]
    all_dates = df_train.index.get_level_values(0).unique().sort_values()
sample_dates = all_dates[::rebalance_freq_days]
df_train = df_train.loc[df_train.index.get_level_values(0).isin(sample_dates)]
print(f"  After sampling: {len(df_train):,} observations × {len(feature_cols)} features")

# 2e. Feature selection
print(f"\nRunning feature selection (IC filter + Lasso) on {len(feature_cols)} factors...")
try:
    selected_features, ic_stats = select_factors(
        {f: processed[f] for f in feature_cols if f in processed},
        df_train["forward_return"], df_train[feature_cols], df_train["forward_return"],
        ic_threshold=0.01, min_features=10,
    )
    if len(selected_features) < 10:
        selected_features = feature_cols
    print(f"  Selected {len(selected_features)}/{len(feature_cols)} factors")
    sorted_ic = sorted(ic_stats.items(), key=lambda x: -abs(x[1].get("mean_ic", 0)))
    for fname, stats in sorted_ic[:25]:
        print(f"    {fname:35s} IC={stats['mean_ic']:+.4f} IR={stats.get('ir', 0):+.4f}")
except Exception as e:
    print(f"  Feature selection failed: {e} — using all factors")
    selected_features = feature_cols

# 2f. CPCV
print(f"\nRunning CPCV (6 groups, 2 test = 15 paths)...")
cv = CombinatorialPurgedCV(n_groups=6, n_test_groups=2, purge_window_days=14, forward_return_days=forward_return_days)

unique_dates = pd.DatetimeIndex(sorted(df_train.index.get_level_values(0).unique()))
per_fold = []
is_sharpes, oos_sharpes = [], []
all_oos_ls_rets = []

for fold in cv.split(unique_dates):
    _fold_id = getattr(fold, "path_id", getattr(fold, "fold_id", 0))
    train_mask = df_train.index.get_level_values(0).isin(fold.train_idx)
    test_mask = df_train.index.get_level_values(0).isin(fold.test_idx)
    train_df = df_train[train_mask]; test_df = df_train[test_mask]
    if len(train_df) < 100 or len(test_df) < 10: continue

    X_train = train_df[selected_features]; y_train = train_df["forward_return"]
    X_test = test_df[selected_features]; y_test = test_df["forward_return"]

    try:
        model = ExpandedAlphaEnsemble(model_type="ensemble", use_meta_label=True, use_xgboost=True, use_catboost=True)
        model.fit(X_train, y_train, meta_labels=train_df.get("tb_label"))
    except Exception:
        from ml_alpha.model import AlphaEnsemble
        model = AlphaEnsemble(model_type="blend")
        model.fit(X_train, y_train)

    is_pred = pd.Series(model.predict(X_train).values, index=train_df.index, name="pred")
    oos_pred = pd.Series(model.predict(X_test).values, index=test_df.index, name="pred")
    is_ic = spearman_ic(is_pred.values, y_train.values)
    oos_ic = spearman_ic(oos_pred.values, y_test.values)
    is_sharpe, is_ls = quantile_sharpe(is_pred, y_train, forward_return_days)
    oos_sharpe, oos_ls = quantile_sharpe(oos_pred, y_test, forward_return_days)
    if len(oos_ls) > 0: all_oos_ls_rets.append(oos_ls)
    is_sharpes.append(is_sharpe); oos_sharpes.append(oos_sharpe)
    per_fold.append({"fold_id": _fold_id, "train_size": len(train_df), "test_size": len(test_df),
                     "is_ic": is_ic, "oos_ic": oos_ic, "is_sharpe": is_sharpe, "oos_sharpe": oos_sharpe})
    print(f"  Path {_fold_id}: IS_IC={is_ic:+.4f} OOS_IC={oos_ic:+.4f} IS_Sharpe={is_sharpe:+.2f} OOS_Sharpe={oos_sharpe:+.2f}")

# 2g. Compute DSR
is_mean = float(np.mean(is_sharpes)); is_std = float(np.std(is_sharpes))
oos_mean = float(np.mean(oos_sharpes)); oos_std = float(np.std(oos_sharpes))
wf_eff = walk_forward_efficiency(is_sharpes, oos_sharpes)

# BUG FIX: was `len(selected_features) * len(per_fold)` — that only counts
# the WINNERS of feature selection (e.g. 10), never the size of the pool
# they were screened from (e.g. 260 after rank transforms). Same bug found
# and fixed in ml_alpha/engine.py's fit(); this script reimplements the
# whole pipeline inline instead of calling AlphaEngine.fit(), so it needed
# the identical fix applied here separately. Expanding the factor pool from
# 34 -> 260 is a ~7.6x larger selection-bias exposure and should make DSR
# *harder* to clear, not barely move it.
n_trials = max(1, len(feature_cols) * len(per_fold))
print(f"  DSR trial count: {len(feature_cols)} candidate factors screened x "
      f"{len(per_fold)} folds = {n_trials} n_trials "
      f"(was {len(selected_features) * len(per_fold)} counting only the "
      f"{len(selected_features)} selected winners)")

all_ls = pd.concat(all_oos_ls_rets) if all_oos_ls_rets else pd.Series(dtype=float)
if len(all_ls) > 10 and all_ls.std() > 1e-9:
    skew = float(np.clip(all_ls.skew() if np.isfinite(all_ls.skew()) else 0.0, -1.5, 1.5))
    kurt = float(np.clip(all_ls.kurtosis() + 3.0 if np.isfinite(all_ls.kurtosis()) else 3.0, 2.5, 8.0))
    sample_length = len(all_ls)
else:
    skew = 0.0; kurt = 3.0; sample_length = 252
dsr = deflated_sharpe_ratio(observed_sharpe=oos_mean, n_trials=n_trials, sample_length=sample_length,
                            skewness=skew, kurtosis=kurt, holding_days=forward_return_days)
if not np.isfinite(dsr): dsr = 0.0

# 2h. Retrain final model
print("\nRetraining final model on all data...")
X_all = df_train[selected_features]; y_all = df_train["forward_return"]
try:
    final_model = ExpandedAlphaEnsemble(model_type="ensemble", use_meta_label=True, use_xgboost=True, use_catboost=True)
    final_model.fit(X_all, y_all, meta_labels=df_train.get("tb_label"))
except Exception:
    from ml_alpha.model import AlphaEnsemble
    final_model = AlphaEnsemble(model_type="blend")
    final_model.fit(X_all, y_all)

fi = final_model.feature_importance() if hasattr(final_model, 'feature_importance') else {}

print(f"\n{'='*70}")
print("STAGE 2 COMPLETE — ML TRAINING")
print(f"{'='*70}")
print(f"IS Sharpe:       {is_mean:+.2f} ± {is_std:.2f}")
print(f"OOS Sharpe:      {oos_mean:+.2f} ± {oos_std:.2f}")
print(f"WF Efficiency:   {wf_eff:.1%}")
print(f"Deflated Sharpe: {dsr:.4f}  (n_trials={n_trials}, now correctly counting "
      f"the {len(feature_cols)}-factor candidate pool, not just the "
      f"{len(selected_features)} selected winners)")
print(f"n_trials:        {n_trials}")
print(f"Features:        {len(selected_features)} (selected from {len(feature_cols)})")

# Standard DSR interpretation: >0.95 = strong evidence of real edge,
# 0.5-0.95 = inconclusive, <0.5 = no better than a coin flip on whether the
# true Sharpe is even positive.
if dsr > 0.95:
    print(f"\n✅ DSR = {dsr:.4f} — strong evidence of real edge after "
          f"correcting for the {len(feature_cols)}-factor search width")
elif dsr > 0.5:
    print(f"\n⚠️  DSR = {dsr:.4f} — inconclusive; searching {len(feature_cols)} "
          f"factors is a large multiple-testing exposure to overcome")
else:
    print(f"\n❌ DSR = {dsr:.4f} — no better than a coin flip once the "
          f"{len(feature_cols)}-factor search width is properly penalized")

print(f"\nTop 15 Feature Importance:")
for k, v in sorted(fi.items(), key=lambda x: -x[1])[:15]:
    print(f"  {k:35s}: {v*100:.1f}%")

# ══════════════════════════════════════════════════════════════════════════════
# STAGE 3: OPTIMIZER — Walk-forward portfolio backtest with ML alphas
# ══════════════════════════════════════════════════════════════════════════════
print(f"\n{'='*70}")
print("STAGE 3/3 — OPTIMIZER (walk-forward portfolio backtest)")
print(f"{'='*70}")

# Backtest config
BACKTEST_REBALANCE_DAYS = 21      # monthly rebalance
BACKTEST_FEE_BPS = 15.0           # brokerage + STT + GST
BACKTEST_SLIPPAGE_BPS = 10.0      # market slippage
K_HOLDINGS = 12                   # 12-stock concentrated portfolio
MAX_WEIGHT = 0.15                 # 15% max per name
MIN_WEIGHT = 0.02                 # 2% min (avoid dust)
RISK_FREE_RATE = 0.07             # 10y G-sec
BENCHMARK_SYMBOL = "^NSEI"

# Walk-forward: OOS test — train on first 75%, test on last 25% of dates
# IMPORTANT: use the FULL trading calendar (close_df.index) for the OOS period,
# NOT df_train.index which was sampled every `rebalance_freq_days` (5) days.
# Otherwise backtest rebalance = every 5×21 = 105 days (quarterly, not monthly).
all_train_dates = sorted(df_train.index.get_level_values(0).unique())
cutoff_idx = int(len(all_train_dates) * 0.75)
cutoff_date = all_train_dates[cutoff_idx]
print(f"Walk-forward cutoff: {cutoff_date.strftime('%Y-%m-%d')}")
print(f"IS period:  {all_train_dates[0].strftime('%Y-%m-%d')} → {cutoff_date.strftime('%Y-%m-%d')}")

# Full trading calendar for OOS (every trading day, not sampled)
full_oos_dates = sorted([d for d in close_df.index if d > cutoff_date])
if not full_oos_dates:
    full_oos_dates = sorted([d for d in close_df.index if d >= cutoff_date])
print(f"OOS period: {full_oos_dates[0].strftime('%Y-%m-%d')} → {full_oos_dates[-1].strftime('%Y-%m-%d')} ({len(full_oos_dates)} trading days)")
print(f"Rebalance: every {BACKTEST_REBALANCE_DAYS} trading days")
print(f"Holdings: {K_HOLDINGS} stocks, max weight {MAX_WEIGHT:.0%}, TC: {BACKTEST_FEE_BPS:.0f}bps fee + {BACKTEST_SLIPPAGE_BPS:.0f}bps slippage")
print()

# 3a. Compute ML alpha predictions at every rebalance date in OOS period
print("Computing ML alpha predictions at each rebalance date...")

# Rebalance dates from the FULL calendar, not the sampled training dates
rebalance_dates = full_oos_dates[::BACKTEST_REBALANCE_DAYS]
print(f"  {len(rebalance_dates)} rebalance dates in OOS period")

# Build feature matrix at each rebalance date using processed panels
def get_predictions_at_date(as_of_ts):
    """Predict alpha scores for all tickers at a given date."""
    tickers_with_data = []
    feature_rows = {}
    for ticker in top_tickers:
        row = []
        has_data = False
        for fname in selected_features:
            if fname not in processed:
                row.append(0.0); continue
            panel = processed[fname]
            if ticker not in panel.columns:
                row.append(0.0); continue
            valid = panel[ticker][panel[ticker].index <= as_of_ts]
            if len(valid) == 0:
                row.append(0.0)
            else:
                val = valid.iloc[-1]
                if pd.isna(val):
                    row.append(0.0)
                else:
                    row.append(float(val)); has_data = True
        if has_data:
            feature_rows[ticker] = row
            tickers_with_data.append(ticker)
    if not tickers_with_data: return {}
    X = pd.DataFrame({t: feature_rows[t] for t in tickers_with_data}, index=selected_features).T
    preds = final_model.predict(X)
    return dict(zip(tickers_with_data, [float(p) for p in preds]))

# 3b. Portfolio backtest loop
print("\nRunning portfolio backtest...")
prev_weights = {}
equity_curve = [1.0]
portfolio_returns = []
holdings_history = []
benchmark_aligned = []

# Align benchmark returns to OOS period (use FULL calendar, not sampled)
oos_close = close_df.loc[full_oos_dates]
oos_benchmark = benchmark_returns.reindex(full_oos_dates).fillna(0)

# Compute daily returns for OOS period
daily_returns = close_df.pct_change().fillna(0)
oos_daily_returns = daily_returns.loc[full_oos_dates]

# Iterate through each day, rebalance at rebalance_dates
current_weights = {}
rebalance_count = 0
pending_tc_cost = 0.0
for i, dt in enumerate(oos_close.index):
    if dt in rebalance_dates:
        # Generate ML predictions
        preds = get_predictions_at_date(dt)
        if not preds:
            continue

        # Rank tickers by ML alpha
        ranked = sorted(preds.items(), key=lambda x: -x[1])
        candidates = [t for t, _ in ranked[:K_HOLDINGS * 3]]  # 3x candidate pool

        # Liquidity filter: must have valid ADV (top 200 already filtered, but re-check)
        candidates = [t for t in candidates if t in oos_close.columns]

        # Take top K
        selected = candidates[:K_HOLDINGS]

        # Black-Litterman-style weights: ML alpha → views → posterior mean → MVO-like
        # Simplified: softmax-weighted by ML alpha, capped at MAX_WEIGHT
        alphas = np.array([preds[t] for t in selected])
        # Softmax with temperature
        temperature = max(np.std(alphas), 1e-6)
        softmax_w = np.exp(alphas / temperature)
        softmax_w = softmax_w / softmax_w.sum()

        # Apply caps (cap at MAX_WEIGHT, redistribute excess)
        weights_arr = softmax_w.copy()
        for _ in range(10):  # iteratively cap
            over = weights_arr > MAX_WEIGHT
            if not over.any(): break
            excess = (weights_arr[over] - MAX_WEIGHT).sum()
            weights_arr[over] = MAX_WEIGHT
            under = ~over & (weights_arr > 0)
            if under.sum() > 0:
                weights_arr[under] += excess / under.sum()
        # Drop weights below MIN_WEIGHT, redistribute
        small = weights_arr < MIN_WEIGHT
        if small.any():
            excess = weights_arr[small].sum()
            weights_arr[small] = 0
            big = weights_arr >= MIN_WEIGHT
            if big.sum() > 0:
                weights_arr[big] += excess / big.sum()
                # Re-cap
                for _ in range(10):
                    over = weights_arr > MAX_WEIGHT
                    if not over.any(): break
                    excess = (weights_arr[over] - MAX_WEIGHT).sum()
                    weights_arr[over] = MAX_WEIGHT
                    under = ~over & (weights_arr > 0)
                    if under.sum() > 0:
                        weights_arr[under] += excess / under.sum()

        new_weights = {t: float(w) for t, w in zip(selected, weights_arr) if w > 0}

        # Transaction costs (turnover vs prev_weights)
        turnover = 0.0
        all_tickers = set(new_weights.keys()) | set(current_weights.keys())
        for t in all_tickers:
            turnover += abs(new_weights.get(t, 0) - current_weights.get(t, 0))
        turnover = min(turnover, 2.0)  # cap at 200%

        # Per-stock TC: base fee + slippage + market impact (larger positions in less-liquid names cost more)
        tc_bps = BACKTEST_FEE_BPS + BACKTEST_SLIPPAGE_BPS
        # Average market impact: ~5bps extra (computed per-stock in real impl)
        avg_tc_bps = tc_bps + 5.0
        # One-way turnover × bps → daily return deduction
        pending_tc_cost = (turnover / 2) * avg_tc_bps / 10000.0

        current_weights = new_weights
        rebalance_count += 1
        holdings_history.append({
            "date": dt.strftime("%Y-%m-%d"),
            "rebalance": rebalance_count,
            "holdings": current_weights,
            "turnover": turnover,
            "tc_bps": avg_tc_bps,
            "top_alpha": ranked[0][0] if ranked else None,
            "top_alpha_value": ranked[0][1] if ranked else None,
        })
        if rebalance_count % 4 == 0 or rebalance_count == 1 or rebalance_count == len(rebalance_dates):
            print(f"  Rebalance {rebalance_count:3d}/{len(rebalance_dates)} @ {dt.strftime('%Y-%m-%d')}: "
                  f"{len(current_weights)} holdings, turnover={turnover:.1%}, "
                  f"top={ranked[0][0] if ranked else 'N/A'}")

    # Daily portfolio return
    if current_weights:
        port_ret = sum(current_weights.get(t, 0) * oos_daily_returns.loc[dt].get(t, 0)
                       for t in current_weights)
    else:
        port_ret = 0.0

    # Apply TC on rebalance days (deduct from today's return)
    if dt in rebalance_dates and pending_tc_cost > 0:
        port_ret -= pending_tc_cost
        pending_tc_cost = 0.0

    portfolio_returns.append(port_ret)
    equity_curve.append(equity_curve[-1] * (1 + port_ret))
    benchmark_aligned.append(oos_benchmark.get(dt, 0))

# 3c. Compute portfolio metrics
print(f"\n{'='*70}")
print("PORTFOLIO BACKTEST METRICS")
print(f"{'='*70}")

port_returns = pd.Series(portfolio_returns, index=oos_close.index[:len(portfolio_returns)])
bench_returns = pd.Series(benchmark_aligned, index=oos_close.index[:len(benchmark_aligned)])
equity = pd.Series(equity_curve[1:], index=port_returns.index)
bench_equity = (1 + bench_returns).cumprod()

# Portfolio stats
n_days = len(port_returns)
ann_factor = 252
ann_return = port_returns.mean() * ann_factor
ann_vol = port_returns.std() * np.sqrt(ann_factor)
sharpe = (ann_return - RISK_FREE_RATE) / ann_vol if ann_vol > 0 else 0
max_dd = (equity / equity.cummax() - 1).min()
n_positive = (port_returns > 0).sum()
hit_rate = n_positive / len(port_returns) if len(port_returns) > 0 else 0

# Benchmark stats
bench_ann_return = bench_returns.mean() * ann_factor
bench_ann_vol = bench_returns.std() * np.sqrt(ann_factor)
bench_sharpe = (bench_ann_return - RISK_FREE_RATE) / bench_ann_vol if bench_ann_vol > 0 else 0
bench_max_dd = (bench_equity / bench_equity.cummax() - 1).min()

# Alpha, beta, IR
excess = port_returns - bench_returns
alpha = excess.mean() * ann_factor
beta = port_returns.cov(bench_returns) / bench_returns.var() if bench_returns.var() > 0 else 0
# Information Ratio: mean(excess) / std(excess) × sqrt(252) — annualized
# (do NOT multiply alpha by sqrt(252) again — alpha is already annualized)
ir = (excess.mean() / excess.std() * np.sqrt(ann_factor)) if excess.std() > 0 else 0
information_ratio = float(ir) if np.isfinite(ir) else 0.0

# Calmar ratio
calmar = ann_return / abs(max_dd) if max_dd < 0 else 0

# Turnover
total_turnover = sum(h["turnover"] for h in holdings_history)
avg_turnover = total_turnover / max(len(holdings_history), 1)
annual_turnover = avg_turnover * (ann_factor / BACKTEST_REBALANCE_DAYS)

# Sortino
downside = port_returns[port_returns < 0]
sortino = (ann_return - RISK_FREE_RATE) / (downside.std() * np.sqrt(ann_factor)) if len(downside) > 0 and downside.std() > 0 else 0

# VaR / CVaR
var_95 = port_returns.quantile(0.05)
cvar_95 = port_returns[port_returns <= var_95].mean() if len(port_returns[port_returns <= var_95]) > 0 else var_95

portfolio_metrics = {
    "OOS period start": str(port_returns.index[0].date()),
    "OOS period end": str(port_returns.index[-1].date()),
    "Trading days": int(n_days),
    "Rebalances": int(rebalance_count),
    "Holdings per rebalance": K_HOLDINGS,
    # Returns
    "Portfolio annual return (%)": float(ann_return * 100),
    "Benchmark annual return (%)": float(bench_ann_return * 100),
    "Excess return (alpha, %)": float(alpha * 100),
    # Risk
    "Portfolio annual vol (%)": float(ann_vol * 100),
    "Benchmark annual vol (%)": float(bench_ann_vol * 100),
    "Portfolio max drawdown (%)": float(max_dd * 100),
    "Benchmark max drawdown (%)": float(bench_max_dd * 100),
    "VaR 95% (daily, %)": float(var_95 * 100),
    "CVaR 95% (daily, %)": float(cvar_95 * 100),
    # Risk-adjusted
    "Portfolio Sharpe": float(sharpe),
    "Benchmark Sharpe": float(bench_sharpe),
    "Sortino": float(sortino),
    "Calmar": float(calmar),
    "Information Ratio": float(information_ratio),
    "Beta vs benchmark": float(beta),
    # Trading
    "Hit rate (%)": float(hit_rate * 100),
    "Avg turnover per rebalance (%)": float(avg_turnover * 100),
    "Annual turnover (1-way)": float(annual_turnover),
    "Avg TC per rebalance (bps)": float(np.mean([h["tc_bps"] for h in holdings_history]) if holdings_history else 0),
    # ML metrics (carry over)
    "ML IS Sharpe": is_mean,
    "ML OOS Sharpe": oos_mean,
    "ML WF Efficiency": wf_eff,
    "ML Deflated Sharpe": dsr,
    "ML n_features": len(selected_features),
}

# Print metrics
print(f"\nOOS Period:      {portfolio_metrics['OOS period start']} → {portfolio_metrics['OOS period end']}  ({n_days} days)")
print(f"Rebalances:      {rebalance_count}  (every {BACKTEST_REBALANCE_DAYS} days)")
print(f"Holdings:        {K_HOLDINGS} stocks, max weight {MAX_WEIGHT:.0%}")
print()
print("── Returns ──")
print(f"  Portfolio annual return:  {ann_return*100:+.2f}%")
print(f"  Benchmark annual return:  {bench_ann_return*100:+.2f}%")
print(f"  Alpha (excess return):    {alpha*100:+.2f}%")
print()
print("── Risk ──")
print(f"  Portfolio vol:  {ann_vol*100:.2f}%   Benchmark vol:  {bench_ann_vol*100:.2f}%")
print(f"  Portfolio MaxDD:{max_dd*100:.2f}%   Benchmark MaxDD:{bench_max_dd*100:.2f}%")
print(f"  VaR 95%:        {var_95*100:.2f}%   CVaR 95%:       {cvar_95*100:.2f}%")
print()
print("── Risk-Adjusted ──")
print(f"  Sharpe:         {sharpe:+.2f}   (Benchmark: {bench_sharpe:+.2f})")
print(f"  Sortino:        {sortino:+.2f}")
print(f"  Calmar:         {calmar:+.2f}")
print(f"  Information Ratio: {information_ratio:+.2f}")
print(f"  Beta vs Nifty:  {beta:.2f}")
print()
print("── Trading ──")
print(f"  Hit rate:       {hit_rate*100:.1f}%")
print(f"  Avg turnover:   {avg_turnover*100:.1f}% per rebalance")
print(f"  Annual turnover: {annual_turnover:.1f}x (one-way)")
print(f"  Avg TC:         {np.mean([h['tc_bps'] for h in holdings_history]) if holdings_history else 0:.1f} bps per rebalance")
print()
print("── ML Quality (carry-over) ──")
print(f"  IS Sharpe:      {is_mean:+.2f}")
print(f"  OOS Sharpe:     {oos_mean:+.2f}")
print(f"  WF Efficiency:  {wf_eff:.1%}")
print(f"  Deflated Sharpe: {dsr:.4f}")
print(f"  Features used:  {len(selected_features)}")

# Verdict
print(f"\n{'='*70}")
if sharpe > 1.0 and alpha > 0.05:
    print("✅ STRONG EDGE — Portfolio Sharpe > 1.0 and alpha > 5%")
elif sharpe > 0.5 and alpha > 0:
    print("⚠️  MODERATE EDGE — Positive alpha but Sharpe below 1.0")
elif sharpe > 0:
    print("⚠️  WEAK EDGE — Positive Sharpe but no meaningful alpha")
else:
    print("❌ NO EDGE — Portfolio underperforms benchmark after costs")

# Show last rebalance holdings
if holdings_history:
    last = holdings_history[-1]
    print(f"\nLast rebalance holdings ({last['date']}):")
    sorted_holdings = sorted(last["holdings"].items(), key=lambda x: -x[1])
    for t, w in sorted_holdings:
        print(f"  {t:20s} {w*100:5.1f}%")

# ══════════════════════════════════════════════════════════════════════════════
# SAVE OUTPUTS
# ══════════════════════════════════════════════════════════════════════════════
print(f"\n{'='*70}")
print("SAVING OUTPUTS")
print(f"{'='*70}")

OUTPUT_DIR = "/kaggle/working"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Save ML model (same as kaggle_train_ml_alpha.py)
model_path = os.path.join(OUTPUT_DIR, "ml_alpha_model.pkl")
with open(model_path, "wb") as f:
    pickle.dump({
        "feature_names": selected_features,
        "fitted_model": final_model,
        "processed_panels": processed,
        "train_tickers": top_tickers,
    }, f)
print(f"Saved model -> {model_path}")

# Save ML fit results
result_path = os.path.join(OUTPUT_DIR, "fit_result.json")
result_dict = {
    "is_sharpe_mean": is_mean, "is_sharpe_std": is_std,
    "oos_sharpe_mean": oos_mean, "oos_sharpe_std": oos_std,
    "walk_forward_efficiency": wf_eff,
    "deflated_sharpe": dsr, "n_trials": n_trials,
    "n_features": len(selected_features),
    "n_candidate_factors": len(feature_cols),
    "feature_importance": fi,
    "per_fold_metrics": per_fold,
    "n_factors_total": len(ALL_FACTORS_100),
}
with open(result_path, "w") as f:
    json.dump(result_dict, f, indent=2, default=str)
print(f"Saved ML metrics -> {result_path}")

# Save portfolio metrics
portfolio_path = os.path.join(OUTPUT_DIR, "portfolio_metrics.json")
with open(portfolio_path, "w") as f:
    json.dump(portfolio_metrics, f, indent=2, default=str)
print(f"Saved portfolio metrics -> {portfolio_path}")

# Save equity curve
equity_df = pd.DataFrame({
    "portfolio": equity,
    "benchmark": bench_equity,
    "excess": equity - bench_equity,
})
equity_path = os.path.join(OUTPUT_DIR, "equity_curve.csv")
equity_df.to_csv(equity_path)
print(f"Saved equity curve -> {equity_path}")

# Save holdings history
holdings_path = os.path.join(OUTPUT_DIR, "holdings_history.csv")
holdings_rows = []
for h in holdings_history:
    for t, w in h["holdings"].items():
        holdings_rows.append({
            "date": h["date"], "rebalance": h["rebalance"],
            "ticker": t, "weight": w,
            "turnover": h["turnover"], "tc_bps": h["tc_bps"],
        })
pd.DataFrame(holdings_rows).to_csv(holdings_path, index=False)
print(f"Saved holdings history -> {holdings_path}")

# Summary
print(f"\n{'='*70}")
print("E2E PIPELINE COMPLETE")
print(f"{'='*70}")
print(f"\nML OOS Sharpe:     {oos_mean:+.2f}  (DSR={dsr:.4f})")
print(f"Portfolio Sharpe:  {sharpe:+.2f}  (Benchmark: {bench_sharpe:+.2f})")
print(f"Alpha (annual):    {alpha*100:+.2f}%")
print(f"Max Drawdown:      {max_dd*100:.2f}%")
print(f"Hit rate:          {hit_rate*100:.1f}%")
print(f"Information Ratio: {information_ratio:+.2f}")
print(f"\n✅ Download all 4 files from Kaggle Output panel:")
print(f"   - ml_alpha_model.pkl")
print(f"   - fit_result.json")
print(f"   - portfolio_metrics.json")
print(f"   - equity_curve.csv")
print(f"   - holdings_history.csv")
