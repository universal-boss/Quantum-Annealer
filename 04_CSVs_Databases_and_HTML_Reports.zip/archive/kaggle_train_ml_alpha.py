"""
kaggle_train_ml_alpha.py — 100+ FACTORS EDITION
================================================
Trains with 100+ factors (instead of 8) so the model can find real signals.
Monkey-patches classes at runtime. Works on ANY dataset version.

USAGE:
1. Upload QuantumAnnealer.zip as a Kaggle Dataset (any version)
2. Create Kaggle Notebook, attach dataset, enable Internet
3. Paste this entire script into a cell and run it
4. Download ml_alpha_model.pkl + fit_result.json from Output panel
5. Copy ml_alpha_model.pkl into QuantumAnnealer/models/ on your Mac
"""

import os
import sys
import json
import pickle
import subprocess
import importlib
from datetime import date, timedelta
from pathlib import Path
import numpy as np
import pandas as pd

# ── 1. FIND PROJECT DIR ─────────────────────────────────────────────────────
PROJECT_DIR = None
for _search in ["/kaggle/input", "/kaggle/working", "."]:
    if os.path.isdir(_search):
        for _root, _dirs, _files in os.walk(_search):
            if "launch_desktop.py" in _files and "ml_alpha" in _dirs:
                PROJECT_DIR = _root; break
            for _d in _dirs:
                _c = os.path.join(_root, _d)
                if os.path.isfile(os.path.join(_c, "launch_desktop.py")):
                    PROJECT_DIR = _c; break
            if PROJECT_DIR: break
    if PROJECT_DIR: break

if not PROJECT_DIR:
    print("Could not auto-detect. Listing /kaggle/input:")
    if os.path.isdir("/kaggle/input"):
        for item in os.listdir("/kaggle/input"):
            print(f"  /kaggle/input/{item}")
            sub = os.path.join("/kaggle/input", item)
            if os.path.isdir(sub):
                for s in os.listdir(sub)[:20]: print(f"    {s}")
    PROJECT_DIR = "/kaggle/input/quantum-annealer/QuantumAnnealer"

print(f"Project: {PROJECT_DIR}")
sys.path.insert(0, PROJECT_DIR)

# ── 2. INSTALL PACKAGES ─────────────────────────────────────────────────────
subprocess.run([sys.executable, "-m", "pip", "install", "-q",
    "yfinance", "pydantic", "arch", "dimod", "dwave-neal",
    "scipy", "lightgbm", "xgboost", "catboost", "torch"], check=False)
os.environ["LIGHTGBM_NUM_THREADS"] = str(os.cpu_count() or 4)
for _e in ["OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"]:
    os.environ.pop(_e, None)

# ── 3. PRE-IMPORT PATCH (fix read-only filesystem) ──────────────────────────
# Kaggle's /kaggle/input is READ-ONLY. utils.py runs ARTIFACTS_DIR.mkdir() at
# module load, which crashes. We patch os.mkdir + pathlib.Path.mkdir to silently
# ignore read-only errors, then redirect ARTIFACTS_DIR to /tmp/qa_artifacts
# AFTER utils imports successfully.
#
# BUG FIX (RecursionError on re-run): Kaggle kernels persist Python state
# across cell re-executions. The old code captured "_orig_pathlib_mkdir =
# _pathlib.Path.mkdir" and then had the wrapper call that name as a mutable
# GLOBAL (looked up at call time, not bound at definition time). Re-running
# this cell in the same kernel session meant "_orig_pathlib_mkdir" got
# reassigned to the PREVIOUS run's wrapper — and that previous wrapper's own
# body looks up the SAME global name, which by then pointed back at itself,
# causing infinite self-recursion. Fixed by (a) making patching idempotent
# (skip entirely if already patched — checked via a marker attribute) and
# (b) binding the original function as a default argument, which snapshots
# it ONCE at definition time instead of re-reading a mutable global forever.

import os as _os
import pathlib as _pathlib

# Pre-create writable artifact directories
Path("/tmp/qa_artifacts").mkdir(parents=True, exist_ok=True)
Path("/tmp/qa_feature_cache").mkdir(parents=True, exist_ok=True)
Path("/tmp/qa_experiments").mkdir(parents=True, exist_ok=True)
Path("/tmp/qa_runtime").mkdir(parents=True, exist_ok=True)

# Patch os.mkdir — silently ignore read-only fs errors (idempotent)
if not getattr(_os.mkdir, "_qa_patched", False):
    _orig_os_mkdir = _os.mkdir
    def _safe_os_mkdir(path, mode=0o777, *, _orig=_orig_os_mkdir):
        try:
            return _orig(path, mode)
        except (OSError, PermissionError):
            pass
    _safe_os_mkdir._qa_patched = True
    _os.mkdir = _safe_os_mkdir

# Patch pathlib.Path.mkdir — silently ignore read-only fs errors (idempotent)
if not getattr(_pathlib.Path.mkdir, "_qa_patched", False):
    _orig_pathlib_mkdir = _pathlib.Path.mkdir
    def _safe_pathlib_mkdir(self, mode=0o777, parents=False, exist_ok=False, *, _orig=_orig_pathlib_mkdir):
        try:
            return _orig(self, mode=mode, parents=parents, exist_ok=exist_ok)
        except (OSError, PermissionError):
            pass
    _safe_pathlib_mkdir._qa_patched = True
    _pathlib.Path.mkdir = _safe_pathlib_mkdir

# Patch pathlib.Path.resolve — may fail on broken symlinks (idempotent)
if not getattr(_pathlib.Path.resolve, "_qa_patched", False):
    _orig_resolve = _pathlib.Path.resolve
    def _safe_resolve(self, strict=False, *, _orig=_orig_resolve):
        try:
            return _orig(self, strict=strict)
        except (OSError, RuntimeError):
            return _pathlib.Path(str(self))
    _safe_resolve._qa_patched = True
    _pathlib.Path.resolve = _safe_resolve

print("✓ Patched os.mkdir + pathlib.Path.mkdir (read-only fs guard, idempotent — safe to re-run in the same kernel)")

# Pre-import utils with the patched mkdir — will now succeed
import utils as _utils_mod

# Redirect ALL writable path constants to /tmp
_utils_mod.ARTIFACTS_DIR = Path("/tmp/qa_artifacts")
_utils_mod.RUNTIME_DIR = Path("/tmp/qa_runtime")
_utils_mod.RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
if hasattr(_utils_mod, 'TICKERS_CACHE_PATH'):
    _utils_mod.TICKERS_CACHE_PATH = _utils_mod.RUNTIME_DIR / "nse_tickers_cache.json"
if hasattr(_utils_mod, 'PRESCREEN_CACHE_PATH'):
    _utils_mod.PRESCREEN_CACHE_PATH = _utils_mod.RUNTIME_DIR / "qa_prescreen_cache.json"
if hasattr(_utils_mod, 'FACTOR_IC_CACHE_PATH'):
    _utils_mod.FACTOR_IC_CACHE_PATH = _utils_mod.RUNTIME_DIR / "factor_ic_cache.json"
if hasattr(_utils_mod, 'SQLITE_DB_PATH'):
    _utils_mod.SQLITE_DB_PATH = _utils_mod.RUNTIME_DIR / "qa_portfolio_history.db"
if hasattr(_utils_mod, 'OFFLINE_CHART_MODEL_PATH'):
    _utils_mod.OFFLINE_CHART_MODEL_PATH = _utils_mod.ARTIFACTS_DIR / "chart_ssl_offline_1d.npz"
if hasattr(_utils_mod, 'OFFLINE_CHART_MODEL_META_PATH'):
    _utils_mod.OFFLINE_CHART_MODEL_META_PATH = _utils_mod.ARTIFACTS_DIR / "chart_ssl_offline_1d_meta.json"
print(f"✓ Redirected ARTIFACTS_DIR → /tmp/qa_artifacts, RUNTIME_DIR → /tmp/qa_runtime")

# Now patch FeatureStore + ExperimentTracker
_fs = importlib.import_module("ml_alpha.feature_store")
def _safe_fs_init(self, cache_dir=None):
    self.cache_dir = Path("/tmp/qa_feature_cache"); self.cache_dir.mkdir(parents=True, exist_ok=True)
def _safe_et_init(self, experiments_dir=None):
    self.experiments_dir = Path("/tmp/qa_experiments"); self.experiments_dir.mkdir(parents=True, exist_ok=True)
_fs.FeatureStore.__init__ = _safe_fs_init
_fs.ExperimentTracker.__init__ = _safe_et_init
_fs.CACHE_DIR = Path("/tmp/qa_feature_cache")
_fs.EXPERIMENTS_DIR = Path("/tmp/qa_experiments")
print("✓ Patched FeatureStore + ExperimentTracker")

# Note: ensemble is defined INLINE later in the script (no import needed).
# The old ml_alpha.expanded_ensemble import is no longer used.
print("✓ Inline ensemble will be used (Ridge + LightGBM LambdaRank + CatBoost YetiRank + RandomForest + MLP)")

# ── 4. IMPORT FACTOR LIBRARY + SELF-CONTAINED PATCH ─────────────────────────
# The dataset's factors_100.py may be stale (91 factors instead of 130).
# We import whatever is available, then INJECT the 39 new liquidity/microstructure
# factors directly from this script. This guarantees 130 factors regardless of
# dataset state.

sys.path.insert(0, os.path.join(PROJECT_DIR, "ml_alpha"))

import numpy as _np
import pandas as _pd

def _safe_div_patch(a, b):
    return a / b.replace(0, _np.nan) if hasattr(b, 'replace') else a / (b + 1e-12)

# Embedded factor definitions (39 new liquidity/microstructure factors)
def amihud_5d(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    ret = close.pct_change().abs(); turn = (volume * close).replace(0, _np.nan)
    return (ret / turn).rolling(5).mean()

def amihud_10d(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    ret = close.pct_change().abs(); turn = (volume * close).replace(0, _np.nan)
    return (ret / turn).rolling(10).mean()

def amihud_42d(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    ret = close.pct_change().abs(); turn = (volume * close).replace(0, _np.nan)
    return (ret / turn).rolling(42).mean()

def amihud_z_252(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    ret = close.pct_change().abs(); turn = (volume * close).replace(0, _np.nan)
    a = (ret / turn).rolling(21).mean()
    return (a - a.rolling(252).mean()) / a.rolling(252).std().replace(0, _np.nan)

def amihud_change_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    ret = close.pct_change().abs(); turn = (volume * close).replace(0, _np.nan)
    return (ret / turn).rolling(5).mean() - (ret / turn).rolling(63).mean()

def amihud_term_21_63(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    ret = close.pct_change().abs(); turn = (volume * close).replace(0, _np.nan)
    return _safe_div_patch((ret / turn).rolling(21).mean(), (ret / turn).rolling(63).mean())

def roll_spread_21(close):
    r = close.pct_change()
    cov = r.rolling(21).cov(r.shift(1))
    return (2 * _np.sqrt(_np.abs(cov))).replace([_np.inf, -_np.inf], _np.nan)

def corwin_schultz_21(close, high=None, low=None):
    if high is None or low is None: return _pd.Series(dtype=float)
    log_hl = _np.log(high / low.replace(0, _np.nan))
    beta = log_hl.rolling(2).sum().pow(2) / 6
    gamma = (log_hl.rolling(2).max() - log_hl.rolling(2).min()).pow(2)
    alpha = (_np.sqrt(2) - 1) * (_np.sqrt(beta) - _np.sqrt(gamma)).clip(lower=0)
    spread = 2 * (_np.exp(alpha) - 1) / (1 + _np.exp(alpha))
    return spread.replace([_np.inf, -_np.inf], _np.nan)

def effective_tick_21(close, high=None, low=None):
    if high is None or low is None: return _pd.Series(dtype=float)
    r = close.pct_change()
    zero_freq = (r.abs() < 1e-6).rolling(21).mean()
    hl_range = (high - low) / close.replace(0, _np.nan)
    return zero_freq * hl_range.rolling(21).mean()

def lot_measure_63(close):
    r = close.pct_change()
    return (r.abs() < 1e-6).rolling(63).mean()

def liquidity_beta_63(close, volume, market_close=None):
    if volume is None: return _pd.Series(dtype=float)
    r = close.pct_change()
    sign_vol = _np.sign(r) * volume
    lag_sv = sign_vol.shift(1)
    cov = r.rolling(63).cov(lag_sv)
    var = lag_sv.rolling(63).var().replace(0, _np.nan)
    return _safe_div_patch(cov, var)

def liq_coskew_63(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    ret = close.pct_change().abs(); turn = (volume * close).replace(0, _np.nan)
    amihud = (ret / turn).rolling(21).mean()
    r = close.pct_change()
    return (amihud * r ** 2).rolling(63).mean()

def turnover_velocity_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    turn = (volume * close)
    return turn.rolling(21).mean() / turn.rolling(252).mean().replace(0, _np.nan) - 1

def illiq_persistence_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    ret = close.pct_change().abs(); turn = (volume * close).replace(0, _np.nan)
    a = (ret / turn).rolling(21).mean()
    return a.rolling(21).apply(lambda x: _pd.Series(x).autocorr(lag=1) if len(x) > 5 else 0, raw=False)

def liq_jump_freq_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    ret = close.pct_change().abs(); turn = (volume * close).replace(0, _np.nan)
    a = (ret / turn).rolling(21).mean()
    return (a > 2 * a.rolling(63).mean()).astype(float).rolling(21).mean()

def kyle_lambda_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    r = close.pct_change()
    sv = _np.sign(r) * _np.sqrt(volume.replace(0, _np.nan))
    return _safe_div_patch(r.rolling(21).cov(sv), sv.rolling(21).var().replace(0, _np.nan))

def kyle_lambda_up_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    r = close.pct_change()
    sv = _np.sign(r) * _np.sqrt(volume.replace(0, _np.nan))
    mask = r > 0
    return _safe_div_patch(r.where(mask).rolling(21).cov(sv.where(mask)),
                           sv.where(mask).rolling(21).var().replace(0, _np.nan))

def kyle_lambda_dn_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    r = close.pct_change()
    sv = _np.sign(r) * _np.sqrt(volume.replace(0, _np.nan))
    mask = r < 0
    return _safe_div_patch(r.where(mask).rolling(21).cov(sv.where(mask)),
                           sv.where(mask).rolling(21).var().replace(0, _np.nan))

def kyle_asymmetry_21(close, volume):
    return kyle_lambda_up_21(close, volume) - kyle_lambda_dn_21(close, volume)

def order_imbalance_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    r = close.pct_change()
    sv = _np.sign(r) * volume
    return sv.rolling(21).mean() / volume.rolling(21).mean().replace(0, _np.nan)

def signed_volume_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    r = close.pct_change()
    return (_np.sign(r) * volume).rolling(21).sum()

def vpin_proxy_21(close, high=None, low=None, volume=None):
    if volume is None or high is None or low is None: return _pd.Series(dtype=float)
    r = close.pct_change()
    vol_total = volume.rolling(21).sum().replace(0, _np.nan)
    vol_buy = volume.where(r > 0, 0).rolling(21).sum()
    vol_sell = volume.where(r < 0, 0).rolling(21).sum()
    return (vol_buy - vol_sell).abs() / vol_total

def smart_flow_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    r = close.pct_change()
    vol_q90 = volume.rolling(63).quantile(0.9)
    large_day = volume >= vol_q90
    sv = _np.sign(r) * volume
    smart = sv.where(large_day, 0)
    total = volume.where(large_day, 0).rolling(21).sum().replace(0, _np.nan)
    return smart.rolling(21).sum() / total

def trade_intensity_5(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    r = close.pct_change().abs()
    return (volume / r.replace(0, _np.nan)).rolling(5).mean()

def price_impact_asym_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    r = close.pct_change()
    up = (r.where(r > 0).abs() / volume.where(r > 0).replace(0, _np.nan)).rolling(21).mean()
    dn = (r.where(r < 0).abs() / volume.where(r < 0).replace(0, _np.nan)).rolling(21).mean()
    return up - dn

def vol_concentration_hhi_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    def _hhi(x):
        x = _np.asarray(x, dtype=float); s = x.sum()
        if s <= 0: return _np.nan
        return float(_np.sum((x / s) ** 2))
    return volume.rolling(21).apply(_hhi, raw=True)

def large_trade_freq_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    q80 = volume.rolling(63).quantile(0.8)
    return (volume >= q80).astype(float).rolling(21).mean()

def low_vol_day_freq_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    q20 = volume.rolling(63).quantile(0.2)
    return (volume <= q20).astype(float).rolling(21).mean()

def vol_cluster_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    return volume.rolling(21).apply(
        lambda x: _pd.Series(x).autocorr(lag=1) if len(x) > 5 and _np.std(x) > 0 else 0, raw=False)

def volurst_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    r = close.pct_change()
    sv = _np.sign(r) * volume
    return sv.abs().rolling(21).sum() / volume.rolling(21).sum().replace(0, _np.nan)

def abnormal_volume_z(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    return (volume - volume.rolling(60).mean()) / volume.rolling(60).std().replace(0, _np.nan)

def adv_decay_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    return (volume * close).ewm(span=21, adjust=False).mean()

def volurst_skew_21(close, volume):
    if volume is None: return _pd.Series(dtype=float)
    r = close.pct_change()
    return (_np.sign(r) * volume).rolling(21).skew()

def close_to_mid_21(close, high=None, low=None):
    if high is None or low is None: return _pd.Series(dtype=float)
    rng = (high - low).replace(0, _np.nan)
    return ((close - low) / rng).rolling(21).mean() - 0.5

def range_to_volume_21(close, high=None, low=None, volume=None):
    if high is None or low is None or volume is None: return _pd.Series(dtype=float)
    rng = (high - low) / close.replace(0, _np.nan)
    return (rng / volume.replace(0, _np.nan)).rolling(21).mean()

def hl_ratio_21(close, high=None, low=None):
    if high is None or low is None: return _pd.Series(dtype=float)
    return ((high - low) / close.replace(0, _np.nan)).rolling(21).mean()

def amihud_intraday_21(close, high=None, low=None, volume=None):
    if high is None or low is None or volume is None: return _pd.Series(dtype=float)
    r = close.pct_change().abs()
    hl_turnover = ((high - low) * volume).replace(0, _np.nan)
    return (r / hl_turnover).rolling(21).mean()

def vol_range_21(close, high, low):
    if high is None or low is None: return _pd.Series(dtype=float)
    # Fix: Replace 0 with NaN to avoid division by zero (data glitches, halted trading)
    log_hl = _np.log(high / low.replace(0, _np.nan))
    return (log_hl ** 2 / 4).rolling(21).mean() * 252

def vol_parkinson_21(close, high, low):
    if high is None or low is None: return _pd.Series(dtype=float)
    # Fix: Replace 0 with NaN to avoid division by zero
    log_hl = _np.log(high / low.replace(0, _np.nan))
    return (log_hl ** 2 / (4 * _np.log(2))).rolling(21).mean() * 252

# Explicitly define zero_return_freq_21 so the stale-price drop-list always matches
# (may be missing from stale dataset factors_100.py — this guarantees it's available to drop)
def zero_return_freq_21(close):
    r = close.pct_change()
    return (r.abs() < 1e-6).rolling(21).mean()

# ── NEW FACTORS: additional well-established, leakage-safe families ────────
# All computed purely from each ticker's own historical OHLCV (no forward
# information, no cross-ticker/benchmark dependency since the calling loop
# only passes one ticker's data at a time). Named to avoid colliding with
# whatever factors_100.py already provides -- the injection mechanism below
# only adds a factor under a given name if that name isn't already present,
# so there's no risk of overwriting/duplicating the external dataset.

def pct_off_52w_high(close):
    # Distance from the 252-day rolling high, as a fraction. Distinct from a
    # simple breakout flag -- this is continuous, capturing "how far below
    # the high" rather than "did it break out."
    roll_high = close.rolling(252, min_periods=60).max()
    return (close - roll_high) / roll_high.replace(0, _np.nan)

def pct_off_52w_low(close):
    roll_low = close.rolling(252, min_periods=60).min()
    return (close - roll_low) / roll_low.replace(0, _np.nan)

def new_high_freq_63(close):
    # How often, in the trailing 63 days, did the stock make a new 252-day high?
    roll_high = close.rolling(252, min_periods=60).max()
    is_new_high = (close >= roll_high * 0.999).astype(float)
    return is_new_high.rolling(63).mean()

def overnight_return_21(close, open_col=None):
    # Overnight (close[t-1] -> open[t]) vs intraday (open[t] -> close[t])
    # return decomposition is a well-documented, genuinely distinct momentum
    # source from close-to-close momentum -- overnight and intraday returns
    # have been shown in the literature to have different persistence.
    if open_col is None: return _pd.Series(dtype=float)
    overnight = (open_col / close.shift(1) - 1.0)
    return overnight.rolling(21).mean()

def intraday_return_21(close, open_col=None):
    if open_col is None: return _pd.Series(dtype=float)
    intraday = (close / open_col - 1.0)
    return intraday.rolling(21).mean()

def overnight_intraday_spread_21(close, open_col=None):
    # The DIFFERENCE between overnight and intraday return tendencies --
    # captures whether a stock's moves are driven by gap risk vs session flow.
    if open_col is None: return _pd.Series(dtype=float)
    overnight = (open_col / close.shift(1) - 1.0).rolling(21).mean()
    intraday = (close / open_col - 1.0).rolling(21).mean()
    return overnight - intraday

def kaufman_efficiency_ratio_21(close):
    # Kaufman's Efficiency Ratio: net directional move / sum of absolute
    # daily moves. Close to 1 = strong, efficient trend; close to 0 = choppy,
    # directionless. A well-established, distinct measure from plain
    # momentum or volatility -- it's about trend QUALITY, not magnitude.
    net_move = (close - close.shift(21)).abs()
    total_move = close.diff().abs().rolling(21).sum().replace(0, _np.nan)
    return net_move / total_move

def kaufman_efficiency_ratio_63(close):
    net_move = (close - close.shift(63)).abs()
    total_move = close.diff().abs().rolling(63).sum().replace(0, _np.nan)
    return net_move / total_move

def obv_slope_21(close, volume=None):
    # On-Balance-Volume slope: a classic, well-established volume-price
    # confirmation signal, distinct from raw volume or price momentum alone.
    if volume is None: return _pd.Series(dtype=float)
    direction = _np.sign(close.diff()).fillna(0.0)
    obv = (direction * volume).cumsum()
    return obv.diff(21) / volume.rolling(21).mean().replace(0, _np.nan)

def money_flow_multiplier_21(close, high=None, low=None, volume=None):
    # Chaikin-style money flow: where the close sits within the day's range,
    # weighted by volume, averaged over the window. Different information
    # from close_to_mid_21 (which isn't volume-weighted).
    if high is None or low is None or volume is None: return _pd.Series(dtype=float)
    rng = (high - low).replace(0, _np.nan)
    mfm = ((close - low) - (high - close)) / rng
    return (mfm * volume).rolling(21).sum() / volume.rolling(21).sum().replace(0, _np.nan)

def ret_skew_21(close):
    return close.pct_change().rolling(21).skew()

def ret_skew_252(close):
    return close.pct_change().rolling(252).skew()

def ret_kurt_21(close):
    return close.pct_change().rolling(21).kurt()

def ret_kurt_252(close):
    return close.pct_change().rolling(252).kurt()

def atr_normalized_mom_21(close, high=None, low=None):
    # Momentum normalized by Average True Range -- a risk-adjusted momentum
    # measure distinct from raw momentum, common in trend-following systems.
    if high is None or low is None: return _pd.Series(dtype=float)
    tr = _pd.concat([
        (high - low),
        (high - close.shift(1)).abs(),
        (low - close.shift(1)).abs(),
    ], axis=1).max(axis=1)
    atr = tr.rolling(21).mean().replace(0, _np.nan)
    mom = close - close.shift(21)
    return mom / atr

def volume_cv_21(close, volume=None):
    # Coefficient of variation of volume -- captures volume STABILITY
    # (predictable, steady trading vs erratic/event-driven), distinct from
    # the level or trend of volume itself.
    if volume is None: return _pd.Series(dtype=float)
    m = volume.rolling(21).mean().replace(0, _np.nan)
    s = volume.rolling(21).std()
    return s / m

def gap_frequency_21(close, open_col=None):
    # How often, in the trailing window, did the stock gap >1% at the open?
    # A distinct liquidity/event-risk proxy from continuous volatility measures.
    if open_col is None: return _pd.Series(dtype=float)
    gap = (open_col / close.shift(1) - 1.0).abs()
    return (gap > 0.01).astype(float).rolling(21).mean()

def price_acceleration_21(close):
    # Second derivative of price trend: is momentum itself speeding up or
    # slowing down. Distinct from mom_accel_63 (different window + uses
    # momentum-of-momentum on RETURNS rather than raw price differencing).
    ret = close.pct_change()
    mom_5 = ret.rolling(5).mean()
    return mom_5.diff(21)

def drawdown_recovery_63(close):
    # How far has price recovered from its trailing max drawdown, as a
    # fraction -- distinct from plain drawdown_252 (magnitude) since this
    # captures RECOVERY DYNAMICS, which has separate predictive content.
    roll_max = close.rolling(63, min_periods=20).max()
    trough = close.rolling(63, min_periods=20).min()
    dd_range = (roll_max - trough).replace(0, _np.nan)
    return (close - trough) / dd_range

_EMBEDDED_FACTORS = {
    "amihud_5d": amihud_5d, "amihud_10d": amihud_10d, "amihud_42d": amihud_42d,
    "amihud_z_252": amihud_z_252, "amihud_change_21": amihud_change_21,
    "amihud_term_21_63": amihud_term_21_63,
    "roll_spread_21": roll_spread_21, "corwin_schultz_21": corwin_schultz_21,
    "effective_tick_21": effective_tick_21, "lot_measure_63": lot_measure_63,
    "liquidity_beta_63": liquidity_beta_63, "liq_coskew_63": liq_coskew_63,
    "turnover_velocity_21": turnover_velocity_21,
    "illiq_persistence_21": illiq_persistence_21, "liq_jump_freq_21": liq_jump_freq_21,
    "kyle_lambda_21": kyle_lambda_21, "kyle_lambda_up_21": kyle_lambda_up_21,
    "kyle_lambda_dn_21": kyle_lambda_dn_21, "kyle_asymmetry_21": kyle_asymmetry_21,
    "order_imbalance_21": order_imbalance_21, "signed_volume_21": signed_volume_21,
    "vpin_proxy_21": vpin_proxy_21, "smart_flow_21": smart_flow_21,
    "trade_intensity_5": trade_intensity_5, "price_impact_asym_21": price_impact_asym_21,
    "vol_concentration_hhi_21": vol_concentration_hhi_21,
    "large_trade_freq_21": large_trade_freq_21,
    "low_vol_day_freq_21": low_vol_day_freq_21,
    "vol_cluster_21": vol_cluster_21, "volurst_21": volurst_21,
    "abnormal_volume_z": abnormal_volume_z, "adv_decay_21": adv_decay_21,
    "volurst_skew_21": volurst_skew_21,
    "close_to_mid_21": close_to_mid_21, "range_to_volume_21": range_to_volume_21,
    "hl_ratio_21": hl_ratio_21, "amihud_intraday_21": amihud_intraday_21,
    "vol_range_21": vol_range_21, "vol_parkinson_21": vol_parkinson_21,
    "zero_return_freq_21": zero_return_freq_21,  # explicit so drop-list always matches
    # New additions (see functions above for rationale on each):
    "pct_off_52w_high": pct_off_52w_high, "pct_off_52w_low": pct_off_52w_low,
    "new_high_freq_63": new_high_freq_63,
    "overnight_return_21": overnight_return_21, "intraday_return_21": intraday_return_21,
    "overnight_intraday_spread_21": overnight_intraday_spread_21,
    "kaufman_efficiency_ratio_21": kaufman_efficiency_ratio_21,
    "kaufman_efficiency_ratio_63": kaufman_efficiency_ratio_63,
    "obv_slope_21": obv_slope_21, "money_flow_multiplier_21": money_flow_multiplier_21,
    "ret_skew_21": ret_skew_21, "ret_skew_252": ret_skew_252,
    "ret_kurt_21": ret_kurt_21, "ret_kurt_252": ret_kurt_252,
    "atr_normalized_mom_21": atr_normalized_mom_21,
    "volume_cv_21": volume_cv_21, "gap_frequency_21": gap_frequency_21,
    "price_acceleration_21": price_acceleration_21,
    "drawdown_recovery_63": drawdown_recovery_63,
}

# Import whatever factors_100.py provides, then inject the missing ones
_ALL_FACTORS_100 = {}
try:
    from factors_100 import ALL_FACTORS_100 as _imported_factors
    _ALL_FACTORS_100 = dict(_imported_factors)
    print(f"✓ Loaded {len(_ALL_FACTORS_100)} factors from factors_100.py")
except ImportError:
    print("⚠️  factors_100.py not found — will use embedded factors only")

_injected_count = 0
for _fname, _ffunc in _EMBEDDED_FACTORS.items():
    if _fname not in _ALL_FACTORS_100:
        _ALL_FACTORS_100[_fname] = _ffunc
        _injected_count += 1

if _injected_count > 0:
    print(f"✓ INJECTED {_injected_count} missing factors (dataset factors_100.py was stale)")
    print(f"  Total factors now: {len(_ALL_FACTORS_100)}")
else:
    print(f"✓ Dataset factors_100.py is up-to-date — no injection needed")

ALL_FACTORS_100 = _ALL_FACTORS_100
print(f"✓ Final factor count: {len(ALL_FACTORS_100)}")

if len(ALL_FACTORS_100) < 100:
    print(f"❌ FATAL: Only {len(ALL_FACTORS_100)} factors available — expected 130.")
    sys.exit(1)

from ml_alpha import AlphaEngine
print("✓ AlphaEngine imported")

# ── 5. CUSTOM FIT FUNCTION WITH 100+ FACTORS ────────────────────────────────
# We bypass engine.fit() and run our own pipeline with ALL factors,
# then let IC+Lasso select which ones have predictive power.

print(f"\n{'='*60}")
print(f"100+ FACTORS TRAINING (Kaggle Linux)")
print(f"{'='*60}")
print(f"Total factors: {len(ALL_FACTORS_100)}")
print(f"Models: Ridge + LightGBM LambdaRank + CatBoost YetiRank + RandomForest + MLP (stacking)")
print(f"CV: CPCV (15 paths) | Labeling: Triple-barrier | Loss: Ranking (LambdaRank/YetiRank)")
print(f"Feature selection: IC filter + Lasso (per-fold, no leakage)")
print(f"{'='*60}\n")

# 5a. Fetch universe + prices (reuse engine's methods)
engine = AlphaEngine(model_type="blend")
from datetime import date as _date
_end = _date.today()
_start = _end - timedelta(days=365 * 4)

print(f"Training: {_start} -> {_end}")
print(f"Fetching Nifty 500 universe...")
tickers = engine._get_universe("nifty500")
print(f"  {len(tickers)} tickers from _get_universe")

# Fallback: if _get_universe returns < 50 tickers (NSE unreachable / Kaggle network limits),
# fetch NSE index constituents DYNAMICALLY from the NSE archives CSV endpoint.
# Never hardcode ticker lists — they go stale (splits, renames, delistings).
# Try Nifty 50, Nifty Next 50, Nifty Midcap 150, Nifty Smallcap 250 in order
# until we get enough liquid names.
if len(tickers) < 50:
    print(f"  ⚠️ Only {len(tickers)} tickers from _get_universe — trying dynamic NSE archive fetch")
    import urllib.request
    import csv as _csv
    import io as _io

    _NSE_INDEX_CSVS = [
        ("nifty50",           "https://archives.nseindia.com/content/indices/ind_nifty50list.csv"),
        ("niftynext50",       "https://archives.nseindia.com/content/indices/ind_niftynext50list.csv"),
        ("nifty100",          "https://archives.nseindia.com/content/indices/ind_nifty100list.csv"),
        ("niftymidcap150",    "https://archives.nseindia.com/content/indices/ind_niftymidcap150list.csv"),
        ("niftysmallcap250",  "https://archives.nseindia.com/content/indices/ind_niftysmallcap250list.csv"),
        ("nifty500",          "https://archives.nseindia.com/content/indices/ind_nifty500list.csv"),
    ]

    _fallback_tickers = []
    for _idx_name, _csv_url in _NSE_INDEX_CSVS:
        if len(_fallback_tickers) >= 200:
            break
        try:
            _req = urllib.request.Request(_csv_url, headers={
                "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"
            })
            with urllib.request.urlopen(_req, timeout=20) as _resp:
                _csv_text = _resp.read().decode("utf-8", errors="ignore")
            _reader = _csv.DictReader(_io.StringIO(_csv_text))
            for _row in _reader:
                # NSE CSV has "Symbol" column — append .NS suffix for yfinance
                _sym = _row.get("Symbol") or _row.get("SYMBOL") or _row.get("symbol")
                if _sym:
                    _fallback_tickers.append(f"{_sym.strip()}.NS")
            print(f"    ✓ {_idx_name}: fetched {len(_fallback_tickers)} cumulative tickers")
        except Exception as _e:
            print(f"    ✗ {_idx_name}: fetch failed ({_e})")

    if _fallback_tickers:
        # Deduplicate, preserving order
        tickers = list(dict.fromkeys(_fallback_tickers))
        print(f"  ✓ Dynamic fallback universe: {len(tickers)} tickers from NSE archives")

if len(tickers) < 10:
    print("❌ FATAL: Cannot obtain a meaningful ticker universe (NSE archives unreachable).")
    print("   Check Kaggle internet setting and try again.")
    sys.exit(1)

print(f"Fetching prices...")
panel, benchmark = engine._fetch_prices(tickers, _start - timedelta(days=450), _end)
close_df = panel.get("Close", pd.DataFrame())
high_df = panel.get("High", pd.DataFrame())
low_df = panel.get("Low", pd.DataFrame())
volume_df = panel.get("Volume", pd.DataFrame())
open_df = panel.get("Open", pd.DataFrame())
print(f"  {len(close_df)} trading days, {close_df.shape[1]} tickers with data")

# LIQUIDITY FILTER: drop stocks below ₹50cr ADV so the model can't learn
# "illiquid = high return" — that's a stale-price artifact, not real alpha.
# ₹50cr ADV ≈ top ~150-200 NSE names by liquidity — the actually tradeable universe
# without stale-price issues. ₹10cr was too low (only dropped 7/500 Nifty names).
#
# POINT-IN-TIME FIX (Grok): use head(63) not tail(63). tail(63) selects stocks
# liquid at the END of the period (2026) — survivorship bias + look-ahead.
# head(63) selects stocks liquid at the START (2022) — no look-ahead, and
# avoids including stocks that IPO'd recently (sparse early history).
_MIN_ADV_INR = 500_000_000  # ₹50 crore
if volume_df.shape[1] > 0 and close_df.shape[1] > 0:
    _adv_63d = (volume_df.head(63) * close_df.head(63)).mean()  # head, not tail
    _liquid_tickers = _adv_63d[_adv_63d >= _MIN_ADV_INR].index.tolist()
    _dropped_n = len(tickers) - len(_liquid_tickers)
    if _liquid_tickers and _dropped_n > 0:
        close_df = close_df[_liquid_tickers]
        high_df = high_df[_liquid_tickers] if high_df.shape[1] > 0 else high_df
        low_df = low_df[_liquid_tickers] if low_df.shape[1] > 0 else low_df
        volume_df = volume_df[_liquid_tickers] if volume_df.shape[1] > 0 else volume_df
        open_df = open_df[_liquid_tickers] if open_df.shape[1] > 0 else open_df
        tickers = _liquid_tickers
        print(f"  Liquidity filter (ADV ≥ ₹{_MIN_ADV_INR/1e7:.0f}cr, point-in-time head(63)): "
              f"kept {len(_liquid_tickers)}, dropped {_dropped_n} illiquid names")

# 5b. Compute ALL 100+ factors for ALL tickers
print(f"\nComputing {len(ALL_FACTORS_100)} factors for {len(tickers)} tickers...")
factor_panels = {}
master_idx = close_df.index.sort_values()

for fname, ffunc in ALL_FACTORS_100.items():
    try:
        col_dict = {}
        for ticker in tickers:
            try:
                close = close_df[ticker].dropna() if ticker in close_df.columns else pd.Series(dtype=float)
                if len(close) < 30:
                    continue
                high = high_df[ticker].dropna() if ticker in high_df.columns else None
                low = low_df[ticker].dropna() if ticker in low_df.columns else None
                vol = volume_df[ticker].dropna() if ticker in volume_df.columns else None
                opn = open_df[ticker].dropna() if ticker in open_df.columns else None

                # Call factor function with appropriate args
                import inspect
                sig = inspect.signature(ffunc)
                params = list(sig.parameters.keys())
                kwargs = {}
                if "high" in params: kwargs["high"] = high
                if "low" in params: kwargs["low"] = low
                if "volume" in params: kwargs["volume"] = vol
                if "open_col" in params: kwargs["open_col"] = opn

                result = ffunc(close, **kwargs)
                if result is not None and len(result) > 0:
                    col_dict[ticker] = result
            except Exception:
                continue

        if col_dict:
            df = pd.DataFrame(col_dict)
            df = df.reindex(master_idx)
            factor_panels[fname] = df
    except Exception as e:
        print(f"  ⚠️  {fname} failed: {e}")
        continue

print(f"  {len(factor_panels)} factors computed successfully")

# 5b2. FUNDAMENTALS — genuinely orthogonal information, not derived from price.
# ═══════════════════════════════════════════════════════════════════════════
# Every factor above (momentum, volatility, liquidity/microstructure) is
# derived from the SAME OHLCV price series -- which is exactly why we kept
# finding massive collinearity across "different" factors. Fundamentals
# (profitability, leverage, growth) are priced on a different cadence
# (quarterly filings, not daily price action) and have real academic backing
# (Fama-French value/quality factors) for being largely uncorrelated with
# price-momentum signals. This is a genuinely new information source, not
# another reshaping of the same one.
#
# CRITICAL: POINT-IN-TIME CORRECTNESS.
# Naively joining "current" fundamentals across 4 years of training history
# would be a leak far worse than the lot_measure_63 one caught earlier in
# this project -- it would use TODAY's ROE to "predict" 2022 returns. Every
# value used below is lagged by REPORT_LAG_DAYS after its fiscal period end
# before being treated as "known," matching SEBI's actual disclosure
# deadlines (unaudited quarterly results within 45 days, audited annual
# results within 60 days of period end -- see SEBI LODR Regulation 33). 60
# days is used as a conservative buffer covering both cases.
#
# HONEST LIMITATION: this could not be tested against live Yahoo Finance
# data from the environment that built this script (network egress to
# query1.finance.yahoo.com is blocked there). The field-name lookup below is
# written defensively (multiple aliases per ratio, since yfinance's exact
# row-label naming has changed across versions) specifically because of
# that -- but verify the coverage diagnostics printed below on first run,
# since this is the one part of the pipeline that hasn't been empirically
# validated the way everything else in this script has been.
print("\nFetching point-in-time fundamentals (ROE, D/E, margins, growth)...")
print(f"  Using a {60}-day reporting lag (SEBI LODR disclosure deadlines) "
      f"to prevent look-ahead bias -- see comment above for why this matters.")

_REPORT_LAG_DAYS = 60
_MAX_STALENESS_DAYS = 200  # beyond this since last report, mark NaN rather
# than use badly stale fundamentals (e.g. a company that stopped reporting).

def _find_row(df, aliases):
    """Robust line-item lookup: yfinance's exact row labels have changed
    across versions (e.g. 'Total Revenue' vs 'TotalRevenue', 'Stockholders
    Equity' vs 'Total Stockholder Equity'). Try each alias as a
    case-insensitive substring match against the actual index."""
    if df is None or df.empty:
        return None
    idx_lower = {str(i).lower().replace(" ", ""): i for i in df.index}
    for alias in aliases:
        key = alias.lower().replace(" ", "")
        for idx_key, orig in idx_lower.items():
            if key in idx_key:
                return df.loc[orig]
    return None

def _fetch_fundamentals_pit(ticker, master_idx):
    """Returns dict of {ratio_name: pd.Series indexed by master_idx} for one
    ticker, with each value only becoming "known" REPORT_LAG_DAYS after its
    fiscal period end, forward-filled until the next report (capped at
    MAX_STALENESS_DAYS)."""
    try:
        import yfinance as _yf
        t = _yf.Ticker(ticker)
        qf = t.quarterly_financials      # income statement, columns = period-end dates
        qb = t.quarterly_balance_sheet   # balance sheet, columns = period-end dates
        if qf is None or qf.empty or qb is None or qb.empty:
            return {}

        revenue = _find_row(qf, ["Total Revenue", "TotalRevenue", "Revenue"])
        net_income = _find_row(qf, ["Net Income", "NetIncome", "Net Income Common Stockholders"])
        equity = _find_row(qb, ["Stockholders Equity", "Total Stockholder Equity",
                                 "Total Equity Gross Minority Interest"])
        total_debt = _find_row(qb, ["Total Debt", "TotalDebt"])
        current_assets = _find_row(qb, ["Total Current Assets", "CurrentAssets"])
        current_liab = _find_row(qb, ["Total Current Liabilities", "CurrentLiabilities"])

        if revenue is None or net_income is None:
            return {}  # not enough to compute anything meaningful

        # Period-end dates come from column headers, sorted oldest -> newest
        periods = sorted(revenue.index)
        ratios = {"fund_roe": {}, "fund_debt_equity": {}, "fund_profit_margin": {},
                   "fund_rev_growth_yoy": {}, "fund_earnings_growth_yoy": {}}
        for i, period_end in enumerate(periods):
            avail_date = pd.Timestamp(period_end) + pd.Timedelta(days=_REPORT_LAG_DAYS)
            rev_val = revenue.get(period_end)
            ni_val = net_income.get(period_end)
            eq_val = equity.get(period_end) if equity is not None else None
            debt_val = total_debt.get(period_end) if total_debt is not None else None

            if rev_val and rev_val != 0 and ni_val is not None:
                ratios["fund_profit_margin"][avail_date] = ni_val / rev_val
            if eq_val and eq_val != 0 and ni_val is not None:
                ratios["fund_roe"][avail_date] = ni_val / eq_val
            if eq_val and eq_val != 0 and debt_val is not None:
                ratios["fund_debt_equity"][avail_date] = debt_val / eq_val
            # YoY growth needs the SAME quarter one year earlier (i-4 in a
            # quarterly series), not the immediately prior quarter.
            if i >= 4:
                prev_period = periods[i - 4]
                rev_prev = revenue.get(prev_period)
                ni_prev = net_income.get(prev_period)
                if rev_val is not None and rev_prev and rev_prev != 0:
                    ratios["fund_rev_growth_yoy"][avail_date] = (rev_val - rev_prev) / abs(rev_prev)
                if ni_val is not None and ni_prev and ni_prev != 0:
                    ratios["fund_earnings_growth_yoy"][avail_date] = (ni_val - ni_prev) / abs(ni_prev)

        out = {}
        for rname, vals in ratios.items():
            if not vals:
                continue
            s = pd.Series(vals).sort_index()
            # Forward-fill onto the trading calendar, but cap staleness --
            # a value more than MAX_STALENESS_DAYS past its availability
            # date (i.e. the company stopped reporting, or there's a data
            # gap) should NOT keep being used as if still current.
            reindexed = s.reindex(master_idx, method="ffill")
            days_since_avail = pd.Series(master_idx, index=master_idx).apply(
                lambda d: (d - s.index[s.index <= d].max()).days if (s.index <= d).any() else 10**9
            )
            reindexed[days_since_avail > _MAX_STALENESS_DAYS] = float("nan")
            out[rname] = reindexed
        return out
    except Exception:
        return {}

_fund_panels = {"fund_roe": {}, "fund_debt_equity": {}, "fund_profit_margin": {},
                 "fund_rev_growth_yoy": {}, "fund_earnings_growth_yoy": {}}
_fund_covered = 0
for _i, _ticker in enumerate(tickers):
    _res = _fetch_fundamentals_pit(_ticker, master_idx)
    if _res:
        _fund_covered += 1
        for _rname, _series in _res.items():
            _fund_panels[_rname][_ticker] = _series
    if (_i + 1) % 50 == 0:
        print(f"  ...fetched fundamentals for {_i+1}/{len(tickers)} tickers "
              f"({_fund_covered} with usable data so far)")

for _rname, _cols in _fund_panels.items():
    if _cols:
        factor_panels[_rname] = pd.DataFrame(_cols).reindex(master_idx)

print(f"  Fundamentals coverage: {_fund_covered}/{len(tickers)} tickers had "
      f"usable quarterly financial data")
print(f"  Added {sum(1 for r, c in _fund_panels.items() if c)}/5 fundamental "
      f"ratio panels: {[r for r, c in _fund_panels.items() if c]}")
if _fund_covered < len(tickers) * 0.3:
    print(f"  ⚠️  Coverage under 30% -- yfinance's fundamentals data for NSE "
          f"names can be inconsistent. Check the _find_row aliases above "
          f"against what t.quarterly_financials/quarterly_balance_sheet "
          f"actually return for a sample ticker if this looks too low.")

# 5c. Add cross-sectional rank transforms (SELECTIVELY — only where they add
# genuinely different information)
# BUG FIX: this used to unconditionally rank-transform EVERY factor,
# doubling the candidate pool 130 -> 260. Across multiple real runs, nearly
# every volatility-family factor (vol_252d, vol_126d, vol_63d, vol_21d,
# true_range_pct, hl_ratio_21, vol_of_vol_63, ...) showed its raw and
# _rank versions with virtually IDENTICAL IC every single time -- meaning
# the rank version was carrying almost no distinct information, just
# inflating the search width the DSR has to be penalized for.
#
# The fix: only keep a factor's rank-transform if it's actually structurally
# different from the raw values. This is decided PURELY from each factor's
# own cross-sectional distribution shape (Pearson correlation between raw
# values and their own rank, averaged across dates) -- it never looks at
# forward returns, IC, or any label. That makes it a legitimate a priori
# rule applied uniformly to all factors, NOT hindsight cherry-picking of
# "whichever factors happened to work" (which would just hide the same
# multiple-testing exposure instead of genuinely reducing it).
#
# Intuition: an already roughly-symmetric/comparable factor (e.g. a
# momentum z-score) has raw-vs-rank correlation ~0.95-0.98 -- the rank
# transform changes almost nothing. A heavy-tailed factor (e.g. raw volume,
# turnover, dollar-value factors) has much lower raw-vs-rank correlation
# (~0.4-0.6) -- ranking genuinely compresses outliers and captures a
# different relationship, so it's worth keeping as a separate candidate.
print("Adding cross-sectional rank transforms (skipping structurally redundant ones)...")
_RANK_REDUNDANCY_THRESHOLD = 0.85  # skip rank version if raw-vs-rank corr exceeds this
rank_panels = {}
_skipped_redundant = []
_kept_distinct = []
for fname, df in factor_panels.items():
    if not (isinstance(df, pd.DataFrame) and not df.empty):
        continue
    ranked = df.rank(axis=1, pct=True)
    try:
        _redundancy = df.corrwith(ranked, axis=1, method="pearson").mean()
        _redundancy = float(_redundancy) if np.isfinite(_redundancy) else 0.0
    except Exception:
        _redundancy = 0.0  # if the check itself fails, err toward keeping the rank version
    if _redundancy > _RANK_REDUNDANCY_THRESHOLD:
        _skipped_redundant.append((fname, _redundancy))
    else:
        rank_panels[f"{fname}_rank"] = ranked
        _kept_distinct.append((fname, _redundancy))
factor_panels.update(rank_panels)
print(f"  Kept {len(_kept_distinct)} rank transforms as genuinely distinct "
      f"(raw-vs-rank corr <= {_RANK_REDUNDANCY_THRESHOLD})")
print(f"  Skipped {len(_skipped_redundant)} redundant rank transforms "
      f"(raw-vs-rank corr > {_RANK_REDUNDANCY_THRESHOLD}, e.g. "
      f"{', '.join(f'{n}({c:.2f})' for n, c in _skipped_redundant[:5])}"
      f"{' ...' if len(_skipped_redundant) > 5 else ''})")
print(f"  {len(factor_panels)} total factors after rank transforms "
      f"(was would-be {len(factor_panels) + len(_skipped_redundant)} if unconditional)")

# 5d. Preprocess (winsorize + standardize)
print("Preprocessing factors (winsorize + standardize)...")
processed = {}
for fname, df in factor_panels.items():
    if not isinstance(df, pd.DataFrame) or df.empty:
        continue
    MIN_PERIODS = 30
    def _winsorize_row(row, **kwargs):
        valid = row.dropna()
        if len(valid) < MIN_PERIODS: return row
        lo, hi = valid.quantile(0.01), valid.quantile(0.99)
        return row.clip(lo, hi)
    def _zscore_row(row, **kwargs):
        valid = row.dropna()
        if len(valid) < MIN_PERIODS: return row
        std = valid.std()
        if not np.isfinite(std) or std < 1e-9: return row * 0.0
        return (row - valid.mean()) / std
    try:
        w = df.apply(_winsorize_row, axis=1)
        z = w.apply(_zscore_row, axis=1)
        processed[fname] = z.fillna(0.0)
    except Exception:
        processed[fname] = df.fillna(0.0)

print(f"  {len(processed)} factors preprocessed")

# 5e. Build training dataset with triple-barrier labeling
print("Building training dataset with triple-barrier labeling...")
from ml_alpha.labeling import compute_daily_volatility, triple_barrier_labels, labels_to_forward_returns

forward_return_days = 21  # ~1 calendar month of trading days.
# WAS 10. Changed based on: (1) the dominant feature, mom_skip21_252, is the
# classic 12-1 month momentum construction, designed for monthly rebalancing
# -- training it against a 10-day label was a methodological mismatch;
# (2) Indian market transaction costs (STT + brokerage + market impact on
# the smaller/mid-cap-heavy names in this universe) tend to eat most of a
# short-horizon (1-10 day) edge before it's realized; (3) the live desktop
# app's own WFO steps run ~21 trading days apart (monthly) -- training on a
# different horizon than the strategy is actually deployed on means the
# reported metrics don't describe real usage.
# NOTE: this is a compromise, not a clean win -- several selected features
# (rev_1d/3d/5d/10d) are short-term reversal signals that decay fast and
# don't naturally want a 21-day hold. A single holding period can't be
# perfectly right for both a momentum and a reversal factor at once.
rebalance_freq_days = 5  # unchanged: this only controls training-sample
# density (how many overlapping windows to include), not a live trading
# assumption -- CPCV purging (below) is what actually prevents leakage
# across these overlapping samples, so keeping this fine-grained is fine
# and gives the model more training examples.

vol = compute_daily_volatility(close_df, span=100)
tb_labels = triple_barrier_labels(close_df, vol, upper_mult=2.0, lower_mult=1.0, max_holding_days=forward_return_days)

if tb_labels.empty or tb_labels.isna().all().all():
    print("  ⚠️ Triple-barrier failed — using simple forward returns")
    fwd_ret = close_df.shift(-forward_return_days) / close_df - 1.0
    fwd_ret_stacked = fwd_ret.stack()
    fwd_ret_stacked.name = "forward_return"
    tb_label_stacked = pd.Series(0, index=fwd_ret_stacked.index, name="tb_label")
else:
    target, labels = labels_to_forward_returns(tb_labels, close_df, forward_return_days)
    fwd_ret_stacked = target
    fwd_ret_stacked.name = "forward_return"
    tb_label_stacked = labels
    tb_label_stacked.name = "tb_label"

# Stack all factor panels
# The real fixes (target winsorization + rank transform + liquidity filter + stronger
# regularization) are already applied above. Those solved the DOMINANCE problem
# (lot_measure went from 52% → 10.4%). 
#
# Additional defensive cleanup: drop stale-price / illiquidity-proxy factors by
# SUBSTRING match (not exact key — more robust to rank-transform renames). Even at
# 10.4% importance, lot_measure is theoretically a stale-price proxy. Removing it
# makes the result more defensible. Uses substring matching per Gemini's suggestion.
_STALE_SUBSTRINGS = ["lot_measure", "zero_return", "effective_tick", "volurst"]
_dropped_stale = [f for f in list(processed.keys()) if any(sub in f for sub in _STALE_SUBSTRINGS)]
for f in _dropped_stale:
    del processed[f]
if _dropped_stale:
    print(f"  ⚠️  Dropped {len(_dropped_stale)} stale-price / illiquidity proxies "
          f"(substring match): {_dropped_stale[:6]}{'...' if len(_dropped_stale) > 6 else ''}")

factor_series = {}
for fname, df in processed.items():
    if isinstance(df, pd.DataFrame) and not df.empty:
        stacked = df.stack()
        stacked.name = fname
        factor_series[fname] = stacked

if not factor_series:
    print("❌ No factors to train on!")
    sys.exit(1)

all_series = [fwd_ret_stacked, tb_label_stacked] + list(factor_series.values())
df = pd.concat(all_series, axis=1)
df = df.dropna(subset=["forward_return"])

feature_cols = [c for c in df.columns if c not in ("forward_return", "tb_label")]
print(f"  {len(df):,} observations × {len(feature_cols)} features")

# ── TARGET WINSORIZATION + RANK TRANSFORM ────────────────────────────────────
# The IS IC of 0.35 was absurd because extreme forward-return outliers (takeovers,
# circuit filters, 20% single-day moves) let the tree models fit a few observations
# perfectly. Winsorize the target at 1st/99th percentile per date, then rank-transform
# cross-sectionally so no single observation can dominate the loss.
#
# IMPORTANT: keep the raw forward_return for Sharpe/DSR computation. The rank-
# transformed version is ONLY for model training. Using ranks for Sharpe would
# compute the Sharpe of rank-positions, not actual portfolio returns — meaningless.
print("  Winsorizing forward returns (1st/99th pct) + cross-sectional rank transform...")
df["forward_return_raw"] = df["forward_return"].copy()  # preserve for Sharpe/DSR
# Winsorize per date (cross-sectionally)
def _winsorize_cs(group):
    lo, hi = group.quantile(0.01), group.quantile(0.99)
    return group.clip(lo, hi)
df["forward_return"] = df.groupby(level=0)["forward_return"].transform(_winsorize_cs)
# Rank-transform per date (0 to 1) — this is what the model trains on
df["forward_return"] = df.groupby(level=0)["forward_return"].rank(pct=True) - 0.5  # centered around 0
print(f"  Target transformed: range [{df['forward_return'].min():.3f}, {df['forward_return'].max():.3f}], "
      f"std={df['forward_return'].std():.3f}")

# Sample at rebalance frequency
all_dates = df.index.get_level_values(0).unique().sort_values()
if len(all_dates) > 252:
    df = df.loc[df.index.get_level_values(0) >= all_dates[252]]
    all_dates = df.index.get_level_values(0).unique().sort_values()
sample_dates = all_dates[::rebalance_freq_days]
df = df.loc[df.index.get_level_values(0).isin(sample_dates)]
print(f"  After sampling: {len(df):,} observations × {len(feature_cols)} features")

# 5f. Feature selection (IC + Lasso) — INITIAL selection on full data for reporting
# NOTE: This is used ONLY for the final model retrain and for reporting top factors.
# The CPCV loop below runs feature selection PER-FOLD on training data only to
# prevent leakage (Grok point #3). Running selection on full data before CPCV
# would leak test-fold information into feature selection.
print(f"\nRunning initial feature selection (IC filter + Lasso) on {len(feature_cols)} factors...")
print(f"  (Per-fold selection runs inside CPCV to prevent leakage)")
from ml_alpha.feature_selection import select_factors
try:
    selected_features, ic_stats = select_factors(
        {f: processed[f] for f in feature_cols if f in processed},
        df["forward_return"], df[feature_cols], df["forward_return"],
        ic_threshold=0.01,
        min_features=10,
        max_features=20,  # BUG FIX: see ml_alpha/feature_selection.py — caps
        # against Lasso instability under high collinearity, which caused
        # selection to blow up to 106/192 factors in one real run (massive
        # overfit, IS Sharpe >10) vs 10/192 on near-identical data otherwise.
    )
    if len(selected_features) < 10:
        selected_features = feature_cols
    print(f"  Selected {len(selected_features)}/{len(feature_cols)} factors (for final model)")
    sorted_ic = sorted(ic_stats.items(), key=lambda x: -abs(x[1].get("mean_ic", 0)))
    for fname, stats in sorted_ic[:20]:
        print(f"    {fname:30s} IC={stats['mean_ic']:+.4f} IR={stats.get('ir', 0):+.4f}")
except Exception as e:
    print(f"  Feature selection failed: {e} — using all factors")
    selected_features = feature_cols

# 5g. CPCV with full ensemble
print(f"\nRunning CPCV (6 groups, 2 test = 15 paths)...")
from ml_alpha.walk_forward import CombinatorialPurgedCV
cv = CombinatorialPurgedCV(
    n_groups=6, n_test_groups=2,
    # BUG FIX: was hardcoded purge_window_days=14, sized for the old
    # forward_return_days=10. The purge window must be >= the label horizon,
    # or samples near a CV fold boundary can have forward-return windows
    # that overlap into the OTHER fold -- exactly the leakage purging exists
    # to prevent. Now scales with forward_return_days automatically, with a
    # small margin, so this can't silently drift out of sync again.
    purge_window_days=forward_return_days + 4,
    forward_return_days=forward_return_days,
)

unique_dates = pd.DatetimeIndex(sorted(df.index.get_level_values(0).unique()))
per_fold = []
is_sharpes, oos_sharpes = [], []
all_oos_ls_rets = []
from ml_alpha.metrics import spearman_ic, quantile_sharpe, deflated_sharpe_ratio, walk_forward_efficiency

# ═══════════════════════════════════════════════════════════════════════════════
# INLINE ENSEMBLE — self-contained, no import from ml_alpha.expanded_ensemble
# 5 diverse models with ranking losses + purged stacking meta-learner
# ═══════════════════════════════════════════════════════════════════════════════
import platform as _platform
_is_macos_arm = (_platform.system() == "Darwin" and _platform.machine() == "arm64")
_HAS_LGB = False; _HAS_XGB = False; _HAS_CB = False; _HAS_SKLEARN = False; _HAS_TORCH = False
try:
    from sklearn.linear_model import Ridge as _Ridge, LogisticRegression as _LogReg
    from sklearn.ensemble import RandomForestRegressor as _RF
    _HAS_SKLEARN = True
except ImportError: pass
if not _is_macos_arm:
    try: import lightgbm as _lgb; _HAS_LGB = True
    except ImportError: pass
    try: import catboost as _cb; _HAS_CB = True
    except ImportError: pass
try:
    import torch as _torch; import torch.nn as _nn; import torch.optim as _optim
    from torch.utils.data import DataLoader as _DataLoader, TensorDataset as _TensorDataset
    _HAS_TORCH = True
except ImportError: pass

class _AlphaMLP(_nn.Module):
    def __init__(self, input_dim, hidden_dim=128, dropout=0.4):
        super().__init__()
        self.net = _nn.Sequential(
            _nn.Linear(input_dim, hidden_dim), _nn.BatchNorm1d(hidden_dim), _nn.ReLU(), _nn.Dropout(dropout),
            _nn.Linear(hidden_dim, hidden_dim//2), _nn.BatchNorm1d(hidden_dim//2), _nn.ReLU(), _nn.Dropout(dropout),
            _nn.Linear(hidden_dim//2, 1))
    def forward(self, x): return self.net(x).squeeze(-1)

class _TorchMLPWrapper:
    def __init__(self, input_dim, hidden_dim=128, dropout=0.4, lr=0.001, epochs=30, batch_size=512):
        self.input_dim=input_dim; self.hidden_dim=hidden_dim; self.dropout=dropout
        self.lr=lr; self.epochs=epochs; self.batch_size=batch_size
        self.device = "cuda" if _HAS_TORCH and _torch.cuda.is_available() else "cpu"
        self.model = None
    def fit(self, X, y):
        self.model = _AlphaMLP(self.input_dim, self.hidden_dim, self.dropout).to(self.device)
        opt = _optim.Adam(self.model.parameters(), lr=self.lr, weight_decay=1e-3)
        crit = _nn.MSELoss()
        X_t = _torch.FloatTensor(X).to(self.device); y_t = _torch.FloatTensor(y).to(self.device)
        ds = _TensorDataset(X_t, y_t); loader = _DataLoader(ds, batch_size=self.batch_size, shuffle=True, drop_last=True)  # drop_last: BatchNorm needs >1 sample
        self.model.train()
        for _ in range(self.epochs):
            for bx, by in loader:
                opt.zero_grad(); loss = crit(self.model(bx), by); loss.backward(); opt.step()
        return self
    def predict(self, X):
        self.model.eval()
        with _torch.no_grad():
            return self.model(_torch.FloatTensor(X).to(self.device)).cpu().numpy()

class ExpandedAlphaEnsemble:
    """5-model ensemble: Ridge + LightGBM LambdaRank + CatBoost YetiRank + RandomForest + MLP.
    Stacking meta-learner trained on purged OOF predictions."""
    def __init__(self, model_type="ensemble", use_meta_label=True, use_xgboost=True,
                 use_catboost=True, use_stacking=True, n_stacking_folds=5, forward_return_days=21):
        self.model_type=model_type; self.use_meta_label=use_meta_label
        self.use_catboost=use_catboost and _HAS_CB; self.use_stacking=use_stacking and _HAS_SKLEARN
        self.n_stacking_folds=max(2,int(n_stacking_folds)); self.forward_return_days=max(1,int(forward_return_days))
        self._models={}; self._feature_names=[]; self._meta_model=None; self._stacker=None; self._base_model_names=[]
        self._stacker_weights={}  # NNLS weights, populated in fit() if stacking succeeds
    def _purged_splits(self, n):
        ns=min(self.n_stacking_folds,5); fs=n//ns; pg=self.forward_return_days; splits=[]
        for i in range(ns):
            vs=i*fs; ve=(i+1)*fs if i<ns-1 else n; vi=np.arange(vs,ve)
            te=max(0,vs-pg); tb=np.arange(0,te); tas=min(n,ve+pg); ta=np.arange(tas,n); ti=np.concatenate([tb,ta])
            if len(ti)>50 and len(vi)>10: splits.append((ti,vi))
        return splits
    def _build_model(self, name, dim=0):
        if name=="ridge": return _Ridge(alpha=1.0)
        if name=="lightgbm_rank" and _HAS_LGB:
            return _lgb.LGBMRanker(n_estimators=200,learning_rate=0.02,num_leaves=12,max_depth=4,
                min_child_samples=100,subsample=0.7,colsample_bytree=0.6,reg_alpha=1.5,reg_lambda=10.0,
                random_state=42,verbosity=-1,objective="lambdarank")
        if name=="catboost_rank" and _HAS_CB:
            return _cb.CatBoostRanker(iterations=200,learning_rate=0.02,depth=4,l2_leaf_reg=10.0,
                random_seed=42,verbose=0,loss_function="YetiRank")
        if name=="random_forest" and _HAS_SKLEARN:
            return _RF(n_estimators=100,max_depth=6,min_samples_leaf=100,max_features="sqrt",random_state=42,n_jobs=-1)
        if name=="mlp" and _HAS_TORCH and dim>0:
            return _TorchMLPWrapper(input_dim=dim,hidden_dim=128,dropout=0.4,lr=0.001,epochs=30,batch_size=512)
        return None
    def _fit_rank(self, model, name, X, y, dates=None):
        """Fit ranking model with PROPER label encoding.
        LGBMRanker/CatBoostRanker expect SMALL integer relevance levels (0-9 for deciles),
        NOT per-stock ranks (0-205). The old code produced 206 unique labels which crashed
        LightGBM's internal label mapping.
        Fix: bucket stocks into DECILES (0-9) within each date group.
        """
        try:
            if dates is None: return False
            ud, inv = np.unique(dates, return_inverse=True)
            if len(ud) < 5: return False

            # Bucket into deciles (0-9) within each group — standard LGBMRanker approach
            yi = np.zeros(len(y), dtype=int)
            for g in range(len(ud)):
                gmask = inv == g
                if gmask.sum() < 10: continue
                yvals = y[gmask]
                try:
                    # Decile rank: 0 = bottom 10%, 9 = top 10%
                    deciles = pd.qcut(yvals, 10, labels=False, duplicates="drop")
                    yi[gmask] = deciles
                except Exception:
                    # Fallback: simple rank-based decile
                    ranks = pd.Series(yvals).rank(pct=True)
                    yi[gmask] = np.clip((ranks * 10).astype(int), 0, 9)

            if name=="lightgbm_rank":
                si = np.argsort(inv)
                model.fit(X[si], yi[si], group=np.bincount(inv[si]).tolist())
                return True
            elif name=="catboost_rank":
                model.fit(X, yi, group_id=inv)
                return True
        except Exception as e:
            print(f"  ⚠️ Ranking model {name} failed: {e}")
            return False
        return False
    def fit(self, X, y, meta_labels=None):
        Xc=X.fillna(0.0); ya=y.to_numpy(float); mask=~np.isnan(ya); Xc=Xc.loc[mask]; ya=ya[mask]
        dates = Xc.index.get_level_values(0).to_numpy() if isinstance(Xc.index, pd.MultiIndex) else None
        self._feature_names=list(Xc.columns); Xa=Xc.to_numpy(float); n=len(ya); dim=Xa.shape[1]
        bmn=["ridge"]
        if _HAS_LGB and self.model_type in ("lightgbm","blend","ensemble"): bmn.append("lightgbm_rank")
        if self.use_catboost: bmn.append("catboost_rank")
        if _HAS_SKLEARN: bmn.append("random_forest")
        if _HAS_TORCH: bmn.append("mlp")
        self._base_model_names=bmn
        oof_preds={}
        if self.use_stacking and n>200 and _HAS_SKLEARN:
            try:
                splits=self._purged_splits(n); om=np.full((n,len(bmn)),np.nan)
                for fi,(ti,vi) in enumerate(splits):
                    Xtr,Xval=Xa[ti],Xa[vi]; ytr=ya[ti]; dtr=dates[ti] if dates is not None else None
                    if len(Xtr)<50: continue
                    for mi,mn in enumerate(bmn):
                        try:
                            m=self._build_model(mn,dim=dim)
                            if m is None: continue
                            if mn in ("lightgbm_rank","catboost_rank"):
                                if self._fit_rank(m,mn,Xtr,ytr,dates=dtr): om[vi,mi]=m.predict(Xval)
                            else: m.fit(Xtr,ytr); om[vi,mi]=m.predict(Xval)
                        except: pass
                for mi,mn in enumerate(bmn): oof_preds[mn]=om[:,mi]
            except: self.use_stacking=False
        mf=[]
        for mn in bmn:
            try:
                m=self._build_model(mn,dim=dim)
                if m is None: continue
                if mn in ("lightgbm_rank","catboost_rank"):
                    if self._fit_rank(m,mn,Xa,ya,dates=dates): self._models[mn]=m; mf.append(mn)
                else: m.fit(Xa,ya); self._models[mn]=m; mf.append(mn)
            except: pass
        if self.use_stacking and oof_preds and len(mf)>=2:
            try:
                oa=np.column_stack([oof_preds[m] for m in mf]); vm=~np.any(np.isnan(oa),axis=1)
                if vm.sum()>100:
                    # BUG FIX: was an unconstrained Ridge(alpha=1.0) stacker.
                    # With only ~5 stacking folds feeding a 5-column OOF
                    # matrix, an unconstrained linear meta-learner has almost
                    # nothing stopping it from assigning wildly negative
                    # weights to a perfectly reasonable base model just
                    # because it happened to anti-correlate with noise in a
                    # small validation sample. Real runs showed this exact
                    # failure mode: ridge weight swinging from -0.76 to
                    # +0.48 fold to fold, catboost negatively weighted in
                    # nearly every fold. A model that's "shorted" by the
                    # meta-learner is a red flag for overfitting the
                    # combination step, not genuine complementary signal.
                    #
                    # Fixed via non-negative least squares (NNLS) + simplex
                    # normalization (weights >= 0, sum to 1) — this is
                    # standard practice for robust forecast combination
                    # (Bates-Granger style averaging). No base model can be
                    # assigned negative weight, which removes the main
                    # degree of freedom the meta-learner was using to overfit.
                    from scipy.optimize import nnls
                    _w, _resid = nnls(oa[vm], ya[vm])
                    _wsum = _w.sum()
                    if _wsum > 1e-9:
                        _w = _w / _wsum
                    else:
                        # NNLS degenerated to all-zero weights (can happen if
                        # no base model's OOF predictions are genuinely
                        # useful) -- fall back to equal weighting rather than
                        # producing a stacker that always predicts zero.
                        _w = np.ones(len(mf)) / len(mf)
                    self._stacker_weights = dict(zip(mf, _w.round(4)))
                    self._stacker = "nnls"  # marker: predict() uses self._stacker_weights directly
                    print(f"  Stacking weights (NNLS, non-negative, sum-to-1): {self._stacker_weights}")
            except Exception as _stack_e:
                print(f"  ⚠️  Stacking failed ({_stack_e}), falling back to equal-weight average")
                self._stacker=None
        if self.use_meta_label and meta_labels is not None and _HAS_SKLEARN:
            try:
                ma=meta_labels.loc[mask].to_numpy(float); v=ma!=0
                if v.sum()>50: self._meta_model=_LogReg(max_iter=500); self._meta_model.fit(Xa[v],ma[v])
            except: pass
        return {"models_fitted":mf, "stacking_enabled":self._stacker is not None}
    def predict(self, X):
        Xc=X.fillna(0.0); Xa=Xc.to_numpy(float); bp={}
        for nm,m in self._models.items():
            try:
                p=m.predict(Xa)
                if len(p)==len(Xc): bp[nm]=p
            except: pass
        if not bp: return pd.Series(0.0,index=Xc.index)
        if self._stacker == "nnls" and self._stacker_weights and len(bp)>=2:
            try:
                # Weighted average using the non-negative, sum-to-1 NNLS
                # weights computed in fit(). Any base model missing from bp
                # (e.g. failed to predict) is simply excluded and the
                # remaining weights are renormalized, rather than crashing.
                _active = {m: w for m, w in self._stacker_weights.items() if m in bp}
                _wsum = sum(_active.values())
                if _wsum > 1e-9:
                    ap = sum(bp[m] * (w / _wsum) for m, w in _active.items())
                else:
                    ap = np.mean(list(bp.values()), axis=0)
            except Exception:
                ap = np.mean(list(bp.values()), axis=0)
        else: ap = np.mean(list(bp.values()),axis=0)
        if self._meta_model is not None:
            try:
                mp=self._meta_model.predict_proba(Xa)
                if 1.0 in self._meta_model.classes_.tolist():
                    ap=ap*(0.5+mp[:,list(self._meta_model.classes_).index(1.0)])
            except: pass
        return pd.Series(ap,index=Xc.index)
    def feature_importance(self):
        imp={}; c=0
        for nm in ["lightgbm_rank","catboost_rank","random_forest"]:
            if nm not in self._models: continue
            m=self._models[nm]
            try:
                if hasattr(m,"feature_importances_"):
                    fi=m.feature_importances_
                    if len(fi)==len(self._feature_names):
                        for fn,v in zip(self._feature_names,fi): imp[fn]=imp.get(fn,0.0)+v
                        c+=1
            except: pass
        if c>0 and imp:
            t=sum(imp.values())
            if t>0: imp={k:v/t for k,v in imp.items()}
        return imp
    def stacking_weights(self):
        return dict(self._stacker_weights) if self._stacker_weights else {}

print("✓ Inline ensemble loaded: Ridge + LightGBM LambdaRank + CatBoost YetiRank + RandomForest + MLP")
print(f"  Stacking: enabled (purged OOF, gap={forward_return_days}d) | MLP: {_HAS_TORCH} | LGB: {_HAS_LGB} | CB: {_HAS_CB}")

for fold in cv.split(unique_dates):
    _fold_id = getattr(fold, "path_id", getattr(fold, "fold_id", 0))
    train_mask = df.index.get_level_values(0).isin(fold.train_idx)
    test_mask = df.index.get_level_values(0).isin(fold.test_idx)
    train_df = df[train_mask]; test_df = df[test_mask]
    if len(train_df) < 100 or len(test_df) < 10: continue

    # PER-FOLD FEATURE SELECTION (Grok point #3): run select_factors on TRAIN
    # data only, not the full dataset. Prevents test-fold leakage into selection.
    try:
        fold_features, _ = select_factors(
            {f: processed[f] for f in feature_cols if f in processed},
            train_df["forward_return"], train_df[feature_cols], train_df["forward_return"],
            ic_threshold=0.01, min_features=10, max_features=20,
            # BUG FIX: same instability cap as the final-model selection
            # above — without this, individual CPCV folds were selecting
            # 100+ collinear factors and overfitting so badly that IS_IC hit
            # +0.25 to +0.32 (vs the normal +0.02-0.10 range) in several
            # folds of one real run, while OOS_IC in those same folds was
            # negative.
        )
        if len(fold_features) < 10:
            fold_features = feature_cols
    except Exception:
        fold_features = selected_features  # fallback to global selection

    X_train = train_df[fold_features]; y_train = train_df["forward_return"]
    X_test = test_df[fold_features]; y_test = test_df["forward_return"]
    # Use RAW forward returns (not rank-transformed) for Sharpe/DSR computation.
    y_train_raw = train_df["forward_return_raw"]
    y_test_raw = test_df["forward_return_raw"]

    try:
        model = ExpandedAlphaEnsemble(model_type="ensemble", use_meta_label=True, use_xgboost=True, use_catboost=True, use_stacking=True, forward_return_days=forward_return_days)
        model.fit(X_train, y_train, meta_labels=train_df.get("tb_label"))
    except Exception:
        from ml_alpha.model import AlphaEnsemble  # fallback if inline ensemble fails
        model = AlphaEnsemble(model_type="blend")
        model.fit(X_train, y_train)

    is_pred = pd.Series(model.predict(X_train).values, index=train_df.index, name="pred")
    oos_pred = pd.Series(model.predict(X_test).values, index=test_df.index, name="pred")
    # IC: rank correlation — works on either rank or raw target (both are cross-sectional ranks effectively)
    is_ic = spearman_ic(is_pred.values, y_train.values)
    oos_ic = spearman_ic(oos_pred.values, y_test.values)
    # Sharpe: MUST use raw returns, not rank-transformed target
    is_sharpe, is_ls = quantile_sharpe(is_pred, y_train_raw, forward_return_days)
    oos_sharpe, oos_ls = quantile_sharpe(oos_pred, y_test_raw, forward_return_days)
    if len(oos_ls) > 0: all_oos_ls_rets.append(oos_ls)
    is_sharpes.append(is_sharpe); oos_sharpes.append(oos_sharpe)
    per_fold.append({"fold_id": _fold_id, "train_size": len(train_df), "test_size": len(test_df),
                     "is_ic": is_ic, "oos_ic": oos_ic, "is_sharpe": is_sharpe, "oos_sharpe": oos_sharpe})
    print(f"  Path {_fold_id}: IS_IC={is_ic:+.4f} OOS_IC={oos_ic:+.4f} IS_Sharpe={is_sharpe:+.2f} OOS_Sharpe={oos_sharpe:+.2f}")

# 5h. Compute DSR
is_mean = float(np.mean(is_sharpes)); is_std = float(np.std(is_sharpes))
oos_mean = float(np.mean(oos_sharpes)); oos_std = float(np.std(oos_sharpes))
wf_eff = walk_forward_efficiency(is_sharpes, oos_sharpes)
# BUG FIX: was `len(selected_features) * len(per_fold)` — that only counts
# the WINNERS of feature selection (e.g. 10), never the size of the pool
# they were screened from (e.g. 260 after rank transforms). Same bug found
# and fixed in ml_alpha/engine.py's fit(); this script reimplements the
# whole pipeline inline instead of calling AlphaEngine.fit(), so it needed
# the identical fix applied here separately. Expanding the factor pool from
# 34 -> 260 is a ~7.6x larger selection-bias exposure and should make DSR
# *harder* to clear, not barely move it.
n_trials = max(1, len(feature_cols) * len(per_fold))
print(f"  DSR trial count: {len(feature_cols)} candidate factors screened x "
      f"{len(per_fold)} folds = {n_trials} n_trials "
      f"(was {len(selected_features) * len(per_fold)} counting only the "
      f"{len(selected_features)} selected winners)")
all_ls = pd.concat(all_oos_ls_rets) if all_oos_ls_rets else pd.Series(dtype=float)

# CPCV OVERLAP DEDUP: with C(n_groups, n_test) combinatorial paths, each underlying
# date appears in multiple paths (e.g. C(6,2)=15 paths, but only 6 groups, so each
# date appears in ~5 paths). Using all 965 pooled OOS observations as "independent"
# inflates the DSR by making the sample look 5x larger than it actually is.
# Fix: deduplicate by date — use only unique underlying dates for sample_length.
_n_raw_obs = len(all_ls)
if isinstance(all_ls.index, pd.MultiIndex):
    _unique_dates = all_ls.index.get_level_values(0).nunique()
elif hasattr(all_ls.index, 'nunique'):
    _unique_dates = all_ls.index.nunique()
else:
    _unique_dates = _n_raw_obs
_overlap_factor = _n_raw_obs / max(1, _unique_dates)
print(f"  CPCV overlap check: {_n_raw_obs} raw pooled OOS observations across "
      f"{len(per_fold)} paths, but only {_unique_dates} UNIQUE underlying dates "
      f"(~{_overlap_factor:.1f}x overlap from paths reusing the same "
      f"{6} underlying groups)")

# DIAGNOSTIC: print the ACTUAL raw and clipped skew/kurtosis/sample_length
# that feed the DSR formula.
_raw_skew = float(all_ls.skew()) if len(all_ls) > 10 else float("nan")
_raw_kurt_excess = float(all_ls.kurtosis()) if len(all_ls) > 10 else float("nan")
print(f"  DSR distribution inputs: n_oos_observations(raw pooled)={_n_raw_obs}, "
      f"n_unique_dates={_unique_dates}, "
      f"raw_skew={_raw_skew:+.4f}, raw_excess_kurtosis={_raw_kurt_excess:+.4f}")
if len(all_ls) > 10 and all_ls.std() > 1e-9:
    skew = float(np.clip(all_ls.skew() if np.isfinite(all_ls.skew()) else 0.0, -1.5, 1.5))
    kurt = float(np.clip(all_ls.kurtosis() + 3.0 if np.isfinite(all_ls.kurtosis()) else 3.0, 2.5, 8.0))
    # Use UNIQUE dates as sample_length, not raw pooled count
    sample_length = _unique_dates
else:
    skew = 0.0; kurt = 3.0; sample_length = 252
print(f"  DSR inputs actually used: observed_sharpe={oos_mean:+.4f}, "
      f"n_trials={n_trials}, sample_length={sample_length} "
      f"(deduplicated, was {_n_raw_obs} before this fix), "
      f"skewness(clipped)={skew:+.4f}, kurtosis(clipped)={kurt:.4f}, "
      f"holding_days={forward_return_days}")
dsr = deflated_sharpe_ratio(observed_sharpe=oos_mean, n_trials=n_trials, sample_length=sample_length,
                            skewness=skew, kurtosis=kurt, holding_days=forward_return_days)
if not np.isfinite(dsr): dsr = 0.0

# Sensitivity table using the REAL skew/kurtosis/sample_length from THIS run
# (not assumed/guessed values). IMPORTANT CAVEAT, printed below too: this
# only answers "if observed_sharpe stayed exactly the same and only the
# candidate count changed, what would DSR be?" It is NOT a prediction of
# what actually retraining with fewer factors would produce — a smaller
# factor pool changes which features get selected, which changes the model,
# which changes observed_sharpe itself (up or down), not just n_trials.
# It also does NOT license retroactively "curating" factors after seeing
# which ones worked in this 260-factor run — that doesn't reduce your real
# multiple-testing exposure, it just hides it.
print(f"\n  --- DSR sensitivity to candidate count (arithmetic only, holding "
      f"observed_sharpe={oos_mean:+.4f} fixed at THIS run's real skew="
      f"{skew:+.4f}/kurtosis={kurt:.4f}/sample_length={sample_length}) ---")
print(f"  This is NOT a prediction of what retraining with fewer factors "
      f"would actually produce — see caveat in code comments.")
for _n_cand in [260, 130, 91, 50, 10]:
    _nt = max(1, _n_cand * len(per_fold))
    _d = deflated_sharpe_ratio(observed_sharpe=oos_mean, n_trials=_nt, sample_length=sample_length,
                               skewness=skew, kurtosis=kurt, holding_days=forward_return_days)
    _marker = "  <- this run" if _n_cand == len(feature_cols) else ""
    print(f"    {_n_cand:4d} candidates -> n_trials={_nt:5d} -> DSR={_d:.4f}{_marker}")

# 5i. Retrain final model on ALL data
print("\nRetraining final model on all data...")
X_all = df[selected_features]; y_all = df["forward_return"]
try:
    final_model = ExpandedAlphaEnsemble(model_type="ensemble", use_meta_label=True, use_xgboost=True, use_catboost=True, use_stacking=True, forward_return_days=forward_return_days)
    final_model.fit(X_all, y_all, meta_labels=df.get("tb_label"))
except Exception:
    from ml_alpha.model import AlphaEnsemble
    final_model = AlphaEnsemble(model_type="blend")
    final_model.fit(X_all, y_all)

fi = final_model.feature_importance() if hasattr(final_model, 'feature_importance') else {}

# Print stacking weights — shows which base models the meta-learner trusts
if hasattr(final_model, 'stacking_weights'):
    _sw = final_model.stacking_weights()
    if _sw:
        print(f"\n  Stacking meta-learner weights (which base models are trusted):")
        for mname, w in sorted(_sw.items(), key=lambda x: -abs(x[1])):
            print(f"    {mname:15s}: {w:+.4f}")

# ── 6. RESULTS ──────────────────────────────────────────────────────────────
print(f"\n{'='*60}")
print("FIT COMPLETE — 100+ FACTORS")
print(f"{'='*60}")
print(f"IS Sharpe:       {is_mean:+.2f} ± {is_std:.2f}")
print(f"OOS Sharpe:      {oos_mean:+.2f} ± {oos_std:.2f}")
print(f"WF Efficiency:   {wf_eff:.1%}")
print(f"Deflated Sharpe: {dsr:.4f}  (n_trials={n_trials}, now correctly counting "
      f"the {len(feature_cols)}-factor candidate pool, not just the "
      f"{len(selected_features)} selected winners)")
print(f"n_trials:        {n_trials}")
print(f"Features:        {len(selected_features)} (selected from {len(feature_cols)})")

# NOTE: the old "Mac DSR=0.5591" comparison has been removed — that number
# was computed with the SAME n_trials bug this script just fixed (counting
# selected features, not the candidate pool), so it's not a valid baseline
# to compare against anymore. Re-run the Mac/engine.py path with the fixed
# formula (already patched in ml_alpha/engine.py) to get a real comparison
# point. Standard DSR interpretation: >0.95 = strong evidence of real edge,
# 0.5-0.95 = inconclusive, <0.5 = no better than a coin flip on whether the
# true Sharpe is even positive.
if dsr > 0.95:
    print(f"\n✅ DSR = {dsr:.4f} — strong evidence of real edge after "
          f"correcting for the {len(feature_cols)}-factor search width")
elif dsr > 0.5:
    print(f"\n⚠️  DSR = {dsr:.4f} — inconclusive; searching {len(feature_cols)} "
          f"factors is a large multiple-testing exposure to overcome")
else:
    print(f"\n❌ DSR = {dsr:.4f} — no better than a coin flip once the "
          f"{len(feature_cols)}-factor search width is properly penalized")

print(f"\nTop 20 Feature Importance:")
for k, v in sorted(fi.items(), key=lambda x: -x[1])[:20]:
    print(f"  {k:35s}: {v*100:.1f}%")

print(f"\nPer-Fold CPCV Results:")
for m in per_fold:
    print(f"  Path {m['fold_id']:2d}: IS_IC={m['is_ic']:+.4f}  OOS_IC={m['oos_ic']:+.4f}  IS_Sharpe={m['is_sharpe']:+.2f}  OOS_Sharpe={m['oos_sharpe']:+.2f}")

# ── 7. SAVE MODEL ───────────────────────────────────────────────────────────
OUTPUT_DIR = "/kaggle/working"
os.makedirs(OUTPUT_DIR, exist_ok=True)

model_path = os.path.join(OUTPUT_DIR, "ml_alpha_model.pkl")
with open(model_path, "wb") as f:
    pickle.dump({
        "feature_names": selected_features,
        "fitted_model": final_model,
    }, f)
print(f"\nSaved model -> {model_path}")

result_path = os.path.join(OUTPUT_DIR, "fit_result.json")
result_dict = {
    "is_sharpe_mean": is_mean, "is_sharpe_std": is_std,
    "oos_sharpe_mean": oos_mean, "oos_sharpe_std": oos_std,
    "walk_forward_efficiency": wf_eff,
    "deflated_sharpe": dsr, "n_trials": n_trials,
    "n_features": len(selected_features),
    "feature_importance": fi,
    "per_fold_metrics": per_fold,
}
with open(result_path, "w") as f:
    json.dump(result_dict, f, indent=2, default=str)
print(f"Saved metrics -> {result_path}")

print(f"\n✅ Download both from Kaggle Output panel.")