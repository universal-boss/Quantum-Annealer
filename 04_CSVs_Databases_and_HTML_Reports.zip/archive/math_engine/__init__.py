"""
math_engine
===========
Unified Quantum Annealer Quantitative Math Engine.

Exposes high-performance vector optimizers, CVaR risk managers,
copula tail risk screeners, RL order execution agents, QAOA quantum circuit compilers,
NLP sentiment view extractors, factor risk models, and broker routers.
"""

from .indicators import *

# Core Solvers & Optimizers
try:
    from .jax_optimizer import JaxPortfolioOptimizer
except Exception:
    JaxPortfolioOptimizer = None

try:
    from .expected_shortfall import ExpectedShortfallOptimizer
except Exception:
    ExpectedShortfallOptimizer = None

try:
    from .copula_risk import CopulaTailRiskScreener
except Exception:
    CopulaTailRiskScreener = None

try:
    from .rl_execution_agent import ExecutionLOBEnvironment, RLExecutionPolicy
except Exception:
    ExecutionLOBEnvironment = None
    RLExecutionPolicy = None

try:
    from .qaoa_optimizer import QAOAPortfolioCompiler
except Exception:
    QAOAPortfolioCompiler = None

try:
    from .filing_sentiment import FilingSentimentViewsExtractor
except Exception:
    FilingSentimentViewsExtractor = None

try:
    from .solver_coordinator import SolverCoordinator
except Exception:
    SolverCoordinator = None

try:
    from .wasserstein_calibrator import WassersteinCalibrator
except Exception:
    WassersteinCalibrator = None

try:
    from .cqm_formulator import CQMFormulator
except Exception:
    CQMFormulator = None

try:
    from .baryonic_memory import BaryonicMemoryBuffer
except Exception:
    BaryonicMemoryBuffer = None

try:
    from .dynamic_factor_engine import DynamicFactorWeightEngine
except Exception:
    DynamicFactorWeightEngine = None

try:
    from .latent_screener import LatentManifoldScreener
except Exception:
    LatentManifoldScreener = None

try:
    from .regime_detector import RegimeDetector
except Exception:
    RegimeDetector = None

try:
    from .smart_order_router import SmartOrderRouter
except Exception:
    SmartOrderRouter = None

try:
    from .broker_router import AngelOneAdapter, AngelOneExecutionRouter, DhanAdapter, DhanExecutionRouter
except Exception:
    AngelOneAdapter = None
    AngelOneExecutionRouter = None
    DhanAdapter = None
    DhanExecutionRouter = None

try:
    from .websocket_feed import AngelOnePollingFeedClient, MockWebSocketClient, DhanPollingFeedClient
except Exception:
    AngelOnePollingFeedClient = None
    MockWebSocketClient = None
    DhanPollingFeedClient = None

try:
    from .integrated_gems import InstitutionalGemsEngine
except Exception:
    InstitutionalGemsEngine = None

__all__ = [
    "JaxPortfolioOptimizer",
    "ExpectedShortfallOptimizer",
    "CopulaTailRiskScreener",
    "ExecutionLOBEnvironment",
    "RLExecutionPolicy",
    "QAOAPortfolioCompiler",
    "FilingSentimentViewsExtractor",
    "SolverCoordinator",
    "WassersteinCalibrator",
    "CQMFormulator",
    "BaryonicMemoryBuffer",
    "DynamicFactorWeightEngine",
    "LatentManifoldScreener",
    "RegimeDetector",
    "SmartOrderRouter",
    "AngelOneAdapter",
    "AngelOneExecutionRouter",
    "DhanAdapter",
    "DhanExecutionRouter",
    "AngelOnePollingFeedClient",
    "MockWebSocketClient",
    "DhanPollingFeedClient",
]
