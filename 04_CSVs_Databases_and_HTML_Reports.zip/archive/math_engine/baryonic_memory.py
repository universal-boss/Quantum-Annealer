"""
math_engine/baryonic_memory.py / archive/math_engine/baryonic_memory.py
========================================================================
Institutional Circular Ring Buffer & Portfolio State Register.
Provides high-performance, thread-safe circular memory storage for rolling order
reconciliation, transaction trail logging, and state snapshot auditing.
"""
from __future__ import annotations

import logging
import threading
import hashlib
import json
from typing import Dict, Any, List, Tuple, Optional
from collections import deque
from datetime import datetime

logger = logging.getLogger(__name__)


class RingBufferMemoryRegister:
    """Thread-safe circular ring buffer register for rolling execution & portfolio reconciliation.
    
    Replaces legacy baryonic spin registers with a production-grade circular memory structure
    featuring FIFO eviction, O(1) state pushes, historical query windows, and audit hashing.
    """

    def __init__(self, size: int = 1024) -> None:
        self.capacity: int = max(16, int(size))
        self._buffer: deque = deque(maxlen=self.capacity)
        self._lock = threading.RLock()
        self._sequence_counter: int = 0
        self._addr_map: Dict[int, Dict[str, Any]] = {}

    def push(self, data: Dict[str, Any]) -> int:
        """Pushes a new state record into the circular ring buffer.
        
        Evicts oldest record if capacity is reached. Returns unique sequence ID.
        """
        with self._lock:
            self._sequence_counter += 1
            record = {
                "seq": self._sequence_counter,
                "timestamp": datetime.now().isoformat(),
                "data": data
            }
            if len(self._buffer) >= self.capacity:
                oldest = self._buffer[0]
                old_seq = oldest.get("seq")
                if old_seq in self._addr_map:
                    del self._addr_map[old_seq]
            
            self._buffer.append(record)
            address = self._sequence_counter % self.capacity
            self._addr_map[address] = record
            return self._sequence_counter

    def write_baryon_state(self, address: int, data: Any) -> bool:
        """Writes or updates state at circular address (compatibility API)."""
        with self._lock:
            if isinstance(data, (tuple, list)):
                payload = {"values": list(data)}
            elif isinstance(data, dict):
                payload = data
            else:
                payload = {"value": data}
            
            addr = address % self.capacity
            record = {
                "seq": address,
                "timestamp": datetime.now().isoformat(),
                "data": payload
            }
            self._addr_map[addr] = record
            if record not in self._buffer:
                self._buffer.append(record)
            return True

    def read_baryon_state(self, address: int) -> Dict[str, Any]:
        """Reads state at circular address (compatibility API)."""
        with self._lock:
            addr = address % self.capacity
            rec = self._addr_map.get(addr)
            if rec:
                return rec.get("data", {})
            return {}

    def get_latest(self, n: int = 1) -> List[Dict[str, Any]]:
        """Returns the N most recent records from the ring buffer."""
        with self._lock:
            items = list(self._buffer)
            return [item["data"] for item in items[-n:]]

    def get_history(self) -> List[Dict[str, Any]]:
        """Returns all active records currently in the circular memory ring."""
        with self._lock:
            return [item["data"] for item in self._buffer]

    def apply_hadronic_logic_gate(self, address: int, gate_type: str) -> Dict[str, Any]:
        """State transformation gate (compatibility API): applies linear transformation or state shift."""
        with self._lock:
            addr = address % self.capacity
            rec = self._addr_map.get(addr, {"seq": address, "data": {"status": "ACTIVE"}})
            data = dict(rec.get("data", {}))
            
            if gate_type == "X":
                data["flag_inverted"] = not data.get("flag_inverted", False)
            elif gate_type == "Z":
                data["phase_shift"] = data.get("phase_shift", 0.0) + 180.0
            elif gate_type == "H":
                data["reconciled"] = True
                
            rec["data"] = data
            rec["timestamp"] = datetime.now().isoformat()
            self._addr_map[addr] = rec
            return data

    def compute_audit_hash(self) -> str:
        """Computes SHA-256 cryptographic hash of current buffer contents for SEBI audit trail."""
        with self._lock:
            raw = json.dumps([item["data"] for item in self._buffer], sort_keys=True, default=str)
            return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def clear(self) -> None:
        """Clears all entries from the ring buffer."""
        with self._lock:
            self._buffer.clear()
            self._addr_map.clear()


# Canonical production class aliases
BaryonicMemoryRegister = RingBufferMemoryRegister
BaryonicMemoryBuffer = RingBufferMemoryRegister
