"""
math_engine/cda_matching_core.py
================================
Continuous Double Auction (CDA) Order Matching Core.

Simulates price-time priority limit order matching queues for exact order fill price calculation.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, List

logger = logging.getLogger(__name__)


class CDAMatchingCore:
    """
    Continuous Double Auction (CDA) Price-Time Priority Order Matching Simulator.
    """

    @staticmethod
    def match_limit_orders(bids: List[Dict[str, float]], asks: List[Dict[str, float]]) -> Dict[str, Any]:
        """
        Matches limit order bids and asks in price-time priority sequence.
        bids: [{"price": 100.0, "qty": 10}, ...]
        asks: [{"price": 99.5, "qty": 5}, ...]
        """
        if not bids or not asks:
            return {"matched_trades": [], "total_volume": 0, "vwap_price": 0.0}

        sorted_bids = sorted(bids, key=lambda x: -x["price"])  # Descending bid price
        sorted_asks = sorted(asks, key=lambda x: x["price"])   # Ascending ask price

        trades = []
        total_vol = 0
        total_val = 0.0

        i, j = 0, 0
        while i < len(sorted_bids) and j < len(sorted_asks):
            bid = sorted_bids[i]
            ask = sorted_asks[j]

            if bid["price"] >= ask["price"]:
                # Match occurs at ask price (passive price priority)
                exec_price = ask["price"]
                exec_qty = min(bid["qty"], ask["qty"])

                trades.append({
                    "price": exec_price,
                    "qty": exec_qty
                })

                total_vol += exec_qty
                total_val += exec_price * exec_qty

                bid["qty"] -= exec_qty
                ask["qty"] -= exec_qty

                if bid["qty"] <= 0:
                    i += 1
                if ask["qty"] <= 0:
                    j += 1
            else:
                break  # Spread is negative, no further matches

        vwap = (total_val / total_vol) if total_vol > 0 else 0.0

        return {
            "matched_trades": trades,
            "total_volume": total_vol,
            "vwap_price": round(vwap, 2)
        }
