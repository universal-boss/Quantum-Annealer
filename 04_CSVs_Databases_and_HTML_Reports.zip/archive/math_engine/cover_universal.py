"""
math_engine/cover_universal.py
==============================
Cover's Universal Portfolio & Wasserstein Hierarchical Risk Parity (W-HRP).

Implements:
  1. Cover's Universal Portfolio algorithm (Algorithmic Portfolio Theory).
  2. Optimal Transport (Wasserstein Distance) HRP tree clustering.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, List

logger = logging.getLogger(__name__)


def compute_wasserstein_distance_matrix(returns_df: pd.DataFrame) -> np.ndarray:
    """
    Computes Optimal Transport (Wasserstein 1-D Distance) matrix between return distributions.
    """
    if returns_df is None or returns_df.empty:
        return np.array([[]])

    clean_ret = returns_df.dropna().values
    n_assets = clean_ret.shape[1]
    dist_matrix = np.zeros((n_assets, n_assets))

    for i in range(n_assets):
        for j in range(i + 1, n_assets):
            # 1D Wasserstein distance between sample quantile functions
            u = np.sort(clean_ret[:, i])
            v = np.sort(clean_ret[:, j])
            w_dist = float(np.mean(np.abs(u - v)))
            dist_matrix[i, j] = w_dist
            dist_matrix[j, i] = w_dist

    return dist_matrix


class CoverUniversalPortfolio:
    """
    Cover's Universal Portfolio Selection Engine.
    Achieves asymptotic growth rate optimality without distribution assumptions.
    """

    @staticmethod
    def compute_universal_weights(returns_df: pd.DataFrame, n_simulations: int = 100) -> Dict[str, float]:
        """
        Computes weighted average over constant-rebalanced portfolio (CRP) simplex.
        """
        if returns_df is None or returns_df.empty:
            return {}

        tickers = list(returns_df.columns)
        n_assets = len(tickers)
        if n_assets == 0:
            return {}

        # Uniform Dirichlet random simplex draws
        simplex_draws = np.random.dirichlet(np.ones(n_assets), size=n_simulations)
        returns_mat = 1.0 + returns_df.fillna(0.0).values

        wealth_factors = np.zeros(n_simulations)
        for i in range(n_simulations):
            w = simplex_draws[i]
            port_growth = np.dot(returns_mat, w)
            wealth_factors[i] = np.prod(port_growth)

        total_wealth = np.sum(wealth_factors) + 1e-9
        weighted_simplex = np.dot(wealth_factors, simplex_draws) / total_wealth

        return {t: round(float(weighted_simplex[idx]), 4) for idx, t in enumerate(tickers)}
