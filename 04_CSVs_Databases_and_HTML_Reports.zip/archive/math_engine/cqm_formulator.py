"""
math_engine/cqm_formulator.py
==============================
D-Wave Continuous Quadratic Model (CQM) formulation builder.
Sets up portfolio optimization quadratic and linear expressions for continuous variable solvers.
Includes dynamic Lagrange penalty multipliers scaled by the covariance matrix spectrum.
"""
from __future__ import annotations

import logging
from typing import Dict, Any, List, Tuple, Optional  # R46 FIX: Optional was referenced but never imported
import numpy as np

logger = logging.getLogger(__name__)


class QuantumCQMFormulator:
    """Structures portfolio optimization problems for D-Wave CQM solvers."""

    @staticmethod
    def build_portfolio_cqm(
        mu: np.ndarray,
        cov: np.ndarray,
        target_return: float = 0.08,
        risk_aversion: float = 2.5
    ) -> Dict[str, Any]:
        """Formulate D-Wave compatible CQM dictionary configuration.
        
        Calculates penalty multipliers using Lagrange approximation bounds:
            multiplier = max_eigenvalue(cov) * risk_aversion
            
        Returns dict containing:
            "variables": list of variable names
            "objective": quadratic and linear coefficients
            "constraints": equality and inequality penalty configurations
            "lagrange_multipliers": estimated penalty scaling factors
        """
        n = len(mu)
        var_names = [f"w_{i}" for i in range(n)]

        # Find maximum eigenvalue to scale penalty factors
        try:
            eigvals = np.linalg.eigvalsh(cov)
            max_eig = float(np.max(eigvals))
        except Exception:
            max_eig = 1.0

        # Lagrange penalty multiplier estimation: balances the quadratic risk term
        # and constraint violation bounds.
        lagrange_multiplier = float(max(1.0, max_eig * risk_aversion))

        # Build quadratic objective: w^T * cov * w - risk_aversion * (mu^T * w)
        objective_quad = {}
        for i in range(n):
            for j in range(n):
                val = float(cov[i, j])
                if abs(val) > 1e-9:
                    objective_quad[(var_names[i], var_names[j])] = val

        objective_linear = {}
        for i in range(n):
            val = -float(risk_aversion * mu[i])
            if abs(val) > 1e-9:
                objective_linear[var_names[i]] = val

        # Constraint 1: sum(w) == 1
        # Penalty formulation: Lagrange * (sum(w) - 1)^2
        sum_constraint = {
            "type": "equality",
            "linear_coefficients": {name: 1.0 for name in var_names},
            "target": 1.0,
            "penalty_multiplier": lagrange_multiplier
        }

        # Constraint 2: mu^T * w >= target_return (Return target constraint)
        return_constraint = {
            "type": "inequality_greater_or_equal",
            "linear_coefficients": {var_names[i]: float(mu[i]) for i in range(n)},
            "target": float(target_return),
            "penalty_multiplier": float(lagrange_multiplier * 0.5)
        }

        return {
            "variables": var_names,
            "objective": {
                "quadratic": objective_quad,
                "linear": objective_linear
            },
            "constraints": [
                sum_constraint,
                return_constraint
            ],
            "lagrange_multipliers": {
                "equality_penalty": lagrange_multiplier,
                "inequality_penalty": lagrange_multiplier * 0.5
            }
        }

    @staticmethod
    def build_cardinality_bounded_cqm(
        mu: np.ndarray,
        cov: np.ndarray,
        prev_weights: np.ndarray,
        target_return: float = 0.08,
        risk_aversion: float = 2.5,
        k_max: int = 15,
        w_min: float = 0.02,
        w_max: float = 0.20,
        turnover_limit: float = 0.40,
        asset_volumes: Optional[np.ndarray] = None,
        asset_volatilities: Optional[np.ndarray] = None,
        impact_friction_coefficient: float = 0.10,
        benchmark_weights: Optional[np.ndarray] = None,
        max_tracking_error: float = 0.05
    ) -> Dict[str, Any]:
        """Formulates a mixed-integer portfolio CQM with selection binary variables z_i.
        
        Constraints:
            1. Budget: Sum(w_i) == 1.0
            2. Cardinality: Sum(z_i) <= k_max
            3. Semicontinuous bounds: z_i * w_min <= w_i <= z_i * w_max
            4. Turnover limits: Sum(|w_i - prev_w_i|) <= turnover_limit (formulated linearly via slack variables)
        """
        n = len(mu)
        w_vars = [f"w_{i}" for i in range(n)]
        z_vars = [f"z_{i}" for i in range(n)]
        
        # Default volume and volatility arrays if not provided
        if asset_volumes is None:
            asset_volumes = np.ones(n) * 1e6
        if asset_volatilities is None:
            asset_volatilities = np.ones(n) * 0.20
            
        try:
            eigvals = np.linalg.eigvalsh(cov)
            max_eig = float(np.max(eigvals))
        except Exception:
            max_eig = 1.0
        lagrange_multiplier = float(max(1.0, max_eig * risk_aversion))
        
        # Linear & Quadratic Objective Coefficients
        objective_quad = {}
        for i in range(n):
            for j in range(n):
                val = float(cov[i, j])
                if abs(val) > 1e-9:
                    objective_quad[(w_vars[i], w_vars[j])] = val
                    
        objective_linear = {}
        for i in range(n):
            val = -float(risk_aversion * mu[i])
            if abs(val) > 1e-9:
                objective_linear[w_vars[i]] = val
                
        # Incorporate quadratic market impact transaction cost: Sum( c_i * (w_i - w_i^0)^2 )
        # Where c_i = impact_friction_coefficient * volatility_i / sqrt(volume_i)
        for i in range(n):
            vol_term = max(0.01, asset_volatilities[i])
            volume_term = max(1.0, np.sqrt(asset_volumes[i]))
            c_i = float(impact_friction_coefficient * vol_term / volume_term)
            
            # w_i^2 term (added to diagonal quadratic coefficient)
            quad_key = (w_vars[i], w_vars[i])
            objective_quad[quad_key] = objective_quad.get(quad_key, 0.0) + c_i
            
            # -2 * c_i * w_i^0 term (added to linear coefficient)
            linear_adjustment = -2.0 * c_i * float(prev_weights[i])
            objective_linear[w_vars[i]] = objective_linear.get(w_vars[i], 0.0) + linear_adjustment
                
        # 1. Budget Constraint: Sum(w_i) == 1
        budget_constraint = {
            "type": "equality",
            "linear_coefficients": {w_vars[i]: 1.0 for i in range(n)},
            "target": 1.0,
            "penalty_multiplier": lagrange_multiplier
        }
        
        # 2. Cardinality Constraint: Sum(z_i) <= k_max
        cardinality_constraint = {
            "type": "inequality_less_or_equal",
            "linear_coefficients": {z_vars[i]: 1.0 for i in range(n)},
            "target": float(k_max),
            "penalty_multiplier": lagrange_multiplier * 0.75
        }
        
        # 3. Semicontinuous constraints (formulated as double inequalities):
        # w_i - z_i * w_max <= 0  AND  w_i - z_i * w_min >= 0
        semicontinuous_constraints = []
        for i in range(n):
            semicontinuous_constraints.append({
                "type": "inequality_less_or_equal",
                "linear_coefficients": {w_vars[i]: 1.0, z_vars[i]: -w_max},
                "target": 0.0,
                "penalty_multiplier": lagrange_multiplier
            })
            semicontinuous_constraints.append({
                "type": "inequality_greater_or_equal",
                "linear_coefficients": {w_vars[i]: 1.0, z_vars[i]: -w_min},
                "target": 0.0,
                "penalty_multiplier": lagrange_multiplier
            })
            
        # 4. Linearized Turnover Constraint: |w_i - w_i^0| <= d_i, Sum(d_i) <= L
        # Requires n auxiliary slack variables d_i
        d_vars = [f"d_{i}" for i in range(n)]
        turnover_constraints = []
        
        # d_i >= w_i - w_i^0  =>  w_i - d_i <= w_i^0
        # d_i >= w_i^0 - w_i  =>  -w_i - d_i <= -w_i^0
        for i in range(n):
            turnover_constraints.append({
                "type": "inequality_less_or_equal",
                "linear_coefficients": {w_vars[i]: 1.0, d_vars[i]: -1.0},
                "target": float(prev_weights[i]),
                "penalty_multiplier": lagrange_multiplier * 0.5
            })
            turnover_constraints.append({
                "type": "inequality_less_or_equal",
                "linear_coefficients": {w_vars[i]: -1.0, d_vars[i]: -1.0},
                "target": -float(prev_weights[i]),
                "penalty_multiplier": lagrange_multiplier * 0.5
            })
            
        # Sum(d_i) <= turnover_limit
        sum_turnover_constraint = {
            "type": "inequality_less_or_equal",
            "linear_coefficients": {d_vars[i]: 1.0 for i in range(n)},
            "target": float(turnover_limit),
            "penalty_multiplier": lagrange_multiplier * 0.5
        }
        
        # 5. Ex-Ante Tracking Error Constraint: (w - w_b)^T * Sigma * (w - w_b) <= TE_max^2
        # w^T * Sigma * w - 2 * w_b^T * Sigma * w <= TE_max^2 - w_b^T * Sigma * w_b
        if benchmark_weights is None:
            w_b = np.ones(n) / n
        else:
            w_b = benchmark_weights
            
        sigma_w_b = cov @ w_b
        w_b_sigma_w_b = float(w_b @ sigma_w_b)
        
        tracking_error_quad = {}
        for i in range(n):
            for j in range(n):
                val = float(cov[i, j])
                if abs(val) > 1e-9:
                    tracking_error_quad[(w_vars[i], w_vars[j])] = val
                    
        tracking_error_linear = {
            w_vars[i]: -2.0 * float(sigma_w_b[i]) for i in range(n)
        }
        
        tracking_error_constraint = {
            "type": "inequality_less_or_equal",
            "linear_coefficients": tracking_error_linear,
            "quadratic_coefficients": tracking_error_quad,
            "target": float(max_tracking_error ** 2 - w_b_sigma_w_b),
            "penalty_multiplier": lagrange_multiplier * 0.5
        }
        
        all_constraints = [budget_constraint, cardinality_constraint] + semicontinuous_constraints + turnover_constraints + [sum_turnover_constraint, tracking_error_constraint]
        
        return {
            "w_variables": w_vars,
            "z_variables": z_vars,
            "d_variables": d_vars,
            "objective": {
                "quadratic": objective_quad,
                "linear": objective_linear
            },
            "constraints": all_constraints,
            "lagrange_multipliers": {
                "equality_penalty": lagrange_multiplier,
                "inequality_penalty": lagrange_multiplier * 0.5
            }
        }

