"""
math_engine/credit_contagion.py
===============================
Supply Chain Credit Contagion & Debt Cascade Network.

Builds a directed financial dependency graph connecting suppliers, customers, and guarantors.
Calculates Debt-Contagion centrality to prune suppliers at risk of customer default.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, List

logger = logging.getLogger(__name__)


class CreditContagionNetworkEngine:
    """
    Financial Dependency Graph & Debt Cascade Contagion Engine.
    """

    @staticmethod
    def evaluate_contagion_risk(suppliers_dict: Dict[str, List[str]],
                                customer_defaults: List[str]) -> Dict[str, Any]:
        """
        Calculates credit contagion risk scores for universe suppliers.
        suppliers_dict: {supplier_ticker: [customer_ticker_1, customer_ticker_2]}
        """
        if not suppliers_dict or not customer_defaults:
            return {"at_risk_suppliers": [], "contagion_scores": {}}

        default_set = set(str(c).upper() for c in customer_defaults)
        at_risk = []
        contagion_scores = {}

        for supplier, customers in suppliers_dict.items():
            cust_upper = [str(c).upper() for c in customers]
            n_total = len(cust_upper) or 1
            n_defaulted = sum(1 for c in cust_upper if c in default_set)
            
            score = float(n_defaulted) / float(n_total)
            contagion_scores[supplier] = round(score, 4)
            if score >= 0.30:  # >30% customer base in default -> high contagion risk
                at_risk.append(supplier)

        return {
            "at_risk_suppliers": at_risk,
            "contagion_scores": contagion_scores
        }
