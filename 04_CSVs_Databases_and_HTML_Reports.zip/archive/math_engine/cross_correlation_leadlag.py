"""
math_engine/cross_correlation_leadlag.py
=========================================
Multi-Asset High-Frequency Cross-Correlation Matrix Lead-Lag Network.

Estimates lead-lag latency offset matrices tau_{ij} = argmax_tau CrossCorr(r_i(t), r_j(t - tau))
across correlated ticker pairs to exploit intraday price propagation lags.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, Tuple

logger = logging.getLogger(__name__)


class CrossCorrelationLeadLagEngine:
    """
    High-Frequency Cross-Correlation Lead-Lag Offset Matrix Estimator.
    """

    @staticmethod
    def estimate_lead_lag_offsets(returns_df: pd.DataFrame, max_lag: int = 5) -> Dict[str, Any]:
        """
        Calculates optimal lead-lag offset tau_ij (positive tau_ij means i leads j).
        """
        if returns_df is None or returns_df.empty or returns_df.shape[1] < 2:
            return {"optimal_lag_offset": 0, "max_cross_corr": 0.0, "leader_ticker": "N/A", "follower_ticker": "N/A"}

        clean_ret = returns_df.dropna().values
        tickers = list(returns_df.columns)
        n_assets = len(tickers)

        best_corr = -1.0
        best_lag = 0
        leader = tickers[0]
        follower = tickers[1] if n_assets > 1 else tickers[0]

        for i in range(n_assets):
            for j in range(n_assets):
                if i == j:
                    continue
                r_i = clean_ret[:, i]
                r_j = clean_ret[:, j]

                for lag in range(1, max_lag + 1):
                    # Cross-correlation between r_i(t) and r_j(t - lag)
                    corr = float(np.corrcoef(r_i[lag:], r_j[:-lag])[0, 1]) if len(r_i) > lag else 0.0
                    if corr > best_corr:
                        best_corr = corr
                        best_lag = lag
                        leader = tickers[i]
                        follower = tickers[j]

        return {
            "optimal_lag_offset": best_lag,
            "max_cross_corr": round(max(best_corr, 0.0), 4),
            "leader_ticker": leader,
            "follower_ticker": follower,
            "is_significant_lead_lag": bool(best_corr > 0.40)
        }
