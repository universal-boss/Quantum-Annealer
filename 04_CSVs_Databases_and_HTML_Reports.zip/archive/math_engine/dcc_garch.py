"""
math_engine/dcc_garch.py
========================
Multivariate Dynamic Conditional Correlation (DCC-GARCH) Engine.

Estimates time-varying correlation matrix R_t between asset returns:
  Q_t = (1 - a - b) * Q_bar + a * (e_{t-1} e'_{t-1}) + b * Q_{t-1}
  R_t = diag(Q_t)^{-1/2} * Q_t * diag(Q_t)^{-1/2}
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any

logger = logging.getLogger(__name__)


class DCCGARCHEngine:
    """
    Multivariate Dynamic Conditional Correlation (DCC-GARCH) Estimator.
    """

    @staticmethod
    def fit_dynamic_correlation(returns_df: pd.DataFrame, a: float = 0.05, b: float = 0.90) -> Dict[str, Any]:
        """
        Calculates time-varying correlation matrix R_t at current time step t.
        """
        if returns_df is None or returns_df.empty or returns_df.shape[1] < 2:
            return {"dcc_correlation_matrix": np.eye(2), "mean_dynamic_correlation": 0.0}

        clean_ret = returns_df.dropna().values
        if clean_ret.shape[0] < 10:
            return {"dcc_correlation_matrix": np.eye(clean_ret.shape[1]), "mean_dynamic_correlation": 0.0}

        # Demean and standardize residuals
        std = np.std(clean_ret, axis=0) + 1e-9
        e = (clean_ret - np.mean(clean_ret, axis=0)) / std

        n_assets = clean_ret.shape[1]
        q_bar = np.cov(e, rowvar=False)

        q_t = np.copy(q_bar)
        for t_idx in range(1, len(e)):
            e_prev = e[t_idx - 1].reshape(-1, 1)
            q_t = (1.0 - a - b) * q_bar + a * (e_prev @ e_prev.T) + b * q_t

        q_std = np.sqrt(np.diag(q_t)) + 1e-9
        r_t = q_t / np.outer(q_std, q_std)

        # Ensure valid correlation bounds
        r_t = np.clip(r_t, -1.0, 1.0)
        np.fill_diagonal(r_t, 1.0)

        mean_corr = float((np.sum(r_t) - n_assets) / (n_assets * (n_assets - 1) + 1e-9))

        return {
            "dcc_correlation_matrix": np.round(r_t, 4),
            "mean_dynamic_correlation": round(mean_corr, 4),
            "n_assets": n_assets
        }
