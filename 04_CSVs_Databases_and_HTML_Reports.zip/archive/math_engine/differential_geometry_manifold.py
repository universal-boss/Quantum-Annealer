"""
math_engine/differential_geometry_manifold.py
=============================================
Differential Geometry Ricci Curvature Flow Asset Clustering Engine.

Computes Forman-Ricci curvature R(e) on asset correlation graphs to identify market manifold bottlenecks.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any

logger = logging.getLogger(__name__)


class RicciCurvatureManifoldEngine:
    """
    Forman-Ricci Curvature Flow Asset Graph Bottleneck Calculator.
    """

    @staticmethod
    def compute_ricci_curvature(returns_df: pd.DataFrame) -> Dict[str, Any]:
        """
        Calculates mean Forman-Ricci curvature across correlation edges.
        """
        if returns_df is None or returns_df.empty or returns_df.shape[1] < 2:
            return {"mean_ricci_curvature": 0.0, "is_manifold_bottleneck": False}

        clean_ret = returns_df.dropna().values
        corr = np.abs(np.corrcoef(clean_ret, rowvar=False))
        np.fill_diagonal(corr, 0.0)

        d = np.sum(corr > 0.3, axis=1)  # Node degree at threshold 0.3
        curvatures = []
        n_assets = len(d)

        for i in range(n_assets):
            for j in range(i + 1, n_assets):
                if corr[i, j] > 0.3:
                    # Forman-Ricci curvature formula: R(e) = 4 - d(i) - d(j)
                    r_e = 4.0 - d[i] - d[j]
                    curvatures.append(r_e)

        mean_ricci = float(np.mean(curvatures)) if curvatures else 0.0

        return {
            "mean_ricci_curvature": round(mean_ricci, 4),
            "is_manifold_bottleneck": bool(mean_ricci < -5.0)
        }
