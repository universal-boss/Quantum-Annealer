"""
math_engine/epochs_i_ii.py
==========================
Implementation of Epoch I & II Cosmological Modules (V12 to V35).
Includes:
- Quark-Gluon Plasma Liquidity Flow (V12)
- Hawking Radiation Evaporation (V13)
- Neutron Star Equation of State Portfolio Density (V14)
- Cosmic Ray Muon Latency (V15)
- Relativistic Doppler Price Shift (V18)
- Landauer Boundary Heat Dissipation (V21)
- Shannon Information Entropic Density (V23)
- Tsallis Non-Extensive Entropy Risk (V25)
- Kolmogorov Complexity Signal Compressibility (V31)
- Von Neumann Entropy Spectral Shift (V34)
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


class QuarkGluonPlasmaLiquidity:
    """V12: Models market liquidity viscosity using Relativistic Navier-Stokes QGP bounds."""

    @staticmethod
    def compute_shear_viscosity_bound(
        entropy_density: float,
        temperature: float
    ) -> float:
        """Kovtun-Son-Starinets bound eta/s >= hbar / (4 * pi * k_B)."""
        # Rescaled constants for trading physics
        hbar_over_kb = 0.079577  # 1 / (4 * pi)
        min_viscosity = hbar_over_kb * entropy_density / max(1e-6, temperature)
        return float(min_viscosity)


class HawkingRadiationEvaporation:
    """V13: Models transaction fee and slippage leakage as Hawking black hole evaporation."""

    @staticmethod
    def calculate_evaporation_loss(
        portfolio_mass: float,
        time_elapsed: float,
        radiation_constant: float = 1e-4
    ) -> float:
        """Hawking temperature T_H scales with 1/M. Loss rate scales with 1/M^2."""
        if portfolio_mass <= 1e-6:
            return 0.0
        loss = radiation_constant * time_elapsed / (portfolio_mass ** 2)
        return float(np.clip(loss, 0.0, portfolio_mass))


class NeutronStarDensity:
    """V14: Hydrostatic pressure limits mapping weight leverage to TOV collapse bounds."""

    @staticmethod
    def check_hydrostatic_collapse(
        weights: np.ndarray,
        pressure_constant: float = 0.35
    ) -> tuple[bool, float]:
        """Checks if L2 concentration exceeds critical TOV stability limits."""
        concentration = float(np.sum(weights ** 2))
        collapse = concentration > pressure_constant
        return collapse, concentration


class CosmicRayLatency:
    """V15: Muon relativistic time dilation delay projections."""

    @staticmethod
    def calculate_relativistic_delay(
        distance_meters: float,
        velocity_pct_c: float
    ) -> float:
        """Delta_t = d / v * sqrt(1 - v^2/c^2)."""
        v = np.clip(velocity_pct_c, 0.0, 0.9999)
        c = 299792458.0  # Speed of light
        time_classical = distance_meters / (v * c + 1e-6)
        lorentz_gamma = np.sqrt(1.0 - v ** 2)
        return float(time_classical * lorentz_gamma)


class RelativisticDoppler:
    """V18: Relativistic Doppler shift price velocity filter."""

    @staticmethod
    def shift_price_frequency(
        base_price: float,
        velocity: float
    ) -> float:
        """f_prime = f * sqrt((1 - v) / (1 + v))."""
        v = np.clip(velocity, -0.99, 0.99)
        factor = np.sqrt((1.0 - v) / (1.0 + v))
        return float(base_price * factor)


class LandauerBoundary:
    """V21: Thermodynamic minimum energy dissipation inside computation FPGA boards."""

    @staticmethod
    def get_erasure_energy(
        n_bits: int,
        temperature_kelvin: float = 293.15
    ) -> float:
        """E = n * k_B * T * ln(2)."""
        k_b = 1.380649e-23
        energy = n_bits * k_b * temperature_kelvin * np.log(2.0)
        return float(energy)


class ShannonEntropyDensity:
    """V23: Calculates information entropy of factor series."""

    @staticmethod
    def compute_entropy(
        series: pd.Series,
        n_bins: int = 10
    ) -> float:
        """Shannon Entropy H(X) = -sum(p_i * log(p_i))."""
        if series.empty:
            return 0.0
        hist, _ = np.histogram(series.dropna(), bins=n_bins, density=True)
        prob = hist / (np.sum(hist) + 1e-12)
        prob = prob[prob > 0.0]
        entropy = -np.sum(prob * np.log2(prob))
        return float(entropy)


class TsallisNonExtensiveEntropy:
    """V25: Generalizes non-extensive statistical risk under heavy tails."""

    @staticmethod
    def compute_tsallis_risk(
        returns: np.ndarray,
        q_parameter: float = 1.5
    ) -> float:
        """Tsallis entropy S_q = (1 - sum(p^q)) / (q - 1)."""
        if len(returns) == 0:
            return 0.0
        hist, _ = np.histogram(returns, bins=10, density=True)
        prob = hist / (np.sum(hist) + 1e-12)
        prob = prob[prob > 0.0]
        if abs(q_parameter - 1.0) < 1e-6:
            return float(-np.sum(prob * np.log(prob)))
        tsallis = (1.0 - np.sum(prob ** q_parameter)) / (q_parameter - 1.0)
        return float(tsallis)


class KolmogorovComplexity:
    """V31: Approximates complexity using sequence compression size."""

    @staticmethod
    def estimate_complexity(
        sequence: np.ndarray
    ) -> float:
        """Approximates Kolmogorov complexity by compressing byte values."""
        try:
            import zlib
            bytes_data = sequence.astype(np.float32).tobytes()
            compressed = zlib.compress(bytes_data)
            return float(len(compressed)) / len(bytes_data)
        except Exception:
            return 1.0


class VonNeumannEntropy:
    """V34: Spectral correlation trace Von Neumann entropy."""

    @staticmethod
    def compute_von_neumann_entropy(
        correlation_matrix: np.ndarray
    ) -> float:
        """S(rho) = -tr(rho * log(rho)). Eigenvalues must be normalized to sum to 1."""
        eigvals = np.linalg.eigvalsh(correlation_matrix)
        # Normalize to probability distribution
        eigvals = np.clip(eigvals, 1e-12, None)
        probs = eigvals / np.sum(eigvals)
        entropy = -np.sum(probs * np.log(probs))
        return float(entropy)
