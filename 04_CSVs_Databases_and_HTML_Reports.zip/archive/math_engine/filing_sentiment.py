"""
math_engine/filing_sentiment.py
================================
Regulatory filing NLP sentiment extraction pipeline.
Processes earnings call transcripts and announcements to generate sentiment views for Black-Litterman priors.
"""
from __future__ import annotations

import re
import logging
from typing import Dict, Any, List, Tuple
import numpy as np

logger = logging.getLogger(__name__)

# Institutional keyword dictionaries for financial sentiment scoring
BULLISH_KEYWORDS = [
    r"\bgrowth\b", r"\boutperform\b", r"\bprofit\b", r"\brevenue increase\b",
    r"\bexpansion\b", r"\bbreakout\b", r"\bacquisition\b", r"\bstrong demand\b",
    r"\bmargin expansion\b", r"\bmarket share gain\b", r"\bguidance upgrade\b",
    r"\bdividend increase\b", r"\bpositive outlook\b"
]

BEARISH_KEYWORDS = [
    r"\bdecline\b", r"\bdeficit\b", r"\bloss\b", r"\bcontraction\b",
    r"\brevenue decrease\b", r"\bheadwinds\b", r"\bmargin pressure\b",
    r"\bguidance downgrade\b", r"\blawsuit\b", r"\bdefault\b",
    r"\bpledge increase\b", r"\bmarket share loss\b", r"\bcost overrun\b"
]


class FilingSentimentViewsExtractor:
    """Parses regulatory and transcript texts to compute Black-Litterman sentiment view inputs."""

    @classmethod
    def calculate_text_sentiment(cls, text: str) -> float:
        """Returns normalized sentiment score in range [-1.0, 1.0].
        
        Utilizes compiled financial keyword pattern matches for speed and stability.
        """
        if not text:
            return 0.0

        clean_text = text.lower()
        
        bull_count = 0
        for pattern in BULLISH_KEYWORDS:
            bull_count += len(re.findall(pattern, clean_text))

        bear_count = 0
        for pattern in BEARISH_KEYWORDS:
            bear_count += len(re.findall(pattern, clean_text))

        total_matches = bull_count + bear_count
        if total_matches == 0:
            return 0.0

        # Sentiment score bounded index
        sentiment_score = (bull_count - bear_count) / total_matches
        return float(sentiment_score)

    @classmethod
    def extract_views_from_transcripts(
        cls,
        filings_map: Dict[str, str],   # Ticker -> raw filing text
        tickers: List[str]
    ) -> Tuple[np.ndarray, np.ndarray, List[float]]:
        """Extracts views matrices P, Q, and view confidence from financial text filings.
        
        Returns:
            Tuple: P (views mapping matrix), Q (expected return view vector), confidences list
        """
        views_P = []
        views_Q = []
        confidences = []

        n_assets = len(tickers)

        for idx, ticker in enumerate(tickers):
            text = filings_map.get(ticker, "")
            if not text:
                continue

            sentiment = cls.calculate_text_sentiment(text)
            
            # Map sentiment non-zero score to an active views row
            if abs(sentiment) > 0.15:
                p_row = np.zeros(n_assets, dtype=np.float32)
                p_row[idx] = 1.0
                views_P.append(p_row)
                
                # Q expected return is sentiment scaled by a target premium factor (e.g. 5%)
                expected_ret = float(sentiment * 0.05)
                views_Q.append(expected_ret)
                
                # Confidence corresponds to sentiment absolute strength capped at 90%
                conf = float(min(0.90, max(0.10, abs(sentiment))))
                confidences.append(conf)

        if not views_P:
            return np.empty((0, n_assets)), np.empty(0), []

        return np.array(views_P), np.array(views_Q), confidences
