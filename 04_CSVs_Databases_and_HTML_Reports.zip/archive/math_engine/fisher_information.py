"""
math_engine/fisher_information.py
==================================
Fisher Information Matrix & Information Geometry Parameter Auditor.

Computes Fisher Information Matrix I(theta) = E[ (grad log f)^2 ] and Cramér-Rao lower bound
to evaluate parameter estimation variance and prevent model over-fitting.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any

logger = logging.getLogger(__name__)


class FisherInformationEngine:
    """
    Fisher Information Matrix & Cramér-Rao Bound Auditor.
    """

    @staticmethod
    def calculate_fisher_information(returns_series: pd.Series) -> Dict[str, Any]:
        """
        Calculates Fisher information for mean (mu) and variance (sigma^2) estimators.
        """
        clean_ret = returns_series.dropna().values
        n = len(clean_ret)
        if n < 10:
            return {"fisher_info_mu": 0.0, "cramer_rao_lower_bound": 999.0, "estimation_confidence": 0.50}

        sigma_sq = float(np.var(clean_ret, ddof=1)) + 1e-9
        
        # Fisher Information for Gaussian mean: I(mu) = n / sigma^2
        i_mu = float(n / sigma_sq)
        # Cramér-Rao lower bound for mean estimation variance: Var(mu_hat) >= 1 / I(mu)
        cramer_rao_lb = float(1.0 / i_mu)

        return {
            "fisher_info_mu": round(i_mu, 4),
            "cramer_rao_lower_bound": round(cramer_rao_lb, 8),
            "n_samples": n,
            "estimation_confidence": round(min(1.0, np.sqrt(n) / 20.0), 4)
        }
