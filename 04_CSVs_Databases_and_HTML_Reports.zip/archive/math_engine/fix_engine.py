"""
math_engine/fix_engine.py
===========================
Institutional-grade FIX 4.2/4.4 protocol serialization and connection engine.
"""
from __future__ import annotations

import time
from datetime import datetime
import hashlib
from typing import Dict, Any, Tuple

SOH = "\x01"  # SOH separator character for FIX messages

class FIXOrderSerializer:
    """Serializes portfolio order parameters into raw standard FIX 4.2/4.4 message strings."""

    def __init__(self, sender_comp_id: str = "QUANT_ANNEAL_PRO", target_comp_id: str = "ALADDIN_DESK") -> None:
        self.sender_comp_id = sender_comp_id
        self.target_comp_id = target_comp_id
        self.seq_num = 1

    def build_logon_message(self) -> str:
        """Constructs a Logon message (Tag 35=A)."""
        tags = [
            ("35", "A"),              # MsgType = Logon
            ("49", self.sender_comp_id),
            ("56", self.target_comp_id),
            ("34", str(self.seq_num)),
            ("52", datetime.utcnow().strftime("%Y%m%d-%H:%M:%S")),
            ("98", "0"),              # EncryptMethod = None
            ("108", "30"),            # HeartBtInt = 30 seconds
        ]
        self.seq_num += 1
        return self._compile_message(tags)

    def build_heartbeat_message(self) -> str:
        """Constructs a Heartbeat message (Tag 35=0)."""
        tags = [
            ("35", "0"),              # MsgType = Heartbeat
            ("49", self.sender_comp_id),
            ("56", self.target_comp_id),
            ("34", str(self.seq_num)),
            ("52", datetime.utcnow().strftime("%Y%m%d-%H:%M:%S")),
        ]
        self.seq_num += 1
        return self._compile_message(tags)

    def serialize_new_order_single(
        self,
        cl_ord_id: str,
        symbol: str,
        side: str, # "BUY" or "SELL"
        quantity: int,
        order_type: str = "MARKET",
        price: float = 0.0,
    ) -> str:
        """Constructs a New Order Single message (Tag 35=D)."""
        fix_side = "1" if side.upper() == "BUY" else "2"
        fix_type = "1" if order_type.upper() == "MARKET" else "2"
        
        tags = [
            ("35", "D"),              # MsgType = New Order Single
            ("49", self.sender_comp_id),
            ("56", self.target_comp_id),
            ("34", str(self.seq_num)),
            ("52", datetime.utcnow().strftime("%Y%m%d-%H:%M:%S")),
            ("11", cl_ord_id),        # Client Order ID
            ("21", "1"),              # HandlInst = Private (automated)
            ("55", symbol),           # Symbol / Ticker
            ("54", fix_side),         # Side: 1=Buy, 2=Sell
            ("38", str(quantity)),    # Quantity
            ("40", fix_type),         # Order Type: 1=Market, 2=Limit
        ]
        if fix_type == "2" and price > 0:
            tags.append(("44", f"{price:.2f}")) # Price for Limit orders
            
        self.seq_num += 1
        return self._compile_message(tags)

    def _compile_message(self, body_tags: list) -> str:
        """Combines BeginString, BodyLength, body, and Checksum tags."""
        # 1. Build body string (from Tag 35 onwards)
        body_str = "".join(f"{tag}={val}{SOH}" for tag, val in body_tags)
        
        # 2. Add BeginString (Tag 8) and BodyLength (Tag 9)
        begin_str = f"8=FIX.4.2{SOH}"
        length_str = f"9={len(body_str.encode('latin-1'))}{SOH}"
        
        full_msg_without_checksum = begin_str + length_str + body_str
        
        # 3. Compute Checksum (Tag 10)
        # Sum of byte values of all characters in the message (excluding checksum field itself)
        msg_bytes = full_msg_without_checksum.encode('latin-1')
        ascii_sum = sum(msg_bytes)
        checksum_val = ascii_sum % 256
        checksum_str = f"10={checksum_val:03d}{SOH}"
        
        return full_msg_without_checksum + checksum_str


class FIXConnectionManager:
    """Simulates a secure FIX protocol session connection, maintaining heartbeats and sequences."""

    def __init__(self, host: str = "127.0.0.1", port: int = 9876) -> None:
        self.host = host
        self.port = port
        self.serializer = FIXOrderSerializer()
        self.is_connected = False

    def connect(self) -> str:
        """Simulate Logon handshake."""
        self.is_connected = True
        logon_msg = self.serializer.build_logon_message()
        return logon_msg

    def disconnect(self) -> None:
        self.is_connected = False

    def send_heartbeat(self) -> str:
        if not self.is_connected:
            raise RuntimeError("FIX Session is not logged on.")
        return self.serializer.build_heartbeat_message()

    def route_order(
        self,
        symbol: str,
        side: str,
        quantity: int,
        order_type: str = "MARKET",
        price: float = 0.0,
    ) -> Tuple[str, str]:
        """Routes a single order, returning the unique ClOrdID and serialized raw FIX string."""
        if not self.is_connected:
            raise RuntimeError("FIX Session is not logged on.")
            
        import uuid
        cl_ord_id = f"CL-{uuid.uuid4().hex[:12].upper()}"
        fix_msg = self.serializer.serialize_new_order_single(
            cl_ord_id=cl_ord_id,
            symbol=symbol,
            side=side,
            quantity=quantity,
            order_type=order_type,
            price=price
        )
        return cl_ord_id, fix_msg
