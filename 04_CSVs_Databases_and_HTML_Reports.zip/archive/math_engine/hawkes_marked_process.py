"""
math_engine/hawkes_marked_process.py
====================================
Marked Hawkes Process Order Size & Price Impact Intensity Engine.

Extends standard Hawkes processes by marking event arrivals with order volume m_k:
  lambda(t, m) = (mu + sum_{t_k < t} alpha * (m_k / m_bar)^gamma * exp(-beta * (t - t_k))) * f(m)
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, List

logger = logging.getLogger(__name__)


class MarkedHawkesEngine:
    """
    Marked Hawkes Process Volume-Weighted Price Impact Intensity Engine.
    """

    @staticmethod
    def calculate_marked_intensity(order_volumes: List[float], order_times: List[float],
                                   beta: float = 1.0, gamma: float = 0.5) -> Dict[str, Any]:
        """
        Calculates marked jump intensity lambda(t, m) incorporating order size m_k.
        """
        if not order_volumes or not order_times or len(order_volumes) != len(order_times):
            return {"marked_intensity": 0.10, "is_block_order_excitation": False}

        v_arr = np.array(order_volumes, dtype=float)
        t_arr = np.array(order_times, dtype=float)
        m_bar = float(np.mean(v_arr)) + 1e-9

        t_now = t_arr[-1]
        dt = t_now - t_arr[:-1]
        decay = np.exp(-beta * np.maximum(0.0, dt))
        marks = (v_arr[:-1] / m_bar) ** gamma

        intensity = 0.10 + float(np.sum(0.5 * marks * decay))

        return {
            "marked_intensity": round(intensity, 4),
            "is_block_order_excitation": bool(intensity > 2.0),
            "mean_order_volume": round(m_bar, 2)
        }
