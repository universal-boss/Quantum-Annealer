"""
archive/math_engine/hive_mind_consensus.py
===========================================
Multi-Agent Alpha Voting & Consensus Aggregator.
"""
from __future__ import annotations

from math_engine.hive_mind_consensus import MultiAgentConsensusEngine, HiveMindConsensusEngine

__all__ = ["MultiAgentConsensusEngine", "HiveMindConsensusEngine"]
