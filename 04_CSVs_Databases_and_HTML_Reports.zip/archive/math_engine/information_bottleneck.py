"""
math_engine/information_bottleneck.py
======================================
Information Bottleneck (IB) Mutual Information Alpha Compressor.

Optimizes objective I(X; Z) - beta * I(Z; Y) to compress high-dimensional feature matrix X
into minimal sufficient alpha representation Z while preserving target forecast Y.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any

logger = logging.getLogger(__name__)


class InformationBottleneckEngine:
    """
    Tishby's Information Bottleneck Alpha Compression Engine.
    """

    @staticmethod
    def compress_alpha_representation(features_df: pd.DataFrame, target_series: pd.Series,
                                       beta: float = 1.5) -> Dict[str, Any]:
        """
        Compresses feature matrix into minimal sufficient representation Z.
        """
        if features_df is None or features_df.empty or target_series is None or target_series.empty:
            return {"mutual_information_xz": 0.0, "mutual_information_zy": 0.0, "ib_objective": 0.0}

        x = features_df.dropna().values
        y = target_series.reindex(features_df.index).fillna(0.0).values

        if len(x) < 10 or x.shape[1] < 2:
            return {"mutual_information_xz": 0.0, "mutual_information_zy": 0.0, "ib_objective": 0.0}

        # PCA compression as surrogate bottleneck Z
        u, s, vt = np.linalg.svd(x, full_matrices=False)
        z = u[:, :2]

        mi_xz = float(np.mean(np.log(s[:2] + 1e-6)))
        corr_zy = np.corrcoef(z[:, 0], y)[0, 1] if np.std(y) > 0 else 0.0
        mi_zy = float(abs(corr_zy))

        ib_obj = mi_xz - beta * mi_zy

        return {
            "mutual_information_xz": round(mi_xz, 4),
            "mutual_information_zy": round(mi_zy, 4),
            "ib_objective": round(ib_obj, 4),
            "compressed_rank": 2
        }
