"""
math_engine/kalman_pair_trading.py
===================================
Adaptive 2-State Kalman Filter Pair Trading & Cointegration Spread Engine.

Recursively updates hedge ratio beta_t and spread z-score z_t = (y_t - beta_t * x_t - alpha_t) / sigma_e
in real-time to trade statistical arbitrage pairs.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any

logger = logging.getLogger(__name__)


class KalmanPairTradingEngine:
    """
    Adaptive Kalman Filter Cointegration Pair Trading Engine.
    """

    @staticmethod
    def filter_pair_spread(series_y: pd.Series, series_x: pd.Series) -> Dict[str, Any]:
        """
        Runs Kalman filter to estimate rolling hedge ratio beta and spread z-score.
        """
        y = series_y.dropna().values
        x = series_x.dropna().values
        n = min(len(y), len(x))
        if n < 10:
            return {"hedge_ratio_beta": 1.0, "spread_zscore": 0.0, "trade_signal": "FLAT"}

        # State vector theta = [alpha, beta]^T
        theta = np.zeros(2)
        p_cov = np.eye(2) * 10.0
        r_var = 0.001
        q_var = 1e-5 * np.eye(2)

        spreads = []
        for t in range(n):
            f_t = np.array([1.0, x[t]])
            y_pred = float(np.dot(f_t, theta))
            e_t = y[t] - y_pred

            q_est = float(f_t @ p_cov @ f_t.T + r_var)
            k_gain = (p_cov @ f_t.T) / q_est

            theta = theta + k_gain * e_t
            p_cov = (np.eye(2) - np.outer(k_gain, f_t)) @ p_cov + q_var
            spreads.append(e_t)

        spread_arr = np.array(spreads)
        std_s = float(np.std(spread_arr)) + 1e-9
        z_score = float(spread_arr[-1] / std_s)

        signal = "LONG_PAIR" if z_score < -2.0 else ("SHORT_PAIR" if z_score > 2.0 else "FLAT")

        return {
            "hedge_ratio_beta": round(float(theta[1]), 4),
            "intercept_alpha": round(float(theta[0]), 4),
            "spread_zscore": round(z_score, 4),
            "trade_signal": signal
        }
