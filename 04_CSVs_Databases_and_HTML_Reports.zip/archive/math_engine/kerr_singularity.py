"""
archive/math_engine/kerr_singularity.py
=======================================
Institutional Non-Linear Market Regime Singularity Detector.
"""
from __future__ import annotations

from math_engine.kerr_singularity import RegimeSingularityDetector, KerrSingularityDetector

__all__ = ["RegimeSingularityDetector", "KerrSingularityDetector"]
