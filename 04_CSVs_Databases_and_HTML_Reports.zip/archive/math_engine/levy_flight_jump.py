"""
math_engine/levy_flight_jump.py
===============================
Heavy-Tailed Lévy Flight Jump Diffusion Stochastic Process Model.

Models non-Gaussian price jumps using alpha-stable Lévy flight process L_alpha(t)
with stability index alpha in (1, 2] to quantify fat-tailed market crash risk.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any

logger = logging.getLogger(__name__)


class LevyFlightJumpEngine:
    """
    Alpha-Stable Heavy-Tailed Lévy Flight Process Model.
    """

    @staticmethod
    def estimate_levy_stability_index(returns_series: pd.Series) -> Dict[str, Any]:
        """
        Estimates stability index alpha in (1, 2] where alpha < 2 indicates heavy-tailed Lévy jumps.
        """
        clean_ret = returns_series.dropna().values
        if len(clean_ret) < 20:
            return {"levy_alpha_stability": 2.0, "is_heavy_tailed_levy_jump": False}

        # Estimate characteristic exponent alpha from tail log-quantile ratio
        q99 = float(np.percentile(clean_ret, 99.0))
        q95 = float(np.percentile(clean_ret, 95.0))
        q90 = float(np.percentile(clean_ret, 90.0))

        ratio = (q99 - q95) / (q95 - q90 + 1e-9)
        alpha = float(np.clip(2.0 / (np.log(ratio + 1e-6) + 1.0), 1.05, 2.0))

        return {
            "levy_alpha_stability": round(alpha, 4),
            "is_heavy_tailed_levy_jump": bool(alpha < 1.75),
            "tail_jump_ratio": round(ratio, 4)
        }
