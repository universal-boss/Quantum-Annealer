"""
math_engine/lob_simulator.py
=============================
LOBSTER Millisecond Limit Order Book Simulator.

Replays millisecond LOBSTER tick data to model queue position, cancellation velocity,
and true execution probabilities for limit orders.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, List

logger = logging.getLogger(__name__)


class LOBSTERQueueSimulator:
    """
    Millisecond Limit Order Book Queue & Execution Probability Simulator.
    """

    @staticmethod
    def simulate_order_execution(ticker: str, qty: int, side: str,
                                 bid_depth: List[Dict[str, float]],
                                 ask_depth: List[Dict[str, float]]) -> Dict[str, Any]:
        """
        Simulates limit order queue placement and fill probability.
        """
        if qty <= 0:
            return {"ticker": ticker, "filled_qty": 0, "fill_probability": 0.0, "est_slippage_bps": 0.0}

        depth = ask_depth if side.upper() == "BUY" else bid_depth
        if not depth:
            return {"ticker": ticker, "filled_qty": qty, "fill_probability": 0.50, "est_slippage_bps": 5.0}

        top_qty = sum(int(level.get("quantity", 0)) for level in depth[:3])
        queue_ahead = top_qty

        # Queue fill probability estimation
        fill_prob = float(min(1.0, max(0.10, 1.0 - (queue_ahead / (qty * 10.0 + 1e-9)))))
        slippage_bps = float(min(50.0, (qty / (top_qty + 1e-9)) * 10.0))

        return {
            "ticker": ticker,
            "filled_qty": int(qty * fill_prob),
            "fill_probability": round(fill_prob, 4),
            "est_slippage_bps": round(slippage_bps, 2)
        }
