"""
math_engine/many_worlds_risk.py
===============================
Many-Worlds quantum branching portfolio optimizer.
Evaluates portfolio returns across parallel world timelines (branches)
and optimizes allocations by maximizing expected return while minimizing Shannon entropy dispersion.
"""
from __future__ import annotations

import logging
from typing import Dict, Any, List, Tuple
import numpy as np
import cvxpy as cp

logger = logging.getLogger(__name__)


class ManyWorldsPortfolioOptimizer:
    """Optimizes portfolio weight allocations across parallel-universe return distributions."""

    @classmethod
    def optimize_many_worlds(
        cls,
        world_returns: np.ndarray,       # shape: (K, N) - expected returns of N assets in K parallel universes
        gamma_entropy: float = 0.5,      # Penalty multiplier for Shannon entropy dispersion
        min_weight: float = 0.0,
        max_weight: float = 0.50
    ) -> np.ndarray:
        """Solves Many-Worlds Shannon Entropy portfolio optimization.
        
        Since Shannon entropy over softmax probabilities is non-convex in general,
        we linearize the objective using a local approximation or solve it via a projected
        gradient descent solver to guarantee convergence over the simplex constraints.
        
        Objective:
            f(w) = Expected_Return(w) - gamma * Shannon_Entropy(w)
        """
        K, N = world_returns.shape
        if K == 0 or N == 0:
            return np.ones(N) / N

        # Start with equal weights
        w = np.ones(N) / N
        lr = 0.05
        steps = 100

        # Gradient descent with simplex projection
        for step in range(steps):
            # 1. Compute portfolio return in each world k: R_k = sum_i( w_i * returns_{k,i} )
            R = world_returns @ w  # shape: (K,)
            
            # 2. Compute softmax probabilities of each world k
            exp_R = np.exp(R - np.max(R))
            p = exp_R / (exp_R.sum() + 1e-9)  # shape: (K,)
            
            # 3. Compute Shannon Entropy: H = -sum( p_k * ln(p_k) )
            # Small epsilon to prevent log(0)
            log_p = np.log(np.clip(p, 1e-9, 1.0))
            entropy = -float((p * log_p).sum())
            
            # 4. Compute gradient of Shannon Entropy w.r.t w:
            # dH/dw_i = - sum_k (1 + ln p_k) * dp_k/dw_i
            # where dp_k/dw_i = p_k * (returns_{k,i} - E[returns])
            expected_returns_world = world_returns.mean(axis=0)
            
            grad_entropy = np.zeros(N)
            for k in range(K):
                ret_k = world_returns[k]
                dp_dw = p[k] * (ret_k - expected_returns_world)
                grad_entropy += -(1.0 + log_p[k]) * dp_dw

            # Objective: Maximize expected return - gamma * entropy
            # So gradient to maximize is: grad = expected_returns_world - gamma * grad_entropy
            # Therefore gradient step to maximize (Gradient Ascent):
            grad = expected_returns_world - gamma_entropy * grad_entropy
            w_next = w + lr * grad
            
            # 5. Project w_next back onto the simplex probability space
            w = cls._project_simplex_numpy(w_next, min_weight, max_weight)

        logger.info(f"[ManyWorldsRisk] Optimization completed. Final Shannon Entropy: {entropy:.6f}")
        return w

    @staticmethod
    def _project_simplex_numpy(
        v: np.ndarray,
        min_weight: float = 0.0,
        max_weight: float = 0.50
    ) -> np.ndarray:
        """Projects a vector v onto the simplex constraints (sum(w)=1, w_i in [min_w, max_w])."""
        n = len(v)
        # Clip to boundaries
        w = np.clip(v, min_weight, max_weight)
        # Normalize to sum to 1.0
        w_sum = w.sum()
        if w_sum > 1e-9:
            w = w / w_sum
        else:
            w = np.ones(n) / n
        return w
