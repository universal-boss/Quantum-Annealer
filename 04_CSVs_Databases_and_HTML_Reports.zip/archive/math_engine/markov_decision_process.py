"""
math_engine/markov_decision_process.py
======================================
Markov Decision Process (MDP) Dynamic Programming Portfolio Allocation.

Solves Bellman Equation V(s) = max_a [ R(s,a) + gamma * sum_{s'} P(s'|s,a) * V(s') ]
for optimal dynamic cash vs asset allocation policy under transaction cost friction.
"""
from __future__ import annotations

import logging
import numpy as np
from typing import Dict, Any, List

logger = logging.getLogger(__name__)


class MDPPortfolioOptimizer:
    """
    Markov Decision Process Bellman Dynamic Programming Portfolio Allocator.
    """

    @staticmethod
    def solve_bellman_policy(n_states: int = 5, gamma: float = 0.95, max_iter: int = 50) -> Dict[str, Any]:
        """
        Solves Value Iteration for optimal state-action policy.
        """
        # States: 0=Extreme Bear, 1=Bear, 2=Neutral, 3=Bull, 4=Extreme Bull
        # Actions: 0=100% Cash, 1=50% Cash/50% Equity, 2=100% Equity
        v = np.zeros(n_states)
        policy = np.zeros(n_states, dtype=int)

        for _ in range(max_iter):
            v_new = np.copy(v)
            for s in range(n_states):
                q_vals = []
                for a in [0, 1, 2]:
                    # Reward function: higher equity action in bull state gives higher reward
                    reward = (s - 2) * (a - 1) * 1.5 - 0.1 * abs(a - 1)
                    # Next state transition P(s'|s,a)
                    s_next = min(max(s + (a - 1), 0), n_states - 1)
                    q_val = reward + gamma * v[s_next]
                    q_vals.append(q_val)

                best_a = int(np.argmax(q_vals))
                v_new[s] = q_vals[best_a]
                policy[s] = best_a

            v = v_new

        return {
            "value_function": np.round(v, 4).tolist(),
            "optimal_policy": policy.tolist(),
            "n_states": n_states
        }
