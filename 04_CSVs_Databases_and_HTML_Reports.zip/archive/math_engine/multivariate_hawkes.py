"""
math_engine/multivariate_hawkes.py
==================================
Multivariate Hawkes Process Jump Engine.

Computes cross-exciting volatility jump intensities:
  lambda_i(t) = mu_i + sum_j sum_{t_{k,j} < t} alpha_{ij} * exp(-beta_{ij} * (t - t_{k,j}))
across sector bellwether stocks to detect cross-asset volatility spillover cascades.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, List

logger = logging.getLogger(__name__)


class MultivariateHawkesJumpEngine:
    """
    Multivariate Self- and Cross-Exciting Hawkes Jump Engine.
    """

    def __init__(self, beta: float = 1.0):
        self.beta = beta

    def fit_predict_cross_intensity(self, returns_df: pd.DataFrame) -> Dict[str, Any]:
        """
        Fits cross-excitation intensity matrix Alpha and calculates systemic jump probability.
        """
        if returns_df is None or returns_df.empty or returns_df.shape[1] < 2:
            return {"systemic_jump_warning": False, "max_branching_ratio": 0.50}

        clean_ret = returns_df.dropna().values
        std_ret = np.std(clean_ret, axis=0) + 1e-9
        shocks = (np.abs(clean_ret) > 2.0 * std_ret).astype(float)

        n_assets = clean_ret.shape[1]
        alpha_matrix = np.zeros((n_assets, n_assets))

        for i in range(n_assets):
            for j in range(n_assets):
                # Cross-correlation of jump events
                corr = float(np.corrcoef(shocks[:, i], shocks[:, j])[0, 1]) if np.std(shocks[:, j]) > 0 else 0.0
                alpha_matrix[i, j] = max(0.0, corr * 0.8)

        # Spectral radius (max eigenvalue) of branching ratio matrix
        eigvals = np.linalg.eigvals(alpha_matrix)
        max_branching = float(np.max(np.abs(eigvals)))

        return {
            "systemic_jump_warning": bool(max_branching >= 1.0),
            "max_branching_ratio": round(max_branching, 4),
            "n_assets_analyzed": n_assets
        }
