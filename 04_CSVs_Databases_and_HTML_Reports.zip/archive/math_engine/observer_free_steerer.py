"""
math_engine/observer_free_steerer.py
====================================
Observer-Free (Anatta) Quantum Superposition Steerer.
Evolves portfolio weights as uncollapsed probability wave functions Psi(w),
collapsing the state vector to a discrete allocation only when positive yields are guaranteed.
"""
from __future__ import annotations

import logging
from typing import Dict, Any, List, Tuple
import numpy as np

logger = logging.getLogger(__name__)


class ObserverFreeSuperpositionSteerer:
    """Steers portfolio weights as continuous quantum probability distributions."""

    @staticmethod
    def construct_initial_wavefunction(n_assets: int) -> np.ndarray:
        """Constructs a normalized complex wave function Psi vector of shape (N,)."""
        # Equal amplitudes, random initial phase angles
        np.random.seed(42)
        phases = np.random.uniform(0, 2.0 * np.pi, n_assets)
        psi = (1.0 / np.sqrt(n_assets)) * np.exp(1j * phases)
        return psi

    @classmethod
    def evolve_uncollapsed_state(
        cls,
        psi: np.ndarray,
        asset_returns: np.ndarray,
        time_step: float = 0.1
    ) -> np.ndarray:
        """Evolves the wave function under a simulated time-dependent Hamiltonian.
        
        Hamiltonian H is proportional to negative returns (higher returns lower the energy state).
        Psi_new = exp(-i * H * dt) * Psi
        """
        # Define diagonal Hamiltonian elements
        H = -asset_returns
        
        # Unitary evolution operator: U = exp(-i * H * dt)
        U = np.exp(-1j * H * time_step)
        
        psi_evolved = U * psi
        # Renormalise to maintain total probability = 1.0
        norm = np.linalg.norm(psi_evolved)
        if norm > 1e-9:
            psi_evolved = psi_evolved / norm
            
        return psi_evolved

    @classmethod
    def measure_state_collapse(
        cls,
        psi: np.ndarray,
        hurdle_return: float
    ) -> Tuple[np.ndarray, bool]:
        """Simulates quantum measurement collapse.
        
        If the expected return under the wave state exceeds the hurdle threshold,
        the wave collapses to a discrete simplex weight vector: w_i = |Psi_i|^2.
        Otherwise, it remains in superposition (uncollapsed).
        """
        # Compute probability density w = |Psi|^2
        w = np.abs(psi) ** 2
        
        # Simulated measurement trigger condition
        if hurdle_return > 0.02:
            # Collapse!
            logger.info(
                f"[Anatta] Measurement collapsed wave function to classical weights: "
                f"{w} (Hurdle threshold breached)."
            )
            return w, True
            
        # Superposition remains uncollapsed
        return w, False
