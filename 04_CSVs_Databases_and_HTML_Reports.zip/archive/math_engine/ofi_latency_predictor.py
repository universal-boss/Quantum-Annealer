"""
math_engine/ofi_latency_predictor.py
=====================================
High-Frequency Order Flow Imbalance (OFI) Latency Predictor.

Computes sub-second Order Flow Imbalance (OFI) to predict immediate price impact direction:
  OFI_t = I_{delta P_b >= 0} * v_{b,t} - I_{delta P_b <= 0} * v_{b,t-1} - I_{delta P_a <= 0} * v_{a,t} + I_{delta P_a >= 0} * v_{a,t-1}
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, List

logger = logging.getLogger(__name__)


class OFILatencyPredictor:
    """
    Sub-Second Order Flow Imbalance (OFI) Price Impact Predictor.
    """

    @staticmethod
    def calculate_order_flow_imbalance(bid_prices: List[float], bid_volumes: List[float],
                                        ask_prices: List[float], ask_volumes: List[float]) -> Dict[str, Any]:
        """
        Calculates cumulative Order Flow Imbalance (OFI) metric across microsecond tick updates.
        """
        n = min(len(bid_prices), len(bid_volumes), len(ask_prices), len(ask_volumes))
        if n < 2:
            return {"ofi_metric": 0.0, "predicted_price_direction": "NEUTRAL", "impact_bps": 0.0}

        ofi_sum = 0.0
        for t in range(1, n):
            # Bid side flow e_b,t
            if bid_prices[t] > bid_prices[t - 1]:
                e_b = bid_volumes[t]
            elif bid_prices[t] == bid_prices[t - 1]:
                e_b = bid_volumes[t] - bid_volumes[t - 1]
            else:
                e_b = -bid_volumes[t - 1]

            # Ask side flow e_a,t
            if ask_prices[t] < ask_prices[t - 1]:
                e_a = ask_volumes[t]
            elif ask_prices[t] == ask_prices[t - 1]:
                e_a = ask_volumes[t] - ask_volumes[t - 1]
            else:
                e_a = -ask_volumes[t - 1]

            ofi_sum += (e_b - e_a)

        # Direction prediction
        if ofi_sum > 100.0:
            direction = "BULLISH_UPWARD"
        elif ofi_sum < -100.0:
            direction = "BEARISH_DOWNWARD"
        else:
            direction = "NEUTRAL"

        impact_bps = float(np.clip(ofi_sum * 0.01, -25.0, 25.0))

        return {
            "ofi_metric": round(ofi_sum, 2),
            "predicted_price_direction": direction,
            "impact_bps": round(impact_bps, 2)
        }
