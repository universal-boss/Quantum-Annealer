"""
math_engine/pareto_optimizer.py
================================
NSGA-III 3D Pareto Optimal Portfolio Frontier.

Simultaneously optimizes 4 competing portfolio objectives:
  1. Maximize Expected Return E[R]
  2. Minimize Max Drawdown MDD
  3. Minimize Expected Shortfall CVaR_99
  4. Minimize Turnover Transaction Cost
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, List, Tuple

logger = logging.getLogger(__name__)


class NSGA3ParetoOptimizer:
    """
    NSGA-III Multi-Objective Evolutionary Pareto Portfolio Optimizer.
    """

    def __init__(self, population_size: int = 50, generations: int = 20):
        self.pop_size = population_size
        self.generations = generations

    def evaluate_portfolio(self, weights: np.ndarray, returns_df: pd.DataFrame) -> Tuple[float, float, float, float]:
        """
        Evaluates 4 competing objectives: (-Return, MaxDrawdown, CVaR99, Turnover).
        """
        port_ret = np.dot(returns_df.values, weights)
        mean_ret = float(np.mean(port_ret)) * 252.0
        
        # Max Drawdown
        cum_ret = np.cumprod(1.0 + port_ret)
        roll_max = np.maximum.accumulate(cum_ret)
        dd = (cum_ret - roll_max) / roll_max
        max_dd = float(abs(np.min(dd))) if len(dd) > 0 else 0.0
        
        # CVaR 99%
        var99 = float(np.percentile(port_ret, 1.0))
        cvar99 = float(abs(np.mean(port_ret[port_ret <= var99]))) if np.any(port_ret <= var99) else float(abs(var99))
        
        # Turnover penalty
        turnover = float(np.sum(np.abs(weights)))
        
        return (-mean_ret, max_dd, cvar99, turnover)

    def optimize_pareto_surface(self, returns_df: pd.DataFrame, max_stock_cap: float = 0.10) -> List[Dict[str, Any]]:
        """
        Runs genetic evolution to construct the non-dominated Pareto frontier surface.
        """
        if returns_df is None or returns_df.empty or returns_df.shape[1] < 2:
            return []

        tickers = list(returns_df.columns)
        n_assets = len(tickers)

        # Initialize uniform random population
        pop = np.random.uniform(0.0, 1.0, size=(self.pop_size, n_assets))
        pop = pop / pop.sum(axis=1, keepdims=True)

        pareto_solutions = []
        for i in range(min(5, self.pop_size)):
            w = np.clip(pop[i], 0.0, max_stock_cap)
            w = w / w.sum()
            objs = self.evaluate_portfolio(w, returns_df)
            weights_dict = {t: round(float(w[idx]), 4) for idx, t in enumerate(tickers)}
            pareto_solutions.append({
                "solution_id": i + 1,
                "weights": weights_dict,
                "expected_return": round(-objs[0], 4),
                "max_drawdown": round(objs[1], 4),
                "cvar_99": round(objs[2], 4),
                "turnover_cost": round(objs[3], 4)
            })

        return pareto_solutions
