"""
math_engine/qaoa_optimizer.py
==============================
Quantum Approximate Optimization Algorithm (QAOA) compiler for gate-based quantum devices.
Converts portfolio QUBO matrices into quantum circuits (Qiskit & logical gate lists).
"""
from __future__ import annotations

import logging
from typing import Dict, Any, List, Tuple

logger = logging.getLogger(__name__)

try:
    import qiskit
    from qiskit import QuantumCircuit
    from qiskit.circuit import Parameter
    _HAS_QISKIT = True
except ImportError:
    _HAS_QISKIT = False


class QAOAPortfolioCompiler:
    """Compiles portfolio QUBO optimization targets into gate-based QAOA circuits."""

    @staticmethod
    def is_qiskit_available() -> bool:
        return _HAS_QISKIT

    @classmethod
    def compile_qaoa_circuit(
        cls,
        qubo_matrix: Dict[Tuple[int, int], float],
        n_qubits: int,
        p_layers: int = 1
    ) -> Dict[str, Any]:
        """Compiles a portfolio QUBO into a QAOA circuit.
        
        If Qiskit is available, constructs and returns a qiskit.QuantumCircuit.
        Otherwise, returns a detailed list of logic gates representing the ansatz.
        """
        gate_list = []
        
        # 1. Initialize superposition: Apply Hadamard gate to all qubits
        for i in range(n_qubits):
            gate_list.append({"gate": "H", "qubits": [i]})

        # 2. Add layers of Problem and Mixer Hamiltonians
        for layer in range(p_layers):
            gamma_param = f"gamma_{layer}"
            beta_param = f"beta_{layer}"
            
            # --- Problem Hamiltonian (ZZ gates and Rz gates) ---
            for (i, j), weight in qubo_matrix.items():
                if i == j:
                    # Single qubit Z rotation (diagonal bias term)
                    # angle = 2 * weight * gamma
                    gate_list.append({
                        "gate": "Rz",
                        "qubits": [i],
                        "parameter": gamma_param,
                        "scale": float(2.0 * weight)
                    })
                else:
                    # Two-qubit ZZ interaction (coupling term)
                    # Represented as CNOT -> Rz -> CNOT
                    # angle = weight * gamma
                    gate_list.append({
                        "gate": "CNOT",
                        "qubits": [i, j]
                    })
                    gate_list.append({
                        "gate": "Rz",
                        "qubits": [j],
                        "parameter": gamma_param,
                        "scale": float(weight)
                    })
                    gate_list.append({
                        "gate": "CNOT",
                        "qubits": [i, j]
                    })

            # --- Mixer Hamiltonian (Rx gates) ---
            for i in range(n_qubits):
                # angle = 2 * beta
                gate_list.append({
                    "gate": "Rx",
                    "qubits": [i],
                    "parameter": beta_param,
                    "scale": 2.0
                })

        # Build Qiskit circuit object if package is present
        qiskit_circuit = None
        if _HAS_QISKIT:
            try:
                qc = QuantumCircuit(n_qubits)
                
                # Apply initial Hadamard gates
                for i in range(n_qubits):
                    qc.h(i)
                    
                # Apply layers
                for layer in range(p_layers):
                    g = Parameter(f"gamma_{layer}")
                    b = Parameter(f"beta_{layer}")
                    
                    # Encode Problem Hamiltonian
                    for (i, j), weight in qubo_matrix.items():
                        if i == j:
                            qc.rz(2.0 * weight * g, i)
                        else:
                            qc.cx(i, j)
                            qc.rz(weight * g, j)
                            qc.cx(i, j)
                            
                    # Encode Mixer Hamiltonian
                    for i in range(n_qubits):
                        qc.rx(2.0 * b, i)
                        
                qiskit_circuit = qc
                logger.info("[QAOA] Successfully compiled Qiskit circuit with %d qubits.", n_qubits)
            except Exception as e:
                logger.error(f"[QAOA] Failed to instantiate Qiskit circuit: {e}")

        return {
            "n_qubits": n_qubits,
            "p_layers": p_layers,
            "logical_gates": gate_list,
            "qiskit_circuit": qiskit_circuit,
            "has_qiskit_compiled": (qiskit_circuit is not None)
        }
