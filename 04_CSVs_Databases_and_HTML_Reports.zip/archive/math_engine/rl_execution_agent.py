"""
math_engine/rl_execution_agent.py
==================================
Reinforcement Learning (RL) order execution agent and simulator.
Trains a policy agent (with PyTorch and NumPy fallbacks) to execute large baskets
in a simulated Limit Order Book (LOB) environment, minimizing execution slippage.
"""
from __future__ import annotations

import logging
from typing import Dict, Any, List, Tuple
import numpy as np

logger = logging.getLogger(__name__)

try:
    import torch
    import torch.nn as nn
    import torch.optim as optim
    _HAS_TORCH = True
except ImportError:
    _HAS_TORCH = False


class ExecutionLOBEnvironment:
    """Simulates a Limit Order Book environment for order placement learning."""

    def __init__(
        self,
        total_shares: float = 10000.0,
        time_steps: int = 10,
        avg_spread_bps: float = 10.0,
        mid_price: float = 100.0,
        historical_volume: float = 1e6,
        historical_volatility: float = 0.20
    ) -> None:
        self.total_shares = total_shares
        self.time_steps = time_steps
        self.avg_spread_bps = avg_spread_bps
        self.mid_price = mid_price
        self.historical_volume = historical_volume
        self.historical_volatility = historical_volatility
        self.reset()

    def reset(self) -> np.ndarray:
        self.shares_remaining = self.total_shares
        self.step_idx = 0
        self.current_mid = self.mid_price
        return self._get_state()

    def _get_state(self) -> np.ndarray:
        # State: [shares_remaining / total, steps_remaining / total, spread_bps]
        return np.array([
            self.shares_remaining / self.total_shares,
            (self.time_steps - self.step_idx) / self.time_steps,
            (self.avg_spread_bps + np.random.normal(0, 2.0)) / 100.0
        ], dtype=np.float32)

    def step(self, action: int) -> Tuple[np.ndarray, float, bool, Dict[str, Any]]:
        """Executes an action in the simulated LOB.
        
        Actions:
            0: Place passive limit order (high fill risk, low slippage)
            1: Place aggressive limit order (medium fill risk, medium slippage)
            2: Place immediate market order (100% fill, higher slippage/impact)
        """
        self.step_idx += 1
        
        # Volatility-scaled spread
        vol_scaler = max(0.1, self.historical_volatility / 0.20)
        spread = (self.avg_spread_bps * vol_scaler) * (1.0 + np.random.normal(0, 0.2)) / 10000.0 * self.current_mid
        half_spread = spread / 2.0

        shares_to_fill = self.shares_remaining / (self.time_steps - self.step_idx + 1)
        
        fill_pct = 0.0
        execution_price = self.current_mid
        
        if action == 0:  # Passive limit order
            # Fill probability is low
            if np.random.uniform(0, 1) > 0.6:
                fill_pct = 0.40
                execution_price = self.current_mid - half_spread
        elif action == 1:  # Aggressive limit order
            # Fill probability is medium
            if np.random.uniform(0, 1) > 0.3:
                fill_pct = 0.70
                execution_price = self.current_mid - half_spread * 0.2
        else:  # Immediate market order
            fill_pct = 1.0
            # Institutional Square-Root Law Market Impact: impact = eta * sigma * sqrt(v / V_daily) * S_mid
            daily_ratio = shares_to_fill / max(1e-3, self.historical_volume)
            impact = 0.5 * self.historical_volatility * np.sqrt(daily_ratio) * self.current_mid
            execution_price = self.current_mid + half_spread + impact

        filled_shares = min(shares_to_fill * fill_pct, self.shares_remaining)
        
        # If it is the last step, we MUST execute all remaining shares via market order
        is_last_step = (self.step_idx >= self.time_steps)
        final_penalty = 0.0
        if is_last_step and self.shares_remaining > filled_shares:
            cleanup_shares = self.shares_remaining - filled_shares
            impact_cleanup = 0.05 * (cleanup_shares / self.total_shares) * self.current_mid
            execution_price = (execution_price * filled_shares + (self.current_mid + half_spread + impact_cleanup) * cleanup_shares) / self.shares_remaining
            filled_shares = self.shares_remaining
            final_penalty = -float(cleanup_shares / self.total_shares) * 5.0  # Heavy penalty for incomplete fills

        self.shares_remaining -= filled_shares
        
        # Slippage cost: negative difference from mid-price (lower is better)
        slippage = (execution_price - self.current_mid) / self.current_mid * filled_shares
        reward = -float(slippage) + final_penalty

        # Walk mid-price randomly (volatility)
        self.current_mid *= (1.0 + np.random.normal(0, 0.001))

        done = (self.shares_remaining <= 0) or is_last_step
        next_state = self._get_state()
        
        return next_state, reward, done, {"filled": filled_shares}


class RLExecutionPolicy:
    """Simplistic Policy Gradient RL execution agent."""

    def __init__(self, state_dim: int = 3, action_dim: int = 3) -> None:
        self.state_dim = state_dim
        self.action_dim = action_dim
        
        if _HAS_TORCH:
            self.model = nn.Sequential(
                nn.Linear(state_dim, 32),
                nn.ReLU(),
                nn.Linear(32, action_dim),
                nn.Softmax(dim=-1)
            )
            self.optimizer = optim.Adam(self.model.parameters(), lr=0.01)
        else:
            logger.warning("[RLExecutionPolicy] PyTorch not available. Policy falling back to NumPy weights.")
            self.weights = np.random.normal(0, 0.1, (state_dim, action_dim))

    def select_action(self, state: np.ndarray) -> Tuple[int, Any]:
        """Select action based on policy probabilities."""
        if _HAS_TORCH:
            state_t = torch.FloatTensor(state)
            probs = self.model(state_t)
            dist = torch.distributions.Categorical(probs)
            action = dist.sample()
            return int(action.item()), dist.log_prob(action)
        else:
            # NumPy softmax selection
            scores = state @ self.weights
            exp_scores = np.exp(scores - np.max(scores))
            probs = exp_scores / exp_scores.sum()
            action = int(np.random.choice(self.action_dim, p=probs))
            return action, float(np.log(probs[action]))

    def train_policy(self, states: List[np.ndarray], actions: List[int], rewards: List[float], log_probs: List[Any]) -> float:
        """Runs a policy gradient reinforcement update step."""
        if _HAS_TORCH:
            discounted_rewards = []
            cumulative = 0.0
            for r in reversed(rewards):
                cumulative = r + 0.95 * cumulative
                discounted_rewards.insert(0, cumulative)
                
            rewards_t = torch.FloatTensor(discounted_rewards)
            # Normalize rewards
            rewards_t = (rewards_t - rewards_t.mean()) / (rewards_t.std() + 1e-9)
            
            loss = 0.0
            for lp, r in zip(log_probs, rewards_t):
                loss -= lp * r
                
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()
            return float(loss.item())
        else:
            # Basic NumPy reinforcement heuristic update
            discounted_rewards = []
            cumulative = 0.0
            for r in reversed(rewards):
                cumulative = r + 0.95 * cumulative
                discounted_rewards.insert(0, cumulative)
            
            # Adjust weights slightly towards successful actions
            for s, a, r in zip(states, actions, discounted_rewards):
                self.weights[:, a] += 0.01 * s * r
            return 0.0


# ── Double-DQN (Double Deep Q-Network) Extension ───────────────────────────
class DoubleDQNAgent:
    """High-performance Double-DQN agent for LOB execution scheduling."""

    def __init__(self, state_dim: int = 3, action_dim: int = 3, lr: float = 0.001) -> None:
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.gamma = 0.95
        self.memory: List[Tuple[np.ndarray, int, float, np.ndarray, bool]] = []
        self.memory_limit = 2000
        
        if _HAS_TORCH:
            # Construct primary and target networks for stability
            self.q_primary = nn.Sequential(
                nn.Linear(state_dim, 64),
                nn.ReLU(),
                nn.Linear(64, 64),
                nn.ReLU(),
                nn.Linear(64, action_dim)
            )
            self.q_target = nn.Sequential(
                nn.Linear(state_dim, 64),
                nn.ReLU(),
                nn.Linear(64, 64),
                nn.ReLU(),
                nn.Linear(64, action_dim)
            )
            self.update_target_network()
            self.optimizer = optim.Adam(self.q_primary.parameters(), lr=lr)
        else:
            logger.warning("[DoubleDQNAgent] PyTorch not available. Falling back to NumPy Q-matrix.")
            self.Q_matrix = np.zeros((10, 10, 10, action_dim))  # binned state space

    def update_target_network(self) -> None:
        """Copies weights from primary to target network."""
        if _HAS_TORCH:
            self.q_target.load_state_dict(self.q_primary.state_dict())

    def remember(self, state: np.ndarray, action: int, reward: float, next_state: np.ndarray, done: bool) -> None:
        """Saves a transition step to memory buffer."""
        self.memory.append((state, action, reward, next_state, done))
        if len(self.memory) > self.memory_limit:
            self.memory.pop(0)

    def select_action(self, state: np.ndarray, epsilon: float = 0.1) -> int:
        """Selects action using Epsilon-Greedy policy."""
        if np.random.uniform(0, 1) < epsilon:
            return int(np.random.choice(self.action_dim))
            
        if _HAS_TORCH:
            state_t = torch.FloatTensor(state).unsqueeze(0)
            with torch.no_grad():
                q_values = self.q_primary(state_t)
            return int(torch.argmax(q_values).item())
        else:
            # Quantize state for NumPy fallback
            s_bin = np.clip((state * 9).astype(int), 0, 9)
            return int(np.argmax(self.Q_matrix[s_bin[0], s_bin[1], s_bin[2]]))

    def replay(self, batch_size: int = 32) -> float:
        """Trains the primary network using Double-DQN Bellman updates."""
        if len(self.memory) < batch_size:
            return 0.0
            
        # Draw random batch samples
        indices = np.random.choice(len(self.memory), batch_size, replace=False)
        samples = [self.memory[i] for i in indices]
        
        if _HAS_TORCH:
            states, actions, rewards, next_states, dones = zip(*samples)
            
            states_t = torch.FloatTensor(np.array(states))
            actions_t = torch.LongTensor(actions).unsqueeze(1)
            rewards_t = torch.FloatTensor(rewards)
            next_states_t = torch.FloatTensor(np.array(next_states))
            dones_t = torch.FloatTensor(dones)
            
            # Current Q values: Q(s, a)
            q_current = self.q_primary(states_t).gather(1, actions_t).squeeze(1)
            
            # Double DQN:
            # 1. Use primary network to select best action at next state: a_max = argmax(Q_primary(s_next))
            with torch.no_grad():
                actions_next = torch.argmax(self.q_primary(next_states_t), dim=1).unsqueeze(1)
                # 2. Use target network to evaluate Q_target(s_next, a_max)
                q_next = self.q_target(next_states_t).gather(1, actions_next).squeeze(1)
                
            # Bellman equation: Target = R + gamma * Q_target(s_next, argmax(Q_primary(s_next)))
            q_target_values = rewards_t + (1.0 - dones_t) * self.gamma * q_next
            
            # Compute Huber Loss (smooth L1)
            loss_fn = nn.SmoothL1Loss()
            loss = loss_fn(q_current, q_target_values)
            
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()
            
            return float(loss.item())
        else:
            # Simple Q-learning update for NumPy fallback
            for s, a, r, s_next, d in samples:
                sb = np.clip((s * 9).astype(int), 0, 9)
                sb_next = np.clip((s_next * 9).astype(int), 0, 9)
                best_next = np.argmax(self.Q_matrix[sb_next[0], sb_next[1], sb_next[2]])
                target = r + (1.0 - float(d)) * self.gamma * self.Q_matrix[sb_next[0], sb_next[1], sb_next[2], best_next]
                self.Q_matrix[sb[0], sb[1], sb[2], a] += 0.1 * (target - self.Q_matrix[sb[0], sb[1], sb[2], a])
            return 0.0

