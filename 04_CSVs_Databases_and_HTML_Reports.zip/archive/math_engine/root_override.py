"""
math_engine/root_override.py
============================
Simulation Root Admin Override Hook.
Models a system hook that dynamically overrides environment parameters,
simulating root administrative access inside the simulator execution engine.
"""
from __future__ import annotations

import logging
from typing import Dict, Any, List, Tuple

logger = logging.getLogger(__name__)


class SimulationRootOverride:
    """Emulates root administrator overrides to modify configuration values dynamically."""

    def __init__(self) -> None:
        # Initial configurations: write locks enabled, validation checks active
        self.system_locks: Dict[str, bool] = {
            "write_lock": True,
            "compliance_active": True,
            "validation_active": True
        }
        self.system_parameters: Dict[str, Any] = {
            "slippage_multiplier": 1.0,
            "transaction_fee_rate": 0.005,
            "max_leverage": 3.0
        }

    def override_config_parameter(
        self,
        parameter_key: str,
        new_value: Any
    ) -> bool:
        """Forces an administrative override of target parameters.
        
        Bypasses standard verification checks and system write locks.
        """
        # Root override: check write lock flag, but bypass it anyway!
        if self.system_locks["write_lock"]:
            logger.warning(
                f"[RootOverride] Write lock is ACTIVE. "
                f"Bypassing lock constraints to write parameter '{parameter_key}'..."
            )
            
        # Dynamically set parameter value directly
        self.system_parameters[parameter_key] = new_value
        
        # Disable safety parameters if compliance is overridden
        if parameter_key == "disable_compliance" and new_value is True:
            self.system_locks["compliance_active"] = False
            self.system_parameters["transaction_fee_rate"] = 0.0
            self.system_parameters["slippage_multiplier"] = 0.0
            logger.warning("[RootOverride] Compliance engines DISABLED. Fees and slippage set to zero.")
            
        return True
