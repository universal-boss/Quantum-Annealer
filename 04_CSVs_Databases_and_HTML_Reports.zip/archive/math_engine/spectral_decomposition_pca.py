"""
math_engine/spectral_decomposition_pca.py
==========================================
Kernel Principal Component Analysis (Kernel PCA) Non-linear Factor Extractor.

Extracts non-linear principal factors using RBF Kernel Matrix K_ij = exp(-gamma * ||x_i - x_j||^2).
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any

logger = logging.getLogger(__name__)


class KernelPCAFactorExtractor:
    """
    RBF Kernel PCA Non-linear Factor Extractor.
    """

    @staticmethod
    def extract_kernel_factors(returns_df: pd.DataFrame, n_components: int = 3, gamma: float = 0.1) -> Dict[str, Any]:
        """
        Extracts top n_components non-linear Kernel PCA factors.
        """
        if returns_df is None or returns_df.empty or returns_df.shape[1] < n_components:
            return {"explained_variance_ratio": [0.0] * n_components, "n_components": n_components}

        x = returns_df.dropna().values
        n_samples, n_features = x.shape
        if n_samples < 10:
            return {"explained_variance_ratio": [0.0] * n_components, "n_components": n_components}

        # Compute RBF Kernel Matrix K_ij = exp(-gamma * ||x_i - x_j||^2)
        sq_dists = np.sum(x**2, axis=1).reshape(-1, 1) + np.sum(x**2, axis=1) - 2 * np.dot(x, x.T)
        k = np.exp(-gamma * np.maximum(0.0, sq_dists))

        # Center Kernel Matrix K_c = K - 1_n K - K 1_n + 1_n K 1_n
        one_n = np.ones((n_samples, n_samples)) / n_samples
        k_centered = k - one_n @ k - k @ one_n + one_n @ k @ one_n

        eigvals, eigvecs = np.linalg.eigh(k_centered)
        idx = np.argsort(eigvals)[::-1]
        eigvals = eigvals[idx]

        tot = np.sum(np.maximum(0.0, eigvals)) + 1e-9
        var_explained = [round(float(max(0.0, eigvals[i]) / tot), 4) for i in range(n_components)]

        return {
            "explained_variance_ratio": var_explained,
            "top_component_variance": var_explained[0] if var_explained else 0.0,
            "n_components": n_components
        }
