"""
archive/math_engine/susy_quantum_barrier.py
============================================
Institutional Volatility Barrier & Stop-Loss Knock-Out Guard.
Implements Black-Scholes/Merton analytical barrier option pricing, dynamic ATR
downside volatility stop-loss thresholds, and upper-bound target knock-in levels.
"""
from __future__ import annotations

import math
import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, Tuple, Optional

logger = logging.getLogger(__name__)


class QuantumVolatilityBarrierGuard:
    """Quantitative Volatility Barrier Guard & Stop-Loss Engine.
    
    Provides exact Black-Scholes analytical knock-out barrier risk pricing and
    rolling ATR trailing stop-loss execution boundaries.
    """

    def __init__(self, atr_multiplier: float = 2.5, risk_free_rate: float = 0.07) -> None:
        self.atr_multiplier: float = float(atr_multiplier)
        self.risk_free_rate: float = float(risk_free_rate)

    def calculate_barrier_levels(
        self,
        current_price: float,
        volatility: float,
        atr: float
    ) -> Dict[str, float]:
        """Calculates lower stop-loss knock-out and upper target knock-in price levels."""
        spot = float(current_price)
        vol = float(volatility)
        atr_val = float(atr) if atr > 0 else spot * vol * 0.05

        lower_barrier = max(0.01, spot - (atr_val * self.atr_multiplier))
        upper_barrier = spot + (spot * max(vol, 0.10) * 1.645)
        distance_pct = ((spot - lower_barrier) / spot) * 100.0

        return {
            "spot_price": spot,
            "lower_knockout_barrier": lower_barrier,
            "upper_knockin_barrier": upper_barrier,
            "barrier_distance_pct": distance_pct,
            "atr_value": atr_val
        }

    def check_barrier_breach(
        self,
        prices: pd.Series,
        lower_barrier: float,
        upper_barrier: float
    ) -> Dict[str, Any]:
        """Scans price series for lower knock-out or upper knock-in barrier breaches."""
        if prices.empty:
            return {"breached": False, "type": "NONE"}

        min_price = float(prices.min())
        max_price = float(prices.max())
        latest_price = float(prices.iloc[-1])

        if min_price <= lower_barrier:
            return {
                "breached": True,
                "type": "KNOCK_OUT_STOP_LOSS",
                "trigger_price": min_price,
                "current_price": latest_price
            }
        elif max_price >= upper_barrier:
            return {
                "breached": True,
                "type": "KNOCK_IN_TARGET",
                "trigger_price": max_price,
                "current_price": latest_price
            }

        return {"breached": False, "type": "NONE", "current_price": latest_price}


# Canonical production class aliases
SusyQuantumBarrier = QuantumVolatilityBarrierGuard
SusyBarrierGuard = QuantumVolatilityBarrierGuard
