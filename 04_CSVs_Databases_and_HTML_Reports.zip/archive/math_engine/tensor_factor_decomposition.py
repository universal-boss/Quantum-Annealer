"""
math_engine/tensor_factor_decomposition.py
===========================================
Tensor Decomposition (CP / CANDECOMP-PARAFAC) Factor Extractor.

Decomposes 3D tensor T in R^{Stocks x Factors x Time} into latent mode matrices
using CP rank reduction to isolate persistent cross-sectional factor drivers across time.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, List

logger = logging.getLogger(__name__)


class TensorFactorDecomposer:
    """
    CANDECOMP/PARAFAC (CP) Tensor Factor Decomposition Engine.
    """

    @staticmethod
    def decompose_factor_tensor(tensor_3d: np.ndarray, rank: int = 3, max_iter: int = 20) -> Dict[str, Any]:
        """
        Decomposes 3D tensor (Stocks x Factors x Time) into latent factor matrices A, B, C via ALS.
        """
        if tensor_3d is None or tensor_3d.ndim != 3 or tensor_3d.size == 0:
            return {"latent_stock_factors": np.array([]), "reconstruction_error": 0.0}

        shape = tensor_3d.shape
        n_stocks, n_factors, n_time = shape

        # Initialize random factor matrices
        a = np.random.randn(n_stocks, rank)
        b = np.random.randn(n_factors, rank)
        c = np.random.randn(n_time, rank)

        # Alternating Least Squares (ALS) iterations
        for _ in range(max_iter):
            # Update A
            bc = np.einsum('fr,tr->ftr', b, c).reshape(-1, rank)
            t_unfold_0 = tensor_3d.reshape(n_stocks, -1)
            a = np.linalg.lstsq(bc, t_unfold_0.T, rcond=None)[0].T

            # Update B
            ac = np.einsum('sr,tr->str', a, c).reshape(-1, rank)
            t_unfold_1 = np.transpose(tensor_3d, (1, 0, 2)).reshape(n_factors, -1)
            b = np.linalg.lstsq(ac, t_unfold_1.T, rcond=None)[0].T

            # Update C
            ab = np.einsum('sr,fr->sfr', a, b).reshape(-1, rank)
            t_unfold_2 = np.transpose(tensor_3d, (2, 0, 1)).reshape(n_time, -1)
            c = np.linalg.lstsq(ab, t_unfold_2.T, rcond=None)[0].T

        # Reconstruction error
        recon = np.einsum('sr,fr,tr->sft', a, b, c)
        error = float(np.linalg.norm(tensor_3d - recon) / (np.linalg.norm(tensor_3d) + 1e-9))

        return {
            "latent_stock_factors": np.round(a, 4),
            "reconstruction_error": round(error, 4),
            "rank": rank
        }
