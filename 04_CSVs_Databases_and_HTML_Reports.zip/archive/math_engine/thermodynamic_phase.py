"""
math_engine/thermodynamic_phase.py
==================================
Thermodynamic Simulated Annealing Free-Energy Phase Transition Engine.

Calculates Helmholtz Free Energy F = E - T*S and specific heat capacity C_v = dE/dT
across annealing temperature schedules to detect phase transitions in portfolio optimization.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, List

logger = logging.getLogger(__name__)


class ThermodynamicPhaseEngine:
    """
    Simulated Annealing Helmholtz Free Energy & Phase Transition Calculator.
    """

    @staticmethod
    def calculate_phase_transition(temperatures: List[float], energies: List[float]) -> Dict[str, Any]:
        """
        Calculates Free Energy F = E - T*S and specific heat C_v = Var(E) / T^2 to detect critical phase transitions.
        """
        if not temperatures or not energies or len(temperatures) != len(energies) or len(temperatures) < 5:
            return {"helmholtz_free_energy": 0.0, "specific_heat_capacity": 0.0, "is_phase_transition_freeze": False}

        t_arr = np.array(temperatures, dtype=float)
        e_arr = np.array(energies, dtype=float)

        # Entropy estimation: S = (E - F) / T
        entropy = float(np.std(e_arr) / (np.mean(t_arr) + 1e-9))
        free_energy = float(np.mean(e_arr) - np.mean(t_arr) * entropy)

        # Specific heat capacity C_v = Var(E) / T^2
        c_v = float(np.var(e_arr) / (np.mean(t_arr) ** 2 + 1e-9))

        # Critical phase transition occurs at specific heat peak (C_v > threshold)
        is_phase_freeze = bool(c_v > 2.5 * float(np.mean(e_arr) + 1e-6))

        return {
            "helmholtz_free_energy": round(free_energy, 4),
            "specific_heat_capacity": round(c_v, 4),
            "estimated_entropy": round(entropy, 4),
            "is_phase_transition_freeze": is_phase_freeze
        }
