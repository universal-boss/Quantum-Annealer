"""
math_engine/wasserstein_barycenter_flow.py
===========================================
Optimal Transport Wasserstein Gradient Flow Portfolio Rebalancing Engine.

Calculates continuous gradient flow trajectory w(t) along the Wasserstein probability manifold
to minimize turnover rebalancing friction while transitioning between portfolio allocation states.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, List

logger = logging.getLogger(__name__)


class WassersteinGradientFlowEngine:
    """
    Optimal Transport Wasserstein Gradient Flow Trajectory Allocator.
    """

    @staticmethod
    def compute_flow_trajectory(w_current: Dict[str, float], w_target: Dict[str, float],
                                n_steps: int = 5) -> List[Dict[str, float]]:
        """
        Computes Wasserstein gradient flow interpolation steps between current and target weights.
        """
        all_tickers = sorted(list(set(list(w_current.keys()) + list(w_target.keys()))))
        if not all_tickers:
            return []

        w_curr_arr = np.array([w_current.get(t, 0.0) for t in all_tickers], dtype=float)
        w_targ_arr = np.array([w_target.get(t, 0.0) for t in all_tickers], dtype=float)

        trajectory = []
        for step in range(n_steps + 1):
            t = float(step) / float(n_steps)
            # Geodesic interpolation along optimal transport path
            w_step = (1.0 - t) * w_curr_arr + t * w_targ_arr
            w_step_norm = w_step / (np.sum(w_step) + 1e-9)
            trajectory.append({t_name: round(float(w_step_norm[idx]), 4) for idx, t_name in enumerate(all_tickers)})

        return trajectory
