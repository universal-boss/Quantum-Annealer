"""
math_engine/wavelet_multiresolution.py
======================================
Discrete Wavelet Transform (DWT) Multi-Resolution Frequency Decomposer.

Decomposes time series into approximation A_j and detail D_j coefficients
to separate high-frequency microstructure noise from low-frequency secular trends.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any

logger = logging.getLogger(__name__)


class WaveletMultiresolutionEngine:
    """
    Haar Discrete Wavelet Transform (DWT) Multi-Resolution Decomposer.
    """

    @staticmethod
    def decompose_wavelet(series: pd.Series) -> Dict[str, Any]:
        """
        Performs 1-level Haar wavelet decomposition into Approximation (low-pass) and Detail (high-pass).
        """
        vals = series.dropna().values
        n = len(vals)
        if n < 4:
            return {"trend_power_ratio": 0.50, "noise_power_ratio": 0.50}

        # Truncate to even length
        if n % 2 != 0:
            vals = vals[:-1]

        # Haar DWT: Approx = (x_even + x_odd)/sqrt(2), Detail = (x_even - x_odd)/sqrt(2)
        even = vals[0::2]
        odd = vals[1::2]

        approx = (even + odd) / np.sqrt(2.0)
        detail = (even - odd) / np.sqrt(2.0)

        approx_power = float(np.sum(approx**2))
        detail_power = float(np.sum(detail**2))
        total_power = approx_power + detail_power + 1e-9

        return {
            "trend_power_ratio": round(approx_power / total_power, 4),
            "noise_power_ratio": round(detail_power / total_power, 4),
            "is_trend_dominant": bool((approx_power / total_power) > 0.70)
        }
