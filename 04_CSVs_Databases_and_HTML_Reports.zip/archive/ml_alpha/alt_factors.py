"""Alternative data factors — the real source of edge in Indian markets.

Technical factors (momentum, RSI, MACD) are public knowledge and arbitraged away.
These alternative data factors capture information that retail traders don't have:

  - NSE Delivery %: institutional conviction (delivery > 50% = strong hands)
  - FII/DII Flows: smart money direction (net buy = bullish)
  - Bulk/Block Deals: large institutional footprints
  - Pledge Data: promoter pledging (distress signal)
  - Fundamental Factors: P/E, P/B, ROE, debt-to-equity, revenue growth
  - Sector Momentum: sector ETF relative strength
  - Short-term Reversal: 3-day mean reversion (contrarian)
  - Earnings Quality: accruals ratio, earnings surprise

All factors are PIT-correct (only use data available at time t).
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Optional


# ═══════════════════════════════════════════════════════════════════════════════
# ALTERNATIVE DATA FACTORS
# ═══════════════════════════════════════════════════════════════════════════════

def delivery_conviction_factor(
    close: pd.Series,
    volume: pd.Series,
    delivered_qty: pd.Series,
    lookback: int = 21,
) -> pd.Series:
    """NSE Delivery % conviction — institutional hands signal.

    High delivery % (>50%) = institutions holding, not intraday speculation.
    Low delivery % (<30%) = retail speculation, weak hands.

    Factor = rolling avg delivery % - 50 (centered at 0)
    Positive = strong hands, Negative = weak hands.
    """
    if len(close) < lookback or len(delivered_qty) < lookback:
        return pd.Series(dtype=float)
    common = close.index.intersection(volume.index).intersection(delivered_qty.index)
    if len(common) < lookback:
        return pd.Series(dtype=float)
    v = volume.loc[common]
    d = delivered_qty.loc[common]
    # Delivery % = delivered / total traded
    safe_v = v.replace(0, np.nan)
    delivery_pct = (d / safe_v).replace([np.inf, -np.inf], np.nan)
    # Rolling average, centered at 50%
    return (delivery_pct.rolling(lookback).mean() - 0.50).dropna()


def fii_dii_flow_factor(
    close: pd.Series,
    fii_flow: pd.Series,
    dii_flow: pd.Series,
    lookback: int = 5,
) -> pd.Series:
    """FII + DII net flow factor — smart money direction.

    Positive flow = institutions net buying = bullish.
    Negative flow = institutions net selling = bearish.

    Factor = rolling sum of (FII + DII) net flow, z-scored.
    """
    if len(close) < lookback:
        return pd.Series(dtype=float)
    common = close.index.intersection(fii_flow.index).intersection(dii_flow.index)
    if len(common) < lookback:
        return pd.Series(dtype=float)
    total_flow = (fii_flow.loc[common] + dii_flow.loc[common]).fillna(0.0)
    rolling_flow = total_flow.rolling(lookback).sum()
    # Z-score for cross-sectional comparability
    std = rolling_flow.std()
    if not np.isfinite(std) or std < 1e-9:
        return pd.Series(dtype=float)
    return ((rolling_flow - rolling_flow.mean()) / std).dropna()


def bulk_block_footprint_factor(
    close: pd.Series,
    bulk_deal_signal: pd.Series,
    lookback: int = 10,
) -> pd.Series:
    """Bulk/block deal footprint — large institutional activity.

    bulk_deal_signal: +1 for net buy bulk deals, -1 for net sell, 0 for none.
    Factor = rolling sum of signals (positive = accumulation, negative = distribution).
    """
    if len(close) < lookback or len(bulk_deal_signal) < lookback:
        return pd.Series(dtype=float)
    common = close.index.intersection(bulk_deal_signal.index)
    if len(common) < lookback:
        return pd.Series(dtype=float)
    return bulk_deal_signal.loc[common].rolling(lookback).sum().dropna()


def pledge_distress_factor(
    close: pd.Series,
    pledge_pct: pd.Series,
) -> pd.Series:
    """Promoter pledging — distress signal.

    High pledge % (>50%) = promoter has pledged shares for loans = distress.
    Low pledge % (<10%) = healthy balance sheet.

    Factor = -1 × pledge_pct (negative because high pledge is bearish).
    """
    if len(close) == 0 or len(pledge_pct) == 0:
        return pd.Series(dtype=float)
    common = close.index.intersection(pledge_pct.index)
    if len(common) == 0:
        return pd.Series(dtype=float)
    return (-pledge_pct.loc[common]).dropna()


def pe_value_factor(close: pd.Series, pe_ratio: pd.Series) -> pd.Series:
    """P/E value factor — inverse P/E (value investing).

    High P/E = expensive (bearish for value strategies).
    Low P/E = cheap (bullish for value strategies).

    Factor = 1 / P/E (so higher = cheaper = more bullish).
    """
    if len(close) == 0 or len(pe_ratio) == 0:
        return pd.Series(dtype=float)
    common = close.index.intersection(pe_ratio.index)
    if len(common) == 0:
        return pd.Series(dtype=float)
    safe_pe = pe_ratio.loc[common].replace(0, np.nan).clip(lower=1.0)
    return (1.0 / safe_pe).replace([np.inf, -np.inf], np.nan).dropna()


def pb_value_factor(close: pd.Series, pb_ratio: pd.Series) -> pd.Series:
    """P/B value factor — inverse P/B (book value investing)."""
    if len(close) == 0 or len(pb_ratio) == 0:
        return pd.Series(dtype=float)
    common = close.index.intersection(pb_ratio.index)
    if len(common) == 0:
        return pd.Series(dtype=float)
    safe_pb = pb_ratio.loc[common].replace(0, np.nan).clip(lower=0.1)
    return (1.0 / safe_pb).replace([np.inf, -np.inf], np.nan).dropna()


def roe_quality_factor(close: pd.Series, roe: pd.Series) -> pd.Series:
    """ROE quality factor — return on equity.

    High ROE (>20%) = high-quality company generating strong returns.
    Low ROE (<10%) = poor capital efficiency.
    """
    if len(close) == 0 or len(roe) == 0:
        return pd.Series(dtype=float)
    common = close.index.intersection(roe.index)
    if len(common) == 0:
        return pd.Series(dtype=float)
    return roe.loc[common].dropna()


def debt_to_equity_factor(close: pd.Series, de_ratio: pd.Series) -> pd.Series:
    """Debt-to-equity leverage factor — inverse (low debt = quality).

    High D/E (>2.0) = overleveraged (bearish).
    Low D/E (<0.5) = conservative balance sheet (bullish).

    Factor = -D/E (negative because high debt is bearish).
    """
    if len(close) == 0 or len(de_ratio) == 0:
        return pd.Series(dtype=float)
    common = close.index.intersection(de_ratio.index)
    if len(common) == 0:
        return pd.Series(dtype=float)
    return (-de_ratio.loc[common]).dropna()


def revenue_growth_factor(close: pd.Series, revenue_growth: pd.Series) -> pd.Series:
    """Revenue growth factor — top-line growth momentum."""
    if len(close) == 0 or len(revenue_growth) == 0:
        return pd.Series(dtype=float)
    common = close.index.intersection(revenue_growth.index)
    if len(common) == 0:
        return pd.Series(dtype=float)
    return revenue_growth.loc[common].dropna()


def sector_momentum_factor(
    close: pd.Series,
    sector_index: pd.Series,
    lookback: int = 63,
) -> pd.Series:
    """Sector momentum — relative strength vs sector index.

    Factor = stock return / sector return - 1 (positive = outperforming sector).
    """
    if len(close) < lookback or len(sector_index) < lookback:
        return pd.Series(dtype=float)
    common = close.index.intersection(sector_index.index)
    if len(common) < lookback:
        return pd.Series(dtype=float)
    c = close.loc[common]
    s = sector_index.loc[common]
    stock_ret = c / c.shift(lookback) - 1.0
    sector_ret = s / s.shift(lookback) - 1.0
    safe_sector = sector_ret.replace(0, np.nan)
    return (stock_ret / safe_sector - 1.0).replace([np.inf, -np.inf], np.nan).dropna()


def short_term_reversal_factor(close: pd.Series, lookback: int = 3) -> pd.Series:
    """Short-term reversal — 3-day mean reversion (contrarian).

    Stocks that dropped over 3 days tend to bounce back (contrarian).
    Factor = -1 × 3-day return (negative because reversal = opposite of recent move).
    """
    if len(close) < lookback + 1:
        return pd.Series(dtype=float)
    ret = close / close.shift(lookback) - 1.0
    return (-ret).dropna()


def earnings_surprise_factor(
    close: pd.Series,
    actual_eps: pd.Series,
    expected_eps: pd.Series,
) -> pd.Series:
    """Earnings surprise — actual vs expected EPS.

    Positive surprise = actual > expected = bullish.
    Negative surprise = actual < expected = bearish.

    Factor = (actual - expected) / |expected| (surprise %).
    """
    if len(close) == 0 or len(actual_eps) == 0:
        return pd.Series(dtype=float)
    common = close.index.intersection(actual_eps.index).intersection(expected_eps.index)
    if len(common) == 0:
        return pd.Series(dtype=float)
    a = actual_eps.loc[common]
    e = expected_eps.loc[common]
    safe_e = e.replace(0, np.nan)
    return ((a - e) / safe_e.abs()).replace([np.inf, -np.inf], np.nan).dropna()


def accruals_quality_factor(
    close: pd.Series,
    net_income: pd.Series,
    operating_cash_flow: pd.Series,
) -> pd.Series:
    """Accruals ratio — earnings quality signal.

    High accruals (net income >> cash flow) = low earnings quality (bearish).
    Low accruals (net income ≈ cash flow) = high earnings quality (bullish).

    Sloan's accruals: accruals = (NI - OCF) / Total Assets
    We approximate with (NI - OCF) / |NI| since we don't have total assets.
    """
    if len(close) == 0 or len(net_income) == 0:
        return pd.Series(dtype=float)
    common = close.index.intersection(net_income.index).intersection(operating_cash_flow.index)
    if len(common) == 0:
        return pd.Series(dtype=float)
    ni = net_income.loc[common]
    ocf = operating_cash_flow.loc[common]
    accruals = ni - ocf
    safe_ni = ni.replace(0, np.nan)
    # Negative because high accruals = low quality = bearish
    return (-(accruals / safe_ni.abs())).replace([np.inf, -np.inf], np.nan).dropna()


# ═══════════════════════════════════════════════════════════════════════════════
# FACTOR REGISTRY — all alternative data factors
# ═══════════════════════════════════════════════════════════════════════════════

ALT_FACTOR_NAMES = [
    "delivery_conviction",
    "fii_dii_flow",
    "bulk_block_footprint",
    "pledge_distress",
    "pe_value",
    "pb_value",
    "roe_quality",
    "debt_to_equity",
    "revenue_growth",
    "sector_momentum",
    "short_term_reversal",
    "earnings_surprise",
    "accruals_quality",
]
