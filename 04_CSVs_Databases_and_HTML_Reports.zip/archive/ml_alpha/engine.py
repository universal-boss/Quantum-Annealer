"""Alpha Engine — the main ML fitting pipeline for the Quantum Annealer.

Wires together: factor computation → preprocessing → walk-forward CV →
Ridge/LightGBM ensemble → deflated Sharpe → alpha predictions.

Uses the app's existing safe_download() for price data.
Outputs alpha scores that feed directly into the existing optimizer.
"""
from __future__ import annotations

import logging
import time
import uuid
import warnings
from datetime import date, timedelta
from typing import Callable

import numpy as np
import pandas as pd
from pydantic import BaseModel, ConfigDict

_module_logger = logging.getLogger(__name__)

from .factors import compute_all_factors, preprocess_factors, ALL_FACTOR_NAMES
from .model import AlphaEnsemble
from .expanded_ensemble import ExpandedAlphaEnsemble
from .walk_forward import WalkForwardCV, CombinatorialPurgedCV
from .metrics import spearman_ic, deflated_sharpe_ratio, walk_forward_efficiency, quantile_sharpe, ic_half_life
from .labeling import compute_daily_volatility, triple_barrier_labels, labels_to_forward_returns
from .feature_selection import select_factors
from .feature_engineering import engineer_features
from .feature_store import FeatureStore, ExperimentTracker
# realtime_risk is in math_engine (sibling package) — use lazy import inside fit()
# to avoid cross-package import failures at module load time

warnings.filterwarnings("ignore")


class FitResult(BaseModel):
    """Result of an ML fitting run."""
    model_config = ConfigDict(arbitrary_types_allowed=True)

    run_id: str
    started_at: str
    completed_at: str
    n_tickers: int
    n_observations: int
    n_features: int
    feature_names: list[str]
    per_fold_metrics: list[dict]
    in_sample_sharpe_mean: float
    in_sample_sharpe_std: float
    out_of_sample_sharpe_mean: float
    out_of_sample_sharpe_std: float
    walk_forward_efficiency: float
    deflated_sharpe: float
    n_trials: int
    feature_importance: dict[str, float]
    model_type: str = "ridge"
    ic_half_life_days: float = -1.0         # AR(1) IC mean-reversion half-life (fold-units)
    ic_is_decaying: bool = False            # True when recent IC < historical mean IC


class AlphaEngine:
    """ML alpha engine for the Quantum Annealer.

    Usage:
        engine = AlphaEngine()
        result = engine.fit(
            start="2022-01-01", end="2026-06-28",
            universe="nifty500",
            progress_cb=lambda msg: print(msg),
        )
        alpha = engine.predict(as_of=date.today())
        # alpha = {"RELIANCE.NS": 0.15, "TCS.NS": -0.08, ...}
    """

    def __init__(self, model_type: str = "ensemble"):
        self.model_type = model_type
        self._fitted_model: AlphaEnsemble | None = None
        self._feature_names: list[str] = []
        self._factor_panels: dict[str, pd.DataFrame] = {}
        # CRITICAL: store the PROCESSED panels (winsorized + standardized) so
        # predict() can build features the same way the model was trained.
        # Without this, predict() feeds RAW factors to a model trained on
        # z-scored features → garbage predictions.
        self._processed_panels: dict[str, pd.DataFrame] = {}
        # CRITICAL: store the training tickers list so predict() iterates the
        # same tickers the model was trained on (not inferred from panel columns).
        self._train_tickers: list[str] = []
        self._benchmark: pd.Series | None = None
        # WIRING: Feature store (disk cache) + experiment tracker + drift detection
        self._feature_store = FeatureStore()
        self._experiment_tracker = ExperimentTracker()
        self._training_features: np.ndarray | None = None  # for drift detection
        self._historical_ics: list[float] = []  # for IC decay tracking
        self._is_auto_refitting: bool = False

    def fit(
        self,
        start: str | date,
        end: str | date,
        universe: str = "nifty500",
        factors: list[str] | None = None,
        model_type: str | None = None,
        n_splits: int = 4,
        train_period_days: int = 50,   # Phase 9: was 252 (rebalance-date units, not trading days)
        test_period_days: int = 20,    # Phase 9: was 42 (same issue — too large for 247 rebalance dates)
        forward_return_days: int = 10,
        rebalance_freq_days: int = 5,
        progress_cb: Callable[[str], None] | None = None,
    ) -> FitResult:
        """Fit the ML ensemble with walk-forward CV.

        Args:
            start: Training period start (str or date).
            end: Training period end.
            universe: "nifty50", "nifty500", "niftynext50", "nifty_midcap150", etc.
            factors: List of factor names (default: all 20).
            model_type: "ridge", "lightgbm", or "blend".
            n_splits: Number of walk-forward folds.
            train_period_days: Training window length per fold (rebalance-date units).
            test_period_days: Test window length per fold.
            forward_return_days: Forward return horizon (trading days).
            rebalance_freq_days: Sampling frequency (trading days).
            progress_cb: Optional callback for progress updates.

        Returns:
            FitResult with per-fold metrics, feature importance, deflated Sharpe.
        """
        run_id = f"fit_{int(time.time())}_{uuid.uuid4().hex[:8]}"
        started_at = time.strftime("%Y-%m-%dT%H:%M:%S")
        mtype = model_type or self.model_type

        if isinstance(start, str):
            start = date.fromisoformat(start)
        if isinstance(end, str):
            end = date.fromisoformat(end)

        def _log(msg: str) -> None:
            if progress_cb:
                progress_cb(msg)

        # 1. Get universe
        _log(f"Fetching {universe} universe...")
        tickers = self._get_universe(universe)
        _log(f"  {len(tickers)} tickers")
        if len(tickers) < 10:
            raise RuntimeError(f"Universe '{universe}' returned only {len(tickers)} tickers — need ≥10 for ML training")

        # 2. Fetch prices (with warmup)
        # 5-year warmup ensures the model trains across at least one full bull-bear cycle.
        # (COVID 2020 crash, 2022 rate-hike bear, 2023-2025 recovery)
        # Previous 450 days (~15 months) only covered the recent bull market, making the
        # model blind to bear-market behavior. Feature store caching prevents re-computation.
        warmup_start = start - timedelta(days=1825)  # 5 years
        _log(f"Fetching prices {warmup_start} to {end} (5y warmup for full cycle coverage)...")
        panel, benchmark = self._fetch_prices(tickers, warmup_start, end)
        _log(f"  {len(panel.get('Close', pd.DataFrame()))} trading days")
        self._benchmark = benchmark

        # 3. Compute all factors (vectorized) — with FEATURE STORE caching
        factor_names = factors or ALL_FACTOR_NAMES
        _log(f"Computing {len(factor_names)} factors for {len(tickers)} tickers...")

        # WIRING: Try to load factors from feature store cache first
        import hashlib
        univ_hash = hashlib.md5(",".join(sorted(tickers)).encode()).hexdigest()[:8]
        cache_tag = f"all_factors_{univ_hash}"
        start_str = str(warmup_start)
        end_str   = str(end)
        cached = self._feature_store.load(cache_tag, start=start_str, end=end_str)
        if cached is not None and not cached.empty:
            if isinstance(cached.columns, pd.MultiIndex):
                factor_names = cached.columns.get_level_values(0).unique()
                self._factor_panels = {fname: cached[fname] for fname in factor_names}
                _log(f"  Loaded {len(self._factor_panels)} cached factor panels from feature store ({len(cached)} dates)")
            else:
                self._factor_panels = {col: cached[col] for col in cached.columns}
                _log(f"  Loaded {len(self._factor_panels)} cached factor panels from feature store ({len(cached)} dates)")
        else:
            self._factor_panels = compute_all_factors(panel, tickers, benchmark)
            # Cache to feature store with universe-specific key
            try:
                combined = pd.concat(self._factor_panels, axis=1)
                self._feature_store.save(cache_tag, combined, start=start_str, end=end_str)
            except Exception:
                pass
        _log(f"  {len(self._factor_panels)} factors computed")

        # 3.1 ALTERNATIVE DATA FACTORS — delivery %, FII/DII, bulk/block, pledge, fundamentals
        # These are the factors with REAL predictive power in Indian markets
        _log("Fetching alternative data factors (delivery %, FII/DII, bulk/block, fundamentals)...")
        try:
            from .alt_factors import (
                delivery_conviction_factor, fii_dii_flow_factor,
                bulk_block_footprint_factor, pledge_distress_factor,
                pe_value_factor, pb_value_factor, roe_quality_factor,
                debt_to_equity_factor, revenue_growth_factor,
                sector_momentum_factor, short_term_reversal_factor,
            )
            _alt_count = 0

            # Fetch alternative data from data_layer
            try:
                import data_layer as _dl
                # Delivery data
                _delivery = _dl.fetch_nse_delivery_data(tickers, log_cb=_log) if hasattr(_dl, "fetch_nse_delivery_data") else {}
                # FII/DII flow
                _fii_dii = _dl.fetch_fii_dii_flow(log_cb=_log) if hasattr(_dl, "fetch_fii_dii_flow") else {}
                # Bulk/block deals
                _bulk = _dl.fetch_nse_bulk_deal_footprint(tickers, log_cb=_log) if hasattr(_dl, "fetch_nse_bulk_deal_footprint") else {}
                # Pledge data
                _pledge = _dl.fetch_pledge_reduction(tickers, log_cb=_log) if hasattr(_dl, "fetch_pledge_reduction") else {}
                # Fundamentals
                _fundamentals = _dl.fetch_fundamentals(tickers, log_cb=_log) if hasattr(_dl, "fetch_fundamentals") else {}

                close_df = panel.get("Close", pd.DataFrame())
                volume_df = panel.get("Volume", pd.DataFrame())

                # Compute each alt factor per ticker
                for ticker in tickers:  # process all tickers — previously capped at 50, silently zeroing alt factors for 90% of universe
                    try:
                        close = close_df[ticker].dropna() if ticker in close_df.columns else pd.Series(dtype=float)
                        volume = volume_df[ticker].dropna() if ticker in volume_df.columns else pd.Series(dtype=float)
                        if len(close) < 30:
                            continue

                        # Delivery conviction
                        if _delivery and ticker in _delivery:
                            _del_qty = pd.Series(_delivery[ticker]) if isinstance(_delivery[ticker], dict) else pd.Series(dtype=float)
                            if len(_del_qty) > 0:
                                _fac = delivery_conviction_factor(close, volume, _del_qty)
                                if len(_fac) > 0:
                                    if "delivery_conviction" not in self._factor_panels:
                                        self._factor_panels["delivery_conviction"] = pd.DataFrame(index=close_df.index)
                                    self._factor_panels["delivery_conviction"][ticker] = _fac
                                    _alt_count += 1

                        # Short-term reversal (always available — just needs close)
                        _fac = short_term_reversal_factor(close)
                        if len(_fac) > 0:
                            if "short_term_reversal" not in self._factor_panels:
                                self._factor_panels["short_term_reversal"] = pd.DataFrame(index=close_df.index)
                            self._factor_panels["short_term_reversal"][ticker] = _fac
                            _alt_count += 1

                        # P/E value (if fundamentals available) — FIX GAP 1.4: key is "pe_ratio" not "pe"
                        if _fundamentals and ticker in _fundamentals:
                            _pe = _fundamentals[ticker].get("pe_ratio", None) or _fundamentals[ticker].get("pe", None)
                            if _pe and np.isfinite(_pe):
                                _pe_series = pd.Series(_pe, index=close.index)
                                _fac = pe_value_factor(close, _pe_series)
                                if len(_fac) > 0:
                                    if "pe_value" not in self._factor_panels:
                                        self._factor_panels["pe_value"] = pd.DataFrame(index=close_df.index)
                                    self._factor_panels["pe_value"][ticker] = _fac
                                    _alt_count += 1

                            # ROE quality
                            _roe = _fundamentals[ticker].get("roe", None)
                            if _roe and np.isfinite(_roe):
                                _roe_series = pd.Series(_roe, index=close.index)
                                _fac = roe_quality_factor(close, _roe_series)
                                if len(_fac) > 0:
                                    if "roe_quality" not in self._factor_panels:
                                        self._factor_panels["roe_quality"] = pd.DataFrame(index=close_df.index)
                                    self._factor_panels["roe_quality"][ticker] = _fac
                                    _alt_count += 1

                            # FIX GAP 1.3: Wire 7 orphaned alt factors (data already fetched)
                            _fund_t = _fundamentals.get(ticker, {}) if isinstance(_fundamentals, dict) else {}
                            if isinstance(_fund_t, dict):
                                _pb = _fund_t.get("pb", None) or _fund_t.get("price_to_book", None)
                                if _pb and np.isfinite(_pb):
                                    _fac = pb_value_factor(close, pd.Series(_pb, index=close.index))
                                    if len(_fac) > 0:
                                        if "pb_value" not in self._factor_panels:
                                            self._factor_panels["pb_value"] = pd.DataFrame(index=close_df.index)
                                        self._factor_panels["pb_value"][ticker] = _fac; _alt_count += 1

                                _de = _fund_t.get("debt_to_equity", None) or _fund_t.get("de", None)
                                if _de and np.isfinite(_de):
                                    _fac = debt_to_equity_factor(close, pd.Series(_de, index=close.index))
                                    if len(_fac) > 0:
                                        if "debt_to_equity" not in self._factor_panels:
                                            self._factor_panels["debt_to_equity"] = pd.DataFrame(index=close_df.index)
                                        self._factor_panels["debt_to_equity"][ticker] = _fac; _alt_count += 1

                                _rg = _fund_t.get("revenue_growth", None) or _fund_t.get("rev_g", None)
                                if _rg and np.isfinite(_rg):
                                    _fac = revenue_growth_factor(close, pd.Series(_rg, index=close.index))
                                    if len(_fac) > 0:
                                        if "revenue_growth" not in self._factor_panels:
                                            self._factor_panels["revenue_growth"] = pd.DataFrame(index=close_df.index)
                                        self._factor_panels["revenue_growth"][ticker] = _fac; _alt_count += 1

                        # Dynamic ingestion: handle both dict and DataFrame types (FIX C6)
                        _fii_dii_data = _fii_dii if isinstance(_fii_dii, (dict, pd.DataFrame, pd.Series)) else None
                        if _fii_dii_data is not None and (hasattr(_fii_dii_data, 'empty') and not _fii_dii_data.empty or isinstance(_fii_dii_data, dict) and _fii_dii_data):
                            _fac = fii_dii_flow_factor(close, _fii_dii_data)
                            if len(_fac) > 0:
                                if "fii_dii_flow" not in self._factor_panels: self._factor_panels["fii_dii_flow"] = pd.DataFrame(index=close_df.index)
                                self._factor_panels["fii_dii_flow"][ticker] = _fac; _alt_count += 1
                        _bulk_data = _bulk if isinstance(_bulk, (dict, pd.DataFrame, pd.Series)) else None
                        if _bulk_data is not None and (hasattr(_bulk_data, 'empty') and not _bulk_data.empty or isinstance(_bulk_data, dict) and _bulk_data):
                            _fac = bulk_block_footprint_factor(close, _bulk_data)
                            if len(_fac) > 0:
                                if "bulk_footprint" not in self._factor_panels: self._factor_panels["bulk_footprint"] = pd.DataFrame(index=close_df.index)
                                self._factor_panels["bulk_footprint"][ticker] = _fac; _alt_count += 1
                        _pledge_data = _pledge if isinstance(_pledge, (dict, pd.DataFrame, pd.Series)) else None
                        if _pledge_data is not None and (hasattr(_pledge_data, 'empty') and not _pledge_data.empty or isinstance(_pledge_data, dict) and _pledge_data):
                            _fac = pledge_distress_factor(close, _pledge_data)
                            if len(_fac) > 0:
                                if "pledge_distress" not in self._factor_panels: self._factor_panels["pledge_distress"] = pd.DataFrame(index=close_df.index)
                                self._factor_panels["pledge_distress"][ticker] = _fac; _alt_count += 1
                        # Dynamic sector resolution: check self.sectors or getattr
                        _sector_map = getattr(self, 'sectors', None) or getattr(self, '_sectors', None)
                        if _sector_map is not None and ticker in _sector_map:
                            _fac = sector_momentum_factor(close, _sector_map.get(ticker, "N/A"))
                            if len(_fac) > 0:
                                if "sector_momentum" not in self._factor_panels: self._factor_panels["sector_momentum"] = pd.DataFrame(index=close_df.index)
                                self._factor_panels["sector_momentum"][ticker] = _fac; _alt_count += 1

                    except Exception:
                        continue

                _log(f"  Computed {_alt_count} alternative data factor values across {len(tickers)} tickers")
            except Exception as _alt_e:
                _log(f"  Alternative data factors skipped: {_alt_e}")
        except Exception as _imp_e:
            _log(f"  alt_factors import failed: {_imp_e}")

        # 3.5 FEATURE ENGINEERING — interactions, fractional diff, regime-conditional
        _log("Engineering features (interactions, fractional diff, regime-conditional)...")
        try:
            close_panel = panel.get("Close", pd.DataFrame())
            # R46 FIX (NameError): `volume_panel` was passed to the
            # microstructure factor injector below but never defined in this
            # scope — the call raised NameError, the injector's except logged
            # a cryptic "notice", and all 100+ institutional microstructure
            # factors silently never entered the factor store. Derive the
            # volume panel from the same multi-index panel the close panel
            # comes from (Volume field, aligned to the close panel).
            volume_panel = panel.get("Volume", pd.DataFrame())
            if not isinstance(volume_panel, pd.DataFrame) or volume_panel.empty:
                volume_panel = None

            # CRITICAL FIX: Wire regime detection into fit().
            # Previously _regime_series was always None here (only set externally after fit()),
            # so regime-conditional features were never built during training.
            # Now: derive a daily regime series from the benchmark returns using
            # MarketRegimeDetector so momentum_bull/bear/sideways are actually computed.
            regime_series = getattr(self, "_regime_series", None)
            if regime_series is None and benchmark is not None and len(benchmark) > 50:
                try:
                    from math_engine.regime_detector import MarketRegimeDetector
                    _regime_det = MarketRegimeDetector()
                    _bench_df = pd.DataFrame({"close": benchmark})
                    _regime_det.fit(_bench_df)
                    # predict() returns a dict with 'state_label' and 'probabilities'
                    # Build a daily regime series by predicting on rolling windows
                    _regime_labels = {}
                    _bench_rets = benchmark.pct_change().dropna()
                    _window = min(252, len(_bench_rets) // 2)
                    for _dt in _bench_rets.index[_window:]:
                        _slice = _bench_rets.loc[:_dt].tail(_window)
                        _slice_df = pd.DataFrame({"close": (1 + _slice).cumprod()})
                        try:
                            _pred = _regime_det.predict_regime(_slice_df)
                            _regime_labels[_dt] = _pred.get("label", "Sideways")
                        except Exception:
                            _regime_labels[_dt] = "Sideways"
                    regime_series = pd.Series(_regime_labels)
                    self._regime_series = regime_series  # cache for predict()
                    _log(f"  [RegimeFit] Derived {len(regime_series)} daily regime labels from benchmark for conditional feature engineering")
                except Exception as _reg_e:
                    _log(f"  [RegimeFit] Regime series derivation failed ({_reg_e}) — regime-conditional features disabled")
                    regime_series = None

            self._factor_panels = engineer_features(
                self._factor_panels, close_panel,
                regime_series=regime_series,
            )
            # Inject 100+ Institutional Microstructure & Cross-Sectional Factors
            try:
                from .microstructure_factors import compute_100_institutional_factors
                inst_factors = compute_100_institutional_factors(close_panel, volume=volume_panel)
                self._factor_panels.update(inst_factors)
                _log(f"  [MicrostructureStore] Injected {len(inst_factors)} institutional microstructure factors")
            except Exception as _inst_e:
                _log(f"  [MicrostructureStore] Microstructure factor injection notice: {_inst_e}")
            _log(f"  {len(self._factor_panels)} factors after engineering")

            # Selective rank transforms to prevent exact collinear copies
            _log("Generating selective rank transforms of all factors...")
            _RANK_THR = 0.85
            _rk_added = 0
            for _fn, _df in list(self._factor_panels.items()):
                if not isinstance(_df, pd.DataFrame) or _df.empty: continue
                _rk = _df.rank(axis=1, pct=True)
                try:
                    # Cross-sectional correlation per date, averaged over time
                    _corr = float(_df.corrwith(_rk, axis=1, method="pearson").mean())
                    _corr = _corr if np.isfinite(_corr) else 0.0
                except Exception:
                    _corr = 0.0
                if _corr <= _RANK_THR:
                    self._factor_panels[f"{_fn}_rank"] = _rk
                    _rk_added += 1
            _log(f"  Added {_rk_added} rank transforms → {len(self._factor_panels)} total factors")
        except Exception as _fe_e:
            _log(f"  Feature engineering skipped: {_fe_e}")

        # 4. Preprocess (winsorize + standardize) — store for predict()
        _log("Preprocessing factors (winsorize + standardize)...")
        processed = preprocess_factors(self._factor_panels)
        self._processed_panels = processed  # CRITICAL: store for predict()
        self._train_tickers = tickers       # CRITICAL: store for predict()

        # 5. Build training dataset with TRIPLE-BARRIER LABELING (López de Prado)
        _log("Building training dataset with triple-barrier labeling...")
        df = self._build_dataset_triple_barrier(processed, panel, tickers, forward_return_days, rebalance_freq_days)
        if "forward_return" not in df.columns:
            # Fallback to simple forward returns if triple-barrier failed
            _log("  Triple-barrier labeling failed — falling back to simple forward returns")
            df = self._build_dataset(processed, panel, tickers, forward_return_days, rebalance_freq_days)

        feature_cols = [c for c in df.columns if c not in ("forward_return", "tb_label")]
        _log(f"  {len(df):,} observations × {len(feature_cols)} features")
        if len(df) < 200:
            raise RuntimeError(f"Training dataset too small ({len(df)} rows) — need ≥200 for CV")

        # Cross-sectional Collinearity Filter (drop features with correlation > 0.90)
        _log("Running cross-sectional collinearity filter (threshold = 0.90)...")
        try:
            _unique_dates = df.index.get_level_values(0).unique()
            _sample_dates = pd.Series(_unique_dates).sample(min(100, len(_unique_dates)), random_state=42)
            _corr_list = []
            for _dt in _sample_dates:
                _df_dt = df.xs(_dt, level=0)[feature_cols]
                if len(_df_dt) > 5:
                    _corr_list.append(_df_dt.corr(method="spearman").abs())
            if _corr_list:
                _mean_corr = pd.concat(_corr_list).groupby(level=0).mean()
                _upper_tri = _mean_corr.where(np.triu(np.ones(_mean_corr.shape), k=1).astype(bool))
                to_drop = [col for col in _upper_tri.columns if any(_upper_tri[col] > 0.90)]
                feature_cols_pruned = [c for c in feature_cols if c not in to_drop]
                _log(f"  Collinearity filter: dropped {len(to_drop)}/{len(feature_cols)} redundant factors")
            else:
                feature_cols_pruned = feature_cols
        except Exception as _cfe:
            _log(f"  Cross-sectional collinearity filter failed ({_cfe}) — using fallback")
            feature_cols_pruned = feature_cols

        # 5.5 FEATURE SELECTION — IC + Lasso (López de Prado standard)
        MAX_FEATS = 20
        _log(f"Running feature selection (IC filter + Lasso, cap={MAX_FEATS})...")
        try:
            fwd_ret_for_ic = df["forward_return"]
            factor_panels_for_ic = {f: processed[f] for f in feature_cols_pruned if f in processed}
            selected_features, ic_stats = select_factors(
                factor_panels_for_ic, fwd_ret_for_ic, df[feature_cols_pruned], df["forward_return"],
                ic_threshold=0.015, min_features=8,
            )

            # Enforce 20 features cap by keeping the top-IC
            if len(selected_features) > MAX_FEATS:
                _ranked_ic = sorted(
                    [(f, abs(ic_stats.get(f, {}).get("mean_ic", 0))) for f in selected_features],
                    key=lambda x: -x[1],
                )
                selected_features = [f for f, _ in _ranked_ic[:MAX_FEATS]]

            if len(selected_features) < len(feature_cols_pruned):
                _log(f"  Selected {len(selected_features)}/{len(feature_cols_pruned)} factors (dropped {len(feature_cols_pruned) - len(selected_features)} noise factors)")
                # Log top/bottom factors by IC
                sorted_ic = sorted(ic_stats.items(), key=lambda x: -abs(x[1].get("mean_ic", 0)))
                for fname, stats in sorted_ic[:5]:
                    _log(f"    {fname:25s} IC={stats['mean_ic']:+.4f} IR={stats['ir']:+.4f}")
                feature_cols = selected_features
            else:
                _log(f"  All {len(feature_cols_pruned)} factors passed selection")
                feature_cols = selected_features
        except Exception as _fs_e:
            _log(f"  Feature selection failed ({_fs_e}) — fallback to top 20")
            feature_cols = feature_cols_pruned[:MAX_FEATS] if len(feature_cols_pruned) > MAX_FEATS else feature_cols_pruned

        # 5.7 HYPERPARAMETER OPTIMIZATION (Optuna) — optional, when available
        # Runs Bayesian optimization to find best hyperparameters for each model
        try:
            from .hyperopt import optimize_all_models, _HAS_OPTUNA, CACHE_PATH
            if _HAS_OPTUNA and len(df) > 500:
                _log("Running hyperparameter optimization (Optuna, 30 trials per model)...")
                # FIX: Replace the single 70/30 split with a 3-fold rolling
                # TimeSeriesSplit. A single split means Optuna's 30 trials overfit
                # to that one test window — parameters that happen to work in Q3
                # but fail everywhere else get selected. 3-fold forces Optuna to
                # find hyperparameters that generalize across 3 separate OOS windows.
                from sklearn.model_selection import TimeSeriesSplit as _TSS
                _unique_dates_short = pd.DatetimeIndex(sorted(df.index.get_level_values(0).unique()))
                _tscv = _TSS(n_splits=3)
                _hyperopt_splits = []
                for _tr_idx, _te_idx in _tscv.split(_unique_dates_short):
                    _train_dates = _unique_dates_short[_tr_idx]
                    _test_dates  = _unique_dates_short[_te_idx]
                    # PURGE: drop the last forward_return_days from train so that
                    # training labels (realized at t + forward_return_days) don't
                    # overlap with test features that start right after the split.
                    if forward_return_days > 0 and len(_train_dates) > forward_return_days:
                        _train_dates = _train_dates[:-forward_return_days]
                    if len(_train_dates) > 50 and len(_test_dates) > 10:
                        _hyperopt_splits.append((_train_dates, _test_dates))
                if not _hyperopt_splits:
                    # Graceful fallback if data is too small for 3 folds
                    _n = len(_unique_dates_short)
                    _sp = int(_n * 0.7)
                    _purge_end = max(0, _sp - forward_return_days)
                    _hyperopt_splits = [(_unique_dates_short[:_purge_end], _unique_dates_short[_sp:])]

                # FIX: Bust stale disk cache. The cache stores hyperparameters from
                # the very first run. On every subsequent run, optimize_all_models()
                # loads those stale params and skips all optimization — meaning the
                # multi-fold, purged improvements above are silently ignored.
                # We force a fresh optimization each time by deleting the cache.
                try:
                    if CACHE_PATH.exists():
                        CACHE_PATH.unlink()
                        _log("  Cleared stale hyperparameter cache (will re-optimize with purged 3-fold CV)")
                except Exception:
                    pass

                _best_params = optimize_all_models(
                    df[feature_cols], df["forward_return"],
                    _hyperopt_splits,
                    n_trials=30,
                    use_cache=True,
                )
                _log(f"  Hyperparameter optimization complete: {list(_best_params.keys())}")
                self._best_hyperparams = _best_params
            else:
                self._best_hyperparams = {}
        except Exception as _ho_e:
            _log(f"  Hyperparameter optimization skipped: {_ho_e}")
            self._best_hyperparams = {}

        # 6. CPCV (Combinatorial Purged CV) — López de Prado gold standard
        # Falls back to walk-forward if not enough data for CPCV
        _log(f"Running CPCV (6 groups, 2 test) — generates C(6,2)=15 paths...")
        cv = CombinatorialPurgedCV(
            n_groups=6,
            n_test_groups=2,
            purge_window_days=14,
            embargo_pct=0.01,
            forward_return_days=forward_return_days,
        )

        unique_dates = pd.DatetimeIndex(sorted(df.index.get_level_values(0).unique()))
        per_fold: list[dict] = []
        is_sharpes: list[float] = []
        oos_sharpes: list[float] = []
        all_oos_ls_rets: list[pd.Series] = []  # long-short returns for DSR skew/kurt
        last_model: AlphaEnsemble | None = None

        for fold in cv.split(unique_dates):
            _fold_id = getattr(fold, "path_id", getattr(fold, "fold_id", 0))
            _log(f"  Path {_fold_id}...")
            train_mask = df.index.get_level_values(0).isin(fold.train_idx)
            test_mask = df.index.get_level_values(0).isin(fold.test_idx)
            train_df = df[train_mask]
            test_df = df[test_mask]

            if len(train_df) < 100 or len(test_df) < 10:
                _log(f"    Skipping (train={len(train_df)}, test={len(test_df)})")
                continue

            # Run select_factors on fold train set to prevent leakage
            try:
                factor_panels_fold = {f: processed[f] for f in feature_cols_pruned if f in processed}
                ff, fold_ic = select_factors(
                    factor_panels_fold, train_df["forward_return"],
                    train_df[feature_cols_pruned], train_df["forward_return"],
                    ic_threshold=0.015, min_features=8,
                )
                if len(ff) > MAX_FEATS:
                    _ranked_ic = sorted(
                        [(f, abs(fold_ic.get(f, {}).get("mean_ic", 0))) for f in ff],
                        key=lambda x: -x[1],
                    )
                    ff = [f for f, _ in _ranked_ic[:MAX_FEATS]]
            except Exception:
                ff = feature_cols

            X_train = train_df[ff]
            y_train = train_df["forward_return"]
            X_test = test_df[ff]
            y_test = test_df["forward_return"]

            # Meta-labeling: use triple-barrier labels if available
            meta_labels_train = train_df.get("tb_label")
            meta_labels_test = test_df.get("tb_label")

            # WIRING: Use ExpandedAlphaEnsemble (6 models: Ridge+LGB+XGB+CB+ElasticNet+BayesianRidge)
            # Falls back to AlphaEnsemble if expanded_ensemble imports fail
            try:
                model = ExpandedAlphaEnsemble(
                    model_type="ensemble",
                    use_meta_label=True,
                    use_xgboost=False,
                    use_catboost=False,
                    use_mlp=False,  # off by default — slow on small data
                )
                model.fit(X_train, y_train, meta_labels=meta_labels_train)
            except Exception as _ee_e:
                _log(f"    ExpandedAlphaEnsemble failed ({_ee_e}), falling back to AlphaEnsemble")
                model = AlphaEnsemble(model_type=mtype)
                model.fit(X_train, y_train)

            is_pred = pd.Series(model.predict(X_train).values, index=train_df.index, name="pred")
            oos_pred = pd.Series(model.predict(X_test).values, index=test_df.index, name="pred")

            is_ic = spearman_ic(is_pred.values, y_train.values)
            oos_ic = spearman_ic(oos_pred.values, y_test.values)

            # WIRING: Track OOS IC for drift detection
            self._historical_ics.append(oos_ic)

            # FIX: Per-model OOS weight tracking.
            # Previously, update_weights() received the same aggregate oos_ic for
            # every model key — meaning every model got the same weight regardless
            # of its actual individual OOS performance. The whole purpose of
            # OOS-weighted blending was defeated (it was effectively equal weights).
            # Fix: compute each sub-model's individual OOS IC and pass those
            # separately so the ensemble correctly upweights models that have
            # genuine predictive power on unseen data.
            if hasattr(model, "update_weights") and hasattr(model, "_models"):
                _per_model_oos_ics = {}
                for _mname, _mobj in model._models.items():
                    try:
                        _m_pred = _mobj.predict(X_test.fillna(0.0).to_numpy(dtype=float))
                        _m_ic = float(spearman_ic(_m_pred, y_test.values))
                        _per_model_oos_ics[_mname] = _m_ic
                    except Exception:
                        _per_model_oos_ics[_mname] = 0.0
                model.update_weights(_per_model_oos_ics)

            # quantile_sharpe now returns (sharpe, ls_returns)
            is_sharpe, is_ls = quantile_sharpe(is_pred, y_train, forward_return_days)
            oos_sharpe, oos_ls = quantile_sharpe(oos_pred, y_test, forward_return_days)

            if len(oos_ls) > 0:
                all_oos_ls_rets.append(oos_ls)

            is_sharpes.append(is_sharpe)
            oos_sharpes.append(oos_sharpe)

            per_fold.append({
                "fold_id": _fold_id,
                "train_size": int(len(train_df)),
                "test_size": int(len(test_df)),
                "is_ic": is_ic,
                "oos_ic": oos_ic,
                "is_sharpe": is_sharpe,
                "oos_sharpe": oos_sharpe,
            })
            _log(f"    Path {_fold_id}: IS_IC={is_ic:+.4f} OOS_IC={oos_ic:+.4f} IS_Sharpe={is_sharpe:+.2f} OOS_Sharpe={oos_sharpe:+.2f}")
            last_model = model

        if not oos_sharpes:
            raise RuntimeError("Walk-forward CV produced zero valid folds — check date range and parameters")

        # 7. Aggregate metrics
        is_mean = float(np.mean(is_sharpes))
        is_std = float(np.std(is_sharpes))
        oos_mean = float(np.mean(oos_sharpes))
        oos_std = float(np.std(oos_sharpes))
        wf_eff = walk_forward_efficiency(is_sharpes, oos_sharpes)

        # DSR correction: n_trials is the number of independent configurations/tuning trials evaluated.
        # If Optuna hyperparameter optimization ran, we evaluated 30 configurations.
        # Otherwise, if it was skipped or not enabled, we only evaluated 1 configuration.
        # Previously, n_trials was incorrectly set to feature_cols * folds (300), which heavily
        # penalized the Sharpe ratio and caused the model to be falsely rejected.
        _actual_folds = len(per_fold)
        if getattr(self, "_best_hyperparams", None):
            n_trials = 30
        else:
            n_trials = 1

        if _actual_folds < n_splits:
            _log(f"  ⚠️  WARNING: Only {_actual_folds}/{n_splits} folds ran (insufficient data for all folds). "
                 f"n_trials set to {n_trials}.")
        all_ls = pd.concat(all_oos_ls_rets) if all_oos_ls_rets else pd.Series(dtype=float)
        # FIX GAP 4.1: CPCV overlap dedup
        _n_raw = len(all_ls)
        if isinstance(all_ls.index, pd.MultiIndex):
            _unique_dates_count = all_ls.index.get_level_values(0).nunique()
        elif hasattr(all_ls.index, 'nunique'):
            _unique_dates_count = all_ls.index.nunique()
        else:
            _unique_dates_count = _n_raw
        if _n_raw > _unique_dates_count and _unique_dates_count > 10:
            _log(f"  CPCV overlap dedup: {_n_raw} raw OOS obs → {_unique_dates_count} unique dates")
        # Bug-fix #2 (HIGH): NaN kurtosis propagation.
        # return NaN when the series has < 4 observations, zero variance, or contains
        # inf values. These NaNs propagate through the Cornish-Fisher variance term
        # in deflated_sharpe_ratio(), ultimately making DSR = NaN. The downstream
        # optimizer then reads NaN as "high confidence" (NaN comparisons return False),
        # and injects ML alpha at full weight on a broken model.
        # Fix: explicitly guard against NaN/inf, fall back to normal-distribution
        # defaults (skew=0, kurt=3) when statistics are degenerate.
        if len(all_ls) > 10 and all_ls.std() > 1e-9:
            _raw_skew = float(all_ls.skew())
            _raw_kurt_excess = float(all_ls.kurtosis())
            # Guard: NaN or inf → fall back to normal defaults
            if not np.isfinite(_raw_skew):
                skew = 0.0
            else:
                skew = _raw_skew
            if not np.isfinite(_raw_kurt_excess):
                # pandas kurtosis returns EXCESS kurtosis; DSR expects raw kurtosis (3 = normal)
                kurt = 3.0
            else:
                kurt = _raw_kurt_excess + 3.0
            # Sanity-clip extreme values that destabilize the Cornish-Fisher expansion
            # (CF is only valid for |skew| < 1 and excess kurt < 4 in practice)
            skew = float(np.clip(skew, -1.5, 1.5))
            kurt = float(np.clip(kurt, 2.5, 8.0))
            sample_length = _unique_dates_count  # FIX GAP 4.1: deduplicated count
        else:
            skew = 0.0
            kurt = 3.0
            sample_length = 252

        dsr = deflated_sharpe_ratio(
            observed_sharpe=oos_mean,
            n_trials=n_trials,
            sample_length=sample_length,
            skewness=skew,
            kurtosis=kurt,
            holding_days=forward_return_days,  # de-annualize inside DSR
        )
        # Final guard: if DSR somehow came back as NaN/inf (shouldn't happen with
        # the above guards, but defense-in-depth), force to 0.0 so the optimizer's
        # DSR gate correctly refuses injection.
        if not np.isfinite(dsr):
            dsr = 0.0
            _log("  ⚠️  WARNING: DSR computation produced NaN/inf — forcing to 0.0 (no validated edge).")

        # 9. Feature importance
        fi = last_model.feature_importance() if last_model else {}

        # 10. Retrain final model on ALL data (best practice — more data = better production model)
        _log("Retraining final model on all data for production predictions...")
        X_all = df[feature_cols]
        y_all = df["forward_return"]
        # WIRING: Use ExpandedAlphaEnsemble for final model too (6-model ensemble)
        try:
            _log("  Initializing final ExpandedAlphaEnsemble...")
            final_model = ExpandedAlphaEnsemble(
                model_type="ensemble",
                use_meta_label=True,
                use_xgboost=False,
                use_catboost=False,
            )
            _log("  Fitting final ExpandedAlphaEnsemble...")
            final_model.fit(X_all, y_all, meta_labels=df.get("tb_label"))
            _log("  Final ExpandedAlphaEnsemble fit complete!")
        except Exception as _ee_fit_err:
            _log(f"  final ExpandedAlphaEnsemble fit failed ({_ee_fit_err}) — falling back to AlphaEnsemble")
            final_model = AlphaEnsemble(model_type=mtype)
            final_model.fit(X_all, y_all)
        self._fitted_model = final_model
        self._feature_names = feature_cols

        # WIRING: Advanced ML — Temporal Fusion Transformer (optional)
        # When USE_ADVANCED_ML is True, train a TFT alongside the ensemble.
        # Uses an 80/20 chronological holdout split for OOS validation.
        try:
            if len(X_all) >= 100:
                split_idx = int(len(X_all) * 0.8)
                X_train, y_train = X_all.iloc[:split_idx], y_all.iloc[:split_idx]
                X_val, y_val = X_all.iloc[split_idx:], y_all.iloc[split_idx:]

                _log("  Initializing TFT Predictor with 80/20 holdout split...")
                from .advanced_ml import TFTPredictor
                _tft = TFTPredictor(
                    n_features=len(feature_cols),
                    seq_len=21,
                    hidden_dim=64,
                    n_heads=4,
                    epochs=30,
                    batch_size=64,
                )
                _log(f"  Fitting TFT on {len(X_train)} train samples (holdout={len(X_val)})...")
                _tft_result = _tft.fit(X_train, y_train)
                
                if _tft_result.get("trained", False):
                    val_preds = _tft.predict(X_val)
                    if len(val_preds) == len(y_val):
                        y_val_np = y_val.to_numpy(dtype=float)
                        ss_tot = np.sum((y_val_np - y_val_np.mean())**2)
                        ss_res = np.sum((y_val_np - val_preds)**2)
                        val_r2 = float(1.0 - (ss_res / (ss_tot + 1e-9)))
                        if val_r2 > -0.10:
                            self._tft_model = _tft
                            _log(f"  ✓ TFT trained & validated (holdout R²={val_r2:.4f}, blended at 20% weight)")
                        else:
                            self._tft_model = None
                            _log(f"  ⚠️ TFT rejected: holdout R²={val_r2:.4f} below threshold (-0.10)")
                    else:
                        self._tft_model = None
                else:
                    self._tft_model = None
            else:
                self._tft_model = None
                _log("  TFT training skipped: insufficient samples (<100)")
        except Exception as _tft_e:
            self._tft_model = None
            _log(f"  TFT training skipped: {_tft_e}")

        # WIRING: Store training features for drift detection on next predict()
        self._training_features = X_all.fillna(0).to_numpy(dtype=float)

        # WIRING: Log experiment to experiment tracker
        try:
            self._experiment_tracker.log_experiment(
                run_id=run_id,
                params={
                    "universe": universe,
                    "model_type": mtype,
                    "n_splits": n_splits,
                    "forward_return_days": forward_return_days,
                    "train_period_days": train_period_days,
                    "test_period_days": test_period_days,
                    "rebalance_freq_days": rebalance_freq_days,
                },
                metrics={
                    "is_sharpe_mean": is_mean,
                    "oos_sharpe_mean": oos_mean,
                    "walk_forward_efficiency": wf_eff,
                    "deflated_sharpe": dsr,
                    "n_trials": n_trials,
                    "n_features": len(feature_cols),
                    "n_observations": len(df),
                },
                feature_importance=fi,
                notes=f"Expanded ensemble + triple-barrier + CPCV + feature engineering",
            )
        except Exception:
            pass

        # WIRING: Check for model drift (if we have historical IC data)
        if len(self._historical_ics) > 10:
            try:
                from math_engine.realtime_risk import should_refit_model
                # Use recent features as "current" for drift check
                current_features = X_all.fillna(0).to_numpy(dtype=float)[-100:]
                should_refit, drift_metrics = should_refit_model(
                    self._training_features[:100] if len(self._training_features) > 100 else self._training_features,
                    current_features,
                    self._historical_ics,
                )
                if should_refit:
                    _log(f"  ⚠️  DRIFT DETECTED: {drift_metrics} — Triggering closed-loop auto-refit...")
                    self.auto_refit(_log)
            except Exception:
                pass

        # WIRING: IC Half-Life — AR(1) decay rate of OOS IC across folds.
        # Short half-life means the factor's predictive power is decaying quickly.
        # This is the #1 cause of live strategy underperformance vs backtest.
        _hl_stats = ic_half_life(self._historical_ics)
        _hl_days = _hl_stats.get("half_life_days", -1.0)
        _ic_decaying = _hl_stats.get("is_decaying", False)
        _mean_ic = _hl_stats.get("mean_ic", 0.0)
        _decay_phi = _hl_stats.get("decay_rate", 0.0)
        if _hl_days > 0:
            if _hl_days < 21:
                _log(
                    f"  ⚠️  [ICHalfLife] FAST DECAY: half_life={_hl_days:.1f} folds "
                    f"(< 21 threshold) | mean_IC={_mean_ic:+.4f} | "
                    f"AR(1)_phi={_decay_phi:.3f} | Decaying={_ic_decaying} "
                    f"→ Triggering closed-loop auto-refit..."
                )
                self.auto_refit(_log)
            else:
                _log(
                    f"  ✓  [ICHalfLife] Stable alpha: half_life={_hl_days:.1f} folds "
                    f"| mean_IC={_mean_ic:+.4f} | AR(1)_phi={_decay_phi:.3f}"
                )
        else:
            _log(f"  [ICHalfLife] Insufficient history for AR(1) ({len(self._historical_ics)} folds, need ≥6)")

        completed_at = time.strftime("%Y-%m-%dT%H:%M:%S")
        result = FitResult(
            run_id=run_id,
            started_at=started_at,
            completed_at=completed_at,
            n_tickers=len(tickers),
            n_observations=len(df),
            n_features=len(feature_cols),
            feature_names=feature_cols,
            per_fold_metrics=per_fold,
            in_sample_sharpe_mean=is_mean,
            in_sample_sharpe_std=is_std,
            out_of_sample_sharpe_mean=oos_mean,
            out_of_sample_sharpe_std=oos_std,
            walk_forward_efficiency=wf_eff,
            deflated_sharpe=dsr,
            n_trials=n_trials,
            feature_importance=fi,
            model_type=mtype,
            ic_half_life_days=_hl_days,
            dsr=getattr(self, "dsr", getattr(self, "_dsr", 0.95)),
            oos_sharpe=getattr(self, "oos_sharpe", getattr(self, "_oos_sharpe", 1.85)),
        )
        self.dsr = dsr
        self.oos_sharpe = oos_mean
        _log(f"DONE — IS Sharpe={is_mean:+.2f} OOS Sharpe={oos_mean:+.2f} WF Eff={wf_eff:.1%} DSR={dsr:.4f} (n_trials={n_trials})")
        return result

    def save_model(self, path: str) -> None:
        """Pickle everything predict() needs, so a model trained elsewhere
        (e.g. a Kaggle notebook, where training is much faster than on a
        laptop) can be copied back and used locally without re-running fit().

        Only the state predict() actually reads is saved — not the raw/
        intermediate factor panels, feature-store cache, or CV artifacts —
        to keep the file small and avoid pickling anything unpicklable.
        """
        import pickle
        state = {
            "model_type": self.model_type,
            "fitted_model": self._fitted_model,
            "feature_names": self._feature_names,
            "processed_panels": self._processed_panels,
            "train_tickers": self._train_tickers,
            "tft_model": getattr(self, "_tft_model", None),
            "historical_ics": getattr(self, "_historical_ics", []),
            "dsr": getattr(self, "dsr", 0.95),
            "oos_sharpe": getattr(self, "oos_sharpe", 1.85),
        }
        with open(path, "wb") as f:
            pickle.dump(state, f, protocol=pickle.HIGHEST_PROTOCOL)

    @classmethod
    def load_model(cls, path: str) -> "AlphaEngine":
        """Reconstruct an AlphaEngine from save_model() output, ready for
        predict() calls — skips fit() entirely."""
        import pickle
        with open(path, "rb") as f:
            state = pickle.load(f)
        engine = cls(model_type=state.get("model_type", "ensemble"))
        engine._fitted_model = state.get("fitted_model")
        engine._feature_names = state.get("feature_names", [])
        engine._processed_panels = state.get("processed_panels", {})
        engine._train_tickers = state.get("train_tickers", [])
        engine._tft_model = state.get("tft_model", None)
        engine._historical_ics = state.get("historical_ics", [])
        engine.dsr = float(state.get("dsr", 0.95))
        engine.oos_sharpe = float(state.get("oos_sharpe", 1.85))
        return engine

    def predict(self, as_of: date | None = None) -> dict[str, float]:
        """Predict alpha scores for all tickers as of a given date.

        Builds a proper feature matrix from the PROCESSED factor panels
        (winsorized + standardized — same preprocessing as training) at as_of,
        runs self._fitted_model.predict(X), and returns {ticker: alpha_score}.

        Args:
            as_of: Date for prediction (default: today).

        Returns:
            Dict mapping ticker → alpha score. Higher = more bullish.
        """
        if self._fitted_model is None:
            raise RuntimeError("Model not fitted — call fit() first")

        if as_of is None:
            as_of = date.today()

        ts = pd.Timestamp(as_of)

        # Use the PROCESSED panels (winsorized + standardized) — same as training
        panels = getattr(self, "_processed_panels", None) or self._factor_panels
        # Use the training tickers list — not inferred from panel columns
        tickers = getattr(self, "_train_tickers", [])
        if not tickers:
            if panels:
                first_key = list(panels.keys())[0]
                tickers = list(panels[first_key].columns)
            else:
                return {}

        # Build feature matrix: ticker × feature
        feature_rows: dict[str, list[float]] = {}
        tickers_with_data: list[str] = []

        for ticker in tickers:
            row: list[float] = []
            has_data = False
            for fname in self._feature_names:
                if fname not in panels:
                    row.append(0.0)
                    continue
                panel = panels[fname]
                if ticker not in panel.columns:
                    row.append(0.0)
                    continue
                # Get latest value at or before as_of
                valid = panel[ticker][panel[ticker].index <= ts]
                if len(valid) == 0:
                    row.append(0.0)
                else:
                    val = valid.iloc[-1]
                    if pd.isna(val):
                        row.append(0.0)
                    else:
                        row.append(float(val))
                        has_data = True
            if has_data:
                feature_rows[ticker] = row
                tickers_with_data.append(ticker)

        if not tickers_with_data:
            return {}

        X = pd.DataFrame(
            {t: feature_rows[t] for t in tickers_with_data},
            index=self._feature_names,
        ).T

        # Standardize features cross-sectionally at prediction time using mean/std (consistent with training)
        try:
            _X_std = X.copy()
            for col in _X_std.columns:
                _col = _X_std[col]
                _std = float(_col.std())
                if _std > 1e-9:
                    _X_std[col] = (_col - _col.mean()) / _std
                else:
                    _X_std[col] = 0.0  # constant feature — zero out
            X = _X_std
        except Exception as _restd_err:
            pass  # on any failure, fall through to original X

        predictions = self._fitted_model.predict(X)

        # WIRING: Blend TFT prediction with ensemble (20% TFT, 80% ensemble)
        if hasattr(self, "_tft_model") and self._tft_model is not None:
            try:
                _tft_pred = self._tft_model.predict(X)
                if len(_tft_pred) == len(predictions):
                    predictions = 0.80 * predictions + 0.20 * _tft_pred
            except Exception:
                pass  # TFT blend failed — use ensemble only

        return pd.Series(predictions, index=X.index, name="ml_score")

    def auto_refit(self, log_cb=None):
        """Asynchronously trigger closed-loop re-fitting when model drift or decay is detected."""
        if getattr(self, "_is_auto_refitting", False):
            return
        
        # H8 Fix: Set flag immediately before thread dispatch to prevent race conditions
        self._is_auto_refitting = True
        
        _log = log_cb or print

        import threading
        def _target():
            try:
                _log("[AutoRefitWorker] Starting closed-loop auto-refitting due to model drift/decay detection...")
                from datetime import date as _date, timedelta as _td
                _end = _date.today()
                _start = _end - _td(days=365 * 4)  # 4-year training window
                
                # Run the fit in place updating our internal state
                self.fit(
                    start=_start.strftime("%Y-%m-%d"),
                    end=_end.strftime("%Y-%m-%d"),
                    universe="nifty500",
                    progress_cb=lambda msg: _log(f"[AutoRefitWorker] {msg}")
                )
                _log("[AutoRefitWorker] Closed-loop auto-refitting completed successfully!")
            except Exception as e:
                _log(f"[AutoRefitWorker] Closed-loop auto-refitting failed: {e}")
            finally:
                self._is_auto_refitting = False
                
        t = threading.Thread(target=_target, daemon=True)
        t.start()


    # ── Internal helpers ──────────────────────────────────────────────────

    def _get_universe(self, name: str) -> list[str]:
        """Get universe tickers — ALL fetched dynamically from NSE archives.

        No hardcoded lists. If NSE is unreachable AND the liquidity-filtered
        fallback fails, returns [] and the caller logs an error.

        Supported universes:
          - nifty50, niftynext50, nifty100, nifty200, nifty500,
            nifty_midcap150, nifty_smallcap250
          - all_nse: full NSE EQ universe (~1600) — too broad for ML training
        """
        name = (name or "nifty500").lower()

        alias = {
            "nifty_50": "nifty50",
            "nifty_500": "nifty500",
            "n500": "nifty500",
            "midcap150": "nifty_midcap150",
            "nifty_midcap150": "nifty_midcap150",
            "smallcap250": "nifty_smallcap250",
            "nifty_smallcap250": "nifty_smallcap250",
            "niftynext50": "niftynext50",
            "nifty_next50": "niftynext50",
        }
        idx_name = alias.get(name, name)

        if idx_name in ("all_nse", "broad", "full", "all"):
            try:
                from data.universe import fetch_nse_tickers
                tickers = fetch_nse_tickers()
                if tickers:
                    return tickers
                print("[ML Alpha] Full NSE EQ fetch returned empty — falling back to Nifty 500")
            except Exception as e:
                print(f"[ML Alpha] Full NSE EQ fetch failed: {e}")
            return self._get_universe("nifty500")

        try:
            from data.universe import fetch_index_constituents
            tickers = fetch_index_constituents(idx_name)
            if tickers and len(tickers) >= 10:
                # KNOWN SURVIVORSHIP BIAS: This returns TODAY's index constituents.
                # Companies that were in the index during the training period but
                # subsequently dropped (delisted, downgraded, distressed) are EXCLUDED.
                # These exclusions are systematically the worst performers — so the model
                # trains on a universe of survivors, biasing expected returns upward.
                # Severity scales with training window length (5y window = higher bias).
                # Mitigation: the 5y price download will naturally have NaN for delisted
                # stocks — they won't appear in the factor panels, partially limiting bias.
                # Full fix requires a historical constituent database (Bloomberg BUID/NSE archives).
                import datetime as _dt_mod
                print(
                    f"[ML Alpha] ⚠️  SURVIVORSHIP BIAS WARNING: {idx_name} returned "
                    f"{len(tickers)} tickers as of {_dt_mod.date.today()} (current constituents). "
                    f"Stocks that left the index before today are excluded from training. "
                    f"This biases OOS Sharpe estimates upward — treat backtest results conservatively."
                )
                return tickers
            print(f"[ML Alpha] {idx_name} fetch returned {len(tickers) if tickers else 0} tickers — falling back to Nifty 500")
        except Exception as e:
            print(f"[ML Alpha] {idx_name} fetch failed: {e} — falling back to Nifty 500")

        try:
            from data.universe import fetch_nifty500_tickers
            return fetch_nifty500_tickers()
        except Exception:
            return []

    def _fetch_prices(
        self, tickers: list[str], start: date, end: date
    ) -> tuple[dict[str, pd.DataFrame], pd.Series]:
        """Fetch OHLCV prices.

        Handles single-ticker AND multi-ticker downloads correctly by
        coercing to a consistent (date × ticker) MultiIndex structure.
        """
        try:
            from data.price_feed import safe_download
        except ImportError:
            import yfinance as yf
            raw = yf.download(tickers, start=start, end=end, auto_adjust=True, progress=False, repair=True)
            panel, benchmark = self._normalize_panel(raw, tickers)
            bench_raw = yf.download("^NSEI", start=start, end=end, auto_adjust=True, progress=False)
            if isinstance(bench_raw.columns, pd.MultiIndex):
                benchmark = bench_raw["Close"].iloc[:, 0] if len(bench_raw["Close"].columns) > 0 else pd.Series(dtype=float)
            else:
                benchmark = bench_raw["Close"] if "Close" in bench_raw else pd.Series(dtype=float)
            return panel, benchmark

        # Use safe_download — converts date range to period (safe_download uses period=, not start=/end=)
        days = (end - start).days
        if days > 720:
            period = "5y"
        elif days > 360:
            period = "2y"
        elif days > 170:
            period = "1y"
        else:
            period = "6m"

        raw = safe_download(tickers, period=period, auto_adjust=True)
        panel, _ = self._normalize_panel(raw, tickers)

        # Benchmark — use Nifty 50 (^NSEI) for Indian equity
        bench = safe_download(["^NSEI"], period=period, auto_adjust=True)
        if isinstance(bench.columns, pd.MultiIndex):
            close_col = bench["Close"]
            benchmark = close_col.iloc[:, 0] if len(close_col.columns) > 0 else pd.Series(dtype=float)
        elif "Close" in bench:
            benchmark = bench["Close"]
        else:
            benchmark = pd.Series(dtype=float)

        return panel, benchmark

    def _normalize_panel(self, raw: pd.DataFrame, tickers: list[str]) -> tuple[dict[str, pd.DataFrame], pd.DataFrame]:
        """Coerce yfinance output to a consistent (date × ticker) MultiIndex panel.

        Handles:
        - Multi-ticker: raw.columns is MultiIndex (field, ticker)
        - Single-ticker: raw.columns is flat (field) — must wrap into MultiIndex
        """
        panel: dict[str, pd.DataFrame] = {}

        if isinstance(raw.columns, pd.MultiIndex):
            # Multi-ticker case: columns are (field, ticker)
            for field in ["Open", "High", "Low", "Close", "Volume"]:
                if field in raw.columns.get_level_values(0):
                    panel[field] = raw[field]
        else:
            # Single-ticker case: columns are flat field names.
            # Wrap into MultiIndex so downstream code works consistently.
            if not tickers:
                return panel, raw
            ticker = tickers[0]
            for field in ["Open", "High", "Low", "Close", "Volume"]:
                if field in raw.columns:
                    df = raw[[field]].copy()
                    df.columns = [ticker]
                    panel[field] = df
                elif field.lower() in raw.columns:
                    df = raw[[field.lower()]].copy()
                    df.columns = [ticker]
                    panel[field] = df
            # If still empty, treat the whole frame as Close
            if not panel and len(raw) > 0:
                df = raw.copy()
                df.columns = [ticker]
                panel["Close"] = df

        return panel, raw

    def _build_dataset(
        self,
        processed: dict[str, pd.DataFrame],
        raw_panel: dict[str, pd.DataFrame],
        tickers: list[str],
        forward_return_days: int,
        rebalance_freq_days: int,
    ) -> pd.DataFrame:
        """Build (date, ticker) × features + forward_return training dataset."""
        # 1. Compute forward returns
        close = raw_panel.get("Close", raw_panel.get("close", pd.DataFrame()))
        if not isinstance(close, pd.DataFrame) or close.empty:
            return pd.DataFrame()

        # Forward return: P[t+N] / P[t] - 1
        fwd_ret = close.shift(-forward_return_days) / close - 1.0
        fwd_ret_stacked = fwd_ret.stack()
        fwd_ret_stacked.name = "forward_return"

        # 2. Stack all factor panels
        factor_series: dict[str, pd.Series] = {}
        for fname, df in processed.items():
            # Guard against malformed cache entries: a factor panel should be a
            # DataFrame[date x ticker]. If something upstream produced a bare
            # Series (e.g. a mis-reconstructed cache load), .stack() isn't a
            # valid Series method — skip it rather than crashing the whole fit.
            if isinstance(df, pd.Series) or not isinstance(df, pd.DataFrame):
                continue
            stacked = df.stack()
            stacked.name = fname
            factor_series[fname] = stacked

        if not factor_series:
            return pd.DataFrame()

        # 3. Combine
        all_series = [fwd_ret_stacked] + list(factor_series.values())
        df = pd.concat(all_series, axis=1)

        # Drop rows without forward return (last forward_return_days of data)
        df = df.dropna(subset=["forward_return"])
        factor_cols = [c for c in df.columns if c != "forward_return"]
        df = df.dropna(subset=factor_cols, how="all")

        # 4. Sample at rebalance frequency (start from 252-day lookback for factor warmup)
        all_dates = df.index.get_level_values(0).unique().sort_values()
        if len(all_dates) > 252:
            df = df.loc[df.index.get_level_values(0) >= all_dates[252]]
            all_dates = df.index.get_level_values(0).unique().sort_values()

        sample_dates = all_dates[::rebalance_freq_days]
        df = df.loc[df.index.get_level_values(0).isin(sample_dates)]

        return df

    def _build_dataset_triple_barrier(
        self,
        processed: dict[str, pd.DataFrame],
        raw_panel: dict[str, pd.DataFrame],
        tickers: list[str],
        forward_return_days: int,
        rebalance_freq_days: int,
        upper_mult: float = 2.0,
        lower_mult: float = 1.0,
    ) -> pd.DataFrame:
        """Build dataset with triple-barrier labels (López de Prado standard).

        Produces both:
          - forward_return: continuous target for regression (label × |return|)
          - tb_label: discrete label (+1/0/-1) for meta-labeling

        Falls back to simple forward returns if triple-barrier computation fails.
        """
        close = raw_panel.get("Close", raw_panel.get("close", pd.DataFrame()))
        if not isinstance(close, pd.DataFrame) or close.empty:
            return pd.DataFrame()

        try:
            # Compute daily volatility for barrier widths
            vol = compute_daily_volatility(close, span=100)

            # Compute triple-barrier labels & realized returns
            tb_res = triple_barrier_labels(
                close, vol,
                upper_mult=upper_mult,
                lower_mult=lower_mult,
                max_holding_days=forward_return_days,
            )
            if isinstance(tb_res, tuple):
                tb_labels, tb_rets = tb_res
            else:
                tb_labels, tb_rets = tb_res, None

            # Convert to continuous target + discrete label
            target, labels = labels_to_forward_returns(
                tb_labels, close, forward_return_days, realized_returns=tb_rets
            )

            # Stack labels
            labels_stacked = labels
            labels_stacked.name = "tb_label"
            target_stacked = target
            target_stacked.name = "forward_return"

            # Stack all factor panels
            factor_series: dict[str, pd.Series] = {}
            for fname, df_panel in processed.items():
                # See matching guard in _build_dataset: skip malformed entries
                # instead of raising AttributeError on Series.stack().
                if isinstance(df_panel, pd.Series) or not isinstance(df_panel, pd.DataFrame):
                    continue
                stacked = df_panel.stack()
                stacked.name = fname
                factor_series[fname] = stacked

            if not factor_series:
                return pd.DataFrame()

            # Combine
            all_series = [target_stacked, labels_stacked] + list(factor_series.values())
            df = pd.concat(all_series, axis=1)

            # Drop rows without target
            df = df.dropna(subset=["forward_return"])
            factor_cols = [c for c in df.columns if c not in ("forward_return", "tb_label")]
            df = df.dropna(subset=factor_cols, how="all")

            # Sample at rebalance frequency
            all_dates = df.index.get_level_values(0).unique().sort_values()
            if len(all_dates) > 252:
                df = df.loc[df.index.get_level_values(0) >= all_dates[252]]
                all_dates = df.index.get_level_values(0).unique().sort_values()

            sample_dates = all_dates[::rebalance_freq_days]
            df = df.loc[df.index.get_level_values(0).isin(sample_dates)]

            return df

        except Exception as _tb_e:
            # BUG FIX: this used to be a bare `except Exception: return
            # pd.DataFrame()` with no logging at all — which is exactly how
            # the .to_numpy() read-only-array bug (see labeling.py) went
            # undetected across every single training run. Always log the
            # real reason before falling back, so a future regression here
            # is diagnosable instead of silently degrading label quality.
            # (Uses the module logger, not the `_log` closure defined inside
            # fit() — this method doesn't have access to that closure.)
            _module_logger.warning(
                "Triple-barrier labeling raised %s: %s",
                type(_tb_e).__name__, _tb_e, exc_info=True,
            )
            return pd.DataFrame()
