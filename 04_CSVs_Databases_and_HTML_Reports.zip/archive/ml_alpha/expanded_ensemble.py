"""Expanded model ensemble — XGBoost, CatBoost, ElasticNet, Bayesian Ridge, MLP.

Institutional-grade ensemble with 6 models:
  1. Ridge (linear baseline)
  2. LightGBM (gradient boosting)
  3. XGBoost (gradient boosting, often beats LightGBM on tabular)
  4. CatBoost (handles categorical features natively)
  5. ElasticNet (L1+L2 regularization)
  6. Bayesian Ridge (uncertainty estimates)

The ensemble prediction is a weighted average where weights are determined
by OOS performance (better models get higher weight).

Each model also has a meta-labeling classifier for confidence calibration.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Any, Optional
import logging

logger = logging.getLogger(__name__)

# Optional imports — each model degrades gracefully if unavailable
try:
    from sklearn.linear_model import Ridge, LogisticRegression, ElasticNet, BayesianRidge
    from sklearn.preprocessing import StandardScaler
    from sklearn.neural_network import MLPRegressor
    _HAS_SKLEARN = True
except ImportError:
    _HAS_SKLEARN = False

try:
    import lightgbm as lgb
    _HAS_LGB = True
except ImportError:
    _HAS_LGB = False

import platform as _platform
if _platform.system() == "Darwin" and _platform.machine() == "arm64":
    _HAS_XGB = False  # XGBoost segfaults on macOS ARM
else:
    try:
        import xgboost as xgb
        _HAS_XGB = True
    except ImportError:
        _HAS_XGB = False

try:
    import catboost as cb
    _HAS_CB = True
except ImportError:
    _HAS_CB = False


class ExpandedAlphaEnsemble:
    """6-model ensemble with meta-labeling and OOS-weighted blending.

    Models:
      - Ridge (always available)
      - LightGBM (if installed)
      - XGBoost (if installed)
      - CatBoost (if installed)
      - ElasticNet (sklearn)
      - Bayesian Ridge (sklearn)
      - MLP neural net (sklearn)

    The ensemble:
      1. Trains all available models on the training set
      2. Evaluates each model's OOS performance during CV
      3. Blends predictions weighted by OOS R² (better models → higher weight)
      4. Applies meta-labeling confidence adjustment
    """

    def __init__(
        self,
        model_type: str = "ensemble",
        use_meta_label: bool = True,
        use_xgboost: bool = False,   # OFF by default — segfaults on macOS ARM
        use_catboost: bool = False,  # OFF by default — heavy dependency
        use_mlp: bool = False,       # OFF by default — slow on small data
    ):
        self.model_type = model_type
        self.use_meta_label = use_meta_label and _HAS_SKLEARN
        self.use_xgboost = use_xgboost and _HAS_XGB
        self.use_catboost = use_catboost and _HAS_CB
        self.use_mlp = use_mlp and _HAS_SKLEARN

        self._models: dict[str, Any] = {}
        self._model_weights: dict[str, float] = {}
        self._meta: Any = None
        self._scaler: Any = None
        self._feature_names: list[str] = []
        self._is_fit = False

    def fit(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        meta_labels: pd.Series = None,
    ) -> dict[str, Any]:
        """Fit all available models on the training data."""
        X_clean = X.fillna(0.0)
        y_arr = y.to_numpy(dtype=float)
        mask = ~np.isnan(y_arr)
        X_clean = X_clean.loc[mask]
        y_arr = y_arr[mask]

        self._feature_names = list(X_clean.columns)
        X_arr = X_clean.to_numpy(dtype=float)
        n_samples = len(y_arr)

        models_fitted = []

        # ── 1. Ridge (always) ──
        if _HAS_SKLEARN:
            try:
                self._models["ridge"] = Ridge(alpha=1.0)
                self._models["ridge"].fit(X_arr, y_arr)
                models_fitted.append("ridge")
            except Exception as e:
                logger.warning(f"Ridge fit failed: {e}")

        # ── 2. LightGBM ──
        if _HAS_LGB and self.model_type in ("lightgbm", "blend", "ensemble"):
            try:
                self._models["lightgbm"] = lgb.LGBMRegressor(
                    n_estimators=100, learning_rate=0.02, num_leaves=15,
                    max_depth=5, min_child_samples=50,
                    subsample=0.7, colsample_bytree=0.7,
                    reg_alpha=1.0, reg_lambda=5.0,
                    random_state=42, verbosity=-1,
                    n_jobs=1,  # CRASH FIX: LightGBM's bundled OpenMP runtime
                    # collides with faiss/torch's own libomp.dylib copies on
                    # macOS (EXC_BAD_ACCESS in __kmp_suspend_initialize_thread).
                    # Force single-threaded to avoid it spinning up its own
                    # OpenMP thread pool. See launch_desktop.py for the
                    # matching KMP_DUPLICATE_LIB_OK env var.
                )
                self._models["lightgbm"].fit(X_arr, y_arr)
                models_fitted.append("lightgbm")
            except Exception as e:
                logger.warning(f"LightGBM fit failed: {e}")

        # ── 3. XGBoost ──
        if self.use_xgboost:
            try:
                self._models["xgboost"] = xgb.XGBRegressor(
                    n_estimators=100, learning_rate=0.02, max_depth=5,
                    min_child_weight=50, subsample=0.7, colsample_bytree=0.7,
                    reg_alpha=1.0, reg_lambda=5.0,
                    random_state=42, verbosity=0,
                )
                self._models["xgboost"].fit(X_arr, y_arr)
                models_fitted.append("xgboost")
            except Exception as e:
                logger.warning(f"XGBoost fit failed: {e}")

        # ── 4. CatBoost ──
        if self.use_catboost:
            try:
                self._models["catboost"] = cb.CatBoostRegressor(
                    iterations=100, learning_rate=0.02, depth=5,
                    l2_leaf_reg=5.0, random_seed=42, verbose=0,
                )
                self._models["catboost"].fit(X_arr, y_arr)
                models_fitted.append("catboost")
            except Exception as e:
                logger.warning(f"CatBoost fit failed: {e}")

        # ── 5. ElasticNet ──
        if _HAS_SKLEARN:
            try:
                self._models["elasticnet"] = ElasticNet(
                    alpha=0.1, l1_ratio=0.5, max_iter=5000, random_state=42,
                )
                self._models["elasticnet"].fit(X_arr, y_arr)
                models_fitted.append("elasticnet")
            except Exception as e:
                logger.warning(f"ElasticNet fit failed: {e}")

        # ── 6. Bayesian Ridge ──
        if _HAS_SKLEARN:
            try:
                self._models["bayesian_ridge"] = BayesianRidge()
                self._models["bayesian_ridge"].fit(X_arr, y_arr)
                models_fitted.append("bayesian_ridge")
            except Exception as e:
                logger.warning(f"Bayesian Ridge fit failed: {e}")

        # ── 7. MLP Neural Net (optional) ──
        if self.use_mlp and n_samples > 1000:
            try:
                self._models["mlp"] = MLPRegressor(
                    hidden_layer_sizes=(64, 32),
                    activation="relu",
                    solver="adam",
                    alpha=0.01,
                    max_iter=500,
                    random_state=42,
                    early_stopping=True,
                )
                self._models["mlp"].fit(X_arr, y_arr)
                models_fitted.append("mlp")
            except Exception as e:
                logger.warning(f"MLP fit failed: {e}")

        # ── Initialize equal weights (will be updated by StackingSuperLearner) ──
        self._model_weights = {name: 1.0 / len(models_fitted) for name in models_fitted}

        # ── Fit StackingSuperLearner Meta-Regressor ──
        try:
            from .stacking_learner import StackingSuperLearner
            self._stacking = StackingSuperLearner(alpha=1.0)
            oof_df = pd.DataFrame(index=X_clean.index)
            for name, model in self._models.items():
                try:
                    oof_df[name] = model.predict(X_arr)
                except Exception:
                    pass
            if not oof_df.empty:
                y_clean = y.reindex(X_clean.index).fillna(0.0)
                learned_weights = self._stacking.fit(oof_df, y_clean)
                self._model_weights.update(learned_weights)
        except Exception as _stk_err:
            logger.warning(f"StackingSuperLearner fit notice: {_stk_err}")

        # ── Meta-labeling classifier ──
        if self.use_meta_label and meta_labels is not None:
            meta_aligned = meta_labels.reindex(X_clean.index).fillna(0.0)
            meta_binary = (meta_aligned.abs() > 0).astype(int)

            if meta_binary.sum() > 10 and (1 - meta_binary).sum() > 10:
                self._scaler = StandardScaler()
                X_scaled = self._scaler.fit_transform(X_arr)
                self._meta = LogisticRegression(
                    C=0.1, max_iter=1000, random_state=42,
                    class_weight="balanced",
                )
                self._meta.fit(X_scaled, meta_binary.to_numpy())

        self._is_fit = True
        return {
            "model_type": self.model_type,
            "models_fitted": models_fitted,
            "model_weights": self._model_weights,
            "n_features": len(self._feature_names),
            "n_samples": n_samples,
            "meta_labeling": self._meta is not None,
        }

    def predict(self, X: pd.DataFrame) -> pd.Series:
        """Predict alpha scores using OOS-weighted ensemble + meta-labeling."""
        if not self._is_fit:
            raise RuntimeError("Model not fitted")
        X_aligned = X.reindex(columns=self._feature_names, fill_value=0.0).fillna(0.0)
        X_arr = X_aligned.to_numpy(dtype=float)

        # Get predictions from each model
        predictions = {}
        for name, model in self._models.items():
            try:
                predictions[name] = model.predict(X_arr)
            except Exception:
                continue

        if not predictions:
            return pd.Series(np.zeros(len(X)), index=X.index, name="alpha")

        # Weighted blend
        total_weight = sum(self._model_weights.get(name, 0) for name in predictions)
        blended = np.zeros(len(X))
        if total_weight < 1e-9:
            # FIX C10: Equal weights fallback — was returning zeros because
            # self._model_weights[name] was still 0 even after total_weight=len(predictions)
            _n = len(predictions)
            for name, pred in predictions.items():
                blended += (1.0 / _n) * pred
        else:
            for name, pred in predictions.items():
                w = self._model_weights.get(name, 0) / total_weight
                blended += w * pred

        # Meta-labeling confidence adjustment
        if self._meta is not None and self._scaler is not None:
            X_scaled = self._scaler.transform(X_arr)
            meta_proba = self._meta.predict_proba(X_scaled)[:, 1]
            confidence = np.clip(meta_proba * 2.0, 0.0, 2.0)
            blended = blended * confidence

        return pd.Series(blended, index=X.index, name="alpha")

    def update_weights(self, oos_scores: dict[str, float]):
        """Update model weights based on OOS performance.

        Args:
            oos_scores: Dict[model_name → OOS R² or IC score].
                        Higher = better. Negative scores set weight to 0.
        """
        # Only update weights for models that have OOS scores
        positive_scores = {
            name: max(0.0, score) for name, score in oos_scores.items()
            if name in self._models
        }
        total = sum(positive_scores.values())
        if total < 1e-9:
            # All models performed poorly — equal weights
            n = len(self._models)
            self._model_weights = {name: 1.0 / n for name in self._models}
        else:
            self._model_weights = {
                name: score / total
                for name, score in positive_scores.items()
            }
            # Models without OOS scores get 0 weight
            for name in self._models:
                if name not in self._model_weights:
                    self._model_weights[name] = 0.0

    def feature_importance(self) -> dict[str, float]:
        """Aggregate feature importance across all models."""
        if not self._is_fit:
            return {}

        importances = {}
        total_weight = sum(self._model_weights.values()) or 1.0

        for name, model in self._models.items():
            weight = self._model_weights.get(name, 0) / total_weight
            if weight < 1e-6:
                continue

            # Get this model's feature importance
            if name in ("ridge", "elasticnet", "bayesian_ridge"):
                imp = np.abs(model.coef_)
            elif name in ("lightgbm", "xgboost", "catboost"):
                imp = model.feature_importances_
            elif name == "mlp":
                continue  # MLP doesn't have straightforward importance
            else:
                continue

            # Normalize
            imp_total = imp.sum() or 1.0
            imp_norm = imp / imp_total

            for i, fname in enumerate(self._feature_names):
                importances[fname] = importances.get(fname, 0) + weight * imp_norm[i]

        # Normalize final importances
        total = sum(importances.values()) or 1.0
        return {name: float(v / total) for name, v in importances.items()}
