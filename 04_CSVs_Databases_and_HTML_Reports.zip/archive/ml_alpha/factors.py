"""Vectorized factor computation — 15+ factors across momentum, volatility, technical, and advanced.

All factors use vectorized pandas operations for 50x speedup over per-date loops.
PIT-correct by construction: rolling windows only look backward.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Any


# ═══════════════════════════════════════════════════════════════════════════════
# FACTOR COMPUTATION (vectorized — all dates at once)
# ═══════════════════════════════════════════════════════════════════════════════

def _safe_close(panel: dict[str, pd.DataFrame] | pd.DataFrame, ticker: str) -> pd.Series:
    """Extract close prices for a ticker from a panel dict or DataFrame.
    FIX: Don't dropna() — let shift() propagate NaN naturally for illiquid tickers.
    dropna() before shift() causes position-based shift to misalign dates.
    """
    if isinstance(panel, dict):
        close = panel.get("Close", panel.get("close", pd.DataFrame()))
    else:
        close = panel
    if isinstance(close, pd.DataFrame):
        if ticker in close.columns:
            return close[ticker]
        for col in close.columns:
            if str(col).replace(".NS", "") == ticker.replace(".NS", ""):
                return close[col]
    return pd.Series(dtype=float)


def _safe_volume(panel: dict[str, pd.DataFrame] | pd.DataFrame, ticker: str) -> pd.Series:
    """Extract volume for a ticker."""
    if isinstance(panel, dict):
        vol = panel.get("Volume", panel.get("volume", pd.DataFrame()))
    else:
        vol = pd.DataFrame()
    if isinstance(vol, pd.DataFrame) and ticker in vol.columns:
        return vol[ticker].dropna()
    return pd.Series(dtype=float)


def _safe_high_low(panel: dict[str, pd.DataFrame] | pd.DataFrame, ticker: str) -> tuple[pd.Series, pd.Series]:
    """Extract high and low for a ticker."""
    if isinstance(panel, dict):
        high_df = panel.get("High", panel.get("high", pd.DataFrame()))
        low_df = panel.get("Low", panel.get("low", pd.DataFrame()))
    else:
        high_df = low_df = pd.DataFrame()
    h = high_df[ticker].dropna() if isinstance(high_df, pd.DataFrame) and ticker in high_df.columns else pd.Series(dtype=float)
    l = low_df[ticker].dropna() if isinstance(low_df, pd.DataFrame) and ticker in low_df.columns else pd.Series(dtype=float)
    return h, l


def _safe_open(panel: dict[str, pd.DataFrame] | pd.DataFrame, ticker: str) -> pd.Series:
    """Extract open prices for a ticker."""
    if isinstance(panel, dict):
        open_df = panel.get("Open", panel.get("open", pd.DataFrame()))
    else:
        open_df = pd.DataFrame()
    if isinstance(open_df, pd.DataFrame) and ticker in open_df.columns:
        return open_df[ticker].dropna()
    return pd.Series(dtype=float)


# ── Momentum factors ──────────────────────────────────────────────────────────

def momentum_12_1(close: pd.Series) -> pd.Series:
    """12-1 momentum: (P[t-21] / P[t-252]) - 1"""
    if len(close) < 253:
        return pd.Series(dtype=float)
    return (close.shift(21) / close.shift(252) - 1.0).dropna()

def momentum_6_1(close: pd.Series) -> pd.Series:
    if len(close) < 127:
        return pd.Series(dtype=float)
    return (close.shift(21) / close.shift(126) - 1.0).dropna()

def momentum_3_1(close: pd.Series) -> pd.Series:
    if len(close) < 64:
        return pd.Series(dtype=float)
    return (close.shift(21) / close.shift(63) - 1.0).dropna()

def breakout_252(close: pd.Series) -> pd.Series:
    """P[t] / max(P[t-252:t]) — 1.0 = at the high, >1.0 = new high"""
    if len(close) < 253:
        return pd.Series(dtype=float)
    rolling_hi = close.shift(1).rolling(252).max()
    return (close / rolling_hi).dropna()


# ── Volatility factors ────────────────────────────────────────────────────────

def lowvol_3m(close: pd.Series) -> pd.Series:
    """3-month realized vol: std(log_returns[-63:]) * sqrt(252)"""
    rets = np.log(close / close.shift(1))
    if len(rets) < 63:
        return pd.Series(dtype=float)
    return (rets.rolling(63).std() * np.sqrt(252)).dropna()

def lowvol_6m(close: pd.Series) -> pd.Series:
    rets = np.log(close / close.shift(1))
    if len(rets) < 126:
        return pd.Series(dtype=float)
    return (rets.rolling(126).std() * np.sqrt(252)).dropna()

def lowvol_12m(close: pd.Series) -> pd.Series:
    rets = np.log(close / close.shift(1))
    if len(rets) < 252:
        return pd.Series(dtype=float)
    return (rets.rolling(252).std() * np.sqrt(252)).dropna()


# ── Beta factor ───────────────────────────────────────────────────────────────

def beta_1y(close: pd.Series, benchmark: pd.Series) -> pd.Series:
    """Rolling 252-day beta vs benchmark."""
    stock_ret = close.pct_change()
    bench_ret = benchmark.pct_change()
    common = stock_ret.index.intersection(bench_ret.index)
    stock_ret = stock_ret.loc[common]
    bench_ret = bench_ret.loc[common]
    if len(stock_ret) < 252:
        return pd.Series(dtype=float)
    rolling_cov = stock_ret.rolling(252).cov(bench_ret)
    rolling_var = bench_ret.rolling(252).var()
    return (rolling_cov / rolling_var.replace(0, np.nan)).dropna()


# ── Liquidity factor ──────────────────────────────────────────────────────────

def adv_21d(close: pd.Series, volume: pd.Series) -> pd.Series:
    """21-day average daily volume × close (rupee ADV)."""
    if len(volume) < 21:
        return pd.Series(dtype=float)
    common = close.index.intersection(volume.index)
    c, v = close.loc[common], volume.loc[common]
    return (v.rolling(21).mean() * c).dropna()


# ── Technical factors ─────────────────────────────────────────────────────────

def rsi_14(close: pd.Series) -> pd.Series:
    """14-period RSI. Range [0, 100]."""
    if len(close) < 15:
        return pd.Series(dtype=float)
    delta = close.diff()
    gain = delta.clip(lower=0).ewm(alpha=1/14, min_periods=14, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1/14, min_periods=14, adjust=False).mean()
    rs = gain / (loss + 1e-9)
    return (100 - (100 / (1 + rs))).dropna()

def macd_hist(close: pd.Series) -> pd.Series:
    """MACD histogram / close × 100."""
    if len(close) < 35:
        return pd.Series(dtype=float)
    ema12 = close.ewm(span=12, adjust=False).mean()
    ema26 = close.ewm(span=26, adjust=False).mean()
    macd = ema12 - ema26
    signal = macd.ewm(span=9, adjust=False).mean()
    return ((macd - signal) / close * 100).dropna()

def bb_position(close: pd.Series) -> pd.Series:
    """Bollinger Band position [-1, +1]."""
    if len(close) < 20:
        return pd.Series(dtype=float)
    ma = close.rolling(20).mean()
    std = close.rolling(20).std()
    pos = (close - ma) / (2 * std)  # normalize to [-1, +1]
    return pos.clip(-1.0, 1.0).dropna()

def vol_momentum_21(volume: pd.Series) -> pd.Series:
    """21-day volume momentum: recent 5d avg / 21d avg - 1."""
    if len(volume) < 21:
        return pd.Series(dtype=float)
    return (volume.rolling(5).mean() / volume.rolling(21).mean() - 1.0).dropna()

def atr_14_pct(close: pd.Series, high: pd.Series, low: pd.Series) -> pd.Series:
    """ATR as % of price."""
    if len(close) < 15:
        return pd.Series(dtype=float)
    common = close.index.intersection(high.index).intersection(low.index)
    c, h, l = close.loc[common], high.loc[common], low.loc[common]
    tr = pd.DataFrame({"hl": h - l, "hc": (h - c.shift(1)).abs(), "lc": (l - c.shift(1)).abs()}).max(axis=1)
    atr = tr.ewm(alpha=1/14, min_periods=14, adjust=False).mean()
    return (atr / c * 100).dropna()

def vwap_distance_21(close: pd.Series, high: pd.Series, low: pd.Series, volume: pd.Series) -> pd.Series:
    """Distance from 21-day VWAP (%)."""
    if len(close) < 21:
        return pd.Series(dtype=float)
    common = close.index.intersection(high.index).intersection(low.index).intersection(volume.index)
    c, h, l, v = close.loc[common], high.loc[common], low.loc[common], volume.loc[common]
    typical = (h + l + c) / 3
    vwap = (typical * v).rolling(21).sum() / v.rolling(21).sum()
    return ((c - vwap) / vwap * 100).dropna()


# ── Advanced factors ──────────────────────────────────────────────────────────

def ret_skew_63(close: pd.Series) -> pd.Series:
    """63-day return skewness."""
    rets = np.log(close / close.shift(1))
    if len(rets) < 63:
        return pd.Series(dtype=float)
    return rets.rolling(63).skew().dropna()

def ma_distance_50(close: pd.Series) -> pd.Series:
    """Distance from 50-day MA (%)."""
    if len(close) < 50:
        return pd.Series(dtype=float)
    ma = close.rolling(50).mean()
    return ((close - ma) / ma * 100).dropna()

def ma_distance_200(close: pd.Series) -> pd.Series:
    """Distance from 200-day MA (%)."""
    if len(close) < 200:
        return pd.Series(dtype=float)
    ma = close.rolling(200).mean()
    return ((close - ma) / ma * 100).dropna()

def vw_momentum_63(close: pd.Series, volume: pd.Series) -> pd.Series:
    """63-day volume-weighted momentum."""
    if len(close) < 63:
        return pd.Series(dtype=float)
    common = close.index.intersection(volume.index)
    c, v = close.loc[common], volume.loc[common]
    rolling_pv = (c * v).rolling(63).sum()
    rolling_v = v.rolling(63).sum()
    vwap = rolling_pv / rolling_v
    return (c / vwap - 1.0).dropna()

def max_drawdown_63(close: pd.Series) -> pd.Series:
    """63-day max drawdown from peak. Range [0, 1]."""
    if len(close) < 63:
        return pd.Series(dtype=float)
    rolling_peak = close.rolling(63).max()
    return (1.0 - close / rolling_peak).dropna()


# ── Phase 9: New factors with real predictive power ────────────────────────

def overnight_gap_20(close: pd.Series, open_col: pd.Series = None) -> pd.Series:
    """20-day average overnight gap (close-to-open return)."""
    if open_col is None or len(close) < 21:
        return pd.Series(dtype=float)
    common = close.index.intersection(open_col.index)
    if len(common) < 21:
        return pd.Series(dtype=float)
    c = close.loc[common]
    o = open_col.loc[common]
    gap = (o / c.shift(1) - 1.0).replace([np.inf, -np.inf], np.nan)
    return gap.rolling(20).mean().dropna()


def intraday_reversal_10(close: pd.Series, open_col: pd.Series = None) -> pd.Series:
    """10-day average intraday reversal (open-to-close / prev close)."""
    if open_col is None or len(close) < 11:
        return pd.Series(dtype=float)
    common = close.index.intersection(open_col.index)
    if len(common) < 11:
        return pd.Series(dtype=float)
    c = close.loc[common]
    o = open_col.loc[common]
    intraday = (c / o - 1.0).replace([np.inf, -np.inf], np.nan)
    return intraday.rolling(10).mean().dropna()


def volume_trend_20(volume: pd.Series) -> pd.Series:
    """20-day volume trend: 20d avg / 60d avg - 1.0.

    Bug-fix #1 (CRITICAL): Previously this was identical to relative_volume_5
    (both computed rolling_5 / rolling_60). Now volume_trend_20 uses a 20-day
    window to capture medium-term volume trend, while relative_volume_5 uses
    the current day vs 60d average to capture unusual volume spikes.
    """
    if len(volume) < 60:
        return pd.Series(dtype=float)
    safe_60 = volume.rolling(60).mean().replace(0, np.nan)
    safe_20 = volume.rolling(20).mean()
    result = safe_20 / safe_60 - 1.0
    return result.replace([np.inf, -np.inf], np.nan).dropna()


def price_acceleration(close: pd.Series) -> pd.Series:
    """Price acceleration: 2nd derivative of 20-day momentum."""
    if len(close) < 41:
        return pd.Series(dtype=float)
    mom_20 = close / close.shift(20) - 1.0
    mom_20_prev = mom_20.shift(20)
    accel = (mom_20 - mom_20_prev).replace([np.inf, -np.inf], np.nan)
    return accel.dropna()


def range_expansion_20(close: pd.Series, high: pd.Series = None, low: pd.Series = None) -> pd.Series:
    """20-day ATR expansion: current ATR / 60d average ATR."""
    if high is None or low is None or len(close) < 60:
        return pd.Series(dtype=float)
    common = close.index.intersection(high.index).intersection(low.index)
    if len(common) < 60:
        return pd.Series(dtype=float)
    c, h, l = close.loc[common], high.loc[common], low.loc[common]
    tr = pd.DataFrame({"hl": h - l, "hc": (h - c.shift(1)).abs(), "lc": (l - c.shift(1)).abs()}).max(axis=1)
    atr_20 = tr.rolling(20).mean()
    atr_60 = tr.rolling(60).mean().replace(0, np.nan)
    result = atr_20 / atr_60
    return result.replace([np.inf, -np.inf], np.nan).dropna()


def relative_volume_5(volume: pd.Series) -> pd.Series:
    """Relative volume: current day's volume / 60d average volume.

    Bug-fix #1 (CRITICAL): Now distinct from volume_trend_20. This captures
    unusual single-day volume spikes (e.g., news-driven events), while
    volume_trend_20 captures medium-term volume drift.
    """
    if len(volume) < 60:
        return pd.Series(dtype=float)
    safe_60 = volume.rolling(60).mean().replace(0, np.nan)
    result = volume / safe_60
    return result.replace([np.inf, -np.inf], np.nan).dropna()


# ═══════════════════════════════════════════════════════════════════════════════
# BULK COMPUTATION
# ═══════════════════════════════════════════════════════════════════════════════

ALL_FACTOR_NAMES = [
    "momentum_12_1", "momentum_6_1", "momentum_3_1",
    "lowvol_3m", "lowvol_6m", "lowvol_12m",
    "beta_1y", "breakout_252", "adv_21d",
    "rsi_14", "macd_hist", "bb_position",
    "vol_momentum_21", "atr_14_pct", "vwap_distance_21",
    "ret_skew_63", "ma_distance_50", "ma_distance_200",
    "vw_momentum_63", "max_drawdown_63",
    # Phase 9: New factors with real predictive power
    "overnight_gap_20",      # Overnight gap (close-to-open return, 20d avg)
    "intraday_reversal_10",  # Open-to-close vs prev close (mean reversion)
    "volume_trend_20",       # Volume trend (recent vs long-term)
    "price_acceleration",    # 2nd derivative of price (momentum of momentum)
    "range_expansion_20",    # ATR expansion (volatility regime change)
    "relative_volume_5",     # Volume vs 60d average (unusual activity)
]

def compute_all_factors(
    panel: dict[str, pd.DataFrame] | pd.DataFrame,
    tickers: list[str],
    benchmark: pd.Series | None = None,
) -> dict[str, pd.DataFrame]:
    """Compute ALL factors for ALL tickers × ALL dates (vectorized).

    Args:
        panel: Price panel dict with 'Close', 'High', 'Low', 'Volume' keys,
               or a single close DataFrame.
        tickers: List of ticker symbols.
        benchmark: Benchmark close series (for beta_1y).

    Returns:
        Dict mapping factor_name -> DataFrame[date × ticker].
        Each DataFrame is indexed by the UNION of all tickers' dates (with NaN
        for missing ticker-date combinations) so that no data is silently lost
        when the first ticker has a short history.

    Bug-fix #8 (MEDIUM): Phase 9 introduced new factors but regressed the master
    date index fix — the first ticker's date range became the DataFrame index,
    silently dropping subsequent tickers' earlier data. Restored the master_idx
    union from QuantumAnnealer_FULL.
    """
    # Pre-build a master date index as the UNION of all tickers' close dates.
    master_idx: pd.DatetimeIndex = pd.DatetimeIndex([])
    close_panel = panel.get("Close", panel) if isinstance(panel, dict) else panel
    if isinstance(close_panel, pd.DataFrame):
        for t in tickers:
            if t in close_panel.columns:
                master_idx = master_idx.union(close_panel[t].dropna().index)
    master_idx = master_idx.sort_values()

    results: dict[str, pd.DataFrame] = {}

    for ticker in tickers:
        close = _safe_close(panel, ticker)
        volume = _safe_volume(panel, ticker)
        high, low = _safe_high_low(panel, ticker)

        if len(close) < 20:
            continue

        # Compute all factors for this ticker
        ticker_factors: dict[str, pd.Series] = {
            "momentum_12_1": momentum_12_1(close),
            "momentum_6_1": momentum_6_1(close),
            "momentum_3_1": momentum_3_1(close),
            "lowvol_3m": lowvol_3m(close),
            "lowvol_6m": lowvol_6m(close),
            "lowvol_12m": lowvol_12m(close),
            "breakout_252": breakout_252(close),
            "rsi_14": rsi_14(close),
            "macd_hist": macd_hist(close),
            "bb_position": bb_position(close),
            "ret_skew_63": ret_skew_63(close),
            "ma_distance_50": ma_distance_50(close),
            "ma_distance_200": ma_distance_200(close),
            "max_drawdown_63": max_drawdown_63(close),
        }

        if len(volume) > 0:
            ticker_factors["adv_21d"] = adv_21d(close, volume)
            ticker_factors["vol_momentum_21"] = vol_momentum_21(volume)
            ticker_factors["vw_momentum_63"] = vw_momentum_63(close, volume)
            # Phase 9: New volume-based factors
            ticker_factors["volume_trend_20"] = volume_trend_20(volume)
            ticker_factors["relative_volume_5"] = relative_volume_5(volume)

        if len(high) > 0 and len(low) > 0:
            ticker_factors["atr_14_pct"] = atr_14_pct(close, high, low)
            ticker_factors["range_expansion_20"] = range_expansion_20(close, high, low)
            if len(volume) > 0:
                ticker_factors["vwap_distance_21"] = vwap_distance_21(close, high, low, volume)

        if benchmark is not None:
            ticker_factors["beta_1y"] = beta_1y(close, benchmark)

        # Phase 9: New price-based factors
        open_series = _safe_open(panel, ticker)
        if len(open_series) > 0:
            ticker_factors["overnight_gap_20"] = overnight_gap_20(close, open_series)
            ticker_factors["intraday_reversal_10"] = intraday_reversal_10(close, open_series)
        ticker_factors["price_acceleration"] = price_acceleration(close)

        # Reindex each ticker's factor Series to the master date index, then
        # assign to the results DataFrame. NaN fills naturally for dates where
        # this ticker had no data.
        for fname, ts in ticker_factors.items():
            if len(ts) == 0:
                continue
            ts_reindexed = ts.reindex(master_idx)
            if fname not in results:
                results[fname] = pd.DataFrame(index=master_idx)
            results[fname][ticker] = ts_reindexed

    return results


def preprocess_factors(factor_panels: dict[str, pd.DataFrame]) -> dict[str, pd.DataFrame]:
    """Cross-sectional winsorize + standardize each factor at each date.

    Each row (a cross-section at one date) is:
      1. Winsorized at 1st/99th percentile (only if ≥30 valid values)
      2. Z-scored (only if ≥30 valid values and std > 1e-9)

    Rows with fewer than 30 valid values are left as NaN (not filled with 0)
    so the model can either skip them or impute properly.

    Bug-fix #7 (MEDIUM): Phase 9 regressed the MIN_PERIODS guard. Without it,
    cross-sections with very few tickers (e.g., early dates with only 5 tickers
    having data) were winsorized/z-scored using degenerate statistics,
    producing extreme outlier values that poisoned the ML model.
    Restored MIN_PERIODS=30 guard from QuantumAnnealer_FULL.
    """
    MIN_PERIODS = 30
    processed = {}
    for fname, df in factor_panels.items():
        # Handle Series (single ticker) vs DataFrame (multiple tickers)
        if isinstance(df, pd.Series):
            processed[fname] = df.fillna(0.0)
            continue
        if not isinstance(df, pd.DataFrame) or df.empty:
            processed[fname] = df
            continue

        # Winsorize at 1st/99th percentile cross-sectionally
        def _winsorize_row(row, **kwargs):
            valid = row.dropna()
            if len(valid) < MIN_PERIODS:
                return row
            lo, hi = valid.quantile(0.01), valid.quantile(0.99)
            return row.clip(lo, hi)

        winsorized = df.apply(_winsorize_row, axis=1)

        # Standardize (z-score) cross-sectionally
        def _zscore_row(row, **kwargs):
            valid = row.dropna()
            if len(valid) < MIN_PERIODS:
                return row
            std = valid.std()
            if not np.isfinite(std) or std < 1e-9:
                return row * 0.0
            return (row - valid.mean()) / std

        standardized = winsorized.apply(_zscore_row, axis=1)
        processed[fname] = standardized.fillna(0.0)
    return processed
