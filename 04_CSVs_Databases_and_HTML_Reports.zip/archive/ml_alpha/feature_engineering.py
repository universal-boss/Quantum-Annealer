"""Feature engineering — factor interactions, regime-conditional, fractional differentiation.

Transforms raw factors into more predictive features:

  1. Factor interactions: momentum × volatility, RSI × volume
  2. Regime-conditional factors: separate momentum in bull vs bear
  3. Fractional differentiation: stationary price series (López de Prado AFML Ch.4)
  4. Cross-sectional rank transforms: rank within sector
  5. Time-decay features: exponentially-weighted factor values
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Optional


# ═══════════════════════════════════════════════════════════════════════════════
# FRACTIONAL DIFFERENTIATION (López de Prado AFML Ch. 4)
# ═══════════════════════════════════════════════════════════════════════════════

def fractional_difference(
    series: pd.Series,
    d: float = 0.4,
    threshold: float = 1e-5,
) -> pd.Series:
    """Fractionally differentiate a time series to make it stationary.

    Standard differencing (d=1) makes a series stationary but loses memory.
    Fractional differencing (d=0.3-0.6) achieves stationarity while retaining
    more memory of the original series — critical for ML models.

    Args:
        series: Input time series (e.g., close prices).
        d: Differencing order (0 < d < 1). Lower = more memory retained.
        threshold: Weight cutoff for truncating the window.

    Returns:
        Fractionally differenced series (stationary, with memory).
    """
    # Compute weights for the fractional difference
    weights = [1.0]
    k = 1
    while True:
        w = -weights[-1] * (d - k + 1) / k
        if abs(w) < threshold:
            break
        weights.append(w)
        k += 1

    weights = np.array(weights[::-1])  # reverse for convolution
    width = len(weights)

    # Apply convolution
    result = series.rolling(width).apply(
        lambda x: np.dot(weights, x), raw=True
    )
    return result.dropna()


def frac_diff_factor(close: pd.Series, d: float = 0.4) -> pd.Series:
    """Fractional differentiation factor — stationary price with memory."""
    return fractional_difference(close, d=d)


# ═══════════════════════════════════════════════════════════════════════════════
# FACTOR INTERACTIONS
# ═══════════════════════════════════════════════════════════════════════════════

def factor_interaction(
    factor_a: pd.Series,
    factor_b: pd.Series,
    method: str = "multiply",
) -> pd.Series:
    """Create an interaction feature from two factors.

    Args:
        factor_a, factor_b: Input factor series.
        method: "multiply", "divide", "add", "subtract".

    Returns:
        Interaction feature series.
    """
    common = factor_a.index.intersection(factor_b.index)
    if len(common) == 0:
        return pd.Series(dtype=float)
    a = factor_a.loc[common]
    b = factor_b.loc[common]

    if method == "multiply":
        return (a * b).dropna()
    elif method == "divide":
        safe_b = b.replace(0, np.nan)
        return (a / safe_b).replace([np.inf, -np.inf], np.nan).dropna()
    elif method == "add":
        return (a + b).dropna()
    elif method == "subtract":
        return (a - b).dropna()
    else:
        return (a * b).dropna()


def momentum_volatility_interaction(
    momentum: pd.Series,
    volatility: pd.Series,
) -> pd.Series:
    """Momentum × Volatility interaction.

    High-vol momentum behaves differently from low-vol momentum.
    This feature captures that interaction.
    """
    return factor_interaction(momentum, volatility, "multiply")


def rsi_volume_interaction(
    rsi: pd.Series,
    volume: pd.Series,
) -> pd.Series:
    """RSI × Volume interaction.

    RSI > 70 with high volume = strong conviction overbought.
    RSI < 30 with high volume = strong conviction oversold.
    """
    return factor_interaction(rsi, volume, "multiply")


# ═══════════════════════════════════════════════════════════════════════════════
# REGIME-CONDITIONAL FACTORS
# ═══════════════════════════════════════════════════════════════════════════════

def regime_conditional_factor(
    factor: pd.Series,
    regime: pd.Series,
    target_regime: str = "Bull",
) -> pd.Series:
    """Factor value only when in target regime, 0 otherwise.

    Momentum has different predictive power in bull vs bear markets.
    This feature isolates the factor's signal in a specific regime.

    Args:
        factor: Input factor series.
        regime: Regime label series ("Bull", "Bear", "Sideways").
        target_regime: Regime to keep factor values for.

    Returns:
        Factor series with values zeroed outside target regime.
    """
    common = factor.index.intersection(regime.index)
    if len(common) == 0:
        return pd.Series(dtype=float)
    f = factor.loc[common].copy()
    r = regime.loc[common]
    # Zero out factor values where regime doesn't match
    mask = r != target_regime
    f[mask] = 0.0
    return f.dropna()


# ═══════════════════════════════════════════════════════════════════════════════
# CROSS-SECTIONAL RANK TRANSFORMS
# ═══════════════════════════════════════════════════════════════════════════════

def cross_sectional_rank(
    factor_panel: pd.DataFrame,
    group_by: Optional[pd.Series] = None,
) -> pd.DataFrame:
    """Cross-sectional rank transform of a factor panel.

    Ranks each ticker within the cross-section (or within sector groups)
    at each date. This makes the factor robust to outliers and comparable
    across different market regimes.

    Args:
        factor_panel: DataFrame[date × ticker] of factor values.
        group_by: Optional Series mapping ticker → sector. If provided,
                  ranking is done within each sector group.

    Returns:
        DataFrame[date × ticker] of ranks (0 to 1, normalized).
    """
    if group_by is None:
        # Rank across all tickers at each date
        return factor_panel.rank(axis=1, pct=True)
    else:
        # Rank within sector groups
        result = factor_panel.copy()
        for date in factor_panel.index:
            row = factor_panel.loc[date]
            for sector in group_by.unique():
                sector_tickers = [t for t in group_by[group_by == sector].index if t in row.index]
                if len(sector_tickers) > 1:
                    result.loc[date, sector_tickers] = row[sector_tickers].rank(pct=True)
        return result


# ═══════════════════════════════════════════════════════════════════════════════
# TIME-DECAY FEATURES (exponentially weighted)
# ═══════════════════════════════════════════════════════════════════════════════

def ewma_factor(
    factor: pd.Series,
    span: int = 21,
) -> pd.Series:
    """Exponentially-weighted moving average of a factor.

    Recent observations get higher weight. Useful for smoothing noisy factors
    while preserving responsiveness.

    Args:
        factor: Input factor series.
        span: EWMA span (default 21 = 1 month of trading days).

    Returns:
        EWMA-smoothed factor series.
    """
    return factor.ewm(span=span, adjust=False).mean().dropna()


def factor_momentum(
    factor: pd.Series,
    lookback: int = 21,
) -> pd.Series:
    """Momentum of a factor — how fast the factor is changing.

    If a factor is rising rapidly, it may signal strengthening conviction.
    If falling, weakening conviction.

    Args:
        factor: Input factor series.
        lookback: Lookback period for momentum calculation.

    Returns:
        Factor momentum series (current / lagged - 1).
    """
    if len(factor) < lookback + 1:
        return pd.Series(dtype=float)
    safe_lagged = factor.shift(lookback).replace(0, np.nan)
    return (factor / safe_lagged - 1.0).replace([np.inf, -np.inf], np.nan).dropna()


# ═══════════════════════════════════════════════════════════════════════════════
# FULL FEATURE ENGINEERING PIPELINE
# ═══════════════════════════════════════════════════════════════════════════════

def engineer_features(
    factor_panels: dict[str, pd.DataFrame],
    close_panel: pd.DataFrame,
    regime_series: Optional[pd.Series] = None,
    sector_map: Optional[pd.Series] = None,
) -> dict[str, pd.DataFrame]:
    """Apply full feature engineering pipeline to factor panels.

    Adds:
      1. Fractional differentiation of close prices
      2. Factor interactions (momentum×vol, RSI×vol)
      3. Regime-conditional factors (if regime provided)
      4. Cross-sectional rank transforms (if sector_map provided)
      5. EWMA-smoothed versions of key factors
      6. Factor momentum (rate of change)

    Args:
        factor_panels: Dict[factor_name → DataFrame[date × ticker]].
        close_panel: DataFrame[date × ticker] of close prices.
        regime_series: Optional regime labels for conditional factors.
        sector_map: Optional ticker → sector mapping for rank transforms.

    Returns:
        Expanded dict of factor panels (original + engineered).
    """
    engineered = dict(factor_panels)  # copy originals

    # 1. Fractional differentiation of close prices (per ticker)
    try:
        frac_diff_panel = close_panel.apply(
            lambda col: fractional_difference(col, d=0.4)
        )
        if not frac_diff_panel.empty:
            engineered["frac_diff_price"] = frac_diff_panel
    except Exception:
        pass

    # 2. Factor interactions
    if "momentum_12_1" in factor_panels and "lowvol_3m" in factor_panels:
        try:
            mom = factor_panels["momentum_12_1"]
            vol = factor_panels["lowvol_3m"]
            # Align and multiply
            common_dates = mom.index.intersection(vol.index)
            common_tickers = mom.columns.intersection(vol.columns)
            if len(common_dates) > 0 and len(common_tickers) > 0:
                interaction = (mom.loc[common_dates, common_tickers] *
                              vol.loc[common_dates, common_tickers])
                engineered["mom_vol_interaction"] = interaction
        except Exception:
            pass

    if "rsi_14" in factor_panels and "vol_momentum_21" in factor_panels:
        try:
            rsi = factor_panels["rsi_14"]
            volm = factor_panels["vol_momentum_21"]
            common_dates = rsi.index.intersection(volm.index)
            common_tickers = rsi.columns.intersection(volm.columns)
            if len(common_dates) > 0 and len(common_tickers) > 0:
                interaction = (rsi.loc[common_dates, common_tickers] *
                              volm.loc[common_dates, common_tickers])
                engineered["rsi_vol_interaction"] = interaction
        except Exception:
            pass

    # 3. Regime-conditional factors
    if regime_series is not None and "momentum_12_1" in factor_panels:
        try:
            mom_panel = factor_panels["momentum_12_1"]
            for target_regime in ["Bull", "Bear", "Sideways"]:
                conditional = mom_panel.copy()
                for date in mom_panel.index:
                    if date in regime_series.index:
                        if regime_series.loc[date] != target_regime:
                            conditional.loc[date] = 0.0
                engineered[f"momentum_{target_regime.lower()}"] = conditional
        except Exception:
            pass

    # 4. Cross-sectional rank transforms
    if sector_map is not None:
        try:
            for fname in ["momentum_12_1", "rsi_14", "lowvol_3m"]:
                if fname in factor_panels:
                    ranked = cross_sectional_rank(factor_panels[fname], sector_map)
                    engineered[f"{fname}_sector_rank"] = ranked
        except Exception:
            pass

    # 5. EWMA-smoothed versions of key factors
    for fname in ["momentum_12_1", "rsi_14"]:
        if fname in factor_panels:
            try:
                ewma_panel = factor_panels[fname].ewm(span=21, axis=0).mean()
                engineered[f"{fname}_ewma"] = ewma_panel
            except Exception:
                pass

    # 6. Factor momentum (rate of change)
    for fname in ["momentum_12_1", "rsi_14"]:
        if fname in factor_panels:
            try:
                fmom = factor_panels[fname] / factor_panels[fname].shift(21) - 1.0
                engineered[f"{fname}_momentum"] = fmom.replace([np.inf, -np.inf], np.nan)
            except Exception:
                pass

    return engineered
