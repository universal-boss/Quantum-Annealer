"""
ml_alpha/feature_extractor.py
==============================
Phase 9: Single source of truth for feature extraction.

The Kaggle-trained ViT model (v3) expects 128-d features from _extract_features().
This module provides that function so ALL code paths (training, prototype building,
live screening) use the SAME feature format.

Previously: three different feature extractors were used in three places,
none matching what the model was trained on → all similarities = 0.000.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Optional

FEAT_DIM = 128
LOOKBACK = 60


def extract_features_v3(
    window: pd.Series,
    benchmark_window: Optional[pd.Series] = None,
    feat_dim: int = FEAT_DIM,
) -> Optional[np.ndarray]:
    """Extract 128-d temporal features matching the Kaggle v3 training format.

    This is the EXACT same function used in kaggle_train_vit_v3.py.
    ALL inference paths (live_verify, build_prototypes, onnx_inference)
    MUST use this function to ensure features match training distribution.

    Args:
        window: 60-day close price series for the stock.
        benchmark_window: Optional 60-day close price series for the benchmark (^NSEI).
            If provided, relative returns are computed (excess over market).
        feat_dim: Output dimension (128 for v3 model).

    Returns:
        Normalized 128-d float32 feature vector, or None if extraction fails.
    """
    try:
        prices = window.values.astype(np.float32)
        if len(prices) < 20:
            return None

        rets = np.diff(prices, prepend=prices[0])

        # Relative returns vs benchmark (if provided)
        if benchmark_window is not None and len(benchmark_window) >= len(prices):
            bench = benchmark_window.values.astype(np.float32)
            bench_rets = np.diff(bench, prepend=bench[0])
        else:
            # No benchmark — use zeros (model was trained with benchmark, but
            # will still produce meaningful output without it)
            bench_rets = np.zeros_like(rets)

        rel_rets = rets - bench_rets

        features = []

        # 1. Last 20 daily returns (20 features)
        features.extend(rets[-20:].tolist())

        # 2. Relative returns vs benchmark (20 features)
        features.extend(rel_rets[-20:].tolist())

        # 3. Rolling statistics (12 features)
        for p in [5, 10, 20, 60]:
            if len(rets) >= p:
                features.append(float(np.mean(rets[-p:])))
                features.append(float(np.std(rets[-p:])))
                features.append(float(np.mean(rel_rets[-p:])))
            else:
                features.extend([0.0, 0.0, 0.0])

        # 4. Momentum (6 features)
        for p in [5, 10, 20, 60]:
            if len(prices) > p:
                features.append(float(prices[-1] / prices[-p] - 1.0))
            else:
                features.append(0.0)
        # Relative momentum
        if len(prices) > 20 and benchmark_window is not None and len(benchmark_window) > 20:
            stock_mom = prices[-1] / prices[-21] - 1.0
            bench_mom = bench[-1] / bench[-21] - 1.0
            features.append(float(stock_mom - bench_mom))
        else:
            features.append(0.0)
        features.append(float(prices[-1] / prices[-60] - 1.0) if len(prices) > 60 else 0.0)

        # 5. RSI (1 feature)
        deltas = np.diff(prices, prepend=prices[0])
        gains = np.where(deltas > 0, deltas, 0.0)
        losses = np.where(deltas < 0, -deltas, 0.0)
        avg_gain = np.mean(gains[-14:]) if len(gains) >= 14 else np.mean(gains)
        avg_loss = np.mean(losses[-14:]) if len(losses) >= 14 else np.mean(losses)
        rs = avg_gain / (avg_loss + 1e-9)
        features.append(float(100 - (100 / (1 + rs))) / 100.0)

        # 6. Volatility regime (3 features)
        features.append(float(np.std(rets[-20:])) if len(rets) >= 20 else 0.0)
        features.append(float(np.std(rets[-60:])) if len(rets) >= 60 else 0.0)
        features.append(float(np.max(prices[-20:]) / np.min(prices[-20:]) - 1.0) if len(prices) >= 20 else 0.0)

        # 7. Volume profile (2 features) — using |return| as volume proxy
        abs_rets = np.abs(rets)
        features.append(float(np.mean(abs_rets[-20:])) if len(abs_rets) >= 20 else 0.0)
        features.append(float(np.mean(abs_rets[-5:]) / (np.mean(abs_rets[-20:]) + 1e-9)) if len(abs_rets) >= 20 else 1.0)

        # 8. Drawdown (2 features)
        peak = np.maximum.accumulate(prices)
        dd = (prices - peak) / (peak + 1e-9)
        features.append(float(dd[-1]))  # current drawdown
        features.append(float(dd.min()))  # max drawdown in window

        # 9. Position in range (1 feature)
        p_min, p_max = float(prices.min()), float(prices.max())
        features.append(float((prices[-1] - p_min) / (p_max - p_min + 1e-9)))

        # Pad to feat_dim
        feat = np.array(features, dtype=np.float32)
        if len(feat) < feat_dim:
            feat = np.pad(feat, (0, feat_dim - len(feat)), "constant")
        else:
            feat = feat[:feat_dim]

        # Normalize
        norm = np.linalg.norm(feat)
        if norm > 1e-9:
            feat = feat / norm
        return feat
    except Exception:
        return None


def extract_features_from_close(
    close: pd.Series,
    benchmark: Optional[pd.Series] = None,
    lookback: int = LOOKBACK,
) -> Optional[np.ndarray]:
    """Convenience wrapper: extract features from the last `lookback` days of a close series.

    Args:
        close: Full close price series for a ticker.
        benchmark: Full close price series for the benchmark (will be aligned).
        lookback: Number of days to use (default 60).

    Returns:
        128-d feature vector or None.
    """
    if close is None or len(close) < lookback:
        return None

    window = close.iloc[-lookback:]
    bench_window = None
    if benchmark is not None and len(benchmark) >= lookback:
        # Align benchmark to the window's dates
        common = window.index.intersection(benchmark.index)
        if len(common) >= lookback:
            bench_window = benchmark.loc[window.index]

    return extract_features_v3(window, bench_window)
