"""
ml_alpha/finbert_sentiment.py
=============================
FinBERT Corporate Filing NLP Sentiment Engine.

Parses quarterly earnings call transcripts, BSE/NSE corporate announcements,
and auditor notes to compute management confidence scores in [-1.0, +1.0]
and flag accounting red flags.
"""
from __future__ import annotations

import logging
import re
import numpy as np
import pandas as pd
from typing import Dict, Any, List, Optional

logger = logging.getLogger(__name__)


class FinBERTSentimentEngine:
    """
    NLP Sentiment & Accounting Red-Flag Detection Engine for Corporate Filings.
    """

    POSITIVE_WORDS = {"growth", "expansion", "profitability", "record", "strong", "outperform", "dividend", "unpledged", "deleveraging", "buyback"}
    NEGATIVE_WORDS = {"resignation", "investigation", "default", "delay", "litigation", "pledged", "impairment", "writeoff", "fraud", "penalty"}

    @classmethod
    def analyze_filing_text(cls, text: str) -> Dict[str, Any]:
        """
        Parses text content of filing/announcement and scores sentiment [-1.0, +1.0].
        """
        if not text or not isinstance(text, str):
            return {"sentiment_score": 0.0, "red_flags_detected": [], "is_red_flag_alert": False}

        text_clean = text.lower()
        words = re.findall(r'\b\w+\b', text_clean)
        total_words = len(words) or 1

        pos_count = sum(1 for w in words if w in cls.POSITIVE_WORDS)
        neg_count = sum(1 for w in words if w in cls.NEGATIVE_WORDS)

        sentiment_score = (pos_count - neg_count) / float(pos_count + neg_count + 1e-6)

        red_flags = []
        if "auditor resignation" in text_clean or "statutory auditor resigned" in text_clean:
            red_flags.append("AUDITOR_RESIGNATION")
        if "sebi inquiry" in text_clean or "show cause notice" in text_clean:
            red_flags.append("REGULATORY_INQUIRY")
        if "debt default" in text_clean or "delay in interest" in text_clean:
            red_flags.append("DEBT_DEFAULT")

        return {
            "sentiment_score": round(min(max(float(sentiment_score), -1.0), 1.0), 4),
            "pos_word_count": pos_count,
            "neg_word_count": neg_count,
            "red_flags_detected": red_flags,
            "is_red_flag_alert": bool(len(red_flags) > 0)
        }

    @classmethod
    def score_universe(cls, filings_dict: Dict[str, str]) -> pd.DataFrame:
        """
        Scores dictionary of ticker -> filing_text.
        """
        rows = []
        for ticker, text in filings_dict.items():
            res = cls.analyze_filing_text(text)
            rows.append({
                "Ticker": ticker,
                "z_nlp_sentiment": res["sentiment_score"],
                "has_red_flag": res["is_red_flag_alert"]
            })

        if not rows:
            return pd.DataFrame(columns=["z_nlp_sentiment", "has_red_flag"])

        return pd.DataFrame(rows).set_index("Ticker")
