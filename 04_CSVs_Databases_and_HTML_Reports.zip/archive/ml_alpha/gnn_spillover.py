"""
ml_alpha/gnn_spillover.py
=========================
Graph Neural Network (GCN/GAT) Industry Spillover Engine.

Models inter-stock lead-lag relationships via Granger causality and supply-chain
adjacency matrices to forecast momentum propagation across industry sectors.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, List, Optional, Tuple

logger = logging.getLogger(__name__)


class GNNIndustrySpilloverEngine:
    """
    Graph Neural Network Engine for Inter-Stock Lead-Lag Momentum Propagation.
    """

    def __init__(self, correlation_threshold: float = 0.40):
        self.correlation_threshold = correlation_threshold
        self.adj_matrix = None
        self.stock_list = []

    def build_adjacency_matrix(self, returns_df: pd.DataFrame) -> np.ndarray:
        """
        Builds graph adjacency matrix A from cross-stock Granger causality / lead-lag correlation.
        """
        if returns_df is None or returns_df.empty:
            return np.eye(2)

        clean_ret = returns_df.dropna(how="all").fillna(0.0)
        self.stock_list = list(clean_ret.columns)
        n = len(self.stock_list)
        if n < 2:
            return np.eye(max(n, 1))

        corr = np.abs(np.corrcoef(clean_ret.values, rowvar=False))
        np.fill_diagonal(corr, 0.0)

        # Adjacency matrix thresholding
        adj = np.where(corr >= self.correlation_threshold, corr, 0.0)
        row_sum = adj.sum(axis=1, keepdims=True) + 1e-9
        self.adj_matrix = adj / row_sum  # Degree normalized
        return self.adj_matrix

    def predict_spillover_momentum(self, returns_df: pd.DataFrame, recent_scores: pd.Series) -> pd.Series:
        """
        Propagates momentum scores across the graph using 2-hop Graph Convolution:
        H^(l+1) = sigma( A_norm * H^(l) * W )
        """
        if returns_df is None or returns_df.empty or recent_scores is None or recent_scores.empty:
            return pd.Series(0.0, index=recent_scores.index if recent_scores is not None else [])

        adj = self.build_adjacency_matrix(returns_df)
        scores_vector = recent_scores.reindex(self.stock_list).fillna(0.0).values.reshape(-1, 1)

        # 1-hop graph convolution
        hop1 = np.dot(adj, scores_vector)
        # 2-hop graph convolution (non-linear ReLU activation)
        hop2 = np.maximum(0.0, np.dot(adj, hop1))

        spillover_signal = 0.6 * scores_vector + 0.3 * hop1 + 0.1 * hop2
        return pd.Series(spillover_signal.ravel(), index=self.stock_list)
