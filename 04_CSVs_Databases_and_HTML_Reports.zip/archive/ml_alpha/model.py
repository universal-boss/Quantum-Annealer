"""Alpha ensemble — Ridge + LightGBM blend for factor combination.

Ridge (linear) is the primary model — it can't overfit like trees on 50 stocks.
LightGBM captures non-linear interactions. Blend = 50/50 average.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Any

try:
    import lightgbm as lgb
    _HAS_LGB = True
except ImportError:
    _HAS_LGB = False

from sklearn.linear_model import Ridge


class AlphaEnsemble:
    """Factor combination model. Supports 'ridge', 'lightgbm', or 'blend'."""

    def __init__(self, model_type: str = "ridge"):
        self.model_type = model_type
        self._ridge: Ridge | None = None
        self._lgb: Any = None
        self._feature_names: list[str] = []
        self._is_fit = False

    def fit(self, X: pd.DataFrame, y: pd.Series) -> dict[str, Any]:
        """Fit the ensemble on (date, ticker) × factors → forward returns."""
        X_clean = X.fillna(0.0)
        y_arr = y.to_numpy(dtype=float)
        mask = ~np.isnan(y_arr)
        X_clean = X_clean.loc[mask]
        y_arr = y_arr[mask]

        self._feature_names = list(X_clean.columns)
        X_arr = X_clean.to_numpy(dtype=float)

        # Always fit Ridge (primary model)
        self._ridge = Ridge(alpha=1.0)
        self._ridge.fit(X_arr, y_arr)

        # Optionally fit LightGBM
        if self.model_type in ("lightgbm", "blend") and _HAS_LGB:
            self._lgb = lgb.LGBMRegressor(
                n_estimators=60, learning_rate=0.03, num_leaves=12,
                max_depth=4, min_child_samples=50,
                subsample=0.7, colsample_bytree=0.7,
                reg_alpha=1.0, reg_lambda=5.0,
                random_state=42, verbosity=-1,
                n_jobs=1,  # CRASH FIX: see expanded_ensemble.py — avoids
                # LightGBM's bundled OpenMP runtime colliding with faiss/torch's.
            )
            self._lgb.fit(X_arr, y_arr)

        self._is_fit = True
        return {"model_type": self.model_type, "n_features": len(self._feature_names), "n_samples": len(y_arr)}

    def predict(self, X: pd.DataFrame) -> pd.Series:
        """Predict alpha scores. Blend = 50/50 Ridge + LightGBM.

        Handles missing features gracefully via reindex (fills 0.0).
        Returns Ridge-only for 'ridge' model_type, LGB-only for 'lightgbm',
        and 50/50 blend for 'blend'.
        """
        if not self._is_fit:
            raise RuntimeError("Model not fitted")
        # Reindex to ensure all training features are present, filling missing with 0.0
        X_aligned = X.reindex(columns=self._feature_names, fill_value=0.0).fillna(0.0).to_numpy(dtype=float)

        ridge_pred = self._ridge.predict(X_aligned)

        if self._lgb is not None:
            lgb_pred = self._lgb.predict(X_aligned)
            if self.model_type == "blend":
                preds = 0.5 * ridge_pred + 0.5 * lgb_pred
            elif self.model_type == "lightgbm":
                preds = lgb_pred
            else:
                preds = ridge_pred
        else:
            preds = ridge_pred

        return pd.Series(preds, index=X.index, name="alpha")

    def feature_importance(self) -> dict[str, float]:
        """Return feature importance as dict. Uses Ridge |coef|."""
        if not self._is_fit:
            return {}
        imp = np.abs(self._ridge.coef_)
        total = imp.sum() or 1.0
        return {name: float(v / total) for name, v in zip(self._feature_names, imp)}
