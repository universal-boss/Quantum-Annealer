"""
ml_alpha/reinforcement_q_learning.py
===================================
Q-Learning Deep Reinforcement Trade Execution Slicing Engine.

Updates Q-table Q(s, a) <- Q(s, a) + alpha * [ r + gamma * max_a' Q(s', a') - Q(s, a) ]
to learn optimal TWAP/VWAP order slicing schedules under market impact penalties.
"""
from __future__ import annotations

import logging
import numpy as np
from typing import Dict, Any, List

logger = logging.getLogger(__name__)


class QLearningExecutionAgent:
    """
    Q-Learning Deep RL Order Slicing Agent.
    """

    def __init__(self, n_states: int = 5, n_actions: int = 3, lr: float = 0.1, gamma: float = 0.9):
        self.n_states = n_states
        self.n_actions = n_actions
        self.lr = lr
        self.gamma = gamma
        self.q_table = np.zeros((n_states, n_actions))

    def select_action(self, state: int, epsilon: float = 0.1) -> int:
        """
        Epsilon-greedy action selection.
        """
        state = min(max(state, 0), self.n_states - 1)
        if np.random.rand() < epsilon:
            return int(np.random.randint(self.n_actions))
        return int(np.argmax(self.q_table[state]))

    def update_q_value(self, state: int, action: int, reward: float, next_state: int):
        """
        Updates Q(s, a) via temporal difference error.
        """
        state = min(max(state, 0), self.n_states - 1)
        next_state = min(max(next_state, 0), self.n_states - 1)
        action = min(max(action, 0), self.n_actions - 1)

        best_next_q = float(np.max(self.q_table[next_state]))
        td_target = reward + self.gamma * best_next_q
        self.q_table[state, action] += self.lr * (td_target - self.q_table[state, action])
