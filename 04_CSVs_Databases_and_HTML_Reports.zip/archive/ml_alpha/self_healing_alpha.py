"""
ml_alpha/self_healing_alpha.py
==============================
Autonomous Self-Healing Alpha Engine & Online Re-tuning.

Continuously monitors rolling factor Information Coefficients (ICs).
Automatically down-weights or replaces decaying factors on-the-fly to prevent alpha loss.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any, List

logger = logging.getLogger(__name__)


class SelfHealingAlphaEngine:
    """
    Autonomous Factor Self-Healing & Dynamic Re-weighting Engine.
    """

    @staticmethod
    def reweight_decaying_factors(factor_weights: Dict[str, float],
                                  recent_ics: Dict[str, float],
                                  min_ic_threshold: float = 0.01) -> Dict[str, Any]:
        """
        Dynamically adjusts factor weights based on real-time rolling IC health.
        """
        if not factor_weights or not recent_ics:
            return {"adjusted_weights": factor_weights, "healed_factors": [], "pruned_factors": []}

        adj_weights = dict(factor_weights)
        healed = []
        pruned = []

        for factor, w in factor_weights.items():
            ic = recent_ics.get(factor, 0.05)
            if ic < 0:
                # Negative IC -> zero out weight to prevent trading inverted factor
                adj_weights[factor] = 0.0
                pruned.append(factor)
            elif ic < min_ic_threshold:
                # Weak IC -> down-weight by 50%
                adj_weights[factor] = round(w * 0.5, 4)
                healed.append(factor)
            elif ic > 0.08:
                # Strong IC -> boost weight by 20%
                adj_weights[factor] = round(w * 1.2, 4)

        # Normalize positive weights
        pos_total = sum(v for v in adj_weights.values() if v > 0)
        if pos_total > 0:
            adj_weights = {k: round(v / pos_total, 4) for k, v in adj_weights.items()}

        return {
            "adjusted_weights": adj_weights,
            "healed_factors": healed,
            "pruned_factors": pruned
        }
