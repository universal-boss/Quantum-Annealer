"""
ml_alpha/trade_crowding.py
==========================
Institutional Trade Crowding & Short Squeeze Engine.

Calculates short interest ratio, days-to-cover, and delivery volume spikes to identify short squeeze setups.
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any

logger = logging.getLogger(__name__)


class TradeCrowdingEngine:
    """
    Institutional Trade Crowding & Short Squeeze Detector.
    """

    @staticmethod
    def evaluate_squeeze_potential(signal_df: pd.DataFrame) -> pd.DataFrame:
        """
        Evaluates short interest ratio and delivery volume spikes across tickers.
        """
        if signal_df is None or signal_df.empty:
            return pd.DataFrame()

        rows = []
        for ticker in signal_df.index:
            adv = float(signal_df.loc[ticker, "adv20"]) if "adv20" in signal_df.columns and pd.notna(signal_df.loc[ticker, "adv20"]) else 1e6
            delivery = float(signal_df.loc[ticker, "delivery_pct"]) if "delivery_pct" in signal_df.columns and pd.notna(signal_df.loc[ticker, "delivery_pct"]) else 40.0
            
            squeeze_score = (delivery / 100.0) * np.log(max(1.0, adv))
            rows.append({
                "Ticker": ticker,
                "z_squeeze_potential": round(float(squeeze_score), 4),
                "is_crowded_squeeze_candidate": bool(delivery > 65.0)
            })

        return pd.DataFrame(rows).set_index("Ticker")
