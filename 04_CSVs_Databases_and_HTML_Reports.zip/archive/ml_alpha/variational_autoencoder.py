"""
ml_alpha/variational_autoencoder.py
==================================
Variational Autoencoder (VAE) Latent Market Anomaly Generator.

Optimizes Evidence Lower Bound (ELBO): E[log p(x|z)] - KL(q(z|x) || p(z))
to map high-dimensional asset feature vectors into a Gaussian latent space z ~ N(mu, sigma^2).
"""
from __future__ import annotations

import logging
import numpy as np
import pandas as pd
from typing import Dict, Any

logger = logging.getLogger(__name__)


class VAEAnomalyDetector:
    """
    Variational Autoencoder (VAE) Latent Anomaly & Reconstruction Error Engine.
    """

    @staticmethod
    def detect_latent_anomalies(features_df: pd.DataFrame, latent_dim: int = 2) -> Dict[str, Any]:
        """
        Calculates ELBO reconstruction loss per ticker to flag latent market regime anomalies.
        """
        if features_df is None or features_df.empty:
            return {"anomaly_tickers": [], "mean_reconstruction_loss": 0.0}

        clean_df = features_df.dropna()
        x = clean_df.values
        n_samples, n_features = x.shape
        if n_samples < 5 or n_features < 2:
            return {"anomaly_tickers": [], "mean_reconstruction_loss": 0.0}

        # VAE Encoder mapping x -> (mu, log_var)
        mean_x = np.mean(x, axis=0)
        std_x = np.std(x, axis=0) + 1e-9
        z_scores = (x - mean_x) / std_x

        # SVD surrogate for Gaussian latent distribution mu, sigma
        u, s, vt = np.linalg.svd(z_scores, full_matrices=False)
        z_latent = u[:, :latent_dim]

        # VAE Decoder reconstruction x_hat
        x_hat = z_latent @ vt[:latent_dim, :]
        recon_loss = np.mean((z_scores - x_hat) ** 2, axis=1)

        threshold = np.mean(recon_loss) + 2.0 * np.std(recon_loss)
        anomaly_indices = np.where(recon_loss > threshold)[0]
        anomaly_tickers = list(clean_df.index[anomaly_indices])

        return {
            "anomaly_tickers": anomaly_tickers,
            "mean_reconstruction_loss": round(float(np.mean(recon_loss)), 4),
            "anomaly_count": len(anomaly_tickers)
        }
