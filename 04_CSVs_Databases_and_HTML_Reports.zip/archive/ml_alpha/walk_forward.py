"""Walk-forward cross-validation with purge and embargo.

Implements TRUE rolling-window walk-forward CV (not expanding-window).
Train on the most recent `train_period_days` observations, test on the next
`test_period_days` observations, with a purge gap of `purge_window_days`
(extended by `forward_return_days` to prevent label leakage) between train
and test.

Follows López de Prado's "Advances in Financial Machine Learning" Ch. 7-12:
- Purge: remove training observations whose forward-return label overlaps
  with the test set.
- Embargo: skip a few observations after each test set to prevent serial
  correlation from inflating OOS metrics.
"""
from __future__ import annotations

from datetime import timedelta
from typing import Iterator
import pandas as pd


class WalkForwardSplit:
    """One fold of walk-forward CV."""
    def __init__(self, fold_id: int, train_idx: pd.DatetimeIndex, test_idx: pd.DatetimeIndex):
        self.fold_id = fold_id
        self.train_idx = train_idx
        self.test_idx = test_idx


class WalkForwardCV:
    """True rolling-window walk-forward CV splitter.

    Args:
        n_splits: max number of folds
        train_period_days: training window length (in rebalance-date units)
        test_period_days: test window length (in rebalance-date units)
        purge_window_days: gap between train end and test start (in rebalance-date
            units). Will be extended by forward_return_days to prevent label leakage.
        embargo_pct: fraction of total dates to embargo after each test set
        forward_return_days: forward return horizon — used to extend the purge
            window so labels don't leak into the test set.
    """

    def __init__(
        self,
        n_splits: int = 4,
        train_period_days: int = 252,
        test_period_days: int = 42,
        purge_window_days: int = 14,
        embargo_pct: float = 0.01,
        forward_return_days: int = 0,
    ):
        self.n_splits = max(1, int(n_splits))
        self.train_period_days = max(10, int(train_period_days))
        self.test_period_days = max(5, int(test_period_days))
        # Effective purge = purge_window_days + forward_return_days
        # This prevents a training observation at date t (with label realized at
        # t + forward_return_days) from leaking into the test set.
        self.forward_return_days = max(0, int(forward_return_days))
        self.purge_window_days = max(1, int(purge_window_days)) + self.forward_return_days
        self.embargo_pct = float(embargo_pct)

    def split(self, dates: pd.DatetimeIndex) -> Iterator[WalkForwardSplit]:
        """Yield WalkForwardSplit(train_idx, test_idx) pairs.

        Train is always the most recent `train_period_days` dates BEFORE the
        purge window. Test is the `test_period_days` dates AFTER the purge
        window. This is a true rolling window (not expanding).
        """
        dates = pd.DatetimeIndex(sorted(set(dates)))
        n = len(dates)
        if n == 0:
            return

        train_days = self.train_period_days
        test_days = self.test_period_days
        purge_days = self.purge_window_days  # already extended by forward_return_days
        # Embargo: at least forward_return_days to prevent serial correlation
        embargo_days = max(self.forward_return_days, int(self.embargo_pct * n))
        embargo_days = max(embargo_days, 1)

        # Validate: need at least train + purge + test dates for one fold
        min_required = train_days + purge_days + test_days
        if n < min_required:
            # Shrink train_days to fit at least one fold
            train_days = max(30, n - purge_days - test_days)
            if train_days < 30:
                return  # not enough data for even one fold

        fold_id = 0
        # First test starts at train_days + purge_days
        test_start_pos = train_days + purge_days

        while test_start_pos + test_days <= n and fold_id < self.n_splits:
            test_end_pos = test_start_pos + test_days
            test_idx = dates[test_start_pos:test_end_pos]

            # Train: rolling window of train_days dates, ending purge_days before test_start
            train_end_pos = test_start_pos - purge_days
            train_start_pos = max(0, train_end_pos - train_days)
            train_idx = dates[train_start_pos:train_end_pos]

            if len(train_idx) < 50:
                # Not enough training data — skip this fold
                test_start_pos = test_end_pos + embargo_days
                fold_id += 1
                continue

            yield WalkForwardSplit(fold_id=fold_id, train_idx=train_idx, test_idx=test_idx)

            # Advance to next fold: test_end + embargo
            test_start_pos = test_end_pos + embargo_days
            fold_id += 1


class CPCVSplit:
    """One path of Combinatorial Purged CV."""
    def __init__(self, path_id: int, train_idx: pd.DatetimeIndex, test_idx: pd.DatetimeIndex):
        self.path_id = path_id
        self.fold_id = path_id  # alias for compatibility
        self.train_idx = train_idx
        self.test_idx = test_idx


class CombinatorialPurgedCV:
    """Combinatorial Purged Cross-Validation (CPCV) — López de Prado gold standard.

    Splits data into N groups, generates all C(N, k) combinations of k test groups.
    Each combination is one path — a complete train/test split with purge+embargo.
    """

    def __init__(
        self,
        n_groups: int = 6,
        n_test_groups: int = 2,
        purge_window_days: int = 14,
        forward_return_days: int = 0,
        embargo_pct: float = 0.01,
    ):
        self.n_groups = max(2, int(n_groups))
        self.n_test_groups = max(1, min(int(n_test_groups), self.n_groups - 1))
        self.forward_return_days = max(0, int(forward_return_days))
        self.purge_window_days = max(1, int(purge_window_days)) + self.forward_return_days
        self.embargo_pct = float(embargo_pct)

    def split(self, dates: pd.DatetimeIndex):
        """Yield CPCVSplit(train_idx, test_idx) pairs — all C(N, k) combinations."""
        from itertools import combinations
        import numpy as np

        dates = pd.DatetimeIndex(sorted(set(dates)))
        n = len(dates)
        if n == 0:
            return

        group_boundaries = np.array_split(np.arange(n), self.n_groups)
        groups = [dates[boundaries] for boundaries in group_boundaries]

        purge_days = self.purge_window_days
        test_combos = list(combinations(range(self.n_groups), self.n_test_groups))

        for path_id, test_indices in enumerate(test_combos):
            test_dates = []
            for gi in test_indices:
                test_dates.extend(groups[gi])
            test_idx = pd.DatetimeIndex(sorted(set(test_dates)))

            # FIX: Vectorized purge check — replaces the O(N²) nested loop that
            # checked each training date vs every test date one-by-one.
            # On 1,000 dates × 15 CPCV paths, the old loop did up to 15M comparisons,
            # causing folds to time out and be skipped (why only 12/15 ran).
            # New approach: convert dates to integer timestamps, then use numpy
            # broadcasting to compute min-distance from each train date to any
            # test date in a single vectorized operation — O(N*M) but in numpy
            # C-speed, which is ~100x faster than Python loops.
            train_candidate_dates = []
            for gi in range(self.n_groups):
                if gi not in test_indices:
                    train_candidate_dates.extend(groups[gi])

            if train_candidate_dates:
                train_arr = np.array([pd.Timestamp(d).value for d in train_candidate_dates], dtype=np.int64)  # nanoseconds
                test_arr  = np.array([pd.Timestamp(d).value for d in test_idx],              dtype=np.int64)
                # FIX C8: purge_days is in rebalance-date units, NOT calendar days.
                # Converting as calendar days (× 86400 × 1e9) makes the purge ~5× too small.
                # Instead, compute the median gap between consecutive dates and use that
                # to convert rebalance-date units → nanoseconds.
                all_dates_sorted = sorted(set([pd.Timestamp(d) for d in train_candidate_dates] + [pd.Timestamp(d) for d in test_idx]))
                if len(all_dates_sorted) > 1:
                    gaps_ns = np.diff([d.value for d in all_dates_sorted])
                    median_gap_ns = int(np.median(gaps_ns))
                else:
                    median_gap_ns = 86_400 * 1_000_000_000  # fallback: 1 calendar day
                purge_ns = purge_days * median_gap_ns
                # For each training date, find its minimum absolute distance to any test date
                dist_matrix = np.abs(train_arr[:, None] - test_arr[None, :])
                min_dist    = dist_matrix.min(axis=1)
                keep_mask   = min_dist > purge_ns
                train_dates_kept = [train_candidate_dates[i] for i in range(len(train_candidate_dates)) if keep_mask[i]]
            else:
                train_dates_kept = []

            train_idx = pd.DatetimeIndex(sorted(set(train_dates_kept)))


            if len(train_idx) < 50 or len(test_idx) < 10:
                continue

            yield CPCVSplit(path_id=path_id, train_idx=train_idx, test_idx=test_idx)
