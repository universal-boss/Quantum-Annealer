"""
test_rmt.py — Unit tests for optimizer and HRP weights.
"""
import numpy as np
import pandas as pd
try:
    import pytest
except ImportError:
    pytest = None

# FIX: import from the split optimizer module.
from optimizer import hrp_weights


def test_hrp_weights_basic():
    """HRP weights should be positive and sum to 1."""
    np.random.seed(42)
    n = 10
    returns = pd.DataFrame(
        np.random.randn(252, n) * 0.01,
        columns=[f"STOCK_{i}" for i in range(n)],
    )
    weights = hrp_weights(returns)
    assert isinstance(weights, (dict, pd.Series)), "hrp_weights must return dict or Series"
    if isinstance(weights, pd.Series):
        w = weights.values
    elif hasattr(weights, "values") and callable(weights.values):
        w = np.array(list(weights.values()))
    else:
        w = np.array(list(weights))
    assert np.all(w >= -1e-9), "All weights must be non-negative"
    assert abs(w.sum() - 1.0) < 1e-6, f"Weights must sum to 1, got {w.sum()}"


def test_hrp_weights_single_asset():
    """Single asset should get weight = 1.0."""
    returns = pd.DataFrame({"A": np.random.randn(100) * 0.01})
    weights = hrp_weights(returns)
    if isinstance(weights, dict):
        w = list(weights.values())
    elif isinstance(weights, pd.Series):
        w = weights.values.tolist()
    else:
        w = list(weights)
    assert abs(w[0] - 1.0) < 1e-6


def test_hrp_weights_equal_corr():
    """With identical assets, HRP should assign roughly equal weights."""
    np.random.seed(0)
    base = np.random.randn(252) * 0.01
    returns = pd.DataFrame({f"S{i}": base + np.random.randn(252) * 1e-6 for i in range(5)})
    weights = hrp_weights(returns)
    if isinstance(weights, pd.Series):
        w = weights.values
    elif hasattr(weights, "values") and callable(weights.values):
        w = np.array(list(weights.values()))
    else:
        w = np.array(list(weights))
    assert np.allclose(w, w.mean(), atol=0.05), "Equal-corr assets should have near-equal weights"


if __name__ == "__main__":
    test_hrp_weights_basic()
    test_hrp_weights_single_asset()
    test_hrp_weights_equal_corr()
    print("All test_rmt tests passed.")
