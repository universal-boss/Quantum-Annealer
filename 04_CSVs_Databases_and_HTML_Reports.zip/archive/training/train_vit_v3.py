"""
training/train_vit_v3.py
==========================
Phase 7: REAL ViT training script for the dual-tower chart pattern model.

Trains a CNN visual tower + MLP temporal tower on real NSE data:
  1. Fetches 50 NSE stocks (5y daily data)
  2. Generates 60-day chart windows labeled by forward 20-day return quartiles
  3. Trains with BCEWithLogitsLoss (binary breakout classification)
  4. AdamW optimizer with cosine schedule
  5. Early stopping on validation recall@k
  6. Exports best checkpoint to ONNX (opset 18)

Previously: this script did NO training — just exported randomly-initialized
weights. The "trained ViT" was a random network.
"""
from __future__ import annotations

import os
import sys
import time
import logging
import numpy as np
import pandas as pd
from pathlib import Path
from datetime import date, timedelta

# R46 FIX (NameError at import): the module-level model classes (ChartCNN,
# ChartViT, ...) subclass nn.Module, but `torch`/`torch.nn` were only ever
# imported INSIDE functions — importing this module raised NameError before
# any function could run. Guarded so the archive stays importable in
# torch-less environments; training entry points still raise a clear error.
try:
    import torch
    import torch.nn as nn
except ImportError:  # pragma: no cover
    torch = None

    class _nn_missing_stub:
        """Placeholder namespace: keeps module-level `class X(nn.Module)`
        definitions importable in torch-less environments. Any real use
        (instantiation, calling nn.<anything> at runtime) raises loudly."""

        class Module:
            def __init__(self, *a, **k):
                raise RuntimeError(
                    "PyTorch is not installed — archive model classes are "
                    "importable but not usable. Install torch to train."
                )

        def __getattr__(self, name):
            raise RuntimeError(
                f"torch.nn.{name} unavailable — PyTorch is not installed."
            )

    nn = _nn_missing_stub()


logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

# Project root
PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))


def fetch_training_data(n_stocks: int = 50, period: str = "5y") -> pd.DataFrame:
    """Fetch NSE stock prices for training.

    Returns a DataFrame indexed by date, columns = tickers, values = close prices.
    """
    from data.universe import fetch_nifty50_tickers
    tickers = fetch_nifty50_tickers()
    if not tickers or len(tickers) < 10:
        logger.warning("NSE fetch failed — using hardcoded Nifty 50 fallback")
        tickers = [
            "RELIANCE.NS", "TCS.NS", "HDFCBANK.NS", "INFY.NS", "ICICIBANK.NS",
            "SBIN.NS", "BAJFINANCE.NS", "HCLTECH.NS", "WIPRO.NS", "AXISBANK.NS",
            "KOTAKBANK.NS", "LT.NS", "TITAN.NS", "SUNPHARMA.NS", "ONGC.NS",
            "MARUTI.NS", "NESTLEIND.NS", "POWERGRID.NS", "NTPC.NS", "TECHM.NS",
            "ASIANPAINT.NS", "TATASTEEL.NS", "JSWSTEEL.NS", "ADANIENT.NS",
            "ULTRACEMCO.NS", "BRITANNIA.NS", "HINDALCO.NS", "COALINDIA.NS",
            "BPCL.NS", "TATAMOTORS.NS", "BAJAJFINSV.NS", "DIVISLAB.NS",
            "DRREDDY.NS", "EICHERMOT.NS", "GRASIM.NS", "HDFCLIFE.NS",
            "HEROMOTOCO.NS", "INDUSINDBK.NS", "CIPLA.NS", "ITC.NS",
            "JSWENERGY.NS", "M&M.NS", "SHRIRAMFIN.NS", "TATACONSUM.NS",
            "TRENT.NS", "BAJAJ-AUTO.NS", "APOLLOHOSP.NS", "BEL.NS",
            "BHARTIARTL.NS", "HINDUNILVR.NS",
        ]

    tickers = tickers[:n_stocks]
    logger.info(f"Fetching {len(tickers)} tickers for {period}...")

    from data.price_feed import safe_download
    raw = safe_download(tickers, period=period, auto_adjust=True)
    if raw is None or raw.empty:
        raise RuntimeError("Failed to fetch training data")

    # Extract close prices
    if isinstance(raw.columns, pd.MultiIndex):
        close = raw["Close"] if "Close" in raw.columns.get_level_values(0) else raw.iloc[:, 0]
    else:
        close = raw[["Close"]] if "Close" in raw.columns else raw
        if len(tickers) == 1:
            close.columns = tickers

    close = close.dropna(how="all")
    logger.info(f"Loaded {len(close)} trading days × {len(close.columns)} tickers")
    return close


def generate_chart_windows(
    close: pd.DataFrame,
    lookback: int = 60,
    forward: int = 20,
    stride: int = 5,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Generate 60-day chart windows with forward return labels.

    Returns:
        images: (N, 4, 224, 224) — 4-channel chart images (OHLC normalized)
        features: (N, 512) — temporal features (returns, vol, RSI, etc.)
        labels: (N,) — binary: 1 if forward return in top quartile, else 0
    """
    tickers = list(close.columns)
    all_images = []
    all_features = []
    all_labels = []

    for ticker in tickers:
        series = close[ticker].dropna()
        if len(series) < lookback + forward + 10:
            continue

        # Compute forward returns for labeling
        fwd_ret = series.shift(-forward) / series - 1.0

        for i in range(0, len(series) - lookback - forward, stride):
            window = series.iloc[i : i + lookback]
            if len(window) < lookback:
                continue
            fwd = fwd_ret.iloc[i + lookback - 1]
            if pd.isna(fwd):
                continue

            # Generate 4-channel chart image (OHLC candles at 224x224)
            img = _window_to_image(window)
            if img is None:
                continue

            # Generate 512-d temporal features
            feat = _window_to_features(window)
            if feat is None:
                continue

            all_images.append(img)
            all_features.append(feat)
            all_labels.append(fwd)

    if not all_images:
        raise RuntimeError("No valid chart windows generated")

    images = np.array(all_images, dtype=np.float32)
    features = np.array(all_features, dtype=np.float32)
    labels_raw = np.array(all_labels, dtype=np.float32)

    # Binary label: top quartile = 1 (breakout), else 0
    threshold = np.percentile(labels_raw, 75)
    labels = (labels_raw >= threshold).astype(np.float32)

    logger.info(f"Generated {len(images)} windows: {int(labels.sum())} positive (breakout), "
                f"{int((1-labels).sum())} negative (threshold={threshold:.4f})")
    return images, features, labels


def _window_to_image(window: pd.Series, img_size: int = 224) -> np.ndarray | None:
    """Convert a price window to a 4-channel 224x224 chart image.

    Channels: [normalized_close, normalized_volume_proxy, rsi, ma_distance]
    """
    try:
        prices = window.values.astype(np.float32)
        if len(prices) < 20:
            return None

        # Normalize prices to [0, 1]
        p_min, p_max = float(prices.min()), float(prices.max())
        if p_max - p_min < 1e-9:
            return None
        norm_prices = (prices - p_min) / (p_max - p_min)

        # Resize to img_size using nearest-neighbor (simple but works)
        indices = np.linspace(0, len(norm_prices) - 1, img_size).astype(int)
        close_channel = norm_prices[indices]

        # Volume proxy: absolute daily returns
        rets = np.abs(np.diff(prices, prepend=prices[0]))
        r_min, r_max = float(rets.min()), float(rets.max())
        if r_max - r_min < 1e-9:
            vol_channel = np.zeros(img_size, dtype=np.float32)
        else:
            vol_channel = ((rets - r_min) / (r_max - r_min))[indices]

        # RSI (simplified)
        deltas = np.diff(prices, prepend=prices[0])
        gains = np.where(deltas > 0, deltas, 0.0)
        losses = np.where(deltas < 0, -deltas, 0.0)
        avg_gain = pd.Series(gains).rolling(14, min_periods=1).mean().values
        avg_loss = pd.Series(losses).rolling(14, min_periods=1).mean().values
        rs = np.where(avg_loss > 1e-9, avg_gain / (avg_loss + 1e-9), 0.0)
        rsi = (100 - (100 / (1 + rs))) / 100.0  # normalize to [0,1]
        rsi_channel = rsi[indices]

        # MA distance
        ma20 = pd.Series(prices).rolling(20, min_periods=1).mean().values
        ma_dist = np.where(ma20 > 1e-9, (prices - ma20) / ma20, 0.0)
        ma_dist = np.clip(ma_dist, -0.2, 0.2) / 0.4 + 0.5  # normalize to ~[0,1]
        ma_channel = ma_dist[indices]

        # Stack to (4, img_size) then tile to (4, img_size, img_size)
        channels = np.stack([close_channel, vol_channel, rsi_channel, ma_channel])
        # Repeat each row to make 2D image
        img = np.tile(channels[:, :, np.newaxis], (1, 1, img_size))
        return img.astype(np.float32)
    except Exception:
        return None


def _window_to_features(window: pd.Series, feat_dim: int = 512) -> np.ndarray | None:
    """Convert a price window to a 512-d temporal feature vector."""
    try:
        prices = window.values.astype(np.float32)
        rets = np.diff(prices, prepend=prices[0])

        # Compute various features
        features = []
        # 1. Raw returns (last 60)
        features.extend(rets[-60:].tolist())
        # 2. Rolling mean returns (5, 10, 20, 60)
        for p in [5, 10, 20, 60]:
            if len(rets) >= p:
                features.append(float(np.mean(rets[-p:])))
            else:
                features.append(0.0)
        # 3. Rolling vol (5, 10, 20, 60)
        for p in [5, 10, 20, 60]:
            if len(rets) >= p:
                features.append(float(np.std(rets[-p:])))
            else:
                features.append(0.0)
        # 4. RSI
        deltas = np.diff(prices, prepend=prices[0])
        gains = np.where(deltas > 0, deltas, 0.0)
        losses = np.where(deltas < 0, -deltas, 0.0)
        avg_gain = np.mean(gains[-14:]) if len(gains) >= 14 else np.mean(gains)
        avg_loss = np.mean(losses[-14:]) if len(losses) >= 14 else np.mean(losses)
        rs = avg_gain / (avg_loss + 1e-9)
        features.append(float(100 - (100 / (1 + rs))))
        # 5. Momentum (current / 20-day-ago - 1)
        if len(prices) >= 21:
            features.append(float(prices[-1] / prices[-21] - 1.0))
        else:
            features.append(0.0)
        # 6. Max drawdown in window
        peak = np.maximum.accumulate(prices)
        dd = (prices - peak) / (peak + 1e-9)
        features.append(float(dd.min()))
        # 7. Current price position in range
        features.append(float((prices[-1] - prices.min()) / (prices.max() - prices.min() + 1e-9)))

        # Pad or truncate to 512
        feat = np.array(features, dtype=np.float32)
        if len(feat) < feat_dim:
            feat = np.pad(feat, (0, feat_dim - len(feat)), "constant")
        else:
            feat = feat[:feat_dim]

        # Normalize
        norm = np.linalg.norm(feat)
        if norm > 1e-9:
            feat = feat / norm
        return feat
    except Exception:
        return None


def train_and_export(
    n_stocks: int = 50,
    period: str = "5y",
    epochs: int = 30,
    batch_size: int = 32,
    lr: float = 1e-3,
    val_split: float = 0.2,
) -> None:
    """Train the dual-tower model on real NSE data and export to ONNX.

    Phase 7: This now does ACTUAL training. Previously it just exported
    randomly-initialized weights.
    """
    logger.info("=" * 60)
    logger.info("Phase 7: REAL ViT Training Pipeline")
    logger.info("=" * 60)

    try:
        import torch
        import torch.nn as nn
        import torch.onnx
        from torch.utils.data import DataLoader, TensorDataset
    except ImportError:
        logger.error("PyTorch is not installed. Install: pip install torch")
        return

    # 1. Fetch data
    close = fetch_training_data(n_stocks=n_stocks, period=period)

    # 2. Generate chart windows
    images, features, labels = generate_chart_windows(close)

    # 3. Chronological train/val split (NO shuffle — prevents leakage)
    n = len(images)
    split_idx = int(n * (1 - val_split))
    X_img_train, X_img_val = images[:split_idx], images[split_idx:]
    X_feat_train, X_feat_val = features[:split_idx], features[split_idx:]
    y_train, y_val = labels[:split_idx], labels[split_idx:]

    logger.info(f"Train: {split_idx} samples | Val: {n - split_idx} samples")
    logger.info(f"Train positive ratio: {y_train.mean():.2%} | Val positive ratio: {y_val.mean():.2%}")

    # 4. Create data loaders
    train_ds = TensorDataset(
        torch.from_numpy(X_img_train),
        torch.from_numpy(X_feat_train),
        torch.from_numpy(y_train),
    )
    val_ds = TensorDataset(
        torch.from_numpy(X_img_val),
        torch.from_numpy(X_feat_val),
        torch.from_numpy(y_val),
    )
    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True, drop_last=True)
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False)

    # 5. Build model with proper initialization
    model = DualTowerModel()
    model.apply(_init_weights)  # Phase 7.3: trunc_normal_ init

    # B20-fix: Support Apple Silicon MPS (M-series GPU) in addition to CUDA.
    # Checking in priority order: CUDA → MPS → CPU.
    if torch.cuda.is_available():
        device = torch.device("cuda")
    elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        device = torch.device("mps")   # Apple Silicon GPU
    else:
        device = torch.device("cpu")
    model = model.to(device)
    logger.info(f"Training on device: {device}")
    logger.info(f"Model parameters: {sum(p.numel() for p in model.parameters()):,}")

    # 6. Loss, optimizer, scheduler
    criterion = nn.BCEWithLogitsLoss()
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)

    # 7. Training loop with early stopping
    best_val_recall = 0.0
    patience = 5
    patience_counter = 0
    output_path = PROJECT_ROOT / "artifacts" / "vit_v3_fused.onnx"
    output_path.parent.mkdir(parents=True, exist_ok=True)

    for epoch in range(epochs):
        # Train
        model.train()
        train_loss = 0.0
        n_batches = 0
        for img_batch, feat_batch, label_batch in train_loader:
            img_batch = img_batch.to(device)
            feat_batch = feat_batch.to(device)
            label_batch = label_batch.to(device)

            optimizer.zero_grad()
            _, _, fused = model(img_batch, feat_batch)
            logit = model.classify(fused)
            loss = criterion(logit.squeeze(-1), label_batch)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()

            train_loss += loss.item()
            n_batches += 1

        scheduler.step()

        # Validate
        model.eval()
        val_loss = 0.0
        val_preds = []
        val_labels = []
        with torch.no_grad():
            for img_batch, feat_batch, label_batch in val_loader:
                img_batch = img_batch.to(device)
                feat_batch = feat_batch.to(device)
                label_batch = label_batch.to(device)
                _, _, fused = model(img_batch, feat_batch)
                logit = model.classify(fused)
                loss = criterion(logit.squeeze(-1), label_batch)
                val_loss += loss.item()
                val_preds.extend(torch.sigmoid(logit.squeeze(-1)).cpu().numpy())
                val_labels.extend(label_batch.cpu().numpy())

        val_preds = np.array(val_preds)
        val_labels = np.array(val_labels)

        # Recall@k: of the top-k predicted, how many are actually positive?
        k = max(1, len(val_preds) // 4)
        top_k_idx = np.argsort(val_preds)[-k:]
        val_recall = float(val_labels[top_k_idx].mean()) if k > 0 else 0.0

        avg_train_loss = train_loss / max(1, n_batches)
        avg_val_loss = val_loss / max(1, len(val_loader))

        logger.info(
            f"Epoch {epoch+1}/{epochs} | "
            f"Train Loss: {avg_train_loss:.4f} | "
            f"Val Loss: {avg_val_loss:.4f} | "
            f"Val Recall@{k}: {val_recall:.4f} | "
            f"LR: {scheduler.get_last_lr()[0]:.6f}"
        )

        # Early stopping
        if val_recall > best_val_recall:
            best_val_recall = val_recall
            patience_counter = 0
            # Export best model
            _export_onnx(model, output_path, device)
            logger.info(f"  → New best recall {best_val_recall:.4f}, exported to {output_path.name}")
        else:
            patience_counter += 1
            if patience_counter >= patience:
                logger.info(f"Early stopping at epoch {epoch+1} (patience={patience})")
                break

    logger.info(f"Training complete. Best val recall: {best_val_recall:.4f}")
    logger.info(f"Model saved to: {output_path}")


def _init_weights(m):
    """Phase 7.3: Proper ViT initialization with trunc_normal_ std=0.02."""
    import torch.nn as nn
    if isinstance(m, nn.Linear):
        try:
            nn.init.trunc_normal_(m.weight, std=0.02)
            if m.bias is not None:
                nn.init.constant_(m.bias, 0.0)
        except Exception:
            nn.init.xavier_uniform_(m.weight)
    elif isinstance(m, nn.LayerNorm):
        nn.init.constant_(m.bias, 0.0)
        nn.init.constant_(m.weight, 1.0)
    elif isinstance(m, nn.Conv2d):
        nn.init.kaiming_normal_(m.weight, mode="fan_out")


class ChartCNN(nn.Module):
    """Phase 7: Simple CNN visual tower (more stable than full ViT for 50 stocks).

    Processes 4-channel 224x224 chart images through 4 conv blocks.
    """
    def __init__(self, output_dim=512):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(4, 32, 3, padding=1), nn.BatchNorm2d(32), nn.ReLU(), nn.MaxPool2d(2),  # 112
            nn.Conv2d(32, 64, 3, padding=1), nn.BatchNorm2d(64), nn.ReLU(), nn.MaxPool2d(2),  # 56
            nn.Conv2d(64, 128, 3, padding=1), nn.BatchNorm2d(128), nn.ReLU(), nn.MaxPool2d(2),  # 28
            nn.Conv2d(128, 256, 3, padding=1), nn.BatchNorm2d(256), nn.ReLU(), nn.AdaptiveAvgPool2d(1),
        )
        self.fc = nn.Sequential(
            nn.Flatten(),
            nn.Linear(256, output_dim),
            nn.LayerNorm(output_dim),
        )

    def forward(self, x):
        x = self.conv(x)
        return self.fc(x)


class TemporalMLP(nn.Module):
    """Phase 7: MLP temporal tower for 512-d features."""
    def __init__(self, output_dim=512):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(512, 256), nn.ReLU(), nn.Dropout(0.1),
            nn.Linear(256, 256), nn.ReLU(), nn.Dropout(0.1),
            nn.Linear(256, output_dim),
            nn.LayerNorm(output_dim),
        )

    def forward(self, x):
        return self.net(x)


class DualTowerModel(nn.Module):
    """Phase 7: Dual-tower model with LEARNABLE fusion gate.

    Previously: fixed 0.5/0.5 fusion. Now: sigmoid(learnable_param) gate.
    forward() returns 512-d embeddings for ONNX export.
    classify() returns 1-d logit for BCEWithLogitsLoss during training.
    """
    def __init__(self):
        super().__init__()
        self.visual_tower = ChartCNN(output_dim=512)
        self.temporal_tower = TemporalMLP(output_dim=512)
        # Phase 7.3: Learnable fusion gate (was fixed 0.5/0.5)
        self.fuse_gate = nn.Parameter(torch.tensor(0.0))  # sigmoid(0) = 0.5
        # Classification head (logit for BCEWithLogitsLoss) — NOT exported to ONNX
        self.classifier = nn.Sequential(
            nn.Linear(512, 128),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(128, 1),
        )

    def forward(self, image_tensor, feature_tensor):
        """Returns (visual_emb, temporal_emb, fused_emb) — all 512-d normalized.

        This is the ONNX-export interface. The 512-d fused_emb is used for
        FAISS retrieval in onnx_inference.py.
        """
        visual_emb = self.visual_tower(image_tensor)
        temporal_emb = self.temporal_tower(feature_tensor)

        # L2 normalize
        v_norm = visual_emb / (torch.norm(visual_emb, dim=1, keepdim=True) + 1e-9)
        t_norm = temporal_emb / (torch.norm(temporal_emb, dim=1, keepdim=True) + 1e-9)

        # Phase 7.3: Learnable fusion gate
        gate = torch.sigmoid(self.fuse_gate)
        fused_emb = gate * v_norm + (1 - gate) * t_norm
        fused_norm = fused_emb / (torch.norm(fused_emb, dim=1, keepdim=True) + 1e-9)

        return v_norm, t_norm, fused_norm

    def classify(self, fused_emb):
        """Compute classification logit from fused embedding (training only)."""
        return self.classifier(fused_emb)


def _export_onnx(model, output_path, device):
    """Export model to ONNX format."""
    import torch.onnx
    model.eval()
    dummy_image = torch.zeros(1, 4, 224, 224, dtype=torch.float32).to(device)
    dummy_ts = torch.zeros(1, 512, dtype=torch.float32).to(device)

    torch.onnx.export(
        model,
        (dummy_image, dummy_ts),
        str(output_path),
        input_names=["image_tensor", "feature_tensor"],
        output_names=["visual_embedding", "temporal_embedding", "fused_embedding"],
        dynamic_axes={
            "image_tensor": {0: "batch"},
            "feature_tensor": {0: "batch"},
            "visual_embedding": {0: "batch"},
            "temporal_embedding": {0: "batch"},
            "fused_embedding": {0: "batch"},
        },
        opset_version=18,
    )


if __name__ == "__main__":
    train_and_export()
