"""
workers/nightly_model_trainer.py
================================
Nightly batch job to fit the HMM Regime Detector (RS-GARCH) and GARCH(1,1) volatility models.
Saves serialized parameters to JSON with timestamp-based versioning to avoid
pickle/joblib code execution vulnerabilities.
"""

import sys
import json
import logging
import argparse
import os
from pathlib import Path
from datetime import datetime, timezone
import numpy as np
import pandas as pd

# Add project root to sys.path
sys.path.append(str(Path(__file__).resolve().parent.parent))

from math_engine.regime_detector import MarketRegimeDetector
from utils import get_provider

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


def get_versioned_path(base_dir: Path, prefix: str) -> tuple[Path, Path]:
    """Return (timestamped_path, latest_symlink_path) for versioning."""
    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    timestamped = base_dir / f"{prefix}_{ts}.json"
    latest = base_dir / f"{prefix}_latest.json"
    return timestamped, latest


def copy_to_latest(src: Path, dest: Path) -> None:
    """Copy the timestamped JSON to the 'latest' path."""
    import shutil
    shutil.copy2(src, dest)
    logger.info("Updated latest symlink/copy at %s", dest)


def get_active_provider():
    """Retrieve pluggable provider, falling back to YFinanceProvider in development."""
    provider = get_provider()
    if provider is None:
        from data_layer import YFinanceProvider
        provider = YFinanceProvider()
    
    if os.getenv("ENV") == "production":
        if provider.__class__.__name__ == "YFinanceProvider":
            raise RuntimeError(
                "FATAL: ENV=production but data provider is YFinanceProvider. "
                "Set DATA_VENDOR env var to a live institutional feed."
            )
    return provider


def train_hmm_regime(models_dir: Path) -> None:
    """Train the HMM regime model on Nifty 500 proxy and save as JSON."""
    logger.info("--- Starting HMM Regime Training ---")
    
    ticker = "^CRSLDX" # Nifty 500
    logger.info("Fetching %s for HMM training...", ticker)
    
    provider = get_active_provider()
    df = provider.get_prices([ticker], period="5y")
    if df.empty:
        logger.warning("%s failed, falling back to ^NSEI", ticker)
        ticker = "^NSEI"
        df = provider.get_prices([ticker], period="5y")
        
    if df.empty:
        raise RuntimeError("Failed to fetch broad market index for HMM training.")
        
    # Extract close column
    if isinstance(df.columns, pd.MultiIndex):
        if "Close" in df.columns.levels[0] and ticker in df.columns.levels[1]:
            close_col = df[("Close", ticker)]
        else:
            close_col = df.xs("Close", axis=1, level=0).iloc[:, 0]
    else:
        close_col = df["Close"]
        
    hist_df = pd.DataFrame({"close": close_col.dropna()})
    
    hmm = MarketRegimeDetector(n_iter=500)
    hmm.fit(hist_df)
    
    ts_path, latest_path = get_versioned_path(models_dir, "regime_hmm")
    hmm.save_json(ts_path)
    copy_to_latest(ts_path, latest_path)


def fit_garch_mle(returns: np.ndarray) -> dict:
    """Fit GARCH(1,1) using arch library — numerically stable MLE."""
    from arch import arch_model
    
    rets_pct = returns * 100.0
    model = arch_model(rets_pct, vol='Garch', p=1, q=1,
                       dist='StudentsT',
                       rescale=False)
    try:
        res = model.fit(disp='off', show_warning=False)
        params = res.params

        alpha = float(params.get('alpha[1]', 0.05))
        beta  = float(params.get('beta[1]', 0.85))
        omega = float(params.get('omega', 1e-4))
        nu    = float(params.get('nu', 6.0))

        # Parameter validation
        if alpha + beta > 0.995 or omega <= 0 or alpha < 0 or beta < 0:
            raise ValueError(f"Invalid GARCH parameters: alpha={alpha:.4f}, beta={beta:.4f}, omega={omega:.6f}")

        # Rescale omega back to decimal returns space
        return {
            "omega": omega / (100.0 ** 2),
            "alpha": alpha,
            "beta":  beta,
            "nu":    nu,
            "converged": True
        }
    except Exception as e:
        logger.warning("GARCH fit failed (%s). Using robust heuristic fallback.", e)
        var = float(np.var(returns))
        return {
            "omega": float(var * 0.05),
            "alpha": 0.05,
            "beta": 0.85,
            "nu": 6.0,
            "converged": False
        }


def train_garch_vols(models_dir: Path, limit: int = 200) -> None:
    """
    Train GARCH(1,1) models for the NSE universe and save parameters.
    BUG-N1 FIX: expanded from 5 hardcoded large caps to Nifty 500 universe.
    GARCH params are needed for every stock the optimizer selects — fitting
    only 5 stocks means 95% of optimizer selections fall back to sample variance.
    """
    logger.info("--- Starting GARCH(1,1) Training ---")

    # Dynamically load NSE universe from the same source as the optimizer
    try:
        from data.universe import fetch_nse_tickers
        all_tickers = fetch_nse_tickers()
        # Prioritise Nifty 500 constituents; fall back to full NSE list
        tickers = all_tickers[:limit] if all_tickers else []
        logger.info("Loaded %d NSE tickers for GARCH training", len(tickers))
    except Exception as e:
        logger.warning("Could not load NSE universe (%s). Using Nifty 50 fallback.", e)
        tickers = [
            "RELIANCE.NS", "TCS.NS", "HDFCBANK.NS", "INFY.NS", "ICICIBANK.NS",
            "LT.NS", "SBIN.NS", "BHARTIARTL.NS", "HCLTECH.NS", "WIPRO.NS",
            "AXISBANK.NS", "KOTAKBANK.NS", "TITAN.NS", "BAJFINANCE.NS", "MARUTI.NS",
            "ASIANPAINT.NS", "NTPC.NS", "POWERGRID.NS", "COALINDIA.NS", "ONGC.NS",
            "TRENT.NS", "BEL.NS", "PERSISTENT.NS", "COFORGE.NS", "DIXON.NS",
            "ASTRAL.NS", "APARINDS.NS", "AIAENG.NS", "CARBORUNIV.NS", "ANUP.NS",
        ]

    params_dict = {}
    provider = get_active_provider()
    failed = 0

    for t in tickers:
        try:
            df = provider.get_prices([t], period="3y")
            if df.empty:
                continue

            if isinstance(df.columns, pd.MultiIndex):
                if "Close" in df.columns.levels[0] and t in df.columns.levels[1]:
                    close_col = df[("Close", t)]
                else:
                    close_col = df.xs("Close", axis=1, level=0).iloc[:, 0]
            else:
                close_col = df.get("Close", df.iloc[:, 0])

            close = close_col.dropna()
            if len(close) < 120:
                continue

            rets = np.log(close / close.shift(1)).dropna().values
            params = fit_garch_mle(rets)

            # Only save converged fits with valid parameters
            if params.get("converged", False):
                params_dict[t] = params
                logger.debug("GARCH %s: α=%.3f β=%.3f ω=%.6f",
                             t, params["alpha"], params["beta"], params["omega"])
            else:
                failed += 1

        except Exception as e:
            logger.warning("Failed to fit GARCH for %s: %s", t, e)
            failed += 1

    logger.info("GARCH training complete: %d fitted, %d failed/skipped out of %d",
                len(params_dict), failed, len(tickers))

    payload = {
        "metadata": {
            "version": "2.0_garch",
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
            "count": len(params_dict)
        },
        "parameters": params_dict
    }
    
    ts_path, latest_path = get_versioned_path(models_dir, "garch_params")
    with open(ts_path, "w") as f:
        json.dump(payload, f, indent=2)
    logger.info("Saved GARCH JSON -> %s", ts_path)
    
    copy_to_latest(ts_path, latest_path)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--models-dir", type=str, default="models", help="Directory to save JSON models")
    parser.add_argument("--skip-hmm", action="store_true")
    parser.add_argument("--skip-garch", action="store_true")
    args = parser.parse_args()
    
    mdir = Path(args.models_dir)
    mdir.mkdir(parents=True, exist_ok=True)
    
    if not args.skip_hmm:
        train_hmm_regime(mdir)
        
    if not args.skip_garch:
        train_garch_vols(mdir)
        
    logger.info("Nightly Model Trainer completed successfully.")
