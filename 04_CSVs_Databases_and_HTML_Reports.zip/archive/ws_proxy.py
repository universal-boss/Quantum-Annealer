import asyncio
import websockets
import urllib.parse
import threading

async def proxy(client_ws, path):
    try:
        # Construct the target URI
        target_uri = f"wss://data.tradingview.com{path}"
        
        # Connect to TradingView with spoofed Origin
        async with websockets.connect(
            target_uri, 
            origin="https://www.tradingview.com",
            extra_headers={
                "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            }
        ) as server_ws:
            async def client_to_server():
                try:
                    async for message in client_ws:
                        await server_ws.send(message)
                except Exception:
                    pass
            async def server_to_client():
                try:
                    async for message in server_ws:
                        await client_ws.send(message)
                except Exception:
                    pass
            
            await asyncio.gather(
                client_to_server(),
                server_to_client()
            )
    except Exception as e:
        print(f"WS Proxy Error: {e}")

def start_ws_proxy():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    start_server = websockets.serve(proxy, "127.0.0.1", 8089)
    loop.run_until_complete(start_server)
    print("WebSocket Proxy running on ws://127.0.0.1:8089")
    loop.run_forever()

if __name__ == "__main__":
    start_ws_proxy()
