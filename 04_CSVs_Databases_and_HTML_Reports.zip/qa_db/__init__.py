"""
qa_db/__init__.py
=================
Institutional-grade local database warehouse module.
Provides centralized access to SQLite and Postgres storage drivers.
"""
import os
import threading
from qa_db.sqlite_store import SQLiteStore

_GLOBAL_STORE = None
# AUDIT-FIX (Round 8, B10 — Part 2B): get_store() was a check-then-act race —
# two threads (e.g. optimizer workers + UI) calling get_store() concurrently
# could both see _GLOBAL_STORE is None and construct TWO store instances; the
# loser's connections/pools leaked and DB writes interleaved unpredictably.
# Store construction is now serialized under a module lock (double-checked).
_STORE_LOCK = threading.Lock()

def _runtime_dir() -> str:
    """AUDIT-FIX (Round 5, 2-e-3): resolve RUNTIME_DIR without a hard utils
    import. utils.py calls get_store() at *its* import time, before defining
    RUNTIME_DIR — the resulting 'cannot import name from partially
    initialized module' ImportError made the first get_store() call fail
    silently (defeating the production fail-fast and routing DB writes to
    fallbacks). Fall back to utils' documented default directory."""
    try:
        from utils import RUNTIME_DIR  # late import to break cycle
        return str(RUNTIME_DIR)
    except Exception:
        from pathlib import Path
        import os
        return os.environ.get(
            "QA_DB_DIR",
            str(Path.home() / ".quantum_annealer_pro_v17"),
        )


def get_store():
    global _GLOBAL_STORE
    if _GLOBAL_STORE is None:
        with _STORE_LOCK:
            if _GLOBAL_STORE is None:  # double-checked under lock (B10)
                _build_global_store()
    return _GLOBAL_STORE


def _build_global_store():
    """Constructs the process-global store exactly once (caller holds
    _STORE_LOCK — see the B10 note above)."""
    global _GLOBAL_STORE
    import os

    env = os.environ.get("ENV", "development").lower()
    if env == "production":
        from qa_db.postgres_store import PostgresStore
        # Phase 5.2: Removed the hardcoded default DSN
        # "postgresql://user:password@localhost:5432/quantdb".
        # If QA_DB_URI is missing in production, the app would silently fall
        # back to publicly-known credentials — a critical security hole.
        # Now: fail fast with a clear error message.
        pg_dsn = os.environ.get("QA_DB_URI")
        if not pg_dsn:
            raise RuntimeError(
                "QA_DB_URI environment variable is required in production. "
                "Set it to your Postgres DSN (e.g. postgresql://user:pass@host:5432/db). "
                "Do NOT embed credentials in source code."
            )
        _GLOBAL_STORE = PostgresStore(dsn=pg_dsn)
    else:
        db_dir = os.path.expanduser(os.environ.get("QA_DB_DIR", _runtime_dir()))
        os.makedirs(db_dir, exist_ok=True)
        db_path = os.path.join(db_dir, "quantum_annealer_pro.db")
        from qa_db.sqlite_store import SQLiteStore
        _GLOBAL_STORE = SQLiteStore(db_path)

def set_store(store):
    global _GLOBAL_STORE
    with _STORE_LOCK:
        _GLOBAL_STORE = store
