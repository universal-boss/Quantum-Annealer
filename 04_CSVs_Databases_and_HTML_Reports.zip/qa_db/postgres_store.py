"""
qa_db/postgres_store.py
========================
PostgreSQL database driver wrapper for remote enterprise portfolio data warehousing.
Mirrors SQLiteStore interface for transparent cloud database failover.

C6-fix (2026-06-29): rewritten to use enterprise.postgres_pool.DatabaseConnectionPool
instead of a single shared self.conn across all Qt worker threads. Concurrent transactions
on the same psycopg2 connection were corrupting each other (thread A's commit() committed
thread B's in-flight work). Each method now leases its own connection via the
`with self._pool.connection() as conn:` context manager.
"""
from __future__ import annotations

import logging
import json
import time
import threading
from datetime import datetime
from typing import Any, Dict, List, Optional
from qa_db.sqlite_store import SQLiteStore

try:
    import pandas as pd
except ImportError:
    pd = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)


class PostgresStore(SQLiteStore):
    """Enterprise-grade PostgreSQL database driver.

    Acts as a direct drop-in replacement for SQLiteStore. Connects to local SQLite
    warehouse as a failover if PostgreSQL connection parameters are blank or fail.

    Connection management is pool-based: each method leases a fresh connection from
    `self._pool` via `with self._pool.connection() as conn:`. The context manager
    handles commit-on-success / rollback-on-exception and returns the connection
    to the pool automatically.
    """

    def __init__(self, dsn: Optional[str] = None) -> None:
        self._is_pg = False
        self._pool = None
        self.dsn = dsn
        # AUDIT-FIX (Round 8, B11 — Part 2B): serializes all pool-state
        # mutation (reconnect / shutdown) — see _handle_pg_failure.
        self._pool_lock = threading.RLock()

        # Always initialize SQLiteStore base so self.db_path and fallback local DB exist
        # AUDIT-FIX (Round 5, 2-e-3): tolerate a partially-initialized utils module
        # (utils.py imports qa_db before defining RUNTIME_DIR). Falling back to
        # the documented default keeps the production fail-fast path reachable
        # instead of raising ImportError inside a swallowed except.
        import os
        try:
            from utils import RUNTIME_DIR
        except Exception:
            from pathlib import Path
            RUNTIME_DIR = Path.home() / ".quantum_annealer_pro_v17"
        db_dir = os.path.expanduser(os.environ.get("QA_DB_DIR", str(RUNTIME_DIR)))
        os.makedirs(db_dir, exist_ok=True)
        db_path = os.path.join(db_dir, "quantum_annealer_pro.db")
        super().__init__(db_path)

        if dsn:
            try:
                from enterprise.postgres_pool import DatabaseConnectionPool
                self._pool = DatabaseConnectionPool(dsn, min_connections=2, max_connections=10)
                # Probe the pool with a trivial query to confirm it works
                with self._pool.connection() as conn:
                    with conn.cursor() as cur:
                        cur.execute("SELECT 1")
                self._is_pg = True
                self._init_pg_db()
                logger.info("[PostgresStore] Connected successfully to PostgreSQL remote cloud via pool.")
            except Exception as e:
                logger.warning("[PostgresStore] PG connection failed: %s. Safely fell back to SQLite warehouse.", e)
                self._pool = None
                self._is_pg = False

    # C6-fix: backward-compat shim. Old code reads `self.conn` and `if not self.conn:`.
    # We expose `conn` as a property that returns None when PG is unavailable, so
    # `if not self.conn:` guards still work. Direct `self.conn.cursor()` calls have
    # all been migrated to `with self._pool.connection() as conn:`.
    @property
    def name(self) -> str:
        """AUDIT-FIX (Round 5, 2-e-8): report the *effective* backend so the
        DB-switch dialog labels the active store correctly (PG vs SQLite
        fallback) instead of crashing on a missing attribute."""
        return "PostgreSQL" if self._is_pg else "SQLite (fallback)"

    @property
    def conn(self):
        if not self._is_pg or not self._pool:
            return None
        # Returning a truthy non-None marker so `if not self.conn:` evaluates False.
        # Callers should NOT use this for actual cursor operations — use
        # `with self._pool.connection() as conn:` instead.
        return self._pool

    def close(self):
        """H12-fix: explicitly close the pool on shutdown. Previously the connection
        was never closed, leaking server-side Postgres backend processes."""
        # AUDIT-FIX (Round 8, B11): shutdown also serialized under the pool lock.
        with self._pool_lock:
            if self._pool is not None:
                try:
                    self._pool.close_all()
                except Exception as e:
                    logger.warning("[PostgresStore] Error closing pool: %s", e)
                self._pool = None
            self._is_pg = False

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass

    def _handle_pg_failure(self, context: str, exc: Exception):
        """M14-fix: on PG failure, log loudly and mark _is_pg=False so subsequent
        calls fall back to SQLite. Previously reconnect failures were silently
        swallowed and _is_pg stayed True, causing silent PG→SQLite degradation.

        AUDIT-FIX (Round 8, B11 — Part 2B): this handler mutates `_pool` and
        `_is_pg` UNLOCKED — concurrent failure paths could interleave (one
        thread reading a half-swapped pool) and every reconnect LEAKED the old
        pool's server-side connections (close() was never called on it).
        Pool-state mutation is now serialized under `_pool_lock`, and the old
        pool is explicitly closed before replacement.
        """
        logger.error("[PostgresStore] PostgreSQL %s failed: %s. Falling back to SQLite.", context, exc)
        with self._pool_lock:
            # Try to reinitialize the pool once; if that fails, mark PG as down.
            try:
                if self.dsn:
                    from enterprise.postgres_pool import DatabaseConnectionPool
                    _old_pool = self._pool
                    self._pool = DatabaseConnectionPool(self.dsn, min_connections=2, max_connections=10)
                    with self._pool.connection() as conn:
                        with conn.cursor() as cur:
                            cur.execute("SELECT 1")
                    # Pool recovered — keep _is_pg True; close the OLD pool so its
                    # server-side connections don't leak (B11).
                    if _old_pool is not None and _old_pool is not self._pool:
                        try:
                            _old_pool.close_all()
                        except Exception as _old_close_err:
                            logger.warning("[PostgresStore] Old pool close failed (leaked connections possible): %s", _old_close_err)
                    logger.info("[PostgresStore] PostgreSQL pool recovered after %s failure.", context)
                    return
            except Exception as recover_exc:
                logger.error("[PostgresStore] PG reconnect also failed: %s. Marking PG as down.", recover_exc)
            # Reconnect failed — pin _is_pg False so we don't keep retrying every call
            self._is_pg = False
            if self._pool is not None:
                try:
                    self._pool.close_all()
                except Exception:
                    pass
            self._pool = None

    def _init_pg_db(self) -> None:
        """Create tables in PostgreSQL remote cloud if they do not exist."""
        if not self._is_pg or not self._pool:
            return
        try:
            with self._pool.connection() as conn:
                with conn.cursor() as cursor:
                    # 1. Runs Table
                    cursor.execute("""
                        CREATE TABLE IF NOT EXISTS runs (
                            id VARCHAR(255) PRIMARY KEY,
                            timestamp INTEGER,
                            regime VARCHAR(100),
                            vix REAL,
                            n_stocks INTEGER,
                            solver VARCHAR(100),
                            energy REAL,
                            payload TEXT,
                            config TEXT,
                            cfg_hash VARCHAR(255),
                            ann_return REAL,
                            sharpe REAL
                        )
                    """)
                    # 2. Notes Table
                    cursor.execute("""
                        CREATE TABLE IF NOT EXISTS notes (
                            run_id VARCHAR(255) PRIMARY KEY,
                            text TEXT,
                            updated_at INTEGER
                        )
                    """)
                    # 3. Watchlists Table
                    cursor.execute("""
                        CREATE TABLE IF NOT EXISTS watchlists (
                            id SERIAL PRIMARY KEY,
                            tickers TEXT,
                            updated_at INTEGER
                        )
                    """)
                    # 4. IC Table
                    cursor.execute("""
                        CREATE TABLE IF NOT EXISTS ic_observations (
                            id SERIAL PRIMARY KEY,
                            ticker VARCHAR(50),
                            observation_date VARCHAR(50),
                            metric_name VARCHAR(100),
                            value REAL
                        )
                    """)
                    # 5. OOS Table
                    cursor.execute("""
                        CREATE TABLE IF NOT EXISTS oos_results (
                            id SERIAL PRIMARY KEY,
                            run_id VARCHAR(255),
                            date VARCHAR(50),
                            portfolio_return REAL,
                            benchmark_return REAL,
                            is_sharpe REAL,
                            oos_sharpe REAL
                        )
                    """)

                    # 6. Custom Universes Table
                    cursor.execute("""
                        CREATE TABLE IF NOT EXISTS custom_universes (
                            name VARCHAR(255) PRIMARY KEY,
                            tickers TEXT,
                            updated_at INTEGER
                        )
                    """)

                    # 7. Bi-Temporal Price History Table
                    cursor.execute("""
                        CREATE TABLE IF NOT EXISTS bi_temporal_price_history (
                            ticker VARCHAR(50),
                            date VARCHAR(50),
                            system_timestamp VARCHAR(100),
                            open REAL,
                            high REAL,
                            low REAL,
                            close REAL,
                            volume REAL,
                            adjustment_factor REAL,
                            PRIMARY KEY (ticker, date, system_timestamp)
                        )
                    """)

                    # 8. Strategy Profiles Table (AUDIT-FIX Round 5, 2-e-4)
                    cursor.execute("""
                        CREATE TABLE IF NOT EXISTS strategy_profiles (
                            name VARCHAR(255) PRIMARY KEY,
                            cfg TEXT,
                            updated_at INTEGER
                        )
                    """)

                    # Dynamic Schema Migration: check if columns exist in PostgreSQL
                    cursor.execute("""
                        SELECT column_name
                        FROM information_schema.columns
                        WHERE table_name = 'oos_results'
                    """)
                    columns = [row[0] for row in cursor.fetchall()]
                    if columns:
                        if "is_sharpe" not in columns:
                            cursor.execute("ALTER TABLE oos_results ADD COLUMN is_sharpe REAL")
                        if "oos_sharpe" not in columns:
                            cursor.execute("ALTER TABLE oos_results ADD COLUMN oos_sharpe REAL")

                    # AUDIT-FIX (Round 5, 2-e-6): runs metrics migration (parity
                    # with SQLiteStore) so 'Ann Ret' is available on the PG path.
                    cursor.execute("""
                        SELECT column_name
                        FROM information_schema.columns
                        WHERE table_name = 'runs'
                    """)
                    run_cols = [row[0] for row in cursor.fetchall()]
                    if run_cols:
                        if "ann_return" not in run_cols:
                            cursor.execute("ALTER TABLE runs ADD COLUMN ann_return REAL")
                        if "sharpe" not in run_cols:
                            cursor.execute("ALTER TABLE runs ADD COLUMN sharpe REAL")

                    # Add indexes for bi-temporal query performance
                    cursor.execute("CREATE INDEX IF NOT EXISTS idx_pg_bi_temporal_ticker_date ON bi_temporal_price_history(ticker, date)")
                    cursor.execute("CREATE INDEX IF NOT EXISTS idx_pg_bi_temporal_system_ts ON bi_temporal_price_history(system_timestamp)")

                logger.info("[PostgresStore] PostgreSQL Enterprise tables initialized successfully.")
        except Exception as e:
            logger.error("[PostgresStore] PostgreSQL initialization failed: %s", e)
            self._handle_pg_failure("_init_pg_db", e)

    def save_run(
        self,
        payload: dict,
        config: dict,
        regime_info: Optional[dict] = None,
        vix: Optional[float] = None,
        n_stocks: Optional[int] = None,
        solver: Optional[str] = None,
        energy: Optional[float] = None,
        cfg_hash: Optional[str] = None,
        **kwargs
    ) -> bool:
        # AUDIT-FIX (Round 5, 2-e-5): accept the caller's india_vix kwarg.
        if vix is None:
            vix = kwargs.get("india_vix")
        # Always write to SQLite fallback first for local data redundancy
        res_sqlite = super().save_run(payload, config, regime_info, vix, n_stocks, solver, energy, cfg_hash, **kwargs)

        if not self._is_pg or not self._pool:
            return res_sqlite

        try:
            # AUDIT-FIX (Round 8, B12 — Part 2B): run_id and timestamp were
            # computed from TWO separate time.time() calls at 1-second
            # resolution — two runs in the same second generated the SAME
            # run_id and the ON CONFLICT upsert silently OVERWROTE the first
            # run. A single nanosecond clock read now sources BOTH values:
            # the timestamp stays second-granular (schema-compat) while the
            # run_id carries nanosecond precision, making collisions
            # practically impossible.
            _now_ns = time.time_ns()
            run_id = payload.get("run_id") or f"run_{_now_ns}"
            timestamp = _now_ns // 1_000_000_000

            regime = "Unknown"
            if regime_info and isinstance(regime_info, dict):
                regime = regime_info.get("Regime", "Unknown")
            elif isinstance(regime_info, str):
                regime = regime_info

            clean_payload = {
                "selected": payload.get("selected", []),
                "weights": payload.get("weights", {}),
                "portfolio_health": payload.get("portfolio_health", {}),
            }

            # AUDIT-FIX (Round 5, 2-e-6): probe backtest metrics (same keys as
            # SQLiteStore) for the PG runs columns.
            _bt = payload.get("backtest") if isinstance(payload, dict) else None
            _bt = _bt if isinstance(_bt, dict) else {}
            _ar = _bt.get("Annual Return", _bt.get("Ann Return"))
            _sh = _bt.get("Sharpe Ratio")
            _pg_ann_return = float(_ar) if isinstance(_ar, (int, float)) else None
            _pg_sharpe = float(_sh) if isinstance(_sh, (int, float)) else None

            with self._pool.connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute("""
                        INSERT INTO runs (id, timestamp, regime, vix, n_stocks, solver, energy, payload, config, cfg_hash, ann_return, sharpe)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                        ON CONFLICT (id) DO UPDATE SET
                            timestamp = EXCLUDED.timestamp,
                            regime = EXCLUDED.regime,
                            vix = EXCLUDED.vix,
                            n_stocks = EXCLUDED.n_stocks,
                            solver = EXCLUDED.solver,
                            energy = EXCLUDED.energy,
                            payload = EXCLUDED.payload,
                            config = EXCLUDED.config,
                            cfg_hash = EXCLUDED.cfg_hash,
                            ann_return = EXCLUDED.ann_return,
                            sharpe = EXCLUDED.sharpe
                    """, (
                        run_id,
                        timestamp,
                        regime,
                        vix,
                        n_stocks or len(payload.get("selected", [])),
                        solver or "SimulatedAnnealing",
                        energy,
                        json.dumps(clean_payload),
                        json.dumps(config),
                        cfg_hash,
                        # AUDIT-FIX (Round 5, 2-e-6): metrics parity with SQLiteStore
                        _pg_ann_return,
                        _pg_sharpe
                    ))
                logger.info("[PostgresStore] Saved run to PostgreSQL cloud database: %s", run_id)
            return True
        except Exception as e:
            self._handle_pg_failure("save_run", e)
            return res_sqlite

    def load_history(self, limit: int = 30) -> List[dict]:
        if not self._is_pg or not self._pool:
            return super().load_history(limit)
        try:
            with self._pool.connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute("""
                        SELECT id, timestamp, regime, vix, n_stocks, solver, energy, cfg_hash
                        FROM runs
                        ORDER BY timestamp DESC
                        LIMIT %s
                    """, (limit,))
                    rows = cursor.fetchall()
                    result = []
                    for r in rows:
                        dt = datetime.fromtimestamp(r[1])
                        result.append({
                            "Run ID": r[0],
                            "Date": dt.strftime("%Y-%m-%d"),
                            "Time": dt.strftime("%H:%M:%S"),
                            "Regime": r[2],
                            "VIX": r[3] if r[3] is not None else 15.0,
                            "Stocks": r[4],
                            "Solver": r[5],
                            "Energy": round(r[6], 4) if r[6] is not None else 0.0,
                            "CfgHash": r[7] or "n/a"
                        })
                    return result
        except Exception as e:
            self._handle_pg_failure("load_history", e)
            return super().load_history(limit)

    def save_note(self, run_id: str, text: str) -> bool:
        res_sqlite = super().save_note(run_id, text)
        if not self._is_pg or not self._pool:
            return res_sqlite
        try:
            with self._pool.connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute("""
                        INSERT INTO notes (run_id, text, updated_at)
                        VALUES (%s, %s, %s)
                        ON CONFLICT (run_id) DO UPDATE SET
                            text = EXCLUDED.text,
                            updated_at = EXCLUDED.updated_at
                    """, (run_id, text, int(time.time())))
            return True
        except Exception as e:
            self._handle_pg_failure("save_note", e)
            return res_sqlite

    def load_note(self, run_id: str) -> str:
        if not self._is_pg or not self._pool:
            return super().load_note(run_id)
        try:
            with self._pool.connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute("SELECT text FROM notes WHERE run_id = %s", (run_id,))
                    row = cursor.fetchone()
                    return row[0] if row else ""
        except Exception as e:
            self._handle_pg_failure("load_note", e)
            return super().load_note(run_id)

    def save_ic_observations(self, observations: list) -> bool:
        """Save historical factor information coefficient observations to PG and fallback SQLite."""
        # Always write to SQLite fallback first
        res_sqlite = super().save_ic_observations(observations)
        if not self._is_pg or not self._pool:
            return res_sqlite

        if not observations:
            return True

        valid_obs = []
        for obs in observations:
            if not isinstance(obs, dict):
                continue
            ticker = obs.get("ticker")
            obs_date = obs.get("date")
            metric = obs.get("metric")
            val = obs.get("value")

            # Row level validation
            if not ticker or not isinstance(ticker, str):
                continue
            if not obs_date or not isinstance(obs_date, str):
                continue
            if not metric or not isinstance(metric, str):
                continue
            try:
                if val is None:
                    continue
                val_float = float(val)
                import math
                if math.isnan(val_float) or math.isinf(val_float):
                    continue
            except (ValueError, TypeError):
                continue

            valid_obs.append((ticker, obs_date, metric, val_float))

        if not valid_obs:
            return True

        try:
            with self._pool.connection() as conn:
                with conn.cursor() as cursor:
                    try:
                        cursor.executemany("""
                            INSERT INTO ic_observations (ticker, observation_date, metric_name, value)
                            VALUES (%s, %s, %s, %s)
                        """, valid_obs)
                    except Exception as ex:
                        # The pool's context manager will rollback; re-raise so it does
                        raise ex
            return True
        except Exception as e:
            self._handle_pg_failure("save_ic_observations", e)
            return res_sqlite

    def save_oos_result(
        self,
        run_id: Optional[str] = None,
        date: Optional[str] = None,
        port_ret: Optional[float] = None,
        bench_ret: Optional[float] = None,
        oos_result: Optional[dict] = None,
        regime: Optional[str] = None,
        log_cb = None,
        **kwargs
    ) -> bool:
        """Save Out-of-Sample forward test metrics to PostgreSQL remote and fallback SQLite."""
        # Always write to SQLite fallback first for local data redundancy
        res_sqlite = super().save_oos_result(run_id, date, port_ret, bench_ret, oos_result, regime, log_cb, **kwargs)

        if not self._is_pg or not self._pool:
            return res_sqlite

        try:
            def _safe_float(val):
                import math
                if val is None:
                    return None
                try:
                    f = float(str(val).strip())
                    return None if (math.isnan(f) or math.isinf(f)) else f
                except Exception:
                    return None

            # Generate a run_id if not present
            if not run_id:
                run_id = f"run_{int(time.time())}"

            # If oos_result dict is provided, extract metrics from it
            if oos_result and isinstance(oos_result, dict):
                port_ret = oos_result.get("OOS Sharpe")
                bench_ret = oos_result.get("IS Sharpe")
                date = str(oos_result.get("OOS Period", datetime.now().strftime("%Y-%m-%d")))

            # Apply _safe_float unconditionally to normalize both positional/keyword inputs
            port_ret = _safe_float(port_ret)
            bench_ret = _safe_float(bench_ret)

            if date is None:
                date = datetime.now().strftime("%Y-%m-%d")

            with self._pool.connection() as conn:
                with conn.cursor() as cursor:
                    # AUDIT-FIX (Round 16, REG-1): the Round 13 SEC-5 fix was
                    # silently reverted in a later merge — Sharpe values were
                    # again written into portfolio_return / benchmark_return
                    # (the exact B13 data-model corruption the SQLite path
                    # fixed). port_ret/bench_ret hold SHARPE values here (see
                    # oos_result extraction above): Sharpe metrics go ONLY to
                    # the is_sharpe / oos_sharpe columns; return columns stay
                    # NULL unless genuine returns are supplied.
                    cursor.execute("""
                        INSERT INTO oos_results (run_id, date, portfolio_return, benchmark_return, is_sharpe, oos_sharpe)
                        VALUES (%s, %s, %s, %s, %s, %s)
                    """, (run_id, date, None, None, bench_ret, port_ret))
                if log_cb:
                    log_cb(f"[PG] OOS result saved successfully to remote: IS Sharpe={bench_ret}, OOS Sharpe={port_ret}")
            return True
        except Exception as e:
            if log_cb:
                log_cb(f"[PG] save_oos_result failed: {e}")
            self._handle_pg_failure("save_oos_result", e)
            return res_sqlite

    def save_watchlist(self, tickers_str: str) -> bool:
        """Save the active workspace ticker watchlist."""
        if not self._is_pg:
            return super().save_watchlist(tickers_str)
        try:
            with self._pool.connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute("""
                        INSERT INTO watchlists (tickers, updated_at)
                        VALUES (%s, %s)
                    """, (tickers_str, int(time.time())))
                    return True
        except Exception as e:
            logger.error("[PostgresStore] save_watchlist failed: %s", e)
            self._handle_pg_failure("save_watchlist", e)
            return super().save_watchlist(tickers_str)

    def load_watchlist(self) -> str:
        """Load the most recently saved workspace ticker watchlist."""
        if not self._is_pg:
            return super().load_watchlist()
        try:
            with self._pool.connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute("SELECT tickers FROM watchlists ORDER BY id DESC LIMIT 1")
                    row = cursor.fetchone()
                    return row[0] if row else ""
        except Exception as e:
            logger.error("[PostgresStore] load_watchlist failed: %s", e)
            self._handle_pg_failure("load_watchlist", e)
            return super().load_watchlist()

    def save_universe(self, name: str, tickers: str) -> bool:
        """Save a named custom universe (comma-separated symbols)."""
        if not self._is_pg:
            return super().save_universe(name, tickers)
        try:
            with self._pool.connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute("""
                        INSERT INTO custom_universes (name, tickers, updated_at)
                        VALUES (%s, %s, %s)
                        ON CONFLICT (name) DO UPDATE SET tickers = EXCLUDED.tickers, updated_at = EXCLUDED.updated_at
                    """, (name, tickers, int(time.time())))
                    return True
        except Exception as e:
            logger.error("[PostgresStore] save_universe failed: %s", e)
            self._handle_pg_failure("save_universe", e)
            return super().save_universe(name, tickers)

    def load_universe(self, name: str) -> str:
        """Load a named custom universe's symbols."""
        if not self._is_pg:
            return super().load_universe(name)
        try:
            with self._pool.connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute("SELECT tickers FROM custom_universes WHERE name = %s", (name,))
                    row = cursor.fetchone()
                    return row[0] if row else ""
        except Exception as e:
            logger.error("[PostgresStore] load_universe failed: %s", e)
            self._handle_pg_failure("load_universe", e)
            return super().load_universe(name)

    def list_universes(self) -> List[str]:
        """List all saved custom universe names."""
        if not self._is_pg:
            return super().list_universes()
        try:
            with self._pool.connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute("SELECT name FROM custom_universes ORDER BY name ASC")
                    return [row[0] for row in cursor.fetchall()]
        except Exception as e:
            logger.error("[PostgresStore] list_universes failed: %s", e)
            self._handle_pg_failure("list_universes", e)
            return super().list_universes()

    def delete_universe(self, name: str) -> bool:
        """Delete a named custom universe."""
        if not self._is_pg:
            return super().delete_universe(name)
        try:
            with self._pool.connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute("DELETE FROM custom_universes WHERE name = %s", (name,))
                    return True
        except Exception as e:
            logger.error("[PostgresStore] delete_universe failed: %s", e)
            self._handle_pg_failure("delete_universe", e)
            return super().delete_universe(name)

    # ── Strategy Profiles (AUDIT-FIX Round 5, 2-e-4) ──────────────────────────
    # PG-path overrides; the inherited SQLiteStore methods serve as fallback.

    def save_profile(self, name: str, cfg: dict) -> bool:
        """Persist a named strategy-configuration snapshot to PG (SQLite fallback)."""
        res_sqlite = super().save_profile(name, cfg)
        if not self._is_pg:
            return res_sqlite
        try:
            with self._pool.connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute("""
                        INSERT INTO strategy_profiles (name, cfg, updated_at)
                        VALUES (%s, %s, %s)
                        ON CONFLICT (name) DO UPDATE SET
                            cfg = EXCLUDED.cfg,
                            updated_at = EXCLUDED.updated_at
                    """, (name, json.dumps(cfg, default=str), int(time.time())))
                    return True
        except Exception as e:
            logger.error("[PostgresStore] save_profile failed: %s", e)
            self._handle_pg_failure("save_profile", e)
            return res_sqlite

    def load_profile(self, name: str) -> Optional[dict]:
        """Load a saved strategy-configuration snapshot by name from PG."""
        if not self._is_pg:
            return super().load_profile(name)
        try:
            with self._pool.connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute("SELECT cfg FROM strategy_profiles WHERE name = %s", (name,))
                    row = cursor.fetchone()
                    if not row or not row[0]:
                        return None
                    return json.loads(row[0])
        except Exception as e:
            logger.error("[PostgresStore] load_profile failed: %s", e)
            self._handle_pg_failure("load_profile", e)
            return super().load_profile(name)

    def list_profiles(self) -> List[str]:
        """List all saved strategy-profile names from PG."""
        if not self._is_pg:
            return super().list_profiles()
        try:
            with self._pool.connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute("SELECT name FROM strategy_profiles ORDER BY name ASC")
                    return [row[0] for row in cursor.fetchall()]
        except Exception as e:
            logger.error("[PostgresStore] list_profiles failed: %s", e)
            self._handle_pg_failure("list_profiles", e)
            return super().list_profiles()

    def delete_profile(self, name: str) -> bool:
        """Delete a saved strategy profile by name from PG."""
        if not self._is_pg:
            return super().delete_profile(name)
        try:
            with self._pool.connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute("DELETE FROM strategy_profiles WHERE name = %s", (name,))
                    return True
        except Exception as e:
            logger.error("[PostgresStore] delete_profile failed: %s", e)
            self._handle_pg_failure("delete_profile", e)
            return super().delete_profile(name)

    def save_pit_price(
        self,
        ticker: str,
        date: str,
        system_timestamp: str,
        open_val: float,
        high_val: float,
        low_val: float,
        close_val: float,
        volume_val: float,
        adjustment_factor: float = 1.0
    ) -> bool:
        """Insert or replace a price observation with SQLite fallback."""
        res_sqlite = super().save_pit_price(ticker, date, system_timestamp, open_val, high_val, low_val, close_val, volume_val, adjustment_factor)
        if not self._is_pg:
            return res_sqlite
        try:
            with self._pool.connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute("""
                        INSERT INTO bi_temporal_price_history 
                        (ticker, date, system_timestamp, open, high, low, close, volume, adjustment_factor)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                        ON CONFLICT (ticker, date, system_timestamp) DO UPDATE SET
                            open = EXCLUDED.open,
                            high = EXCLUDED.high,
                            low = EXCLUDED.low,
                            close = EXCLUDED.close,
                            volume = EXCLUDED.volume,
                            adjustment_factor = EXCLUDED.adjustment_factor
                    """, (
                        ticker.upper(), date, system_timestamp,
                        open_val, high_val, low_val, close_val, volume_val, adjustment_factor
                    ))
                    return True
        except Exception as e:
            logger.error("[PostgresStore] save_pit_price failed: %s", e)
            self._handle_pg_failure("save_pit_price", e)
            return res_sqlite

    def get_pit_price_history(
        self,
        tickers: List[str],
        as_of_system_timestamp: str,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> pd.DataFrame:
        """Retrieve historical OHLCV data from Postgres (or fallback SQLite)."""
        if not self._is_pg:
            return super().get_pit_price_history(tickers, as_of_system_timestamp, start_date, end_date)
        try:
            import pandas as pd
            if not tickers:
                return pd.DataFrame()
            
            placeholders = ",".join("%s" for _ in tickers)
            query = f"""
                WITH ranked_prices AS (
                    SELECT 
                        ticker, date, open, high, low, close, volume, adjustment_factor, system_timestamp,
                        ROW_NUMBER() OVER (
                            PARTITION BY ticker, date 
                            ORDER BY system_timestamp DESC
                        ) as rnk
                    FROM bi_temporal_price_history
                    WHERE ticker IN ({placeholders})
                      AND system_timestamp <= %s
            """
            params = [t.upper() for t in tickers]
            params.append(as_of_system_timestamp)
            
            if start_date:
                query += " AND date >= %s"
                params.append(start_date)
            if end_date:
                query += " AND date <= %s"
                params.append(end_date)
                
            query += """
                )
                SELECT ticker, date, open, high, low, close, volume, adjustment_factor, system_timestamp
                FROM ranked_prices
                WHERE rnk = 1
                ORDER BY date ASC
            """
            
            with self._pool.connection() as conn:
                df = pd.read_sql_query(query, conn, params=params)
                return df
        except Exception as e:
            logger.error("[PostgresStore] get_pit_price_history failed: %s", e)
            self._handle_pg_failure("get_pit_price_history", e)
            return super().get_pit_price_history(tickers, as_of_system_timestamp, start_date, end_date)

