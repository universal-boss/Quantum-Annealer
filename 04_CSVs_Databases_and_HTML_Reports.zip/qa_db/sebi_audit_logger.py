"""
qa_db/sebi_audit_logger.py
===========================
SEBI Algo Regulatory Compliance Audit Logger.

Generates an immutable SQLite/PostgreSQL audit trail with unique order tagging,
pre-trade risk control checks, cryptographic SHA-256 hash chaining,
database-level immutability triggers, and regulatory compliance verification.

ROUND 7 FIXES (R7-9a..h) — institutional hardening of the audit chain:
  (a) `PRAGMA recursive_triggers=ON` + an INSERT-time collision trigger close
      the `INSERT OR REPLACE` bypass (SQLite's implicit DELETE under OR REPLACE
      does not fire BEFORE DELETE triggers unless recursive triggers are on —
      previously a REPLACE silently overwrote history).
  (b) Optional HMAC-SHA256 keying of the chain via $QA_AUDIT_HMAC_KEY. A plain
      SHA-256 chain can be rewritten wholesale by anyone with DB write access
      and still verify; a keyed chain cannot (key never stored in the DB).
  (c) Audit-write failures now RAISE instead of returning False — an order
      that cannot be audited must not proceed (fail-closed, SEBI).
  (d) `quantity` is normalized to int BEFORE hashing and insert — a caller
      passing 100.0 or np.int64(100) previously hashed "100.0" while SQLite
      stored INTEGER 100, permanently flagging the row as tampered.
  (e) `compliance_passed` converted via bool() (int("true") raised ValueError
      and silently dropped the whole entry).
  (f) verify/write fallback symmetry — the verifier previously expected
      `None` as previous hash where the writer chained from GENESIS_HASH,
      poisoning every subsequent append with a false tampering alarm.
  (g) Legacy/unverifiable rows now count as violations — the report can no
      longer say "valid" while 90% of the trail is unverifiable.
  (h) All connections closed via contextlib.closing; external head-anchor
      export/import makes tail truncation detectable.
"""
from __future__ import annotations

import contextlib
import hmac
import logging
import math
import sqlite3
import time
import json
import hashlib
import os
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple
import threading

logger = logging.getLogger(__name__)

GENESIS_HASH = "0000000000000000000000000000000000000000000000000000000000000000"

# AUDIT-FIX (Round 5, 2-e-2): module-level lock serializing hash-chain appends.
# Without it, two concurrent writers (auto-run + manual run, or the web-dashboard
# process) can both SELECT the same last checksum and INSERT two records chained
# to the same prev_hash — a chain fork that verify_integrity() then reports as
# tampering. BEGIN IMMEDIATE below serializes across *processes*; this Lock
# serializes writers within this process.
_CHAIN_LOCK = threading.Lock()

# R7-9(b): optional HMAC key for the chain. Read once at import. When unset the
# chain falls back to plain SHA-256 (backwards compatible with existing DBs)
# and logs a warning at init so operators know the chain is unkeyed.
_HMAC_KEY: Optional[bytes] = None
if os.environ.get("QA_AUDIT_HMAC_KEY"):
    _HMAC_KEY = os.environ["QA_AUDIT_HMAC_KEY"].encode("utf-8")


class SEBIAuditLogger:
    """
    SEBI Mandatory Algo Trading Compliance Audit Trail Logger.
    Implements a cryptographic SHA-256 hash chain with database-level immutability triggers.
    """

    def __init__(self, db_path: str = ""):
        # AUDIT-FIX (Round 5, 2-e-7): the old default "qa_db/sebi_algo_audit.db"
        # was CWD-relative — launched from any other directory, the regulatory
        # trail silently fragmented into a fresh DB per working directory.
        # Anchor to this file's directory instead.
        if not db_path:
            db_path = str(Path(__file__).resolve().parent / "sebi_algo_audit.db")
        self.db_path = db_path
        if _HMAC_KEY is None:
            # AUDIT-FIX (Round 13, SEC-7): in a PRODUCTION deployment an
            # unkeyed chain must be a blocking condition, not a warning
            # (anyone with DB write access can rewrite history and still
            # pass verify_integrity()). Dev/test environments keep the
            # permissive default so the 207-test suite and local runs work.
            if os.environ.get("ENV", "").lower() in ("production", "prod"):
                raise RuntimeError(
                    "SEBIAuditLogger refuses to start in production without "
                    "QA_AUDIT_HMAC_KEY — an unkeyed hash chain is forgeable "
                    "by anyone with DB write access."
                )
            logger.warning(
                "[SEBIAudit] QA_AUDIT_HMAC_KEY not set — running with UNKEYED "
                "SHA-256 chain. Anyone with DB write access can rewrite history "
                "and still pass verify_integrity(). Set the environment variable "
                "before the first append for a tamper-evident (keyed) chain."
            )
        # AUDIT-FIX (Round 13, SEC-8): tamper verification was DEAD CODE —
        # verify_integrity() / export_head_anchor() had zero call sites, so
        # the chain was appended to but never checked (no startup check, no
        # scheduled verification). Run a verification pass at init (after
        # the schema exists) and surface a CRITICAL alert on tampering.
        self._init_db()
        try:
            _report = self.verify_integrity()
            if _report.get("valid") is False:
                logger.critical(
                    "[SEBIAudit] TAMPER CHECK FAILED at startup: %s",
                    json.dumps(_report)[:2000],
                )
            elif _report.get("valid") is None:
                # ROUND 45 FIX: verification could not run (transient DB error
                # etc.) — this is NOT tampering. Log at warning, not critical.
                logger.warning(
                    "[SEBIAudit] Chain verification unavailable at startup (%s): %s",
                    _report.get("error_type", "?"), _report.get("message", ""),
                )
            # Best-effort head-anchor export after every init: tail
            # truncation detection (R7-9h) requires an anchor that is
            # refreshed as the chain grows.
            try:
                self.export_head_anchor()
            except Exception:
                pass
        except Exception as _verify_err:
            # A broken verification pass must not take down the trading app,
            # but it MUST be loud.
            logger.critical(
                "[SEBIAudit] Startup integrity verification ERROR: %s",
                _verify_err,
                exc_info=True,
            )

    def _init_db(self):
        try:
            Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
            with contextlib.closing(sqlite3.connect(self.db_path)) as conn, conn:
                # R7-9(a): recursive triggers must be ON for the REPLACE-bypass
                # guard below to work (session-scoped pragma, re-issued per
                # connection by the trigger creation check).
                conn.execute("PRAGMA recursive_triggers=ON")
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS sebi_algo_audit_trail (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        timestamp REAL,
                        order_id TEXT,
                        ticker TEXT,
                        action TEXT,
                        quantity INTEGER,
                        price REAL,
                        algo_category TEXT,
                        compliance_passed INTEGER,
                        compliance_details TEXT,
                        prev_hash TEXT,
                        checksum TEXT
                    )
                """)

                # Check if prev_hash column exists in older database instances
                cursor = conn.execute("PRAGMA table_info(sebi_algo_audit_trail)")
                columns = [row[1] for row in cursor.fetchall()]
                if "prev_hash" not in columns:
                    try:
                        conn.execute("ALTER TABLE sebi_algo_audit_trail ADD COLUMN prev_hash TEXT")
                    except Exception:
                        pass

                # Database-level immutability triggers (prevent retroactive UPDATE / DELETE)
                conn.execute("""
                    CREATE TRIGGER IF NOT EXISTS prevent_sebi_audit_update
                    BEFORE UPDATE ON sebi_algo_audit_trail
                    BEGIN
                        SELECT RAISE(FAIL, 'SEBI Regulatory Audit Trail is immutable: UPDATE operations are strictly prohibited.');
                    END;
                """)
                conn.execute("""
                    CREATE TRIGGER IF NOT EXISTS prevent_sebi_audit_delete
                    BEFORE DELETE ON sebi_algo_audit_trail
                    BEGIN
                        SELECT RAISE(FAIL, 'SEBI Regulatory Audit Trail is immutable: DELETE operations are strictly prohibited.');
                    END;
                """)
                # R7-9(a): forbid INSERT of a row whose id already exists. This
                # closes the `INSERT OR REPLACE` hole: the implicit DELETE that
                # REPLACE performs does not fire BEFORE DELETE triggers unless
                # recursive_triggers=ON, so previously row 1 could be silently
                # overwritten. With this trigger the REPLACE raises instead.
                conn.execute("""
                    CREATE TRIGGER IF NOT EXISTS prevent_sebi_audit_replace
                    BEFORE INSERT ON sebi_algo_audit_trail
                    WHEN NEW.id IS NOT NULL AND EXISTS (
                        SELECT 1 FROM sebi_algo_audit_trail WHERE id = NEW.id
                    )
                    BEGIN
                        SELECT RAISE(FAIL, 'SEBI Regulatory Audit Trail is append-only: inserting over an existing id is prohibited.');
                    END;
                """)
                conn.commit()
        except Exception as e:
            # R7-9(c): a broken audit DB must not be silently operational.
            logger.critical("[SEBIAudit] Init FAILED: %s", e, exc_info=True)
            raise

    def _compute_entry_hash(self, prev_hash: str, order_id: str, ticker: str, action: str,
                            quantity: int, price: float, algo_category: str,
                            compliance_passed: int, details_json: str, ts: float) -> str:
        # R7-9(d): quantity normalized to int by the caller BEFORE hashing; the
        # canonical serialization is kept byte-identical for verification.
        payload = (
            f"{prev_hash}|{order_id}|{ticker}|{action}|{quantity}|"
            f"{price:.6f}|{algo_category}|{compliance_passed}|{details_json}|{ts:.6f}"
        )
        if _HMAC_KEY is not None:
            return hmac.new(_HMAC_KEY, payload.encode("utf-8"), hashlib.sha256).hexdigest()
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def log_algo_order(self, order_id: str, ticker: str, action: str, quantity: int,
                       price: float, algo_category: str, compliance_passed: bool,
                       details: Dict[str, Any]) -> bool:
        """
        Appends an immutable, cryptographically chained audit log entry for SEBI compliance.

        R7-9(c): FAIL-CLOSED. A regulatory audit entry that cannot be persisted
        raises RuntimeError — callers (broker execution path) must treat an
        exception here as a BLOCKING event: the order must not be submitted
        without a successful audit append. Returning a silent False that nobody
        checks is how unauditable orders happen.
        """
        ts = time.time()
        details_json = json.dumps(details, sort_keys=True)
        # R7-9(e): bool() is safe for truthy strings / numpy bools; int() raised.
        compliance_int = 1 if compliance_passed else 0
        # R7-9(d): normalize quantity BEFORE hashing AND insert so the stored
        # INTEGER round-trips identically through verification.
        quantity_int = int(quantity)

        # AUDIT-FIX (Round 13, SEC-6): the regulatory record accepted
        # NaN/inf/negative prices and non-positive quantities. A NaN price
        # hashes as "nan", SQLite stores NULL, and verification later hits
        # f"{None:.6f}" → TypeError → the WHOLE integrity report turns
        # invalid from one bad record (availability loss on the tamper
        # report). Negative/zero quantity and non-finite price are invalid
        # order intents — reject at the audit boundary (fail-closed).
        _price_f = float(price)
        if not math.isfinite(_price_f) or _price_f <= 0:
            raise ValueError(
                f"AUDIT_REJECTED: order {order_id} has invalid price {price!r} "
                f"(must be finite and > 0)"
            )
        if quantity_int <= 0:
            raise ValueError(
                f"AUDIT_REJECTED: order {order_id} has non-positive quantity {quantity!r}"
            )
        if not order_id or not str(order_id).strip() or not str(ticker).strip():
            raise ValueError(
                f"AUDIT_REJECTED: order missing id or ticker ({order_id!r}, {ticker!r})"
            )
        price = _price_f

        # AUDIT-FIX (Round 5, 2-e-2): hold the chain lock and BEGIN IMMEDIATE
        # *before* reading the last checksum so the read→insert pair is one
        # serialized write transaction (prevents chain forks under concurrency).
        try:
            with _CHAIN_LOCK, contextlib.closing(sqlite3.connect(self.db_path, timeout=10)) as conn:
                conn.execute("PRAGMA recursive_triggers=ON")  # R7-9(a): per-connection
                conn.execute("BEGIN IMMEDIATE")
                # Fetch last row's hash to maintain cryptographic chain
                cursor = conn.execute(
                    "SELECT checksum FROM sebi_algo_audit_trail ORDER BY id DESC LIMIT 1"
                )
                last_row = cursor.fetchone()
                prev_hash = last_row[0] if (last_row and last_row[0]) else GENESIS_HASH

                # Compute current entry's hash chained to prev_hash
                checksum = self._compute_entry_hash(
                    prev_hash=prev_hash,
                    order_id=order_id,
                    ticker=ticker,
                    action=action,
                    quantity=quantity_int,
                    price=price,
                    algo_category=algo_category,
                    compliance_passed=compliance_int,
                    details_json=details_json,
                    ts=ts
                )

                conn.execute("""
                    INSERT INTO sebi_algo_audit_trail
                    (timestamp, order_id, ticker, action, quantity, price, algo_category, compliance_passed, compliance_details, prev_hash, checksum)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (ts, order_id, ticker, action, quantity_int, price, algo_category, compliance_int, details_json, prev_hash, checksum))
                conn.commit()
            return True
        except Exception as e:
            # R7-9(c): fail closed — this is a regulatory write, not a best-effort log.
            logger.critical(
                "[SEBIAudit] AUDIT WRITE FAILED for order %s (%s %s %s) — entry NOT "
                "persisted; treat as a blocking compliance event: %s",
                order_id, action, quantity_int, ticker, e, exc_info=True,
            )
            raise RuntimeError(
                f"SEBI audit append failed for order {order_id}: {e}. "
                "Order submission must be blocked until the audit trail is writable."
            ) from e

    def export_head_anchor(self, anchor_path: Optional[str] = None) -> Optional[str]:
        """R7-9(h): export the current chain head checksum + id to an external
        anchor file (append-mode sidecar). Truncation of the DB tail becomes
        detectable by comparing the DB head against the latest anchor.
        Returns the exported checksum, or None on failure.
        """
        if anchor_path is None:
            anchor_path = str(Path(self.db_path).with_suffix(".anchor"))
        try:
            with contextlib.closing(sqlite3.connect(self.db_path, timeout=10)) as conn:
                row = conn.execute(
                    "SELECT id, checksum FROM sebi_algo_audit_trail ORDER BY id DESC LIMIT 1"
                ).fetchone()
            if not row or not row[1]:
                return None
            line = f"{int(time.time())}|{row[0]}|{row[1]}\n"
            with open(anchor_path, "a", encoding="utf-8") as f:
                f.write(line)
            return str(row[1])
        except Exception as e:
            logger.error("[SEBIAudit] Head anchor export failed: %s", e, exc_info=True)
            return None

    def verify_integrity(self) -> Dict[str, Any]:
        """
        Cryptographically validates the entire audit trail from genesis to head.
        Returns a verification report indicating whether the chain is unbroken.

        R7-9(f): the verifier's expected_prev now applies the same
        GENESIS_HASH fallback the writer uses for a NULL previous checksum,
        eliminating the permanent false "prev_hash mismatch" alarms on
        legacy-tailed chains.

        R7-9(g): legacy/unverifiable rows are reported as violations — a
        report can no longer claim validity while a majority of the trail is
        unverifiable (attacker-groomable condition: corrupt a checksum into
        a non-64-char value and it becomes exempt from verification).
        """
        try:
            with contextlib.closing(sqlite3.connect(self.db_path, timeout=10)) as conn:
                conn.execute("PRAGMA recursive_triggers=ON")
                rows = conn.execute("""
                    SELECT id, timestamp, order_id, ticker, action, quantity, price,
                           algo_category, compliance_passed, compliance_details, prev_hash, checksum
                    FROM sebi_algo_audit_trail
                    ORDER BY id ASC
                """).fetchall()

            if not rows:
                return {"valid": True, "total_records": 0, "verified_chained_records": 0, "message": "Empty log"}

            total_records = len(rows)
            verified_count = 0
            legacy_count = 0
            violations = []

            for i, row in enumerate(rows):
                (r_id, ts, order_id, ticker, action, quantity, price,
                 algo_cat, comp_passed, details_json, prev_h, checksum) = row

                # Check if this is a legacy entry (non-SHA256 checksum)
                # AUDIT-FIX (Round 5): guard None checksum — len(None) raised
                # TypeError and aborted the whole verification pass.
                if checksum is None or len(checksum) != 64 or ":" in checksum:
                    legacy_count += 1
                    # R7-9(g): unverifiable rows are violations, not skips.
                    violations.append(
                        f"Row {r_id}: unverifiable legacy/invalid checksum format "
                        "(row cannot be cryptographically attested)"
                    )
                    continue

                # R7-9(f): same fallback the writer uses — NULL previous checksum
                # chains from GENESIS on both sides of the comparison.
                expected_prev = (rows[i - 1][11] if i > 0 else None) or GENESIS_HASH
                if prev_h and prev_h != expected_prev:
                    violations.append(f"Row {r_id}: prev_hash mismatch (expected {expected_prev}, got {prev_h})")

                # Verify hash recalculation
                try:
                    recomputed = self._compute_entry_hash(
                        prev_hash=prev_h or expected_prev,
                        order_id=order_id,
                        ticker=ticker,
                        action=action,
                        quantity=quantity,
                        price=price,
                        algo_category=algo_cat,
                        compliance_passed=comp_passed,
                        details_json=details_json,
                        ts=ts
                    )
                    if recomputed != checksum:
                        violations.append(f"Row {r_id}: hash tampering detected (stored {checksum}, computed {recomputed})")
                    else:
                        verified_count += 1
                except Exception as ex:
                    violations.append(f"Row {r_id}: recalculation error: {ex}")

            # R7-9(g): any violation (incl. unverifiable legacy rows) invalidates.
            is_valid = len(violations) == 0
            return {
                "valid": is_valid,
                "total_records": total_records,
                "verified_chained_records": verified_count,
                "legacy_records": legacy_count,
                "violations": violations,
                "hmac_keyed": _HMAC_KEY is not None,
                "message": (
                    "Audit chain intact and cryptographically verified"
                    if is_valid
                    else f"Audit violations found: {len(violations)}"
                    + (f" (of which {legacy_count} unverifiable legacy rows)" if legacy_count else "")
                ),
            }
        except Exception as e:
            # ROUND 45 FIX: a transient DB error (e.g. sqlite3.OperationalError
            # "database is locked" while the dashboard holds BEGIN IMMEDIATE)
            # used to return valid:False, which __init__ logged as
            # "TAMPER CHECK FAILED" — a false CRITICAL regulatory alarm
            # indistinguishable from real chain corruption. Verification
            # failures due to infrastructure errors are now reported as
            # valid:None (unknown) with an explicit error_type, and the
            # startup check no longer treats them as tampering.
            import sqlite3 as _sq
            transient = isinstance(e, (_sq.OperationalError, _sq.DatabaseError, OSError))
            return {
                "valid": None,
                "error": str(e),
                "error_type": type(e).__name__,
                "transient": bool(transient),
                "message": (
                    "Chain verification unavailable (transient infrastructure error)"
                    if transient
                    else f"Chain verification error: {type(e).__name__}"
                ),
            }
