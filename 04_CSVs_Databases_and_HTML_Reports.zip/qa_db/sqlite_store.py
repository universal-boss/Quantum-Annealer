"""
qa_db/sqlite_store.py
======================
High-performance SQLite database driver for local portfolio data warehousing.
Tracks optimization runs, OOS backtest metrics, factor validation, and notes.
"""
from __future__ import annotations

import contextlib
import json
import sqlite3
import time
import logging
from datetime import datetime
from typing import Any, Dict, List, Optional

try:
    import pandas as pd
except ImportError:
    pd = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)


class SQLiteStore:
    """Institutional-grade SQLite local database warehouse.
    
    Supports transactional updates, schema migrations, and full audit logging
    of all portfolio optimizer runs.
    """

    def __init__(self, db_path: str) -> None:
        self.db_path = db_path
        self._init_db()

    @property
    def name(self) -> str:
        """AUDIT-FIX (Round 5, 2-e-8): human-readable store identifier.
        ProviderSwitcherDialog formats `s.name` after a DB switch; without
        this property the AttributeError surfaced only *after* set_store()
        had already succeeded, showing '❌ DB:' for a successful switch."""
        return "SQLite"

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, timeout=10)
        try:
            conn.execute("PRAGMA synchronous=NORMAL;")
            conn.execute("PRAGMA busy_timeout=5000;")
        except Exception:
            pass
        return conn

    def _init_db(self) -> None:
        """Create tables and indexes if they do not exist."""
        try:
            # L34-fix: sqlite3 Connection context manager only commits/rollbacks;
            # it does NOT close the connection. Use contextlib.closing to ensure close().
            with contextlib.closing(self._connect()) as conn:
                cursor = conn.cursor()
                cursor.execute("PRAGMA journal_mode=WAL;")
                mode = cursor.fetchone()[0]
                logger.info("[SQLiteStore] SQLite journal mode set to: %s", mode)
                
                # 1. Runs Table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS runs (
                        id TEXT PRIMARY KEY,
                        timestamp INTEGER,
                        regime TEXT,
                        vix REAL,
                        n_stocks INTEGER,
                        solver TEXT,
                        energy REAL,
                        payload TEXT,
                        config TEXT,
                        cfg_hash TEXT
                    )
                """)
                
                # 2. Notes Table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS notes (
                        run_id TEXT PRIMARY KEY,
                        text TEXT,
                        updated_at INTEGER
                    )
                """)
                
                # 3. Watchlists Table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS watchlists (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        tickers TEXT,
                        updated_at INTEGER
                    )
                """)
                
                # 4. Information Coefficient (IC) Table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS ic_observations (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        ticker TEXT,
                        observation_date TEXT,
                        metric_name TEXT,
                        value REAL
                    )
                """)
                
                # 5. Out-of-Sample (OOS) Table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS oos_results (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        run_id TEXT,
                        date TEXT,
                        portfolio_return REAL,
                        benchmark_return REAL,
                        is_sharpe REAL,
                        oos_sharpe REAL
                    )
                """)

                # 6. Custom Universes Table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS custom_universes (
                        name TEXT PRIMARY KEY,
                        tickers TEXT,
                        updated_at INTEGER
                    )
                """)

                # 7. Bi-Temporal Price History Table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS bi_temporal_price_history (
                        ticker TEXT,
                        date TEXT,
                        system_timestamp TEXT,
                        open REAL,
                        high REAL,
                        low REAL,
                        close REAL,
                        volume REAL,
                        adjustment_factor REAL,
                        PRIMARY KEY (ticker, date, system_timestamp)
                    )
                """)

                # 8. Strategy Profiles Table
                # AUDIT-FIX (Round 5, 2-e-4): StrategyProfileDialog calls
                # save_profile / list_profiles / load_profile / delete_profile
                # on the store — none of which existed, so profile persistence
                # always raised AttributeError ('SQLiteStore' object has no
                # attribute 'save_profile').
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS strategy_profiles (
                        name TEXT PRIMARY KEY,
                        cfg TEXT,
                        updated_at INTEGER
                    )
                """)

                # 9. Approval / order-audit notes reuse the notes table.

                # Dynamic Schema Migration: check if columns exist, if not alter table
                cursor.execute("PRAGMA table_info(oos_results)")
                columns = [row[1] for row in cursor.fetchall()]
                if columns:
                    if "is_sharpe" not in columns:
                        cursor.execute("ALTER TABLE oos_results ADD COLUMN is_sharpe REAL")
                    if "oos_sharpe" not in columns:
                        cursor.execute("ALTER TABLE oos_results ADD COLUMN oos_sharpe REAL")

                # AUDIT-FIX (Round 5, 2-e-6): runs-table metrics migration. The
                # CircuitBreaker (utils.py) reads r.get('Ann Ret') from
                # load_history() rows to detect performance collapse; the runs
                # table previously had no metrics columns, so the breaker saw
                # an empty history and was silently dead on the store path.
                cursor.execute("PRAGMA table_info(runs)")
                run_cols = [row[1] for row in cursor.fetchall()]
                if run_cols:
                    if "ann_return" not in run_cols:
                        cursor.execute("ALTER TABLE runs ADD COLUMN ann_return REAL")
                    if "sharpe" not in run_cols:
                        cursor.execute("ALTER TABLE runs ADD COLUMN sharpe REAL")
                
                # Indexes for O(1) performance lookups
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_runs_timestamp ON runs(timestamp)")
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_ic_ticker ON ic_observations(ticker)")
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_oos_run ON oos_results(run_id)")
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_bi_temporal_ticker_date ON bi_temporal_price_history(ticker, date)")
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_bi_temporal_system_ts ON bi_temporal_price_history(system_timestamp)")
                
                conn.commit()
                logger.info("[SQLiteStore] Local Database Warehouse successfully initialized at: %s", self.db_path)
        except Exception as e:
            logger.error("[SQLiteStore] Initialization failed: %s", e)

    def save_run(
        self,
        payload: dict,
        config: dict,
        regime_info: Optional[dict] = None,
        vix: Optional[float] = None,
        n_stocks: Optional[int] = None,
        solver: Optional[str] = None,
        energy: Optional[float] = None,
        cfg_hash: Optional[str] = None,
        **kwargs
    ) -> bool:
        """Persist a complete portfolio optimization run snapshot."""
        try:
            run_id = payload.get("run_id") or f"run_{int(time.time())}"
            timestamp = int(time.time())

            # AUDIT-FIX (Round 5, 2-e-5): callers invoke save_run(...,
            # india_vix=payload.get("india_vix")) — 'india_vix' fell into
            # **kwargs and was silently discarded, leaving runs.vix NULL and
            # load_history() substituting the hardcoded 15.0.
            if vix is None:
                vix = kwargs.get("india_vix")

            regime = "Unknown"
            if regime_info and isinstance(regime_info, dict):
                regime = regime_info.get("Regime", "Unknown")
            elif isinstance(regime_info, str):
                regime = regime_info

            # AUDIT-FIX (Round 5, 2-e-6): persist backtest metrics so
            # load_history() can expose 'Ann Ret' for the CircuitBreaker.
            _bt = payload.get("backtest") if isinstance(payload, dict) else None
            _bt = _bt if isinstance(_bt, dict) else {}
            _ann_ret = _bt.get("Annual Return", _bt.get("Ann Return"))
            # AUDIT-FIX (Round 32): optimizer payload uses "Sharpe" (short key),
            # not "Sharpe Ratio" — sharpe was silently NULL on every run, which
            # caused _handle_backtest_data to always see 0 qualifying runs and
            # fall through to the simulated-data path.
            # R34-7: explicit None checks instead of an `or` chain — `or` treats a
            # legitimate 0.0 Sharpe (or 0.0 annual return) as falsy and skips to
            # the next key, storing NULL for a measured zero.
            _sharpe = _bt.get("Sharpe Ratio")
            if _sharpe is None:
                _sharpe = _bt.get("Sharpe")
            if _sharpe is None:
                _sharpe = _bt.get("sharpe")
            # Also pull ann_return from payload["metrics"] as secondary source
            _metrics = payload.get("metrics") if isinstance(payload, dict) else None
            _metrics = _metrics if isinstance(_metrics, dict) else {}
            if _ann_ret is None:
                _ann_ret = _metrics.get("ann_return")
            if _sharpe is None:
                _sharpe = _metrics.get("sharpe")
            ann_return = float(_ann_ret) if isinstance(_ann_ret, (int, float)) else None
            sharpe = float(_sharpe) if isinstance(_sharpe, (int, float)) else None

            # Clean payload data for serializability
            clean_payload = {
                "selected": payload.get("selected", []),
                "weights": payload.get("weights", {}),
                "portfolio_health": payload.get("portfolio_health", {}),
            }

            # L34-fix: sqlite3 Connection context manager only commits/rollbacks;
            # it does NOT close the connection. Use contextlib.closing to ensure close().
            with contextlib.closing(sqlite3.connect(self.db_path, timeout=10)) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT OR REPLACE INTO runs (id, timestamp, regime, vix, n_stocks, solver, energy, payload, config, cfg_hash, ann_return, sharpe)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    run_id,
                    timestamp,
                    regime,
                    vix,
                    n_stocks or len(payload.get("selected", [])),
                    solver or "SimulatedAnnealing",
                    energy,
                    json.dumps(clean_payload),
                    json.dumps(config),
                    cfg_hash,
                    ann_return,
                    sharpe
                ))
                conn.commit()
                logger.info("[SQLiteStore] Saved run details for id: %s", run_id)
                return True
        except Exception as e:
            logger.error("[SQLiteStore] save_run failed: %s", e)
            return False

    def load_history(self, limit: int = 30) -> List[dict]:
        """Fetch historical runs to display in the audit history grid."""
        try:
            # L34-fix: sqlite3 Connection context manager only commits/rollbacks;
            # it does NOT close the connection. Use contextlib.closing to ensure close().
            with contextlib.closing(sqlite3.connect(self.db_path, timeout=10)) as conn:
                conn.row_factory = sqlite3.Row
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT id, timestamp, regime, vix, n_stocks, solver, energy, cfg_hash, ann_return, sharpe
                    FROM runs
                    ORDER BY timestamp DESC
                    LIMIT ?
                """, (limit,))

                rows = cursor.fetchall()
                result = []
                for r in rows:
                    dt = datetime.fromtimestamp(r["timestamp"])
                    result.append({
                        "Run ID": r["id"],
                        "Date": dt.strftime("%Y-%m-%d"),
                        "Time": dt.strftime("%H:%M:%S"),
                        "Regime": r["regime"],
                        "VIX": r["vix"] if r["vix"] is not None else 15.0,
                        "Stocks": r["n_stocks"],
                        "Solver": r["solver"],
                        "Energy": round(r["energy"], 4) if r["energy"] is not None else 0.0,
                        "CfgHash": r["cfg_hash"] or "n/a",
                        # AUDIT-FIX (Round 5, 2-e-6): expose backtest metrics so
                        # CircuitBreaker.check_history (utils.py) can evaluate
                        # 'Ann Ret' on the store path instead of always [].
                        "Ann Ret": r["ann_return"] if "ann_return" in r.keys() and r["ann_return"] is not None else "",
                        "Sharpe": r["sharpe"] if "sharpe" in r.keys() and r["sharpe"] is not None else "",
                    })
                return result
        except Exception as e:
            logger.error("[SQLiteStore] load_history failed: %s", e)
            return []

    def save_note(self, run_id: str, text: str) -> bool:
        """Save a dynamic research thesis note linked to a specific run."""
        try:
            # L34-fix: sqlite3 Connection context manager only commits/rollbacks;
            # it does NOT close the connection. Use contextlib.closing to ensure close().
            with contextlib.closing(sqlite3.connect(self.db_path, timeout=10)) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT OR REPLACE INTO notes (run_id, text, updated_at)
                    VALUES (?, ?, ?)
                """, (run_id, text, int(time.time())))
                conn.commit()
                return True
        except Exception as e:
            logger.error("[SQLiteStore] save_note failed: %s", e)
            return False

    def load_note(self, run_id: str) -> str:
        """Load the research thesis note for a given run."""
        try:
            # L34-fix: sqlite3 Connection context manager only commits/rollbacks;
            # it does NOT close the connection. Use contextlib.closing to ensure close().
            with contextlib.closing(sqlite3.connect(self.db_path, timeout=10)) as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT text FROM notes WHERE run_id = ?", (run_id,))
                row = cursor.fetchone()
                return row[0] if row else ""
        except Exception as e:
            logger.error("[SQLiteStore] load_note failed: %s", e)
            return ""

    def save_watchlist(self, tickers_str: str) -> bool:
        """Save the active workspace ticker watchlist."""
        try:
            # L34-fix: sqlite3 Connection context manager only commits/rollbacks;
            # it does NOT close the connection. Use contextlib.closing to ensure close().
            with contextlib.closing(sqlite3.connect(self.db_path, timeout=10)) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO watchlists (tickers, updated_at)
                    VALUES (?, ?)
                """, (tickers_str, int(time.time())))
                conn.commit()
                return True
        except Exception as e:
            logger.error("[SQLiteStore] save_watchlist failed: %s", e)
            return False

    def load_watchlist(self) -> str:
        """Load the most recently saved workspace ticker watchlist."""
        try:
            # L34-fix: sqlite3 Connection context manager only commits/rollbacks;
            # it does NOT close the connection. Use contextlib.closing to ensure close().
            with contextlib.closing(sqlite3.connect(self.db_path, timeout=10)) as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT tickers FROM watchlists ORDER BY id DESC LIMIT 1")
                row = cursor.fetchone()
                return row[0] if row else ""
        except Exception as e:
            logger.error("[SQLiteStore] load_watchlist failed: %s", e)
            return ""

    def save_ic_observations(self, observations: list) -> bool:
        """Save historical factor information coefficient observations."""
        if not observations:
            return True

        valid_obs = []
        for obs in observations:
            if not isinstance(obs, dict):
                continue
            ticker = obs.get("ticker")
            obs_date = obs.get("date")
            metric = obs.get("metric")
            val = obs.get("value")

            # Row level validation
            if not ticker or not isinstance(ticker, str):
                continue
            if not obs_date or not isinstance(obs_date, str):
                continue
            if not metric or not isinstance(metric, str):
                continue
            try:
                if val is None:
                    continue
                val_float = float(val)
                import math
                if math.isnan(val_float) or math.isinf(val_float):
                    continue
            except (ValueError, TypeError):
                continue

            valid_obs.append((ticker, obs_date, metric, val_float))

        if not valid_obs:
            return True

        try:
            # L34-fix: sqlite3 Connection context manager only commits/rollbacks;
            # it does NOT close the connection. Use contextlib.closing to ensure close().
            with contextlib.closing(sqlite3.connect(self.db_path, timeout=10)) as conn:
                cursor = conn.cursor()
                try:
                    cursor.executemany("""
                        INSERT INTO ic_observations (ticker, observation_date, metric_name, value)
                        VALUES (?, ?, ?, ?)
                    """, valid_obs)
                    conn.commit()
                    return True
                except Exception as ex:
                    conn.rollback()
                    raise ex
        except Exception as e:
            logger.error("[SQLiteStore] save_ic_observations failed: %s", e)
            return False

    def save_oos_result(
        self,
        run_id: Optional[str] = None,
        date: Optional[str] = None,
        port_ret: Optional[float] = None,
        bench_ret: Optional[float] = None,
        oos_result: Optional[dict] = None,
        regime: Optional[str] = None,
        log_cb = None,
        **kwargs
    ) -> bool:
        """Save Out-of-Sample forward test metrics."""
        def _safe_float(val):
            import math
            if val is None:
                return None
            try:
                f = float(str(val).strip())
                return None if (math.isnan(f) or math.isinf(f)) else f
            except Exception:
                return None

        try:
            # Generate a run_id if not present
            if not run_id:
                run_id = f"run_{int(time.time())}"
            
            # If oos_result dict is provided, extract metrics from it
            if oos_result and isinstance(oos_result, dict):
                port_ret = oos_result.get("OOS Sharpe")
                bench_ret = oos_result.get("IS Sharpe")
                date = str(oos_result.get("OOS Period", datetime.now().strftime("%Y-%m-%d")))
            
            # Apply _safe_float unconditionally to normalize both positional/keyword inputs
            port_ret = _safe_float(port_ret)
            bench_ret = _safe_float(bench_ret)

            if date is None:
                date = datetime.now().strftime("%Y-%m-%d")

            # L34-fix: sqlite3 Connection context manager only commits/rollbacks;
            # it does NOT close the connection. Use contextlib.closing to ensure close().
            with contextlib.closing(sqlite3.connect(self.db_path, timeout=10)) as conn:
                cursor = conn.cursor()
                # port_ret  = OOS Sharpe  (extracted from oos_result["OOS Sharpe"])
                # AUDIT-FIX (Round 8, B13 — Part 2B): the INSERT previously wrote
                # SHARPE values into the portfolio_return / benchmark_return
                # columns (data-model corruption: any downstream consumer that
                # computes return-based statistics from those columns reads
                # Sharpe ratios silently). Sharpe metrics now go ONLY to the
                # correctly-labeled is_sharpe / oos_sharpe columns; the return
                # columns stay NULL unless actual returns are supplied.
                cursor.execute("""
                    INSERT INTO oos_results (run_id, date, portfolio_return, benchmark_return, is_sharpe, oos_sharpe)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (run_id, date, None, None, bench_ret, port_ret))  # B13: is_sharpe=IS(bench_ret), oos_sharpe=OOS(port_ret); return columns NULL
                conn.commit()
                if log_cb:
                    log_cb(f"[DB] OOS result saved successfully for {run_id}: IS Sharpe={bench_ret}, OOS Sharpe={port_ret}")
                return True
        except Exception as e:
            logger.error("[SQLiteStore] save_oos_result failed: %s", e)
            if log_cb:
                log_cb(f"[DB] save_oos_result failed: {e}")
            return False

    def save_universe(self, name: str, tickers: str) -> bool:
        """Save a named custom universe (comma-separated symbols)."""
        try:
            with contextlib.closing(sqlite3.connect(self.db_path, timeout=10)) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT OR REPLACE INTO custom_universes (name, tickers, updated_at)
                    VALUES (?, ?, ?)
                """, (name, tickers, int(time.time())))
                conn.commit()
                return True
        except Exception as e:
            logger.error("[SQLiteStore] save_universe failed: %s", e)
            return False

    def load_universe(self, name: str) -> str:
        """Load a named custom universe's symbols."""
        try:
            with contextlib.closing(sqlite3.connect(self.db_path, timeout=10)) as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT tickers FROM custom_universes WHERE name = ?", (name,))
                row = cursor.fetchone()
                return row[0] if row else ""
        except Exception as e:
            logger.error("[SQLiteStore] load_universe failed: %s", e)
            return ""

    def list_universes(self) -> List[str]:
        """List all saved custom universe names."""
        try:
            with contextlib.closing(sqlite3.connect(self.db_path, timeout=10)) as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT name FROM custom_universes ORDER BY name ASC")
                return [row[0] for row in cursor.fetchall()]
        except Exception as e:
            logger.error("[SQLiteStore] list_universes failed: %s", e)
            return []

    def delete_universe(self, name: str) -> bool:
        """Delete a named custom universe."""
        try:
            with contextlib.closing(sqlite3.connect(self.db_path, timeout=10)) as conn:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM custom_universes WHERE name = ?", (name,))
                conn.commit()
                return True
        except Exception as e:
            logger.error("[SQLiteStore] delete_universe failed: %s", e)
            return False

    # ── Strategy Profiles ─────────────────────────────────────────────────────
    # AUDIT-FIX (Round 5, 2-e-4): StrategyProfileDialog (ui/custom_widgets.py)
    # calls save_profile / list_profiles / load_profile / delete_profile on the
    # store. None of these existed on any store class, so the dialog's Save /
    # Load / Delete buttons always failed with AttributeError and the profile
    # list was silently empty. PostgresStore inherits these (it subclasses
    # SQLiteStore) and overrides them for the PG path.

    def save_profile(self, name: str, cfg: dict) -> bool:
        """Persist a named strategy-configuration snapshot (JSON)."""
        try:
            with contextlib.closing(sqlite3.connect(self.db_path, timeout=10)) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT OR REPLACE INTO strategy_profiles (name, cfg, updated_at)
                    VALUES (?, ?, ?)
                """, (name, json.dumps(cfg, default=str), int(time.time())))
                conn.commit()
                return True
        except Exception as e:
            logger.error("[SQLiteStore] save_profile failed: %s", e)
            return False

    def load_profile(self, name: str) -> Optional[dict]:
        """Load a saved strategy-configuration snapshot by name."""
        try:
            with contextlib.closing(sqlite3.connect(self.db_path, timeout=10)) as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT cfg FROM strategy_profiles WHERE name = ?", (name,))
                row = cursor.fetchone()
                if not row or not row[0]:
                    return None
                return json.loads(row[0])
        except Exception as e:
            logger.error("[SQLiteStore] load_profile failed: %s", e)
            return None

    def list_profiles(self) -> List[str]:
        """List all saved strategy-profile names."""
        try:
            with contextlib.closing(sqlite3.connect(self.db_path, timeout=10)) as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT name FROM strategy_profiles ORDER BY name ASC")
                return [row[0] for row in cursor.fetchall()]
        except Exception as e:
            logger.error("[SQLiteStore] list_profiles failed: %s", e)
            return []

    def delete_profile(self, name: str) -> bool:
        """Delete a saved strategy profile by name."""
        try:
            with contextlib.closing(sqlite3.connect(self.db_path, timeout=10)) as conn:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM strategy_profiles WHERE name = ?", (name,))
                conn.commit()
                return True
        except Exception as e:
            logger.error("[SQLiteStore] delete_profile failed: %s", e)
            return False

    def save_pit_price(
        self,
        ticker: str,
        date: str,
        system_timestamp: str,
        open_val: float,
        high_val: float,
        low_val: float,
        close_val: float,
        volume_val: float,
        adjustment_factor: float = 1.0
    ) -> bool:
        """Insert or replace a price observation with a bi-temporal system_timestamp."""
        try:
            with contextlib.closing(sqlite3.connect(self.db_path, timeout=10)) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT OR REPLACE INTO bi_temporal_price_history 
                    (ticker, date, system_timestamp, open, high, low, close, volume, adjustment_factor)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    ticker.upper(), date, system_timestamp,
                    open_val, high_val, low_val, close_val, volume_val, adjustment_factor
                ))
                conn.commit()
                return True
        except Exception as e:
            logger.error("[SQLiteStore] save_pit_price failed: %s", e)
            return False

    def get_pit_price_history(
        self,
        tickers: List[str],
        as_of_system_timestamp: str,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> pd.DataFrame:
        """Retrieve historical OHLCV data as it was known before or at as_of_system_timestamp.
        For each (ticker, date), it takes the latest system_timestamp that is <= as_of_system_timestamp.
        """
        try:
            import pandas as pd
            if not tickers:
                return pd.DataFrame()
            
            placeholders = ",".join("?" for _ in tickers)
            query = f"""
                WITH ranked_prices AS (
                    SELECT 
                        ticker, date, open, high, low, close, volume, adjustment_factor, system_timestamp,
                        ROW_NUMBER() OVER (
                            PARTITION BY ticker, date 
                            ORDER BY system_timestamp DESC
                        ) as rnk
                    FROM bi_temporal_price_history
                    WHERE ticker IN ({placeholders})
                      AND system_timestamp <= ?
            """
            params = [t.upper() for t in tickers]
            params.append(as_of_system_timestamp)
            
            if start_date:
                query += " AND date >= ?"
                params.append(start_date)
            if end_date:
                query += " AND date <= ?"
                params.append(end_date)
                
            query += """
                )
                SELECT ticker, date, open, high, low, close, volume, adjustment_factor, system_timestamp
                FROM ranked_prices
                WHERE rnk = 1
                ORDER BY date ASC
            """
            
            with contextlib.closing(sqlite3.connect(self.db_path, timeout=10)) as conn:
                df = pd.read_sql_query(query, conn, params=params)
                return df
        except Exception as e:
            logger.error("[SQLiteStore] get_pit_price_history failed: %s", e)
            return pd.DataFrame()

